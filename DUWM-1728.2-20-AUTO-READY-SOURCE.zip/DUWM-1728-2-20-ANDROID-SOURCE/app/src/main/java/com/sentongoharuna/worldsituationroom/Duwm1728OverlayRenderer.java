package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.graphics.*;
import android.media.*;
import android.net.Uri;
import android.os.*;
import java.io.File;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Source-preserving GPU video export. Shared graphics, input timestamps, AAC retained.
 * Does not upscale, drop unsupported audio silently, invent source data or claim HDR conversion. */
public final class Duwm1728OverlayRenderer {
    private Duwm1728OverlayRenderer(){}
    public interface Progress{void update(int percent);}
    public static final class Spec {
        public long fromMs,toMs;public long tickerOriginMs=-1,captionOriginMs=-1;public String title="",place="",description="",reporter="",reportId="",ratio="ORIGINAL";
        public boolean bottom=true,breakingApproved;public Uri pipVideo;
        public String ticker="",template="GENERAL REPORT",captions="",provenance="REPORTER ACCOUNT • UNVERIFIED";
        public String composition=Duwm1728BroadcastComposition.FULL;
        public String frameMode=Duwm1728FramePlan.FILL;public float frameX=.5f,frameY=.5f;
        public int tickerSpeed=75;public Duwm1728CaptureTelemetry.Snapshot capturedTelemetry;
        public List<Duwm1728TelemetryTimeline.Point> recordedTrack=Collections.emptyList();
        public boolean includeSourceSummary,includeCoordinates;
        public List<Duwm1728TickerTimeline.Cue> tickerCues=Collections.emptyList(),captionCues=Collections.emptyList();
        public List<Duwm1728BroadcastLayout.Cue> automaticCaptions=Collections.emptyList(),automaticTickers=Collections.emptyList();
        public List<Duwm1728BroadcastLayout.Cue> renderedTickers=Collections.emptyList(),renderedCaptions=Collections.emptyList();
        public final AtomicBoolean cancelled=new AtomicBoolean();public Progress progress;
    }
    private static String available(String value){if(value==null)return "";String u=value.toUpperCase(Locale.ROOT);return u.contains("UNAVAILABLE")||u.contains("NOT REQUESTED")||u.contains("WITHHELD")||u.contains("MISSING")||u.contains("FETCHING")||u.contains("STALE")?"":value;}
    public static Duwm1728BroadcastLayout.Report reportAt(Spec s,long elapsed){
        Duwm1728BroadcastLayout.Report r=new Duwm1728BroadcastLayout.Report();r.title=s.title;r.location=s.place;r.description=s.description;r.category=s.template;r.reporter=s.reporter;r.breakingApproved=s.breakingApproved;r.provenance=s.provenance;r.coordinatesAllowed=s.includeCoordinates;r.tickerPixelsPerSecond=s.tickerSpeed;
        r.composition=Duwm1728BroadcastComposition.normalize(s.composition);
        // Structured automatic excerpts retain their source cue interval and
        // use measured pages. Manually entered tickers keep their marquee.
        r.automaticTickerPages=!s.automaticTickers.isEmpty();
        r.tickers.addAll(s.renderedTickers);r.captions.addAll(s.renderedCaptions);
        if(s.includeSourceSummary&&s.capturedTelemetry!=null){Duwm1728CaptureTelemetry.Snapshot measured=s.capturedTelemetry;Duwm1728TelemetryTimeline.Point point=Duwm1728TelemetryTimeline.at(s.recordedTrack,elapsed+s.fromMs);if(point!=null)measured=point.snapshot;
            r.clock=point==null?measured.captureTimeLabel():measured.captureTimeLabel().replace("CAPTURE-END","SAMPLE");r.heading=available(measured.compass);r.altitude=available(measured.altitude);r.weather=available(measured.weather);if(s.includeCoordinates&&measured.preciseEnabled)r.gps=available(measured.coordinates);}
        return r;
    }
    public static void drawOverlay(Canvas canvas,Spec spec,long elapsed,Bitmap pip){
        if(pip!=null&&!pip.isRecycled()){
            Duwm1728FramePlan.Inset frame=Duwm1728FramePlan.inset(canvas.getWidth(),canvas.getHeight(),pip.getWidth(),pip.getHeight());
            Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);RectF box=new RectF(frame.left,frame.top,frame.left+frame.width,frame.top+frame.height);
            float edge=frame.border*1.5f;p.setColor(0xFF041424);canvas.drawRect(box.left-edge,box.top-edge,box.right+edge,box.bottom+edge,p);
            canvas.drawBitmap(pip,null,box,p);p.setColor(0xFFDEE5EF);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(frame.border);canvas.drawRect(box,p);
        }
        Duwm1728BroadcastLayout.draw(new Duwm1728BroadcastCanvas(canvas),canvas.getWidth(),canvas.getHeight(),reportAt(spec,elapsed),elapsed);
    }
    public static void prepareTimelines(Spec spec){
        if(spec==null)throw new IllegalArgumentException("No broadcast specification");
        Duwm1728BroadcastTimeline.range(spec.fromMs,spec.toMs);
        spec.tickerCues=Duwm1728TickerTimeline.parse(spec.ticker);spec.captionCues=Duwm1728TickerTimeline.parse(spec.captions);
        spec.renderedTickers=spec.automaticTickers.isEmpty()
            ?Duwm1728BroadcastTimeline.tickers(spec.tickerCues,spec.tickerOriginMs<0?spec.fromMs:spec.tickerOriginMs,spec.fromMs,spec.toMs)
            :Duwm1728BroadcastTimeline.captions(spec.automaticTickers,spec.fromMs,spec.toMs);
        spec.renderedCaptions=spec.automaticCaptions.isEmpty()
            ?Duwm1728BroadcastTimeline.manualCaptions(spec.captionCues,spec.captionOriginMs<0?spec.fromMs:spec.captionOriginMs,spec.fromMs,spec.toMs)
            :Duwm1728BroadcastTimeline.captions(spec.automaticCaptions,spec.fromMs,spec.toMs);
    }
    public static void prepare(Spec spec){
        prepareTimelines(spec);Duwm1728FramePlan.validate(spec.frameMode,spec.frameX,spec.frameY);if(spec.title==null||spec.title.trim().isEmpty())throw new IllegalArgumentException("Review a factual headline before export");
        if(spec.includeCoordinates&&(spec.capturedTelemetry==null||!spec.capturedTelemetry.preciseEnabled))throw new IllegalArgumentException("No consenting recorded GPS source");
    }
    private static int number(MediaFormat f,String k,int fallback){try{return f.getInteger(k);}catch(Exception e){return fallback;}}
    private static final class Drain {
        final MediaCodec encoder;final MediaMuxer muxer;final MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();boolean started,eos;int track=-1,frames;long previous=-1;
        Drain(MediaCodec e,MediaMuxer m){encoder=e;muxer=m;}
        void pump(long wait){for(;;){int n=encoder.dequeueOutputBuffer(info,wait);wait=0;if(n==MediaCodec.INFO_TRY_AGAIN_LATER)return;
            if(n==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){if(started)throw new IllegalStateException("Duplicate encoder format");track=muxer.addTrack(encoder.getOutputFormat());muxer.start();started=true;}
            else if(n>=0){try{ByteBuffer data=encoder.getOutputBuffer(n);if((info.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)!=0)info.size=0;
                if(info.size>0){if(!started||data==null||info.presentationTimeUs<=previous)throw new IllegalStateException("Invalid encoded timestamp/track");data.position(info.offset);data.limit(info.offset+info.size);muxer.writeSampleData(track,data,info);previous=info.presentationTimeUs;frames++;}
                if((info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0)eos=true;}finally{encoder.releaseOutputBuffer(n,false);}if(eos)return;}}
        }
    }
    public static File export(Context context,Uri source,Spec spec)throws Exception {
        prepare(spec);Duwm1728ExportPreflight.Result plan=Duwm1728ExportPreflight.inspect(context,source,spec.fromMs,spec.toMs,spec.ratio,spec.frameMode,spec.frameX,spec.frameY);File output=File.createTempFile("DUWM_BROADCAST_",".mp4",context.getCacheDir());
        MediaExtractor video=new MediaExtractor(),audio=new MediaExtractor();MediaMetadataRetriever metadata=new MediaMetadataRetriever(),pipInfo=null;
        MediaCodec decoder=null,encoder=null;MediaMuxer muxer=null;Duwm1728EglVideoPipe gl=null;android.view.Surface surface=null;Bitmap overlay=null;Drain drain=null;
        boolean success=false,stopped=false;long fromUs=spec.fromMs*1000L,toUs=spec.toMs*1000L;
        try{
            metadata.setDataSource(context,source);String duration=metadata.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);if(duration==null||Long.parseLong(duration)<spec.toMs)throw new IllegalArgumentException("Clip exceeds source duration");
            video.setDataSource(context,source,null);MediaFormat sourceFormat=null;
            for(int i=0;i<video.getTrackCount();i++){MediaFormat f=video.getTrackFormat(i);String type=f.getString(MediaFormat.KEY_MIME);if(type!=null&&type.startsWith("video/")){sourceFormat=f;video.selectTrack(i);break;}}
            if(sourceFormat==null)throw new IllegalArgumentException("No video track");
            int transfer=number(sourceFormat,MediaFormat.KEY_COLOR_TRANSFER,3);if(transfer==6||transfer==7)throw new IllegalArgumentException("HDR source preserved. This graphics export requires SDR; no incorrect HDR conversion attempted.");
            int sw=sourceFormat.getInteger(MediaFormat.KEY_WIDTH),sh=sourceFormat.getInteger(MediaFormat.KEY_HEIGHT),rotation=number(sourceFormat,MediaFormat.KEY_ROTATION,0);
            String rot=metadata.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);if(rot!=null)rotation=Integer.parseInt(rot);rotation=((rotation%360)+360)%360;
            int[] dims=Duwm1728FramePlan.dimensions(rotation%180==0?sw:sh,rotation%180==0?sh:sw,spec.ratio,spec.frameMode);int width=dims[0],height=dims[1];
            int fps=plan.fps;MediaFormat out=Duwm1728ExportPreflight.outputFormat(plan);String name=plan.encoder;
            if(plan.width!=width||plan.height!=height)throw new IllegalStateException("Source changed after output inspection");
            encoder=MediaCodec.createByCodecName(name);encoder.configure(out,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);surface=encoder.createInputSurface();encoder.start();
            gl=new Duwm1728EglVideoPipe(surface,width,height,sw,sh,rotation,spec.frameMode,spec.frameX,spec.frameY);sourceFormat.setInteger(MediaFormat.KEY_ROTATION,0);if(Build.VERSION.SDK_INT>=29)sourceFormat.setInteger(MediaFormat.KEY_ALLOW_FRAME_DROP,0);
            decoder=MediaCodec.createDecoderByType(sourceFormat.getString(MediaFormat.KEY_MIME));decoder.configure(sourceFormat,gl.surface(),null,0);decoder.start();video.seekTo(fromUs,MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            muxer=new MediaMuxer(output.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);audio.setDataSource(context,source,null);int audioDest=-1;
            for(int i=0;i<audio.getTrackCount();i++){MediaFormat f=audio.getTrackFormat(i);String mime=f.getString(MediaFormat.KEY_MIME);if(mime!=null&&mime.startsWith("audio/")){if(!"audio/mp4a-latm".equals(mime))throw new IllegalArgumentException("Source audio requires AAC conversion; stopped rather than silently dropping sound");audio.selectTrack(i);audioDest=muxer.addTrack(f);break;}}
            drain=new Drain(encoder,muxer);overlay=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(overlay);
            long pipDuration=Long.MAX_VALUE;if(spec.pipVideo!=null){pipInfo=new MediaMetadataRetriever();pipInfo.setDataSource(context,spec.pipVideo);String d=pipInfo.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);if(d!=null)pipDuration=Long.parseLong(d)*1000L;}
            boolean fedEos=false,decodedEos=false;MediaCodec.BufferInfo decoded=new MediaCodec.BufferInfo();long lastWork=SystemClock.elapsedRealtime(),lastPts=-1;
            while(!decodedEos){
                if(spec.cancelled.get()||Thread.currentThread().isInterrupted())throw new InterruptedException("Export cancelled; original retained");drain.pump(0);
                if(!fedEos){int n=decoder.dequeueInputBuffer(10000);if(n>=0){ByteBuffer input=decoder.getInputBuffer(n);if(input==null)throw new IllegalStateException("Decoder input unavailable");input.clear();long ts=video.getSampleTime();int count=ts<0||ts>=toUs?-1:video.readSampleData(input,0);
                    if(count<0){decoder.queueInputBuffer(n,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);fedEos=true;}else{decoder.queueInputBuffer(n,0,count,ts,0);video.advance();}lastWork=SystemClock.elapsedRealtime();}}
                int n=decoder.dequeueOutputBuffer(decoded,10000);
                if(n>=0){long ts=decoded.presentationTimeUs;boolean render=decoded.size>0&&ts>=fromUs&&ts<toUs&&ts>lastPts,eos=(decoded.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;decoder.releaseOutputBuffer(n,render);
                    if(render){gl.awaitFrame();overlay.eraseColor(Color.TRANSPARENT);Bitmap inset=null;
                        try{if(pipInfo!=null){long at=Math.min(Math.max(0,ts-fromUs),Math.max(0,pipDuration-1));inset=Build.VERSION.SDK_INT>=27?pipInfo.getScaledFrameAtTime(at,MediaMetadataRetriever.OPTION_CLOSEST,Math.max(2,width/3),Math.max(2,height/3)):pipInfo.getFrameAtTime(at,MediaMetadataRetriever.OPTION_CLOSEST);}
                            drawOverlay(canvas,spec,(ts-fromUs)/1000L,inset);gl.submit(overlay,ts-fromUs);
                        }finally{if(inset!=null)inset.recycle();}lastPts=ts;drain.pump(0);if(spec.progress!=null)spec.progress.update((int)Math.min(98,(ts-fromUs)*98/Math.max(1,toUs-fromUs)));}
                    decodedEos=eos;lastWork=SystemClock.elapsedRealtime();
                }else if(n==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED)lastWork=SystemClock.elapsedRealtime();
                if(SystemClock.elapsedRealtime()-lastWork>20000)throw new IllegalStateException("Decoder stalled");
            }
            encoder.signalEndOfInputStream();long deadline=SystemClock.elapsedRealtime()+20000;
            while(!drain.eos){if(spec.cancelled.get())throw new InterruptedException("Export cancelled");drain.pump(10000);if(SystemClock.elapsedRealtime()>deadline)throw new IllegalStateException("Encoder did not finish");}
            if(!drain.started||drain.frames<1)throw new IllegalStateException("No encoded frames");
            if(audioDest>=0){audio.seekTo(fromUs,MediaExtractor.SEEK_TO_PREVIOUS_SYNC);ByteBuffer bytes=ByteBuffer.allocateDirect(2*1024*1024);MediaCodec.BufferInfo ai=new MediaCodec.BufferInfo();long previous=-1;
                while(audio.getSampleTime()>=0&&audio.getSampleTime()<toUs){if(spec.cancelled.get())throw new InterruptedException("Export cancelled");long ts=audio.getSampleTime();if(ts>=fromUs){bytes.clear();int size=audio.readSampleData(bytes,0);if(size<0)break;long pts=ts-fromUs;if(pts>previous){bytes.position(0);bytes.limit(size);ai.set(0,size,pts,audio.getSampleFlags());muxer.writeSampleData(audioDest,bytes,ai);previous=pts;}}if(!audio.advance())break;}}
            muxer.stop();stopped=true;
            MediaMetadataRetriever check=new MediaMetadataRetriever();try{check.setDataSource(output.getAbsolutePath());int w=Integer.parseInt(check.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)),h=Integer.parseInt(check.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));if(w!=width||h!=height)throw new IllegalStateException("Export dimensions mismatch");
                long ms=Long.parseLong(check.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));if(Math.abs(ms-(spec.toMs-spec.fromMs))>Math.max(1200,2000/fps))throw new IllegalStateException("Export duration mismatch");if(audioDest>=0&&!"yes".equalsIgnoreCase(check.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)))throw new IllegalStateException("Export lost audio");
            }finally{check.release();}
            success=true;if(spec.progress!=null)spec.progress.update(100);return output;
        }finally{
            if(decoder!=null){try{decoder.stop();}catch(Exception ignored){}try{decoder.release();}catch(Exception ignored){}}
            if(gl!=null)gl.close();if(surface!=null)surface.release();if(encoder!=null){try{encoder.stop();}catch(Exception ignored){}try{encoder.release();}catch(Exception ignored){}}
            if(muxer!=null){if(drain!=null&&drain.started&&!stopped)try{muxer.stop();}catch(Exception ignored){}try{muxer.release();}catch(Exception ignored){}}
            video.release();audio.release();try{metadata.release();}catch(Exception ignored){}if(pipInfo!=null)try{pipInfo.release();}catch(Exception ignored){}if(overlay!=null)overlay.recycle();if(!success)output.delete();
        }
    }
}
