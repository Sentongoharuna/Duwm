package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.FrameLayout;

/** 1709: nineteen restrained 0.85dp sector-identity keylines over the approved
 * #050D22 command-center print. Colours identify DESKS, not data freshness,
 * warning severity, or fabricated live signals. No map renderer is replaced.
 */
public final class Duwm1709SectorOutline {
    private Duwm1709SectorOutline() {}
    public static final int[] SECTOR_COLORS = {
        0xFF5986C3, // 01 Aircraft - muted aviation blue
        0xFF4096B1, // 02 Maritime - deep sea blue
        0xFFAD8B6C, // 03 Earthquakes - earth ochre
        0xFF7EA6C2, // 04 Weather - slate sky
        0xFF927DBC, // 05 Satellites - muted indigo
        0xFF628F9A, // 06 Geographic watchlist - steel teal
        0xFF709C8B, // 07 Place maps - evergreen
        0xFFAB84AD, // 08 World news - mauve
        0xFF737EBD, // 09 News atlas - periwinkle
        0xFF699BB1, // 10 Radio - ocean steel
        0xFF877EA9, // 11 TV - plum
        0xFF619C92, // 12 Public cameras - spruce
        0xFF9783B9, // 13 NASA images - space violet
        0xFFB0A073, // 14 Markets - muted gold
        0xFF6F9F97, // 15 Source health - sea glass
        0xFFAD827D, // 16 Evidence vault - soft terracotta
        0xFF7294B5, // 17 Source directory - blue grey
        0xFFAD87A1, // 18 Geopolitical lens - faded rose
        0xFF98A276  // 19 Local reports - olive
    };
    public static int color(int index) {
        return SECTOR_COLORS[((index % SECTOR_COLORS.length) + SECTOR_COLORS.length) % SECTOR_COLORS.length];
    }
    public static int index(Duwm1683DeskCatalog.Desk desk) {
        if (desk == null) return -1;
        for (int i=0; i<Duwm1683DeskCatalog.ALL.length; i++)
            if (Duwm1683DeskCatalog.ALL[i] == desk ||
                Duwm1683DeskCatalog.ALL[i].title.equals(desk.title)) return i;
        return -1;
    }
    private static int width(Context context) {
        return Math.max(1, Math.round(context.getResources().getDisplayMetrics().density * 0.85f));
    }
    public static GradientDrawable card(Context context,int index,int fill,boolean selected) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(DuwmUnifiedTheme.PANEL);
        d.setCornerRadius(Math.round(context.getResources().getDisplayMetrics().density * 19f));
        int accent=color(index);
        // Slight transparency keeps the stripe delicate against midnight navy.
        int opacity=selected?222:168;
        int stroke=Color.argb(opacity, Color.red(accent), Color.green(accent), Color.blue(accent));
        d.setStroke(width(context),stroke);
        return d;
    }
    public static GradientDrawable pageFrame(Context context,int index) {
        GradientDrawable d=new GradientDrawable();d.setColor(Color.TRANSPARENT);
        int c=color(index);
        d.setStroke(width(context),Color.argb(145,Color.red(c),Color.green(c),Color.blue(c)));
        return d;
    }
    /** Native pages for all 19 desks receive a near-hairline frame. Activity
     * foreground does not intercept clicks or replace embedded maps/players.
     */
    public static void frameNativePage(Activity activity) {
        Duwm1683DeskCatalog.Desk desk=Duwm1683DeskCatalog.find(activity);
        int index=index(desk);
        if(index<0)return;
        View content=activity.findViewById(android.R.id.content);
        if(content instanceof FrameLayout){
            FrameLayout frame=(FrameLayout)content;
            if(frame.getForeground()==null)frame.setForeground(pageFrame(activity,index));
        }
    }
}
