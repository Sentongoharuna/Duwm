package com.sentongoharuna.worldsituationroom;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.graphics.YuvImage;
import android.graphics.ImageFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.security.MessageDigest;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/**
 * DUWM 1718 MONITORS CAM: native vertical video compositor.
 * Android Camera preview frames are drawn on the MediaRecorder video input Surface together
 * with source-labelled telemetry. This differs from temporary UI overlays: the drawn text
 * is part of the frames submitted to the H264 recorder, if the device supports Canvas on
 * its recorder input surface. If that surface is unsupported recording FAILS CLEARLY instead
 * of silently saving a video without burned-in telemetry.
 * Reporter identity, place and situation are self-reported; GPS/heading are sensor-only;
 * weather is an opt-in Open-Meteo model response. All reports remain UNVERIFIED.
 */
@SuppressWarnings("deprecation")
public final class Duwm1718MonitorsCamActivity extends Activity implements TextureView.SurfaceTextureListener, SensorEventListener {
    private static final int NAVY=DuwmUnifiedTheme.APPROVED_NAVY;
    private static final int TEXT=DuwmUnifiedTheme.TEXT, MUTED=DuwmUnifiedTheme.MUTED;
    private static final int W=540,H=960,FPS=12;
    private static final int REQ_CAMERA=1818,REQ_LOCATION=1819;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService frames=Executors.newSingleThreadExecutor();
    private final AtomicBoolean processing=new AtomicBoolean();
    private final AtomicReference<Bitmap> latest=new AtomicReference<>();
    private final Object surfaceLock=new Object();
    private Camera camera; private MediaRecorder recorder; private Surface recorderSurface;
    private ScheduledExecutorService videoClock;
    private TextureView preview; private TextView indicator,telemetry,recordButton;
    private View previewGrid; private boolean showGrid=false;
    private ScaleGestureDetector scaleGesture;
    private float tapDownX,tapDownY;
    private boolean gestureScaled;
    private LinearLayout reportDetails; private TextView detailsToggle;
    private EditText placeInput,situationInput,reporterInput;
    private CheckBox preciseLocation,audioEnabled;
    private SensorManager sensorManager; private LocationManager locationManager;
    private volatile Location lastLocation;
    private boolean recording,closed,finished,locationActive;
    private volatile float heading=-1f;
    private volatile long lastHeadingAt=0L;
    private volatile String weather="MODEL WX NOT REQUESTED";
    private volatile long weatherReceivedAt=0L;
    private volatile double weatherLat=999d,weatherLon=999d;
    private String lastFile="";
    private static final String CLIP_RECEIPTS="duwm1721_camera_receipts";
    private static final String RECEIPT_LATEST="latest";
    private static final String[] CATEGORIES={"GENERAL","WEATHER","TRANSPORT","PUBLIC SAFETY","ENVIRONMENT","EYEWITNESS"};
    private int categoryIndex=0;private String bakedCategory="GENERAL";
    private TextView categoryControl;
    private volatile String bakedReporter="",bakedPlace="",bakedSituation="";
    private volatile boolean bakedPrecise;
    private long startedAt,lastFrameAt,lastWeatherAt;
    private int cameraId=0,cameraFacing=Camera.CameraInfo.CAMERA_FACING_BACK,rotate=90,previewWidth=640,previewHeight=480,limitSeconds=60,recordedFrames;
    private final Runnable telemetryRefresh=new Runnable(){@Override public void run(){if(closed)return;displayTelemetry();main.postDelayed(this,650);}};
    private final LocationListener gpsListener=new LocationListener(){@Override public void onLocationChanged(Location value){if(value!=null && value.getAccuracy()<2000f)lastLocation=value;} @Override public void onProviderEnabled(String p){}@Override public void onProviderDisabled(String p){}@Override public void onStatusChanged(String p,int s,Bundle extras){}};
    private int dp(float x){return Math.round(getResources().getDisplayMetrics().density*x);}
    private GradientDrawable outline(){GradientDrawable d=new GradientDrawable();d.setColor(NAVY);d.setCornerRadius(dp(14));d.setStroke(dp(1),DuwmUnifiedTheme.BORDER);return d;}
    private TextView txt(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextColor(TEXT);t.setTextSize(sp);t.setGravity(Gravity.CENTER_VERTICAL);t.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));return t;}
    private TextView action(String label,Runnable a){TextView t=txt(label,12);t.setGravity(Gravity.CENTER);t.setBackground(outline());t.setMinHeight(dp(48));t.setOnClickListener(v->a.run());return t;}
    private LinearLayout.LayoutParams mp(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(7);return p;}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(NAVY);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        cameraId=findCamera(Camera.CameraInfo.CAMERA_FACING_BACK);if(cameraId<0)cameraId=0;
        sensorManager=(SensorManager)getSystemService(SENSOR_SERVICE);
        locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(NAVY);
        ScrollView wrap=new ScrollView(this);wrap.setFillViewport(false);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12),dp(6),dp(12),dp(12));root.setBackgroundColor(NAVY);
        root.addView(txt("DUWM 1723  /  MONITORS CAM",17),mp());
        root.addView(txt("REAL DEVICE CAMERA  •  SOURCE-LABELLED MP4  •  UNVERIFIED REPORT",10),mp());
        FrameLayout stage=new FrameLayout(this);stage.setBackground(outline());
        preview=new TextureView(this);preview.setSurfaceTextureListener(this);
        // Actual legacy-camera zoom API; optical/digital availability is device dependent.
        scaleGesture=new ScaleGestureDetector(this,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
            @Override public boolean onScale(ScaleGestureDetector detector){
                gestureScaled=true;return scaleCamera(detector.getScaleFactor());
            }
        });
        preview.setOnTouchListener((view,event)->{
            if(event.getActionMasked()==MotionEvent.ACTION_DOWN){
                tapDownX=event.getX();tapDownY=event.getY();gestureScaled=false;
            }
            scaleGesture.onTouchEvent(event);
            if(event.getActionMasked()==MotionEvent.ACTION_UP && !gestureScaled &&
               Math.abs(event.getX()-tapDownX)<dp(22) && Math.abs(event.getY()-tapDownY)<dp(22)){
                focusOnce();
                view.performClick();
            }
            return true;
        });
        preview.setContentDescription("MONITORS CAM viewfinder: tap to autofocus; pinch to zoom where supported");
        stage.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        final View compositionGrid=new View(this){
            private final Paint gridPaint=new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas c){super.onDraw(c);if(!showGrid)return;
                gridPaint.setColor(0x70DEE5EF);gridPaint.setStrokeWidth(dp(1));
                float w=getWidth(),h=getHeight();
                for(int i=1;i<=2;i++){float x=w*i/3f,y=h*i/3f;
                    c.drawLine(x,0,x,h,gridPaint);c.drawLine(0,y,w,y,gridPaint);}
            }
        };
        compositionGrid.setClickable(false);
        stage.addView(compositionGrid,new FrameLayout.LayoutParams(-1,-1));
        previewGrid=compositionGrid;
        indicator=txt("● READY / CAMERA CHECK",11);indicator.setPadding(dp(9),dp(4),dp(9),dp(4));
        indicator.setBackgroundColor(0xB8041424);
        stage.addView(indicator,new FrameLayout.LayoutParams(-1,dp(33),Gravity.TOP));
        telemetry=txt("UTC / GPS WITHHELD / SENSOR STATUS",10);
        telemetry.setBackgroundColor(0xD5041424);telemetry.setPadding(dp(9),dp(5),dp(9),dp(5));
        stage.addView(telemetry,new FrameLayout.LayoutParams(-1,dp(87),Gravity.BOTTOM));
        // 1722: larger uncluttered preview; persistent record controls live below the scroller.
        root.addView(stage,new LinearLayout.LayoutParams(-1,dp(312)));
        root.addView(txt("TAP CAMERA PREVIEW TO FOCUS  •  PINCH TO ZOOM (WHEN SUPPORTED)",10),mp());
        LinearLayout shortcuts=new LinearLayout(this);shortcuts.setOrientation(LinearLayout.HORIZONTAL);
        TextView flip=action("FLIP",this::flipCamera);
        TextView zoom=action("ZOOM +",this::zoomCamera);
        TextView focus=action("FOCUS",this::focusOnce);
        for(TextView t:new TextView[]{flip,zoom,focus}){
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(46),1);p.rightMargin=dp(5);
            shortcuts.addView(t,p);
        }
        root.addView(shortcuts,mp());
        detailsToggle=action("REPORT DETAILS & CAMERA SETTINGS  ▾",()->{
            boolean expand=reportDetails.getVisibility()!=View.VISIBLE;
            reportDetails.setVisibility(expand?View.VISIBLE:View.GONE);
            detailsToggle.setText(expand?"HIDE DETAILS & SETTINGS  ▴":"REPORT DETAILS & CAMERA SETTINGS  ▾");
        });
        root.addView(detailsToggle,mp());
        reportDetails=new LinearLayout(this);reportDetails.setOrientation(LinearLayout.VERTICAL);
        reportDetails.setPadding(0,dp(3),0,dp(12));
        reporterInput=input("Reporter / ID (self-reported)","WORLD MONITOR REPORTER");reportDetails.addView(reporterInput,mp());
        placeInput=input("City / place (self-reported)","");reportDetails.addView(placeInput,mp());
        situationInput=input("Situation / eyewitness description","");
        situationInput.setSingleLine(false);situationInput.setMinLines(2);situationInput.setMaxLines(4);
        situationInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE |
                android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        reportDetails.addView(situationInput,mp());
        preciseLocation=new CheckBox(this);
        preciseLocation.setText("Embed precise GPS in video (optional; privacy risk)");
        preciseLocation.setTextColor(TEXT);preciseLocation.setButtonTintList(
                android.content.res.ColorStateList.valueOf(DuwmUnifiedTheme.BORDER));
        preciseLocation.setChecked(false);
        preciseLocation.setOnCheckedChangeListener((button,checked)->{
            if(checked)requestLocation();else stopLocation();
        });reportDetails.addView(preciseLocation,mp());
        audioEnabled=new CheckBox(this);audioEnabled.setText("Microphone audio (permission required)");
        audioEnabled.setTextColor(TEXT);audioEnabled.setChecked(false);
        audioEnabled.setButtonTintList(android.content.res.ColorStateList.valueOf(DuwmUnifiedTheme.BORDER));
        reportDetails.addView(audioEnabled,mp());
        categoryControl=action("REPORT CATEGORY  /  GENERAL  ▸",this::nextCategory);
        reportDetails.addView(categoryControl,mp());
        reportDetails.addView(action("FETCH OPTIONAL WEATHER MODEL",this::fetchWeather),mp());
        reportDetails.addView(txt("Weather is opt-in model data, not a device measurement. Confirm licensing before commercial use.",10),mp());
        reportDetails.addView(action("CAMERA / SENSOR / PRIVACY READINESS",this::showReadiness),mp());
        LinearLayout proTools=new LinearLayout(this);proTools.setOrientation(LinearLayout.HORIZONTAL);
        TextView evDown=action("EXPOSURE −",()->adjustExposure(-1));
        TextView evUp=action("EXPOSURE +",()->adjustExposure(1));
        for(TextView t:new TextView[]{evDown,evUp}){
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(46),1);lp.rightMargin=dp(5);
            proTools.addView(t,lp);
        }
        reportDetails.addView(proTools,mp());
        reportDetails.addView(action("PREVIEW GRID ON / OFF",()->{
            showGrid=!showGrid;if(previewGrid!=null)previewGrid.invalidate();
        }),mp());
        reportDetails.addView(action("RECORDING LENGTH",this::setDuration),mp());
        reportDetails.addView(action("LATEST VIDEO SHA-256 RECEIPT",this::showCaptureReceipt),mp());
        reportDetails.addView(txt("Sensor data is measured only when available. Reporter descriptions are unverified. Overlay encoding depends on phone hardware.",10),mp());
        reportDetails.setVisibility(View.GONE);
        root.addView(reportDetails,mp());
        root.addView(action("BACK TO WORLD MONITOR",()->{
            if(recording)stopRecording(true);else finish();
        }),mp());
        root.addView(action("MY WORLD / FOLLOWED PLACES",()->{
            if(recording)note("Stop recording first");
            else startActivity(new Intent(this,Duwm1719MyWorldActivity.class));
        }),mp());
        wrap.addView(root);page.addView(wrap,new LinearLayout.LayoutParams(-1,0,1f));
        // Accessible one-handed record control; never below the report form or bottom system bar.
        LinearLayout recordDock=new LinearLayout(this);recordDock.setOrientation(LinearLayout.HORIZONTAL);
        recordDock.setPadding(dp(12),dp(7),dp(12),dp(7));
        recordDock.setBackgroundColor(NAVY);
        recordButton=action("● RECORD / 60 SEC",this::toggleRecording);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,dp(55),2f);rp.rightMargin=dp(7);
        recordDock.addView(recordButton,rp);
        TextView readiness=action("CHECK",this::showReadiness);
        recordDock.addView(readiness,new LinearLayout.LayoutParams(0,dp(55),1f));
        page.addView(recordDock,new LinearLayout.LayoutParams(-1,dp(69)));
        setContentView(page);
        main.post(telemetryRefresh);
        if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAMERA);
    }
    private EditText input(String hint,String value){EditText x=new EditText(this);x.setSingleLine(true);x.setTextSize(14);x.setTextColor(TEXT);x.setHintTextColor(MUTED);x.setHint(hint);x.setText(value);x.setPadding(dp(13),0,dp(13),0);x.setBackground(outline());x.setMinHeight(dp(49));return x;}
    private int findCamera(int facing){for(int i=0;i<Camera.getNumberOfCameras();i++){Camera.CameraInfo info=new Camera.CameraInfo();Camera.getCameraInfo(i,info);if(info.facing==facing)return i;}return Camera.getNumberOfCameras()>0?0:-1;}
    @Override protected void onResume(){super.onResume();if(preciseLocation!=null&&preciseLocation.isChecked())requestLocation();Sensor rv=sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);if(rv!=null)sensorManager.registerListener(this,rv,SensorManager.SENSOR_DELAY_UI);if(preview!=null&&preview.isAvailable())openCamera();}
    private void openCamera(){if(camera!=null||recording||closed||checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED||preview==null||!preview.isAvailable())return;
        try{camera=Camera.open(cameraId);Camera.CameraInfo info=new Camera.CameraInfo();Camera.getCameraInfo(cameraId,info);rotate=info.orientation;cameraFacing=info.facing;
            Camera.Parameters p=camera.getParameters();Camera.Size best=null;int delta=Integer.MAX_VALUE;for(Camera.Size sz:p.getSupportedPreviewSizes()){int score=Math.abs(sz.width-640)+Math.abs(sz.height-480);if(score<delta){delta=score;best=sz;}}if(best!=null){previewWidth=best.width;previewHeight=best.height;p.setPreviewSize(best.width,best.height);}
            p.setPreviewFormat(ImageFormat.NV21);if(p.getSupportedFocusModes().contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO))p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
            camera.setParameters(p);int display=getWindowManager().getDefaultDisplay().getRotation();int degrees=display==Surface.ROTATION_90?90:display==Surface.ROTATION_180?180:display==Surface.ROTATION_270?270:0;
            int adjusted=info.facing==Camera.CameraInfo.CAMERA_FACING_FRONT?(360-(info.orientation+degrees)%360)%360:(info.orientation-degrees+360)%360;
            camera.setDisplayOrientation(adjusted);camera.setPreviewTexture(preview.getSurfaceTexture());camera.setPreviewCallbackWithBuffer(this::acceptFrame);
            camera.addCallbackBuffer(new byte[previewWidth*previewHeight*3/2]);camera.addCallbackBuffer(new byte[previewWidth*previewHeight*3/2]);camera.startPreview();indicator.setText("● CAMERA READY  /  MP4 OVERLAY RECORDING");}
        catch(Exception e){releaseCamera();indicator.setText("CAMERA UNAVAILABLE  /  "+safe(e));}
    }
    private void acceptFrame(byte[] data,Camera src){if(data==null)return;long now=SystemClock.elapsedRealtime();if(now-lastFrameAt>=100&&processing.compareAndSet(false,true)){
            lastFrameAt=now;final byte[] bytes=Arrays.copyOf(data,data.length);final int w=previewWidth,h=previewHeight,rot=rotate;final boolean mirror=cameraFacing==Camera.CameraInfo.CAMERA_FACING_FRONT;
            try { frames.execute(()->{try{YuvImage yuv=new YuvImage(bytes,ImageFormat.NV21,w,h,null);ByteArrayOutputStream buf=new ByteArrayOutputStream(140000);if(!yuv.compressToJpeg(new Rect(0,0,w,h),68,buf))return;
                byte[] jpeg=buf.toByteArray();Bitmap raw=BitmapFactory.decodeByteArray(jpeg,0,jpeg.length);if(raw==null)return;Matrix mx=new Matrix();mx.postRotate(rot);if(mirror)mx.postScale(-1,1);Bitmap corrected=Bitmap.createBitmap(raw,0,0,raw.getWidth(),raw.getHeight(),mx,true);if(raw!=corrected)raw.recycle();latest.set(corrected);}catch(Exception e){android.util.Log.w("DUWM-CAM","Frame conversion unavailable",e);}finally{processing.set(false);}}); } catch(java.util.concurrent.RejectedExecutionException closedFrames) { processing.set(false); }
        }
        try{src.addCallbackBuffer(data);}catch(RuntimeException ignored){}
    }
    private void flipCamera(){if(recording)return;int f=cameraFacing==Camera.CameraInfo.CAMERA_FACING_FRONT?Camera.CameraInfo.CAMERA_FACING_BACK:Camera.CameraInfo.CAMERA_FACING_FRONT;int id=findCamera(f);if(id<0)return;releaseCamera();cameraId=id;openCamera();}
    private void zoomCamera(){if(recording||camera==null)return;try{Camera.Parameters p=camera.getParameters();if(!p.isZoomSupported()){note("Zoom not supported");return;}p.setZoom((p.getZoom()+Math.max(1,p.getMaxZoom()/8))%(p.getMaxZoom()+1));camera.setParameters(p);}catch(Exception e){note("Zoom unavailable");}}
    private boolean scaleCamera(float factor){
        if(recording||camera==null)return false;
        try{
            Camera.Parameters settings=camera.getParameters();
            if(!settings.isZoomSupported())return false;
            int maximum=settings.getMaxZoom();if(maximum<=0)return false;
            int previous=settings.getZoom();
            // Avoid jumping across the whole device zoom range in one gesture.
            int jump=Math.max(1,Math.min(3,Math.round(Math.abs(factor-1f)*maximum*0.6f)));
            int target=Math.max(0,Math.min(maximum,previous+(factor>=1f?jump:-jump)));
            if(target!=previous){settings.setZoom(target);camera.setParameters(settings);
                indicator.setText("● CAMERA READY / PINCH ZOOM "+target+" / "+maximum);
            }
            return true;
        }catch(RuntimeException unsupported){note("Pinch zoom unavailable on this camera");return false;}
    }
    private void focusOnce(){
        if(recording){note("Focus is locked while recording");return;}
        if(camera==null){note("Camera is not available");return;}
        try{
            Camera.Parameters p=camera.getParameters();
            if(p.getSupportedFocusModes()==null||!p.getSupportedFocusModes().contains(Camera.Parameters.FOCUS_MODE_AUTO)){
                note("Manual focus not supported on this camera");return;
            }
            p.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);camera.setParameters(p);
            camera.autoFocus((success,c)->main.post(()->indicator.setText(success?
                    "● FOCUS CONFIRMED  /  DEVICE CAMERA":"● AUTOFOCUS NOT CONFIRMED")));
        }catch(RuntimeException e){note("Device autofocus unavailable");}
    }
    private void adjustExposure(int direction){
        if(recording){note("Exposure locked while recording");return;}
        if(camera==null){note("Camera unavailable");return;}
        try{
            Camera.Parameters p=camera.getParameters();
            int min=p.getMinExposureCompensation(),max=p.getMaxExposureCompensation();
            if(min==0&&max==0){note("Exposure adjustment unsupported");return;}
            int target=Math.max(min,Math.min(max,p.getExposureCompensation()+direction));
            p.setExposureCompensation(target);camera.setParameters(p);
            indicator.setText("● CAMERA READY  /  EXPOSURE "+target+" / "+min+".."+max);
        }catch(RuntimeException e){note("Exposure adjustment unavailable on this camera");}
    }
    private void nextCategory(){if(recording){note("Stop recording to change report category");return;}categoryIndex=(categoryIndex+1)%CATEGORIES.length;categoryControl.setText("REPORT CATEGORY  /  "+CATEGORIES[categoryIndex]+"  ▸");}
    private void showCaptureReceipt(){String entry=getSharedPreferences(CLIP_RECEIPTS,MODE_PRIVATE).getString(RECEIPT_LATEST,"");
        if(entry.isEmpty()){note("No completed video receipt stored on this phone");return;}
        new AlertDialog.Builder(this).setTitle("Local capture receipt / not independently verified")
            .setMessage(entry+"\n\nSHA-256 identifies the locally recorded bytes at the time of capture. It does not prove the scene or report is authentic.")
            .setNegativeButton("CLOSE",null).setPositiveButton("SHARE TEXT",(d,w)->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,"DUWM local capture receipt\n"+entry+"\nNot independently verified");startActivity(Intent.createChooser(i,"Share capture receipt"));}).show();
    }
    private void saveCaptureReceipt(File completed,String captureName,long elapsedMillis,int framesMade,String reportCategory,boolean includedPrecise){
        final android.content.Context application=getApplicationContext();
        new Thread(()->{try(FileInputStream input=new FileInputStream(completed)){
            MessageDigest digest=MessageDigest.getInstance("SHA-256");byte[] buffer=new byte[32768];int len;
            while((len=input.read(buffer))!=-1)digest.update(buffer,0,len);
            StringBuilder hex=new StringBuilder();for(byte b:digest.digest())hex.append(String.format(Locale.US,"%02x",b&0xff));
            String receipt="FILE  "+captureName+"\nUTC RECEIPT  "+utc()+"\nDURATION  "+(elapsedMillis/1000)+" sec\nFRAMES  "+framesMade+
                    "\nSIZE  "+completed.length()+" bytes\nREPORT TYPE  "+reportCategory+
                    " (SELF-REPORTED)\nPRECISE GPS BURNED  "+(includedPrecise?"USER OPTED IN":"NO")+
                    "\nSHA-256  "+hex.toString();
            application.getSharedPreferences(CLIP_RECEIPTS,MODE_PRIVATE).edit().putString(RECEIPT_LATEST,receipt).apply();
        }catch(Exception ex){android.util.Log.w("DUWM-CAM","Capture fingerprint unavailable",ex);}},"duwm1721-private-mp4-sha256").start();
    }
    private void setDuration(){if(recording)return;final String[] options={"15 seconds","30 seconds","60 seconds","3 minutes","5 minutes"};final int[] seconds={15,30,60,180,300};new AlertDialog.Builder(this).setTitle("Maximum video length").setItems(options,(d,w)->{limitSeconds=seconds[w];recordButton.setText("●  RECORD / "+limitSeconds+" SEC");}).show();}
    private void toggleRecording(){if(recording){stopRecording(true);return;}if(camera==null){note("Camera is not ready");return;}if(audioEnabled.isChecked()&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_CAMERA);note("Microphone permission requested. Press RECORD again.");return;}
        new AlertDialog.Builder(this).setTitle("Confirm MONITORS CAM recording")
          .setMessage("Recording uses your device camera.\n\n"+readiness()+"\n\nVideo overlays are burned into the MP4 and cannot be removed later. Captured reports remain UNVERIFIED; you decide whether to publish.")
          .setNegativeButton("CANCEL",null).setPositiveButton("RECORD",(dialog,which)->{if(!closed&&!recording)startRecording();}).show();}
    private String compass(){return heading>=0f && lastHeadingAt>0L && SystemClock.elapsedRealtime()-lastHeadingAt<20000L?String.format(Locale.US,"%.0f°",heading):"UNAVAILABLE";}
    private String gpsAccuracy(){Location l=lastLocation;return locationFresh(l)&&l.hasAccuracy()?String.format(Locale.US,"±%.0f m",l.getAccuracy()):"UNAVAILABLE";}
    private String sourceWeather(){
        if(weatherReceivedAt==0L)return weather;
        long age=SystemClock.elapsedRealtime()-weatherReceivedAt;
        Location l=lastLocation;
        if(age<0L||age>1800000L)return "MODEL WX STALE (RE-FETCH)";
        if(locationFresh(l)&&(Math.abs(l.getLatitude()-weatherLat)>0.25||Math.abs(l.getLongitude()-weatherLon)>0.25))return "MODEL WX FOR DIFFERENT PLACE";
        return weather;
    }
    private String readiness(){
        String cameraState=camera!=null&&latest.get()!=null?"READY":"UNAVAILABLE";
        String mic=audioEnabled.isChecked()?(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED?"ON / PERMITTED":"PERMISSION REQUIRED"):"OFF";
        String gps=preciseLocation.isChecked()?(locationFresh(lastLocation)?"ON / SENSOR "+gpsAccuracy():"ON / WAITING FOR FRESH SENSOR"):"WITHHELD";
        return "CAMERA  "+cameraState+"\nMICROPHONE  "+mic+"\nPRECISE GPS  "+gps+"\nDEVICE COMPASS  "+compass()+"\nWEATHER  "+sourceWeather()+"\nREPORTER / PLACE / SITUATION  SELF-REPORTED";
    }
    private void showReadiness(){new AlertDialog.Builder(this).setTitle("1719 / Camera readiness & source status")
      .setMessage(readiness()+"\n\nAll exact coordinates remain off by default. Never record sensitive locations or people without appropriate safeguards.")
      .setPositiveButton("CLOSE",null).show();}
    private void startRecording(){
        if(latest.get()==null){note("Camera is preparing frames. Wait until preview is ready.");return;}
        bakedReporter=reporterInput.getText().toString();
        bakedPlace=placeInput.getText().toString();
        bakedSituation=situationInput.getText().toString();
        bakedCategory=CATEGORIES[categoryIndex];
        bakedPrecise=preciseLocation.isChecked();
        reporterInput.setEnabled(false);placeInput.setEnabled(false);situationInput.setEnabled(false);preciseLocation.setEnabled(false);audioEnabled.setEnabled(false);if(categoryControl!=null)categoryControl.setEnabled(false);
        try{MonitorStore store=new MonitorStore(this);lastFile=store.createCaptureTarget();File output=store.mediaFile(lastFile);if(output==null)throw new IllegalStateException("Private video target unavailable");
            recorder=new MediaRecorder();if(audioEnabled.isChecked())recorder.setAudioSource(MediaRecorder.AudioSource.MIC);recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
            recorder.setVideoSize(W,H);recorder.setVideoFrameRate(FPS);recorder.setVideoEncodingBitRate(2400000);
            if(audioEnabled.isChecked()){recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);recorder.setAudioEncodingBitRate(96000);recorder.setAudioSamplingRate(44100);}
            recorder.setOutputFile(output.getAbsolutePath());recorder.setMaxDuration((limitSeconds+1)*1000);recorder.prepare();recorderSurface=recorder.getSurface();recorder.start();startedAt=SystemClock.elapsedRealtime();recordedFrames=0;recording=true;
            videoClock=Executors.newSingleThreadScheduledExecutor();videoClock.scheduleAtFixedRate(this::drawVideoFrame,0,1000/FPS,TimeUnit.MILLISECONDS);recordButton.setText("■  STOP & CREATE WORLD REPORT");indicator.setText("● REC  /  MP4 + PERMANENT SOURCE LABELS");
        }catch(Exception ex){android.util.Log.e("DUWM-CAM","Recording not supported",ex);cleanupRecorder();new MonitorStore(this).discardMedia(lastFile);lastFile="";unlockInputs();note("This device cannot start telemetry-overlay recording: "+safe(ex));}}
    private void unlockInputs(){reporterInput.setEnabled(true);placeInput.setEnabled(true);situationInput.setEnabled(true);preciseLocation.setEnabled(true);audioEnabled.setEnabled(true);if(categoryControl!=null)categoryControl.setEnabled(true);}
    private String safe(Exception ex){String s=ex.getMessage();return TextUtils.isEmpty(s)?ex.getClass().getSimpleName():s;}
    private void drawVideoFrame(){synchronized(surfaceLock){if(!recording||recorderSurface==null)return;Canvas canvas=null;try{canvas=recorderSurface.lockCanvas(null);canvas.drawColor(NAVY);Bitmap pic=latest.get();if(pic!=null&&!pic.isRecycled()){
                int pw=pic.getWidth(),ph=pic.getHeight();float ratio=Math.max((float)W/pw,(float)H/ph);float cropW=W/ratio,cropH=H/ratio;Rect source=new Rect(Math.round((pw-cropW)/2),Math.round((ph-cropH)/2),Math.round((pw+cropW)/2),Math.round((ph+cropH)/2));canvas.drawBitmap(pic,source,new RectF(0,0,W,H),new Paint(Paint.FILTER_BITMAP_FLAG));}
            overlay(canvas);if(pic!=null)recordedFrames++;
        }catch(Exception ex){android.util.Log.e("DUWM-CAM","Device recorder surface does not allow Canvas overlay",ex);main.post(()->{if(recording){note("Permanent video-overlay encoder unsupported on this device; recording cancelled.");stopRecording(false);}});}finally{if(canvas!=null)try{recorderSurface.unlockCanvasAndPost(canvas);}catch(Exception ignored){}}}}
    private void overlay(Canvas c){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(0xD6041424);c.drawRect(0,0,W,164,p);c.drawRect(0,H-238,W,H,p);p.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));p.setColor(0xFFF5F7FA);p.setTextSize(23);
        c.drawText("DUWM  /  MONITORS CAM",20,37,p);p.setTextSize(17);p.setColor(0xFFDEE5EF);c.drawText("● UNVERIFIED  /  "+shortText(bakedCategory,20)+"  /  DEVICE CAMERA",20,68,p);
        p.setTextSize(19);c.drawText("UTC  "+utc(),20,103,p);c.drawText("REPORTER  "+shortText(bakedReporter,31),20,137,p);
        p.setTextSize(20);p.setColor(0xFFF5F7FA);c.drawText("PLACE  "+shortText(bakedPlace.trim().isEmpty()?"NOT PROVIDED":bakedPlace,29),20,H-199,p);
        String g=coordinates();c.drawText("GPS  "+g,20,H-169,p);p.setTextSize(16);c.drawText(shortText("ALT  "+altitude()+"  |  DEVICE HDG  "+compass()+"  |  GPS ACC "+gpsAccuracy(),66),20,H-139,p);
        p.setTextSize(16);p.setColor(0xFFDEE5EF);c.drawText(shortText("WX  "+sourceWeather(),56),20,H-100,p);c.drawText("SITUATION  "+shortText(bakedSituation,41),20,H-69,p);
        c.drawText("DUWM 1723 • DEVICE/PROVIDER VS SELF-REPORT",20,H-35,p);
    }
    private String shortText(String value,int max){if(value==null||value.trim().isEmpty())return "NOT PROVIDED";String s=value.replace('\n',' ').trim();return s.length()>max?s.substring(0,Math.max(1,max-1))+"…":s;}
    private String utc(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date());}
    private boolean locationFresh(Location l){return l!=null && (SystemClock.elapsedRealtimeNanos()-l.getElapsedRealtimeNanos())>=0L && (SystemClock.elapsedRealtimeNanos()-l.getElapsedRealtimeNanos())<120_000_000_000L;}
    private String coordinates(){if(!(recording?bakedPrecise:preciseLocation.isChecked()))return "WITHHELD";Location l=lastLocation;return !locationFresh(l)?"SENSOR MISSING / STALE":String.format(Locale.US,"%.5f, %.5f",l.getLatitude(),l.getLongitude());}
    private String altitude(){Location l=lastLocation;return (recording?bakedPrecise:preciseLocation.isChecked())&&locationFresh(l)&&l.hasAltitude()?String.format(Locale.US,"%.0f m",l.getAltitude()):"UNAVAILABLE";}
    private void displayTelemetry(){if(telemetry==null)return;telemetry.setText("UTC "+utc()+"\nGPS  "+coordinates()+"\nALT  "+altitude()+"  /  DEVICE COMPASS  "+compass()+"\n"+sourceWeather());
        if(recording){long secs=(SystemClock.elapsedRealtime()-startedAt)/1000;indicator.setText("● REC  "+secs+" / "+limitSeconds+"s    •    "+recordedFrames+" COMPOSITED FRAMES");if(secs>=limitSeconds)stopRecording(true);}}
    private void stopRecording(boolean keep){if(!recording)return;recording=false;ScheduledExecutorService clock=videoClock;videoClock=null;if(clock!=null)clock.shutdownNow();boolean valid=false;
        synchronized(surfaceLock){try{if(recorder!=null){recorder.stop();valid=true;}}catch(RuntimeException ex){android.util.Log.e("DUWM-CAM","Recorder output incomplete",ex);}cleanupRecorder();}
        unlockInputs();recordButton.setText("●  RECORD / "+limitSeconds+" SEC");indicator.setText(valid?"● VIDEO SAVED / PRIVATE DRAFT":"● VIDEO ERROR / RETRY");File f=new MonitorStore(this).mediaFile(lastFile);if(!keep||!valid||recordedFrames<2||f==null||f.length()<1024){new MonitorStore(this).discardMedia(lastFile);lastFile="";if(keep)note("Video not completed; please retry");return;}
        saveCaptureReceipt(f,lastFile,Math.max(0L,SystemClock.elapsedRealtime()-startedAt),recordedFrames,bakedCategory,bakedPrecise);
        Intent next=new Intent(this,LocalMonitorActivity.class);next.putExtra("duwm1718_camera_file",lastFile);next.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(next);finish();
    }
    private void cleanupRecorder(){try{if(recorder!=null)recorder.reset();}catch(Exception ignored){}try{if(recorder!=null)recorder.release();}catch(Exception ignored){}recorder=null;recorderSurface=null;}
    private void releaseCamera(){if(camera!=null){try{camera.setPreviewCallbackWithBuffer(null);camera.stopPreview();}catch(Exception ignored){}try{camera.release();}catch(Exception ignored){}camera=null;}}
    private void requestLocation(){if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQ_LOCATION);return;}try{locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1800L,0f,gpsListener);locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,2500L,0f,gpsListener);locationActive=true;Location last=locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);if(last!=null)lastLocation=last;}catch(SecurityException | IllegalArgumentException e){note("Location sensors unavailable");}}
    private void stopLocation(){if(locationActive)try{locationManager.removeUpdates(gpsListener);}catch(Exception ignored){}locationActive=false;lastLocation=null;weather="MODEL WX NOT REQUESTED";weatherReceivedAt=0L;}
    private void fetchWeather(){if(!preciseLocation.isChecked()||!locationFresh(lastLocation)){note("Enable optional GPS and obtain a sensor reading before weather lookup");return;}long now=SystemClock.elapsedRealtime();if(now-lastWeatherAt<60000){note("Wait before fetching model data again");return;}lastWeatherAt=now;double lat=lastLocation.getLatitude(),lon=lastLocation.getLongitude();weather="FETCHING MODEL WX…";weatherReceivedAt=0L;
        new Thread(()->{String result="MODEL WX UNAVAILABLE";HttpURLConnection conn=null;try{String address=String.format(Locale.US,"https://api.open-meteo.com/v1/forecast?latitude=%.5f&longitude=%.5f&current=temperature_2m,wind_speed_10m,weather_code&timezone=UTC",lat,lon);conn=(HttpURLConnection)new URL(address).openConnection();conn.setConnectTimeout(7000);conn.setReadTimeout(7000);if(conn.getResponseCode()!=200)throw new IllegalStateException("Weather HTTP "+conn.getResponseCode());try(InputStream in=conn.getInputStream();ByteArrayOutputStream bytes=new ByteArrayOutputStream()){byte[] b=new byte[4096];int n;while((n=in.read(b))>=0){if(bytes.size()+n>22000)throw new IllegalStateException("Unexpected weather data size");bytes.write(b,0,n);}JSONObject wx=new JSONObject(bytes.toString("UTF-8")).getJSONObject("current");result=String.format(Locale.US,"Open-Meteo MODEL %.1f°C WIND %.0f km/h",wx.getDouble("temperature_2m"),wx.getDouble("wind_speed_10m"));weatherLat=lat;weatherLon=lon;weatherReceivedAt=SystemClock.elapsedRealtime();}}catch(Exception e){android.util.Log.w("DUWM-CAM","Weather model unavailable",e);}finally{if(conn!=null)conn.disconnect();}weather=result;},"duwm1718-user-weather-model").start();}
    private void note(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    @Override public void onRequestPermissionsResult(int r,String[] perms,int[] grants){super.onRequestPermissionsResult(r,perms,grants);if(r==REQ_CAMERA&&checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)openCamera();if(r==REQ_LOCATION&&grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED)requestLocation();else if(r==REQ_LOCATION){preciseLocation.setChecked(false);note("Coordinates will remain withheld");}}
    @Override public void onSurfaceTextureAvailable(SurfaceTexture surface,int width,int height){openCamera();}
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture surface,int w,int h){}
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture surface){if(recording)stopRecording(false);releaseCamera();return true;}
    @Override public void onSurfaceTextureUpdated(SurfaceTexture surface){}
    @Override public void onSensorChanged(SensorEvent event){if(event.sensor.getType()!=Sensor.TYPE_ROTATION_VECTOR)return;float[] matrix=new float[9],bearing=new float[3];SensorManager.getRotationMatrixFromVector(matrix,event.values);SensorManager.getOrientation(matrix,bearing);heading=(float)((Math.toDegrees(bearing[0])+360.0)%360.0);lastHeadingAt=SystemClock.elapsedRealtime();}
    @Override public void onAccuracyChanged(Sensor sensor,int accuracy){}
    @Override protected void onPause(){if(recording)stopRecording(false);releaseCamera();sensorManager.unregisterListener(this);stopLocation();super.onPause();}
    @Override protected void onDestroy(){closed=true;main.removeCallbacks(telemetryRefresh);if(videoClock!=null)videoClock.shutdownNow();frames.shutdownNow();cleanupRecorder();releaseCamera();super.onDestroy();}
}
