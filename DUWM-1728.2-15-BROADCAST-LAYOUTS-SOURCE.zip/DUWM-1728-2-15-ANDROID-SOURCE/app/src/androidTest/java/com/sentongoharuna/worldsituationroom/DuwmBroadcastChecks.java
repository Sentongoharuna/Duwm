package com.sentongoharuna.worldsituationroom;
import android.app.Instrumentation;
import android.content.Context;
import android.graphics.*;
import android.media.*;
import android.net.Uri;
import java.io.*;
import java.util.*;

/** Actual Android Canvas + EGL/codec export tests. Never part of the production APK. */
final class DuwmBroadcastChecks {
    private int passed;
    private final DuwmNativeEvidence proof;
    DuwmBroadcastChecks(DuwmNativeEvidence proof){this.proof=proof;}
    private void phase(String name){proof.phase(name);}
    private void check(boolean condition,String message){passed++;if(!condition)throw new AssertionError(message);}
    private Duwm1728BroadcastLayout.Report fixture(){
        Duwm1728BroadcastLayout.Report r=new Duwm1728BroadcastLayout.Report();r.title="AUTOMATED GRAPHICS TEST";r.description="Not a published news report";r.category="BREAKING NEWS";r.breakingApproved=true;r.clock="TEST ONLY";
        r.heading="TEST";r.altitude="TEST";r.weather="TEST";r.gps="DO NOT EXPOSE";r.coordinatesAllowed=false;
        r.tickers.add(new Duwm1728BroadcastLayout.Cue(0,10000,"Moving ticker from the same layout used in preview and MP4 export"));return r;
    }
    void pixels(File folder)throws Exception{
        for(int[] size:new int[][]{{720,800},{720,1280},{1280,720}}){
            phase("graphics.canvas."+size[0]+"x"+size[1]);
            Bitmap first=Bitmap.createBitmap(size[0],size[1],Bitmap.Config.ARGB_8888),later=Bitmap.createBitmap(size[0],size[1],Bitmap.Config.ARGB_8888);
            Canvas a=new Canvas(first),b=new Canvas(later);a.drawColor(0xFF17202B);b.drawColor(0xFF17202B);
            Duwm1728BroadcastLayout.Report report=fixture();
            Duwm1728BroadcastLayout.Geometry g=Duwm1728BroadcastLayout.draw(new Duwm1728BroadcastCanvas(a),size[0],size[1],report,0);
            Duwm1728BroadcastLayout.draw(new Duwm1728BroadcastCanvas(b),size[0],size[1],report,1000);
            try(FileOutputStream stream=new FileOutputStream(new File(folder,"NATIVE-"+size[0]+"x"+size[1]+".png"))){check(first.compress(Bitmap.CompressFormat.PNG,100,stream),"Write native PNG");}
            check(first.getPixel((int)(g.x+4*g.unit),(int)(g.tagTop+4*g.unit))==0xFFD50000,"Native exact red badge");
            check(first.getPixel((int)(g.x+130*g.unit),(int)(g.tickerTop+4*g.unit))==0xFF041424,"Native navy ticker");
            int changed=0;for(int y=(int)g.tickerTop;y<(int)g.bottom;y++)for(int x=(int)(g.x+130*g.unit);x<(int)(g.x+g.width-10*g.unit);x++)if(first.getPixel(x,y)!=later.getPixel(x,y))changed++;
            check(changed>20,"Native ticker changes pixels");
            first.recycle();later.recycle();
        }
        portraitInsetPixels(folder);
    }
    private void portraitInsetPixels(File folder)throws Exception{
        phase("graphics.portrait_inset");
        Bitmap portrait=Bitmap.createBitmap(90,160,Bitmap.Config.ARGB_8888);
        Canvas source=new Canvas(portrait);Paint paint=new Paint();paint.setColor(0xFFC91010);source.drawRect(0,0,90,160f/3,paint);
        paint.setColor(0xFF00B842);source.drawRect(0,160f/3,90,320f/3,paint);paint.setColor(0xFF1043D0);source.drawRect(0,320f/3,90,160,paint);
        Duwm1728OverlayRenderer.Spec spec=new Duwm1728OverlayRenderer.Spec();spec.fromMs=0;spec.toMs=1500;spec.title="PORTRAIT INSET TEST";
        Bitmap frame=Bitmap.createBitmap(960,540,Bitmap.Config.ARGB_8888);Duwm1728OverlayRenderer.drawOverlay(new Canvas(frame),spec,500,portrait);
        try{
            try(FileOutputStream output=new FileOutputStream(new File(folder,"NATIVE-PIP-PORTRAIT.png"))){check(frame.compress(Bitmap.CompressFormat.PNG,100,output),"Write native inset pixel proof");}
            Duwm1728FramePlan.Inset inset=Duwm1728FramePlan.inset(960,540,90,160);
            check(Math.abs(inset.width/inset.height-90f/160)<.0001f,"Portrait inset keeps source aspect ratio");
            check(frame.getPixel(760,145)==Color.TRANSPARENT,"Portrait inset does not widen over adjacent source pixels");
            colour(frame,(inset.left+inset.width/2)/960,(inset.top+inset.height*.16f)/540,0xFFC91010,"Portrait inset retains top");
            colour(frame,(inset.left+inset.width/2)/960,(inset.top+inset.height*.5f)/540,0xFF00B842,"Portrait inset retains centre");
            colour(frame,(inset.left+inset.width/2)/960,(inset.top+inset.height*.84f)/540,0xFF1043D0,"Portrait inset retains bottom");
        }finally{portrait.recycle();frame.recycle();}
    }
    void exports4(Instrumentation instrumentation,File folder)throws Exception {
        phase("exports4.fixture");Context target=instrumentation.getTargetContext();
        File master=new File(target.getCacheDir(),"broadcast_fixture.mp4");
        try(InputStream input=instrumentation.getContext().getAssets().open("broadcast_fixture.mp4");FileOutputStream output=new FileOutputStream(master)){byte[] block=new byte[65536];int n;while((n=input.read(block))!=-1)output.write(block,0,n);}
        String sourceDigest=hash(master);
        for(int scenario=0;scenario<4;scenario++){
            phase("exports4."+scenario+".preflight");
            String ratio=new String[]{"9:10","9:16","16:9","16:9"}[scenario];
            boolean trimmed=scenario==3;
            Duwm1728OverlayRenderer.Spec spec=new Duwm1728OverlayRenderer.Spec();spec.fromMs=0;spec.toMs=1900;
            spec.title="AUTOMATED ENCODER TEST";spec.description="Test fixture; not a news event";spec.ratio=ratio;spec.template="BREAKING NEWS";spec.breakingApproved=true;
            spec.ticker="00:00=This ticker is permanently encoded in the test MP4";spec.captions="00:00=Separate caption from the source test";
            if(trimmed){spec.fromMs=500;spec.toMs=1800;spec.tickerOriginMs=0;
                spec.ticker="00:00=First source update;00:01=Second source update";
                spec.automaticCaptions=Arrays.asList(new Duwm1728BroadcastLayout.Cue(650,850,"Short timed subtitle"),new Duwm1728BroadcastLayout.Cue(1200,1500,"Second timed subtitle"));
                Duwm1728OverlayRenderer.prepare(spec);
                check(Duwm1728OverlayRenderer.reportAt(spec,200).captions.get(0).endMs==350,"Trim preserves exact caption end");
                check(Duwm1728BroadcastLayout.active(spec.renderedCaptions,400)==null,"No stale caption in silent gap");
                check(Duwm1728BroadcastLayout.active(spec.renderedTickers,500).text.equals("Second source update"),"Trim does not restart the source ticker");
            }
            Duwm1728ExportPreflight.Result plan=Duwm1728ExportPreflight.inspect(target,Uri.fromFile(master),spec.fromMs,spec.toMs,ratio);
            check(plan.audio,"Preflight inspects actual AAC soundtrack");
            check(plan.durationMs==spec.toMs-spec.fromMs,"Preflight uses selected trim duration");
            check(!plan.encoder.isEmpty(),"Advertised encoder present; actual export follows");
            phase("exports4."+scenario+".encode");File result=Duwm1728OverlayRenderer.export(target,Uri.fromFile(master),spec);
            File proof=new File(folder,"ANDROID-EXPORT-"+ratio.replace(':','-')+(trimmed?"-TRIMMED":"")+".mp4");
            try(InputStream in=new FileInputStream(result);OutputStream out=new FileOutputStream(proof)){byte[] bytes=new byte[65536];int n;while((n=in.read(bytes))!=-1)out.write(bytes,0,n);}finally{result.delete();}
            phase("exports4."+scenario+".decode");int[] expected=Duwm1728BroadcastLayout.dimensions(960,540,ratio);MediaMetadataRetriever checkVideo=new MediaMetadataRetriever();
            try{checkVideo.setDataSource(proof.getAbsolutePath());int width=Integer.parseInt(checkVideo.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)),height=Integer.parseInt(checkVideo.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
                check(width==expected[0]&&height==expected[1],"Encoded ratio and dimensions "+ratio);
                check("yes".equalsIgnoreCase(checkVideo.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)),"AAC audio retained "+ratio);
                long duration=Long.parseLong(checkVideo.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));check(Math.abs(duration-(spec.toMs-spec.fromMs))<180,"Real encoded duration preserved "+ratio);
                Bitmap a=checkVideo.getFrameAtTime(200000,MediaMetadataRetriever.OPTION_CLOSEST),b=checkVideo.getFrameAtTime(1200000,MediaMetadataRetriever.OPTION_CLOSEST);check(a!=null&&b!=null,"Actual MP4 frames decode "+ratio);
                Duwm1728BroadcastLayout.Report report=fixture();report.heading="";report.altitude="";report.weather="";
                Bitmap dummy=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);Duwm1728BroadcastLayout.Geometry g=Duwm1728BroadcastLayout.draw(new Duwm1728BroadcastCanvas(new Canvas(dummy)),width,height,report,0);dummy.recycle();
                int pixel=a.getPixel((int)(g.x+8*g.unit),(int)(g.tagTop+7*g.unit));check(Color.red(pixel)>150&&Color.green(pixel)<65&&Color.blue(pixel)<65,"Red survives MP4 encoding "+ratio);
                int diff=0;for(int y=(int)g.tickerTop+2;y<(int)g.bottom-2;y++)for(int x=(int)(g.x+130*g.unit);x<(int)(g.x+g.width-10*g.unit);x++)if(a.getPixel(x,y)!=b.getPixel(x,y))diff++;
                check(diff>15,"Ticker actually moves in MP4 "+ratio);a.recycle();b.recycle();
            }finally{checkVideo.release();}
            check(sourceDigest.equals(hash(master)),"Original fixture unchanged "+ratio);
            check(Duwm1728ExportPreflight.savedDetails(proof).contains("audio track present"),"Saved-output inspector confirms encoded audio");
        }
        master.delete();phase("exports4.complete");
    }
    private static void copy(InputStream in,OutputStream out)throws Exception{byte[] bytes=new byte[65536];int n;while((n=in.read(bytes))!=-1)out.write(bytes,0,n);}
    private void colour(Bitmap frame,float x,float y,int wanted,String label){int pixel=frame.getPixel(Math.round((frame.getWidth()-1)*x),Math.round((frame.getHeight()-1)*y));
        check(Math.abs(Color.red(pixel)-Color.red(wanted))<40&&Math.abs(Color.green(pixel)-Color.green(wanted))<40&&Math.abs(Color.blue(pixel)-Color.blue(wanted))<40,label+" pixel="+Integer.toHexString(pixel));}
    private File rotateMetadata(File input,Context context)throws Exception{
        File output=new File(context.getCacheDir(),"framing-rotated90.mp4");MediaExtractor e=new MediaExtractor();MediaMuxer m=null;
        try{e.setDataSource(input.getAbsolutePath());m=new MediaMuxer(output.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);m.setOrientationHint(90);
            int[] dest=new int[e.getTrackCount()];for(int i=0;i<dest.length;i++)dest[i]=m.addTrack(e.getTrackFormat(i));m.start();
            java.nio.ByteBuffer buffer=java.nio.ByteBuffer.allocate(2*1024*1024);MediaCodec.BufferInfo b=new MediaCodec.BufferInfo();
            for(int i=0;i<dest.length;i++){e.selectTrack(i);e.seekTo(0,MediaExtractor.SEEK_TO_CLOSEST_SYNC);
                for(;;){buffer.clear();int n=e.readSampleData(buffer,0);if(n<0)break;b.set(0,n,e.getSampleTime(),e.getSampleFlags());m.writeSampleData(dest[i],buffer,b);e.advance();}e.unselectTrack(i);}
            m.stop();return output;
        }finally{e.release();if(m!=null)m.release();}
    }
    void framingExports(Instrumentation instrumentation,File folder)throws Exception{
        phase("framing.fixture");Context target=instrumentation.getTargetContext();File master=new File(target.getCacheDir(),"framing_fixture.mp4");
        try(InputStream in=instrumentation.getContext().getAssets().open("framing_fixture.mp4");OutputStream out=new FileOutputStream(master)){copy(in,out);}
        File rotated=rotateMetadata(master,target);String digest=hash(master),rotatedDigest=hash(rotated);
        try{for(int scenario=0;scenario<6;scenario++){
            phase("framing."+scenario+".encode");
            boolean turn=scenario>=3;File source=turn?rotated:master;
            Duwm1728OverlayRenderer.Spec s=new Duwm1728OverlayRenderer.Spec();s.fromMs=0;s.toMs=1500;s.title="NATIVE FRAMING TEST";s.description="Synthetic marker fixture, not news";
            s.ratio=turn?"16:9":"9:16";s.frameMode=(scenario==0||scenario==3)?"FIT":"FILL";
            s.frameX=scenario==1?0:scenario==2?1:.5f;s.frameY=scenario==4?0:scenario==5?1:.5f;
            s.ticker="00:00=Native encoder framing check • Original master preserved";
            Duwm1728ExportPreflight.Result plan=Duwm1728ExportPreflight.inspect(target,Uri.fromFile(source),s.fromMs,s.toMs,s.ratio,s.frameMode,s.frameX,s.frameY);
            File result=Duwm1728OverlayRenderer.export(target,Uri.fromFile(source),s);File proof=new File(folder,"ANDROID-FRAMING-"+scenario+"-"+s.frameMode+".mp4");
            try(InputStream in=new FileInputStream(result);OutputStream out=new FileOutputStream(proof)){copy(in,out);}finally{result.delete();}
            phase("framing."+scenario+".decode");MediaMetadataRetriever reader=new MediaMetadataRetriever();try{reader.setDataSource(proof.getAbsolutePath());
                check(Integer.toString(plan.width).equals(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)),"Framing exported width");
                check(Integer.toString(plan.height).equals(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)),"Framing exported height");
                check("yes".equals(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)),"Framing keeps AAC audio");
                Bitmap frame=reader.getFrameAtTime(500000,MediaMetadataRetriever.OPTION_CLOSEST);check(frame!=null,"Decode framed MP4");
                if(scenario==0){colour(frame,.10f,.50f,0xFFC91010,"Keep full retains left marker");colour(frame,.90f,.50f,0xFF1043D0,"Keep full retains right marker");colour(frame,.50f,.25f,0xFF041424,"Letterbox uses approved navy");}
                if(scenario==1)colour(frame,.50f,.45f,0xFFC91010,"Left pan selects left source");
                if(scenario==2)colour(frame,.50f,.45f,0xFF1043D0,"Right pan selects right source");
                if(scenario==3){colour(frame,.12f,.45f,0xFF041424,"Rotated source pillarbox navy");colour(frame,.50f,.20f,0xFFC91010,"Rotation90 top marker");colour(frame,.50f,.50f,0xFF00B842,"Rotation90 middle marker");}
                if(scenario==4)colour(frame,.50f,.45f,0xFFC91010,"Top pan after source rotation");
                if(scenario==5)colour(frame,.50f,.45f,0xFF1043D0,"Bottom pan after source rotation");frame.recycle();
            }finally{reader.release();}
        }previewFraming(instrumentation,master,folder);}finally{check(digest.equals(hash(master)),"Framing master unchanged");check(rotatedDigest.equals(hash(rotated)),"Rotated master unchanged");master.delete();rotated.delete();}
    }
    void portraitInsetExport(Instrumentation instrumentation,File folder)throws Exception{
        phase("inset.fixture");Context target=instrumentation.getTargetContext();File master=new File(target.getCacheDir(),"pip_landscape_fixture.mp4");
        try(InputStream in=instrumentation.getContext().getAssets().open("framing_fixture.mp4");OutputStream out=new FileOutputStream(master)){copy(in,out);}
        File portrait=rotateMetadata(master,target);String masterHash=hash(master),portraitHash=hash(portrait);
        try{
            Duwm1728OverlayRenderer.Spec spec=new Duwm1728OverlayRenderer.Spec();spec.fromMs=0;spec.toMs=1500;spec.ratio="16:9";
            spec.title="PORTRAIT INSET ENCODER TEST";spec.description="Synthetic colour markers, not news";spec.pipVideo=Uri.fromFile(portrait);
            phase("inset.encode");File result=Duwm1728OverlayRenderer.export(target,Uri.fromFile(master),spec);File proof=new File(folder,"ANDROID-PIP-PORTRAIT.mp4");
            try(InputStream in=new FileInputStream(result);OutputStream out=new FileOutputStream(proof)){copy(in,out);}finally{result.delete();}
            phase("inset.decode");MediaMetadataRetriever video=new MediaMetadataRetriever();
            try{
                video.setDataSource(proof.getAbsolutePath());Bitmap frame=video.getFrameAtTime(500000,MediaMetadataRetriever.OPTION_CLOSEST);
                check(frame!=null,"Actual portrait-inset MP4 decodes");
                try{
                    check(frame.getWidth()==960&&frame.getHeight()==540,"Inset retains main-video output dimensions");
                    Duwm1728FramePlan.Inset inset=Duwm1728FramePlan.inset(960,540,540,960);
                    colour(frame,.79f,.27f,0xFF1043D0,"Portrait inset leaves adjacent main picture visible");
                    colour(frame,(inset.left+inset.width/2)/960,(inset.top+inset.height*.16f)/540,0xFFC91010,"Encoded portrait inset retains top after rotation");
                    colour(frame,(inset.left+inset.width/2)/960,(inset.top+inset.height*.5f)/540,0xFF00B842,"Encoded portrait inset retains centre");
                    colour(frame,(inset.left+inset.width/2)/960,(inset.top+inset.height*.84f)/540,0xFF1043D0,"Encoded portrait inset retains bottom");
                }finally{frame.recycle();}
                check("yes".equals(video.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)),"Inset export preserves main soundtrack");
            }finally{video.release();}
        }finally{check(masterHash.equals(hash(master)),"Inset export leaves main source unchanged");check(portraitHash.equals(hash(portrait)),"Inset export leaves second video unchanged");master.delete();portrait.delete();}
    }
    private Object field(Object target,String name)throws Exception{java.lang.reflect.Field f=target.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(target);}
    private void setField(Object target,String name,Object value)throws Exception{java.lang.reflect.Field f=target.getClass().getDeclaredField(name);f.setAccessible(true);f.set(target,value);}
    private void screenColour(Bitmap screen,int[] origin,int w,int h,float x,float y,int wanted,String label){
        int px=origin[0]+Math.round((w-1)*x),py=origin[1]+Math.round((h-1)*y);
        check(px>=0&&py>=0&&px<screen.getWidth()&&py<screen.getHeight(),label+" in screenshot bounds");
        int v=screen.getPixel(px,py);check(Math.abs(Color.red(v)-Color.red(wanted))<40&&Math.abs(Color.green(v)-Color.green(wanted))<40&&Math.abs(Color.blue(v)-Color.blue(wanted))<40,label+" actual screen="+Integer.toHexString(v));
    }
    private void previewFraming(Instrumentation runner,File source,File folder)throws Exception{
        phase("framing.editor.launch");
        android.content.Intent intent=new android.content.Intent(runner.getTargetContext(),Duwm1728VideoEditorActivity.class)
            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(Duwm1728VideoEditorActivity.EXTRA_VIDEO_URI,Uri.fromFile(source).toString()).putExtra("broadcast_ratio","9:16");
        android.app.Activity editor=runner.startActivitySync(intent);
        try{
            long deadline=android.os.SystemClock.elapsedRealtime()+15000;boolean ready=false;
            while(!ready&&android.os.SystemClock.elapsedRealtime()<deadline){java.util.concurrent.atomic.AtomicBoolean value=new java.util.concurrent.atomic.AtomicBoolean();
                ui(runner,()->value.set((Boolean)field(editor,"prepared")));ready=value.get();if(!ready)Thread.sleep(100);}
            check(ready,"Actual editor MediaPlayer prepared");
            phase("framing.editor.ready");
            java.util.concurrent.atomic.AtomicReference<Throwable> error=new java.util.concurrent.atomic.AtomicReference<>();
            for(int scenario=0;scenario<3;scenario++){
                phase("framing.editor."+scenario+".preview");
                final int step=scenario;final int[] origin=new int[2],size=new int[2];
                ui(runner,()->{try{setField(editor,"frameMode",step==0?"FIT":"FILL");setField(editor,"frameX",step==1?0f:step==2?1f:.5f);setField(editor,"frameY",.5f);
                    java.lang.reflect.Method refresh=editor.getClass().getDeclaredMethod("refresh");refresh.setAccessible(true);refresh.invoke(editor);
                    MediaPlayer player=(MediaPlayer)field(editor,"player");player.setVolume(0,0);player.seekTo(500);player.start();
                }catch(Throwable t){error.set(t);}});
                if(error.get()!=null)throw new AssertionError("Native preview update failed",error.get());
                runner.waitForIdleSync();Thread.sleep(500);
                ui(runner,()->{try{android.view.TextureView view=(android.view.TextureView)field(editor,"texture");view.getLocationOnScreen(origin);size[0]=view.getWidth();size[1]=view.getHeight();}catch(Throwable t){error.set(t);}});
                if(error.get()!=null)throw new AssertionError("Native view bounds failed",error.get());
                check(size[0]>64&&size[1]>64,"Actual camera-first editor viewport visible");
                Bitmap screenshot=runner.getUiAutomation().takeScreenshot();check(screenshot!=null,"Actual Android preview screenshot captured");
                try{
                    try(FileOutputStream output=new FileOutputStream(new File(folder,"ANDROID-EDITOR-FRAMING-"+scenario+".png"))){check(screenshot.compress(Bitmap.CompressFormat.PNG,100,output),"Save actual editor screenshot");}
                    proof.assertUnobstructed("ANDROID-EDITOR-FRAMING-"+scenario);
                    if(scenario==0){screenColour(screenshot,origin,size[0],size[1],.1f,.5f,0xFFC91010,"Native preview keeps left marker");screenColour(screenshot,origin,size[0],size[1],.9f,.5f,0xFF1043D0,"Native preview keeps right marker");screenColour(screenshot,origin,size[0],size[1],.5f,.25f,0xFF041424,"Native preview has navy letterbox");}
                    if(scenario==1)screenColour(screenshot,origin,size[0],size[1],.5f,.45f,0xFFC91010,"Native preview follows left pan");
                    if(scenario==2)screenColour(screenshot,origin,size[0],size[1],.5f,.45f,0xFF1043D0,"Native preview follows right pan");
                }finally{screenshot.recycle();}
            }
        }finally{ui(runner,editor::finish);runner.waitForIdleSync();}
    }
    private boolean flag(Instrumentation runner,Object target,String name)throws Exception{
        java.util.concurrent.atomic.AtomicBoolean value=new java.util.concurrent.atomic.AtomicBoolean();
        ui(runner,()->value.set((Boolean)field(target,name)));return value.get();
    }
    private int reviewPosition(Instrumentation runner,android.app.Activity activity)throws Exception{
        java.util.concurrent.atomic.AtomicInteger value=new java.util.concurrent.atomic.AtomicInteger();
        ui(runner,()->value.set(((android.widget.VideoView)activity.getWindow().getDecorView().findViewWithTag("broadcast-review-video")).getCurrentPosition()));
        return value.get();
    }
    void savedVideoReview(Instrumentation runner,File folder)throws Exception{
        Context target=runner.getTargetContext();File encoded=reviewFixture(runner,folder,"ANDROID-REVIEW-FIXTURE.mp4");
        phase("review.publish");
        String name="DUWM_NATIVE_REVIEW_"+System.currentTimeMillis()+".mp4";
        Uri published=Duwm1724GalleryPublisher.publish(target,encoded,name);android.app.Activity review=null;
        try{
            check("content".equals(published.getScheme()),"Finished MP4 is published as a grantable Gallery URI");
            long length=0;try(InputStream input=target.getContentResolver().openInputStream(published)){check(input!=null,"Published MP4 opens through ContentResolver");byte[] bytes=new byte[65536];int n;while((n=input.read(bytes))!=-1)length+=n;}
            check(length==encoded.length(),"Published video has all encoded bytes");
            android.content.Intent share=Duwm1728BroadcastReviewActivity.shareIntent(published);
            check(android.content.Intent.ACTION_SEND.equals(share.getAction())&&"video/mp4".equals(share.getType()),"Share intent sends a real MP4");
            check(published.equals(share.getParcelableExtra(android.content.Intent.EXTRA_STREAM)),"Share stream is the finished Gallery MP4");
            check(share.getClipData()!=null&&share.getClipData().getItemCount()==1&&published.equals(share.getClipData().getItemAt(0).getUri()),"Share ClipData grants the same saved URI");
            check((share.getFlags()&android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)!=0,"Share carries temporary read access");
            boolean rejected=false;try{Duwm1728BroadcastReviewActivity.shareIntent(Uri.fromFile(encoded));}catch(IllegalArgumentException expected){rejected=true;}
            check(rejected,"Unshareable file paths are rejected");
            phase("review.launch");review=runner.startActivitySync(Duwm1728BroadcastReviewActivity.intent(target,published).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK));
            final android.app.Activity activity=review;long deadline=android.os.SystemClock.elapsedRealtime()+15000;
            while(!flag(runner,activity,"ready")&&android.os.SystemClock.elapsedRealtime()<deadline)Thread.sleep(100);
            check(flag(runner,activity,"ready"),"Actual saved MP4 reaches prepared playback");
            phase("review.play");
            java.util.concurrent.atomic.AtomicReference<Object> facts=new java.util.concurrent.atomic.AtomicReference<>();
            ui(runner,()->{facts.set(field(activity,"facts"));activity.getWindow().getDecorView().findViewWithTag("broadcast-review-play").performClick();});
            check((Integer)field(facts.get(),"width")==960&&(Integer)field(facts.get(),"height")==540,"Review reads encoded output dimensions");
            check((Boolean)field(facts.get(),"audio"),"Review reads actual audio-track presence");
            check(Math.abs((Long)field(facts.get(),"durationMs")-1500)<180,"Review reads actual MP4 duration");
            deadline=android.os.SystemClock.elapsedRealtime()+5000;
            while(reviewPosition(runner,activity)<200&&android.os.SystemClock.elapsedRealtime()<deadline)Thread.sleep(100);
            check(reviewPosition(runner,activity)>=200,"Native PLAY advances the saved video");
            final int[] origin=new int[2],size=new int[2];
            ui(runner,()->{
                android.widget.VideoView video=activity.getWindow().getDecorView().findViewWithTag("broadcast-review-video");
                if(video.isPlaying())activity.getWindow().getDecorView().findViewWithTag("broadcast-review-play").performClick();
                check(!video.isPlaying(),"Native PAUSE stops playback");video.getLocationOnScreen(origin);size[0]=video.getWidth();size[1]=video.getHeight();
            });
            check(size[0]>64&&size[1]>64&&Math.abs(size[0]/(float)size[1]-16f/9f)<.03f,"Review retains encoded aspect without stretching");
            runner.waitForIdleSync();Bitmap screenshot=runner.getUiAutomation().takeScreenshot();check(screenshot!=null,"Capture actual saved-video SurfaceView");
            try{
                try(FileOutputStream out=new FileOutputStream(new File(folder,"ANDROID-SAVED-VIDEO-REVIEW.png"))){check(screenshot.compress(Bitmap.CompressFormat.PNG,100,out),"Save real playback screen proof");}
                proof.assertUnobstructed("ANDROID-SAVED-VIDEO-REVIEW");
                screenColour(screenshot,origin,size[0],size[1],.10f,.45f,0xFFC91010,"Saved review displays encoded left marker");
                screenColour(screenshot,origin,size[0],size[1],.90f,.50f,0xFF1043D0,"Saved review displays encoded right marker");
            }finally{screenshot.recycle();}
            phase("review.seek");ui(runner,()->{
                android.widget.SeekBar bar=activity.getWindow().getDecorView().findViewWithTag("broadcast-review-seek");
                float x=bar.getPaddingLeft()+(bar.getWidth()-bar.getPaddingLeft()-bar.getPaddingRight())*2f/3f,y=bar.getHeight()/2f;
                long now=android.os.SystemClock.uptimeMillis();android.view.MotionEvent down=android.view.MotionEvent.obtain(now,now,android.view.MotionEvent.ACTION_DOWN,x,y,0);
                android.view.MotionEvent up=android.view.MotionEvent.obtain(now,now+30,android.view.MotionEvent.ACTION_UP,x,y,0);
                try{bar.dispatchTouchEvent(down);bar.dispatchTouchEvent(up);}finally{down.recycle();up.recycle();}
            });
            deadline=android.os.SystemClock.elapsedRealtime()+5000;int seekPosition=reviewPosition(runner,activity);
            while((seekPosition<750||seekPosition>1300)&&android.os.SystemClock.elapsedRealtime()<deadline){Thread.sleep(100);seekPosition=reviewPosition(runner,activity);}
            check(seekPosition>=750&&seekPosition<=1300,"Native seek bar moves within a short encoded clip");
            ui(runner,activity::finish);runner.waitForIdleSync();review=null;
            phase("review.missing_file");
            check(target.getContentResolver().delete(published,null,null)==1,"Delete only the test-owned published video");
            review=runner.startActivitySync(Duwm1728BroadcastReviewActivity.intent(target,published).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK));
            final android.app.Activity missing=review;deadline=android.os.SystemClock.elapsedRealtime()+10000;
            java.util.concurrent.atomic.AtomicBoolean reported=new java.util.concurrent.atomic.AtomicBoolean();
            while(!reported.get()&&android.os.SystemClock.elapsedRealtime()<deadline){
                ui(runner,()->reported.set("VIDEO UNAVAILABLE".contentEquals(((android.widget.TextView)missing.getWindow().getDecorView().findViewWithTag("broadcast-review-status")).getText())));
                if(!reported.get())Thread.sleep(100);
            }
            check(reported.get()&&!flag(runner,missing,"ready")&&!flag(runner,missing,"available"),"Deleted saved video has an unavailable state, not false playback success");
            ui(runner,()->check(!missing.getWindow().getDecorView().findViewWithTag("broadcast-review-share").isEnabled(),"Missing saved video cannot be shared"));
        }finally{
            if(review!=null){final android.app.Activity closing=review;ui(runner,closing::finish);runner.waitForIdleSync();}
            target.getContentResolver().delete(published,null,null);
        }
    }
    private File reviewFixture(Instrumentation runner,File folder,String name)throws Exception{
        File encoded=new File(folder,name);
        if(proof.reuse("inset1","ANDROID-PIP-PORTRAIT.mp4",encoded)
                ||(!name.equals("ANDROID-REVIEW-FIXTURE.mp4")&&proof.reuse("review","ANDROID-REVIEW-FIXTURE.mp4",encoded)))return encoded;
        phase("review.fixture.encode");File source=new File(runner.getTargetContext().getCacheDir(),"native-review-source.mp4");
        try{
            try(InputStream in=runner.getContext().getAssets().open("framing_fixture.mp4");OutputStream out=new FileOutputStream(source)){copy(in,out);}
            Duwm1728OverlayRenderer.Spec spec=new Duwm1728OverlayRenderer.Spec();spec.fromMs=0;spec.toMs=1500;spec.ratio="16:9";spec.frameMode="FIT";
            spec.title="SAVED VIDEO CONTROL TEST";spec.description="Synthetic native fixture, not news";
            File result=Duwm1728OverlayRenderer.export(runner.getTargetContext(),Uri.fromFile(source),spec);
            try(InputStream in=new FileInputStream(result);OutputStream out=new FileOutputStream(encoded)){copy(in,out);}finally{result.delete();}
            return encoded;
        }finally{source.delete();}
    }
    private interface UiAction{void run()throws Exception;}
    private void ui(Instrumentation runner,UiAction action)throws Exception{
        java.util.concurrent.atomic.AtomicReference<Throwable> failure=new java.util.concurrent.atomic.AtomicReference<>();
        runner.runOnMainSync(()->{try{action.run();}catch(Throwable error){failure.set(error);}});
        Throwable error=failure.get();if(error instanceof Error)throw (Error)error;if(error instanceof Exception)throw (Exception)error;
    }
    private android.view.View tagged(android.app.Activity activity,String tag){
        android.view.View view=activity.getWindow().getDecorView().findViewWithTag(tag);check(view!=null,"Native control exists: "+tag);return view;
    }
    private void click(Instrumentation runner,android.app.Activity activity,String tag)throws Exception{
        ui(runner,()->{android.view.View view=tagged(activity,tag);check(view.isShown()&&view.isEnabled(),"Native control is visible and enabled: "+tag);check(view.performClick(),"Native control handles click: "+tag);});
    }
    private void capture(Instrumentation runner,File folder,String name)throws Exception{
        runner.waitForIdleSync();Bitmap screenshot=runner.getUiAutomation().takeScreenshot();check(screenshot!=null,"Capture "+name);
        try{try(FileOutputStream out=new FileOutputStream(new File(folder,name+".png"))){check(screenshot.compress(Bitmap.CompressFormat.PNG,100,out),"Save "+name);}}
        finally{screenshot.recycle();}
        proof.assertUnobstructed(name);
    }
    private void seekFraction(Instrumentation runner,android.app.Activity activity,String tag,float fraction)throws Exception{
        ui(runner,()->{
            android.widget.SeekBar bar=(android.widget.SeekBar)tagged(activity,tag);check(bar.isEnabled()&&bar.getWidth()>0,"Seek control can be used");
            float x=bar.getPaddingLeft()+(bar.getWidth()-bar.getPaddingLeft()-bar.getPaddingRight())*Math.max(0,Math.min(1,fraction)),y=bar.getHeight()/2f;
            long now=android.os.SystemClock.uptimeMillis();android.view.MotionEvent down=android.view.MotionEvent.obtain(now,now,android.view.MotionEvent.ACTION_DOWN,x,y,0);
            android.view.MotionEvent up=android.view.MotionEvent.obtain(now,now+30,android.view.MotionEvent.ACTION_UP,x,y,0);
            try{bar.dispatchTouchEvent(down);bar.dispatchTouchEvent(up);}finally{down.recycle();up.recycle();}
        });
    }
    private void awaitReady(Instrumentation runner,android.app.Activity activity,String fieldName)throws Exception{
        long deadline=android.os.SystemClock.elapsedRealtime()+15000;
        while(!flag(runner,activity,fieldName)&&android.os.SystemClock.elapsedRealtime()<deadline)Thread.sleep(100);
        check(flag(runner,activity,fieldName),"Native activity prepared: "+fieldName);
    }
    private int editorPosition(Instrumentation runner,android.app.Activity editor)throws Exception{
        java.util.concurrent.atomic.AtomicInteger value=new java.util.concurrent.atomic.AtomicInteger();ui(runner,()->value.set(((MediaPlayer)field(editor,"player")).getCurrentPosition()));return value.get();
    }
    private long editorBound(Instrumentation runner,android.app.Activity editor,String name)throws Exception{
        java.util.concurrent.atomic.AtomicLong value=new java.util.concurrent.atomic.AtomicLong();
        ui(runner,()->value.set(Math.round(Double.parseDouble(((android.widget.EditText)field(editor,name)).getText().toString())*1000)));return value.get();
    }
    private int seekEditor(Instrumentation runner,android.app.Activity editor,long target,long from,long to)throws Exception{
        seekFraction(runner,editor,"broadcast-editor-seek",(target-from)/(float)(to-from));
        long deadline=android.os.SystemClock.elapsedRealtime()+5000;int position=editorPosition(runner,editor);
        while(Math.abs(position-target)>120&&android.os.SystemClock.elapsedRealtime()<deadline){Thread.sleep(100);position=editorPosition(runner,editor);}
        check(Math.abs(position-target)<=120,"Real editor seek reaches a subsecond source position");return position;
    }
    private android.app.Activity openEditor(Instrumentation runner,File source)throws Exception{
        phase("editor_controls.launch");android.content.Intent intent=new android.content.Intent(runner.getTargetContext(),Duwm1728VideoEditorActivity.class)
            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(Duwm1728VideoEditorActivity.EXTRA_VIDEO_URI,Uri.fromFile(source).toString()).putExtra("broadcast_ratio","16:9");
        android.app.Activity activity=runner.startActivitySync(intent);awaitReady(runner,activity,"prepared");return activity;
    }
    void editorControls(Instrumentation runner,File folder)throws Exception{
        File source=new File(runner.getTargetContext().getCacheDir(),"editor-controls-"+System.currentTimeMillis()+".mp4");
        try(InputStream in=runner.getContext().getAssets().open("framing_fixture.mp4");OutputStream out=new FileOutputStream(source)){copy(in,out);}
        String original=hash(source);android.app.Activity editor=null;
        try{
            editor=openEditor(runner,source);final android.app.Activity first=editor;
            capture(runner,folder,"ANDROID-EDITOR-CONTROLS-READY");
            java.util.concurrent.atomic.AtomicLong duration=new java.util.concurrent.atomic.AtomicLong();
            ui(runner,()->{
                duration.set((Long)field(first,"durationMs"));check(duration.get()>1700,"Trim fixture contains distinct subsecond source marks");
                ((android.widget.EditText)field(first,"title")).setText("NATIVE TRIM CONTROL TEST");
                ((android.widget.EditText)field(first,"ticker")).setText("00:00=Original source cue");
                ((android.widget.EditText)field(first,"subtitles")).setText("00:00=Original source subtitle");
                setField(first,"tickerOriginMs",137L);setField(first,"captionOriginMs",281L);
            });
            phase("editor_controls.paused_clock");seekEditor(runner,first,437,0,duration.get());Thread.sleep(300);
            java.util.concurrent.atomic.AtomicInteger textWrites=new java.util.concurrent.atomic.AtomicInteger();
            android.text.TextWatcher observer=new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){}public void afterTextChanged(android.text.Editable text){textWrites.incrementAndGet();}};
            ui(runner,()->((android.widget.TextView)tagged(first,"broadcast-editor-time")).addTextChangedListener(observer));
            int pausedAt=editorPosition(runner,first);
            try{Thread.sleep(600);check(textWrites.get()==0,"Paused editor does not repeatedly rewrite an unchanged playback label");check(Math.abs(editorPosition(runner,first)-pausedAt)<=50,"Paused source playhead remains stationary");}
            finally{ui(runner,()->((android.widget.TextView)tagged(first,"broadcast-editor-time")).removeTextChangedListener(observer));}
            phase("editor_controls.mark_in");
            ui(runner,()->((android.widget.CheckBox)field(first,"approval")).setChecked(true));
            int beforeIn=editorPosition(runner,first);click(runner,first,"broadcast-editor-mark-in");long markedIn=editorBound(runner,first,"from");
            check(Math.abs(markedIn-beforeIn)<=50&&markedIn%1000!=0,"MARK IN captures the actual millisecond playhead, not a whole-second approximation");
            check(editorBound(runner,first,"to")==duration.get(),"MARK IN preserves the existing OUT bound");
            ui(runner,()->{check(!((MediaPlayer)field(first,"player")).isPlaying(),"MARK IN pauses the source");check(!((android.widget.CheckBox)field(first,"approval")).isChecked(),"MARK IN clears prior export approval");});
            phase("editor_controls.mark_out");seekEditor(runner,first,1567,markedIn,duration.get());
            ui(runner,()->((android.widget.CheckBox)field(first,"approval")).setChecked(true));
            int beforeOut=editorPosition(runner,first);click(runner,first,"broadcast-editor-mark-out");long markedOut=editorBound(runner,first,"to");
            capture(runner,folder,"ANDROID-EDITOR-TRIM-MARKS");
            check(Math.abs(markedOut-beforeOut)<=50&&markedOut%1000!=0,"MARK OUT captures the actual millisecond playhead");
            check(editorBound(runner,first,"from")==markedIn&&markedOut>markedIn,"MARK OUT preserves IN and a valid source range");
            ui(runner,()->{
                check((Long)field(first,"tickerOriginMs")==137L&&(Long)field(first,"captionOriginMs")==281L,"Trim marks preserve ticker and subtitle source-time origins");
                check(!((android.widget.CheckBox)field(first,"approval")).isChecked(),"MARK OUT clears prior export approval");
                Duwm1728OverlayRenderer.Spec spec=(Duwm1728OverlayRenderer.Spec)field(first,"previewSpec");
                check(spec.fromMs==markedIn&&spec.toMs==markedOut,"Visible marks drive the actual preview/export trim specification");
            });
            ui(runner,first::finish);runner.waitForIdleSync();editor=null;
            phase("editor_controls.restore");editor=openEditor(runner,source);final android.app.Activity restored=editor;
            capture(runner,folder,"ANDROID-EDITOR-TRIM-RESTORED");
            check(editorBound(runner,restored,"from")==markedIn&&editorBound(runner,restored,"to")==markedOut,"Reopened draft retains the marked millisecond range");
            ui(runner,()->check((Long)field(restored,"tickerOriginMs")==137L&&(Long)field(restored,"captionOriginMs")==281L,"Reopened draft retains source cue origins"));
            phase("editor_controls.reset");click(runner,restored,"broadcast-editor-reset-trim");
            capture(runner,folder,"ANDROID-EDITOR-TRIM-RESET");
            check(editorBound(runner,restored,"from")==0&&editorBound(runner,restored,"to")==duration.get(),"RESET TRIM restores the complete original source");
            ui(runner,()->{
                check(!((MediaPlayer)field(restored,"player")).isPlaying(),"RESET TRIM leaves playback paused");
                check((Long)field(restored,"tickerOriginMs")==137L&&(Long)field(restored,"captionOriginMs")==281L,"RESET TRIM does not restart source cue timing");
            });
            editorLandscape(runner,restored,folder,duration.get());
            check(original.equals(hash(source)),"Trim controls leave the original recording byte-for-byte unchanged");
        }finally{if(editor!=null){final android.app.Activity closing=editor;ui(runner,closing::finish);runner.waitForIdleSync();}source.delete();}
    }
    private void editorLandscape(Instrumentation runner,android.app.Activity editor,File folder,long duration)throws Exception{
        phase("editor_controls.landscape");seekEditor(runner,editor,1233,0,duration);int before=editorPosition(runner,editor);
        java.util.concurrent.atomic.AtomicReference<android.view.TextureView> original=new java.util.concurrent.atomic.AtomicReference<>();
        java.util.concurrent.atomic.AtomicReference<android.view.ViewParent> parent=new java.util.concurrent.atomic.AtomicReference<>();
        ui(runner,()->{original.set((android.view.TextureView)field(editor,"texture"));parent.set(original.get().getParent());editor.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);});
        long deadline=android.os.SystemClock.elapsedRealtime()+15000;java.util.concurrent.atomic.AtomicBoolean landscape=new java.util.concurrent.atomic.AtomicBoolean();
        while(!landscape.get()&&android.os.SystemClock.elapsedRealtime()<deadline){
            ui(runner,()->{android.view.View workspace=tagged(editor,"broadcast-editor-workspace");landscape.set(editor.getResources().getConfiguration().orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE&&workspace.getWidth()>workspace.getHeight());});
            if(!landscape.get())Thread.sleep(100);
        }
        runner.waitForIdleSync();
        final String[] controls={"broadcast-editor-mark-in","broadcast-editor-mark-out","broadcast-editor-reset-trim"};boolean[] reachable=new boolean[controls.length];
        for(int i=0;i<controls.length;i++){
            final int index=i;ui(runner,()->{android.view.View control=tagged(editor,controls[index]);control.requestRectangleOnScreen(new Rect(0,0,control.getWidth(),control.getHeight()),true);});runner.waitForIdleSync();
            ui(runner,()->{android.view.View control=tagged(editor,controls[index]);Rect visible=new Rect();reachable[index]=control.isEnabled()&&control.isClickable()&&control.getGlobalVisibleRect(visible)&&visible.width()>=control.getWidth()-2&&visible.height()>=control.getHeight()-2;});
        }
        capture(runner,folder,"ANDROID-EDITOR-TRIM-LANDSCAPE");
        check(landscape.get(),"The same editor reaches a real landscape window");
        ui(runner,()->{
            android.view.TextureView texture=(android.view.TextureView)field(editor,"texture");Rect visible=new Rect();int minimum=Math.round(80*editor.getResources().getDisplayMetrics().density);
            check(texture==original.get()&&texture.getParent()==parent.get(),"Rotation preserves the existing source TextureView and its parent");
            check(texture.isShown()&&texture.getWidth()>=minimum&&texture.getHeight()>=minimum&&texture.getGlobalVisibleRect(visible)&&visible.width()>=texture.getWidth()-2&&visible.height()>=texture.getHeight()-2,
                "Landscape retains a visible full source viewport beside the controls");
            for(int i=0;i<controls.length;i++)check(reachable[i],"Landscape trim control remains reachable by scrolling: "+controls[i]);
            check(!((MediaPlayer)field(editor,"player")).isPlaying(),"Rotation does not start paused source playback");
        });
        check(Math.abs(editorPosition(runner,editor)-before)<=80,"Landscape rotation preserves the paused subsecond playhead");
        check(editorBound(runner,editor,"from")==0&&editorBound(runner,editor,"to")==duration,"Landscape rotation retains the selected source trim");
    }
    private boolean reviewPlaying(Instrumentation runner,android.app.Activity activity)throws Exception{
        java.util.concurrent.atomic.AtomicBoolean playing=new java.util.concurrent.atomic.AtomicBoolean();
        ui(runner,()->playing.set(((android.widget.VideoView)tagged(activity,"broadcast-review-video")).isPlaying()));return playing.get();
    }
    private android.app.Activity openReview(Instrumentation runner,Uri uri)throws Exception{
        phase("review_controls.launch");android.app.Activity activity=runner.startActivitySync(Duwm1728BroadcastReviewActivity.intent(runner.getTargetContext(),uri).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK));
        awaitReady(runner,activity,"ready");return activity;
    }
    private int awaitReviewPosition(Instrumentation runner,android.app.Activity activity,int target,int tolerance)throws Exception{
        long deadline=android.os.SystemClock.elapsedRealtime()+5000;int position=reviewPosition(runner,activity);
        while(Math.abs(position-target)>tolerance&&android.os.SystemClock.elapsedRealtime()<deadline){Thread.sleep(100);position=reviewPosition(runner,activity);}
        check(Math.abs(position-target)<=tolerance,"Actual saved-video seek/resume reaches requested position");return position;
    }
    void reviewControls(Instrumentation runner,File folder)throws Exception{
        File encoded=reviewFixture(runner,folder,"ANDROID-REVIEW-CONTROLS-FIXTURE.mp4");Context target=runner.getTargetContext();
        phase("review_controls.publish");Uri published=Duwm1724GalleryPublisher.publish(target,encoded,"DUWM_NATIVE_CONTROLS_"+System.currentTimeMillis()+".mp4");
        android.app.Activity review=null;
        try{
            check("content".equals(published.getScheme()),"Isolated review controls use an actual published content URI");
            review=openReview(runner,published);final android.app.Activity first=review;
            capture(runner,folder,"ANDROID-REVIEW-CONTROLS-READY");
            check(!reviewPlaying(runner,first),"New saved-video review opens paused");
            check(!flag(runner,first,"loopEnabled")&&!flag(runner,first,"muted"),"New saved video starts with independent loop/mute preferences");
            phase("review_controls.preferences");click(runner,first,"broadcast-review-loop");click(runner,first,"broadcast-review-mute");
            ui(runner,()->{
                check((Boolean)field(first,"loopEnabled")&&((MediaPlayer)field(first,"mediaPlayer")).isLooping(),"LOOP ON applies to the actual native MediaPlayer");
                check((Boolean)field(first,"muted"),"MUTE ON changes the playback preference");
                android.widget.TextView loop=(android.widget.TextView)tagged(first,"broadcast-review-loop"),mute=(android.widget.TextView)tagged(first,"broadcast-review-mute");
                check(loop.isSelected()&&"LOOP ON".contentEquals(loop.getText()),"Loop state is visibly selected");
                check(mute.isSelected()&&"MUTE ON".contentEquals(mute.getText()),"Mute state is visibly selected");
            });
            phase("review_controls.loop_playback");seekFraction(runner,first,"broadcast-review-seek",.8f);awaitReviewPosition(runner,first,1200,180);
            click(runner,first,"broadcast-review-play");long deadline=android.os.SystemClock.elapsedRealtime()+5000;boolean wrapped=false;
            while(!wrapped&&android.os.SystemClock.elapsedRealtime()<deadline){int position=reviewPosition(runner,first);wrapped=position<750&&reviewPlaying(runner,first);if(!wrapped)Thread.sleep(100);}
            check(wrapped,"LOOP ON crosses the encoded end and continues playing from the beginning");
            click(runner,first,"broadcast-review-play");check(!reviewPlaying(runner,first),"Looping playback can still be paused");
            phase("review_controls.fullscreen");java.util.concurrent.atomic.AtomicReference<android.widget.VideoView> originalVideo=new java.util.concurrent.atomic.AtomicReference<>();
            ui(runner,()->originalVideo.set((android.widget.VideoView)tagged(first,"broadcast-review-video")));
            click(runner,first,"broadcast-review-fullscreen");runner.waitForIdleSync();
            final int[] origin=new int[2],size=new int[2];
            ui(runner,()->{
                check((Boolean)field(first,"fullscreen"),"Full-screen entry changes the active mode");
                check(!tagged(first,"broadcast-review-header").isShown()&&!tagged(first,"broadcast-review-controls").isShown(),"Full-screen reserves the picture area by hiding ordinary controls");
                android.widget.VideoView video=(android.widget.VideoView)tagged(first,"broadcast-review-video");
                check(video==originalVideo.get(),"Full-screen retains the same saved-video player and surface");
                video.getLocationOnScreen(origin);size[0]=video.getWidth();size[1]=video.getHeight();
                android.view.View exit=tagged(first,"broadcast-review-exit-fullscreen");int[] exitOrigin=new int[2];exit.getLocationOnScreen(exitOrigin);
                check(exit.isShown()&&exit.isEnabled()&&exit.isClickable()&&exit.getHeight()>=Math.round(48*target.getResources().getDisplayMetrics().density),"Full-screen always exposes a usable CONTROLS exit");
                Rect picture=new Rect(origin[0],origin[1],origin[0]+size[0],origin[1]+size[1]);Rect exitRect=new Rect(exitOrigin[0],exitOrigin[1],exitOrigin[0]+exit.getWidth(),exitOrigin[1]+exit.getHeight());
                check(!Rect.intersects(picture,exitRect),"Full-screen controls do not cover finished video pixels");
            });
            check(size[0]>64&&size[1]>64&&Math.abs(size[0]/(float)size[1]-16f/9f)<.03f,"Full-screen retains the encoded aspect ratio without stretching");
            Bitmap fullscreen=runner.getUiAutomation().takeScreenshot();check(fullscreen!=null,"Capture actual full-screen playback surface");
            try{
                try(FileOutputStream out=new FileOutputStream(new File(folder,"ANDROID-REVIEW-FULLSCREEN.png"))){check(fullscreen.compress(Bitmap.CompressFormat.PNG,100,out),"Save native full-screen proof");}
                proof.assertUnobstructed("ANDROID-REVIEW-FULLSCREEN");
                screenColour(fullscreen,origin,size[0],size[1],.10f,.45f,0xFFC91010,"Full-screen retains the encoded left source marker");
                screenColour(fullscreen,origin,size[0],size[1],.90f,.50f,0xFF1043D0,"Full-screen retains the encoded right source marker");
            }finally{fullscreen.recycle();}
            click(runner,first,"broadcast-review-fullscreen-mute");
            check(!flag(runner,first,"muted"),"Full-screen mute control changes the same preference");
            click(runner,first,"broadcast-review-fullscreen-mute");
            runner.sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_BACK);runner.waitForIdleSync();
            check(!flag(runner,first,"fullscreen")&&!first.isFinishing(),"System Back leaves full-screen before leaving saved-video review");
            click(runner,first,"broadcast-review-fullscreen");click(runner,first,"broadcast-review-exit-fullscreen");runner.waitForIdleSync();
            ui(runner,()->check(!(Boolean)field(first,"fullscreen")&&tagged(first,"broadcast-review-header").isShown()&&tagged(first,"broadcast-review-controls").isShown(),"CONTROLS restores the ordinary review interface"));
            phase("review_controls.persist");seekFraction(runner,first,"broadcast-review-seek",.6f);int pausedAt=awaitReviewPosition(runner,first,900,180);
            check(!reviewPlaying(runner,first),"Seeking does not start paused playback");
            ui(runner,first::finish);runner.waitForIdleSync();review=null;
            review=openReview(runner,published);final android.app.Activity restored=review;
            awaitReviewPosition(runner,restored,pausedAt,180);capture(runner,folder,"ANDROID-REVIEW-RESTORED");
            check(!reviewPlaying(runner,restored),"Reopening resumes the saved position without autoplay");
            ui(runner,()->{
                check((Boolean)field(restored,"loopEnabled")&&(Boolean)field(restored,"muted"),"Reopening restores loop and mute for this saved URI");
                check(((MediaPlayer)field(restored,"mediaPlayer")).isLooping(),"Restored loop preference reaches the newly prepared player");
                check(tagged(restored,"broadcast-review-loop").isSelected()&&tagged(restored,"broadcast-review-mute").isSelected(),"Restored preferences are visible in their controls");
            });
            phase("review_controls.completed_restart");click(runner,restored,"broadcast-review-loop");
            ui(runner,()->check(!((MediaPlayer)field(restored,"mediaPlayer")).isLooping(),"LOOP OFF reaches the actual player"));
            seekFraction(runner,restored,"broadcast-review-seek",.8f);awaitReviewPosition(runner,restored,1200,180);click(runner,restored,"broadcast-review-play");
            deadline=android.os.SystemClock.elapsedRealtime()+5000;while(!flag(runner,restored,"ended")&&android.os.SystemClock.elapsedRealtime()<deadline)Thread.sleep(100);
            check(flag(runner,restored,"ended")&&!reviewPlaying(runner,restored),"LOOP OFF allows the saved clip to complete");
            ui(runner,restored::finish);runner.waitForIdleSync();review=null;
            review=openReview(runner,published);final android.app.Activity completed=review;awaitReviewPosition(runner,completed,0,100);
            check(!reviewPlaying(runner,completed)&&!flag(runner,completed,"loopEnabled"),"A completed clip reopens at the beginning and stays paused");
        }finally{
            if(review!=null){final android.app.Activity closing=review;ui(runner,closing::finish);runner.waitForIdleSync();}
            target.getContentResolver().delete(published,null,null);
        }
    }
    void exportRecovery(Instrumentation runner,File folder)throws Exception{
        Context target=runner.getTargetContext();phase("recovery.fixture");
        File encoded=reviewFixture(runner,folder,"ANDROID-RECOVERY-FIXTURE.mp4");
        File master=File.createTempFile("native-recovery-master-",".mp4",target.getCacheDir());
        try(InputStream in=runner.getContext().getAssets().open("framing_fixture.mp4");OutputStream out=new FileOutputStream(master)){copy(in,out);}
        Uri source=Uri.fromFile(master),injectedReceipt=Uri.parse("content://media/external_primary/video/media/9223372036854770000");
        String sourceHash=hash(master),encodedHash=hash(encoded);List<String> owned=new ArrayList<>();List<Uri> grants=new ArrayList<>();
        android.content.SharedPreferences gallery=target.getSharedPreferences("duwm1726_gallery_exports",Context.MODE_PRIVATE);
        android.content.SharedPreferences shortcuts=target.getSharedPreferences("duwm1728_saved_broadcasts",Context.MODE_PRIVATE);
        Map<String,?> galleryBefore=new HashMap<>(gallery.getAll()),shortcutsBefore=new HashMap<>(shortcuts.getAll());
        try{
            Duwm1728ExportRecovery.Entry pending=recoveryStorage(runner,folder,encoded,source,injectedReceipt,encodedHash,owned,grants);
            phase("recovery.storage.complete");
            recoveryUi(runner,folder,master,pending,injectedReceipt);
            check(sourceHash.equals(hash(master)),"Recovery, review and retry leave the clean original source unchanged");
            phase("recovery.discard_owned_copies");
            for(String id:owned){Duwm1728ExportRecovery.discard(target,id);check(Duwm1728ExportRecovery.find(target,id)==null,"Explicit discard removes only its owned recovery record");}
            boolean unavailable=false;try(InputStream ignored=target.getContentResolver().openInputStream(pending.uri)){}catch(FileNotFoundException expected){unavailable=true;}
            check(unavailable,"Discarded local content URI no longer exposes a completed MP4");
        }finally{
            for(Uri uri:grants)try{target.revokeUriPermission(uri,android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(RuntimeException ignored){}
            for(String id:owned)try{Duwm1728ExportRecovery.discard(target,id);}catch(Exception cleanup){android.util.Log.w("DUWM-NATIVE","Test-owned recovery cleanup failed",cleanup);}
            restorePreferences(gallery,galleryBefore);restorePreferences(shortcuts,shortcutsBefore);master.delete();
        }
    }
    private static void restorePreferences(android.content.SharedPreferences preferences,Map<String,?> before)throws IOException{
        android.content.SharedPreferences.Editor edit=preferences.edit().clear();
        for(Map.Entry<String,?> entry:before.entrySet()){
            Object value=entry.getValue();String key=entry.getKey();
            if(value instanceof String)edit.putString(key,(String)value);
            else if(value instanceof Boolean)edit.putBoolean(key,(Boolean)value);
            else if(value instanceof Integer)edit.putInt(key,(Integer)value);
            else if(value instanceof Long)edit.putLong(key,(Long)value);
            else if(value instanceof Float)edit.putFloat(key,(Float)value);
            else if(value instanceof Set){Set<String> strings=new HashSet<>();for(Object item:(Set<?>)value)strings.add((String)item);edit.putStringSet(key,strings);}
            else throw new IOException("Unsupported preference snapshot value");
        }
        if(!edit.commit())throw new IOException("Could not restore test preference snapshot");
    }
    private Duwm1728ExportRecovery.Entry retainRecovery(Context target,File encoded,Uri source,String suffix,List<String> owned)throws Exception{
        File temporary=File.createTempFile("native-recovery-result-",".mp4",target.getCacheDir());
        try{
            try(InputStream in=new FileInputStream(encoded);OutputStream out=new FileOutputStream(temporary)){copy(in,out);}
            Duwm1728ExportRecovery.Entry entry=Duwm1728ExportRecovery.retain(target,temporary,source,"DUWM_NATIVE_RECOVERY_"+suffix+"_"+System.currentTimeMillis()+".mp4");
            owned.add(entry.id);return entry;
        }finally{temporary.delete();}
    }
    private String uriHash(Context target,Uri uri)throws Exception{
        java.security.MessageDigest digest=java.security.MessageDigest.getInstance("SHA-256");
        try(InputStream in=target.getContentResolver().openInputStream(uri)){
            check(in!=null,"Retained content URI opens a real stream");byte[] buffer=new byte[65536];int n;while((n=in.read(buffer))!=-1)digest.update(buffer,0,n);
        }
        StringBuilder value=new StringBuilder();for(byte b:digest.digest())value.append(String.format(Locale.ROOT,"%02x",b&255));return value.toString();
    }
    private void recoveryProvider(Instrumentation runner,Duwm1728ExportRecovery.Entry entry,File encoded,String digest,List<Uri> grants)throws Exception{
        Context target=runner.getTargetContext();android.content.ContentResolver resolver=target.getContentResolver();
        check(entry.hasLocalCopy&&entry.bytes==encoded.length()&&digest.equals(entry.sha256),"Retained metadata describes the exact completed encoded fixture");
        check("content".equals(entry.uri.getScheme())&&Duwm1728ExportRecovery.isRecoveryUri(target,entry.uri),"Retained video has a scoped local content URI");
        check("video/mp4".equals(resolver.getType(entry.uri)),"Local provider advertises MP4 MIME type");
        check(digest.equals(uriHash(target,entry.uri)),"ContentResolver reads every retained MP4 byte unchanged");
        try(android.database.Cursor row=resolver.query(entry.uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME,android.provider.OpenableColumns.SIZE},null,null,null)){
            check(row!=null&&row.moveToFirst(),"Local provider exposes openable-file metadata");
            check(entry.name.equals(row.getString(0))&&row.getLong(1)==encoded.length(),"Local provider name and length match the retained file");
        }
        boolean denied=false;try(android.os.ParcelFileDescriptor ignored=resolver.openFileDescriptor(entry.uri,"rw")){}catch(FileNotFoundException|SecurityException expected){denied=true;}
        check(denied,"Local video content URI rejects write access");
        denied=false;try{resolver.delete(entry.uri,null,null);}catch(UnsupportedOperationException|SecurityException expected){denied=true;}
        check(denied&&digest.equals(uriHash(target,entry.uri)),"Provider clients cannot delete or change the retained MP4");
        denied=false;try(InputStream ignored=resolver.openInputStream(entry.uri.buildUpon().appendPath("outside").build())){}catch(FileNotFoundException|IllegalArgumentException|SecurityException expected){denied=true;}
        check(denied,"Local provider rejects additional path segments");
        android.content.pm.ProviderInfo provider=target.getPackageManager().resolveContentProvider(entry.uri.getAuthority(),0);
        check(provider!=null&&!provider.exported&&provider.grantUriPermissions,"Local provider is private and supports temporary URI grants");
        int receiverUid=target.getPackageManager().getApplicationInfo(runner.getContext().getPackageName(),0).uid;
        check(receiverUid!=target.getApplicationInfo().uid,"Read-grant recipient is the separate instrumentation package UID");
        target.grantUriPermission(runner.getContext().getPackageName(),entry.uri,android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);grants.add(entry.uri);
        check(target.checkUriPermission(entry.uri,-1,receiverUid,android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)==android.content.pm.PackageManager.PERMISSION_GRANTED,"Temporary read grant is recorded for the recipient UID");
        check(target.checkUriPermission(entry.uri,-1,receiverUid,android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION)==android.content.pm.PackageManager.PERMISSION_DENIED,"Read grant does not grant write permission");
        android.content.Intent share=Duwm1728BroadcastReviewActivity.shareIntent(entry.uri);
        check(android.content.Intent.ACTION_SEND.equals(share.getAction())&&"video/mp4".equals(share.getType())&&entry.uri.equals(share.getParcelableExtra(android.content.Intent.EXTRA_STREAM)),"Retained-copy share targets the actual local MP4");
        check(share.getClipData()!=null&&entry.uri.equals(share.getClipData().getItemAt(0).getUri())&&(share.getFlags()&android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)!=0,"Retained-copy share carries matching ClipData and read access");
        MediaMetadataRetriever reader=new MediaMetadataRetriever();
        try{reader.setDataSource(target,entry.uri);
            check("960".equals(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH))&&"540".equals(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)),"Native metadata reader opens the retained encoded dimensions");
            check("yes".equals(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)),"Retained copy contains the actual encoded soundtrack");
            check(Math.abs(Long.parseLong(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION))-1500)<180,"Retained copy preserves encoded duration");
        }finally{reader.release();}
    }
    private Duwm1728ExportRecovery.Entry recoveryStorage(Instrumentation runner,File folder,File encoded,Uri source,Uri receipt,String digest,List<String> owned,List<Uri> grants)throws Exception{
        Context target=runner.getTargetContext();phase("recovery.retain");int before=passed;
        Duwm1728ExportRecovery.Entry entry=retainRecovery(target,encoded,source,"STORE",owned);final String id=entry.id;
        check(entry.state==Duwm1728ExportRecovery.State.READY&&entry.publishedUri==null,"Newly retained output is READY and is not reported as a Gallery save");
        check(source.equals(entry.sourceUri),"Retained output remains associated with its clean source");
        recoveryProvider(runner,entry,encoded,digest,grants);
        String key=Duwm1728CaptureTelemetry.storageKey(source);
        android.content.SharedPreferences shortcuts=target.getSharedPreferences("duwm1728_saved_broadcasts",Context.MODE_PRIVATE);
        String prior=new org.json.JSONObject().put("uri","content://media/external_primary/video/media/9223372036854769999").put("name","DUWM_NATIVE_SEEDED_PRIOR.mp4").put("saved_at",1).toString();
        check(shortcuts.edit().putString(key,prior).commit(),"Seed a test-only prior shortcut to check that failure cannot overwrite it");
        phase("recovery.definite_failure");java.util.concurrent.atomic.AtomicInteger definiteCalls=new java.util.concurrent.atomic.AtomicInteger();
        boolean failed=false;try{Duwm1728ExportRecovery.publish(target,id,(app,file,name)->{definiteCalls.incrementAndGet();throw new Duwm1728ExportRecovery.DefinitePublishFailure("INJECTED: Gallery unavailable before publication");});}
        catch(Duwm1728ExportRecovery.DefinitePublishFailure expected){failed=true;}
        check(failed&&definiteCalls.get()==1,"Definite Gallery failure is reported without false publication success");
        entry=Duwm1728ExportRecovery.find(target,id);
        check(entry!=null&&entry.state==Duwm1728ExportRecovery.State.READY&&entry.hasLocalCopy&&!entry.lastError.isEmpty()&&entry.publishedUri==null,"Known failed publication persists a retryable local copy and error");
        check(digest.equals(uriHash(target,entry.uri)),"Gallery failure retains the exact completed MP4");
        check(prior.equals(shortcuts.getString(key,"")),"Fixture-seeded prior LAST EXPORT stays unchanged after a failed save");
        Duwm1728ExportRecovery.Entry reopened=null;for(Duwm1728ExportRecovery.Entry item:Duwm1728ExportRecovery.list(target))if(item.id.equals(id))reopened=item;
        check(reopened!=null&&reopened.state==Duwm1728ExportRecovery.State.READY&&digest.equals(reopened.sha256),"Catalog reload restores the pending record from durable storage");
        phase("recovery.interruption");recoveryInterruption(target,id,receipt);
        entry=Duwm1728ExportRecovery.find(target,id);
        check(entry!=null&&entry.state==Duwm1728ExportRecovery.State.UNCONFIRMED&&entry.hasLocalCopy,"An interrupted in-flight save is persisted as unconfirmed with local bytes retained");
        check(digest.equals(uriHash(target,entry.uri)),"Interrupted publication leaves encoded bytes intact");
        java.util.concurrent.atomic.AtomicInteger automaticCalls=new java.util.concurrent.atomic.AtomicInteger();failed=false;
        try{Duwm1728ExportRecovery.publish(target,id,(app,file,name)->{automaticCalls.incrementAndGet();return receipt;});}catch(Duwm1728ExportRecovery.UnconfirmedException expected){failed=true;}
        check(failed&&automaticCalls.get()==0,"Unconfirmed save cannot retry silently or invoke another Gallery gateway");
        check(prior.equals(shortcuts.getString(key,"")),"Fixture-seeded LAST EXPORT also stays unchanged after interruption");
        failed=false;try{Duwm1728ExportRecovery.retryAfterUnconfirmed(target,id,(app,file,name)->{throw new Duwm1728ExportRecovery.DefinitePublishFailure("INJECTED: confirmed retry could not begin");});}
        catch(Duwm1728ExportRecovery.UnconfirmedException expected){failed=true;}
        check(failed&&Duwm1728ExportRecovery.find(target,id).state==Duwm1728ExportRecovery.State.UNCONFIRMED,"A definite failure on a later retry cannot erase the earlier unconfirmed save");
        failed=false;try{Duwm1728ExportRecovery.publish(target,id,(app,file,name)->{automaticCalls.incrementAndGet();return receipt;});}catch(Duwm1728ExportRecovery.UnconfirmedException expected){failed=true;}
        check(failed&&automaticCalls.get()==0,"Failed explicit retry still requires confirmation before another publication");
        phase("recovery.retry_concurrent");int successCalls=recoveryConcurrentRetry(target,id,receipt,digest);
        entry=Duwm1728ExportRecovery.find(target,id);
        check(entry!=null&&entry.state==Duwm1728ExportRecovery.State.PUBLISHED&&receipt.equals(entry.publishedUri),"Injected gateway success is committed as an idempotent receipt");
        check(!entry.hasLocalCopy,"Private encoded copy is cleaned only after a durable successful receipt");
        java.util.concurrent.atomic.AtomicInteger duplicateCalls=new java.util.concurrent.atomic.AtomicInteger();
        Uri repeated=Duwm1728ExportRecovery.publish(target,id,(app,file,name)->{duplicateCalls.incrementAndGet();throw new IOException("Duplicate gateway must not run");});
        check(receipt.equals(repeated)&&duplicateCalls.get()==0,"Repeated confirmed publish returns its original receipt without a second copy or render");
        check(receipt.toString().equals(new org.json.JSONObject(shortcuts.getString(key,"{}")).getString("uri")),"Injected successful receipt updates only the confirmed shortcut slot");
        phase("recovery.pending_ui_fixture");Duwm1728ExportRecovery.Entry pending=retainRecovery(target,encoded,source,"UI",owned);
        failed=false;try{Duwm1728ExportRecovery.publish(target,pending.id,(app,file,name)->{throw new Duwm1728ExportRecovery.DefinitePublishFailure("INJECTED: Gallery unavailable; local review remains possible");});}catch(Duwm1728ExportRecovery.DefinitePublishFailure expected){failed=true;}
        check(failed&&digest.equals(uriHash(target,pending.uri)),"Independent pending UI fixture retains the actual encoded video after a failed save");
        org.json.JSONObject report=new org.json.JSONObject().put("schema",1).put("status","PASS").put("run_id",proof.runId())
            .put("scope","Synthetic native recovery fixture; publication failures and successful receipt are injected")
            .put("real_gallery_integration_pass",false).put("fixture_seeded_last_export",true).put("fixture_bytes",encoded.length()).put("fixture_sha256",digest)
            .put("private_provider_read_metadata_grants",true).put("known_failure_state","READY").put("interrupted_state","UNCONFIRMED")
            .put("explicit_retry_gateway_calls",successCalls).put("concurrent_duplicate_rejected",true).put("idempotent_gateway_calls",duplicateCalls.get())
            .put("injected_receipt",receipt.toString()).put("storage_assertions",passed-before)
            .put("ui_verified",false).put("note","This storage record does not pass the recovery stage; actual editor, recovery list and private-URI playback checks follow.");
        try(FileOutputStream out=new FileOutputStream(new File(folder,"RECOVERY-STORAGE.json"))){out.write((report.toString(2)+"\n").getBytes("UTF-8"));out.getFD().sync();}
        return Duwm1728ExportRecovery.find(target,pending.id);
    }
    private void recoveryInterruption(Context target,String id,Uri receipt)throws Exception{
        java.util.concurrent.CountDownLatch entered=new java.util.concurrent.CountDownLatch(1),release=new java.util.concurrent.CountDownLatch(1);
        java.util.concurrent.atomic.AtomicReference<Throwable> failure=new java.util.concurrent.atomic.AtomicReference<>();
        Thread worker=new Thread(()->{try{Duwm1728ExportRecovery.publish(target,id,(app,file,name)->{entered.countDown();release.await();return receipt;});}
            catch(Throwable error){failure.set(error);}},"native-recovery-interrupted-gateway");worker.start();
        try{
            check(entered.await(15,java.util.concurrent.TimeUnit.SECONDS),"Interrupted-save fixture reaches the real publication state");
            worker.interrupt();worker.join(15000);
            check(!worker.isAlive()&&failure.get() instanceof Duwm1728ExportRecovery.UnconfirmedException,"Interrupted gateway terminates with an explicit unconfirmed result");
        }finally{worker.interrupt();release.countDown();worker.join(15000);}
    }
    private int recoveryConcurrentRetry(Context target,String id,Uri receipt,String digest)throws Exception{
        java.util.concurrent.CountDownLatch entered=new java.util.concurrent.CountDownLatch(1),release=new java.util.concurrent.CountDownLatch(1);
        java.util.concurrent.atomic.AtomicInteger calls=new java.util.concurrent.atomic.AtomicInteger(),duplicates=new java.util.concurrent.atomic.AtomicInteger();
        java.util.concurrent.atomic.AtomicReference<Throwable> failure=new java.util.concurrent.atomic.AtomicReference<>();
        java.util.concurrent.atomic.AtomicReference<Uri> result=new java.util.concurrent.atomic.AtomicReference<>();
        Thread worker=new Thread(()->{try{result.set(Duwm1728ExportRecovery.retryAfterUnconfirmed(target,id,(app,file,name)->{
            calls.incrementAndGet();if(!digest.equals(hash(file)))throw new AssertionError("Retry passed different bytes to Gallery");entered.countDown();release.await();return receipt;
        }));}catch(Throwable error){failure.set(error);}},"native-recovery-confirmed-retry");worker.start();
        try{
            check(entered.await(15,java.util.concurrent.TimeUnit.SECONDS),"Explicit retry reaches the gateway with the original retained encoded bytes");
            check(Duwm1728ExportRecovery.find(target,id).state==Duwm1728ExportRecovery.State.PUBLISHING,"Active retry is durably marked as publishing");
            boolean busy=false;try{Duwm1728ExportRecovery.publish(target,id,(app,file,name)->{duplicates.incrementAndGet();return receipt;});}catch(Duwm1728ExportRecovery.BusyException expected){busy=true;}
            check(busy&&duplicates.get()==0,"Concurrent retry cannot invoke a second Gallery publication");
            busy=false;try{Duwm1728ExportRecovery.discard(target,id);}catch(Duwm1728ExportRecovery.BusyException expected){busy=true;}
            check(busy,"A copy cannot be discarded while its publication is active");
            release.countDown();worker.join(15000);
            check(!worker.isAlive()&&failure.get()==null&&receipt.equals(result.get())&&calls.get()==1,"Explicit retry finishes exactly once and clears the interrupted attempt's busy state");
            return calls.get();
        }finally{release.countDown();if(worker.isAlive())worker.interrupt();worker.join(15000);}
    }
    private void awaitTaggedText(Instrumentation runner,android.app.Activity activity,String tag,String wanted)throws Exception{
        java.util.concurrent.atomic.AtomicReference<String> actual=new java.util.concurrent.atomic.AtomicReference<>("");long deadline=android.os.SystemClock.elapsedRealtime()+15000;
        do{
            ui(runner,()->{android.view.View view=activity.getWindow().getDecorView().findViewWithTag(tag);actual.set(view instanceof android.widget.TextView?((android.widget.TextView)view).getText().toString():"");});
            if(actual.get().contains(wanted))return;Thread.sleep(100);
        }while(android.os.SystemClock.elapsedRealtime()<deadline);
        check(false,"Recovery UI reaches expected state "+wanted+"; actual="+actual.get());
    }
    private android.app.Activity monitoredClick(Instrumentation runner,android.app.Activity from,String tag,Class<? extends android.app.Activity> destination)throws Exception{
        Instrumentation.ActivityMonitor monitor=runner.addMonitor(destination.getName(),null,false);
        try{click(runner,from,tag);android.app.Activity activity=runner.waitForMonitorWithTimeout(monitor,15000);check(activity!=null,"Native action opens "+destination.getSimpleName());return activity;}
        finally{runner.removeMonitor(monitor);}
    }
    private void recoveryUi(Instrumentation runner,File folder,File master,Duwm1728ExportRecovery.Entry pending,Uri seededReceipt)throws Exception{
        Context target=runner.getTargetContext();android.app.Activity editor=null,recovery=null,review=null;
        try{
            phase("recovery.editor.reopen");
            editor=runner.startActivitySync(new android.content.Intent(target,Duwm1728VideoEditorActivity.class).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(Duwm1728VideoEditorActivity.EXTRA_VIDEO_URI,Uri.fromFile(master).toString()).putExtra("broadcast_ratio","16:9"));
            final android.app.Activity sourceEditor=editor;awaitReady(runner,sourceEditor,"prepared");
            awaitTaggedText(runner,sourceEditor,"broadcast-editor-recovery-status","LOCAL COPY • NOT IN GALLERY");
            capture(runner,folder,"ANDROID-EDITOR-RECOVERY-PENDING");
            ui(runner,()->{
                Duwm1728ExportRecovery.Entry restored=(Duwm1728ExportRecovery.Entry)field(sourceEditor,"pendingRecovery");
                check(restored!=null&&pending.id.equals(restored.id),"Reopened editor restores the pending copy for its original source");
                check(seededReceipt.equals(field(sourceEditor,"lastBroadcast")),"Fixture-seeded LAST EXPORT remains separate from the pending local copy");
                check(tagged(sourceEditor,"broadcast-editor-review-copy").isEnabled(),"Editor offers local review while Gallery is unavailable");
            });
            recovery=monitoredClick(runner,sourceEditor,"broadcast-editor-recovery",Duwm1728ExportRecoveryActivity.class);
            ui(runner,sourceEditor::finish);runner.waitForIdleSync();editor=null;
            final android.app.Activity readyScreen=recovery;phase("recovery.ui.ready");
            awaitTaggedText(runner,readyScreen,"recovery-state-"+pending.id,"LOCAL COPY • NOT IN GALLERY");
            capture(runner,folder,"ANDROID-EXPORT-RECOVERY");
            ui(runner,()->{
                check(tagged(readyScreen,"recovery-review-"+pending.id).isEnabled()&&tagged(readyScreen,"recovery-share-"+pending.id).isEnabled(),"Pending recovery copy can be reviewed and shared without Gallery");
                android.widget.TextView save=(android.widget.TextView)tagged(readyScreen,"recovery-save-"+pending.id);
                check(save.isEnabled()&&"SAVE TO GALLERY".contentEquals(save.getText()),"Known failed save remains explicitly retryable");
            });
            phase("recovery.ui.local_playback");review=monitoredClick(runner,readyScreen,"recovery-review-"+pending.id,Duwm1728BroadcastReviewActivity.class);
            final android.app.Activity localPlayer=review;awaitReady(runner,localPlayer,"ready");
            check(pending.uri.equals(localPlayer.getIntent().getData()),"REVIEW COPY opens the real retained content URI, never the seeded Gallery shortcut");
            ui(runner,()->check(((android.widget.TextView)tagged(localPlayer,"broadcast-review-metadata")).getText().toString().contains("LOCAL RECOVERY COPY"),"Private playback is visibly identified as a local recovery copy"));
            click(runner,localPlayer,"broadcast-review-play");long deadline=android.os.SystemClock.elapsedRealtime()+5000;
            while(reviewPosition(runner,localPlayer)<200&&android.os.SystemClock.elapsedRealtime()<deadline)Thread.sleep(100);
            check(reviewPosition(runner,localPlayer)>=200,"Native player advances the retained MP4 through its private provider");
            if(reviewPlaying(runner,localPlayer))click(runner,localPlayer,"broadcast-review-play");
            int[] origin=new int[2],size=new int[2];
            ui(runner,()->{android.widget.VideoView video=(android.widget.VideoView)tagged(localPlayer,"broadcast-review-video");video.getLocationOnScreen(origin);size[0]=video.getWidth();size[1]=video.getHeight();});
            runner.waitForIdleSync();Bitmap screen=runner.getUiAutomation().takeScreenshot();check(screen!=null,"Capture actual retained-MP4 playback surface");
            try{
                try(FileOutputStream out=new FileOutputStream(new File(folder,"ANDROID-RECOVERY-LOCAL-REVIEW.png"))){check(screen.compress(Bitmap.CompressFormat.PNG,100,out),"Save local recovery playback proof");}
                proof.assertUnobstructed("ANDROID-RECOVERY-LOCAL-REVIEW");
                check(size[0]>64&&size[1]>64&&Math.abs(size[0]/(float)size[1]-16f/9f)<.03f,"Retained playback fits the actual encoded aspect ratio");
                screenColour(screen,origin,size[0],size[1],.10f,.45f,0xFFC91010,"Retained playback displays the encoded left source marker");
                screenColour(screen,origin,size[0],size[1],.90f,.50f,0xFF1043D0,"Retained playback displays the encoded right source marker");
            }finally{screen.recycle();}
            ui(runner,localPlayer::finish);runner.waitForIdleSync();review=null;
            ui(runner,readyScreen::finish);runner.waitForIdleSync();recovery=null;
            phase("recovery.ui.unconfirmed_reopen");boolean unconfirmed=false;
            try{Duwm1728ExportRecovery.publish(target,pending.id,(app,file,name)->{throw new IOException("INJECTED: previous publication result unknown");});}
            catch(Duwm1728ExportRecovery.UnconfirmedException expected){unconfirmed=true;}
            check(unconfirmed,"UI fixture enters a real persisted unconfirmed state after an ambiguous gateway result");
            Duwm1728ExportRecovery.Entry before=Duwm1728ExportRecovery.find(target,pending.id);
            recovery=runner.startActivitySync(Duwm1728ExportRecoveryActivity.intent(target,pending.id).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK));
            final android.app.Activity ambiguous=recovery;
            awaitTaggedText(runner,ambiguous,"recovery-state-"+pending.id,"SAVE UNCONFIRMED • CHECK GALLERY");
            capture(runner,folder,"ANDROID-EXPORT-RECOVERY-UNCONFIRMED");
            ui(runner,()->check("CHECK SAVE".contentEquals(((android.widget.TextView)tagged(ambiguous,"recovery-save-"+pending.id)).getText()),"Unconfirmed recovery exposes confirmation, not an automatic retry"));
            click(runner,ambiguous,"recovery-save-"+pending.id);capture(runner,folder,"ANDROID-EXPORT-RECOVERY-CONFIRM");
            cancelRecoveryConfirmation(runner);
            Duwm1728ExportRecovery.Entry after=Duwm1728ExportRecovery.find(target,pending.id);
            check(after.state==Duwm1728ExportRecovery.State.UNCONFIRMED&&before.lastError.equals(after.lastError)&&after.hasLocalCopy,"Cancelling the retry confirmation leaves the uncertain save and local bytes unchanged");
        }finally{
            if(review!=null){final android.app.Activity closing=review;ui(runner,closing::finish);runner.waitForIdleSync();}
            if(recovery!=null){final android.app.Activity closing=recovery;ui(runner,closing::finish);runner.waitForIdleSync();}
            if(editor!=null){final android.app.Activity closing=editor;ui(runner,closing::finish);runner.waitForIdleSync();}
        }
    }
    private void cancelRecoveryConfirmation(Instrumentation runner)throws Exception{
        android.view.accessibility.AccessibilityNodeInfo root=runner.getUiAutomation().getRootInActiveWindow();check(root!=null,"Recovery retry confirmation is an actual accessible dialog");
        try{
            List<android.view.accessibility.AccessibilityNodeInfo> titles=root.findAccessibilityNodeInfosByText("Check Gallery before retrying");
            boolean exactTitle=false;for(android.view.accessibility.AccessibilityNodeInfo node:titles){if("Check Gallery before retrying".contentEquals(node.getText()))exactTitle=true;node.recycle();}
            check(exactTitle,"Unconfirmed retry explains that an earlier Gallery copy may already exist");
            List<android.view.accessibility.AccessibilityNodeInfo> choices=root.findAccessibilityNodeInfosByText("CANCEL");boolean cancelled=false;
            for(android.view.accessibility.AccessibilityNodeInfo node:choices){if(!cancelled&&"CANCEL".contentEquals(node.getText())&&node.isClickable())cancelled=node.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK);node.recycle();}
            check(cancelled,"Explicitly cancel only the app's identified retry confirmation");
        }finally{root.recycle();}
        runner.waitForIdleSync();
    }
    /** Real Android Canvas adapter with a record of issued text, for privacy/hidden-row assertions. */
    private static final class CompositionCanvas implements Duwm1728BroadcastLayout.Painter {
        private final Duwm1728BroadcastCanvas canvas;final ArrayList<String> text=new ArrayList<>();final ArrayList<Integer> fills=new ArrayList<>();
        CompositionCanvas(Bitmap frame){canvas=new Duwm1728BroadcastCanvas(new Canvas(frame));}
        public void rect(float x,float y,float w,float h,int color,float radius){fills.add(color);canvas.rect(x,y,w,h,color,radius);}
        public void line(float x,float y,float x2,float y2,int color,float width){canvas.line(x,y,x2,y2,color,width);}
        public void text(String value,float x,float y,float size,int color,boolean bold){text.add(value);canvas.text(value,x,y,size,color,bold);}
        public float measure(String value,float size,boolean bold){return canvas.measure(value,size,bold);}
        public void clip(float x,float y,float w,float h){canvas.clip(x,y,w,h);}
        public void unclip(){canvas.unclip();}
        boolean contains(String token){for(String value:text)if(value.contains(token))return true;return false;}
    }
    private Duwm1728BroadcastLayout.Report compositionReport(String mode){
        Duwm1728BroadcastLayout.Report report=new Duwm1728BroadcastLayout.Report();report.composition=mode;
        report.title="HEADLINE TOKEN";report.location="BYLINE TOKEN";report.category="WEATHER";
        report.provenance="TEST FIXTURE • UNVERIFIED";report.clock="RECORDED • TEST";
        report.heading="HEADING TOKEN";report.altitude="HEIGHT TOKEN";report.weather="WEATHER TOKEN";
        report.gps="PRIVATE TOKEN";report.coordinatesAllowed=false;
        report.tickers.add(new Duwm1728BroadcastLayout.Cue(0,1500,"TICKER TOKEN • Synthetic native fixture"));
        report.captions.add(new Duwm1728BroadcastLayout.Cue(500,950,"CAPTION ONE"));
        report.captions.add(new Duwm1728BroadcastLayout.Cue(1100,1400,"CAPTION TWO"));return report;
    }
    private void nativePng(Bitmap bitmap,File folder,String name)throws Exception{
        try(FileOutputStream out=new FileOutputStream(new File(folder,name+".png"))){check(bitmap.compress(Bitmap.CompressFormat.PNG,100,out),"Write "+name);}
    }
    private void compositionCanvas(File folder)throws Exception{
        String[] modes={"FULL","COMPACT","CAPTIONS"};
        for(int[] size:new int[][]{{720,800},{720,1280},{1280,720}}){
            float fullHeight=0,compactHeight=0;
            for(String mode:modes){
                phase("composition.canvas."+mode+"."+size[0]+"x"+size[1]);
                Bitmap frame=Bitmap.createBitmap(size[0],size[1],Bitmap.Config.ARGB_8888);frame.eraseColor(0xFF17202B);
                try{
                    CompositionCanvas painter=new CompositionCanvas(frame);Duwm1728BroadcastLayout.Report report=compositionReport(mode);
                    Duwm1728BroadcastLayout.Geometry g=Duwm1728BroadcastLayout.draw(painter,size[0],size[1],report,700);
                    nativePng(frame,folder,"NATIVE-COMPOSITION-"+mode+"-"+size[0]+"x"+size[1]);
                    boolean hidden="CAPTIONS".equals(mode);check(mode.equals(g.composition),"Native draw receives selected composition");
                    check(g.headlineVisible==!hidden&&g.tickerVisible==!hidden&&g.telemetryVisible==!hidden,"Native geometry follows selected visibility");
                    check(painter.contains("HEADLINE TOKEN")==!hidden&&painter.contains("BYLINE TOKEN")==!hidden&&painter.contains("TICKER TOKEN")==!hidden&&painter.contains("HDG")==!hidden,"Native hidden rows are not issued to Canvas");
                    check(painter.contains("DUWM")&&painter.contains("RECORDED")&&painter.contains("WEATHER")&&painter.contains("TEST FIXTURE"),"Native identity, recorded status, category and provenance remain");
                    check(!painter.contains("PRIVATE TOKEN")&&!painter.contains("GPS"),"Native composition withholds private coordinates");
                    check(g.captionVisible&&painter.contains("CAPTION ONE")&&!painter.contains("CAPTION TWO"),"Native currently active subtitle only");
                    check(g.captionTop>g.headerBottom&&g.captionBottom<g.tagTop&&g.captionLeft>=g.x&&g.captionLeft+g.captionWidth<=g.x+g.width+.01f,"Native captions avoid identity and lower graphics");
                    Duwm1728FramePlan.Inset inset=Duwm1728FramePlan.inset(size[0],size[1],9,16);
                    check(g.captionTop>inset.top+inset.height+inset.border,"Native caption clears portrait PiP placement");
                    check(frame.getPixel((int)(g.x+3*g.unit),(int)(g.headerTop+12*g.unit))==0xFF00ACC1,"Native WEATHER accent is cyan");
                    check(!painter.fills.contains(Duwm1728BroadcastLayout.RED),"Native unapproved report has no red badge or ticker");
                    if("FULL".equals(mode))fullHeight=g.bottom-g.tagTop;
                    if("COMPACT".equals(mode))compactHeight=g.bottom-g.tagTop;
                    if(hidden)check(g.headlineHeight==0&&g.tickerHeight==0&&g.telemetryHeight==0,"CAPTIONS creates no hidden strip area");
                }finally{frame.recycle();}
            }
            check(compactHeight<fullHeight*.70f,"Native COMPACT reclaims at least thirty percent of full lower strip");
        }
        phase("composition.category_privacy_and_cues");
        String[] categories={"WEATHER","TRAFFIC","ENVIRONMENT","INTERVIEW","GENERAL REPORT","BREAKING NEWS"};
        int[] colors={0xFF00ACC1,0xFFFFA000,0xFF00C853,0xFFB39DDB,0xFFDEE5EF,0xFFDEE5EF};
        for(String mode:modes){
            for(int i=0;i<categories.length;i++){
                Duwm1728BroadcastLayout.Report r=compositionReport(mode);r.category=categories[i];
                Bitmap frame=Bitmap.createBitmap(960,540,Bitmap.Config.ARGB_8888);
                try{CompositionCanvas painter=new CompositionCanvas(frame);Duwm1728BroadcastLayout.Geometry g=Duwm1728BroadcastLayout.draw(painter,960,540,r,700);
                    check(frame.getPixel((int)(g.x+3*g.unit),(int)(g.headerTop+12*g.unit))==colors[i],"Actual native category accent "+mode+" "+categories[i]);
                    check(!painter.contains("BREAKING NEWS")&&!painter.fills.contains(Duwm1728BroadcastLayout.RED),"No unapproved breaking semantics in native category graphics");
                    r.breakingApproved=true;painter=new CompositionCanvas(frame);g=Duwm1728BroadcastLayout.draw(painter,960,540,r,700);
                    check(painter.contains("BREAKING NEWS")&&frame.getPixel((int)(g.x+8*g.unit),(int)(g.tagTop+7*g.unit))==0xFFD50000,"Explicit breaking approval retains native red badge");
                }finally{frame.recycle();}
            }
            for(long ms:new long[]{499,500,949,950,1099,1100,1399,1400}){
                Bitmap frame=Bitmap.createBitmap(960,540,Bitmap.Config.ARGB_8888);
                try{CompositionCanvas painter=new CompositionCanvas(frame);Duwm1728BroadcastLayout.Geometry g=Duwm1728BroadcastLayout.draw(painter,960,540,compositionReport(mode),ms);
                    boolean first=ms>=500&&ms<950,second=ms>=1100&&ms<1400;
                    check(g.captionVisible==(first||second)&&painter.contains("CAPTION ONE")==first&&painter.contains("CAPTION TWO")==second,"Native exact subtitle boundary "+mode+" "+ms);
                }finally{frame.recycle();}
            }
            Duwm1728BroadcastLayout.Report r=compositionReport(mode);r.coordinatesAllowed=true;
            Bitmap frame=Bitmap.createBitmap(960,540,Bitmap.Config.ARGB_8888);
            try{CompositionCanvas painter=new CompositionCanvas(frame);Duwm1728BroadcastLayout.draw(painter,960,540,r,700);
                check(painter.contains("PRIVATE TOKEN")==!"CAPTIONS".equals(mode),"Native explicit coordinate consent still follows sensor visibility");
            }finally{frame.recycle();}
        }
    }
    void compositions(Instrumentation runner,File folder)throws Exception{
        compositionCanvas(folder);
        File source=new File(runner.getTargetContext().getCacheDir(),"composition-source-"+System.nanoTime()+".mp4");
        try(InputStream in=runner.getContext().getAssets().open("framing_fixture.mp4");OutputStream out=new FileOutputStream(source)){copy(in,out);}
        String original=hash(source);
        try{
            compositionExport(runner,source,folder);
            compositionEditor(runner,source,folder);
            check(original.equals(hash(source)),"Composition selection and encoding leave source byte-for-byte unchanged");
            org.json.JSONObject result=new org.json.JSONObject().put("status","PASS").put("scope","SYNTHETIC_NATIVE_CANVAS_EDITOR_AND_ENCODER")
                .put("compositions",new org.json.JSONArray(Arrays.asList("FULL","COMPACT","CAPTIONS")))
                .put("encoded_composition","CAPTIONS").put("encoded_audio_mime","audio/mp4a-latm")
                .put("editor_selection_and_reopen",true).put("source_sha256",original).put("physical_camera_verified",false);
            try(FileOutputStream out=new FileOutputStream(new File(folder,"COMPOSITION-NATIVE.json"))){out.write(result.toString(2).getBytes("UTF-8"));}
            phase("composition.complete");
        }finally{source.delete();}
    }
    private void compositionExport(Instrumentation runner,File source,File folder)throws Exception{
        Duwm1728OverlayRenderer.Spec spec=new Duwm1728OverlayRenderer.Spec();spec.fromMs=0;spec.toMs=1500;
        spec.title="CAPTIONS ENCODER TEST";spec.template="WEATHER";spec.provenance="SYNTHETIC TEST • UNVERIFIED";
        spec.composition="CAPTIONS";spec.ratio="16:9";spec.frameMode="FIT";spec.ticker="00:00=This ticker must be hidden";
        spec.automaticCaptions=Arrays.asList(new Duwm1728BroadcastLayout.Cue(500,950,"CAPTION ONE"),new Duwm1728BroadcastLayout.Cue(1100,1400,"CAPTION TWO"));
        phase("composition.export.encode");File result=Duwm1728OverlayRenderer.export(runner.getTargetContext(),Uri.fromFile(source),spec);
        File output=new File(folder,"ANDROID-COMPOSITION-CAPTIONS.mp4");
        try(InputStream in=new FileInputStream(result);OutputStream out=new FileOutputStream(output)){copy(in,out);}finally{result.delete();}
        phase("composition.export.decode");MediaMetadataRetriever video=new MediaMetadataRetriever();
        Bitmap before=null,active=null,gap=null;Bitmap geometryFrame=Bitmap.createBitmap(960,540,Bitmap.Config.ARGB_8888);
        try{
            video.setDataSource(output.getAbsolutePath());check("960".equals(video.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH))&&"540".equals(video.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)),"Composition output retains exact source dimensions");
            check("yes".equalsIgnoreCase(video.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)),"Composition output retains real AAC soundtrack");
            check(Math.abs(Long.parseLong(video.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION))-1500)<180,"Composition export preserves selected duration");
            before=video.getFrameAtTime(300000,MediaMetadataRetriever.OPTION_CLOSEST);active=video.getFrameAtTime(700000,MediaMetadataRetriever.OPTION_CLOSEST);gap=video.getFrameAtTime(1000000,MediaMetadataRetriever.OPTION_CLOSEST);
            check(before!=null&&active!=null&&gap!=null,"Actual CAPTIONS MP4 frames decode");
            nativePng(active,folder,"ANDROID-COMPOSITION-DECODED-700MS");
            Duwm1728BroadcastLayout.Report report=Duwm1728OverlayRenderer.reportAt(spec,700);
            Duwm1728BroadcastLayout.Geometry g=Duwm1728BroadcastLayout.draw(new Duwm1728BroadcastCanvas(new Canvas(geometryFrame)),960,540,report,700);
            check("CAPTIONS".equals(report.composition)&&!g.headlineVisible&&!g.tickerVisible,"Actual export specification reaches CAPTIONS renderer");
            colour(active,.90f,.82f,0xFF1043D0,"Encoded picture remains visible where FULL would place the headline");
            float x=(g.captionLeft+12*g.unit)/960,y=(g.captionTop+7*g.unit)/540;
            colour(before,x,y,0xFFC91010,"Encoded caption absent before supplied start");
            colour(active,x,y,0xFF041424,"Encoded caption panel visible only during supplied cue");
            colour(gap,x,y,0xFFC91010,"Encoded caption disappears in supplied silence gap");
        }finally{if(before!=null)before.recycle();if(active!=null)active.recycle();if(gap!=null)gap.recycle();geometryFrame.recycle();video.release();}
        MediaExtractor tracks=new MediaExtractor();try{tracks.setDataSource(output.getAbsolutePath());boolean aac=false;
            for(int i=0;i<tracks.getTrackCount();i++){MediaFormat format=tracks.getTrackFormat(i);if("audio/mp4a-latm".equals(format.getString(MediaFormat.KEY_MIME))){aac=true;check(format.getInteger(MediaFormat.KEY_SAMPLE_RATE)==48000&&format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)==1,"Original fixture AAC sample rate and channels preserved");}}
            check(aac,"Inspect actual AAC track, not only a metadata presence flag");
        }finally{tracks.release();}
    }
    private void showCompositionPicker(Instrumentation runner,android.app.Activity editor)throws Exception{
        ui(runner,()->{android.view.View button=tagged(editor,"broadcast-editor-layout");button.requestRectangleOnScreen(new Rect(0,0,button.getWidth(),button.getHeight()),true);});
        runner.waitForIdleSync();click(runner,editor,"broadcast-editor-layout");runner.waitForIdleSync();
        ui(runner,()->{android.app.AlertDialog dialog=(android.app.AlertDialog)field(editor,"layoutPicker");check(dialog!=null&&dialog.isShowing(),"Real layout picker opens");
            for(String mode:new String[]{"FULL","COMPACT","CAPTIONS"}){android.view.View choice=dialog.getWindow().getDecorView().findViewWithTag("broadcast-editor-layout-"+mode);
                check(choice!=null&&choice.isEnabled(),"Real picker offers "+mode);android.view.View thumbnail=dialog.getWindow().getDecorView().findViewWithTag("broadcast-editor-layout-preview-"+mode);
                check(thumbnail!=null,"Real picker contains current-report production thumbnail "+mode);}
        });
    }
    private void chooseComposition(Instrumentation runner,android.app.Activity editor,String mode)throws Exception{
        ui(runner,()->{android.app.AlertDialog dialog=(android.app.AlertDialog)field(editor,"layoutPicker");check(dialog!=null&&dialog.isShowing(),"Picker remains open before selection");
            android.view.View choice=dialog.getWindow().getDecorView().findViewWithTag("broadcast-editor-layout-"+mode);check(choice!=null&&choice.isEnabled(),"Requested real layout choice enabled");
            choice.requestRectangleOnScreen(new Rect(0,0,choice.getWidth(),choice.getHeight()),true);
            check(choice.isShown()&&choice.getGlobalVisibleRect(new Rect()),"Requested layout is reachable in the scrolling picker");
            check(choice.performClick(),"Real picker handles "+mode+" selection");
        });runner.waitForIdleSync();
    }
    private void compositionEditor(Instrumentation runner,File source,File folder)throws Exception{
        android.app.Activity editor=null;
        try{
            phase("composition.editor.launch");editor=openEditor(runner,source);final android.app.Activity first=editor;
            ui(runner,()->{check("FULL".equals(field(first,"selectedComposition")),"New draft uses backward-compatible FULL composition");
                ((android.widget.EditText)field(first,"title")).setText("NATIVE LAYOUT SELECTOR TEST");
                ((android.widget.EditText)field(first,"ticker")).setText("00:00=EDITOR TICKER");
                ((android.widget.EditText)field(first,"subtitles")).setText("00:00=EDITOR CAPTION");
                setField(first,"selectedTemplate",2);setField(first,"tickerOriginMs",137L);setField(first,"captionOriginMs",281L);
                java.lang.reflect.Method refresh=first.getClass().getDeclaredMethod("refresh");refresh.setAccessible(true);refresh.invoke(first);
            });
            long from=editorBound(runner,first,"from"),to=editorBound(runner,first,"to");seekEditor(runner,first,637,from,to);
            int originalPosition=editorPosition(runner,first);
            for(String mode:new String[]{"COMPACT","FULL","CAPTIONS"}){
                phase("composition.editor."+mode);ui(runner,()->((android.widget.CheckBox)field(first,"approval")).setChecked(true));
                showCompositionPicker(runner,first);
                if("COMPACT".equals(mode))capture(runner,folder,"ANDROID-EDITOR-LAYOUT-PICKER");
                chooseComposition(runner,first,mode);capture(runner,folder,"ANDROID-EDITOR-LAYOUT-"+mode);
                java.util.concurrent.atomic.AtomicReference<Duwm1728OverlayRenderer.Spec> selected=new java.util.concurrent.atomic.AtomicReference<>();
                ui(runner,()->{check(mode.equals(field(first,"selectedComposition")),"Editor applies "+mode);check(field(first,"layoutPicker")==null,"Picker dismisses after applying layout");
                    check(!((android.widget.CheckBox)field(first,"approval")).isChecked(),"Changing the output composition clears old approval");
                    Duwm1728OverlayRenderer.Spec spec=(Duwm1728OverlayRenderer.Spec)field(first,"previewSpec");selected.set(spec);
                    check(spec!=null&&mode.equals(spec.composition),"Actual current preview/export Spec contains selected layout");
                    check(spec.fromMs==from&&spec.toMs==to&&spec.tickerOriginMs==137L&&spec.captionOriginMs==281L,"Layout choice leaves source trim and cue origins intact");
                    check("FIT".equals(spec.frameMode)&&"16:9".equals(spec.ratio)&&spec.frameX==.5f&&spec.frameY==.5f,"Layout choice leaves full-picture framing intact");
                    check(((android.widget.TextView)tagged(first,"broadcast-editor-layout-summary")).getText().toString().contains(Duwm1728BroadcastComposition.label(mode)),"Visible summary names current composition");
                    check(!((MediaPlayer)field(first,"player")).isPlaying(),"Choosing a layout does not start playback");
                });
                check(Math.abs(editorPosition(runner,first)-originalPosition)<=50,"Choosing a layout preserves paused source position");
                Bitmap frame=Bitmap.createBitmap(960,540,Bitmap.Config.ARGB_8888);
                try{Duwm1728OverlayRenderer.drawOverlay(new Canvas(frame),selected.get(),700,null);nativePng(frame,folder,"NATIVE-EDITOR-SPEC-"+mode);
                    Duwm1728BroadcastLayout.Report r=Duwm1728OverlayRenderer.reportAt(selected.get(),700);
                    check(mode.equals(r.composition)&&Duwm1728BroadcastLayout.active(r.captions,700)!=null,"Actual editor Spec reaches shared renderer and preserves active cue");
                    check(Color.alpha(frame.getPixel(864,443))==("CAPTIONS".equals(mode)?0:255),"Current editor Spec changes actual native lower-strip pixels");
                }finally{frame.recycle();}
            }
            ui(runner,first::finish);runner.waitForIdleSync();editor=null;
            phase("composition.editor.reopen");editor=openEditor(runner,source);final android.app.Activity reopened=editor;
            capture(runner,folder,"ANDROID-EDITOR-LAYOUT-RESTORED");
            ui(runner,()->{check("CAPTIONS".equals(field(reopened,"selectedComposition")),"Reopened source restores its saved CAPTIONS choice");
                Duwm1728OverlayRenderer.Spec spec=(Duwm1728OverlayRenderer.Spec)field(reopened,"previewSpec");
                check(spec!=null&&"CAPTIONS".equals(spec.composition)&&spec.fromMs==from&&spec.toMs==to,"Reopened draft restores chosen output composition and source bounds");
                check(spec.tickerOriginMs==137L&&spec.captionOriginMs==281L,"Reopened layout retains exact cue source origins");
            });
        }finally{if(editor!=null){final android.app.Activity closing=editor;ui(runner,closing::finish);runner.waitForIdleSync();}}
    }
    int count(){return passed;}
    private static String hash(File file)throws Exception{java.security.MessageDigest md=java.security.MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(file)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)md.update(b,0,n);}StringBuilder value=new StringBuilder();for(byte b:md.digest())value.append(String.format(Locale.US,"%02x",b&255));return value.toString();}
}
