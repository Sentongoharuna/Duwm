#!/usr/bin/env python3
"""Negative release-gate tests. Synthetic records here are never native proof."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

import verify_native_stages as gate


class NativeStageGateTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="duwm-gate-unit-")
        self.root = Path(self.temporary.name)
        self.proof = self.root / "native-stage-proof"
        self.logs = self.root / "logs"
        self.logs.mkdir()
        self.app, self.test = self.root / "app.apk", self.root / "test.apk"
        self.app.write_bytes(b"unit-only app identity")
        self.test.write_bytes(b"unit-only test identity")
        self.run = "unit-gate-negative-tests"
        (self.root / "RETURN-CODE.txt").write_text("0\n")
        self.manifests = {}
        for stage in gate.STAGES:
            directory = self.proof / stage
            evidence = directory / "evidence"
            evidence.mkdir(parents=True)
            listed = []
            for name in gate.REQUIRED[stage]:
                data = (b"\x00\x00\x00\x18ftypmp42" + b"x" * 11000) if name.endswith(".mp4") else b"\x89PNG\r\n\x1a\nunit-only-image-record"
                path = evidence / name
                path.write_bytes(data)
                listed.append({"path": "evidence/" + name, "bytes": len(data), "sha256": gate.sha256(path)})
            manifest = {"schema": 1, "stage": stage, "status": "PASS", "run_id": self.run,
                        "application_id": "com.sentongoharuna.worldsituationroom.rb2live25",
                        "app_apk_sha256": gate.sha256(self.app), "test_apk_sha256": gate.sha256(self.test),
                        "physical_camera_verified": False, "checks": 10, "started_at_ms": 100, "finished_at_ms": 200,
                        "elapsed_ms": 100, "evidence": listed}
            self.manifests[stage] = manifest
            self.write_manifest(stage, manifest)
            (directory / "PHASES.txt").write_text(f"100 0ms DUWM_NATIVE_STAGE_PHASE stage={stage} run_id={self.run} phase=start\n")
            self.log(stage).write_text(f"INSTRUMENTATION_RESULT: stream=DUWM_NATIVE_STAGE_PASS stage={stage} run_id={self.run} checks=10\nINSTRUMENTATION_CODE: -1\n")
            (self.logs / f"RETURN-CODE-{stage}.txt").write_text("0\n")

    def tearDown(self):
        self.temporary.cleanup()

    def log(self, stage):
        return self.logs / f"INSTRUMENTATION-{stage}.txt"

    def write_manifest(self, stage, manifest):
        (self.proof / stage / "RESULT.json").write_text(json.dumps(manifest))

    def verify(self):
        return gate.verify(self.proof, self.app, self.test, self.run, logs_dir=self.logs)

    def test_complete_staged_contract(self):
        result = self.verify()
        self.assertEqual("PASS", result["status"])
        self.assertEqual(10, len(result["stages"]))
        self.assertIs(False, result["physical_camera_verified"])

    def test_complete_full_log_contract(self):
        log = self.root / "full.txt"
        log.write_text("".join(f"DUWM_NATIVE_STAGE_PASS stage={stage} run_id={self.run} checks=10\n" for stage in gate.STAGES)
                       + f"DUWM_NATIVE_BROADCAST_PASS run_id={self.run}\nINSTRUMENTATION_CODE: -1\n")
        self.assertEqual("PASS", gate.verify(self.proof, self.app, self.test, self.run, full_log=log)["status"])

    def test_missing_stage_never_passes(self):
        (self.proof / "framing" / "RESULT.json").unlink()
        with self.assertRaisesRegex(ValueError, "missing result"):
            self.verify()

    def test_previous_eight_stages_cannot_replace_recovery(self):
        (self.proof / "recovery" / "RESULT.json").unlink()
        with self.assertRaisesRegex(ValueError, "recovery: missing result"):
            self.verify()

    def test_previous_nine_stages_cannot_replace_composition(self):
        (self.proof / "composition" / "RESULT.json").unlink()
        with self.assertRaisesRegex(ValueError, "composition: missing result"):
            self.verify()

    def test_composition_canvas_success_cannot_replace_missing_encoder_or_ui_proof(self):
        for required in ("ANDROID-COMPOSITION-CAPTIONS.mp4", "ANDROID-EDITOR-LAYOUT-CAPTIONS.png", "ANDROID-EDITOR-LAYOUT-RESTORED.png"):
            with self.subTest(required=required):
                manifest = copy.deepcopy(self.manifests["composition"])
                manifest["evidence"] = [item for item in manifest["evidence"] if item["path"] != "evidence/" + required]
                self.write_manifest("composition", manifest)
                with self.assertRaisesRegex(ValueError, "composition: mandatory evidence missing"):
                    self.verify()
        self.write_manifest("composition", self.manifests["composition"])

    def test_composition_obstructed_ui_cannot_become_a_native_pass(self):
        manifest = copy.deepcopy(self.manifests["composition"])
        manifest.update(status="FAIL", failure_kind="environment_overlay", checks=100, last_phase="composition.editor")
        self.write_manifest("composition", manifest)
        with self.assertRaisesRegex(ValueError, "composition: status is FAIL"):
            self.verify()

    def test_recovery_storage_success_cannot_replace_obstructed_ui(self):
        manifest = copy.deepcopy(self.manifests["recovery"])
        manifest.update(status="FAIL", failure_kind="environment_overlay", checks=40, last_phase="recovery.ui")
        self.write_manifest("recovery", manifest)
        with self.assertRaisesRegex(ValueError, "recovery: status is FAIL"):
            self.verify()

    def test_different_run_or_either_apk_never_passes(self):
        for key in ("run_id", "app_apk_sha256", "test_apk_sha256"):
            with self.subTest(key=key):
                manifest = copy.deepcopy(self.manifests["review_controls"])
                manifest[key] = "stale-value"
                self.write_manifest("review_controls", manifest)
                with self.assertRaisesRegex(ValueError, "another"):
                    self.verify()
        self.write_manifest("review_controls", self.manifests["review_controls"])

    def test_changed_delivered_apk_never_passes(self):
        self.app.write_bytes(b"different compiled APK")
        with self.assertRaisesRegex(ValueError, "another app APK"):
            self.verify()

    def test_altered_media_never_passes(self):
        path = self.proof / "inset1" / "evidence" / "ANDROID-PIP-PORTRAIT.mp4"
        changed = bytearray(path.read_bytes())
        changed[-1] ^= 1
        path.write_bytes(changed)
        with self.assertRaisesRegex(ValueError, "digest differs"):
            self.verify()

    def test_missing_required_media_never_passes_even_if_manifest_omits_it(self):
        manifest = copy.deepcopy(self.manifests["exports4"])
        manifest["evidence"].pop()
        self.write_manifest("exports4", manifest)
        with self.assertRaisesRegex(ValueError, "mandatory evidence missing"):
            self.verify()

    def test_environment_failure_or_incomplete_stage_never_passes(self):
        for status in ("FAIL", "RUNNING"):
            with self.subTest(status=status):
                manifest = copy.deepcopy(self.manifests["framing"])
                manifest.update(status=status, failure_kind="environment_overlay")
                self.write_manifest("framing", manifest)
                with self.assertRaisesRegex(ValueError, "status is"):
                    self.verify()

    def test_failed_or_partial_instrumentation_never_passes(self):
        path = self.log("editor_controls")
        good = path.read_text()
        for broken in (good.replace("CODE: -1", "CODE: 0"),
                       good.replace("DUWM_NATIVE_STAGE_PASS", "DUWM_NATIVE_STAGE_PHASE"),
                       "DUWM_NATIVE_STAGE_FAIL stage=editor_controls failure_kind=environment_overlay\n" + good):
            with self.subTest(log=broken):
                path.write_text(broken)
                with self.assertRaises(ValueError):
                    self.verify()

    def test_full_summary_alone_never_passes(self):
        log = self.root / "full.txt"
        log.write_text(f"DUWM_NATIVE_BROADCAST_PASS run_id={self.run}\nINSTRUMENTATION_CODE: -1\n")
        with self.assertRaisesRegex(ValueError, "no explicit current-run PASS"):
            gate.verify(self.proof, self.app, self.test, self.run, full_log=log)

    def test_missing_breadcrumbs_never_passes(self):
        (self.proof / "review" / "PHASES.txt").unlink()
        with self.assertRaisesRegex(ValueError, "phase breadcrumbs"):
            self.verify()

    def test_nonzero_timeout_or_missing_wrapper_result_never_passes(self):
        path = self.logs / "RETURN-CODE-review_controls.txt"
        for code in ("1\n", "124\n", "", "0\n124\n"):
            with self.subTest(code=code):
                path.write_text(code)
                with self.assertRaisesRegex(ValueError, "wrapper did not exit"):
                    self.verify()
        path.unlink()
        with self.assertRaisesRegex(ValueError, "Missing wrapper return code"):
            self.verify()


if __name__ == "__main__":
    unittest.main(verbosity=2)
