#!/usr/bin/env python3
"""Fail-closed V1156 native aircraft inspector overlay on V1155. No fake aircraft records."""
import hashlib,pathlib,re,sys,xml.etree.ElementTree as ET
root=pathlib.Path(sys.argv[1]).resolve()
assert root.is_dir(), 'Expected inherited Android project'
app=root/'app'
pkg=app/'src/main/java/com/sentongoharuna/worldsituationroom'
source_dir=pathlib.Path(__file__).resolve().parent
main=pkg/'OperationsMainActivity.java'
globe=pkg/'OperationsGlobeView.java'
manifest=app/'src/main/AndroidManifest.xml'
settings=app/'build.gradle.kts'
assert all(p.is_file() for p in (main,globe,manifest,settings)), 'V1155 baseline missing'
# Verify the actual inherited source, not just the version number. Prevent silent overwrites.
for name in ('OperationsMainActivity.java','OperationsGlobeView.java'):
    actual=hashlib.sha256((pkg/name).read_bytes()).hexdigest()
    expected=hashlib.sha256((pathlib.Path('/mnt/data/v1155_pro')/name).read_bytes()).hexdigest() if (pathlib.Path('/mnt/data/v1155_pro')/name).exists() else None
    # Exact expected hashes embedded below and populated by the build producer.
    expected_h={'OperationsMainActivity.java':'f242403d568dd77f6bb5f8e4a16163e8326c959dd8ea81781cab06373b456d4d','OperationsGlobeView.java':'f51b801e3e9b489ee40b44c58c6d945b2223e2efc48aef897bd9e22a8fe3c3cb'}[name]
    assert actual==expected_h, f'Protected V1155 {name} source unexpectedly changed: {actual}'

for name in ('AirTrackStore.java','AircraftOperationsActivity.java'):
    target=pkg/name
    assert not target.exists(), 'Refusing to overwrite pre-existing '+name
    target.write_bytes((source_dir/name).read_bytes())

s=main.read_text()
a='''    private void navigate(String mode){Intent intent=new Intent(this,WorldSourceHubActivity.class);intent.putExtra("mode",mode);startActivity(intent);}'''
b='''    private void navigate(String mode){
        if("AIRCRAFT".equals(mode)){startActivity(new Intent(this,AircraftOperationsActivity.class));return;}
        Intent intent=new Intent(this,WorldSourceHubActivity.class);intent.putExtra("mode",mode);startActivity(intent);
    }'''
assert s.count(a)==1,'AIRCRAFT navigation anchor drift'
s=s.replace(a,b,1)
a='''                JSONArray a=payload.optJSONArray("states");if(a==null)throw new java.io.IOException("States array absent");'''
b='''                AirTrackStore.publish(payload); // Same real OpenSky snapshot powers globe and searchable register.
                JSONArray a=payload.optJSONArray("states");if(a==null)throw new java.io.IOException("States array absent");'''
assert s.count(a)==1,'OpenSky ingestion anchor drift'
s=s.replace(a,b,1)
a='''        earth.setOnObservationSelected(item->{detail.setText(item.title+"  •  "+item.detail+"  |  "+item.source+"  |  "+(item.timeMillis>0?utc(item.timeMillis)+" UTC":"TIME NOT SUPPLIED"));});'''
b='''        earth.setOnObservationSelected(item->{
            detail.setText(item.title+"  •  "+item.detail+"  |  "+item.source+"  |  "+(item.timeMillis>0?utc(item.timeMillis)+" UTC":"TIME NOT SUPPLIED")
                +(item.type==OperationsGlobeView.AIR?"  •  TAP FOR AIRCRAFT INSPECTOR":""));
            detail.setOnClickListener(v->{
                if(item.type!=OperationsGlobeView.AIR)return;
                Intent i=new Intent(this,AircraftOperationsActivity.class);
                i.putExtra("query",item.title.trim());startActivity(i);
            });
        });'''
assert s.count(a)==1,'Globe selection anchor drift'
s=s.replace(a,b,1)
a='''    @Override protected void onResume(){super.onResume();foreground=true;if(rotate)earth.resume();main.post(second);}'''
b='''    private void applyFocus(Intent intent){
        if(earth==null||intent==null||!intent.hasExtra("focus_lat")||!intent.hasExtra("focus_lon"))return;
        double lat=intent.getDoubleExtra("focus_lat",Double.NaN),lon=intent.getDoubleExtra("focus_lon",Double.NaN);
        if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)return;
        rotate=false;rotationControl.setText("ROTATION  OFF");earth.pause();earth.focusAt(lat,lon);
        detail.setText(intent.getStringExtra("focus_label")+"  |  "+String.format(Locale.US,"%.4f°, %.4f°",lat,lon));
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);applyFocus(intent);}
    @Override protected void onResume(){super.onResume();foreground=true;applyFocus(getIntent());if(rotate)earth.resume();main.post(second);}'''
assert s.count(a)==1,'Resume focus anchor drift'
s=s.replace(a,b,1)
a='''        String[][] categories={{"AIRCRAFT","AIRCRAFT"}'''
b='''        String[][] categories={{"AIRCRAFT REGISTER","AIRCRAFT"}'''
assert s.count(a)==1,'Tabs anchor drift'
s=s.replace(a,b,1)
# Reduce the chance that the new flight register is mistaken for a decorative menu.
s=s.replace('"OBSERVATION STATUS"','"OBSERVATION STATUS / LIVE RECEIPTS"',1)
main.write_text(s)

s=globe.read_text()
a='''    private int coastSegments=0;'''
b='''    private int coastSegments=0;
    private boolean focusOn=false;
    private double focusedLat,focusedLon;'''
assert s.count(a)==1,'Focus field anchor drift'
s=s.replace(a,b,1)
a='''    public int getCoastSegmentCount(){return coastSegments;}'''
b='''    public int getCoastSegmentCount(){return coastSegments;}
    public void focusAt(double lat,double lon){
        if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)return;
        focusOn=true;focusedLat=lat;focusedLon=lon;
        moving=false;yaw=Math.toRadians(lon);
        pitch=Math.max(-1.1,Math.min(1.1,Math.toRadians(lat)));
        invalidate();
    }'''
assert s.count(a)==1,'Focus method anchor drift'
s=s.replace(a,b,1)
a='''        canvas.restore();p.setShader(null);p.setColor(EDGE);p.setStyle(Paint.Style.STROKE);'''
b='''        if(focusOn){
            float[] target=project(focusedLat,focusedLon);
            if(target!=null){
                p.setShader(null);p.setStyle(Paint.Style.STROKE);p.setColor(Color.rgb(245,231,174));
                p.setStrokeWidth(dp(1.6f));canvas.drawCircle(target[0],target[1],dp(12),p);
                canvas.drawLine(target[0]-dp(18),target[1],target[0]-dp(7),target[1],p);
                canvas.drawLine(target[0]+dp(7),target[1],target[0]+dp(18),target[1],p);
                canvas.drawLine(target[0],target[1]-dp(18),target[0],target[1]-dp(7),p);
                canvas.drawLine(target[0],target[1]+dp(7),target[0],target[1]+dp(18),p);
            }
        }
        canvas.restore();p.setShader(null);p.setColor(EDGE);p.setStyle(Paint.Style.STROKE);'''
assert s.count(a)==1,'Focus draw anchor drift'
s=s.replace(a,b,1)
globe.write_text(s)

s=manifest.read_text(encoding='utf-8')
assert 'AircraftOperationsActivity' not in s,'Duplicate aircraft Activity'
anchor='</application>'
assert s.count(anchor)==1,'Missing closing application'
s=s.replace(anchor,'<activity android:name=".AircraftOperationsActivity" android:exported="false" android:screenOrientation="unspecified"/>'+anchor,1)
ET.fromstring(s)
manifest.write_text(s,encoding='utf-8')

s=settings.read_text()
assert s.count('versionCode = 1155')==1,'Expected exact V1155 versionCode'
s=s.replace('versionCode = 1155','versionCode = 1156',1)
assert 'RUNNINGBALL2-V1155-PRO-OPERATIONS' in s,'V1155 identity missing'
s=s.replace('RUNNINGBALL2-V1155-PRO-OPERATIONS','RUNNINGBALL2-V1156-AIRCRAFT-OPERATIONS',1)
assert 'com.sentongoharuna.worldsituationroom.rb2live25' in s,'Protected package changed'
settings.write_text(s)
for f in ('OperationsMainActivity.java','OperationsGlobeView.java','AirTrackStore.java','AircraftOperationsActivity.java'):
    p=pkg/f
    print('V1156 source',f,'bytes',p.stat().st_size,'sha256',hashlib.sha256(p.read_bytes()).hexdigest())
print('PASS: V1156 aircraft source store, 4-sort register, lookup, focus crosshair, unchanged legacy sources and package')
