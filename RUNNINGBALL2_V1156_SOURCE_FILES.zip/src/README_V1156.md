# DEVELOP.UGANDA / RUNNINGBALL2 V1156 — Aircraft Operations

This is a focused, source-code upgrade to the V1155 World Situation Room.

## New native implementation

- **AircraftOperationsActivity** is a searchable flight register with callsign, ICAO24, origin country, reported speed, altitude, heading, last contact and UTC source time.
- Four sort modes: latest contact, callsign, altitude, and speed.
- An expandable observation panel and **Locate observed position on Earth** that focuses the existing rotating globe without inventing flight paths.
- **AirTrackStore** preserves immutable observations received from OpenSky inside the active process. The globe and register share the actual received snapshot, without a second synthetic dataset.
- The app handles HTTP failures, stale records, missing coordinates, and provider coverage limits visibly. Zero received records is *not* interpreted as zero flights worldwide.

## Preserved components

The V1155 main screen, original command centre, wallpaper, source hub, news, USGS, NASA, ISS and DEVELOP.UGANDA branding stay in place. Only the flight navigation route, real OpenSky record caching, focus-overlay and Activity registration are changed.

## Build acceptance

- Fail closed if V1155 source hashes change unexpectedly.
- Verify the unique Android package, versionCode 1156 and presence of both new classes in compiled DEX.
- Install Pillow on CI, then test real Android globe motion by comparing cropped screenshots.
- Click the actual aircraft tab and check that the new flight register, search and sort controls are on screen.
- Only after emulator success, publish a directly installable signed APK to GitHub Releases as `RUNNINGBALL2-V1156-DEVELOP-UGANDA.apk`.

No guarantee of worldwide aircraft coverage or live records on every phone/network. Access is subject to OpenSky service availability and provider limits. This release does not add native AIS or webcam feeds.
