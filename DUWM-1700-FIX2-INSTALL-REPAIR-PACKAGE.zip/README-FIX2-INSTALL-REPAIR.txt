DUWM 1700 FIX2 - emulator installation script scope repair

Replace .github/workflows/1700_FIX2.yml in GitHub using the YAML from this package.
The source ZIP is identical to the existing approved 1700 source in GitHub.
KVM access and APK validation remain mandatory.
GitHub run is required to confirm emulator installation and app launch.
