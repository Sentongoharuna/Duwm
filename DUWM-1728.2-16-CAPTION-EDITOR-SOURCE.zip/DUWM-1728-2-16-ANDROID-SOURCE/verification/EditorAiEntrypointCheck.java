import com.sun.source.tree.*;
import com.sun.source.util.*;
import javax.tools.*;
import java.nio.file.*;
import java.util.*;

/** Verifies self-call wiring in the actual editor AST. Does not claim Android API
 * type checking. The independent Android Gradle compilation remains mandatory. */
public final class EditorAiEntrypointCheck {
    private static final Set<String> ENTRY_POINTS = Set.of(
        "startAi", "beginAi", "requestAi", "maybeStartAiAfterCapture", "applyAi", "aiSettings");
    public static void main(String[] args) throws Exception {
        if(args.length!=1) throw new IllegalArgumentException("Pass the production editor Java file");
        JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
        if(compiler==null)throw new IllegalStateException("JDK required");
        DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
        try(StandardJavaFileManager files=compiler.getStandardFileManager(diagnostics,null,null)) {
            JavacTask task=(JavacTask)compiler.getTask(null,files,diagnostics,
                List.of("-proc:none"),null,files.getJavaFileObjects(args[0]));
            CompilationUnitTree unit=task.parse().iterator().next();
            ClassTree editor=null;
            for(Tree decl:unit.getTypeDecls()) if(decl instanceof ClassTree &&
                ((ClassTree)decl).getSimpleName().contentEquals("Duwm1728VideoEditorActivity")) editor=(ClassTree)decl;
            if(editor==null)throw new AssertionError("Expected actual editor class");
            Map<String,Set<Integer>> signatures=new HashMap<>();
            Map<String,MethodTree> methods=new HashMap<>();
            for(Tree member:editor.getMembers())if(member instanceof MethodTree){
                MethodTree method=(MethodTree)member;
                String name=method.getName().toString();
                signatures.computeIfAbsent(name,k->new HashSet<>()).add(method.getParameters().size());
                methods.put(name,method);
            }
            List<String> failures=new ArrayList<>();
            final Map<String,Set<Integer>> declared=signatures;
            new TreeScanner<Void,Void>() {
                @Override public Void visitMethodInvocation(MethodInvocationTree call,Void unused){
                    ExpressionTree selected=call.getMethodSelect();
                    String name=null;
                    if(selected instanceof IdentifierTree)name=((IdentifierTree)selected).getName().toString();
                    if(selected instanceof MemberSelectTree){MemberSelectTree m=(MemberSelectTree)selected;
                        if(m.getExpression().toString().equals("this"))name=m.getIdentifier().toString();}
                    if(name!=null && ENTRY_POINTS.contains(name) &&
                       !declared.getOrDefault(name,Set.of()).contains(call.getArguments().size()))
                        failures.add("UNRESOLVED_AI_SELF_CALL "+name+"/"+call.getArguments().size());
                    return super.visitMethodInvocation(call,unused);
                }
                @Override public Void visitMemberReference(MemberReferenceTree call,Void unused){
                    String name=call.getName().toString();
                    if(call.getQualifierExpression().toString().equals("this") && ENTRY_POINTS.contains(name) && !declared.containsKey(name))
                        failures.add("UNRESOLVED_AI_REFERENCE "+name);
                    return super.visitMemberReference(call,unused);
                }
            }.scan(editor,null);
            if(!failures.isEmpty())throw new AssertionError(String.join("; ",failures));
            require(methods.containsKey("beginAi"),"Missing actual AI worker");
            require(methods.containsKey("maybeStartAiAfterCapture"),"Automatic entry point not unified");
            require(calls(methods.get("maybeStartAiAfterCapture")).contains("beginAi"),"Automatic entry does not call real worker");
            require(calls(methods.get("requestAi")).contains("beginAi"),"Confirmed manual entry does not call same worker");
            require(calls(methods.get("beginAi")).contains("produce"),"AI worker must call production client, not a no-op stub");
            require(methods.get("beginAi").toString().contains("selected.toMs > durationMs"),"Missing range guard");
            for(Diagnostic<?> d:diagnostics.getDiagnostics())if(d.getKind()==Diagnostic.Kind.ERROR)throw new AssertionError(d.toString());
            System.out.println("PASS actual editor AST: automatic/manual AI paths resolve to beginAi(Spec), client call retained, range guard present. Not an Android API compile.");
        }
    }
    private static Set<String> calls(MethodTree method){
        Set<String> names=new HashSet<>();
        new TreeScanner<Void,Void>(){
            @Override public Void visitMethodInvocation(MethodInvocationTree call,Void unused){
                ExpressionTree m=call.getMethodSelect();
                if(m instanceof IdentifierTree)names.add(((IdentifierTree)m).getName().toString());
                else if(m instanceof MemberSelectTree)names.add(((MemberSelectTree)m).getIdentifier().toString());
                return super.visitMethodInvocation(call,unused);
            }
        }.scan(method,null);
        return names;
    }
    private static void require(boolean value,String message){if(!value)throw new AssertionError(message);}
}
