package com.sentongoharuna.worldsituationroom;

import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Strict timecoded SRT import. The source file must already contain transcript text and times. */
public final class Duwm1728SubtitleImport {
    private Duwm1728SubtitleImport(){}
    private static final Pattern TIMING=Pattern.compile("(\\d{2}):(\\d{2}):(\\d{2})[,\\.](\\d{3})\\s*-->\\s*(\\d{2}):(\\d{2}):(\\d{2})[,\\.](\\d{3})");
    private static long ms(Matcher m,int start){
        long h=Long.parseLong(m.group(start)),min=Long.parseLong(m.group(start+1));
        long s=Long.parseLong(m.group(start+2)),frac=Long.parseLong(m.group(start+3));
        if(min>59||s>59)throw new IllegalArgumentException("Invalid subtitle timestamp");
        return ((h*60+min)*60+s)*1000+frac;
    }
    /** Exact source-video cue times. No old 45-second / 12-caption restriction. */
    public static java.util.List<Duwm1728BroadcastLayout.Cue> parseSrtCues(String text){
        if(text==null||text.length()>65536)throw new IllegalArgumentException("Invalid or oversized SRT file");
        text=text.replace("\r\n","\n").replace('\r','\n').replace("\uFEFF","");
        String[] blocks=text.trim().split("\n\\s*\n");
        ArrayList<Duwm1728BroadcastLayout.Cue> cues=new ArrayList<>();long previousEnd=-1;
        for(String block:blocks){
            String[] lines=block.split("\n");int index=0;
            if(lines.length>0&&lines[0].trim().matches("[0-9]+"))index++;
            if(index>=lines.length)continue;
            Matcher m=TIMING.matcher(lines[index].trim());
            if(!m.matches())throw new IllegalArgumentException("Unrecognised SRT time code");
            long start=ms(m,1),end=ms(m,5);
            if(start<previousEnd||end<=start)throw new IllegalArgumentException("Subtitle cues overlap or have invalid times; review the SRT file");
            StringBuilder words=new StringBuilder();
            for(int i=index+1;i<lines.length;i++){
                String clean=lines[i].replaceAll("<[^>]*>","").trim();
                if(!clean.isEmpty()){if(words.length()>0)words.append(' ');words.append(clean);}
            }
            if(words.length()==0)continue;
            if(words.length()>500)throw new IllegalArgumentException("Subtitle exceeds 500 characters");
            cues.add(new Duwm1728BroadcastLayout.Cue(start,end,words.toString()));previousEnd=end;
            if(cues.size()>5000)throw new IllegalArgumentException("Maximum 5000 imported cues");
        }
        if(cues.isEmpty())throw new IllegalArgumentException("No subtitle cues found");
        return java.util.Collections.unmodifiableList(cues);
    }
    /** Compatibility helper only. New editor uses parseSrtCues and retains exact end times. */
    @Deprecated public static String convertSrt(String text){
        ArrayList<String> result=new ArrayList<>();
        for(Duwm1728BroadcastLayout.Cue c:parseSrtCues(text))result.add(String.format(Locale.US,
            "%02d:%02d=%s",c.startMs/60000,(c.startMs/1000)%60,c.text.replace(';',',').replace('=','-')));
        return String.join(";",result);
    }
}
