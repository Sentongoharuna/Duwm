package com.sentongoharuna.worldsituationroom;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.graphics.YuvImage;
import android.graphics.ImageFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaRecorder;
import android.media.AudioManager;
import android.media.AudioDeviceInfo;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaFormat;
import android.os.Build;
import android.util.Range;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.security.MessageDigest;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/** MONITORS CAM: direct camera-to-recorder clean master, with separately stored telemetry.
 * Recording opens the shared broadcast review/export path. Preview frames are used only for
 * operational health; no JPEG intermediates or pre-burned text panels are inserted in the master.
 * Advanced modes remain device-dependent. AI requires an explicitly configured/consented service.
 */
@SuppressWarnings("deprecation")
public final class Duwm1718MonitorsCamActivity extends Activity implements TextureView.SurfaceTextureListener, SensorEventListener {
    private static final int NAVY=DuwmUnifiedTheme.APPROVED_NAVY;
    private static final int TEXT=DuwmUnifiedTheme.TEXT, MUTED=DuwmUnifiedTheme.MUTED;
    // Camera hardware and Canvas input support vary by device. Both ratios are EXACT
    // encoded pixel ratios, not merely letterboxing the preview widget.
    private int outputW=1080,outputH=1920,outputFps=30,outputBitrate=16_000_000;
    private int nativeVideoW=1920,nativeVideoH=1080,mediaRotation;
    private Duwm1728AspectFrame viewfinder;
    private boolean recorderOwnsCamera;
    private static final String VIDEO_SETTINGS="duwm1724_video_settings";
    private static final String KEY_RATIO="ratio",KEY_QUALITY="quality";
    private int ratioIndex=0,qualityIndex=0; // 0 = 9:10 portrait; 1 = 16:9 landscape
    private int actualSourceWidth=0,actualSourceHeight=0;
    private TextView aspectButton,qualityButton,recordingProfile;
    private static final int REQ_LEGACY_GALLERY=1824;
    private static final int REQ_CAMERA=1818,REQ_LOCATION=1819;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService frames=Executors.newSingleThreadExecutor();
    private final AtomicBoolean processing=new AtomicBoolean();
    private final AtomicReference<Bitmap> latest=new AtomicReference<>();
    private final Object surfaceLock=new Object();
    private Camera camera; private MediaRecorder recorder; private Surface recorderSurface;
    private ScheduledExecutorService videoClock;
    private TextureView preview; private TextView indicator,telemetry,recordButton;
    // 1728.2/7: UI-only measured health, independent from the encoder and newsroom text.
    private Duwm1728CaptureHealthView captureHealthDock;
    private boolean cameraUiActive;
    private volatile long decodedFrameAt=-1L;
    private volatile int cameraSessionGeneration;
    private final java.util.concurrent.atomic.AtomicInteger decodedFrameCount=new java.util.concurrent.atomic.AtomicInteger();
    private String captureFailure="", microphoneFailure="", galleryMessage="";
    private long microphoneSampleAt=-1L, galleryCompletedAt=-1L;
    private int microphonePeak=-1, galleryResult=0, compassAccuracy=-1;
    private boolean weatherRequested, weatherLoading;
    private String weatherFailure="";
    private int weatherGeneration;
    private View previewGrid; private boolean showGrid=false;
    private ScaleGestureDetector scaleGesture;
    private float tapDownX,tapDownY;
    private boolean gestureScaled;
    private LinearLayout reportDetails; private TextView detailsToggle;
    private EditText placeInput,situationInput,reporterInput;
    private CheckBox preciseLocation,audioEnabled;
    private SensorManager sensorManager; private LocationManager locationManager;
    private volatile Location lastLocation;
    private boolean recording,closed,finished,locationActive;
    private volatile float heading=-1f;
    private volatile long lastHeadingAt=0L;
    private volatile String weather="MODEL WX NOT REQUESTED";
    private volatile long weatherReceivedAt=0L;
    private volatile double weatherLat=999d,weatherLon=999d;
    private String lastFile="";
    private static final String CLIP_RECEIPTS="duwm1721_camera_receipts";
    private static final String RECEIPT_LATEST="latest";
    private static final String[] CATEGORIES={"GENERAL","WEATHER","TRANSPORT","PUBLIC SAFETY","ENVIRONMENT","EYEWITNESS"};
    private int categoryIndex=0;private String bakedCategory="GENERAL";
    private static final String[] REPORT_OVERLAYS={"STANDARD","BREAKING NEWS","WEATHER REPORT","FIELD REPORT"};
    private int reportOverlayIndex=0;
    private String bakedOverlay="STANDARD";
    private boolean torchEnabled=false,nightModeEnabled=false;
    private String selectedWhiteBalance="AUTO";
    private boolean videoStabilizationEnabled=false;
    private int selectedMicrophoneId=-1;
    private int audioProcessingMode=0; // 0 standard mic, 1 voice-recognition, 2 voice-communication
    private int cameraEngineMode=0; // 0 currently verified HD/Pro engine, 1 optional UHD, 2 60 fps
    private static final String[] ADVANCED_CAPTURE_MODES={"STANDARD", "4K CAPABILITY-CHECKED", "60 FPS CAPABILITY-CHECKED"};
    private TextView categoryControl;
    private volatile boolean pendingGallerySave;
    private final java.util.List<Duwm1728TelemetryTimeline.Point> telemetrySamples=new java.util.ArrayList<>();
    private long lastSampleElapsed=-2000L;
    private TextView prompterDisplay;
    private String prompterScript="";
    private boolean showPrompter=false;
    private int prompterOffset=0;
    private final Runnable prompterScroll=new Runnable(){@Override public void run(){
        if(!closed && showPrompter && recording && prompterDisplay!=null){
            prompterOffset=Math.min(prompterScript.length(),prompterOffset+2);
            prompterDisplay.setText(prompterScript.substring(prompterOffset));
            main.postDelayed(this,600);
        }
    }};
    private volatile String bakedReporter="",bakedPlace="",bakedSituation="";
    private volatile boolean bakedPrecise;
    private long startedAt,lastFrameAt,lastWeatherAt;
    private final java.util.concurrent.atomic.AtomicInteger sourceFrames=new java.util.concurrent.atomic.AtomicInteger();
    private int cameraId=0,cameraFacing=Camera.CameraInfo.CAMERA_FACING_BACK,rotate=90,previewWidth=640,previewHeight=480,limitSeconds=60,recordedFrames;
    private final Runnable telemetryRefresh=new Runnable(){@Override public void run(){if(closed||!cameraUiActive)return;displayTelemetry();refreshCaptureHealth();main.postDelayed(this,650);}};
    private final LocationListener gpsListener=new LocationListener(){@Override public void onLocationChanged(Location value){if(value!=null && value.getAccuracy()<2000f)lastLocation=value;} @Override public void onProviderEnabled(String p){}@Override public void onProviderDisabled(String p){}@Override public void onStatusChanged(String p,int s,Bundle extras){}};
    private int dp(float x){return Math.round(getResources().getDisplayMetrics().density*x);}
    private GradientDrawable outline(){GradientDrawable d=new GradientDrawable();d.setColor(NAVY);d.setCornerRadius(dp(14));d.setStroke(dp(1),DuwmUnifiedTheme.BORDER);return d;}
    private TextView txt(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextColor(TEXT);t.setTextSize(sp);t.setGravity(Gravity.CENTER_VERTICAL);t.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));return t;}
    private TextView action(String label,Runnable a){TextView t=txt(label,12);t.setGravity(Gravity.CENTER);t.setBackground(outline());t.setMinHeight(dp(48));t.setOnClickListener(v->a.run());return t;}
    private LinearLayout.LayoutParams mp(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(7);return p;}
    @Override public void onCreate(Bundle b){super.onCreate(b);
        ratioIndex=getSharedPreferences(VIDEO_SETTINGS,MODE_PRIVATE).getInt(KEY_RATIO,2);if(ratioIndex<0||ratioIndex>2)ratioIndex=2;
        qualityIndex=getSharedPreferences(VIDEO_SETTINGS,MODE_PRIVATE).getInt(KEY_QUALITY,1);updateProfile();
        setRequestedOrientation(ratioIndex==1?ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE:ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
        getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(NAVY);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        cameraId=findCamera(Camera.CameraInfo.CAMERA_FACING_BACK);if(cameraId<0)cameraId=0;
        sensorManager=(SensorManager)getSystemService(SENSOR_SERVICE);locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setBackgroundColor(NAVY);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(10),0,dp(10),0);
        TextView brand=txt("MONITORS CAM",16);brand.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));header.addView(brand,new LinearLayout.LayoutParams(0,dp(42),1));
        header.addView(action("WORLD",this::finish),new LinearLayout.LayoutParams(dp(70),dp(40)));page.addView(header);
        LinearLayout tools=new LinearLayout(this);tools.setPadding(dp(8),0,dp(8),dp(4));
        aspectButton=action(ratioName(),this::switchRatio);qualityButton=action(qualityIndex==0?"HD":"PRO",this::chooseRecordingMode);detailsToggle=action("SETTINGS",this::showCameraSettings);
        for(TextView t:new TextView[]{aspectButton,qualityButton,detailsToggle}){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(42),1);lp.setMargins(dp(3),0,dp(3),0);tools.addView(t,lp);}page.addView(tools);
        FrameLayout outer=new FrameLayout(this);outer.setBackgroundColor(NAVY);viewfinder=new Duwm1728AspectFrame(this);viewfinder.setRatio(outputW/(float)outputH);
        outer.addView(viewfinder,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));preview=new TextureView(this);preview.setSurfaceTextureListener(this);
        preview.setContentDescription("Camera viewfinder. Tap to focus, pinch to zoom. The selected crop is used for broadcast export.");viewfinder.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        scaleGesture=new ScaleGestureDetector(this,new ScaleGestureDetector.SimpleOnScaleGestureListener(){@Override public boolean onScale(ScaleGestureDetector g){gestureScaled=true;return scaleCamera(g.getScaleFactor());}});
        preview.setOnTouchListener((v,e)->{if(e.getActionMasked()==MotionEvent.ACTION_DOWN){tapDownX=e.getX();tapDownY=e.getY();gestureScaled=false;}scaleGesture.onTouchEvent(e);
            if(e.getActionMasked()==MotionEvent.ACTION_UP&&!gestureScaled&&Math.abs(e.getX()-tapDownX)<dp(22)&&Math.abs(e.getY()-tapDownY)<dp(22)){focusOnce();v.performClick();}return true;});
        previewGrid=new View(this){final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);@Override protected void onDraw(Canvas c){if(!showGrid)return;paint.setColor(0x80DEE5EF);paint.setStrokeWidth(dp(1));for(int i=1;i<3;i++){c.drawLine(getWidth()*i/3f,0,getWidth()*i/3f,getHeight(),paint);c.drawLine(0,getHeight()*i/3f,getWidth(),getHeight()*i/3f,paint);}}};
        viewfinder.addView(previewGrid,new FrameLayout.LayoutParams(-1,-1));
        indicator=txt("CAMERA INITIALISING",10);indicator.setSingleLine(true);indicator.setPadding(dp(9),0,dp(9),0);indicator.setBackgroundColor(0xB8041424);viewfinder.addView(indicator,new FrameLayout.LayoutParams(-1,dp(28),Gravity.TOP));
        telemetry=txt("",10);telemetry.setVisibility(View.GONE); // detailed telemetry lives in settings, not over the picture
        prompterDisplay=txt("",17);prompterDisplay.setGravity(Gravity.CENTER);prompterDisplay.setBackgroundColor(0xC0041424);prompterDisplay.setVisibility(View.GONE);viewfinder.addView(prompterDisplay,new FrameLayout.LayoutParams(-1,dp(90),Gravity.CENTER));
        page.addView(outer,new LinearLayout.LayoutParams(-1,0,1));
        recordingProfile=txt(profileLabel(),10);recordingProfile.setGravity(Gravity.CENTER);page.addView(recordingProfile,new LinearLayout.LayoutParams(-1,dp(23)));
        captureHealthDock=new Duwm1728CaptureHealthView(this);page.addView(captureHealthDock,new LinearLayout.LayoutParams(-1,dp(46)));
        LinearLayout dock=new LinearLayout(this);dock.setGravity(Gravity.CENTER);dock.setPadding(dp(12),dp(6),dp(12),dp(10));
        TextView gallery=action("GALLERY",()->{if(!recording)startActivity(new Intent(this,Duwm1726GalleryLibraryActivity.class));});
        TextView flip=action("FLIP",this::flipCamera);recordButton=action("● REC",this::toggleRecording);recordButton.setTextSize(19);recordButton.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        GradientDrawable rec=new GradientDrawable();rec.setColor(0xFFD50000);rec.setCornerRadius(dp(34));rec.setStroke(dp(2),0xFFDEE5EF);recordButton.setBackground(rec);recordButton.setContentDescription("Start recording; press again to stop and produce a broadcast");
        dock.addView(gallery,new LinearLayout.LayoutParams(0,dp(50),1));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(dp(96),dp(62));rp.setMargins(dp(18),0,dp(18),0);dock.addView(recordButton,rp);dock.addView(flip,new LinearLayout.LayoutParams(0,dp(50),1));page.addView(dock);
        reportDetails=new LinearLayout(this);reportDetails.setOrientation(LinearLayout.VERTICAL);reportDetails.setPadding(dp(14),dp(12),dp(14),dp(16));
        reporterInput=input("Reporter / ID (self-reported)","WORLD MONITOR REPORTER");reportDetails.addView(reporterInput,mp());
        placeInput=input("City / place (self-reported)","");reportDetails.addView(placeInput,mp());
        situationInput=input("Situation / eyewitness description","");
        situationInput.setSingleLine(false);situationInput.setMinLines(2);situationInput.setMaxLines(4);
        situationInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE |
                android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        reportDetails.addView(situationInput,mp());
        preciseLocation=new CheckBox(this);
        preciseLocation.setText("Record exact GPS privately (broadcast disclosure is separate)");
        preciseLocation.setTextColor(TEXT);preciseLocation.setButtonTintList(
                android.content.res.ColorStateList.valueOf(DuwmUnifiedTheme.BORDER));
        preciseLocation.setChecked(false);
        preciseLocation.setOnCheckedChangeListener((button,checked)->{
            if(checked)requestLocation();else stopLocation();
        });reportDetails.addView(preciseLocation,mp());
        audioEnabled=new CheckBox(this);audioEnabled.setText("Microphone audio (permission required)");
        audioEnabled.setTextColor(TEXT);audioEnabled.setChecked(true);
        audioEnabled.setButtonTintList(android.content.res.ColorStateList.valueOf(DuwmUnifiedTheme.BORDER));
        reportDetails.addView(audioEnabled,mp());
        categoryControl=action("REPORT CATEGORY  /  GENERAL  ▸",this::nextCategory);
        reportDetails.addView(categoryControl,mp());
        reportDetails.addView(action("FETCH OPTIONAL WEATHER MODEL",this::fetchWeather),mp());
        reportDetails.addView(txt("Weather is opt-in model data, not a device measurement. Confirm licensing before commercial use.",10),mp());
        reportDetails.addView(action("CAMERA / SENSOR / PRIVACY READINESS",this::showReadiness),mp());
        LinearLayout proTools=new LinearLayout(this);proTools.setOrientation(LinearLayout.HORIZONTAL);
        TextView evDown=action("EXPOSURE −",()->adjustExposure(-1));
        TextView evUp=action("EXPOSURE +",()->adjustExposure(1));
        for(TextView t:new TextView[]{evDown,evUp}){
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(46),1);lp.rightMargin=dp(5);
            proTools.addView(t,lp);
        }
        reportDetails.addView(proTools,mp());
        reportDetails.addView(action("WHITE BALANCE  /  DEVICE CONTROL",this::cycleWhiteBalance),mp());
        reportDetails.addView(action("LOW LIGHT  /  DEVICE MODE",this::toggleNightMode),mp());
        reportDetails.addView(action("TORCH  /  DEVICE FLASH",this::toggleTorch),mp());
        reportDetails.addView(action("BROADCAST STYLE / APPLIED AFTER REVIEW",this::cycleOverlayTemplate),mp());
        reportDetails.addView(action("CAMERA CAPABILITIES / HDR / HIGH-SPEED / LENSES",this::showAdvancedCameraCapabilities),mp());
        reportDetails.addView(action("RECORDING MODE / HD, PRO, 4K, 60 FPS",this::chooseRecordingMode),mp());
        reportDetails.addView(action("STABILIZATION / DEVICE VIDEO MODE",this::toggleVideoStabilization),mp());
        reportDetails.addView(action("CAMERA LENS / SWITCH AVAILABLE CAMERA IDS",this::switchPhysicalCamera),mp());
        reportDetails.addView(action("AUDIO INPUT / SELECT MICROPHONE",this::chooseMicrophone),mp());
        reportDetails.addView(action("AUDIO PROCESSING / STANDARD OR SPEECH",this::chooseAudioProcessing),mp());
        reportDetails.addView(action("SLOW MOTION / TIMELAPSE / HDR SUPPORT",this::showSpecialCaptureModes),mp());
        reportDetails.addView(action("TELEPROMPTER / SCRIPT & DISPLAY",this::editTeleprompter),mp());
        reportDetails.addView(txt("The teleprompter guides the reporter in preview; it is NOT burned into recorded footage.",10),mp());
        reportDetails.addView(action("PREVIEW GRID ON / OFF",()->{
            showGrid=!showGrid;if(previewGrid!=null)previewGrid.invalidate();
        }),mp());
        reportDetails.addView(action("RECORDING LENGTH",this::setDuration),mp());
        reportDetails.addView(action("LATEST VIDEO SHA-256 RECEIPT",this::showCaptureReceipt),mp());
        reportDetails.addView(action("MY SAVED GALLERY VIDEOS",()->startActivity(new Intent(this,Duwm1726GalleryLibraryActivity.class))),mp());
        reportDetails.addView(txt("Sensor data is measured only when available. Reporter descriptions are unverified. Overlay encoding depends on phone hardware.",10),mp());

        reportDetails.addView(telemetry,mp());telemetry.setVisibility(View.VISIBLE);
        reportDetails.addView(action("HD / PRO QUALITY",this::switchQuality),mp());
        setContentView(page);
        if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAMERA);
    }
    private String ratioName(){return ratioIndex==0?"9:10":ratioIndex==1?"16:9":"9:16";}
    private void showCameraSettings(){if(recording){note("Stop recording before changing the camera setup");return;}
        if(reportDetails.getParent() instanceof android.view.ViewGroup)((android.view.ViewGroup)reportDetails.getParent()).removeView(reportDetails);
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(NAVY);scroll.addView(reportDetails);
        new AlertDialog.Builder(this).setTitle("Camera & reporting settings").setView(scroll).setPositiveButton("DONE",null).show();
    }

    private EditText input(String hint,String value){EditText x=new EditText(this);x.setSingleLine(true);x.setTextSize(14);x.setTextColor(TEXT);x.setHintTextColor(MUTED);x.setHint(hint);x.setText(value);x.setPadding(dp(13),0,dp(13),0);x.setBackground(outline());x.setMinHeight(dp(49));return x;}
    private int findCamera(int facing){for(int i=0;i<Camera.getNumberOfCameras();i++){Camera.CameraInfo info=new Camera.CameraInfo();Camera.getCameraInfo(i,info);if(info.facing==facing)return i;}return Camera.getNumberOfCameras()>0?0:-1;}
    @Override protected void onResume(){super.onResume();cameraUiActive=true;
        main.removeCallbacks(telemetryRefresh);main.post(telemetryRefresh);
        if(preciseLocation!=null&&preciseLocation.isChecked())requestLocation();
        Sensor rv=sensorManager==null?null:sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        if(rv!=null)sensorManager.registerListener(this,rv,SensorManager.SENSOR_DELAY_UI);
        if(preview!=null&&preview.isAvailable())openCamera();}
    private void openCamera(){if(camera!=null||recording||closed||checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED||preview==null||!preview.isAvailable())return;
        captureFailure="";decodedFrameAt=-1;cameraSessionGeneration++;
        try{camera=Camera.open(cameraId);Camera.CameraInfo info=new Camera.CameraInfo();Camera.getCameraInfo(cameraId,info);cameraFacing=info.facing;
            Camera.Parameters p=camera.getParameters();java.util.List<Camera.Size> videoSizes=p.getSupportedVideoSizes();if(videoSizes==null)videoSizes=p.getSupportedPreviewSizes();
            int targetW=cameraEngineMode==1?3840:qualityIndex==0?1280:1920,targetH=cameraEngineMode==1?2160:qualityIndex==0?720:1080;
            nativeVideoW=0;nativeVideoH=0;for(Camera.Size size:videoSizes)if(size.width==targetW&&size.height==targetH){nativeVideoW=size.width;nativeVideoH=size.height;break;}
            if(nativeVideoW==0){for(Camera.Size size:videoSizes)if(Math.abs(size.width/(double)size.height-16.0/9.0)<.02&&size.width>nativeVideoW){nativeVideoW=size.width;nativeVideoH=size.height;}}
            if(nativeVideoW==0)throw new IllegalStateException("No supported 16:9 clean-master profile");
            Camera.Size best=null;long bestScore=Long.MAX_VALUE;for(Camera.Size size:p.getSupportedPreviewSizes()){
                long score=Math.abs((long)size.width*size.height-Math.min((long)nativeVideoW*nativeVideoH,1920L*1080));score+=(long)(Math.abs(size.width/(double)size.height-16.0/9.0)*10000000);if(score<bestScore){best=size;bestScore=score;}}
            if(best!=null){previewWidth=best.width;previewHeight=best.height;p.setPreviewSize(best.width,best.height);}
            actualSourceWidth=nativeVideoW;actualSourceHeight=nativeVideoH;p.setPreviewFormat(ImageFormat.NV21);p.setRecordingHint(true);
            if(p.getSupportedFocusModes()!=null&&p.getSupportedFocusModes().contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO))p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
            if(videoStabilizationEnabled&&p.isVideoStabilizationSupported())p.setVideoStabilization(true);
            java.util.List<int[]> ranges=p.getSupportedPreviewFpsRange();int[] selected=null;if(ranges!=null)for(int[] range:ranges)if(range[0]<=outputFps*1000&&range[1]>=outputFps*1000&&(selected==null||(range[1]-range[0])<(selected[1]-selected[0])))selected=range;
            if(selected!=null)p.setPreviewFpsRange(selected[0],selected[1]);camera.setParameters(p);
            int display=getWindowManager().getDefaultDisplay().getRotation(),degrees=display==Surface.ROTATION_90?90:display==Surface.ROTATION_180?180:display==Surface.ROTATION_270?270:0;
            mediaRotation=info.facing==Camera.CameraInfo.CAMERA_FACING_FRONT?(info.orientation+degrees)%360:(info.orientation-degrees+360)%360;
            rotate=mediaRotation;int displayRotation=info.facing==Camera.CameraInfo.CAMERA_FACING_FRONT?(360-mediaRotation)%360:mediaRotation;
            camera.setDisplayOrientation(displayRotation);camera.setPreviewTexture(preview.getSurfaceTexture());camera.setPreviewCallbackWithBuffer(this::acceptFrame);
            camera.addCallbackBuffer(new byte[previewWidth*previewHeight*3/2]);camera.addCallbackBuffer(new byte[previewWidth*previewHeight*3/2]);camera.startPreview();applyViewfinderAspect();indicator.setText("READY  •  CLEAN MASTER "+nativeVideoW+"×"+nativeVideoH);
        }catch(Exception e){releaseCamera();captureFailure=safe(e);indicator.setText("CAMERA UNAVAILABLE • "+safe(e));refreshCaptureHealth();}
    }
    /** Keep the preview picture at the selected recorded aspect (no stretched faces). */
    private void applyViewfinderAspect(){if(preview==null)return;preview.post(()->{int w=preview.getWidth(),h=preview.getHeight();if(w<1||h<1)return;
        int sw=rotate%180==0?previewWidth:previewHeight,sh=rotate%180==0?previewHeight:previewWidth;float scale=Math.max(w/(float)sw,h/(float)sh);
        Matrix transform=new Matrix();transform.setScale(sw*scale/w,sh*scale/h,w/2f,h/2f);preview.setTransform(transform);});}
    private void acceptFrame(byte[] data,Camera src){
        if(src!=camera||closed||data==null)return;decodedFrameAt=SystemClock.elapsedRealtime();decodedFrameCount.incrementAndGet();sourceFrames.incrementAndGet();
        try{src.addCallbackBuffer(data);}catch(RuntimeException ignored){}
    }
    private void flipCamera(){if(recording)return;int f=cameraFacing==Camera.CameraInfo.CAMERA_FACING_FRONT?Camera.CameraInfo.CAMERA_FACING_BACK:Camera.CameraInfo.CAMERA_FACING_FRONT;int id=findCamera(f);if(id<0)return;releaseCamera();cameraId=id;openCamera();}
    private void zoomCamera(){if(recording||camera==null)return;try{Camera.Parameters p=camera.getParameters();if(!p.isZoomSupported()){note("Zoom not supported");return;}p.setZoom((p.getZoom()+Math.max(1,p.getMaxZoom()/8))%(p.getMaxZoom()+1));camera.setParameters(p);}catch(Exception e){note("Zoom unavailable");}}
    private boolean scaleCamera(float factor){
        if(recording||camera==null)return false;
        try{
            Camera.Parameters settings=camera.getParameters();
            if(!settings.isZoomSupported())return false;
            int maximum=settings.getMaxZoom();if(maximum<=0)return false;
            int previous=settings.getZoom();
            // Avoid jumping across the whole device zoom range in one gesture.
            int jump=Math.max(1,Math.min(3,Math.round(Math.abs(factor-1f)*maximum*0.6f)));
            int target=Math.max(0,Math.min(maximum,previous+(factor>=1f?jump:-jump)));
            if(target!=previous){settings.setZoom(target);camera.setParameters(settings);
                indicator.setText("● CAMERA READY / PINCH ZOOM "+target+" / "+maximum);
            }
            return true;
        }catch(RuntimeException unsupported){note("Pinch zoom unavailable on this camera");return false;}
    }
    private void focusOnce(){
        if(recording){note("Focus is locked while recording");return;}
        if(camera==null){note("Camera is not available");return;}
        try{
            Camera.Parameters p=camera.getParameters();
            if(p.getSupportedFocusModes()==null||!p.getSupportedFocusModes().contains(Camera.Parameters.FOCUS_MODE_AUTO)){
                note("Manual focus not supported on this camera");return;
            }
            p.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);camera.setParameters(p);
            camera.autoFocus((success,c)->main.post(()->indicator.setText(success?
                    "● FOCUS CONFIRMED  /  DEVICE CAMERA":"● AUTOFOCUS NOT CONFIRMED")));
        }catch(RuntimeException e){note("Device autofocus unavailable");}
    }
    private void adjustExposure(int direction){
        if(recording){note("Exposure locked while recording");return;}
        if(camera==null){note("Camera unavailable");return;}
        try{
            Camera.Parameters p=camera.getParameters();
            int min=p.getMinExposureCompensation(),max=p.getMaxExposureCompensation();
            if(min==0&&max==0){note("Exposure adjustment unsupported");return;}
            int target=Math.max(min,Math.min(max,p.getExposureCompensation()+direction));
            p.setExposureCompensation(target);camera.setParameters(p);
            indicator.setText("● CAMERA READY  /  EXPOSURE "+target+" / "+min+".."+max);
        }catch(RuntimeException e){note("Exposure adjustment unavailable on this camera");}
    }
    /** Only enable a feature when the opened camera reports it as supported. */
    private void cycleWhiteBalance(){
        if(recording||camera==null){note("Stop recording and open the camera first");return;}
        try{
            Camera.Parameters p=camera.getParameters();java.util.List<String> modes=p.getSupportedWhiteBalance();
            if(modes==null||modes.size()<2){note("This camera has no alternate white-balance modes");return;}
            int index=modes.indexOf(p.getWhiteBalance());
            String next=modes.get((index+1+modes.size())%modes.size());
            p.setWhiteBalance(next);camera.setParameters(p);selectedWhiteBalance=next;
            indicator.setText("● WHITE BALANCE / "+next.toUpperCase(Locale.US));
        }catch(RuntimeException ex){note("White balance not supported on this device");}
    }
    private void toggleNightMode(){
        if(recording||camera==null){note("Change low-light mode before recording");return;}
        try{
            Camera.Parameters p=camera.getParameters();java.util.List<String> modes=p.getSupportedSceneModes();
            if(modes==null||!modes.contains(Camera.Parameters.SCENE_MODE_NIGHT)){
                note("This camera does not advertise a native night scene mode");return;
            }
            nightModeEnabled=!nightModeEnabled;
            p.setSceneMode(nightModeEnabled?Camera.Parameters.SCENE_MODE_NIGHT:Camera.Parameters.SCENE_MODE_AUTO);
            camera.setParameters(p);indicator.setText(nightModeEnabled?"● DEVICE NIGHT MODE ON":"● DEVICE NIGHT MODE OFF");
        }catch(RuntimeException ex){nightModeEnabled=false;note("Native low-light mode unavailable");}
    }
    private void toggleTorch(){
        if(recording||camera==null){note("Torch cannot change while recording on this camera engine");return;}
        try{
            Camera.Parameters p=camera.getParameters();java.util.List<String> modes=p.getSupportedFlashModes();
            if(modes==null||!modes.contains(Camera.Parameters.FLASH_MODE_TORCH)){
                note("No camera torch available");return;
            }
            torchEnabled=!torchEnabled;
            p.setFlashMode(torchEnabled?Camera.Parameters.FLASH_MODE_TORCH:Camera.Parameters.FLASH_MODE_OFF);
            camera.setParameters(p);indicator.setText(torchEnabled?"● TORCH ON":"● TORCH OFF");
        }catch(RuntimeException ex){torchEnabled=false;note("Torch unsupported by current camera");}
    }
    private void cycleOverlayTemplate(){
        if(recording){note("Cannot change permanent video graphics during recording");return;}
        reportOverlayIndex=(reportOverlayIndex+1)%REPORT_OVERLAYS.length;
        note("Permanent MP4 graphic / "+REPORT_OVERLAYS[reportOverlayIndex]);
    }
    private void showAdvancedCameraCapabilities(){
        String report=Duwm1728CameraCapabilities.inspect(this);
        new AlertDialog.Builder(this).setTitle("Camera2 hardware & encoder capability report")
          .setMessage(report+"\n\nThis is hardware discovery only: not proof that the legacy Canvas recording engine can achieve 4K, 60 FPS or HDR.")
          .setPositiveButton("CLOSE",null).show();
    }
    /** A mode is selectable only when camera frames AND the H.264 encoder declare enough capacity.
     * This does NOT claim successful capture until an actual file is inspected on a device. */
    private boolean codecSupports(int width,int height,int fps){
        try{
            MediaCodecList list=new MediaCodecList(MediaCodecList.REGULAR_CODECS);
            for(MediaCodecInfo info:list.getCodecInfos()){
                if(!info.isEncoder())continue;
                for(String type:info.getSupportedTypes()){
                    if(!"video/avc".equalsIgnoreCase(type))continue;
                    MediaCodecInfo.VideoCapabilities v=info.getCapabilitiesForType(type).getVideoCapabilities();
                    if(v!=null&&v.areSizeAndRateSupported(width,height,(double)fps))return true;
                }
            }
        }catch(Exception ex){android.util.Log.w("DUWM-CAM","Encoder capability query failed",ex);}
        return false;
    }
    private boolean cameraPreviewSupports(int width,int height,int fps){
        if(camera==null)return false;
        try{
            Camera.Parameters p=camera.getParameters();boolean pixels=false,rates=false;
            for(Camera.Size size:p.getSupportedPreviewSizes()){
                if((long)size.width*size.height>=(long)width*height){pixels=true;break;}
            }
            java.util.List<int[]> ranges=p.getSupportedPreviewFpsRange();
            if(ranges!=null)for(int[] r:ranges)if(r!=null&&r.length>=2&&r[0]<=fps*1000&&r[1]>=fps*1000){rates=true;break;}
            return pixels&&rates;
        }catch(RuntimeException ex){return false;}
    }
    private void chooseRecordingMode(){
        if(recording||pendingGallerySave){note("Stop the current recording first");return;}
        if(camera==null){note("Open the camera before selecting an advanced recording mode");return;}
        final String[] modes={"STANDARD / current aspect and quality", "UHD 4K / 3840×2160 30 FPS (landscape)",
                "60 FPS / current aspect and quality"};
        new AlertDialog.Builder(this).setTitle("Recording profile (device-dependent)")
          .setItems(modes,(dialog,index)->{
              if(index==1&&(ratioIndex!=1||!cameraPreviewSupports(3840,2160,30)||!codecSupports(3840,2160,30))){
                  note("4K mode unavailable: landscape, camera preview and H.264 encoder support required");return;
              }
              if(index==2&&(!cameraPreviewSupports(outputW,outputH,60)||!codecSupports(outputW,outputH,60))){
                  note("60 FPS unavailable for the current camera and recording resolution");return;
              }
              cameraEngineMode=index;
              applyRequestedCaptureMode();
              if(camera!=null){releaseCamera();openCamera();}
              if(recordingProfile!=null)recordingProfile.setText(profileLabel());
              note(index==0?"Standard mode selected": "Advanced mode requested; recording and actual MP4 FPS must still be verified");
          }).show();
    }
    private void applyRequestedCaptureMode(){
        if(cameraEngineMode==1){outputW=3840;outputH=2160;outputFps=30;outputBitrate=45_000_000;}
        else if(cameraEngineMode==2){outputFps=60;outputBitrate=Math.max(outputBitrate,18_000_000);}
    }
    private void toggleVideoStabilization(){
        if(camera==null||recording){note("Open camera and stop recording before changing stabilisation");return;}
        try{
            Camera.Parameters p=camera.getParameters();
            if(!p.isVideoStabilizationSupported()){note("Device does not provide legacy-camera video stabilization");return;}
            boolean enable=!p.getVideoStabilization();p.setVideoStabilization(enable);
            camera.setParameters(p);videoStabilizationEnabled=camera.getParameters().getVideoStabilization();
            note(videoStabilizationEnabled?"Device video stabilization ON":"Device video stabilization OFF");
        }catch(RuntimeException ex){videoStabilizationEnabled=false;note("Stabilization request rejected by the camera");}
    }
    private void switchPhysicalCamera(){
        if(recording){note("Stop recording before switching lenses");return;}
        int n=Camera.getNumberOfCameras();if(n<2){note("Only one independently addressable camera is available");return;}
        String[] choices=new String[n];
        for(int i=0;i<n;i++){Camera.CameraInfo info=new Camera.CameraInfo();Camera.getCameraInfo(i,info);
            choices[i]="Camera "+i+" / "+(info.facing==Camera.CameraInfo.CAMERA_FACING_FRONT?"FRONT":"BACK")+
                (i==cameraId?" / SELECTED":"");}
        new AlertDialog.Builder(this).setTitle("Cameras independently exposed by Android")
           .setItems(choices,(d,which)->{if(which!=cameraId){releaseCamera();cameraId=which;openCamera();}}).show();
    }
    private AudioDeviceInfo[] audioInputs(){
        AudioManager manager=(AudioManager)getSystemService(AUDIO_SERVICE);
        return manager==null?new AudioDeviceInfo[0]:manager.getDevices(AudioManager.GET_DEVICES_INPUTS);
    }
    private void chooseMicrophone(){
        if(recording){note("Stop recording before selecting a microphone");return;}
        AudioDeviceInfo[] inputs=audioInputs();String[] labels=new String[inputs.length+1];labels[0]="SYSTEM DEFAULT";
        for(int i=0;i<inputs.length;i++)labels[i+1]=
            "INPUT "+inputs[i].getId()+" / "+inputs[i].getProductName()+" / type "+inputs[i].getType();
        new AlertDialog.Builder(this).setTitle("Choose recording audio input")
          .setItems(labels,(d,i)->{selectedMicrophoneId=i==0?-1:inputs[i-1].getId();
              note(i==0?"System-default microphone selected":"Requested microphone: "+labels[i]);}).show();
    }
    private void chooseAudioProcessing(){
        if(recording){note("Stop recording to change audio input processing");return;}
        String[] modes={"STANDARD MICROPHONE / no special processing request",
            "VOICE RECOGNITION / voice-oriented input", "VOICE COMMUNICATION / platform may apply noise processing"};
        new AlertDialog.Builder(this).setTitle("Device audio capture profile")
          .setItems(modes,(d,i)->{audioProcessingMode=i;note(modes[i]+"; actual noise reduction is device-controlled");}).show();
    }
    private void showSpecialCaptureModes(){
        String desc="Slow motion needs genuinely high-frame-rate samples and adjusted media timestamps. " +
          "Time lapse needs time-controlled sample timestamps. " +
          "10-bit HDR requires a compatible Camera2 dynamic-range capture pipeline and HDR encoder. " +
          "This recording path does not supply those complete recording paths; they remain DISABLED, " +
          "even when the camera advertises related hardware capabilities.";
        new AlertDialog.Builder(this).setTitle("Advanced capture: not yet recordable")
          .setMessage(desc).setPositiveButton("CLOSE",null).show();
    }
    private void applyRecorderAudio(){
        if(!audioEnabled.isChecked()||recorder==null)return;
        int src=audioProcessingMode==1?MediaRecorder.AudioSource.VOICE_RECOGNITION:
            audioProcessingMode==2?MediaRecorder.AudioSource.VOICE_COMMUNICATION:MediaRecorder.AudioSource.MIC;
        recorder.setAudioSource(src);
        if(Build.VERSION.SDK_INT>=28&&selectedMicrophoneId>=0){
            boolean routed=false;
            for(AudioDeviceInfo device:audioInputs()){
                if(device.getId()==selectedMicrophoneId){routed=recorder.setPreferredDevice(device);break;}
            }
            if(!routed)throw new IllegalStateException("Selected microphone is no longer available");
        }
    }
    private void nextCategory(){if(recording){note("Stop recording to change report category");return;}categoryIndex=(categoryIndex+1)%CATEGORIES.length;categoryControl.setText("REPORT CATEGORY  /  "+CATEGORIES[categoryIndex]+"  ▸");}
    private void showCaptureReceipt(){String entry=getSharedPreferences(CLIP_RECEIPTS,MODE_PRIVATE).getString(RECEIPT_LATEST,"");
        if(entry.isEmpty()){note("No completed video receipt stored on this phone");return;}
        new AlertDialog.Builder(this).setTitle("Local capture receipt / not independently verified")
            .setMessage(entry+"\n\nSHA-256 identifies the locally recorded bytes at the time of capture. It does not prove the scene or report is authentic.")
            .setNegativeButton("CLOSE",null).setPositiveButton("SHARE TEXT",(d,w)->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,"DUWM local capture receipt\n"+entry+"\nNot independently verified");startActivity(Intent.createChooser(i,"Share capture receipt"));}).show();
    }
    private void saveCaptureReceipt(File completed,String captureName,long elapsedMillis,int framesMade,String reportCategory,boolean includedPrecise){
        final android.content.Context application=getApplicationContext();
        new Thread(()->{try(FileInputStream input=new FileInputStream(completed)){
            MessageDigest digest=MessageDigest.getInstance("SHA-256");byte[] buffer=new byte[32768];int len;
            while((len=input.read(buffer))!=-1)digest.update(buffer,0,len);
            StringBuilder hex=new StringBuilder();for(byte b:digest.digest())hex.append(String.format(Locale.US,"%02x",b&0xff));
            String receipt="FILE  "+captureName+"\nUTC RECEIPT  "+utc()+"\nDURATION  "+(elapsedMillis/1000)+" sec\nFRAMES  "+framesMade+
                    "\nSIZE  "+completed.length()+" bytes\nREPORT TYPE  "+reportCategory+
                    " (SELF-REPORTED)\nPRECISE GPS SIDECAR  "+(includedPrecise?"USER OPTED IN":"NO")+
                    "\nSHA-256  "+hex.toString();
            application.getSharedPreferences(CLIP_RECEIPTS,MODE_PRIVATE).edit().putString(RECEIPT_LATEST,receipt).apply();
        }catch(Exception ex){android.util.Log.w("DUWM-CAM","Capture fingerprint unavailable",ex);}},"duwm1721-private-mp4-sha256").start();
    }
    private void updateProfile(){
        int shortEdge=qualityIndex==0?720:1080;outputW=ratioIndex==1?(qualityIndex==0?1280:1920):shortEdge;
        outputH=ratioIndex==0?(qualityIndex==0?800:1200):ratioIndex==1?shortEdge:(qualityIndex==0?1280:1920);
        outputFps=30;outputBitrate=qualityIndex==0?8_000_000:16_000_000;applyRequestedCaptureMode();
    }
    private String profileLabel(){return ratioName()+"  •  "+outputW+"×"+outputH+" BROADCAST  •  "+outputFps+" FPS REQUEST";}
    private void switchRatio(){if(recording||pendingGallerySave){note("Stop recording first");return;}
        final String[] choices={"9:10","16:9","9:16"};new AlertDialog.Builder(this).setTitle("Broadcast aspect ratio").setSingleChoiceItems(choices,ratioIndex,(dialog,index)->{
            ratioIndex=index;cameraEngineMode=0;getSharedPreferences(VIDEO_SETTINGS,MODE_PRIVATE).edit().putInt(KEY_RATIO,index).apply();updateProfile();viewfinder.setRatio(outputW/(float)outputH);
            aspectButton.setText(ratioName());recordingProfile.setText(profileLabel());setRequestedOrientation(index==1?ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE:ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
            if(camera!=null){releaseCamera();openCamera();}applyViewfinderAspect();dialog.dismiss();}).show();}
    private void switchQuality(){
        if(recording||pendingGallerySave){note("Stop recording before changing quality");return;}
        cameraEngineMode=0;
        qualityIndex=1-qualityIndex;
        getSharedPreferences(VIDEO_SETTINGS,MODE_PRIVATE).edit().putInt(KEY_QUALITY,qualityIndex).apply();
        updateProfile();if(qualityButton!=null)qualityButton.setText("QUALITY / "+(qualityIndex==0?"HD":"PRO"));
        if(recordingProfile!=null)recordingProfile.setText(profileLabel());
        if(camera!=null){releaseCamera();openCamera();}
        note(qualityIndex==1?"PRO requests higher resolution and needs a capable device":"HD uses a lighter encoding profile");
    }
    private boolean hasAdequateCameraSource(){
        int wantedWidth=cameraEngineMode==1?3840:qualityIndex==0?1280:1920;
        int wantedHeight=cameraEngineMode==1?2160:qualityIndex==0?720:1080;
        return nativeVideoW>=wantedWidth&&nativeVideoH>=wantedHeight;
    }
    private void setDuration(){if(recording)return;final String[] options={"15 seconds","30 seconds","60 seconds","3 minutes","5 minutes"};final int[] seconds={15,30,60,180,300};new AlertDialog.Builder(this).setTitle("Maximum video length").setItems(options,(d,w)->{limitSeconds=seconds[w];recordButton.setText("● REC");}).show();}
    private void toggleRecording(){if(recording){stopRecording(true);return;}if(pendingGallerySave){note("Previous recording is saving");return;}if(camera==null){note("Camera not ready");return;}
        if(Duwm1724GalleryPublisher.needsLegacyPermission(this)){requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},REQ_LEGACY_GALLERY);return;}
        if(!hasAdequateCameraSource()||!codecSupports(nativeVideoW,nativeVideoH,outputFps)){note("Selected profile is not supported. Choose HD or another exposed camera; no quality is faked.");return;}
        if(audioEnabled.isChecked()&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_CAMERA);note("Allow microphone, then press Record. Silent recording can be selected in settings.");return;}
        if(preciseLocation.isChecked())new AlertDialog.Builder(this).setTitle("Record location alongside video?").setMessage("Exact sensor location will be saved privately as a sidecar. Disclosure in the broadcast is a separate choice. The clean camera master contains no graphic labels.").setNegativeButton("CANCEL",null).setPositiveButton("RECORD",(d,w)->startRecording()).show();else startRecording();
    }
    private String compass(){return heading>=0f && lastHeadingAt>0L && SystemClock.elapsedRealtime()-lastHeadingAt<20000L?String.format(Locale.US,"%.0f°",heading):"UNAVAILABLE";}
    private String gpsAccuracy(){Location l=lastLocation;return locationFresh(l)&&l.hasAccuracy()?String.format(Locale.US,"±%.0f m",l.getAccuracy()):"UNAVAILABLE";}
    private String sourceWeather(){
        if(weatherReceivedAt==0L)return weather;
        long age=SystemClock.elapsedRealtime()-weatherReceivedAt;
        Location l=lastLocation;
        if(age<0L||age>1800000L)return "MODEL WX STALE (RE-FETCH)";
        if(locationFresh(l)&&(Math.abs(l.getLatitude()-weatherLat)>0.25||Math.abs(l.getLongitude()-weatherLon)>0.25))return "MODEL WX FOR DIFFERENT PLACE";
        return weather;
    }
    private String readiness(){
        String cameraState=camera!=null&&decodedFrameAt>0&&SystemClock.elapsedRealtime()-decodedFrameAt<3000?"READY":"UNAVAILABLE";
        String mic=audioEnabled.isChecked()?(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED?"ON / PERMITTED":"PERMISSION REQUIRED"):"OFF";
        String gps=preciseLocation.isChecked()?(locationFresh(lastLocation)?"ON / SENSOR "+gpsAccuracy():"ON / WAITING FOR FRESH SENSOR"):"WITHHELD";
        return "CAMERA  "+cameraState+"\nVIDEO  "+profileLabel()+"\nINPUT  "+actualSourceWidth+"×"+actualSourceHeight+" (native video size)\nGALLERY  Movies / "+Duwm1724GalleryPublisher.ALBUM+"\nMICROPHONE  "+mic+"\nPRECISE GPS  "+gps+"\nDEVICE COMPASS  "+compass()+"\nWEATHER  "+sourceWeather()+"\nREPORTER / PLACE / SITUATION  SELF-REPORTED";
    }
    private void showReadiness(){new AlertDialog.Builder(this).setTitle("MONITORS CAM / Measured source status")
      .setMessage(readiness()+"\n\nAll exact coordinates remain off by default. Never record sensitive locations or people without appropriate safeguards.")
      .setPositiveButton("CLOSE",null).show();}
    private void editTeleprompter(){
        if(recording){note("Stop recording before changing the teleprompter script");return;}
        EditText input=new EditText(this);input.setText(prompterScript);input.setTextColor(TEXT);
        input.setHint("Paste reporter script");input.setHintTextColor(MUTED);
        input.setMinLines(4);input.setMaxLines(10);input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|
            android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        new AlertDialog.Builder(this).setTitle("Private reporter teleprompter")
            .setMessage("Script appears on the camera preview, not inside the exported MP4.")
            .setView(input).setNeutralButton("HIDE",(d,w)->{
                showPrompter=false;if(prompterDisplay!=null)prompterDisplay.setVisibility(View.GONE);
            }).setNegativeButton("CANCEL",null).setPositiveButton("SHOW",(d,w)->{
                prompterScript=input.getText().toString().trim();
                if(prompterScript.length()>4000)prompterScript=prompterScript.substring(0,4000);
                showPrompter=!prompterScript.isEmpty();prompterOffset=0;
                if(prompterDisplay!=null){prompterDisplay.setText(prompterScript);
                    prompterDisplay.setVisibility(showPrompter?View.VISIBLE:View.GONE);}
            }).show();
    }
    private void recordTelemetrySample(){
        if(!recording)return;
        long ms=SystemClock.elapsedRealtime()-startedAt;
        if(ms<0||ms-lastSampleElapsed<2000L||telemetrySamples.size()>=200)return;
        lastSampleElapsed=ms;
        // Label the sensor/provider data as measured at this time; unavailable stays unavailable.
        telemetrySamples.add(new Duwm1728TelemetryTimeline.Point(ms,
            new Duwm1728CaptureTelemetry.Snapshot(System.currentTimeMillis(),compass(),altitude(),
                gpsAccuracy(),sourceWeather(),coordinates(),bakedPrecise)));
    }
    private void startRecording(){
        microphonePeak=-1;microphoneSampleAt=-1;microphoneFailure="";captureFailure="";decodedFrameCount.set(0);
        if(camera==null||decodedFrameAt<0){note("Wait for a camera preview");return;}
        bakedReporter=reporterInput.getText().toString();bakedPlace=placeInput.getText().toString();bakedSituation=situationInput.getText().toString();bakedCategory=CATEGORIES[categoryIndex];bakedOverlay=REPORT_OVERLAYS[reportOverlayIndex];bakedPrecise=preciseLocation.isChecked();
        reporterInput.setEnabled(false);placeInput.setEnabled(false);situationInput.setEnabled(false);preciseLocation.setEnabled(false);audioEnabled.setEnabled(false);categoryControl.setEnabled(false);
        try{MonitorStore store=new MonitorStore(this);lastFile=store.createCaptureTarget();File output=store.mediaFile(lastFile);if(output==null)throw new IllegalStateException("Private recording target unavailable");
            camera.setPreviewCallbackWithBuffer(null);camera.unlock();recorderOwnsCamera=true;recorder=new MediaRecorder();recorder.setCamera(camera);applyRecorderAudio();
            recorder.setVideoSource(MediaRecorder.VideoSource.CAMERA);recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
            recorder.setVideoSize(nativeVideoW,nativeVideoH);recorder.setVideoFrameRate(outputFps);recorder.setVideoEncodingBitRate(outputBitrate);recorder.setOrientationHint(mediaRotation);
            if(audioEnabled.isChecked()){recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);recorder.setAudioEncodingBitRate(192000);recorder.setAudioSamplingRate(48000);}
            recorder.setOutputFile(output.getAbsolutePath());recorder.setMaxDuration(limitSeconds*1000);recorder.setOnInfoListener((r,what,extra)->{if(what==MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED)main.post(()->stopRecording(true));});
            recorder.setOnErrorListener((r,what,extra)->main.post(()->{captureFailure="Recorder error "+what;stopRecording(true);}));
            recorder.prepare();recorder.start();startedAt=SystemClock.elapsedRealtime();recordedFrames=0;sourceFrames.set(0);telemetrySamples.clear();lastSampleElapsed=-2000;recording=true;
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);recordTelemetrySample();main.removeCallbacks(prompterScroll);if(showPrompter)main.post(prompterScroll);recordButton.setText("■ STOP");indicator.setText("REC • CLEAN MASTER / AUDIO "+(audioEnabled.isChecked()?"ON":"OFF"));
        }catch(Exception e){captureFailure=safe(e);cleanupRecorder();new MonitorStore(this).discardMedia(lastFile);lastFile="";unlockInputs();releaseCamera();openCamera();note("Recording could not start: "+safe(e));}
    }
    private void unlockInputs(){reporterInput.setEnabled(true);placeInput.setEnabled(true);situationInput.setEnabled(true);preciseLocation.setEnabled(true);audioEnabled.setEnabled(true);if(categoryControl!=null)categoryControl.setEnabled(true);}
    private String safe(Exception ex){String s=ex.getMessage();return TextUtils.isEmpty(s)?ex.getClass().getSimpleName():s;}
    
    
    private String shortText(String value,int max){if(value==null||value.trim().isEmpty())return "NOT PROVIDED";String s=value.replace('\n',' ').trim();return s.length()>max?s.substring(0,Math.max(1,max-1))+"…":s;}
    private String utc(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date());}
    private boolean locationFresh(Location l){return l!=null && (SystemClock.elapsedRealtimeNanos()-l.getElapsedRealtimeNanos())>=0L && (SystemClock.elapsedRealtimeNanos()-l.getElapsedRealtimeNanos())<120_000_000_000L;}
    private String coordinates(){if(!(recording?bakedPrecise:preciseLocation.isChecked()))return "WITHHELD";Location l=lastLocation;return !locationFresh(l)?"SENSOR MISSING / STALE":String.format(Locale.US,"%.5f, %.5f",l.getLatitude(),l.getLongitude());}
    private String altitude(){Location l=lastLocation;return (recording?bakedPrecise:preciseLocation.isChecked())&&locationFresh(l)&&l.hasAltitude()?String.format(Locale.US,"%.0f m",l.getAltitude()):"UNAVAILABLE";}
    private void displayTelemetry(){if(telemetry==null)return;recordTelemetrySample();telemetry.setText("UTC "+utc()+"\nGPS  "+coordinates()+"\nALT  "+altitude()+"  /  DEVICE COMPASS  "+compass()+"\n"+sourceWeather());
        if(recording){long secs=(SystemClock.elapsedRealtime()-startedAt)/1000;
            String level="MIC OFF";
            if(audioEnabled.isChecked()&&recorder!=null){try{
                int amplitude=recorder.getMaxAmplitude();
                microphonePeak=amplitude;microphoneSampleAt=SystemClock.elapsedRealtime();microphoneFailure="";
                float db=amplitude<=0?-90f:(float)(20.0*Math.log10(amplitude/32767.0));
                level=String.format(Locale.US,"MIC %.0f dBFS",Math.max(-90f,db));
            }catch(RuntimeException ex){microphoneFailure=safe(ex);level="MIC LEVEL UNAVAILABLE";}}
            double measuredFps=1000.0*sourceFrames.get()/Math.max(1000L,SystemClock.elapsedRealtime()-startedAt);
            String quality=secs>=3 && measuredFps<outputFps*0.70?" / SOURCE FPS LOW":"";
            indicator.setText(String.format(Locale.US,"● REC %d/%ds • %s • VIEWFINDER %.1f fps / %.0f target%s",secs,limitSeconds,level,measuredFps,(double)outputFps,quality));
            if(secs>=limitSeconds)stopRecording(true);}}
    private void stopRecording(boolean keep){if(!recording)return;recordTelemetrySample();recording=false;main.removeCallbacks(prompterScroll);ScheduledExecutorService clock=videoClock;videoClock=null;if(clock!=null)clock.shutdownNow();boolean valid=false;
        synchronized(surfaceLock){try{if(recorder!=null){recorder.stop();valid=true;}}catch(RuntimeException ex){android.util.Log.e("DUWM-CAM","Recorder output incomplete",ex);}cleanupRecorder();}
        unlockInputs();recordButton.setText("● REC");indicator.setText(valid?"● VIDEO SAVED / PRIVATE DRAFT":"● VIDEO ERROR / RETRY");File f=new MonitorStore(this).mediaFile(lastFile);if(!keep||!valid||f==null||f.length()<1024){new MonitorStore(this).discardMedia(lastFile);lastFile="";if(keep){galleryResult=-1;galleryMessage="No complete MP4 was produced; no Gallery success is claimed.";note("Video not completed; please retry");}refreshCaptureHealth();return;}
        // Keep the original private capture and the World Monitor draft route.
        // Copy a SECOND completed MP4 into the user-visible phone Gallery.
        saveCaptureReceipt(f,lastFile,Math.max(0L,SystemClock.elapsedRealtime()-startedAt),recordedFrames,bakedCategory,bakedPrecise);
        // Snapshot the *capture-end* readings before the asynchronous Gallery export.
        // This is NOT a continuous time series and cannot be described as per-frame GPS.
        final Duwm1728CaptureTelemetry.Snapshot captureEnd=new Duwm1728CaptureTelemetry.Snapshot(
            System.currentTimeMillis(),compass(),altitude(),gpsAccuracy(),sourceWeather(),coordinates(),bakedPrecise);
        pendingGallerySave=true;galleryResult=0;galleryMessage="";refreshCaptureHealth();indicator.setText("● COMPLETED MP4 / SAVING TO PHONE GALLERY");
        final String savedFile=lastFile;
        final java.util.List<Duwm1728TelemetryTimeline.Point> capturedTrack=new java.util.ArrayList<>(telemetrySamples);
        final String galleryName="DUWM_MASTER_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".mp4";
        new Thread(()->{
            Uri gallery=null;String message;
            try{
                MediaMetadataRetriever verify=new MediaMetadataRetriever();
                try{verify.setDataSource(f.getAbsolutePath());
                    String duration=verify.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                    if(duration==null || Long.parseLong(duration)<500L)throw new IllegalStateException("Unplayable MP4 duration");
                } finally {verify.release();}
                gallery=Duwm1724GalleryPublisher.publish(getApplicationContext(),f,galleryName);
                message="MP4 saved to your phone Gallery / Movies / "+Duwm1724GalleryPublisher.ALBUM;
            }catch(Exception e){
                android.util.Log.e("DUWM-CAM","Gallery copy failed; private recording retained",e);
                message="Video saved as private draft. Gallery copy failed: "+safe(e);
            }
            final Uri savedUri=gallery;final String result=message;
            main.post(()->{
                pendingGallerySave=false;
                galleryResult=savedUri!=null?1:-1;galleryCompletedAt=SystemClock.elapsedRealtime();galleryMessage=result;
                refreshCaptureHealth();
                if(savedUri!=null){
                    getSharedPreferences(VIDEO_SETTINGS,MODE_PRIVATE).edit()
                       .putString("last_gallery_uri",savedUri.toString()).apply();
                    Duwm1726GalleryIndex.add(getApplicationContext(),savedUri,galleryName);
                    Duwm1728CaptureTelemetry.save(getApplicationContext(),savedUri,captureEnd);
                    Duwm1728TelemetryTimeline.save(getApplicationContext(),savedUri,capturedTrack);
                }
                Toast.makeText(getApplicationContext(),result,Toast.LENGTH_LONG).show();
                if(closed||isFinishing()||!cameraUiActive)return;
                Intent next=new Intent(this,Duwm1728VideoEditorActivity.class);
                next.putExtra("duwm1718_camera_file",savedFile);
                Uri reviewUri=savedUri!=null?savedUri:Uri.fromFile(f);
                Duwm1728CaptureTelemetry.save(getApplicationContext(),reviewUri,captureEnd);
                Duwm1728TelemetryTimeline.save(getApplicationContext(),reviewUri,capturedTrack);
                next.putExtra(Duwm1728VideoEditorActivity.EXTRA_VIDEO_URI,reviewUri.toString());
                next.putExtra("clean_master",true);next.putExtra("broadcast_ratio",ratioName());
                next.putExtra("reporter",bakedReporter);next.putExtra("place",bakedPlace);next.putExtra("notes",bakedSituation);
                next.putExtra("report_category",bakedCategory);
                if(savedUri!=null)next.putExtra("duwm1724_gallery_uri",savedUri.toString());
                next.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(next);finish();
            });
        },"duwm1724-gallery-export").start();
    }
    private void cleanupRecorder(){if(recorder!=null){try{recorder.reset();}catch(Exception ignored){}try{recorder.release();}catch(Exception ignored){}}recorder=null;recorderSurface=null;if(recorderOwnsCamera&&camera!=null)try{camera.lock();}catch(Exception ignored){}recorderOwnsCamera=false;}
    private void releaseCamera(){cameraSessionGeneration++;decodedFrameAt=-1L;
        synchronized(surfaceLock){Bitmap old=latest.getAndSet(null);if(old!=null&&!old.isRecycled())old.recycle();}
        if(camera!=null){try{camera.setPreviewCallbackWithBuffer(null);camera.stopPreview();}catch(Exception ignored){}try{camera.release();}catch(Exception ignored){}camera=null;}}
    private void requestLocation(){if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQ_LOCATION);return;}try{locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1800L,0f,gpsListener);locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,2500L,0f,gpsListener);locationActive=true;Location last=locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);if(last!=null)lastLocation=last;}catch(SecurityException | IllegalArgumentException e){note("Location sensors unavailable");}}
    private void stopLocation(){weatherGeneration++;weatherRequested=false;weatherLoading=false;weatherFailure="";if(locationActive)try{locationManager.removeUpdates(gpsListener);}catch(Exception ignored){}locationActive=false;lastLocation=null;weather="MODEL WX NOT REQUESTED";weatherReceivedAt=0L;}
    private void fetchWeather(){
        if(!preciseLocation.isChecked()||!locationFresh(lastLocation)){
            note("Enable optional GPS and obtain a sensor reading before weather lookup");return;
        }
        long now=SystemClock.elapsedRealtime();
        if(weatherLoading || (lastWeatherAt>0L && now-lastWeatherAt<60000L)){
            note("Wait before fetching model data again");return;
        }
        lastWeatherAt=now;final double lat=lastLocation.getLatitude(),lon=lastLocation.getLongitude();
        final int generation=++weatherGeneration;weatherRequested=true;weatherLoading=true;weatherFailure="";
        weather="FETCHING MODEL WX…";weatherReceivedAt=0L;refreshCaptureHealth();
        new Thread(()->{
            String result="MODEL WX UNAVAILABLE",error="";boolean success=false;HttpURLConnection conn=null;
            try{
                String address=String.format(Locale.US,"https://api.open-meteo.com/v1/forecast?latitude=%.5f&longitude=%.5f&current=temperature_2m,wind_speed_10m,weather_code&timezone=UTC",lat,lon);
                conn=(HttpURLConnection)new URL(address).openConnection();conn.setConnectTimeout(7000);conn.setReadTimeout(7000);
                if(conn.getResponseCode()!=200)throw new IllegalStateException("Weather HTTP "+conn.getResponseCode());
                try(InputStream in=conn.getInputStream();ByteArrayOutputStream bytes=new ByteArrayOutputStream()){
                    byte[] buffer=new byte[4096];int n;
                    while((n=in.read(buffer))>=0){if(bytes.size()+n>22000)throw new IllegalStateException("Unexpected weather data size");bytes.write(buffer,0,n);}
                    JSONObject wx=new JSONObject(bytes.toString("UTF-8")).getJSONObject("current");
                    result=String.format(Locale.US,"Open-Meteo MODEL %.1f°C WIND %.0f km/h",wx.getDouble("temperature_2m"),wx.getDouble("wind_speed_10m"));success=true;
                }
            }catch(Exception e){error=safe(e);android.util.Log.w("DUWM-CAM","Weather model unavailable",e);}
            finally{if(conn!=null)conn.disconnect();}
            final String accepted=result,failure=error;final boolean received=success;
            main.post(()->{
                if(closed||generation!=weatherGeneration||!preciseLocation.isChecked())return;
                weatherLoading=false;weatherFailure=failure;weather=accepted;
                if(received){weatherLat=lat;weatherLon=lon;weatherReceivedAt=SystemClock.elapsedRealtime();}
                refreshCaptureHealth();
            });
        },"duwm172827-opt-in-weather").start();
    }
    private void refreshCaptureHealth(){
        if(closed||!cameraUiActive||captureHealthDock==null)return;
        Duwm1728CaptureHealth.Input in=new Duwm1728CaptureHealth.Input();
        in.now=SystemClock.elapsedRealtime();
        in.cameraPermission=checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED;
        in.cameraOpen=camera!=null;in.frameAt=decodedFrameAt;in.cameraError=captureFailure;
        in.recording=recording;in.adequateResolution=hasAdequateCameraSource();in.targetFps=outputFps;
        if(recording){in.recordingMs=Math.max(0L,in.now-startedAt);in.sourceFps=1000d*decodedFrameCount.get()/Math.max(1000L,in.recordingMs);}
        in.microphoneEnabled=audioEnabled!=null&&audioEnabled.isChecked();
        in.microphonePermission=checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED;
        in.microphonePeak=microphonePeak;in.microphoneAt=microphoneSampleAt;in.microphoneError=microphoneFailure;
        in.gpsOptIn=preciseLocation!=null&&preciseLocation.isChecked();
        in.gpsPermission=checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
        if(in.gpsOptIn&&in.gpsPermission&&locationManager!=null){try{
            in.gpsProviderEnabled=locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)||locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        }catch(RuntimeException ignored){in.gpsProviderEnabled=false;}}
        Location location=lastLocation;
        if(in.gpsOptIn&&location!=null){
            long age=SystemClock.elapsedRealtimeNanos()-location.getElapsedRealtimeNanos();
            if(location.getElapsedRealtimeNanos()>0L && age>=0L)in.gpsAgeMs=age/1_000_000L;
            if(location.hasAccuracy())in.gpsAccuracy=location.getAccuracy();
            in.mockLocation=location.isFromMockProvider();
        }
        in.compassPresent=sensorManager!=null&&sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)!=null;
        in.compassAt=lastHeadingAt>0L?lastHeadingAt:-1L;in.compassAccuracy=compassAccuracy;
        in.weatherRequested=weatherRequested;in.weatherLoading=weatherLoading;in.weatherError=weatherFailure;
        in.weatherAt=weatherReceivedAt>0L?weatherReceivedAt:-1L;
        if(locationFresh(location))in.weatherPlaceMatches=Math.abs(location.getLatitude()-weatherLat)<=.25&&Math.abs(location.getLongitude()-weatherLon)<=.25;
        in.gallerySaving=pendingGallerySave;in.galleryResult=galleryResult;
        in.galleryAt=galleryCompletedAt;in.galleryMessage=galleryMessage;
        captureHealthDock.update(in);
    }
    private void note(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    @Override public void onRequestPermissionsResult(int r,String[] perms,int[] grants){super.onRequestPermissionsResult(r,perms,grants);if(r==REQ_CAMERA){
            for(int i=0;i<perms.length;i++)if(Manifest.permission.RECORD_AUDIO.equals(perms[i]) && (i>=grants.length||grants[i]!=PackageManager.PERMISSION_GRANTED)){
                audioEnabled.setChecked(false);note("Microphone denied: next recording will be silent unless you enable it in Settings.");}
            if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)openCamera();}if(r==REQ_LOCATION&&grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED)requestLocation();else if(r==REQ_LOCATION){preciseLocation.setChecked(false);note("Coordinates will remain withheld");}}
    @Override public void onSurfaceTextureAvailable(SurfaceTexture surface,int width,int height){openCamera();}
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture surface,int w,int h){applyViewfinderAspect();}
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture surface){if(recording)stopRecording(true);releaseCamera();return true;}
    @Override public void onSurfaceTextureUpdated(SurfaceTexture surface){decodedFrameAt=SystemClock.elapsedRealtime();if(recording){decodedFrameCount.incrementAndGet();sourceFrames.incrementAndGet();recordedFrames++;}}
    @Override public void onSensorChanged(SensorEvent event){if(event.sensor.getType()!=Sensor.TYPE_ROTATION_VECTOR)return;float[] matrix=new float[9],bearing=new float[3];SensorManager.getRotationMatrixFromVector(matrix,event.values);SensorManager.getOrientation(matrix,bearing);heading=(float)((Math.toDegrees(bearing[0])+360.0)%360.0);lastHeadingAt=SystemClock.elapsedRealtime();compassAccuracy=event.accuracy;}
    @Override public void onAccuracyChanged(Sensor sensor,int accuracy){if(sensor!=null&&sensor.getType()==Sensor.TYPE_ROTATION_VECTOR)compassAccuracy=accuracy;}
    @Override protected void onPause(){cameraUiActive=false;main.removeCallbacks(telemetryRefresh);main.removeCallbacks(prompterScroll);if(recording)stopRecording(true);releaseCamera();if(sensorManager!=null)sensorManager.unregisterListener(this);stopLocation();super.onPause();}
    @Override protected void onDestroy(){closed=true;main.removeCallbacks(telemetryRefresh);main.removeCallbacks(prompterScroll);if(videoClock!=null)videoClock.shutdownNow();frames.shutdownNow();cleanupRecorder();releaseCamera();super.onDestroy();}
}
