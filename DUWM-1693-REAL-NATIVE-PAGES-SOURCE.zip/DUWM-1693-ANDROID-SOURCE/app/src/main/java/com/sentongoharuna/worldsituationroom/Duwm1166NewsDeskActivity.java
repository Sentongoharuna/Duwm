package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.EditText;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** Source-backed regional news, each article opens and exports an original 9:16 PNG. */
public final class Duwm1166NewsDeskActivity extends Activity {
  private static final String[] GROUPS={"ALL","LOCAL","WORLDWIDE","WARS","ECONOMICS","WESTERN","MIDDLE EAST","AFRICA","INDIA"};
  private static final int BG=0xFF081824,CARD=0xFF0F4150,WHITE=0xFFDFEEF2,MUTED=0xFFBDCACD,ACCENT=0xFF47D2DB;
  private String category="ALL";private int page=0;private NewsAggregator engine;
  private String searchText="",publisherFilter="";private boolean oldestFirst=false,savedOnly=false,dayOnly=false,compactNews=false;private TextView orderControl,savedControl,dayControl,publisherControl;private Duwm1690EvidenceBars newsEvidence;
  private final Handler handler=new Handler(Looper.getMainLooper());
  private LinearLayout stories,filters;private TextView status;private boolean active=false;
  private int dp(float a){return (int)(a*getResources().getDisplayMetrics().density+.5f);}
  private TextView txt(String s,int sp,int color,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);
    if(bold)v.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));return v;}
  private GradientDrawable panel(int bg,int edge,int radius){GradientDrawable g=new GradientDrawable();g.setColor(bg);g.setStroke(dp(1),edge);g.setCornerRadius(dp(radius));return g;}
  private TextView action(String label,Runnable handler){TextView v=txt(label,12,ACCENT,true);v.setGravity(Gravity.CENTER);v.setMinimumHeight(dp(43));
    v.setPadding(dp(13),dp(8),dp(13),dp(8));v.setBackground(panel(CARD,0xFF185769,11));v.setOnClickListener(q->handler.run());return v;}
  private boolean saved(String url){return url!=null&&getSharedPreferences("duwm_news_bookmarks",MODE_PRIVATE).getBoolean(url,false);}
  private void toggleSaved(String url){if(url==null||!url.startsWith("https://"))return;
    getSharedPreferences("duwm_news_bookmarks",MODE_PRIVATE).edit().putBoolean(url,!saved(url)).apply();draw();}
  private static String time(long millis){if(millis<=0)return "PUBLISHER TIME NOT PROVIDED";
    SimpleDateFormat f=new SimpleDateFormat("dd MMM · HH:mm 'UTC'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(millis));}
  private static String region(String v){return v==null?"":v.toUpperCase(Locale.US);}
  private static boolean has(String text,String... needles){for(String n:needles)if(text.contains(n))return true;return false;}
  private boolean fits(NewsItem news){String text=(news.title+" "+news.summary+" "+news.sourceName+" "+news.region+" "+news.topic).toUpperCase(Locale.ROOT);
    String country=region(news.region);
    switch(category){
      case "LOCAL":return country.contains("UGANDA")||country.contains("KAMPALA")||country.contains("EAST_AFRICA");
      case "WARS":return has(text,"WAR","CONFLICT","AIRSTRIKE","CEASEFIRE","MILITARY","PEACE TALKS","DEFENCE","BATTLE");
      case "ECONOMICS":return has(text,"MARKET","BANK","ECONOM","FOREX","OIL PRICE","FINANCE","TRADE","INFLATION","BUSINESS","COMMODIT");
      case "WESTERN":return has(text,"UNITED STATES","WASHINGTON","CANADA","EUROPE","NATO","BRITAIN","UNITED KINGDOM","FRANCE","GERMANY");
      case "MIDDLE EAST":return has(text,"MIDDLE EAST","IRAN","ISRAEL","GAZA","LEBANON","SAUDI","QATAR","UAE","SYRIA","YEMEN","GULF");
      case "AFRICA":return has(text,"AFRICA","UGANDA","KENYA","TANZANIA","NIGERIA","RWANDA","SUDAN","ETHIOPIA","CONGO","SOUTH AFRICA");
      case "INDIA":return has(text,"INDIA","DELHI","MUMBAI","BENGALURU","HINDUSTAN","CHENNAI");
      case "WORLDWIDE":return true;
      default:return true;
    }
  }
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    engine=new NewsAggregator(this);ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(BG);setContentView(sc);Duwm1167SafeArea.install(this,sc);
    LinearLayout root=new LinearLayout(this);root.setPadding(dp(12),dp(15),dp(12),dp(24));root.setOrientation(LinearLayout.VERTICAL);sc.addView(root);
    root.addView(txt("DEVELOP.UGANDA  /  WORLD NEWS",12,ACCENT,true));root.addView(Duwm1693Chrome.title(txt("INTELLIGENCE WIRE  /  1693",24,WHITE,true)));
    root.addView(txt("SOURCE-ATTRIBUTED REPORTS  •  9:16 SHARE IMAGES  •  REAL PUBLISHER DATES",10,MUTED,false));
    LinearLayout commands=new LinearLayout(this);commands.setPadding(0,dp(10),0,dp(9));root.addView(commands);
    commands.addView(action("‹ BACK",this::finish),new LinearLayout.LayoutParams(0,dp(43),1));
    TextView refresh=action("REFRESH FEEDS",this::refresh);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,dp(43),1);rp.leftMargin=dp(9);commands.addView(refresh,rp);
    TextView add=action("+ ADD PUBLIC SITE",()->startActivity(new Intent(this,Duwm1166CustomFeedActivity.class)));
    LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(45));ap.bottomMargin=dp(9);root.addView(add,ap);
    // Search the received stories themselves; typing never triggers fabricated headlines or a network query.
    EditText search=new EditText(this);search.setSingleLine(true);search.setTextColor(WHITE);search.setHintTextColor(MUTED);
    search.setTextSize(14);search.setHint("Search real headlines, publishers, countries and topics");
    search.setPadding(dp(13),0,dp(10),0);search.setBackground(panel(0xFF0E303E,0xFF185769,11));
    LinearLayout.LayoutParams findLp=new LinearLayout.LayoutParams(-1,dp(51));findLp.bottomMargin=dp(8);root.addView(search,findLp);
    LinearLayout sorting=new LinearLayout(this);sorting.setGravity(Gravity.CENTER_VERTICAL);root.addView(sorting);
    orderControl=action("NEWEST FIRST  ↓",()->{oldestFirst=!oldestFirst;page=0;draw();});
    sorting.addView(orderControl,new LinearLayout.LayoutParams(0,dp(44),1));
    TextView clear=action("CLEAR SEARCH",()->{search.setText("");category="ALL";publisherFilter="";savedOnly=false;dayOnly=false;page=0;draw();});
    LinearLayout.LayoutParams clearLp=new LinearLayout.LayoutParams(0,dp(44),1);clearLp.leftMargin=dp(8);sorting.addView(clear,clearLp);
    publisherControl=action("PUBLISHER: ALL  /  TAP TO SELECT",()->{
      java.util.LinkedHashSet<String> sources=new java.util.LinkedHashSet<>();
      for(NewsItem item:new NewsStore(this).load())if(item!=null&&item.sourceName!=null&&!item.sourceName.trim().isEmpty())sources.add(item.sourceName.trim());
      ArrayList<String> choices=new ArrayList<>(sources);Collections.sort(choices,String.CASE_INSENSITIVE_ORDER);
      if(choices.isEmpty()){publisherFilter="";}else{int at=choices.indexOf(publisherFilter);publisherFilter=at<0?choices.get(0):at==choices.size()-1?"":choices.get(at+1);}
      page=0;draw();});
    LinearLayout.LayoutParams publisherLp=new LinearLayout.LayoutParams(-1,dp(44));publisherLp.topMargin=dp(7);root.addView(publisherControl,publisherLp);
    savedControl=action("☆ SAVED ONLY",()->{savedOnly=!savedOnly;page=0;draw();});
    LinearLayout.LayoutParams savedLp=new LinearLayout.LayoutParams(-1,dp(43));savedLp.topMargin=dp(7);root.addView(savedControl,savedLp);
    search.addTextChangedListener(new TextWatcher(){
      @Override public void beforeTextChanged(CharSequence s,int st,int count,int after){}
      @Override public void onTextChanged(CharSequence s,int st,int before,int count){searchText=s.toString().trim().toLowerCase(Locale.ROOT);page=0;draw();}
      @Override public void afterTextChanged(Editable e){}
    });
    status=txt("Waiting for received publisher records",12,MUTED,false);status.setPadding(0,dp(8),0,dp(10));root.addView(status);
    newsEvidence=new Duwm1690EvidenceBars(this);
    root.addView(newsEvidence,new LinearLayout.LayoutParams(-1,dp(226)));
    TextView layoutMode=action("READING LAYOUT  /  EXPANDED IMAGE STORIES",()->{compactNews=!compactNews;page=0;draw();});
    LinearLayout.LayoutParams layoutLp=new LinearLayout.LayoutParams(-1,dp(45));layoutLp.topMargin=dp(7);root.addView(layoutMode,layoutLp);
    layoutMode.setOnClickListener(v->{compactNews=!compactNews;layoutMode.setText(compactNews?"READING LAYOUT  /  COMPACT SOURCE WIRE":"READING LAYOUT  /  EXPANDED IMAGE STORIES");page=0;draw();});
    dayControl=action("ALL PUBLISHER DATES  /  TAP FOR LAST 24H",()->{dayOnly=!dayOnly;page=0;draw();});
    LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(-1,dp(43));dlp.topMargin=dp(7);root.addView(dayControl,dlp);
    HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setHorizontalScrollBarEnabled(false);root.addView(scroll);
    filters=new LinearLayout(this);filters.setOrientation(LinearLayout.HORIZONTAL);scroll.addView(filters);
    stories=new LinearLayout(this);stories.setOrientation(LinearLayout.VERTICAL);root.addView(stories);
    draw();refresh();
  }
  @Override public void onStart(){super.onStart();active=true;draw();}
  @Override public void onStop(){active=false;super.onStop();}
  @Override public void onDestroy(){if(engine!=null)engine.shutdown();super.onDestroy();}
  private void refresh(){status.setText("REQUESTING PUBLIC RSS / ATOM / JSON SOURCE RECORDS");
    engine.refresh((items,working)->runOnUiThread(()->{if(!active||isFinishing())return;status.setText(working+" SOURCE RESPONSES RECEIVED  •  "+items.size()+" CACHED RECORDS  •  "+time(System.currentTimeMillis()));draw();}));
  }
  private void draw(){if(filters==null||stories==null)return;filters.removeAllViews();stories.removeAllViews();
    for(String c:GROUPS){TextView chip=action(c,()->{category=c;page=0;draw();});chip.setTextColor(c.equals(category)?WHITE:MUTED);
      chip.setBackground(panel(c.equals(category)?0xFF185769:0xFF0E404E,c.equals(category)?ACCENT:0xFF185769,12));
      LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,dp(43));cp.rightMargin=dp(6);filters.addView(chip,cp);}
    ArrayList<NewsItem> match=new ArrayList<>();long now=System.currentTimeMillis();for(NewsItem n:new NewsStore(this).load()){
      if(n==null||n.title==null||n.title.trim().length()<8||n.link==null||!n.link.startsWith("https://")||!fits(n)||(savedOnly&&!saved(n.link)))continue;
      if(dayOnly && (n.publishedAt<=0||n.publishedAt>now+300000L||now-n.publishedAt>86400000L))continue;
      if(!publisherFilter.isEmpty()&&!publisherFilter.equalsIgnoreCase(n.sourceName==null?"":n.sourceName.trim()))continue;
      if(!searchText.isEmpty() && !(n.title+" "+n.summary+" "+n.sourceName+" "+n.region+" "+n.topic).toLowerCase(Locale.ROOT).contains(searchText))continue;
      match.add(n);
    }
    Collections.sort(match,(a,b)->oldestFirst?Long.compare(a.publishedAt,b.publishedAt):Long.compare(b.publishedAt,a.publishedAt));
    if(orderControl!=null)orderControl.setText(oldestFirst?"OLDEST FIRST  ↑":"NEWEST FIRST  ↓");
    if(publisherControl!=null)publisherControl.setText("PUBLISHER: "+(publisherFilter.isEmpty()?"ALL RECEIVED SOURCES":publisherFilter)+"  /  TAP TO CHANGE");
    if(savedControl!=null)savedControl.setText(savedOnly?"★ VIEWING SAVED REPORTS  /  TAP FOR ALL":"☆ SAVED REPORTS  /  TAP TO FILTER");
    if(dayControl!=null)dayControl.setText(dayOnly?"LAST 24H  /  VERIFIED PUBLISHER TIMES":"ALL PUBLISHER DATES  /  TAP FOR LAST 24H");
    if(newsEvidence!=null){int local=0,hasImage=0,recent=0,savedCount=0;
      for(NewsItem n:match){String r=region(n.region);
        if(r.contains("UGANDA")||r.contains("KAMPALA")||r.contains("EAST_AFRICA"))local++;
        if(n.imageUrl!=null&&n.imageUrl.startsWith("https://"))hasImage++;
        if(n.publishedAt>0&&n.publishedAt<=now+300000L&&now-n.publishedAt<=86400000L)recent++;
        if(saved(n.link))savedCount++;}
      newsEvidence.setValues("NEWS / FILTERED PUBLISHER REPORTS",
        new String[]{"MATCHING ARTICLES","PUBLISHED < 24H","IMAGE URL GIVEN","SAVED MATCHES"},
        new long[]{match.size(),recent,hasImage,savedCount});}
    if(match.size()>0 && page*18>=match.size())page=0;
    TextView heading=txt(category+"  /  "+match.size()+" RECEIVED STORIES  /  PAGE "+(match.isEmpty()?0:page+1)+" OF "+((match.size()+17)/18),14,ACCENT,true);heading.setPadding(0,dp(13),0,dp(6));stories.addView(heading);
    if(match.isEmpty()){TextView missing=txt("NO RECEIVED STORIES MATCH THE CURRENT SEARCH AND CATEGORY. Clear the search or refresh publisher feeds. No headlines have been invented.",13,MUTED,false);
      missing.setPadding(dp(15),dp(20),dp(15),dp(20));missing.setBackground(panel(CARD,0xFF185769,12));stories.addView(missing);return;}
    int from=page*18,to=Math.min(match.size(),from+18);
    for(int i=from;i<to;i++)addArticle(match.get(i),now);
    if(to<match.size()){TextView next=action("NEXT PAGE   •   "+(match.size()-to)+" MORE",()->{page++;draw();});stories.addView(next);}
    if(page>0){TextView back=action("PREVIOUS PAGE",()->{page--;draw();});stories.addView(back);}
  }
  private void addArticle(NewsItem n,long now){
    LinearLayout card=new LinearLayout(this);card.setPadding(dp(13),dp(12),dp(13),dp(13));card.setOrientation(LinearLayout.VERTICAL);card.setBackground(panel(CARD,0xFF185769,16));
    LinearLayout.LayoutParams outer=new LinearLayout.LayoutParams(-1,-2);outer.bottomMargin=dp(12);stories.addView(card,outer);
    LinearLayout meta=new LinearLayout(this);meta.setGravity(Gravity.CENTER_VERTICAL);card.addView(meta);
    Duwm1166SignalView led=new Duwm1166SignalView(this);long sourceTime=n.publishedAt,receiveTime=n.firstSeenAt;
    led.source("NEWS",sourceTime,receiveTime,false,false);
    meta.addView(led,new LinearLayout.LayoutParams(dp(25),dp(25)));
    TextView source=txt("  "+n.sourceName.toUpperCase(Locale.US)+"  /  "+n.region,10,ACCENT,true);meta.addView(source,new LinearLayout.LayoutParams(0,-2,1));
    TextView when=txt(time(n.publishedAt),10,MUTED,false);meta.addView(when);
    TextView title=txt(n.title,compactNews?16:19,WHITE,true);title.setPadding(0,dp(9),0,dp(10));card.addView(title);
    ImageView thumb=new ImageView(this);thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
    if(n.imageUrl!=null&&n.imageUrl.startsWith("https://")){card.addView(thumb,new LinearLayout.LayoutParams(-1,dp(compactNews?106:240)));NewsImageLoader.load(this,n.imageUrl,thumb);}
    else{TextView noImage=txt("◈  PUBLISHER IMAGE NOT PROVIDED  •  SOURCE-TEXT CARD AVAILABLE",10,MUTED,true);
      noImage.setGravity(Gravity.CENTER);noImage.setBackground(panel(0xFF081824,0xFF185769,9));card.addView(noImage,new LinearLayout.LayoutParams(-1,dp(48)));}
    if(!compactNews&&n.summary!=null&&!n.summary.isEmpty()){TextView summary=txt(n.summary,12,MUTED,false);summary.setMaxLines(4);summary.setPadding(0,dp(8),0,dp(12));card.addView(summary);}
    TextView bookmark=action(saved(n.link)?"★ SAVED  /  TAP TO REMOVE":"☆ SAVE THIS REPORT",()->toggleSaved(n.link));
    bookmark.setContentDescription("Save or unsave received article from "+n.sourceName);
    LinearLayout.LayoutParams bookmarkLp=new LinearLayout.LayoutParams(-1,dp(41));bookmarkLp.bottomMargin=dp(7);card.addView(bookmark,bookmarkLp);
    LinearLayout row=new LinearLayout(this);card.addView(row);
    TextView read=action("READ / PLAY IN APP",()->{Intent i=new Intent(this,Duwm1166ArticleActivity.class);i.putExtra("url",n.link);i.putExtra("title",n.title);startActivity(i);});
    row.addView(read,new LinearLayout.LayoutParams(0,dp(46),1));
    TextView share=action("SHARE 9:16 IMAGE",()->Duwm1166PortraitCard.share(this,n,category,thumb));
    LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(46),1);sp.leftMargin=dp(7);row.addView(share,sp);
  }
}
