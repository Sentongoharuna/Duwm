from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
pkg=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
app=(pkg/'DuWorldApplication.java').read_text()
full=(pkg/'Duwm1683FullScreen.java').read_text()
kit=(pkg/'Duwm1683DeskDetailKit.java').read_text()
opts=(pkg/'DuwmOptionsActivity.java').read_text()
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
activities={a.get(ns+'name','') for a in manifest.iter('activity')}
assert '.Duwm1683DeskFullScreenActivity' in activities
assert 'Duwm1683FullScreen.install(this)' in app
assert 'Duwm1683DeskCatalog.find(a)!=null' in full
assert 'a instanceof MainActivity' in full
assert 'FLAG_FULLSCREEN' in full
assert 'Duwm1683DeskFullScreenActivity.class' in kit
assert 'AlertDialog.Builder' not in kit
assert 'FULL SCREEN DETAILS' in opts
assert 'new SatelliteMapView(this)' in (pkg/'MainActivity.java').read_text()
assert 'versionCode = 168301' in (root/'app/build.gradle.kts').read_text()
media=(pkg/'MediaDeskActivity.java').read_text()
assert 'new LinearLayout.LayoutParams(-1,dp(270))' in media
marine=(pkg/'GevMarineActivity.java').read_text()
assert 'new LinearLayout.LayoutParams(-1,dp(440))' in marine
print('PASS: all 19 desks are full-height native activities, details use dedicated fullscreen activity, one original globe')
