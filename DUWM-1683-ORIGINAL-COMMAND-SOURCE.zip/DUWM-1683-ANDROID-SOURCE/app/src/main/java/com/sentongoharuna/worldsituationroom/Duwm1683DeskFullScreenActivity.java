package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Real, full-screen source-detail destination for all nineteen intelligence desks.
 * Data comes from the on-device receipt of its linked provider; unavailable stays unavailable.
 */
public final class Duwm1683DeskFullScreenActivity extends Activity {
    public static final String EXTRA_DESK_INDEX="duwm1683_desk_index";
    private Duwm1683DeskCatalog.Desk desk;
    private TextView receipt,provider;
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView label(String value,int size,int color,boolean bold){
        TextView v=new TextView(this);v.setText(value);v.setTextColor(color);v.setTextSize(size);
        if(bold)v.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        v.setPadding(dp(7),dp(7),dp(7),dp(7));return v;
    }
    private GradientDrawable panel(){
        GradientDrawable d=new GradientDrawable();d.setColor(DuwmUnifiedTheme.PANEL);
        d.setCornerRadius(dp(10));d.setStroke(dp(1),DuwmUnifiedTheme.BORDER);return d;
    }
    private TextView action(String value,Runnable fn){
        TextView t=label(value,12,DuwmUnifiedTheme.ACCENT_BRIGHT,true);
        t.setGravity(Gravity.CENTER);t.setBackground(panel());t.setOnClickListener(v->fn.run());return t;
    }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        int index=getIntent().getIntExtra(EXTRA_DESK_INDEX,-1);
        if(index<0 || index>=Duwm1683DeskCatalog.ALL.length){finish();return;}
        desk=Duwm1683DeskCatalog.ALL[index];
        LinearLayout screen=new LinearLayout(this);screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(DuwmUnifiedTheme.BACKGROUND);setContentView(screen);
        LinearLayout toolbar=new LinearLayout(this);toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(9),dp(4),dp(9),dp(4));screen.addView(toolbar,new LinearLayout.LayoutParams(-1,dp(52)));
        toolbar.addView(action("‹ BACK",this::finish),new LinearLayout.LayoutParams(dp(86),-1));
        TextView name=label(desk.title.toUpperCase(java.util.Locale.US),15,DuwmUnifiedTheme.TEXT,true);
        name.setMaxLines(1);name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        toolbar.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        toolbar.addView(action("OPEN",()->startActivity(Duwm1683DeskCatalog.intent(this,desk))),new LinearLayout.LayoutParams(dp(80),-1));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);screen.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(13),dp(8),dp(13),dp(20));scroll.addView(body);
        TextView category=label(desk.category+"  /  SOURCE DETAILS",11,DuwmUnifiedTheme.ACCENT,true);body.addView(category);
        body.addView(label(desk.subtitle,15,DuwmUnifiedTheme.TEXT,true));
        receipt=label("CHECKING RECEIVED SOURCE",15,DuwmUnifiedTheme.ACCENT_BRIGHT,true);receipt.setBackground(panel());
        LinearLayout.LayoutParams recLp=new LinearLayout.LayoutParams(-1,-2);recLp.topMargin=dp(12);body.addView(receipt,recLp);
        TextView details=label("INFORMATION AVAILABLE",12,DuwmUnifiedTheme.ACCENT,true);details.setPadding(0,dp(20),0,dp(5));body.addView(details);
        body.addView(label(desk.description,15,DuwmUnifiedTheme.TEXT,false));
        body.addView(label("INTERPRETATION & COVERAGE",12,DuwmUnifiedTheme.ACCENT,true));
        body.addView(label(desk.howToRead,14,DuwmUnifiedTheme.TEXT,false));
        body.addView(label("PROVIDER / RECEIPTS / LAST ERROR",12,DuwmUnifiedTheme.ACCENT,true));
        provider=label("Waiting for latest local receipt",13,DuwmUnifiedTheme.MUTED,false);
        provider.setBackground(panel());body.addView(provider);
        LinearLayout row=new LinearLayout(this);LinearLayout.LayoutParams rowLp=new LinearLayout.LayoutParams(-1,dp(48));rowLp.topMargin=dp(15);body.addView(row,rowLp);
        row.addView(action("SOURCE HEALTH",()->startActivity(new Intent(this,Duwm1671SourceStatusActivity.class))),new LinearLayout.LayoutParams(0,-1,1));
        TextView share=action("SHARE",this::share);
        LinearLayout.LayoutParams shareLp=new LinearLayout.LayoutParams(0,-1,1);shareLp.leftMargin=dp(8);row.addView(share,shareLp);
        body.addView(label("All provider figures, position histories and capture times are source-dependent. A cached record is not a fresh observation.",12,DuwmUnifiedTheme.MUTED,false));
        updateReceipt();
    }
    private void updateReceipt(){
        if(desk==null)return;
        receipt.setText(Duwm1683DeskCatalog.status(this,desk));
        provider.setText(Duwm1683DeskCatalog.fullStatus(this,desk));
    }
    @Override protected void onResume(){super.onResume();if(receipt!=null)updateReceipt();}
    private void share(){
        Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT,"DUWM / "+desk.title+"\n"+desk.description+"\n"+
            Duwm1683DeskCatalog.fullStatus(this,desk)+"\n"+desk.howToRead);
        startActivity(Intent.createChooser(send,"Share source details"));
    }
}
