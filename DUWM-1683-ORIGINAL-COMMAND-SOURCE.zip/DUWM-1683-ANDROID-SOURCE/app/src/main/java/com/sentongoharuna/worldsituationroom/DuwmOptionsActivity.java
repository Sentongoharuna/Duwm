package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Locale;

/** 1683: a searchable, data-aware front door to EVERY original DUWM intelligence desk.
 * Opens individual existing activities, never places a second globe over MainActivity.
 */
public final class DuwmOptionsActivity extends Activity {
    private static final int BG=DuwmUnifiedTheme.BACKGROUND;
    private static final int WHITE=DuwmUnifiedTheme.TEXT;
    private static final int MUTED=DuwmUnifiedTheme.MUTED;
    private static final int CYAN=DuwmUnifiedTheme.ACCENT;
    private static final int TEAL=DuwmUnifiedTheme.PANEL;
    private final ArrayList<LinearLayout> tiles=new ArrayList<>();
    private final ArrayList<TextView> headers=new ArrayList<>();
    private final ArrayList<TextView> receiptLines=new ArrayList<>();
    private TextView resultCount;
    private EditText searchBox;
    private String sectionFilter="ALL";
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);
        if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return t;
    }
    private GradientDrawable background(boolean selected){
        GradientDrawable d=new GradientDrawable();d.setColor(selected?DuwmUnifiedTheme.PANEL_SELECTED:TEAL);
        d.setStroke(dp(1),selected?CYAN:DuwmUnifiedTheme.BORDER);
        d.setCornerRadius(dp(11));return d;
    }
    private TextView pill(String value){
        TextView v=text(value,11,CYAN,true);v.setGravity(Gravity.CENTER);v.setBackground(background(false));
        v.setPadding(dp(9),dp(9),dp(9),dp(9));return v;
    }
    private void header(LinearLayout root,String category){
        TextView h=text(category,12,CYAN,true);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.topMargin=dp(16);p.bottomMargin=dp(8);root.addView(h,p);headers.add(h);
    }
    private void item(LinearLayout root,Duwm1683DeskCatalog.Desk d){
        LinearLayout block=new LinearLayout(this);block.setOrientation(LinearLayout.VERTICAL);
        block.setPadding(dp(13),dp(12),dp(13),dp(11));block.setBackground(background(false));
        LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.HORIZONTAL);
        TextView name=text(d.title,16,WHITE,true);top.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow=text("›",21,CYAN,true);top.addView(arrow);
        block.addView(top);
        TextView subtitle=text(d.subtitle,12,MUTED,false);subtitle.setPadding(0,dp(3),0,dp(4));block.addView(subtitle);
        TextView receipt=text(Duwm1683DeskCatalog.status(this,d),11,
                              d.source>=0?CYAN:MUTED,false);
        receipt.setSingleLine(false);receipt.setMaxLines(3);block.addView(receipt);receiptLines.add(receipt);
        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams actionParams=new LinearLayout.LayoutParams(-1,-2);
        actionParams.topMargin=dp(6);block.addView(actions,actionParams);
        TextView open=pill("OPEN DESK");open.setOnClickListener(v->startActivity(Duwm1683DeskCatalog.intent(this,d)));
        actions.addView(open,new LinearLayout.LayoutParams(0,dp(39),1));
        TextView detail=pill("FULL SCREEN DETAILS");
        LinearLayout.LayoutParams detailParams=new LinearLayout.LayoutParams(0,dp(39),1);
        detailParams.leftMargin=dp(8);actions.addView(detail,detailParams);
        detail.setOnClickListener(v->Duwm1683DeskDetailKit.show(this,d));
        block.setOnClickListener(v->startActivity(Duwm1683DeskCatalog.intent(this,d)));
        block.setContentDescription(d.title+". "+d.subtitle+". "+Duwm1683DeskCatalog.status(this,d));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(9);
        root.addView(block,p);tiles.add(block);
    }
    private void filter(String query){
        String q=query==null?"":query.trim().toLowerCase(Locale.ROOT);
        String group="";int visible=0;int matching=0;int groupIndex=-1;
        for(int i=0;i<Duwm1683DeskCatalog.ALL.length;i++){
            Duwm1683DeskCatalog.Desk d=Duwm1683DeskCatalog.ALL[i];
            boolean sectionOk=sectionFilter.equals("ALL")||d.category.equals(sectionFilter);
            boolean show=sectionOk && (q.isEmpty()||(d.title+" "+d.subtitle+" "+d.category+" "+d.description)
                                  .toLowerCase(Locale.ROOT).contains(q));
            if(show){visible++;matching++;}tiles.get(i).setVisibility(show?View.VISIBLE:View.GONE);
        }
        for(int k=0;k<headers.size();k++){
            String section=headers.get(k).getText().toString();boolean has=false;
            for(int i=0;i<Duwm1683DeskCatalog.ALL.length;i++){
                if(Duwm1683DeskCatalog.ALL[i].category.equals(section)&&tiles.get(i).getVisibility()==View.VISIBLE){has=true;break;}
            }
            headers.get(k).setVisibility(has?View.VISIBLE:View.GONE);
        }
        if(resultCount!=null)resultCount.setText("VISIBLE INTELLIGENCE DESKS  "+visible+" / "+Duwm1683DeskCatalog.ALL.length+
                                "  •  REAL SOURCE STATUS ON EACH CARD");
    }
    private void refreshReceipts(){
        for(int i=0;i<Duwm1683DeskCatalog.ALL.length&&i<receiptLines.size();i++){
            receiptLines.get(i).setText(Duwm1683DeskCatalog.status(this,Duwm1683DeskCatalog.ALL[i]));
        }
    }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(BG);setContentView(shell);Duwm1167SafeArea.install(this,shell);
        TextView home=pill("← ORIGINAL COMMAND / ONE GLOBE");home.setGravity(Gravity.CENTER);
        home.setOnClickListener(v->finish());
        LinearLayout.LayoutParams back=new LinearLayout.LayoutParams(-1,dp(38));
        back.setMargins(dp(13),dp(9),dp(13),dp(7));shell.addView(home,back);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);
        shell.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14),dp(8),dp(14),dp(26));scroll.addView(root);
        root.addView(text("INTELLIGENCE DESKS  /  FULL SCREEN",18,WHITE,true));
        TextView caption=text("19 full-screen destinations • verified source status • one original Command Center",12,MUTED,false);
        caption.setPadding(0,dp(6),0,dp(12));root.addView(caption);
        searchBox=new EditText(this);searchBox.setSingleLine(true);searchBox.setTextSize(14);
        searchBox.setTextColor(WHITE);searchBox.setHintTextColor(MUTED);
        searchBox.setHint("SEARCH DESKS, SOURCES OR INFORMATION");
        searchBox.setBackground(background(false));searchBox.setPadding(dp(12),0,dp(12),0);
        root.addView(searchBox,new LinearLayout.LayoutParams(-1,dp(52)));
        android.widget.HorizontalScrollView sectionsScroll=new android.widget.HorizontalScrollView(this);
        sectionsScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout sectionsRow=new LinearLayout(this);sectionsRow.setOrientation(LinearLayout.HORIZONTAL);
        sectionsScroll.addView(sectionsRow);
        for(String label:new String[]{"ALL","AIR, SEA & EARTH","NEWS & MEDIA","DATA, RECORDS & SOURCES"}){
            TextView choice=pill(label);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,dp(39));
            cp.rightMargin=dp(7);sectionsRow.addView(choice,cp);
            choice.setOnClickListener(v->{sectionFilter=label;
                for(int j=0;j<sectionsRow.getChildCount();j++){
                    TextView b=(TextView)sectionsRow.getChildAt(j);
                    b.setBackground(background(b.getText().toString().equals(sectionFilter)));
                }
                filter(searchBox.getText().toString());});
            if(label.equals("ALL"))choice.setBackground(background(true));
        }
        LinearLayout.LayoutParams sectionsLp=new LinearLayout.LayoutParams(-1,dp(40));
        sectionsLp.topMargin=dp(9);root.addView(sectionsScroll,sectionsLp);
        resultCount=text("19 DESKS",12,CYAN,true);resultCount.setPadding(0,dp(10),0,dp(4));root.addView(resultCount);
        String group="";
        for(Duwm1683DeskCatalog.Desk d:Duwm1683DeskCatalog.ALL){
            if(!d.category.equals(group)){group=d.category;header(root,group);}
            item(root,d);
        }
        searchBox.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){filter(s.toString());}
            @Override public void afterTextChanged(Editable e){}
        });
        TextView foot=text("Each DETAILS panel describes the actual provider, record freshness, missing coverage and how to read the information. No synthetic live records are created.",12,MUTED,false);
        foot.setPadding(0,dp(8),0,dp(18));root.addView(foot);filter("");
    }
    @Override protected void onResume(){super.onResume();refreshReceipts();}
}
