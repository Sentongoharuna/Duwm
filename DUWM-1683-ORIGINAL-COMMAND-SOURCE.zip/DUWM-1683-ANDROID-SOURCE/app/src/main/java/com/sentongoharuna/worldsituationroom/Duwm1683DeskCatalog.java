package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import java.util.Locale;

/** The same source-aware description is used in the Options hub and inside each existing desk. */
public final class Duwm1683DeskCatalog {
    private Duwm1683DeskCatalog() {}
    public static final class Desk {
        public final String title,subtitle,category,mode,description,howToRead;
        public final Class<? extends Activity> target;
        public final int source;
        Desk(String title,String subtitle,String category,Class<? extends Activity> target,
             String mode,int source,String description,String howToRead) {
            this.title=title;this.subtitle=subtitle;this.category=category;this.target=target;
            this.mode=mode;this.source=source;this.description=description;this.howToRead=howToRead;
        }
    }
    private static Desk d(String title,String subtitle,String category,Class<? extends Activity> target,
                          String mode,int source,String description,String howToRead) {
        return new Desk(title,subtitle,category,target,mode,source,description,howToRead);
    }
    public static final Desk[] ALL={
        d("Aircraft tracker","Received aircraft positions, headings and tracks","AIR, SEA & EARTH",Duwm1670FlightMapActivity.class,null,0,
          "Select an aircraft to inspect ICAO24, callsign, source position, ground speed, altitude and bearing. Compare two distinct received fixes to see an observed track.",
          "OpenSky reports aircraft positions, not published arrival times. An airport you select is a scenario, never a verified flight destination."),
        d("Maritime intelligence","Regional AIS, ships and vessel profiles","AIR, SEA & EARTH",GevMarineActivity.class,null,2,
          "Select an ocean region, load actual AIS reports, then inspect the reported MMSI, vessel name, speed, heading, geographic fix and observation age.",
          "Regional receivers do not cover every sea. A ship moving on the screen requires two different reported positions."),
        d("Earthquakes","USGS events, coordinates, magnitude and depth","AIR, SEA & EARTH",Duwm1671SectorActivity.class,"EARTHQUAKES",3,
          "Inspect real earthquakes on a geographic map. Use observed magnitude, location, depth, source time and event history when records exist.",
          "Empty data means that this phone has no usable stored observations; a blank chart is not evidence that no earthquakes occurred."),
        d("Weather","Temperature, precipitation, wind and forecasts","AIR, SEA & EARTH",Duwm1671SectorActivity.class,"WEATHER",6,
          "Open regional weather forecast and provider measurements. Compare available receipt dates and inspect the regional weather map.",
          "Open-Meteo values are model forecasts, not directly measured station conditions."),
        d("Satellites and ISS","Orbital elements, ISS location and imagery","AIR, SEA & EARTH",GevSatelliteActivity.class,null,1,
          "Inspect satellite identifiers, orbital elements, calculated positions and available observed spacecraft imagery.",
          "Orbit paths are calculated estimates. Keep propagation time distinct from directly received observations."),
        d("Geographic watchlist","Saved geographic regions and monitoring radius","AIR, SEA & EARTH",Duwm1676GeoWatchActivity.class,null,-1,
          "Choose or save places, select a distance, and examine which source positions intersect that saved region.",
          "Results are constrained to actual cached observations; a saved watchlist does not automatically mean a live sensor report."),
        d("Place maps","Street tiles, countries and mapped source points","AIR, SEA & EARTH",DuwmPlaceMapActivity.class,null,-1,
          "Search places, zoom to countries or cities, and choose geographically positioned source observations.",
          "Map lines and illumination show cartography; not real traffic unless a valid traffic source is explicitly connected."),
        d("World news","Published stories, photos and article actions","NEWS & MEDIA",Duwm1166NewsDeskActivity.class,null,5,
          "Browse publisher-attributed headlines, story dates and legitimately available photographs; open original articles and share source cards.",
          "A story location must be supplied or corroborated; never treat a publisher's home country as an incident location."),
        d("News atlas","Publishers by region and article geography","NEWS & MEDIA",Duwm1670NewsAtlasActivity.class,null,5,
          "Filter publishers and articles by region, then inspect their source, publication time, geographic scope and article links.",
          "A directory of publishers is not itself a feed of live articles. Unavailable publishers remain labelled as such."),
        d("Radio stations","In-app streams, stations, countries and maps","NEWS & MEDIA",Duwm1166RadioAtlasActivity.class,null,-1,
          "Search real radio listings by country and station name, select a supported stream, then play or share its source card.",
          "Stations without verified GPS coordinates must not be plotted at invented locations."),
        d("TV stations","Country channels and native media playback","NEWS & MEDIA",MediaDeskActivity.class,"TV STATIONS",-1,
          "Select a listed live TV channel, use in-app playback controls, inspect its stream source and share station information.",
          "A station listing is not proof of playable video; transport, codec, geo-rights and network errors are shown by the player."),
        d("Public cameras","Camera locations, frames and playback","NEWS & MEDIA",MediaDeskActivity.class,"PUBLIC CAMERAS",-1,
          "Browse public webcams, inspect the source or latest available image, and share a card containing attribution.",
          "A refreshed photograph is a snapshot, not a continuous live video feed."),
        d("NASA Earth images","EPIC observation, original capture time","NEWS & MEDIA",RunningballV107EpicActivity.class,null,-1,
          "View NASA's received Earth images with actual capture times, source information and an image share action.",
          "Image observation time can be earlier than receipt time. Do not label an older image as today's live picture."),
        d("World markets","Actual reference FX and historical receipts","DATA, RECORDS & SOURCES",Duwm1671SectorActivity.class,"MARKETS",7,
          "Inspect reference exchange rates, dates, source information and a chart when two or more distinct receipts are stored.",
          "Reference FX quotes are not an exchange trading terminal; no synthetic price series or implied market momentum."),
        d("Source health","Provider receipts, failures and data age","DATA, RECORDS & SOURCES",Duwm1671SourceStatusActivity.class,null,-1,
          "Inspect actual last-good receipts, missing sources, stale caches, provider errors, time stamps and coverage limits.",
          "Received, current, stale, not configured and failed are different statuses. Repeated cached data is not a new live receipt."),
        d("Evidence vault","Capture and compare on-device receipts","DATA, RECORDS & SOURCES",Duwm1675EvidenceVaultActivity.class,null,-1,
          "Record snapshots of the phone's source-status board, compare captures and export genuine recorded differences.",
          "An Evidence Vault entry records what this phone knew at capture time; it is not independently verified ground truth."),
        d("World source directory","Registered provider details and permissions","DATA, RECORDS & SOURCES",Duwm1669SourceDirectoryActivity.class,null,-1,
          "Search public websites and potential providers across aviation, maritime, news, cameras and television.",
          "Directory entries are candidates, not proof of API availability or playback rights."),
        d("Geopolitical lens","Country focus and source-backed events","DATA, RECORDS & SOURCES",Duwm1668GeopoliticalLensActivity.class,null,-1,
          "Inspect geo-positioned news and events in country context with links to original providers.",
          "Two reports happening nearby do not establish a causal relationship or a verified risk score."),
        d("Local reports","Nearby reporting and source records","DATA, RECORDS & SOURCES",LocalMonitorActivity.class,null,-1,
          "Review locally collected verified reports, media links, place data and record details.",
          "Only observations received from a genuine provider should be shown as active local signals.")
    };
    public static Desk find(Activity a){
        String kind=a.getIntent()==null?null:a.getIntent().getStringExtra(Duwm1671SectorActivity.EXTRA_KIND);
        String mode=a.getIntent()==null?null:a.getIntent().getStringExtra("mode");
        for(Desk d:ALL){
            if(d.target!=a.getClass())continue;
            if(d.target==Duwm1671SectorActivity.class) {if(d.mode!=null&&d.mode.equalsIgnoreCase(kind))return d;}
            else if(d.target==MediaDeskActivity.class){
                if(d.mode!=null && d.mode.equalsIgnoreCase(mode))return d;
            }else return d;
        }
        // Legacy launch paths can omit a mode; still show a useful desk-specific details panel.
        for(Desk d:ALL)if(d.target==a.getClass())return d;
        return null;
    }
    public static Intent intent(Activity a,Desk desk){
        Intent i=new Intent(a,desk.target);
        if(desk.mode!=null){
            if(desk.target==Duwm1671SectorActivity.class)i.putExtra(Duwm1671SectorActivity.EXTRA_KIND,desk.mode);
            else i.putExtra("mode",desk.mode);
        }
        return i;
    }
    public static String status(Context context,Desk d){
        if(d.source>=0){
            try{
                RunningballV25Sources.Result r=RunningballV25Sources.read(context,d.source);
                String count=(r.value==null||r.value.trim().isEmpty())?"--":r.value;
                return count+"  •  "+r.status.toString().replace('_',' ')+"  •  "+r.age();
            }catch(Exception e){return "SOURCE STATUS UNAVAILABLE  •  CHECK SOURCE HEALTH";}
        }
        return "AVAILABLE TOOL  •  OPEN FOR INDIVIDUAL SOURCE STATUS";
    }
    public static String fullStatus(Context context,Desk d){
        if(d.source<0)return "This is a navigation/tool page. See its own records and use Source Health for provider status.";
        try{
            RunningballV25Sources.Result r=RunningballV25Sources.read(context,d.source);
            return "PROVIDER  "+r.provider+"\nSTATUS  "+r.display()+"\nVALUE  "+
              (r.value==null?"--":r.value)+"\nCOVERAGE  "+r.coverage+"\nSOURCE OBSERVATION AGE  "+r.sourceAge()+
              "\nENDPOINT  "+r.endpoint+(r.errorReason.isEmpty()?"":"\nLAST ERROR  "+r.errorReason);
        }catch(Exception e){return "Unable to read the latest on-device provider receipt. Source Health contains diagnostics.";}
    }
}
