package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.content.ClipData;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;

/** Original 1080x1920 editorial social export; original publisher photos only, no invented imagery. */
public final class Duwm1166PortraitCard {
  private static final int W=1080,H=1920,WHITE=0xFFF0F7FA,BG=0xFF06121F,MUTED=0xFFA9CBDC;
  private Duwm1166PortraitCard(){}
  private static void fill(Canvas c,Paint p,int col,float a,float b,float d,float e){p.setColor(col);p.setStyle(Paint.Style.FILL);c.drawRoundRect(a,b,d,e,28,28,p);}
  private static void text(Canvas c,Paint p,String s,int size,int color,boolean bold,float x,float y){p.setShader(null);p.setColor(color);p.setTextSize(size);
    p.setTypeface(Typeface.create(bold?"sans-serif-condensed":"sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));p.setStyle(Paint.Style.FILL);c.drawText(s,x,y,p);}
  private static float wrap(Canvas c,Paint p,String value,int size,int color,boolean bold,int x,float y,int maxWidth,int maxLines,int leading){
    p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create(bold?"sans-serif-condensed":"sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
    String[] words=(value==null?"":value.replaceAll("[\\p{Cntrl}]+"," ")).split("\\s+");String line="";int count=0;
    for(String word:words){String next=line.isEmpty()?word:line+" "+word;
      if(p.measureText(next)>maxWidth && !line.isEmpty()){c.drawText(line,x,y,p);y+=leading;count++;line="";
        if(count==maxLines)return y;}
      while(p.measureText(word)>maxWidth&&word.length()>1){int cut=Math.max(1,word.length()/2);while(cut>1&&p.measureText(word.substring(0,cut))>maxWidth)cut--;
        if(!line.isEmpty()){c.drawText(line,x,y,p);y+=leading;count++;line="";if(count==maxLines)return y;}
        c.drawText(word.substring(0,cut),x,y,p);y+=leading;count++;if(count==maxLines)return y;word=word.substring(cut);
      }
      line=line.isEmpty()?word:line+" "+word;
    }
    if(!line.isEmpty()&&count<maxLines){c.drawText(line,x,y,p);y+=leading;}return y;
  }
  private static String time(long t){if(t<=0)return "PUBLISHER TIME NOT SUPPLIED";SimpleDateFormat f=new SimpleDateFormat("dd MMM yyyy  HH:mm 'UTC'",Locale.US);
    f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(t));}
  private static int tone(String category){if("WARS".equals(category))return 0xFFF17678;if("ECONOMICS".equals(category))return 0xFFFFC66D;
    if("AFRICA".equals(category)||"LOCAL".equals(category))return 0xFF56E4B7;if("MIDDLE EAST".equals(category))return 0xFFB0A0FB;return 0xFF55CFF6;}
  public static Bitmap render(Activity a,NewsItem item,String category,Bitmap publisherPhoto){
    Bitmap card=Bitmap.createBitmap(W,H,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(card);Paint p=new Paint(3);c.drawColor(BG);int accent=tone(category);
    p.setColor(0xFF0A2535);for(int y=0;y<H;y+=75)c.drawRect(0,y,W,y+1,p);
    p.setColor(accent);c.drawRect(0,0,W,15,p);fill(c,p,0xFF102D3B,45,48,1035,225);
    try{Bitmap logo=BitmapFactory.decodeResource(a.getResources(),R.drawable.develop_uganda_logo);if(logo!=null){c.drawBitmap(logo,null,new Rect(72,78,189,194),p);logo.recycle();}}catch(Exception ignored){}
    text(c,p,"DEVELOP.UGANDA",37,WHITE,true,210,126);text(c,p,"WORLD SITUATION ROOM  /  NEWS INTELLIGENCE",23,MUTED,false,210,170);
    text(c,p,category+"  /  EDITORIAL REPORT",35,accent,true,72,314);
    p.setColor(accent);c.drawRect(72,350,1008,356,p);
    int top=393,bottom=1030;
    if(publisherPhoto!=null&&!publisherPhoto.isRecycled()&&publisherPhoto.getWidth()>0&&publisherPhoto.getHeight()>0){
      int w=publisherPhoto.getWidth(),h=publisherPhoto.getHeight();float aspect=(1008f-72f)/(bottom-top);Rect crop;
      if(w/(float)h>aspect){int width=(int)(h*aspect);crop=new Rect((w-width)/2,0,(w+width)/2,h);}else{int height=(int)(w/aspect);crop=new Rect(0,(h-height)/2,w,(h+height)/2);}
      c.drawBitmap(publisherPhoto,crop,new Rect(72,top,1008,bottom),p);
      fill(c,p,0xD90C2230,76,948,940,1014);text(c,p,"PUBLISHER IMAGE  •  SOURCE ATTRIBUTED",23,accent,true,100,993);
    }else{
      fill(c,p,0xFF102839,72,top,1008,bottom);p.setColor(0xFF1A4656);p.setStrokeWidth(2);
      for(int x=105;x<1000;x+=75)c.drawLine(x,420,x,1003,p);
      for(int y=441;y<1000;y+=75)c.drawLine(93,y,988,y,p);
      p.setColor(accent);c.drawCircle(540,696,14,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);c.drawCircle(540,696,120,p);c.drawCircle(540,696,65,p);p.setStyle(Paint.Style.FILL);
      text(c,p,"SOURCE PHOTO NOT PROVIDED",32,WHITE,true,220,910);text(c,p,"Verified headline and text only",25,MUTED,false,310,951);
    }
    fill(c,p,0xFF102638,45,1060,1035,1788);
    float y=1140;y=wrap(c,p,item.title,57,WHITE,true,82,y,912,5,68)+42;
    text(c,p,"REPORT SUMMARY",23,accent,true,82,y);y+=50;
    y=wrap(c,p,item.summary==null||item.summary.isEmpty()?"Full details are available at the source publisher.":item.summary,
        31,0xFFCADFE9,false,82,y,900,5,43)+35;
    if(y>1620)y=1620;
    text(c,p,"PUBLISHER / SOURCE",22,accent,true,82,y);y+=43;
    y=wrap(c,p,item.sourceName,30,WHITE,true,82,y,892,2,40)+24;
    text(c,p,"SOURCE DATE",21,accent,true,82,y);y+=34;
    text(c,p,time(item.publishedAt),27,WHITE,false,82,y);
    p.setColor(accent);c.drawRect(55,1824,1025,1827,p);
    String sourceUrl=item.link==null?"SOURCE URL UNAVAILABLE":item.link;
    if(sourceUrl.length()>84)sourceUrl=sourceUrl.substring(0,84)+"…";
    text(c,p,sourceUrl,18,MUTED,false,75,1806);
    text(c,p,"SOURCE-ATTRIBUTED REPORT",25,WHITE,true,75,1874);
    text(c,p,"NOT INDEPENDENTLY VERIFIED  •  DEVELOP.UGANDA",20,MUTED,false,75,1905);
    return card;
  }
  public static void share(Activity activity,NewsItem item,String category,ImageView imageView){
    Bitmap photo=null;try{Drawable d=imageView==null?null:imageView.getDrawable();if(d instanceof BitmapDrawable)photo=((BitmapDrawable)d).getBitmap();}catch(Exception ignored){}
    final Bitmap original=photo;Toast.makeText(activity,"Creating 9:16 share image",Toast.LENGTH_SHORT).show();
    new Thread(()->{try{
      Bitmap card=render(activity,item,category,original);
      File folder=new File(activity.getCacheDir(),"share-cards");if(!folder.exists()&&!folder.mkdirs())throw new java.io.IOException("Card cache unavailable");
      String filename="duwm1166-"+UUID.randomUUID().toString().substring(0,16)+".png";
      File dest=new File(folder,filename);try(FileOutputStream f=new FileOutputStream(dest)){if(!card.compress(Bitmap.CompressFormat.PNG,100,f))throw new java.io.IOException("PNG export failed");}card.recycle();
      Uri uri=new Uri.Builder().scheme("content").authority(activity.getPackageName()+".sharecards").appendPath(filename).build();
      activity.runOnUiThread(()->{
        if(activity.isFinishing()||activity.isDestroyed())return;
        Intent send=new Intent(Intent.ACTION_SEND);send.setType("image/png");send.putExtra(Intent.EXTRA_STREAM,uri);
        send.putExtra(Intent.EXTRA_TEXT,item.title+"\nSource: "+item.sourceName+"\n"+item.link);
        send.setClipData(ClipData.newUri(activity.getContentResolver(),"DUWM verified editorial card",uri));send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try{activity.startActivity(Intent.createChooser(send,"Share DUWM portrait news card"));}catch(Exception e){Toast.makeText(activity,"No share app available",Toast.LENGTH_LONG).show();}
      });
    }catch(Exception ex){activity.runOnUiThread(()->Toast.makeText(activity,"Image export failed: "+ex.getClass().getSimpleName(),Toast.LENGTH_LONG).show());}},"duwm1166-tiktok-png").start();
  }
}
