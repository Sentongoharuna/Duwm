package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Bar graph for counted RECEIVED records per region. No generated/simulated readings. */
public final class Duwm1166RecordChart extends View {
  private final Paint p=new Paint(3);
  private int[] values=new int[0];private String[] names=new String[0];
  public Duwm1166RecordChart(Context context){super(context);setMinimumHeight(180);}
  public void data(String[] labels,int[] counts){names=labels==null?new String[0]:labels.clone();values=counts==null?new int[0]:counts.clone();invalidate();}
  @Override protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(0xFF0B2433);int w=getWidth(),h=getHeight();
    int n=Math.min(values.length,names.length);p.setTypeface(android.graphics.Typeface.DEFAULT);p.setTextSize(24);
    if(n==0){p.setColor(0xFFABCAD5);c.drawText("NO SOURCE MEASUREMENTS",16,h/2f,p);return;}
    int max=1;for(int i=0;i<n;i++)max=Math.max(max,values[i]);float stride=(w-30f)/n;
    for(int i=0;i<n;i++){float cx=15+stride*i+stride*.5f;float bottom=h-43;float top=bottom-(h-85f)*Math.max(0,values[i])/(float)max;
      p.setColor(0xFF42C8DE);c.drawRoundRect(cx-stride*.32f,top,cx+stride*.32f,bottom,7,7,p);
      p.setColor(0xFFE0F2F7);p.setTextSize(20);c.drawText(Integer.toString(values[i]),cx-10,Math.max(24,top-8),p);
      p.setColor(0xFFA1C0CC);p.setTextSize(17);String label=names[i].length()>10?names[i].substring(0,10):names[i];c.drawText(label,cx-stride*.34f,h-13,p);
    }
  }
}
