package com.sentongoharuna.worldsituationroom;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import java.util.*;

/** Dedicated aircraft, vessel, ISS, earthquake and weather record screens with real sample histograms. */
public final class Duwm1166RecordsActivity extends Activity {
  private static final int BG=0xFF06131F,MUTED=0xFFAFCAD5,ACCENT=0xFF4FCDE6;
  private static final String[] REGIONS={"ALL","AFRICA","EUROPE","MIDDLE EAST","INDIA / ASIA","AMERICAS","PACIFIC"};
  private String kind="AIRCRAFT",region="ALL";private LinearLayout list,filters,body;private TextView subtitle;
  private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
  private TextView text(String s,int size,boolean title){TextView v=new TextView(this);v.setText(s);v.setTextColor(title?0xFFF3F8FB:MUTED);v.setTextSize(size);
    if(title)v.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));return v;}
  private TextView btn(String s,Runnable action){TextView b=text(s,12,true);b.setGravity(Gravity.CENTER);b.setPadding(dp(10),dp(11),dp(10),dp(11));b.setMinimumHeight(dp(44));
    GradientDrawable d=new GradientDrawable();d.setColor(0xFF143348);d.setCornerRadius(dp(10));d.setStroke(dp(1),0xFF30647A);b.setBackground(d);b.setOnClickListener(v->action.run());return b;}
  @Override public void onCreate(Bundle b){super.onCreate(b);kind=getIntent().getStringExtra("kind");if(kind==null)kind="AIRCRAFT";
    getWindow().setStatusBarColor(BG);ScrollView sc=new ScrollView(this);sc.setBackgroundColor(BG);setContentView(sc);
    body=new LinearLayout(this);body.setPadding(dp(13),dp(16),dp(13),dp(22));body.setOrientation(LinearLayout.VERTICAL);sc.addView(body);
    body.addView(text("DEVELOP.UGANDA / "+kind+" INTELLIGENCE",25,true));subtitle=text("ONLY SOURCE-REPORTED OBSERVATIONS  •  NO INFERRED MOVEMENT",11,false);subtitle.setPadding(0,dp(8),0,dp(9));body.addView(subtitle);
    LinearLayout actions=new LinearLayout(this);body.addView(actions);actions.addView(btn("‹ HOME",this::finish),new LinearLayout.LayoutParams(0,dp(46),1));
    TextView map=btn("FULL SCREEN MAP",()->startActivity(new Intent(this,DuwmPlaceMapActivity.class)));LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(0,dp(46),1);mp.leftMargin=dp(8);actions.addView(map,mp);
    TextView refresh=btn("REFRESH SOURCE BOARD",()->startActivity(new Intent(this,DuwmWorldIntelligenceActivity.class)));body.addView(refresh,new LinearLayout.LayoutParams(-1,dp(46)));
    HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);body.addView(hsv);
    filters=new LinearLayout(this);hsv.addView(filters);
    Duwm1166RecordChart chart=new Duwm1166RecordChart(this);body.addView(chart,new LinearLayout.LayoutParams(-1,dp(206)));
    list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);body.addView(list);
    for(String place:REGIONS){TextView chip=btn(place,()->{region=place;draw(chart);});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(46));p.rightMargin=dp(6);filters.addView(chip,p);}
    draw(chart);
  }
  private String normalize(String k){if(k.equals("SATELLITES"))return "ISS";if(k.equals("VESSELS"))return "VESSEL";
    if(k.equals("EARTHQUAKES"))return "EARTHQUAKE";return k;}
  private boolean matches(DuwmGeoObservationStore.Fix f){if(f==null||!normalize(kind).equals(f.type))return false;
    switch(region){case "AFRICA":return f.lat>=-35&&f.lat<=38&&f.lon>=-18&&f.lon<=52;
      case "EUROPE":return f.lat>=35&&f.lat<=73&&f.lon>=-12&&f.lon<=45;
      case "MIDDLE EAST":return f.lat>=10&&f.lat<=43&&f.lon>=34&&f.lon<=65;
      case "INDIA / ASIA":return f.lat>=-12&&f.lat<=55&&f.lon>=65&&f.lon<=145;
      case "AMERICAS":return f.lon>=-170&&f.lon<=-30;
      case "PACIFIC":return f.lon>145||f.lon< -170;
      default:return true;}}
  private void draw(Duwm1166RecordChart chart){list.removeAllViews();List<DuwmGeoObservationStore.Fix> raw=DuwmGeoObservationStore.read(this);
    ArrayList<DuwmGeoObservationStore.Fix> matching=new ArrayList<>();String[] labels={"AFRICA","EUROPE","M. EAST","ASIA","AMERICAS","PACIFIC"};int[] counts=new int[6];
    for(DuwmGeoObservationStore.Fix f:raw){if(!normalize(kind).equals(f.type))continue;
      for(int i=0;i<6;i++)if(inRegion(f,labels[i]))counts[i]++;
      if(matches(f))matching.add(f);
    }
    chart.data(labels,counts);subtitle.setText(kind+" / "+region+" / "+matching.size()+" RECEIVED POSITIONS  •  FROM SAVED SOURCE RECEIPTS");
    if(matching.isEmpty()){TextView empty=text("NO VERIFIED OBSERVATIONS FOR THIS REGION. This is not evidence of zero aircraft, vessels, or events.",14,false);empty.setPadding(dp(9),dp(20),dp(9),dp(15));list.addView(empty);return;}
    int n=0;for(DuwmGeoObservationStore.Fix f:matching){if(n++>=100)break;
      LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);
      GradientDrawable bg=new GradientDrawable();bg.setColor(0xFF0E293A);bg.setCornerRadius(dp(10));bg.setStroke(dp(1),0xFF296179);row.setBackground(bg);
      LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(7);list.addView(row,p);
      Duwm1166SignalView led=new Duwm1166SignalView(this);led.source(f.type,f.sourceTime,f.receivedAt,false,false);row.addView(led,new LinearLayout.LayoutParams(dp(35),dp(60)));
      TextView label=text(f.title+"\n"+f.provider+" · "+f.sourceTime+"\n"+f.detail,12,false);label.setPadding(dp(2),dp(9),dp(8),dp(9));label.setMaxLines(4);row.addView(label,new LinearLayout.LayoutParams(0,-2,1));
      row.setOnLongClickListener(v->{LinearLayout detail=new LinearLayout(this);detail.setOrientation(LinearLayout.VERTICAL);
        TextView msg=text(f.title+"\n"+f.provider+" / "+f.sourceTime+"\n"+f.detail,12,false);detail.addView(msg);
        detail.addView(new Duwm1166TrackView(this,f),new LinearLayout.LayoutParams(-1,dp(245)));
        new android.app.AlertDialog.Builder(this).setTitle("RECORDED MOVEMENT GRAPH").setView(detail).setPositiveButton("CLOSE",null).show();return true;});
      row.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle(f.title)
        .setMessage(f.detail+"\nSource time: "+f.sourceTime+"\nPosition: "+f.lat+", "+f.lon+"\nHistory: "+(f.hasActualTrack()?"Two recorded fixes":"One recorded fix or unavailable"))
        .setPositiveButton("ON MAP",(dialog,which)->{Intent next=new Intent(this,DuwmPlaceMapActivity.class);next.putExtra("focus_lat",Double.toString(f.lat));next.putExtra("focus_lon",Double.toString(f.lon));startActivity(next);})
        .setNeutralButton("SHARE IMAGE",(dialog,which)->V115941ShareCards.share(this,f.type,f.title,f.detail,f.provider,f.sourceTime,f.lat,f.lon,f.url,null)).setNegativeButton("CLOSE",null).show());
    }
  }
  private boolean inRegion(DuwmGeoObservationStore.Fix f,String key){switch(key){case "AFRICA":return f.lat>=-35&&f.lat<=38&&f.lon>=-18&&f.lon<=52;
    case "EUROPE":return f.lat>=35&&f.lat<=73&&f.lon>=-12&&f.lon<=45;
    case "M. EAST":return f.lat>=10&&f.lat<=43&&f.lon>=34&&f.lon<=65;
    case "ASIA":return f.lat>=-12&&f.lat<=55&&f.lon>=65&&f.lon<=145;
    case "AMERICAS":return f.lon>=-170&&f.lon<=-30;default:return f.lon>145||f.lon< -170;}}
}
