#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
"$P/scripts/verify-1-2-20-4-20-working-globe-baseline.sh" "$P"
echo "1.2/20/4.20 WORKING GLOBE BASELINE FIX1 PASS"
