plugins {
    id("com.android.application")
}

android {
    namespace = "com.sentongoharuna.worldsituationroom"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.sentongoharuna.worldsituationroom.rb2live25"
        minSdk = 23
        targetSdk = 35
        versionCode = 167900
        versionName = "1679"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = true
        checkReleaseBuilds = true
    }
}

// The APK has no external runtime libraries. HTTPS, media playback and the optional AIS
// WebSocket are implemented with Android/Java platform APIs so Actions produces one compact,
// self-contained application package without dependency-resolution surprises.
