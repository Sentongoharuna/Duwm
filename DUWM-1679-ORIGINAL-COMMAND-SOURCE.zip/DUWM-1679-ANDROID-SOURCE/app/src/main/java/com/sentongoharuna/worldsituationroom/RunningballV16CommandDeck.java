package com.sentongoharuna.worldsituationroom;

import android.animation.ValueAnimator;
import android.view.animation.LinearInterpolator;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Visible control room: moving chrome, only actual cached observation counts. */
public final class RunningballV16CommandDeck extends LinearLayout {
  private static final int BG=0xFF081824, LIGHT=0xFFE4F4F8, MUTED=0xFF39B5C3;
  private static final int CYAN=0xFF47D2DB, GREEN=0xFF39B5C3, GOLD=0xFF47D2DB;
  private static final int RED=0xFF47D2DB, OFF=0xFF185769;
  private static final String EVENTS="rb_global_public_events";
  private final Handler handler=new Handler(Looper.getMainLooper());
  private final ArrayList<Cell> cells=new ArrayList<>();
  private TextView ticker,clock,region,status;
  private SignalRail rail;
  private boolean active=false;
  private int tickerIndex=0;
  private long lastTicker=0,lastCacheCheck=0;
  private final ArrayList<String> tickerLines=new ArrayList<>();
  private String lastKey="";
  private final Runnable uiLoop=new Runnable(){@Override public void run(){
    if(!active)return;
    long now=System.currentTimeMillis();
    if(now-lastCacheCheck>12000L){render();lastCacheCheck=now;}
    if(now-lastTicker>6800L){rotateTicker();lastTicker=now;}
    clock.setText("UTC  "+utc(now));
    handler.postDelayed(this,1000L);
  }};
  private final class Cell {
    final String kind;final TextView number,meta,source,title;final SignalDot signal;
    String prev="";Cell(String k,TextView n,TextView m,TextView s,TextView t,SignalDot l){kind=k;number=n;meta=m;source=s;title=t;signal=l;}
  }
  private final class SignalDot extends View {
    private final Paint pen=new Paint(3);
    private int state=0;private long changed=0;
    SignalDot(){super(RunningballV16CommandDeck.this.getContext());}
    void setState(int s,boolean realChange){if(state!=s){state=s;invalidate();}if(realChange){changed=System.currentTimeMillis();invalidate();}}
    @Override protected void onDraw(Canvas c){super.onDraw(c);
      int col=state==2?GREEN:state==1?GOLD:state==3?RED:OFF;
      float r=Math.min(getWidth(),getHeight())*.22f;
      if(System.currentTimeMillis()-changed<2400L){pen.setColor(col);pen.setAlpha(65);c.drawCircle(getWidth()/2f,getHeight()/2f,r*1.7f,pen);}
      pen.setAlpha(255);pen.setColor(col);c.drawCircle(getWidth()/2f,getHeight()/2f,r,pen);
      pen.setStyle(Paint.Style.STROKE);pen.setStrokeWidth(dp(1));pen.setColor(0x7739B5C3);
      c.drawCircle(getWidth()/2f,getHeight()/2f,r*1.55f,pen);pen.setStyle(Paint.Style.FILL);
      // Short glow only after a genuinely changed source count; no permanent fake alerts.
      if(System.currentTimeMillis()-changed<2400L)postInvalidateDelayed(140L);
    }
  }
  private final class SignalRail extends View {
    private final Paint p=new Paint(3);private float phase=0;private ValueAnimator sweep;
    SignalRail(){super(RunningballV16CommandDeck.this.getContext());}
    void start(){if(sweep!=null)return;
      sweep=ValueAnimator.ofFloat(0f,1f);sweep.setDuration(4200L);
      sweep.setRepeatCount(ValueAnimator.INFINITE);sweep.setInterpolator(new LinearInterpolator());
      sweep.addUpdateListener(anim->{phase=(Float)anim.getAnimatedValue();invalidate();});sweep.start();
    }
    void stop(){if(sweep!=null){sweep.cancel();sweep=null;}}

    @Override protected void onDraw(Canvas c){super.onDraw(c);
      float y=getHeight()/2f; p.setStrokeWidth(dp(1));p.setColor(0xFF185769);
      c.drawLine(0,y,getWidth(),y,p);
      p.setStrokeWidth(dp(2));p.setColor(CYAN);
      float x=Math.max(0,(getWidth()+dp(70))*phase-dp(70));
      c.drawLine(x,y,Math.min(getWidth(),x+dp(70)),y,p);
    }
  }
  private int dp(float d){return Math.round(getResources().getDisplayMetrics().density*d);}
  private static String utc(long time){SimpleDateFormat f=new SimpleDateFormat("HH:mm:ss",Locale.US);
    f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(time));}
  private static String ago(long stamp){if(stamp<=0)return "NOT LOADED";
    long secs=Math.max(0L,System.currentTimeMillis()-stamp)/1000;
    if(secs<60)return secs+"s AGO";
    if(secs<3600)return (secs/60)+"m AGO";
    return (secs/3600)+"h AGO";
  }
  private int freshness(long stamp){if(stamp<=0)return 0;
    long age=Math.max(0,System.currentTimeMillis()-stamp);
    return age<=180000L?2:age<=3600000L?1:3;
  }
  private TextView text(String content,int sp,int col,boolean strong){TextView t=new TextView(getContext());t.setText(content);
    t.setTextSize(sp);t.setTextColor(col);t.setIncludeFontPadding(true);
    if(strong)t.setTypeface(null,1);return t;
  }
  private GradientDrawable panel(int col){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
    new int[]{0xFF0E404E,0xFF081824});g.setCornerRadius(dp(15));g.setStroke(dp(1),col);return g;}
  private void open(Class<?> target){getContext().startActivity(new Intent(getContext(),target));}
  private View tile(String key,String head,String desc,int color,Class<?> target){
    LinearLayout outer=new LinearLayout(getContext());outer.setOrientation(VERTICAL);
    outer.setPadding(dp(11),dp(12),dp(10),dp(10));outer.setBackground(panel(0xFF185769));
    LinearLayout line=new LinearLayout(getContext());line.setOrientation(HORIZONTAL);line.setGravity(Gravity.CENTER_VERTICAL);
    SignalDot dot=new SignalDot();line.addView(dot,new LayoutParams(dp(21),dp(21)));
    TextView title=text(head,11,color,true);LayoutParams tlp=new LayoutParams(0,-2,1);tlp.leftMargin=dp(3);line.addView(title,tlp);
    outer.addView(line,new LayoutParams(-1,dp(28)));
    TextView count=text("--",25,LIGHT,true);LayoutParams clp=new LayoutParams(-1,dp(38));outer.addView(count,clp);
    TextView meta=text(desc,10,MUTED,false);meta.setMaxLines(3);outer.addView(meta,new LayoutParams(-1,dp(49)));
    TextView source=text("NO SOURCE REPORT",9,color,false);source.setMaxLines(2);outer.addView(source,new LayoutParams(-1,dp(30)));
    outer.setOnClickListener(v->open(target));outer.setClickable(true);outer.setFocusable(true);
    cells.add(new Cell(key,count,meta,source,title,dot));return outer;
  }
  private void pair(View left,View right){LinearLayout line=new LinearLayout(getContext());line.setOrientation(HORIZONTAL);
    LayoutParams a=new LayoutParams(0,dp(169),1);a.rightMargin=dp(5);line.addView(left,a);
    LayoutParams b=new LayoutParams(0,dp(169),1);b.leftMargin=dp(5);line.addView(right,b);
    LayoutParams lp=new LayoutParams(-1,-2);lp.topMargin=dp(9);addView(line,lp);
  }
  public RunningballV16CommandDeck(Context context){super(context);setOrientation(VERTICAL);
    TextView eyebrow=text("WORLDWIDE  /  MULTI-SOURCE INTELLIGENCE",10,GREEN,true);addView(eyebrow);
    LinearLayout head=new LinearLayout(context);head.setOrientation(HORIZONTAL);head.setGravity(Gravity.CENTER_VERTICAL);
    TextView big=text("WORLD COMMAND GRID",19,LIGHT,true);head.addView(big,new LayoutParams(0,dp(38),1));
    clock=text("UTC --:--:--",10,CYAN,true);head.addView(clock);
    addView(head);
    region=text("REGION  /  NOT SELECTED",11,GOLD,true);addView(region);
    status=text("REAL OBSERVATIONS ONLY  ·  ANIMATION DOES NOT MEAN NEW DATA",10,MUTED,false);
    LayoutParams sp=new LayoutParams(-1,-2);sp.topMargin=dp(6);addView(status,sp);
    rail=new SignalRail();LayoutParams rp=new LayoutParams(-1,dp(14));rp.topMargin=dp(6);addView(rail,rp);
    pair(tile("AIR","AIRCRAFT","Regional ADS-B position reports",CYAN,AirRadarActivity.class),
         tile("SAT","SATELLITES","CelesTrak orbital elements",GREEN,GevSatelliteActivity.class));
    pair(tile("SEA","MARITIME","AIS gateway vessel snapshots",GOLD,GevMarineActivity.class),
         tile("QUAKE","EARTHQUAKES","USGS M2.5+ in last 24 hours",RED,RunningballGlobalEventsActivity.class));
    pair(tile("NASA","NASA EVENTS","Open natural events · up to 65",CYAN,RunningballGlobalEventsActivity.class),
         tile("REGION","WORLD SECTOR","Select any coordinates worldwide",GREEN,RunningballWorldExplorerActivity.class));
    ticker=text("SOURCE TICKER  /  AWAITING OBSERVATIONS",11,CYAN,true);
    ticker.setSingleLine(true);ticker.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
    ticker.setMarqueeRepeatLimit(-1);ticker.setSelected(true);
    ticker.setPadding(dp(12),dp(9),dp(12),dp(9));ticker.setBackground(panel(0xFF185769));
    LayoutParams p=new LayoutParams(-1,dp(41));p.topMargin=dp(10);addView(ticker,p);
    TextView select=text("SELECT WORLD REGION   ›",12,GREEN,true);
    select.setGravity(Gravity.CENTER);select.setBackground(panel(GREEN));
    select.setOnClickListener(v->open(RunningballWorldExplorerActivity.class));
    LayoutParams choose=new LayoutParams(-1,dp(42));choose.topMargin=dp(9);addView(select,choose);
    render();
  }
  private static int satelliteCount(Context ctx){
    SharedPreferences sp=ctx.getSharedPreferences("rb10_satellite",Context.MODE_PRIVATE);
    try{JSONArray a=new JSONArray(sp.getString("data_STATIONS","[]"));int result=0;
      for(int i=0;i<a.length()&&i<100;i++){
        JSONObject o=a.optJSONObject(i);if(o==null)continue;
        String name=o.optString("OBJECT_NAME","");int norad=o.optInt("NORAD_CAT_ID",0);
        if(!name.isEmpty()&&norad>0)result++;
      }return result;
    }catch(Exception e){return 0;}
  }
  private static int vesselCount(Context ctx){
    try{SharedPreferences sp=ctx.getSharedPreferences("rb11_marine",Context.MODE_PRIVATE);
      JSONArray a=new JSONObject(sp.getString("rows","{}")).optJSONArray("rows");
      if(a==null)return 0;int c=0;
      for(int i=0;i<a.length()&&i<800;i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;
        if(GevMarineMath.validMmsi(o.optString("mmsi","")) && GevMarineMath.valid(o.optDouble("lat",Double.NaN),o.optDouble("lon",Double.NaN)))c++;
      }return c;
    }catch(Exception e){return 0;}
  }
  private String quakesRaw="",nasaRaw="";
  private int quakesCount=0,nasaCount=0;
  private int events(Context ctx,String kind){
    String raw=ctx.getSharedPreferences(EVENTS,Context.MODE_PRIVATE).getString(kind+"_raw","");
    if("quakes".equals(kind)&&raw.equals(quakesRaw))return quakesCount;
    if("nasa".equals(kind)&&raw.equals(nasaRaw))return nasaCount;
    int count=0;
    try{JSONArray a=new JSONObject(raw).optJSONArray("quakes".equals(kind)?"features":"events");
      if(a!=null)count=a.length();
    }catch(Exception ignored){count=0;}
    if("quakes".equals(kind)){quakesRaw=raw;quakesCount=count;}
    else{nasaRaw=raw;nasaCount=count;}
    return count;
  }
  private void update(String key,String figure,String detail,String source,int state){
    for(Cell c:cells)if(c.kind.equals(key)){
      boolean changed=!c.prev.isEmpty()&&!c.prev.equals(figure);
      c.prev=figure;c.signal.setState(state,changed);
      if(!figure.contentEquals(c.number.getText())){
        c.number.setText(figure);if(changed){c.number.setAlpha(.45f);c.number.animate().alpha(1f).setDuration(350).start();}
      }
      c.meta.setText(detail);c.source.setText(source);break;
    }
  }
  private void render(){
    Context ctx=getContext();long now=System.currentTimeMillis();
    SharedPreferences airsp=ctx.getSharedPreferences("air_widget_v2",Context.MODE_PRIVATE);
    JSONObject air=AirOperationsWidgets.lastData(ctx);
    long airTime=air.optLong("time",0L);
    boolean selected=RunningballWorldTarget.ready(ctx);
    if(!selected)airTime=0L;
    String regionName=RunningballWorldTarget.label(ctx);
    String airError=airsp.getString("last_error","");
    int airState=airTime<=0?0:(!airError.isEmpty()?3:freshness(airTime));
    update("AIR",airTime>0?String.valueOf(air.optInt("count",0)):"--",
      selected?"250 NM radius · "+(airTime>0?"regional report":"NO REPORT"):"CHOOSE A WORLD SECTOR",
      "ADSB.LOL  ·  "+ago(airTime)+(airError.isEmpty()?"":"  ·  FETCH ERROR"),airState);
    SharedPreferences sat=ctx.getSharedPreferences("rb10_satellite",Context.MODE_PRIVATE);
    long st=sat.getLong("data_STATIONS_time",0L);
    update("SAT",st>0?String.valueOf(satelliteCount(ctx)):"--","Catalogued entries, max 100 shown",
      "CELESTRAK  ·  "+ago(st),freshness(st));
    SharedPreferences sea=ctx.getSharedPreferences("rb11_marine",Context.MODE_PRIVATE);
    long mt=sea.getLong("last_fetch",0L);
    String gateway=sea.getString("status","not connected");
    update("SEA",mt>0?String.valueOf(vesselCount(ctx)):"--",mt>0?"Gateway: "+gateway:"HTTPS GATEWAY REQUIRED",
      "AIS SNAPSHOT  ·  "+ago(mt),mt<=0?0:freshness(mt));
    SharedPreferences globe=ctx.getSharedPreferences(EVENTS,Context.MODE_PRIVATE);
    long qt=globe.getLong("quakes_time",0L),nt=globe.getLong("nasa_time",0L);
    String qe=globe.getString("quakes_v16_error","");String ne=globe.getString("nasa_v16_error","");
    update("QUAKE",qt>0?String.valueOf(events(ctx,"quakes")):"--","M2.5+ · worldwide / past 24 h",
      "USGS  ·  "+ago(qt)+(qe.isEmpty()?"":"  ·  FETCH FAILED"),qt>0?(qe.isEmpty()?freshness(qt):3):0);
    update("NASA",nt>0?String.valueOf(events(ctx,"nasa")):"--","Open EONET events · max 65",
      "NASA EONET  ·  "+ago(nt)+(ne.isEmpty()?"":"  ·  FETCH FAILED"),nt>0?(ne.isEmpty()?freshness(nt):3):0);
    region.setText("WORLD REGION  /  "+regionName.toUpperCase(Locale.US));
    update("REGION",selected?"ACTIVE":"SELECT",selected?
      String.format(Locale.US,"%.3f°, %.3f°",RunningballWorldTarget.lat(ctx),RunningballWorldTarget.lon(ctx)):
      "NO TARGET · GLOBAL MAP AVAILABLE","WORLDWIDE LOCATION SELECTOR",selected?2:0);
    String state="AIR "+ago(airTime)+"  ·  SAT "+ago(st)+"  ·  AIS "+ago(mt)
      +"  ·  USGS "+ago(qt)+"  ·  NASA "+ago(nt);
    if(!state.equals(lastKey)){
      lastKey=state;tickerLines.clear();
      tickerLines.add("AIR  /  "+regionName+"  /  "+(airTime>0?air.optInt("count",0)+" REPORTED AIRCRAFT":"NO OBSERVATIONS")+"  /  "+ago(airTime));
      tickerLines.add("SAT  /  "+(st>0?satelliteCount(ctx)+" CATALOGUE ENTRIES":"NOT LOADED")+"  /  "+ago(st));
      tickerLines.add("SEA  /  "+(mt>0?vesselCount(ctx)+" VESSELS":"GATEWAY NOT CONNECTED")+"  /  "+ago(mt));
      tickerLines.add("USGS  /  "+(qt>0?events(ctx,"quakes")+" EARTHQUAKES M2.5+":"NOT LOADED")+"  /  "+ago(qt));
      tickerLines.add("NASA EONET  /  "+(nt>0?events(ctx,"nasa")+" OPEN EVENTS":"NOT LOADED")+"  /  "+ago(nt));
    }
    status.setText("DATA AGE SHOWN BELOW  ·  NUMBERS UPDATE ONLY FROM SOURCES");
  }
  private void rotateTicker(){if(tickerLines.isEmpty())return;
    ticker.setText(tickerLines.get(tickerIndex%tickerLines.size()));tickerIndex++;}
  public void start(){if(active)return;active=true;rail.start();render();lastCacheCheck=System.currentTimeMillis();lastTicker=0;
    handler.removeCallbacks(uiLoop);handler.post(uiLoop);
    RunningballV16SourceRefresh.request(getContext(),false,()->{if(active)render();});
    if(RunningballWorldTarget.ready(getContext())){
      // Existing command provider performs real regional ADS-B fetch with its own cache controls.
      // Do not poll this endpoint on a 700 ms UI animation tick.
      SharedPreferences rate=getContext().getSharedPreferences("rb16_app_refresh",Context.MODE_PRIVATE);
      long last=rate.getLong("air_requested",0L);long now=System.currentTimeMillis();
      if(last<=0L || now-last>300000L){
        rate.edit().putLong("air_requested",now).apply();
        Intent request=new Intent(getContext(),AirOperationsWidgets.Command.class);
        request.setAction("com.sentongoharuna.worldsituationroom.AIR_WIDGET_REFRESH");
        getContext().sendBroadcast(request);
      }
    }
  }
  public void stop(){active=false;rail.stop();handler.removeCallbacks(uiLoop);}
  @Override protected void onDetachedFromWindow(){stop();super.onDetachedFromWindow();}
}
