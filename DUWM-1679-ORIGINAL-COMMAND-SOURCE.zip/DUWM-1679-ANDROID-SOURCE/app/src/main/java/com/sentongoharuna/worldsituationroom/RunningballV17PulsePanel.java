package com.sentongoharuna.worldsituationroom;

import android.animation.ValueAnimator;
import android.os.Handler;
import android.os.Looper;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.Locale;

/** Three direct, sourced intelligence boards; no generated readings. */
public final class RunningballV17PulsePanel extends LinearLayout {
  private static final int CYAN=0xFF47D2DB,GREEN=0xFF47D2DB,GOLD=0xFF47D2DB,MUTED=0xFF668D95,INK=0xFFE4F4F8;
  private final Cell[] boards=new Cell[3];
  private PulseRail rail;
  private boolean active=false;
  private TextView newsTicker;
  private int tickerStep=0;
  private final Handler clock=new Handler(Looper.getMainLooper());
  private final Runnable tickerLoop=new Runnable(){@Override public void run(){
    if(!active)return;
    render();
    JSONArray a=RunningballV17Feeds.cached(getContext(),RunningballV17Feeds.NEWS).optJSONArray("articles");
    if(a!=null&&a.length()>0){JSONObject item=a.optJSONObject(tickerStep%a.length());
      if(item!=null)newsTicker.setText("WORLD NEWS  /  "+item.optString("domain","SOURCE")+"  /  "+item.optString("title","NO HEADLINE"));
      tickerStep++;
    }else newsTicker.setText("WORLD NEWS  /  "+(RunningballV17Feeds.error(getContext(),RunningballV17Feeds.NEWS).isEmpty()?"AWAITING VERIFIED HEADLINES":"SOURCE TEMPORARILY UNAVAILABLE"));
    clock.postDelayed(this,9200L);
  }};
  private static class Cell {
    TextView number,meta,source;View dot;String key;String prior="";HistoryLine history;
    Cell(String k,TextView n,TextView m,TextView s,View d,HistoryLine h){key=k;number=n;meta=m;source=s;dot=d;history=h;}
  }
  /** Real source-snapshot history; 0/1 sample renders a flat baseline, never a fake trend. */
  private final class HistoryLine extends View {
    private final Paint paint=new Paint(3);private final String key;private final int tint;
    HistoryLine(Context c,String k,int t){super(c);key=k;tint=t;setContentDescription("Historical successful source samples for "+k);}
    @Override protected void onDraw(Canvas c){super.onDraw(c);
      float w=getWidth(),h=getHeight();paint.setColor(0xFF185769);paint.setStrokeWidth(dp(1));
      c.drawLine(0,h*.7f,w,h*.7f,paint);
      try {
        SharedPreferences prefs=RunningballV17Feeds.data(getContext());
        JSONArray samples=new JSONArray(prefs.getString(key+"_history","[]"));
        int n=samples.length();if(n<2)return;
        float min=Float.POSITIVE_INFINITY,max=Float.NEGATIVE_INFINITY;
        float[] values=new float[n];
        for(int i=0;i<n;i++){JSONObject p=samples.optJSONObject(i);if(p==null)return;
          values[i]=(float)p.optDouble("value",Double.NaN);if(Float.isNaN(values[i]))return;
          min=Math.min(min,values[i]);max=Math.max(max,values[i]);}
        float span=Math.max(.001f,max-min);paint.setColor(tint);paint.setStrokeWidth(dp(2));
        for(int i=1;i<n;i++){
          float x1=(w*(i-1))/(n-1),x2=(w*i)/(n-1);
          float y1=h*.85f-((values[i-1]-min)/span)*h*.68f;
          float y2=h*.85f-((values[i]-min)/span)*h*.68f;
          c.drawLine(x1,y1,x2,y2,paint);
        }
      }catch(Exception ignored){}
    }
  }
  private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
  private TextView label(String t,int size,int color,boolean strong){TextView v=new TextView(getContext());v.setText(t);v.setTextSize(size);v.setTextColor(color);if(strong)v.setTypeface(null,1);return v;}
  private GradientDrawable card(int accent){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFF0F4251,0xFF081824});g.setStroke(dp(1),accent);g.setCornerRadius(dp(13));return g;}
  private View board(int i,String key,String heading,String desc,int tint){
    LinearLayout box=new LinearLayout(getContext());box.setOrientation(VERTICAL);box.setPadding(dp(13),dp(10),dp(12),dp(11));box.setBackground(card(0xFF185769));
    LinearLayout top=new LinearLayout(getContext());top.setGravity(Gravity.CENTER_VERTICAL);
    View dot=new View(getContext());GradientDrawable dg=new GradientDrawable();dg.setColor(tint);dg.setShape(GradientDrawable.OVAL);dot.setBackground(dg);top.addView(dot,new LayoutParams(dp(7),dp(7)));
    TextView t=label("  "+heading+"   ›",11,tint,true);top.addView(t);box.addView(top);
    TextView value=label("--",21,INK,true);LayoutParams vp=new LayoutParams(-1,-2);vp.topMargin=dp(3);box.addView(value,vp);
    TextView meta=label(desc,11,MUTED,false);meta.setMaxLines(2);box.addView(meta);
    TextView source=label("NOT LOADED",9,tint,false);LayoutParams sp=new LayoutParams(-1,-2);sp.topMargin=dp(7);box.addView(source,sp);
    HistoryLine history=new HistoryLine(getContext(),key,tint);
    LinearLayout.LayoutParams hp=new LayoutParams(-1,dp(18));hp.topMargin=dp(5);box.addView(history,hp);
    boards[i]=new Cell(key,value,meta,source,dot,history);
    box.setContentDescription("OPEN V17 "+key.toUpperCase(Locale.US)+" DETAIL");
    box.setOnClickListener(v->{Intent it=new Intent(getContext(),RunningballV17DetailsActivity.class);it.putExtra("feed",key);getContext().startActivity(it);});
    return box;
  }
  private void pair(View a,View b){LinearLayout row=new LinearLayout(getContext());
    row.setOrientation(HORIZONTAL);LayoutParams l=new LayoutParams(0,-2,1);l.rightMargin=dp(5);row.addView(a,l);
    LayoutParams r=new LayoutParams(0,-2,1);r.leftMargin=dp(5);row.addView(b,r);
    LayoutParams rp=new LayoutParams(-1,-2);rp.topMargin=dp(7);addView(row,rp);
  }
  private final class PulseRail extends View {
    Paint p=new Paint(3);ValueAnimator animation;float progress;
    PulseRail(Context c){super(c);}
    void start(){if(animation!=null)return;animation=ValueAnimator.ofFloat(0,1);animation.setDuration(4800);
      animation.setRepeatCount(ValueAnimator.INFINITE);animation.setInterpolator(new LinearInterpolator());
      animation.addUpdateListener(v->{progress=(Float)v.getAnimatedValue();invalidate();});animation.start();}
    void stop(){if(animation!=null){animation.cancel();animation=null;}}
    @Override protected void onDraw(Canvas canvas){float y=getHeight()/2f;p.setColor(0xFF185769);p.setStrokeWidth(dp(1));canvas.drawLine(0,y,getWidth(),y,p);
      p.setColor(CYAN);p.setStrokeWidth(dp(2));float start=(getWidth()+dp(60))*progress-dp(60);
      canvas.drawLine(Math.max(0,start),y,Math.min(getWidth(),start+dp(60)),y,p);}
  }
  public RunningballV17PulsePanel(Context c){super(c);setOrientation(VERTICAL);
    TextView subtitle=label("V17 / VERIFIED PUBLIC-SOURCE BULLETIN",10,GREEN,true);addView(subtitle);
    TextView title=label("WORLD NEWS  •  WEATHER  •  FX",16,INK,true);LayoutParams titlep=new LayoutParams(-1,-2);titlep.topMargin=dp(5);addView(title,titlep);
    rail=new PulseRail(c);LayoutParams railp=new LayoutParams(-1,dp(13));railp.topMargin=dp(4);addView(rail,railp);
    pair(board(0,RunningballV17Feeds.NEWS,"WORLD NEWS","Sourced global article list",CYAN),
         board(1,RunningballV17Feeds.WEATHER,"WEATHER","Selected-region model weather",GREEN));
    LayoutParams fx=new LayoutParams(-1,-2);fx.topMargin=dp(7);addView(board(2,RunningballV17Feeds.FX,"FX REFERENCE","USD / EUR • GBP • JPY — daily references",GOLD),fx);
    newsTicker=label("WORLD NEWS / AWAITING SOURCE",10,CYAN,true);
    newsTicker.setSingleLine(true);newsTicker.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
    newsTicker.setMarqueeRepeatLimit(-1);newsTicker.setSelected(true);
    newsTicker.setPadding(dp(10),dp(8),dp(10),dp(8));newsTicker.setBackground(card(0xFF2891A2));
    newsTicker.setOnClickListener(v->{Intent it=new Intent(getContext(),RunningballV17DetailsActivity.class);
      it.putExtra("feed",RunningballV17Feeds.NEWS);getContext().startActivity(it);});
    LinearLayout.LayoutParams tp=new LayoutParams(-1,dp(35));tp.topMargin=dp(9);addView(newsTicker,tp);
    TextView disclaimer=label("REAL SOURCE SAMPLES ONLY  ·  HISTORY APPEARS AFTER TWO DISTINCT REPORTS",9,MUTED,false);
    LayoutParams dp0=new LayoutParams(-1,-2);dp0.topMargin=dp(8);addView(disclaimer,dp0);
    render();
  }
  private String fmt(double d,int decimals){if(Double.isNaN(d)||Double.isInfinite(d))return "--";return String.format(Locale.US,"%."+decimals+"f",d);}
  private void update(int i,String figure,String meta,String source,boolean good){
    Cell c=boards[i];boolean changed=!c.prior.isEmpty()&&!c.prior.equals(figure);c.prior=figure;
    if(!figure.contentEquals(c.number.getText())){
      c.number.setText(figure);if(changed&&active){c.number.setAlpha(.45f);c.number.animate().alpha(1).setDuration(320).start();}
    }
    c.meta.setText(meta);c.source.setText(source);c.dot.setAlpha(good?1f:.3f);c.history.invalidate();
  }
  public void render(){Context c=getContext();
    JSONObject n=RunningballV17Feeds.cached(c,RunningballV17Feeds.NEWS);
    JSONArray articles=n.optJSONArray("articles");long nt=RunningballV17Feeds.received(c,RunningballV17Feeds.NEWS);
    String nerr=RunningballV17Feeds.error(c,RunningballV17Feeds.NEWS);
    String headline=articles!=null&&articles.length()>0?articles.optJSONObject(0).optString("title","NO HEADLINE"):"SOURCE NOT LOADED";
    update(0,nt>0&&articles!=null?""+articles.length():"--",
      "Retrieved stories: "+(headline.length()>65?headline.substring(0,64)+"…":headline),
      n.optString("provider","NEWS SOURCE")+" · "+RunningballV17Feeds.age(nt)+(nerr.isEmpty()?"":" · FETCH FAILED"),nt>0&&nerr.isEmpty());
    JSONObject w=RunningballV17Feeds.cached(c,RunningballV17Feeds.WEATHER);
    long wt=RunningballV17Feeds.received(c,RunningballV17Feeds.WEATHER);
    boolean selected=RunningballWorldTarget.ready(c);
    String sector=selected?String.format(Locale.US,"%.4f,%.4f",RunningballWorldTarget.lat(c),RunningballWorldTarget.lon(c)):"";
    boolean match=selected&&sector.equals(w.optString("region",""));
    double temp=w.optDouble("temperature",Double.NaN),wind=w.optDouble("wind",Double.NaN);
    String werr=RunningballV17Feeds.error(c,RunningballV17Feeds.WEATHER);
    update(1,match&&wt>0?fmt(temp,1)+"°C":"--",
      !selected?"SELECT A WORLD SECTOR":!match?"AWAITING SELECTED-REGION WEATHER":("Wind "+fmt(wind,0)+" km/h · model-derived"),
      "OPEN-METEO · "+(match?RunningballV17Feeds.age(wt):"NO CURRENT-REGION DATA")+(werr.isEmpty()?"":" · FETCH FAILED"),match&&wt>0&&werr.isEmpty());
    JSONObject f=RunningballV17Feeds.cached(c,RunningballV17Feeds.FX);JSONObject rates=f.optJSONObject("rates");
    long ft=RunningballV17Feeds.received(c,RunningballV17Feeds.FX);
    String ferr=RunningballV17Feeds.error(c,RunningballV17Feeds.FX);
    update(2,ft>0&&rates!=null?"USD/EUR "+fmt(rates.optDouble("EUR",Double.NaN),3):"--",
      ft>0&&rates!=null?"GBP "+fmt(rates.optDouble("GBP",Double.NaN),3)+"  ·  JPY "+fmt(rates.optDouble("JPY",Double.NaN),2):"OFFICIAL DAILY REFERENCES · NOT LIVE TRADES",
      "FRANKFURTER · "+f.optString("date","NO RATE DATE")+(ferr.isEmpty()?"":" · FETCH FAILED"),ft>0&&ferr.isEmpty());
  }
  public void start(){if(active)return;active=true;rail.start();render();clock.removeCallbacks(tickerLoop);clock.post(tickerLoop);
    RunningballV17Feeds.request(getContext(),false,()->{if(active)render();});}
  public void stop(){active=false;rail.stop();clock.removeCallbacks(tickerLoop);}
  @Override protected void onDetachedFromWindow(){stop();super.onDetachedFromWindow();}
}
