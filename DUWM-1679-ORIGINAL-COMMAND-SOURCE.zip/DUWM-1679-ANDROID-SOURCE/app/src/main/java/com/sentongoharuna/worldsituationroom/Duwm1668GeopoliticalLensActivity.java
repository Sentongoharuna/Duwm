package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

/** DUWM 1668. Actual-source geographic intelligence lens, not a simulated conflict map.
 * Shares the existing Natural Earth animated globe without changing its renderer or wallpaper.
 * Pin positions come solely from DuwmGeoObservationStore's provider observations.
 */
public final class Duwm1668GeopoliticalLensActivity extends Activity {
    private static final int BACK=Color.rgb(5,14,23), PANEL=Color.rgb(8,24,36);
    private static final int LINE=Color.rgb(24,87,105), WHITE=Color.rgb(215,231,234);
    private static final int SOFT=Color.rgb(92,127,134), LIME=Color.rgb(71,210,219);
    private static final int AQUA=Color.rgb(57,181,195);
    private static final String[] CATEGORIES={"ALL","AIRCRAFT","EARTHQUAKE","ISS","VESSEL"};
    private static final String[] REGIONS={"WORLD","AFRICA","EUROPE","MIDDLE EAST","ASIA","AMERICAS","PACIFIC"};
    private final ArrayList<DuwmGeoObservationStore.Fix> all=new ArrayList<>();
    private final ArrayList<DuwmGeoObservationStore.Fix> visible=new ArrayList<>();
    private String category="ALL",region="WORLD";
    private OperationsGlobeView earth;
    private LinearLayout records,categoryBar,regionBar;
    private TextView state,regionSummary,detail;
    private DuwmGeoObservationStore.Fix selected;
    private long lastLoaded=-1;

    private int dp(float n){return (int)(getResources().getDisplayMetrics().density*n+0.5f);}
    private TextView label(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);
        t.setFontFeatureSettings("tnum");if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        return t;
    }
    private GradientDrawable panel(int fill,int line){GradientDrawable d=new GradientDrawable();d.setColor(fill);
        d.setCornerRadius(dp(10));if(line!=0)d.setStroke(dp(1),line);return d;}
    private TextView control(String title,Runnable action){TextView t=label(title,11,WHITE,true);
        t.setGravity(Gravity.CENTER);t.setPadding(dp(12),dp(10),dp(12),dp(10));
        t.setBackground(panel(PANEL,LINE));t.setOnClickListener(v->action.run());return t;}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private String timestamp(long ms){if(ms<=0)return "SOURCE TIME UNAVAILABLE";
        SimpleDateFormat f=new SimpleDateFormat("dd MMM yyyy HH:mm 'UTC'",Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(ms));}
    private String freshness(long ms){if(ms<=0)return "UNKNOWN AGE";
        long m=Math.max(0,(System.currentTimeMillis()-ms)/60000L);
        if(ms>System.currentTimeMillis()+300000L)return "CLOCK MISMATCH";
        return m<60?m+" MIN AGO":m<1440?(m/60)+" HOURS AGO":(m/1440)+" DAYS AGO";}
    private void pad(LinearLayout root,int h){View v=new View(this);root.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}

    @Override public void onCreate(Bundle b){super.onCreate(b);
        getWindow().setStatusBarColor(BACK);getWindow().setNavigationBarColor(BACK);
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(BACK);
        LinearLayout root=vertical();root.setPadding(dp(14),dp(8),dp(14),dp(26));sc.addView(root);setContentView(sc);
        Duwm1167SafeArea.install(this,sc);
        LinearLayout masthead=new LinearLayout(this);masthead.setGravity(Gravity.CENTER_VERTICAL);
        TextView back=control("‹  HOME",()->finish());masthead.addView(back,new LinearLayout.LayoutParams(dp(90),dp(44)));
        TextView brand=label("  DEVELOP.UGANDA  /  1668",13,WHITE,true);
        brand.setGravity(Gravity.CENTER_VERTICAL);masthead.addView(brand,new LinearLayout.LayoutParams(0,-1,1));
        root.addView(masthead);
        pad(root,14);
        TextView name=label("GEOPOLITICAL  LENS",23,WHITE,true);root.addView(name);
        TextView disclaimer=label("OBSERVED POSITIONS • PROVIDER DATA ONLY • NO SIMULATED CONFLICTS",10,SOFT,false);
        disclaimer.setPadding(0,dp(5),0,dp(12));root.addView(disclaimer);
        state=label("READING SOURCE OBSERVATIONS…",11,AQUA,true);root.addView(state);pad(root,9);
        earth=new OperationsGlobeView(this);earth.setBackground(panel(PANEL,LINE));
        root.addView(earth,new LinearLayout.LayoutParams(-1,dp(286)));
        earth.setOnObservationSelected(v->{for(DuwmGeoObservationStore.Fix f:visible){
            if(f.title.equals(v.title)&&f.sourceTime==v.timeMillis){select(f,true);return;}}
        });
        TextView tip=label("DRAG TO ROTATE  •  PINCH TO ZOOM  •  TAP OBSERVED MARKERS",10,SOFT,false);
        tip.setPadding(0,dp(7),0,dp(9));root.addView(tip);
        regionSummary=label("AWAITING SAVED SOURCE FIXES",11,LIME,true);root.addView(regionSummary);
        pad(root,10);
        TextView hd=label("GEOGRAPHIC VIEW",11,SOFT,true);root.addView(hd);pad(root,6);
        HorizontalScrollView rgScroll=new HorizontalScrollView(this);rgScroll.setHorizontalScrollBarEnabled(false);
        regionBar=new LinearLayout(this);rgScroll.addView(regionBar);root.addView(rgScroll);
        pad(root,12);
        TextView layerHead=label("SOURCE LAYERS",11,SOFT,true);root.addView(layerHead);pad(root,6);
        HorizontalScrollView catScroll=new HorizontalScrollView(this);catScroll.setHorizontalScrollBarEnabled(false);
        categoryBar=new LinearLayout(this);catScroll.addView(categoryBar);root.addView(catScroll);
        pad(root,13);
        LinearLayout buttons=new LinearLayout(this);
        TextView sync=control("SYNC SOURCES",()->startActivity(new Intent(this,DuwmWorldIntelligenceActivity.class)));
        buttons.addView(sync,new LinearLayout.LayoutParams(0,dp(44),1));
        TextView map=control("FULL MAP",()->startActivity(new Intent(this,DuwmPlaceMapActivity.class)));
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(0,dp(44),1);mp.leftMargin=dp(8);buttons.addView(map,mp);
        root.addView(buttons);pad(root,12);
        detail=label("TAP AN OBSERVED RECORD TO INSPECT ITS SOURCE, TIME AND COORDINATES",11,SOFT,false);
        detail.setPadding(dp(12),dp(12),dp(12),dp(12));detail.setBackground(panel(PANEL,LINE));root.addView(detail);
        pad(root,14);
        TextView title=label("OBSERVATION REGISTER  /  RECEIVED FIXES",15,WHITE,true);root.addView(title);
        pad(root,6);records=vertical();root.addView(records);
        TextView policy=label("Provider records may be rate-limited or stale. Region selection uses approximate coordinate bounds, not political boundaries. " +
             "Missing observations are not counted as zero worldwide activity. Tracks require two verified positions.",10,SOFT,false);
        policy.setPadding(0,dp(16),0,0);root.addView(policy);
        configureBars();
    }
    @Override protected void onResume(){super.onResume();earth.resume();load();}
    @Override protected void onPause(){earth.pause();super.onPause();}
    private void configureBars(){regionBar.removeAllViews();for(String r:REGIONS){
        TextView t=control(r,()->{region=r;configureBars();render();});
        t.setTextColor(r.equals(region)?LIME:SOFT);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(43));p.rightMargin=dp(6);regionBar.addView(t,p);
    }
    categoryBar.removeAllViews();for(String c:CATEGORIES){
        TextView t=control(c,()->{category=c;configureBars();render();});t.setTextColor(c.equals(category)?AQUA:SOFT);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(43));p.rightMargin=dp(6);categoryBar.addView(t,p);
    }}
    private void load(){List<DuwmGeoObservationStore.Fix> recent=DuwmGeoObservationStore.read(this);
        all.clear();all.addAll(recent);Collections.sort(all,(a,b)->Long.compare(b.receivedAt,a.receivedAt));
        lastLoaded=System.currentTimeMillis();render();}
    private boolean regionMatch(DuwmGeoObservationStore.Fix f){
        double lat=f.lat,lon=f.lon;
        switch(region){
          case "WORLD":return true;
          case "AFRICA":return lat>=-36&&lat<=38&&lon>=-18&&lon<=52;
          case "EUROPE":return lat>=35&&lat<=72&&lon>=-26&&lon<=47;
          case "MIDDLE EAST":return lat>=12&&lat<=43&&lon>=32&&lon<=64;
          case "ASIA":return lat>=-12&&lat<=77&&lon>=64&&lon<=180;
          case "AMERICAS":return lat>=-56&&lat<=84&&lon>=-170&&lon<=-30;
          case "PACIFIC":return lon>=110||lon<=-125;
          default:return true;
        }
    }
    private String kindOf(DuwmGeoObservationStore.Fix f){String t=f.type.toUpperCase(Locale.ROOT);
        if(t.equals("VESSELS"))return "VESSEL";
        if(t.equals("EARTHQUAKES"))return "EARTHQUAKE";
        return t;}
    private void render(){if(earth==null||records==null)return;
        visible.clear();ArrayList<OperationsGlobeView.Observation> mapped=new ArrayList<>();
        long newest=0;
        for(DuwmGeoObservationStore.Fix f:all){
            if(!regionMatch(f)||(!category.equals("ALL")&&!kindOf(f).equals(category)))continue;
            visible.add(f);newest=Math.max(newest,f.receivedAt);
            int layer=kindOf(f).equals("AIRCRAFT")?OperationsGlobeView.AIR:
                    kindOf(f).equals("EARTHQUAKE")?OperationsGlobeView.QUAKE:
                    kindOf(f).equals("ISS")?OperationsGlobeView.SPACE:0;
            if(layer!=0)mapped.add(new OperationsGlobeView.Observation(layer,f.lat,f.lon,f.title,f.detail,f.provider,f.sourceTime));
        }
        earth.setObservations(mapped);
        int tracked=0;for(DuwmGeoObservationStore.Fix f:visible)if(f.hasActualTrack())tracked++;
        state.setText(all.size()+" STORED OBSERVED FIXES  •  " + visible.size()+" FILTERED  •  " +
            (newest>0?"LATEST RECEIPT "+freshness(newest):"NO RECEIPTS"));
        regionSummary.setText(region+"  /  "+category+"  •  "+mapped.size()+" GLOBE MARKERS  •  "+tracked+" REAL MOVEMENT PAIRS");
        records.removeAllViews();
        if(visible.isEmpty()){
            TextView empty=label("NO RECENT SOURCE FIXES FOR THIS SELECTION. Open SYNC SOURCES to request provider records. No simulated dots will appear.",12,SOFT,false);
            empty.setPadding(dp(12),dp(15),dp(12),dp(15));records.addView(empty);return;
        }
        int max=Math.min(visible.size(),65);
        for(int i=0;i<max;i++){
            DuwmGeoObservationStore.Fix f=visible.get(i);
            LinearLayout card=vertical();card.setBackground(panel(PANEL,LINE));
            card.setPadding(dp(11),dp(10),dp(11),dp(10));
            TextView cat=label(kindOf(f)+"  /  "+f.provider+"   •   "+freshness(f.receivedAt),10,LIME,true);card.addView(cat);
            TextView title=label(f.title,14,WHITE,true);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);
            card.addView(title);TextView coords=label(String.format(Locale.US,"%.3f°, %.3f°  •  %s",f.lat,f.lon,timestamp(f.sourceTime)),10,SOFT,false);
            card.addView(coords);
            if(f.hasActualTrack())card.addView(label("TWO DISTINCT OBSERVED FIXES AVAILABLE",10,AQUA,true));
            card.setOnClickListener(v->select(f,true));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(7);records.addView(card,lp);
        }
        if(visible.size()>max)records.addView(label("SHOWING "+max+" OF "+visible.size()+" STORED FIXES • filter by source or region",10,SOFT,false));
    }
    private void select(DuwmGeoObservationStore.Fix f,boolean focus){selected=f;
        if(focus)earth.focusAt(f.lat,f.lon);
        detail.setText(kindOf(f)+"  /  "+f.title+"\n"+f.detail+"\nPROVIDER: "+f.provider+
            "\nOBSERVED: "+timestamp(f.sourceTime)+"\nRECEIVED: "+timestamp(f.receivedAt)+
            String.format(Locale.US,"\nLOCATION: %.5f, %.5f",f.lat,f.lon)+
            (f.hasActualTrack()?"\nMOVEMENT: two actual fixes":"\nMOVEMENT: not established"));
        detail.setTextColor(WHITE);
        detail.setOnClickListener(v->recordOptions(f));
        android.widget.Toast.makeText(this,"Tap the detail panel to open or share this observed record",android.widget.Toast.LENGTH_SHORT).show();
    }
    private void recordOptions(DuwmGeoObservationStore.Fix f){
        new android.app.AlertDialog.Builder(this).setTitle("Observed source record")
            .setItems(new String[]{"Share source details","Open provider URL","Locate on globe"},(dialog,which)->{
                if(which==0){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT,"DEVELOP.UGANDA / SOURCE OBSERVATION\n"+
                        kindOf(f)+" — "+f.title+"\n"+f.detail+"\n"+
                        String.format(Locale.US,"%.5f, %.5f",f.lat,f.lon)+"\nSource: "+f.provider+
                        "\nObserved: "+timestamp(f.sourceTime)+"\n"+f.url);
                    startActivity(Intent.createChooser(i,"Share observed data"));
                }else if(which==1){if(f.url.startsWith("https://")){
                    try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(f.url)));}
                    catch(Exception e){android.widget.Toast.makeText(this,"No browser available",android.widget.Toast.LENGTH_SHORT).show();}}
                    else android.widget.Toast.makeText(this,"Source URL not available",android.widget.Toast.LENGTH_SHORT).show();
                }else earth.focusAt(f.lat,f.lon);
            }).show();
    }
}
