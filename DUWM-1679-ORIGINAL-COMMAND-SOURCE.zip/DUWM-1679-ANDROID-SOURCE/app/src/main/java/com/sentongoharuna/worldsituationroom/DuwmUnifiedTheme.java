package com.sentongoharuna.worldsituationroom;

/** Single DUWM look: original Command Center globe, dark navy surfaces, one cyan-teal accent.
 * The color system does not change data, positions, receipt timestamps or source state.
 */
public final class DuwmUnifiedTheme {
    private DuwmUnifiedTheme() {}
    public static final int BACKGROUND = 0xFF06121E;
    public static final int PANEL = 0xFF0B2432;
    public static final int PANEL_SELECTED = 0xFF12394B;
    public static final int BORDER = 0xFF286777;
    public static final int ACCENT = 0xFF47D2DB;
    public static final int ACCENT_BRIGHT = 0xFF83E7EC;
    public static final int TEXT = 0xFFE4F4F7;
    public static final int MUTED = 0xFF8DAFBC;
    public static final int UNAVAILABLE = 0xFF628B99;
}
