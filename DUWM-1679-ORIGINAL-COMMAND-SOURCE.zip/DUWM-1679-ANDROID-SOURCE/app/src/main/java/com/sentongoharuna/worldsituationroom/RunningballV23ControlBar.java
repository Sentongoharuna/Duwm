package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;
import java.util.Locale;

/** V23. Displays source truth; never synthesizes numbers, positions or events. */
public final class RunningballV23ControlBar extends LinearLayout {
  private static final int CYAN=0xFF47D2DB, GREEN=0xFF47D2DB, AMBER=0xFF47D2DB,
                           INK=0xFFE3F3F7, DIM=0xFFB9C6C9;
  private final Handler handler=new Handler(Looper.getMainLooper());
  private final TextView overview, last, feedHealth;
  private long lastRefreshTap=0;
  private boolean visible=false;
  private final Runnable tick=new Runnable(){@Override public void run(){
    if(!visible)return;render();handler.postDelayed(this,10000L);
  }};
  private int dp(int p){return Math.round(getResources().getDisplayMetrics().density*p);}
  private TextView label(String t,int size,int tint,boolean bold){
    TextView view=new TextView(getContext());view.setText(t);view.setTextSize(size);view.setTextColor(tint);
    if(bold)view.setTypeface(null,1);return view;
  }
  private GradientDrawable panel(int border){
    GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
      new int[]{0xFF104655,0xFF081824});d.setStroke(dp(1),border);d.setCornerRadius(dp(14));return d;
  }
  private SharedPreferences p(String file){return getContext().getApplicationContext().getSharedPreferences(file,Context.MODE_PRIVATE);}
  private static String freshness(long stamp,long maxAge){
    if(stamp<=0)return "NOT LOADED";
    long diff=Math.max(0,System.currentTimeMillis()-stamp);
    if(diff>maxAge)return "STALE / CACHED";
    long mins=diff/60000L;return mins==0?"RECENT <1M":"RECENT "+mins+"M";
  }
  private void open(Class<?> activity){getContext().startActivity(new Intent(getContext(),activity));}
  private TextView button(String title,final Runnable click){
    TextView text=label(title,11,CYAN,true);text.setGravity(Gravity.CENTER);
    text.setBackground(panel(0xFF2891A2));text.setPadding(dp(5),dp(14),dp(5),dp(14));
    text.setOnClickListener(v->click.run());return text;
  }
  private void actions(LinearLayout body,String a,Runnable actionA,String b,Runnable actionB){
    LinearLayout row=new LinearLayout(getContext());
    LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,-2);params.topMargin=dp(9);
    LinearLayout.LayoutParams left=new LinearLayout.LayoutParams(0,-2,1);left.rightMargin=dp(5);
    LinearLayout.LayoutParams right=new LinearLayout.LayoutParams(0,-2,1);right.leftMargin=dp(5);
    row.addView(button(a,actionA),left);row.addView(button(b,actionB),right);body.addView(row,params);
  }
  public RunningballV23ControlBar(Context context){super(context);setOrientation(VERTICAL);
    setPadding(dp(13),dp(12),dp(13),dp(13));setBackground(panel(0xFF39B5C3));
    addView(label("V23 / WORLD OPERATIONS CONTROL",13,CYAN,true));
    overview=label("CHECKING VERIFIED SOURCES…",12,INK,false);
    LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,-2);op.topMargin=dp(9);addView(overview,op);
    last=label("SOURCE CHANGES / NO REPORT YET",10,DIM,false);
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(8);addView(last,lp);
              feedHealth=label("WORLD NEWS AND NASA / AWAITING REPORTS",10,DIM,false);
              LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,-2);fp.topMargin=dp(8);addView(feedHealth,fp);
              actions(this,"WORLD MAP",()->open(RunningballWorldExplorerActivity.class),
                 "SOURCE HEALTH",()->open(RunningballV19SourceCenterActivity.class));
    actions(this,"REFRESH SOURCES",this::refresh,
                 "AIS / VESSELS",()->open(GevMarineActivity.class));
              actions(this,"WORLD NEWS",()->{
                Intent it=new Intent(getContext(),RunningballV17DetailsActivity.class);
                it.putExtra("feed",RunningballV17Feeds.NEWS);getContext().startActivity(it);
              },"NASA EVENTS",()->open(RunningballGlobalEventsActivity.class));
              render();
            }
            private void render(){
    Context context=getContext();
    String region=RunningballWorldTarget.ready(context)?RunningballWorldTarget.label(context):"SELECT WORLD REGION FOR AIR / WEATHER";
    long quake=p("rb_global_public_events").getLong("quakes_time",0L);
    long satellite=p("rb10_satellite").getLong("data_STATIONS_time",0L);
    long noaa=RunningballV19Noaa.received(context);
    String ais=p("rb11_marine").getString("endpoint","").trim().isEmpty()?"AIS NOT CONFIGURED":"AIS GATEWAY SET";
    overview.setText("REGION: "+region+"\nUSGS: "+freshness(quake,1200000L)+
      "    SAT: "+freshness(satellite,7200000L)+
      "\nNOAA: "+freshness(noaa,14400000L)+"    "+ais);
              long newsAt=p("rb17_verified_feeds").getLong("news_received",0L);
              long nasaAt=p("rb_global_public_events").getLong("nasa_time",0L);
              String provider=RunningballV17Feeds.cached(context,RunningballV17Feeds.NEWS).optString("provider","NOT CONNECTED");
              String coverage=p("rb_global_public_events").getString("nasa_coverage","NO NASA REPORT");
              feedHealth.setText("NEWS: "+freshness(newsAt,3600000L)+" / "+provider+
                "\nNASA: "+freshness(nasaAt,1200000L)+" / "+coverage);
              String changes=p("rb21_verified_changes").getString("updates","").trim();
    last.setText(changes.isEmpty()?"LATEST SOURCE CHANGE: NONE RECEIVED":
      "LATEST VERIFIED CHANGES\n"+changes);
  }
  private void refresh(){
    long now=System.currentTimeMillis();
    if(now-lastRefreshTap<60000L){last.setText("SOURCE REQUEST RATE-LIMITED / CHECK SOURCE HEALTH");return;}
    lastRefreshTap=now;
    last.setText("REQUESTS SENT / RESULTS NOT YET CONFIRMED");
    Context app=getContext().getApplicationContext();
    Runnable finished=()->handler.post(this::render);
    RunningballV16SourceRefresh.request(app,false,finished);
    RunningballV17Feeds.request(app,false,finished);
    RunningballV19SatelliteBootstrap.request(app,finished);
    RunningballV19Noaa.request(app,finished);
  }
  @Override protected void onAttachedToWindow(){super.onAttachedToWindow();visible=true;
    handler.removeCallbacks(tick);handler.post(tick);}
  @Override protected void onDetachedFromWindow(){visible=false;handler.removeCallbacks(tick);super.onDetachedFromWindow();}
}
