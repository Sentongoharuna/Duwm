package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Optional tools for the original command. No second globe is created or layered. */
public final class DuwmOptionsActivity extends Activity {
    private static final int BG = DuwmUnifiedTheme.BACKGROUND;
    private static final int WHITE = DuwmUnifiedTheme.TEXT;
    private static final int MUTED = DuwmUnifiedTheme.MUTED;
    private static final int CYAN = DuwmUnifiedTheme.ACCENT;
    private static final int TEAL = DuwmUnifiedTheme.PANEL;
    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(color); t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return t;
    }
    private GradientDrawable background() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(TEAL); d.setStroke(dp(1), Color.rgb(40,145,162));
        d.setCornerRadius(dp(10)); return d;
    }
    private void heading(LinearLayout root, String title) {
        TextView t = text(title, 12, CYAN, true);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin=dp(16); p.bottomMargin=dp(7);
        root.addView(t,p);
    }
    private void item(LinearLayout root,String title,String subtitle,Class<?> dest,String mediaMode) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setBackground(background());
        block.setPadding(dp(15),dp(12),dp(15),dp(12));
        TextView a=text(title,14,WHITE,true); block.addView(a);
        TextView b=text(subtitle,10,MUTED,false); block.addView(b);
        block.setMinimumHeight(dp(62));
        block.setContentDescription(title + ". " + subtitle);
        block.setOnClickListener(v->{
            Intent intent = new Intent(this,dest);
            if(mediaMode!=null) {
                if(dest==Duwm1671SectorActivity.class)
                    intent.putExtra(Duwm1671SectorActivity.EXTRA_KIND,mediaMode);
                else intent.putExtra("mode",mediaMode);
            }
            startActivity(intent);
        });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.bottomMargin=dp(7); root.addView(block,p);
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(BG); setContentView(shell);
        Duwm1167SafeArea.install(this,shell);
        Button home=new Button(this);home.setText("← ORIGINAL COMMAND / ONE GLOBE");
        home.setTextColor(CYAN);home.setAllCaps(false);home.setOnClickListener(v->finish());
        home.setBackground(background());
        LinearLayout.LayoutParams back=new LinearLayout.LayoutParams(-1,dp(48));
        back.setMargins(dp(12),dp(8),dp(12),dp(6));shell.addView(home,back);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);
        shell.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14),dp(7),dp(14),dp(24));scroll.addView(root);
        root.addView(text("DUWM / INTELLIGENCE OPTIONS",19,WHITE,true));
        TextView note=text("Your original live globe remains the home screen. These are optional, separate pages; no second globe is placed on top of it.",11,MUTED,false);
        root.addView(note);
        heading(root,"AIR, SEA & EARTH");
        item(root,"Aircraft tracker","Detailed flight reports, positions and trails",Duwm1670FlightMapActivity.class,null);
        item(root,"Maritime intelligence","Regional AIS and individual vessel details",GevMarineActivity.class,null);
        item(root,"Earthquakes","Received seismic events and magnitude history",Duwm1671SectorActivity.class,"EARTHQUAKES");
        item(root,"Weather","Provider forecasts and regional records",Duwm1671SectorActivity.class,"WEATHER");
        item(root,"Satellites and ISS","Orbital and received observation details",GevSatelliteActivity.class,null);
        item(root,"Geographic watchlist","Saved locations, radius and source positions",Duwm1676GeoWatchActivity.class,null);
        item(root,"Place maps","Streets, boundaries and geographic sources",DuwmPlaceMapActivity.class,null);
        heading(root,"NEWS & MEDIA");
        item(root,"World news","Headlines, photos and source-backed stories",Duwm1166NewsDeskActivity.class,null);
        item(root,"News atlas","Regional publishers and geographic news",Duwm1670NewsAtlasActivity.class,null);
        item(root,"Radio stations","Radio atlas with in-app station playback",Duwm1166RadioAtlasActivity.class,null);
        item(root,"TV stations","Native player for available TV streams",MediaDeskActivity.class,"TV STATIONS");
        item(root,"Public cameras","Real public feeds and refreshed snapshots",MediaDeskActivity.class,"PUBLIC CAMERAS");
        item(root,"NASA Earth images","Observed Earth imagery and image details",RunningballV107EpicActivity.class,null);
        heading(root,"DATA, RECORDS & SOURCES");
        item(root,"World markets","FX history and provider receipts",Duwm1671SectorActivity.class,"MARKETS");
        item(root,"Source health","Failures, last receipt times and diagnostics",Duwm1671SourceStatusActivity.class,null);
        item(root,"Evidence vault","Saved source status snapshots and exports",Duwm1675EvidenceVaultActivity.class,null);
        item(root,"World source directory","Discover registered external data providers",Duwm1669SourceDirectoryActivity.class,null);
        item(root,"Geopolitical lens","Geographic views of sourced events",Duwm1668GeopoliticalLensActivity.class,null);
        item(root,"Local reports","Local-source monitoring and report details",LocalMonitorActivity.class,null);
    }
}
