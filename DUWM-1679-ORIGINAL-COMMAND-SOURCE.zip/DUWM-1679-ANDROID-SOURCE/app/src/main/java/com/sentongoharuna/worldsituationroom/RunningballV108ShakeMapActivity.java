package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Independent V108 USGS ShakeMap source-card implementation.
 * Shaking-intensity images are modelled/observed intensity maps, NOT ground photographs.
 * Only products attributed to USGS (source=us) are accepted for source image sharing.
 * Official earthquake data alone does not imply a ShakeMap exists. */
public final class RunningballV108ShakeMapActivity extends Activity {
  static final String FEED="https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_week.geojson";
  private static final int INK=0xFFE3F3F7, CYAN=0xFF47D2DB, GREEN=0xFF47D2DB, AMBER=0xFF47D2DB;
  private final ExecutorService io=Executors.newSingleThreadExecutor();
  private volatile boolean closed=false;
  private TextView status,title,source,description;
  private ImageView preview;
  private Button share;
  private Record current;
  private long lastTap;
  static final class Record {
    final String id,place,eventUrl,photoUrl;
    final long when;
    final double magnitude,lat,lon;
    Record(String id,String place,String eventUrl,String photoUrl,long when,double magnitude,double lat,double lon){
      this.id=id;this.place=place;this.eventUrl=eventUrl;this.photoUrl=photoUrl;
      this.when=when;this.magnitude=magnitude;this.lat=lat;this.lon=lon;
    }
  }
  private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
  private TextView label(String value,int size,int color){TextView t=new TextView(this);t.setText(value);t.setTextColor(color);t.setTextSize(size);return t;}
  private Button action(String name){Button b=new Button(this);b.setText(name);b.setAllCaps(false);b.setMinHeight(dp(52));b.setTextColor(INK);b.setBackgroundColor(0xFF135265);return b;}
  @Override public void onCreate(Bundle saved){super.onCreate(saved);
    RunningballV17Insets.install(this);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(0xFF081824);
    LinearLayout col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);
    col.setPadding(dp(16),dp(18),dp(16),dp(32));scroll.addView(col);setContentView(scroll);
    col.addView(label("RUNNINGBALL2 V108 / USGS EARTHQUAKE SOURCE IMAGE",12,GREEN));
    col.addView(label("USGS SHAKEMAP SHARE CARD",25,INK));
    col.addView(label("Official earthquake event + its own USGS shaking-intensity image when available",12,CYAN));
    status=label("USGS SOURCE NOT CHECKED",13,AMBER);status.setPadding(0,dp(12),0,dp(10));col.addView(status);
    preview=new ImageView(this);preview.setBackgroundColor(0xFF0D3946);preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
    col.addView(preview,new LinearLayout.LayoutParams(-1,dp(265)));
    title=label("NO EARTHQUAKE REPORT LOADED",18,INK);col.addView(title);
    description=label("No quake source image is fabricated",13,AMBER);col.addView(description);
    source=label("USGS / OBSERVATION TIME NOT RECEIVED",12,CYAN);source.setPadding(0,dp(10),0,dp(12));col.addView(source);
    share=action("SHARE SOURCE-ATTRIBUTED EARTHQUAKE CARD");share.setEnabled(false);col.addView(share);
    share.setOnClickListener(v->shareActual());
    Button refresh=action("REFRESH USGS EARTHQUAKES / SHAKEMAP");col.addView(refresh);
    refresh.setOnClickListener(v->{long now=System.currentTimeMillis();if(now-lastTap<60000L){status.setText("REFRESH COOLDOWN / 60 SEC");return;}lastTap=now;refresh();});
    Button page=action("OPEN ORIGINAL USGS EARTHQUAKE RECORD");col.addView(page);
    page.setOnClickListener(v->{Record r=current;if(r!=null){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(r.eventUrl)));}catch(Exception ex){status.setText("BROWSER UNAVAILABLE");}}});
    col.addView(label("USGS SHAKEMAP = ESTIMATED AND OBSERVED SHAKING INTENSITY, NOT A PHOTO OF DAMAGE. NO PRODUCT IMAGE = FACTUAL CARD ONLY. NO USGS ENDORSEMENT.",11,AMBER));
    refresh();
  }
  static String checkImageUrl(String address) {
    try{
      URL url=new URL(address);
      if(!"https".equals(url.getProtocol())||!"earthquake.usgs.gov".equalsIgnoreCase(url.getHost())||
         url.getQuery()!=null||url.getUserInfo()!=null||url.getPort()!=-1||
         !url.getPath().matches("/product/shakemap/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/[0-9]{1,14}/download/intensity\\.jpg"))return "";
      return address;
    }catch(Exception invalid){return "";}
  }
  private static byte[] download(String endpoint,int max) throws Exception {
    HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection();
    try{
      c.setConnectTimeout(8000);c.setReadTimeout(10000);c.setInstanceFollowRedirects(false);
      c.setRequestProperty("User-Agent","RUNNINGBALL2/V108 USGS source credit");
      if(c.getResponseCode()!=200)throw new IllegalStateException("USGS HTTP "+c.getResponseCode());
      if(c.getContentLengthLong()>max)throw new IllegalStateException("USGS response too large");
      ByteArrayOutputStream out=new ByteArrayOutputStream();
      try(InputStream in=c.getInputStream()){
        byte[] b=new byte[8192];int n;
        while((n=in.read(b))!=-1){if(out.size()+n>max)throw new IllegalStateException("USGS response limit");out.write(b,0,n);}
      }
      return out.toByteArray();
    }finally{c.disconnect();}
  }
  private static String utc(long t){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(t));}
  private static boolean valid(double x,double min,double max){return !Double.isNaN(x)&&!Double.isInfinite(x)&&x>=min&&x<=max;}
  private static Record candidate(JSONObject feature) {
    String id=feature.optString("id","");if(!id.matches("[A-Za-z0-9_-]{6,40}"))return null;
    JSONObject properties=feature.optJSONObject("properties"),geometry=feature.optJSONObject("geometry");
    if(properties==null||geometry==null)return null;
    JSONArray coord=geometry.optJSONArray("coordinates");if(coord==null||coord.length()<2)return null;
    double lon=coord.optDouble(0,Double.NaN),lat=coord.optDouble(1,Double.NaN),mag=properties.optDouble("mag",Double.NaN);
    long time=properties.optLong("time",0L);
    if(!valid(lat,-90,90)||!valid(lon,-180,180)||!valid(mag,-2,10)||time<=0L||time>System.currentTimeMillis()+86400000L)return null;
    return new Record(id,properties.optString("place","UNSPECIFIED LOCATION"),
      "https://earthquake.usgs.gov/earthquakes/eventpage/"+id,"",time,mag,lat,lon);
  }
  private static String verifiedShakeMap(JSONObject detail) {
    JSONObject properties=detail.optJSONObject("properties");if(properties==null)return "";
    JSONObject products=properties.optJSONObject("products");if(products==null)return "";
    JSONArray maps=products.optJSONArray("shakemap");if(maps==null)return "";
    for(int i=0;i<maps.length();i++){
      JSONObject product=maps.optJSONObject(i);if(product==null)continue;
      if(!"us".equals(product.optString("source",""))||"DELETE".equals(product.optString("status","")))continue;
      JSONObject contents=product.optJSONObject("contents");if(contents==null)continue;
      JSONObject picture=contents.optJSONObject("download/intensity.jpg");if(picture==null)continue;
      String approved=checkImageUrl(picture.optString("url",""));if(!approved.isEmpty())return approved;
    }
    return "";
  }
  private static String checkedDetail(String link) {
    try{URL u=new URL(link);if(!"https".equals(u.getProtocol())||!"earthquake.usgs.gov".equals(u.getHost())||
      u.getQuery()!=null||u.getUserInfo()!=null||u.getPort()!=-1||
      !u.getPath().matches("/earthquakes/feed/v1\\.0/detail/[A-Za-z0-9_-]+\\.geojson"))return "";return link;}
    catch(Exception e){return "";}
  }
  private static Record fromLiveFeed() throws Exception {
    JSONObject feed=new JSONObject(new String(download(FEED,900000),"UTF-8"));
    JSONArray rows=feed.optJSONArray("features");if(rows==null)throw new IllegalStateException("USGS features missing");
    Record first=null;int probes=0;
    for(int i=0;i<Math.min(rows.length(),60);i++){
      JSONObject row=rows.optJSONObject(i);if(row==null)continue;
      Record record=candidate(row);if(record==null)continue;
      if(first==null||record.when>first.when)first=record;
      JSONObject props=row.optJSONObject("properties");
      if(props==null||!props.optString("types","").contains(",shakemap,"))continue;
      String detail=checkedDetail(props.optString("detail",""));if(detail.isEmpty()||probes++>=3)continue;
      try {
        JSONObject full=new JSONObject(new String(download(detail,1200000),"UTF-8"));
        if(!record.id.equals(full.optString("id","")))continue; // exact-event association
        String image=verifiedShakeMap(full);
        if(!image.isEmpty())return new Record(record.id,record.place,record.eventUrl,image,record.when,record.magnitude,record.lat,record.lon);
      }catch(Exception ignored){} // a missing ShakeMap is never turned into a random image
    }
    if(first==null)throw new IllegalStateException("USGS returned no valid earthquake reports");
    return first; // factual fallback: no ShakeMap image
  }
  private void refresh() {
    status.setText("CHECKING SOURCE / REAL USGS REPORTS ONLY");
    io.execute(()->{
      Record r=null;Bitmap bitmap=null;String error="";
      try{
        r=fromLiveFeed();
        if(!r.photoUrl.isEmpty()){
          try{byte[] data=download(r.photoUrl,2000000);BitmapFactory.Options o=new BitmapFactory.Options();o.inSampleSize=2;bitmap=BitmapFactory.decodeByteArray(data,0,data.length,o);}
          catch(Exception ignored){} // sharing still validates media in the main share renderer
        }
      }catch(Exception e){error=e.getClass().getSimpleName()+": "+String.valueOf(e.getMessage());}
      final Record result=r;final Bitmap photo=bitmap;final String problem=error;
      runOnUiThread(()->{
        if(closed){if(photo!=null)photo.recycle();return;}
        if(result!=null){current=result;share.setEnabled(true);title.setText(String.format(Locale.US,"M%.1f / %s",result.magnitude,result.place));
          description.setText(result.photoUrl.isEmpty()?"NO VERIFIED SHAKEMAP IMAGE / TEXT + OBSERVED COORDINATES ONLY":"USGS SHAKEMAP INTENSITY IMAGE / ACTUAL EVENT PRODUCT");
          source.setText("USGS EVENT "+result.id+" / "+utc(result.when)+" / IMAGE: "+(result.photoUrl.isEmpty()?"NOT AVAILABLE":"USGS PRODUCT"));
          if(photo!=null)preview.setImageBitmap(photo);else preview.setImageDrawable(null);
          status.setText(result.photoUrl.isEmpty()?"EARTHQUAKE RECEIVED / NO SHAKEMAP":"USGS SOURCE IMAGE VERIFIED FOR THIS EVENT");
        }else{status.setText("SOURCE ERROR / "+problem+" / LAST VALID REPORT RETAINED");}
      });
    });
  }
  private void shareActual(){
    Record r=current;if(r==null){status.setText("NO SOURCE REPORT TO SHARE");return;}
    Map<String,String> facts=new LinkedHashMap<>();
    facts.put("EVENT ID",r.id);facts.put("MAGNITUDE",String.format(Locale.US,"%.1f",r.magnitude));
    facts.put("OBSERVED UTC",utc(r.when));facts.put("COORDINATE ORIGIN","SOURCE_REPORTED");
    facts.put("MAP TYPE","USGS SHAKEMAP SHAKING INTENSITY / NOT PHOTOGRAPHIC DAMAGE");
    if(!r.photoUrl.isEmpty()){
      facts.put("IMAGE",r.photoUrl);facts.put("IMAGE_RECORD_URL",r.eventUrl);
      facts.put("IMAGE_CREDIT","U.S. GEOLOGICAL SURVEY / SHAKEMAP");facts.put("IMAGE_LICENSE","USGS_PUBLIC_DOMAIN");
    }
    ShareCardData card=new ShareCardData("EARTHQUAKE / USGS",String.format(Locale.US,"M%.1f / %s",r.magnitude,r.place),
      "SOURCE-REPORTED EARTHQUAKE","USGS SHAKEMAP WHEN AVAILABLE","QUAKE","WORLDWIDE",1,
      "U.S. GEOLOGICAL SURVEY",r.eventUrl,r.when,r.lat,r.lon,facts,CYAN,
      "USGS EVENT + SOURCE INTENSITY IMAGE / MAP IS SHAKING ESTIMATE / NO ENDORSEMENT");
    ShareCardRenderer.share(this,card);
  }
  @Override protected void onDestroy(){closed=true;io.shutdownNow();super.onDestroy();}
}
