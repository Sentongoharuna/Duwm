package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.EditText;
import android.text.Editable;
import android.text.TextWatcher;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** RUNNINGBALL2 GEV Port 04 — satellite catalogue and approximate orbital ground tracks.
 * Unlike ADS-B, no observation of satellite positions is provided. All satellite
 * coordinates are calculated from CelesTrak mean elements using 2-body Kepler
 * dynamics. These are approximate estimates, NOT precision SGP4 positions.
 * CelesTrak is the source; no paid keys required. */
public final class GevSatelliteActivity extends Activity {
    private static final String PREF="rb10_satellite";
    private static final String BASE="https://celestrak.org/NORAD/elements/gp.php?GROUP=";
    private static final int BACK=Color.rgb(5,14,23), PANEL=Color.rgb(8,24,36), INK=Color.rgb(224,239,243);
    private static final int CYAN=Color.rgb(71,210,219), MUTED=Color.rgb(57,181,195), GREEN=Color.rgb(71,210,219),AMBER=Color.rgb(71,210,219);
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService pool=Executors.newSingleThreadExecutor();
    private final ArrayList<Sat> items=new ArrayList<>();
    private TextView banner,record,meta,selection,foot;
    private LinearLayout list;
    private EditText query;
    private int selected=-1;
    private String group="STATIONS";
    private long downloadMs;
    private boolean loading;
    private final Runnable tick=new Runnable(){@Override public void run(){if(!isFinishing()){render();ui.postDelayed(this,15000L);}}};
    private static final class Sat {
        String name,epoch;
        int norad;
        double mm,ecc,inc,raan,arg,mean;
        long epochMs;
        GevOrbitMath.Position at(long time){return GevOrbitMath.propagate(mm,ecc,inc,raan,arg,mean,epochMs,time);}
    }
    private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable card(boolean highlighted){GradientDrawable d=new GradientDrawable();d.setColor(PANEL);
        d.setCornerRadius(dp(23));d.setStroke(dp(1),highlighted?CYAN:Color.rgb(24,87,105));return d;}
    private TextView label(String text,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(text);t.setTextSize(sp);
        t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    private TextView action(String name,Runnable run){TextView t=label(name,12,CYAN,true);t.setGravity(Gravity.CENTER);t.setBackground(card(false));t.setOnClickListener(v->run.run());return t;}
    @Override protected void onCreate(Bundle s){super.onCreate(s);RunningballV17Insets.install(this);getWindow().setStatusBarColor(BACK);getWindow().setNavigationBarColor(BACK);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BACK);root.setPadding(dp(12),dp(10),dp(12),dp(10));
        root.addView(label("RUNNINGBALL2 / GOD'S EYE VIEW PORT 04",11,CYAN,true),new LinearLayout.LayoutParams(-1,dp(25)));
        root.addView(label("SATELLITE INTELLIGENCE",23,INK,true),new LinearLayout.LayoutParams(-1,dp(42)));
        banner=label("LOADING PUBLIC ORBITAL ELEMENTS",12,AMBER,false);root.addView(banner,new LinearLayout.LayoutParams(-1,dp(35)));
        LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.HORIZONTAL);
        TextView stations=action("SPACE STATIONS",()->switchGroup("STATIONS"));controls.addView(stations,new LinearLayout.LayoutParams(0,dp(46),1f));
        TextView gps=action("GPS SATELLITES",()->switchGroup("GPS-OPS"));LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(0,dp(46),1f);gp.leftMargin=dp(7);controls.addView(gps,gp);
        TextView refresh=action("REFRESH",()->fetch(true));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(dp(82),dp(46));rp.leftMargin=dp(7);controls.addView(refresh,rp);
        root.addView(controls);
        query=new EditText(this);query.setSingleLine();query.setTextColor(INK);query.setHintTextColor(MUTED);query.setTextSize(14);
        query.setHint("Search satellite name or NORAD ID");query.setPadding(dp(16),0,dp(16),0);query.setBackground(card(false));
        LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(-1,dp(46));qp.topMargin=dp(9);root.addView(query,qp);
        record=label("CATALOGUE: --",12,CYAN,true);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(27));cp.topMargin=dp(6);root.addView(record,cp);
        ScrollView scrolling=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
        scrolling.addView(list);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,0,1f);root.addView(scrolling,lp);
        selection=label("SELECT A SATELLITE TO VIEW THE PREDICTED GROUND POSITION",12,INK,true);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(42));sp.topMargin=dp(7);root.addView(selection,sp);
        meta=label("ORBITAL ESTIMATES, NOT LIVE SATELLITE LOCATION OBSERVATIONS",11,AMBER,false);
        root.addView(meta,new LinearLayout.LayoutParams(-1,dp(64)));
        LinearLayout bottom=new LinearLayout(this);bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.addView(action("EARTH POSITION",this::openEarth),new LinearLayout.LayoutParams(0,dp(46),1f));
        LinearLayout.LayoutParams sh=new LinearLayout.LayoutParams(0,dp(46),1f);sh.leftMargin=dp(7);
        bottom.addView(action("SHARE CARD",this::share),sh);root.addView(bottom);
        foot=label("CELESTRAK OMM • KEPLER APPROX. • NO SGP4 • NOT FOR NAVIGATION",10,MUTED,false);
        root.addView(action("MARITIME / VESSELS",()->startActivity(new Intent(this,GevMarineActivity.class))),new LinearLayout.LayoutParams(-1,dp(40)));
        root.addView(foot,new LinearLayout.LayoutParams(-1,dp(33)));setContentView(root);
        query.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}
            public void onTextChanged(CharSequence s,int st,int before,int count){renderList();}
            public void afterTextChanged(Editable e){} });
        restore();fetch(false);
    }
    private void switchGroup(String next){if(next.equals(group))return;group=next;selected=-1;items.clear();query.setText("");restore();fetch(false);}
    private SharedPreferences prefs(){return getSharedPreferences(PREF,MODE_PRIVATE);}
    private String key(){return "data_"+group;}
    private void restore(){String raw=prefs().getString(key(),"[]");downloadMs=prefs().getLong(key()+"_time",0L);parse(raw);render();GevSatelliteWidget.updateAll(this);RunningballV14SignalWidget.updateAll(this);}
    private static long parseEpoch(String epoch){try{
        String s=epoch.replace("Z","");int dot=s.indexOf('.');if(dot>=0){String fraction=s.substring(dot+1);
            if(fraction.length()>3)fraction=fraction.substring(0,3);
            while(fraction.length()<3)fraction+="0";s=s.substring(0,dot)+"."+fraction;
        }else{s+=".000";}
        SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS",Locale.US);fmt.setLenient(false);
        fmt.setTimeZone(TimeZone.getTimeZone("UTC"));Date d=fmt.parse(s);return d==null?0L:d.getTime();
    }catch(Exception e){return 0L;}}
    private void parse(String raw){items.clear();try{JSONArray arr=new JSONArray(raw);
       for(int i=0;i<arr.length()&&items.size()<100;i++){
         JSONObject j=arr.optJSONObject(i);if(j==null)continue;Sat s=new Sat();
         s.name=j.optString("OBJECT_NAME","");s.norad=j.optInt("NORAD_CAT_ID",0);
         s.epoch=j.optString("EPOCH","");s.epochMs=parseEpoch(s.epoch);
         s.mm=j.optDouble("MEAN_MOTION",Double.NaN);s.ecc=j.optDouble("ECCENTRICITY",Double.NaN);
         s.inc=j.optDouble("INCLINATION",Double.NaN);s.raan=j.optDouble("RA_OF_ASC_NODE",Double.NaN);
         s.arg=j.optDouble("ARG_OF_PERICENTER",Double.NaN);s.mean=j.optDouble("MEAN_ANOMALY",Double.NaN);
         if(!s.name.isEmpty()&&s.norad>0&&s.epochMs>0&&GevOrbitMath.validElements(s.mm,s.ecc,s.inc,s.raan,s.arg,s.mean))items.add(s);
       }
    }catch(Exception ignored){}if(selected>=items.size())selected=-1;}
    private void fetch(boolean user){if(loading)return;
        long age=System.currentTimeMillis()-downloadMs;
        if(!user&&!items.isEmpty()&&age>=0&&age<6*3600000L){render();return;}
        loading=true;banner.setText("REQUESTING "+group+" FROM CELESTRAK …");
        final String forGroup=group;
        pool.execute(()->{
            String raw=null, error=null;
            HttpURLConnection con=null;
            try{URL url=new URL(BASE+forGroup+"&FORMAT=JSON");con=(HttpURLConnection)url.openConnection();
                con.setRequestProperty("User-Agent","RUNNINGBALL2-SatelliteMonitor/10");
                con.setConnectTimeout(9000);con.setReadTimeout(11000);
                int code=con.getResponseCode();if(code!=200)throw new IllegalStateException("HTTP "+code);
                try(InputStream stream=con.getInputStream();ByteArrayOutputStream b=new ByteArrayOutputStream()){
                    byte[] buf=new byte[4096];int n;while((n=stream.read(buf))!=-1){b.write(buf,0,n);if(b.size()>600000)throw new IllegalStateException("Catalogue too large");}
                    raw=b.toString("UTF-8");
                }
                if(!raw.trim().startsWith("["))throw new IllegalStateException("Invalid JSON catalogue");
            }catch(Exception e){error=e.getMessage();}finally{if(con!=null)con.disconnect();}
            final String body=raw,err=error;
            ui.post(()->{if(isFinishing()||isDestroyed())return;loading=false;
                if(!forGroup.equals(group))return;
                if(body!=null){parse(body);if(!items.isEmpty()){
                    downloadMs=System.currentTimeMillis();prefs().edit().putString(key(),body)
                        .putLong(key()+"_time",downloadMs).apply();banner.setText("CATALOGUE RECEIVED • PREDICTED ORBITS");
                }else banner.setText("SOURCE RETURNED NO USABLE ORBITS");}
                else banner.setText("OFFLINE / CACHED ORBITS • "+(err==null?"UNKNOWN ERROR":err));
                render();GevSatelliteWidget.updateAll(this);RunningballV14SignalWidget.updateAll(this);
            });
        });
    }
    private static String utc(long ms){if(ms<=0)return "UNKNOWN";SimpleDateFormat f=new SimpleDateFormat("dd MMM HH:mm 'UTC'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(ms));}
    private void render(){record.setText(group+"  •  "+items.size()+" ORBITAL RECORDS  •  "+utc(downloadMs));renderList();showSelected();}
    private void renderList(){if(list==null)return;list.removeAllViews();long now=System.currentTimeMillis();String f=query==null?"":query.getText().toString().trim().toLowerCase(Locale.US);int count=0;
        for(int i=0;i<items.size();i++){Sat sat=items.get(i);if(!f.isEmpty()&&!sat.name.toLowerCase(Locale.US).contains(f)&&!String.valueOf(sat.norad).contains(f))continue;
            if(count++>=45)break;final int ix=i;
            GevOrbitMath.Position p=sat.at(now);TextView row=label(sat.name+"  •  #"+sat.norad+"\n"+
                (p.valid?String.format(Locale.US,"EST %.1f°, %.1f°  •  %.0f KM",p.lat,p.lon,p.altKm):"ELEMENTS INVALID"),12,
                i==selected?CYAN:INK,i==selected);
            row.setPadding(dp(13),dp(7),dp(10),dp(7));row.setBackground(card(i==selected));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(67));lp.bottomMargin=dp(6);list.addView(row,lp);
            row.setOnClickListener(v->{selected=ix;render();});
        }
        if(count==0){TextView empty=label("NO MATCHING SATELLITES • UPDATE OR CHANGE GROUP",12,MUTED,false);list.addView(empty);}
    }
    private String nextEstimatedPass(Sat sat,long now){
        // Coarse orbital forecast; two-body model, 3-minute grid, NOT SGP4.
        GevOrbitMath.Position current=sat.at(now);
        if(GevOrbitMath.elevationDeg(current,RunningballWorldTarget.lat(this),RunningballWorldTarget.lon(this))>=10d)return "EST ABOVE 10° NOW";
        for(long t=now+180000L;t<=now+86400000L;t+=180000L){
            double elev=GevOrbitMath.elevationDeg(sat.at(t),RunningballWorldTarget.lat(this),RunningballWorldTarget.lon(this));
            if(!Double.isNaN(elev)&&elev>=10d)return "EST NEXT >10° "+utc(t);
        }
        return "NO EST >10° PASS IN 24H";
    }
    private void showSelected(){if(selection==null||meta==null)return;
        if(selected<0||selected>=items.size()){
            selection.setText("SELECT A SATELLITE • POSITIONS ARE ESTIMATED");meta.setText("SOURCE: CELESTRAK • TWO-BODY KEPLER ESTIMATE; NOT SGP4 • NO LIVE TRACKING");return;
        }
        Sat s=items.get(selected);long now=System.currentTimeMillis();GevOrbitMath.Position p=s.at(now);
        long elementAge=Math.abs(now-s.epochMs);String quality=elementAge>72L*3600000L?"OLD ELEMENTS — LOW CONFIDENCE":"APPROXIMATE TWO-BODY ORBIT";
        selection.setText(s.name+" • NORAD "+s.norad);
        if(!p.valid){meta.setText("POSITION UNAVAILABLE • CHECK SOURCE ELEMENTS");return;}
        double elev=GevOrbitMath.elevationDeg(p,RunningballWorldTarget.lat(this),RunningballWorldTarget.lon(this));
        meta.setText(String.format(Locale.US,"EST %.3f°, %.3f°  •  %.0f KM ALT  •  %.0f MIN PERIOD\nSELECTED REGION ELEV %.1f° • %s\n%s",p.lat,p.lon,p.altKm,GevOrbitMath.periodSeconds(s.mm)/60d,elev,quality,nextEstimatedPass(s,now)));
    }
    private void openEarth(){Sat s=chosen();if(s==null){banner.setText("SELECT A SATELLITE FIRST");return;}
        GevOrbitMath.Position p=s.at(System.currentTimeMillis());if(!p.valid){banner.setText("ORBITAL POSITION UNAVAILABLE");return;}
        Intent i=new Intent(this,GevEarthExploreActivity.class);i.putExtra("geo_lat",p.lat);i.putExtra("geo_lon",p.lon);
        i.putExtra("satellite_name",s.name);i.putExtra("satellite_estimated",true);startActivity(i);
    }
    private Sat chosen(){return selected>=0&&selected<items.size()?items.get(selected):null;}
    private void share(){Sat s=chosen();if(s==null){banner.setText("SELECT A SATELLITE FIRST");return;}
        GevOrbitMath.Position p=s.at(System.currentTimeMillis());if(!p.valid){banner.setText("POSITION UNAVAILABLE");return;}
        long age=Math.abs(System.currentTimeMillis()-s.epochMs);
        LinkedHashMap<String,String> details=new LinkedHashMap<>();
        details.put("NORAD",String.valueOf(s.norad));details.put("EST LAT",String.format(Locale.US,"%.3f°",p.lat));
        details.put("EST LON",String.format(Locale.US,"%.3f°",p.lon));details.put("EST ALT",String.format(Locale.US,"%.0f km",p.altKm));
        details.put("EPOCH",utc(s.epochMs));details.put("ELEMENT AGE",String.format(Locale.US,"%.1f hours",age/3600000d));details.put("EST NEXT PASS",nextEstimatedPass(s,System.currentTimeMillis()));
        ShareCardRenderer.share(this,new ShareCardData(
            s.name,"Satellite position calculated from public mean orbital elements — not an observed live location.",
            "ORBIT ESTIMATE",age>72L*3600000L?"OLDER ELEMENTS / LOW CONFIDENCE":"APPROXIMATE KEPLERIAN",
            "SATELLITES",group,1,"CELESTRAK / OMM","",System.currentTimeMillis(),p.lat,p.lon,details,CYAN,
            "Two-body Kepler model, not SGP4. Not for tracking safety, collision avoidance or navigation."));
    }
    @Override protected void onResume(){super.onResume();ui.post(tick);}
    @Override protected void onPause(){super.onPause();ui.removeCallbacks(tick);}
    @Override protected void onDestroy(){super.onDestroy();ui.removeCallbacks(tick);pool.shutdownNow();}
}
