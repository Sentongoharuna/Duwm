package com.sentongoharuna.worldsituationroom;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;
import org.json.JSONArray;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Native V13 command board; reports stored observations only, never simulated counts. */
public final class RunningballV13SignalsActivity extends Activity {
  private static final int BG=0xFF050E17,WHITE=0xFFE3F3F7,DIM=0xFF39B5C3;
  private static final int CYAN=0xFF47D2DB,GREEN=0xFF47D2DB,AMBER=0xFF47D2DB;
  private LinearLayout rows;
  private TextView status;
  private Handler handler=new Handler(Looper.getMainLooper());
  private final Runnable tick=new Runnable(){@Override public void run(){draw();handler.postDelayed(this,30000L);}};
  private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
  private TextView text(String s,int pt,int color,boolean bold){TextView t=new TextView(this);
    t.setText(s);t.setTextSize(pt);t.setTextColor(color);if(bold)t.setTypeface(null,1);return t;}
  private GradientDrawable bg(int accent){GradientDrawable b=new GradientDrawable();
    b.setColor(0xFF081824);b.setCornerRadius(dp(16));b.setStroke(dp(1),accent);return b;}
  private void go(Class<?> target){startActivity(new Intent(this,target));}
  private void item(String head,String value,String desc,String source,Class<?> target,int color){
    LinearLayout tile=new LinearLayout(this);tile.setOrientation(LinearLayout.VERTICAL);
    tile.setPadding(dp(17),dp(13),dp(15),dp(15));tile.setBackground(bg(color));
    tile.addView(text(head,11,color,true));
    TextView count=text(value,22,WHITE,true);LinearLayout.LayoutParams c=new LinearLayout.LayoutParams(-1,-2);c.topMargin=dp(5);tile.addView(count,c);
    TextView info=text(desc,12,DIM,false);LinearLayout.LayoutParams f=new LinearLayout.LayoutParams(-1,-2);f.topMargin=dp(5);tile.addView(info,f);
    TextView from=text(source+"  /  TAP FOR DETAILS  ›",10,color,false);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);
    sp.topMargin=dp(9);tile.addView(from,sp);tile.setOnClickListener(v->go(target));
    LinearLayout.LayoutParams outer=new LinearLayout.LayoutParams(-1,-2);outer.topMargin=dp(11);rows.addView(tile,outer);
  }
  private static long age(long when){if(when<=0L)return Long.MAX_VALUE;return Math.max(0L,System.currentTimeMillis()-when);}
  private static String freshness(long when){long a=age(when);if(a==Long.MAX_VALUE)return "NO DATA";
    if(a<=180000L)return "RECENT SNAPSHOT";if(a<=3600000L)return "CACHED SNAPSHOT";return "STALE SNAPSHOT";}
  private static String stamp(long when){if(when<=0L)return "NEVER LOADED";
    SimpleDateFormat f=new SimpleDateFormat("dd MMM HH:mm:ss 'UTC'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(when));}
  private static String airFreshness(Context c,long t){
    String error=c.getSharedPreferences("air_widget_v2",MODE_PRIVATE).getString("last_error","");
    return error.isEmpty()?freshness(t):"FETCH FAILED / CACHED";
  }
  private static String satRaw(Context c){return c.getSharedPreferences("rb10_satellite",MODE_PRIVATE).getString("data_STATIONS","[]");}
  private static int stations(Context c){try{
    JSONArray raw=new JSONArray(satRaw(c));int valid=0;
    for(int i=0;i<raw.length()&&valid<100;i++){
      JSONObject j=raw.optJSONObject(i);if(j==null)continue;
      String name=j.optString("OBJECT_NAME","");int norad=j.optInt("NORAD_CAT_ID",0);
      String epoch=j.optString("EPOCH","");
      boolean goodEpoch=false;
      try{String v=epoch.replace("Z","");int dot=v.indexOf('.');
        if(dot>=0){String fraction=v.substring(dot+1);if(fraction.length()>3)fraction=fraction.substring(0,3);
          while(fraction.length()<3)fraction+="0";v=v.substring(0,dot)+"."+fraction;}
        else v+=".000";
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS",Locale.US);
        format.setLenient(false);format.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date dt=format.parse(v);goodEpoch=dt!=null&&dt.getTime()>0;
      }catch(Exception ignored){}
      if(!name.isEmpty()&&norad>0&&goodEpoch&&GevOrbitMath.validElements(
         j.optDouble("MEAN_MOTION",Double.NaN),j.optDouble("ECCENTRICITY",Double.NaN),
         j.optDouble("INCLINATION",Double.NaN),j.optDouble("RA_OF_ASC_NODE",Double.NaN),
         j.optDouble("ARG_OF_PERICENTER",Double.NaN),j.optDouble("MEAN_ANOMALY",Double.NaN)))valid++;
    }
    return valid;
  }catch(Exception e){return 0;}}
  private static int vessels(Context c){try{
    String raw=c.getSharedPreferences("rb11_marine",MODE_PRIVATE).getString("rows", "");
    JSONArray arr=new JSONObject(raw).optJSONArray("rows");if(arr==null)return 0;
    int count=0;for(int i=0;i<arr.length()&&i<800;i++){
      JSONObject row=arr.optJSONObject(i);if(row==null)continue;
      String mmsi=row.optString("mmsi","");double lat=row.optDouble("lat",Double.NaN),lon=row.optDouble("lon",Double.NaN);
      if(GevMarineMath.validMmsi(mmsi)&&GevMarineMath.valid(lat,lon))count++;
    }return count;
  }catch(Exception e){return 0;}}
  public static String summary(Context c){
    JSONObject a=AirOperationsWidgets.lastData(c);
    long at=a.optLong("time",0L);
    SharedPreferences sats=c.getSharedPreferences("rb10_satellite",MODE_PRIVATE);
    long st=sats.getLong("data_STATIONS_time",0L);
    SharedPreferences sea=c.getSharedPreferences("rb11_marine",MODE_PRIVATE);
    long mt=sea.getLong("last_fetch",0L);
    return "AIR " + (at<=0L?"--":a.optInt("count",0))+"  ·  "+airFreshness(c,at)+"\n"
          +"SAT " + (st<=0L?"--":stations(c))+"  ·  "+freshness(st)+"\n"
          +"SEA " + (mt<=0L?"--":vessels(c))+"  ·  "+freshness(mt);
  }
  private void draw(){if(rows==null)return;rows.removeAllViews();
    JSONObject air=AirOperationsWidgets.lastData(this);
    long airTime=air.optLong("time",0L);
    String airError=getSharedPreferences("air_widget_v2",MODE_PRIVATE).getString("last_error","");
    item("AIRCRAFT / 250 NM / "+RunningballWorldTarget.label(this),
      airTime>0L?air.optInt("count",0)+" AIRCRAFT":"NO SNAPSHOT",
      "Moving "+(airTime>0L?air.optInt("moving",0):"--")+"  •  Ground "+(airTime>0L?air.optInt("ground",0):"--")+"  •  "+freshness(airTime)
         +(airError.isEmpty()?"":"  •  "+airError)+"\nLast report: "+stamp(airTime),
      "ADSB.LOL / OBSERVED POSITION",AirRadarActivity.class,CYAN);
    SharedPreferences sats=getSharedPreferences("rb10_satellite",MODE_PRIVATE);
    long satelliteTime=sats.getLong("data_STATIONS_time",0L);
    item("SATELLITES  /  CELESTRAK STATIONS CATALOGUE",
      satelliteTime>0L?stations(this)+" OBJECTS":"NOT LOADED",
      freshness(satelliteTime)+"  •  Two-body estimates, not live satellite positions"
      +"\nCatalogue received: "+stamp(satelliteTime),
      "CELESTRAK / ESTIMATED ORBITS",GevSatelliteActivity.class,GREEN);
    SharedPreferences marine=getSharedPreferences("rb11_marine",MODE_PRIVATE);
    long marineTime=marine.getLong("last_fetch",0L);
    String status=marine.getString("status","not connected");
    item("VESSELS  /  HTTPS AIS GATEWAY",
      marineTime>0L?vessels(this)+" REPORTED":"GATEWAY NOT CONNECTED",
      freshness(marineTime)+"  •  Gateway says: "+status
      +"\nSnapshot: "+stamp(marineTime)+"\nNo gateway means no live ship observations.",
      "AIS GATEWAY / EXTERNAL CONFIGURATION",GevMarineActivity.class,AMBER);
    this.status.setText("CHECKED LOCALLY  •  "+stamp(System.currentTimeMillis())+"\n"
      +"Counts are cached reports. Opening a module can refresh its own source.");
  }
  private void shareReport(){
    String report="RUNNINGBALL2 V14  /  GLOBAL SIGNALS\n"
      +summary(this)+"\nSource notices: AIR = ADSB.LOL observed; SAT = CelesTrak estimated; SEA = configured HTTPS AIS gateway.\n"
      +"All counts are locally cached reports, not verified real-time positions.\n"
      +"Generated from app cache at "+stamp(System.currentTimeMillis());
    Intent share=new Intent(Intent.ACTION_SEND);
    share.setType("text/plain");share.putExtra(Intent.EXTRA_SUBJECT,"RUNNINGBALL2 V14 Global Signals");
    share.putExtra(Intent.EXTRA_TEXT,report);
    startActivity(Intent.createChooser(share,"Share Global Signals Report"));
  }
  private void header(LinearLayout body,String s,int sz,int color){TextView v=text(s,sz,color,true);
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(9);body.addView(v,lp);}
  private void command(LinearLayout body,String title,Runnable run){TextView v=text(title+"   ›",13,CYAN,true);
    v.setGravity(Gravity.CENTER_VERTICAL);v.setPadding(dp(15),dp(12),dp(15),dp(12));v.setBackground(bg(CYAN));
    v.setOnClickListener(w->run.run());LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(8);body.addView(v,p);}
  @Override public void onCreate(Bundle b){super.onCreate(b);RunningballV17Insets.install(this);
    getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    ScrollView sc=new ScrollView(this);sc.setBackgroundColor(BG);sc.setFillViewport(true);
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
    root.setPadding(dp(17),dp(20),dp(17),dp(24));sc.addView(root);
    header(root,"RUNNINGBALL2  V15  /  GLOBAL SIGNALS",11,GREEN);
    header(root,"GLOBAL SIGNALS",27,WHITE);
    header(root,"Real cached snapshots • no generated aircraft, satellites or vessels",12,DIM);
    status=text("READING SOURCE SNAPSHOTS …",11,DIM,false);
    LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(7);root.addView(status,sp);
    rows=new LinearLayout(this);rows.setOrientation(LinearLayout.VERTICAL);
    LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(12);root.addView(rows,rp);
    command(root,"RECHECK ALL CACHED COUNTERS",()->{draw();RunningballV14SignalWidget.updateAll(this);});
    command(root,"SHARE GLOBAL SIGNALS REPORT",this::shareReport);
    command(root,"RECHECK HOME WIDGET CACHE",()->{RunningballV14SignalWidget.updateAll(this);
      android.widget.Toast.makeText(this,"Home widget refreshed from cached reports",android.widget.Toast.LENGTH_SHORT).show();});
    command(root,"REQUEST AIRCRAFT FEED UPDATE",()->{
      Intent i=new Intent(this,AirOperationsWidgets.Command.class);
      i.setAction("com.sentongoharuna.worldsituationroom.AIR_WIDGET_REFRESH");sendBroadcast(i);
      android.widget.Toast.makeText(this,"Aircraft refresh requested",android.widget.Toast.LENGTH_SHORT).show();
      draw();
    });
    command(root,"SELECT WORLD LOCATION",()->go(RunningballWorldExplorerActivity.class));
            command(root,"OPEN NEAREST AIRCRAFT CONTACTS",()->go(GevContactsActivity.class));
    command(root,"OPEN ORIGINAL MONITOR",()->finish());
    setContentView(sc);
  }
  @Override protected void onResume(){super.onResume();handler.removeCallbacks(tick);tick.run();RunningballV14SignalWidget.updateAll(this);}
  @Override protected void onPause(){handler.removeCallbacks(tick);super.onPause();}
  @Override protected void onDestroy(){handler.removeCallbacks(tick);super.onDestroy();}
}
