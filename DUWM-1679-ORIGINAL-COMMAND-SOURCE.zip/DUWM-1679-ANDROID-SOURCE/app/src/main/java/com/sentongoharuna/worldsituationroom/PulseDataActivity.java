package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;
import java.io.StringReader;

/** Source-driven visual intelligence. All plotted marks are received observations; never demo points. */
public final class PulseDataActivity extends Activity {
  private static final int BG=Color.rgb(5,14,23), PANEL=Color.rgb(8,24,36), CYAN=Color.rgb(71,210,219);
  private static final int WHITE=Color.rgb(223,238,242), MUTED=Color.rgb(57,181,195);
  private static final long PERIOD_MS=90000L;
  private final Handler handler=new Handler(Looper.getMainLooper());
  private final ArrayList<Signal> records=new ArrayList<>();
  private final HashMap<String,Signal> prevRecords=new HashMap<>();
  private final HashMap<String,String> status=new HashMap<>();
  private final HashMap<String,Long> responseMs=new HashMap<>();
  private final HashSet<String> seen=new HashSet<>();
  private final String[] categories={"ALL","AIRCRAFT","EARTHQUAKE","ISS","NEWS"};
  private volatile boolean loading=false;
  private boolean active=false;
  private String category="ALL";
  private LinearLayout list, counterRow, root;
  private TextView statusLine, selectedLine, updatedLine;
  private RadarView radar;
  private TimelineView timeline;
  private Signal selected;
  private long lastUpdated=0;
  private int freshCount=0;
  private final Runnable refreshTicker=new Runnable(){public void run(){if(!active)return;refresh();handler.postDelayed(this,PERIOD_MS);}};

  static final class Signal {
    final String id,kind,title,detail,source,url;
    final long time;
    final Double latitude,longitude;
    float oldX=Float.NaN,oldY=Float.NaN;
    long moveStarted=0;
    Signal(String id,String kind,String title,String detail,String source,String url,long time,Double lat,Double lon){
      this.id=id;this.kind=kind;this.title=title;this.detail=detail;this.source=source;this.url=url;this.time=time;
      this.latitude=lat;this.longitude=lon;
    }
    boolean positioned(){return latitude!=null&&longitude!=null&&Double.isFinite(latitude)&&Double.isFinite(longitude)&&Math.abs(latitude)<=90&&Math.abs(longitude)<=180;}
  }

  private int dp(float x){return (int)(getResources().getDisplayMetrics().density*x+.5f);}
  private TextView label(String value,int size,int color){TextView t=new TextView(this);t.setText(value);t.setTextColor(color);t.setTextSize(size);t.setPadding(dp(10),dp(8),dp(10),dp(8));return t;}
  private void panel(View v){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(PANEL);d.setCornerRadius(dp(15));d.setStroke(dp(1),Color.rgb(24,87,105));v.setBackground(d);}
  private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;}
  private void add(LinearLayout parent, View child){parent.addView(child,new LinearLayout.LayoutParams(-1,-2));}
  private void heading(String s){TextView t=label(s,15,CYAN);t.setTypeface(null,1);add(root,t);}
  @Override public void onCreate(Bundle b){super.onCreate(b);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
    root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(10),dp(8),dp(10),dp(20));scroll.addView(root);setContentView(scroll);
    TextView h=label("DEVELOP.UGANDA   /   LIVE SIGNAL INTELLIGENCE",16,WHITE);h.setTypeface(null,1);add(root,h);
    add(root,label("SOURCE-DRIVEN RADAR  •  EVERY RECORD SHAREABLE",11,MUTED));
    add(root,label("SIGNAL LIGHTS  /  COLOUR KEY\nRED alert  •  ORANGE traffic  •  YELLOW satellite  •  GREEN verified\nBLUE vessel/weather  •  CYAN incoming feed  •  PURPLE intelligence  •  WHITE system\nBright = recent real receipt; blinking = a genuine new arrival/change; dim = no confirmed data. Tap an LED to share its actual status.",10,MUTED));
    LinearLayout tabs=row();tabs.setWeightSum(5);for(String c:categories){TextView t=label(c.equals("EARTHQUAKE")?"QUAKE":c,10,c.equals(category)?CYAN:MUTED);t.setGravity(Gravity.CENTER);panel(t);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(40),1);p.setMargins(dp(2),dp(2),dp(2),dp(2));tabs.addView(t,p);t.setOnClickListener(v->{category=c;drawAll();});}add(root,tabs);
    radar=new RadarView();panel(radar);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(350));rp.setMargins(dp(2),dp(8),dp(2),dp(8));root.addView(radar,rp);
    selectedLine=label("Select a source-observed point or record below to inspect and share.",12,WHITE);panel(selectedLine);add(root,selectedLine);
    TextView share=label("SHARE SELECTED INDIVIDUAL DATA POINT",13,CYAN);panel(share);share.setGravity(Gravity.CENTER);add(root,share);
    share.setOnClickListener(v->{if(selected!=null)share(selected);else android.widget.Toast.makeText(this,"Select a real record first",android.widget.Toast.LENGTH_SHORT).show();});
    heading("OBSERVED SOURCE TIMELINE  /  TAP A BAR TO SHARE ITS COUNT");
    timeline=new TimelineView();panel(timeline);root.addView(timeline,new LinearLayout.LayoutParams(-1,dp(144)));
    heading("SOURCE RECEIPTS  /  MEASURED RESPONSE TIME");
    statusLine=label("Waiting for actual provider responses; no simulated data.",12,MUTED);add(root,statusLine);
    updatedLine=label("Last refresh: not received",11,MUTED);add(root,updatedLine);
    TextView refresh=label("REFRESH SOURCES NOW",13,CYAN);panel(refresh);refresh.setGravity(Gravity.CENTER);add(root,refresh);refresh.setOnClickListener(v->refresh());
    heading("ALL RECEIVED RECORDS  /  TAP ONE TO SHARE");
    counterRow=row();add(root,counterRow);
    list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);add(root,list);
    add(root,label("A radar sweep is a display animation, not detection evidence. Positions and values come only from provider responses. Stale/unavailable sources remain labelled.",11,MUTED));
  }
  @Override public void onStart(){super.onStart();active=true;handler.post(refreshTicker);}
  @Override public void onStop(){active=false;handler.removeCallbacks(refreshTicker);super.onStop();}

  private void refresh(){if(loading)return;loading=true;statusLine.setText("Fetching public-source observations …");
    new Thread(()->{
      final ArrayList<Signal> incoming=new ArrayList<>();
      final HashMap<String,String> state=new HashMap<>();
      final HashMap<String,Long> latency=new HashMap<>();
      fetchOne("AIRCRAFT","https://opensky-network.org/api/states/all",incoming,state,latency);
      fetchOne("EARTHQUAKE","https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson",incoming,state,latency);
      fetchOne("ISS","https://api.wheretheiss.at/v1/satellites/25544",incoming,state,latency);
      fetchOne("NEWS","https://feeds.bbci.co.uk/news/world/rss.xml",incoming,state,latency);
      runOnUiThread(()->{
        if(!active){loading=false;return;}
        long now=System.currentTimeMillis();freshCount=0;
        boolean movingPoint=false,recentNewQuake=false,newNews=false;
        for(Signal p:incoming){Signal prior=prevRecords.get(p.id);
          if(prior!=null&&prior.positioned()&&p.positioned()&&(prior.latitude.doubleValue()!=p.latitude.doubleValue()||prior.longitude.doubleValue()!=p.longitude.doubleValue())){
            p.oldX=(float)(prior.longitude/180d);p.oldY=(float)(prior.latitude/90d);p.moveStarted=now;
            movingPoint=true;
          }
          if(!seen.contains(p.id)){
            freshCount++;seen.add(p.id);
            // ALERT may light only for a newly received quake with a recent provider timestamp.
            if(p.kind.equals("EARTHQUAKE") && p.time>0 && p.time<=now && now-p.time<900000L)
              recentNewQuake=true;
            if(p.kind.equals("NEWS"))newNews=true;
          }
        }
        prevRecords.clear();for(Signal p:incoming)prevRecords.put(p.id,p);
        records.clear();records.addAll(incoming);DuwmGeoObservationStore.publishPulse(this,records);status.clear();status.putAll(state);responseMs.clear();responseMs.putAll(latency);lastUpdated=now;
        if(selected!=null)selected=prevRecords.get(selected.id);
        DuwmSignalRail.publishPulse(this,state,movingPoint,recentNewQuake,newNews,freshCount>0,now);
        loading=false;drawAll();
      });
    },"DUWM-real-provider-refresh").start();
  }
  private static String str(JSONObject o,String name){return o==null?"":o.optString(name,"").trim();}
  private static String clean(String s){return s==null?"":s.replaceAll("[\\p{Cntrl}]+"," ").trim();}
  private static Double number(JSONArray a,int at){if(a==null||a.isNull(at))return null;double d=a.optDouble(at,Double.NaN);return Double.isFinite(d)?d:null;}
  private static long longFrom(JSONArray a,int at){if(a==null||a.isNull(at))return 0;return a.optLong(at,0)*1000L;}
  private static String fmt(double d){return String.format(Locale.US,"%.2f",d);}
  private static String time(long when){if(when<=0)return "SOURCE TIME UNKNOWN";SimpleDateFormat f=new SimpleDateFormat("dd MMM HH:mm:ss 'UTC'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(when));}
  private String fetch(String endpoint)throws Exception{
    HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection();c.setConnectTimeout(8500);c.setReadTimeout(8500);c.setRequestProperty("User-Agent","DEVELOP.UGANDA-World-Monitor/1160");c.setRequestProperty("Accept","application/json, application/rss+xml, application/xml, text/xml");
    try{int code=c.getResponseCode();if(code!=200)throw new java.io.IOException("HTTP "+code);
      ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] block=new byte[8192];int n;try(InputStream in=c.getInputStream()){while((n=in.read(block))!=-1){if(out.size()+n>6000000)throw new java.io.IOException("Response exceeds safety limit");out.write(block,0,n);}}return out.toString("UTF-8");
    }finally{c.disconnect();}
  }
  private void fetchOne(String kind,String endpoint,List<Signal> to,Map<String,String> state,Map<String,Long> latency){
    long started=System.currentTimeMillis();try{String body=fetch(endpoint);int before=to.size();
      if(kind.equals("AIRCRAFT"))readAircraft(body,to);else if(kind.equals("EARTHQUAKE"))readQuakes(body,to);else if(kind.equals("ISS"))readISS(body,to);else readNews(body,to);
      latency.put(kind,System.currentTimeMillis()-started);state.put(kind,"RECEIVED  "+(to.size()-before)+" records");
    }catch(Exception e){latency.put(kind,System.currentTimeMillis()-started);state.put(kind,"UNAVAILABLE / "+clean(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()));}
  }
  private void readAircraft(String data,List<Signal> dest)throws Exception{
    JSONObject o=new JSONObject(data);JSONArray states=o.getJSONArray("states");int n=0;
    for(int i=0;i<states.length()&&n<100;i++){JSONArray v=states.optJSONArray(i);if(v==null||v.length()<11)continue;
      Double lon=number(v,5),lat=number(v,6);if(lon==null||lat==null)continue;
      String id=v.optString(0,"").trim(),call=v.optString(1,"").trim();if(id.length()==0)continue;
      Double altitude=number(v,7),speed=number(v,9);
      String info="ICAO24: "+id+"  |  Country: "+v.optString(2,"Not supplied")+"  |  Altitude: "+(altitude==null?"Not reported":fmt(altitude)+" m")+"  |  Ground speed: "+(speed==null?"Not reported":fmt(speed*3.6)+" km/h");
      dest.add(new Signal("AIR:"+id,"AIRCRAFT",call.isEmpty()?id:call,info,"OpenSky Network","https://opensky-network.org/",longFrom(v,4),lat,lon));n++;
    }
  }
  private void readQuakes(String data,List<Signal> dest)throws Exception{
    JSONArray features=new JSONObject(data).getJSONArray("features");
    for(int i=0;i<features.length()&&i<70;i++){JSONObject f=features.getJSONObject(i),properties=f.getJSONObject("properties"),geometry=f.getJSONObject("geometry");JSONArray coordinates=geometry.optJSONArray("coordinates");Double lon=number(coordinates,0),lat=number(coordinates,1);if(lat==null||lon==null)continue;
      String id=str(f,"id"),title=str(properties,"title"),place=str(properties,"place");double mag=properties.optDouble("mag",Double.NaN);long stamp=properties.optLong("time",0);
      String details="Magnitude: "+(Double.isFinite(mag)?fmt(mag):"Unknown")+"  |  Region: "+place;
      dest.add(new Signal("QUAKE:"+id,"EARTHQUAKE",title,details,"USGS Earthquake Hazards Program",str(properties,"url"),stamp,lat,lon));
    }
  }
  private void readISS(String data,List<Signal> dest)throws Exception{
    JSONObject o=new JSONObject(data);double lat=o.optDouble("latitude",Double.NaN),lon=o.optDouble("longitude",Double.NaN);if(!Double.isFinite(lat)||!Double.isFinite(lon))throw new Exception("No ISS coordinates");
    long timestamp=o.optLong("timestamp",0)*1000L;String details="Altitude: "+o.optString("altitude","Unknown")+" km  |  Velocity: "+o.optString("velocity","Unknown")+" km/h";
    dest.add(new Signal("ISS:25544","ISS","International Space Station",details,"Where The ISS At","https://api.wheretheiss.at/v1/satellites/25544",timestamp,lat,lon));
  }
  private void readNews(String data,List<Signal> dest)throws Exception{
    XmlPullParser p=XmlPullParserFactory.newInstance().newPullParser();p.setInput(new StringReader(data));
    boolean inside=false;String field=null,title="",link="",date="",desc="";int count=0;
    for(int ev=p.getEventType();ev!=XmlPullParser.END_DOCUMENT&&count<35;ev=p.next()){
      if(ev==XmlPullParser.START_TAG){String n=p.getName();if(n.equalsIgnoreCase("item")){inside=true;title="";link="";date="";desc="";}else if(inside&&(n.equals("title")||n.equals("link")||n.equals("pubDate")||n.equals("description")))field=n;}
      else if(ev==XmlPullParser.TEXT&&inside&&field!=null){String value=p.getText();if(field.equals("title"))title+=value;else if(field.equals("link"))link+=value;else if(field.equals("pubDate"))date+=value;else if(field.equals("description"))desc+=value;}
      else if(ev==XmlPullParser.END_TAG){String n=p.getName();if(n.equalsIgnoreCase("item")){inside=false;field=null;if(!title.trim().isEmpty()){
        long stamp=0;try{stamp=new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z",Locale.ENGLISH).parse(date.trim()).getTime();}catch(Exception ignored){}
        String detail=clean(desc.replaceAll("<[^>]*>"," "));if(detail.length()>350)detail=detail.substring(0,350);
        dest.add(new Signal("NEWS:"+(link.isEmpty()?title:link),"NEWS",clean(title),detail,"BBC News RSS",link,stamp,null,null));count++;
      }}else if(field!=null&&n.equals(field))field=null;}
    }
  }
  private List<Signal> filtered(){ArrayList<Signal> out=new ArrayList<>();for(Signal s:records)if(category.equals("ALL")||category.equals(s.kind))out.add(s);return out;}
  private void drawAll(){if(root==null)return;List<Signal> data=filtered();radar.invalidate();timeline.invalidate();
    StringBuilder b=new StringBuilder("LIVE SOURCE RECEIPTS: ");for(String k:new String[]{"AIRCRAFT","EARTHQUAKE","ISS","NEWS"}){
      b.append("\n").append(k).append(" • ").append(status.containsKey(k)?status.get(k):"NOT CHECKED");Long ms=responseMs.get(k);if(ms!=null)b.append(" • ").append(ms).append("ms");
    }
    statusLine.setText(b.toString());updatedLine.setText("Received records "+records.size()+"  |  New IDs since previous check "+freshCount+"  |  Checked "+time(lastUpdated));
    selectedLine.setText(selected==null?"Select an actual observation on the radar or in the list.":selected.kind+"  /  "+selected.title+"  •  "+selected.detail+"  /  "+time(selected.time));
    counterRow.removeAllViews();for(String k:new String[]{"AIRCRAFT","EARTHQUAKE","ISS","NEWS"}){
      int count=0;for(Signal s:records)if(s.kind.equals(k))count++;final int total=count;
      TextView t=label(k.substring(0,Math.min(4,k.length()))+"  "+total,10,color(k));t.setGravity(Gravity.CENTER);t.setOnClickListener(v->{
        V115941ShareCards.share(this,"SOURCE COUNT",k+" received records: "+total,"Count from last provider response; received at "+time(lastUpdated),k+" / DEVELOP.UGANDA",lastUpdated,null,null,sourceUrl(k),null);
      });counterRow.addView(t,new LinearLayout.LayoutParams(0,dp(45),1));
    }
    list.removeAllViews();if(data.isEmpty())add(list,label("NO VERIFIED RECORDS RECEIVED IN THIS CATEGORY. No demonstration entries are generated.",12,MUTED));
    for(Signal signal:data){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);panel(card);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(dp(1),dp(3),dp(1),dp(3));list.addView(card,p);
      TextView title=label(signal.kind+"  •  "+signal.title,13,color(signal.kind));title.setTypeface(null,1);add(card,title);
      add(card,label(signal.detail+"\nSOURCE: "+signal.source+"  |  "+time(signal.time),11,WHITE));
      TextView button=label("OPEN POINT  /  SHARE SOURCE CARD",12,CYAN);add(card,button);
      View.OnClickListener selectedAction=v->{selected=signal;selectedLine.setText(signal.kind+"  /  "+signal.title+"\n"+signal.detail+"\n"+time(signal.time));radar.invalidate();share(signal);};
      card.setOnClickListener(selectedAction);button.setOnClickListener(selectedAction);
    }
  }
  private String sourceUrl(String kind){if(kind.equals("AIRCRAFT"))return "https://opensky-network.org/";if(kind.equals("EARTHQUAKE"))return "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson";if(kind.equals("ISS"))return "https://api.wheretheiss.at/v1/satellites/25544";return "https://feeds.bbci.co.uk/news/world/rss.xml";}
  private int color(String type){if(type.equals("EARTHQUAKE"))return Color.rgb(71,210,219);if(type.equals("ISS"))return Color.rgb(71,210,219);if(type.equals("NEWS"))return Color.rgb(71,210,219);return CYAN;}
  private void share(Signal r){V115941ShareCards.share(this,r.kind,r.title,r.detail,r.source,r.time,r.latitude,r.longitude,r.url,null);}
  private void write(Canvas c,Paint p,String v,float x,float y,float sp,int rgb){p.setColor(rgb);p.setTextSize(sp*getResources().getDisplayMetrics().scaledDensity);p.setStyle(Paint.Style.FILL);c.drawText(v,x,y,p);}

  private final class RadarView extends View {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private float phase=0;
    RadarView(){super(PulseDataActivity.this);setContentDescription("Live geospatial source observations; tap a point to inspect its report");setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();c.drawColor(BG);float cx=w/2,cy=h*.51f,r=Math.min(w*.45f,h*.45f);
      p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));p.setColor(Color.rgb(24,87,105));for(int i=1;i<=4;i++)c.drawCircle(cx,cy,r*i/4,p);c.drawLine(cx-r,cy,cx+r,cy,p);c.drawLine(cx,cy-r,cx,cy+r,p);
      p.setColor(Color.rgb(57,181,195));p.setStrokeWidth(dp(2));c.drawCircle(cx,cy,r,p);
      float angle=(System.currentTimeMillis()%7000L)*360f/7000f;
      p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(3));p.setColor(Color.rgb(71,210,219));c.drawArc(new RectF(cx-r,cy-r,cx+r,cy+r),angle-20,20,false,p);
      p.setStrokeWidth(dp(1));float x=(float)Math.cos(Math.toRadians(angle))*r,y=(float)Math.sin(Math.toRadians(angle))*r;c.drawLine(cx,cy,cx+x,cy+y,p);
      write(c,p,"WORLD GEOGRAPHIC DISPLAY / NOT A SENSOR RADAR",dp(8),dp(20),10,MUTED);
      write(c,p,"N",cx-dp(3),cy-r-dp(6),12,CYAN);
      List<Signal> points=filtered();int drawn=0;
      for(Signal s:points){if(!s.positioned())continue;float px=cx+(float)(s.longitude/180d)*r,py=cy-(float)(s.latitude/90d)*r;
        // Movement only interpolates between successive actual provider positions.
        if(s.moveStarted>0&&System.currentTimeMillis()-s.moveStarted<12000L){float t=Math.min(1f,(System.currentTimeMillis()-s.moveStarted)/12000f);
          px=cx+(s.oldX+(float)((s.longitude/180d)-s.oldX)*t)*r;
          py=cy-(s.oldY+(float)((s.latitude/90d)-s.oldY)*t)*r;
        }
        p.setStyle(Paint.Style.FILL);p.setColor(color(s.kind));c.drawCircle(px,py,selected!=null&&selected.id.equals(s.id)?dp(6):dp(3),p);drawn++;
      }
      write(c,p,"RECEIVED POSITIONED RECORDS: "+drawn,dp(10),h-dp(12),11,WHITE);
      write(c,p,"SWEEP ANIMATION IS DECORATIVE",w-dp(202),h-dp(12),9,MUTED);
      if(active)postInvalidateDelayed(33);
    }
    @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;
      float cx=getWidth()/2f,cy=getHeight()*.51f,r=Math.min(getWidth()*.45f,getHeight()*.45f);Signal nearest=null;double best=dp(28)*dp(28);
      for(Signal s:filtered()){if(!s.positioned())continue;float x=cx+(float)(s.longitude/180d)*r,y=cy-(float)(s.latitude/90d)*r;
        double d=(e.getX()-x)*(e.getX()-x)+(e.getY()-y)*(e.getY()-y);if(d<best){best=d;nearest=s;}}
      if(nearest!=null){selected=nearest;selectedLine.setText(nearest.kind+"  /  "+nearest.title+"  •  "+nearest.detail+"\nSOURCE: "+nearest.source+"  /  "+time(nearest.time));invalidate();}
      return true;
    }
  }
  private final class TimelineView extends View {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private long anchor=0;private final int bins=8;private final int[] counts=new int[bins];
    TimelineView(){super(PulseDataActivity.this);setContentDescription("Source observation time histogram; tap any bar to share its measured record count");}
    private void recompute(){java.util.Arrays.fill(counts,0);anchor=System.currentTimeMillis();long span=24*3600*1000L;
      for(Signal s:filtered()){if(s.time<=0||s.time>anchor||s.time<anchor-span)continue;int bin=(int)((s.time-(anchor-span))/(span/bins));counts[Math.min(bins-1,Math.max(0,bin))]++;}}
    @Override protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(BG);recompute();float w=getWidth(),h=getHeight();int max=1;for(int n:counts)max=Math.max(max,n);
      write(c,p,"LAST 24 HOURS  /  PROVIDER TIMESTAMPS ONLY",dp(8),dp(19),10,MUTED);
      float yBase=h-dp(28),top=dp(30),slot=(w-dp(24))/bins;
      for(int i=0;i<bins;i++){float bh=(yBase-top)*counts[i]/max,left=dp(12)+i*slot+dp(5),right=left+slot-dp(10);
        p.setColor(CYAN);p.setStyle(Paint.Style.FILL);if(counts[i]>0)c.drawRoundRect(left,yBase-bh,right,yBase,dp(3),dp(3),p);
        write(c,p,String.valueOf(counts[i]),left,yBase-bh-dp(4),10,WHITE);
      }
      write(c,p,"-24h",dp(10),h-dp(9),9,MUTED);write(c,p,"NOW",w-dp(42),h-dp(9),9,MUTED);
    }
    @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;recompute();int idx=Math.max(0,Math.min(bins-1,(int)((e.getX()-dp(12))/((getWidth()-dp(24))/(float)bins))));
      long span=24*3600*1000L,from=anchor-span+idx*(span/bins),to=from+(span/bins);final int count=counts[idx];
      V115941ShareCards.share(PulseDataActivity.this,"OBSERVATION HISTOGRAM",category+" source observations: "+count,
          "Count of provider-reported records with timestamps from "+time(from)+" through "+time(to)+". This is not a global event estimate.",
          "DEVELOP.UGANDA / SOURCE TIMELINE",lastUpdated,null,null,"",null);return true;}
  }
}
