package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.os.SystemClock;
import java.util.HashMap;
import java.util.Map;
import android.view.View;
import java.util.ArrayList;

/** Port 05: read-only vessel radar. Coordinates are actual AIS snapshot points.
 * No interpolation, simulation or extrapolation of vessel movements. */
public final class GevMarineRadarView extends View {
    public interface OnShipSelected { void selected(int sourceIndex); }
    public static final class Point {
        public final int originalIndex;public final double lat,lon;
        public final long lastObserved;
        public final String label, mmsi;
        public Point(int index,double lat,double lon,long observed,String label,String mmsi){
            this.originalIndex=index;this.lat=lat;this.lon=lon;
            this.lastObserved=observed;this.label=label;this.mmsi=mmsi;
        }
    }
    private final Paint pen=new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean active=false;
    public void resume(){active=true;postInvalidateDelayed(85L);}
    public void pause(){active=false;}
    @Override protected void onDetachedFromWindow(){pause();super.onDetachedFromWindow();}
    private final ArrayList<Point> points=new ArrayList<>();
    private final Map<String,Point> lastByMmsi=new HashMap<>();
    private final Map<String,Point> animationFrom=new HashMap<>();
    private long transitionStarted;
    private static final long TRANSITION_MS=9000L;
    private double centerLat=-4.04d,centerLon=39.67d,rangeNm=140d;
    private OnShipSelected listener;
    public GevMarineRadarView(Context c){super(c);setBackgroundColor(Color.rgb(8,24,36));}
    public void setPort(double lat,double lon,double rangeNm){if(GevMarineMath.valid(lat,lon)&&rangeNm>0d){centerLat=lat;centerLon=lon;this.rangeNm=rangeNm;invalidate();}}
    public void setRecords(ArrayList<Point> records){
        Map<String,Point> oldFrom=new HashMap<>(animationFrom);
        Map<String,Point> previous=new HashMap<>(lastByMmsi);
        Map<String,Point> newFrom=new HashMap<>();
        Map<String,Point> next=new HashMap<>();
        boolean receivedNewFix=false;
        long now=SystemClock.uptimeMillis();
        points.clear();if(records!=null)points.addAll(records);
        for(Point v:points){
            if(v.mmsi==null || v.mmsi.isEmpty())continue;
            next.put(v.mmsi,v);
            Point older=previous.get(v.mmsi);
            if(older!=null && older.lastObserved>0 && v.lastObserved>older.lastObserved &&
              (Math.abs(older.lat-v.lat)>0.000001 || Math.abs(older.lon-v.lon)>0.000001)){
                newFrom.put(v.mmsi,older);receivedNewFix=true;
            }else if(older!=null && older.lastObserved==v.lastObserved &&
                now-transitionStarted<TRANSITION_MS && oldFrom.containsKey(v.mmsi)){
                newFrom.put(v.mmsi,oldFrom.get(v.mmsi));
            }
        }
        lastByMmsi.clear();lastByMmsi.putAll(next);
        animationFrom.clear();animationFrom.putAll(newFrom);
        if(receivedNewFix)transitionStarted=now;
        invalidate();
    }
    private float[] animatedXY(Point p,float cx,float cy,float radius){
        Point from=animationFrom.get(p.mmsi);
        long elapsed=SystemClock.uptimeMillis()-transitionStarted;
        if(from!=null&&elapsed>=0L&&elapsed<TRANSITION_MS && p.lastObserved>from.lastObserved){
            float t=Math.max(0f,Math.min(1f,elapsed/(float)TRANSITION_MS));
            t=t*t*(3f-2f*t); // display-only interpolation between TWO received AIS fixes
            return xy(from.lat+(p.lat-from.lat)*t,from.lon+(p.lon-from.lon)*t,cx,cy,radius);
        }
        return xy(p.lat,p.lon,cx,cy,radius);
    }
    public void setOnShipSelected(OnShipSelected selected){listener=selected;}
    private void stroke(Canvas c,int color,float width,float cx,float cy,float radius){pen.setColor(color);pen.setStyle(Paint.Style.STROKE);pen.setStrokeWidth(width);c.drawCircle(cx,cy,radius,pen);pen.setStyle(Paint.Style.FILL);}
    private float[] xy(double lat,double lon,float cx,float cy,float radius){
        double north=GevMarineMath.distanceNm(centerLat,centerLon,lat,centerLon)*(lat>=centerLat?1d:-1d);
        double east=GevMarineMath.distanceNm(centerLat,centerLon,centerLat,lon)*(lon>=centerLon?1d:-1d);
        return new float[]{(float)(cx+east/rangeNm*radius),(float)(cy-north/rangeNm*radius)};
    }
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);float w=getWidth(),h=getHeight();
        float cx=w/2f,cy=h/2f,radius=Math.max(12f,Math.min(w,h)*.43f);
        int cyan=Color.rgb(57,181,195),muted=Color.rgb(24,87,105);
        pen.setStyle(Paint.Style.FILL);
        pen.setShader(new LinearGradient(0,0,w,h,0xFF185769,0xFF081824,Shader.TileMode.CLAMP));
        canvas.drawRect(0,0,w,h,pen);pen.setShader(null);
        // Rotating visual scan is not a simulated AIS observation.
        if(active){double angle=(SystemClock.uptimeMillis()%8500L)/8500d*Math.PI*2d;
            pen.setColor(0x5547D2DB);pen.setStrokeWidth(2.0f);
            canvas.drawLine(cx,cy,cx+(float)Math.sin(angle)*radius,cy-(float)Math.cos(angle)*radius,pen);
        }
        stroke(canvas,muted,1f,cx,cy,radius);
        stroke(canvas,muted,1f,cx,cy,radius*.65f);
        stroke(canvas,muted,1f,cx,cy,radius*.32f);
        pen.setColor(muted);pen.setStrokeWidth(1f);canvas.drawLine(cx-radius,cy,cx+radius,cy,pen);canvas.drawLine(cx,cy-radius,cx,cy+radius,pen);
        pen.setStyle(Paint.Style.FILL);pen.setTextSize(19f);pen.setColor(cyan);
        canvas.drawText("N",cx-5f,cy-radius+14f,pen);
        canvas.drawText(""+(int)rangeNm+" NM",12f,h-10f,pen);
        long now=System.currentTimeMillis();int drawn=0,within=0;
        int cellSize=Math.max(8,(int)(getResources().getDisplayMetrics().density*9));
        int cols=Math.max(1,(getWidth()+cellSize-1)/cellSize),rows=Math.max(1,(getHeight()+cellSize-1)/cellSize);
        boolean[] occupied=new boolean[cols*rows];
        for(Point p:points){if(!GevMarineMath.valid(p.lat,p.lon))continue;
            double distance=GevMarineMath.distanceNm(centerLat,centerLon,p.lat,p.lon);
            if(distance>rangeNm)continue;within++;
            float[] v=animatedXY(p,cx,cy,radius);
            if(v[0]<0||v[0]>=getWidth()||v[1]<0||v[1]>=getHeight())continue;
            int cell=Math.min(rows-1,Math.max(0,(int)v[1]/cellSize))*cols+
                    Math.min(cols-1,Math.max(0,(int)v[0]/cellSize));
            if(occupied[cell])continue;occupied[cell]=true;drawn++;
            String freshness=GevMarineMath.freshness(p.lastObserved,now);
            int color="RECENT".equals(freshness)?Color.rgb(71,210,219):"CACHED".equals(freshness)?Color.rgb(71,210,219):Color.rgb(40,145,162);
            pen.setColor(color);canvas.drawCircle(v[0],v[1],4.2f,pen);
        }
        pen.setColor(Color.rgb(71,210,219));pen.setTextSize(20f);
        canvas.drawText("IN RANGE "+within+"  /  VISIBLE "+drawn,12f,24f,pen);
        pen.setTextSize(16f);canvas.drawText("AIS FIXES / SMOOTHED TWO-REPORT MOTION",12f,44f,pen);
        if(active)postInvalidateDelayed(85L);
    }
    @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;
        if(listener==null)return true;
        float cx=getWidth()/2f,cy=getHeight()/2f,radius=Math.max(12f,Math.min(getWidth(),getHeight())*.43f);
        double best=18d*18d;int index=-1;
        for(Point p:points){if(GevMarineMath.distanceNm(centerLat,centerLon,p.lat,p.lon)>rangeNm)continue;
            float[] pt=animatedXY(p,cx,cy,radius);double delta=Math.pow(e.getX()-pt[0],2)+Math.pow(e.getY()-pt[1],2);
            if(delta<best){best=delta;index=p.originalIndex;}}
        if(index>=0)listener.selected(index);return true;
    }
}
