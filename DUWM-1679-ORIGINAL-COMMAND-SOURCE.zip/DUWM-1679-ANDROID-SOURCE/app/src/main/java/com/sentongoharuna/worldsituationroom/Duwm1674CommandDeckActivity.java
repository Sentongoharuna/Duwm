package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/**
 * 1674 redesigned mission control: the globe, layout and information hierarchy are new.
 * Only provider receipts feed counts/pins; on-screen movement does not forge observations.
 * No fixed inherited-version or protected-theme dependency exists in this screen.
 */
public class Duwm1674CommandDeckActivity extends Activity {
    private static final int BG=0xFF050E17, CARD=0xFF0D3A47, EDGE=0xFF185769;
    private static final int WHITE=0xFFE4F4F8, DIM=0xFFB8C5C8, CYAN=0xFF47D2DB, GOLD=0xFF47D2DB;
    private static final String[] GROUPS={"AIRCRAFT","VESSELS","NEWS","MARKETS","WEATHER", "EARTHQUAKES","SATELLITES","TV STATIONS","PUBLIC CAMERAS","RADIO"};
    private static final int[] SRC={0,2,5,7,6,3,1,-1,-1,-1};
    private final Handler ui=new Handler(Looper.getMainLooper());
    private boolean running=false, rotation=true, aurora=true, airLayer=true, seaLayer=true, quakeLayer=true, orbitLayer=true;
    private long lastAircraftRefresh=0L,lastMarineRefresh=0L;
    private OperationsGlobeView earth;
    private Duwm1670HomeTelemetryView receiptRail;
    private Duwm1674SignalBoardView healthStrip;
    private TextView utcLabel, healthLabel, globeMode, spinLabel, selectedLabel, featuredLabel, sourceTicker, evidenceButton;
    private final ArrayList<TextView> figures=new ArrayList<>();
    private final ArrayList<TextView> statuses=new ArrayList<>();
    private OperationsGlobeView.Observation chosen;
    private final Runnable timer=new Runnable(){@Override public void run(){
        if(!running)return;updateReceipts();
        long now=System.currentTimeMillis();
        if(now-lastAircraftRefresh>=90000L){
            lastAircraftRefresh=now;
            RunningballV25GlobalAircraftData.refresh(Duwm1674CommandDeckActivity.this,()->{if(running)updateReceipts();});
        }
        if(now-lastMarineRefresh>=180000L){
            lastMarineRefresh=now;
            Duwm1674MaritimeRefresh.refresh(Duwm1674CommandDeckActivity.this,()->{if(running)updateReceipts();});
        }
        ui.postDelayed(this,15000L);
    }};

    private int dp(float n){return Math.round(getResources().getDisplayMetrics().density*n);}
    private TextView label(String s,int size,int color,boolean strong){
        TextView v=new TextView(this);v.setText(s);v.setTextColor(color);v.setTextSize(size);
        v.setFontFeatureSettings("tnum");if(strong)v.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return v;
    }
    private GradientDrawable background(int fill,int outline,int corner){
        GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(corner));if(outline!=0)d.setStroke(dp(1),outline);return d;
    }
    private TextView button(String s,Runnable click){
        TextView v=label(s,11,CYAN,true);v.setGravity(Gravity.CENTER);v.setPadding(dp(9),dp(11),dp(9),dp(11));
        v.setBackground(background(CARD,EDGE,9));v.setOnClickListener(w->click.run());return v;
    }
    private String utc(long stamp){
        if(stamp<=0L)return "NOT RECEIVED";
        SimpleDateFormat f=new SimpleDateFormat("HH:mm:ss 'UTC'",Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(stamp));
    }
    private void spacer(LinearLayout root,int h){View v=new View(this);root.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    private void addPair(LinearLayout parent,TextView first,TextView second){
        LinearLayout row=new LinearLayout(this);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(8);parent.addView(row,rp);
        row.addView(first,new LinearLayout.LayoutParams(0,dp(45),1));
        LinearLayout.LayoutParams b=new LinearLayout.LayoutParams(0,dp(45),1);b.leftMargin=dp(8);row.addView(second,b);
    }
    private TextView sectorCard(String title,int index){
        TextView v=button(title+"   ›",()->openSector(index));v.setTextColor(WHITE);v.setGravity(Gravity.CENTER_VERTICAL);
        v.setPadding(dp(14),dp(12),dp(10),dp(12));return v;
    }
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        ScrollView screen=new ScrollView(this);screen.setFillViewport(true);screen.setBackgroundColor(BG);
        setContentView(screen);Duwm1167SafeArea.install(this,screen);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(13),dp(9),dp(13),dp(28));screen.addView(root);

        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);root.addView(header,new LinearLayout.LayoutParams(-1,dp(65)));
        LinearLayout brand=new LinearLayout(this);brand.setOrientation(LinearLayout.VERTICAL);header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        brand.addView(label("DUWM     /     GLOBAL SITUATION ROOM",12,CYAN,true));
        brand.addView(label("MISSION CONTROL  /  1676",19,WHITE,true));
        TextView now=label("●  LIVE DATA",10,GOLD,true);now.setGravity(Gravity.CENTER);now.setPadding(dp(8),dp(10),dp(8),dp(10));
        now.setBackground(background(CARD,EDGE,8));header.addView(now);
        LinearLayout clocks=new LinearLayout(this);root.addView(clocks,new LinearLayout.LayoutParams(-1,dp(28)));
        utcLabel=label("UTC --:--:--",11,DIM,true);clocks.addView(utcLabel,new LinearLayout.LayoutParams(0,-2,1));
        healthLabel=label("INITIALIZING",11,CYAN,true);clocks.addView(healthLabel);
        evidenceButton=button("1675 EVIDENCE VAULT  /  VIEW SOURCE HISTORY  •  SAVE CSV",()->
            startActivity(new Intent(this,Duwm1675EvidenceVaultActivity.class)));
        evidenceButton.setTextColor(0xFF47D2DB);
        evidenceButton.setTextSize(12);
        LinearLayout.LayoutParams vaultLp=new LinearLayout.LayoutParams(-1,dp(46));vaultLp.topMargin=dp(6);
        root.addView(evidenceButton,vaultLp);
        // 1676 primary new feature: real observation geofences and saved watch regions.
        TextView geoWatchButton=button("1676 GEOGRAPHIC WATCHLIST  •  SAVED REGIONS + SOURCE POSITIONS",
            ()->startActivity(new Intent(this,Duwm1676GeoWatchActivity.class)));
        geoWatchButton.setTextSize(12);geoWatchButton.setTextColor(0xFF47D2DB);
        LinearLayout.LayoutParams watchLp=new LinearLayout.LayoutParams(-1,dp(48));watchLp.topMargin=dp(7);
        root.addView(geoWatchButton,watchLp);

        receiptRail=new Duwm1670HomeTelemetryView(this);
        LinearLayout.LayoutParams rail=new LinearLayout.LayoutParams(-1,dp(67));rail.topMargin=dp(6);root.addView(receiptRail,rail);
        healthStrip=new Duwm1674SignalBoardView(this);
        LinearLayout.LayoutParams signalLp=new LinearLayout.LayoutParams(-1,dp(158));signalLp.topMargin=dp(8);root.addView(healthStrip,signalLp);
        healthStrip.setOnClickListener(v->startActivity(new Intent(this,Duwm1671SourceStatusActivity.class)));
        spacer(root,12);
        LinearLayout globeHeader=new LinearLayout(this);globeHeader.setGravity(Gravity.CENTER_VERTICAL);root.addView(globeHeader);
        TextView eTitle=label("EARTH  /  REGIONAL OPERATIONS",14,WHITE,true);globeHeader.addView(eTitle,new LinearLayout.LayoutParams(0,-2,1));
        TextView info=label("TAP A REAL PIN",10,GOLD,true);globeHeader.addView(info);
        FrameLayout viewport=new FrameLayout(this);viewport.setBackground(background(0xFF081824,EDGE,16));
        LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-1,dp(332));vp.topMargin=dp(9);root.addView(viewport,vp);
        earth=new OperationsGlobeView(this);
        earth.setGlobePalette(true);
        earth.setCompassRingEnabled(true);
        earth.setRotationSpeed(1.25f);
        viewport.addView(earth,new FrameLayout.LayoutParams(-1,-1));
        TextView modeBadge=label("1676  /  AIR + SEA",10,CYAN,true);modeBadge.setPadding(dp(10),dp(7),dp(10),dp(7));
        modeBadge.setBackground(background(0xD7081824,EDGE,8));
        FrameLayout.LayoutParams badgeLp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT);badgeLp.leftMargin=dp(11);badgeLp.topMargin=dp(10);
        viewport.addView(modeBadge,badgeLp);globeMode=modeBadge;
        TextView markers=label("ACTUAL AIR / AIS / QUAKE / ISS POSITIONS",10,DIM,true);markers.setPadding(dp(9),dp(5),dp(9),dp(5));
        markers.setBackground(background(0xC4081824,0,5));FrameLayout.LayoutParams mLp=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);mLp.bottomMargin=dp(28);viewport.addView(markers,mLp);
        earth.setOnObservationSelected(o->{chosen=o;
            selectedLabel.setText(o.title+"  /  "+o.source+"  /  "+utc(o.timeMillis)+"\n"+o.detail);
        });

        LinearLayout controls=new LinearLayout(this);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(9);root.addView(controls,cp);
        spinLabel=button("ROTATION ON",()->{rotation=!rotation;if(rotation)earth.resume();else earth.pause();spinLabel.setText(rotation?"ROTATION ON":"ROTATION OFF");});
        controls.addView(spinLabel,new LinearLayout.LayoutParams(0,dp(45),1));
        TextView palette=button("CHANGE GLOBE",()->{aurora=!aurora;earth.setGlobePalette(aurora);globeMode.setText(aurora?"1676  /  AIR + SEA":"1676  /  CARBON EARTH");});
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(0,dp(45),1);pp.leftMargin=dp(8);controls.addView(palette,pp);
        TextView reload=button("REFRESH ALL",()->{healthLabel.setText("REQUESTING REAL FEEDS");
            RunningballV25GlobalAircraftData.refreshNow(this,()->{if(running)updateReceipts();});
            RunningballV25NewsRepository.refresh(this,true,()->{if(running)updateReceipts();});
            RunningballV17Feeds.request(this,true,()->{if(running)updateReceipts();});
            Duwm1674MaritimeRefresh.refresh(this,()->{if(running)updateReceipts();});
        });
        LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(0,dp(45),1);rlp.leftMargin=dp(8);controls.addView(reload,rlp);

        LinearLayout geoControls=new LinearLayout(this);
        LinearLayout.LayoutParams gcp=new LinearLayout.LayoutParams(-1,-2);gcp.topMargin=dp(8);root.addView(geoControls,gcp);
        geoControls.addView(button("AFRICA",()->region(-1.8,23.5)),new LinearLayout.LayoutParams(0,dp(42),1));
        addControl(geoControls,"EUROPE",()->region(49,12));
        addControl(geoControls,"ASIA",()->region(24,83));
        addControl(geoControls,"AMERICAS",()->region(22,-83));
        LinearLayout filters=new LinearLayout(this);
        LinearLayout.LayoutParams flp=new LinearLayout.LayoutParams(-1,-2);flp.topMargin=dp(8);root.addView(filters,flp);
        addToggle(filters,"AIRCRAFT",()->{airLayer=!airLayer;earth.showLayer(OperationsGlobeView.AIR,airLayer);},CYAN);
        addToggle(filters,"VESSELS",()->{seaLayer=!seaLayer;earth.showLayer(OperationsGlobeView.SEA,seaLayer);},0xFF47D2DB);
        addToggle(filters,"QUAKES",()->{quakeLayer=!quakeLayer;earth.showLayer(OperationsGlobeView.QUAKE,quakeLayer);},GOLD);
        addToggle(filters,"SATELLITES",()->{orbitLayer=!orbitLayer;earth.showLayer(OperationsGlobeView.SPACE,orbitLayer);},0xFF39B5C3);
        selectedLabel=label("SELECT A VERIFIED MAP POINT FOR DETAILS AND SHARING",12,DIM,false);
        selectedLabel.setPadding(dp(12),dp(10),dp(12),dp(10));selectedLabel.setBackground(background(CARD,EDGE,9));
        LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,-2);slp.topMargin=dp(9);root.addView(selectedLabel,slp);
        addPair(root,button("SHARE OBSERVATION",this::shareSelected),button("AIRCRAFT FOLLOW MAP",()->startActivity(new Intent(this,Duwm1670FlightMapActivity.class))));
        spacer(root,16);
        root.addView(label("LIVE WORLD INTELLIGENCE  /  SELECT A DESK",14,WHITE,true));
        root.addView(label("Each section opens its own map, chart, viewer or stream player.",11,DIM,false));
        for(int i=0;i<GROUPS.length;i+=2){
            LinearLayout row=new LinearLayout(this);LinearLayout.LayoutParams rowP=new LinearLayout.LayoutParams(-1,-2);rowP.topMargin=dp(8);root.addView(row,rowP);
            for(int k=i;k<Math.min(i+2,GROUPS.length);k++){
                final int index=k;
                LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(10),dp(10),dp(10),dp(10));box.setBackground(background(CARD,EDGE,11));
                LinearLayout.LayoutParams colP=new LinearLayout.LayoutParams(0,dp(120),1);if(k>i)colP.leftMargin=dp(8);row.addView(box,colP);
                box.addView(label((index<9?"0":"")+(index+1)+"   /   "+GROUPS[index],12,CYAN,true));
                TextView big=label("--",19,WHITE,true);big.setSingleLine(true);big.setEllipsize(android.text.TextUtils.TruncateAt.END);
                LinearLayout.LayoutParams f=new LinearLayout.LayoutParams(-1,0,1);f.topMargin=dp(6);box.addView(big,f);
                TextView state=label("NO SOURCE RECEIPT",10,DIM,false);state.setSingleLine(true);state.setEllipsize(android.text.TextUtils.TruncateAt.END);box.addView(state);
                figures.add(big);statuses.add(state);box.setOnClickListener(v->openSector(index));
                box.setContentDescription("Open "+GROUPS[index]+" operational view");
            }
        }
        spacer(root,16);
        root.addView(label("SOURCE NETWORK  /  VERIFIED UPDATES",14,WHITE,true));
        sourceTicker=label("NO VERIFIED REPORT RECEIVED YET",12,GOLD,false);sourceTicker.setPadding(dp(13),dp(14),dp(13),dp(14));
        sourceTicker.setBackground(background(CARD,EDGE,10));
        sourceTicker.setSingleLine(true);sourceTicker.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
        sourceTicker.setMarqueeRepeatLimit(-1);sourceTicker.setSelected(true);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=dp(8);root.addView(sourceTicker,tp);
        addPair(root,button("SOURCE HEALTH",()->startActivity(new Intent(this,Duwm1671SourceStatusActivity.class))),button("200 SOURCE DIRECTORY",()->startActivity(new Intent(this,Duwm1669SourceDirectoryActivity.class))));
        addPair(root,button("WORLD NEWS ATLAS",()->startActivity(new Intent(this,Duwm1670NewsAtlasActivity.class))),button("SHARE WORLD STATUS CARD",this::shareMission));
        addPair(root,button("LIVE TV CHANNELS",()->openMedia("TV STATIONS")),button("WORLD RADIO",()->openMedia("RADIO")));
        addPair(root,button("PUBLIC CITY CAMERAS",()->openMedia("PUBLIC CAMERAS")),button("LEGACY COMMAND",()->startActivity(new Intent(this,OperationsMainActivity.class))));
        spacer(root,12);
        featuredLabel=label("PIN MOVEMENT USES ACTUAL OBSERVATIONS. VISUAL GLOBE ROTATION IS NOT TELEMETRY.",10,DIM,false);root.addView(featuredLabel);
        updateReceipts();
    }
    private void addControl(LinearLayout row,String label,Runnable action){
        TextView b=button(label,action);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(42),1);lp.leftMargin=dp(6);row.addView(b,lp);
    }
    private void addToggle(LinearLayout row,String label,Runnable action,int color){
        TextView b=button(label,action);b.setTextColor(color);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(42),1);if(row.getChildCount()>0)lp.leftMargin=dp(6);
        row.addView(b,lp);
        b.setOnClickListener(v->{action.run();b.setAlpha(b.getAlpha()<1f?1f:0.5f);});
    }
    private void region(double lat,double lon){
        earth.focusAt(lat,lon);rotation=false;
        spinLabel.setText("RESUME ROTATION");
        if(selectedLabel!=null)selectedLabel.setText("GEOGRAPHIC VIEW SELECTED • MAP ROTATION PAUSED • OBSERVATION COORDINATES UNCHANGED");
    }
    private void openMedia(String mode){Intent i=new Intent(this,MediaDeskActivity.class);i.putExtra("mode",mode);startActivity(i);}
    private void shareMission(){
        RunningballV25GlobalAircraftData.Snapshot air=RunningballV25GlobalAircraftData.read(this);
        StringBuilder report=new StringBuilder();
        report.append("AIRCRAFT ").append(air.hasGood()?air.countLabel():"NOT RECEIVED").append(" / ").append(air.ageLabel());
        int[] ids={2,5,6,7,3,1};
        for(int id:ids){RunningballV25Sources.Result r=RunningballV25Sources.read(this,id);
            report.append("\n").append(r.key.toUpperCase(Locale.US)).append(" ").append(r.value==null?"--":r.value).append(" / ").append(r.display());}
        Duwm1671Share.share(this,"WORLD STATUS • DUWM 1675","GLOBAL SOURCE RECEIPTS",report.toString(),
            "Individual provider receipts on this device","",System.currentTimeMillis());
    }
    private void openSector(int index){
        Class<?> dest=Duwm1671SectorActivity.class;Intent intent;
        if(index==0)dest=Duwm1670FlightMapActivity.class;
        else if(index==1)dest=GevMarineActivity.class;
        else if(index==2)dest=Duwm1670NewsAtlasActivity.class;
        if(index==7||index==8||index==9){intent=new Intent(this,MediaDeskActivity.class);
            intent.putExtra("mode",index==7?"TV STATIONS":index==8?"PUBLIC CAMERAS":"RADIO");}
        else{intent=new Intent(this,dest);if(dest==Duwm1671SectorActivity.class)intent.putExtra(Duwm1671SectorActivity.EXTRA_KIND,GROUPS[index]);}
        startActivity(intent);
    }
    private void shareSelected(){
        if(chosen==null){android.widget.Toast.makeText(this,"Tap an actual observation on the globe first",android.widget.Toast.LENGTH_SHORT).show();return;}
        OperationsGlobeView.Observation o=chosen;
        String name=o.type==OperationsGlobeView.AIR?"AIRCRAFT":o.type==OperationsGlobeView.SEA?"AIS VESSEL":o.type==OperationsGlobeView.QUAKE?"EARTHQUAKE":"SATELLITE";
        String link=o.type==OperationsGlobeView.AIR?"https://opensky-network.org/":o.type==OperationsGlobeView.SEA?"https://openwaters.io/api/ais/":o.type==OperationsGlobeView.QUAKE?"https://earthquake.usgs.gov/":"https://api.wheretheiss.at/";
        V115941ShareCards.share(this,name,o.title,o.detail,o.source,o.timeMillis,o.lat,o.lon,link,null);
    }
    private void updateReceipts(){
        if(receiptRail==null)return;
        utcLabel.setText(utc(System.currentTimeMillis()));receiptRail.update();
        if(evidenceButton!=null){int saved=Duwm1675EvidenceStore.read(this).length();
            evidenceButton.setText("1675 EVIDENCE VAULT  •  "+saved+" SAVED  •  OPEN / EXPORT");}
        RunningballV25GlobalAircraftData.Snapshot plane=RunningballV25GlobalAircraftData.read(this);
        Duwm1674UnifiedReceipts.Receipt airTruth=Duwm1674UnifiedReceipts.aircraft(this);
        Duwm1674UnifiedReceipts.Receipt seaTruth=Duwm1674UnifiedReceipts.maritime(this);
        Duwm1674UnifiedReceipts.Receipt newsTruth=Duwm1674UnifiedReceipts.news(this);
        int good=airTruth.hasReceipt()?1:0;
        List<OperationsGlobeView.Observation> report=new ArrayList<>();
        if(plane.hasGood() && plane.ageMs()<21600000L){
            JSONArray points=plane.points;int step=Math.max(1,(points.length()+1199)/1200);
            for(int i=0;i<points.length()&&report.size()<1200;i+=step){
                JSONArray a=points.optJSONArray(i);if(a==null)continue;
                double lat=a.optDouble(0,Double.NaN),lon=a.optDouble(1,Double.NaN);
                if(!Double.isFinite(lat)||!Double.isFinite(lon))continue;
                if(!Duwm1674TimeGuard.recent(a.isNull(7)?plane.sourceAt:a.optLong(7),21600000L))continue;
                report.add(new OperationsGlobeView.Observation(OperationsGlobeView.AIR,lat,lon,
                    a.optString(3,a.optString(2,"AIRCRAFT")),"OpenSky source position","OpenSky",
                    Duwm1674TimeGuard.normalize(a.isNull(7)?plane.sourceAt:a.optLong(7))));
            }
        }
        for(DuwmGeoObservationStore.Fix f:DuwmGeoObservationStore.read(this)){
            if("EARTHQUAKE".equals(f.type))report.add(new OperationsGlobeView.Observation(OperationsGlobeView.QUAKE,f.lat,f.lon,f.title,f.detail,f.provider,f.sourceTime));
            if("ISS".equals(f.type))report.add(new OperationsGlobeView.Observation(OperationsGlobeView.SPACE,f.lat,f.lon,f.title,f.detail,f.provider,f.sourceTime));
        }
        // Only actual AIS rows produce maritime pins. The cache receipt time is
        // not substituted for an unknown ship observation timestamp.
        if(seaTruth.hasReceipt()&&System.currentTimeMillis()-seaTruth.receivedAt<24L*60L*60L*1000L){
            SharedPreferences marine=getSharedPreferences("rb11_marine",MODE_PRIVATE);
            try{
                JSONObject payload=new JSONObject(marine.getString("rows","{}"));
                JSONArray rows=payload.optJSONArray("rows");
                if(rows!=null){
                    int step=Math.max(1,(rows.length()+299)/300);
                    for(int j=0;j<rows.length()&&report.size()<1650;j+=step){
                        JSONObject ship=rows.optJSONObject(j);if(ship==null)continue;
                        double lat=ship.optDouble("lat",Double.NaN),lon=ship.optDouble("lon",Double.NaN);
                        String mmsi=ship.optString("mmsi","");
                        if(!GevMarineMath.valid(lat,lon)||!GevMarineMath.validMmsi(mmsi))continue;
                        long observed=GevMarineActivity.timestamp(ship);
                        String name=ship.optString("name","");if(name.isEmpty())name="MMSI "+mmsi;
                        report.add(new OperationsGlobeView.Observation(OperationsGlobeView.SEA,lat,lon,name,
                            "Reported AIS position • MMSI "+mmsi+(observed>0?" • "+Duwm1674TimeGuard.utc(observed):" • OBSERVATION TIME UNKNOWN"),
                            payload.optString("source","REGIONAL AIS"),observed));
                    }
                }
            }catch(Exception ignored){}
        }
        earth.setObservations(report);
        for(int i=0;i<GROUPS.length;i++){
            int src=SRC[i];TextView figure=figures.get(i),state=statuses.get(i);
            if(src>=0){
                if(i==0){figure.setText(airTruth.count());state.setText(airTruth.detail);}
                else if(i==1){
                    figure.setText(seaTruth.count()+" AIS POSITIONS");
                    state.setText(seaTruth.detail);if(seaTruth.hasReceipt())good++;
                }else if(i==2){
                    figure.setText(newsTruth.count()+" NEWS SOURCE ENTRIES");
                    state.setText(newsTruth.detail);if(newsTruth.hasReceipt())good++;
                }else{RunningballV25Sources.Result r=RunningballV25Sources.read(this,src);
                    figure.setText(r.value==null?"--":r.value);state.setText(r.display());if(r.fetchedAt>0L)good++;}
            }else{figure.setText("OPEN DESK");state.setText("CHECK STREAM ON SELECTION");}
        }
        healthLabel.setText(good+" SOURCE RECEIPTS");if(healthStrip!=null)healthStrip.update();
        StringBuilder tick=new StringBuilder("RECEIPT STATUS  •  ");
        for(int i=0;i<7;i++){
            RunningballV25Sources.Result r=RunningballV25Sources.read(this,i);
            if(i>0)tick.append("     •     ");
            if(i==0){
                tick.append("AIR ").append(figures.get(0).getText())
                    .append(" [").append(statuses.get(0).getText()).append(']');
            }else if(i==2){
                TextView sea=figures.get(1);
                tick.append("AIS ").append(sea.getText()).append(" [").append(statuses.get(1).getText()).append(']');
            }else if(i==5){
                TextView news=figures.get(2);
                tick.append("NEWS ").append(news.getText()).append(" [").append(statuses.get(2).getText()).append(']');
            }else{
                tick.append(r.key.toUpperCase(Locale.US)).append(' ').append(r.value).append(" [").append(r.display()).append(']');
            }
        }
        sourceTicker.setText(tick.toString());
    }
    @Override protected void onResume(){super.onResume();running=true;if(earth!=null&&rotation)earth.resume();if(receiptRail!=null)receiptRail.resume();if(healthStrip!=null)healthStrip.resume();
        updateReceipts();ui.removeCallbacks(timer);ui.postDelayed(timer,15000L);
        lastAircraftRefresh=System.currentTimeMillis();
        RunningballV25GlobalAircraftData.refresh(this,()->{if(running)updateReceipts();});
        RunningballV25NewsRepository.refresh(this,false,()->{if(running)updateReceipts();});
        RunningballV17Feeds.request(this,false,()->{if(running)updateReceipts();});
        lastMarineRefresh=System.currentTimeMillis();
        Duwm1674MaritimeRefresh.refresh(this,()->{if(running)updateReceipts();});
    }
    @Override protected void onPause(){running=false;ui.removeCallbacks(timer);if(earth!=null)earth.pause();if(receiptRail!=null)receiptRail.pause();if(healthStrip!=null)healthStrip.pause();super.onPause();}
}
