package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import android.net.Uri;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** News publisher atlas. Pins are country-capital reference points, NOT geocoded news events.
 * The 200 outlet/organization entries are discovery candidates, not 200 connected RSS feeds.
 * Received headlines are read separately from NewsStore. Unverified article positions are NOT mapped.
 */
public final class Duwm1670NewsAtlasActivity extends Activity {
  private static final int BG=0xFF081824,PANEL=0xFF0F4353,EDGE=0xFF185769,WHITE=0xFFE1F1F5,MUTED=0xFF6C959E,AQUA=0xFF47D2DB,AMBER=0xFF47D2DB;
  private static final String[] GROUPS={"AFRICA  /  50","CONFLICT REPORTING  /  50","WESTERN  /  50","ISS + SPACE  /  50"};
  private static final String[] KEYS={"AFRICA","CONFLICT","WEST","ISS_SPACE"};
  private String group="AFRICA",search="";
  private int newsVisible=8;
  private final ArrayList<JSONObject> catalog=new ArrayList<>();
  private Duwm1670WorldMapView map;
  private LinearLayout rows,headlines;private TextView state,selection;
  private int dp(float n){return Math.round(getResources().getDisplayMetrics().density*n);}
  private TextView label(String s,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  private GradientDrawable panel(int bg){GradientDrawable d=new GradientDrawable();d.setColor(bg);d.setCornerRadius(dp(9));d.setStroke(dp(1),EDGE);return d;}
  private TextView button(String s,Runnable fn){TextView t=label(s,12,AQUA,true);t.setGravity(Gravity.CENTER);t.setBackground(panel(PANEL));t.setPadding(dp(12),dp(12),dp(12),dp(12));t.setOnClickListener(v->fn.run());return t;}
  private String utc(long ms){if(ms<=0)return "PUBLISHER TIME UNKNOWN";SimpleDateFormat df=new SimpleDateFormat("dd MMM HH:mm 'UTC'",Locale.US);df.setTimeZone(TimeZone.getTimeZone("UTC"));return df.format(new Date(ms));}
  private void readSources(){try(BufferedReader br=new BufferedReader(new InputStreamReader(getAssets().open("duwm_news_200_region_sources.json"),"UTF-8"))){
    StringBuilder b=new StringBuilder();String ln;while((ln=br.readLine())!=null)b.append(ln).append('\n');
    JSONArray a=new JSONObject(b.toString()).getJSONArray("sources");for(int i=0;i<a.length();i++)catalog.add(a.getJSONObject(i));
  }catch(Exception ex){state.setText("REGIONAL NEWS DIRECTORY UNAVAILABLE: "+ex.getClass().getSimpleName());}}
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    ScrollView sc=new ScrollView(this);sc.setBackgroundColor(BG);setContentView(sc);Duwm1167SafeArea.install(this,sc);
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(13),dp(12),dp(13),dp(32));sc.addView(root);
    root.addView(label("DEVELOP.UGANDA   /   MEDIA GEOGRAPHY",13,AQUA,true));root.addView(label("WORLD NEWS ATLAS",26,WHITE,true));
    TextView note=label("200 regional source websites • 50 per category • source home countries, not incident locations",11,MUTED,false);root.addView(note);
    state=label("LOADING 200 PUBLISHER CANDIDATES",12,AQUA,true);state.setPadding(0,dp(11),0,dp(8));root.addView(state);
    Spinner spinner=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,GROUPS);
    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);spinner.setAdapter(adapter);spinner.setBackground(panel(PANEL));root.addView(spinner,new LinearLayout.LayoutParams(-1,dp(51)));
    spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
      @Override public void onItemSelected(AdapterView<?> p,View v,int index,long id){group=KEYS[index];newsVisible=8;render();}
      @Override public void onNothingSelected(AdapterView<?> p){} });
    EditText q=new EditText(this);q.setTextSize(14);q.setSingleLine(true);q.setHint("Search publisher / country / region");q.setTextColor(WHITE);q.setHintTextColor(MUTED);
    q.setBackground(panel(PANEL));q.setPadding(dp(12),dp(10),dp(12),dp(10));LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(-1,-2);qp.topMargin=dp(7);root.addView(q,qp);
    q.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){search=s.toString().toLowerCase(Locale.ROOT);render();}public void afterTextChanged(Editable e){} });
    map=new Duwm1670WorldMapView(this);map.setLayer("NEWS / PUBLISHER COUNTRIES");LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(260));mp.topMargin=dp(10);root.addView(map,mp);
    map.setOnPinSelected(pin->{for(JSONObject item:catalog)if(item.optString("id").equals(pin.id)){focusSource(item);break;}});
    selection=label("SELECT A PUBLISHER TO FOCUS ITS COUNTRY REFERENCE ON THE MAP",12,WHITE,false);
    selection.setBackground(panel(PANEL));selection.setPadding(dp(12),dp(11),dp(12),dp(11));root.addView(selection);
    TextView mapNote=label("Borders are geographic. Publisher markers use national capitals, not exact newsroom addresses or story-event locations.",10,MUTED,false);
    mapNote.setPadding(0,dp(8),0,dp(8));root.addView(mapNote);
    TextView openNews=button("OPEN REAL NEWS FEED + 9:16 SHARE CARDS",()->startActivity(new Intent(this,Duwm1166NewsDeskActivity.class)));root.addView(openNews);
    root.addView(label("ACTUAL RECEIVED ARTICLES / SOURCE TIMESTAMPS",14,AQUA,true));
    headlines=new LinearLayout(this);headlines.setOrientation(LinearLayout.VERTICAL);root.addView(headlines);
    root.addView(label("PUBLISHER DIRECTORY  /  50 PER REGION",14,AQUA,true));
    rows=new LinearLayout(this);rows.setOrientation(LinearLayout.VERTICAL);root.addView(rows);
    TextView refresh=button("REFRESH REAL NEWS SOURCES",()->{
      state.setText("FETCHING RSS / GDELT — SEE SOURCE STATUS BELOW");
      RunningballV25NewsRepository.refresh(this,true,this::render);
      RunningballV17Feeds.request(this,true,this::render);
    });root.addView(refresh);
    readSources();render();
    RunningballV25NewsRepository.refresh(this,false,this::render);
    RunningballV17Feeds.request(this,false,this::render);
  }
  private void focusSource(JSONObject item){if(map==null)return;
    double lat=item.optDouble("lat",Double.NaN),lon=item.optDouble("lon",Double.NaN);
    if(Double.isFinite(lat)&&Double.isFinite(lon)){map.focus(lat,lon,3.1f);map.setSelected(item.optString("id"));}
    selection.setText(item.optString("name")+" / "+item.optString("country")+"\nSITE: "+item.optString("url")+"\nSTATUS: candidate source • no verified feed or current story claimed. Tap below to view its original site.");
    selection.setOnClickListener(v->openPublisher(item));
  }
  private void openPublisher(JSONObject obj){String url=obj.optString("url");if(!url.startsWith("https://"))return;
    Intent i=new Intent(this,Duwm1166ArticleActivity.class);i.putExtra("url",url);i.putExtra("title",obj.optString("name"));startActivity(i);
  }
  private boolean matchesArticle(NewsItem n){String p=(n.sourceName+" "+n.title+" "+n.summary+" "+n.region+" "+n.topic).toUpperCase(Locale.ROOT);
    switch(group){case "AFRICA":return p.matches("(?s).*\\b(UGANDA|AFRICA|KENYA|TANZANIA|RWANDA|SUDAN|ETHIOPIA|NIGERIA|CONGO|SOUTH AFRICA)\\b.*");
      case "CONFLICT":return p.matches("(?s).*(CONFLICT|CEASEFIRE|MILITARY|WAR|AIRSTRIKE|FIGHTING|INVASION|DISPLACED|PEACE TALKS).*");
      case "WEST":return p.matches("(?s).*(UNITED STATES|EUROPE|NATO|CANADA|BRITAIN|FRANCE|GERMANY|WASHINGTON|LONDON).*");
      case "ISS_SPACE":return p.matches("(?s).*(NASA|ISS|SPACE STATION|SPACECRAFT|SATELLITE|ASTRONAUT|ORBIT|SPACEX|ESA|JAXA).*");
      default:return false;}
  }
  private void render(){if(rows==null||map==null)return;
    rows.removeAllViews();ArrayList<Duwm1670WorldMapView.Pin> pins=new ArrayList<>();int matched=0;
    for(JSONObject s:catalog){if(!group.equals(s.optString("group")))continue;
      String searchText=(s.optString("name")+" "+s.optString("country")).toLowerCase(Locale.ROOT);
      if(!searchText.contains(search))continue;matched++;
      pins.add(new Duwm1670WorldMapView.Pin(s.optString("id"),s.optString("name"),"NEWS",s.optDouble("lat"),s.optDouble("lon"),0L,"PUBLISHER COUNTRY REFERENCE"));
      TextView card=button(s.optString("name")+"   /   "+s.optString("country")+"\nSOURCE WEBSITE · NOT CONFIRMED LIVE",()->focusSource(s));
      card.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);card.setTextColor(WHITE);
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(5);rows.addView(card,lp);
    }
    map.setPins(pins,false);
    state.setText(group.replace('_',' ')+"  /  "+matched+" MATCHING WEBSITES  /  50 CANDIDATES IN GROUP");
    renderNews();
  }
  private void renderNews(){if(headlines==null)return;headlines.removeAllViews();ArrayList<NewsItem> stories=new ArrayList<>();
    for(NewsItem n:new NewsStore(this).load())if(n!=null&&n.link!=null&&n.link.startsWith("https://")&&matchesArticle(n))stories.add(n);
    Collections.sort(stories,(a,b)->Long.compare(b.publishedAt,a.publishedAt));
    int collected=0;
    for(String feed:RunningballV25NewsRepository.KEYS){
      boolean relevant=group.equals("AFRICA")&&feed.startsWith("ug_") ||
          group.equals("CONFLICT")&&feed.startsWith("conflict_");
      if(!relevant)continue;
      JSONArray items=RunningballV25NewsRepository.articles(this,feed);
      long fetched=RunningballV25NewsRepository.last(this,feed);
      String err=RunningballV25NewsRepository.error(this,feed);
      for(int i=0;i<items.length()&&collected<36;i++){
        JSONObject item=items.optJSONObject(i);if(item==null)continue;
        String title=item.optString("title","").trim(),link=item.optString("url","");
        if(title.length()<8||!RunningballV25NewsRepository.validArticle(link))continue;
        TextView card=button(item.optString("publisher",feed)+" • "+title+"\nRECEIVED "+
          RunningballV25NewsRepository.age(fetched)+" AGO • ORIGINAL ARTICLE",()->{
            Intent intent=new Intent(this,Duwm1166ArticleActivity.class);
            intent.putExtra("url",link);intent.putExtra("title",title);startActivity(intent);
          });
        card.setTextColor(WHITE);card.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams cl=new LinearLayout.LayoutParams(-1,-2);cl.topMargin=dp(5);
        headlines.addView(card,cl);collected++;
      }
      if(items.length()==0 && !err.isEmpty())
        headlines.addView(label(feed.toUpperCase(Locale.US)+" • FETCH FAILED: "+err,10,AMBER,false));
    }
    // The long-running global fallback stores genuine DW RSS / GDELT articles separately.
    // Show only headlines matching the selected category; do not invent a location.
    JSONArray global=RunningballV17Feeds.cached(this,RunningballV17Feeds.NEWS).optJSONArray("articles");
    if(global!=null)for(int i=0;i<global.length()&&collected<55;i++){
      JSONObject item=global.optJSONObject(i);if(item==null)continue;
      String title=item.optString("title","").trim(),link=item.optString("url","");
      if(title.length()<8||!RunningballV25NewsRepository.validArticle(link))continue;
      String itemText=title.toUpperCase(Locale.ROOT);
      boolean match=group.equals("AFRICA")&&itemText.matches("(?s).*(AFRICA|UGANDA|KENYA|NIGERIA|CONGO|SUDAN|ETHIOPIA|TANZANIA|RWANDA).*" )||
          group.equals("CONFLICT")&&itemText.matches("(?s).*(CONFLICT|WAR|CEASEFIRE|FIGHTING|STRIKE|MILITARY|DISPLACED|INVASION).*" )||
          group.equals("WEST")&&itemText.matches("(?s).*(USA|UNITED STATES|EUROPE|BRITAIN|FRANCE|GERMANY|CANADA|NATO|LONDON|WASHINGTON).*" )||
          group.equals("ISS_SPACE")&&itemText.matches("(?s).*(NASA|ISS|SPACE|SATELLITE|ASTRONAUT|ORBIT|SPACEX|ESA|JAXA).*" );
      if(!match)continue;
      TextView card=button(item.optString("domain","GLOBAL REPORT")+"  •  "+title+"\nSOURCE ARTICLE · "+item.optString("seen","TIME UNAVAILABLE"),()->{
        Intent intent=new Intent(this,Duwm1166ArticleActivity.class);
        intent.putExtra("url",link);intent.putExtra("title",title);startActivity(intent);
      });
      card.setTextColor(WHITE);card.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
      LinearLayout.LayoutParams cl=new LinearLayout.LayoutParams(-1,-2);cl.topMargin=dp(5);headlines.addView(card,cl);collected++;
    }
    if(stories.isEmpty()&&collected==0){
      headlines.addView(label("NO RECEIVED HEADLINES MATCH THIS REGION. PRESS REFRESH TO RETRY PUBLIC RSS / GDELT. EMPTY CACHE IS NOT AN EMPTY WORLD.",11,AMBER,false));return;
    }
    if(stories.isEmpty())return;
    headlines.addView(label(stories.size()+" SAVED PUBLISHER ARTICLES MATCH THIS CATEGORY",11,AQUA,false));
    for(int k=0;k<Math.min(stories.size(),newsVisible);k++){NewsItem n=stories.get(k);
      TextView card=button(n.title+"\n"+n.sourceName+"  •  "+utc(n.publishedAt),()->{Intent i=new Intent(this,Duwm1166ArticleActivity.class);
        i.putExtra("url",n.link);i.putExtra("title",n.title);startActivity(i);});
      card.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,-2);pp.bottomMargin=dp(5);headlines.addView(card,pp);
    }
    if(stories.size()>newsVisible){
      final int remaining=stories.size()-newsVisible;
      headlines.addView(button("LOAD MORE RECEIVED NEWS  /  "+remaining+" REMAINING",()->{
        newsVisible+=20;renderNews();
      }));
    }
  }
  @Override protected void onResume(){super.onResume();if(map!=null)map.resume();if(headlines!=null)renderNews();
    RunningballV25NewsRepository.refresh(this,false,()->{if(!isFinishing())renderNews();});}
  @Override protected void onPause(){if(map!=null)map.pause();super.onPause();}
}
