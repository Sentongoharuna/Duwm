package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.SystemClock;
import android.view.View;
import android.widget.TextView;
import java.util.Locale;

/** DUWM 1678 visual layer. Scan beams and gridlines are decorative; reported values come from providers. */
public final class Duwm1678VisualKit {
  private Duwm1678VisualKit(){}
  public static final int RADIO=DuwmUnifiedTheme.ACCENT,TV=DuwmUnifiedTheme.ACCENT,
      CAMERA=DuwmUnifiedTheme.ACCENT,MARINE=DuwmUnifiedTheme.ACCENT,
      AIR=DuwmUnifiedTheme.ACCENT,QUAKE=DuwmUnifiedTheme.ACCENT,
      MARKET=DuwmUnifiedTheme.ACCENT,WEATHER=DuwmUnifiedTheme.ACCENT,
      NEWS=DuwmUnifiedTheme.ACCENT,SPACE=DuwmUnifiedTheme.ACCENT;
  public static int accent(String sector){if(sector==null)return AIR;
    String s=sector.toUpperCase(Locale.ROOT);
    if(s.contains("RADIO"))return RADIO;if(s.contains("TV"))return TV;
    if(s.contains("CAMERA"))return CAMERA;if(s.contains("VESSEL")||s.contains("MARITIME")||s.contains("SEA"))return MARINE;
    if(s.contains("QUAKE"))return QUAKE;if(s.contains("MARKET")||s.contains("FX"))return MARKET;
    if(s.contains("WEATHER"))return WEATHER;if(s.contains("NEWS"))return NEWS;
    if(s.contains("SATELLITE")||s.contains("ISS"))return SPACE;return AIR;}
  private static int dp(Context c,float n){return Math.round(c.getResources().getDisplayMetrics().density*n);}
  public static GradientDrawable panel(Context c,String sector,boolean selected){int a=accent(sector);
    GradientDrawable shape=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
      new int[]{selected?0xFF135468:0xFF0F4251,0xFF081824});
    shape.setCornerRadius(dp(c,14));shape.setStroke(dp(c,selected?2:1),selected?a:0xFF185769);return shape;}
  public static TextView chip(Context c,String label,String sector){TextView t=new TextView(c);
    t.setText(label);t.setTextColor(accent(sector));t.setTextSize(10);
    t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setPadding(dp(c,9),dp(c,5),dp(c,9),dp(c,5));
    t.setBackground(panel(c,sector,true));return t;}
  public static final class PulsePanel extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private String sector="AIRCRAFT",status="NO SOURCE RECEIPT";
    private boolean running=false,good=false;
    private int observed=0;
    public PulsePanel(Context c,String name){super(c);sector=name==null?"AIRCRAFT":name;
      setContentDescription("Decorative sector monitor; no simulated source observations");}
    private float d(float v){return v*getResources().getDisplayMetrics().density;}
    public void setMode(String s){sector=s==null?"AIRCRAFT":s;invalidate();}
    public void setReceipt(String s,int count,boolean verified){status=s==null?"NO SOURCE RECEIPT":s;
      observed=Math.max(0,count);good=verified;invalidate();}
    public void start(){running=true;postInvalidateDelayed(70);}
    public void stop(){running=false;}
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();start();}
    @Override protected void onDetachedFromWindow(){stop();super.onDetachedFromWindow();}
    @Override protected void onDraw(Canvas c){super.onDraw(c);
      float w=getWidth(),h=getHeight();if(w<1||h<1)return;
      int color=accent(sector),off=0xFF081824;
      paint.setShader(new LinearGradient(0,0,w,h,0xFF135669,off,Shader.TileMode.CLAMP));
      c.drawRoundRect(d(1),d(1),w-d(1),h-d(1),d(15),d(15),paint);paint.setShader(null);
      paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(d(1));paint.setColor(color);
      c.drawRoundRect(d(1),d(1),w-d(1),h-d(1),d(15),d(15),paint);
      paint.setColor(0x4439B5C3);paint.setStrokeWidth(d(.65f));
      for(int k=1;k<11;k++){float x=w*k/11f;c.drawLine(x,d(34),x,h-d(10),paint);}
      for(int k=1;k<4;k++){float y=d(36)+(h-d(48))*k/4f;c.drawLine(d(8),y,w-d(8),y,paint);}
      float time=(SystemClock.uptimeMillis()%5400L)/5400f;
      float scan=d(12)+(w-d(24))*time;
      paint.setColor((color&0x00E4F4F8)|0x66050E17);paint.setStrokeWidth(d(3));
      c.drawLine(scan,d(32),scan,h-d(6),paint);
      paint.setStyle(Paint.Style.FILL);paint.setColor(color);paint.setTextSize(d(13));paint.setTypeface(Typeface.DEFAULT_BOLD);
      c.drawText(sector+"  /  SOURCE DISPLAY",d(13),d(22),paint);
      paint.setColor(good?DuwmUnifiedTheme.ACCENT:DuwmUnifiedTheme.UNAVAILABLE);c.drawCircle(w-d(15),d(16),d(4),paint);
      paint.setColor(0xFFE3F3F7);paint.setTextSize(d(10));paint.setTypeface(Typeface.DEFAULT);
      String msg=status.length()>64?status.substring(0,64):status;
      c.drawText(msg,d(13),h-d(9),paint);
      if(observed>0){String n=String.format(Locale.US,"%,d",observed);paint.setColor(color);
        paint.setTextSize(d(16));paint.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText(n,w-d(18)-paint.measureText(n),h-d(10),paint);}
      if(running)postInvalidateDelayed(75);
    }
  }
}
