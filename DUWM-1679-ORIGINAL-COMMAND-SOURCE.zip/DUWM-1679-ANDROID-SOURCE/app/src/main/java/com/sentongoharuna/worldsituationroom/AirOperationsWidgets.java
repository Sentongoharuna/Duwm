package com.sentongoharuna.worldsituationroom;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Two opt-in, native RemoteViews home widgets. No changes to WallpaperService. */
public abstract class AirOperationsWidgets extends AppWidgetProvider {
    private static final String ACTION_REFRESH = "com.sentongoharuna.worldsituationroom.AIR_WIDGET_REFRESH";
    private static final String PREFS = "air_widget_v2";
    private static final String DATA = "last_snapshot";
    private static final String FAILURE = "last_error";
    // ADS-B endpoint constructed from current worldwide location; no fixed-city feed.
    private static final long RECENT_MS = 180_000L;
    private static final long MIN_RETRY_MS = 45_000L;
    private static final int TEXT = Color.rgb(224,240,244);
    private static final int MUTED = Color.rgb(57,181,195);
    private static final int AQUA = Color.rgb(71,210,219);
    private static final int GREEN = Color.rgb(71,210,219);
    private static final int AMBER = Color.rgb(71,210,219);
    private static final AtomicBoolean FETCHING = new AtomicBoolean(false);
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static volatile long lastAttemptMs;

    public static final class Pulse extends AirOperationsWidgets {}
    public static final class Command extends AirOperationsWidgets {}

    @Override public void onReceive(Context context, Intent intent) {
        String action = intent == null ? "" : intent.getAction();
        if (AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(action) || ACTION_REFRESH.equals(action)) {
            final Context app = context.getApplicationContext();
            renderAll(app); // Show cached data immediately; never block Android's main thread.
            long now = android.os.SystemClock.elapsedRealtime();
            if ((lastAttemptMs != 0L && now - lastAttemptMs < MIN_RETRY_MS)
                    || !FETCHING.compareAndSet(false, true)) return;
            lastAttemptMs = now;
            final PendingResult completion = goAsync();
            try {
                IO.execute(new Runnable() {
                    @Override public void run() {
                        try { refresh(app); }
                        finally {
                            FETCHING.set(false);
                            renderAll(app);
                            RunningballV14SignalWidget.updateAll(app);
                            completion.finish();
                        }
                    }
                });
            } catch (RuntimeException error) {
                FETCHING.set(false);
                completion.finish();
            }
            return;
        }
        super.onReceive(context, intent);
    }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        renderAll(context.getApplicationContext());
    }

    @Override public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager,
                                                      int id, android.os.Bundle options) {
        renderAll(context.getApplicationContext());
    }

    private static void refresh(Context context) {
        if (!RunningballWorldTarget.ready(context)) {
            context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString(FAILURE,"SELECT WORLD REGION").apply();
            return;
        }
        HttpURLConnection conn = null;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        try {
            conn = (HttpURLConnection) new URL(RunningballWorldTarget.url(context)).openConnection();
            conn.setConnectTimeout(3500);
            conn.setReadTimeout(3500);
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("User-Agent", "RUNNINGBALL2-Air-Widget/2");
            int status = conn.getResponseCode();
            if (status != 200) throw new IllegalStateException(status == 429 ? "RATE LIMITED" : "HTTP " + status);
            ByteArrayOutputStream data = new ByteArrayOutputStream();
            try (InputStream in = conn.getInputStream()) {
                byte[] buffer = new byte[8192];
                int count;
                while ((count = in.read(buffer)) != -1) {
                    if (data.size() + count > 2_000_000) throw new IllegalStateException("FEED TOO LARGE");
                    data.write(buffer, 0, count);
                }
            }
            JSONObject response = new JSONObject(new String(data.toByteArray(), StandardCharsets.UTF_8));
            JSONArray records = response.optJSONArray("ac");
            if (records == null) throw new IllegalStateException("NO AIRCRAFT ARRAY");
            List<Flight> seen = new ArrayList<>();
            int moving = 0, onGround = 0;
            for (int i=0; i<records.length() && i<1200; i++) {
                JSONObject row = records.optJSONObject(i);
                if (row == null) continue;
                String hex = row.optString("hex", "").trim().toUpperCase(Locale.US);
                if (!hex.matches("[0-9A-F]{6}")) continue;
                double lat = row.optDouble("lat", Double.NaN);
                double lon = row.optDouble("lon", Double.NaN);
                double positionAge = row.optDouble("seen_pos", Double.NaN);
                if (!finite(lat) || !finite(lon) || Math.abs(lat)>90 || Math.abs(lon)>180
                        || !finite(positionAge) || positionAge<0 || positionAge>120) continue;
                double nm = distanceNm(RunningballWorldTarget.lat(context), RunningballWorldTarget.lon(context), lat, lon);
                if (nm>250d) continue;
                String flight = row.optString("flight", "").trim();
                if (flight.length()==0) flight = hex;
                Object altitudeRaw = row.opt("alt_baro");
                double altitude = altitudeRaw instanceof Number ? ((Number)altitudeRaw).doubleValue() : Double.NaN;
                boolean grounded = "ground".equalsIgnoreCase(String.valueOf(altitudeRaw));
                double speed = row.optDouble("gs", Double.NaN);
                double heading = row.optDouble("track", Double.NaN);
                if (grounded) onGround++;
                else if (finite(speed) && speed >= 40d) moving++;
                seen.add(new Flight(hex, flight, lat, lon, nm, altitude, speed, heading, positionAge, grounded));
            }
            Collections.sort(seen, new Comparator<Flight>() {
                @Override public int compare(Flight a, Flight b) { return Double.compare(a.distanceNm, b.distanceNm); }
            });
            JSONArray items = new JSONArray();
            for (int i=0; i<Math.min(seen.size(), 160); i++) items.put(seen.get(i).toJson());
            long now = System.currentTimeMillis();
            JSONObject cache = new JSONObject();
            cache.put("time", now);
            cache.put("region", RunningballWorldTarget.label(context));
            cache.put("observerLat", RunningballWorldTarget.lat(context));
            cache.put("observerLon", RunningballWorldTarget.lon(context));
            cache.put("count", seen.size());
            cache.put("moving", moving);
            cache.put("ground", onGround);
            cache.put("items", items);
            prefs.edit().putString(DATA, cache.toString()).remove(FAILURE).apply();
        } catch (Exception error) {
            String why = error.getMessage();
            String reason = why != null && why.contains("RATE LIMITED") ? "RATE LIMITED" : "SOURCE UNAVAILABLE";
            prefs.edit().putString(FAILURE, reason).apply();
        } finally { if (conn != null) conn.disconnect(); }
    }

    static JSONObject lastData(Context context) {
        try { return new JSONObject(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(DATA, "{}")); }
        catch (Exception error) { return new JSONObject(); }
    }

    private static void renderAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        JSONObject data = lastData(context);
        String error = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(FAILURE, "");
        long stamp = data.optLong("time", 0L);
        int count = data.optInt("count", 0);
        int moving = data.optInt("moving", 0);
        int ground = data.optInt("ground", 0);
        JSONArray aircraft = data.optJSONArray("items");
        long age = stamp==0 ? Long.MAX_VALUE : Math.max(0L, System.currentTimeMillis() - stamp);
        String state = stamp==0 ? "WAITING" : !error.isEmpty() ? "CACHED" : age<=RECENT_MS ? "RECENT" : "CACHED";
        String when = stamp==0 ? "NO REPORT YET" : "FIX " + utc(stamp);
        int statusColor = "RECENT".equals(state) ? GREEN : "WAITING".equals(state) ? AQUA : AMBER;

        int[] pulse = manager.getAppWidgetIds(new ComponentName(context, Pulse.class));
        for (int id : pulse) {
            RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.rb_air_pulse);
            rv.setTextViewText(R.id.rb_air_pulse_region, RunningballWorldTarget.coverage(context));
            rv.setTextViewText(R.id.rb_air_pulse_count, stamp==0 ? "--" : String.valueOf(count));
            rv.setTextViewText(R.id.rb_air_pulse_state, state);
            rv.setTextColor(R.id.rb_air_pulse_state, statusColor);
            rv.setTextViewText(R.id.rb_air_pulse_moving, stamp==0 ? "-- MOVING" : moving + " MOVING");
            rv.setTextViewText(R.id.rb_air_pulse_fix, ageLabel(age, stamp) + "  •  " + when);
            rv.setTextViewText(R.id.rb_air_pulse_ground, stamp == 0 ? "-- GROUND" : ground + " GROUND");
            android.os.Bundle options = manager.getAppWidgetOptions(id);
            int heightDp = Math.max(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0),
                                    options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0));
            // The 2x2 home widget stays compact; a tall widget reveals useful flight details.
            rv.setViewVisibility(R.id.rb_air_pulse_metrics,
                                 heightDp >= 135 ? android.view.View.VISIBLE : android.view.View.GONE);
            rv.setViewVisibility(R.id.rb_air_pulse_extra,
                                 heightDp >= 180 ? android.view.View.VISIBLE : android.view.View.GONE);
            rv.setViewVisibility(R.id.rb_air_pulse_row2,
                                 heightDp >= 245 ? android.view.View.VISIBLE : android.view.View.GONE);
            int[] pRows = {R.id.rb_air_pulse_row1, R.id.rb_air_pulse_row2};
            int[] pNames = {R.id.rb_air_pulse_call1, R.id.rb_air_pulse_call2};
            int[] pStats = {R.id.rb_air_pulse_stat1, R.id.rb_air_pulse_stat2};
            for (int index = 0; index < pRows.length; index++) {
                JSONObject flight = aircraft == null ? null : aircraft.optJSONObject(index);
                String hex = flight == null ? "" : flight.optString("hex", "");
                rv.setTextViewText(pNames[index], flight == null ? "NO REPORTED FLIGHT" :
                                   trim(flight.optString("flight", hex), 15));
                rv.setTextViewText(pStats[index], flight == null ?
                                   (stamp == 0 ? "AWAITING REPORT" : "NO POSITION AVAILABLE") :
                                   fmt(flight.optDouble("nm", Double.NaN), " NM") + "   " +
                                   (flight.optBoolean("ground", false) ? "GROUND" :
                                    fmt(flight.optDouble("alt", Double.NaN), " FT")) + "   " +
                                   fmt(flight.optDouble("speed", Double.NaN), " KT"));
                rv.setOnClickPendingIntent(pRows[index], openDetail(context, 510_000 + id * 10 + index, hex));
            }
            rv.setOnClickPendingIntent(R.id.rb_air_pulse_refresh, refreshIntent(context, id, Pulse.class));
            rv.setOnClickPendingIntent(R.id.rb_air_pulse_open, openDetail(context, id, ""));
            manager.updateAppWidget(id, rv);
        }
        int[] desk = manager.getAppWidgetIds(new ComponentName(context, Command.class));
        for (int id : desk) {
            RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.rb_air_command);
            rv.setTextViewText(R.id.rb_air_command_region, RunningballWorldTarget.coverage(context));
            rv.setTextViewText(R.id.rb_air_command_state, state);
            rv.setTextColor(R.id.rb_air_command_state, statusColor);
            rv.setTextViewText(R.id.rb_air_command_count, stamp==0 ? "--" : String.valueOf(count));
            rv.setTextViewText(R.id.rb_air_command_moving, stamp==0 ? "--" : String.valueOf(moving));
            rv.setTextViewText(R.id.rb_air_command_ground, stamp==0 ? "--" : String.valueOf(ground));
            rv.setTextViewText(R.id.rb_air_command_fix, when + "  •  250 NM");
            rv.setTextViewText(R.id.rb_air_command_provider,
                    error.isEmpty() ? "SOURCE ADSB.LOL  •  OBSERVED POSITIONS" : "SOURCE " + error + "  •  CACHED POSITIONS");
            rv.setTextViewText(R.id.rb_air_command_age, ageLabel(age, stamp));
            rv.setTextColor(R.id.rb_air_command_age, statusColor);
            rv.setImageViewBitmap(R.id.rb_air_command_radar, radarImage(context, aircraft, stamp, count));
            rv.setOnClickPendingIntent(R.id.rb_air_command_radar, openRadar(context, id));
            rv.setOnClickPendingIntent(R.id.rb_air_open_radar, openRadar(context, id + 50_000));
            android.os.Bundle sizeOptions = manager.getAppWidgetOptions(id);
            int availableHeight = Math.max(sizeOptions.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0),
                                           sizeOptions.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0));
            rv.setViewVisibility(R.id.rb_air_command_radar, availableHeight >= 270 ? android.view.View.VISIBLE : android.view.View.GONE);
            rv.setViewVisibility(R.id.rb_air_row2, availableHeight >= 285 ? android.view.View.VISIBLE : android.view.View.GONE);
            rv.setViewVisibility(R.id.rb_air_row3, availableHeight >= 355 ? android.view.View.VISIBLE : android.view.View.GONE);
            rv.setOnClickPendingIntent(R.id.rb_air_command_refresh, refreshIntent(context, id, Command.class));
            int[] flightRows = {R.id.rb_air_row1, R.id.rb_air_row2, R.id.rb_air_row3};
            int[] names = {R.id.rb_air_call1, R.id.rb_air_call2, R.id.rb_air_call3};
            int[] stats = {R.id.rb_air_stat1, R.id.rb_air_stat2, R.id.rb_air_stat3};
            for (int index=0;index<3;index++) {
                JSONObject flight = aircraft == null ? null : aircraft.optJSONObject(index);
                String hex = "";
                if (flight == null) {
                    rv.setTextViewText(names[index], index==0 && stamp>0 && count==0 ? "NO REPORTED AIRCRAFT" : "AWAITING AIRCRAFT");
                    rv.setTextViewText(stats[index], "—");
                } else {
                    hex = flight.optString("hex", "");
                    rv.setTextViewText(names[index], trim(flight.optString("flight", hex), 14));
                    rv.setTextViewText(stats[index], fmt(flight.optDouble("nm", Double.NaN), "NM")
                            + "  " + (flight.optBoolean("ground", false) ? "GROUND" : fmt(flight.optDouble("alt", Double.NaN), "FT"))
                            + "  " + fmt(flight.optDouble("speed", Double.NaN), "KT")
                            + "  HDG " + fmt(flight.optDouble("heading", Double.NaN), "°"));
                }
                rv.setOnClickPendingIntent(flightRows[index], openDetail(context, id * 10 + index, hex));
            }
            manager.updateAppWidget(id, rv);
        }
    }

    /** Snapshot age is calculated locally; no claim of continuous live tracking. */
    private static String ageLabel(long ageMs, long timestamp) {
        if (timestamp <= 0L) return "NO DATA";
        if (ageMs < 60_000L) return "AGE " + Math.max(0L, ageMs / 1000L) + "S";
        if (ageMs < 3_600_000L) return "AGE " + ageMs / 60_000L + "M";
        return "AGE " + ageMs / 3_600_000L + "H";
    }

    /** Real, finite provider positions only; snapshot radar never predicts tracks. */
    private static Bitmap radarImage(Context context, JSONArray flights, long timestamp, int total) {
        final int width = 540, height = 148;
        Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        canvas.drawColor(Color.rgb(8,24,36));
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final float cx = 88f, cy = 74f, radius = 58f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.8f);
        p.setColor(Color.argb(155,40,145,162));
        for (int ring=1; ring<=3; ring++) canvas.drawCircle(cx,cy,radius*ring/3f,p);
        p.setColor(Color.argb(120,40,145,162));
        canvas.drawLine(cx-radius,cy,cx+radius,cy,p);
        canvas.drawLine(cx,cy-radius,cx,cy+radius,p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(71,210,219));
        p.setTextSize(15f);
        canvas.drawText("N",cx-6f,cy-radius-6f,p);
        p.setColor(Color.rgb(71,210,219));
        canvas.drawCircle(cx,cy,4f,p);
        int plotted=0;
        if (flights!=null && timestamp>0) for(int i=0; i<flights.length() && i<8; i++) {
            JSONObject item=flights.optJSONObject(i);
            if(item==null)continue;
            double la=item.optDouble("lat",Double.NaN), lo=item.optDouble("lon",Double.NaN);
            if(!finite(la) || !finite(lo))continue;
            double north=(la-RunningballWorldTarget.lat(context))*60d;
            double east=(lo-RunningballWorldTarget.lon(context))*60d*Math.cos(Math.toRadians(RunningballWorldTarget.lat(context)));
            double nm=Math.hypot(north,east);
            if(nm>250d)continue;
            p.setColor(item.optBoolean("ground",false)?Color.rgb(108,149,158):Color.rgb(71,210,219));
            canvas.drawCircle(cx+(float)(east/250d*radius),cy-(float)(north/250d*radius),5f,p);
            plotted++;
        }
        p.setColor(Color.rgb(71,210,219));p.setTextSize(19f);p.setFakeBoldText(true);
        canvas.drawText("SECTOR: "+RunningballWorldTarget.label(context),178f,38f,p);
        p.setFakeBoldText(false);p.setTextSize(16f);p.setColor(Color.rgb(191,205,208));
        canvas.drawText("250 NM  •  POSITION SNAPSHOT",178f,68f,p);
        canvas.drawText(timestamp<=0?"AWAITING ADS-B REPORT":plotted+" PLOTTED / "+total+" REPORTED",178f,100f,p);
        p.setTextSize(13f);p.setColor(Color.rgb(40,145,162));
        canvas.drawText("NO PREDICTED AIRCRAFT MOVEMENT",178f,125f,p);
        return bmp;
    }

    private static PendingIntent openRadar(Context context, int id) {
        Intent intent = new Intent(context, AirRadarActivity.class);
        return PendingIntent.getActivity(context, 620_000 + id, intent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static PendingIntent refreshIntent(Context context, int id, Class<?> receiver) {
        Intent intent = new Intent(context, receiver);
        intent.setAction(ACTION_REFRESH);
        return PendingIntent.getBroadcast(context, id + (receiver==Pulse.class?100_000:200_000), intent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static PendingIntent openDetail(Context context, int requestId, String hex) {
        Intent intent = new Intent(context, AirFlightDetailsActivity.class);
        intent.putExtra("air_hex", hex);
        return PendingIntent.getActivity(context, 300_000 + requestId, intent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static String utc(long time) {
        SimpleDateFormat format = new SimpleDateFormat("HH:mm 'UTC'", Locale.US);
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        return format.format(new Date(time));
    }
    private static String trim(String value,int limit) {
        return value.length()<=limit?value:value.substring(0,limit);
    }
    static boolean finite(double value) { return !Double.isNaN(value) && !Double.isInfinite(value); }
    static String fmt(double value, String unit) {
        return finite(value) ? String.format(Locale.US, "%.0f%s", value, unit) : "—";
    }
    private static double distanceNm(double la1,double lo1,double la2,double lo2) {
        double dlat=Math.toRadians(la2-la1),dlon=Math.toRadians(lo2-lo1);
        double h=Math.pow(Math.sin(dlat/2),2)+Math.cos(Math.toRadians(la1))
                *Math.cos(Math.toRadians(la2))*Math.pow(Math.sin(dlon/2),2);
        return 3440.065d*2d*Math.atan2(Math.sqrt(h),Math.sqrt(Math.max(0d,1d-h)));
    }

    private static final class Flight {
        final String hex,flight;
        final double lat,lon,distanceNm,altitudeFt,speedKt,headingDeg,seenSeconds;
        final boolean ground;
        Flight(String hex,String flight,double lat,double lon,double nm,double alt,double spd,double hdg,double seen,boolean ground) {
            this.hex=hex;this.flight=flight;this.lat=lat;this.lon=lon;this.distanceNm=nm;
            this.altitudeFt=alt;this.speedKt=spd;this.headingDeg=hdg;this.seenSeconds=seen;this.ground=ground;
        }
        JSONObject toJson() throws org.json.JSONException {
            JSONObject o=new JSONObject();
            o.put("hex",hex);o.put("flight",flight);o.put("lat",lat);o.put("lon",lon);
            o.put("nm",distanceNm);o.put("ground",ground);o.put("seen",seenSeconds);
            if(finite(altitudeFt))o.put("alt",altitudeFt);
            if(finite(speedKt))o.put("speed",speedKt);
            if(finite(headingDeg))o.put("heading",headingDeg);
            return o;
        }
    }
}
