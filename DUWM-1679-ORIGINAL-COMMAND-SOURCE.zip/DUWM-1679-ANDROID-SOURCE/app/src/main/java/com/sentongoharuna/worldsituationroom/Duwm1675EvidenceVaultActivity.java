package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** New DUWM 1675 feature: offline capture, compare and CSV export of actual provider receipt metadata. */
public final class Duwm1675EvidenceVaultActivity extends Activity {
    private static final int BG=0xFF081824,CARD=0xFF0E3F4D,STROKE=0xFF185769,WHITE=0xFFE1F1F5,
                             MUTED=0xFFBCC9CC,ACCENT=0xFF47D2DB,GOLD=0xFF47D2DB;
    private static final int SAVE_CSV=1675;
    private LinearLayout entries;
    private TextView overview;
    private EditText note;
    private Spinner filter;
    private String pendingCsv;
    private int dp(int v){return Math.round(getResources().getDisplayMetrics().density*v);}
    private GradientDrawable bg(int color){GradientDrawable g=new GradientDrawable();g.setColor(color);
        g.setStroke(dp(1),STROKE);g.setCornerRadius(dp(12));return g;}
    private TextView text(String value,int sp,int col,boolean bold){TextView t=new TextView(this);t.setText(value);
        t.setTextSize(sp);t.setTextColor(col);t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));return t;}
    private TextView button(String value,Runnable click){TextView t=text(value,13,ACCENT,true);
        t.setGravity(Gravity.CENTER);t.setPadding(dp(9),dp(12),dp(9),dp(12));t.setBackground(bg(CARD));t.setOnClickListener(v->click.run());return t;}
    private void pair(LinearLayout root,TextView l,TextView r){LinearLayout row=new LinearLayout(this);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(9);root.addView(row,lp);
        row.addView(l,new LinearLayout.LayoutParams(0,dp(48),1));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,dp(48),1);rp.leftMargin=dp(8);
        row.addView(r,rp);
    }
    @Override public void onCreate(Bundle state){super.onCreate(state);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        ScrollView screen=new ScrollView(this);screen.setBackgroundColor(BG);screen.setFillViewport(true);setContentView(screen);
        Duwm1167SafeArea.install(this,screen);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(16),dp(16),dp(16),dp(38));screen.addView(root);
        root.addView(text("DEVELOP.UGANDA  /  SOURCE EVIDENCE",13,ACCENT,true));
        root.addView(text("EVIDENCE VAULT  /  1675",25,WHITE,true));
        TextView back=button("‹  BACK TO MISSION CONTROL",()->finish());
        LinearLayout.LayoutParams backLp=new LinearLayout.LayoutParams(-1,dp(43));backLp.topMargin=dp(8);
        root.addView(back,backLp);
        TextView explain=text("Save what the app actually received. Compare changes between saved captures, inspect source timestamps and export CSV. All data stays on this phone until you share it.",13,MUTED,false);
        explain.setPadding(0,dp(12),0,dp(14));root.addView(explain);
        overview=text("NO SAVED CAPTURES",14,GOLD,true);root.addView(overview);
        note=new EditText(this);note.setSingleLine(true);note.setHint("Optional note for this capture");note.setTextColor(WHITE);
        note.setHintTextColor(MUTED);note.setTextSize(14);note.setPadding(dp(10),dp(9),dp(10),dp(9));note.setBackground(bg(CARD));
        LinearLayout.LayoutParams nlp=new LinearLayout.LayoutParams(-1,-2);nlp.topMargin=dp(12);root.addView(note,nlp);
        pair(root,button("CAPTURE RECEIPTS",()->capture()),button("COMPARE LAST TWO",()->compare()));
        pair(root,button("SAVE CSV FILE",()->saveCsv()),button("SHARE LATEST 9:16 CARD",()->shareLatest()));
        TextView caveat=text("NO SYNTHETIC DATA • A SNAPSHOT IS NOT A NEW PROVIDER FETCH • RECEIPT COUNTS MAY INCLUDE DUPLICATED NEWS ENTRIES",11,MUTED,false);
        caveat.setPadding(0,dp(18),0,dp(10));root.addView(caveat);
        String[] labels={"ALL CHANNELS","AIR","SAT","SEA","QUAKE","EVENT","NEWS","WEATHER","FX","KP"};
        filter=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);filter.setAdapter(adapter);
        filter.setBackground(bg(CARD));root.addView(filter,new LinearLayout.LayoutParams(-1,dp(52)));
        filter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> parent,View view,int position,long id){render();}
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent){} });
        entries=new LinearLayout(this);entries.setOrientation(LinearLayout.VERTICAL);root.addView(entries);
        render();
    }
    private void capture(){try{Duwm1675EvidenceStore.capture(this,note.getText().toString());note.setText("");render();
        Toast.makeText(this,"Actual receipt metadata saved on this phone",Toast.LENGTH_SHORT).show();
        }catch(Exception e){Toast.makeText(this,"Could not save: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    private String currentChannel(){if(filter==null||filter.getSelectedItemPosition()<=0)return "";
        return String.valueOf(filter.getSelectedItem());}
    private void render(){if(entries==null)return;
        JSONArray saved=Duwm1675EvidenceStore.read(this);entries.removeAllViews();
        overview.setText(saved.length()+" SNAPSHOTS SAVED  •  LATEST FIRST  •  MAX 60");
        if(saved.length()==0){TextView blank=text("No history yet. Tap CAPTURE RECEIPTS to record the nine actual source statuses currently stored on this device.",14,MUTED,false);
            blank.setPadding(0,dp(20),0,0);entries.addView(blank);return;}
        String only=currentChannel();
        for(int i=0;i<saved.length();i++){
            JSONObject s=saved.optJSONObject(i);if(s==null)continue;
            String time=Duwm1675EvidenceMath.utc(s.optLong("capturedAt"));
            String summary=s.optInt("receiptCount")+" / 9 source receipts";
            if(!only.isEmpty()){
                JSONArray list=s.optJSONArray("channels");
                if(list!=null)for(int j=0;j<list.length();j++){
                    JSONObject c=list.optJSONObject(j);if(c!=null&&only.equals(c.optString("id"))){
                        summary=only+"  /  "+c.optString("value","--")+"  /  "+c.optString("status");break;}
                }
            }
            TextView card=text(time+"\n"+summary+(s.optString("note").isEmpty()?"":"\nNOTE  "+s.optString("note"))+"\nTAP TO INSPECT SAVED SOURCE TIMESTAMPS",13,WHITE,false);
            card.setPadding(dp(14),dp(14),dp(14),dp(14));card.setBackground(bg(CARD));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(10);entries.addView(card,p);
            final JSONObject data=s;card.setOnClickListener(v->new AlertDialog.Builder(this)
                .setTitle("SNAPSHOT / "+time).setMessage(Duwm1675EvidenceStore.details(data,currentChannel()))
                .setPositiveButton("SHARE CARD",(d,w)->share(data)).setNegativeButton("CLOSE",null).show());
        }
    }
    private void compare(){JSONArray saved=Duwm1675EvidenceStore.read(this);
        if(saved.length()<2){Toast.makeText(this,"Save two snapshots first",Toast.LENGTH_LONG).show();return;}
        new AlertDialog.Builder(this).setTitle("RECEIPT CHANGE / NOT LIVE TELEMETRY")
            .setMessage(Duwm1675EvidenceStore.compare(saved.optJSONObject(1),saved.optJSONObject(0)))
            .setPositiveButton("CLOSE",null).show();
    }
    private void shareLatest(){JSONArray saved=Duwm1675EvidenceStore.read(this);
        if(saved.length()<1){Toast.makeText(this,"Capture a snapshot first",Toast.LENGTH_SHORT).show();return;}
        share(saved.optJSONObject(0));
    }
    private void share(JSONObject snapshot){if(snapshot==null)return;
        Duwm1671Share.share(this,"EVIDENCE","DUWM SOURCE EVIDENCE / "+Duwm1675EvidenceMath.utc(snapshot.optLong("capturedAt")),
           Duwm1675EvidenceStore.details(snapshot,currentChannel()),"DEVICE SNAPSHOT OF PROVIDER RECEIPT METADATA","",snapshot.optLong("capturedAt"));
    }
    private void saveCsv(){JSONArray saved=Duwm1675EvidenceStore.read(this);
        if(saved.length()==0){Toast.makeText(this,"Capture a snapshot before export",Toast.LENGTH_SHORT).show();return;}
        pendingCsv=Duwm1675EvidenceStore.exportCsv(saved);
        Intent create=new Intent(Intent.ACTION_CREATE_DOCUMENT);create.addCategory(Intent.CATEGORY_OPENABLE);
        create.setType("text/csv");create.putExtra(Intent.EXTRA_TITLE,"duwm-1675-source-evidence.csv");
        try{startActivityForResult(create,SAVE_CSV);}catch(Exception e){Toast.makeText(this,"File picker unavailable",Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=SAVE_CSV||resultCode!=RESULT_OK||data==null||data.getData()==null||pendingCsv==null)return;
        try(OutputStream stream=getContentResolver().openOutputStream(data.getData())){
            if(stream==null)throw new java.io.IOException("Could not write to destination");
            stream.write(pendingCsv.getBytes(StandardCharsets.UTF_8));stream.flush();
            Toast.makeText(this,"CSV saved to selected location",Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        finally{pendingCsv=null;}
    }
}
