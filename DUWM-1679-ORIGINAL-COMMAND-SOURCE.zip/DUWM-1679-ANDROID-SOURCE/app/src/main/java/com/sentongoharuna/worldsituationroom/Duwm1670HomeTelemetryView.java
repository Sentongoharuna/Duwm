package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.SystemClock;
import android.view.View;

/** 1671 home telemetry: SIX true data sectors, distinct source freshness states, no invented counts. */
public final class Duwm1670HomeTelemetryView extends View {
  private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private boolean running;
  private final String[] names={"AIR","SEA","NEWS","WX","FX","QUAKE"};
  private final String[] values={"--","--","--","--","--","--"};
  private final boolean[] available=new boolean[6];
  public Duwm1670HomeTelemetryView(Context c){super(c);setContentDescription("Actual source-backed counts, measurements and freshness; changing LED brightness is a status animation, not a new event.");}
  public void update(){
    Duwm1674UnifiedReceipts.Receipt air=Duwm1674UnifiedReceipts.aircraft(getContext());
    values[0]=air.count();available[0]=air.current;
    int[] ids={2,5,6,7,3};
    for(int k=1;k<names.length;k++){
      if(k==1||k==2){
        Duwm1674UnifiedReceipts.Receipt r=k==1?Duwm1674UnifiedReceipts.maritime(getContext()):Duwm1674UnifiedReceipts.news(getContext());
        values[k]=r.count();available[k]=r.current;
      }else{
        RunningballV25Sources.Result r=RunningballV25Sources.read(getContext(),ids[k-1]);
        values[k]=r.value==null?"--":r.value;
        available[k]=r.fetchedAt>0&&(r.status==RunningballV25Sources.Status.LIVE||r.status==RunningballV25Sources.Status.DELAYED);
      }
    }
    invalidate();
  }
  public void resume(){running=true;update();postInvalidateDelayed(700);}
  public void pause(){running=false;}
  @Override protected void onDetachedFromWindow(){pause();super.onDetachedFromWindow();}
  @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();c.drawColor(0xFF0E3C4A);
    float pulse=(float)Math.sin(SystemClock.uptimeMillis()/390d);
    for(int i=0;i<6;i++){
      float x=i*w/6f,slot=w/6f,dx=getResources().getDisplayMetrics().density;
      p.setColor(0xFF185769);p.setStrokeWidth(dx);if(i>0)c.drawLine(x,dx*6,x,h-dx*6,p);
      p.setStyle(Paint.Style.FILL);p.setColor(available[i]?0xFF39B5C3:0xFF39B5C3);
      c.drawCircle(x+dx*8,h*.23f,Math.max(2,dx*2.5f)+(available[i]?dx*.5f*pulse:0),p);
      p.setColor(0xFF39B5C3);p.setTextSize(Math.min(h*.19f,dx*10f));c.drawText(names[i],x+dx*15f,h*.29f,p);
      p.setColor(available[i]?0xFFE0F0F4:0xFFCBD9DD);p.setTextSize(Math.min(h*.26f,dx*12f));
      String v=values[i];float max=slot-dx*9;while(v.length()>2&&p.measureText(v)>max)v=v.substring(0,v.length()-1);
      if(v.length()<values[i].length())v=v.substring(0,Math.max(0,v.length()-1))+"…";
      c.drawText(v,x+dx*6,h*.76f,p);
    }
    if(running)postInvalidateDelayed(750);
  }
}
