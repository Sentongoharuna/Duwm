package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** True historical source receipt series. Animation is a scan cursor, not a fabricated quote. */
public final class Duwm1671TrendView extends View {
  private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
  private final ArrayList<Duwm1671Measurements.Point> series=new ArrayList<>();
  private String title="REAL RECEIPTS",units="";private boolean active=false;
  public Duwm1671TrendView(Context c){super(c);setContentDescription("Historical values from actual cached provider receipts only");}
  public void setData(String name,String unit,List<Duwm1671Measurements.Point> data){title=name;units=unit;series.clear();if(data!=null)series.addAll(data);invalidate();}
  public void start(){active=true;postInvalidateDelayed(350);}
  public void stop(){active=false;}
  @Override protected void onDetachedFromWindow(){stop();super.onDetachedFromWindow();}
  private float dp(float a){return a*getResources().getDisplayMetrics().density;}
  @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();
    p.setShader(new LinearGradient(0,0,w,h,0xFF125163,0xFF081824,Shader.TileMode.CLAMP));
    c.drawRect(0,0,w,h,p);p.setShader(null);
    p.setColor(0xFF47D2DB);p.setTextSize(dp(12));p.setStyle(Paint.Style.FILL);c.drawText(title+"   /   "+series.size()+" SOURCE RECEIPTS",dp(12),dp(22),p);
    float l=dp(53),r=w-dp(13),top=dp(44),bottom=h-dp(35);
    p.setColor(0xFF185769);p.setStrokeWidth(dp(.7f));for(int i=0;i<=4;i++){float yy=top+i*(bottom-top)/4f;c.drawLine(l,yy,r,yy,p);}
    if(series.size()<2){
      p.setColor(0xFF47D2DB);p.setTextSize(dp(15));p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
      c.drawText("AWAITING SOURCE HISTORY",dp(13),h*.53f,p);
      p.setColor(0xFFC1CFD2);p.setTextSize(dp(11));p.setTypeface(android.graphics.Typeface.DEFAULT);
      c.drawText("Two distinct real receipts are required",dp(13),h*.68f,p);
      // No graph or synthetic trend is drawn without actual measurements.
      return;
    }
    long t0=series.get(0).received,t1=series.get(series.size()-1).received;
    double low=Double.POSITIVE_INFINITY,high=Double.NEGATIVE_INFINITY;
    for(Duwm1671Measurements.Point q:series){low=Math.min(low,q.value);high=Math.max(high,q.value);}
    if(t1<=t0){c.drawText("TIMESTAMP SERIES UNAVAILABLE",l,h*.6f,p);return;}
    double span=Math.max(0.0001,high-low);double padding=Math.max(span*.12,Math.abs(high)*.001);
    low-=padding;high+=padding;
    Path path=new Path();int i=0;
    for(Duwm1671Measurements.Point q:series){float x=l+(float)((q.received-t0)/(double)(t1-t0))*(r-l);
      float y=bottom-(float)((q.value-low)/(high-low))*(bottom-top);
      if(i++==0)path.moveTo(x,y);else path.lineTo(x,y);}
    p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(5.0f));p.setColor(0x4447D2DB);c.drawPath(path,p);
    p.setStrokeWidth(dp(2.5f));p.setColor(0xFF47D2DB);c.drawPath(path,p);p.setStyle(Paint.Style.FILL);
    p.setTextSize(dp(10));p.setColor(0xFFD6E5E8);c.drawText(String.format(Locale.US,"%.3f",high),dp(5),top+dp(8),p);c.drawText(String.format(Locale.US,"%.3f",low),dp(5),bottom,p);
    c.drawText("OLDEST RECEIPT",l,bottom+dp(22),p);c.drawText("LATEST  "+units,Math.max(l,r-dp(108)),bottom+dp(22),p);
    // Moving cursor is a decorative reading guide, never a new quote or interpolated observation.
    float scan=l+(SystemClock.uptimeMillis()%5200L)/5200f*(r-l);
    p.setColor(0x6639B5C3);p.setStrokeWidth(dp(1));c.drawLine(scan,top,scan,bottom,p);
    if(active)postInvalidateDelayed(90);
  }
}
