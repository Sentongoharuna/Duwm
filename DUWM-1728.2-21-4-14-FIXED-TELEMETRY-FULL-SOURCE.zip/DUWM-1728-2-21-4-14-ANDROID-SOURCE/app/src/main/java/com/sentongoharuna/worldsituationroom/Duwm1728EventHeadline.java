package com.sentongoharuna.worldsituationroom;

import java.util.Locale;

/** Produces a short broadcast headline only from the current on-device AI description.
 * It never adds people, places, causes or events that were not present in that description. */
public final class Duwm1728EventHeadline {
    public static final int MAX_WORDS = 9;
    private Duwm1728EventHeadline(){}

    public static String fromDescription(String modelDescription){
        String text=Duwm1728SceneTimeline.clean(modelDescription, Duwm1728SceneTimeline.MAX_DESCRIPTION_CODE_POINTS);
        if(text.isEmpty())return "";
        String lower=text.toLowerCase(Locale.ROOT);
        String[] prefixes={"this image shows ","the image shows ","this photo shows ","the photo shows ","an image of ","a photo of ","there are ","there is "};
        for(String prefix:prefixes)if(lower.startsWith(prefix)){text=text.substring(prefix.length()).trim();break;}
        // Keep one observed sentence only. This is editing of the model output, not another inference.
        for(int i=0;i<text.length();i++){char c=text.charAt(i);if((c=='.'||c=='!'||c=='?')&&(i+1==text.length()||Character.isWhitespace(text.charAt(i+1)))){text=text.substring(0,i).trim();break;}}
        String[] words=text.split("\\s+");
        StringBuilder out=new StringBuilder();int used=0;
        for(String word:words){if(word.isEmpty())continue;if(used>=MAX_WORDS)break;if(out.length()>0)out.append(' ');out.append(word);used++;}
        if(out.length()==0)return "";
        String headline=Duwm1728SceneTimeline.clean(out.toString(), Duwm1728SceneTimeline.MAX_TITLE_CODE_POINTS);
        return headline.toUpperCase(Locale.ROOT);
    }
}
