package com.sentongoharuna.worldsituationroom;

import java.util.ArrayDeque;

/** Actual presented TextureView frame arrivals. This is not an encoder frame-rate claim. */
public final class Duwm1728PreviewRate {
    private static final long WINDOW_MS=2000L, MIN_WINDOW_MS=500L, MAX_SILENCE_MS=1000L;
    private final ArrayDeque<Long> arrivals=new ArrayDeque<>();
    private long lastProducerNs=-1L,lastArrivalMs=-1L;

    public static final class Reading {
        public final double framesPerSecond;
        public final long observedAtMs,windowMs;
        public final int frames;
        Reading(double fps,long at,long window,int count){
            framesPerSecond=fps;observedAtMs=at;windowMs=window;frames=count;
        }
    }

    public synchronized void reset(){arrivals.clear();lastProducerNs=-1L;lastArrivalMs=-1L;}

    public synchronized void onFrame(long elapsedMs,long producerNs){
        if(elapsedMs<0L)return;
        if(lastArrivalMs>=0L&&elapsedMs<lastArrivalMs)reset();
        // TextureView can deliver another UI notification for an unchanged producer frame.
        if(producerNs>0L&&lastProducerNs>0L&&producerNs<=lastProducerNs)return;
        if(lastArrivalMs==elapsedMs)return;
        if(producerNs>0L)lastProducerNs=producerNs;
        lastArrivalMs=elapsedMs;arrivals.addLast(elapsedMs);trim(elapsedMs);
        while(arrivals.size()>1000)arrivals.removeFirst();
    }

    private void trim(long now){while(!arrivals.isEmpty()&&now-arrivals.peekFirst()>WINDOW_MS)arrivals.removeFirst();}

    public synchronized Reading at(long elapsedMs){
        if(elapsedMs<0L||lastArrivalMs<0L||elapsedMs<lastArrivalMs)
            return new Reading(Double.NaN,-1L,0L,0);
        trim(elapsedMs);
        int count=arrivals.size();long span=count<2?0L:arrivals.peekLast()-arrivals.peekFirst();
        if(count<2||span<MIN_WINDOW_MS||elapsedMs-lastArrivalMs>MAX_SILENCE_MS)
            return new Reading(Double.NaN,lastArrivalMs,span,count);
        double fps=(count-1)*1000d/span;
        if(!Double.isFinite(fps)||fps<=0d||fps>240d)fps=Double.NaN;
        return new Reading(fps,lastArrivalMs,span,count);
    }
}
