package com.sentongoharuna.worldsituationroom;

import java.util.Locale;

/** One compact source-timed telemetry slot. It rotates supplied observations only;
 * it never synthesizes GPS, speed or frame-rate values. */
public final class Duwm1728RotatingTelemetry {
    public static final long SLOT_MS = 4_000L;
    private Duwm1728RotatingTelemetry() {}

    public static int index(long sourceMs){
        if(sourceMs<0)return 3;
        return (int)((sourceMs/SLOT_MS)%4L);
    }

    public static long nextBoundaryDelayMs(long sourceMs){
        if(sourceMs<0)return -1;
        long remainder=sourceMs%SLOT_MS;
        return remainder==0?SLOT_MS:SLOT_MS-remainder;
    }

    public static String value(long sourceMs,String clockPrefix,boolean coordinatesAllowed,
            String coordinates,String coordinateState,String speed,String movement,String fps){
        switch(index(sourceMs)){
            case 0: return gps(coordinatesAllowed,coordinates,coordinateState);
            case 1: return speed(speed,movement);
            case 2: return frameRate(fps);
            default:return recordingTime(sourceMs,clockPrefix);
        }
    }

    static String gps(boolean allowed,String coordinates,String state){
        String value=clean(allowed?coordinates:state);
        if(value.isEmpty())return allowed?"GPS —":"GPS WITHHELD";
        if(value.toUpperCase(Locale.ROOT).startsWith("LAT/LON "))
            value="GPS "+value.substring(8).trim();
        else if(!value.toUpperCase(Locale.ROOT).startsWith("GPS")) value="GPS "+value;
        return value;
    }
    static String speed(String speed,String movement){
        String first=clean(speed),second=clean(movement);
        if(first.isEmpty())first="SPEED —";
        if(second.toUpperCase(Locale.ROOT).startsWith("MOVEMENT "))second=second.substring(9).trim();
        return second.isEmpty()?first:first+" • "+second;
    }
    static String frameRate(String fps){
        String value=clean(fps);
        if(value.isEmpty())return "FPS —";
        value=value.replaceFirst("(?i)^PREVIEW FPS\\s+","FPS ")
                   .replaceFirst("(?i)^PREVIEW\\s+","FPS ");
        return value;
    }
    static String recordingTime(long sourceMs,String prefix){
        String p=clean(prefix).toUpperCase(Locale.ROOT);
        if(sourceMs<0||!(p.contains("RECORD")||p.contains("RECORDED")))return "REC —";
        long totalSeconds=sourceMs/1000L;
        long hours=totalSeconds/3600L,minutes=(totalSeconds/60L)%60L,seconds=totalSeconds%60L;
        return String.format(Locale.US,"REC %02d:%02d:%02d",hours,minutes,seconds);
    }
    private static String clean(String value){
        return value==null?"":value.replaceAll("[\\p{Cntrl}]+"," ").trim();
    }
}
