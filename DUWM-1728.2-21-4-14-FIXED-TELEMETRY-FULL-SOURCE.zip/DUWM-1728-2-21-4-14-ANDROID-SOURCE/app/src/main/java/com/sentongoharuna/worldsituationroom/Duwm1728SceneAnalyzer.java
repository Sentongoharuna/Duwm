package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.genai.common.FeatureStatus;
import com.google.mlkit.genai.common.GenAiException;
import com.google.mlkit.genai.imagedescription.ImageDescriber;
import com.google.mlkit.genai.imagedescription.ImageDescriberOptions;
import com.google.mlkit.genai.imagedescription.ImageDescription;
import com.google.mlkit.genai.imagedescription.ImageDescriptionRequest;
import com.google.mlkit.genai.imagedescription.ImageDescriptionResult;

import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

/**
 * Real AICore image inference. All public methods and callbacks use the main thread;
 * SDK futures perform preparation and inference asynchronously. No image is uploaded.
 *
 * request() ALWAYS takes ownership of its Bitmap, including rejected requests. The
 * caller must not recycle or reuse it. Only one accepted image is retained at a time.
 */
public final class Duwm1728SceneAnalyzer implements AutoCloseable {
    public enum State { PAUSED, CHECKING, DOWNLOADING, READY, ANALYZING, WAITING, UNAVAILABLE, CLOSED }

    public interface Listener {
        void onStatus(State state, String detail);
        void onScene(Duwm1728SceneTimeline.Entry entry);
    }

    public static final long MIN_REQUEST_INTERVAL_MS = 4_000L;
    public static final long MAX_RESULT_AGE_MS = 8_000L;
    public static final int MAX_IMAGE_EDGE = 768;
    private static final long INFERENCE_TIMEOUT_MS = 15_000L;
    private static final long MODEL_PREPARATION_TIMEOUT_MS = 10 * 60_000L;
    private static final long FEATURE_RECHECK_MS = 5 * 60_000L;
    private static final long BATTERY_QUOTA_BACKOFF_MS = 60 * 60_000L;
    // The pinned image-description beta resolves a GenAiException.ErrorCode
    // type without these newer named fields. Compare getErrorCode() with the
    // documented wire values instead, retaining the same safe retry behavior.
    // https://developers.google.com/android/reference/com/google/mlkit/genai/common/GenAiException.ErrorCode
    private static final int SDK_BATTERY_QUOTA_ERROR = 27;
    private static final int SDK_BACKGROUND_BLOCKED_ERROR = 30;
    private static final String PREFERENCES = "duwm_scene_model_policy";
    private static final String QUOTA_UNTIL_UTC = "quota_until_utc";
    private static final String TAG = "DUWM-SCENE-AI";

    private final Context context;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Executor completionExecutor = command -> main.post(command);
    private ImageDescriber client;
    private ListenableFuture<?> preparation;
    private FrameRequest inFlight;
    private Runnable retryTask;
    private Runnable preparationTimeout;
    private boolean active;
    private boolean closed;
    private boolean ready;
    private long lifecycleGeneration;
    private long sceneGeneration;
    private long lastSourceMs = -1;
    private long nextAllowedElapsedMs;
    private int consecutiveFailures;
    private State state = State.PAUSED;
    private String statusText = "Scene descriptions paused";

    private static final class FrameRequest {
        final long sceneGeneration;
        final long sourceMs;
        final long capturedElapsedMs;
        Bitmap bitmap;
        ListenableFuture<ImageDescriptionResult> future;
        Runnable timeout;

        FrameRequest(long generation, long sourceMs, long capturedElapsedMs, Bitmap bitmap) {
            this.sceneGeneration = generation;
            this.sourceMs = sourceMs;
            this.capturedElapsedMs = capturedElapsedMs;
            this.bitmap = bitmap;
        }
    }

    public Duwm1728SceneAnalyzer(Context context, Listener listener) {
        requireMainThread();
        if (context == null || listener == null) throw new IllegalArgumentException("Scene owner required");
        this.context = context.getApplicationContext();
        this.listener = listener;
        long until = this.context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
                .getLong(QUOTA_UNTIL_UTC, 0);
        long remaining = Math.max(0, until - System.currentTimeMillis());
        // Preserve a long quota cooldown through Activity/process recreation. Device clock
        // changes cannot make the locally imposed delay longer than one day.
        nextAllowedElapsedMs = SystemClock.elapsedRealtime() + Math.min(remaining, 86_400_000L);
    }

    public void start() { resume(); }

    public void resume() {
        requireMainThread();
        if (closed || active) return;
        active = true;
        lifecycleGeneration++;
        sceneGeneration++;
        lastSourceMs = -1;
        ready = false;
        if (SystemClock.elapsedRealtime() < nextAllowedElapsedMs) {
            publish(State.WAITING, "Scene analysis will resume after its cooldown");
            scheduleRetry();
        } else beginPreparation();
    }

    public void pause() {
        requireMainThread();
        if (closed) return;
        active = false;
        ready = false;
        lifecycleGeneration++;
        sceneGeneration++;
        lastSourceMs = -1;
        cancelRetry();
        cancelPreparation();
        cancelFrame();
        publish(State.PAUSED, "Scene descriptions paused");
    }

    /**
     * Call at a camera switch or recording time-origin change. Model preparation has
     * its own generation; this invalidates scene results without resetting quotas.
     */
    public void resetSession() {
        requireMainThread();
        if (closed) return;
        sceneGeneration++;
        lastSourceMs = -1;
        cancelFrame();
        if (active && ready) publishReadiness();
    }

    public boolean isReady() {
        requireMainThread();
        return active && !closed && ready;
    }

    /** Allows the camera to skip bitmap extraction while inference/preparation is busy. */
    public boolean canRequest() {
        requireMainThread();
        return isReady() && inFlight == null
                && SystemClock.elapsedRealtime() >= nextAllowedElapsedMs;
    }

    /** frameTimeMs is a monotonically increasing source offset within the current session. */
    public boolean request(Bitmap ownedBitmap, long frameTimeMs) {
        requireMainThread();
        if (ownedBitmap == null) return false;
        if (!canRequest() || ownedBitmap.isRecycled() || frameTimeMs < 0
                || frameTimeMs <= lastSourceMs
                || frameTimeMs > Long.MAX_VALUE - Duwm1728SceneTimeline.MAX_VALIDITY_MS) {
            recycle(ownedBitmap);
            return false;
        }
        Bitmap image = ownedBitmap;
        try {
            int longest = Math.max(image.getWidth(), image.getHeight());
            if (longest <= 0) { recycle(image); return false; }
            if (longest > MAX_IMAGE_EDGE) {
                double scale = (double) MAX_IMAGE_EDGE / longest;
                Bitmap scaled = Bitmap.createScaledBitmap(image,
                        Math.max(1, (int) Math.round(image.getWidth() * scale)),
                        Math.max(1, (int) Math.round(image.getHeight() * scale)), true);
                if (scaled != image) recycle(image);
                image = scaled;
            }
            long now = SystemClock.elapsedRealtime();
            FrameRequest request = new FrameRequest(sceneGeneration, frameTimeMs, now, image);
            lastSourceMs = frameTimeMs;
            nextAllowedElapsedMs = Math.max(nextAllowedElapsedMs, now + MIN_REQUEST_INTERVAL_MS);
            inFlight = request;
            publish(State.ANALYZING, "Describing the current scene");
            request.future = client.runInference(ImageDescriptionRequest.builder(image).build());
            request.timeout = () -> {
                if (inFlight != request) return;
                cancelFrame();
                deferFailure(null, "Scene analysis took too long", false);
            };
            main.postDelayed(request.timeout, INFERENCE_TIMEOUT_MS);
            observe(request.future, result -> completeFrame(request, result),
                    failure -> failFrame(request, failure));
            return true;
        } catch (RuntimeException failure) {
            // If setup failed after the future was returned, cancellation still owns
            // the image's lifetime. Never recycle a bitmap while that SDK may read it.
            if (inFlight != null && inFlight.future != null) cancelFrame();
            else { inFlight = null; recycle(image); }
            deferFailure(failure, "Scene description is temporarily unavailable", false);
            return false;
        }
    }

    private void beginPreparation() {
        if (!active || closed || preparation != null) return;
        if (SystemClock.elapsedRealtime() < nextAllowedElapsedMs) { scheduleRetry(); return; }
        ready = false;
        publish(State.CHECKING, "Checking on-device scene descriptions");
        try {
            if (client == null) client = ImageDescription.getClient(
                    ImageDescriberOptions.builder(context).build());
            ListenableFuture<Integer> future = client.checkFeatureStatus();
            trackPreparation(future, 30_000L, status -> {
                if (status == FeatureStatus.UNAVAILABLE) {
                    nextAllowedElapsedMs = Math.max(nextAllowedElapsedMs,
                            SystemClock.elapsedRealtime() + FEATURE_RECHECK_MS);
                    publish(State.UNAVAILABLE, "Scene descriptions are not available on this device yet");
                    scheduleRetry();
                } else if (status == FeatureStatus.AVAILABLE
                        || status == FeatureStatus.DOWNLOADABLE
                        || status == FeatureStatus.DOWNLOADING) {
                    publish(status == FeatureStatus.AVAILABLE ? State.CHECKING : State.DOWNLOADING,
                            status == FeatureStatus.AVAILABLE ? "Preparing scene descriptions"
                                    : "Preparing the on-device scene model");
                    // The documented API automatically downloads missing models, then warms
                    // the inference engine. It requires no app-entered URL, key, or token.
                    trackPreparation(client.prepareInferenceEngine(), MODEL_PREPARATION_TIMEOUT_MS,
                            ignored -> { ready = true; consecutiveFailures = 0; publishReadiness(); });
                } else {
                    deferFailure(null, "Scene model status is unavailable", true);
                }
            });
        } catch (RuntimeException failure) {
            deferFailure(failure, "On-device scene preparation is unavailable", true);
        }
    }

    private <T> void trackPreparation(ListenableFuture<T> future, long timeoutMs,
                                       Consumer<T> onSuccess) {
        long generation = lifecycleGeneration;
        preparation = future;
        preparationTimeout = () -> {
            if (preparation != future || generation != lifecycleGeneration) return;
            cancelPreparation();
            deferFailure(null, "Waiting for the on-device model", true);
        };
        main.postDelayed(preparationTimeout, timeoutMs);
        observe(future, value -> {
            if (!active || closed || generation != lifecycleGeneration || preparation != future) return;
            clearPreparation();
            try { onSuccess.accept(value); }
            catch (RuntimeException failure) {
                deferFailure(failure, "Scene model preparation could not finish", true);
            }
        }, failure -> {
            if (!active || closed || generation != lifecycleGeneration || preparation != future) return;
            clearPreparation();
            deferFailure(failure, "Waiting for on-device scene descriptions", true);
        });
    }

    private void completeFrame(FrameRequest request, ImageDescriptionResult result) {
        if (inFlight != request) { release(request, false); return; }
        inFlight = null;
        if (request.timeout != null) main.removeCallbacks(request.timeout);
        release(request, true);
        if (!active || closed || request.sceneGeneration != sceneGeneration) return;
        long age = SystemClock.elapsedRealtime() - request.capturedElapsedMs;
        if (age < 0 || age > MAX_RESULT_AGE_MS) {
            publish(State.READY, "Refreshing an older scene sample");
            return;
        }
        String text = result == null ? "" : result.getDescription();
        if (Duwm1728SceneTimeline.clean(text, Duwm1728SceneTimeline.MAX_DESCRIPTION_CODE_POINTS).isEmpty()) {
            deferFailure(null, "No description was returned for this frame", false);
            return;
        }
        consecutiveFailures = 0;
        listener.onScene(Duwm1728SceneTimeline.fromDescription(request.sourceMs, text));
        publishReadiness();
    }

    private void failFrame(FrameRequest request, Throwable failure) {
        if (inFlight != request) { release(request, false); return; }
        inFlight = null;
        if (request.timeout != null) main.removeCallbacks(request.timeout);
        release(request, !(failure instanceof CancellationException));
        if (!active || closed || request.sceneGeneration != sceneGeneration) return;
        deferFailure(failure, "No scene description is available for this frame", false);
    }

    private void deferFailure(Throwable failure, String fallback, boolean preparing) {
        if (!active || closed) return;
        int errorCode = Integer.MIN_VALUE;
        Throwable cause = failure;
        for (int depth = 0; cause != null && depth < 8; depth++, cause = cause.getCause()) {
            if (cause instanceof GenAiException) { errorCode = ((GenAiException) cause).getErrorCode(); break; }
        }
        if (failure != null) Log.w(TAG, "On-device scene request failed (code " + errorCode + ")", failure);
        long backoff = Math.min(120_000L, 5_000L << consecutiveFailures);
        consecutiveFailures = Math.min(consecutiveFailures + 1, 5);
        State next = State.WAITING;
        String detail = fallback;
        if (preparing) ready = false;
        if (errorCode == GenAiException.ErrorCode.BUSY) {
            backoff = Math.max(10_000L, backoff);
            detail = "Scene analysis is busy; it will retry automatically";
        } else if (errorCode == SDK_BATTERY_QUOTA_ERROR) {
            backoff = BATTERY_QUOTA_BACKOFF_MS;
            context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit()
                    .putLong(QUOTA_UNTIL_UTC, System.currentTimeMillis() + backoff).apply();
            detail = "Scene analysis has reached its device limit; it will retry later";
        } else if (errorCode == SDK_BACKGROUND_BLOCKED_ERROR) {
            ready = false;
            backoff = 30_000L;
            detail = "Scene analysis needs the camera screen in front";
        } else {
            // Recheck model readiness after an unclassified SDK error. Only the
            // public feature-status API determines whether support is unavailable.
            ready = false;
        }
        nextAllowedElapsedMs = Math.max(nextAllowedElapsedMs, SystemClock.elapsedRealtime() + backoff);
        publish(next, detail);
        scheduleRetry();
    }

    private void publishReadiness() {
        if (!active || closed || !ready) return;
        if (SystemClock.elapsedRealtime() >= nextAllowedElapsedMs) {
            publish(State.READY, "Scene descriptions ready");
        } else {
            publish(State.WAITING, "Waiting for the next scene sample");
            scheduleRetry();
        }
    }

    private void scheduleRetry() {
        cancelRetry();
        if (!active || closed) return;
        long generation = lifecycleGeneration;
        retryTask = () -> {
            retryTask = null;
            if (!active || closed || generation != lifecycleGeneration) return;
            if (ready) publishReadiness(); else beginPreparation();
        };
        main.postDelayed(retryTask, Math.max(1L, nextAllowedElapsedMs - SystemClock.elapsedRealtime()));
    }

    private void publish(State next, String detail) {
        if (state == next && statusText.equals(detail)) return;
        state = next;
        statusText = detail;
        listener.onStatus(next, detail);
    }

    private void cancelRetry() {
        if (retryTask != null) main.removeCallbacks(retryTask);
        retryTask = null;
    }

    private void clearPreparation() {
        if (preparationTimeout != null) main.removeCallbacks(preparationTimeout);
        preparationTimeout = null;
        preparation = null;
    }

    private void cancelPreparation() {
        ListenableFuture<?> future = preparation;
        clearPreparation();
        if (future != null) future.cancel(true);
    }

    private void cancelFrame() {
        FrameRequest request = inFlight;
        inFlight = null;
        if (request == null) return;
        if (request.timeout != null) main.removeCallbacks(request.timeout);
        if (request.future != null) request.future.cancel(true);
        // Cancellation is best-effort. Do not recycle an image the SDK may still read;
        // relinquish our reference and let its last owner/GC release it safely.
        release(request, false);
    }

    private static void release(FrameRequest request, boolean recycleNow) {
        Bitmap bitmap = request.bitmap;
        request.bitmap = null;
        if (recycleNow) recycle(bitmap);
    }

    private static void recycle(Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
    }

    private <T> void observe(ListenableFuture<T> future, Consumer<T> success,
                             Consumer<Throwable> failure) {
        future.addListener(() -> {
            T value;
            try { value = future.get(); } // The listener runs only after completion; never waits.
            catch (ExecutionException error) { failure.accept(error.getCause()); return; }
            catch (CancellationException error) { failure.accept(error); return; }
            catch (InterruptedException error) {
                Thread.currentThread().interrupt(); failure.accept(error); return;
            }
            success.accept(value);
        }, completionExecutor);
    }

    @Override public void close() {
        requireMainThread();
        if (closed) return;
        pause();
        closed = true;
        if (client != null) {
            try { client.close(); }
            catch (RuntimeException failure) { Log.w(TAG, "Scene engine could not close cleanly", failure); }
            finally { client = null; }
        }
        publish(State.CLOSED, "Scene descriptions closed");
    }

    private static void requireMainThread() {
        if (Looper.myLooper() != Looper.getMainLooper())
            throw new IllegalStateException("Scene analyzer calls must use the main thread");
    }
}
