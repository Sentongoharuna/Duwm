package com.sentongoharuna.worldsituationroom;

/** Short deterministic source-time transitions for broadcast text. Geometry never changes. */
public final class Duwm1728ProfessionalTransition {
    public static final long HEADLINE_MS=260L, STATUS_MS=180L;
    private Duwm1728ProfessionalTransition(){}
    public static final class State {
        public final float alpha,offset;
        State(float a,float o){alpha=a;offset=o;}
    }
    public static State state(long nowMs,long changedAtMs,long durationMs){
        if(changedAtMs<0 || nowMs<changedAtMs || durationMs<=0)return new State(1f,0f);
        float p=Math.min(1f,(nowMs-changedAtMs)/(float)durationMs);
        float eased=1f-(float)Math.pow(1f-p,3d);
        return new State(.28f+.72f*eased,1f-eased);
    }
    public static boolean active(long nowMs,long changedAtMs,long durationMs){
        return changedAtMs>=0 && nowMs>=changedAtMs && nowMs-changedAtMs<durationMs;
    }
    public static int alpha(int color,float opacity){
        int base=(color>>>24)&0xff;
        int a=Math.max(0,Math.min(255,Math.round(base*Math.max(0f,Math.min(1f,opacity)))));
        return (color&0x00ffffff)|(a<<24);
    }
}
