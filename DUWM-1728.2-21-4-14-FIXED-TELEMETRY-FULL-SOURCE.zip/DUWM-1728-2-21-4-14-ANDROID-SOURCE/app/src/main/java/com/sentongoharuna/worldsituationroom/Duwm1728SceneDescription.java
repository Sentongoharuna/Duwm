package com.sentongoharuna.worldsituationroom;

import java.util.Locale;

/** Creates a short visible subtitle from the current on-device AI scene description.
 * It only edits supplied model text and never adds facts, places, people or urgency. */
public final class Duwm1728SceneDescription {
    public static final int MAX_WORDS = 16;
    public static final int MAX_CODE_POINTS = 112;
    private Duwm1728SceneDescription(){}

    public static String fromDescription(String modelDescription){
        String text=Duwm1728SceneTimeline.clean(modelDescription, Duwm1728SceneTimeline.MAX_DESCRIPTION_CODE_POINTS);
        if(text.isEmpty())return "";
        String lower=text.toLowerCase(Locale.ROOT);
        String[] prefixes={"this image shows ","the image shows ","this photo shows ","the photo shows ","the scene shows ","an image of ","a photo of "};
        for(String prefix:prefixes)if(lower.startsWith(prefix)){text=text.substring(prefix.length()).trim();break;}
        // Keep only the first observed sentence and bound it without adding an inference.
        for(int i=0;i<text.length();i++){char c=text.charAt(i);if((c=='.'||c=='!'||c=='?')&&(i+1==text.length()||Character.isWhitespace(text.charAt(i+1)))){text=text.substring(0,i).trim();break;}}
        String[] words=text.split("\\s+");StringBuilder out=new StringBuilder();int used=0;
        for(String word:words){if(word.isEmpty())continue;if(used>=MAX_WORDS)break;if(out.length()>0)out.append(' ');out.append(word);used++;}
        String result=Duwm1728SceneTimeline.clean(out.toString(),MAX_CODE_POINTS);
        if(result.isEmpty())return "";
        // Preserve sentence case rather than turning the subtitle into a second headline.
        int first=result.codePointAt(0);int upper=Character.toUpperCase(first);
        StringBuilder normalized=new StringBuilder();normalized.appendCodePoint(upper);normalized.append(result.substring(Character.charCount(first)));
        return normalized.toString();
    }
}
