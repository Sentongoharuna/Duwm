package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import java.io.IOException;

/** Final hands-free gate for automatic productions. A video is only called ready
 * after a readable durable content URI exists. No network service or user approval is involved. */
public final class Duwm1728AutomaticFinish {
    private Duwm1728AutomaticFinish() {}

    public static String savedState(boolean hasCaptions) {
        return hasCaptions ? "SAVED_VERIFIED_WITH_CAPTIONS" : "SAVED_VERIFIED_WITHOUT_CAPTIONS";
    }

    public static String recoveryState(boolean localCopy, boolean galleryUriReturned) {
        if (galleryUriReturned) return "GALLERY_UNCONFIRMED_LOCAL_COPY";
        if (localCopy) return "LOCAL_COPY_READY";
        return "FAILED";
    }

    /** Confirms the actual completed content can be reopened. A zero-length descriptor
     * or a non-content URI is never reported as a finished automatic video. */
    public static long verifyReadable(Context context, Uri uri) throws IOException {
        if (context == null) throw new IOException("Application context is unavailable");
        if (uri == null || !"content".equals(uri.getScheme())) throw new IOException("Finished video URI is invalid");
        try (AssetFileDescriptor descriptor=context.getContentResolver().openAssetFileDescriptor(uri,"r")) {
            if (descriptor == null) throw new IOException("Finished video could not be reopened");
            long length=descriptor.getLength();
            if (length == 0) throw new IOException("Finished video is empty");
            // Some providers return UNKNOWN_LENGTH (-1) for valid streams. Reopening the
            // descriptor is the durable-readability gate; positive lengths are retained.
            return length;
        } catch (SecurityException denied) {
            throw new IOException("Finished video permission was not retained",denied);
        }
    }
}
