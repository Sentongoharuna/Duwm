from pathlib import Path
import json,hashlib
from xml.etree import ElementTree as ET
P=Path(__file__).resolve().parents[1]
JAVA=P/'app/src/main/java/com/sentongoharuna/worldsituationroom'
assets=P/'app/src/main/assets/duwm_global_200_sources.json'
obj=json.loads(assets.read_text())
records=obj['sources']
assert len(records)==200 and len(set(x['id'] for x in records))==200
for cat in ('Cameras','TV','News','Vessels'):
    items=[x for x in records if x['category']==cat]
    assert len(items)==50,(cat,len(items))
    assert all(x['url'].startswith('https://') and x['status']=='CANDIDATE - NOT YET LIVE-INTEGRATED' for x in items)
activity=(JAVA/'Duwm1669SourceDirectoryActivity.java').read_text()
main=(JAVA/'OperationsMainActivity.java').read_text()
assert '200 WORLD SOURCES' in main and 'Duwm1669SourceDirectoryActivity.class' in main
for token in ('duwm_global_200_sources.json','NOT 200 LIVE DATA CONNECTIONS','NOT YET CONNECTED','OPEN SOURCE WEBSITE','Search source, region or capability'):
    assert token in activity,token
M=ET.parse(P/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
assert any(x.get(ns+'name')=='.Duwm1669SourceDirectoryActivity' for x in M.iter('activity'))
assert 'versionCode = 166900' in (P/'app/build.gradle.kts').read_text()
for name,digest in json.loads((P/'DUWM_REAL_SOURCE_CHANGE_REPORT.json').read_text())['unmodified_source_components'].items():
 assert hashlib.sha256((JAVA/name).read_bytes()).hexdigest()==digest,name
print('PASS 200 actual directory entries (50 per category), visible native Android navigation, original protected globe preserved')
