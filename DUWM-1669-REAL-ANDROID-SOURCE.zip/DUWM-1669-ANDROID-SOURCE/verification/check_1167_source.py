"""Fail build when 1167 native additions or protected original globe are absent."""
from pathlib import Path
from xml.etree import ElementTree as ET
import re
import hashlib
import json
ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT/'app/src/main/java/com/sentongoharuna/worldsituationroom'
MANIFEST=ROOT/'app/src/main/AndroidManifest.xml'
GRADLE=(ROOT/'app/build.gradle.kts').read_text()
assert 'versionCode = 166900' in GRADLE and 'versionName = "1669"' in GRADLE
assert 'applicationId = "com.sentongoharuna.worldsituationroom.rb2live25"' in GRADLE
required={
 'Duwm1166DirectoryActivity.java': ['AIRCRAFT','VESSELS','NEWS','RADIO ATLAS','PUBLIC CAMERAS','WORLD MAP'],
 'Duwm1166NewsDeskActivity.java': ['LOCAL','WORLDWIDE','WARS','ECONOMICS','MIDDLE EAST','AFRICA','INDIA','Duwm1166PortraitCard.share'],
 'Duwm1166PortraitCard.java': ['W=1080,H=1920','Share DUWM portrait news card','SOURCE-ATTRIBUTED REPORT'],
 'Duwm1166SignalView.java': ['FRESH=1','STALE=2','ERROR=3','FETCHING=4','postInvalidateDelayed'],
 'Duwm1166RadioAtlasActivity.java': ['de1.api.radio-browser.info','geo_lat','geo_long','prepareAsync','naturalearth_coasts.txt'],
 'Duwm1166RecordsActivity.java': ['Duwm1166RecordChart','DuwmGeoObservationStore.read','Duwm1166SignalView'],
 'Duwm1166RecordChart.java': ['NO SAVED SOURCE POSITIONS','Math.max(0,values[i])'],
 'Duwm1166TrackView.java': ['NO TWO VERIFIED MOVEMENT FIXES','hasActualTrack()'],
 'Duwm1166ArticleActivity.java': ['WebView','WebChromeClient','shouldOverrideUrlLoading'],
 'Duwm1166CustomFeedActivity.java': ['RssParser.parse','NewsReaders.jsonFeed','https'],
 'DuwmWorldIntelligenceActivity.java': ['Duwm1166SignalView','loadVessels()','https://meri.digitraffic.fi/api/ais/v1/locations'],
 'NewsSourceCatalog.java': ['gnewsindia','gnewsaf','gnewsme','gnewswar','gnewssea'],
 'OperationsMainActivity.java': ['Duwm1166DirectoryActivity','Duwm1166NewsDeskActivity','duwm1166AirLed'],
 'DuwmGeoObservationStore.java': ['type.equals("VESSEL")'],
 'DuwmPlaceMapActivity.java': ['FLAG_FULLSCREEN','duwmRenderStatus','duwm_place_map.html'],
}
for name,terms in required.items():
 p=JAVA/name; assert p.is_file(),f'missing native source {name}'
 s=p.read_text()
 for needle in terms:assert needle in s,(name,needle)
protected=['OperationsGlobeView.java','SatelliteMapView.java','DuwmLiveWallpaperService.java','DuWidgetProviders.java','DuWidgetUpdater.java','WidgetSnapshot.java','V115941ShareCards.java','MediaDeskActivity.java']
for name in protected:assert (JAVA/name).is_file(),f'protected original file absent: {name}'
assert (ROOT/'app/src/main/assets/duwm_place_map.html').is_file()
assert (ROOT/'app/src/main/assets/naturalearth_coasts.txt').is_file()
ET.register_namespace('android','http://schemas.android.com/apk/res/android')
manifest=ET.parse(MANIFEST).getroot()
a='{http://schemas.android.com/apk/res/android}'
activities=[e.get(a+'name','') for e in manifest.iter('activity')]
for name in required:
 if name.endswith('Activity.java'):
  assert any(n.endswith(name[:-5]) for n in activities),f'{name} not registered'
assert '1669' in (ROOT/'app/src/main/res/values/strings.xml').read_text()
print('PASS DUWM 1167 actual source, ten new Java components, registry, original detailed globe, geo map, 9:16 cards, region feeds and Finnish AIS')

# Regression fixes are requirements, not build bypasses.
assert (JAVA/'Duwm1167SafeArea.java').is_file(), 'Missing modern Android system-bar-safe layout helper'
helper=(JAVA/'Duwm1167SafeArea.java').read_text()
assert 'setDecorFitsSystemWindows(false)' in helper and 'getInsets(WindowInsets.Type.systemBars())' in helper
for name in ['DuwmWorldIntelligenceActivity','Duwm1166NewsDeskActivity','Duwm1166RecordsActivity',
             'Duwm1166RadioAtlasActivity','Duwm1166DirectoryActivity','MediaDeskActivity','Duwm1166ArticleActivity','Duwm1166CustomFeedActivity','RunningballV107EpicActivity']:
 assert 'Duwm1167SafeArea.install(' in (JAVA/(name+'.java')).read_text(),name+' not safe-area protected'
board=(JAVA/'DuwmWorldIntelligenceActivity.java').read_text()
assert 'refresh.setOnClickListener(v->refresh(true))' in board, 'Forced refresh button still throttled'
assert 'if(!force&&was!=null&&now-was<period)continue;' in board, 'Forced refresh not honored'
assert 'PENDING ' in board and 'UNAVAILABLE ' in board, 'Unknown source state falsely listed as unavailable'
records=(JAVA/'Duwm1166RecordsActivity.java').read_text()
assert 'SAVED POSITION SAMPLES' in records and 'NOT FULL PROVIDER COUNT' in records
radio=(JAVA/'Duwm1166RadioAtlasActivity.java').read_text()
assert '■ STOP AUDIO' in radio and 'MAPPED WITH SOURCE COORDINATES' in radio
card=(JAVA/'Duwm1166PortraitCard.java').read_text()
assert 'duwm1167-' in card and 'SOURCE PHOTO NOT PROVIDED' in card
# Preserve the core interactive globe and wallpaper untouched relative to the recorded 1166 baseline.
report=json.loads((ROOT/'DUWM_REAL_SOURCE_CHANGE_REPORT.json').read_text())
for name in ['DuwmLiveWallpaperService.java','DuWidgetProviders.java','DuWidgetUpdater.java','WidgetSnapshot.java','V115941ShareCards.java','AircraftOperationsActivity.java']:
 assert hashlib.sha256((JAVA/name).read_bytes()).hexdigest()==report['unmodified_source_components'][name],name+' changed unexpectedly'
assert 'earth=new OperationsGlobeView(this)' in (JAVA/'OperationsMainActivity.java').read_text()
print('PASS 1167 actual edits, manual refresh, cached-position labeling, UI safe areas, radio controls and protected globe components')
