Final cumulative F9-F20 functional gate. F9 remains source/detail/chronology owner; no F20 Activity or second NewsStore.
