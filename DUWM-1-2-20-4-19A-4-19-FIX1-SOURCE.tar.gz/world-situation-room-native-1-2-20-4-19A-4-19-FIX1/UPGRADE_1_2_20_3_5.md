# 1.2/20/3 — 5/20 Aircraft Trail
The existing observed provider-fix trail is now keyed by canonical aircraft identity, so refresh replacement
does not split a trail. Only actual provider positions with a newer timestamp or changed coordinates are appended.
History remains bounded by MAX_FIXES_PER_TRACK and expires under the existing two-hour retention rule.
The Aircraft Intelligence Sheet reports the number of observed fixes and explicitly says no interpolated history.
