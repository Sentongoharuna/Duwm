# 1.2/20/4 — 2/20 Object Movement Intelligence
Built directly on 1.2/20/4-1.
For an exact canonical object, the Intelligence Sheet compares the two newest valid provider observations with
different provider timestamps and calculates observed displacement, initial bearing/cardinal direction,
between-fix speed, interval and FROM/TO provider times.
If two valid observed fixes do not exist, it reports INSUFFICIENT OBSERVED FIXES.
This is retrospective movement intelligence only: no extrapolation, predicted path or invented position.
