# 1.2/20/4 — 6/20 Proximity Intelligence
Built on 4-5. For a selected located canonical object, DUWM scans the current provider-returned located records
across all active layers and returns up to eight nearest unique objects within 150 km, ordered by distance.
Each row shows layer, distance, compass direction/bearing, title and provider. The selected object is excluded.
This is geometric context only: proximity does not create a relationship, incident, confirmation or risk claim.
No new page and no synthetic coordinates.
