# 1.2/20/4 — 7/20 Live Change Timeline
Built on 4-6. This adds a timeline of meaningful detected changes for each canonical object using only
LiveChangeRegistry events from Build 4-1. It is deliberately separate from the raw provider observation timeline
built in /3-12. The sheet summarizes change counts by kind and displays up to eight newest change events from a
bounded 12-entry view. It does not invent intermediate states or predict future movement.
