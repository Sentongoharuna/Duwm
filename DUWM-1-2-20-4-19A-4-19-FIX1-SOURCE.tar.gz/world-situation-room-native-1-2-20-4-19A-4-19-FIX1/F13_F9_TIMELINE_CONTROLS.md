# F13/20 — Replay Timeline Controls
Adds PREVIOUS, NEXT and LIVE navigation to F12 time windows.
The anchor changes only the time interval applied to F9's canonical NewsStore chronology.
F11 country lens remains in the same chain. No new Activity, NewsStore or copied records.
