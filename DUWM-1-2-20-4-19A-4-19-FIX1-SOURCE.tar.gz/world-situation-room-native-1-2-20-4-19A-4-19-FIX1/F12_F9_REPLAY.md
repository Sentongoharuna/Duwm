# F12/20 — Replay Chronological Lens
F12 is not a second history database. It filters the same F9 NewsStore records after F11 country selection.
Windows: NOW, 1H, 6H, 12H, 24H, 3D, 7D.
F9 owns sorting/chronology once; F12 preserves original record ID, cluster, source and detail path.
