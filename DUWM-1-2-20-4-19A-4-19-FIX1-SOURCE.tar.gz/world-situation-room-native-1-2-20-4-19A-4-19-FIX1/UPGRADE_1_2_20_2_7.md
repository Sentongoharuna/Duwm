1.2/20/2-7 preserves the existing Signal facts as an immutable type-specific payload attached to each canonical object. No UI/navigation/provider/F9 changes.
