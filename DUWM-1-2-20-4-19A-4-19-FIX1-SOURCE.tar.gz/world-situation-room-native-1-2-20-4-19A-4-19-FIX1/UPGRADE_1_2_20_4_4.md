# 1.2/20/4 — 4/20 Incident Formation
Builds an evidence-preserving incident-candidate workspace from the existing relationship IDs.
Related canonical records remain independent Signal records with their own provider identity, timestamps,
credibility and source. A candidate reports ID, SINGLE_SOURCE/MULTI_SOURCE_RELATED state, record/provider/layer
counts and observed geographic spread. The selected object's Intelligence Sheet lists up to six constituent
records. The app explicitly states INCIDENT CANDIDATE ≠ CONFIRMED INCIDENT.
No new page, no record merge, no automatic claim that proximity or reporting confirms an incident.
