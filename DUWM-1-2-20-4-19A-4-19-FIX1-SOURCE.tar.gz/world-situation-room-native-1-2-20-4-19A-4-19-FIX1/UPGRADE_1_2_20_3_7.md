# 1.2/20/3 — 7/20 Satellite / Orbit Intelligence
SATELLITES objects now expose CelesTrak/NORAD identity, object type/group, element epoch/age,
calculation time, altitude/speed estimates, period, inclination, model, coordinate origin and provider.
The sheet prominently states CALCULATED FROM PUBLIC ELEMENTS — NOT LIVE TELEMETRY.
Existing CALCULATED credibility and source link remain intact. No Globe redesign.
