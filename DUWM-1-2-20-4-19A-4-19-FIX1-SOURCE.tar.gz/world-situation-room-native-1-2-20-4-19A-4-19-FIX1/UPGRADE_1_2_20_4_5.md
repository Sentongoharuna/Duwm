# 1.2/20/4 — 5/20 Uganda / East Africa Priority Engine
Adds a separate geographic relevance layer without altering source severity, credibility, freshness or identity.
Located objects are classified from their observed coordinates as UGANDA, EAST_AFRICA or GLOBAL. Records without
usable coordinates may receive regional relevance only when their provider-returned text names a controlled place
already used by DUWM's geographic resolver. The Intelligence Sheet shows band, relevance score, basis and original
source severity. Relevance is explicitly not severity, confirmation, danger or incident status.
