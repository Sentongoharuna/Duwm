# F11 / 20 — Regional Country Lenses
F9 remains the sole source, cluster and chronological owner.
F11 filters the same NewsStore records for Uganda, Kenya, Tanzania, Rwanda, Burundi, DR Congo and South Sudan.
No new Activity, screen, record copy or secondary chronology is introduced.
Detail continues through the existing F9 showLocalNewsDetail(NewsItem) path.
