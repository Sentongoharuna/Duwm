# 1.2/20/3 — 4/20 Aircraft Live Track
FOLLOW now stays bound to the aircraft canonical ID. Provider refreshes update the same followed object,
the map center follows its newest provider position, and an open Aircraft Intelligence Sheet updates
telemetry in place without reopening. Temporary provider loss retains the last observed position with
its original timestamp/freshness; no fake position or teleport is created. STOP FOLLOWING remains the exit.
