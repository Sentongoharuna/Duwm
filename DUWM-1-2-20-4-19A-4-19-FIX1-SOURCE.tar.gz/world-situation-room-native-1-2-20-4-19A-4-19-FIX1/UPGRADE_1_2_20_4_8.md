# 1.2/20/4 — 8/20 Cross-Source Evidence Panel
Built on 4-7. The selected canonical object now has an evidence panel that begins with the exact primary record
and adds up to seven independently identified related records from the existing RelationshipRegistry.
Each row keeps role, layer, provider, freshness and title visible. Same-provider related records are explicitly
distinguished from different-provider records. The panel reports independent-record, distinct-provider and
distinct-layer counts, but deliberately produces no truth/confidence score and does not label related evidence
as corroboration or confirmation. No records are merged and no new page is added.
