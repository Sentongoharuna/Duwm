# 1.2/20/2 — 6/20 Coordinates Provenance
Every canonical object now records where its Globe coordinates came from:
PROVIDER, CALCULATED_ORBIT, RESOLVED_PLACE, MONITOR_SUPPLIED, or UNAVAILABLE.

CelesTrak/orbit positions are explicitly CALCULATED_ORBIT, preserving the app's existing
honest disclosure that these positions are calculated rather than live telemetry.
Objects without valid coordinates are UNAVAILABLE; no location is invented.
OriginalRecordRef carries the coordinate-origin audit value.
No UI, navigation, provider endpoint, F9 catalog or Globe styling changes.
