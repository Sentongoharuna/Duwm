# 1.2/20/3 — 6/20 Earthquake / Event Intelligence
NATURAL objects now expose an event intelligence block in the existing Object Intelligence Sheet.
USGS earthquake records surface magnitude, depth, felt reports, alert, event time, freshness, provider and source record.
NASA EONET records surface category, status, event ID, event time, freshness, provider and source record.
Existing SOURCE, WATCH and SHARE actions remain available; no new page or Globe redesign.
