# 1.2/20/2 — 2/20 Provider Identity Attached
Additive upgrade on Canonical Object ID.

Every Signal now carries:
- providerId: stable normalized machine identity
- providerName: human-readable source attribution
- canonicalId: derived from providerId + layer + provider-native record id

Known live providers receive stable IDs (OpenSky, USGS, CelesTrak, RainViewer, NASA,
CoinGecko, OurAirports). Other F9/news providers receive deterministic slug IDs.
No UI, source endpoint, navigation, F9 catalog, or Globe styling is changed.
