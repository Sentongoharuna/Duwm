# 1.2/20/2 — 4/20 Timestamp Chain
Each canonical object now tracks four distinct times:
1. providerTimeMs — source-supplied record time
2. firstSeenMs — first time this canonical object entered this app process
3. fetchedAtMs — when this record instance was fetched/constructed
4. renderedAtMs — when the Globe accepted the changed render snapshot

Provider time is never replaced by fetch or render time. Missing provider time falls back only
for age calculation, not by mutating the original source timestamp.
No UI/navigation/provider/F9 catalog changes.
