FIX2: CoordinateProvenance used nonexistent Signal.Layer.ORBIT. The app's real enum is Signal.Layer.SATELLITES. Code and regression gate now use SATELLITES. No UI/provider/data behavior changes.
