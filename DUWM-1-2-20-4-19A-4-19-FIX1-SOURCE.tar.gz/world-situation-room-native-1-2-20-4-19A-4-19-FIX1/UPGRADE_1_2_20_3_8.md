# 1.2/20/3 — 8/20 Weather Object Intelligence
The existing WEATHER operations page now exposes intelligence for the currently selected RainViewer radar frame:
frame index/count, generation time, age, provider state and animation state.
It explicitly distinguishes historical radar observation/history from a forecast or ground-impact report.
Existing frame selector, play/pause, map overlay and share behavior are preserved. No new page.
