# 1.2/20/3 — 3/20 Aircraft Intelligence
Aircraft taps now expose a dedicated provider-backed intelligence block inside the existing Object Intelligence Sheet:
callsign, ICAO24, origin country, altitude, speed, heading, vertical rate, state, aircraft category,
squawk, position source, last-contact relation, current position age and provider.
No airline, destination or flight number is inferred when OpenSky does not return it.
No Globe/UI redesign.
