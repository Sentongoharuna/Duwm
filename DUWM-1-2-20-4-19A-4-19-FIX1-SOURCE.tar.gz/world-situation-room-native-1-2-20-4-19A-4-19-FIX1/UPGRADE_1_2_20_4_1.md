# 1.2/20/4 — 1/20 Live Change Detection
Built on the verified 1.2/20/3/20 FIX2 frozen base.
A bounded in-memory registry compares each layer's current provider-returned canonical records with the previous refresh.
It detects APPEARED, MOVED, HEADING_CHANGED, SPEED_CHANGED, SEVERITY_CHANGED, STATE_CHANGED, UPDATED and DISAPPEARED.
First load establishes baseline and does not falsely label every object APPEARED.
Movement requires >=250 m observed displacement; heading >=12 degrees; speed >=5 m/s.
The Object Intelligence Sheet shows up to six newest changes and explicitly states CHANGE ≠ INCIDENT.
No new page, no invented trajectory, no inference from UI redraws.
