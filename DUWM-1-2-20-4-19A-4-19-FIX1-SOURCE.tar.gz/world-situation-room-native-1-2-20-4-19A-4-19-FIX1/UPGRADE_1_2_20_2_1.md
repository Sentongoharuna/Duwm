# 1.2/20/2 — 1/20 Canonical Object ID
Built additively on the frozen 1.2/20/1 FIX2 phone-confirmed base.

Canonical identity = provider + layer + provider-native record id.
It deliberately excludes coordinates, title, timestamp and refresh order, so moving aircraft,
calculated orbital positions and updated events remain the same logical Globe object.
No UI, navigation, provider endpoint or F9 source catalog is changed in this step.
