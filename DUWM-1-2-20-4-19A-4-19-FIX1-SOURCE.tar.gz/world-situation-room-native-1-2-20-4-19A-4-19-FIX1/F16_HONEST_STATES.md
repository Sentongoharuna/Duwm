F16 makes F9 states explicit: live, stale, offline/saved, no records, unknown source/location/time. It does not invent substitute information and introduces no new screen/store.
