# 1.2/20/4 — 9/20 News ↔ Event Linking
Built on 4-8. DUWM now exposes conservative candidate links between F9 NEWS records and NATURAL/WEATHER/AIRSPACE
event records. A candidate is created only when the existing relationship IDs match, or when both records have
real coordinates within 100 km and timestamps within six hours. The panel displays basis, news title, event title,
distance when applicable, and time delta. No text similarity guess, causation claim, corroboration label or
confirmation score is created. Link candidates remain two independent canonical records.
