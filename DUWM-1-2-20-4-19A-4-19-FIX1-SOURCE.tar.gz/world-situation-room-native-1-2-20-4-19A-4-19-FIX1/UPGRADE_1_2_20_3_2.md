# 1.2/20/3 — 2/20 Object Intelligence Sheet
The existing Detail overlay is upgraded in place into the Object Intelligence Sheet.
It now leads with object type, state, freshness, provider, provider-native record ID and canonical ID,
while retaining the native provider facts and existing SOURCE/FOLLOW, WATCH and SHARE actions.
WATCH state is refreshed whenever the sheet opens. No new page and no Globe redesign.
