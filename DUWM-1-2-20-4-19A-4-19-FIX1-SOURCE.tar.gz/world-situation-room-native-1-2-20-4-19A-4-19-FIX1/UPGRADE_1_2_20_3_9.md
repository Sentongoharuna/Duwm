# 1.2/20/3 — 9/20 News -> Globe Intelligence
Exact F9 NewsItem detail now leads with outlet/source ID/news ID, published time, first-seen time,
region, topic, cluster, also-reported-by and honest Globe-location state.
GeoIndex remains the only named-place resolver. Unresolved stories explicitly say NO MARKER INVENTED.
Existing OPEN FULL ARTICLE, SHARE, MARK READ, HIDE OUTLET, FOLLOW TOPIC and SHOW ON GLOBE actions remain.
