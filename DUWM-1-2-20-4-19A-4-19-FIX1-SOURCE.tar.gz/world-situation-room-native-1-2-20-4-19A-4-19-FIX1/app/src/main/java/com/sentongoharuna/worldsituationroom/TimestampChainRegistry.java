package com.sentongoharuna.worldsituationroom;

import java.util.LinkedHashMap;
import java.util.Map;

/** Small in-process provenance registry keyed only by canonical object identity. */
public final class TimestampChainRegistry {
    private static final int MAX = 20000;
    private static final LinkedHashMap<String, Long> FIRST = new LinkedHashMap<String, Long>(256, .75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, Long> eldest) { return size() > MAX; }
    };

    private TimestampChainRegistry() { }

    public static synchronized RecordTimestampChain create(
            String canonicalId, long providerTimeMs, long fetchedAtMs) {
        long now = fetchedAtMs > 0L ? fetchedAtMs : System.currentTimeMillis();
        Long seen = FIRST.get(canonicalId);
        if (seen == null) { seen = now; FIRST.put(canonicalId, seen); }
        return new RecordTimestampChain(providerTimeMs, seen, now, 0L);
    }
}
