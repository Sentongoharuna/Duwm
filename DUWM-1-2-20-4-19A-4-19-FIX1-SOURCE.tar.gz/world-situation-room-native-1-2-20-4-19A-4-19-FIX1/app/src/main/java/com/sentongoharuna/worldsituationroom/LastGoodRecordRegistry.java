package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Retains last valid canonical provider records without changing their source timestamps. */
public final class LastGoodRecordRegistry{
 private final LinkedHashMap<String,Signal> good=new LinkedHashMap<>();
 public synchronized void accept(List<Signal> v){if(v!=null)for(Signal s:v)if(s!=null&&s.canonicalId!=null&&!s.canonicalId.isEmpty())good.put(s.canonicalId,s);}
 public synchronized List<Signal> snapshot(){return new ArrayList<>(good.values());}
 public synchronized Signal get(String id){return id==null?null:good.get(id);}
}
