package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** 1.2/20/4.19A/4.14 watched-change deepening; includes repaired 4.13 last-view dependency. */
public final class WatchChangeDetection{
 public static final class Item{
  public final CanonicalWatchStore.Watch watch;public final Signal current;public final LiveChangeRegistry.Change latest;
  public final int totalChanges,changesSinceWatch;public final boolean newSinceView,persistentlyMissing;public final long lastObservationMs,missingSinceMs;
  Item(CanonicalWatchStore.Watch w,Signal s,LiveChangeRegistry.Change c,int t,int sw,boolean n,boolean pm,long lo,long ms){watch=w;current=s;latest=c;totalChanges=t;changesSinceWatch=sw;newSinceView=n;persistentlyMissing=pm;lastObservationMs=lo;missingSinceMs=ms;}
 }
 public static List<Item> build(CanonicalWatchStore store,Collection<List<Signal>>layers,LiveChangeRegistry reg,int limit){
  LinkedHashMap<String,Signal>cur=new LinkedHashMap<>();if(layers!=null)for(List<Signal>l:layers)if(l!=null)for(Signal s:l)if(s!=null&&s.canonicalId!=null)cur.put(s.canonicalId,s);
  ArrayList<Item>out=new ArrayList<>();for(CanonicalWatchStore.Watch w:store.all()){List<LiveChangeRegistry.Change>cs=reg.changesFor(w.canonicalId);if(cs.isEmpty())continue;
   Signal s=cur.get(w.canonicalId);LiveChangeRegistry.Change latest=cs.get(0);int since=0;for(LiveChangeRegistry.Change c:cs)if(c.detectedAtMs>=w.watchedAtMs)since++;
   LiveChangeRegistry.Lifecycle life=reg.lifecycleFor(w.canonicalId);long lo=s!=null?(s.timestampChain==null?s.timestampMs:s.timestampChain.providerTimeMs):(life==null?0:life.lastSeenMs);
   long viewed=store.lastViewed(w.canonicalId);out.add(new Item(w,s,latest,cs.size(),since,latest.detectedAtMs>Math.max(w.watchedAtMs,viewed),life!=null&&life.persistentlyMissing(),lo,life==null?0:life.missingSinceMs));
  }
  out.sort((x,y)->{if(x.newSinceView!=y.newSinceView)return x.newSinceView?-1:1;return Long.compare(y.latest.detectedAtMs,x.latest.detectedAtMs);});
  if(out.size()>limit)out=new ArrayList<>(out.subList(0,limit));return Collections.unmodifiableList(out);
 }
 public static String state(Item i){if(i.current==null)return i.persistentlyMissing?"PERSISTENTLY MISSING":"CURRENT RECORD MISSING";return i.current.freshness==null?"UNKNOWN":i.current.freshness.state.name();}
}