package com.sentongoharuna.worldsituationroom;

import java.util.List;

/** Resolves an immutable OriginalRecordRef against the current provider record collection. */
public final class OriginalRecordResolver {
    private OriginalRecordResolver() { }

    public static Signal resolve(OriginalRecordRef ref, List<Signal> current) {
        if (ref == null || current == null) return null;
        for (Signal signal : current) {
            if (signal != null && ref.matches(signal)) return signal;
        }
        return null;
    }
}
