package com.sentongoharuna.worldsituationroom;

import java.util.Locale;

/**
 * 1.2/20/2-6 geographic provenance.
 * Coordinates are labelled by origin; this class never invents a location.
 */
public final class CoordinateProvenance {
    public enum Origin {
        PROVIDER,
        CALCULATED_ORBIT,
        RESOLVED_PLACE,
        MONITOR_SUPPLIED,
        UNAVAILABLE
    }

    public final Origin origin;
    public final String authority;
    public final boolean hasCoordinates;

    private CoordinateProvenance(Origin origin, String authority, boolean hasCoordinates) {
        this.origin = origin;
        this.authority = authority == null ? "" : authority;
        this.hasCoordinates = hasCoordinates;
    }

    public static CoordinateProvenance forSignal(
            Signal.Layer layer, String providerId, boolean hasCoordinates) {
        if (!hasCoordinates) return new CoordinateProvenance(Origin.UNAVAILABLE, providerId, false);
        String p = providerId == null ? "" : providerId.toLowerCase(Locale.ROOT);
        if (layer == Signal.Layer.SATELLITES || p.contains("celestrak"))
            return new CoordinateProvenance(Origin.CALCULATED_ORBIT, providerId, true);
        if (p.contains("monitor") || p.contains("local-monitor"))
            return new CoordinateProvenance(Origin.MONITOR_SUPPLIED, providerId, true);
        return new CoordinateProvenance(Origin.PROVIDER, providerId, true);
    }

    public static CoordinateProvenance resolvedPlace(String authority, boolean hasCoordinates) {
        return hasCoordinates
                ? new CoordinateProvenance(Origin.RESOLVED_PLACE, authority, true)
                : new CoordinateProvenance(Origin.UNAVAILABLE, authority, false);
    }
}
