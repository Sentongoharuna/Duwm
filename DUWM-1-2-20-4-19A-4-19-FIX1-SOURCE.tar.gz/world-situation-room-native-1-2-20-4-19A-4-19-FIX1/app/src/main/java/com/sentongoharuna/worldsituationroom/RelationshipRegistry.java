package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Index of current canonical records by relationship ID. Records remain independent. */
public final class RelationshipRegistry {
    private final LinkedHashMap<String, LinkedHashMap<String, Signal>> groups = new LinkedHashMap<>();
    public synchronized void accept(List<Signal> values) {
        if (values == null) return;
        for (Signal s : values) {
            if (s == null || s.relationshipId == null || s.relationshipId.isEmpty()) continue;
            LinkedHashMap<String, Signal> g = groups.get(s.relationshipId);
            if (g == null) { g = new LinkedHashMap<>(); groups.put(s.relationshipId, g); }
            g.put(s.canonicalId, s);
        }
    }
    public synchronized List<Signal> relatedTo(Signal focus) {
        if (focus == null || focus.relationshipId == null) return Collections.emptyList();
        LinkedHashMap<String, Signal> g = groups.get(focus.relationshipId);
        if (g == null) return Collections.emptyList();
        ArrayList<Signal> out = new ArrayList<>();
        for (Signal s : g.values()) if (!s.canonicalId.equals(focus.canonicalId)) out.add(s);
        return out;
    }
}
