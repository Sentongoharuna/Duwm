package com.sentongoharuna.worldsituationroom;
import android.content.*; import java.util.*;
public final class NewsPreferences {
 private final SharedPreferences p; public NewsPreferences(Context c){p=c.getSharedPreferences("du_local_news_r33",Context.MODE_PRIVATE);}
 public boolean source(NewsSource s){return SafePreferences.bool(p,"source_"+s.id,s.enabledByDefault);} public void source(String id,boolean v){p.edit().putBoolean("source_"+id,v).apply();}
 public boolean topic(String t){return SafePreferences.bool(p,"topic_"+t.replace(' ','_'),true);} public void topic(String t,boolean v){p.edit().putBoolean("topic_"+t.replace(' ','_'),v).apply();}
 public boolean images(){return SafePreferences.bool(p,"images",true);} public void images(boolean v){p.edit().putBoolean("images",v).apply();}
 public boolean alerts(){return SafePreferences.bool(p,"alerts",true);} public boolean breaking(){return SafePreferences.bool(p,"breaking",true);} public boolean grouped(){return SafePreferences.bool(p,"grouped",true);} public boolean digest(){return SafePreferences.bool(p,"digest",true);} public boolean quiet(){return SafePreferences.bool(p,"quiet",true);}
 public void setFlag(String k,boolean v){p.edit().putBoolean(k,v).apply();} public boolean flag(String k,boolean d){return SafePreferences.bool(p,k,d);} public long time(String k,long d){return SafePreferences.longValue(p,k,d);} public void setTime(String k,long v){p.edit().putLong(k,v).apply();}
 public int dayCount(){String k="day_"+new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US).format(new java.util.Date());return p.getInt(k,0);} public void bumpDay(){String k="day_"+new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US).format(new java.util.Date());p.edit().putInt(k,dayCount()+1).apply();}
 public String feed(String id){return SafePreferences.string(p,"feed_"+id,"");} public long feedAt(String id){return SafePreferences.longValue(p,"feed_at_"+id,0);} public void feed(String id,String u){p.edit().putString("feed_"+id,u).putLong("feed_at_"+id,System.currentTimeMillis()).apply();}
 public void status(String id,String v){p.edit().putString("status_"+id,v).apply();} public String status(String id){return SafePreferences.string(p,"status_"+id,"Checking");}
}
