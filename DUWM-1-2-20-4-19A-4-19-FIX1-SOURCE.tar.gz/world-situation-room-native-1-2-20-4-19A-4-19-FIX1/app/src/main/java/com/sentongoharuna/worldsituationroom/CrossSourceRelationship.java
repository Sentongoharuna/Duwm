package com.sentongoharuna.worldsituationroom;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

/**
 * 1.2/20/2-12 relationship identity.
 * Keeps provider records separate while allowing related records to share an event relationship.
 * This is NOT canonical identity and never merges records from different providers.
 */
public final class CrossSourceRelationship {
    private CrossSourceRelationship() { }

    public static String id(Signal signal) {
        if (signal == null) return "";
        String explicit = fact(signal, "clusterId");
        if (explicit.isEmpty()) explicit = fact(signal, "Cluster ID");
        if (explicit.isEmpty()) explicit = fact(signal, "CLUSTER ID");
        if (!explicit.isEmpty()) return "rel:" + shortHash("explicit|" + explicit);

        // Conservative relationship basis: type + normalized region + coarse provider time window.
        // Title is included to avoid broad accidental merging of unrelated events.
        String title = normalize(signal.title);
        String type = normalize(signal.eventType);
        String region = normalize(signal.region);
        long providerTime = signal.timestampChain == null
                ? signal.timestampMs : signal.timestampChain.effectiveProviderTimeMs();
        long hourBucket = providerTime > 0L ? providerTime / 3_600_000L : 0L;
        if (title.isEmpty()) return "";
        return "rel:" + shortHash(type + "|" + region + "|" + hourBucket + "|" + title);
    }

    public static boolean related(Signal a, Signal b) {
        if (a == null || b == null) return false;
        // Same canonical object is identity, not a cross-source relationship.
        if (a.canonicalId != null && a.canonicalId.equals(b.canonicalId)) return false;
        String ar = id(a), br = id(b);
        return !ar.isEmpty() && ar.equals(br);
    }

    private static String fact(Signal s, String key) {
        return s.nativePayload == null ? "" : s.nativePayload.value(key);
    }

    private static String normalize(String value) {
        if (value == null) return "";
        return value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim();
    }

    private static String shortHash(String value) {
        try {
            byte[] b = MessageDigest.getInstance("SHA-256")
                    .digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder(24);
            for (int i = 0; i < 12; i++) out.append(String.format(Locale.US, "%02x", b[i] & 0xff));
            return out.toString();
        } catch (Exception ignored) {
            return Integer.toHexString(value.hashCode());
        }
    }
}
