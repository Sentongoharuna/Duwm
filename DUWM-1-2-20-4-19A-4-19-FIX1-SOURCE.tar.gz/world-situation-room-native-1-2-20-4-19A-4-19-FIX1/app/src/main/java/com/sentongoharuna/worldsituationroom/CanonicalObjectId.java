package com.sentongoharuna.worldsituationroom;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

/**
 * 1.2/20/2-1 canonical identity authority.
 * Stable identity is based on normalized providerId + layer + provider-native record id.
 * Position, title, timestamps and refresh order are deliberately excluded.
 */
public final class CanonicalObjectId {
    private CanonicalObjectId() { }

    public static String of(String provider, Signal.Layer layer, String providerRecordId) {
        String p = clean(provider);
        String l = layer == null ? "UNKNOWN" : layer.name();
        String r = clean(providerRecordId);
        if (r.isEmpty()) r = "UNIDENTIFIED";
        String basis = p + "|" + l + "|" + r;
        return "du:" + shortSha256(basis);
    }

    public static String basis(String provider, Signal.Layer layer, String providerRecordId) {
        return clean(provider) + "|" + (layer == null ? "UNKNOWN" : layer.name())
                + "|" + clean(providerRecordId);
    }

    private static String clean(String value) {
        if (value == null) return "";
        return value.trim().toUpperCase(Locale.ROOT).replaceAll("\\s+", " ");
    }

    private static String shortSha256(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder(32);
            for (int i = 0; i < 16; i++) out.append(String.format(Locale.US, "%02x", bytes[i] & 0xff));
            return out.toString();
        } catch (Exception ignored) {
            return Integer.toHexString(value.hashCode());
        }
    }
}
