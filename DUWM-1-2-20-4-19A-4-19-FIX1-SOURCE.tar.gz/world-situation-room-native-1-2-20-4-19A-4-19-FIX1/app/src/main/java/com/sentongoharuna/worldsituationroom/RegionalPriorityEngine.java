package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4.19A/4.5 auditable Uganda/East Africa relevance with border context and explicit method. */
public final class RegionalPriorityEngine {
 public enum Band { UGANDA, UGANDA_BORDER, EAST_AFRICA, GLOBAL }
 public enum Method { OBSERVED_COORDINATES, CONTROLLED_PROVIDER_TEXT, NONE }
 public static final class Result {
  public final Band band; public final int relevance; public final String reason; public final Method method;
  public final double borderDistanceKm;
  Result(Band b,int r,String why,Method m,double bd){band=b;relevance=r;reason=why;method=m;borderDistanceKm=bd;}
 }
 public static Result evaluate(Signal s){
  if(s==null)return new Result(Band.GLOBAL,0,"No object",Method.NONE,Double.NaN);
  if(s.hasLocation()){
   if(inUganda(s.latitude,s.longitude))return new Result(Band.UGANDA,100,"Observed coordinates inside conservative Uganda operational bounds",Method.OBSERVED_COORDINATES,0d);
   double bd=distanceToUgandaBoundsKm(s.latitude,s.longitude);
   if(bd<=75d)return new Result(Band.UGANDA_BORDER,80,String.format(Locale.US,"Observed coordinates %.1f km from conservative Uganda operational bounds",bd),Method.OBSERVED_COORDINATES,bd);
   if(inEastAfrica(s.latitude,s.longitude))return new Result(Band.EAST_AFRICA,70,"Observed coordinates inside East Africa operational bounds",Method.OBSERVED_COORDINATES,bd);
  }
  String text=(s.region+" "+s.title+" "+s.summary).toLowerCase(Locale.ROOT);
  if(has(text,"uganda","kampala","entebbe","jinja","mbarara","gulu","mbale","masaka","arua","lira","soroti","kabale","hoima","kasese","moroto","fort portal"))
   return new Result(Band.UGANDA,85,"Provider text names a controlled Uganda place",Method.CONTROLLED_PROVIDER_TEXT,Double.NaN);
  if(has(text,"kenya","nairobi","mombasa","kisumu","tanzania","dar es salaam","arusha","rwanda","kigali","burundi","bujumbura","south sudan","juba"))
   return new Result(Band.EAST_AFRICA,60,"Provider text names a controlled East Africa place",Method.CONTROLLED_PROVIDER_TEXT,Double.NaN);
  return new Result(Band.GLOBAL,10,"No Uganda/East Africa relevance detected",Method.NONE,Double.NaN);
 }
 private static boolean inUganda(double a,double o){return a>=-1.6&&a<=4.3&&o>=29.4&&o<=35.1;}
 private static boolean inEastAfrica(double a,double o){return a>=-12.5&&a<=12.5&&o>=28.0&&o<=52.0;}
 private static double distanceToUgandaBoundsKm(double a,double o){
  double ca=Math.max(-1.6,Math.min(4.3,a)),co=Math.max(29.4,Math.min(35.1,o));return km(a,o,ca,co);
 }
 private static double km(double a,double b,double c,double d){double r=6371.0088,p1=Math.toRadians(a),p2=Math.toRadians(c),dp=Math.toRadians(c-a),dl=Math.toRadians(d-b);double h=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);return 2*r*Math.asin(Math.min(1d,Math.sqrt(h)));}
 private static boolean has(String text,String...terms){for(String t:terms)if(text.contains(t))return true;return false;}
}