package com.sentongoharuna.worldsituationroom;
import android.content.*;
public final class NewsActionReceiver extends BroadcastReceiver{public void onReceive(Context c,Intent i){String id=i.getStringExtra("story_id");if(id==null)return;if("MARK_READ".equals(i.getAction()))new NewsStore(c).markRead(id);}}
