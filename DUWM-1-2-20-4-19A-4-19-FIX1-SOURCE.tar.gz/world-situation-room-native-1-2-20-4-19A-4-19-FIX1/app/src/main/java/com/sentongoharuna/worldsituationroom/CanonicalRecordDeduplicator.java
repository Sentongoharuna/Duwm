package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** 1.2/20/2-11 one provider record -> one canonical Globe object. */
public final class CanonicalRecordDeduplicator {
 private CanonicalRecordDeduplicator(){}
 public static List<Signal> deduplicate(List<Signal> input){
  LinkedHashMap<String,Signal> unique=new LinkedHashMap<>();
  if(input==null)return new ArrayList<>();
  for(Signal s:input){
   if(s==null)continue;
   String key=s.canonicalId==null||s.canonicalId.isEmpty()?CanonicalObjectId.of(s.providerId,s.layer,s.id):s.canonicalId;
   Signal old=unique.get(key);
   if(old==null||newer(s,old))unique.put(key,s);
  }
  return new ArrayList<>(unique.values());
 }
 private static boolean newer(Signal a,Signal b){
  long at=a.timestampChain==null?a.timestampMs:a.timestampChain.effectiveProviderTimeMs();
  long bt=b.timestampChain==null?b.timestampMs:b.timestampChain.effectiveProviderTimeMs();
  return at>=bt;
 }
}
