package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** 1.2/20/4.19A/4.15 explainable operational attention; never rewrites source severity or asserts danger. */
public final class OperationalPriorityEngine {
 public enum Band { ROUTINE, WATCH, ELEVATED, HIGH_ATTENTION }
 public static final class Factor {
  public final String name; public final int points; public final boolean applied; public final String reason;
  Factor(String n,int p,boolean a,String r){name=n;points=p;applied=a;reason=r;}
 }
 public static final class Result {
  public final Band band; public final int points; public final List<String> reasons; public final List<Factor> factors;
  Result(Band b,int p,List<String>r,List<Factor>f){band=b;points=p;reasons=Collections.unmodifiableList(r);factors=Collections.unmodifiableList(f);}
 }
 public static Result evaluate(Signal s,CanonicalWatchStore watch,LiveChangeRegistry changes,
                               RegionalPriorityEngine.Result region,IncidentFormationEngine.Incident incident){
  if(s==null)return new Result(Band.ROUTINE,0,Collections.singletonList("No current object"),Collections.singletonList(new Factor("OBJECT",0,false,"No current object")));
  ArrayList<Factor>f=new ArrayList<>();int p=0;
  boolean current=s.freshness!=null&&(s.freshness.state==ObjectFreshness.State.LIVE||s.freshness.state==ObjectFreshness.State.FRESH);
  p+=factor(f,"CURRENT RECORD",10,current,current?"LIVE/FRESH provider record":"Not LIVE/FRESH");
  boolean watched=watch!=null&&watch.watched(s.canonicalId);p+=factor(f,"USER WATCH",20,watched,watched?"Persistent canonical WATCH":"Not watched");
  boolean changed=changes!=null&&!changes.changesFor(s.canonicalId).isEmpty();p+=factor(f,"MEANINGFUL CHANGE",20,changed,changed?"Detected canonical change history":"No detected change history");
  boolean ug=region!=null&&region.band==RegionalPriorityEngine.Band.UGANDA, border=region!=null&&region.band==RegionalPriorityEngine.Band.UGANDA_BORDER, ea=region!=null&&region.band==RegionalPriorityEngine.Band.EAST_AFRICA;
  p+=factor(f,"UGANDA RELEVANCE",20,ug,ug?"Inside Uganda operational relevance":"Not Uganda band");
  p+=factor(f,"UGANDA BORDER CONTEXT",15,!ug&&border,border?"Near-Uganda-border relevance":"Not border band");
  p+=factor(f,"EAST AFRICA RELEVANCE",10,!ug&&!border&&ea,ea?"East Africa relevance":"Not East Africa-only band");
  boolean multi=incident!=null&&(incident.state==IncidentFormationEngine.State.MULTI_SOURCE_RELATED||incident.state==IncidentFormationEngine.State.FORMING||incident.state==IncidentFormationEngine.State.ACTIVE_RELATED);
  boolean duplicateOnly=multi&&duplicateEvidenceOnly(incident);
  p+=factor(f,"MULTI-RECORD CANDIDATE",15,multi&&!duplicateOnly,multi?(duplicateOnly?"Suppressed: duplicate canonical/provider evidence":"Related candidate with non-duplicate evidence"):"No multi-record candidate");
  boolean sev=s.severity>=3;p+=factor(f,"SOURCE SEVERITY",15,sev,sev?"Provider/source severity "+s.severity:"Provider/source severity below threshold");
  p=Math.min(100,p);Band b=p>=70?Band.HIGH_ATTENTION:p>=45?Band.ELEVATED:p>=20?Band.WATCH:Band.ROUTINE;
  ArrayList<String>why=new ArrayList<>();for(Factor x:f)if(x.applied)why.add(x.name+" +"+x.points+" — "+x.reason);if(why.isEmpty())why.add("No operational attention factors");
  return new Result(b,p,why,f);
 }
 private static int factor(List<Factor>f,String n,int pts,boolean applied,String reason){f.add(new Factor(n,pts,applied,reason));return applied?pts:0;}
 private static boolean duplicateEvidenceOnly(IncidentFormationEngine.Incident i){
  if(i==null||i.evidence==null||i.evidence.size()<2)return false;HashSet<String>pairs=new HashSet<>();
  for(IncidentFormationEngine.Evidence e:i.evidence)pairs.add(e.providerId+"|"+e.canonicalId);
  return pairs.size()<2;
 }
}