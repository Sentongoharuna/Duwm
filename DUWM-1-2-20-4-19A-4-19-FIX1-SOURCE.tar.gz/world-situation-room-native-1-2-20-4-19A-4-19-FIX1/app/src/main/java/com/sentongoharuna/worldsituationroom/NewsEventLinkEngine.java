package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4.19A/4.9 auditable conservative News/Event candidate linking with explicit rejection reasons. */
public final class NewsEventLinkEngine {
 public enum Basis { EXISTING_RELATIONSHIP_ID, LOCATION_AND_TIME }
 public enum Reject { NONE, LOCATION_UNRESOLVED, TOO_FAR, TIME_WINDOW_FAILED, NOT_RELATED_TO_FOCUS }
 public static final class Link {
  public final Signal news,event; public final Basis basis; public final double distanceKm; public final long timeDeltaMs;
  public final String reason;
  Link(Signal n,Signal e,Basis b,double d,long t,String r){news=n;event=e;basis=b;distanceKm=d;timeDeltaMs=t;reason=r;}
 }
 public static final class Rejection {
  public final String newsId,eventId; public final Reject reason; public final double distanceKm; public final long timeDeltaMs;
  Rejection(Signal n,Signal e,Reject r,double d,long t){newsId=n.canonicalId;eventId=e.canonicalId;reason=r;distanceKm=d;timeDeltaMs=t;}
 }
 public static final class Audit {
  public final List<Link> links; public final List<Rejection> rejected;
  Audit(List<Link>l,List<Rejection>r){links=Collections.unmodifiableList(l);rejected=Collections.unmodifiableList(r);}
 }
 public static Audit audit(Signal focus,Collection<List<Signal>> layers,int limit){
  if(focus==null)return new Audit(Collections.emptyList(),Collections.emptyList());
  ArrayList<Signal>news=new ArrayList<>(),events=new ArrayList<>();
  if(layers!=null)for(List<Signal>list:layers)if(list!=null)for(Signal s:list){
   if(s==null)continue;if(s.layer==Signal.Layer.NEWS)news.add(s);
   else if(s.layer==Signal.Layer.NATURAL||s.layer==Signal.Layer.WEATHER||s.layer==Signal.Layer.AIRSPACE)events.add(s);
  }
  ArrayList<Link>out=new ArrayList<>();ArrayList<Rejection>rej=new ArrayList<>();HashSet<String>seen=new HashSet<>();
  for(Signal n:news)for(Signal e:events){
   if(!focus.canonicalId.equals(n.canonicalId)&&!focus.canonicalId.equals(e.canonicalId))continue;
   String key=n.canonicalId+"|"+e.canonicalId;if(!seen.add(key))continue;
   long dt=Math.abs(providerTime(n)-providerTime(e));double d=Double.NaN;
   if(n.relationshipId!=null&&!n.relationshipId.isEmpty()&&n.relationshipId.equals(e.relationshipId)){
    out.add(new Link(n,e,Basis.EXISTING_RELATIONSHIP_ID,d,dt,"Existing DUWM relationship identity"));continue;
   }
   if(!n.hasLocation()||!e.hasLocation()){rej.add(new Rejection(n,e,Reject.LOCATION_UNRESOLVED,d,dt));continue;}
   d=km(n.latitude,n.longitude,e.latitude,e.longitude);
   if(d>100d){rej.add(new Rejection(n,e,Reject.TOO_FAR,d,dt));continue;}
   if(dt>6L*60L*60L*1000L){rej.add(new Rejection(n,e,Reject.TIME_WINDOW_FAILED,d,dt));continue;}
   out.add(new Link(n,e,Basis.LOCATION_AND_TIME,d,dt,String.format(Locale.US,"Observed locations within %.1f km and provider times within %d min",d,dt/60000L)));
   if(out.size()>=limit)break;
  }
  if(rej.size()>20)rej=new ArrayList<>(rej.subList(0,20));
  return new Audit(out,rej);
 }
 public static List<Link> linksFor(Signal focus,Collection<List<Signal>>layers,int limit){return audit(focus,layers,limit).links;}
 private static long providerTime(Signal s){return s.timestampChain==null?s.timestampMs:s.timestampChain.providerTimeMs;}
 private static double km(double a,double b,double c,double d){double r=6371.0088,p1=Math.toRadians(a),p2=Math.toRadians(c),dp=Math.toRadians(c-a),dl=Math.toRadians(d-b);double h=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);return 2*r*Math.asin(Math.min(1d,Math.sqrt(h)));}
}