package com.sentongoharuna.worldsituationroom;
import java.util.Collections;import java.util.LinkedHashMap;import java.util.Map;
/** 1.2/20/2-7 immutable provider/type-specific facts. */
public final class TypeSpecificPayload{
 public final Signal.Layer layer;public final Map<String,String> facts;
 private TypeSpecificPayload(Signal.Layer l,Map<String,String> f){layer=l;facts=Collections.unmodifiableMap(new LinkedHashMap<>(f));}
 public static TypeSpecificPayload from(Signal.Layer l,Map<String,String> src){LinkedHashMap<String,String> o=new LinkedHashMap<>();if(src!=null)for(Map.Entry<String,String>e:src.entrySet()){if(e.getKey()==null||e.getKey().trim().isEmpty())continue;o.put(e.getKey().trim(),e.getValue()==null?"":e.getValue().trim());}return new TypeSpecificPayload(l,o);}
 public String value(String k){String v=k==null?null:facts.get(k);return v==null?"":v;}
 public boolean has(String k){return k!=null&&facts.containsKey(k)&&!value(k).isEmpty();}
}
