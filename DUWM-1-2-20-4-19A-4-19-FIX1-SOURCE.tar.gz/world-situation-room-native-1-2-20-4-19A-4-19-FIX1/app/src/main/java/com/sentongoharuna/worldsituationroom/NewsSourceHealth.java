package com.sentongoharuna.worldsituationroom;
import android.content.Context;
/** 1.2/20/2-14 accountable F9 source health derived from persisted discovery/fetch state. */
public final class NewsSourceHealth{
 public enum State{WORKING,UNAVAILABLE,CHECKING,STALE}
 public final NewsSource source;public final State state;public final long lastSuccessMs;public final long lastCheckedMs;public final String workingFeed;
 private NewsSourceHealth(NewsSource s,State st,long ok,long checked,String feed){source=s;state=st;lastSuccessMs=ok;lastCheckedMs=checked;workingFeed=feed==null?"":feed;}
 public static NewsSourceHealth read(Context c,NewsSource s){NewsPreferences p=new NewsPreferences(c);String raw=p.status(s.id);long ok=p.time("success_"+s.id,0);long checked=p.time("checked_"+s.id,0);State st="Working".equalsIgnoreCase(raw)?State.WORKING:"Unavailable".equalsIgnoreCase(raw)?State.UNAVAILABLE:State.CHECKING;if(st==State.WORKING&&ok>0&&System.currentTimeMillis()-ok>6L*60L*60L*1000L)st=State.STALE;return new NewsSourceHealth(s,st,ok,checked,p.feed(s.id));}
}
