package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4.19A/4.8 evidence independence audit: provider diversity is not assumed independent reporting. */
public final class CrossSourceEvidencePanel {
 public enum Role { PRIMARY_RECORD, RELATED_PROVIDER_RECORD, SAME_PROVIDER_RELATED }
 public enum Independence { PRIMARY, SAME_PROVIDER, DISTINCT_PROVIDER, POSSIBLE_DUPLICATE_CONTENT, UNKNOWN_LINEAGE }
 public static final class Evidence {
  public final Role role; public final Independence independence; public final Signal signal; public final String contentSignature;
  Evidence(Role r,Independence i,Signal s,String sig){role=r;independence=i;signal=s;contentSignature=sig;}
 }
 public static final class Audit {
  public final List<Evidence> evidence; public final int distinctProviders,distinctLayers,duplicateContentGroups;
  Audit(List<Evidence>e,int p,int l,int d){evidence=Collections.unmodifiableList(e);distinctProviders=p;distinctLayers=l;duplicateContentGroups=d;}
 }
 public static Audit audit(Signal focus,List<Signal> related,int limit){
  if(focus==null)return new Audit(Collections.emptyList(),0,0,0);
  ArrayList<Signal> source=new ArrayList<>();source.add(focus);if(related!=null)source.addAll(related);
  HashSet<String>seenCanonical=new HashSet<>();LinkedHashMap<String,Integer>sigCounts=new LinkedHashMap<>();
  for(Signal s:source)if(s!=null&&s.canonicalId!=null&&seenCanonical.add(s.canonicalId)){String sig=signature(s);sigCounts.put(sig,sigCounts.getOrDefault(sig,0)+1);}
  seenCanonical.clear();ArrayList<Evidence>out=new ArrayList<>();HashSet<String>providers=new HashSet<>();EnumSet<Signal.Layer>layers=EnumSet.noneOf(Signal.Layer.class);
  for(Signal s:source){
   if(s==null||s.canonicalId==null||!seenCanonical.add(s.canonicalId))continue;
   Role role=s==focus?Role.PRIMARY_RECORD:(focus.providerId.equals(s.providerId)?Role.SAME_PROVIDER_RELATED:Role.RELATED_PROVIDER_RECORD);
   String sig=signature(s);Independence ind;
   if(s==focus)ind=Independence.PRIMARY;
   else if(focus.providerId.equals(s.providerId))ind=Independence.SAME_PROVIDER;
   else if(sigCounts.getOrDefault(sig,0)>1)ind=Independence.POSSIBLE_DUPLICATE_CONTENT;
   else ind=Independence.UNKNOWN_LINEAGE; // different provider is visible, but editorial/wire lineage is not invented.
   out.add(new Evidence(role,ind,s,sig));providers.add(s.providerId);layers.add(s.layer);if(out.size()>=limit)break;
  }
  int dup=0;for(int n:sigCounts.values())if(n>1)dup++;
  return new Audit(out,providers.size(),layers.size(),dup);
 }
 public static List<Evidence> build(Signal focus,List<Signal> related,int limit){return audit(focus,related,limit).evidence;}
 public static int distinctProviders(List<Evidence>e){HashSet<String>x=new HashSet<>();if(e!=null)for(Evidence v:e)if(v!=null&&v.signal!=null)x.add(v.signal.providerId);return x.size();}
 public static int distinctLayers(List<Evidence>e){EnumSet<Signal.Layer>x=EnumSet.noneOf(Signal.Layer.class);if(e!=null)for(Evidence v:e)if(v!=null&&v.signal!=null)x.add(v.signal.layer);return x.size();}
 private static String signature(Signal s){
  String t=norm(s.title)+"|"+norm(s.summary);if(t.length()>240)t=t.substring(0,240);return Integer.toHexString(t.hashCode());
 }
 private static String norm(String s){return s==null?"":s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+"," ").trim();}
}