package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4.19A/4.1 deep live-change state: first/last seen, persistence, deltas and bounded history. */
public final class LiveChangeRegistry {
 public enum Kind { APPEARED, MOVED, HEADING_CHANGED, SPEED_CHANGED, SEVERITY_CHANGED, STATE_CHANGED, UPDATED, DISAPPEARED }
 public static final class Change {
  public final String canonicalId; public final Kind kind; public final long detectedAtMs; public final String detail;
  public final String previousValue,currentValue; public final long providerDeltaMs;
  Change(String id,Kind k,long at,String d){this(id,k,at,d,"","",0L);}
  Change(String id,Kind k,long at,String d,String pv,String cv,long dt){
   canonicalId=id;kind=k;detectedAtMs=at;detail=d;previousValue=pv;currentValue=cv;providerDeltaMs=dt;
  }
 }
 public static final class Lifecycle {
  public final long firstSeenMs,lastSeenMs,missingSinceMs; public final int consecutivePresent,consecutiveMissing;
  Lifecycle(long f,long l,long m,int p,int x){firstSeenMs=f;lastSeenMs=l;missingSinceMs=m;consecutivePresent=p;consecutiveMissing=x;}
  public boolean persistentlyMissing(){return consecutiveMissing>=2;}
 }
 private static final class Snapshot {
  final double lat,lon,heading,speed; final int severity; final long providerTime; final String freshness;
  Snapshot(Signal s){lat=s.latitude;lon=s.longitude;heading=s.heading;speed=s.speedMetersPerSecond;severity=s.severity;
   providerTime=s.timestampChain==null?s.timestampMs:s.timestampChain.providerTimeMs;freshness=s.freshness==null?"UNKNOWN":s.freshness.state.name();}
 }
 private static final class Life {
  long first,last,missingSince; int present,missing;
  Life(long n){first=n;last=n;present=1;}
 }
 private final EnumMap<Signal.Layer,LinkedHashMap<String,Snapshot>> previous=new EnumMap<>(Signal.Layer.class);
 private final LinkedHashMap<String,ArrayDeque<Change>> history=new LinkedHashMap<>(128,0.75f,true);
 private final LinkedHashMap<String,Life> lifecycle=new LinkedHashMap<>(128,0.75f,true);

 public synchronized List<Change> accept(Signal.Layer layer,List<Signal> current,long now){
  LinkedHashMap<String,Snapshot> before=previous.get(layer),next=new LinkedHashMap<>();ArrayList<Change> out=new ArrayList<>();HashSet<String> presentIds=new HashSet<>();
  if(current!=null)for(Signal s:current){
   if(s==null||s.canonicalId==null||s.canonicalId.isEmpty())continue;
   presentIds.add(s.canonicalId);Snapshot n=new Snapshot(s);next.put(s.canonicalId,n);
   Life life=lifecycle.get(s.canonicalId);if(life==null){life=new Life(now);lifecycle.put(s.canonicalId,life);}
   else {life.last=now;life.present++;life.missing=0;life.missingSince=0L;}
   Snapshot o=before==null?null:before.get(s.canonicalId);
   if(o==null){if(before!=null)add(out,new Change(s.canonicalId,Kind.APPEARED,now,"Returned in current provider refresh","","present",0L));continue;}
   long pdt=n.providerTime>0&&o.providerTime>0?n.providerTime-o.providerTime:0L;
   if(moved(o,n)){double d=distanceKm(o.lat,o.lon,n.lat,n.lon);add(out,new Change(s.canonicalId,Kind.MOVED,now,String.format(Locale.US,"%.1f km observed displacement",d),coord(o),coord(n),pdt));}
   if(finite(o.heading)&&finite(n.heading)&&angle(o.heading,n.heading)>=12d)add(out,new Change(s.canonicalId,Kind.HEADING_CHANGED,now,String.format(Locale.US,"Heading %.0f° → %.0f°",o.heading,n.heading),fmt(o.heading),fmt(n.heading),pdt));
   if(finite(o.speed)&&finite(n.speed)&&Math.abs(n.speed-o.speed)>=5d)add(out,new Change(s.canonicalId,Kind.SPEED_CHANGED,now,String.format(Locale.US,"Speed %.1f → %.1f m/s",o.speed,n.speed),fmt(o.speed),fmt(n.speed),pdt));
   if(o.severity!=n.severity)add(out,new Change(s.canonicalId,Kind.SEVERITY_CHANGED,now,"Severity "+o.severity+" → "+n.severity,String.valueOf(o.severity),String.valueOf(n.severity),pdt));
   if(!o.freshness.equals(n.freshness))add(out,new Change(s.canonicalId,Kind.STATE_CHANGED,now,"Freshness "+o.freshness+" → "+n.freshness,o.freshness,n.freshness,pdt));
   if(n.providerTime>o.providerTime)add(out,new Change(s.canonicalId,Kind.UPDATED,now,"Provider observation advanced",String.valueOf(o.providerTime),String.valueOf(n.providerTime),pdt));
  }
  if(before!=null)for(String id:before.keySet())if(!next.containsKey(id)){
   Life life=lifecycle.get(id);if(life==null){life=new Life(now);lifecycle.put(id,life);}
   if(life.missing==0)life.missingSince=now;life.missing++;life.present=0;
   String d=life.missing>=2?"Persistently absent for "+life.missing+" refreshes":"Absent from current provider refresh";
   add(out,new Change(id,Kind.DISAPPEARED,now,d,"present","missing",0L));
  }
  previous.put(layer,next);trimLifecycle();return Collections.unmodifiableList(out);
 }
 public synchronized Lifecycle lifecycleFor(String id){
  Life x=lifecycle.get(id);return x==null?null:new Lifecycle(x.first,x.last,x.missingSince,x.present,x.missing);
 }
 public synchronized List<Change> changesFor(String id){ArrayDeque<Change>h=history.get(id);if(h==null)return Collections.emptyList();ArrayList<Change>o=new ArrayList<>(h);Collections.reverse(o);return o;}
 private void add(List<Change>out,Change c){out.add(c);ArrayDeque<Change>h=history.get(c.canonicalId);if(h==null){h=new ArrayDeque<>();history.put(c.canonicalId,h);}h.addLast(c);while(h.size()>32)h.removeFirst();while(history.size()>1024){Iterator<String>i=history.keySet().iterator();if(!i.hasNext())break;i.next();i.remove();}}
 private void trimLifecycle(){while(lifecycle.size()>2048){Iterator<String>i=lifecycle.keySet().iterator();if(!i.hasNext())break;i.next();i.remove();}}
 private static String coord(Snapshot s){return String.format(Locale.US,"%.5f,%.5f",s.lat,s.lon);}
 private static String fmt(double v){return String.format(Locale.US,"%.2f",v);}
 private static boolean moved(Snapshot a,Snapshot b){return finite(a.lat)&&finite(a.lon)&&finite(b.lat)&&finite(b.lon)&&distanceKm(a.lat,a.lon,b.lat,b.lon)>=0.25d;}
 private static boolean finite(double v){return Double.isFinite(v);}
 private static double angle(double a,double b){double d=Math.abs(a-b)%360d;return d>180d?360d-d:d;}
 private static double distanceKm(double a,double b,double c,double d){double r=6371.0088,p1=Math.toRadians(a),p2=Math.toRadians(c),dp=Math.toRadians(c-a),dl=Math.toRadians(d-b);double h=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);return 2*r*Math.asin(Math.min(1d,Math.sqrt(h)));}
}