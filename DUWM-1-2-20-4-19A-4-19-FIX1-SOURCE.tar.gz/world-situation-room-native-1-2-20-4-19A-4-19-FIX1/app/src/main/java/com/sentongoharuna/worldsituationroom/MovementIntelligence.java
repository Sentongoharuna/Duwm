package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4.19A/4.2 multi-fix movement intelligence from observed provider fixes only. */
public final class MovementIntelligence {
 public enum Motion { UNKNOWN, STATIONARY, MOVING }
 public enum Trend { UNKNOWN, DECREASING, STABLE, INCREASING }
 public static final class State {
  public final boolean available; public final int fixCount;
  public final double distanceKm,bearingDeg,derivedSpeedMps,totalObservedKm,averageSpeedMps,turnMagnitudeDeg;
  public final long elapsedMs,fromProviderMs,toProviderMs,maxGapMs;
  public final String direction; public final Motion motion; public final Trend speedTrend,headingTrend;
  State(boolean a,int fc,double d,double b,double s,double total,double avg,double turn,long e,long f,long t,long gap,String dir,Motion mo,Trend st,Trend ht){
   available=a;fixCount=fc;distanceKm=d;bearingDeg=b;derivedSpeedMps=s;totalObservedKm=total;averageSpeedMps=avg;turnMagnitudeDeg=turn;
   elapsedMs=e;fromProviderMs=f;toProviderMs=t;maxGapMs=gap;direction=dir;motion=mo;speedTrend=st;headingTrend=ht;
  }
 }
 public static State from(List<CanonicalTimelineRegistry.Entry> newestFirst){
  if(newestFirst==null||newestFirst.size()<2)return unavailable();
  ArrayList<CanonicalTimelineRegistry.Entry> fixes=new ArrayList<>();
  long last=Long.MAX_VALUE;
  for(CanonicalTimelineRegistry.Entry e:newestFirst){
   if(valid(e)&&e.providerTimeMs>0&&e.providerTimeMs<last){fixes.add(e);last=e.providerTimeMs;}
   if(fixes.size()>=8)break;
  }
  if(fixes.size()<2)return unavailable();
  Collections.reverse(fixes);
  CanonicalTimelineRegistry.Entry from=fixes.get(0),to=fixes.get(fixes.size()-1);
  long elapsed=to.providerTimeMs-from.providerTimeMs;if(elapsed<=0)return unavailable();
  double total=0,maxTurn=0;long maxGap=0;ArrayList<Double> segmentSpeeds=new ArrayList<>(),bearings=new ArrayList<>();
  for(int i=1;i<fixes.size();i++){
   CanonicalTimelineRegistry.Entry a=fixes.get(i-1),b=fixes.get(i);long dt=b.providerTimeMs-a.providerTimeMs;if(dt<=0)continue;
   double km=distanceKm(a.latitude,a.longitude,b.latitude,b.longitude),br=bearing(a.latitude,a.longitude,b.latitude,b.longitude);
   total+=km;maxGap=Math.max(maxGap,dt);segmentSpeeds.add((km*1000d)/(dt/1000d));bearings.add(br);
   if(bearings.size()>1)maxTurn=Math.max(maxTurn,angle(bearings.get(bearings.size()-2),br));
  }
  double displacement=distanceKm(from.latitude,from.longitude,to.latitude,to.longitude);
  double overallBearing=bearing(from.latitude,from.longitude,to.latitude,to.longitude);
  double between=(displacement*1000d)/(elapsed/1000d),avg=(total*1000d)/(elapsed/1000d);
  Motion motion=total<0.25d?Motion.STATIONARY:Motion.MOVING;
  return new State(true,fixes.size(),displacement,overallBearing,between,total,avg,maxTurn,elapsed,from.providerTimeMs,to.providerTimeMs,maxGap,
    compass(overallBearing),motion,trend(segmentSpeeds),headingTrend(bearings));
 }
 private static Trend trend(List<Double>x){if(x.size()<2)return Trend.UNKNOWN;double d=x.get(x.size()-1)-x.get(0);return d>5?Trend.INCREASING:d<-5?Trend.DECREASING:Trend.STABLE;}
 private static Trend headingTrend(List<Double>x){if(x.size()<2)return Trend.UNKNOWN;double d=angle(x.get(0),x.get(x.size()-1));return d>=12?Trend.INCREASING:Trend.STABLE;}
 private static State unavailable(){return new State(false,0,Double.NaN,Double.NaN,Double.NaN,Double.NaN,Double.NaN,Double.NaN,0,0,0,0,"UNKNOWN",Motion.UNKNOWN,Trend.UNKNOWN,Trend.UNKNOWN);}
 private static boolean valid(CanonicalTimelineRegistry.Entry e){return e!=null&&Double.isFinite(e.latitude)&&Double.isFinite(e.longitude)&&e.latitude>=-90&&e.latitude<=90&&e.longitude>=-180&&e.longitude<=180;}
 private static double distanceKm(double a,double b,double c,double d){double r=6371.0088,p1=Math.toRadians(a),p2=Math.toRadians(c),dp=Math.toRadians(c-a),dl=Math.toRadians(d-b);double h=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);return 2*r*Math.asin(Math.min(1d,Math.sqrt(h)));}
 private static double bearing(double a,double b,double c,double d){double p1=Math.toRadians(a),p2=Math.toRadians(c),dl=Math.toRadians(d-b);double y=Math.sin(dl)*Math.cos(p2),x=Math.cos(p1)*Math.sin(p2)-Math.sin(p1)*Math.cos(p2)*Math.cos(dl);return (Math.toDegrees(Math.atan2(y,x))+360d)%360d;}
 private static double angle(double a,double b){double d=Math.abs(a-b)%360d;return d>180d?360d-d:d;}
 private static String compass(double b){String[]p={"N","NE","E","SE","S","SW","W","NW"};return p[((int)Math.floor((b+22.5d)/45d))%8];}
}