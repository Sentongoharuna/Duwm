package com.sentongoharuna.worldsituationroom;

/**
 * 1.2/20/2-4 timestamp provenance.
 * Provider time is never replaced by fetch/render time.
 */
public final class RecordTimestampChain {
    public final long providerTimeMs;
    public final long firstSeenMs;
    public final long fetchedAtMs;
    public final long renderedAtMs;

    public RecordTimestampChain(long providerTimeMs, long firstSeenMs, long fetchedAtMs, long renderedAtMs) {
        this.providerTimeMs = providerTimeMs;
        this.firstSeenMs = firstSeenMs;
        this.fetchedAtMs = fetchedAtMs;
        this.renderedAtMs = renderedAtMs;
    }

    public long effectiveProviderTimeMs() {
        return providerTimeMs > 0L ? providerTimeMs : firstSeenMs;
    }

    public long providerAgeMs(long now) {
        long t = effectiveProviderTimeMs();
        return t <= 0L ? -1L : Math.max(0L, now - t);
    }

    public RecordTimestampChain rendered(long now) {
        return new RecordTimestampChain(providerTimeMs, firstSeenMs, fetchedAtMs, now);
    }
}
