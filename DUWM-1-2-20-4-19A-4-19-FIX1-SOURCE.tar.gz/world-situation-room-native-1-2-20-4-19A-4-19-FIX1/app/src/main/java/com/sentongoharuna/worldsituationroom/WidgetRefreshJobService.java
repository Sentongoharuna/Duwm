package com.sentongoharuna.worldsituationroom;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Handler;
import android.os.Looper;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Runs one short acquisition window using the same repository and rate-limited cache as the app.
 * It is deliberately bounded: the launcher receives a recent snapshot without a permanent
 * background process, fake movement, or an excessive free-tier request rate.
 */
public final class WidgetRefreshJobService extends JobService {
    private static final long ACQUISITION_WINDOW_MS = 27_000L;
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WorldDataRepository repository;
    private JobParameters activeParameters;

    private final Runnable finish = () -> finishAcquisition(false);

    @Override
    public boolean onStartJob(JobParameters parameters) {

        if (!RUNNING.compareAndSet(false, true)) return false;
        activeParameters = parameters;
        repository = new WorldDataRepository(this, new WorldDataRepository.Listener() {
            @Override
            public void onLayer(Signal.Layer layer, List<Signal> signals, FeedStatus status) {
                DuWidgetUpdater.requestUpdate(WidgetRefreshJobService.this);
            }

            @Override
            public void onWeather(String host, List<WorldDataRepository.RadarFrame> frames,
                                  FeedStatus status) {
                DuWidgetUpdater.requestUpdate(WidgetRefreshJobService.this);
            }

            @Override
            public void onSearchResult(WorldDataRepository.Place place, String error) { }
        });
        repository.start();
        try { new NewsAggregator(this).refresh((items, working) -> { }); } catch (RuntimeException error) { CrashLedger.recordRecovered(this, "NewsBackground", error); }
        handler.postDelayed(finish, ACQUISITION_WINDOW_MS);
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters parameters) {
        finishAcquisition(true);
        return true;
    }

    private void finishAcquisition(boolean stoppedBySystem) {
        handler.removeCallbacks(finish);
        WorldDataRepository active = repository;
        repository = null;
        if (active != null) active.stop();
        DuWidgetUpdater.updateAll(this);
        RUNNING.set(false);
        JobParameters parameters = activeParameters;
        activeParameters = null;
        if (!stoppedBySystem && parameters != null) jobFinished(parameters, false);
    }
}
