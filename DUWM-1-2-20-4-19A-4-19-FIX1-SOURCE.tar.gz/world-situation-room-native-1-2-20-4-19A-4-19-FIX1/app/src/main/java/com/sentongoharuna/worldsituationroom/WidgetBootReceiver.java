package com.sentongoharuna.worldsituationroom;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

/** Restores widget scheduling after reboot; it performs no network request in the receiver. */
public final class WidgetBootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent == null ? null : intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            WidgetRefreshScheduler.schedulePeriodic(context);
            DuWidgetUpdater.requestUpdate(context);
        }
    }
}
