package com.sentongoharuna.worldsituationroom;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Small built-in centroid index used only to place headlines that lack coordinates. */
public final class GeoIndex {
    public static final class Point {
        public final double latitude;
        public final double longitude;
        public final String region;

        Point(double latitude, double longitude, String region) {
            this.latitude = latitude;
            this.longitude = longitude;
            this.region = region;
        }
    }

    private static final Map<String, Point> COUNTRIES = new LinkedHashMap<>();

    static {
        add("uganda", 1.37, 32.29, "AFRICA"); add("kampala", 0.3476, 32.5825, "AFRICA");
        add("kampale", 0.3476, 32.5825, "AFRICA");
        add("entebbe", 0.0512, 32.4637, "AFRICA"); add("kenya", 0.02, 37.91, "AFRICA");
        add("tanzania", -6.37, 34.89, "AFRICA"); add("rwanda", -1.94, 29.87, "AFRICA");
        add("burundi", -3.37, 29.92, "AFRICA"); add("congo", -2.88, 23.66, "AFRICA");
        add("sudan", 12.86, 30.22, "AFRICA"); add("south sudan", 7.86, 29.69, "AFRICA");
        add("ethiopia", 9.15, 40.49, "AFRICA"); add("somalia", 5.15, 46.20, "AFRICA");
        add("nigeria", 9.08, 8.68, "AFRICA"); add("ghana", 7.95, -1.02, "AFRICA");
        add("south africa", -30.56, 22.94, "AFRICA"); add("egypt", 26.82, 30.80, "AFRICA");
        add("libya", 26.34, 17.23, "AFRICA"); add("morocco", 31.79, -7.09, "AFRICA");
        add("united states", 39.78, -100.45, "AMERICAS"); add("usa", 39.78, -100.45, "AMERICAS");
        add("canada", 56.13, -106.35, "AMERICAS"); add("mexico", 23.63, -102.55, "AMERICAS");
        add("brazil", -14.24, -51.93, "AMERICAS"); add("argentina", -38.42, -63.62, "AMERICAS");
        add("colombia", 4.57, -74.30, "AMERICAS"); add("venezuela", 6.42, -66.59, "AMERICAS");
        add("united kingdom", 55.38, -3.44, "EUROPE"); add("uk", 55.38, -3.44, "EUROPE");
        add("france", 46.23, 2.21, "EUROPE"); add("germany", 51.17, 10.45, "EUROPE");
        add("ukraine", 48.38, 31.17, "EUROPE"); add("russia", 61.52, 105.32, "EUROPE");
        add("italy", 41.87, 12.57, "EUROPE"); add("spain", 40.46, -3.75, "EUROPE");
        add("turkey", 38.96, 35.24, "MIDDLE EAST"); add("israel", 31.05, 34.85, "MIDDLE EAST");
        add("gaza", 31.42, 34.38, "MIDDLE EAST"); add("palestine", 31.95, 35.23, "MIDDLE EAST");
        add("lebanon", 33.85, 35.86, "MIDDLE EAST"); add("syria", 34.80, 38.99, "MIDDLE EAST");
        add("iraq", 33.22, 43.68, "MIDDLE EAST"); add("iran", 32.43, 53.69, "MIDDLE EAST");
        add("saudi arabia", 23.89, 45.08, "MIDDLE EAST"); add("yemen", 15.55, 48.52, "MIDDLE EAST");
        add("india", 20.59, 78.96, "ASIA"); add("pakistan", 30.38, 69.35, "ASIA");
        add("afghanistan", 33.94, 67.71, "ASIA"); add("china", 35.86, 104.20, "ASIA");
        add("japan", 36.20, 138.25, "ASIA"); add("south korea", 35.91, 127.77, "ASIA");
        add("north korea", 40.34, 127.51, "ASIA"); add("indonesia", -0.79, 113.92, "ASIA");
        add("philippines", 12.88, 121.77, "ASIA"); add("myanmar", 21.92, 95.96, "ASIA");
        // 1.2/20/3-10 controlled Uganda / East Africa named-place index.
        add("jinja", 0.4244, 33.2042, "AFRICA"); add("mbarara", -0.6072, 30.6545, "AFRICA");
        add("gulu", 2.7746, 32.2990, "AFRICA"); add("mbale", 1.0806, 34.1750, "AFRICA");
        add("fort portal", 0.6710, 30.2750, "AFRICA"); add("masaka", -0.3338, 31.7341, "AFRICA");
        add("arua", 3.0201, 30.9111, "AFRICA"); add("lira", 2.2499, 32.8998, "AFRICA");
        add("soroti", 1.7146, 33.6111, "AFRICA"); add("kabale", -1.2486, 29.9899, "AFRICA");
        add("hoima", 1.4331, 31.3524, "AFRICA"); add("kasese", 0.1833, 30.0833, "AFRICA");
        add("moroto", 2.5345, 34.6666, "AFRICA"); add("kampala international airport", 0.0512, 32.4637, "AFRICA");
        add("entebbe international airport", 0.0424, 32.4435, "AFRICA");
        add("nairobi", -1.2864, 36.8172, "AFRICA"); add("mombasa", -4.0435, 39.6682, "AFRICA");
        add("kisumu", -0.0917, 34.7680, "AFRICA"); add("dar es salaam", -6.7924, 39.2083, "AFRICA");
        add("arusha", -3.3869, 36.6830, "AFRICA"); add("kigali", -1.9441, 30.0619, "AFRICA");
        add("bujumbura", -3.3614, 29.3599, "AFRICA"); add("juba", 4.8594, 31.5713, "AFRICA");
        add("australia", -25.27, 133.78, "OCEANIA"); add("new zealand", -40.90, 174.89, "OCEANIA");
    }

    private GeoIndex() {}

    private static void add(String name, double latitude, double longitude, String region) {
        COUNTRIES.put(name, new Point(latitude, longitude, region));
    }

    public static Point find(String countryOrText) {
        if (countryOrText == null) {
            return null;
        }
        String normalized = countryOrText.toLowerCase(Locale.ROOT);
        Point exact = COUNTRIES.get(normalized.trim());
        if (exact != null) {
            return exact;
        }
        for (Map.Entry<String, Point> entry : COUNTRIES.entrySet()) {
            if (normalized.contains(entry.getKey())) {
                return entry.getValue();
            }
        }
        return null;
    }

    /** News resolver: named city/town/airport only; country-only mentions do not create a marker. */
    public static Point findSpecific(String text) {
        if (text == null) return null;
        String normalized=text.toLowerCase(Locale.ROOT);
        String[] places={"entebbe international airport","kampala international airport","fort portal",
                "dar es salaam","kampala","entebbe","jinja","mbarara","gulu","mbale","masaka","arua",
                "lira","soroti","kabale","hoima","kasese","moroto","nairobi","mombasa","kisumu",
                "arusha","kigali","bujumbura","juba"};
        for(String place:places) if(normalized.contains(place)) return COUNTRIES.get(place);
        return null;
    }

    /** Exact built-in matches make common searches useful before any network request finishes. */
    public static Point findExact(String place) {
        if (place == null) return null;
        return COUNTRIES.get(place.toLowerCase(Locale.ROOT).trim());
    }
}
