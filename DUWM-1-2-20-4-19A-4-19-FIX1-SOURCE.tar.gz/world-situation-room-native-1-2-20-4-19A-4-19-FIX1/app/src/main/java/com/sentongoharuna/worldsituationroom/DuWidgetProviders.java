package com.sentongoharuna.worldsituationroom;

/** Manifest-addressable provider classes kept together to make the widget suite auditable. */
public final class DuWidgetProviders {
    private DuWidgetProviders() { }

    public static final class AlertBeacon extends BaseSituationWidgetProvider {
        @Override protected DuWidgetContract.Kind kind() { return DuWidgetContract.Kind.ALERT; }
    }

    public static final class LiveCounters extends BaseSituationWidgetProvider {
        @Override protected DuWidgetContract.Kind kind() { return DuWidgetContract.Kind.COUNTERS; }
    }

    public static final class LocalWatch extends BaseSituationWidgetProvider {
        @Override protected DuWidgetContract.Kind kind() { return DuWidgetContract.Kind.LOCAL; }
    }

    public static final class BreakingWire extends BaseSituationWidgetProvider {
        @Override protected DuWidgetContract.Kind kind() { return DuWidgetContract.Kind.WIRE; }
    }

    public static final class AirSeaTracker extends BaseSituationWidgetProvider {
        @Override protected DuWidgetContract.Kind kind() { return DuWidgetContract.Kind.AIR_SEA; }
    }

    public static final class HazardsWeather extends BaseSituationWidgetProvider {
        @Override protected DuWidgetContract.Kind kind() { return DuWidgetContract.Kind.HAZARDS; }
    }

    public static final class MediaWatch extends BaseSituationWidgetProvider {
        @Override protected DuWidgetContract.Kind kind() { return DuWidgetContract.Kind.MEDIA; }
    }

    public static final class WorldPulse extends BaseSituationWidgetProvider {
        @Override protected DuWidgetContract.Kind kind() { return DuWidgetContract.Kind.WORLD_PULSE; }
    }

    public static final class OrbitWatch extends BaseSituationWidgetProvider {
        @Override protected DuWidgetContract.Kind kind() { return DuWidgetContract.Kind.ORBIT_WATCH; }
    }

    public static final class SourceMatrix extends BaseSituationWidgetProvider {
        @Override protected DuWidgetContract.Kind kind() { return DuWidgetContract.Kind.SOURCE_MATRIX; }
    }

    public static final class MonitorStories extends BaseSituationWidgetProvider {
        @Override protected DuWidgetContract.Kind kind() { return DuWidgetContract.Kind.MONITOR_STORIES; }
    }

    public static final class LocalNews extends BaseSituationWidgetProvider {
        @Override protected DuWidgetContract.Kind kind() { return DuWidgetContract.Kind.LOCAL_NEWS; }
    }

    public static final class CommandCentre extends BaseSituationWidgetProvider {
        @Override protected DuWidgetContract.Kind kind() { return DuWidgetContract.Kind.COMMAND; }
    }
}
