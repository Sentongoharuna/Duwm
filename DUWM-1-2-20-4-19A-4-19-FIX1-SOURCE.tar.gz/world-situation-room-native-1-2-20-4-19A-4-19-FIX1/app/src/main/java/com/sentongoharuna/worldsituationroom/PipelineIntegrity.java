package com.sentongoharuna.worldsituationroom;

import java.util.*;

/** 1.2/20/2-19 non-UI integrity checks for source -> record -> canonical object pipeline. */
public final class PipelineIntegrity {
    private PipelineIntegrity() { }

    public static List<String> inspect(List<Signal> values) {
        ArrayList<String> failures = new ArrayList<>();
        if (values == null) return failures;
        HashSet<String> canonical = new HashSet<>();
        for (Signal s : values) {
            if (s == null) { failures.add("NULL_SIGNAL"); continue; }
            if (s.providerId == null || s.providerId.isEmpty()) failures.add("NO_PROVIDER:" + s.id);
            if (s.canonicalId == null || s.canonicalId.isEmpty()) failures.add("NO_CANONICAL:" + s.id);
            else if (!canonical.add(s.canonicalId)) failures.add("DUP_CANONICAL:" + s.canonicalId);
            if (s.originalRecord == null || !s.originalRecord.matches(s))
                failures.add("BROKEN_ORIGINAL:" + s.id);
            if (s.timestampChain == null) failures.add("NO_TIME_CHAIN:" + s.id);
            if (s.coordinateProvenance == null) failures.add("NO_COORDINATE_PROVENANCE:" + s.id);
            if (s.nativePayload == null) failures.add("NO_NATIVE_PAYLOAD:" + s.id);
            if (s.freshness == null) failures.add("NO_FRESHNESS:" + s.id);
        }
        return failures;
    }

    public static boolean healthy(List<Signal> values) { return inspect(values).isEmpty(); }
}
