package com.sentongoharuna.worldsituationroom;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 1.2/20/2-8 in-place canonical object registry.
 * One canonicalId owns one current provider record. Refresh replaces data for that identity,
 * never creates duplicate logical Globe objects.
 */
public final class CanonicalObjectRegistry {
    private static final int MAX = 25000;
    private final LinkedHashMap<String, Signal> current =
            new LinkedHashMap<String, Signal>(512, .75f, true) {
                @Override protected boolean removeEldestEntry(Map.Entry<String, Signal> eldest) {
                    return size() > MAX;
                }
            };

    public synchronized List<Signal> merge(List<Signal> incoming) {
        ArrayList<Signal> out = new ArrayList<>();
        if (incoming == null) return out;
        List<Signal> deduplicated = CanonicalRecordDeduplicator.deduplicate(incoming);
        LinkedHashMap<String, Signal> thisRefresh = new LinkedHashMap<>();
        for (Signal next : deduplicated) {
            if (next == null || next.canonicalId == null || next.canonicalId.isEmpty()) continue;
            Signal previous = current.get(next.canonicalId);
            if (previous != null && previous.timestampChain != null && next.timestampChain != null) {
                // Preserve the true first-seen time across replacement instances.
                next.timestampChain = new RecordTimestampChain(
                        next.timestampChain.providerTimeMs,
                        previous.timestampChain.firstSeenMs,
                        next.timestampChain.fetchedAtMs,
                        previous.timestampChain.renderedAtMs);
            }
            current.put(next.canonicalId, next);
            thisRefresh.put(next.canonicalId, next);
        }
        out.addAll(thisRefresh.values());
        return out;
    }

    public synchronized Signal get(String canonicalId) {
        return canonicalId == null ? null : current.get(canonicalId);
    }

    public synchronized int size() { return current.size(); }
}
