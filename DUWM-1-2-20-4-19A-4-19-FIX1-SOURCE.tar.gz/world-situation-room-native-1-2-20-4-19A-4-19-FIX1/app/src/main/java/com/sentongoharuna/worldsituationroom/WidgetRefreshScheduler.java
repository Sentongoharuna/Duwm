package com.sentongoharuna.worldsituationroom;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;

/** Network-aware refresh scheduling. Android may batch work to protect battery. */
public final class WidgetRefreshScheduler {
    private static final int PERIODIC_JOB_ID = 25001;
    private static final int IMMEDIATE_JOB_ID = 25002;
    private static final int FAST_NEWS_JOB_ID = 25003;
    private static final long MINIMUM_PERIOD_MS = 30L * 60L * 1000L;

    private WidgetRefreshScheduler() { }

    public static void schedulePeriodic(Context context) {
        Context app = context.getApplicationContext();
        JobScheduler scheduler = (JobScheduler) app.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (scheduler == null) return;
        JobInfo job = new JobInfo.Builder(PERIODIC_JOB_ID,
                new ComponentName(app, WidgetRefreshJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setPeriodic(MINIMUM_PERIOD_MS)
                .build();
        scheduler.schedule(job);
        JobInfo fast = new JobInfo.Builder(FAST_NEWS_JOB_ID,
                new ComponentName(app, WidgetRefreshJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_UNMETERED)
                .setRequiresCharging(true)
                .setPersisted(true)
                .setPeriodic(15L * 60L * 1000L)
                .build();
        scheduler.schedule(fast);
    }

    public static void scheduleImmediate(Context context) {
        Context app = context.getApplicationContext();
        JobScheduler scheduler = (JobScheduler) app.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (scheduler == null) return;
        JobInfo job = new JobInfo.Builder(IMMEDIATE_JOB_ID,
                new ComponentName(app, WidgetRefreshJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setMinimumLatency(0L)
                .setOverrideDeadline(4_000L)
                .build();
        scheduler.schedule(job);
    }

    public static void cancel(Context context) {
        JobScheduler scheduler = (JobScheduler) context.getSystemService(
                Context.JOB_SCHEDULER_SERVICE);
        if (scheduler == null) return;
        scheduler.cancel(PERIODIC_JOB_ID);
        scheduler.cancel(IMMEDIATE_JOB_ID);
        scheduler.cancel(FAST_NEWS_JOB_ID);
    }

    private static void cancelPeriodic(Context context) {
        JobScheduler scheduler = (JobScheduler) context.getSystemService(
                Context.JOB_SCHEDULER_SERVICE);
        if (scheduler != null) scheduler.cancel(PERIODIC_JOB_ID);
    }
}
