package com.sentongoharuna.worldsituationroom;
import android.content.Context;
public final class AppContextHolder { private static Context c; private AppContextHolder(){} static void set(Context x){c=x.getApplicationContext();} public static Context get(){return c;} }
