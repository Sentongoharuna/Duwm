package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class NewsSignals{
 private NewsSignals(){}
 public static List<Signal> from(List<NewsItem> items){
  ArrayList<Signal>o=new ArrayList<>();if(items==null)return o;
  for(NewsItem n:items){
   Map<String,String>f=new LinkedHashMap<>();
   f.put("NEWS ID",n.id);f.put("SOURCE ID",n.sourceId);f.put("OUTLET",n.sourceName);
   f.put("REGION",n.region);f.put("LANGUAGE",n.language);f.put("TOPIC",n.topic);
   f.put("CLUSTER ID",n.clusterId);f.put("IMAGE",n.imageUrl);f.put("ARTICLE URL",n.link);
   f.put("PUBLISHED AT",String.valueOf(n.publishedAt));f.put("FIRST SEEN AT",String.valueOf(n.firstSeenAt));
   f.put("ALSO REPORTED BY",android.text.TextUtils.join(", ",n.alsoReportedBy));
   f.put("BREAKING",String.valueOf(n.isBreaking));f.put("READ",String.valueOf(n.isRead));f.put("NOTIFIED",String.valueOf(n.isNotified));
   GeoIndex.Point p=GeoIndex.findSpecific(n.title+" "+n.summary+" "+n.region);
   double lat=p==null?Double.NaN:p.latitude,lon=p==null?Double.NaN:p.longitude;
   Signal s=new Signal("news-"+n.id,Signal.Layer.NEWS,n.title,n.summary,lat,lon,0,n.publishedAt,n.sourceName,n.link,
     Signal.Credibility.PUBLIC_SOURCE,n.isBreaking?"BREAKING":NewsTopics.existingType(n),n.region,n.isBreaking?4:2,f);
   // F9 cluster is an explicit cross-source relationship; canonical identity remains outlet/record specific.
   if(n.clusterId!=null&&!n.clusterId.trim().isEmpty())s.relationshipId=CrossSourceRelationship.id(s);
   o.add(s);
  }
  return o;
 }
}
