package com.sentongoharuna.worldsituationroom;
public final class NewsSource {
 public enum Region { UGANDA, EAST_AFRICA, WORLD }
 public enum Category { GENERAL, BUSINESS, SPORTS, ENTERTAINMENT, TECH, BROADCAST, GOVERNMENT }
 public enum Language { EN, LG }
 public final String id,name,homepageUrl,feedUrl; public final Region region; public final Category category; public final Language language; public final boolean enabledByDefault;
 public NewsSource(String id,String name,String home,String feed,Region region,Category category,Language language,boolean enabled){this.id=id;this.name=name;this.homepageUrl=home;this.feedUrl=feed;this.region=region;this.category=category;this.language=language;this.enabledByDefault=enabled;}
}
