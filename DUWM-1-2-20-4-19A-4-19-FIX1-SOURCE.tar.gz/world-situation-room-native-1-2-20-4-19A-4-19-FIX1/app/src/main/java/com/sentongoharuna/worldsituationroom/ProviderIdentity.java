package com.sentongoharuna.worldsituationroom;

import java.util.Locale;

/**
 * 1.2/20/2-2 provider identity authority.
 * Keeps a stable machine providerId while preserving the provider's human display name.
 */
public final class ProviderIdentity {
    private ProviderIdentity() { }

    public static String id(String providerName) {
        String v = providerName == null ? "" : providerName.trim().toLowerCase(Locale.ROOT);
        if (v.isEmpty()) return "unknown";
        if (v.contains("opensky")) return "opensky";
        if (v.contains("u.s. geological") || v.equals("usgs")) return "usgs";
        if (v.contains("c elestrak")) return "celestrak"; // defensive typo alias
        if (v.contains("celestrak")) return "celestrak";
        if (v.contains("rainviewer")) return "rainviewer";
        if (v.contains("nasa")) return "nasa";
        if (v.contains("coingecko")) return "coingecko";
        if (v.contains("ourairports")) return "ourairports";
        return slug(v);
    }

    private static String slug(String value) {
        String out = value.replaceAll("[^a-z0-9]+", "-").replaceAll("(^-+|-+$)", "");
        return out.isEmpty() ? "unknown" : out;
    }
}
