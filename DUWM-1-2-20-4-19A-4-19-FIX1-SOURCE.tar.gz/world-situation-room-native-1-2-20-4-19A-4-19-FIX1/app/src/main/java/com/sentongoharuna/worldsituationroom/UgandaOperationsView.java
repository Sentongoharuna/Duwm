package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4.19A/4.11 deep Uganda operations snapshot over worldwide canonical records. */
public final class UgandaOperationsView {
 public static final class ChangeItem {
  public final Signal signal; public final LiveChangeRegistry.Change change;
  ChangeItem(Signal s,LiveChangeRegistry.Change c){signal=s;change=c;}
 }
 public static final class Snapshot {
  public final List<Signal> records; public final List<ChangeItem> latestChanges;
  public final Map<Signal.Layer,Integer> layers; public final Map<String,Integer> freshness;
  public final int providerCount,liveFreshCount,watchedCount,changeCount,nearBorderCount;
  Snapshot(List<Signal>r,List<ChangeItem>c,Map<Signal.Layer,Integer>l,Map<String,Integer>f,int p,int lf,int w,int cc,int nb){
   records=Collections.unmodifiableList(r);latestChanges=Collections.unmodifiableList(c);layers=Collections.unmodifiableMap(l);
   freshness=Collections.unmodifiableMap(f);providerCount=p;liveFreshCount=lf;watchedCount=w;changeCount=cc;nearBorderCount=nb;
  }
 }
 public static Snapshot build(Collection<List<Signal>> all,CanonicalWatchStore watch,LiveChangeRegistry changes,int limit){
  ArrayList<Signal>records=new ArrayList<>();ArrayList<ChangeItem>latest=new ArrayList<>();HashSet<String>seen=new HashSet<>(),providers=new HashSet<>();
  EnumMap<Signal.Layer,Integer>counts=new EnumMap<>(Signal.Layer.class);LinkedHashMap<String,Integer>freshness=new LinkedHashMap<>();
  int fresh=0,watched=0,changed=0,nearBorder=0;
  if(all!=null)for(List<Signal>list:all)if(list!=null)for(Signal s:list){
   if(s==null||s.canonicalId==null||!seen.add(s.canonicalId))continue;
   RegionalPriorityEngine.Result rr=RegionalPriorityEngine.evaluate(s);
   if(rr.band==RegionalPriorityEngine.Band.UGANDA_BORDER){nearBorder++;continue;}
   if(rr.band!=RegionalPriorityEngine.Band.UGANDA)continue;
   records.add(s);providers.add(s.providerId);counts.put(s.layer,counts.getOrDefault(s.layer,0)+1);
   String fs=s.freshness==null?"UNKNOWN":s.freshness.state.name();freshness.put(fs,freshness.getOrDefault(fs,0)+1);
   if(s.freshness!=null&&(s.freshness.state==ObjectFreshness.State.LIVE||s.freshness.state==ObjectFreshness.State.FRESH))fresh++;
   if(watch!=null&&watch.watched(s.canonicalId))watched++;
   if(changes!=null){List<LiveChangeRegistry.Change>cs=changes.changesFor(s.canonicalId);if(!cs.isEmpty()){changed++;latest.add(new ChangeItem(s,cs.get(0)));}}
  }
  records.sort((a,b)->Long.compare(b.timestampMs,a.timestampMs));
  latest.sort((a,b)->Long.compare(b.change.detectedAtMs,a.change.detectedAtMs));
  if(records.size()>limit)records=new ArrayList<>(records.subList(0,limit));
  if(latest.size()>12)latest=new ArrayList<>(latest.subList(0,12));
  return new Snapshot(records,latest,new EnumMap<>(counts),freshness,providers.size(),fresh,watched,changed,nearBorder);
 }
}