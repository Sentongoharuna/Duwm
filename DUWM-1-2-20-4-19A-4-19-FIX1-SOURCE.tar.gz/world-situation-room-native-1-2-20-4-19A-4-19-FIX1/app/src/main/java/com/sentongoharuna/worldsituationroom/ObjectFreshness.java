package com.sentongoharuna.worldsituationroom;

/**
 * 1.2/20/2-5 canonical freshness derived from provider age + provider feed state.
 * Retained objects never become LIVE merely because the UI rendered again.
 */
public final class ObjectFreshness {
    public enum State { LIVE, FRESH, AGING, STALE, LAST_GOOD, OFFLINE, UNKNOWN }

    public final State state;
    public final long ageMs;

    private ObjectFreshness(State state, long ageMs) {
        this.state = state;
        this.ageMs = ageMs;
    }

    public static ObjectFreshness evaluate(
            RecordTimestampChain chain, FeedStatus status, long now) {
        return evaluate(null, chain, status, now);
    }

    /** 1.2/20/3-13 provider/type-specific freshness windows. */
    public static ObjectFreshness evaluate(
            Signal.Layer layer, RecordTimestampChain chain, FeedStatus status, long now) {
        long age=chain==null?-1L:chain.providerAgeMs(now);
        if(status!=null&&status.state==FeedStatus.State.OFFLINE)
            return age>=0L?new ObjectFreshness(State.LAST_GOOD,age):new ObjectFreshness(State.OFFLINE,age);
        if(age<0L)return new ObjectFreshness(State.UNKNOWN,age);
        long live=liveMs(layer),fresh=freshMs(layer),aging=agingMs(layer);
        if(age<=live)return new ObjectFreshness(State.LIVE,age);
        if(age<=fresh)return new ObjectFreshness(State.FRESH,age);
        if(age<=aging)return new ObjectFreshness(State.AGING,age);
        return new ObjectFreshness(State.STALE,age);
    }

    private static long liveMs(Signal.Layer l){
        if(l==Signal.Layer.FLIGHTS||l==Signal.Layer.SHIPS)return 2L*60L*1000L;
        if(l==Signal.Layer.SATELLITES)return 30L*1000L;
        if(l==Signal.Layer.WEATHER)return 15L*60L*1000L;
        if(l==Signal.Layer.NEWS)return 15L*60L*1000L;
        if(l==Signal.Layer.NATURAL)return 10L*60L*1000L;
        return 5L*60L*1000L;
    }
    private static long freshMs(Signal.Layer l){
        if(l==Signal.Layer.FLIGHTS||l==Signal.Layer.SHIPS)return 10L*60L*1000L;
        if(l==Signal.Layer.SATELLITES)return 2L*60L*1000L;
        if(l==Signal.Layer.WEATHER)return 30L*60L*1000L;
        if(l==Signal.Layer.NEWS)return 2L*60L*60L*1000L;
        if(l==Signal.Layer.NATURAL)return 60L*60L*1000L;
        return 30L*60L*1000L;
    }
    private static long agingMs(Signal.Layer l){
        if(l==Signal.Layer.FLIGHTS||l==Signal.Layer.SHIPS)return 30L*60L*1000L;
        if(l==Signal.Layer.SATELLITES)return 10L*60L*1000L;
        if(l==Signal.Layer.WEATHER)return 2L*60L*60L*1000L;
        if(l==Signal.Layer.NEWS)return 12L*60L*60L*1000L;
        if(l==Signal.Layer.NATURAL)return 24L*60L*60L*1000L;
        return 2L*60L*60L*1000L;
    }

    public String ageText() {
        if (ageMs < 0L) return "TIME UNKNOWN";
        long min = ageMs / 60000L;
        if (min < 1L) return "NOW";
        if (min < 60L) return min + "m";
        long h = min / 60L;
        return h < 48L ? h + "h" : (h / 24L) + "d";
    }
}
