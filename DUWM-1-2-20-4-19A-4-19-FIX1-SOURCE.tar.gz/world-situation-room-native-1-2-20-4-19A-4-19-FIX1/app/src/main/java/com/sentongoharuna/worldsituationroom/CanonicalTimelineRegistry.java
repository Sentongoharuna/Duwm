package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Bounded observation timeline keyed by canonical identity. Only provider records are stored. */
public final class CanonicalTimelineRegistry {
 public static final class Entry {
  public final long providerTimeMs,firstSeenMs,fetchedAtMs;
  public final double latitude,longitude;
  public final String state,summary;
  Entry(Signal s){
   providerTimeMs=s.timestampChain==null?s.timestampMs:s.timestampChain.providerTimeMs;
   firstSeenMs=s.timestampChain==null?0L:s.timestampChain.firstSeenMs;
   fetchedAtMs=s.timestampChain==null?0L:s.timestampChain.fetchedAtMs;
   latitude=s.latitude;longitude=s.longitude;
   state=s.freshness==null?"UNKNOWN":s.freshness.state.name();
   summary=s.layer==Signal.Layer.FLIGHTS
    ? fact(s,"ALTITUDE")+" • "+fact(s,"SPEED")
    : s.title;
  }
  private static String fact(Signal s,String k){String v=s.facts.get(k);return v==null?"Not reported":v;}
 }
 private final LinkedHashMap<String,ArrayDeque<Entry>> histories=new LinkedHashMap<>(128,0.75f,true);
 private static final int MAX=24;
 public synchronized void accept(List<Signal> values){
  if(values==null)return;
  for(Signal s:values){
   if(s==null||s.canonicalId==null||s.canonicalId.isEmpty())continue;
   ArrayDeque<Entry> h=histories.get(s.canonicalId);
   if(h==null){h=new ArrayDeque<>();histories.put(s.canonicalId,h);}
   Entry e=new Entry(s);Entry last=h.peekLast();
   if(last==null||e.providerTimeMs>last.providerTimeMs
      ||e.providerTimeMs==last.providerTimeMs&&(e.latitude!=last.latitude||e.longitude!=last.longitude)){
    h.addLast(e);while(h.size()>MAX)h.removeFirst();
   }
  }
  while(histories.size()>512){Iterator<String>i=histories.keySet().iterator();if(!i.hasNext())break;i.next();i.remove();}
 }
 public synchronized List<Entry> timeline(String canonicalId){
  ArrayDeque<Entry>h=histories.get(canonicalId);
  if(h==null)return Collections.emptyList();
  ArrayList<Entry>out=new ArrayList<>(h);Collections.reverse(out);return out;
 }
}
