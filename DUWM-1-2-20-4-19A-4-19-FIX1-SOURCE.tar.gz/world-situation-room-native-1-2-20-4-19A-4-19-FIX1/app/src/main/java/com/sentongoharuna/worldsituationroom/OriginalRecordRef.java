package com.sentongoharuna.worldsituationroom;

/**
 * 1.2/20/2-3 immutable provenance pointer.
 * It references the exact provider-native record that produced a Globe Signal.
 * No title, coordinate or UI text is used as record identity.
 */
public final class OriginalRecordRef {
    public final String providerId;
    public final String providerName;
    public final Signal.Layer layer;
    public final String providerRecordId;
    public final String canonicalId;
    public final long providerTimestampMs;
    public final CoordinateProvenance.Origin coordinateOrigin;

    public OriginalRecordRef(
            String providerId,
            String providerName,
            Signal.Layer layer,
            String providerRecordId,
            String canonicalId,
            long providerTimestampMs,
            CoordinateProvenance.Origin coordinateOrigin) {
        this.providerId = providerId == null ? "unknown" : providerId;
        this.providerName = providerName == null ? "" : providerName;
        this.layer = layer;
        this.providerRecordId = providerRecordId == null ? "" : providerRecordId;
        this.canonicalId = canonicalId == null ? "" : canonicalId;
        this.providerTimestampMs = providerTimestampMs;
        this.coordinateOrigin = coordinateOrigin == null
                ? CoordinateProvenance.Origin.UNAVAILABLE : coordinateOrigin;
    }

    public boolean matches(Signal signal) {
        return signal != null
                && canonicalId.equals(signal.canonicalId)
                && providerRecordId.equals(signal.id)
                && providerId.equals(signal.providerId);
    }
}
