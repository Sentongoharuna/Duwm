package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4.19A/4.7 auditable meaningful-change timeline with deltas, lifecycle and grouped counts. */
public final class LiveChangeTimeline {
 public static final class Entry {
  public final LiveChangeRegistry.Kind kind; public final long detectedAtMs; public final String detail,previousValue,currentValue;
  public final long providerDeltaMs;
  Entry(LiveChangeRegistry.Change c){kind=c.kind;detectedAtMs=c.detectedAtMs;detail=c.detail;previousValue=c.previousValue;currentValue=c.currentValue;providerDeltaMs=c.providerDeltaMs;}
 }
 public static final class Snapshot {
  public final List<Entry> entries; public final Map<LiveChangeRegistry.Kind,Integer> counts;
  public final LiveChangeRegistry.Lifecycle lifecycle; public final long spanMs; public final int totalChanges;
  Snapshot(List<Entry>e,Map<LiveChangeRegistry.Kind,Integer>c,LiveChangeRegistry.Lifecycle l,long s,int t){
   entries=Collections.unmodifiableList(e);counts=Collections.unmodifiableMap(c);lifecycle=l;spanMs=s;totalChanges=t;
  }
 }
 public static Snapshot snapshot(LiveChangeRegistry registry,String canonicalId,int limit){
  if(registry==null||canonicalId==null||canonicalId.isEmpty())return new Snapshot(Collections.emptyList(),new EnumMap<>(LiveChangeRegistry.Kind.class),null,0,0);
  List<LiveChangeRegistry.Change> changes=registry.changesFor(canonicalId);ArrayList<Entry>out=new ArrayList<>();
  EnumMap<LiveChangeRegistry.Kind,Integer>counts=new EnumMap<>(LiveChangeRegistry.Kind.class);
  long newest=0,oldest=Long.MAX_VALUE;
  for(LiveChangeRegistry.Change c:changes){
   if(c==null)continue;counts.put(c.kind,counts.getOrDefault(c.kind,0)+1);newest=Math.max(newest,c.detectedAtMs);oldest=Math.min(oldest,c.detectedAtMs);
   if(out.size()<limit)out.add(new Entry(c));
  }
  long span=oldest==Long.MAX_VALUE?0:Math.max(0,newest-oldest);
  return new Snapshot(out,new EnumMap<>(counts),registry.lifecycleFor(canonicalId),span,changes.size());
 }
 public static List<Entry> forObject(LiveChangeRegistry registry,String canonicalId,int limit){return snapshot(registry,canonicalId,limit).entries;}
 public static String transitionSummary(List<Entry> entries){
  if(entries==null||entries.isEmpty())return "NO MATERIAL CHANGE DETECTED";
  EnumMap<LiveChangeRegistry.Kind,Integer>counts=new EnumMap<>(LiveChangeRegistry.Kind.class);
  for(Entry e:entries)counts.put(e.kind,counts.getOrDefault(e.kind,0)+1);
  StringBuilder b=new StringBuilder();for(Map.Entry<LiveChangeRegistry.Kind,Integer>e:counts.entrySet()){if(b.length()>0)b.append(" • ");b.append(e.getKey().name()).append(" ").append(e.getValue());}return b.toString();
 }
}