# F19/20 — Functional Tap Gate
The gate checks visible core controls against real action handlers rather than checking only that Java compiles.
It covers Globe, Monitors, F9 News, country/time controls, unified search result routing, exact detail, article open, share, mark-read, hide-outlet, follow-topic and globe routing.
REGION/REPLAY duplicate dock controls remain forbidden.
