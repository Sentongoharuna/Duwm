# 1.2/20/2 — 8/20 In-place Object Updates
CanonicalObjectRegistry now owns the current provider record for each canonicalId.
A refresh replaces telemetry/content for the same logical object instead of creating a duplicate.
The true first-seen timestamp is preserved across replacement Signal instances.
SatelliteMapView merges through this registry before creating its render snapshot, and followed
objects resolve through canonical identity first.
No UI, navigation, provider endpoint, F9 catalog or Globe styling changes.
