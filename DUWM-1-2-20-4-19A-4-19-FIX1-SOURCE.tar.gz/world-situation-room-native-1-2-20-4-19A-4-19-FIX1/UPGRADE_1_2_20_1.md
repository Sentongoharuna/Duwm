# 1-20 / 1.2 / 20 / 1 — Live Object Refresh + Functional Foundation
Built directly on the uploaded F20 Full Functional Green source.

- Preserves the approved Globe UI.
- Provider callbacks update the existing render snapshot in place.
- Camera, zoom, selected/followed object and active layers are not reset by refresh.
- Unchanged snapshots do not trigger redundant full redraws.
- OFFLINE/DELAYED/KEY_REQUIRED callbacks retain last-good objects while their status remains explicit.
- Empty LIVE/READY responses remain honest empty results.
- Existing mission controls retain real handlers.
- The F9 Uganda/East Africa source catalog is regression-gated.
