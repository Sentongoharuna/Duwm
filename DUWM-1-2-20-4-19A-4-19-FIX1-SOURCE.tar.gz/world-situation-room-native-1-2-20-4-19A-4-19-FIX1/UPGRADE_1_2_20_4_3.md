# 1.2/20/4 — 3/20 Geographic Activity Zones
Built on 4-2. DUWM now detects observational concentrations from current located canonical provider records.
A zone requires at least four located objects within 75 km of a seed and reports centroid, observed radius,
object count, active layer count and dominant layer. The selected object's Intelligence Sheet shows the nearest
zone only when its center is within 150 km. This is density context, not an incident declaration or risk claim.
No new page and no invented coordinates.
