# 1.2/20/2 — 5/20 Freshness State
Canonical objects now expose LIVE / FRESH / DELAYED / STALE / OFFLINE / UNKNOWN.
The classification uses provider timestamp age and actual FeedStatus.
Render/fetch time never makes an old retained record look live.
No UI, provider endpoint, navigation, F9 catalog or Globe styling changes.
