# 1.2/20/3 — 1/20 Universal Globe Object Tap
All rendered located Signals now use one exact-record tap router.
A single hit routes directly. Overlapping canonical objects are deduplicated, distance-sorted,
and shown in a compact chooser so the user selects the intended object.
NEWS and Local Monitor keep their exact existing detail routes; all other object types use exact Signal detail.
No Globe geometry, provider, F9 catalogue, Fusion, navigation or branding redesign.
