# 1.2/20/2 — 3/20 Original Record Reference
Every Signal now carries an immutable OriginalRecordRef containing providerId, providerName,
layer, provider-native record id, canonical object id and provider timestamp.

OriginalRecordResolver resolves that reference against the current provider record set.
Globe follow refresh can resolve by canonical ID while retaining legacy native-ID fallback.
No UI, source endpoint, F9 catalog, Globe styling or navigation is changed.
