#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";B="$J/SituationBriefGenerator.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-19A-4-16-live-search-deepening.sh" "$P"
grep -F 'structured factual situation brief from current canonical provider records only' "$B" >/dev/null
for x in 'WHAT IS CURRENT' 'WHAT CHANGED' 'WHAT IS WATCHED' 'REGIONAL / LAYER ACTIVITY' 'PROVIDER STATUS' 'IMPORTANT LIMITATIONS'; do grep -F "$x" "$M" >/dev/null; done
grep -F 'MISSING WATCHED IDENTITIES' "$M" >/dev/null
grep -F 'MISSING DATA MAY REFLECT PROVIDER LOSS' "$M" >/dev/null
grep -F 'FACTUAL SNAPSHOT • TRACEABLE COUNTS • NO UNSOURCED CONCLUSION' "$M" >/dev/null
echo "1.2/20/4.19A/4.17 SITUATION BRIEF DEEPENING PASS"
