#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$J/MainActivity.java";V="$J/SatelliteMapView.java"

# Cumulative /3 functionality through 18.
"$P/scripts/verify-1-2-20-3-18-object-share-card-2.sh" "$P"

# Universal render -> tap -> exact record.
grep -F 'onSignalTapCandidates(java.util.List<Signal> signals)' "$V" >/dev/null
grep -F 'routeUniversalGlobeTap(signal)' "$M" >/dev/null
grep -F 'Signal exact = resolveExactSignal(signal)' "$M" >/dev/null

# NEWS exact record and Local Monitor exact route.
grep -F 'showLocalNewsDetail(exactNews)' "$M" >/dev/null
grep -F 'openLocalMonitors(exact.id.substring' "$M" >/dev/null

# Generic detail actions must have real listeners.
grep -F 'sourceButton.setOnClickListener' "$M" >/dev/null
grep -F 'detailWatchButton.setOnClickListener' "$M" >/dev/null
grep -F 'detailShareButton.setOnClickListener' "$M" >/dev/null

# Back -> same Globe state.
grep -F 'restoreDetailReturnState()' "$M" >/dev/null
grep -F 'mapView.highlightSignal(s)' "$M" >/dev/null

# Aircraft follow/stop, trail and live refresh.
grep -F 'STOP FOLLOWING' "$M" >/dev/null
grep -F 'refreshTrackedAircraftSheet(trackedUpdate)' "$M" >/dev/null
grep -F 'drawObservedFixTrail' "$V" >/dev/null

# Object intelligence coverage.
for x in 'AIRCRAFT INTELLIGENCE' 'EVENT INTELLIGENCE' 'ORBIT INTELLIGENCE' 'WEATHER INTELLIGENCE' 'NEWS INTELLIGENCE' 'RELATED INTELLIGENCE' 'OBJECT TIMELINE' 'PROVIDER HEALTH' 'WATCH  ON'; do
  grep -F "$x" "$M" >/dev/null
done

# Search and overlap routes.
grep -F 'focusSearchObject(objectMatch)' "$M" >/dev/null
grep -F 'OBJECTS HERE • SELECT EXACT RECORD' "$M" >/dev/null

# Share provenance and truth labels.
grep -F 'CANONICAL OBJECT ID' "$M" >/dev/null
grep -F 'PROVIDER RECORD ID' "$M" >/dev/null
grep -F 'CALCULATED FROM PUBLIC ELEMENTS — NOT LIVE TELEMETRY' "$M" >/dev/null
grep -F 'RADAR HISTORY / OBSERVATION — NOT A FORECAST' "$M" >/dev/null

# F9 actions remain functional and SHOW ON GLOBE is disabled if unresolved.
grep -F 'String[] labels={"OPEN FULL ARTICLE","SHARE","MARK READ","HIDE THIS OUTLET","FOLLOW TOPIC","SHOW ON GLOBE"}' "$M" >/dev/null
grep -F 'if("SHOW ON GLOBE".equals(label))b.setEnabled(gp!=null)' "$M" >/dev/null

# Guard against visible action buttons with no listener in the primary detail action creation block.
python3 - "$M" <<'PY'
import sys,re
s=open(sys.argv[1],encoding="utf-8").read()
for name in ["sourceButton","detailWatchButton","detailShareButton"]:
    if name+".setOnClickListener" not in s:
        raise SystemExit("dead primary detail action: "+name)
print("PRIMARY DETAIL ACTION LISTENERS PASS")
PY

echo "1.2/20/3-19 OBJECT FUNCTIONAL GATE PASS"
