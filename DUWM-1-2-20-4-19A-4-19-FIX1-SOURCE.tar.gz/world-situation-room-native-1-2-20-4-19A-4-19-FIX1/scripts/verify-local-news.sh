#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-$(cd "$(dirname "$0")/.." && pwd)}"
APK="${2:-}"
J="$ROOT/app/src/main/java/com/sentongoharuna/worldsituationroom"
M="$ROOT/app/src/main/AndroidManifest.xml"
G="$ROOT/app/build.gradle.kts"

grep -F 'versionCode = 36' "$G" >/dev/null
grep -F 'versionName = "2026-local-news"' "$G" >/dev/null

# R31 feature contract, excluding only its old version lines.
for x in WorldPulse OrbitWatch SourceMatrix MonitorStories; do grep -F "class $x" "$J/DuWidgetProviders.java" >/dev/null; done
grep -F 'android:icon="@mipmap/ic_launcher"' "$M" >/dev/null
grep -F 'ShareCardProvider' "$M" >/dev/null
grep -F 'LocalMonitorActivity' "$M" >/dev/null

# Same baseline activity set: no LocalNewsActivity/new screen.
test "$(find "$J" -maxdepth 1 -name '*Activity.java' | wc -l)" -eq 4
for a in MainActivity NativeMediaActivity WidgetConfigActivity LocalMonitorActivity; do test -s "$J/$a.java"; done
test ! -e "$J/LocalNewsActivity.java"

# Exactly 12 widget receivers.
test "$(grep -c 'android:name=".DuWidgetProviders\$' "$M")" -eq 12

for f in NewsSource NewsSourceCatalog NewsItem NewsStore NewsAggregator NewsNotifier; do test -s "$J/$f.java"; done
grep -F 'android.permission.POST_NOTIFICATIONS' "$M" >/dev/null
grep -F 'CH_BREAKING="du_news_breaking"' "$J/NewsNotifier.java" >/dev/null
grep -F 'CH_LOCAL="du_news_local"' "$J/NewsNotifier.java" >/dev/null
grep -F 'CH_DIGEST="du_news_digest"' "$J/NewsNotifier.java" >/dev/null

CAT="$J/NewsSourceCatalog.java"
test "$(grep -c 'new NewsSource(' "$CAT")" -eq 43
grep -F 'watchdoguganda.com' "$CAT" >/dev/null
grep -F 'monitor.co.ug' "$CAT" >/dev/null
grep -F 'newvision.co.ug' "$CAT" >/dev/null
grep -F 'nilepost.co.ug' "$CAT" >/dev/null
grep -F 'chimpreports.com' "$CAT" >/dev/null
grep -F 'independent.co.ug' "$CAT" >/dev/null
grep -F 'observer.ug' "$CAT" >/dev/null
grep -F 'kampalapost.com' "$CAT" >/dev/null
grep -F 'pmldaily.com' "$CAT" >/dev/null
grep -F 'softpower.ug' "$CAT" >/dev/null
grep -F 'redpepper.co.ug' "$CAT" >/dev/null
grep -F 'dailyexpress.co.ug' "$CAT" >/dev/null
grep -F 'eagle.co.ug' "$CAT" >/dev/null
grep -F 'dispatch.ug' "$CAT" >/dev/null
grep -F 'thetowerpost.com' "$CAT" >/dev/null
grep -F 'ugandaradionetwork.net' "$CAT" >/dev/null
grep -F 'harunaenterprisesltd.com' "$CAT" >/dev/null
grep -F 'ntv.co.ug' "$CAT" >/dev/null
grep -F 'nbs.ug' "$CAT" >/dev/null
grep -F 'ubc.go.ug' "$CAT" >/dev/null
grep -F 'capitalfm.co.ug' "$CAT" >/dev/null
grep -F 'bukedde.co.ug' "$CAT" >/dev/null
grep -F 'businessfocus.co.ug' "$CAT" >/dev/null
grep -F 'ceo.co.ug' "$CAT" >/dev/null
grep -F 'ugbusiness.com' "$CAT" >/dev/null
grep -F 'kawowo.com' "$CAT" >/dev/null
grep -F 'bigeye.ug' "$CAT" >/dev/null
grep -F 'mbu.ug' "$CAT" >/dev/null
grep -F 'howwe.ug' "$CAT" >/dev/null
grep -F 'pulse.ug' "$CAT" >/dev/null
grep -F 'techjaja.com' "$CAT" >/dev/null
grep -F 'pctechmag.com' "$CAT" >/dev/null
grep -F 'dignited.com' "$CAT" >/dev/null
grep -F 'mediacentre.go.ug' "$CAT" >/dev/null
grep -F 'news.google.com/rss?hl=en-UG' "$CAT" >/dev/null
grep -F 'theeastafrican.co.ke' "$CAT" >/dev/null
grep -F 'nation.africa' "$CAT" >/dev/null
grep -F 'the-star.co.ke' "$CAT" >/dev/null
grep -F 'thecitizen.co.tz' "$CAT" >/dev/null
grep -F 'newtimes.co.rw' "$CAT" >/dev/null
grep -F 'news.google.com/rss?hl=en-KE' "$CAT" >/dev/null
grep -F 'feeds.bbci.co.uk' "$CAT" >/dev/null
grep -F 'aljazeera.com' "$CAT" >/dev/null

grep -F '"UGANDA"' "$J/MainActivity.java" >/dev/null
grep -F '"BREAKING"' "$J/MainActivity.java" >/dev/null
grep -F 'F9 / 20-REGION OPERATIONAL FEED' "$J/MainActivity.java" >/dev/null

# NEWS once in mission dock and directly after MONITORS.
test "$(grep -c 'addMissionAction(row, "NEWS"' "$J/MainActivity.java")" -eq 1
python3 - "$J/MainActivity.java" <<'PY'
import sys
s=open(sys.argv[1]).read()
a=s.index('addMissionAction(row, "MONITORS"')
b=s.index('addMissionAction(row, "NEWS"',a)
c=s.index('addMissionAction(row, "REGION"',b)
assert a < b < c
assert 'openCatalog("NEWS")' in s[b:c]
PY

grep -F 'Executors.newFixedThreadPool(4)' "$J/NewsAggregator.java" >/dev/null
grep -F 'sitemap:' "$J/NewsAggregator.java" >/dev/null
grep -F 'json:' "$J/NewsAggregator.java" >/dev/null
grep -F 'MAX_FEED_CHARS=5*1024*1024' "$J/RssParser.java" >/dev/null
grep -F 'MAX_AGE=7L*24*60*60*1000' "$J/NewsStore.java" >/dev/null
grep -F 'j.length()>=800' "$J/NewsStore.java" >/dev/null
grep -F 'setPeriodic(15L * 60L * 1000L)' "$J/WidgetRefreshScheduler.java" >/dev/null
grep -F 'MINIMUM_PERIOD_MS = 30L * 60L * 1000L' "$J/WidgetRefreshScheduler.java" >/dev/null
grep -F 'NewsAggregator(this).refresh' "$J/WidgetRefreshJobService.java" >/dev/null
grep -F 'Also reported by:' "$J/MainActivity.java" >/dev/null
grep -F 'OPEN FULL ARTICLE' "$J/MainActivity.java" >/dev/null
grep -F 'TURN ON NEWS ALERTS' "$J/MainActivity.java" >/dev/null
grep -F 'Offline — showing saved news' "$J/MainActivity.java" >/dev/null
grep -F 'Local News aggregator' "$J/MainActivity.java" >/dev/null

if grep -REn 'android\.webkit\.WebView|<WebView|loadUrl\(|okhttp3|okio/ByteString' "$ROOT/app/src/main"; then exit 1; fi
if grep -En '^[[:space:]]*(implementation|api)\(' "$G"; then exit 1; fi

if [[ -n "$APK" ]]; then
  test -s "$APK"
  test "$(head -c 2 "$APK")" = 'PK'
fi
echo 'LOCAL NEWS CONTRACT PASS'
