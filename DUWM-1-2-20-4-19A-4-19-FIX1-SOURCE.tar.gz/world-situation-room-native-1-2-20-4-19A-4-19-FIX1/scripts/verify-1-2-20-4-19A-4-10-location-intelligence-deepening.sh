#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";L="$J/LocationIntelligence.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-19A-4-9-news-event-linking-deepening.sh" "$P"
grep -F 'deep factual location snapshot: bands, freshness, providers, watch and changes' "$L" >/dev/null
grep -F 'KM_0_10, KM_10_25, KM_25_50, KM_50_100' "$L" >/dev/null
grep -F 'freshnessCounts' "$L" >/dev/null
grep -F 'nearestByLayer' "$L" >/dev/null
grep -F 'changedCount' "$L" >/dev/null
grep -F 'canonicalWatchStore,liveChangeRegistry,20' "$M" >/dev/null
grep -F 'UNIQUE CURRENT OBJECTS' "$M" >/dev/null
grep -F 'OBJECTS WITH CHANGES' "$M" >/dev/null
grep -F 'DISTANCE BANDS' "$M" >/dev/null
grep -F 'FRESHNESS COUNTS' "$M" >/dev/null
grep -F 'NEAREST BY LAYER' "$M" >/dev/null
grep -F 'LATEST CHANGE' "$M" >/dev/null
grep -F 'DENSITY/CHANGE/WATCH COUNTS ARE DESCRIPTIVE ONLY' "$M" >/dev/null
echo "1.2/20/4.19A/4.10 LOCATION INTELLIGENCE DEEPENING PASS"
