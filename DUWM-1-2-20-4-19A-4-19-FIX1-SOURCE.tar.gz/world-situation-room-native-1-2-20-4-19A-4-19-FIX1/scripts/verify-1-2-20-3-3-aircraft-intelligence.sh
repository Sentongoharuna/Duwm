#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$J/MainActivity.java";R="$J/WorldDataRepository.java"
grep -F 'provider-backed Aircraft Intelligence' "$M" >/dev/null
grep -F 'signal.layer != Signal.Layer.FLIGHTS' "$M" >/dev/null
for x in CALLSIGN ICAO24 'ORIGIN COUNTRY' ALTITUDE SPEED HEADING 'VERTICAL RATE' STATE 'AIRCRAFT CATEGORY' SQUAWK 'POSITION SOURCE' 'LAST CONTACT'; do grep -F "\"$x\"" "$M" >/dev/null; done
grep -F 'POSITION AGE' "$M" >/dev/null
grep -F 'Provider-returned fields only; airline, destination and flight number are not inferred' "$M" >/dev/null
# Prove these fields originate in the existing OpenSky provider parser.
for x in CALLSIGN ICAO24 'ORIGIN COUNTRY' ALTITUDE SPEED HEADING 'VERTICAL RATE' 'LAST CONTACT'; do grep -F "facts.put(\"$x\"" "$R" >/dev/null; done
grep -F 'signal.layer == Signal.Layer.FLIGHTS' "$M" >/dev/null
"$P/scripts/verify-1-2-20-3-2-object-intelligence-sheet.sh" "$P"
echo "1.2/20/3-3 AIRCRAFT INTELLIGENCE PASS"
