#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$J/MainActivity.java";H="$J/NewsSourceHealth.java"
grep -F 'provider health for the exact selected object' "$M" >/dev/null
for x in 'PROVIDER HEALTH' 'LAST CHECK/UPDATE' 'LATEST RECORD AGE' 'F9 SOURCE STATE' 'F9 LAST SUCCESS' 'F9 LAST CHECK'; do grep -F "$x" "$M" >/dev/null; done
grep -F 'feedStatuses.get(signal.layer)' "$M" >/dev/null
grep -F 'signal.timestampChain.providerTimeMs' "$M" >/dev/null
grep -F 'NewsSourceHealth.read(this,match)' "$M" >/dev/null
grep -F 'enum State{WORKING,UNAVAILABLE,CHECKING,STALE}' "$H" >/dev/null
"$P/scripts/verify-1-2-20-3-13-object-freshness-engine.sh" "$P"
echo "1.2/20/3-14 PROVIDER HEALTH FROM OBJECT PASS"
