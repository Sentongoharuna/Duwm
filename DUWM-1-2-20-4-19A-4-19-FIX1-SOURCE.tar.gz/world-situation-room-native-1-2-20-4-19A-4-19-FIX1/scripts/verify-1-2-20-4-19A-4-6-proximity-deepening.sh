#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";X="$J/ProximityIntelligence.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-19A-4-5-regional-priority-deepening.sh" "$P"
grep -F 'concentric-band proximity intelligence from current located canonical records only' "$X" >/dev/null
grep -F 'KM_0_10, KM_10_25, KM_25_50, KM_50_100, KM_100_150' "$X" >/dev/null
grep -F 'nearestByLayer' "$X" >/dev/null
grep -F 'providerCount' "$X" >/dev/null
grep -F 'ProximityIntelligence.snapshot(signal,layerSignals.values(),12)' "$M" >/dev/null
grep -F 'DISTANCE BANDS' "$M" >/dev/null
grep -F 'NEAREST BY LAYER' "$M" >/dev/null
grep -F 'UNIQUE NEARBY OBJECTS' "$M" >/dev/null
grep -F 'DISTANCE BAND ≠ RELATIONSHIP ≠ INCIDENT • CURRENT LOCATED RECORDS ONLY' "$M" >/dev/null
echo "1.2/20/4.19A/4.6 PROXIMITY INTELLIGENCE DEEPENING PASS"
