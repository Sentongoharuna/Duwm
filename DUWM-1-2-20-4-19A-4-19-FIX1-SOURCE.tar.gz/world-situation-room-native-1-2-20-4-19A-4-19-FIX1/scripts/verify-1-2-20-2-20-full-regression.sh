#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
# Run every cumulative 1.2/2 gate in order.
for s in \
 verify-1-2-20-2-1-canonical-object-id.sh \
 verify-1-2-20-2-2-provider-identity.sh \
 verify-1-2-20-2-3-original-record-reference.sh \
 verify-1-2-20-2-4-timestamp-chain.sh \
 verify-1-2-20-2-5-freshness-state.sh \
 verify-1-2-20-2-6-coordinate-provenance.sh \
 verify-1-2-20-2-7-type-specific-payload.sh \
 verify-1-2-20-2-8-in-place-object-updates.sh \
 verify-1-2-20-2-9-selection-persistence.sh \
 verify-1-2-20-2-10-last-good-record.sh \
 verify-1-2-20-2-11-provider-record-dedup.sh \
 verify-1-2-20-2-12-cross-source-relationship.sh \
 verify-1-2-20-2-13-f9-news-pipeline.sh \
 verify-1-2-20-2-14-f9-source-accountability.sh \
 verify-1-2-20-2-15-tap-exact-detail.sh \
 verify-1-2-20-2-16-detail-globe-round-trip.sh \
 verify-1-2-20-2-17-track-watch-canonical.sh \
 verify-1-2-20-2-18-share-provenance.sh \
 verify-1-2-20-2-19-pipeline-integrity.sh; do
  test -x "$P/scripts/$s" || chmod +x "$P/scripts/$s"
  "$P/scripts/$s" "$P"
done
# Frozen 1.2/1 protections remain.
"$P/scripts/verify-1-2-20-1-fix2.sh" "$P"
# Full F9 catalog remains at least the required 43 sources.
test "$(grep -c 'new NewsSource(' "$J/NewsSourceCatalog.java")" -ge 43
# No WebView/OkHttp/Okio dependency drift.
! grep -R -E 'android\.webkit\.WebView|okhttp3|okio\.' "$J"
# Existing Globe owner remains SatelliteMapView and MainActivity still wires it.
grep -F 'mapView = new SatelliteMapView(this)' "$J/MainActivity.java" >/dev/null
grep -F 'mapView.setSignals(mapSignals)' "$J/MainActivity.java" >/dev/null
echo "1.2/20/2-20 FULL SOURCE-TO-GLOBE REGRESSION PASS"
