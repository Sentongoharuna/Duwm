#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";R="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/LastGoodRecordRegistry.java";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
grep -F 'good.put(s.canonicalId,s)' "$R" >/dev/null
grep -F 'LastGoodRecordRegistry> lastGoodRecords' "$M" >/dev/null
grep -F 'lastGood.accept(safeSignals)' "$M" >/dev/null
grep -F 'lastGood.snapshot()' "$M" >/dev/null
grep -F 'FeedStatus.State.OFFLINE' "$M" >/dev/null
grep -F 'FeedStatus.State.DELAYED' "$M" >/dev/null
grep -F 'FeedStatus.State.KEY_REQUIRED' "$M" >/dev/null
"$P/scripts/verify-1-2-20-2-9-selection-persistence.sh" "$P"
echo "1.2/20/2-10 LAST GOOD RECORD PASS"
