#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
"$P/scripts/verify-1-2-20-4-19A-4-17-situation-brief-deepening.sh" "$P"
for x in 'GENERATED AT' 'DATA FRESHNESS' 'OPERATIONAL ATTENTION' 'ATTENTION FACTORS' 'BRIEF SCOPE' 'SCOPE RECORDS' 'SCOPE PROVIDERS' 'SCOPE LIVE / FRESH' 'SCOPE CHANGED' 'SCOPE WATCHED' 'SCOPE MISSING WATCHED' 'LIFECYCLE FIRST SEEN' 'LIFECYCLE LAST SEEN' 'PERSISTENTLY MISSING' 'CARD LIMITATION' 'OPERATIONAL RULE'; do grep -F "cardFacts.put(\"$x\"" "$M" >/dev/null; done
grep -F 'for(OperationalPriorityEngine.Factor f:sharePriority.factors)' "$M" >/dev/null
grep -F 'missing data may reflect provider loss; no prediction' "$M" >/dev/null
grep -F 'CANONICAL OBJECT ID' "$M" >/dev/null
grep -F 'PROVIDER RECORD ID' "$M" >/dev/null
grep -F 'SOURCE UPDATE AGE' "$M" >/dev/null
echo "1.2/20/4.19A/4.18 OPERATIONAL SHARE DEEPENING PASS"
