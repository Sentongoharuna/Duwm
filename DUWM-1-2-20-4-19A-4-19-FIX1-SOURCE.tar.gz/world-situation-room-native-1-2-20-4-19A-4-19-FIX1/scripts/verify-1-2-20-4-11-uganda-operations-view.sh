#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";U="$J/UgandaOperationsView.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-10-location-intelligence.sh" "$P"
test -s "$U"
grep -F 'Uganda operations snapshot from the same worldwide canonical record engine' "$U" >/dev/null
grep -F 'rr.band!=RegionalPriorityEngine.Band.UGANDA' "$U" >/dev/null
grep -F 'ObjectFreshness.State.LIVE||s.freshness.state==ObjectFreshness.State.FRESH' "$U" >/dev/null
grep -F 'watch.watched(s.canonicalId)' "$U" >/dev/null
grep -F 'changes.changesFor(s.canonicalId)' "$U" >/dev/null
grep -F 'UGANDA OPERATIONS VIEW' "$M" >/dev/null
grep -F 'CURRENT UGANDA RECORDS' "$M" >/dev/null
grep -F 'WITH DETECTED CHANGES' "$M" >/dev/null
grep -F 'RegionalPriorityEngine.evaluate(signal).band == RegionalPriorityEngine.Band.UGANDA' "$M" >/dev/null
grep -F 'REGIONAL VIEW ONLY • WORLDWIDE ENGINE REMAINS ACTIVE' "$M" >/dev/null
echo "1.2/20/4-11 UGANDA OPERATIONS VIEW PASS"
