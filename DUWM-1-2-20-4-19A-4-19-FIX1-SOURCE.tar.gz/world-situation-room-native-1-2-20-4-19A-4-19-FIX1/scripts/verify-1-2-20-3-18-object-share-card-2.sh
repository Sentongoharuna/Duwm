#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
grep -F 'human-readable Object Share Card 2.0' "$M" >/dev/null
for x in 'OBJECT TYPE' 'OBJECT STATE' 'OBSERVED / PUBLISHED' LOCATION CREDIBILITY; do grep -F "cardFacts.put(\"$x\"" "$M" >/dev/null; done
grep -F 'CALCULATED FROM PUBLIC ELEMENTS — NOT LIVE TELEMETRY' "$M" >/dev/null
grep -F 'RADAR HISTORY / OBSERVATION — NOT A FORECAST' "$M" >/dev/null
grep -F 'CANONICAL OBJECT ID' "$M" >/dev/null
grep -F 'PROVIDER RECORD ID' "$M" >/dev/null
grep -F 'COORDINATE ORIGIN' "$M" >/dev/null
grep -F 'signal.sourceUrl' "$M" >/dev/null
grep -F 'signal.freshness.state.name()' "$M" >/dev/null
"$P/scripts/verify-1-2-20-3-17-overlap-cluster-selection.sh" "$P"
echo "1.2/20/3-18 OBJECT SHARE CARD 2.0 PASS"
