#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";W="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/CanonicalWatchStore.java";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
test -s "$W"
grep -F '"w_"+s.canonicalId' "$W" >/dev/null
grep -F '"provider_"+s.canonicalId' "$W" >/dev/null
grep -F '"record_"+s.canonicalId' "$W" >/dev/null
grep -F 'canonicalWatchStore = new CanonicalWatchStore(this)' "$M" >/dev/null
grep -F 'actionButton("WATCH", AMBER)' "$M" >/dev/null
grep -F 'canonicalWatchStore.watched(selectedSignal.canonicalId)' "$M" >/dev/null
grep -F 'canonicalWatchStore.setWatched(selectedSignal,next)' "$M" >/dev/null
grep -F 'mapView.isFollowing(signal.canonicalId)' "$M" >/dev/null
"$P/scripts/verify-1-2-20-2-16-detail-globe-round-trip.sh" "$P"
echo "1.2/20/2-17 TRACK WATCH CANONICAL PASS"
