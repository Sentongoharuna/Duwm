#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
M="$J/MainActivity.java"

echo "RUN cumulative deepening chain through 4.18"
"$P/scripts/verify-1-2-20-4-19A-4-18-operational-share-deepening.sh" "$P"

echo "4.1 lifecycle/change persistence"
grep -F 'while(h.size()>32)' "$J/LiveChangeRegistry.java" >/dev/null
grep -F 'while(history.size()>1024)' "$J/LiveChangeRegistry.java" >/dev/null
grep -F 'while(lifecycle.size()>2048)' "$J/LiveChangeRegistry.java" >/dev/null
grep -F 'ONE-REFRESH MISSING ≠ PERSISTENTLY MISSING' "$M" >/dev/null

echo "4.2 movement truth"
grep -F 'if(fixes.size()>=8)break' "$J/MovementIntelligence.java" >/dev/null
grep -F 'NO PREDICTED PATH • DATA GAPS EXPOSED' "$M" >/dev/null

echo "4.3 zones bounded"
grep -F 'while(memory.size()>256)' "$J/GeographicActivityZones.java" >/dev/null
grep -F 'ZONE TREND ≠ INCIDENT' "$M" >/dev/null

echo "4.4 incident lifecycle bounded and unconfirmed"
grep -F 'while(memory.size()>256)' "$J/IncidentFormationEngine.java" >/dev/null
grep -F 'INCIDENT LIFECYCLE ≠ CONFIRMATION' "$M" >/dev/null

echo "4.5 regional border honesty"
grep -F 'UGANDA_BORDER' "$J/RegionalPriorityEngine.java" >/dev/null
grep -F 'BOUNDS ≠ LEGAL BORDER' "$M" >/dev/null

echo "4.6 proximity bands"
grep -F 'KM_0_10, KM_10_25, KM_25_50, KM_50_100, KM_100_150' "$J/ProximityIntelligence.java" >/dev/null
grep -F 'DISTANCE BAND ≠ RELATIONSHIP ≠ INCIDENT' "$M" >/dev/null

echo "4.7 timeline audit"
grep -F 'TOTAL MATERIAL CHANGES' "$M" >/dev/null
grep -F 'MISSING PERSISTENCE EXPOSED' "$M" >/dev/null

echo "4.8 evidence independence"
grep -F 'POSSIBLE_DUPLICATE_CONTENT, UNKNOWN_LINEAGE' "$J/CrossSourceEvidencePanel.java" >/dev/null
grep -F 'DISTINCT PROVIDER ≠ INDEPENDENT REPORTING' "$M" >/dev/null

echo "4.9 link rejection audit"
grep -F 'LOCATION_UNRESOLVED, TOO_FAR, TIME_WINDOW_FAILED' "$J/NewsEventLinkEngine.java" >/dev/null
grep -F 'REJECTIONS EXPOSED' "$M" >/dev/null

echo "4.10 location snapshot"
grep -F 'OBJECTS WITH CHANGES' "$M" >/dev/null
grep -F 'DENSITY/CHANGE/WATCH COUNTS ARE DESCRIPTIVE ONLY' "$M" >/dev/null

echo "4.11/4.12 regional operations"
grep -F 'BORDER CONTEXT KEPT SEPARATE' "$M" >/dev/null
grep -F 'BORDER CONTEXT EXPLICIT' "$M" >/dev/null

echo "4.13/4.14 watch state"
grep -F 'public long lastViewed' "$J/CanonicalWatchStore.java" >/dev/null
grep -F 'NEW SINCE LAST VIEW' "$M" >/dev/null
grep -F 'UNREAD STATE ≠ SOURCE STATE' "$M" >/dev/null

echo "4.15 priority explainability"
grep -F 'CONTRIBUTION LEDGER' "$M" >/dev/null
grep -F 'NON-CONTRIBUTORS EXPOSED' "$M" >/dev/null

echo "4.16 ranked search"
grep -F 'ranked multi-result current canonical intelligence search' "$J/LiveIntelligenceSearch.java" >/dev/null
grep -F 'EXACT IDS RANK FIRST' "$M" >/dev/null

echo "4.17 structured factual brief"
for x in 'WHAT IS CURRENT' 'WHAT CHANGED' 'WHAT IS WATCHED' 'IMPORTANT LIMITATIONS'; do grep -F "$x" "$M" >/dev/null; done
grep -F 'NO UNSOURCED CONCLUSION' "$M" >/dev/null

echo "4.18 provenance-preserving share"
for x in 'GENERATED AT' 'DATA FRESHNESS' 'ATTENTION FACTORS' 'CARD LIMITATION'; do grep -F "cardFacts.put(\"$x\"" "$M" >/dev/null; done
grep -F 'CANONICAL OBJECT ID' "$M" >/dev/null
grep -F 'PROVIDER RECORD ID' "$M" >/dev/null

echo "functional tap/back/action ownership"
grep -F 'sourceButton.setOnClickListener' "$M" >/dev/null
grep -F 'detailWatchButton.setOnClickListener' "$M" >/dev/null
grep -F 'detailShareButton.setOnClickListener' "$M" >/dev/null
grep -F 'restoreDetailReturnState()' "$M" >/dev/null
grep -F 'routeUniversalGlobeTap(exact)' "$M" >/dev/null

echo "architecture drift guard"
! grep -R -E 'android\.webkit\.WebView|okhttp3|okio\.' "$J"

echo "1.2/20/4.19A/4.19 DEEP FUNCTIONAL REGRESSION PASS"
