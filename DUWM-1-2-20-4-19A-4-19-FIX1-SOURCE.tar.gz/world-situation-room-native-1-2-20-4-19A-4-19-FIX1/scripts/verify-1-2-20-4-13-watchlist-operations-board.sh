#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";W="$J/WatchlistOperationsBoard.java";C="$J/CanonicalWatchStore.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-12-east-africa-operations-view.sh" "$P"
test -s "$W"
grep -F 'operational board for persistent canonical WATCH identities' "$W" >/dev/null
grep -F 'current.put(s.canonicalId,s)' "$W" >/dev/null
grep -F 'changes.changesFor(w.canonicalId)' "$W" >/dev/null
grep -F 'public List<Watch> all()' "$C" >/dev/null
grep -F 'e.getKey().substring(2)' "$C" >/dev/null
grep -F 'WATCHLIST OPERATIONS BOARD' "$M" >/dev/null
grep -F 'CURRENTLY PRESENT' "$M" >/dev/null
grep -F 'TEMPORARILY MISSING' "$M" >/dev/null
grep -F 'WITH CHANGE HISTORY' "$M" >/dev/null
grep -F 'canonicalWatchStore.watched(signal.canonicalId)' "$M" >/dev/null
grep -F 'MISSING ≠ ENDED • WATCH IDENTITY SURVIVES PROVIDER LOSS' "$M" >/dev/null
echo "1.2/20/4-13 WATCHLIST OPERATIONS BOARD PASS"
