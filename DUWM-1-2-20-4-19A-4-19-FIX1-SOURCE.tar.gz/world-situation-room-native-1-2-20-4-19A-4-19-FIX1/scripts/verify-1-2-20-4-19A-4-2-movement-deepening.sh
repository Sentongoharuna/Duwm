#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";X="$J/MovementIntelligence.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-19A-4-1-live-change-deepening.sh" "$P"
grep -F 'multi-fix movement intelligence from observed provider fixes only' "$X" >/dev/null
grep -F 'if(fixes.size()>=8)break' "$X" >/dev/null
grep -F 'totalObservedKm,averageSpeedMps,turnMagnitudeDeg' "$X" >/dev/null
grep -F 'maxGapMs' "$X" >/dev/null
grep -F 'enum Motion { UNKNOWN, STATIONARY, MOVING }' "$X" >/dev/null
grep -F 'enum Trend { UNKNOWN, DECREASING, STABLE, INCREASING }' "$X" >/dev/null
grep -F 'OBSERVED FIXES' "$M" >/dev/null
grep -F 'TOTAL OBSERVED PATH' "$M" >/dev/null
grep -F 'PATH AVERAGE SPEED' "$M" >/dev/null
grep -F 'SPEED TREND' "$M" >/dev/null
grep -F 'MAX OBSERVED TURN' "$M" >/dev/null
grep -F 'MAX DATA GAP' "$M" >/dev/null
grep -F 'OBSERVED PROVIDER FIXES ONLY • NO PREDICTED PATH • DATA GAPS EXPOSED' "$M" >/dev/null
echo "1.2/20/4.19A/4.2 MOVEMENT INTELLIGENCE DEEPENING PASS"
