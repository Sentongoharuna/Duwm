#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
grep -F 'F12 / 20 — REPLAY TIME LENS' "$M" >/dev/null
grep -F 'F12_WINDOWS={"NOW","1H","6H","12H","24H","3D","7D"}' "$M" >/dev/null
grep -F 'f12ReplayMatches(n)' "$M" >/dev/null
grep -F 'buildF12ReplayBar()' "$M" >/dev/null
grep -F 'chronological lens over F9' "$M" >/dev/null
grep -F 'List<NewsItem> all = store.load()' "$M" >/dev/null
grep -F 'F9 owns chronology' "$M" >/dev/null
grep -F 'showLocalNewsDetail(n)' "$M" >/dev/null
# F11 remains in the same filtering chain.
grep -F 'f11CountryMatches(n,f9CountryLens)' "$M" >/dev/null
# No Replay/F12 Activity or second NewsStore class.
! find "$P/app/src/main/java" -name '*F12*Activity.java' -print -quit | grep -q .
test "$(find "$P/app/src/main/java" -name 'NewsStore.java' | wc -l)" -eq 1
echo "F12 / F9 REPLAY CHRONOLOGY CONTRACT PASS"
