#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";T="$J/LiveChangeTimeline.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-6-proximity-intelligence.sh" "$P"
test -s "$T"
grep -F 'chronological meaningful-change timeline from LiveChangeRegistry only' "$T" >/dev/null
grep -F 'registry.changesFor(canonicalId)' "$T" >/dev/null
grep -F 'EnumMap<LiveChangeRegistry.Kind,Integer>' "$T" >/dev/null
grep -F 'LIVE CHANGE TIMELINE' "$M" >/dev/null
grep -F 'LiveChangeTimeline.forObject(' "$M" >/dev/null
grep -F 'liveChangeRegistry,signal.canonicalId,12' "$M" >/dev/null
grep -F 'SUMMARY  ' "$M" >/dev/null
grep -F 'CHANGE HISTORY ≠ RAW OBSERVATION HISTORY • NO PREDICTION' "$M" >/dev/null
echo "1.2/20/4-7 LIVE CHANGE TIMELINE PASS"
