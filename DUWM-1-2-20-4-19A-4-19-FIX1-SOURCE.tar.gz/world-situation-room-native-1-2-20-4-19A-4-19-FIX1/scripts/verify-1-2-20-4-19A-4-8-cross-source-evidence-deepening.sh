#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";E="$J/CrossSourceEvidencePanel.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-19A-4-7-live-change-timeline-deepening.sh" "$P"
grep -F 'evidence independence audit: provider diversity is not assumed independent reporting' "$E" >/dev/null
grep -F 'POSSIBLE_DUPLICATE_CONTENT, UNKNOWN_LINEAGE' "$E" >/dev/null
grep -F 'sigCounts.getOrDefault(sig,0)>1' "$E" >/dev/null
grep -F 'different provider is visible, but editorial/wire lineage is not invented' "$E" >/dev/null
grep -F 'INDEPENDENT RECORD IDENTITIES' "$M" >/dev/null
grep -F 'POSSIBLE DUPLICATE-CONTENT GROUPS' "$M" >/dev/null
grep -F 'DISTINCT PROVIDER ≠ INDEPENDENT REPORTING • DUPLICATE SIGNATURE ≠ PROVEN LINEAGE • NO TRUTH SCORE' "$M" >/dev/null
echo "1.2/20/4.19A/4.8 CROSS-SOURCE EVIDENCE DEEPENING PASS"
