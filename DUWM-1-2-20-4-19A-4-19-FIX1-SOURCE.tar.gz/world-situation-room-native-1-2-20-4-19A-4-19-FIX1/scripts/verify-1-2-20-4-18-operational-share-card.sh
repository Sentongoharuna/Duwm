#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
"$P/scripts/verify-1-2-20-4-17-situation-brief-generator.sh" "$P"
grep -F 'operational context is appended to the existing provenance-preserving share card' "$M" >/dev/null
for x in 'OPERATIONAL ATTENTION' 'REGIONAL BAND' WATCH 'DETECTED CHANGES' 'INCIDENT CANDIDATE' 'OPERATIONAL RULE' 'BRIEF SCOPE' 'SCOPE RECORDS' 'SCOPE PROVIDERS' 'SCOPE LIVE / FRESH' 'SCOPE CHANGED'; do grep -F "cardFacts.put(\"$x\"" "$M" >/dev/null; done
grep -F 'OperationalPriorityEngine.evaluate(' "$M" >/dev/null
grep -F 'SituationBriefGenerator.build(' "$M" >/dev/null
grep -F 'PRIORITY ≠ DANGER • LINK ≠ CONFIRMATION' "$M" >/dev/null
grep -F 'CANONICAL OBJECT ID' "$M" >/dev/null
grep -F 'PROVIDER RECORD ID' "$M" >/dev/null
grep -F 'SOURCE URL' "$M" >/dev/null
grep -F 'CALCULATED FROM PUBLIC ELEMENTS — NOT LIVE TELEMETRY' "$M" >/dev/null
grep -F 'RADAR HISTORY / OBSERVATION — NOT A FORECAST' "$M" >/dev/null
echo "1.2/20/4-18 OPERATIONAL SHARE CARD PASS"
