#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$J/MainActivity.java";O="$J/OrbitalPropagator.java"
grep -F 'orbit intelligence; calculated positions are never presented as live telemetry' "$M" >/dev/null
grep -F 'signal.layer != Signal.Layer.SATELLITES' "$M" >/dev/null
for x in 'NORAD CATALOG' 'OBJECT ID' 'OBJECT TYPE' 'CELESTRAK GROUP' 'ELEMENT EPOCH' 'ELEMENT AGE' 'CALCULATED AT' 'ALTITUDE ESTIMATE' 'ORBITAL SPEED ESTIMATE' 'ORBIT PERIOD' INCLINATION MODEL; do grep -F "\"$x\"" "$M" >/dev/null; done
grep -F 'POSITION ORIGIN' "$M" >/dev/null
grep -F 'CALCULATED FROM PUBLIC ELEMENTS — NOT LIVE TELEMETRY' "$M" >/dev/null
grep -F 'Signal.Credibility.CALCULATED' "$O" >/dev/null
grep -F 'facts.put("NORAD CATALOG"' "$O" >/dev/null
grep -F 'facts.put("ELEMENT EPOCH"' "$O" >/dev/null
grep -F 'facts.put("CALCULATED AT"' "$O" >/dev/null
grep -F 'facts.put("MODEL"' "$O" >/dev/null
"$P/scripts/verify-1-2-20-3-6-event-intelligence.sh" "$P"
echo "1.2/20/3-7 ORBIT INTELLIGENCE PASS"
