#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
grep -F 'search live canonical objects before falling back to place lookup' "$M" >/dev/null
grep -F 'private Signal findSearchObject(String raw)' "$M" >/dev/null
grep -F 's.canonicalId' "$M" >/dev/null
grep -F 's.facts.get("CALLSIGN")' "$M" >/dev/null
grep -F 's.facts.get("NORAD CATALOG")' "$M" >/dev/null
grep -F 'private void focusSearchObject(Signal signal)' "$M" >/dev/null
grep -F 'Signal exact=resolveExactSignal(signal)' "$M" >/dev/null
grep -F 'mapView.highlightSignal(exact)' "$M" >/dev/null
grep -F 'routeUniversalGlobeTap(exact)' "$M" >/dev/null
grep -F 'repository.search(searchInput.getText().toString())' "$M" >/dev/null
"$P/scripts/verify-1-2-20-3-15-watch-intelligence.sh" "$P"
echo "1.2/20/3-16 GLOBE SEARCH EXACT OBJECT PASS"
