#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
S="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/Signal.java"
I="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/ProviderIdentity.java"
C="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/CanonicalObjectId.java"
test -s "$I"
grep -F 'public final String providerId;' "$S" >/dev/null
grep -F 'public final String providerName;' "$S" >/dev/null
grep -F 'this.providerName = source == null ? "" : source.trim();' "$S" >/dev/null
grep -F 'this.providerId = ProviderIdentity.id(this.providerName);' "$S" >/dev/null
grep -F 'CanonicalObjectId.of(this.providerId, layer, this.id)' "$S" >/dev/null
for id in opensky usgs celestrak rainviewer nasa coingecko ourairports; do grep -F "\"$id\"" "$I" >/dev/null; done
"$P/scripts/verify-1-2-20-2-1-canonical-object-id.sh" "$P"
echo "1.2/20/2-2 PROVIDER IDENTITY ATTACHED PASS"
