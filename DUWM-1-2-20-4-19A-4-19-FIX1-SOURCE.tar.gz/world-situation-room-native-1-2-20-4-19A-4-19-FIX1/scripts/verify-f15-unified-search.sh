#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
grep -F 'F15 / 20 — UNIFIED SEARCH' "$M" >/dev/null
grep -F 'new NewsStore(this).load()' "$M" >/dev/null
grep -F 'new MonitorStore(this).reports()' "$M" >/dev/null
grep -F 'layerSignals.entrySet()' "$M" >/dev/null
grep -F 'f15Contains(n.title,x)' "$M" >/dev/null
grep -F 'f15Contains(n.summary,x)' "$M" >/dev/null
grep -F 'f15Contains(n.sourceName,x)' "$M" >/dev/null
grep -F 'f15Contains(n.region,x)' "$M" >/dev/null
grep -F 'addF15UnifiedResults(catalogList,unifiedQuery)' "$M" >/dev/null
grep -F 'showLocalNewsDetail(n)' "$M" >/dev/null
grep -F 'DuMonitorPlayer.open(this,m.id)' "$M" >/dev/null
grep -F 'showDetail(s)' "$M" >/dev/null
grep -F 'f11CountryMatches(n,f9CountryLens)' "$M" >/dev/null
grep -F 'f12ReplayMatches(n)' "$M" >/dev/null
grep -F 'f13ReplayAnchorMs' "$M" >/dev/null
grep -F 'addF14Related(box,n)' "$M" >/dev/null
! find "$P/app/src/main/java" -name '*F15*Activity.java' -print -quit | grep -q .
test "$(find "$P/app/src/main/java" -name 'NewsStore.java' | wc -l)" -eq 1
echo "F15 UNIFIED SEARCH CONTRACT PASS"
