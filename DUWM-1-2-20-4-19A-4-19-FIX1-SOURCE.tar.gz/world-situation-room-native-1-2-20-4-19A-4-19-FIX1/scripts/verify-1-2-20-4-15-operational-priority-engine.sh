#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";O="$J/OperationalPriorityEngine.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-14-watch-change-detection.sh" "$P"
test -s "$O"
grep -F 'operational attention priority; never rewrites source severity or asserts danger' "$O" >/dev/null
grep -F 'ROUTINE, WATCH, ELEVATED, HIGH_ATTENTION' "$O" >/dev/null
grep -F 'watch.watched(s.canonicalId)' "$O" >/dev/null
grep -F 'changes.changesFor(s.canonicalId)' "$O" >/dev/null
grep -F 'region.band==RegionalPriorityEngine.Band.UGANDA' "$O" >/dev/null
grep -F 'incident.state==IncidentFormationEngine.State.MULTI_SOURCE_RELATED' "$O" >/dev/null
grep -F 'if(s.severity>=3)' "$O" >/dev/null
grep -F 'OPERATIONAL PRIORITY' "$M" >/dev/null
grep -F 'ATTENTION BAND' "$M" >/dev/null
grep -F 'SOURCE SEVERITY' "$M" >/dev/null
grep -F 'PRIORITY ≠ DANGER ≠ CONFIRMATION • SOURCE SEVERITY UNCHANGED' "$M" >/dev/null
echo "1.2/20/4-15 OPERATIONAL PRIORITY ENGINE PASS"
