#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
T="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/RecordTimestampChain.java"
R="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/TimestampChainRegistry.java"
S="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/Signal.java"
V="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/SatelliteMapView.java"
test -s "$T";test -s "$R"
for x in providerTimeMs firstSeenMs fetchedAtMs renderedAtMs; do grep -F "$x" "$T" >/dev/null; done
grep -F 'providerTimeMs > 0L ? providerTimeMs : firstSeenMs' "$T" >/dev/null
grep -F 'keyed only by canonical object identity' "$R" >/dev/null
grep -F 'TimestampChainRegistry.create(' "$S" >/dev/null
grep -F 'this.canonicalId, timestampMs, System.currentTimeMillis()' "$S" >/dev/null
grep -F 'signal.timestampChain = signal.timestampChain.rendered(renderedNow)' "$V" >/dev/null
# Provider-native timestamp remains the OriginalRecordRef timestamp.
grep -F 'this.canonicalId, timestampMs,' "$S" >/dev/null
"$P/scripts/verify-1-2-20-2-3-original-record-reference.sh" "$P"
echo "1.2/20/2-4 TIMESTAMP CHAIN PASS"
