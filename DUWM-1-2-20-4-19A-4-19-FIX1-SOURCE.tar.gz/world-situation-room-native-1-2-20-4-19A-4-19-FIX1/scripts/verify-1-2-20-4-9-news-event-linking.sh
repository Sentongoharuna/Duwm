#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";E="$J/NewsEventLinkEngine.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-8-cross-source-evidence-panel.sh" "$P"
test -s "$E"
grep -F 'conservative News/Event link candidates; a link is never confirmation' "$E" >/dev/null
grep -F 'EXISTING_RELATIONSHIP_ID, LOCATION_AND_TIME' "$E" >/dev/null
grep -F 'n.relationshipId.equals(e.relationshipId)' "$E" >/dev/null
grep -F 'd<=100d&&dt<=6L*60L*60L*1000L' "$E" >/dev/null
grep -F 'Signal.Layer.NATURAL||s.layer==Signal.Layer.WEATHER||s.layer==Signal.Layer.AIRSPACE' "$E" >/dev/null
grep -F 'NEWS ↔ EVENT LINKS' "$M" >/dev/null
grep -F 'CANDIDATE LINKS' "$M" >/dev/null
grep -F 'LINK ≠ CAUSATION ≠ CORROBORATION ≠ CONFIRMATION' "$M" >/dev/null
echo "1.2/20/4-9 NEWS EVENT LINKING PASS"
