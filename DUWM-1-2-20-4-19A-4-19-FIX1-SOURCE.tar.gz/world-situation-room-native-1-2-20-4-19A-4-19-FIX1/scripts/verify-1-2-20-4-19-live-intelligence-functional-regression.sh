#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
M="$J/MainActivity.java"

echo "RUN 4-18 cumulative chain"
"$P/scripts/verify-1-2-20-4-18-operational-share-card.sh" "$P"

echo "CHECK live-change ownership"
grep -F 'liveChangeRegistry.accept(layer, operational.signals, freshnessNow)' "$M" >/dev/null
grep -F 'LIVE CHANGE DETECTION' "$M" >/dev/null
grep -F 'OBJECT MOVEMENT INTELLIGENCE' "$M" >/dev/null
grep -F 'GEOGRAPHIC ACTIVITY ZONE' "$M" >/dev/null

echo "CHECK incident/evidence truth boundaries"
grep -F 'INCIDENT CANDIDATE ≠ CONFIRMED INCIDENT • RECORDS REMAIN INDEPENDENT' "$M" >/dev/null
grep -F 'RELATED EVIDENCE ≠ CORROBORATION ≠ CONFIRMATION • NO TRUTH SCORE' "$M" >/dev/null
grep -F 'LINK ≠ CAUSATION ≠ CORROBORATION ≠ CONFIRMATION' "$M" >/dev/null
grep -F 'PROXIMITY ≠ RELATIONSHIP ≠ INCIDENT • CURRENT LOCATED RECORDS ONLY' "$M" >/dev/null

echo "CHECK regional operations"
grep -F 'UGANDA OPERATIONS VIEW' "$M" >/dev/null
grep -F 'EAST AFRICA OPERATIONS VIEW' "$M" >/dev/null
grep -F 'LOCATION INTELLIGENCE' "$M" >/dev/null
grep -F 'REGIONAL LENS ≠ SEVERITY • UGANDA + WORLDWIDE MONITORING REMAIN ACTIVE' "$M" >/dev/null

echo "CHECK WATCH operations"
grep -F 'WATCH CHANGE DETECTION' "$M" >/dev/null
grep -F 'WATCHLIST OPERATIONS BOARD' "$M" >/dev/null
grep -F 'canonicalWatchStore.watched(signal.canonicalId)' "$M" >/dev/null
grep -F 'MISSING ≠ ENDED • WATCH IDENTITY SURVIVES PROVIDER LOSS' "$M" >/dev/null

echo "CHECK operational priority separation"
grep -F 'OPERATIONAL PRIORITY' "$M" >/dev/null
grep -F 'PRIORITY ≠ DANGER ≠ CONFIRMATION • SOURCE SEVERITY UNCHANGED' "$M" >/dev/null

echo "CHECK unified search -> exact object"
grep -F 'findLiveIntelligenceSearchObject(query)' "$M" >/dev/null
grep -F 'focusSearchObject(objectMatch)' "$M" >/dev/null
grep -F 'routeUniversalGlobeTap(exact)' "$M" >/dev/null

echo "CHECK factual brief"
grep -F 'SITUATION BRIEF  •  ' "$M" >/dev/null
grep -F 'FACTUAL SNAPSHOT • NO PREDICTION • NO UNSOURCED CONCLUSION' "$M" >/dev/null

echo "CHECK operational share uses existing share path"
grep -F 'operational context is appended to the existing provenance-preserving share card' "$M" >/dev/null
grep -F 'CANONICAL OBJECT ID' "$M" >/dev/null
grep -F 'PROVIDER RECORD ID' "$M" >/dev/null
grep -F 'OPERATIONAL ATTENTION' "$M" >/dev/null
grep -F 'BRIEF SCOPE' "$M" >/dev/null

echo "CHECK primary buttons are wired"
grep -F 'sourceButton.setOnClickListener' "$M" >/dev/null
grep -F 'detailWatchButton.setOnClickListener' "$M" >/dev/null
grep -F 'detailShareButton.setOnClickListener' "$M" >/dev/null

echo "CHECK Back restores same Globe state"
grep -F 'restoreDetailReturnState()' "$M" >/dev/null
grep -F 'mapView.highlightSignal(s)' "$M" >/dev/null

echo "CHECK F9 functional actions remain owned"
grep -F 'String[] labels={"OPEN FULL ARTICLE","SHARE","MARK READ","HIDE THIS OUTLET","FOLLOW TOPIC","SHOW ON GLOBE"}' "$M" >/dev/null
grep -F 'if("SHOW ON GLOBE".equals(label))b.setEnabled(gp!=null)' "$M" >/dev/null

echo "CHECK no forbidden architecture drift"
! grep -R -E 'android\.webkit\.WebView|okhttp3|okio\.' "$J"

echo "1.2/20/4-19 LIVE INTELLIGENCE OPERATIONS FULL FUNCTIONAL REGRESSION PASS"
