#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
V="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/SatelliteMapView.java"
N="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/NewsSourceCatalog.java"
grep -F '1.2/20/1 LIVE OBJECT REFRESH' "$V" >/dev/null
grep -F 'liveObjectFingerprint(next)' "$V" >/dev/null
grep -F 'postInvalidateOnAnimation()' "$V" >/dev/null
grep -F 'keep the last good layer visible during a transient provider failure' "$M" >/dev/null
grep -F 'FeedStatus.State.OFFLINE' "$M" >/dev/null
grep -F 'FeedStatus.State.DELAYED' "$M" >/dev/null
grep -F 'FeedStatus.State.KEY_REQUIRED' "$M" >/dev/null
# Approved Globe behavior remains present.
grep -F 'mapView.setGlobeMode(true)' "$M" >/dev/null
grep -F 'mapView.setSignals(mapSignals)' "$M" >/dev/null
# Visible mission controls have real click handlers.
grep -F 'addMissionAction(row, "GLOBE", view -> showGlobeOverview())' "$M" >/dev/null
grep -F 'addMissionAction(row, "MONITORS", view -> openLocalMonitors())' "$M" >/dev/null
grep -F 'addMissionAction(row, "NEWS", view -> openCatalog("NEWS"))' "$M" >/dev/null
grep -F 'addMissionAction(row, "AIR", view -> openCatalog("AIRCRAFT"))' "$M" >/dev/null
grep -F 'addMissionAction(row, "SEA", view -> openCatalog("SHIPS"))' "$M" >/dev/null
grep -F 'addMissionAction(row, "WX", view -> openCatalog("WEATHER"))' "$M" >/dev/null
grep -F 'addMissionAction(row, "ORBIT", view -> openCatalog("ORBITS"))' "$M" >/dev/null
# F9 Uganda/East Africa catalog is still present.
for d in watchdoguganda.com monitor.co.ug newvision.co.ug nilepost.co.ug chimpreports.com independent.co.ug observer.ug kampalapost.com pmldaily.com softpower.ug redpepper.co.ug dailyexpress.co.ug eagle.co.ug dispatch.ug thetowerpost.com ugandaradionetwork.net harunaenterprisesltd.com ntv.co.ug nbs.ug ubc.go.ug capitalfm.co.ug bukedde.co.ug businessfocus.co.ug ceo.co.ug ugbusiness.com kawowo.com bigeye.ug mbu.ug howwe.ug pulse.ug techjaja.com pctechmag.com dignited.com mediacentre.go.ug news.google.com theeastafrican.co.ke nation.africa the-star.co.ke thecitizen.co.tz newtimes.co.rw; do
  grep -F "$d" "$N" >/dev/null || { echo "Missing F9 source: $d"; exit 1; }
done
echo "1.2/20/1 LIVE OBJECT REFRESH + FUNCTIONAL FOUNDATION PASS"
