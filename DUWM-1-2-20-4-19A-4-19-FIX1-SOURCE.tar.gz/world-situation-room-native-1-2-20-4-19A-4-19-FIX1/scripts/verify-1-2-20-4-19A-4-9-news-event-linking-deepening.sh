#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";E="$J/NewsEventLinkEngine.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-19A-4-8-cross-source-evidence-deepening.sh" "$P"
grep -F 'auditable conservative News/Event candidate linking with explicit rejection reasons' "$E" >/dev/null
grep -F 'LOCATION_UNRESOLVED, TOO_FAR, TIME_WINDOW_FAILED' "$E" >/dev/null
grep -F 'providerTime(n)-providerTime(e)' "$E" >/dev/null
grep -F 'd>100d' "$E" >/dev/null
grep -F 'dt>6L*60L*60L*1000L' "$E" >/dev/null
grep -F 'Existing DUWM relationship identity' "$E" >/dev/null
grep -F 'ACCEPTED CANDIDATE LINKS' "$M" >/dev/null
grep -F 'REJECTED PAIRS AUDITED' "$M" >/dev/null
grep -F 'PROVIDER ΔT' "$M" >/dev/null
grep -F 'REJECTIONS EXPOSED' "$M" >/dev/null
echo "1.2/20/4.19A/4.9 NEWS EVENT LINKING DEEPENING PASS"
