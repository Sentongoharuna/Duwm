#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$J/MainActivity.java";N="$J/NewsSignals.java"
grep -F 'F9 News -> Globe intelligence from the exact NewsItem record' "$M" >/dev/null
for x in 'OUTLET  ' 'SOURCE ID  ' 'NEWS ID  ' 'PUBLISHED  ' 'FIRST SEEN  ' 'REGION  ' 'TOPIC  ' 'CLUSTER  ' 'ALSO REPORTED BY  ' 'GLOBE LOCATION  '; do grep -F "$x" "$M" >/dev/null; done
grep -F 'UNRESOLVED — NO MARKER INVENTED' "$M" >/dev/null
grep -F 'GeoIndex.findSpecific(n.title+" "+n.summary+" "+n.region)' "$M" >/dev/null
grep -F 'showLocalNewsDetail(exactNews)' "$M" >/dev/null
grep -F 'signal.nativePayload.value("NEWS ID")' "$M" >/dev/null
grep -F 'Double.NaN' "$N" >/dev/null
grep -F 'ARTICLE URL' "$N" >/dev/null
"$P/scripts/verify-1-2-20-3-8-weather-object-intelligence.sh" "$P"
echo "1.2/20/3-9 NEWS GLOBE INTELLIGENCE PASS"
