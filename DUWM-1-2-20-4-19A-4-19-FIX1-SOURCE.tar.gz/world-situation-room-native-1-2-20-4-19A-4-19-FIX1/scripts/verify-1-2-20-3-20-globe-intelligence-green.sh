#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
# /3-19 is cumulative: it calls /3-18 -> ... -> /3-1, and /3-1 calls frozen /2-20.
echo "RUNNING CUMULATIVE GATE: verify-1-2-20-3-19-object-functional-gate.sh"
chmod +x "$P/scripts/"*.sh
"$P/scripts/verify-1-2-20-3-19-object-functional-gate.sh" "$P"
# Final architecture/truth invariants.
grep -F 'mapView = new SatelliteMapView(this)' "$J/MainActivity.java" >/dev/null
grep -F 'routeUniversalGlobeTap' "$J/MainActivity.java" >/dev/null
grep -F 'resolveExactSignal' "$J/MainActivity.java" >/dev/null
grep -F 'RELATIONSHIP ≠ CONFIRMATION' "$J/MainActivity.java" >/dev/null
grep -F 'CALCULATED FROM PUBLIC ELEMENTS — NOT LIVE TELEMETRY' "$J/MainActivity.java" >/dev/null
grep -F 'UNRESOLVED — NO MARKER INVENTED' "$J/MainActivity.java" >/dev/null
grep -F 'LAST_GOOD' "$J/ObjectFreshness.java" >/dev/null
! grep -R -E 'android\.webkit\.WebView|okhttp3|okio\.' "$J"
test "$(grep -c 'new NewsSource(' "$J/NewsSourceCatalog.java")" -ge 43
echo "1.2/20/3-20 GLOBE INTELLIGENCE FULL GREEN PASS"
