#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
R="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/CanonicalObjectRegistry.java"
V="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/SatelliteMapView.java"
test -s "$R"
grep -F 'LinkedHashMap<String, Signal> current' "$R" >/dev/null
grep -F 'current.get(next.canonicalId)' "$R" >/dev/null
grep -F 'current.put(next.canonicalId, next)' "$R" >/dev/null
grep -F 'previous.timestampChain.firstSeenMs' "$R" >/dev/null
grep -F 'CanonicalObjectRegistry canonicalObjects' "$V" >/dev/null
grep -F 'List<Signal> merged = canonicalObjects.merge(safe)' "$V" >/dev/null
grep -F 'buildRenderSnapshot(merged)' "$V" >/dev/null
grep -F 'canonicalObjects.get(followedSignalId)' "$V" >/dev/null
"$P/scripts/verify-1-2-20-2-7-type-specific-payload.sh" "$P"
echo "1.2/20/2-8 IN-PLACE OBJECT UPDATES PASS"
