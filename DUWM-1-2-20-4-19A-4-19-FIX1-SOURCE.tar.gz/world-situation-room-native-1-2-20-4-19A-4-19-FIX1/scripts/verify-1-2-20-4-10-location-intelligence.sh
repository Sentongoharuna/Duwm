#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";L="$J/LocationIntelligence.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-9-news-event-linking.sh" "$P"
test -s "$L"
grep -F 'factual location snapshot from current located canonical records' "$L" >/dev/null
grep -F 'seen.add(s.canonicalId)' "$L" >/dev/null
grep -F 'if(d>radiusKm)continue' "$L" >/dev/null
grep -F 'watch.watched(s.canonicalId)' "$L" >/dev/null
grep -F 'LOCATION INTELLIGENCE' "$M" >/dev/null
grep -F 'signal.latitude,signal.longitude,100d,layerSignals.values(),canonicalWatchStore,20' "$M" >/dev/null
grep -F 'DISTINCT PROVIDERS' "$M" >/dev/null
grep -F 'WATCHED OBJECTS' "$M" >/dev/null
grep -F 'NEAREST RECORDS' "$M" >/dev/null
grep -F 'LOCATION SNAPSHOT ≠ INCIDENT • CURRENT LOCATED RECORDS ONLY' "$M" >/dev/null
echo "1.2/20/4-10 LOCATION INTELLIGENCE PASS"
