#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
M="$J/MainActivity.java"
I="$J/PipelineIntegrity.java"
test -s "$I"
for x in NO_PROVIDER NO_CANONICAL DUP_CANONICAL BROKEN_ORIGINAL NO_TIME_CHAIN NO_COORDINATE_PROVENANCE NO_NATIVE_PAYLOAD NO_FRESHNESS; do grep -F "$x" "$I" >/dev/null; done
grep -F 'PipelineIntegrity.inspect(safeSignals)' "$M" >/dev/null
grep -F 'CrashLedger.recordRecovered(this, "PipelineIntegrity."' "$M" >/dev/null
# Canonical/source/record chain.
grep -F 'public final String canonicalId;' "$J/Signal.java" >/dev/null
grep -F 'public final String providerId;' "$J/Signal.java" >/dev/null
grep -F 'public final OriginalRecordRef originalRecord;' "$J/Signal.java" >/dev/null
grep -F 'OriginalRecordResolver.resolve(tapped.originalRecord, current)' "$M" >/dev/null
# Exact tap routes.
grep -F 'showLocalNewsDetail(exactNews)' "$M" >/dev/null
grep -F 'openLocalMonitors(exact.id.substring' "$M" >/dev/null
grep -F 'showDetail(signal)' "$M" >/dev/null
# Detail/back/share/watch.
grep -F 'restoreDetailReturnState()' "$M" >/dev/null
grep -F 'canonicalWatchStore.setWatched(selectedSignal,next)' "$M" >/dev/null
grep -F 'share the exact canonical record provenance' "$M" >/dev/null
# F9 full catalog and actual news pipeline.
test "$(grep -c 'new NewsSource(' "$J/NewsSourceCatalog.java")" -ge 43
grep -F 'f.put("SOURCE ID",n.sourceId)' "$J/NewsSignals.java" >/dev/null
grep -F 'f.put("CLUSTER ID",n.clusterId)' "$J/NewsSignals.java" >/dev/null
# No duplicate canonical records before operations.
grep -F 'CanonicalRecordDeduplicator.deduplicate(' "$M" >/dev/null
"$P/scripts/verify-1-2-20-2-18-share-provenance.sh" "$P"
echo "1.2/20/2-19 PIPELINE INTEGRITY PASS"
