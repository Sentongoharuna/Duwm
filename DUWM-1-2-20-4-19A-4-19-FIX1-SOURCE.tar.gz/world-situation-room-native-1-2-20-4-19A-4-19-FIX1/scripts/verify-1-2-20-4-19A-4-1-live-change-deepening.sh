#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";C="$J/LiveChangeRegistry.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-19-live-intelligence-functional-regression.sh" "$P"
grep -F 'firstSeenMs,lastSeenMs,missingSinceMs' "$C" >/dev/null
grep -F 'consecutivePresent,consecutiveMissing' "$C" >/dev/null
grep -F 'public boolean persistentlyMissing(){return consecutiveMissing>=2;}' "$C" >/dev/null
grep -F 'previousValue,currentValue' "$C" >/dev/null
grep -F 'providerDeltaMs' "$C" >/dev/null
grep -F 'Persistently absent for ' "$C" >/dev/null
grep -F 'while(lifecycle.size()>2048)' "$C" >/dev/null
grep -F 'FIRST SEEN' "$M" >/dev/null
grep -F 'LAST SEEN' "$M" >/dev/null
grep -F 'CONSECUTIVE PRESENT' "$M" >/dev/null
grep -F 'CONSECUTIVE MISSING' "$M" >/dev/null
grep -F 'LATEST DELTA' "$M" >/dev/null
grep -F 'PROVIDER ΔT' "$M" >/dev/null
grep -F 'ONE-REFRESH MISSING ≠ PERSISTENTLY MISSING' "$M" >/dev/null
echo "1.2/20/4.19A/4.1 LIVE CHANGE DETECTION DEEPENING PASS"
