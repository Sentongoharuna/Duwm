#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";T="$J/LiveChangeTimeline.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-19A-4-6-proximity-deepening.sh" "$P"
grep -F 'auditable meaningful-change timeline with deltas, lifecycle and grouped counts' "$T" >/dev/null
grep -F 'previousValue,currentValue' "$T" >/dev/null
grep -F 'providerDeltaMs' "$T" >/dev/null
grep -F 'LiveChangeRegistry.Lifecycle lifecycle' "$T" >/dev/null
grep -F 'spanMs' "$T" >/dev/null
grep -F 'TOTAL MATERIAL CHANGES' "$M" >/dev/null
grep -F 'GROUPED COUNTS' "$M" >/dev/null
grep -F 'PERSISTENTLY MISSING' "$M" >/dev/null
grep -F 'DELTA  ' "$M" >/dev/null
grep -F 'PROVIDER ΔT' "$M" >/dev/null
grep -F 'CHANGE TIMELINE ≠ RAW OBSERVATION TIMELINE • NO PREDICTION • MISSING PERSISTENCE EXPOSED' "$M" >/dev/null
echo "1.2/20/4.19A/4.7 LIVE CHANGE TIMELINE DEEPENING PASS"
