#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";V="$J/SatelliteMapView.java";M="$J/MainActivity.java"
grep -F 'void onSignalTapCandidates(java.util.List<Signal> signals)' "$V" >/dev/null
grep -F 'java.util.List<Signal> hits = findSignals(event.getX(), event.getY())' "$V" >/dev/null
grep -F 'canonicalSeen.add(key)' "$V" >/dev/null
grep -F 'java.util.Collections.sort(hits' "$V" >/dev/null
grep -F 'routeUniversalGlobeTap(signal)' "$M" >/dev/null
grep -F 'showGlobeObjectChooser(signals)' "$M" >/dev/null
grep -F 'OBJECTS HERE • SELECT EXACT RECORD' "$M" >/dev/null
grep -F 'Signal exact = resolveExactSignal(signal)' "$M" >/dev/null
grep -F 'showLocalNewsDetail(exactNews)' "$M" >/dev/null
grep -F 'openLocalMonitors(exact.id.substring' "$M" >/dev/null
grep -F 'showDetail(exact)' "$M" >/dev/null
"$P/scripts/verify-1-2-20-2-20-full-regression.sh" "$P"
echo "1.2/20/3-1 UNIVERSAL GLOBE OBJECT TAP PASS"
