#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";R="$J/RegionalPriorityEngine.java";M="$J/MainActivity.java";E="$J/EastAfricaOperationsView.java";S="$J/SituationBriefGenerator.java";O="$J/OperationalPriorityEngine.java"
"$P/scripts/verify-1-2-20-4-19A-4-4-incident-formation-deepening.sh" "$P"
grep -F 'UGANDA, UGANDA_BORDER, EAST_AFRICA, GLOBAL' "$R" >/dev/null
grep -F 'OBSERVED_COORDINATES, CONTROLLED_PROVIDER_TEXT, NONE' "$R" >/dev/null
grep -F 'distanceToUgandaBoundsKm' "$R" >/dev/null
grep -F 'if(bd<=75d)' "$R" >/dev/null
grep -F 'METHOD  ' "$M" >/dev/null
grep -F 'UGANDA BORDER CONTEXT' "$M" >/dev/null
grep -F 'BOUNDS ≠ LEGAL BORDER' "$M" >/dev/null
grep -F 'RegionalPriorityEngine.Band.UGANDA_BORDER' "$E" >/dev/null
grep -F 'RegionalPriorityEngine.Band.UGANDA_BORDER' "$S" >/dev/null
grep -F 'Near-Uganda-border relevance' "$O" >/dev/null
echo "1.2/20/4.19A/4.5 REGIONAL PRIORITY DEEPENING PASS"
