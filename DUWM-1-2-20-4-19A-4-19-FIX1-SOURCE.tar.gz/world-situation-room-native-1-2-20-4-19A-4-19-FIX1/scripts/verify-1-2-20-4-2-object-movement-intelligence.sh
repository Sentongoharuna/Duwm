#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";X="$J/MovementIntelligence.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-1-live-change-detection.sh" "$P"
test -s "$X"
grep -F 'consecutive observed provider fixes only' "$X" >/dev/null
grep -F 'e.providerTimeMs<to.providerTimeMs' "$X" >/dev/null
grep -F 'double speed=(km*1000d)/(dt/1000d)' "$X" >/dev/null
grep -F 'return (Math.toDegrees(Math.atan2(y,x))+360d)%360d' "$X" >/dev/null
grep -F 'OBJECT MOVEMENT INTELLIGENCE' "$M" >/dev/null
grep -F 'DERIVED BETWEEN-FIX SPEED' "$M" >/dev/null
grep -F 'TWO OBSERVED PROVIDER FIXES • NO PREDICTED PATH' "$M" >/dev/null
grep -F 'canonicalTimelineRegistry.timeline(signal.canonicalId)' "$M" >/dev/null
echo "1.2/20/4-2 OBJECT MOVEMENT INTELLIGENCE PASS"
