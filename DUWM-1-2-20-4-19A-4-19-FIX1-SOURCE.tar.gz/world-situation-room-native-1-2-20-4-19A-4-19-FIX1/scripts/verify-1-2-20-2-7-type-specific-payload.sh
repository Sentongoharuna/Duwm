#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";T="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/TypeSpecificPayload.java";S="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/Signal.java"
test -s "$T"
grep -F 'public final TypeSpecificPayload nativePayload;' "$S" >/dev/null
grep -F 'TypeSpecificPayload.from(layer, this.facts)' "$S" >/dev/null
grep -F 'Collections.unmodifiableMap(new LinkedHashMap<>(f))' "$T" >/dev/null
grep -F '"ICAO24"' "$P/app/src/main/java/com/sentongoharuna/worldsituationroom/WorldDataRepository.java" >/dev/null
grep -F '"MAGNITUDE"' "$P/app/src/main/java/com/sentongoharuna/worldsituationroom/WorldDataRepository.java" >/dev/null
grep -F '"NORAD CATALOG"' "$P/app/src/main/java/com/sentongoharuna/worldsituationroom/OrbitalPropagator.java" >/dev/null
"$P/scripts/verify-1-2-20-2-6-coordinate-provenance.sh" "$P"
echo "1.2/20/2-7 TYPE-SPECIFIC PAYLOAD PASS"
