#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";N="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/NewsSignals.java";C="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/CrossSourceRelationship.java";CAT="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/NewsSourceCatalog.java"
for x in 'SOURCE ID' OUTLET REGION LANGUAGE TOPIC 'CLUSTER ID' 'ARTICLE URL' 'PUBLISHED AT' 'FIRST SEEN AT' 'ALSO REPORTED BY' BREAKING READ NOTIFIED; do grep -F "f.put(\"$x\"" "$N" >/dev/null; done
grep -F 'Signal.Layer.NEWS' "$N" >/dev/null
grep -F 'Double.NaN' "$N" >/dev/null
grep -F 'GeoIndex.find' "$N" >/dev/null
grep -F 'fact(signal, "CLUSTER ID")' "$C" >/dev/null
# Full F9 source catalog remains.
for d in watchdoguganda.com monitor.co.ug newvision.co.ug nilepost.co.ug chimpreports.com independent.co.ug observer.ug kampalapost.com pmldaily.com softpower.ug redpepper.co.ug dailyexpress.co.ug eagle.co.ug dispatch.ug thetowerpost.com ugandaradionetwork.net harunaenterprisesltd.com ntv.co.ug nbs.ug ubc.go.ug capitalfm.co.ug bukedde.co.ug businessfocus.co.ug ceo.co.ug ugbusiness.com kawowo.com bigeye.ug mbu.ug howwe.ug pulse.ug techjaja.com pctechmag.com dignited.com mediacentre.go.ug news.google.com theeastafrican.co.ke nation.africa the-star.co.ke thecitizen.co.tz newtimes.co.rw; do grep -F "$d" "$CAT" >/dev/null; done
"$P/scripts/verify-1-2-20-2-12-cross-source-relationship.sh" "$P"
echo "1.2/20/2-13 F9 NEWS PIPELINE PASS"
