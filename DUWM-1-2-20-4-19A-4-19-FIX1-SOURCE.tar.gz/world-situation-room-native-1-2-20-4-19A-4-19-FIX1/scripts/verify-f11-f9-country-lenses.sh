#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
grep -F 'F9 / 20-REGION OPERATIONAL FEED' "$M" >/dev/null
grep -F 'F11 / 20 — COUNTRY LENSES' "$M" >/dev/null
grep -F 'F11_COUNTRIES = {"UGANDA","KENYA","TANZANIA","RWANDA","BURUNDI","DR CONGO","SOUTH SUDAN"}' "$M" >/dev/null
grep -F 'List<NewsItem> all = store.load()' "$M" >/dev/null
grep -F 'F9 owns chronology' "$M" >/dev/null
grep -F 'f11CountryMatches(n,f9CountryLens)' "$M" >/dev/null
grep -F 'buildF11CountryBar(all)' "$M" >/dev/null
grep -F 'same F9 source IDs / clusters / chronology' "$M" >/dev/null
grep -F 'showLocalNewsDetail(n)' "$M" >/dev/null
# No F11 Activity/screen and no new manifest activity.
! find "$P/app/src/main/java" -name '*F11*Activity.java' -print -quit | grep -q .
# Guard against the duplicate helper found in the incoming local-news source.
test "$(grep -c 'private String localNewsAge(long t)' "$M")" -eq 1
echo "F11 / F9 COUNTRY LENSES CONTRACT PASS"
