#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";D="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/CanonicalRecordDeduplicator.java";R="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/CanonicalObjectRegistry.java";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
test -s "$D"
grep -F 'LinkedHashMap<String,Signal> unique' "$D" >/dev/null
grep -F 's.canonicalId' "$D" >/dev/null
grep -F 'effectiveProviderTimeMs()' "$D" >/dev/null
grep -F 'CanonicalRecordDeduplicator.deduplicate(incoming)' "$R" >/dev/null
grep -F 'CanonicalRecordDeduplicator.deduplicate(' "$M" >/dev/null
"$P/scripts/verify-1-2-20-2-10-last-good-record.sh" "$P"
echo "1.2/20/2-11 PROVIDER RECORD DEDUP PASS"
