#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";B="$J/SituationBriefGenerator.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-16-live-intelligence-search.sh" "$P"
grep -F 'factual situation brief assembled only from current provider-returned records' "$B" >/dev/null
grep -F 'if("UGANDA".equals(scope))' "$B" >/dev/null
grep -F 'if("EAST_AFRICA".equals(scope))' "$B" >/dev/null
grep -F 'SITUATION BRIEF  •  ' "$M" >/dev/null
grep -F 'LATEST RECORDS' "$M" >/dev/null
grep -F 'FACTUAL SNAPSHOT • NO PREDICTION • NO UNSOURCED CONCLUSION' "$M" >/dev/null
echo "1.2/20/4-17 SITUATION BRIEF GENERATOR PASS"
