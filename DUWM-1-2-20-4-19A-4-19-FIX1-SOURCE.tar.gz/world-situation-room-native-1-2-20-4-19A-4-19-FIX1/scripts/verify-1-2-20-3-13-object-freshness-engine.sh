#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";F="$J/ObjectFreshness.java"
grep -F 'LIVE, FRESH, AGING, STALE, LAST_GOOD, OFFLINE, UNKNOWN' "$F" >/dev/null
grep -F 'provider/type-specific freshness windows' "$F" >/dev/null
grep -F 'Signal.Layer.FLIGHTS||l==Signal.Layer.SHIPS' "$F" >/dev/null
grep -F 'Signal.Layer.SATELLITES' "$F" >/dev/null
grep -F 'Signal.Layer.WEATHER' "$F" >/dev/null
grep -F 'Signal.Layer.NEWS' "$F" >/dev/null
grep -F 'Signal.Layer.NATURAL' "$F" >/dev/null
grep -F 'State.LAST_GOOD' "$F" >/dev/null
grep -F 'this.layer, this.timestampChain, null, System.currentTimeMillis()' "$J/Signal.java" >/dev/null
"$P/scripts/verify-1-2-20-3-12-object-timeline.sh" "$P"
echo "1.2/20/3-13 OBJECT FRESHNESS ENGINE PASS"
