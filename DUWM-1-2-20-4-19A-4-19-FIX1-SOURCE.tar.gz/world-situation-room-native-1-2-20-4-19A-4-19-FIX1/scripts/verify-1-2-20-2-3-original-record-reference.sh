#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
S="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/Signal.java"
R="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/OriginalRecordRef.java"
X="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/OriginalRecordResolver.java"
V="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/SatelliteMapView.java"
test -s "$R"; test -s "$X"
grep -F 'public final OriginalRecordRef originalRecord;' "$S" >/dev/null
grep -F 'new OriginalRecordRef(' "$S" >/dev/null
grep -F 'public final String providerRecordId;' "$R" >/dev/null
grep -F 'public final String canonicalId;' "$R" >/dev/null
grep -F 'providerRecordId.equals(signal.id)' "$R" >/dev/null
grep -F 'providerId.equals(signal.providerId)' "$R" >/dev/null
grep -F 'OriginalRecordResolver' "$X" >/dev/null
grep -F 'ref.matches(signal)' "$X" >/dev/null
grep -F 'findByCanonicalOrId' "$V" >/dev/null
grep -F 'key.equals(s.canonicalId) || key.equals(s.id)' "$V" >/dev/null
"$P/scripts/verify-1-2-20-2-2-provider-identity.sh" "$P"
echo "1.2/20/2-3 ORIGINAL RECORD REFERENCE PASS"
