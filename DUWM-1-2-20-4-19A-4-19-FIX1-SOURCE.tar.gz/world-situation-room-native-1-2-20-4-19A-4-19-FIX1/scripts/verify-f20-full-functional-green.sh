#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
grep -F 'F20 / 20 — FULL FUNCTIONAL GREEN GATE' "$M" >/dev/null
grep -F 'F20 FUNCTIONAL GREEN' "$M" >/dev/null
grep -F 'F9 SOURCE / DETAIL / CHRONOLOGY OWNED' "$M" >/dev/null
grep -F 'f19CoreTapsReady()' "$M" >/dev/null
grep -F 'new NewsStore(this).load()!=null' "$M" >/dev/null
grep -F 'F9 / 20-REGION OPERATIONAL FEED' "$M" >/dev/null
grep -F 'List<NewsItem> all = store.load()' "$M" >/dev/null
grep -F 'showLocalNewsDetail(n)' "$M" >/dev/null
test "$(find "$P/app/src/main/java" -name 'NewsStore.java' | wc -l)" -eq 1
grep -F 'f11CountryMatches(n,f9CountryLens)' "$M" >/dev/null
grep -F 'f12ReplayMatches(n)' "$M" >/dev/null
grep -F 'f13ReplayAnchorMs' "$M" >/dev/null
grep -F 'addF14Related(box,n)' "$M" >/dev/null
grep -F 'addF15UnifiedResults(catalogList,unifiedQuery)' "$M" >/dev/null
grep -F 'f16StateLine(f16NewsState(all,offline,prefs))' "$M" >/dev/null
grep -F 'f17RestoreState()' "$M" >/dev/null
! grep -F 'addMissionAction(row, "REGION"' "$M"
! grep -F 'addMissionAction(row, "REPLAY"' "$M"
grep -F 'F19 TAP GATE' "$M" >/dev/null
! find "$P/app/src/main/java" -name '*F20*Activity.java' -print -quit | grep -q .
echo "F20 FULL FUNCTIONAL GREEN CONTRACT PASS"
