#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$J/MainActivity.java"
# FIX1: verify the current deepened implementation directly. Do not recursively run pre-deepening
# 4.x text-contract gates whose implementation classes were intentionally replaced by 4.19A.
test -f "$J/LiveChangeRegistry.java"; test -f "$J/MovementIntelligence.java"; test -f "$J/GeographicActivityZones.java"
test -f "$J/IncidentFormationEngine.java"; test -f "$J/RegionalPriorityEngine.java"; test -f "$J/ProximityIntelligence.java"
test -f "$J/LiveChangeTimeline.java"; test -f "$J/CrossSourceEvidencePanel.java"; test -f "$J/NewsEventLinkEngine.java"
test -f "$J/LocationIntelligence.java"; test -f "$J/UgandaOperationsView.java"; test -f "$J/EastAfricaOperationsView.java"
test -f "$J/WatchChangeDetection.java"; test -f "$J/OperationalPriorityEngine.java"; test -f "$J/LiveIntelligenceSearch.java"; test -f "$J/SituationBriefGenerator.java"
grep -F 'ONE-REFRESH MISSING ≠ PERSISTENTLY MISSING' "$M" >/dev/null
grep -F 'NO PREDICTED PATH • DATA GAPS EXPOSED' "$M" >/dev/null
grep -F 'ZONE TREND ≠ INCIDENT' "$M" >/dev/null
grep -F 'INCIDENT LIFECYCLE ≠ CONFIRMATION' "$M" >/dev/null
grep -F 'BOUNDS ≠ LEGAL BORDER' "$M" >/dev/null
grep -F 'DISTANCE BAND ≠ RELATIONSHIP ≠ INCIDENT' "$M" >/dev/null
grep -F 'DISTINCT PROVIDER ≠ INDEPENDENT REPORTING' "$M" >/dev/null
grep -F 'REJECTIONS EXPOSED' "$M" >/dev/null
grep -F 'BORDER CONTEXT KEPT SEPARATE' "$M" >/dev/null
grep -F 'BORDER CONTEXT EXPLICIT' "$M" >/dev/null
grep -F 'UNREAD STATE ≠ SOURCE STATE' "$M" >/dev/null
grep -F 'CONTRIBUTION LEDGER' "$M" >/dev/null
grep -F 'EXACT IDS RANK FIRST' "$M" >/dev/null
grep -F 'NO UNSOURCED CONCLUSION' "$M" >/dev/null
grep -F 'cardFacts.put("GENERATED AT"' "$M" >/dev/null
grep -F 'cardFacts.put("CARD LIMITATION"' "$M" >/dev/null
grep -F 'sourceButton.setOnClickListener' "$M" >/dev/null
grep -F 'detailWatchButton.setOnClickListener' "$M" >/dev/null
grep -F 'detailShareButton.setOnClickListener' "$M" >/dev/null
grep -F 'restoreDetailReturnState()' "$M" >/dev/null
grep -F 'routeUniversalGlobeTap(exact)' "$M" >/dev/null
! grep -R -E 'android\.webkit\.WebView|okhttp3|okio\.' "$J"
echo "1.2/20/4.19A/4.19 FIX1 CURRENT-DEEPENED REGRESSION PASS"
