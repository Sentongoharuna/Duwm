#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$J/MainActivity.java";W="$J/WatchChangeDetection.java";C="$J/CanonicalWatchStore.java"
"$P/scripts/verify-1-2-20-4-19A-4-12-east-africa-operations-deepening.sh" "$P"
grep -F 'public long lastViewed' "$C" >/dev/null
grep -F 'newSinceView,persistentlyMissing' "$W" >/dev/null
grep -F 'NEW SINCE LAST VIEW' "$M" >/dev/null
grep -F 'CHANGES SINCE WATCH' "$M" >/dev/null
grep -F 'DELTA  ' "$M" >/dev/null
grep -F 'PROVIDER ΔT' "$M" >/dev/null
grep -F 'canonicalWatchStore.markViewed(signal.canonicalId,System.currentTimeMillis())' "$M" >/dev/null
grep -F 'UNREAD STATE ≠ SOURCE STATE • PERSISTENT MISSING EXPOSED' "$M" >/dev/null
echo "1.2/20/4.19A/4.14 WATCH CHANGE DEEPENING PASS"
