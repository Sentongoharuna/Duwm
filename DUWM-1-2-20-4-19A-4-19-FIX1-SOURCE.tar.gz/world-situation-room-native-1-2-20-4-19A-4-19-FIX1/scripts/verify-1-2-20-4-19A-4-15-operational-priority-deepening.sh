#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";O="$J/OperationalPriorityEngine.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-19A-4-14-watch-change-deepening.sh" "$P"
grep -F 'class Factor' "$O" >/dev/null
grep -F 'UGANDA BORDER CONTEXT' "$O" >/dev/null
grep -F 'MULTI-RECORD CANDIDATE' "$O" >/dev/null
grep -F 'duplicateEvidenceOnly' "$O" >/dev/null
grep -F 'CONTRIBUTION LEDGER' "$M" >/dev/null
grep -F 'NOT APPLIED' "$M" >/dev/null
grep -F 'NON-CONTRIBUTORS EXPOSED' "$M" >/dev/null
grep -F 'SOURCE SEVERITY UNCHANGED' "$M" >/dev/null
echo "1.2/20/4.19A/4.15 OPERATIONAL PRIORITY DEEPENING PASS"
