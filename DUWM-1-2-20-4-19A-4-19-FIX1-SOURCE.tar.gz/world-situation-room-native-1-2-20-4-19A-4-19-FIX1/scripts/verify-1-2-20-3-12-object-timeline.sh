#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";T="$J/CanonicalTimelineRegistry.java";M="$J/MainActivity.java"
test -s "$T"
grep -F 'keyed by canonical identity' "$T" >/dev/null
grep -F 'private static final int MAX=24' "$T" >/dev/null
grep -F 'histories.get(s.canonicalId)' "$T" >/dev/null
grep -F 'providerTimeMs=s.timestampChain==null?s.timestampMs:s.timestampChain.providerTimeMs' "$T" >/dev/null
grep -F 'while(h.size()>MAX)h.removeFirst()' "$T" >/dev/null
grep -F 'Collections.reverse(out)' "$T" >/dev/null
grep -F 'canonicalTimelineRegistry.accept(operational.signals)' "$M" >/dev/null
grep -F 'OBJECT TIMELINE' "$M" >/dev/null
grep -F 'PROVIDER OBSERVATIONS ONLY • NEWEST FIRST • MAX 24' "$M" >/dev/null
"$P/scripts/verify-1-2-20-3-11-related-intelligence.sh" "$P"
echo "1.2/20/3-12 OBJECT TIMELINE PASS"
