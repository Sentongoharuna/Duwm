#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
grep -F 'F16 / 20 — HONEST DATA STATES' "$M" >/dev/null
grep -F 'OFFLINE · NO SAVED NEWS' "$M" >/dev/null
grep -F 'OFFLINE · SHOWING SAVED NEWS' "$M" >/dev/null
grep -F 'NO CURRENT RECORDS · SOURCES CHECKING' "$M" >/dev/null
grep -F 'FRESHNESS UNKNOWN' "$M" >/dev/null
grep -F 'STALE · LAST REFRESH' "$M" >/dev/null
grep -F 'LOCATION UNKNOWN' "$M" >/dev/null
grep -F 'SOURCE UNKNOWN' "$M" >/dev/null
grep -F 'TIME UNKNOWN' "$M" >/dev/null
grep -F 'f16StateLine(f16NewsState(all,offline,prefs))' "$M" >/dev/null
grep -F 'NO CURRENT RECORDS · "+f9CountryLens+" · "+f12ReplayWindow' "$M" >/dev/null
# F9-F15 remain.
grep -F 'f11CountryMatches(n,f9CountryLens)' "$M" >/dev/null
grep -F 'f12ReplayMatches(n)' "$M" >/dev/null
grep -F 'f13ReplayAnchorMs' "$M" >/dev/null
grep -F 'addF14Related(box,n)' "$M" >/dev/null
grep -F 'addF15UnifiedResults(catalogList,unifiedQuery)' "$M" >/dev/null
! find "$P/app/src/main/java" -name '*F16*Activity.java' -print -quit | grep -q .
test "$(find "$P/app/src/main/java" -name 'NewsStore.java' | wc -l)" -eq 1
echo "F16 HONEST DATA STATES CONTRACT PASS"
