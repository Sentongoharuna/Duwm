#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";V="$J/SatelliteMapView.java";M="$J/MainActivity.java"
grep -F 'temporary provider loss retains the last observed position' "$V" >/dev/null
grep -F 'public Signal getFollowedSignal()' "$V" >/dev/null
grep -F 'public String getFollowedCanonicalId()' "$V" >/dev/null
grep -F 'mapView.isFollowing(selectedSignal.canonicalId)' "$M" >/dev/null
grep -F 'findCanonical(operational.signals, selectedSignal.canonicalId)' "$M" >/dev/null
grep -F 'refreshTrackedAircraftSheet(trackedUpdate)' "$M" >/dev/null
grep -F 'TRACK MODE  LIVE CANONICAL FOLLOW' "$M" >/dev/null
grep -F 'sourceButton.setText("STOP FOLLOWING")' "$M" >/dev/null
"$P/scripts/verify-1-2-20-3-3-aircraft-intelligence.sh" "$P"
echo "1.2/20/3-4 AIRCRAFT LIVE TRACK PASS"
