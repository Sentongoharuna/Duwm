#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
grep -F 'detail -> Globe round-trip snapshot' "$M" >/dev/null
grep -F 'detailReturnGlobeMode = mapView.isGlobeMode()' "$M" >/dev/null
grep -F 'detailReturnLat = mapView.getCenterLatitude()' "$M" >/dev/null
grep -F 'detailReturnLon = mapView.getCenterLongitude()' "$M" >/dev/null
grep -F 'detailReturnZoom = mapView.getZoom()' "$M" >/dev/null
grep -F 'detailReturnCanonicalId = signal == null ? "" : signal.canonicalId' "$M" >/dev/null
grep -F 'restoreDetailReturnState()' "$M" >/dev/null
grep -F 'mapView.highlightSignal(s)' "$M" >/dev/null
grep -F 'captureDetailReturnState(signal)' "$M" >/dev/null
"$P/scripts/verify-1-2-20-2-15-tap-exact-detail.sh" "$P"
echo "1.2/20/2-16 DETAIL GLOBE ROUND TRIP PASS"
