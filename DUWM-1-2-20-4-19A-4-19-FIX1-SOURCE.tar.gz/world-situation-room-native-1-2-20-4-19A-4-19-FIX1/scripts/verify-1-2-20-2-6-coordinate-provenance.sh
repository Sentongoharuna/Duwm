#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
C="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/CoordinateProvenance.java"
S="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/Signal.java"
R="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/OriginalRecordRef.java"
test -s "$C"
for x in PROVIDER CALCULATED_ORBIT RESOLVED_PLACE MONITOR_SUPPLIED UNAVAILABLE; do grep -F "$x" "$C" >/dev/null; done
grep -F 'this.coordinateProvenance = CoordinateProvenance.forSignal(' "$S" >/dev/null
grep -F 'Double.isFinite(latitude) && Double.isFinite(longitude)' "$S" >/dev/null
grep -F 'public final CoordinateProvenance.Origin coordinateOrigin;' "$R" >/dev/null
grep -F 'this.coordinateProvenance.origin' "$S" >/dev/null
grep -F 'layer == Signal.Layer.SATELLITES' "$C" >/dev/null
grep -F 'Origin.UNAVAILABLE' "$C" >/dev/null
"$P/scripts/verify-1-2-20-2-5-freshness-state.sh" "$P"
echo "1.2/20/2-6 COORDINATE PROVENANCE PASS"
