#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
grep -F 'F18 SINGLE OWNER · REGION = country lens · REPLAY = timeline controls' "$M" >/dev/null
grep -F 'addMissionAction(row, "NEWS", view -> openCatalog("NEWS"))' "$M" >/dev/null
! grep -F 'addMissionAction(row, "REGION"' "$M"
! grep -F 'addMissionAction(row, "REPLAY"' "$M"
# The real functions remain, only duplicate/static dock ownership is removed.
grep -F 'showRegionalOverview()' "$M" >/dev/null
grep -F 'toggleReplayPanel()' "$M" >/dev/null
# F9 owns replacement controls.
grep -F 'buildF11CountryBar(all)' "$M" >/dev/null
grep -F 'buildF12ReplayBar()' "$M" >/dev/null
grep -F '"‹ PREVIOUS"' "$M" >/dev/null
grep -F '"NEXT ›"' "$M" >/dev/null
grep -F '"LIVE"' "$M" >/dev/null
# cumulative F14-F17 retained.
grep -F 'addF14Related(box,n)' "$M" >/dev/null
grep -F 'addF15UnifiedResults(catalogList,unifiedQuery)' "$M" >/dev/null
grep -F 'f16StateLine(f16NewsState(all,offline,prefs))' "$M" >/dev/null
grep -F 'f17RestoreState()' "$M" >/dev/null
! find "$P/app/src/main/java" -name '*F18*Activity.java' -print -quit | grep -q .
test "$(find "$P/app/src/main/java" -name 'NewsStore.java' | wc -l)" -eq 1
echo "F18 REMOVE DUPLICATE STATIC UI CONTRACT PASS"
