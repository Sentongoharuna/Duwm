#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
grep -F 'F19 / 20 — FUNCTIONAL TAP GATE' "$M" >/dev/null
grep -F 'f19CoreTapsReady()' "$M" >/dev/null
grep -F 'F19 TAP GATE' "$M" >/dev/null

# Mission dock actions must have handlers.
grep -F 'addMissionAction(row, "GLOBE", view -> showGlobeOverview())' "$M" >/dev/null
grep -F 'addMissionAction(row, "MONITORS", view -> openLocalMonitors())' "$M" >/dev/null
grep -F 'addMissionAction(row, "NEWS", view -> openCatalog("NEWS"))' "$M" >/dev/null

# F11 country taps.
grep -F 'b.setOnClickListener(v->{f9CountryLens=country' "$M" >/dev/null
# F12/F13 chronology taps.
grep -F 'Button prev=compactButton("‹ PREVIOUS");prev.setOnClickListener' "$M" >/dev/null
grep -F 'Button next=compactButton("NEXT ›");next.setEnabled' "$M" >/dev/null
grep -F 'Button live=compactButton("LIVE");live.setOnClickListener' "$M" >/dev/null
# F14/F15 exact result taps.
grep -F 'addF14Related(box,n)' "$M" >/dev/null
grep -F 'showLocalNewsDetail(n)' "$M" >/dev/null
grep -F 'openLocalMonitors(m.id)' "$M" >/dev/null
grep -F 'showDetail(s)' "$M" >/dev/null

# Exact news detail actions.
grep -F '"OPEN FULL ARTICLE","SHARE","MARK READ","HIDE THIS OUTLET","FOLLOW TOPIC","SHOW ON GLOBE"' "$M" >/dev/null
grep -F 'Intent.ACTION_VIEW' "$M" >/dev/null
grep -F 'Intent.ACTION_SEND' "$M" >/dev/null
grep -F 'new NewsStore(this).markRead(n.id)' "$M" >/dev/null
grep -F 'prefs.source(n.sourceId,false)' "$M" >/dev/null
grep -F 'prefs.topic(n.topic,true)' "$M" >/dev/null

# Dead/duplicate top-level REGION/REPLAY controls stay rejected.
! grep -F 'addMissionAction(row, "REGION"' "$M"
! grep -F 'addMissionAction(row, "REPLAY"' "$M"

# Cumulative ownership and no parallel store/activity.
grep -F 'f16StateLine(f16NewsState(all,offline,prefs))' "$M" >/dev/null
grep -F 'f17RestoreState()' "$M" >/dev/null
! find "$P/app/src/main/java" -name '*F19*Activity.java' -print -quit | grep -q .
test "$(find "$P/app/src/main/java" -name 'NewsStore.java' | wc -l)" -eq 1
echo "F19 FUNCTIONAL TAP GATE PASS"
