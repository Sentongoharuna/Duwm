#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
grep -F 'share the exact canonical record provenance' "$M" >/dev/null
grep -F 'signal = resolveExactSignal(signal)' "$M" >/dev/null
for x in 'CANONICAL OBJECT ID' 'PROVIDER ID' 'PROVIDER NAME' 'PROVIDER RECORD ID' 'COORDINATE ORIGIN' FRESHNESS 'PROVIDER TIME' 'FIRST SEEN' 'FETCHED AT' 'RELATIONSHIP ID'; do grep -F "cardFacts.put(\"$x\"" "$M" >/dev/null; done
grep -F 'signal.nativePayload.facts' "$M" >/dev/null
grep -F 'signal.sourceUrl' "$M" >/dev/null
"$P/scripts/verify-1-2-20-2-17-track-watch-canonical.sh" "$P"
echo "1.2/20/2-18 SHARE PROVENANCE PASS"
