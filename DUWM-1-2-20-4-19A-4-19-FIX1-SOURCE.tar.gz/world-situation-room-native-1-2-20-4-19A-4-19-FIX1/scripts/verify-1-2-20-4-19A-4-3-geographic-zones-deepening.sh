#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";Z="$J/GeographicActivityZones.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-19A-4-2-movement-deepening.sh" "$P"
grep -F 'persistent observed activity zones with stability/trend and bounded state' "$Z" >/dev/null
grep -F 'enum Trend { NEW, INCREASING, STABLE, DECREASING }' "$Z" >/dev/null
grep -F 'zoneId' "$Z" >/dev/null
grep -F 'providerCount' "$Z" >/dev/null
grep -F 'consecutiveRefreshes' "$Z" >/dev/null
grep -F 'while(memory.size()>256)' "$Z" >/dev/null
grep -F 'geographicActivityZoneEngine.detect(layerSignals.values(), freshnessNow)' "$M" >/dev/null
grep -F 'ZONE ID' "$M" >/dev/null
grep -F 'DISTINCT PROVIDERS' "$M" >/dev/null
grep -F 'ACTIVITY TREND' "$M" >/dev/null
grep -F 'CONSECUTIVE REFRESHES' "$M" >/dev/null
grep -F 'FIRST OBSERVED' "$M" >/dev/null
grep -F 'ZONE TREND ≠ INCIDENT • CURRENT LOCATED RECORDS ONLY • ZONE STATE BOUNDED' "$M" >/dev/null
echo "1.2/20/4.19A/4.3 GEOGRAPHIC ACTIVITY ZONES DEEPENING PASS"
