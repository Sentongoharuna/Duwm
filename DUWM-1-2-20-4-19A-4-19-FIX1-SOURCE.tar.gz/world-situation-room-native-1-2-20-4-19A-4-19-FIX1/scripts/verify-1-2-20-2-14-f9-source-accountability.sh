#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";H="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/NewsSourceHealth.java";A="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/NewsAggregator.java";C="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/NewsSourceCatalog.java"
test -s "$H"
grep -F 'enum State{WORKING,UNAVAILABLE,CHECKING,STALE}' "$H" >/dev/null
grep -F 'lastSuccessMs' "$H" >/dev/null; grep -F 'lastCheckedMs' "$H" >/dev/null; grep -F 'workingFeed' "$H" >/dev/null
grep -F 'prefs.status(s.id,"Checking")' "$A" >/dev/null
grep -F 'prefs.setTime("checked_"+s.id' "$A" >/dev/null
grep -F 'prefs.setTime("success_"+s.id' "$A" >/dev/null
grep -F 'List<NewsSourceHealth> health' "$C" >/dev/null
test "$(grep -c 'new NewsSource(' "$C")" -ge 43
"$P/scripts/verify-1-2-20-2-13-f9-news-pipeline.sh" "$P"
echo "1.2/20/2-14 F9 SOURCE ACCOUNTABILITY PASS"
