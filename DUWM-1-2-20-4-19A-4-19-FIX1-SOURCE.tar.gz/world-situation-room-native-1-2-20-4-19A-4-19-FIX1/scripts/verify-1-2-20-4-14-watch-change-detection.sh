#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";W="$J/WatchChangeDetection.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-13-watchlist-operations-board.sh" "$P"
test -s "$W"
grep -F 'meaningful changes for watched canonical identities only' "$W" >/dev/null
grep -F 'for(CanonicalWatchStore.Watch w:store.all())' "$W" >/dev/null
grep -F 'registry.changesFor(w.canonicalId)' "$W" >/dev/null
grep -F 'changes.get(0)' "$W" >/dev/null
grep -F 'CURRENT RECORD MISSING' "$W" >/dev/null
grep -F 'WATCH CHANGE DETECTION' "$M" >/dev/null
grep -F 'WATCHED OBJECTS WITH CHANGES' "$M" >/dev/null
grep -F 'WatchChangeDetection.state(item)' "$M" >/dev/null
grep -F 'CHANGE ≠ ALERT ≠ INCIDENT • WATCHED IDENTITY ONLY' "$M" >/dev/null
echo "1.2/20/4-14 WATCH CHANGE DETECTION PASS"
