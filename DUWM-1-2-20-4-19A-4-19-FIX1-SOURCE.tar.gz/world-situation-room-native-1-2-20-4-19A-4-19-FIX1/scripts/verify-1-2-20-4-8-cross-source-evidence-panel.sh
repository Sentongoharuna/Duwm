#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";E="$J/CrossSourceEvidencePanel.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-7-live-change-timeline.sh" "$P"
test -s "$E"
grep -F 'evidence roles preserve independent provider records and never score truth' "$E" >/dev/null
grep -F 'PRIMARY_RECORD, RELATED_PROVIDER_RECORD, SAME_PROVIDER_RELATED' "$E" >/dev/null
grep -F 'seen.add(focus.canonicalId)' "$E" >/dev/null
grep -F 'focus.providerId.equals(s.providerId)' "$E" >/dev/null
grep -F 'relationshipRegistry.relatedTo(signal)' "$M" >/dev/null
grep -F 'CROSS-SOURCE EVIDENCE' "$M" >/dev/null
grep -F 'INDEPENDENT RECORDS' "$M" >/dev/null
grep -F 'DISTINCT PROVIDERS' "$M" >/dev/null
grep -F 'RELATED EVIDENCE ≠ CORROBORATION ≠ CONFIRMATION • NO TRUTH SCORE' "$M" >/dev/null
echo "1.2/20/4-8 CROSS-SOURCE EVIDENCE PANEL PASS"
