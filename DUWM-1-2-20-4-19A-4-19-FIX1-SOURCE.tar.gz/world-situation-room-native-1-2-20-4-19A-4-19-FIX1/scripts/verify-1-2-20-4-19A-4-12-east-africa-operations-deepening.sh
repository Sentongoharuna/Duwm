#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";E="$J/EastAfricaOperationsView.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-19A-4-11-uganda-operations-deepening.sh" "$P"
grep -F 'deep East Africa operations lens over worldwide canonical records' "$E" >/dev/null
grep -F 'UGANDA_BORDER' "$E" >/dev/null
grep -F 'latestChanges' "$E" >/dev/null
grep -F 'freshness' "$E" >/dev/null
grep -F 'UGANDA RECORDS' "$M" >/dev/null
grep -F 'UGANDA BORDER CONTEXT' "$M" >/dev/null
grep -F 'FRESHNESS DISTRIBUTION' "$M" >/dev/null
grep -F 'LATEST MEANINGFUL REGIONAL CHANGES' "$M" >/dev/null
grep -F 'BORDER CONTEXT EXPLICIT' "$M" >/dev/null
echo "1.2/20/4.19A/4.12 EAST AFRICA OPERATIONS DEEPENING PASS"
