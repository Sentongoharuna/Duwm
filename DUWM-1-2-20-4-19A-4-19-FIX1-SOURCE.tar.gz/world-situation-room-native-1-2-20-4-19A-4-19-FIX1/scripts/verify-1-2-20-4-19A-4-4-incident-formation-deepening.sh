#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";I="$J/IncidentFormationEngine.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-19A-4-3-geographic-zones-deepening.sh" "$P"
grep -F 'evidence-ledger incident candidates with lifecycle; never automatic confirmation' "$I" >/dev/null
grep -F 'FORMING, ACTIVE_RELATED, COOLING, NO_LONGER_CURRENT' "$I" >/dev/null
grep -F 'enum Basis { RELATIONSHIP_ID, SAME_CANONICAL_GROUP }' "$I" >/dev/null
grep -F 'List<Evidence> evidence' "$I" >/dev/null
grep -F 'State.COOLING' "$I" >/dev/null
grep -F 'State.NO_LONGER_CURRENT' "$I" >/dev/null
grep -F 'while(memory.size()>256)' "$I" >/dev/null
grep -F 'incidentFormationEngine.form(layerSignals.values(), freshnessNow)' "$M" >/dev/null
grep -F 'EVIDENCE LEDGER' "$M" >/dev/null
grep -F 'CONSECUTIVE REFRESHES' "$M" >/dev/null
grep -F 'INCIDENT LIFECYCLE ≠ CONFIRMATION • EVIDENCE RECORDS REMAIN INDEPENDENT' "$M" >/dev/null
echo "1.2/20/4.19A/4.4 INCIDENT FORMATION DEEPENING PASS"
