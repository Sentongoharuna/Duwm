#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";S="$J/LiveIntelligenceSearch.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-19A-4-15-operational-priority-deepening.sh" "$P"
grep -F 'ranked multi-result current canonical intelligence search' "$S" >/dev/null
grep -F '"uganda".equals(q)' "$S" >/dev/null
grep -F '"east africa".equals(q)' "$S" >/dev/null
grep -F 'findLiveIntelligenceSearchResults' "$M" >/dev/null
grep -F 'RANKED CURRENT MATCHES' "$M" >/dev/null
grep -F 'SCORE ' "$M" >/dev/null
grep -F 'MULTI-RESULT RANKING • CURRENT CANONICAL RECORDS ONLY • EXACT IDS RANK FIRST' "$M" >/dev/null
echo "1.2/20/4.19A/4.16 LIVE SEARCH DEEPENING PASS"
