#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";C="$J/LiveChangeRegistry.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-3-20-globe-intelligence-green.sh" "$P"
test -s "$C"
grep -F 'APPEARED, MOVED, HEADING_CHANGED, SPEED_CHANGED, SEVERITY_CHANGED, STATE_CHANGED, UPDATED, DISAPPEARED' "$C" >/dev/null
grep -F 'previous.get(layer)' "$C" >/dev/null
grep -F 'distanceKm(a.lat,a.lon,b.lat,b.lon)>=0.25d' "$C" >/dev/null
grep -F 'angle(o.heading,n.heading)>=12d' "$C" >/dev/null
grep -F 'Math.abs(n.speed-o.speed)>=5d' "$C" >/dev/null
grep -F 'if(o.severity!=n.severity)' "$C" >/dev/null
grep -F 'if(!o.freshness.equals(n.freshness))' "$C" >/dev/null
grep -F 'if(n.providerTime>o.providerTime)' "$C" >/dev/null
grep -F 'Kind.DISAPPEARED' "$C" >/dev/null
grep -F 'while(h.size()>32)h.removeFirst()' "$C" >/dev/null
grep -F 'liveChangeRegistry.accept(layer, operational.signals, freshnessNow)' "$M" >/dev/null
grep -F 'LIVE CHANGE DETECTION' "$M" >/dev/null
grep -F 'CHANGE ≠ INCIDENT • PROVIDER OBSERVATIONS ONLY' "$M" >/dev/null
echo "1.2/20/4-1 LIVE CHANGE DETECTION PASS"
