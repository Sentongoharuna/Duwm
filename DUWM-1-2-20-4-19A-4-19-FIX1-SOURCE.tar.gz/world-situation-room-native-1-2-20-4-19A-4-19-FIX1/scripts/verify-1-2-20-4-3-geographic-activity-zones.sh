#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";Z="$J/GeographicActivityZones.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-2-object-movement-intelligence.sh" "$P"
test -s "$Z"
grep -F 'observed geographic concentration from current located provider records' "$Z" >/dev/null
grep -F '<=75d' "$Z" >/dev/null
grep -F 'if(members.size()<4)continue' "$Z" >/dev/null
grep -F 'out.sort((a,b)->Integer.compare(b.objectCount,a.objectCount))' "$Z" >/dev/null
grep -F 'GeographicActivityZones.detect(layerSignals.values())' "$M" >/dev/null
grep -F 'GEOGRAPHIC ACTIVITY ZONE' "$M" >/dev/null
grep -F 'OBSERVED OBJECTS' "$M" >/dev/null
grep -F 'DENSITY ≠ INCIDENT • CURRENT LOCATED RECORDS ONLY' "$M" >/dev/null
echo "1.2/20/4-3 GEOGRAPHIC ACTIVITY ZONES PASS"
