#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$J/MainActivity.java";R="$J/WorldDataRepository.java"
grep -F 'earthquake/natural-event intelligence from the exact provider payload' "$M" >/dev/null
grep -F 'signal.layer != Signal.Layer.NATURAL' "$M" >/dev/null
for x in MAGNITUDE DEPTH 'FELT REPORTS' ALERT CATEGORY STATUS 'EVENT ID'; do grep -F "\"$x\"" "$M" >/dev/null; done
grep -F 'EVENT TIME' "$M" >/dev/null
grep -F 'FRESHNESS' "$M" >/dev/null
grep -F 'SOURCE RECORD' "$M" >/dev/null
grep -F 'facts.put("MAGNITUDE"' "$R" >/dev/null
grep -F 'facts.put("DEPTH"' "$R" >/dev/null
grep -F 'facts.put("FELT REPORTS"' "$R" >/dev/null
grep -F 'facts.put("EVENT ID"' "$R" >/dev/null
grep -F 'signal.layer == Signal.Layer.NATURAL' "$M" >/dev/null
"$P/scripts/verify-1-2-20-3-5-aircraft-trail.sh" "$P"
echo "1.2/20/3-6 EVENT INTELLIGENCE PASS"
