#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";G="$J/GeoIndex.java";N="$J/NewsSignals.java";M="$J/MainActivity.java"
grep -F 'controlled Uganda / East Africa named-place index' "$G" >/dev/null
for x in kampala entebbe jinja mbarara gulu mbale 'fort portal' masaka arua lira soroti kabale hoima kasese moroto nairobi mombasa kisumu 'dar es salaam' arusha kigali bujumbura juba; do grep -F "add(\"$x\"" "$G" >/dev/null; done
grep -F 'public static Point findSpecific(String text)' "$G" >/dev/null
grep -F 'country-only mentions do not create a marker' "$G" >/dev/null
grep -F 'GeoIndex.findSpecific(n.title+" "+n.summary+" "+n.region)' "$N" >/dev/null
grep -F 'GeoIndex.findSpecific(n.title+" "+n.summary+" "+n.region)' "$M" >/dev/null
grep -F 'Double.NaN' "$N" >/dev/null
"$P/scripts/verify-1-2-20-3-9-news-globe-intelligence.sh" "$P" || {
  # Build 10 intentionally replaces the old generic GeoIndex.find assertion with findSpecific.
  sed 's/GeoIndex.find(n.title+" "+n.summary+" "+n.region)/GeoIndex.findSpecific(n.title+" "+n.summary+" "+n.region)/' "$P/scripts/verify-1-2-20-3-9-news-globe-intelligence.sh" > "$P/scripts/.v9"
  chmod +x "$P/scripts/.v9"; "$P/scripts/.v9" "$P"
}
echo "1.2/20/3-10 EAST AFRICA RESOLVER PASS"
