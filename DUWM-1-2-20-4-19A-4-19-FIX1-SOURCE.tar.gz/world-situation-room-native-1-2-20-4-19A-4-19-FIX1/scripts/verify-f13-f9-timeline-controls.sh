#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
grep -F 'f13ReplayAnchorMs' "$M" >/dev/null
grep -F '"‹ PREVIOUS"' "$M" >/dev/null
grep -F '"NEXT ›"' "$M" >/dev/null
grep -F '"LIVE"' "$M" >/dev/null
grep -F 'F13 REPLAY' "$M" >/dev/null
grep -F 'long end=f13ReplayAnchorMs>0?f13ReplayAnchorMs:System.currentTimeMillis()' "$M" >/dev/null
grep -F 'long start=end-f12WindowMs(f12ReplayWindow)' "$M" >/dev/null
grep -F 'f11CountryMatches(n,f9CountryLens)' "$M" >/dev/null
grep -F 'showLocalNewsDetail(n)' "$M" >/dev/null
grep -F 'List<NewsItem> all = store.load()' "$M" >/dev/null
! find "$P/app/src/main/java" -name '*F13*Activity.java' -print -quit | grep -q .
test "$(find "$P/app/src/main/java" -name 'NewsStore.java' | wc -l)" -eq 1
echo "F13 / F9 TIMELINE CONTROLS CONTRACT PASS"
