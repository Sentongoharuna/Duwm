#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";X="$J/ProximityIntelligence.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-5-regional-priority-engine.sh" "$P"
test -s "$X"
grep -F 'factual proximity from current located canonical provider records' "$X" >/dev/null
grep -F 's.canonicalId.equals(focus.canonicalId)' "$X" >/dev/null
grep -F 'if(d>radiusKm)continue' "$X" >/dev/null
grep -F 'out.sort((a,b)->Double.compare(a.distanceKm,b.distanceKm))' "$X" >/dev/null
grep -F 'PROXIMITY INTELLIGENCE' "$M" >/dev/null
grep -F 'ProximityIntelligence.around(' "$M" >/dev/null
grep -F 'signal,layerSignals.values(),150d,8' "$M" >/dev/null
grep -F 'PROXIMITY ≠ RELATIONSHIP ≠ INCIDENT • CURRENT LOCATED RECORDS ONLY' "$M" >/dev/null
echo "1.2/20/4-6 PROXIMITY INTELLIGENCE PASS"
