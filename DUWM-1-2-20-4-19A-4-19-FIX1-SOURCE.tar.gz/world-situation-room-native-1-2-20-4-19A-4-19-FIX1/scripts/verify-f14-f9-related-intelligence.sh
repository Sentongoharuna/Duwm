#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
grep -F 'F14 / 20 — RELATED INTELLIGENCE' "$M" >/dev/null
grep -F 'new NewsStore(this).load()' "$M" >/dev/null
grep -F 'focus.clusterId.equals(n.clusterId)' "$M" >/dev/null
grep -F 'sameRegion&&sameTopic' "$M" >/dev/null
grep -F 'RELATED INTELLIGENCE' "$M" >/dev/null
grep -F 'addF14Related(box,n)' "$M" >/dev/null
grep -F 'b.setOnClickListener(v->showLocalNewsDetail(n))' "$M" >/dev/null
grep -F 'f11CountryMatches(n,f9CountryLens)' "$M" >/dev/null
grep -F 'f12ReplayMatches(n)' "$M" >/dev/null
grep -F 'f13ReplayAnchorMs' "$M" >/dev/null
! find "$P/app/src/main/java" -name '*F14*Activity.java' -print -quit | grep -q .
test "$(find "$P/app/src/main/java" -name 'NewsStore.java' | wc -l)" -eq 1
echo "F14 / F9 RELATED INTELLIGENCE CONTRACT PASS"
