#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$J/MainActivity.java";R="$J/RelationshipRegistry.java"
grep -F 'RelationshipRegistry relationshipRegistry' "$M" >/dev/null
grep -F 'relationshipRegistry.accept(operational.signals)' "$M" >/dev/null
grep -F 'relationshipRegistry.relatedTo(focus)' "$M" >/dev/null
grep -F 'RELATED INTELLIGENCE' "$M" >/dev/null
grep -F 'RELATIONSHIP ≠ CONFIRMATION' "$M" >/dev/null
grep -F 'RECORDS REMAIN INDEPENDENT' "$M" >/dev/null
grep -F 'g.put(s.canonicalId, s)' "$R" >/dev/null
grep -F '!s.canonicalId.equals(focus.canonicalId)' "$R" >/dev/null
"$P/scripts/verify-1-2-20-3-10-east-africa-resolver.sh" "$P"
echo "1.2/20/3-11 RELATED INTELLIGENCE PASS"
