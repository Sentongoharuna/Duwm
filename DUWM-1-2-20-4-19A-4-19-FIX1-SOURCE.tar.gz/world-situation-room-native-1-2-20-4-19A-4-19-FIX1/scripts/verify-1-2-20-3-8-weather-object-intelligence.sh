#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$J/MainActivity.java";R="$J/WorldDataRepository.java"
grep -F 'RainViewer frame intelligence; radar history is not a forecast' "$M" >/dev/null
grep -F 'weatherFrameIntelligence(WorldDataRepository.RadarFrame frame, int index)' "$M" >/dev/null
for x in 'RADAR OBSERVATION/HISTORY FRAME' 'FRAME TIME' 'FRAME AGE' 'PROVIDER  RainViewer' 'ANIMATION' 'Historical radar frame — not a forecast or ground-impact report'; do grep -F "$x" "$M" >/dev/null; done
grep -F 'mapView.getRadarFrameIndex()' "$M" >/dev/null
grep -F 'radarFrames.get(intelligenceIndex)' "$M" >/dev/null
grep -F 'public static final class RadarFrame' "$R" >/dev/null
grep -F 'public final long timestampMs;' "$R" >/dev/null
grep -F 'setRadarFrames(host, frames)' "$M" >/dev/null
"$P/scripts/verify-1-2-20-3-7-orbit-intelligence.sh" "$P"
echo "1.2/20/3-8 WEATHER OBJECT INTELLIGENCE PASS"
