#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";S="$J/LiveIntelligenceSearch.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-15-operational-priority-engine.sh" "$P"
test -s "$S"
grep -F 'unified live intelligence search over current canonical records and operational metadata' "$S" >/dev/null
grep -F 'q.equals(canonical)' "$S" >/dev/null
grep -F 'q.equals(nativeId)||q.equals(callsign)||q.equals(norad)' "$S" >/dev/null
grep -F 'title.contains(q)' "$S" >/dev/null
grep -F 'provider.contains(q)' "$S" >/dev/null
grep -F '"watched".equals(q)' "$S" >/dev/null
grep -F '"changed".equals(q)' "$S" >/dev/null
grep -F 'findLiveIntelligenceSearchObject(query)' "$M" >/dev/null
grep -F 'if(objectMatch==null)objectMatch=findSearchObject(query)' "$M" >/dev/null
grep -F 'focusSearchObject(objectMatch)' "$M" >/dev/null
grep -F 'LIVE INTELLIGENCE SEARCH IDENTITY' "$M" >/dev/null
grep -F 'SEARCH RETURNS CURRENT CANONICAL RECORDS • PLACE SEARCH REMAINS FALLBACK' "$M" >/dev/null
echo "1.2/20/4-16 LIVE INTELLIGENCE SEARCH PASS"
