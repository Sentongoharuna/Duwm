#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";V="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/SatelliteMapView.java"
grep -F 'private String highlightedCanonicalId = "";' "$V" >/dev/null
grep -F 'highlightedCanonicalId = highlightedSignal == null ? "" : highlightedSignal.canonicalId' "$V" >/dev/null
grep -F 'canonicalObjects.get(highlightedCanonicalId)' "$V" >/dev/null
grep -F 'signal.canonicalId == null || signal.canonicalId.isEmpty() ? signal.id : signal.canonicalId' "$V" >/dev/null
grep -F 'canonicalObjects.get(followedSignalId)' "$V" >/dev/null
grep -F 'signalId.equals(followedSignal.canonicalId)' "$V" >/dev/null
"$P/scripts/verify-1-2-20-2-8-in-place-object-updates.sh" "$P"
echo "1.2/20/2-9 SELECTION PERSISTENCE PASS"
