#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";V="$J/SatelliteMapView.java";M="$J/MainActivity.java"
grep -F 'observed trails are keyed by canonical aircraft identity' "$V" >/dev/null
grep -F 'trackKey(signal)' "$V" >/dev/null
grep -F 'observedTracks.get(trackKey(signal))' "$V" >/dev/null
grep -F 'observedTracks.put(trackKey(signal), history)' "$V" >/dev/null
grep -F 'while (history.size() > MAX_FIXES_PER_TRACK) history.removeFirst()' "$V" >/dev/null
grep -F 'signal.timestampMs > last.timestampMs' "$V" >/dev/null
grep -F 'drawObservedFixTrail' "$V" >/dev/null
grep -F 'findByCanonicalOrId(source, followedSignalId)' "$V" >/dev/null
grep -F 'public int getObservedFixCount(Signal signal)' "$V" >/dev/null
grep -F 'OBSERVED TRAIL' "$M" >/dev/null
grep -F 'Observed provider positions only; no interpolated history' "$M" >/dev/null
"$P/scripts/verify-1-2-20-3-4-aircraft-live-track.sh" "$P"
echo "1.2/20/3-5 AIRCRAFT TRAIL PASS"
