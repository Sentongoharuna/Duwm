#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";R="$J/RegionalPriorityEngine.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-4-incident-formation.sh" "$P"
test -s "$R"
grep -F 'geographic relevance for Uganda/East Africa; relevance is not severity or confirmation' "$R" >/dev/null
grep -F 'enum Band { UGANDA, EAST_AFRICA, GLOBAL }' "$R" >/dev/null
grep -F 'Observed coordinates inside Uganda bounds' "$R" >/dev/null
grep -F 'Observed coordinates inside East Africa bounds' "$R" >/dev/null
grep -F 'Provider text names a controlled Uganda place' "$R" >/dev/null
grep -F 'Provider text names a controlled East Africa place' "$R" >/dev/null
grep -F 'REGIONAL PRIORITY' "$M" >/dev/null
grep -F 'SOURCE SEVERITY' "$M" >/dev/null
grep -F 'RELEVANCE ≠ SEVERITY • NO SOURCE RECORD IS REWRITTEN' "$M" >/dev/null
echo "1.2/20/4-5 REGIONAL PRIORITY ENGINE PASS"
