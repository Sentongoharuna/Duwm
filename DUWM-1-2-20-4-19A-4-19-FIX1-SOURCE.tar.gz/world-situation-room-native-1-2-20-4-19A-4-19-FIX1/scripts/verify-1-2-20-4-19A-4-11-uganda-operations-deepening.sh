#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";U="$J/UgandaOperationsView.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-19A-4-10-location-intelligence-deepening.sh" "$P"
grep -F 'deep Uganda operations snapshot over worldwide canonical records' "$U" >/dev/null
grep -F 'UGANDA_BORDER' "$U" >/dev/null
grep -F 'latestChanges' "$U" >/dev/null
grep -F 'freshness' "$U" >/dev/null
grep -F 'NEAR-UGANDA-BORDER CONTEXT' "$M" >/dev/null
grep -F 'FRESHNESS DISTRIBUTION' "$M" >/dev/null
grep -F 'LATEST MEANINGFUL CHANGES' "$M" >/dev/null
grep -F 'BORDER CONTEXT KEPT SEPARATE' "$M" >/dev/null
echo "1.2/20/4.19A/4.11 UGANDA OPERATIONS DEEPENING PASS"
