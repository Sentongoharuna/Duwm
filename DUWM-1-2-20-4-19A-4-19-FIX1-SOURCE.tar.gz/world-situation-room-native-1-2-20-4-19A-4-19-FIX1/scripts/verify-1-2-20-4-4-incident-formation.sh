#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";I="$J/IncidentFormationEngine.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-3-geographic-activity-zones.sh" "$P"
test -s "$I"
grep -F 'evidence-preserving incident candidate formation' "$I" >/dev/null
grep -F 'String key=s.relationshipId==null||s.relationshipId.isEmpty()?s.canonicalId:s.relationshipId' "$I" >/dev/null
grep -F 'MULTI_SOURCE_RELATED' "$I" >/dev/null
grep -F 'records=Collections.unmodifiableList(x)' "$I" >/dev/null
grep -F 'IncidentFormationEngine.form(layerSignals.values())' "$M" >/dev/null
grep -F 'INCIDENT FORMATION' "$M" >/dev/null
grep -F 'INDEPENDENT RECORDS' "$M" >/dev/null
grep -F 'INCIDENT CANDIDATE ≠ CONFIRMED INCIDENT • RECORDS REMAIN INDEPENDENT' "$M" >/dev/null
echo "1.2/20/4-4 INCIDENT FORMATION PASS"
