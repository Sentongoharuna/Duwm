#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";V="$J/SatelliteMapView.java";M="$J/MainActivity.java"
grep -F 'canonicalSeen.add(key)' "$V" >/dev/null
grep -F 'Collections.sort(hits' "$V" >/dev/null
grep -F 'int limit=Math.min(12,hits.size())' "$V" >/dev/null
grep -F 'OBJECTS HERE • SELECT EXACT RECORD' "$M" >/dev/null
grep -F 'Overlapping Globe markers remain separate canonical objects.' "$M" >/dev/null
grep -F 'Signal current = resolveExactSignal(candidate)' "$M" >/dev/null
grep -F 'current.freshness==null?"UNKNOWN":current.freshness.state.name()' "$M" >/dev/null
grep -F 'current.originalRecord.providerRecordId' "$M" >/dev/null
grep -F 'routeUniversalGlobeTap(exact.get(which))' "$M" >/dev/null
"$P/scripts/verify-1-2-20-3-16-globe-search-exact-object.sh" "$P"
echo "1.2/20/3-17 OVERLAP CLUSTER SELECTION PASS"
