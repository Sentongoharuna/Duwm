#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java";C="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/CrashLedger.java"
grep -F 'public static String recordRecovered' "$C" >/dev/null
grep -F 'CrashLedger.recordRecovered(this,"F17_SAVE",e)' "$M" >/dev/null
grep -F 'CrashLedger.recordRecovered(this,"F17_RESTORE",e)' "$M" >/dev/null
! grep -F 'CrashLedger.record(this,"F17_' "$M"
! grep -F 'DuMonitorPlayer.open' "$M"
"$P/scripts/verify-1-2-20-1-live-object-refresh.sh" "$P"
echo "1.2/20/1 FIX2 PUBLIC CRASHLEDGER API PASS"
