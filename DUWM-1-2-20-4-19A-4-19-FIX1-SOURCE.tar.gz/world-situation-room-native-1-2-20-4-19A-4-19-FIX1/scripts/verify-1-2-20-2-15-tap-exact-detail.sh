#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
grep -F 'TAP -> EXACT CURRENT PROVIDER RECORD' "$M" >/dev/null
grep -F 'OriginalRecordResolver.resolve(tapped.originalRecord, current)' "$M" >/dev/null
grep -F 'signal = resolveExactSignal(signal)' "$M" >/dev/null
grep -F 'signal.layer == Signal.Layer.NEWS' "$M" >/dev/null
grep -F 'signal.nativePayload.value("NEWS ID")' "$M" >/dev/null
grep -F 'new NewsStore(this).load()' "$M" >/dev/null
grep -F 'showLocalNewsDetail(exactNews)' "$M" >/dev/null
grep -F 'openLocalMonitors(exact.id.substring' "$M" >/dev/null
"$P/scripts/verify-1-2-20-2-14-f9-source-accountability.sh" "$P"
echo "1.2/20/2-15 TAP EXACT DETAIL PASS"
