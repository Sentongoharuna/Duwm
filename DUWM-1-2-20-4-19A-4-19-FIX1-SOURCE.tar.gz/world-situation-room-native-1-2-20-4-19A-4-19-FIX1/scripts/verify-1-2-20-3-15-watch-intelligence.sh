#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";W="$J/CanonicalWatchStore.java";M="$J/MainActivity.java"
grep -F 'persistent WATCH keyed only by canonical identity' "$W" >/dev/null
grep -F 'public static final class Watch' "$W" >/dev/null
grep -F '"watched_at_"+s.canonicalId' "$W" >/dev/null
grep -F 'public Watch read(String id)' "$W" >/dev/null
grep -F 'public int count()' "$W" >/dev/null
grep -F 'WATCH state follows canonical identity across refresh and provider loss' "$M" >/dev/null
grep -F 'WATCH  ON' "$M" >/dev/null
grep -F 'Canonical watch survives movement, refresh and temporary provider loss' "$M" >/dev/null
grep -F 'canonicalWatchStore.read(signal.canonicalId)' "$M" >/dev/null
grep -F 'showDetail(selectedSignal)' "$M" >/dev/null
"$P/scripts/verify-1-2-20-3-14-provider-health-from-object.sh" "$P"
echo "1.2/20/3-15 WATCH INTELLIGENCE PASS"
