#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";E="$J/EastAfricaOperationsView.java";M="$J/MainActivity.java"
"$P/scripts/verify-1-2-20-4-11-uganda-operations-view.sh" "$P"
test -s "$E"
grep -F 'East Africa operations lens over the same worldwide canonical records' "$E" >/dev/null
grep -F 'rr.band!=RegionalPriorityEngine.Band.UGANDA&&rr.band!=RegionalPriorityEngine.Band.EAST_AFRICA' "$E" >/dev/null
for c in UGANDA KENYA TANZANIA RWANDA BURUNDI 'SOUTH SUDAN'; do grep -F "\"$c\"" "$E" >/dev/null; done
grep -F 'EAST AFRICA OPERATIONS VIEW' "$M" >/dev/null
grep -F 'CURRENT REGIONAL RECORDS' "$M" >/dev/null
grep -F 'COUNTRY / AREA COUNTS' "$M" >/dev/null
grep -F 'LAYER COUNTS' "$M" >/dev/null
grep -F 'regionalBand == RegionalPriorityEngine.Band.UGANDA || regionalBand == RegionalPriorityEngine.Band.EAST_AFRICA' "$M" >/dev/null
grep -F 'REGIONAL LENS ≠ SEVERITY • UGANDA + WORLDWIDE MONITORING REMAIN ACTIVE' "$M" >/dev/null
echo "1.2/20/4-12 EAST AFRICA OPERATIONS VIEW PASS"
