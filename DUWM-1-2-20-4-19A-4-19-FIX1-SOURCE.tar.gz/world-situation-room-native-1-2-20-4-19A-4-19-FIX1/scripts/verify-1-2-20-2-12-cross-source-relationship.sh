#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
C="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/CrossSourceRelationship.java"
S="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/Signal.java"
R="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/RelationshipRegistry.java"
test -s "$C";test -s "$R"
grep -F 'This is NOT canonical identity' "$C" >/dev/null
grep -F 'if (a.canonicalId != null && a.canonicalId.equals(b.canonicalId)) return false' "$C" >/dev/null
grep -F 'public String relationshipId;' "$S" >/dev/null
grep -F 'CrossSourceRelationship.id(this)' "$S" >/dev/null
grep -F 'g.put(s.canonicalId, s)' "$R" >/dev/null
grep -F '!s.canonicalId.equals(focus.canonicalId)' "$R" >/dev/null
"$P/scripts/verify-1-2-20-2-11-provider-record-dedup.sh" "$P"
echo "1.2/20/2-12 CROSS-SOURCE RELATIONSHIP PASS"
