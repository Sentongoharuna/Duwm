package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** V1154 publicly attributed worldwide source explorer. Never synthesizes detected records. */
public final class WorldSourceHubActivity extends Activity {
  static final int BG=Color.rgb(4,12,25), PANEL=Color.rgb(13,32,49), WHITE=Color.rgb(229,242,247),
      CYAN=Color.rgb(69,216,236), DIM=Color.rgb(150,179,192), ORANGE=Color.rgb(252,184,86);
  static final String[] MODES={"VESSELS","AIRCRAFT","SATELLITES","CITY CAMERAS","WORLD NEWS","RADIO","TV STATIONS","INTERNET"};
  private final Handler main=new Handler(Looper.getMainLooper());
  private final ExecutorService executor=Executors.newSingleThreadExecutor();
  private final AtomicBoolean fetching=new AtomicBoolean(false);
  private TextView title,status;
  private LinearLayout results;
  private String mode="AIRCRAFT";
  private boolean active=true;
  private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
  private TextView label(String s,int size,int color,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
  private void insert(LinearLayout parent,View view){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(8);parent.addView(view,p);}
  private void link(String name,String description,String url){
    TextView card=label(name+"\n"+description,14,WHITE,false);card.setPadding(dp(16),dp(13),dp(16),dp(13));
    GradientDrawable d=new GradientDrawable();d.setColor(PANEL);d.setCornerRadius(dp(10));d.setStroke(dp(1),Color.rgb(34,81,100));card.setBackground(d);
    if(url!=null&&url.startsWith("https://")) {card.setContentDescription("Open verified source: "+name);card.setOnClickListener(v->open(url));}
    insert(results,card);
  }
  private void open(String url){try{if(!url.startsWith("https://"))return;startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){status.setText("Could not open source: "+e.getClass().getSimpleName());}}
  @Override public void onCreate(Bundle b){super.onCreate(b);setTheme(android.R.style.Theme_Material_NoActionBar);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    String requested=getIntent().getStringExtra("mode");if(requested!=null)for(String m:MODES)if(m.equals(requested))mode=m;
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(12),dp(14),dp(12),dp(8));root.setBackgroundColor(BG);setContentView(root);
    TextView header=label("DEVELOP.UGANDA  /  WORLD SITUATION ROOM",12,CYAN,true);insert(root,header);
    title=label(mode,25,WHITE,true);insert(root,title);
    status=label("Source connection not checked",12,DIM,false);insert(root,status);
    ScrollView modeScroll=new ScrollView(this);modeScroll.setFillViewport(false);root.addView(modeScroll,new LinearLayout.LayoutParams(-1,dp(91)));
    LinearLayout modes=new LinearLayout(this);modes.setOrientation(LinearLayout.VERTICAL);modeScroll.addView(modes);
    LinearLayout top=new LinearLayout(this);modes.addView(top);LinearLayout lower=new LinearLayout(this);modes.addView(lower);
    for(int i=0;i<MODES.length;i++){final String m=MODES[i];TextView button=label(m,10,m.equals(mode)?ORANGE:CYAN,true);button.setGravity(Gravity.CENTER);button.setPadding(dp(5),dp(13),dp(5),dp(13));
      LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(44),1);(i<4?top:lower).addView(button,p);button.setOnClickListener(v->{if(!mode.equals(m)){mode=m;title.setText(mode);fetch();}});}
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    results=new LinearLayout(this);results.setPadding(0,dp(12),0,dp(4));results.setOrientation(LinearLayout.VERTICAL);scroll.addView(results);
    LinearLayout buttons=new LinearLayout(this);insert(root,buttons);
    Button refresh=new Button(this);refresh.setText("REFRESH SOURCE");refresh.setTextSize(12);buttons.addView(refresh,new LinearLayout.LayoutParams(0,dp(53),1));refresh.setOnClickListener(v->fetch());
    Button back=new Button(this);back.setText("MAIN GLOBE");back.setTextSize(12);buttons.addView(back,new LinearLayout.LayoutParams(0,dp(53),1));back.setOnClickListener(v->finish());
    fetch();
  }
  @Override public void onDestroy(){active=false;executor.shutdownNow();super.onDestroy();}
  private static class Row {String name,desc,url;Row(String n,String d,String u){name=n;desc=d;url=u;}}
  private static class Load {String status;final List<Row> rows=new ArrayList<>();void add(String a,String b,String u){rows.add(new Row(a,b,u));}}
  private static String utc(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm 'UTC'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date());}
  private static String safe(String s){if(s==null)return "Not supplied";return s.length()>210?s.substring(0,210):s;}
  private String read(String path,int limit) throws Exception {
    if(!path.startsWith("https://"))throw new java.io.IOException("HTTPS required");
    HttpURLConnection c=(HttpURLConnection)new URL(path).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(9000);c.setInstanceFollowRedirects(true);
    c.setRequestProperty("User-Agent","DevelopUgandaWorldSituationRoom/1154 (public-sources)");
    try{int status=c.getResponseCode();if(status!=200)throw new java.io.IOException("HTTP "+status);StringBuilder s=new StringBuilder();
      try(InputStream in=c.getInputStream();BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"))){char[] buf=new char[4096];int n;while((n=r.read(buf))!=-1){s.append(buf,0,n);if(s.length()>limit)throw new java.io.IOException("Response exceeds safe bound");}}
      return s.toString();
    }finally{c.disconnect();}
  }
  private void fetch(){if(!fetching.compareAndSet(false,true))return;final String selection=mode;status.setText("Connecting / "+utc());results.removeAllViews();
    link("SOURCE STATUS","Waiting for genuine provider data…",null);
    executor.execute(()->{Load data=new Load();try{load(selection,data);}catch(Exception ex){data.status="UNAVAILABLE: "+safe(ex.getMessage());
      data.add("No verified response","The provider did not supply usable records. This is not proof that activity stopped.",null);}
      final Load ready=data;main.post(()->{fetching.set(false);if(!active||isFinishing())return;if(!selection.equals(mode)){fetch();return;}
        status.setText(safe(ready.status)+"  •  "+utc());results.removeAllViews();for(Row row:ready.rows)link(row.name,row.desc,row.url);
        if(ready.rows.isEmpty())link("NO OBSERVATIONS","No real records returned. No dummy records were created.",null);
      });
    });
  }
  private void load(String m,Load out) throws Exception{
    if(m.equals("VESSELS")){
      out.status="AIS LIVE FEED NOT CONFIGURED";
      out.add("MARITIME AIS • Connection required","Real vessel positions require a permitted AIS provider subscription and a secure backend. No mock ships are drawn.","https://www.aisstream.io/documentation");
      out.add("OPEN PUBLIC VESSEL MAP","Use a publicly accessible vessel website while integration is configured. Coverage varies by receiver.","https://www.vesselfinder.com/");
    }else if(m.equals("AIRCRAFT")){
      JSONObject data=new JSONObject(read("https://opensky-network.org/api/states/all",5500000));JSONArray a=data.optJSONArray("states");if(a==null)throw new java.io.IOException("OpenSky states missing");
      int found=0;for(int i=0;i<a.length()&&found<35;i++){JSONArray x=a.optJSONArray(i);if(x==null||x.isNull(5)||x.isNull(6))continue;double lat=x.optDouble(6,Double.NaN),lon=x.optDouble(5,Double.NaN);
        if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)continue;
        String callsign=x.optString(1,"UNIDENTIFIED").trim();String hex=x.optString(0,"");
        out.add(callsign.length()>0?callsign:hex,String.format(Locale.US,"Observed %.3f°, %.3f° • ICAO %s • OpenSky receiver coverage",lat,lon,hex),null);found++;}
      out.status=a.length()+" reported state vectors, "+found+" displayed • provider UTC epoch "+data.optLong("time",0);
      out.add("OPEN ORIGINAL FLIGHT DATA","OpenSky source and coverage information", "https://opensky-network.org/");
    }else if(m.equals("SATELLITES")){
      JSONObject iss=new JSONObject(read("https://api.wheretheiss.at/v1/satellites/25544",80000));
      if(iss.has("latitude")&&iss.has("longitude"))out.add("ISS • CURRENT REPORTED POSITION",String.format(Locale.US,"Lat %.3f  Lon %.3f • altitude %.1f km • timestamp %d",iss.optDouble("latitude"),iss.optDouble("longitude"),iss.optDouble("altitude"),iss.optLong("timestamp")),"https://www.wheretheiss.at/");
      JSONArray data=new JSONArray(read("https://celestrak.org/NORAD/elements/gp.php?GROUP=STATIONS&FORMAT=JSON",1100000));
      for(int i=0;i<Math.min(data.length(),20);i++){JSONObject x=data.optJSONObject(i);if(x==null)continue;out.add(x.optString("OBJECT_NAME","SATELLITE"),"NORAD "+x.optString("NORAD_CAT_ID","")+" • orbital epoch "+x.optString("EPOCH","unknown")+" • this record is NOT a current ground position",null);}
      out.add("VIEW CURRENT ORBITAL CATALOGUE","CelesTrak orbital elements; propagation is required before plotting positions.","https://celestrak.org/NORAD/elements/");
      out.status="ISS observed position + "+data.length()+" orbital records; catalog entries are not positions";
    }else if(m.equals("CITY CAMERAS")){
      out.status="PUBLIC CAMERA DIRECTORY • NO UNAUTHORISED CAMERA ACCESS";
      out.add("WINDY • WORLDWIDE WEBCAMS","Browse published public webcams and timelapses. Automated image embedding requires Windy API credentials.","https://www.windy.com/webcams");
      out.add("EARTHCAM • PUBLIC LIVE CAMERAS","Browse publicly published EarthCam streams in an external browser. Availability varies.","https://www.earthcam.com/");
      out.add("CAMERA SAFETY","Only cameras deliberately published for public access are supported. The app does not scan or connect to private devices.",null);
    }else if(m.equals("WORLD NEWS")){
      String[][] feeds={
        {"BBC WORLD","https://feeds.bbci.co.uk/news/world/rss.xml"},
        {"AL JAZEERA WORLD","https://www.aljazeera.com/xml/rss/all.xml"},
        {"FRANCE 24","https://www.france24.com/en/rss"},
        {"DEUTSCHE WELLE WORLD","https://rss.dw.com/xml/rss-en-world"},
        {"THE INDEPENDENT UGANDA","https://www.independent.co.ug/feed/"}
      };
      int available=0;
      for(String[] feed:feeds){try{newsFeed(out,feed[0],feed[1],8);available++;}
        catch(Exception e){out.add(feed[0]+" UNAVAILABLE",safe(e.getMessage())+" • no invented headlines",null);}}
      out.status=available+" of "+feeds.length+" independent publishers returned genuine RSS; not every outlet worldwide";
    }else if(m.equals("RADIO")){
      JSONArray data=new JSONArray(read("https://de1.api.radio-browser.info/json/stations/search?limit=60&hidebroken=true&order=clickcount&reverse=true",1100000));
      int count=0;for(int i=0;i<data.length()&&count<45;i++){JSONObject x=data.optJSONObject(i);if(x==null)continue;String url=x.optString("url_resolved","");
        if(!url.startsWith("https://"))continue;out.add(x.optString("name","RADIO"),x.optString("countrycode","--")+" • "+x.optString("codec","unknown")+" • user-reported stream, playback not guaranteed",url);count++;}
      out.add("RADIO DIRECTORY","Browse additional licensed or publicly offered stations, worldwide.","https://www.radio-browser.info/");
      out.status=count+" publicly listed HTTPS radio station streams; playback not verified";
    }else if(m.equals("TV STATIONS")){
      JSONArray data=new JSONArray(read("https://iptv-org.github.io/api/streams.json",11000000));int count=0;
      for(int i=0;i<data.length()&&count<45;i++){JSONObject x=data.optJSONObject(i);if(x==null)continue;String url=x.optString("url","");if(!url.startsWith("https://"))continue;
        String name=x.optString("title",x.optString("channel","TV"));if(name.toLowerCase(Locale.ROOT).contains("adult"))continue;
        out.add(name,"IPTV directory listing • "+x.optString("quality","quality not stated")+" • stream availability/rights vary",url);count++;}
      out.add("OPEN CHANNEL DIRECTORY","IPTV-org worldwide public channel catalog; streams may be geoblocked or unavailable.","https://github.com/iptv-org/iptv");
      out.status=data.length()+" directory stream records; "+count+" HTTPS entries listed; not individually tested";
    }else if(m.equals("INTERNET")){
      String[] codes={"UG","ZA","KE","US","GB","BR","IN","JP"};int observed=0;
      for(String code:codes){try{JSONObject payload=new JSONObject(read("https://stat.ripe.net/data/country-resource-list/data.json?resource="+code,1900000));JSONObject res=payload.getJSONObject("data").getJSONObject("resources");
        int asn=res.optJSONArray("asn")==null?0:res.getJSONArray("asn").length();int v4=res.optJSONArray("ipv4")==null?0:res.getJSONArray("ipv4").length();
        out.add("INTERNET ROUTING RESOURCES • "+code,asn+" registered ASNs • "+v4+" IPv4 allocations • RIPE RIR statistics (not traffic volume)",null);observed++;}
        catch(Exception e){out.add("NETWORK SOURCE UNAVAILABLE • "+code,safe(e.getMessage()),null);}}
      out.add("RIPEstat PUBLIC DATA","Real routing and network statistics, not individual-user tracking.","https://stat.ripe.net/");
      out.add("RIPE RIS LIVE ROUTE CHANGES","Public live BGP network announcements. This does not track private user activity.","https://ris-live.ripe.net/");
      out.add("CLOUDFLARE RADAR","Worldwide aggregate Internet traffic, outages and attack trends. API authentication required.","https://radar.cloudflare.com/");
      out.status=observed+" countries returned actual Internet resource statistics; live packets not inferred";
    }else{out.status="Unknown source category";}
  }
  private void newsFeed(Load out,String name,String path,int max) throws Exception{
    String xml=read(path,1100000);XmlPullParser p=XmlPullParserFactory.newInstance().newPullParser();p.setInput(new StringReader(xml));
    boolean in=false;String tag="",title="",link="",pub="";int count=0;
    for(int ev=p.getEventType();ev!=XmlPullParser.END_DOCUMENT&&count<max;ev=p.next()){
      if(ev==XmlPullParser.START_TAG){tag=p.getName();if("item".equalsIgnoreCase(tag)){in=true;title="";link="";pub="";}}
      else if(ev==XmlPullParser.TEXT&&in){String t=p.getText();if("title".equalsIgnoreCase(tag))title+=t;else if("link".equalsIgnoreCase(tag))link+=t;else if("pubDate".equalsIgnoreCase(tag))pub+=t;}
      else if(ev==XmlPullParser.END_TAG){if("item".equalsIgnoreCase(p.getName())&&in){if(title.length()>0){out.add(safe(title),name+" • "+safe(pub),link.startsWith("https://")?link:null);count++;}in=false;}tag="";}
    }
    if(count==0)throw new java.io.IOException(name+" returned no RSS items");
  }
}
