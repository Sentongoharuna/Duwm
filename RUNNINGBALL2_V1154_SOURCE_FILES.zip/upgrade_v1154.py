#!/usr/bin/env python3
"""Add native eight-sector source explorer and observed ISS overlay to V1153.
Existing original RUNNINGBALL2 engines are not modified.
"""
from pathlib import Path
from xml.etree import ElementTree as ET
import hashlib,sys
root=Path(sys.argv[1]).resolve();assert root.is_dir()
java=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
a=java/'LiveCommandActivity.java';g=java/'LiveEarthGlobeView.java';h=java/'WorldSourceHubActivity.java'
assert a.exists() and g.exists() and (java/'MainActivity.java').exists()
assert (java/'SatelliteMapView.java').exists() and (java/'DuwmLiveWallpaperService.java').exists()
assert not h.exists(),'Refuse to overwrite WorldSourceHubActivity'
new=Path(__file__).parent/'WorldSourceHubActivity.java'
assert new.is_file() and new.stat().st_size>12000
h.write_bytes(new.read_bytes())
coast_src=Path(__file__).parent/'naturalearth_coasts.txt'
assert coast_src.is_file() and coast_src.stat().st_size>8000
asset=root/'app/src/main/assets/naturalearth_coasts.txt'
asset.parent.mkdir(parents=True,exist_ok=True)
asset.write_bytes(coast_src.read_bytes())

def replace(s,old,repl,who):
    assert s.count(old)==1,f'V1154 {who} anchor must occur exactly once; actual {s.count(old)}'
    return s.replace(old,repl,1)

s=a.read_text()
s=replace(s,'import android.widget.ScrollView;','import android.widget.ScrollView;\nimport android.widget.HorizontalScrollView;','horizontal navigation import')
s=replace(s,'private TextView clock, summary, airValue, airStatus, quakeValue, quakeStatus, nasaValue, nasaStatus;',
'''private TextView clock, summary, airValue, airStatus, quakeValue, quakeStatus, nasaValue, nasaStatus, issValue, issStatus;''','ISS view fields')
s=replace(s,'"DEVELOP.UGANDA  •  V1153 LIVE ENGINE"','"DEVELOP.UGANDA  •  V1154 WORLD COMMAND"','live version label')
s=replace(s,'ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));',
'''// V1154 category rail: the rotating globe remains the first and main page.
        HorizontalScrollView ribbon=new HorizontalScrollView(this);ribbon.setHorizontalScrollBarEnabled(false);
        root.addView(ribbon,new LinearLayout.LayoutParams(-1,dp(64)));
        LinearLayout sectors=new LinearLayout(this);sectors.setGravity(Gravity.CENTER_VERTICAL);
        sectors.setPadding(dp(7),dp(5),dp(7),dp(5));ribbon.addView(sectors);
        for(String sector:WorldSourceHubActivity.MODES){
            TextView tab=text(sector,12,BLUE,true);tab.setGravity(Gravity.CENTER);
            tab.setBackground(panel(Color.rgb(29,79,100)));tab.setPadding(dp(13),dp(10),dp(13),dp(10));
            tab.setContentDescription("Open live source " + sector);
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-2,dp(48));tp.rightMargin=dp(7);sectors.addView(tab,tp);
            tab.setOnClickListener(v->{Intent next=new Intent(this,WorldSourceHubActivity.class);next.putExtra("mode",sector);startActivity(next);});
        }
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));''','main source rail')
s=replace(s,'TextView note=text("Source readings are never simulated.',
'''TextView[] satViews=new TextView[2];makeCard(feed,"ISS • REPORTED LIVE SPACE STATION POSITION", "CONNECTING",satViews);issValue=satViews[0];issStatus=satViews[1];
        TextView note=text("Source readings are never simulated.''','ISS status card')
s=replace(s,'List<LiveEarthGlobeView.Position> newAir=new ArrayList<>(),newQuakes=new ArrayList<>();',
'''List<LiveEarthGlobeView.Position> newAir=new ArrayList<>(),newQuakes=new ArrayList<>(),newSat=new ArrayList<>();''','ISS pos list')
s=replace(s,'String av="UNAVAILABLE",qv="UNAVAILABLE",nv="UNAVAILABLE";',
'''String av="UNAVAILABLE",qv="UNAVAILABLE",nv="UNAVAILABLE",iv="UNAVAILABLE";''','ISS value')
s=replace(s,'String as="",qs="",ns="";int ok=0;',
'''String as="",qs="",ns="",is="";int ok=0;''','ISS detail')
s=replace(s,'final String rav=av,ras=as,rqv=qv,rqs=qs,rnv=nv,rns=ns;',
'''try{
                JSONObject pos=new JSONObject(readJson("https://api.wheretheiss.at/v1/satellites/25544"));
                double lat=pos.optDouble("latitude",Double.NaN),lon=pos.optDouble("longitude",Double.NaN);
                if(!valid(lat,lon))throw new java.io.IOException("ISS coordinates absent");
                long source=pos.optLong("timestamp",0);
                if(source<=0||Math.abs(System.currentTimeMillis()/1000L-source)>900L)throw new java.io.IOException("ISS position stale or undated");
                newSat.add(new LiveEarthGlobeView.Position(lat,lon));
                iv=String.format(Locale.US,"ISS %.2f° / %.2f°",lat,lon);
                is="Reported UTC "+timeUTC(source*1000L)+" • not a simulated orbit";ok++;
            }catch(Exception ex){is="ISS provider: "+safeError(ex);}
            final String rav=av,ras=as,rqv=qv,rqs=qs,rnv=nv,rns=ns,riv=iv,ris=is;''','ISS request')
s=replace(s,'nasaValue.setText(rnv);nasaStatus.setText(rns);',
'''nasaValue.setText(rnv);nasaStatus.setText(rns);issValue.setText(riv);issStatus.setText(ris);''','ISS display')
s=replace(s,'globe.setObservations(airPoints,quakePoints);',
'''globe.setObservations(airPoints,quakePoints);globe.setSatellites(newSat);''','ISS marker')
s=replace(s,'receivedSources+"/3 providers reached','receivedSources+"/4 providers reached','source count')
a.write_text(s)

s=g.read_text()
s=replace(s,'import android.view.View;',
'''import android.view.View;
import java.io.BufferedReader;
import java.io.InputStreamReader;''','coastline reader imports')
s=replace(s,'private final List<Position> quakes = new ArrayList<>();',
'''private final List<Position> quakes = new ArrayList<>();
    private final List<Position> satellites = new ArrayList<>();''','satellite points')
s=replace(s,'private boolean showAircraft = true;',
'''private final List<List<Position>> coastlines = new ArrayList<>();
    private boolean showAircraft = true;''','coastline geometry data')
s=replace(s,'public LiveEarthGlobeView(Context context) { super(context); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }',
'''public LiveEarthGlobeView(Context context) {
        super(context); setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        loadWorldCoasts();
    }
    private void loadWorldCoasts() {
        try (BufferedReader reader=new BufferedReader(new InputStreamReader(getContext().getAssets().open("naturalearth_coasts.txt"),"UTF-8"))) {
            String row;
            while((row=reader.readLine())!=null){
                List<Position> coast=new ArrayList<>();
                for(String point:row.split(" ")){
                    String[] xy=point.split(",");if(xy.length!=2)continue;
                    double lat=Double.parseDouble(xy[0]),lon=Double.parseDouble(xy[1]);
                    if(!Double.isNaN(lat)&&!Double.isNaN(lon))coast.add(new Position(lat,lon));
                }
                if(coast.size()>=3)coastlines.add(coast);
            }
        }catch(Exception ignored){ /* A missing asset never creates fake coastline. */ }
    }
    private void paintCoasts(Canvas canvas) {
        p.setStyle(Paint.Style.STROKE);p.setShader(null);p.setStrokeWidth(1.55f);
        p.setColor(Color.argb(225,102,219,192));
        for(List<Position> coast:coastlines){
            Path outline=new Path();boolean visible=false;
            for(Position point:coast){
                float[] spot=screen(point.lat,point.lon);
                if(spot==null){visible=false;continue;}
                if(!visible){outline.moveTo(spot[0],spot[1]);visible=true;}
                else outline.lineTo(spot[0],spot[1]);
            }
            canvas.drawPath(outline,p);
        }
    }''','coastline load and draw')
s=replace(s,'public void showAircraft(boolean show) {',
'''public void setSatellites(List<Position> received) { satellites.clear();satellites.addAll(received);invalidate(); }
    public void showAircraft(boolean show) {''','satellite setter')
s=replace(s,'p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3f);p.setColor(Color.rgb(67,214,222));',
'''paintCoasts(c);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3f);p.setColor(Color.rgb(67,214,222));''','geographical coastlines visible on sphere')
s=replace(s,'if(showQuakes)plot(c,quakes,Color.rgb(255,191,87),4.8f);',
'''if(showQuakes)plot(c,quakes,Color.rgb(255,191,87),4.8f);
        plot(c,satellites,Color.rgb(146,255,175),6.2f);''','visible ISS marker')
g.write_text(s)

manifest=root/'app/src/main/AndroidManifest.xml';src=manifest.read_text();ANDROID='http://schemas.android.com/apk/res/android'
ET.register_namespace('android',ANDROID);ET.register_namespace('tools','http://schemas.android.com/tools')
tree=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True));doc=ET.fromstring(src,parser=tree)
app=doc.find('application');assert app is not None
names=[x.get('{%s}name'%ANDROID) for x in app.findall('activity')]
assert 'com.sentongoharuna.worldsituationroom.LiveCommandActivity' in names
assert 'com.sentongoharuna.worldsituationroom.WorldSourceHubActivity' not in names
ET.SubElement(app,'activity',{'{%s}name'%ANDROID:'com.sentongoharuna.worldsituationroom.WorldSourceHubActivity','{%s}exported'%ANDROID:'false','{%s}label'%ANDROID:'World Sources'})
ET.ElementTree(doc).write(manifest,encoding='utf-8',xml_declaration=True)

b=root/'app/build.gradle.kts';content=b.read_text()
assert content.count('versionCode = 1153')==1
assert content.count('versionName = "RUNNINGBALL2-V1153-ACTIVE-WORLD"')==1
content=content.replace('versionCode = 1153','versionCode = 1154',1).replace('versionName = "RUNNINGBALL2-V1153-ACTIVE-WORLD"','versionName = "RUNNINGBALL2-V1154-WORLD-FEEDS"',1)
assert 'applicationId = "com.sentongoharuna.worldsituationroom.rb2live25"' in content
b.write_text(content)
strings=root/'app/src/main/res/values/strings.xml';cs=strings.read_text();assert cs.count('DEVELOP.UGANDA V1153')==1
strings.write_text(cs.replace('DEVELOP.UGANDA V1153','DEVELOP.UGANDA V1154',1))
for p in [a,g,h]:print('INSTALLED NEW SOURCE',p.name,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
assert len(list(app.findall('activity'))) == len(names)+1
assert 'WorldSourceHubActivity' in manifest.read_text()
assert asset.is_file() and asset.stat().st_size>8000
assert 'paintCoasts(c)' in g.read_text()
print('PASS V1154: original app and wallpaper preserved; true Natural Earth coastlines, ISS marker and eight source tabs installed')
