#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
! grep -F 'DuMonitorPlayer.open' "$M"
grep -F 'openLocalMonitors(m.id)' "$M" >/dev/null
grep -F 'CrashLedger.record(this,"F17_SAVE",e,false)' "$M" >/dev/null
grep -F 'CrashLedger.record(this,"F17_RESTORE",e,false)' "$M" >/dev/null
"$P/scripts/verify-1-2-20-1-live-object-refresh.sh" "$P"
echo "1.2/20/1 FIX1 EXACT COMPILER REPAIR PASS"
