package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class NewsSourceCatalog {
 public static final NewsSource[] ALL = new NewsSource[]{
  new NewsSource("watchdog","Watchdog Uganda","https://watchdoguganda.com","",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("monitor","Daily Monitor","https://www.monitor.co.ug","",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("newvision","New Vision","https://www.newvision.co.ug","",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("nilepost","Nile Post","https://nilepost.co.ug","",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("chimpreports","ChimpReports","https://chimpreports.com","",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("independentug","The Independent (Uganda)","https://www.independent.co.ug","",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("observer","The Observer","https://observer.ug","",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("kampalapost","Kampala Post","https://kampalapost.com","",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("pmldaily","PML Daily","https://www.pmldaily.com","",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("softpower","SoftPower News","https://softpower.ug","",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("redpepper","Red Pepper","https://redpepper.co.ug","",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("dailyexpress","Daily Express","https://dailyexpress.co.ug","",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("eagle","Eagle Online","https://eagle.co.ug","",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("dispatch","The Kampala Dispatch","https://dispatch.ug","",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("towerpost","The Tower Post","https://thetowerpost.com","",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("urn","Uganda Radio Network","https://ugandaradionetwork.net","",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("haruna","Haruna Enterprises","https://harunaenterprisesltd.com","",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("ntv","NTV Uganda","https://www.ntv.co.ug","",NewsSource.Region.UGANDA,NewsSource.Category.BROADCAST,NewsSource.Language.EN,true),
  new NewsSource("nbs","NBS TV","https://nbs.ug","",NewsSource.Region.UGANDA,NewsSource.Category.BROADCAST,NewsSource.Language.EN,true),
  new NewsSource("ubc","UBC","https://ubc.go.ug","",NewsSource.Region.UGANDA,NewsSource.Category.BROADCAST,NewsSource.Language.EN,true),
  new NewsSource("capitalfm","Capital FM Uganda","https://capitalfm.co.ug","",NewsSource.Region.UGANDA,NewsSource.Category.BROADCAST,NewsSource.Language.EN,true),
  new NewsSource("bukedde","Bukedde","https://www.bukedde.co.ug","",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.LG,true),
  new NewsSource("businessfocus","Business Focus","https://businessfocus.co.ug","",NewsSource.Region.UGANDA,NewsSource.Category.BUSINESS,NewsSource.Language.EN,true),
  new NewsSource("ceoea","CEO East Africa","https://www.ceo.co.ug","",NewsSource.Region.UGANDA,NewsSource.Category.BUSINESS,NewsSource.Language.EN,true),
  new NewsSource("ugbusiness","UG Business","https://ugbusiness.com","",NewsSource.Region.UGANDA,NewsSource.Category.BUSINESS,NewsSource.Language.EN,true),
  new NewsSource("kawowo","Kawowo Sports","https://kawowo.com","",NewsSource.Region.UGANDA,NewsSource.Category.SPORTS,NewsSource.Language.EN,true),
  new NewsSource("bigeye","Big Eye","https://bigeye.ug","",NewsSource.Region.UGANDA,NewsSource.Category.ENTERTAINMENT,NewsSource.Language.EN,true),
  new NewsSource("mbu","MBU","https://mbu.ug","",NewsSource.Region.UGANDA,NewsSource.Category.ENTERTAINMENT,NewsSource.Language.EN,true),
  new NewsSource("howwe","Howwe","https://howwe.ug","",NewsSource.Region.UGANDA,NewsSource.Category.ENTERTAINMENT,NewsSource.Language.EN,true),
  new NewsSource("pulseug","Pulse Uganda","https://www.pulse.ug","",NewsSource.Region.UGANDA,NewsSource.Category.ENTERTAINMENT,NewsSource.Language.EN,true),
  new NewsSource("techjaja","Techjaja","https://techjaja.com","",NewsSource.Region.UGANDA,NewsSource.Category.TECH,NewsSource.Language.EN,true),
  new NewsSource("pctech","PC Tech Magazine","https://pctechmag.com","",NewsSource.Region.UGANDA,NewsSource.Category.TECH,NewsSource.Language.EN,true),
  new NewsSource("dignited","Dignited","https://www.dignited.com","",NewsSource.Region.UGANDA,NewsSource.Category.TECH,NewsSource.Language.EN,true),
  new NewsSource("mediacentre","Uganda Media Centre","https://mediacentre.go.ug","",NewsSource.Region.UGANDA,NewsSource.Category.GOVERNMENT,NewsSource.Language.EN,true),
  new NewsSource("googlenewsug","Google News Uganda","https://news.google.com","https://news.google.com/rss?hl=en-UG&gl=UG&ceid=UG:en",NewsSource.Region.UGANDA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("eastafrican","The EastAfrican","https://www.theeastafrican.co.ke","",NewsSource.Region.EAST_AFRICA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("nationke","Nation (Kenya)","https://nation.africa","",NewsSource.Region.EAST_AFRICA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("starke","The Star (Kenya)","https://www.the-star.co.ke","",NewsSource.Region.EAST_AFRICA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("citizentz","The Citizen (Tanzania)","https://www.thecitizen.co.tz","",NewsSource.Region.EAST_AFRICA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("newtimesrw","The New Times (Rwanda)","https://www.newtimes.co.rw","",NewsSource.Region.EAST_AFRICA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("googlenewske","Google News Kenya","https://news.google.com","https://news.google.com/rss?hl=en-KE&gl=KE&ceid=KE:en",NewsSource.Region.EAST_AFRICA,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("bbc","BBC World","https://www.bbc.com/news/world","https://feeds.bbci.co.uk/news/world/rss.xml",NewsSource.Region.WORLD,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
  new NewsSource("aljazeera","Al Jazeera","https://www.aljazeera.com","https://www.aljazeera.com/xml/rss/all.xml",NewsSource.Region.WORLD,NewsSource.Category.GENERAL,NewsSource.Language.EN,true),
 };
 private NewsSourceCatalog(){}
 public static String[] legacyDefaultRss(){return new String[]{"https://feeds.bbci.co.uk/news/world/rss.xml","https://www.aljazeera.com/xml/rss/all.xml"};}
 public static NewsSource byId(String id){for(NewsSource s:ALL)if(s.id.equals(id))return s;return null;}
 public static NewsSource byName(String name){if(name==null)return null; for(NewsSource s:ALL)if(s.name.equalsIgnoreCase(name.trim()))return s;return null;}
}
