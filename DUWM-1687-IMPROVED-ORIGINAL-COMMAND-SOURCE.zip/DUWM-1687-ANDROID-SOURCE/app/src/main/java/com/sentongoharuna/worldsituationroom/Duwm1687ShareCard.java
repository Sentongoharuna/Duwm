package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.View;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Locale;

/** R1687 distinctly redesigned, professional 1080x1920 share image.
 * Never creates a synthetic track, news photo or live stream thumbnail.
 * Actual receipt facts are read on-device; sector visual is explicitly a schematic. */
public final class Duwm1687ShareCard {
    private static final int W=1080,H=1920;
    private static final int BG=0xFF071721,PANEL=0xFF0D2B39,DEEP=0xFF05121D,WHITE=0xFFF0FAFC;
    private static final int ACCENT=0xFF76ECF0,MUTED=0xFFA9C8D1,GRID=0xFF2F5E6C;
    private static final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private Duwm1687ShareCard(){}
    private static void panel(Canvas c,float l,float t,float r,float b,int fill){
        p.setColor(fill);p.setStyle(Paint.Style.FILL);c.drawRoundRect(new RectF(l,t,r,b),23,23,p);
        p.setColor(GRID);p.setStrokeWidth(2);p.setStyle(Paint.Style.STROKE);c.drawRoundRect(new RectF(l,t,r,b),23,23,p);
        p.setStyle(Paint.Style.FILL);
    }
    private static void text(Canvas c,String t,float x,float y,int sz,int color,boolean strong){
        p.setColor(color);p.setTypeface(Typeface.create(strong?"sans-serif-medium":"sans-serif",0));p.setTextSize(sz);
        c.drawText(t==null?"":t,x,y,p);
    }
    private static int paragraph(Canvas c,String value,int x,int baseline,int width,int sz,int color,int cap){
        String v=value==null||value.trim().isEmpty()?"NOT REPORTED":value.trim().replace('\n',' ');
        p.setTypeface(Typeface.create("sans-serif",0));p.setTextSize(sz);
        ArrayList<String> lines=new ArrayList<>();StringBuilder current=new StringBuilder();
        for(String word:v.split("\\s+")){
            if(word.length()==0)continue;
            while(p.measureText(word)>width&&word.length()>2){
                int split=Math.max(1,word.length()/2);lines.add(word.substring(0,split));word=word.substring(split);
            }
            String trial=current.length()==0?word:current+" "+word;
            if(p.measureText(trial)>width&&current.length()>0){lines.add(current.toString());current=new StringBuilder(word);}
            else current=new StringBuilder(trial);
        }
        if(current.length()>0)lines.add(current.toString());
        int len=Math.min(cap,lines.size());
        for(int i=0;i<len;i++){String t=lines.get(i);
            if(i==len-1&&lines.size()>len)t=t.length()>1?t.substring(0,t.length()-1)+"…":"…";
            text(c,t,x,baseline+i*(sz+15),sz,color,false);
        }
        return baseline+len*(sz+15);
    }
    private static void labelValue(Canvas c,String title,String value,int x,int y,int max,int maxLines){
        text(c,title,x,y,22,ACCENT,true);paragraph(c,value,x,y+40,max,29,WHITE,maxLines);
    }
    public static void share(Activity a,Duwm1683DeskCatalog.Desk d){
        Bitmap img=null;
        try{
            Duwm1685ReceiptHistory.capture(a,d);
            Duwm1684DeskDiagnostics.Snapshot s=Duwm1684DeskDiagnostics.read(a,d);
            img=Bitmap.createBitmap(W,H,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(img);canvas.drawColor(BG);
            // Consistent single cyan theme, full-bleed portrait visual language.
            p.setColor(ACCENT);canvas.drawRect(0,0,W,17,p);
            p.setColor(GRID);for(int x=0;x<=W;x+=54)canvas.drawRect(x,0,x+1,H,p);
            panel(canvas,42,43,1038,225,PANEL);
            try{Drawable logo=a.getDrawable(R.drawable.develop_uganda_logo);
                if(logo!=null){logo.setBounds(64,64,195,195);logo.draw(canvas);}}
            catch(Exception ignored){}
            text(canvas,"DEVELOP.UGANDA",225,105,36,ACCENT,true);
            text(canvas,"WORLD SITUATION ROOM",225,156,29,WHITE,true);
            text(canvas,"BUILD 1687  /  SOURCE-BACKED IMAGE",225,194,20,MUTED,true);
            text(canvas,Duwm1684SectorVisual.mode(d.title).toUpperCase(Locale.US)+" / INTELLIGENCE REPORT",57,288,24,ACCENT,true);
            paragraph(canvas,d.title.toUpperCase(Locale.US),57,355,961,56,WHITE,2);
            panel(canvas,42,410,1038,952,PANEL);
            Duwm1684SectorVisual drawing=new Duwm1684SectorVisual(a,d.title,true);
            drawing.measure(View.MeasureSpec.makeMeasureSpec(950,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(344,View.MeasureSpec.EXACTLY));
            drawing.layout(0,0,950,344);canvas.save();canvas.translate(65,434);drawing.draw(canvas);canvas.restore();
            panel(canvas,63,795,1016,938,DEEP);
            text(canvas,"PROVIDER STATE",88,839,22,ACCENT,true);
            paragraph(canvas,s.state,88,899,360,35,WHITE,1);
            text(canvas,"RECEIVED VALUE",540,839,22,ACCENT,true);
            paragraph(canvas,s.count,540,899,437,36,WHITE,1);
            text(canvas,"ILLUSTRATION / NOT A MAP FIX OR SOURCE PHOTO",72,774,19,MUTED,true);
            panel(canvas,42,972,1038,1425,PANEL);
            labelValue(canvas,"01  ORIGINAL PROVIDER",s.provider,78,1026,905,2);
            labelValue(canvas,"02  LAST LOCAL RECEIPT / UTC",s.received,78,1156,905,2);
            labelValue(canvas,"03  SOURCE SCOPE",s.coverage,78,1286,905,2);
            panel(canvas,42,1446,1038,1793,PANEL);
            text(canvas,"04  DEVICE RECEIPT HISTORY",73,1497,25,ACCENT,true);
            Duwm1685ReceiptChart chart=new Duwm1685ReceiptChart(a,d);
            chart.measure(View.MeasureSpec.makeMeasureSpec(933,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(234,View.MeasureSpec.EXACTLY));
            chart.layout(0,0,933,234);canvas.save();canvas.translate(69,1523);chart.draw(canvas);canvas.restore();
            text(canvas,"SAVED OBSERVATIONS  •  NO SIMULATED TIME SERIES",69,1825,20,MUTED,true);
            text(canvas,"DUWM 1687  /  "+d.category.toUpperCase(Locale.US),58,1878,21,ACCENT,true);
            text(canvas,"Inspect the provider record for observation and receipt times.",58,1905,18,MUTED,false);
            File directory=new File(a.getCacheDir(),"share-cards");
            if(!directory.isDirectory()&&!directory.mkdirs())throw new IllegalStateException("Cannot open share cache");
            String slug=d.title.toLowerCase(Locale.US).replaceAll("[^a-z0-9]+","-");
            File output=new File(directory,"duwm-1687-"+slug+"-"+System.currentTimeMillis()+".png");
            try(FileOutputStream out=new FileOutputStream(output)){
                if(!img.compress(Bitmap.CompressFormat.PNG,100,out))throw new IllegalStateException("PNG export failed");
            }
            Uri uri=Uri.parse("content://"+a.getPackageName()+".sharecards/"+output.getName());
            Intent send=new Intent(Intent.ACTION_SEND);send.setType("image/png");send.putExtra(Intent.EXTRA_STREAM,uri);
            send.putExtra(Intent.EXTRA_TEXT,"DUWM 1687 / "+d.title+"\n"+s.report());
            send.setClipData(ClipData.newUri(a.getContentResolver(),"DUWM 1687 image",uri));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            a.startActivity(Intent.createChooser(send,"Share DUWM 1687 source image"));
        }catch(Exception e){android.widget.Toast.makeText(a,"Share card unavailable: "+e.getClass().getSimpleName(),android.widget.Toast.LENGTH_LONG).show();}
        finally{if(img!=null&&!img.isRecycled())img.recycle();}
    }
}
