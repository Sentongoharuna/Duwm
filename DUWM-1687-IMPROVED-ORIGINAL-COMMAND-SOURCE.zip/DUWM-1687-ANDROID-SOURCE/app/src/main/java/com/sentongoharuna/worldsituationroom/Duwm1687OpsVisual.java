package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.View;
import java.util.Locale;

/** A visually alive 1687 instrument, NOT a map, simulated event or new tracking feed.
 * The only numeric report is the original provider's on-device receipt. Rings and sweep
 * are clearly labelled interface geometry, never represented as aircraft or ship fixes. */
public final class Duwm1687OpsVisual extends View {
    private static final int BG=0xFF071924, CYAN=0xFF68E4E6, WHITE=0xFFECFAFB,
            MUTED=0xFFA2C5D0, GRID=0xFF235161;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Duwm1683DeskCatalog.Desk desk;
    private Duwm1684DeskDiagnostics.Snapshot snapshot;
    private final float den;
    private boolean active;
    private long lastCheck;
    public Duwm1687OpsVisual(Context context,Duwm1683DeskCatalog.Desk d){
        super(context);desk=d;den=getResources().getDisplayMetrics().density;
        snapshot=Duwm1684DeskDiagnostics.read(context,d);
        String s=snapshot.state.toUpperCase(Locale.US);
        active=d.source>=0&&(s.contains("RECENT")||s.contains("CURRENT")||s.contains("LIVE")||s.equals("OK"));
        setContentDescription("Decorative 1687 instrument schematic. Source state "+snapshot.state+
                ". Real reported value "+snapshot.count+". No fictitious tracking dots.");
    }
    private void line(Canvas c,float x1,float y1,float x2,float y2,int color,float thickness){
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(thickness*den);paint.setColor(color);
        c.drawLine(x1,y1,x2,y2,paint);paint.setStyle(Paint.Style.FILL);
    }
    private void text(Canvas c,String t,float x,float y,float sp,int color,boolean bold){
        paint.setStyle(Paint.Style.FILL);paint.setColor(color);paint.setTypeface(android.graphics.Typeface.create(bold?"sans-serif-medium":"sans-serif",0));
        paint.setTextSize(sp*den);String value=t==null?"":t;
        float limit=Math.max(0,getWidth()-x-12*den);
        while(paint.measureText(value)>limit && value.length()>3)value=value.substring(0,value.length()-2)+"…";
        c.drawText(value,x,y,paint);
    }
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);float w=getWidth(),h=getHeight();if(w<50||h<50)return;
        paint.setStyle(Paint.Style.FILL);paint.setColor(BG);
        c.drawRoundRect(new RectF(0,0,w,h),18*den,18*den,paint);
        final long uptime=SystemClock.uptimeMillis();
        if(uptime-lastCheck>15000L){
            snapshot=Duwm1684DeskDiagnostics.read(getContext(),desk);lastCheck=uptime;
            String status=snapshot.state.toUpperCase(Locale.US);
            active=desk.source>=0&&(status.contains("RECENT")||status.contains("CURRENT")||status.contains("LIVE")||status.equals("OK"));
        }
        final float left=14*den, top=15*den, cy=h*.55f, cx=w*.28f;
        final float r=Math.min(h*.32f,w*.21f);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.1f*den);
        for(int i=1;i<=4;i++){
            paint.setColor(i==4?0xFF336A78:GRID);c.drawCircle(cx,cy,r*i/4,paint);
        }
        for(int i=0;i<8;i++){
            double angle=2*Math.PI*i/8;
            float x2=cx+(float)Math.cos(angle)*(r+7*den),y2=cy+(float)Math.sin(angle)*(r+7*den);
            line(c,cx-(float)Math.cos(angle)*(r+4*den),cy-(float)Math.sin(angle)*(r+4*den),x2,y2,GRID,.55f);
        }
        if(active){
            float a=(SystemClock.uptimeMillis()%8500L)*360f/8500f;
            paint.setColor(CYAN);paint.setAlpha(195);paint.setStrokeWidth(3.0f*den);
            c.drawArc(new RectF(cx-r,cy-r,cx+r,cy+r),a,38,false,paint);
            paint.setAlpha(255);
        }
        paint.setStyle(Paint.Style.FILL);paint.setColor(CYAN);c.drawCircle(cx,cy,3*den,paint);
        float x=Math.max(cx+r+16*den,w*.52f);
        text(c,"DUWM / 1687",x,top+13*den,11,CYAN,true);
        text(c,Duwm1684SectorVisual.mode(desk.title)+" DESK",x,top+35*den,12,WHITE,true);
        text(c,"SOURCE STATUS",x,top+58*den,10,MUTED,false);
        text(c,snapshot.state,x,top+78*den,15,CYAN,true);
        text(c,"RECEIVED VALUE",x,top+102*den,10,MUTED,false);
        text(c,snapshot.count,x,top+122*den,15,WHITE,true);
        line(c,left,h-30*den,w-left,h-30*den,GRID,1);
        text(c,"SCHEMATIC UI / NOT OBSERVED POSITIONS",left,h-11*den,9,MUTED,false);
        if(isAttachedToWindow()&&isShown())postInvalidateDelayed(active?145L:15000L);
    }
}
