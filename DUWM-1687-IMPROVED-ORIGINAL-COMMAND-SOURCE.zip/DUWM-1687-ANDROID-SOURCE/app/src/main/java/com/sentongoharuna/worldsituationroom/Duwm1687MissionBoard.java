package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.SharedPreferences;
import java.util.LinkedHashSet;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Locale;

/** True 1687 all-desk navigator, with functional text and sector filters.
 * Native maps and players remain the only sources of geographic positions and media. */
public final class Duwm1687MissionBoard {
    private Duwm1687MissionBoard(){}
    private static int dp(Activity a,float n){return Math.round(a.getResources().getDisplayMetrics().density*n);}
    private static GradientDrawable bg(Activity a,boolean selected){
        GradientDrawable g=new GradientDrawable();g.setColor(selected?DuwmUnifiedTheme.PANEL_SELECTED:DuwmUnifiedTheme.PANEL);
        g.setStroke(dp(a,1),selected?DuwmUnifiedTheme.ACCENT:DuwmUnifiedTheme.BORDER);g.setCornerRadius(dp(a,11));return g;
    }
    private static TextView label(Activity a,String s,int size,int color,boolean strong){
        TextView t=new TextView(a);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        if(strong)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));t.setGravity(Gravity.CENTER_VERTICAL);return t;
    }
    private static TextView button(Activity a,String s,Runnable r){
        TextView t=label(a,s,12,DuwmUnifiedTheme.ACCENT_BRIGHT,true);t.setGravity(Gravity.CENTER);
        t.setBackground(bg(a,true));t.setContentDescription(s);t.setOnClickListener(v->r.run());return t;
    }
    public static void refresh(Activity a,View board){
        if(a==null||board==null)return;
        for(int i=0;i<Duwm1683DeskCatalog.ALL.length;i++){
            View match=board.findViewWithTag("duwm-1687-board-"+i);
            if(match instanceof TextView){
                Duwm1683DeskCatalog.Desk d=Duwm1683DeskCatalog.ALL[i];
                Duwm1684DeskDiagnostics.Snapshot s=Duwm1684DeskDiagnostics.read(a,d);
                ((TextView)match).setText("SOURCE  "+s.state+"  •  "+s.count+"  •  "+s.provider);
            }
        }
    }
    public static View create(Activity a){
        SharedPreferences prefs=a.getSharedPreferences("duwm1684_desk_nav",android.content.Context.MODE_PRIVATE);
        LinkedHashSet<String> saved=new LinkedHashSet<>();
        String stored=prefs.getString("favorites","");
        if(!stored.isEmpty())for(String n:stored.split(String.valueOf((char)31)))if(!n.isEmpty())saved.add(n);
        LinearLayout root=new LinearLayout(a);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(a,10),dp(a,13),dp(a,10),dp(a,12));root.setBackground(bg(a,false));
        TextView hero=label(a,"1687  /  WORLD OPERATIONS NETWORK",20,DuwmUnifiedTheme.TEXT,true);root.addView(hero);
        TextView subtitle=label(a,"19 SOURCE-AWARE DESKS  /  REAL RECEIPT STATES  /  ORIGINAL SINGLE GLOBE",11,DuwmUnifiedTheme.ACCENT_BRIGHT,true);
        subtitle.setPadding(0,dp(a,4),0,dp(a,12));root.addView(subtitle);
        int reports=0,local=0;
        for(Duwm1683DeskCatalog.Desk d:Duwm1683DeskCatalog.ALL){
            if(d.source<0){local++;continue;}
            Duwm1684DeskDiagnostics.Snapshot snap=Duwm1684DeskDiagnostics.read(a,d);
            if(!snap.received.contains("NOT RECEIVED")&&!snap.state.equals("SOURCE READ FAILED"))reports++;
        }
        LinearLayout matrix=new LinearLayout(a);matrix.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(matrix,new LinearLayout.LayoutParams(-1,dp(a,76)));
        String[] values={"19",String.valueOf(reports),String.valueOf(local)};
        String[] names={"REGISTERED DESKS","RECEIPT CHECKS","LOCAL / DIRECTORY"};
        for(int i=0;i<3;i++){
            LinearLayout part=new LinearLayout(a);part.setOrientation(LinearLayout.VERTICAL);part.setGravity(Gravity.CENTER);
            part.setBackground(bg(a,true));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);p.rightMargin=dp(a,5);matrix.addView(part,p);
            TextView count=label(a,values[i],24,DuwmUnifiedTheme.TEXT,true);count.setGravity(Gravity.CENTER);part.addView(count);
            TextView caption=label(a,names[i],9,DuwmUnifiedTheme.ACCENT_BRIGHT,true);caption.setGravity(Gravity.CENTER);part.addView(caption);
        }
        TextView caution=label(a,"RECEIPT CHECKS ARE NOT A NUMBER OF LIVE TRACKS OR CURRENT STREAMS.",10,DuwmUnifiedTheme.MUTED,false);
        caution.setPadding(dp(a,3),dp(a,7),0,dp(a,10));root.addView(caution);
        EditText search=new EditText(a);search.setSingleLine(true);search.setTextSize(14);search.setHint("Search aircraft, sea, news, TV, radio, NASA, markets...");
        search.setHintTextColor(DuwmUnifiedTheme.MUTED);search.setTextColor(DuwmUnifiedTheme.TEXT);
        search.setBackground(bg(a,true));search.setPadding(dp(a,12),0,dp(a,8),0);root.addView(search,new LinearLayout.LayoutParams(-1,dp(a,51)));
        LinearLayout tabs=new LinearLayout(a);tabs.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams tablp=new LinearLayout.LayoutParams(-1,dp(a,49));tablp.topMargin=dp(a,8);root.addView(tabs,tablp);
        TextView matches=label(a,"ALL 19 / SELECT A DESK",11,DuwmUnifiedTheme.ACCENT_BRIGHT,true);matches.setPadding(dp(a,4),dp(a,10),0,dp(a,8));root.addView(matches);
        LinearLayout list=new LinearLayout(a);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);
        ArrayList<View> tiles=new ArrayList<>();
        final Runnable[] applyFilter=new Runnable[1];
        for(int i=0;i<Duwm1683DeskCatalog.ALL.length;i++){
            final Duwm1683DeskCatalog.Desk d=Duwm1683DeskCatalog.ALL[i];
            Duwm1684DeskDiagnostics.Snapshot s=Duwm1684DeskDiagnostics.read(a,d);
            LinearLayout card=new LinearLayout(a);card.setOrientation(LinearLayout.VERTICAL);
            card.setBackground(bg(a,false));card.setPadding(dp(a,11),dp(a,9),dp(a,11),dp(a,10));
            LinearLayout.LayoutParams cardLp=new LinearLayout.LayoutParams(-1,-2);cardLp.bottomMargin=dp(a,7);list.addView(card,cardLp);tiles.add(card);
            LinearLayout headerRow=new LinearLayout(a);headerRow.setGravity(Gravity.CENTER_VERTICAL);
            card.addView(headerRow,new LinearLayout.LayoutParams(-1,dp(a,43)));
            TextView title=label(a,String.format(Locale.US,"%02d  %s",i+1,d.title.toUpperCase(Locale.US)),15,DuwmUnifiedTheme.TEXT,true);
            headerRow.addView(title,new LinearLayout.LayoutParams(0,-1,1));
            TextView star=button(a,saved.contains(d.title)?"★":"☆",()->{});
            star.setContentDescription("Save or unsave "+d.title);
            headerRow.addView(star,new LinearLayout.LayoutParams(dp(a,46),dp(a,40)));
            star.setOnClickListener(v->{
                if(!saved.add(d.title))saved.remove(d.title);
                star.setText(saved.contains(d.title)?"★":"☆");
                prefs.edit().putString("favorites",String.join(String.valueOf((char)31),saved)).apply();
                if(applyFilter[0]!=null)applyFilter[0].run();
            });
            TextView details=label(a,d.subtitle,12,DuwmUnifiedTheme.MUTED,false);details.setPadding(0,dp(a,4),0,dp(a,4));card.addView(details);
            TextView receipt=label(a,"SOURCE  "+s.state+"  •  "+s.count+"  •  "+s.provider,11,DuwmUnifiedTheme.ACCENT_BRIGHT,true);
            receipt.setMaxLines(2);receipt.setTag("duwm-1687-board-"+i);card.addView(receipt);
            LinearLayout commands=new LinearLayout(a);LinearLayout.LayoutParams commandsLp=new LinearLayout.LayoutParams(-1,dp(a,43));commandsLp.topMargin=dp(a,7);
            card.addView(commands,commandsLp);
            TextView inspect=button(a,"FULL SCREEN ›",()->Duwm1687WorkspaceActivity.open(a,d));
            LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(0,-1,1);pp.rightMargin=dp(a,6);commands.addView(inspect,pp);
            TextView nativeButton=button(a,"ORIGINAL VIEW ↗",()->a.startActivity(Duwm1683DeskCatalog.intent(a,d)));
            commands.addView(nativeButton,new LinearLayout.LayoutParams(0,-1,1));
            card.setOnClickListener(v->Duwm1687WorkspaceActivity.open(a,d));
        }
        final String[] category={"ALL"};
        Runnable filter=()->{
            String q=search.getText().toString().trim().toLowerCase(Locale.US);int showing=0;
            for(int i=0;i<tiles.size();i++){
                Duwm1683DeskCatalog.Desk d=Duwm1683DeskCatalog.ALL[i];
                boolean group=category[0].equals("ALL")||
                        (category[0].equals("SAVED")?saved.contains(d.title):d.category.equals(category[0]));
                boolean match=q.isEmpty()||(d.title+" "+d.subtitle+" "+d.category+" "+d.description).toLowerCase(Locale.US).contains(q);
                boolean ok=group&&match;tiles.get(i).setVisibility(ok?View.VISIBLE:View.GONE);if(ok)showing++;
            }
            matches.setText("MATCHED "+showing+" / 19  •  TAP TO OPEN A FULL-SCREEN DESK");
        };
        applyFilter[0]=filter;
        String[] groups={"ALL","AIR, SEA & EARTH","NEWS & MEDIA","DATA, RECORDS & SOURCES","SAVED"};
        String[] labels={"ALL","AIR/SEA","MEDIA","DATA","SAVED"};
        for(int i=0;i<groups.length;i++){
            final String next=groups[i];TextView b=button(a,labels[i],()->{category[0]=next;filter.run();});
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);p.rightMargin=dp(a,4);tabs.addView(b,p);
        }
        search.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){filter.run();}
            @Override public void afterTextChanged(Editable s){}
        });
        filter.run();
        TextView bottom=label(a,"All real maps, feeds and in-app playback stay in their original modules. A directory or local tool is not a provider observation.",11,DuwmUnifiedTheme.MUTED,false);
        bottom.setPadding(dp(a,5),dp(a,9),dp(a,5),dp(a,5));root.addView(bottom);
        return root;
    }
}
