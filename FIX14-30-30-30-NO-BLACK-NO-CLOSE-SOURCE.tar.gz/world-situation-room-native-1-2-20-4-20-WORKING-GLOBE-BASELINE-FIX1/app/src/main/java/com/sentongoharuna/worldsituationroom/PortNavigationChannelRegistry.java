package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class PortNavigationChannelRegistry {
 public enum Decision { ADDED, UPDATED, DUPLICATE, REJECTED, CONFLICT }
 public static final class Result {public final Decision decision;public final String reason;Result(Decision d,String r){decision=d;reason=r;}}
 private final LinkedHashMap<String,PortNavigationChannelRecord> byId=new LinkedHashMap<>();private final LinkedHashMap<String,String> sourceBinding=new LinkedHashMap<>();
 public synchronized Result upsert(PortRecord port,PortNavigationChannelRecord c){
  if(port==null||c==null||!c.valid()||!port.portId.equals(c.portId))return new Result(Decision.REJECTED,"INVALID CHANNEL OR PARENT PORT");
  String sk=c.sourceId+"|"+c.sourceRecordId,prior=sourceBinding.get(sk);if(prior!=null&&!prior.equals(c.channelId))return new Result(Decision.CONFLICT,"SOURCE RECORD ALREADY BOUND TO "+prior);
  PortNavigationChannelRecord old=byId.get(c.channelId);if(old!=null&&!old.portId.equals(c.portId))return new Result(Decision.CONFLICT,"CHANNEL PARENT PORT CHANGED");
  if(old!=null&&same(old,c)){sourceBinding.put(sk,c.channelId);return new Result(Decision.DUPLICATE,"UNCHANGED");}
  byId.put(c.channelId,c);sourceBinding.put(sk,c.channelId);return new Result(old==null?Decision.ADDED:Decision.UPDATED,old==null?"ADDED":"UPDATED");
 }
 public synchronized PortNavigationChannelRecord get(String id){return byId.get(id==null?"":id.trim());}
 public synchronized List<PortNavigationChannelRecord> forPort(String p){ArrayList<PortNavigationChannelRecord>o=new ArrayList<>();for(PortNavigationChannelRecord c:byId.values())if(c.portId.equals(p))o.add(c);return Collections.unmodifiableList(o);}
 public synchronized List<PortNavigationChannelRecord> search(String q){String x=q==null?"":q.trim().toLowerCase(Locale.US);ArrayList<PortNavigationChannelRecord>o=new ArrayList<>();for(PortNavigationChannelRecord c:byId.values())if(x.isEmpty()||c.name.toLowerCase(Locale.US).contains(x)||c.channelId.toLowerCase(Locale.US).contains(x)||c.channelType.toLowerCase(Locale.US).contains(x))o.add(c);return Collections.unmodifiableList(o);}
 public synchronized int size(){return byId.size();}
 private static boolean same(PortNavigationChannelRecord a,PortNavigationChannelRecord b){if(!a.portId.equals(b.portId)||!a.name.equals(b.name)||!a.channelType.equals(b.channelType)||Double.compare(a.widthM,b.widthM)!=0||Double.compare(a.reportedDepthM,b.reportedDepthM)!=0||a.centerline.size()!=b.centerline.size()||a.observedAtMs!=b.observedAtMs)return false;for(int i=0;i<a.centerline.size();i++){HarbourBoundaryEvidence.Point x=a.centerline.get(i),y=b.centerline.get(i);if(Double.compare(x.latitude,y.latitude)!=0||Double.compare(x.longitude,y.longitude)!=0)return false;}return true;}
}
