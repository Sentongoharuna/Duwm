package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Per-provider failure isolation. A failing adapter cannot stop healthy providers. */
public final class AisProviderCircuitBreaker {
 public enum State { CLOSED, OPEN, HALF_OPEN }
 public static final class Status {
  public final String providerId;public final State state;public final int consecutiveFailures;public final long openedAtMs,retryAtMs;
  Status(String p,State s,int f,long o,long r){providerId=p;state=s;consecutiveFailures=f;openedAtMs=o;retryAtMs=r;}
  public String disclosure(){return "PROVIDER "+providerId+" • CIRCUIT "+state+" • FAILURES "+consecutiveFailures;}
 }
 private static final int FAILURE_LIMIT=3;private static final long COOLDOWN_MS=60000L;
 private static final class Mutable {State state=State.CLOSED;int failures;long opened,retry;}
 private final LinkedHashMap<String,Mutable> map=new LinkedHashMap<>();
 public synchronized boolean allow(String id,long now){
  Mutable m=map.computeIfAbsent(id,k->new Mutable());
  if(m.state==State.OPEN&&now>=m.retry){m.state=State.HALF_OPEN;return true;}
  return m.state!=State.OPEN;
 }
 public synchronized void success(String id){Mutable m=map.computeIfAbsent(id,k->new Mutable());m.state=State.CLOSED;m.failures=0;m.opened=0;m.retry=0;}
 public synchronized void failure(String id,long now){Mutable m=map.computeIfAbsent(id,k->new Mutable());m.failures++;
  if(m.state==State.HALF_OPEN||m.failures>=FAILURE_LIMIT){m.state=State.OPEN;m.opened=now;m.retry=now+COOLDOWN_MS;}}
 public synchronized Status status(String id){Mutable m=map.get(id);return m==null?new Status(id,State.CLOSED,0,0,0):new Status(id,m.state,m.failures,m.opened,m.retry);}
}
