package com.sentongoharuna.worldsituationroom;
public final class PortAnchoredVesselValidation{private PortAnchoredVesselValidation(){}
 public static PortAnchoredVesselState.State classify(boolean inside,double speedMps,double displacementM,boolean enough){
  if(!enough||Double.isNaN(speedMps)||Double.isNaN(displacementM))return PortAnchoredVesselState.State.INSUFFICIENT;
  boolean slow=speedMps<=0.5,stationary=displacementM<=150;
  if(inside&&slow&&stationary)return PortAnchoredVesselState.State.ANCHORED_EVIDENCE;
  if(inside)return PortAnchoredVesselState.State.INSIDE_ANCHORAGE_MOVING;
  if(slow)return PortAnchoredVesselState.State.SLOW_OUTSIDE_ANCHORAGE;
  return PortAnchoredVesselState.State.NOT_ANCHORED_EVIDENCE;
 }
}