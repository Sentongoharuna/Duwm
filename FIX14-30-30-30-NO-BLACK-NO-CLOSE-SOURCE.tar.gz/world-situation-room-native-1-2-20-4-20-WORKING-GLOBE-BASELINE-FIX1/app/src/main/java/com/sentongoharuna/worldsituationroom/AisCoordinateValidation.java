package com.sentongoharuna.worldsituationroom;
public final class AisCoordinateValidation {
 public enum State { VALID, MISSING, OUT_OF_RANGE, SENTINEL, IMPLAUSIBLE_JUMP }
 public static final class Result {
  public final State state; public final double latitude,longitude,impliedSpeedMps;
  Result(State s,double a,double o,double v){state=s;latitude=a;longitude=o;impliedSpeedMps=v;}
  public boolean accepted(){return state==State.VALID;}
 }
 private AisCoordinateValidation(){}
 public static Result validate(double lat,double lon){
  if(!finite(lat)||!finite(lon))return new Result(State.MISSING,Double.NaN,Double.NaN,Double.NaN);
  if(lat<-90d||lat>90d||lon<-180d||lon>180d)return new Result(State.OUT_OF_RANGE,lat,lon,Double.NaN);
  // Common AIS "not available" latitude/longitude sentinels.
  if(Math.abs(lat-91d)<0.000001d||Math.abs(lon-181d)<0.000001d)return new Result(State.SENTINEL,lat,lon,Double.NaN);
  return new Result(State.VALID,lat,lon,Double.NaN);
 }
 public static Result validateTransition(double oldLat,double oldLon,long oldMs,double lat,double lon,long newMs){
  Result basic=validate(lat,lon);if(!basic.accepted())return basic;
  if(!finite(oldLat)||!finite(oldLon)||oldMs<=0L||newMs<=oldMs)return basic;
  double seconds=(newMs-oldMs)/1000d,km=haversine(oldLat,oldLon,lat,lon),mps=km*1000d/seconds;
  // 45 m/s (~87 kt) is already above normal surface-vessel operation; quarantine larger jumps.
  if(mps>45d)return new Result(State.IMPLAUSIBLE_JUMP,lat,lon,mps);
  return new Result(State.VALID,lat,lon,mps);
 }
 private static double haversine(double a,double o,double b,double p){
  double r=6371.0088d,p1=Math.toRadians(a),p2=Math.toRadians(b),dp=Math.toRadians(b-a),dl=Math.toRadians(p-o);
  double x=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);
  return 2d*r*Math.atan2(Math.sqrt(x),Math.sqrt(Math.max(0d,1d-x)));
 }
 private static boolean finite(double v){return !Double.isNaN(v)&&!Double.isInfinite(v);}
}
