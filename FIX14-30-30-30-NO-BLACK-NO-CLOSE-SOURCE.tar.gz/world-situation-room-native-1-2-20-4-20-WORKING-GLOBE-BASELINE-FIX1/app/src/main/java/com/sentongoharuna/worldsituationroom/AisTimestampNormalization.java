package com.sentongoharuna.worldsituationroom;
import java.util.Locale;
/** Separates provider observation, receive and processing clocks. Never rewrites the provider observation time. */
public final class AisTimestampNormalization {
 public enum ClockState { NORMAL, PROVIDER_AHEAD, STALE, UNKNOWN }
 public final long providerTimeMs,receivedAtMs,processedAtMs,ageAtReceiveMs,processingDelayMs,providerLeadMs;
 public final ClockState state;
 private AisTimestampNormalization(long p,long r,long x,long age,long delay,long lead,ClockState s){
  providerTimeMs=p;receivedAtMs=r;processedAtMs=x;ageAtReceiveMs=age;processingDelayMs=delay;providerLeadMs=lead;state=s;
 }
 public static AisTimestampNormalization from(long provider,long received,long processed){
  if(provider<=0L||received<=0L||processed<=0L)return new AisTimestampNormalization(provider,received,processed,-1L,-1L,-1L,ClockState.UNKNOWN);
  long age=received-provider,delay=Math.max(0L,processed-received),lead=Math.max(0L,provider-received);
  ClockState s=lead>300000L?ClockState.PROVIDER_AHEAD:age>1800000L?ClockState.STALE:ClockState.NORMAL;
  return new AisTimestampNormalization(provider,received,processed,Math.max(0L,age),delay,lead,s);
 }
 public String disclosure(){
  if(state==ClockState.UNKNOWN)return "AIS TIME • UNKNOWN";
  return String.format(Locale.US,"AIS TIME • %s • AGE@RECEIVE %.1fs • PROCESSING %.1fs%s",
   state.name().replace('_',' '),ageAtReceiveMs/1000d,processingDelayMs/1000d,
   providerLeadMs>0L?String.format(Locale.US," • PROVIDER LEAD %.1fs",providerLeadMs/1000d):"");
 }
}
