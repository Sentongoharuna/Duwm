package com.sentongoharuna.worldsituationroom;
public final class PortShareCardValidation{private PortShareCardValidation(){}
 public static boolean include(boolean evidencePresent){return evidencePresent;}
 public static boolean inferredMissingValueAllowed(){return false;}
 public static boolean safeDisclosure(String x){return x!=null&&x.contains("missing data omitted")&&x.contains("no navigation/safety verdict");}
}