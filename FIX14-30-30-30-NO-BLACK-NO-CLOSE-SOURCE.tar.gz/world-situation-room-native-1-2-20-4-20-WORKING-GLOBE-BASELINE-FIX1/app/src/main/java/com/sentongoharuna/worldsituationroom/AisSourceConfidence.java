package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Transparent evidence-quality metadata. This is not certainty, truth probability, or navigation assurance. */
public final class AisSourceConfidence {
 public enum Band { STRONGER_EVIDENCE, MIXED_EVIDENCE, LIMITED_EVIDENCE, UNKNOWN }
 public final Band band;public final int score;public final List<String> reasons;
 private AisSourceConfidence(Band b,int s,List<String>r){band=b;score=s;reasons=Collections.unmodifiableList(new ArrayList<>(r));}
 public static AisSourceConfidence from(AisFusedVesselRecord f){
  if(f==null||f.primary==null)return new AisSourceConfidence(Band.UNKNOWN,0,Collections.singletonList("NO FUSED RECORD"));
  int s=0;ArrayList<String>r=new ArrayList<>();NormalizedAisRecord p=f.primary;
  if(!p.mmsi.isEmpty()||!p.imo.isEmpty()){s+=25;r.add("VALIDATED STRONG IDENTITY +25");}else r.add("NO VALIDATED MMSI/IMO +0");
  if(p.time!=null&&p.time.state==AisTimestampNormalization.ClockState.NORMAL){s+=20;r.add("NORMAL OBSERVATION TIME +20");}else r.add("TIME NOT NORMAL +0");
  if(p.hasLocation()){s+=20;r.add("VALID LOCATION +20");}
  int providers=new HashSet<String>(){{for(NormalizedAisRecord x:f.evidence)if(x!=null)add(x.providerId);}}.size();
  if(providers>=2){s+=15;r.add("MULTI-PROVIDER EVIDENCE +15");}
  boolean conflict=f.positionConflict!=null&&f.positionConflict.state==AisPositionConflict.State.CONFLICT
    ||f.speedConflict!=null&&f.speedConflict.state==AisSpeedConflict.State.CONFLICT
    ||f.headingConflict!=null&&f.headingConflict.state!=AisHeadingConflict.State.NONE&&f.headingConflict.state!=AisHeadingConflict.State.INSUFFICIENT;
  if(!conflict&&providers>=2){s+=20;r.add("NO MATERIAL CROSS-PROVIDER CONFLICT +20");}
  if(conflict){s=Math.max(0,s-25);r.add("MATERIAL PROVIDER CONFLICT -25");}
  s=Math.max(0,Math.min(100,s));
  Band b=s>=75?Band.STRONGER_EVIDENCE:s>=45?Band.MIXED_EVIDENCE:Band.LIMITED_EVIDENCE;
  return new AisSourceConfidence(b,s,r);
 }
 public String disclosure(){return "EVIDENCE QUALITY • "+band.name().replace('_',' ')+" • "+score+"/100 • NOT CERTAINTY";}
}
