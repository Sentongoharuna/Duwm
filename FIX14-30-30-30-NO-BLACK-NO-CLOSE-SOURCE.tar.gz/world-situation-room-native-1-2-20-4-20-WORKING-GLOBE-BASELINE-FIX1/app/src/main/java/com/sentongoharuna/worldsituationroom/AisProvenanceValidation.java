package com.sentongoharuna.worldsituationroom;
public final class AisProvenanceValidation{private AisProvenanceValidation(){}
 public static boolean complete(String value,String provider,String record,String sha,int links){
  return value!=null&&!value.isEmpty()&&provider!=null&&!provider.isEmpty()&&record!=null&&!record.isEmpty()&&sha!=null&&sha.matches("[0-9a-fA-F]{64}")&&links==4;
 }
}