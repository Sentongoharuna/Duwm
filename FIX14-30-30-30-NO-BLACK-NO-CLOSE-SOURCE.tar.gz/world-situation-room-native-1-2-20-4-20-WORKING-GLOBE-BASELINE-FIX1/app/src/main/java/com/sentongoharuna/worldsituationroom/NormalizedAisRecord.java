package com.sentongoharuna.worldsituationroom;
import java.util.Collections;import java.util.LinkedHashMap;import java.util.Map;
/** Strongly typed provider-neutral AIS record. Unknown numeric values are NaN, never invented zeroes. */
public final class NormalizedAisRecord {
 public final String providerId,providerName,providerRecordId,mmsi,imo,name,callsign,registration,vesselType,navigationStatus,destination,eta;
 public final long providerTimestampMs,receivedAtMs,processedAtMs;
 public final AisTimestampNormalization time;
 public final double latitude,longitude,sogMps,cogDegrees,headingDegrees,rotDegPerMin,draughtM;
 public final Map<String,String> rawFields;
 NormalizedAisRecord(String pid,String pn,String rid,long pt,long rt,long processed,String mm,String im,String n,String cs,String reg,String vt,
  double lat,double lon,double sog,double cog,double hdg,double rot,String nav,double dr,String dest,String e,Map<String,String> raw){
  providerId=pid;providerName=pn;providerRecordId=rid;providerTimestampMs=pt;receivedAtMs=rt;processedAtMs=processed;
  time=AisTimestampNormalization.from(pt,rt,processed);mmsi=mm;imo=im;name=n;callsign=cs;registration=reg;vesselType=vt;
  latitude=lat;longitude=lon;sogMps=sog;cogDegrees=cog;headingDegrees=hdg;rotDegPerMin=rot;navigationStatus=nav;draughtM=dr;destination=dest;eta=e;
  rawFields=Collections.unmodifiableMap(new LinkedHashMap<>(raw));
 }
 public boolean hasLocation(){return finite(latitude)&&finite(longitude);}
 public boolean hasSog(){return finite(sogMps);}
 public boolean hasCog(){return finite(cogDegrees);}
 private static boolean finite(double v){return !Double.isNaN(v)&&!Double.isInfinite(v);}
}
