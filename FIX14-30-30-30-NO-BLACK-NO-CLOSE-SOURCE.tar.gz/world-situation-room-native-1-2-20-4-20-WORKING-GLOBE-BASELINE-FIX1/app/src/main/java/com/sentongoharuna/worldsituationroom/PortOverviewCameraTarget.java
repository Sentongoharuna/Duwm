package com.sentongoharuna.worldsituationroom;
/** Camera target derived only from canonical port coordinates. It never mutates port data. */
public final class PortOverviewCameraTarget {
 public final String portId,portName;public final double latitude,longitude,altitudeKm,headingDeg,pitchDeg;public final long createdAtMs;
 PortOverviewCameraTarget(String id,String n,double lat,double lon,double alt,double heading,double pitch,long t){portId=id;portName=n;latitude=lat;longitude=lon;altitudeKm=alt;headingDeg=heading;pitchDeg=pitch;createdAtMs=t;}
 public boolean valid(){return !portId.isEmpty()&&!Double.isNaN(latitude)&&!Double.isNaN(longitude)&&latitude>=-90&&latitude<=90&&longitude>=-180&&longitude<=180&&altitudeKm>0&&pitchDeg>=0&&pitchDeg<=90;}
}
