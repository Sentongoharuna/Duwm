package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Explicit raw -> provider record -> normalized evidence -> fused field -> display provenance. */
public final class AisProvenanceChain {
 public static final class Link {
  public final String stage,id,providerId,detail;
  Link(String s,String i,String p,String d){stage=s;id=i;providerId=p;detail=d;}
 }
 public final String vesselKey,field,value;public final List<Link> links;public final boolean complete;
 private AisProvenanceChain(String k,String f,String v,List<Link>l,boolean c){vesselKey=k;field=f;value=v;links=Collections.unmodifiableList(new ArrayList<>(l));complete=c;}
 public static AisProvenanceChain build(AisFusedVesselRecord fused,String field,List<AisNormalizedEvidence> normalized,List<AisRawMessageEvidence> raw){
  ArrayList<Link> l=new ArrayList<>();if(fused==null)return new AisProvenanceChain("",field,"",l,false);
  String value=fused.values.get(field),provider=fused.providerFor(field);if(value==null)value="";
  l.add(new Link("DISPLAY/FUSED FIELD",field,provider,value));
  AisNormalizedEvidence n=null;if(normalized!=null)for(int i=normalized.size()-1;i>=0;i--){AisNormalizedEvidence x=normalized.get(i);if(x.providerId.equals(provider)){n=x;break;}}
  if(n!=null){l.add(new Link("NORMALIZED EVIDENCE",n.providerRecordId,n.providerId,"rawSha="+n.rawPayloadSha256));
   l.add(new Link("PROVIDER RECORD",n.providerRecordId,n.providerId,"providerTime="+n.providerTimestampMs));
   AisRawMessageEvidence r=null;if(raw!=null)for(AisRawMessageEvidence x:raw)if(x.payloadSha256.equalsIgnoreCase(n.rawPayloadSha256)){r=x;break;}
   if(r!=null)l.add(new Link("RAW PAYLOAD",r.payloadSha256,r.providerId,"received="+r.receivedAtMs+" bytes="+r.utf8Bytes));
  }
  boolean complete=!value.isEmpty()&&!provider.isEmpty()&&n!=null&&!n.rawPayloadSha256.isEmpty()&&l.size()==4;
  return new AisProvenanceChain(fused.vesselKey,field,value,l,complete);
 }
 public String disclosure(){return "PROVENANCE • "+field+" • "+(complete?"COMPLETE RAW→DISPLAY":"PARTIAL")+" • "+links.size()+" LINKS";}
}
