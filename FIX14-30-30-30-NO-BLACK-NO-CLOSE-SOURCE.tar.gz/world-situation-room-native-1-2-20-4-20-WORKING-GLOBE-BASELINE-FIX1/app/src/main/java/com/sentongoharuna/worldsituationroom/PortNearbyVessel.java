package com.sentongoharuna.worldsituationroom;
/** Port-relative AIS observation. Proximity is not equivalent to harbour/anchorage presence. */
public final class PortNearbyVessel {
 public enum Presence { NEARBY, INSIDE_HARBOUR, INSIDE_ANCHORAGE }
 public final String portId,vesselKey,mmsi,name,providerId;public final double latitude,longitude,distanceKm;public final long observedAtMs;public final Presence presence;
 PortNearbyVessel(String p,String k,String m,String n,String provider,double lat,double lon,double d,long t,Presence x){portId=p;vesselKey=k;mmsi=m;name=n;providerId=provider;latitude=lat;longitude=lon;distanceKm=d;observedAtMs=t;presence=x;}
}
