package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Summarizes provider-local freshness without allowing one stale source to poison healthy sources. */
public final class AisFusedFreshness {
 public final List<AisProviderFreshness.Result> providers;public final int live,aging,stale,silent,unknown;
 private AisFusedFreshness(List<AisProviderFreshness.Result> p,int l,int a,int s,int q,int u){providers=Collections.unmodifiableList(p);live=l;aging=a;stale=s;silent=q;unknown=u;}
 public static AisFusedFreshness from(List<NormalizedAisRecord> records,long nowMs){
  LinkedHashMap<String,NormalizedAisRecord> newest=new LinkedHashMap<>();
  if(records!=null)for(NormalizedAisRecord r:records)if(r!=null){NormalizedAisRecord x=newest.get(r.providerId);if(x==null||r.providerTimestampMs>x.providerTimestampMs)newest.put(r.providerId,r);}
  ArrayList<AisProviderFreshness.Result> out=new ArrayList<>();int l=0,a=0,s=0,q=0,u=0;
  for(NormalizedAisRecord r:newest.values()){AisProviderFreshness.Result f=AisProviderFreshness.assess(r.providerId,r.providerTimestampMs,r.receivedAtMs,nowMs);out.add(f);
   switch(f.state){case LIVE:l++;break;case AGING:a++;break;case STALE:s++;break;case SILENT:q++;break;default:u++;}}
  return new AisFusedFreshness(out,l,a,s,q,u);
 }
 public boolean hasHealthySource(){return live>0||aging>0;}
 public String disclosure(){return "PROVIDER FRESHNESS • LIVE "+live+" • AGING "+aging+" • STALE "+stale+" • SILENT "+silent+" • UNKNOWN "+unknown;}
}
