package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Detailed read-only provider health view model. */
public final class AisProviderHealthSnapshot {
 public final String providerId,health,freshness,circuit,lastError,recovery;
 public final long accepted,rejected,duplicates,isolatedSkips,lastReceivedAtMs,lastProviderTimeMs;
 public final double acceptPerMin,duplicatePerMin,rejectPerMin,normalizedPerMin,sourceLatencyMs,processingLatencyMs;
 AisProviderHealthSnapshot(String p,String h,String f,String c,String e,String rec,long a,long r,long d,long i,long lr,long lp,double ar,double dr,double rr,double nr,double sl,double pl){
  providerId=p;health=h;freshness=f;circuit=c;lastError=e;recovery=rec;accepted=a;rejected=r;duplicates=d;isolatedSkips=i;lastReceivedAtMs=lr;lastProviderTimeMs=lp;acceptPerMin=ar;duplicatePerMin=dr;rejectPerMin=rr;normalizedPerMin=nr;sourceLatencyMs=sl;processingLatencyMs=pl;
 }
 public String text(){
  return providerId+"\nHEALTH "+health+"\nFRESHNESS "+freshness+"\nCIRCUIT "+circuit+"\nRECOVERY "+recovery+
   "\nTOTAL ACCEPT "+accepted+" • DUP "+duplicates+" • REJECT "+rejected+" • ISOLATED "+isolatedSkips+
   String.format(Locale.US,"\nRATE/min ACCEPT %.1f • DUP %.1f • REJECT %.1f • NORMALIZED %.1f",acceptPerMin,duplicatePerMin,rejectPerMin,normalizedPerMin)+
   "\nSOURCE LAT "+fmt(sourceLatencyMs)+" • PROCESS LAT "+fmt(processingLatencyMs)+
   "\nLAST PROVIDER TIME "+lastProviderTimeMs+"\nLAST RECEIVE "+lastReceivedAtMs+"\nLAST ERROR "+(lastError.isEmpty()?"NONE":lastError)+
   "\nOPERATIONAL FEED HEALTH • NOT TRUTH";
 }
 private static String fmt(double v){return Double.isNaN(v)?"UNKNOWN":String.format(Locale.US,"%.0fms",v);}
}
