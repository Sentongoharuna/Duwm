package com.sentongoharuna.worldsituationroom;
/** Requires observed prior harbour/anchorage presence plus later exit and receding distance for departure evidence. */
public final class PortDepartingVesselEngine {
 private PortDepartingVesselEngine(){}
 public static PortDepartureEvidence assess(PortRegistry ports,String portId,String vesselKey,NormalizedAisRecord previous,NormalizedAisRecord current){
  PortRecord p=ports==null?null:ports.get(portId);
  if(p==null||previous==null||current==null||current.providerTimestampMs<=previous.providerTimestampMs||Double.isNaN(previous.latitude)||Double.isNaN(previous.longitude)||Double.isNaN(current.latitude)||Double.isNaN(current.longitude))
   return new PortDepartureEvidence(portId,vesselKey,PortDepartureEvidence.State.INSUFFICIENT,Double.NaN,Double.NaN,Double.NaN,previous==null?0:previous.providerTimestampMs,current==null?0:current.providerTimestampMs);
  boolean prevInside=ports.pointInsideHarbour(portId,previous.latitude,previous.longitude)||!ports.anchoragesContaining(portId,previous.latitude,previous.longitude).isEmpty();
  boolean nowInside=ports.pointInsideHarbour(portId,current.latitude,current.longitude)||!ports.anchoragesContaining(portId,current.latitude,current.longitude).isEmpty();
  double a=PortCoordinateRegistry.distanceKm(p.latitude,p.longitude,previous.latitude,previous.longitude),b=PortCoordinateRegistry.distanceKm(p.latitude,p.longitude,current.latitude,current.longitude);
  double rate=(b-a)/((current.providerTimestampMs-previous.providerTimestampMs)/3600000d);
  PortDepartureEvidence.State s=nowInside?PortDepartureEvidence.State.STILL_INSIDE:(prevInside&&b-a>0.10)?PortDepartureEvidence.State.DEPARTING_EVIDENCE:(b-a>0.10)?PortDepartureEvidence.State.RECEDING_NEARBY:PortDepartureEvidence.State.INSUFFICIENT;
  return new PortDepartureEvidence(portId,vesselKey,s,a,b,rate,previous.providerTimestampMs,current.providerTimestampMs);
 }
}
