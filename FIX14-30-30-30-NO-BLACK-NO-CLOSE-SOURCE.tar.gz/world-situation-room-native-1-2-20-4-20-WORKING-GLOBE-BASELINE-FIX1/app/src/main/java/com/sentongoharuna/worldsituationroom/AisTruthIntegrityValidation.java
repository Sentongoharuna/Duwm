package com.sentongoharuna.worldsituationroom;
public final class AisTruthIntegrityValidation{private AisTruthIntegrityValidation(){}
 public static boolean separation(boolean raw,boolean normalized,boolean provenance,boolean notCertainty,boolean notTruth,boolean noAverage){
  return raw&&normalized&&provenance&&notCertainty&&notTruth&&noAverage;
 }
}