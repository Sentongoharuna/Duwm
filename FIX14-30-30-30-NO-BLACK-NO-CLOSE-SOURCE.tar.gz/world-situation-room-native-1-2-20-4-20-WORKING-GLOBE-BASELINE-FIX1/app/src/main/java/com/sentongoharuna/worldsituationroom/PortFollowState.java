package com.sentongoharuna.worldsituationroom;
/** Persistent logical follow state for a canonical loaded port. */
public final class PortFollowState {
 public final String portId;public final boolean followed;public final long changedAtMs;
 PortFollowState(String p,boolean f,long t){portId=p;followed=f;changedAtMs=t;}
}
