package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Follow registry only tracks user-selected canonical ports; it creates no observations. */
public final class PortFollowRegistry {
 private final LinkedHashMap<String,PortFollowState> states=new LinkedHashMap<>();
 public synchronized boolean follow(PortRecord p,long now){if(p==null||now<=0)return false;states.put(p.portId,new PortFollowState(p.portId,true,now));return true;}
 public synchronized boolean unfollow(PortRecord p,long now){if(p==null||now<=0)return false;states.put(p.portId,new PortFollowState(p.portId,false,now));return true;}
 public synchronized boolean isFollowed(String id){PortFollowState s=states.get(id);return s!=null&&s.followed;}
 public synchronized List<String> followedPortIds(){ArrayList<String>o=new ArrayList<>();for(PortFollowState s:states.values())if(s.followed)o.add(s.portId);return Collections.unmodifiableList(o);}
 public synchronized PortFollowState state(String id){return states.get(id);}
 public synchronized int count(){int n=0;for(PortFollowState s:states.values())if(s.followed)n++;return n;}
}
