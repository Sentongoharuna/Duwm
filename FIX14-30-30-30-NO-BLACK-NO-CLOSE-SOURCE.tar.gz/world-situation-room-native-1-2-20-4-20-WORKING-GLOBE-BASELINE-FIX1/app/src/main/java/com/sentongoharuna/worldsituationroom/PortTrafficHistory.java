package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Bounded observed traffic snapshots. Never reconstructs unrecorded history. */
public final class PortTrafficHistory {
 private static final int MAX_PER_PORT=720;
 private final LinkedHashMap<String,ArrayDeque<PortTrafficCounters>> byPort=new LinkedHashMap<>();
 public synchronized boolean record(PortTrafficCounters s){
  if(s==null||s.portId==null||s.portId.trim().isEmpty()||s.generatedAtMs<=0||!s.presenceBalanced())return false;
  ArrayDeque<PortTrafficCounters> q=byPort.computeIfAbsent(s.portId,k->new ArrayDeque<>());
  PortTrafficCounters last=q.peekLast();if(last!=null&&s.generatedAtMs<=last.generatedAtMs)return false;
  q.addLast(s);while(q.size()>MAX_PER_PORT)q.removeFirst();return true;
 }
 public synchronized List<PortTrafficCounters> snapshots(String portId){ArrayDeque<PortTrafficCounters>q=byPort.get(portId);return q==null?Collections.emptyList():Collections.unmodifiableList(new ArrayList<>(q));}
 public synchronized List<PortTrafficCounters> between(String portId,long from,long to){ArrayList<PortTrafficCounters>o=new ArrayList<>();if(to<from)return Collections.emptyList();for(PortTrafficCounters s:snapshots(portId))if(s.generatedAtMs>=from&&s.generatedAtMs<=to)o.add(s);return Collections.unmodifiableList(o);}
 public synchronized PortTrafficCounters nearest(String portId,long at){PortTrafficCounters best=null;long delta=Long.MAX_VALUE;for(PortTrafficCounters s:snapshots(portId)){long d=Math.abs(s.generatedAtMs-at);if(d<delta){delta=d;best=s;}}return best;}
 public synchronized int size(String portId){ArrayDeque<PortTrafficCounters>q=byPort.get(portId);return q==null?0:q.size();}
 public int maxPerPort(){return MAX_PER_PORT;}
}
