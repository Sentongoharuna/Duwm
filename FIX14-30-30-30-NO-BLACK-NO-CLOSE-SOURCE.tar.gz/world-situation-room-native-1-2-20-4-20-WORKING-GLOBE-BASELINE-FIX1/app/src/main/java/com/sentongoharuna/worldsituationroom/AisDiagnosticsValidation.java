package com.sentongoharuna.worldsituationroom;
public final class AisDiagnosticsValidation{private AisDiagnosticsValidation(){}
 public static boolean complete(String line){return line!=null&&line.contains("CIRCUIT")&&line.contains("ACCEPT")&&line.contains("DUP")&&line.contains("REJECT")&&line.contains("SRC LAT")&&line.contains("PROC LAT");}
}