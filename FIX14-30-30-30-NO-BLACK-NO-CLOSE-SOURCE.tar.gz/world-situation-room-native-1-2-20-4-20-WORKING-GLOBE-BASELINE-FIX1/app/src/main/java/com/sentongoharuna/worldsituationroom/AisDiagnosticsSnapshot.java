package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Read-only operational diagnostics snapshot; does not mutate provider/vessel state. */
public final class AisDiagnosticsSnapshot {
 public final long generatedAtMs; public final List<String> providerLines; public final int quarantineCount,rawEvidenceCount,normalizedEvidenceCount; public final long rawEvidenceBytes;
 AisDiagnosticsSnapshot(long t,List<String> p,int q,int r,int n,long b){generatedAtMs=t;providerLines=Collections.unmodifiableList(new ArrayList<>(p));quarantineCount=q;rawEvidenceCount=r;normalizedEvidenceCount=n;rawEvidenceBytes=b;}
 public String text(){
  StringBuilder x=new StringBuilder("FIX13 AIS INGESTION DIAGNOSTICS\n");
  x.append("PROVIDERS ").append(providerLines.size()).append("\n");
  for(String s:providerLines)x.append(s).append("\n");
  x.append("QUARANTINE ").append(quarantineCount).append("\nRAW EVIDENCE ").append(rawEvidenceCount).append(" • ").append(rawEvidenceBytes).append(" bytes\nNORMALIZED EVIDENCE ").append(normalizedEvidenceCount);
  return x.toString();
 }
}
