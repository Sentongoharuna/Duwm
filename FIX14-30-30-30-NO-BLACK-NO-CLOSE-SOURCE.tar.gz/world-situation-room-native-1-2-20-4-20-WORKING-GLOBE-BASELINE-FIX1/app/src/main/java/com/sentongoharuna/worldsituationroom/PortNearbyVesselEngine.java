package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Joins FIX13 fused AIS with FIX14 port geometry without inventing port calls. */
public final class PortNearbyVesselEngine {
 private PortNearbyVesselEngine(){}
 public static List<PortNearbyVessel> find(PortRegistry ports,String portId,List<AisFusedVesselRecord> vessels,double radiusKm){
  PortRecord p=ports==null?null:ports.get(portId);if(p==null||vessels==null||radiusKm<0)return Collections.emptyList();
  ArrayList<PortNearbyVessel> out=new ArrayList<>();
  for(AisFusedVesselRecord v:vessels){
   if(v==null||v.primary==null||Double.isNaN(v.primary.latitude)||Double.isNaN(v.primary.longitude))continue;
   double d=PortCoordinateRegistry.distanceKm(p.latitude,p.longitude,v.primary.latitude,v.primary.longitude);if(d>radiusKm)continue;
   boolean anch=!ports.anchoragesContaining(portId,v.primary.latitude,v.primary.longitude).isEmpty();
   boolean harbour=ports.pointInsideHarbour(portId,v.primary.latitude,v.primary.longitude);
   PortNearbyVessel.Presence presence=anch?PortNearbyVessel.Presence.INSIDE_ANCHORAGE:harbour?PortNearbyVessel.Presence.INSIDE_HARBOUR:PortNearbyVessel.Presence.NEARBY;
   out.add(new PortNearbyVessel(portId,v.vesselKey,v.primary.mmsi,v.primary.name,v.primary.providerId,v.primary.latitude,v.primary.longitude,d,v.primary.providerTimestampMs,presence));
  }
  out.sort(Comparator.comparingDouble(x->x.distanceKm));return Collections.unmodifiableList(out);
 }
}
