package com.sentongoharuna.worldsituationroom;
public final class PortFollowValidation{private PortFollowValidation(){}
 public static boolean validChange(boolean portExists,long atMs){return portExists&&atMs>0;}
 public static int count(boolean... states){int n=0;for(boolean x:states)if(x)n++;return n;}
}