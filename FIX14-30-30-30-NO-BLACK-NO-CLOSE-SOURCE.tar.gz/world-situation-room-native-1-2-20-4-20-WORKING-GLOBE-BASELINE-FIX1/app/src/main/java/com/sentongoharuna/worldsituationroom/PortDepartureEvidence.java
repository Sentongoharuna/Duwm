package com.sentongoharuna.worldsituationroom;
/** Observed exit + increasing-distance evidence. Not a confirmed voyage departure. */
public final class PortDepartureEvidence {
 public enum State { DEPARTING_EVIDENCE, RECEDING_NEARBY, STILL_INSIDE, INSUFFICIENT }
 public final String portId,vesselKey;public final State state;public final double previousDistanceKm,currentDistanceKm,radialRateKph;public final long previousAtMs,currentAtMs;
 PortDepartureEvidence(String p,String v,State s,double a,double b,double rate,long t1,long t2){portId=p;vesselKey=v;state=s;previousDistanceKm=a;currentDistanceKm=b;radialRateKph=rate;previousAtMs=t1;currentAtMs=t2;}
 public String disclosure(){return state+" • observed geometry/movement evidence • not confirmed voyage departure";}
}
