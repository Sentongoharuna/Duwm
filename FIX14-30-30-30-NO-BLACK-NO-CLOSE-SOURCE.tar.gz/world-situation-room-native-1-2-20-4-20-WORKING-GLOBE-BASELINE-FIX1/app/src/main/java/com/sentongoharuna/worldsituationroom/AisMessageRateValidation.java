package com.sentongoharuna.worldsituationroom;
public final class AisMessageRateValidation{private AisMessageRateValidation(){}
 public static double perMinute(long count,long windowMs){return windowMs<=0?0d:count*60000d/windowMs;}
 public static boolean inWindow(long event,long now,long window){return event>0&&now>=event&&now-event<=window;}
}