package com.sentongoharuna.worldsituationroom;
public final class PortPerformanceValidation{private PortPerformanceValidation(){}
 public static boolean accounted(int events,int a,int d,int u,int r){return events>=0&&events==a+d+u+r;}
 public static boolean bounded(int size,int bound){return size>=0&&bound>=0&&size<=bound;}
}