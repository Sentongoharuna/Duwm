package com.sentongoharuna.worldsituationroom;
import java.util.List;
import java.util.Locale;

public final class AircraftAirportProximity {
 public final Signal airportSignal;
 public final AirportIntelligence airport;
 public final double distanceKm;
 public final double bearingDegrees;
 public final String routeRelation;

 private AircraftAirportProximity(Signal s,AirportIntelligence a,double d,double b,String r){
  airportSignal=s;airport=a;distanceKm=d;bearingDegrees=b;routeRelation=r;
 }

 public static AircraftAirportProximity nearest(Signal aircraft,List<Signal> airports){
  if(aircraft==null||aircraft.layer!=Signal.Layer.FLIGHTS||!aircraft.hasLocation()||airports==null)return null;
  AircraftRouteIntelligence route=AircraftRouteIntelligence.from(aircraft);
  AircraftAirportProximity best=null;
  for(Signal s:airports){
   AirportIntelligence a=AirportIntelligence.from(s);
   if(a==null)continue;
   double d=SatelliteMapView.distanceKm(aircraft.latitude,aircraft.longitude,a.latitude,a.longitude);
   if(Double.isNaN(d)||Double.isInfinite(d))continue;
   String relation="NEARBY";
   if(route.known()){
    if(matches(route.origin,a))relation="ROUTE ORIGIN";
    else if(matches(route.destination,a))relation="ROUTE DESTINATION";
   }
   double bearing=bearing(aircraft.latitude,aircraft.longitude,a.latitude,a.longitude);
   if(best==null||d<best.distanceKm)best=new AircraftAirportProximity(s,a,d,bearing,relation);
  }
  return best;
 }

 private static boolean matches(String code,AirportIntelligence a){
  return code!=null&&!code.isEmpty()&&(code.equalsIgnoreCase(a.icao)||code.equalsIgnoreCase(a.iata));
 }
 private static double bearing(double lat1,double lon1,double lat2,double lon2){
  double p1=Math.toRadians(lat1),p2=Math.toRadians(lat2),dl=Math.toRadians(lon2-lon1);
  double y=Math.sin(dl)*Math.cos(p2);
  double x=Math.cos(p1)*Math.sin(p2)-Math.sin(p1)*Math.cos(p2)*Math.cos(dl);
  double b=Math.toDegrees(Math.atan2(y,x));return (b+360d)%360d;
 }
 public String compact(){
  return String.format(Locale.US,"%s • %.1f km • %03.0f° • %s",
      airport.code(),distanceKm,bearingDegrees,routeRelation);
 }
}
