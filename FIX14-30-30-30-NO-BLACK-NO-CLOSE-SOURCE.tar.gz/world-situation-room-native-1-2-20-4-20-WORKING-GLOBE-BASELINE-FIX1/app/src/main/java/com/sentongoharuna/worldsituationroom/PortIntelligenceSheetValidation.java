package com.sentongoharuna.worldsituationroom;
public final class PortIntelligenceSheetValidation{private PortIntelligenceSheetValidation(){}
 public static boolean counts(int... x){for(int v:x)if(v<0)return false;return true;}
 public static boolean buildable(boolean portExists,long now){return portExists&&now>0;}
 public static boolean missingMayRemainMissing(){return true;}
}