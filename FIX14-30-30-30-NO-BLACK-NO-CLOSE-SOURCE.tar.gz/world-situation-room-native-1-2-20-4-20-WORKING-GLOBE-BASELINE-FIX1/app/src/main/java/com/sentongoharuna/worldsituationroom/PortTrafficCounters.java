package com.sentongoharuna.worldsituationroom;
/** Snapshot counts. Presence buckets are mutually exclusive; behavioral evidence is reported separately. */
public final class PortTrafficCounters {
 public final String portId;public final long generatedAtMs;
 public final int uniqueVessels,nearbyOnly,insideHarbour,insideAnchorage,approachingEvidence,departingEvidence,anchoredEvidence;
 PortTrafficCounters(String p,long t,int u,int n,int h,int a,int ap,int d,int an){portId=p;generatedAtMs=t;uniqueVessels=u;nearbyOnly=n;insideHarbour=h;insideAnchorage=a;approachingEvidence=ap;departingEvidence=d;anchoredEvidence=an;}
 public boolean presenceBalanced(){return uniqueVessels==nearbyOnly+insideHarbour+insideAnchorage;}
 public String text(){return "UNIQUE "+uniqueVessels+" • NEARBY "+nearbyOnly+" • HARBOUR "+insideHarbour+" • ANCHORAGE "+insideAnchorage+" • APPROACHING-EVIDENCE "+approachingEvidence+" • DEPARTING-EVIDENCE "+departingEvidence+" • ANCHORED-EVIDENCE "+anchoredEvidence;}
}
