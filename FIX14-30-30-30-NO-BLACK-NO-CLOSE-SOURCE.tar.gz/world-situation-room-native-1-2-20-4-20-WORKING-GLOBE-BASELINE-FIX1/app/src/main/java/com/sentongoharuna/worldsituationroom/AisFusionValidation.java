package com.sentongoharuna.worldsituationroom;
public final class AisFusionValidation{private AisFusionValidation(){}
 public static String choose(String high,String low){if(high!=null&&!high.trim().isEmpty())return high.trim();return low==null?"":low.trim();}
 public static String provider(String high,String highProvider,String low,String lowProvider){return high!=null&&!high.trim().isEmpty()?highProvider:(low!=null&&!low.trim().isEmpty()?lowProvider:"");}
}