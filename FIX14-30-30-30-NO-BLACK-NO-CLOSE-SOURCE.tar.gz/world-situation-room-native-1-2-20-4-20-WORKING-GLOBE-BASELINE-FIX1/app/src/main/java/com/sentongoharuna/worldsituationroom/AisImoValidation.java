package com.sentongoharuna.worldsituationroom;
public final class AisImoValidation {
 public enum State { VALID, MISSING, FORMAT_INVALID, SENTINEL, CHECK_DIGIT_INVALID }
 public static final class Result {
  public final State state; public final String imo; public final int expectedCheckDigit,actualCheckDigit;
  Result(State s,String i,int e,int a){state=s;imo=i;expectedCheckDigit=e;actualCheckDigit=a;}
  public boolean accepted(){return state==State.VALID;}
  public String disclosure(){return accepted()?"IMO "+imo+" • CHECK DIGIT VALID":"IMO "+state.name().replace('_',' ');}
 }
 private AisImoValidation(){}
 public static Result validate(String raw){
  String x=raw==null?"":raw.trim().toUpperCase();
  if(x.startsWith("IMO"))x=x.substring(3).trim();
  if(x.isEmpty())return new Result(State.MISSING,"",-1,-1);
  if(!x.matches("\\d{7}"))return new Result(State.FORMAT_INVALID,x,-1,-1);
  if(x.equals("0000000")||x.equals("9999999"))return new Result(State.SENTINEL,x,-1,-1);
  int sum=0;for(int i=0;i<6;i++)sum+=(x.charAt(i)-'0')*(7-i);
  int expected=sum%10,actual=x.charAt(6)-'0';
  return new Result(expected==actual?State.VALID:State.CHECK_DIGIT_INVALID,x,expected,actual);
 }
}
