package com.sentongoharuna.worldsituationroom;
/** Requires sourced anchorage containment plus low observed speed and limited displacement. */
public final class PortAnchoredVesselEngine {
 private PortAnchoredVesselEngine(){}
 public static PortAnchoredVesselState assess(PortRegistry ports,String portId,String vesselKey,NormalizedAisRecord previous,NormalizedAisRecord current){
  if(ports==null||ports.get(portId)==null||previous==null||current==null||current.providerTimestampMs<=previous.providerTimestampMs)
   return new PortAnchoredVesselState(portId,vesselKey,PortAnchoredVesselState.State.INSUFFICIENT,Double.NaN,Double.NaN,previous==null?0:previous.providerTimestampMs,current==null?0:current.providerTimestampMs);
  boolean coords=valid(previous.latitude,previous.longitude)&&valid(current.latitude,current.longitude);
  if(!coords)return new PortAnchoredVesselState(portId,vesselKey,PortAnchoredVesselState.State.INSUFFICIENT,current.sogMps,Double.NaN,previous.providerTimestampMs,current.providerTimestampMs);
  boolean inside=!ports.anchoragesContaining(portId,current.latitude,current.longitude).isEmpty();
  double displacementM=PortCoordinateRegistry.distanceKm(previous.latitude,previous.longitude,current.latitude,current.longitude)*1000d;
  PortAnchoredVesselState.State s=PortAnchoredVesselValidation.classify(inside,current.sogMps,displacementM,true);
  return new PortAnchoredVesselState(portId,vesselKey,s,current.sogMps,displacementM,previous.providerTimestampMs,current.providerTimestampMs);
 }
 private static boolean valid(double a,double o){return !Double.isNaN(a)&&!Double.isNaN(o)&&a>=-90&&a<=90&&o>=-180&&o<=180;}
}