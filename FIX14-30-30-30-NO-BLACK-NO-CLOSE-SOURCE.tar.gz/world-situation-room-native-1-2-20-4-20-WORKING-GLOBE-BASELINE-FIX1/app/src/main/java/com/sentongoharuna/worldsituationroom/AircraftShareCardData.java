package com.sentongoharuna.worldsituationroom;
import java.util.Locale;
public final class AircraftShareCardData {
 public final String identity,registration,icao24,route,altitude,speed,verticalState,observationTime,provider,truth,coordinates,timeline;
 private AircraftShareCardData(String i,String r,String c,String q,String a,String s,String v,String t,String p,String z,String x,String l){identity=i;registration=r;icao24=c;route=q;altitude=a;speed=s;verticalState=v;observationTime=t;provider=p;truth=z;coordinates=x;timeline=l;}
 public static AircraftShareCardData from(Signal signal,String timeText,String timeline){
  AircraftTelemetry t=AircraftTelemetry.from(signal);AircraftAltitudeIntelligence a=AircraftAltitudeIntelligence.from(signal);AircraftRouteIntelligence r=AircraftRouteIntelligence.from(signal);
  String id=t!=null&&!t.callsign.isEmpty()?t.callsign:t!=null&&!t.registration.isEmpty()?t.registration:t!=null&&!t.icao24.isEmpty()?t.icao24:signal.title;
  String sp=t!=null&&t.hasSpeed()?String.format(Locale.US,"%.0f kt",t.groundSpeedMps*1.943844d):"UNKNOWN";
  String coords=signal.hasLocation()?String.format(Locale.US,"%.5f, %.5f",signal.latitude,signal.longitude):"UNKNOWN";
  return new AircraftShareCardData(id,t==null?"":t.registration,t==null?"":t.icao24,r.known()?r.compact():"ROUTE UNKNOWN",a.compact(),sp,String.valueOf(signal.facts.get("VERTICAL MOVEMENT")),timeText,t==null||t.providerId==null?"UNKNOWN":t.providerId,TruthEnforcement.label(signal),coords,timeline);
 }
 public String text(){
  StringBuilder b=new StringBuilder("DU WORLD MONITOR • AIRCRAFT INTELLIGENCE\n").append(identity).append("\n");
  if(!registration.isEmpty())b.append("REG ").append(registration).append("\n");if(!icao24.isEmpty())b.append("ICAO24 ").append(icao24).append("\n");
  return b.append(route).append("\n").append(altitude).append("\nSPEED ").append(speed).append("\nVERTICAL ").append(verticalState==null?"UNKNOWN":verticalState)
   .append("\nPOSITION ").append(coordinates).append("\nOBSERVED ").append(observationTime).append("\nPROVIDER ").append(provider)
   .append("\nSTATE ").append(truth).append("\nTIMELINE ").append(timeline)
   .append("\nProvider-backed intelligence; calculated/inferred fields retain their disclosures.").toString();
 }
}
