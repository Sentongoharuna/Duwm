package com.sentongoharuna.worldsituationroom;
import java.util.ArrayList;import java.util.Collections;import java.util.Comparator;import java.util.List;import java.util.Locale;
/** Source-backed weather proximity. Does not infer hazard exposure from proximity. */
public final class AircraftWeatherContext {
 public static final class Entry {
  public final Signal signal; public final double distanceKm; public final String kind,summary;
  Entry(Signal s,double d,String k,String x){signal=s;distanceKm=d;kind=k;summary=x;}
  public String label(){return String.format(Locale.US,"%.1f km • %s • %s • %s",distanceKm,kind,summary,TruthEnforcement.label(signal));}
 }
 private AircraftWeatherContext(){}
 public static List<Entry> nearby(Signal aircraft,List<Signal> records,double radiusKm){
  ArrayList<Entry> out=new ArrayList<>();
  if(aircraft==null||aircraft.layer!=Signal.Layer.FLIGHTS||!aircraft.hasLocation()||records==null)return out;
  for(Signal s:records){
   if(s==null||!s.hasLocation())continue;
   double d=SatelliteMapView.distanceKm(aircraft.latitude,aircraft.longitude,s.latitude,s.longitude);
   if(Double.isNaN(d)||d>radiusKm)continue;
   String kind=fact(s,"WEATHER TYPE","TYPE","EVENT TYPE");
   String summary=fact(s,"WEATHER SUMMARY","SUMMARY","CONDITION","TITLE");
   if(kind.isEmpty())kind=s.layer.name(); if(summary.isEmpty())summary=s.title;
   out.add(new Entry(s,d,kind,summary));
  }
  Collections.sort(out,Comparator.comparingDouble(e->e.distanceKm));return out;
 }
 private static String fact(Signal s,String...ks){for(String k:ks){String v=s.facts.get(k);if(v!=null&&!v.trim().isEmpty())return v.trim();}return "";}
}
