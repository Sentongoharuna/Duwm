package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Source-backed harbour/port entrance geometry. No entrance is inferred from approach endpoints. */
public final class PortEntranceRecord {
 public final String entranceId,portId,name,entranceType,sourceId,sourceRecordId;
 public final double latitude,longitude,widthM;public final List<HarbourBoundaryEvidence.Point> gateLine;public final long observedAtMs;
 public PortEntranceRecord(String id,String p,String n,String type,double lat,double lon,double width,List<HarbourBoundaryEvidence.Point> gate,String s,String sr,long t){
  entranceId=c(id);portId=c(p);name=c(n);entranceType=c(type);latitude=lat;longitude=lon;widthM=width;gateLine=Collections.unmodifiableList(new ArrayList<>(gate==null?Collections.emptyList():gate));sourceId=c(s);sourceRecordId=c(sr);observedAtMs=t;
 }
 public boolean valid(){
  if(entranceId.isEmpty()||portId.isEmpty()||name.isEmpty()||sourceId.isEmpty()||sourceRecordId.isEmpty()||!finite(latitude)||!finite(longitude)||latitude<-90||latitude>90||longitude<-180||longitude>180||(!Double.isNaN(widthM)&&widthM<0))return false;
  if(!gateLine.isEmpty()&&gateLine.size()!=2)return false;
  for(HarbourBoundaryEvidence.Point x:gateLine)if(!finite(x.latitude)||!finite(x.longitude)||x.latitude<-90||x.latitude>90||x.longitude<-180||x.longitude>180)return false;
  return true;
 }
 private static String c(String s){return s==null?"":s.trim();}private static boolean finite(double v){return !Double.isNaN(v)&&!Double.isInfinite(v);}
}
