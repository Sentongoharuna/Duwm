package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Multi-source harbour boundaries with point-in-polygon and disagreement detection. */
public final class HarbourBoundaryRegistry {
 public enum Decision { ADDED, UPDATED, DUPLICATE, REJECTED }
 public enum ConflictState { NONE, CONFLICT, INSUFFICIENT }
 public static final class Result {public final Decision decision;public final String reason;Result(Decision d,String r){decision=d;reason=r;}}
 public static final class Conflict {public final ConflictState state;public final double maxCentroidSeparationKm;public final String sourceA,sourceB;Conflict(ConflictState s,double d,String a,String b){state=s;maxCentroidSeparationKm=d;sourceA=a;sourceB=b;}}
 private final LinkedHashMap<String,LinkedHashMap<String,HarbourBoundaryEvidence>> byPort=new LinkedHashMap<>();
 public synchronized Result add(PortRecord port,HarbourBoundaryEvidence e){
  if(port==null||e==null||!e.valid()||!port.portId.equals(e.portId))return new Result(Decision.REJECTED,"INVALID/UNKNOWN HARBOUR BOUNDARY");
  String k=e.sourceId+"|"+e.sourceRecordId+"|"+e.boundaryId;LinkedHashMap<String,HarbourBoundaryEvidence>m=byPort.computeIfAbsent(e.portId,z->new LinkedHashMap<>());HarbourBoundaryEvidence old=m.get(k);
  if(old!=null&&same(old,e))return new Result(Decision.DUPLICATE,"UNCHANGED");m.put(k,e);return new Result(old==null?Decision.ADDED:Decision.UPDATED,old==null?"ADDED":"UPDATED");
 }
 public synchronized List<HarbourBoundaryEvidence> boundaries(String portId){Map<String,HarbourBoundaryEvidence>m=byPort.get(portId);return m==null?Collections.emptyList():Collections.unmodifiableList(new ArrayList<>(m.values()));}
 public synchronized boolean contains(String portId,double lat,double lon){for(HarbourBoundaryEvidence e:boundaries(portId))if(inside(e.polygon,lat,lon))return true;return false;}
 public synchronized Conflict conflict(String portId){
  List<HarbourBoundaryEvidence> e=boundaries(portId);if(e.size()<2)return new Conflict(ConflictState.INSUFFICIENT,Double.NaN,"","");
  double max=0;String a="",b="";boolean compared=false;
  for(int i=0;i<e.size();i++)for(int j=i+1;j<e.size();j++){HarbourBoundaryEvidence x=e.get(i),y=e.get(j);if(x.sourceId.equals(y.sourceId))continue;compared=true;double[]cx=centroid(x),cy=centroid(y);double d=PortCoordinateRegistry.distanceKm(cx[0],cx[1],cy[0],cy[1]);if(d>max){max=d;a=x.sourceId;b=y.sourceId;}}
  if(!compared)return new Conflict(ConflictState.INSUFFICIENT,Double.NaN,"","");
  return new Conflict(max>2d?ConflictState.CONFLICT:ConflictState.NONE,max,a,b);
 }
 public synchronized int count(){int n=0;for(Map<String,HarbourBoundaryEvidence>m:byPort.values())n+=m.size();return n;}
 static boolean inside(List<HarbourBoundaryEvidence.Point> p,double lat,double lon){boolean in=false;for(int i=0,j=p.size()-1;i<p.size();j=i++){double yi=p.get(i).latitude,yj=p.get(j).latitude,xi=p.get(i).longitude,xj=p.get(j).longitude;if(((yi>lat)!=(yj>lat))&&(lon<(xj-xi)*(lat-yi)/(yj-yi)+xi))in=!in;}return in;}
 private static double[] centroid(HarbourBoundaryEvidence e){double a=0,b=0;for(HarbourBoundaryEvidence.Point p:e.polygon){a+=p.latitude;b+=p.longitude;}return new double[]{a/e.polygon.size(),b/e.polygon.size()};}
 private static boolean same(HarbourBoundaryEvidence a,HarbourBoundaryEvidence b){if(!a.method.equals(b.method)||a.observedAtMs!=b.observedAtMs||a.polygon.size()!=b.polygon.size())return false;for(int i=0;i<a.polygon.size();i++){HarbourBoundaryEvidence.Point x=a.polygon.get(i),y=b.polygon.get(i);if(Double.compare(x.latitude,y.latitude)!=0||Double.compare(x.longitude,y.longitude)!=0)return false;}return true;}
}
