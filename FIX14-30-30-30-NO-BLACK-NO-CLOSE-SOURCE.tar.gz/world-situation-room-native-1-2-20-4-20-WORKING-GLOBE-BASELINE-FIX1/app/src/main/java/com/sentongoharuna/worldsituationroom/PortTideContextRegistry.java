package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class PortTideContextRegistry {
 public enum Decision { ADDED, UPDATED, DUPLICATE, REJECTED, CONFLICT }
 public static final class Result {public final Decision decision;public final String reason;Result(Decision d,String r){decision=d;reason=r;}}
 private final LinkedHashMap<String,PortTideContextRecord> byId=new LinkedHashMap<>();private final LinkedHashMap<String,String> sourceBinding=new LinkedHashMap<>();
 public synchronized Result upsert(PortRecord p,PortTideContextRecord x){
  if(p==null||x==null||!x.valid()||!p.portId.equals(x.portId))return new Result(Decision.REJECTED,"INVALID TIDE CONTEXT OR PARENT PORT");
  String sk=x.sourceId+"|"+x.sourceRecordId,prior=sourceBinding.get(sk);if(prior!=null&&!prior.equals(x.tideId))return new Result(Decision.CONFLICT,"SOURCE RECORD ALREADY BOUND TO "+prior);
  PortTideContextRecord old=byId.get(x.tideId);if(old!=null&&(!old.portId.equals(x.portId)||old.kind!=x.kind))return new Result(Decision.CONFLICT,"TIDE ID PORT/KIND CHANGED");
  if(old!=null&&same(old,x)){sourceBinding.put(sk,x.tideId);return new Result(Decision.DUPLICATE,"UNCHANGED");}
  byId.put(x.tideId,x);sourceBinding.put(sk,x.tideId);return new Result(old==null?Decision.ADDED:Decision.UPDATED,old==null?"ADDED":"UPDATED");
 }
 public synchronized PortTideContextRecord get(String id){return byId.get(id==null?"":id.trim());}
 public synchronized List<PortTideContextRecord> forPort(String p,PortTideContextRecord.Kind k){ArrayList<PortTideContextRecord>o=new ArrayList<>();for(PortTideContextRecord x:byId.values())if(x.portId.equals(p)&&(k==null||x.kind==k))o.add(x);return Collections.unmodifiableList(o);}
 public synchronized PortTideContextRecord nearest(String p,PortTideContextRecord.Kind k,long t){PortTideContextRecord best=null;long delta=Long.MAX_VALUE;for(PortTideContextRecord x:forPort(p,k)){long d=Math.abs(x.eventAtMs-t);if(d<delta){delta=d;best=x;}}return best;}
 public synchronized int size(){return byId.size();}
 private static boolean same(PortTideContextRecord a,PortTideContextRecord b){return a.portId.equals(b.portId)&&a.stationId.equals(b.stationId)&&a.datum.equals(b.datum)&&a.kind==b.kind&&a.eventType.equals(b.eventType)&&Double.compare(a.waterLevelM,b.waterLevelM)==0&&a.eventAtMs==b.eventAtMs&&a.issuedAtMs==b.issuedAtMs&&a.receivedAtMs==b.receivedAtMs;}
}
