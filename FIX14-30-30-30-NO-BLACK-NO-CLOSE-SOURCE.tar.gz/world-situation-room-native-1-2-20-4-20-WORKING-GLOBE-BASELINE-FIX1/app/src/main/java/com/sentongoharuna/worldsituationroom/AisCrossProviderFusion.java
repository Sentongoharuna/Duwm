package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Fuses same-vessel provider evidence. Field provenance is mandatory; evidence records are never discarded. */
public final class AisCrossProviderFusion {
 private AisCrossProviderFusion(){}
 public static AisFusedVesselRecord fuse(String key,List<NormalizedAisRecord> records,AisProviderPriority priority){
  AisProviderSelector.Selection sel=AisProviderSelector.select(records,priority);if(sel.selected==null)return null;
  LinkedHashMap<String,String> v=new LinkedHashMap<>(),p=new LinkedHashMap<>();
  ArrayList<NormalizedAisRecord> ordered=new ArrayList<>(sel.evidence);
  ordered.sort((a,b)->{int x=Integer.compare(priority.rank(a.providerId),priority.rank(b.providerId));if(x!=0)return x;return Long.compare(b.providerTimestampMs,a.providerTimestampMs);});
  for(NormalizedAisRecord r:ordered){
   put(v,p,"mmsi",r.mmsi,r.providerId);put(v,p,"imo",r.imo,r.providerId);put(v,p,"name",r.name,r.providerId);
   put(v,p,"callsign",r.callsign,r.providerId);put(v,p,"registration",r.registration,r.providerId);put(v,p,"vessel_type",r.vesselType,r.providerId);
   putNum(v,p,"latitude",r.latitude,r.providerId);putNum(v,p,"longitude",r.longitude,r.providerId);putNum(v,p,"sog_mps",r.sogMps,r.providerId);
   putNum(v,p,"cog_deg",r.cogDegrees,r.providerId);putNum(v,p,"heading_deg",r.headingDegrees,r.providerId);putNum(v,p,"rot_deg_min",r.rotDegPerMin,r.providerId);
   put(v,p,"navigation_status",r.navigationStatus,r.providerId);putNum(v,p,"draught_m",r.draughtM,r.providerId);put(v,p,"destination",r.destination,r.providerId);put(v,p,"eta",r.eta,r.providerId);
  }
  AisPositionConflict.Result positionConflict=AisPositionConflict.detect(sel.evidence);
  AisSpeedConflict.Result speedConflict=AisSpeedConflict.detect(sel.evidence);
  AisHeadingConflict.Result headingConflict=AisHeadingConflict.detect(sel.evidence);
  AisFusedVesselRecord fused=new AisFusedVesselRecord(key,sel.selected,v,p,sel.evidence,positionConflict,speedConflict,headingConflict);
  fused.confidence=AisSourceConfidence.from(fused);
  fused.freshness=AisFusedFreshness.from(sel.evidence,System.currentTimeMillis());
  return fused;
 }
 private static void put(Map<String,String>v,Map<String,String>p,String k,String x,String provider){if(!v.containsKey(k)&&x!=null&&!x.trim().isEmpty()){v.put(k,x.trim());p.put(k,provider);}}
 private static void putNum(Map<String,String>v,Map<String,String>p,String k,double x,String provider){if(!v.containsKey(k)&&!Double.isNaN(x)&&!Double.isInfinite(x)){v.put(k,Double.toString(x));p.put(k,provider);}}
}
