package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Source-backed maritime weather proximity. Proximity never proves vessel impact. */
public final class MaritimeWeatherContext {
 public static final class Entry {
  public final Signal signal;public final double distanceKm;public final String kind,summary,wind,waves,warning;
  Entry(Signal s,double d,String k,String x,String w,String wa,String warn){signal=s;distanceKm=d;kind=k;summary=x;wind=w;waves=wa;warning=warn;}
  public String label(){return String.format(Locale.US,"%.1f km • %s • %s%s%s%s • %s",distanceKm,kind,summary,
   wind.isEmpty()?"":" • WIND "+wind,waves.isEmpty()?"":" • WAVES "+waves,warning.isEmpty()?"":" • WARNING "+warning,TruthEnforcement.label(signal));}
 }
 private MaritimeWeatherContext(){}
 public static List<Entry> nearby(Signal vessel,List<Signal> records,double radiusKm){
  ArrayList<Entry> out=new ArrayList<>();if(vessel==null||vessel.layer!=Signal.Layer.SHIPS||!vessel.hasLocation()||records==null)return out;
  for(Signal s:records){if(s==null||!s.hasLocation())continue;
   if(s.layer!=Signal.Layer.WEATHER&&s.layer!=Signal.Layer.NATURAL)continue;
   double d=SatelliteMapView.distanceKm(vessel.latitude,vessel.longitude,s.latitude,s.longitude);if(Double.isNaN(d)||d>radiusKm)continue;
   String kind=fact(s,"WEATHER TYPE","TYPE","EVENT TYPE"),summary=fact(s,"WEATHER SUMMARY","SUMMARY","CONDITION","TITLE");
   String wind=fact(s,"WIND","WIND SPEED","WIND SUMMARY"),waves=fact(s,"WAVES","WAVE HEIGHT","SEA STATE"),warning=fact(s,"MARINE WARNING","WARNING","ALERT");
   if(kind.isEmpty())kind=s.layer.name();if(summary.isEmpty())summary=s.title;
   out.add(new Entry(s,d,kind,summary,wind,waves,warning));
  }
  Collections.sort(out,Comparator.comparingDouble(e->e.distanceKm));return out;
 }
 private static String fact(Signal s,String...ks){for(String k:ks){String v=s.facts.get(k);if(v!=null&&!v.trim().isEmpty())return v.trim();}return "";}
}
