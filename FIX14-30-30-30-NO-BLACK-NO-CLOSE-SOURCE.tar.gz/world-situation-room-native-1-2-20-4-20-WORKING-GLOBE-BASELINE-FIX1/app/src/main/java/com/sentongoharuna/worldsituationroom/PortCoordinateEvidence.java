package com.sentongoharuna.worldsituationroom;
public final class PortCoordinateEvidence{
 public final String portId,sourceId,sourceRecordId,method;public final double latitude,longitude,accuracyM;public final long observedAtMs;
 public PortCoordinateEvidence(String p,String s,String r,double a,double o,double acc,String m,long t){portId=c(p);sourceId=c(s);sourceRecordId=c(r);latitude=a;longitude=o;accuracyM=acc;method=c(m);observedAtMs=t;}
 public boolean valid(){return !portId.isEmpty()&&!sourceId.isEmpty()&&!sourceRecordId.isEmpty()&&!Double.isNaN(latitude)&&!Double.isNaN(longitude)&&latitude>=-90&&latitude<=90&&longitude>=-180&&longitude<=180&&(Double.isNaN(accuracyM)||accuracyM>=0);}
 private static String c(String s){return s==null?"":s.trim();}
}