package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class AisMultiProviderIngestor {
 public static final class ProviderState {
  public long accepted,rejected,duplicates,isolatedSkips,lastReceivedAtMs,lastProviderTimeMs;public String lastError="";
 }
 private final LinkedHashMap<String,AisProviderAdapter> adapters=new LinkedHashMap<>();
 private final LinkedHashMap<String,ProviderState> states=new LinkedHashMap<>();
 private final AisDuplicateFilter duplicateFilter=new AisDuplicateFilter();
 private final AisOrderedObservationStore orderedStore=new AisOrderedObservationStore();
 private final AisProviderPriority providerPriority=new AisProviderPriority();
 private final AisProviderRecovery providerRecovery=new AisProviderRecovery();
 private final LinkedHashMap<String,AisProviderRecovery.Transition> recoveryTransitions=new LinkedHashMap<>();
 private final AisLatencyRegistry latencyRegistry=new AisLatencyRegistry();
 private final AisMessageRateRegistry messageRateRegistry=new AisMessageRateRegistry();
 private final AisQuarantineRegistry quarantineRegistry=new AisQuarantineRegistry();
 private final AisProviderCircuitBreaker circuitBreaker=new AisProviderCircuitBreaker();
 private final AisRawMessageStore rawMessageStore=new AisRawMessageStore();
 private final AisNormalizedEvidenceStore normalizedEvidenceStore=new AisNormalizedEvidenceStore();
 private final LinkedHashMap<String,String> latestRawShaByProvider=new LinkedHashMap<>();
 public synchronized void register(AisProviderAdapter a){
  if(a==null||clean(a.providerId()).isEmpty())throw new IllegalArgumentException("provider id");
  adapters.put(clean(a.providerId()),a);states.putIfAbsent(clean(a.providerId()),new ProviderState());
 }
 public synchronized List<AisProviderRecord> ingest(String providerId,String payload,long receivedAtMs){
  String id=clean(providerId);AisProviderAdapter a=adapters.get(id);if(a==null)throw new IllegalArgumentException("unregistered AIS provider "+id);
  AisRawMessageEvidence rawEvidence=rawMessageStore.preserve(id,payload,receivedAtMs);
  latestRawShaByProvider.put(id,rawEvidence.payloadSha256);
  ProviderState st=states.get(id);ArrayList<AisProviderRecord> out=new ArrayList<>();
  if(!circuitBreaker.allow(id,receivedAtMs)){st.isolatedSkips++;st.lastReceivedAtMs=receivedAtMs;return Collections.unmodifiableList(out);}
  try{
   List<AisProviderRecord> parsed=a.parse(payload,receivedAtMs);
   if(parsed!=null)for(AisProviderRecord r:parsed){
    if(r!=null&&r.valid()&&id.equals(r.providerId)){
     AisDuplicateFilter.Decision duplicate=duplicateFilter.check(r);
     if(duplicate==AisDuplicateFilter.Decision.ACCEPT){out.add(r);st.accepted++;messageRateRegistry.record(id,AisMessageRateRegistry.Kind.ACCEPTED,receivedAtMs);st.lastProviderTimeMs=Math.max(st.lastProviderTimeMs,r.providerTimestampMs);}
     else {st.duplicates++;messageRateRegistry.record(id,AisMessageRateRegistry.Kind.DUPLICATE,receivedAtMs);}
    } else {st.rejected++;messageRateRegistry.record(id,AisMessageRateRegistry.Kind.REJECTED,receivedAtMs);if(r!=null)quarantineRegistry.add(r,"RAW RECORD INVALID OR PROVIDER MISMATCH",receivedAtMs);}
   }
   st.lastError="";circuitBreaker.success(id);
  }catch(Exception e){st.lastError=e.getClass().getSimpleName()+": "+String.valueOf(e.getMessage());circuitBreaker.failure(id,receivedAtMs);}
  st.lastReceivedAtMs=receivedAtMs;return Collections.unmodifiableList(out);
 }
 public synchronized List<NormalizedAisRecord> ingestNormalized(String providerId,String payload,long receivedAtMs){
  List<AisProviderRecord> raw=ingest(providerId,payload,receivedAtMs);ArrayList<NormalizedAisRecord> out=new ArrayList<>();
  ProviderState st=states.get(clean(providerId));
  for(AisProviderRecord r:raw){AisSchemaNormalizer.Result n=AisSchemaNormalizer.normalize(r);if(n.accepted()){out.add(n.record);latencyRegistry.add(AisIngestionLatency.measure(n.record));messageRateRegistry.record(providerId,AisMessageRateRegistry.Kind.NORMALIZED,n.record.processedAtMs);normalizedEvidenceStore.preserve(n.record,latestRawShaByProvider.get(providerId),System.currentTimeMillis());}else if(st!=null){st.rejected++;long now=System.currentTimeMillis();messageRateRegistry.record(providerId,AisMessageRateRegistry.Kind.REJECTED,now);quarantineRegistry.add(r,n.errors.isEmpty()?"NORMALIZATION REJECTED":String.join(" | ",n.errors),now);}}
  return Collections.unmodifiableList(out);
 }
 public synchronized AisOrderedObservationStore.Update routeOrdered(String vesselKey,NormalizedAisRecord record){
  return orderedStore.accept(vesselKey,record);
 }
 public synchronized NormalizedAisRecord liveNormalized(String vesselKey){return orderedStore.live(vesselKey);}
 public synchronized List<NormalizedAisRecord> normalizedHistory(String vesselKey){return orderedStore.history(vesselKey);}
 public synchronized void setProviderPriority(String providerId,int rank){providerPriority.set(providerId,rank);}
 public synchronized Map<String,Integer> providerPriorities(){return providerPriority.snapshot();}
 public synchronized AisProviderSelector.Selection selectProviderCandidate(List<NormalizedAisRecord> candidates){return AisProviderSelector.select(candidates,providerPriority);}
 public synchronized AisFusedVesselRecord fuseVessel(String vesselKey,List<NormalizedAisRecord> candidates){
  return AisCrossProviderFusion.fuse(vesselKey,candidates,providerPriority);
 }
 public synchronized AisProviderRecovery.Transition updateProviderRecovery(String providerId,long providerObservationMs,long lastReceivedMs,long nowMs){
  AisProviderFreshness.Result f=AisProviderFreshness.assess(providerId,providerObservationMs,lastReceivedMs,nowMs);
  AisProviderRecovery.Transition t=providerRecovery.update(f,nowMs);if(t!=null&&t.event!=AisProviderRecovery.Event.NONE)recoveryTransitions.put(providerId,t);return t;
 }
 public synchronized Map<String,AisProviderRecovery.Transition> recoveryTransitions(){return Collections.unmodifiableMap(new LinkedHashMap<>(recoveryTransitions));}
 public synchronized AisLatencyRegistry.Stats latencyStats(String providerId){return latencyRegistry.stats(providerId);}
 public synchronized AisMessageRateRegistry.Rates messageRates(String providerId,long nowMs){return messageRateRegistry.rates(providerId,nowMs);}
 public synchronized AisProviderHealth providerHealth(String providerId,long nowMs){
  ProviderState s=states.get(clean(providerId));
  if(s==null)return AisProviderHealth.assess(providerId,null,null,null,null);
  AisProviderFreshness.Result f=AisProviderFreshness.assess(providerId,s.lastProviderTimeMs,s.lastReceivedAtMs,nowMs);
  AisProviderRecovery.Transition t=recoveryTransitions.get(clean(providerId));
  return AisProviderHealth.assess(providerId,f,latencyRegistry.stats(providerId),messageRateRegistry.rates(providerId,nowMs),t);
 }
 public synchronized int quarantinedCount(){return quarantineRegistry.size();}
 public synchronized List<AisQuarantinedRecord> quarantinedRecords(){return quarantineRegistry.snapshot();}
 public synchronized Map<String,Long> quarantineReasons(){return quarantineRegistry.reasonCounts();}
 public synchronized AisProviderCircuitBreaker.Status providerCircuit(String providerId){return circuitBreaker.status(clean(providerId));}
 public synchronized List<AisRawMessageEvidence> rawMessageEvidence(){return rawMessageStore.snapshot();}
 public synchronized AisRawMessageEvidence rawMessageBySha256(String sha){return rawMessageStore.findBySha256(sha);}
 public synchronized int rawMessageCount(){return rawMessageStore.size();}
 public synchronized long rawMessageBytes(){return rawMessageStore.retainedBytes();}
 public synchronized int normalizedEvidenceCount(){return normalizedEvidenceStore.size();}
 public synchronized List<AisNormalizedEvidence> normalizedEvidence(){return normalizedEvidenceStore.snapshot();}
 public synchronized List<AisNormalizedEvidence> normalizedEvidenceFor(String providerId,String providerRecordId){return normalizedEvidenceStore.byProviderRecord(providerId,providerRecordId);}
 public synchronized AisProvenanceChain provenance(AisFusedVesselRecord fused,String field){
  return AisProvenanceChain.build(fused,field,normalizedEvidenceStore.snapshot(),rawMessageStore.snapshot());
 }
 public synchronized AisDiagnosticsSnapshot diagnostics(long nowMs){
  ArrayList<String> lines=new ArrayList<>();
  for(String id:adapters.keySet()){
   AisProviderHealth h=providerHealth(id,nowMs);AisLatencyRegistry.Stats l=latencyRegistry.stats(id);AisMessageRateRegistry.Rates r=messageRateRegistry.rates(id,nowMs);AisProviderCircuitBreaker.Status c=circuitBreaker.status(id);ProviderState s=states.get(id);
   lines.add(id+" • "+h.state+" • CIRCUIT "+c.state+" • ACCEPT "+String.format(Locale.US,"%.1f/min",r.acceptedPerMin)+" • DUP "+String.format(Locale.US,"%.1f/min",r.duplicatePerMin)+" • REJECT "+String.format(Locale.US,"%.1f/min",r.rejectedPerMin)+" • SRC LAT "+(Double.isNaN(l.avgSourceToReceiveMs)?"UNKNOWN":String.format(Locale.US,"%.0fms",l.avgSourceToReceiveMs))+" • PROC LAT "+(Double.isNaN(l.avgReceiveToProcessMs)?"UNKNOWN":String.format(Locale.US,"%.0fms",l.avgReceiveToProcessMs))+" • ISOLATED "+(s==null?0:s.isolatedSkips));
  }
  return new AisDiagnosticsSnapshot(nowMs,lines,quarantineRegistry.size(),rawMessageStore.size(),normalizedEvidenceStore.size(),rawMessageStore.retainedBytes());
 }
 public synchronized AisProviderHealthSnapshot providerHealthSnapshot(String providerId,long nowMs){
  String id=clean(providerId);ProviderState s=states.get(id);if(s==null)return null;
  AisProviderFreshness.Result f=AisProviderFreshness.assess(id,s.lastProviderTimeMs,s.lastReceivedAtMs,nowMs);
  AisProviderHealth h=providerHealth(id,nowMs);AisProviderCircuitBreaker.Status c=circuitBreaker.status(id);
  AisProviderRecovery.Transition t=recoveryTransitions.get(id);AisMessageRateRegistry.Rates r=messageRateRegistry.rates(id,nowMs);AisLatencyRegistry.Stats l=latencyRegistry.stats(id);
  return new AisProviderHealthSnapshot(id,h.state.name(),f.state.name(),c.state.name(),s.lastError,t==null?"NONE":t.event.name(),
   s.accepted,s.rejected,s.duplicates,s.isolatedSkips,s.lastReceivedAtMs,s.lastProviderTimeMs,r.acceptedPerMin,r.duplicatePerMin,r.rejectedPerMin,r.normalizedPerMin,l.avgSourceToReceiveMs,l.avgReceiveToProcessMs);
 }
 public synchronized List<AisProviderHealthSnapshot> providerHealthSnapshots(long nowMs){
  ArrayList<AisProviderHealthSnapshot> out=new ArrayList<>();for(String id:adapters.keySet()){AisProviderHealthSnapshot x=providerHealthSnapshot(id,nowMs);if(x!=null)out.add(x);}return Collections.unmodifiableList(out);
 }
 public synchronized ProviderState state(String id){return states.get(clean(id));}
 public synchronized int providerCount(){return adapters.size();}
 public synchronized Set<String> providerIds(){return Collections.unmodifiableSet(new LinkedHashSet<>(adapters.keySet()));}
 public synchronized Map<String,String> healthSummary(){
  LinkedHashMap<String,String> out=new LinkedHashMap<>();
  for(Map.Entry<String,ProviderState> e:states.entrySet()){ProviderState s=e.getValue();out.put(e.getKey(), "accepted="+s.accepted+" rejected="+s.rejected+" duplicates="+s.duplicates+(s.lastError.isEmpty()?"":" error="+s.lastError));}
  return Collections.unmodifiableMap(out);
 }
 private static String clean(String s){return s==null?"":s.trim();}
}
