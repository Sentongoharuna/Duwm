package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class PortApproachRegistry {
 public enum Decision { ADDED, UPDATED, DUPLICATE, REJECTED, CONFLICT }
 public static final class Result {public final Decision decision;public final String reason;Result(Decision d,String r){decision=d;reason=r;}}
 private final LinkedHashMap<String,PortApproachRecord> byId=new LinkedHashMap<>();private final LinkedHashMap<String,String> sourceBinding=new LinkedHashMap<>();
 public synchronized Result upsert(PortRecord port,PortApproachRecord a){
  if(port==null||a==null||!a.valid()||!port.portId.equals(a.portId))return new Result(Decision.REJECTED,"INVALID APPROACH OR PARENT PORT");
  String sk=a.sourceId+"|"+a.sourceRecordId,prior=sourceBinding.get(sk);if(prior!=null&&!prior.equals(a.approachId))return new Result(Decision.CONFLICT,"SOURCE RECORD ALREADY BOUND TO "+prior);
  PortApproachRecord old=byId.get(a.approachId);if(old!=null&&!old.portId.equals(a.portId))return new Result(Decision.CONFLICT,"APPROACH PARENT PORT CHANGED");
  if(old!=null&&same(old,a)){sourceBinding.put(sk,a.approachId);return new Result(Decision.DUPLICATE,"UNCHANGED");}
  byId.put(a.approachId,a);sourceBinding.put(sk,a.approachId);return new Result(old==null?Decision.ADDED:Decision.UPDATED,old==null?"ADDED":"UPDATED");
 }
 public synchronized PortApproachRecord get(String id){return byId.get(id==null?"":id.trim());}
 public synchronized List<PortApproachRecord> forPort(String p){ArrayList<PortApproachRecord>o=new ArrayList<>();for(PortApproachRecord a:byId.values())if(a.portId.equals(p))o.add(a);return Collections.unmodifiableList(o);}
 public synchronized List<PortApproachRecord> search(String q){String x=q==null?"":q.trim().toLowerCase(Locale.US);ArrayList<PortApproachRecord>o=new ArrayList<>();for(PortApproachRecord a:byId.values())if(x.isEmpty()||a.name.toLowerCase(Locale.US).contains(x)||a.approachId.toLowerCase(Locale.US).contains(x)||a.approachType.toLowerCase(Locale.US).contains(x))o.add(a);return Collections.unmodifiableList(o);}
 public synchronized int size(){return byId.size();}
 private static boolean same(PortApproachRecord a,PortApproachRecord b){if(!a.portId.equals(b.portId)||!a.name.equals(b.name)||!a.approachType.equals(b.approachType)||Double.compare(a.corridorWidthM,b.corridorWidthM)!=0||a.centerline.size()!=b.centerline.size()||a.observedAtMs!=b.observedAtMs)return false;for(int i=0;i<a.centerline.size();i++){HarbourBoundaryEvidence.Point x=a.centerline.get(i),y=b.centerline.get(i);if(Double.compare(x.latitude,y.latitude)!=0||Double.compare(x.longitude,y.longitude)!=0)return false;}return true;}
}
