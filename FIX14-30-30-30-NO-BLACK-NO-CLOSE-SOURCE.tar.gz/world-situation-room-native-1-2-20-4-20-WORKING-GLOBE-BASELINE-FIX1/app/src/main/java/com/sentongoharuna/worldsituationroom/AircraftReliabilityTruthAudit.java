package com.sentongoharuna.worldsituationroom;
import java.util.ArrayList;import java.util.List;
public final class AircraftReliabilityTruthAudit {
 private AircraftReliabilityTruthAudit(){}
 public static List<String> inspect(Signal s){
  ArrayList<String> issues=new ArrayList<>();
  if(s==null||s.layer!=Signal.Layer.FLIGHTS)return issues;
  AircraftCanonicalIdentity.Identity id=AircraftCanonicalIdentity.from(s);
  AircraftTelemetry t=AircraftTelemetry.from(s);
  if(s.providerId==null||s.providerId.trim().isEmpty())issues.add("MISSING PROVIDER ID");
  if(s.originalRecord==null)issues.add("MISSING ORIGINAL RECORD");
  if(s.timestampChain==null)issues.add("MISSING TIMESTAMP CHAIN");
  if(id.key.isEmpty())issues.add("WEAK/UNKNOWN AIRCRAFT IDENTITY");
  if(t==null)issues.add("MISSING NORMALIZED TELEMETRY");
  if(!s.hasLocation())issues.add("MISSING OBSERVED POSITION");
  if(s.freshness==null)issues.add("MISSING FRESHNESS");
  if(TruthEnforcement.classify(s)==null)issues.add("MISSING TRUTH CLASSIFICATION");
  return issues;
 }
 public static String summary(Signal s){
  List<String> issues=inspect(s);
  if(issues.isEmpty())return "AIRCRAFT TRUTH CHAIN OK";
  StringBuilder b=new StringBuilder("AIRCRAFT AUDIT • ");
  for(int i=0;i<issues.size();i++){if(i>0)b.append(" • ");b.append(issues.get(i));}
  return b.toString();
 }
}
