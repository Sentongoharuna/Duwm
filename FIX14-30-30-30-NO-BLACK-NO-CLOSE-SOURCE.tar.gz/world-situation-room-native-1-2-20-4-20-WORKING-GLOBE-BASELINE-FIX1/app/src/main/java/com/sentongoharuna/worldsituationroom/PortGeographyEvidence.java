package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Source-backed country/region metadata. No country/region is inferred from coordinates. */
public final class PortGeographyEvidence {
 public final String portId,countryCode,countryName,regionCode,regionName,sourceId,sourceRecordId;
 public final long observedAtMs;
 public PortGeographyEvidence(String p,String cc,String cn,String rc,String rn,String s,String sr,long t){
  portId=c(p);countryCode=c(cc).toUpperCase(Locale.US);countryName=c(cn);regionCode=c(rc).toUpperCase(Locale.US);regionName=c(rn);sourceId=c(s);sourceRecordId=c(sr);observedAtMs=t;
 }
 public boolean valid(){return !portId.isEmpty()&&countryCode.matches("[A-Z]{2}")&&!sourceId.isEmpty()&&!sourceRecordId.isEmpty();}
 private static String c(String s){return s==null?"":s.trim();}
}
