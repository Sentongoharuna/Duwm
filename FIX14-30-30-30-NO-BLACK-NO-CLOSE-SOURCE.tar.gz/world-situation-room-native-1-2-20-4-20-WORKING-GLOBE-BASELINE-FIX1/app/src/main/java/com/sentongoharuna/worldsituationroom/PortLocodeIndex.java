package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** One-to-one canonical UN/LOCODE index for registered ports. */
public final class PortLocodeIndex {
 public enum Decision { INDEXED, SAME_PORT, REJECTED, CONFLICT }
 public static final class Result {public final Decision decision;public final UnLocodeIdentity identity;public final String reason;Result(Decision d,UnLocodeIdentity i,String r){decision=d;identity=i;reason=r;}}
 private final LinkedHashMap<String,String> locodeToPort=new LinkedHashMap<>(),portToLocode=new LinkedHashMap<>();
 public synchronized Result bind(PortRecord port,String raw){
  if(port==null||!port.validIdentity())return new Result(Decision.REJECTED,UnLocodeIdentity.validate(raw,""),"INVALID PORT");
  UnLocodeIdentity id=UnLocodeIdentity.validate(raw,port.countryCode);
  if(!id.accepted())return new Result(Decision.REJECTED,id,id.state.name());
  String existingPort=locodeToPort.get(id.compact),existingCode=portToLocode.get(port.portId);
  if(existingPort!=null&&!existingPort.equals(port.portId))return new Result(Decision.CONFLICT,id,"LOCODE ALREADY BOUND TO "+existingPort);
  if(existingCode!=null&&!existingCode.equals(id.compact))return new Result(Decision.CONFLICT,id,"PORT ALREADY BOUND TO "+existingCode);
  if(port.portId.equals(existingPort))return new Result(Decision.SAME_PORT,id,"UNCHANGED");
  locodeToPort.put(id.compact,port.portId);portToLocode.put(port.portId,id.compact);return new Result(Decision.INDEXED,id,"INDEXED");
 }
 public synchronized String portId(String raw){UnLocodeIdentity id=UnLocodeIdentity.validate(raw,"");return id.accepted()?value(locodeToPort.get(id.compact)):"";}
 public synchronized String locode(String portId){return value(portToLocode.get(portId==null?"":portId.trim()));}
 public synchronized int size(){return locodeToPort.size();}
 private static String value(String s){return s==null?"":s;}
}
