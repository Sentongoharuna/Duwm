package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class PortWeatherContextRegistry {
 public enum Decision { ADDED, UPDATED, DUPLICATE, REJECTED, CONFLICT }
 public static final class Result {public final Decision decision;public final String reason;Result(Decision d,String r){decision=d;reason=r;}}
 private final LinkedHashMap<String,PortWeatherContextRecord> byId=new LinkedHashMap<>();private final LinkedHashMap<String,String> sourceBinding=new LinkedHashMap<>();
 public synchronized Result upsert(PortRecord p,PortWeatherContextRecord w){
  if(p==null||w==null||!w.valid()||!p.portId.equals(w.portId))return new Result(Decision.REJECTED,"INVALID WEATHER OR PARENT PORT");
  String sk=w.sourceId+"|"+w.sourceRecordId,prior=sourceBinding.get(sk);if(prior!=null&&!prior.equals(w.weatherId))return new Result(Decision.CONFLICT,"SOURCE RECORD ALREADY BOUND TO "+prior);
  PortWeatherContextRecord old=byId.get(w.weatherId);if(old!=null&&(!old.portId.equals(w.portId)||old.kind!=w.kind))return new Result(Decision.CONFLICT,"WEATHER ID PORT/KIND CHANGED");
  if(old!=null&&same(old,w)){sourceBinding.put(sk,w.weatherId);return new Result(Decision.DUPLICATE,"UNCHANGED");}
  byId.put(w.weatherId,w);sourceBinding.put(sk,w.weatherId);return new Result(old==null?Decision.ADDED:Decision.UPDATED,old==null?"ADDED":"UPDATED");
 }
 public synchronized PortWeatherContextRecord get(String id){return byId.get(id==null?"":id.trim());}
 public synchronized List<PortWeatherContextRecord> forPort(String p,PortWeatherContextRecord.Kind kind){ArrayList<PortWeatherContextRecord>o=new ArrayList<>();for(PortWeatherContextRecord w:byId.values())if(w.portId.equals(p)&&(kind==null||w.kind==kind))o.add(w);return Collections.unmodifiableList(o);}
 public synchronized PortWeatherContextRecord latest(String p,PortWeatherContextRecord.Kind kind){PortWeatherContextRecord best=null;for(PortWeatherContextRecord w:forPort(p,kind))if(best==null||w.validAtMs>best.validAtMs)best=w;return best;}
 public synchronized int size(){return byId.size();}
 private static boolean same(PortWeatherContextRecord a,PortWeatherContextRecord b){return a.portId.equals(b.portId)&&a.stationId.equals(b.stationId)&&a.kind==b.kind&&Double.compare(a.temperatureC,b.temperatureC)==0&&Double.compare(a.pressureHpa,b.pressureHpa)==0&&Double.compare(a.humidityPct,b.humidityPct)==0&&Double.compare(a.windSpeedMps,b.windSpeedMps)==0&&Double.compare(a.windDirectionDeg,b.windDirectionDeg)==0&&Double.compare(a.gustMps,b.gustMps)==0&&Double.compare(a.visibilityM,b.visibilityM)==0&&Double.compare(a.precipitationMm,b.precipitationMm)==0&&a.validAtMs==b.validAtMs&&a.issuedAtMs==b.issuedAtMs&&a.receivedAtMs==b.receivedAtMs;}
}
