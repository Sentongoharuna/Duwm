package com.sentongoharuna.worldsituationroom;
public final class PortRegistryValidation{private PortRegistryValidation(){}
 public static boolean coordinate(double lat,double lon){return !Double.isNaN(lat)&&!Double.isNaN(lon)&&lat>=-90&&lat<=90&&lon>=-180&&lon<=180;}
 public static boolean identity(String id,String name,String source,String record){return text(id)&&text(name)&&text(source)&&text(record);}
 private static boolean text(String x){return x!=null&&!x.trim().isEmpty();}
}
