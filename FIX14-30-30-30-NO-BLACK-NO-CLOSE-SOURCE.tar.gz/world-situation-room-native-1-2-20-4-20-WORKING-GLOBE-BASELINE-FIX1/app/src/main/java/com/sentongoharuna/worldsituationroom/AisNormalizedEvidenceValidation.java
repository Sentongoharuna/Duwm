package com.sentongoharuna.worldsituationroom;
public final class AisNormalizedEvidenceValidation{private AisNormalizedEvidenceValidation(){}
 public static boolean traceable(String provider,String record,String sha){return provider!=null&&!provider.isEmpty()&&record!=null&&!record.isEmpty()&&sha!=null&&sha.matches("[0-9a-fA-F]{64}");}
 public static int bounded(int existing,int added,int max){return Math.min(max,Math.max(0,existing)+Math.max(0,added));}
}