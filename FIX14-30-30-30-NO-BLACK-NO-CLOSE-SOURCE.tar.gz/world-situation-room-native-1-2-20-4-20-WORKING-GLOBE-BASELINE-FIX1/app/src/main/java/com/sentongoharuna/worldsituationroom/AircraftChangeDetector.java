package com.sentongoharuna.worldsituationroom;
import java.util.ArrayList;import java.util.List;
public final class AircraftChangeDetector {
 public enum Change { NEWLY_OBSERVED, ALTITUDE_BAND, CLIMB_TO_LEVEL, LEVEL_TO_DESCENT,
  DESCENT_TO_LEVEL, LEVEL_TO_CLIMB, MAJOR_HEADING_CHANGE, GROUND_TO_AIRBORNE,
  AIRBORNE_TO_GROUND, PROVIDER_LOST, PROVIDER_RECOVERED }
 public static final class Snapshot {
  final boolean seen;final int altitudeBand;final AircraftVerticalMovement.State vertical;
  final double direction;final Boolean onGround;final TruthEnforcement.Claim truth;
  Snapshot(boolean s,int a,AircraftVerticalMovement.State v,double d,Boolean g,TruthEnforcement.Claim t){
   seen=s;altitudeBand=a;vertical=v;direction=d;onGround=g;truth=t;}
 }
 private AircraftChangeDetector(){}
 public static Snapshot snapshot(Signal s){
  AircraftTelemetry t=AircraftTelemetry.from(s);AircraftAltitudeIntelligence a=AircraftAltitudeIntelligence.from(s);
  AircraftOrientation o=AircraftOrientation.from(s);
  int band=Double.isNaN(a.preferredM)?Integer.MIN_VALUE:(int)Math.floor(a.preferredM/3000d);
  AircraftVerticalMovement.State v=AircraftVerticalMovement.from(s,null,null).state;
  return new Snapshot(true,band,v,o.known()?o.degrees:Double.NaN,t==null?null:t.onGround,TruthEnforcement.classify(s));
 }
 public static List<Change> compare(Snapshot old,Snapshot now){
  ArrayList<Change> out=new ArrayList<>();if(now==null)return out;
  if(old==null||!old.seen){out.add(Change.NEWLY_OBSERVED);return out;}
  if(old.altitudeBand!=Integer.MIN_VALUE&&now.altitudeBand!=Integer.MIN_VALUE&&old.altitudeBand!=now.altitudeBand)out.add(Change.ALTITUDE_BAND);
  if(old.vertical==AircraftVerticalMovement.State.CLIMBING&&now.vertical==AircraftVerticalMovement.State.LEVEL)out.add(Change.CLIMB_TO_LEVEL);
  if(old.vertical==AircraftVerticalMovement.State.LEVEL&&now.vertical==AircraftVerticalMovement.State.DESCENDING)out.add(Change.LEVEL_TO_DESCENT);
  if(old.vertical==AircraftVerticalMovement.State.DESCENDING&&now.vertical==AircraftVerticalMovement.State.LEVEL)out.add(Change.DESCENT_TO_LEVEL);
  if(old.vertical==AircraftVerticalMovement.State.LEVEL&&now.vertical==AircraftVerticalMovement.State.CLIMBING)out.add(Change.LEVEL_TO_CLIMB);
  if(!Double.isNaN(old.direction)&&!Double.isNaN(now.direction)){
   double delta=Math.abs(((now.direction-old.direction+540d)%360d)-180d);
   if(delta>=30d)out.add(Change.MAJOR_HEADING_CHANGE);
  }
  if(Boolean.TRUE.equals(old.onGround)&&Boolean.FALSE.equals(now.onGround))out.add(Change.GROUND_TO_AIRBORNE);
  if(Boolean.FALSE.equals(old.onGround)&&Boolean.TRUE.equals(now.onGround))out.add(Change.AIRBORNE_TO_GROUND);
  boolean oldLost=old.truth==TruthEnforcement.Claim.STALE||old.truth==TruthEnforcement.Claim.UNKNOWN;
  boolean nowLost=now.truth==TruthEnforcement.Claim.STALE||now.truth==TruthEnforcement.Claim.UNKNOWN;
  if(!oldLost&&nowLost)out.add(Change.PROVIDER_LOST);
  if(oldLost&&!nowLost)out.add(Change.PROVIDER_RECOVERED);
  return out;
 }
}
