package com.sentongoharuna.worldsituationroom;
/** FIX11.30/30.14 calculated flight phase. This is interpretation, never provider fact. */
public final class AircraftFlightPhase {
 public enum Phase { GROUND, CLIMB, CRUISE_LIKE, DESCENT, AIRBORNE_UNCLASSIFIED, UNKNOWN }
 public final Phase phase;
 public final String basis;
 public final boolean calculated;
 private AircraftFlightPhase(Phase p,String b){phase=p;basis=b;calculated=true;}

 public static AircraftFlightPhase from(Signal s){
  AircraftTelemetry t=AircraftTelemetry.from(s);
  if(t==null)return new AircraftFlightPhase(Phase.UNKNOWN,"NO AIRCRAFT TELEMETRY");
  AircraftAltitudeIntelligence a=AircraftAltitudeIntelligence.from(s);
  AircraftVerticalMovement v=AircraftVerticalMovement.from(s,null,null);

  if(Boolean.TRUE.equals(t.onGround))
   return new AircraftFlightPhase(Phase.GROUND,"PROVIDER ON_GROUND=TRUE");

  if(v.state==AircraftVerticalMovement.State.CLIMBING)
   return new AircraftFlightPhase(Phase.CLIMB,"VERTICAL MOVEMENT CLIMBING");
  if(v.state==AircraftVerticalMovement.State.DESCENDING)
   return new AircraftFlightPhase(Phase.DESCENT,"VERTICAL MOVEMENT DESCENDING");

  if(Boolean.FALSE.equals(t.onGround) && v.state==AircraftVerticalMovement.State.LEVEL) {
   if(!Double.isNaN(a.preferredM) && a.preferredM>=6000d)
    return new AircraftFlightPhase(Phase.CRUISE_LIKE,
      "ON_GROUND=FALSE + LEVEL + ALTITUDE >= 6000m");
   return new AircraftFlightPhase(Phase.AIRBORNE_UNCLASSIFIED,
      "ON_GROUND=FALSE + LEVEL; insufficient basis for cruise-like");
  }

  if(Boolean.FALSE.equals(t.onGround))
   return new AircraftFlightPhase(Phase.AIRBORNE_UNCLASSIFIED,"PROVIDER ON_GROUND=FALSE");
  return new AircraftFlightPhase(Phase.UNKNOWN,"INSUFFICIENT TELEMETRY");
 }

 public String disclosure(){
  return phase.name().replace('_',' ')+" • CALCULATED • "+basis;
 }
}
