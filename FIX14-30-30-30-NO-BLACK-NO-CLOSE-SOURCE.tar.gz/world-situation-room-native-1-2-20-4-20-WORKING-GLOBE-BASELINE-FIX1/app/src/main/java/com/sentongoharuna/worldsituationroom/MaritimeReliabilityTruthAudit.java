package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** FIX12.30/30.29: verifies maritime evidence-class separation and runtime source integrity. */
public final class MaritimeReliabilityTruthAudit {
 public static final class Result {
  public final boolean pass; public final List<String> checks,failures;
  Result(boolean p,List<String> c,List<String> f){pass=p;checks=Collections.unmodifiableList(c);failures=Collections.unmodifiableList(f);}
  public String summary(){return pass?"MARITIME TRUTH AUDIT • PASS • "+checks.size()+" CHECKS":"MARITIME TRUTH AUDIT • FAIL • "+failures.size()+" FAILURES";}
 }
 private MaritimeReliabilityTruthAudit(){}
 public static Result audit(Signal s){
  ArrayList<String> c=new ArrayList<>(),f=new ArrayList<>();
  if(s==null||s.layer!=Signal.Layer.SHIPS){f.add("NOT A VESSEL SIGNAL");return new Result(false,c,f);}
  check(c,f,"CANONICAL ID",s.canonicalId!=null&&!s.canonicalId.isEmpty());
  check(c,f,"ORIGINAL RECORD",s.originalRecord!=null);
  check(c,f,"TIMESTAMP CHAIN",s.timestampChain!=null);
  check(c,f,"COORDINATE PROVENANCE",s.coordinateProvenance!=null);
  VesselCanonicalIdentity.Identity id=VesselCanonicalIdentity.from(s);
  check(c,f,"VESSEL IDENTITY",!id.key.isEmpty());
  VesselTelemetry t=VesselTelemetry.from(s);check(c,f,"VESSEL TELEMETRY",t!=null);
  if(t!=null&&t.hasSog())check(c,f,"SOG NONNEGATIVE",t.sogMps>=0d);
  if(t!=null&&t.hasCog())check(c,f,"COG NORMALIZED",VesselTelemetry.normalize(t.cogDegrees)>=0d&&VesselTelemetry.normalize(t.cogDegrees)<360d);
  check(c,f,"OBSERVED TRAIL DISCLOSURE","OBSERVED AIS FIXES ONLY".equals(s.facts.get("VESSEL TRAIL EVIDENCE")));
  String movement=s.facts.get("VESSEL MOVEMENT ENGINE");
  check(c,f,"DISPLAY MOVEMENT DISCLOSURE",movement!=null&&movement.contains("OBSERVATIONS IMMUTABLE"));
  String nav=s.facts.get("AIS NAV STATUS DISCLOSURE");
  check(c,f,"NAV STATUS EVIDENCE",nav==null||nav.contains("PROVIDER-REPORTED")||nav.contains("UNKNOWN"));
  String dest=s.facts.get("AIS DESTINATION DISCLOSURE");
  check(c,f,"DESTINATION EVIDENCE",dest==null||dest.contains("AIS REPORTED DESTINATION"));
  String port=s.facts.get("PORT PROXIMITY DISCLOSURE");
  check(c,f,"PORT PROXIMITY EVIDENCE",port==null||port.contains("PROXIMITY ONLY"));
  check(c,f,"NO PREDICTION AS OBSERVATION",!"PREDICTED".equals(s.facts.get("VESSEL TRAIL EVIDENCE")));
  return new Result(f.isEmpty(),c,f);
 }
 private static void check(List<String> c,List<String> f,String name,boolean ok){if(ok)c.add(name);else f.add(name);}
}
