package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Provider-scoped duplicate suppression. Duplicate messages never become additional observations. */
public final class AisDuplicateFilter {
 public enum Decision { ACCEPT, DUPLICATE_RECORD_ID, DUPLICATE_CONTENT }
 private static final int MAX_KEYS=50000;
 private final LinkedHashMap<String,Long> seen=new LinkedHashMap<>();
 public synchronized Decision check(AisProviderRecord r){
  if(r==null)return Decision.DUPLICATE_CONTENT;
  String provider=r.providerId==null?"":r.providerId;
  String rid=r.providerRecordId==null?"":r.providerRecordId;
  String recordKey="RID|"+provider+"|"+rid;
  if(!rid.isEmpty()&&seen.containsKey(recordKey))return Decision.DUPLICATE_RECORD_ID;
  String contentKey="CONTENT|"+provider+"|"+fingerprint(r);
  if(seen.containsKey(contentKey))return Decision.DUPLICATE_CONTENT;
  long now=r.receivedAtMs>0?r.receivedAtMs:System.currentTimeMillis();
  if(!rid.isEmpty())seen.put(recordKey,now);seen.put(contentKey,now);trim();return Decision.ACCEPT;
 }
 public synchronized int retainedKeys(){return seen.size();}
 private void trim(){while(seen.size()>MAX_KEYS){Iterator<String>i=seen.keySet().iterator();if(!i.hasNext())break;i.next();i.remove();}}
 private static String fingerprint(AisProviderRecord r){
  StringBuilder b=new StringBuilder().append(r.providerTimestampMs);
  ArrayList<String> keys=new ArrayList<>(r.fields.keySet());Collections.sort(keys);
  for(String k:keys){if(k==null||k.startsWith("volatile."))continue;b.append('|').append(k).append('=').append(r.fields.get(k));}
  return sha256(b.toString());
 }
 private static String sha256(String x){
  try{java.security.MessageDigest d=java.security.MessageDigest.getInstance("SHA-256");byte[]h=d.digest(x.getBytes(java.nio.charset.StandardCharsets.UTF_8));StringBuilder b=new StringBuilder();for(byte v:h)b.append(String.format("%02x",v));return b.toString();}
  catch(Exception e){throw new IllegalStateException(e);}
 }
}
