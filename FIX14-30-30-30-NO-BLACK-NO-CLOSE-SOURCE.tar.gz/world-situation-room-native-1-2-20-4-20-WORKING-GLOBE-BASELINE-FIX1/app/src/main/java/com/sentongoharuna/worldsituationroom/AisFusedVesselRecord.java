package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Provider-neutral fused vessel state with per-field provenance. */
public final class AisFusedVesselRecord {
 public final String vesselKey; public final NormalizedAisRecord primary;
 public final Map<String,String> values,fieldProviders; public final List<NormalizedAisRecord> evidence; public final AisPositionConflict.Result positionConflict; public final AisSpeedConflict.Result speedConflict; public final AisHeadingConflict.Result headingConflict; public AisSourceConfidence confidence; public AisFusedFreshness freshness;
 AisFusedVesselRecord(String k,NormalizedAisRecord p,Map<String,String>v,Map<String,String>fp,List<NormalizedAisRecord>e,AisPositionConflict.Result pc,AisSpeedConflict.Result sc,AisHeadingConflict.Result hc){
  vesselKey=k;primary=p;values=Collections.unmodifiableMap(new LinkedHashMap<>(v));fieldProviders=Collections.unmodifiableMap(new LinkedHashMap<>(fp));evidence=Collections.unmodifiableList(new ArrayList<>(e));positionConflict=pc;speedConflict=sc;headingConflict=hc;
 }
 public String providerFor(String field){String p=fieldProviders.get(field);return p==null?"":p;}
}
