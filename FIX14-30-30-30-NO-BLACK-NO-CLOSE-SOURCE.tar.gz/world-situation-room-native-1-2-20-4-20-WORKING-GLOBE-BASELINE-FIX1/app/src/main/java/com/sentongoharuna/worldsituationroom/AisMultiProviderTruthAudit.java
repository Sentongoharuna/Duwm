package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** FIX13.29 multi-provider evidence/truth integrity audit. */
public final class AisMultiProviderTruthAudit {
 public static final class Result {
  public final boolean pass;public final List<String> checks,failures;
  Result(boolean p,List<String>c,List<String>f){pass=p;checks=Collections.unmodifiableList(c);failures=Collections.unmodifiableList(f);}
  public String summary(){return pass?"FIX13 AIS TRUTH AUDIT • PASS • "+checks.size()+" CHECKS":"FIX13 AIS TRUTH AUDIT • FAIL • "+failures.size()+" FAILURES";}
 }
 private AisMultiProviderTruthAudit(){}
 public static Result audit(AisFusedVesselRecord fused,AisProvenanceChain provenance){
  ArrayList<String> c=new ArrayList<>(),f=new ArrayList<>();
  check(c,f,"FUSED RECORD",fused!=null);if(fused==null)return new Result(false,c,f);
  check(c,f,"PRIMARY PROVIDER RECORD",fused.primary!=null);
  check(c,f,"PROVIDER EVIDENCE RETAINED",fused.evidence!=null&&!fused.evidence.isEmpty());
  check(c,f,"FIELD PROVIDER MAP",fused.fieldProviders!=null);
  check(c,f,"POSITION NOT AVERAGED",fused.positionConflict!=null);
  check(c,f,"SPEED NOT AVERAGED",fused.speedConflict!=null);
  check(c,f,"HEADING CIRCULAR CONFLICT",fused.headingConflict!=null);
  check(c,f,"EVIDENCE QUALITY NOT CERTAINTY",fused.confidence!=null&&fused.confidence.disclosure().contains("NOT CERTAINTY"));
  check(c,f,"PER-PROVIDER FRESHNESS",fused.freshness!=null);
  if(provenance!=null)check(c,f,"PROVENANCE HONEST",provenance.complete?provenance.links.size()==4:provenance.links.size()<4||provenance.value.isEmpty()||provenance.field.isEmpty());
  for(NormalizedAisRecord r:fused.evidence){
   if(r==null){f.add("NULL EVIDENCE RECORD");continue;}
   check(c,f,"NORMALIZED PROVIDER ID",r.providerId!=null&&!r.providerId.isEmpty());
   check(c,f,"PROVIDER TIME PRESERVED",r.providerTimestampMs>0L);
   check(c,f,"RECEIVE TIME PRESERVED",r.receivedAtMs>0L);
   check(c,f,"PROCESS TIME PRESERVED",r.processedAtMs>0L);
  }
  return new Result(f.isEmpty(),c,f);
 }
 private static void check(List<String>c,List<String>f,String n,boolean ok){if(ok)c.add(n);else f.add(n);}
}
