package com.sentongoharuna.worldsituationroom;
public final class PortOverviewCameraValidation{private PortOverviewCameraValidation(){}
 public static boolean target(double lat,double lon,double altitude,double pitch){return !Double.isNaN(lat)&&!Double.isNaN(lon)&&lat>=-90&&lat<=90&&lon>=-180&&lon<=180&&altitude>0&&pitch>=0&&pitch<=90;}
 public static boolean mutatesPortData(){return false;}
}