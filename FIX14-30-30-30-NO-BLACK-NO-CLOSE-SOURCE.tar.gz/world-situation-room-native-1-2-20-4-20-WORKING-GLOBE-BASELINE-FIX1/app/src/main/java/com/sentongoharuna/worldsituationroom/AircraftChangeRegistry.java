package com.sentongoharuna.worldsituationroom;
import java.util.LinkedHashMap;import java.util.List;import java.util.Map;
public final class AircraftChangeRegistry {
 private final Map<String,AircraftChangeDetector.Snapshot> previous=new LinkedHashMap<>();
 public synchronized List<AircraftChangeDetector.Change> observe(Signal s){
  AircraftCanonicalIdentity.Identity id=AircraftCanonicalIdentity.from(s);
  String key=!id.key.isEmpty()?id.key:s.canonicalId;
  AircraftChangeDetector.Snapshot now=AircraftChangeDetector.snapshot(s),old=previous.put(key,now);
  while(previous.size()>5000){String k=previous.keySet().iterator().next();previous.remove(k);}
  return AircraftChangeDetector.compare(old,now);
 }
}
