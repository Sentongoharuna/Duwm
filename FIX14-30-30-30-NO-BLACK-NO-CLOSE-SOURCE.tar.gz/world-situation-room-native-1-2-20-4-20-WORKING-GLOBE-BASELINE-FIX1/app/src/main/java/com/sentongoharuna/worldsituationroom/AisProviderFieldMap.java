package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class AisProviderFieldMap {
 private final LinkedHashMap<String,String> canonicalToProvider=new LinkedHashMap<>();
 public AisProviderFieldMap map(String canonical,String providerField){
  String c=clean(canonical),p=clean(providerField);if(c.isEmpty()||p.isEmpty())throw new IllegalArgumentException("field mapping");
  canonicalToProvider.put(c,p);return this;
 }
 public String providerField(String canonical){String v=canonicalToProvider.get(clean(canonical));return v==null?"":v;}
 public Map<String,String> extract(Map<String,String> raw){
  LinkedHashMap<String,String> out=new LinkedHashMap<>();if(raw==null)return out;
  for(Map.Entry<String,String> e:canonicalToProvider.entrySet()){String v=raw.get(e.getValue());if(v!=null&&!v.trim().isEmpty())out.put(e.getKey(),v.trim());}
  return out;
 }
 public int size(){return canonicalToProvider.size();}
 private static String clean(String s){return s==null?"":s.trim();}
}
