package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Compares two observed AIS fixes against a canonical port point. No ETA/arrival inference. */
public final class PortApproachingVesselEngine {
 private static final double STABLE_KM=0.10;
 private PortApproachingVesselEngine(){}
 public static PortApproachTrend trend(PortRecord port,String vesselKey,NormalizedAisRecord previous,NormalizedAisRecord current){
  if(port==null||previous==null||current==null||current.providerTimestampMs<=previous.providerTimestampMs||Double.isNaN(previous.latitude)||Double.isNaN(previous.longitude)||Double.isNaN(current.latitude)||Double.isNaN(current.longitude))
   return new PortApproachTrend(port==null?"":port.portId,vesselKey,PortApproachTrend.State.INSUFFICIENT,Double.NaN,Double.NaN,Double.NaN,Double.NaN,previous==null?0:previous.providerTimestampMs,current==null?0:current.providerTimestampMs);
  double a=PortCoordinateRegistry.distanceKm(port.latitude,port.longitude,previous.latitude,previous.longitude),b=PortCoordinateRegistry.distanceKm(port.latitude,port.longitude,current.latitude,current.longitude),d=b-a,h=(current.providerTimestampMs-previous.providerTimestampMs)/3600000d,rate=h>0?d/h:Double.NaN;
  PortApproachTrend.State s=Math.abs(d)<=STABLE_KM?PortApproachTrend.State.STABLE:d<0?PortApproachTrend.State.APPROACHING:PortApproachTrend.State.RECEDING;
  return new PortApproachTrend(port.portId,vesselKey,s,a,b,d,rate,previous.providerTimestampMs,current.providerTimestampMs);
 }
 public static List<PortApproachTrend> approaching(PortRecord port,Map<String,List<NormalizedAisRecord>> histories){
  if(port==null||histories==null)return Collections.emptyList();ArrayList<PortApproachTrend> out=new ArrayList<>();
  for(Map.Entry<String,List<NormalizedAisRecord>> e:histories.entrySet()){List<NormalizedAisRecord> h=e.getValue();if(h==null||h.size()<2)continue;PortApproachTrend t=trend(port,e.getKey(),h.get(h.size()-2),h.get(h.size()-1));if(t.state==PortApproachTrend.State.APPROACHING)out.add(t);}
  out.sort(Comparator.comparingDouble(x->x.currentDistanceKm));return Collections.unmodifiableList(out);
 }
}
