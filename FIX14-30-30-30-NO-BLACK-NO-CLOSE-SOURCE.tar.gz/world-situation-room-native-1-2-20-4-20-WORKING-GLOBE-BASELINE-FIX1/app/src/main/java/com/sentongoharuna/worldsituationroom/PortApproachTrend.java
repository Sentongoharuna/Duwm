package com.sentongoharuna.worldsituationroom;
/** Observed distance trend only. APPROACHING is evidence of decreasing distance, not an arrival prediction. */
public final class PortApproachTrend {
 public enum State { APPROACHING, RECEDING, STABLE, INSUFFICIENT }
 public final String portId,vesselKey;public final State state;public final double previousDistanceKm,currentDistanceKm,deltaKm,radialRateKph;public final long previousAtMs,currentAtMs;
 PortApproachTrend(String p,String v,State s,double a,double b,double d,double rate,long t1,long t2){portId=p;vesselKey=v;state=s;previousDistanceKm=a;currentDistanceKm=b;deltaKm=d;radialRateKph=rate;previousAtMs=t1;currentAtMs=t2;}
 public String disclosure(){return state+" • observed distance trend • not arrival prediction";}
}
