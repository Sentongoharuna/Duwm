package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Bounded immutable post-normalization/pre-fusion evidence store. */
public final class AisNormalizedEvidenceStore {
 private static final int MAX=5000;
 private final ArrayDeque<AisNormalizedEvidence> q=new ArrayDeque<>();
 public synchronized AisNormalizedEvidence preserve(NormalizedAisRecord r,String rawSha,long now){
  if(r==null)return null;AisNormalizedEvidence e=new AisNormalizedEvidence(r,rawSha,now);q.addLast(e);while(q.size()>MAX)q.removeFirst();return e;
 }
 public synchronized List<AisNormalizedEvidence> snapshot(){return Collections.unmodifiableList(new ArrayList<>(q));}
 public synchronized List<AisNormalizedEvidence> byProviderRecord(String provider,String record){
  ArrayList<AisNormalizedEvidence> out=new ArrayList<>();for(AisNormalizedEvidence e:q)if(e.providerId.equals(provider)&&e.providerRecordId.equals(record))out.add(e);return Collections.unmodifiableList(out);
 }
 public synchronized int size(){return q.size();}
}
