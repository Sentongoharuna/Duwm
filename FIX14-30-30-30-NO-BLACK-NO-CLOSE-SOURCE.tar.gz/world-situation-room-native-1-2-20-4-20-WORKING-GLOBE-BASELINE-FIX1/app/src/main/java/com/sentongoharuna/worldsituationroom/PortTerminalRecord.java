package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Source-backed terminal identity belonging to one canonical port. */
public final class PortTerminalRecord {
 public final String terminalId,portId,name,terminalType,sourceId,sourceRecordId;public final double latitude,longitude;public final long observedAtMs;public final Map<String,String> attributes;
 public PortTerminalRecord(String id,String p,String n,String type,double lat,double lon,String s,String sr,long t,Map<String,String>a){
  terminalId=c(id);portId=c(p);name=c(n);terminalType=c(type);latitude=lat;longitude=lon;sourceId=c(s);sourceRecordId=c(sr);observedAtMs=t;attributes=Collections.unmodifiableMap(new LinkedHashMap<>(a==null?Collections.emptyMap():a));
 }
 public boolean valid(){return !terminalId.isEmpty()&&!portId.isEmpty()&&!name.isEmpty()&&!sourceId.isEmpty()&&!sourceRecordId.isEmpty()&&finite(latitude)&&finite(longitude)&&latitude>=-90&&latitude<=90&&longitude>=-180&&longitude<=180;}
 private static String c(String s){return s==null?"":s.trim();}private static boolean finite(double v){return !Double.isNaN(v)&&!Double.isInfinite(v);}
}
