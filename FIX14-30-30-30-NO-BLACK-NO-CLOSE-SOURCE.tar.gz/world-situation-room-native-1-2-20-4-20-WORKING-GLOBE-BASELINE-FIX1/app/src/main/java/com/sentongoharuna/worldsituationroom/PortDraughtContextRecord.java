package com.sentongoharuna.worldsituationroom;
public final class PortDraughtContextRecord{
 public final String contextId,portId,objectType,objectId,measurementType,datum,sourceId,sourceRecordId;public final double reportedDepthM,reportedDraughtM,underKeelClearanceM;public final long validFromMs,validUntilMs,observedAtMs;
 public PortDraughtContextRecord(String id,String p,String ot,String oi,String mt,String d,double depth,double draught,double ukc,long from,long until,String s,String sr,long observed){contextId=c(id);portId=c(p);objectType=c(ot);objectId=c(oi);measurementType=c(mt);datum=c(d);reportedDepthM=depth;reportedDraughtM=draught;underKeelClearanceM=ukc;validFromMs=from;validUntilMs=until;sourceId=c(s);sourceRecordId=c(sr);observedAtMs=observed;}
 public boolean valid(){return !contextId.isEmpty()&&!portId.isEmpty()&&!sourceId.isEmpty()&&!sourceRecordId.isEmpty()&&n(reportedDepthM)&&n(reportedDraughtM)&&n(underKeelClearanceM)&&validFromMs>=0&&validUntilMs>=0&&(validUntilMs==0||validFromMs==0||validUntilMs>=validFromMs);}
 public boolean effectiveAt(long t){return t>=0&&(validFromMs==0||t>=validFromMs)&&(validUntilMs==0||t<=validUntilMs);}
 private static boolean n(double v){return Double.isNaN(v)||(!Double.isInfinite(v)&&v>=0);}private static String c(String s){return s==null?"":s.trim();}
}