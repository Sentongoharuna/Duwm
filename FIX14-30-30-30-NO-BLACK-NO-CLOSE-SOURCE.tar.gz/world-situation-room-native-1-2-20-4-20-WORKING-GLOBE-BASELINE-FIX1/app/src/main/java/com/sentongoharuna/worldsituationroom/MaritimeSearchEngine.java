package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class MaritimeSearchEngine {
 public static final class Match {
  public final Signal signal;public final int score;public final String reason;
  Match(Signal s,int n,String r){signal=s;score=n;reason=r;}
  public String label(){
   if(signal.layer==Signal.Layer.SHIPS){VesselTelemetry t=VesselTelemetry.from(signal);String id=t!=null&&!t.name.isEmpty()?t.name:t!=null&&!t.mmsi.isEmpty()?"MMSI "+t.mmsi:signal.title;return id+" • "+reason+" • "+TruthEnforcement.label(signal);}
   PortIntelligence p=PortIntelligence.from(signal);return (p==null?signal.title:p.compact())+" • "+reason;
  }
 }
 private MaritimeSearchEngine(){}
 public static List<Match> search(String query,List<Signal> ships,List<Signal> ports){
  String q=norm(query);ArrayList<Match> out=new ArrayList<>();if(q.isEmpty())return out;
  if(ships!=null)for(Signal s:ships){if(s==null||s.layer!=Signal.Layer.SHIPS)continue;VesselTelemetry t=VesselTelemetry.from(s);if(t==null)continue;
   int score=0;String reason="";
   if(eq(t.mmsi,q)){score=100;reason="MMSI EXACT";}
   else if(eq(t.imo,q)){score=98;reason="IMO EXACT";}
   else if(eq(t.callsign,q)){score=95;reason="CALLSIGN EXACT";}
   else if(eq(t.name,q)){score=92;reason="VESSEL NAME EXACT";}
   else if(contains(t.name,q)){score=80;reason="VESSEL NAME";}
   else if(contains(t.vesselType,q)){score=65;reason="VESSEL TYPE";}
   else if(contains(t.destination,q)){score=60;reason="AIS DESTINATION";}
   if(score>0)out.add(new Match(s,score,reason));
  }
  if(ports!=null)for(Signal s:ports){PortIntelligence p=PortIntelligence.from(s);if(p==null)continue;int score=0;String reason="";
   if(eq(p.unlocode,q)){score=97;reason="UN/LOCODE EXACT";}
   else if(eq(p.name,q)){score=90;reason="PORT NAME EXACT";}
   else if(contains(p.name,q)){score=75;reason="PORT NAME";}
   if(score>0)out.add(new Match(s,score,reason));
  }
  Collections.sort(out,(a,b)->{int c=Integer.compare(b.score,a.score);return c!=0?c:a.label().compareToIgnoreCase(b.label());});
  return out;
 }
 private static String norm(String s){return s==null?"":s.trim().toUpperCase(Locale.ROOT).replaceAll("\\s+"," ");}
 private static boolean eq(String a,String q){return !q.isEmpty()&&norm(a).equals(q);}
 private static boolean contains(String a,String q){return !q.isEmpty()&&norm(a).contains(q);}
}
