package com.sentongoharuna.worldsituationroom;
public final class AisObservationOrder {
 public enum Decision { FIRST, NEWER_LIVE, SAME_TIME, LATE_HISTORY, TOO_OLD }
 public static final long MAX_LATE_HISTORY_MS=6L*60L*60L*1000L;
 private AisObservationOrder(){}
 public static Decision classify(long currentLiveMs,long incomingMs){
  if(incomingMs<=0L)return Decision.TOO_OLD;
  if(currentLiveMs<=0L)return Decision.FIRST;
  if(incomingMs>currentLiveMs)return Decision.NEWER_LIVE;
  if(incomingMs==currentLiveMs)return Decision.SAME_TIME;
  return currentLiveMs-incomingMs<=MAX_LATE_HISTORY_MS?Decision.LATE_HISTORY:Decision.TOO_OLD;
 }
}
