package com.sentongoharuna.worldsituationroom;
import java.util.Locale;
public final class RelativeAircraftGeometry {
 public final double distanceKm,bearingDegrees,altitudeDifferenceM; public final boolean altitudeDifferenceKnown; public final String altitudeBasisA,altitudeBasisB;
 private RelativeAircraftGeometry(double d,double b,double a,boolean k,String x,String y){distanceKm=d;bearingDegrees=b;altitudeDifferenceM=a;altitudeDifferenceKnown=k;altitudeBasisA=x;altitudeBasisB=y;}
 public static RelativeAircraftGeometry between(Signal a,Signal b){
  if(a==null||b==null||a.layer!=Signal.Layer.FLIGHTS||b.layer!=Signal.Layer.FLIGHTS||!a.hasLocation()||!b.hasLocation())return null;
  double d=SatelliteMapView.distanceKm(a.latitude,a.longitude,b.latitude,b.longitude),br=bearing(a.latitude,a.longitude,b.latitude,b.longitude);
  AircraftAltitudeIntelligence aa=AircraftAltitudeIntelligence.from(a),bb=AircraftAltitudeIntelligence.from(b);
  boolean known=!Double.isNaN(aa.preferredM)&&!Double.isNaN(bb.preferredM);
  return new RelativeAircraftGeometry(d,br,known?bb.preferredM-aa.preferredM:Double.NaN,known,aa.preferredBasis,bb.preferredBasis);
 }
 private static double bearing(double a,double o,double b,double p){double p1=Math.toRadians(a),p2=Math.toRadians(b),dl=Math.toRadians(p-o);double y=Math.sin(dl)*Math.cos(p2),x=Math.cos(p1)*Math.sin(p2)-Math.sin(p1)*Math.cos(p2)*Math.cos(dl);return(Math.toDegrees(Math.atan2(y,x))+360d)%360d;}
 public String disclosure(){String v=altitudeDifferenceKnown?String.format(Locale.US,"ΔALT %+.0fm (%s→%s)",altitudeDifferenceM,altitudeBasisA,altitudeBasisB):"ΔALT UNKNOWN";return String.format(Locale.US,"RANGE %.1f km • BEARING %03.0f° • %s • GEOMETRY ONLY — NOT A COLLISION-RISK ASSESSMENT",distanceKm,bearingDegrees,v);}
}
