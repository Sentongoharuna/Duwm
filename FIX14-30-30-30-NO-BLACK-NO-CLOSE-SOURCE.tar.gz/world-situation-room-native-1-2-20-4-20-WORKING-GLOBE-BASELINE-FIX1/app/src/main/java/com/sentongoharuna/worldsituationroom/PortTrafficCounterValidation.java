package com.sentongoharuna.worldsituationroom;
public final class PortTrafficCounterValidation{private PortTrafficCounterValidation(){}
 public static boolean balanced(int unique,int nearby,int harbour,int anchorage){return unique>=0&&nearby>=0&&harbour>=0&&anchorage>=0&&unique==nearby+harbour+anchorage;}
 public static int dedupe(int... identities){java.util.HashSet<Integer>s=new java.util.HashSet<>();for(int x:identities)s.add(x);return s.size();}
}