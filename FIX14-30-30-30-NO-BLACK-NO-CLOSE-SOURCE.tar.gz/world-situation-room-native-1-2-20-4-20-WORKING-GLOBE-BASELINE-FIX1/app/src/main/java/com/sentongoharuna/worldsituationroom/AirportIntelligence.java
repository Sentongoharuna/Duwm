package com.sentongoharuna.worldsituationroom;
import java.util.Locale;
public final class AirportIntelligence {
 public final String icao,iata,name,country,runway,weather,arrivalsDepartures; public final double latitude,longitude; public final String providerId,source;
 private AirportIntelligence(String a,String b,String n,String c,String r,String w,String d,double lat,double lon,String p,String s){icao=a;iata=b;name=n;country=c;runway=r;weather=w;arrivalsDepartures=d;latitude=lat;longitude=lon;providerId=p;source=s;}
 public static AirportIntelligence from(Signal s){
  if(s==null||!s.hasLocation())return null;
  String icao=code(first(s,"AIRPORT ICAO","ICAO AIRPORT","ICAO"),4),iata=code(first(s,"AIRPORT IATA","IATA AIRPORT","IATA"),3),name=first(s,"AIRPORT NAME","NAME");
  boolean airport=!icao.isEmpty()||!iata.isEmpty()||"AIRPORT".equalsIgnoreCase(first(s,"INFRASTRUCTURE TYPE","TYPE"));
  if(!airport)return null;
  return new AirportIntelligence(icao,iata,name,first(s,"COUNTRY"),first(s,"RUNWAY","RUNWAYS","RUNWAY INFO"),first(s,"AIRPORT WEATHER","METAR","WEATHER"),first(s,"ARRIVALS DEPARTURES","FLIGHT BOARD"),s.latitude,s.longitude,s.providerId,s.source);
 }
 public String code(){return !icao.isEmpty()?icao:!iata.isEmpty()?iata:"AIRPORT";}
 public String compact(){return (name.isEmpty()?code():name)+" • "+code()+(country.isEmpty()?"":" • "+country);}
 private static String first(Signal s,String...ks){for(String k:ks){String v=s.facts.get(k);if(v!=null&&!v.trim().isEmpty())return v.trim();}return "";}
 private static String code(String v,int len){if(v==null)return "";v=v.trim().toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]","");return v.length()==len?v:"";}
}
