package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class AisCanonicalFields {
 public static final List<String> SUPPORTED=Collections.unmodifiableList(Arrays.asList(
  "record_id","timestamp_ms","mmsi","imo","name","callsign","registration","vessel_type",
  "latitude","longitude","sog","cog","heading","rot","navigation_status","draught","destination","eta"));
 private AisCanonicalFields(){}
}
