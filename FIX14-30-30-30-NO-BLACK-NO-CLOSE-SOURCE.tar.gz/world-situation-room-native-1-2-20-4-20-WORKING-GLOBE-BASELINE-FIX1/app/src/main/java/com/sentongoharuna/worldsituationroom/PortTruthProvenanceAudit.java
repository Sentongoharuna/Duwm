package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** FIX14 truth/provenance contract audit. This checks source/evidence separation, not external source correctness. */
public final class PortTruthProvenanceAudit {
 public static final class Check {public final String id,description;Check(String i,String d){id=i;description=d;}}
 public static List<Check> checks(){return Collections.unmodifiableList(Arrays.asList(
  new Check("PORT_IDENTITY_SOURCE","Port identity retains source/source-record identity"),
  new Check("LOCODE_NO_INFERENCE","UN/LOCODE is source-provided and structurally validated"),
  new Check("COORDINATE_EVIDENCE","Coordinates retain provider evidence; conflicts are not averaged"),
  new Check("GEOGRAPHY_EVIDENCE","Country/region evidence retains source and disagreement"),
  new Check("HARBOUR_SOURCE_GEOMETRY","Harbour boundary requires source polygon"),
  new Check("INFRASTRUCTURE_PARENTAGE","Terminal/anchorage/berth/access objects retain canonical parent port"),
  new Check("RESTRICTIONS_DESCRIPTIVE","Restrictions are descriptive evidence, not clearance"),
  new Check("DRAUGHT_NOT_SAFE_LIMIT","Depth/draught/UKC context is not converted to safe draught"),
  new Check("WEATHER_KIND_SEPARATION","Weather observation and forecast remain distinct"),
  new Check("TIDE_KIND_SEPARATION","Tide observation and prediction remain distinct"),
  new Check("PROXIMITY_NOT_PORT_CALL","Nearby vessel does not imply arrival/port call"),
  new Check("APPROACH_NOT_ARRIVAL","Approaching trend does not imply ETA/arrival"),
  new Check("DEPARTURE_EVIDENCE_ONLY","Departure evidence does not confirm voyage departure"),
  new Check("SLOW_NOT_ANCHORED","Slow speed alone does not imply anchored"),
  new Check("COUNTER_NO_DOUBLE_COUNT","Presence buckets are mutually exclusive"),
  new Check("HISTORY_OBSERVED_ONLY","History contains recorded snapshots only"),
  new Check("DESTINATION_NOT_INTENT","AIS destination match does not confirm intent"),
  new Check("FOLLOW_NOT_DATA","Follow state does not create observations"),
  new Check("CAMERA_NOT_DATA","Camera target does not mutate evidence"),
  new Check("SHEET_MISSING_STAYS_MISSING","Intelligence sheet does not synthesize missing values"),
  new Check("SHARE_MISSING_OMITTED","Share card omits missing values"),
  new Check("LOAD_SYNTHETIC_DISCLOSED","Synthetic load rate is not claimed as device/feed throughput")
 ));}
 public static int expectedCount(){return 22;}
}