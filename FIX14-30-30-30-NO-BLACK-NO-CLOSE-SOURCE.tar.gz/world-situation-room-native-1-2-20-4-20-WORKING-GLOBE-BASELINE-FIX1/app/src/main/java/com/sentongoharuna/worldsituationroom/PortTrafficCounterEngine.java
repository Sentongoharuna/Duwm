package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Deduplicates vessel identity before counting. Behavioral evidence does not inflate presence totals. */
public final class PortTrafficCounterEngine {
 private PortTrafficCounterEngine(){}
 public static PortTrafficCounters count(String portId,List<PortNearbyVessel> presence,Map<String,PortApproachTrend> approach,Map<String,PortDepartureEvidence> departure,Map<String,PortAnchoredVesselState> anchored,long now){
  LinkedHashMap<String,PortNearbyVessel> unique=new LinkedHashMap<>();
  if(presence!=null)for(PortNearbyVessel v:presence)if(v!=null&&!v.vesselKey.isEmpty()){PortNearbyVessel old=unique.get(v.vesselKey);if(old==null||rank(v.presence)>rank(old.presence)||v.observedAtMs>old.observedAtMs)unique.put(v.vesselKey,v);}
  int n=0,h=0,a=0;for(PortNearbyVessel v:unique.values()){if(v.presence==PortNearbyVessel.Presence.INSIDE_ANCHORAGE)a++;else if(v.presence==PortNearbyVessel.Presence.INSIDE_HARBOUR)h++;else n++;}
  int ap=0,d=0,an=0;
  if(approach!=null)for(String k:unique.keySet()){PortApproachTrend x=approach.get(k);if(x!=null&&x.state==PortApproachTrend.State.APPROACHING)ap++;}
  if(departure!=null)for(String k:unique.keySet()){PortDepartureEvidence x=departure.get(k);if(x!=null&&x.state==PortDepartureEvidence.State.DEPARTING_EVIDENCE)d++;}
  if(anchored!=null)for(String k:unique.keySet()){PortAnchoredVesselState x=anchored.get(k);if(x!=null&&x.state==PortAnchoredVesselState.State.ANCHORED_EVIDENCE)an++;}
  return new PortTrafficCounters(portId,now,unique.size(),n,h,a,ap,d,an);
 }
 private static int rank(PortNearbyVessel.Presence p){return p==PortNearbyVessel.Presence.INSIDE_ANCHORAGE?3:p==PortNearbyVessel.Presence.INSIDE_HARBOUR?2:1;}
}
