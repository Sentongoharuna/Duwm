package com.sentongoharuna.worldsituationroom;
import java.util.Locale;

public final class AircraftVerticalMovement {
 public enum State { CLIMBING, LEVEL, DESCENDING, ON_GROUND, UNKNOWN }
 public enum Basis { PROVIDER_VERTICAL_RATE, OBSERVED_ALTITUDE_TREND, ON_GROUND, UNKNOWN }
 public final State state;
 public final Basis basis;
 public final double verticalRateMps;
 public final double observedTrendMps;
 public final long trendWindowMs;

 private AircraftVerticalMovement(State s,Basis b,double vr,double trend,long window){
  state=s;basis=b;verticalRateMps=vr;observedTrendMps=trend;trendWindowMs=window;
 }

 public static AircraftVerticalMovement from(Signal signal, Double previousAltitudeM, Long previousTimeMs){
  AircraftTelemetry t=AircraftTelemetry.from(signal);
  if(t==null)return unknown();
  if(Boolean.TRUE.equals(t.onGround))
   return new AircraftVerticalMovement(State.ON_GROUND,Basis.ON_GROUND,t.verticalRateMps,Double.NaN,0L);

  if(!Double.isNaN(t.verticalRateMps))
   return new AircraftVerticalMovement(classify(t.verticalRateMps),Basis.PROVIDER_VERTICAL_RATE,
       t.verticalRateMps,Double.NaN,0L);

  double current=!Double.isNaN(t.barometricAltitudeM)?t.barometricAltitudeM:t.geometricAltitudeM;
  if(previousAltitudeM!=null&&previousTimeMs!=null&&!Double.isNaN(current)
      &&t.providerTimestampMs>previousTimeMs){
    long window=t.providerTimestampMs-previousTimeMs;
    if(window>=1000L&&window<=120000L){
      double trend=(current-previousAltitudeM)/(window/1000d);
      return new AircraftVerticalMovement(classify(trend),Basis.OBSERVED_ALTITUDE_TREND,
          Double.NaN,trend,window);
    }
  }
  return unknown();
 }

 private static State classify(double rate){
  if(rate>1.0d)return State.CLIMBING;
  if(rate<-1.0d)return State.DESCENDING;
  return State.LEVEL;
 }
 private static AircraftVerticalMovement unknown(){
  return new AircraftVerticalMovement(State.UNKNOWN,Basis.UNKNOWN,Double.NaN,Double.NaN,0L);
 }
 public String disclosure(){
  if(basis==Basis.PROVIDER_VERTICAL_RATE)
   return String.format(Locale.US,"%s • PROVIDER VR %+.1f m/s",state.name(),verticalRateMps);
  if(basis==Basis.OBSERVED_ALTITUDE_TREND)
   return String.format(Locale.US,"%s • OBSERVED TREND %+.1f m/s over %.0fs",
       state.name(),observedTrendMps,trendWindowMs/1000d);
  if(basis==Basis.ON_GROUND)return "ON GROUND • PROVIDER STATE";
  return "VERTICAL MOVEMENT UNKNOWN";
 }
}
