package com.sentongoharuna.worldsituationroom;
import java.util.Locale;

/** FIX11.30/30.3 normalized aircraft telemetry. Unknown numeric values stay NaN. */
public final class AircraftTelemetry {
 public final String icao24,registration,callsign,flightNumber,aircraftType,squawk;
 public final double latitude,longitude,barometricAltitudeM,geometricAltitudeM;
 public final double groundSpeedMps,trackDegrees,headingDegrees,verticalRateMps;
 public final Boolean onGround;
 public final long providerTimestampMs;
 public final String providerId;

 private AircraftTelemetry(String i,String r,String c,String f,String t,String q,
  double lat,double lon,double baro,double geo,double speed,double track,double heading,
  double vr,Boolean ground,long ts,String provider){
  icao24=i;registration=r;callsign=c;flightNumber=f;aircraftType=t;squawk=q;
  latitude=lat;longitude=lon;barometricAltitudeM=baro;geometricAltitudeM=geo;
  groundSpeedMps=speed;trackDegrees=track;headingDegrees=heading;verticalRateMps=vr;
  onGround=ground;providerTimestampMs=ts;providerId=provider;
 }
 public static AircraftTelemetry from(Signal s){
  if(s==null||s.layer!=Signal.Layer.FLIGHTS)return null;
  AircraftCanonicalIdentity.Identity id=AircraftCanonicalIdentity.from(s);
  double baro=num(s,"BARO ALTITUDE M","BAROMETRIC ALTITUDE M","BARO ALTITUDE","ALTITUDE M");
  double geo=num(s,"GEO ALTITUDE M","GEOMETRIC ALTITUDE M","GNSS ALTITUDE M");
  double track=num(s,"TRACK","TRUE TRACK","TRACK DEGREES");
  double heading=num(s,"HEADING","TRUE HEADING","MAGNETIC HEADING");
  if(Double.isNaN(track)&&!Double.isNaN(s.heading))track=s.heading;
  double vr=num(s,"VERTICAL RATE M/S","VERTICAL RATE","VERTICAL_RATE");
  Boolean ground=bool(s,"ON GROUND","ONGROUND","ON_GROUND");
  long providerTs=s.timestampChain==null?0L:s.timestampChain.providerTimeMs;
  return new AircraftTelemetry(id.icao24,id.registration,id.callsign,id.flightNumber,
   text(s,"AIRCRAFT TYPE","TYPE","TYPECODE"),text(s,"SQUAWK"),
   s.latitude,s.longitude,baro,geo,s.speedMetersPerSecond,track,heading,vr,ground,
   providerTs,s.providerId);
 }
 public boolean hasPosition(){return !Double.isNaN(latitude)&&!Double.isNaN(longitude);}
 public boolean hasSpeed(){return !Double.isNaN(groundSpeedMps);}
 public boolean hasTrack(){return !Double.isNaN(trackDegrees);}
 public boolean hasHeading(){return !Double.isNaN(headingDegrees);}
 public boolean hasVerticalRate(){return !Double.isNaN(verticalRateMps);}
 public String altitudeDisclosure(){
  if(!Double.isNaN(barometricAltitudeM)&&!Double.isNaN(geometricAltitudeM))
   return String.format(Locale.US,"BARO %.0fm • GEO %.0fm",barometricAltitudeM,geometricAltitudeM);
  if(!Double.isNaN(barometricAltitudeM))return String.format(Locale.US,"BARO %.0fm",barometricAltitudeM);
  if(!Double.isNaN(geometricAltitudeM))return String.format(Locale.US,"GEO %.0fm",geometricAltitudeM);
  return "ALTITUDE UNKNOWN";
 }
 private static String text(Signal s,String...ks){for(String k:ks){String v=s.facts.get(k);if(v!=null&&!v.trim().isEmpty())return v.trim();}return "";}
 private static double num(Signal s,String...ks){for(String k:ks){String v=s.facts.get(k);if(v!=null)try{return Double.parseDouble(v.trim().replaceAll("[^0-9+\\\\-.]",""));}catch(Exception ignored){}}return Double.NaN;}
 private static Boolean bool(Signal s,String...ks){String v=text(s,ks).toLowerCase(Locale.ROOT);if(v.equals("true")||v.equals("yes")||v.equals("1"))return true;if(v.equals("false")||v.equals("no")||v.equals("0"))return false;return null;}
}
