package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Cross-provider COG/heading disagreement using circular-angle distance. Values are never averaged. */
public final class AisHeadingConflict {
 public enum State { NONE, COG_CONFLICT, HEADING_CONFLICT, BOTH_CONFLICT, INSUFFICIENT }
 public static final class Result {
  public final State state;public final double maxCogDeltaDeg,maxHeadingDeltaDeg;public final String cogProviderA,cogProviderB,headingProviderA,headingProviderB;
  Result(State s,double c,double h,String ca,String cb,String ha,String hb){state=s;maxCogDeltaDeg=c;maxHeadingDeltaDeg=h;cogProviderA=ca;cogProviderB=cb;headingProviderA=ha;headingProviderB=hb;}
  public String disclosure(){
   if(state==State.INSUFFICIENT)return "HEADING/COG CONFLICT • INSUFFICIENT";
   if(state==State.NONE)return "HEADING/COG CONFLICT • NONE";
   StringBuilder b=new StringBuilder(state.name().replace('_',' ')).append(" • ");
   if(!Double.isNaN(maxCogDeltaDeg)&&maxCogDeltaDeg>25d)b.append(String.format(Locale.US,"COG Δ %.0f° %s↔%s",maxCogDeltaDeg,cogProviderA,cogProviderB));
   if(!Double.isNaN(maxHeadingDeltaDeg)&&maxHeadingDeltaDeg>25d){if(b.charAt(b.length()-1)!=' ')b.append(" • ");b.append(String.format(Locale.US,"HEADING Δ %.0f° %s↔%s",maxHeadingDeltaDeg,headingProviderA,headingProviderB));}
   return b.append(" • ORIGINAL ANGLES RETAINED").toString();
  }
 }
 private AisHeadingConflict(){}
 public static Result detect(List<NormalizedAisRecord> records){
  if(records==null||records.size()<2)return new Result(State.INSUFFICIENT,Double.NaN,Double.NaN,"","","","");
  double mc=Double.NaN,mh=Double.NaN;String ca="",cb="",ha="",hb="";boolean compared=false;
  for(int i=0;i<records.size();i++){NormalizedAisRecord a=records.get(i);if(a==null)continue;
   for(int j=i+1;j<records.size();j++){NormalizedAisRecord b=records.get(j);if(b==null||a.providerId.equals(b.providerId)||Math.abs(a.providerTimestampMs-b.providerTimestampMs)>120000L)continue;
    if(a.hasCog()&&b.hasCog()){compared=true;double d=delta(a.cogDegrees,b.cogDegrees);if(Double.isNaN(mc)||d>mc){mc=d;ca=a.providerId;cb=b.providerId;}}
    if(finite(a.headingDegrees)&&finite(b.headingDegrees)){compared=true;double d=delta(a.headingDegrees,b.headingDegrees);if(Double.isNaN(mh)||d>mh){mh=d;ha=a.providerId;hb=b.providerId;}}
   }}
  if(!compared)return new Result(State.INSUFFICIENT,mc,mh,ca,cb,ha,hb);
  boolean cc=!Double.isNaN(mc)&&mc>25d,hc=!Double.isNaN(mh)&&mh>25d;
  State s=cc&&hc?State.BOTH_CONFLICT:cc?State.COG_CONFLICT:hc?State.HEADING_CONFLICT:State.NONE;
  return new Result(s,mc,mh,ca,cb,ha,hb);
 }
 public static double delta(double a,double b){if(!finite(a)||!finite(b))return Double.NaN;return Math.abs(((b-a+540d)%360d)-180d);}
 private static boolean finite(double v){return !Double.isNaN(v)&&!Double.isInfinite(v);}
}
