package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Source-backed harbour polygon evidence. No boundary is inferred from a port point. */
public final class HarbourBoundaryEvidence {
 public static final class Point {public final double latitude,longitude;public Point(double a,double o){latitude=a;longitude=o;}}
 public final String portId,boundaryId,sourceId,sourceRecordId,method;public final List<Point> polygon;public final long observedAtMs;
 public HarbourBoundaryEvidence(String p,String b,String s,String r,String m,List<Point> poly,long t){
  portId=c(p);boundaryId=c(b);sourceId=c(s);sourceRecordId=c(r);method=c(m);polygon=Collections.unmodifiableList(new ArrayList<>(poly==null?Collections.emptyList():poly));observedAtMs=t;
 }
 public boolean valid(){if(portId.isEmpty()||boundaryId.isEmpty()||sourceId.isEmpty()||sourceRecordId.isEmpty()||polygon.size()<3)return false;for(Point p:polygon)if(Double.isNaN(p.latitude)||Double.isNaN(p.longitude)||p.latitude<-90||p.latitude>90||p.longitude<-180||p.longitude>180)return false;return Math.abs(area2())>1e-12;}
 double area2(){double a=0;for(int i=0,j=polygon.size()-1;i<polygon.size();j=i++)a+=polygon.get(j).longitude*polygon.get(i).latitude-polygon.get(i).longitude*polygon.get(j).latitude;return a;}
 private static String c(String s){return s==null?"":s.trim();}
}
