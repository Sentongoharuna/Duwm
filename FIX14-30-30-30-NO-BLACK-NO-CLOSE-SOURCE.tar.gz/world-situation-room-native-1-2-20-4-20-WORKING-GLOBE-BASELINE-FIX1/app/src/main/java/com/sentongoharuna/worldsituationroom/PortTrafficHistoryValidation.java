package com.sentongoharuna.worldsituationroom;
public final class PortTrafficHistoryValidation{private PortTrafficHistoryValidation(){}
 public static boolean chronological(long previous,long next){return previous>0&&next>previous;}
 public static int boundedSize(int current,int add,int max){return Math.min(max,Math.max(0,current)+Math.max(0,add));}
 public static boolean validRange(long from,long to){return from>=0&&to>=from;}
}