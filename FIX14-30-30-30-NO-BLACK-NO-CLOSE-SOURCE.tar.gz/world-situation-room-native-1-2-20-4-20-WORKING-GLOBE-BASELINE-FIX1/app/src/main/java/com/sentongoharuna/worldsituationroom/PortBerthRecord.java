package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Source-backed berth identity. Dimensions/capacity remain unknown unless supplied. */
public final class PortBerthRecord {
 public final String berthId,portId,terminalId,name,berthType,sourceId,sourceRecordId;
 public final double latitude,longitude,lengthM,depthM;public final long observedAtMs;public final Map<String,String> attributes;
 public PortBerthRecord(String id,String p,String terminal,String n,String type,double lat,double lon,double len,double depth,String s,String sr,long t,Map<String,String>a){
  berthId=c(id);portId=c(p);terminalId=c(terminal);name=c(n);berthType=c(type);latitude=lat;longitude=lon;lengthM=len;depthM=depth;sourceId=c(s);sourceRecordId=c(sr);observedAtMs=t;attributes=Collections.unmodifiableMap(new LinkedHashMap<>(a==null?Collections.emptyMap():a));
 }
 public boolean valid(){
  return !berthId.isEmpty()&&!portId.isEmpty()&&!name.isEmpty()&&!sourceId.isEmpty()&&!sourceRecordId.isEmpty()&&finite(latitude)&&finite(longitude)&&latitude>=-90&&latitude<=90&&longitude>=-180&&longitude<=180&&(Double.isNaN(lengthM)||lengthM>=0)&&(Double.isNaN(depthM)||depthM>=0);
 }
 private static String c(String s){return s==null?"":s.trim();}private static boolean finite(double v){return !Double.isNaN(v)&&!Double.isInfinite(v);}
}
