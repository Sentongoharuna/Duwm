package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Retains provider geography evidence and exposes disagreements instead of overwriting them. */
public final class PortGeographyRegistry {
 public enum Decision { ADDED, UPDATED, DUPLICATE, REJECTED }
 public enum ConflictState { NONE, COUNTRY_CONFLICT, REGION_CONFLICT, BOTH_CONFLICT, INSUFFICIENT }
 public static final class Result {public final Decision decision;public final String reason;Result(Decision d,String r){decision=d;reason=r;}}
 public static final class Conflict {public final ConflictState state;public final Set<String> countries,regions;Conflict(ConflictState s,Set<String>c,Set<String>r){state=s;countries=Collections.unmodifiableSet(c);regions=Collections.unmodifiableSet(r);}}
 private final LinkedHashMap<String,LinkedHashMap<String,PortGeographyEvidence>> byPort=new LinkedHashMap<>();
 public synchronized Result add(PortRecord port,PortGeographyEvidence e){
  if(port==null||e==null||!e.valid()||!port.portId.equals(e.portId))return new Result(Decision.REJECTED,"INVALID/UNKNOWN PORT GEOGRAPHY");
  if(!port.countryCode.isEmpty()&&!port.countryCode.equals(e.countryCode))return new Result(Decision.REJECTED,"COUNTRY MISMATCH WITH CANONICAL PORT");
  String k=e.sourceId+"|"+e.sourceRecordId;LinkedHashMap<String,PortGeographyEvidence>m=byPort.computeIfAbsent(e.portId,z->new LinkedHashMap<>());PortGeographyEvidence old=m.get(k);
  if(old!=null&&same(old,e))return new Result(Decision.DUPLICATE,"UNCHANGED");m.put(k,e);return new Result(old==null?Decision.ADDED:Decision.UPDATED,old==null?"ADDED":"UPDATED");
 }
 public synchronized List<PortGeographyEvidence> evidence(String id){Map<String,PortGeographyEvidence>m=byPort.get(id);return m==null?Collections.emptyList():Collections.unmodifiableList(new ArrayList<>(m.values()));}
 public synchronized Conflict conflict(String id){
  List<PortGeographyEvidence> e=evidence(id);if(e.size()<2)return new Conflict(ConflictState.INSUFFICIENT,new LinkedHashSet<>(),new LinkedHashSet<>());
  LinkedHashSet<String> countries=new LinkedHashSet<>(),regions=new LinkedHashSet<>();LinkedHashSet<String>sources=new LinkedHashSet<>();
  for(PortGeographyEvidence x:e){sources.add(x.sourceId);countries.add(x.countryCode);if(!x.regionCode.isEmpty()||!x.regionName.isEmpty())regions.add(x.regionCode+"|"+x.regionName);}
  if(sources.size()<2)return new Conflict(ConflictState.INSUFFICIENT,countries,regions);
  boolean c=countries.size()>1,r=regions.size()>1;return new Conflict(c&&r?ConflictState.BOTH_CONFLICT:c?ConflictState.COUNTRY_CONFLICT:r?ConflictState.REGION_CONFLICT:ConflictState.NONE,countries,regions);
 }
 public synchronized int evidenceCount(){int n=0;for(Map<String,PortGeographyEvidence>m:byPort.values())n+=m.size();return n;}
 private static boolean same(PortGeographyEvidence a,PortGeographyEvidence b){return a.countryCode.equals(b.countryCode)&&a.countryName.equals(b.countryName)&&a.regionCode.equals(b.regionCode)&&a.regionName.equals(b.regionName)&&a.observedAtMs==b.observedAtMs;}
}
