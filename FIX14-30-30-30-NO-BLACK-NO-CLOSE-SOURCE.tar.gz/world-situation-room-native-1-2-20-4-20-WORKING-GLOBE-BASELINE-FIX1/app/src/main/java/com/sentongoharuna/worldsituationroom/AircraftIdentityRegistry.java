package com.sentongoharuna.worldsituationroom;
import java.util.LinkedHashMap;import java.util.Map;
public final class AircraftIdentityRegistry {
 private final Map<String,String> canonicalByAircraftKey=new LinkedHashMap<>();
 public synchronized String resolve(Signal s){
  AircraftCanonicalIdentity.Identity id=AircraftCanonicalIdentity.from(s);
  if(id.key.isEmpty())return s==null?"":s.canonicalId;
  String prior=canonicalByAircraftKey.get(id.key);if(prior!=null)return prior;
  canonicalByAircraftKey.put(id.key,s.canonicalId);
  while(canonicalByAircraftKey.size()>5000){String k=canonicalByAircraftKey.keySet().iterator().next();canonicalByAircraftKey.remove(k);}
  return s.canonicalId;
 }
 public synchronized int size(){return canonicalByAircraftKey.size();}
}
