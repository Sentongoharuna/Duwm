package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Separates source-to-receive latency from local receive-to-processing latency. */
public final class AisIngestionLatency {
 public static final class Sample {
  public final String providerId;public final long providerToReceiveMs,receiveToProcessMs,endToEndMs;public final boolean clockSkew;
  Sample(String p,long a,long b,long e,boolean s){providerId=p;providerToReceiveMs=a;receiveToProcessMs=b;endToEndMs=e;clockSkew=s;}
  public String disclosure(){return String.format(Locale.US,"LATENCY • SOURCE→RECEIVE %s • RECEIVE→PROCESS %.0fms • END-TO-END %s",
    clockSkew?"CLOCK-SKEW":String.format(Locale.US,"%.0fms",(double)providerToReceiveMs),(double)receiveToProcessMs,
    clockSkew?"CLOCK-SKEW":String.format(Locale.US,"%.0fms",(double)endToEndMs));}
 }
 private AisIngestionLatency(){}
 public static Sample measure(NormalizedAisRecord r){
  if(r==null)return null;
  long sr=r.receivedAtMs-r.providerTimestampMs,rp=Math.max(0L,r.processedAtMs-r.receivedAtMs),ee=r.processedAtMs-r.providerTimestampMs;
  boolean skew=sr<0L||ee<0L;
  return new Sample(r.providerId,skew?-1L:sr,rp,skew?-1L:ee,skew);
 }
}
