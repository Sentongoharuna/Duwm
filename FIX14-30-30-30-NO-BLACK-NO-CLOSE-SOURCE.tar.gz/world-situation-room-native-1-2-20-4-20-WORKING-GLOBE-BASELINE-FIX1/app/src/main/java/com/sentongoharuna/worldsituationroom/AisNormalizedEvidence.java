package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Immutable evidence snapshot of a normalized AIS record before fusion. */
public final class AisNormalizedEvidence {
 public final String providerId,providerRecordId,mmsi,imo,name,callsign,destination,rawPayloadSha256;
 public final long providerTimestampMs,receivedAtMs,processedAtMs,preservedAtMs;
 public final double latitude,longitude,sogMps,cogDegrees,headingDegrees;
 public final Map<String,String> rawFields;
 AisNormalizedEvidence(NormalizedAisRecord r,String rawSha,long now){
  providerId=r.providerId;providerRecordId=r.providerRecordId;mmsi=r.mmsi;imo=r.imo;name=r.name;callsign=r.callsign;destination=r.destination;
  rawPayloadSha256=rawSha==null?"":rawSha;providerTimestampMs=r.providerTimestampMs;receivedAtMs=r.receivedAtMs;processedAtMs=r.processedAtMs;preservedAtMs=now;
  latitude=r.latitude;longitude=r.longitude;sogMps=r.sogMps;cogDegrees=r.cogDegrees;headingDegrees=r.headingDegrees;
  rawFields=Collections.unmodifiableMap(new LinkedHashMap<>(r.rawFields));
 }
}
