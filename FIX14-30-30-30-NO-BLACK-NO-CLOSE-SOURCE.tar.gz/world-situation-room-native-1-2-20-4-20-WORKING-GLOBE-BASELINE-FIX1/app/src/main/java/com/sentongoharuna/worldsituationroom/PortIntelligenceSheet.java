package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Read-only assembled port detail model. Every section comes from already loaded evidence/registries. */
public final class PortIntelligenceSheet {
 public final PortRecord port;public final String unLocode;public final boolean followed;
 public final int terminals,anchorages,berths,approaches,entrances,channels,restrictions,draughtContexts,weatherContexts,tideContexts,trafficSnapshots;
 public final PortTrafficCounters latestTraffic;public final PortWeatherContextRecord latestObservation,latestForecast;public final PortTideContextRecord nearestObservedTide,nearestPredictedTide;
 public final long generatedAtMs;
 PortIntelligenceSheet(PortRecord p,String u,boolean f,int te,int an,int be,int ap,int en,int ch,int re,int dr,int we,int ti,int hi,PortTrafficCounters tr,PortWeatherContextRecord wo,PortWeatherContextRecord wf,PortTideContextRecord to,PortTideContextRecord tp,long now){
  port=p;unLocode=u;followed=f;terminals=te;anchorages=an;berths=be;approaches=ap;entrances=en;channels=ch;restrictions=re;draughtContexts=dr;weatherContexts=we;tideContexts=ti;trafficSnapshots=hi;latestTraffic=tr;latestObservation=wo;latestForecast=wf;nearestObservedTide=to;nearestPredictedTide=tp;generatedAtMs=now;
 }
 public String disclosure(){return "SOURCE-AWARE PORT INTELLIGENCE • missing sections remain missing • no navigation/safety verdict";}
}
