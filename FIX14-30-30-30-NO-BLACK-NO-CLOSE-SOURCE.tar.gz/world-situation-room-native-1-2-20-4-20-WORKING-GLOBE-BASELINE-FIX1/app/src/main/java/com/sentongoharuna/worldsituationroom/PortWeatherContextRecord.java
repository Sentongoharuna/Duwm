package com.sentongoharuna.worldsituationroom;
/** Source-attributed port weather. Observation and forecast are explicitly separated. */
public final class PortWeatherContextRecord {
 public enum Kind { OBSERVATION, FORECAST }
 public final String weatherId,portId,stationId,sourceId,sourceRecordId;public final Kind kind;
 public final double temperatureC,pressureHpa,humidityPct,windSpeedMps,windDirectionDeg,gustMps,visibilityM,precipitationMm;
 public final long validAtMs,issuedAtMs,receivedAtMs;
 public PortWeatherContextRecord(String id,String p,String station,Kind k,double temp,double pressure,double humidity,double wind,double dir,double gust,double visibility,double precip,long valid,long issued,long received,String source,String sr){
  weatherId=c(id);portId=c(p);stationId=c(station);kind=k;temperatureC=temp;pressureHpa=pressure;humidityPct=humidity;windSpeedMps=wind;windDirectionDeg=dir;gustMps=gust;visibilityM=visibility;precipitationMm=precip;validAtMs=valid;issuedAtMs=issued;receivedAtMs=received;sourceId=c(source);sourceRecordId=c(sr);
 }
 public boolean valid(){return !weatherId.isEmpty()&&!portId.isEmpty()&&kind!=null&&!sourceId.isEmpty()&&!sourceRecordId.isEmpty()&&validAtMs>0&&issuedAtMs>=0&&receivedAtMs>=0&&n(pressureHpa)&&range(humidityPct,0,100)&&n(windSpeedMps)&&range(windDirectionDeg,0,360)&&n(gustMps)&&n(visibilityM)&&n(precipitationMm)&&finiteOrUnknown(temperatureC);}
 private static boolean n(double v){return Double.isNaN(v)||(!Double.isInfinite(v)&&v>=0);}private static boolean range(double v,double a,double b){return Double.isNaN(v)||(!Double.isInfinite(v)&&v>=a&&v<=b);}private static boolean finiteOrUnknown(double v){return Double.isNaN(v)||!Double.isInfinite(v);}private static String c(String s){return s==null?"":s.trim();}
}
