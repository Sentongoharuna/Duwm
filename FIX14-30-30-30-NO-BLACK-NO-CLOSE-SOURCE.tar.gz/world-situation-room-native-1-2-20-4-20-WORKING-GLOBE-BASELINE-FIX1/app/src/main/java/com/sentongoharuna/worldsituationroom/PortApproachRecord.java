package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Source-backed port approach route/corridor. Never inferred from a straight line to port. */
public final class PortApproachRecord {
 public final String approachId,portId,name,approachType,sourceId,sourceRecordId;public final List<HarbourBoundaryEvidence.Point> centerline;public final double corridorWidthM;public final long observedAtMs;
 public PortApproachRecord(String id,String p,String n,String type,List<HarbourBoundaryEvidence.Point> line,double width,String s,String sr,long t){
  approachId=c(id);portId=c(p);name=c(n);approachType=c(type);centerline=Collections.unmodifiableList(new ArrayList<>(line==null?Collections.emptyList():line));corridorWidthM=width;sourceId=c(s);sourceRecordId=c(sr);observedAtMs=t;
 }
 public boolean valid(){if(approachId.isEmpty()||portId.isEmpty()||name.isEmpty()||sourceId.isEmpty()||sourceRecordId.isEmpty()||centerline.size()<2||( !Double.isNaN(corridorWidthM)&&corridorWidthM<0))return false;for(HarbourBoundaryEvidence.Point x:centerline)if(Double.isNaN(x.latitude)||Double.isNaN(x.longitude)||x.latitude<-90||x.latitude>90||x.longitude<-180||x.longitude>180)return false;return true;}
 private static String c(String s){return s==null?"":s.trim();}
}
