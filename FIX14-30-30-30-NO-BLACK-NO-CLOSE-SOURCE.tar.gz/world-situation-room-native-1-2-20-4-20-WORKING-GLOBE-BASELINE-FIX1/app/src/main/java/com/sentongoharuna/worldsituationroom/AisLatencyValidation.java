package com.sentongoharuna.worldsituationroom;
public final class AisLatencyValidation{private AisLatencyValidation(){}
 public static long sourceToReceive(long p,long r){return r>=p&&p>0?r-p:-1;}
 public static long receiveToProcess(long r,long x){return x>=r&&r>0?x-r:-1;}
 public static long endToEnd(long p,long x){return x>=p&&p>0?x-p:-1;}
}