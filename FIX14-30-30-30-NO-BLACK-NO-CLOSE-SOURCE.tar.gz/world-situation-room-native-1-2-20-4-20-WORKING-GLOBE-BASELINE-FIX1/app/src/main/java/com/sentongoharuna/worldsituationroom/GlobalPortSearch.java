package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Searches only actually loaded FIX14 registry content; does not fabricate global coverage. */
public final class GlobalPortSearch {
 private GlobalPortSearch(){}
 public static List<PortSearchResult> search(PortRegistry r,String query){
  if(r==null)return Collections.emptyList();String q=norm(query);if(q.isEmpty())return Collections.emptyList();
  LinkedHashMap<String,PortSearchResult> best=new LinkedHashMap<>();
  for(PortRecord p:r.all()){
   consider(best,p,r,"PORT_ID",p.portId,q,100);
   consider(best,p,r,"PORT_NAME",p.name,q,95);
   consider(best,p,r,"UNLOCODE",r.unLocodeFor(p.portId),q,100);
   consider(best,p,r,"COUNTRY",p.countryCode,q,70);
   consider(best,p,r,"REGION",p.region,q,65);
   for(PortTerminalRecord x:r.terminalsForPort(p.portId)){consider(best,p,r,"TERMINAL_ID",x.terminalId,q,80);consider(best,p,r,"TERMINAL",x.name,q,78);}
   for(PortAnchorageRecord x:r.anchoragesForPort(p.portId)){consider(best,p,r,"ANCHORAGE_ID",x.anchorageId,q,78);consider(best,p,r,"ANCHORAGE",x.name,q,76);}
   for(PortBerthRecord x:r.berthsForPort(p.portId)){consider(best,p,r,"BERTH_ID",x.berthId,q,76);consider(best,p,r,"BERTH",x.name,q,74);}
   for(PortApproachRecord x:r.approachesForPort(p.portId)){consider(best,p,r,"APPROACH_ID",x.approachId,q,72);consider(best,p,r,"APPROACH",x.name,q,70);}
   for(PortEntranceRecord x:r.entrancesForPort(p.portId)){consider(best,p,r,"ENTRANCE_ID",x.entranceId,q,72);consider(best,p,r,"ENTRANCE",x.name,q,70);}
   for(PortNavigationChannelRecord x:r.navigationChannelsForPort(p.portId)){consider(best,p,r,"CHANNEL_ID",x.channelId,q,72);consider(best,p,r,"CHANNEL",x.name,q,70);}
  }
  ArrayList<PortSearchResult> out=new ArrayList<>(best.values());out.sort((a,b)->{int c=Integer.compare(b.score,a.score);return c!=0?c:a.portName.compareToIgnoreCase(b.portName);});return Collections.unmodifiableList(out);
 }
 private static void consider(Map<String,PortSearchResult> best,PortRecord p,PortRegistry r,String field,String value,String q,int weight){
  String v=norm(value);if(v.isEmpty())return;int score=v.equals(q)?weight+20:v.startsWith(q)?weight+10:v.contains(q)?weight:-1;if(score<0)return;
  PortSearchResult old=best.get(p.portId);if(old==null||score>old.score)best.put(p.portId,new PortSearchResult(p.portId,p.name,r.unLocodeFor(p.portId),p.countryCode,p.region,field,value,score));
 }
 private static String norm(String s){return s==null?"":s.trim().toUpperCase(Locale.US).replaceAll("[^A-Z0-9]+"," ").trim().replaceAll("\\s+"," ");}
}
