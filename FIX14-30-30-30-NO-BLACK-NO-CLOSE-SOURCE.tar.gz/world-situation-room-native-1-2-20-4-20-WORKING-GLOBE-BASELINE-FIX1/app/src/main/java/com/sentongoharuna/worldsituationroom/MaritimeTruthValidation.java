package com.sentongoharuna.worldsituationroom;
public final class MaritimeTruthValidation {
 private MaritimeTruthValidation(){}
 public static boolean observedEvidence(String s){return "OBSERVED AIS FIXES ONLY".equals(s);}
 public static boolean movementEvidence(String s){return s!=null&&s.contains("OBSERVATIONS IMMUTABLE");}
 public static boolean cpaDisclosure(String s){return s!=null&&s.contains("CONSTANT-MOTION PROJECTION")&&s.contains("NOT COLLISION PREDICTION");}
 public static boolean replayDisclosure(String s){return s!=null&&s.contains("OBSERVED AIS HISTORY");}
}
