package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Source-backed port identity record. Unknown fields remain empty/NaN. */
public final class PortRecord {
 public final String portId,name,countryCode,region,sourceId,sourceRecordId;
 public final double latitude,longitude;public final long observedAtMs;
 public final Map<String,String> attributes;
 public PortRecord(String id,String n,String cc,String reg,double lat,double lon,String source,String sourceRecord,long observed,Map<String,String>a){
  portId=clean(id);name=clean(n);countryCode=clean(cc).toUpperCase(Locale.US);region=clean(reg);latitude=lat;longitude=lon;sourceId=clean(source);sourceRecordId=clean(sourceRecord);observedAtMs=observed;
  attributes=Collections.unmodifiableMap(new LinkedHashMap<>(a==null?Collections.emptyMap():a));
 }
 public boolean hasLocation(){return finite(latitude)&&finite(longitude)&&latitude>=-90&&latitude<=90&&longitude>=-180&&longitude<=180;}
 public boolean validIdentity(){return !portId.isEmpty()&&!name.isEmpty()&&!sourceId.isEmpty()&&!sourceRecordId.isEmpty();}
 private static String clean(String s){return s==null?"":s.trim();}
 private static boolean finite(double v){return !Double.isNaN(v)&&!Double.isInfinite(v);}
}
