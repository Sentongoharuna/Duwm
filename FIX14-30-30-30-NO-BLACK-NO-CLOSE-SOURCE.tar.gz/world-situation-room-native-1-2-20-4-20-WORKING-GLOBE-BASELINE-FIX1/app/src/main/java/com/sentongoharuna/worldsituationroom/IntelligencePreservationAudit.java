package com.sentongoharuna.worldsituationroom;
import java.util.ArrayList;
import java.util.List;
public final class IntelligencePreservationAudit {
 private IntelligencePreservationAudit(){}
 public static List<String> inspect(List<Signal> signals){
  ArrayList<String> issues=new ArrayList<>();
  if(signals==null)return issues;
  for(Signal s:signals){
   if(s==null){issues.add("NULL SIGNAL");continue;}
   if(s.canonicalId==null||s.canonicalId.trim().isEmpty())issues.add("MISSING CANONICAL ID • "+s.id);
   if(s.providerId==null||s.providerId.trim().isEmpty())issues.add("MISSING PROVIDER ID • "+s.id);
   if(s.originalRecord==null)issues.add("MISSING ORIGINAL RECORD • "+s.id);
   if(s.timestampChain==null)issues.add("MISSING TIMESTAMP CHAIN • "+s.id);
   if(s.source==null||s.source.trim().isEmpty())issues.add("MISSING SOURCE • "+s.id);
  }
  return issues;
 }
}