package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Source-backed anchorage. Geometry may be a point or polygon; no geometry is inferred. */
public final class PortAnchorageRecord {
 public final String anchorageId,portId,name,sourceId,sourceRecordId;public final double latitude,longitude;public final List<HarbourBoundaryEvidence.Point> polygon;public final long observedAtMs;
 public PortAnchorageRecord(String id,String p,String n,double lat,double lon,List<HarbourBoundaryEvidence.Point> poly,String s,String sr,long t){
  anchorageId=c(id);portId=c(p);name=c(n);latitude=lat;longitude=lon;polygon=Collections.unmodifiableList(new ArrayList<>(poly==null?Collections.emptyList():poly));sourceId=c(s);sourceRecordId=c(sr);observedAtMs=t;
 }
 public boolean valid(){if(anchorageId.isEmpty()||portId.isEmpty()||name.isEmpty()||sourceId.isEmpty()||sourceRecordId.isEmpty())return false;boolean point=finite(latitude)&&finite(longitude)&&latitude>=-90&&latitude<=90&&longitude>=-180&&longitude<=180;if(polygon.isEmpty())return point;if(polygon.size()<3)return false;for(HarbourBoundaryEvidence.Point x:polygon)if(!finite(x.latitude)||!finite(x.longitude)||x.latitude<-90||x.latitude>90||x.longitude<-180||x.longitude>180)return false;return point;}
 public boolean contains(double lat,double lon){return !polygon.isEmpty()&&HarbourBoundaryRegistry.inside(polygon,lat,lon);}
 private static String c(String s){return s==null?"":s.trim();}private static boolean finite(double v){return !Double.isNaN(v)&&!Double.isInfinite(v);}
}
