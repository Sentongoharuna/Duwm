package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Provider-local freshness. One stale provider does not make all fused evidence stale. */
public final class AisProviderFreshness {
 public enum State { LIVE, AGING, STALE, SILENT, UNKNOWN }
 public static final class Result {
  public final String providerId;public final State state;public final long observationAgeMs,silenceMs;
  Result(String p,State s,long a,long q){providerId=p;state=s;observationAgeMs=a;silenceMs=q;}
  public String disclosure(){return "PROVIDER "+providerId+" • "+state.name()+" • OBS AGE "+seconds(observationAgeMs)+"s • SILENCE "+seconds(silenceMs)+"s";}
  private static String seconds(long v){return v<0?"UNKNOWN":String.format(Locale.US,"%.0f",v/1000d);}
 }
 private AisProviderFreshness(){}
 public static Result assess(String providerId,long providerObservationMs,long lastReceivedMs,long nowMs){
  if(nowMs<=0L||providerObservationMs<=0L||lastReceivedMs<=0L)return new Result(providerId,State.UNKNOWN,-1,-1);
  long age=Math.max(0L,nowMs-providerObservationMs),silence=Math.max(0L,nowMs-lastReceivedMs);
  State s=silence>600000L?State.SILENT:age>1800000L?State.STALE:age>300000L?State.AGING:State.LIVE;
  return new Result(providerId,s,age,silence);
 }
}
