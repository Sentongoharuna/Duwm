package com.sentongoharuna.worldsituationroom;
/** Gate used before a provider position is allowed into observed AIS history. */
public final class AisCoordinateGate {
 private AisCoordinateGate(){}
 public static AisCoordinateValidation.Result beforeHistory(double oldLat,double oldLon,long oldProviderMs,NormalizedAisRecord next){
  if(next==null)return AisCoordinateValidation.validate(Double.NaN,Double.NaN);
  return AisCoordinateValidation.validateTransition(oldLat,oldLon,oldProviderMs,next.latitude,next.longitude,next.providerTimestampMs);
 }
}
