package com.sentongoharuna.worldsituationroom;
import java.util.Locale;
public final class MaritimeSearchValidation{private MaritimeSearchValidation(){}
 public static String norm(String s){return s==null?"":s.trim().toUpperCase(Locale.ROOT).replaceAll("\\s+"," ");}
 public static int rank(String field,String q,int exact,int partial){String a=norm(field),b=norm(q);if(b.isEmpty())return 0;if(a.equals(b))return exact;if(a.contains(b))return partial;return 0;}
}
