package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class PortEntranceRegistry {
 public enum Decision { ADDED, UPDATED, DUPLICATE, REJECTED, CONFLICT }
 public static final class Result {public final Decision decision;public final String reason;Result(Decision d,String r){decision=d;reason=r;}}
 private final LinkedHashMap<String,PortEntranceRecord> byId=new LinkedHashMap<>();private final LinkedHashMap<String,String> sourceBinding=new LinkedHashMap<>();
 public synchronized Result upsert(PortRecord port,PortEntranceRecord e){
  if(port==null||e==null||!e.valid()||!port.portId.equals(e.portId))return new Result(Decision.REJECTED,"INVALID ENTRANCE OR PARENT PORT");
  String sk=e.sourceId+"|"+e.sourceRecordId,prior=sourceBinding.get(sk);if(prior!=null&&!prior.equals(e.entranceId))return new Result(Decision.CONFLICT,"SOURCE RECORD ALREADY BOUND TO "+prior);
  PortEntranceRecord old=byId.get(e.entranceId);if(old!=null&&!old.portId.equals(e.portId))return new Result(Decision.CONFLICT,"ENTRANCE PARENT PORT CHANGED");
  if(old!=null&&same(old,e)){sourceBinding.put(sk,e.entranceId);return new Result(Decision.DUPLICATE,"UNCHANGED");}
  byId.put(e.entranceId,e);sourceBinding.put(sk,e.entranceId);return new Result(old==null?Decision.ADDED:Decision.UPDATED,old==null?"ADDED":"UPDATED");
 }
 public synchronized PortEntranceRecord get(String id){return byId.get(id==null?"":id.trim());}
 public synchronized List<PortEntranceRecord> forPort(String p){ArrayList<PortEntranceRecord>o=new ArrayList<>();for(PortEntranceRecord e:byId.values())if(e.portId.equals(p))o.add(e);return Collections.unmodifiableList(o);}
 public synchronized List<PortEntranceRecord> search(String q){String x=q==null?"":q.trim().toLowerCase(Locale.US);ArrayList<PortEntranceRecord>o=new ArrayList<>();for(PortEntranceRecord e:byId.values())if(x.isEmpty()||e.name.toLowerCase(Locale.US).contains(x)||e.entranceId.toLowerCase(Locale.US).contains(x)||e.entranceType.toLowerCase(Locale.US).contains(x))o.add(e);return Collections.unmodifiableList(o);}
 public synchronized int size(){return byId.size();}
 private static boolean same(PortEntranceRecord a,PortEntranceRecord b){if(!a.portId.equals(b.portId)||!a.name.equals(b.name)||!a.entranceType.equals(b.entranceType)||Double.compare(a.latitude,b.latitude)!=0||Double.compare(a.longitude,b.longitude)!=0||Double.compare(a.widthM,b.widthM)!=0||a.gateLine.size()!=b.gateLine.size()||a.observedAtMs!=b.observedAtMs)return false;for(int i=0;i<a.gateLine.size();i++){HarbourBoundaryEvidence.Point x=a.gateLine.get(i),y=b.gateLine.get(i);if(Double.compare(x.latitude,y.latitude)!=0||Double.compare(x.longitude,y.longitude)!=0)return false;}return true;}
}
