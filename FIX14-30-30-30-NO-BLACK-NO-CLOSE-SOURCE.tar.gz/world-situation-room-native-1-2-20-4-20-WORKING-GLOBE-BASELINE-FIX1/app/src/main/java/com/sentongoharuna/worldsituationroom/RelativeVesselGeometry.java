package com.sentongoharuna.worldsituationroom;
import java.util.Locale;
/** Instantaneous observed geometry only. This is NOT collision-risk assessment. */
public final class RelativeVesselGeometry {
 public final Signal reference,target;
 public final double rangeKm,bearingDeg,relativeHeadingDeg,speedDifferenceKnots;
 private RelativeVesselGeometry(Signal a,Signal b,double r,double br,double rh,double sd){
  reference=a;target=b;rangeKm=r;bearingDeg=br;relativeHeadingDeg=rh;speedDifferenceKnots=sd;
 }
 public static RelativeVesselGeometry between(Signal a,Signal b){
  if(a==null||b==null||a.layer!=Signal.Layer.SHIPS||b.layer!=Signal.Layer.SHIPS||!a.hasLocation()||!b.hasLocation())return null;
  double range=SatelliteMapView.distanceKm(a.latitude,a.longitude,b.latitude,b.longitude);
  double bearing=VesselPortGeometryValidation.bearing(a.latitude,a.longitude,b.latitude,b.longitude);
  VesselOrientation ao=VesselOrientation.from(a),bo=VesselOrientation.from(b);
  double relative=ao.known()&&bo.known()?RelativeVesselGeometryValidation.signedAngle(bo.degrees,ao.degrees):Double.NaN;
  VesselTelemetry at=VesselTelemetry.from(a),bt=VesselTelemetry.from(b);
  double speed=at!=null&&bt!=null&&at.hasSog()&&bt.hasSog()?RelativeVesselGeometryValidation.speedDifferenceKnots(at.sogMps,bt.sogMps):Double.NaN;
  return new RelativeVesselGeometry(a,b,range,bearing,relative,speed);
 }
 public String disclosure(){
  return String.format(Locale.US,"RANGE %.2f km • BEARING %03.0f° • REL HEADING %s • SPEED Δ %s • GEOMETRY ONLY — NOT COLLISION-RISK ASSESSMENT",
   rangeKm,bearingDeg,Double.isNaN(relativeHeadingDeg)?"UNKNOWN":String.format(Locale.US,"%+.0f°",relativeHeadingDeg),
   Double.isNaN(speedDifferenceKnots)?"UNKNOWN":String.format(Locale.US,"%+.1f kt",speedDifferenceKnots));
 }
}
