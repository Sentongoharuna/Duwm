package com.sentongoharuna.worldsituationroom;
public final class RelativeVesselGeometryValidation {
 private RelativeVesselGeometryValidation(){}
 public static double signedAngle(double target,double reference){
  if(Double.isNaN(target)||Double.isNaN(reference))return Double.NaN;
  return ((target-reference+540d)%360d)-180d;
 }
 public static double speedDifferenceKnots(double aMps,double bMps){
  if(Double.isNaN(aMps)||Double.isNaN(bMps))return Double.NaN;
  return (bMps-aMps)*1.943844d;
 }
}
