package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Canonical terminal registry with strict parent-port and source-record bindings. */
public final class PortTerminalRegistry {
 public enum Decision { ADDED, UPDATED, DUPLICATE, REJECTED, CONFLICT }
 public static final class Result {public final Decision decision;public final String reason;Result(Decision d,String r){decision=d;reason=r;}}
 private final LinkedHashMap<String,PortTerminalRecord> byId=new LinkedHashMap<>();
 private final LinkedHashMap<String,String> sourceToTerminal=new LinkedHashMap<>();
 public synchronized Result upsert(PortRecord parent,PortTerminalRecord t){
  if(parent==null||t==null||!t.valid()||!parent.portId.equals(t.portId))return new Result(Decision.REJECTED,"INVALID TERMINAL OR PARENT PORT");
  String sk=t.sourceId+"|"+t.sourceRecordId,prior=sourceToTerminal.get(sk);if(prior!=null&&!prior.equals(t.terminalId))return new Result(Decision.CONFLICT,"SOURCE RECORD ALREADY BOUND TO "+prior);
  PortTerminalRecord old=byId.get(t.terminalId);if(old!=null&&!old.portId.equals(t.portId))return new Result(Decision.CONFLICT,"TERMINAL ALREADY BOUND TO PORT "+old.portId);
  if(old!=null&&same(old,t)){sourceToTerminal.put(sk,t.terminalId);return new Result(Decision.DUPLICATE,"UNCHANGED");}
  byId.put(t.terminalId,t);sourceToTerminal.put(sk,t.terminalId);return new Result(old==null?Decision.ADDED:Decision.UPDATED,old==null?"ADDED":"UPDATED");
 }
 public synchronized PortTerminalRecord get(String id){return byId.get(id==null?"":id.trim());}
 public synchronized List<PortTerminalRecord> forPort(String portId){ArrayList<PortTerminalRecord>o=new ArrayList<>();for(PortTerminalRecord t:byId.values())if(t.portId.equals(portId))o.add(t);return Collections.unmodifiableList(o);}
 public synchronized List<PortTerminalRecord> search(String q){String x=q==null?"":q.trim().toLowerCase(Locale.US);ArrayList<PortTerminalRecord>o=new ArrayList<>();for(PortTerminalRecord t:byId.values())if(x.isEmpty()||t.name.toLowerCase(Locale.US).contains(x)||t.terminalId.toLowerCase(Locale.US).contains(x)||t.terminalType.toLowerCase(Locale.US).contains(x))o.add(t);return Collections.unmodifiableList(o);}
 public synchronized int size(){return byId.size();}
 private static boolean same(PortTerminalRecord a,PortTerminalRecord b){return a.portId.equals(b.portId)&&a.name.equals(b.name)&&a.terminalType.equals(b.terminalType)&&Double.compare(a.latitude,b.latitude)==0&&Double.compare(a.longitude,b.longitude)==0&&a.sourceId.equals(b.sourceId)&&a.sourceRecordId.equals(b.sourceRecordId)&&a.observedAtMs==b.observedAtMs;}
}
