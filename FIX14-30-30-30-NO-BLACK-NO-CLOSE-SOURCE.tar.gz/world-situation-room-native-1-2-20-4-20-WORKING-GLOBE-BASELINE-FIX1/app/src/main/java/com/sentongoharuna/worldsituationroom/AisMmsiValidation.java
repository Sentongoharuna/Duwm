package com.sentongoharuna.worldsituationroom;
public final class AisMmsiValidation {
 public enum Kind { SHIP_STATION, GROUP_CALL, COAST_STATION, SAR_AIRCRAFT, AIS_SART, MOB, EPIRB_AIS, UNKNOWN }
 public enum State { VALID, MISSING, FORMAT_INVALID, SENTINEL, MID_INVALID }
 public static final class Result {
  public final State state; public final Kind kind; public final String mmsi,mid;
  Result(State s,Kind k,String m,String d){state=s;kind=k;mmsi=m;mid=d;}
  public boolean accepted(){return state==State.VALID;}
  public String disclosure(){return accepted()?"MMSI "+mmsi+" • "+kind.name().replace('_',' ')+" • MID "+mid:"MMSI "+state.name().replace('_',' ');}
 }
 private AisMmsiValidation(){}
 public static Result validate(String raw){
  String m=raw==null?"":raw.trim();
  if(m.isEmpty())return new Result(State.MISSING,Kind.UNKNOWN,"","");
  if(!m.matches("\\d{9}"))return new Result(State.FORMAT_INVALID,Kind.UNKNOWN,m,"");
  if(m.equals("000000000")||m.equals("999999999"))return new Result(State.SENTINEL,Kind.UNKNOWN,m,"");
  Kind k=kind(m);String mid=mid(m,k);
  if(mid.isEmpty()||mid.equals("000")||mid.equals("999"))return new Result(State.MID_INVALID,k,m,mid);
  return new Result(State.VALID,k,m,mid);
 }
 private static Kind kind(String m){
  if(m.startsWith("111"))return Kind.SAR_AIRCRAFT;
  if(m.startsWith("970"))return Kind.AIS_SART;
  if(m.startsWith("972"))return Kind.MOB;
  if(m.startsWith("974"))return Kind.EPIRB_AIS;
  if(m.startsWith("00"))return Kind.COAST_STATION;
  if(m.startsWith("0"))return Kind.GROUP_CALL;
  return Kind.SHIP_STATION;
 }
 private static String mid(String m,Kind k){
  switch(k){
   case SHIP_STATION:return m.substring(0,3);
   case GROUP_CALL:return m.substring(1,4);
   case COAST_STATION:return m.substring(2,5);
   case SAR_AIRCRAFT:return m.substring(3,6);
   default:return ""; // device identities do not use the ordinary ship MID position
  }
 }
}
