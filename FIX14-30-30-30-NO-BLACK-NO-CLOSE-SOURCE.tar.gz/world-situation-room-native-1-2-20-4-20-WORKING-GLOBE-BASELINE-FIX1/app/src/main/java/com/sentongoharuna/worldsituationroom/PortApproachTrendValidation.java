package com.sentongoharuna.worldsituationroom;
public final class PortApproachTrendValidation{private PortApproachTrendValidation(){}
 public static PortApproachTrend.State classify(double previousKm,double currentKm){if(Double.isNaN(previousKm)||Double.isNaN(currentKm))return PortApproachTrend.State.INSUFFICIENT;double d=currentKm-previousKm;return Math.abs(d)<=0.10?PortApproachTrend.State.STABLE:d<0?PortApproachTrend.State.APPROACHING:PortApproachTrend.State.RECEDING;}
 public static double radialRateKph(double previousKm,double currentKm,long previousMs,long currentMs){if(currentMs<=previousMs)return Double.NaN;return (currentKm-previousKm)/((currentMs-previousMs)/3600000d);}
}