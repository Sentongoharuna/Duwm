package com.sentongoharuna.worldsituationroom;
/** Anchorage geometry + observed motion evidence. Slow speed alone never means anchored. */
public final class PortAnchoredVesselState {
 public enum State { ANCHORED_EVIDENCE, INSIDE_ANCHORAGE_MOVING, SLOW_OUTSIDE_ANCHORAGE, NOT_ANCHORED_EVIDENCE, INSUFFICIENT }
 public final String portId,vesselKey;public final State state;public final double speedMps,displacementM;public final long previousAtMs,currentAtMs;
 PortAnchoredVesselState(String p,String v,State s,double speed,double displacement,long a,long b){portId=p;vesselKey=v;state=s;speedMps=speed;displacementM=displacement;previousAtMs=a;currentAtMs=b;}
 public String disclosure(){return state+" • observed AIS + sourced anchorage geometry • not legal anchoring status";}
}
