package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Source-backed navigation channel. Width/depth are evidence, not inferred navigable limits. */
public final class PortNavigationChannelRecord {
 public final String channelId,portId,name,channelType,sourceId,sourceRecordId;
 public final List<HarbourBoundaryEvidence.Point> centerline;public final double widthM,reportedDepthM;public final long observedAtMs;
 public PortNavigationChannelRecord(String id,String p,String n,String type,List<HarbourBoundaryEvidence.Point> line,double width,double depth,String s,String sr,long t){
  channelId=c(id);portId=c(p);name=c(n);channelType=c(type);centerline=Collections.unmodifiableList(new ArrayList<>(line==null?Collections.emptyList():line));widthM=width;reportedDepthM=depth;sourceId=c(s);sourceRecordId=c(sr);observedAtMs=t;
 }
 public boolean valid(){if(channelId.isEmpty()||portId.isEmpty()||name.isEmpty()||sourceId.isEmpty()||sourceRecordId.isEmpty()||centerline.size()<2||(!Double.isNaN(widthM)&&widthM<0)||(!Double.isNaN(reportedDepthM)&&reportedDepthM<0))return false;for(HarbourBoundaryEvidence.Point x:centerline)if(Double.isNaN(x.latitude)||Double.isNaN(x.longitude)||x.latitude<-90||x.latitude>90||x.longitude<-180||x.longitude>180)return false;return true;}
 private static String c(String s){return s==null?"":s.trim();}
}
