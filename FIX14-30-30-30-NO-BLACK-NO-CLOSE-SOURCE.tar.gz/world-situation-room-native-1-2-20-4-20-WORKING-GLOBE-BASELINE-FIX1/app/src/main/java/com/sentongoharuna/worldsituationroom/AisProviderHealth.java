package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Operational feed-health diagnostics. NOT a truth score and NOT vessel confidence. */
public final class AisProviderHealth {
 public enum State { HEALTHY, DEGRADED, UNHEALTHY, UNKNOWN }
 public final String providerId;public final State state;public final List<String> reasons;
 private AisProviderHealth(String p,State s,List<String>r){providerId=p;state=s;reasons=Collections.unmodifiableList(new ArrayList<>(r));}
 public static AisProviderHealth assess(String providerId,AisProviderFreshness.Result fresh,AisLatencyRegistry.Stats lat,AisMessageRateRegistry.Rates rate,AisProviderRecovery.Transition transition){
  ArrayList<String> r=new ArrayList<>();if(fresh==null)return new AisProviderHealth(providerId,State.UNKNOWN,Collections.singletonList("NO FRESHNESS DATA"));
  int severity=0;
  switch(fresh.state){case SILENT:case STALE:severity=2;r.add("SOURCE "+fresh.state);break;case AGING:severity=Math.max(severity,1);r.add("SOURCE AGING");break;case UNKNOWN:severity=Math.max(severity,1);r.add("SOURCE FRESHNESS UNKNOWN");break;default:r.add("SOURCE LIVE");}
  if(lat!=null&&!Double.isNaN(lat.avgSourceToReceiveMs)&&lat.avgSourceToReceiveMs>120000d){severity=Math.max(severity,1);r.add("HIGH SOURCE LATENCY");}
  if(lat!=null&&!Double.isNaN(lat.avgReceiveToProcessMs)&&lat.avgReceiveToProcessMs>5000d){severity=Math.max(severity,1);r.add("HIGH PROCESSING LATENCY");}
  if(rate!=null){double total=rate.acceptedPerMin+rate.duplicatePerMin+rate.rejectedPerMin;
   if(total>0&&rate.rejectedPerMin/total>0.20d){severity=Math.max(severity,2);r.add("REJECTION RATE >20%");}
   else if(total>0&&rate.rejectedPerMin/total>0.05d){severity=Math.max(severity,1);r.add("REJECTION RATE >5%");}
   if(total>0&&rate.duplicatePerMin/total>0.50d){severity=Math.max(severity,1);r.add("DUPLICATE RATE >50%");}
  }
  if(transition!=null&&transition.event==AisProviderRecovery.Event.RECOVERED)r.add("RECENTLY RECOVERED");
  State s=severity>=2?State.UNHEALTHY:severity==1?State.DEGRADED:State.HEALTHY;
  return new AisProviderHealth(providerId,s,r);
 }
 public String disclosure(){return "PROVIDER HEALTH • "+providerId+" • "+state+" • OPERATIONAL FEED HEALTH, NOT TRUTH";}
}
