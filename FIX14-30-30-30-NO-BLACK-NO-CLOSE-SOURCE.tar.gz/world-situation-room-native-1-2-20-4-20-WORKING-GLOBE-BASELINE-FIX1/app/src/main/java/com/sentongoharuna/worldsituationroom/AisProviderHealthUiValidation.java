package com.sentongoharuna.worldsituationroom;
public final class AisProviderHealthUiValidation{private AisProviderHealthUiValidation(){}
 public static boolean detail(String x){return x!=null&&x.contains("HEALTH")&&x.contains("FRESHNESS")&&x.contains("CIRCUIT")&&x.contains("RECOVERY")&&x.contains("RATE/min")&&x.contains("SOURCE LAT")&&x.contains("LAST ERROR")&&x.contains("NOT TRUTH");}
}