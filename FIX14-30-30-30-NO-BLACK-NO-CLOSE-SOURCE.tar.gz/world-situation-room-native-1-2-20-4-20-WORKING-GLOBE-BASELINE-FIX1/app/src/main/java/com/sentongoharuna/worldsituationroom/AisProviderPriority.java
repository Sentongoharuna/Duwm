package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class AisProviderPriority{
 private final LinkedHashMap<String,Integer> ranks=new LinkedHashMap<>();
 public synchronized void set(String id,int rank){id=id==null?"":id.trim();if(id.isEmpty())throw new IllegalArgumentException("provider id");ranks.put(id,Math.max(0,rank));}
 public synchronized int rank(String id){Integer r=ranks.get(id==null?"":id.trim());return r==null?1000:r;}
 public synchronized Map<String,Integer> snapshot(){return Collections.unmodifiableMap(new LinkedHashMap<>(ranks));}
}