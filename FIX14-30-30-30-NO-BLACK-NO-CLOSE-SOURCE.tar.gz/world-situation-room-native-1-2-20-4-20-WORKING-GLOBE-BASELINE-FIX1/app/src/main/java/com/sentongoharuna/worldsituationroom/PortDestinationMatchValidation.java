package com.sentongoharuna.worldsituationroom;
public final class PortDestinationMatchValidation{private PortDestinationMatchValidation(){}
 public static boolean confidence(double x){return x>=0&&x<=1;}
 public static boolean confirmedIntent(boolean matched){return false;} // a text match never confirms vessel intent
 public static boolean ambiguous(double first,double second){return first>=0&&second>=0&&Math.abs(first-second)<0.05;}
}