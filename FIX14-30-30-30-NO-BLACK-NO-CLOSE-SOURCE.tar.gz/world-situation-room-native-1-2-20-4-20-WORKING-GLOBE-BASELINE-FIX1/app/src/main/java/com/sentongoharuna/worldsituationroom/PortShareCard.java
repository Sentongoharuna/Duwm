package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Share-card data model containing only evidence actually present in the intelligence sheet. */
public final class PortShareCard {
 public final String portId,title,subtitle,disclosure;public final List<String> facts;public final long generatedAtMs;
 PortShareCard(String id,String t,String s,List<String> f,String d,long at){portId=id;title=t;subtitle=s;facts=Collections.unmodifiableList(new ArrayList<>(f));disclosure=d;generatedAtMs=at;}
}
