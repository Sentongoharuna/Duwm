package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class PortDestinationMatcher {
 private PortDestinationMatcher(){}
 public static PortDestinationMatch match(PortRegistry registry,String raw){
  String text=raw==null?"":raw.trim();if(registry==null||text.isEmpty())return none(text);
  String compact=text.toUpperCase(Locale.US).replaceAll("[^A-Z0-9]","");
  if(compact.matches("[A-Z]{2}[A-Z0-9]{3}")){PortRecord p=registry.byUnLocode(compact);if(p!=null)return hit(text,p,registry.unLocodeFor(p.portId),PortDestinationMatch.Method.EXACT_LOCODE,1.0,false);}
  String norm=normalize(text);ArrayList<Scored> scores=new ArrayList<>();
  for(PortRecord p:registry.all()){
   String pn=normalize(p.name);if(pn.equals(norm))scores.add(new Scored(p,PortDestinationMatch.Method.EXACT_NAME,0.98));
   else {String loose=loose(p.name);if(!loose.isEmpty()&&loose.equals(loose(text)))scores.add(new Scored(p,PortDestinationMatch.Method.NORMALIZED_NAME,0.90));
   else {double overlap=tokenOverlap(norm,pn);if(overlap>=0.67)scores.add(new Scored(p,PortDestinationMatch.Method.TOKEN_OVERLAP,Math.min(0.85,0.55+0.30*overlap)));}}
  }
  if(scores.isEmpty())return none(text);scores.sort((a,b)->Double.compare(b.score,a.score));Scored top=scores.get(0);boolean ambiguous=scores.size()>1&&Math.abs(top.score-scores.get(1).score)<0.05;
  return hit(text,top.port,registry.unLocodeFor(top.port.portId),top.method,top.score,ambiguous);
 }
 private static PortDestinationMatch hit(String t,PortRecord p,String code,PortDestinationMatch.Method m,double c,boolean a){return new PortDestinationMatch(t,p.portId,p.name,code,m,c,a);}
 private static PortDestinationMatch none(String t){return new PortDestinationMatch(t,"","","",PortDestinationMatch.Method.NONE,0,false);}
 private static String normalize(String s){return s==null?"":s.toUpperCase(Locale.US).replaceAll("[^A-Z0-9]+"," ").trim().replaceAll("\\s+"," ");}
 private static String loose(String s){return normalize(s).replaceAll("\\b(PORT|HARBOUR|HARBOR|TERMINAL)\\b","").trim().replaceAll("\\s+"," ");}
 private static double tokenOverlap(String a,String b){if(a.isEmpty()||b.isEmpty())return 0;Set<String>x=new HashSet<>(Arrays.asList(a.split(" "))),y=new HashSet<>(Arrays.asList(b.split(" ")));Set<String>i=new HashSet<>(x);i.retainAll(y);Set<String>u=new HashSet<>(x);u.addAll(y);return u.isEmpty()?0:(double)i.size()/u.size();}
 private static final class Scored{final PortRecord port;final PortDestinationMatch.Method method;final double score;Scored(PortRecord p,PortDestinationMatch.Method m,double s){port=p;method=m;score=s;}}
}
