package com.sentongoharuna.worldsituationroom;
import java.util.List;
public interface AisProviderAdapter {
 String providerId();
 List<AisProviderRecord> parse(String payload,long receivedAtMs) throws Exception;
}
