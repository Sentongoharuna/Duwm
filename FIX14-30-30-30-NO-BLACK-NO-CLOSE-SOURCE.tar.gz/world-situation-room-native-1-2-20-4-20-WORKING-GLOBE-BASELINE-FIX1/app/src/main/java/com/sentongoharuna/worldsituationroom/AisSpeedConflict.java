package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Detects near-simultaneous cross-provider SOG disagreement. Original measurements remain unchanged. */
public final class AisSpeedConflict {
 public enum State { NONE, CONFLICT, INSUFFICIENT }
 public static final class Result {
  public final State state;public final double maxDifferenceMps,maxDifferenceKnots;public final String providerA,providerB;
  Result(State s,double d,String a,String b){state=s;maxDifferenceMps=d;maxDifferenceKnots=Double.isNaN(d)?Double.NaN:d*1.943844d;providerA=a;providerB=b;}
  public String disclosure(){return state==State.CONFLICT?String.format(Locale.US,"SPEED CONFLICT • %.1f kt • %s ↔ %s • ORIGINAL SOG RETAINED",maxDifferenceKnots,providerA,providerB):state.name();}
 }
 private AisSpeedConflict(){}
 public static Result detect(List<NormalizedAisRecord> records){
  if(records==null||records.size()<2)return new Result(State.INSUFFICIENT,Double.NaN,"","");
  double max=0d;String pa="",pb="";boolean compared=false;
  for(int i=0;i<records.size();i++){NormalizedAisRecord a=records.get(i);if(a==null||!a.hasSog())continue;
   for(int j=i+1;j<records.size();j++){NormalizedAisRecord b=records.get(j);if(b==null||!b.hasSog()||a.providerId.equals(b.providerId))continue;
    if(Math.abs(a.providerTimestampMs-b.providerTimestampMs)>120000L)continue;
    compared=true;double d=Math.abs(a.sogMps-b.sogMps);if(d>max){max=d;pa=a.providerId;pb=b.providerId;}
   }}
  if(!compared)return new Result(State.INSUFFICIENT,Double.NaN,"","");
  // 3 m/s (~5.83 kt) is a material provider disagreement threshold, not a safety threshold.
  return new Result(max>3d?State.CONFLICT:State.NONE,max,pa,pb);
 }
}
