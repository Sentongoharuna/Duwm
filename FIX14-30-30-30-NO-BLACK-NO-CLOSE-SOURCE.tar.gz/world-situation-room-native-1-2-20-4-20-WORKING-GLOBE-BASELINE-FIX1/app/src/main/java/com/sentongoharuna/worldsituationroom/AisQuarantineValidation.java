package com.sentongoharuna.worldsituationroom;
public final class AisQuarantineValidation{private AisQuarantineValidation(){}
 public static boolean shouldQuarantine(boolean rawValid,boolean normalizedAccepted){return !rawValid||!normalizedAccepted;}
 public static int boundedSize(int existing,int added,int max){return Math.min(max,Math.max(0,existing)+Math.max(0,added));}
}