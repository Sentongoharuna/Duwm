package com.sentongoharuna.worldsituationroom;
/** Builds a deterministic overview target from the loaded canonical port point. */
public final class PortOverviewCameraEngine {
 private static final double DEFAULT_ALTITUDE_KM=18.0,DEFAULT_HEADING_DEG=0.0,DEFAULT_PITCH_DEG=45.0;
 private PortOverviewCameraEngine(){}
 public static PortOverviewCameraTarget target(PortRecord p,long nowMs){
  if(p==null||!p.hasLocation()||nowMs<=0)return null;
  return new PortOverviewCameraTarget(p.portId,p.name,p.latitude,p.longitude,DEFAULT_ALTITUDE_KM,DEFAULT_HEADING_DEG,DEFAULT_PITCH_DEG,nowMs);
 }
}
