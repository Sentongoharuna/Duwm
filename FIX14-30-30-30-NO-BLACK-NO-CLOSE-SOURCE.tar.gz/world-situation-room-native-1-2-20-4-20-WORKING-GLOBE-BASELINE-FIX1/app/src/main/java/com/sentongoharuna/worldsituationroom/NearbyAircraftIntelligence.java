package com.sentongoharuna.worldsituationroom;
import java.util.ArrayList;import java.util.Collections;import java.util.Comparator;import java.util.List;import java.util.Locale;

public final class NearbyAircraftIntelligence {
 public static final class Entry {
  public final Signal signal; public final double distanceKm; public final RelativeAircraftGeometry geometry;
  Entry(Signal s,double d,RelativeAircraftGeometry g){signal=s;distanceKm=d;geometry=g;}
  public String label(){
   AircraftTelemetry t=AircraftTelemetry.from(signal);
   String id=t!=null&&!t.callsign.isEmpty()?t.callsign:t!=null&&!t.registration.isEmpty()?t.registration:signal.title;
   String alt=t==null?"ALT UNKNOWN":AircraftAltitudeIntelligence.from(signal).altitudeDisclosure();
   String vertical=geometry!=null&&geometry.altitudeDifferenceKnown?String.format(Locale.US," • ΔALT %+.0fm",geometry.altitudeDifferenceM):" • ΔALT UNKNOWN";
   return String.format(Locale.US,"%.1f km • %s • %s%s • %s",distanceKm,id,alt,vertical,TruthEnforcement.label(signal));
  }
 }
 private NearbyAircraftIntelligence(){}
 public static List<Entry> find(Signal selected,List<Signal> flights,double radiusKm){
  ArrayList<Entry> out=new ArrayList<>();
  if(selected==null||selected.layer!=Signal.Layer.FLIGHTS||!selected.hasLocation()||flights==null)return out;
  for(Signal other:flights){
   if(other==null||other==selected||other.layer!=Signal.Layer.FLIGHTS||!other.hasLocation())continue;
   if(selected.canonicalId!=null&&selected.canonicalId.equals(other.canonicalId))continue;
   if(AircraftCanonicalIdentity.sameAircraft(selected,other))continue;
   double d=SatelliteMapView.distanceKm(selected.latitude,selected.longitude,other.latitude,other.longitude);
   if(!Double.isNaN(d)&&d<=radiusKm)out.add(new Entry(other,d,RelativeAircraftGeometry.between(selected,other)));
  }
  Collections.sort(out,Comparator.comparingDouble(e->e.distanceKm));
  return out;
 }
}
