package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Source-backed descriptive restriction. Not a navigation clearance or legal interpretation. */
public final class PortRestrictionRecord {
 public final String restrictionId,portId,title,restrictionType,description,affectedObjectType,affectedObjectId,sourceId,sourceRecordId;
 public final long effectiveFromMs,effectiveUntilMs,observedAtMs;public final List<HarbourBoundaryEvidence.Point> area;
 public PortRestrictionRecord(String id,String p,String title,String type,String desc,String objectType,String objectId,long from,long until,List<HarbourBoundaryEvidence.Point> polygon,String source,String sourceRecord,long observed){
  restrictionId=c(id);portId=c(p);this.title=c(title);restrictionType=c(type);description=c(desc);affectedObjectType=c(objectType);affectedObjectId=c(objectId);effectiveFromMs=from;effectiveUntilMs=until;area=Collections.unmodifiableList(new ArrayList<>(polygon==null?Collections.emptyList():polygon));sourceId=c(source);sourceRecordId=c(sourceRecord);observedAtMs=observed;
 }
 public boolean valid(){if(restrictionId.isEmpty()||portId.isEmpty()||title.isEmpty()||sourceId.isEmpty()||sourceRecordId.isEmpty()||effectiveFromMs<0||effectiveUntilMs<0||(effectiveUntilMs>0&&effectiveFromMs>0&&effectiveUntilMs<effectiveFromMs))return false;if(!area.isEmpty()&&area.size()<3)return false;for(HarbourBoundaryEvidence.Point x:area)if(Double.isNaN(x.latitude)||Double.isNaN(x.longitude)||x.latitude<-90||x.latitude>90||x.longitude<-180||x.longitude>180)return false;return true;}
 public boolean effectiveAt(long t){return t>=0&&(effectiveFromMs==0||t>=effectiveFromMs)&&(effectiveUntilMs==0||t<=effectiveUntilMs);}
 public boolean contains(double lat,double lon){return !area.isEmpty()&&HarbourBoundaryRegistry.inside(area,lat,lon);}
 private static String c(String s){return s==null?"":s.trim();}
}
