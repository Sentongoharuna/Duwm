package com.sentongoharuna.worldsituationroom;
public final class AisMultiProviderValidation {
 private AisMultiProviderValidation(){}
 public static boolean providerId(String s){return s!=null&&!s.trim().isEmpty()&&s.trim().length()<=80;}
 public static boolean recordId(String s){return s!=null&&!s.trim().isEmpty()&&s.trim().length()<=160;}
 public static boolean timestamp(long provider,long received){return provider>0L&&received>0L&&provider<=received+300000L;}
}
