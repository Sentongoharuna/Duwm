package com.sentongoharuna.worldsituationroom;
public final class NetworkDegradationPolicy {
 private NetworkDegradationPolicy(){}
 public static boolean retainLastGood(FeedStatus status){
  return status!=null&&(status.state==FeedStatus.State.OFFLINE
      ||status.state==FeedStatus.State.DELAYED||status.state==FeedStatus.State.CACHED
      ||status.state==FeedStatus.State.KEY_REQUIRED);
 }
 public static boolean mayReplaceWithEmpty(FeedStatus status){
  return status!=null&&(status.state==FeedStatus.State.LIVE||status.state==FeedStatus.State.READY);
 }
 public static String disclosure(FeedStatus status){
  if(status==null)return "UNKNOWN";
  switch(status.state){
   case OFFLINE:return "OFFLINE • LAST GOOD MAY BE RETAINED";
   case DELAYED:return "DELAYED • LAST GOOD MAY BE RETAINED";
   case CACHED:return "CACHED • NOT A NEW LIVE OBSERVATION";
   case KEY_REQUIRED:return "SOURCE KEY REQUIRED • LAST GOOD MAY BE RETAINED";
   case LIVE:return "LIVE PROVIDER STATE";
   case READY:return "READY PROVIDER STATE";
   default:return "LOADING";
  }
 }
}
