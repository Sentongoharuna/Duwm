package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class PortAnchorageRegistry {
 public enum Decision { ADDED, UPDATED, DUPLICATE, REJECTED, CONFLICT }
 public static final class Result {public final Decision decision;public final String reason;Result(Decision d,String r){decision=d;reason=r;}}
 private final LinkedHashMap<String,PortAnchorageRecord> byId=new LinkedHashMap<>();private final LinkedHashMap<String,String> sourceBinding=new LinkedHashMap<>();
 public synchronized Result upsert(PortRecord parent,PortAnchorageRecord a){
  if(parent==null||a==null||!a.valid()||!parent.portId.equals(a.portId))return new Result(Decision.REJECTED,"INVALID ANCHORAGE OR PARENT PORT");
  String sk=a.sourceId+"|"+a.sourceRecordId,prior=sourceBinding.get(sk);if(prior!=null&&!prior.equals(a.anchorageId))return new Result(Decision.CONFLICT,"SOURCE RECORD ALREADY BOUND TO "+prior);
  PortAnchorageRecord old=byId.get(a.anchorageId);if(old!=null&&!old.portId.equals(a.portId))return new Result(Decision.CONFLICT,"ANCHORAGE ALREADY BOUND TO PORT "+old.portId);
  if(old!=null&&same(old,a)){sourceBinding.put(sk,a.anchorageId);return new Result(Decision.DUPLICATE,"UNCHANGED");}
  byId.put(a.anchorageId,a);sourceBinding.put(sk,a.anchorageId);return new Result(old==null?Decision.ADDED:Decision.UPDATED,old==null?"ADDED":"UPDATED");
 }
 public synchronized PortAnchorageRecord get(String id){return byId.get(id==null?"":id.trim());}
 public synchronized List<PortAnchorageRecord> forPort(String p){ArrayList<PortAnchorageRecord>o=new ArrayList<>();for(PortAnchorageRecord a:byId.values())if(a.portId.equals(p))o.add(a);return Collections.unmodifiableList(o);}
 public synchronized List<PortAnchorageRecord> containing(String p,double lat,double lon){ArrayList<PortAnchorageRecord>o=new ArrayList<>();for(PortAnchorageRecord a:forPort(p))if(a.contains(lat,lon))o.add(a);return Collections.unmodifiableList(o);}
 public synchronized int size(){return byId.size();}
 private static boolean same(PortAnchorageRecord a,PortAnchorageRecord b){if(!a.portId.equals(b.portId)||!a.name.equals(b.name)||Double.compare(a.latitude,b.latitude)!=0||Double.compare(a.longitude,b.longitude)!=0||a.polygon.size()!=b.polygon.size()||a.observedAtMs!=b.observedAtMs)return false;for(int i=0;i<a.polygon.size();i++){HarbourBoundaryEvidence.Point x=a.polygon.get(i),y=b.polygon.get(i);if(Double.compare(x.latitude,y.latitude)!=0||Double.compare(x.longitude,y.longitude)!=0)return false;}return true;}
}
