package com.sentongoharuna.worldsituationroom;
public final class AisProviderHealthValidation{private AisProviderHealthValidation(){}
 public static int severity(boolean staleOrSilent,boolean aging,double rejectRatio,double duplicateRatio,double sourceLatencyMs,double processLatencyMs){
  int s=staleOrSilent?2:aging?1:0;if(rejectRatio>0.20)s=Math.max(s,2);else if(rejectRatio>0.05)s=Math.max(s,1);
  if(duplicateRatio>0.50||sourceLatencyMs>120000||processLatencyMs>5000)s=Math.max(s,1);return s;
 }
}