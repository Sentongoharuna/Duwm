package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Canonical berth registry with strict port/optional-terminal parentage. */
public final class PortBerthRegistry {
 public enum Decision { ADDED, UPDATED, DUPLICATE, REJECTED, CONFLICT }
 public static final class Result {public final Decision decision;public final String reason;Result(Decision d,String r){decision=d;reason=r;}}
 private final LinkedHashMap<String,PortBerthRecord> byId=new LinkedHashMap<>();private final LinkedHashMap<String,String> sourceBinding=new LinkedHashMap<>();
 public synchronized Result upsert(PortRecord port,PortTerminalRecord terminal,PortBerthRecord b){
  if(port==null||b==null||!b.valid()||!port.portId.equals(b.portId))return new Result(Decision.REJECTED,"INVALID BERTH OR PARENT PORT");
  if(!b.terminalId.isEmpty()&&(terminal==null||!terminal.portId.equals(b.portId)))return new Result(Decision.REJECTED,"INVALID TERMINAL PARENT");
  String sk=b.sourceId+"|"+b.sourceRecordId,prior=sourceBinding.get(sk);if(prior!=null&&!prior.equals(b.berthId))return new Result(Decision.CONFLICT,"SOURCE RECORD ALREADY BOUND TO "+prior);
  PortBerthRecord old=byId.get(b.berthId);if(old!=null&&(!old.portId.equals(b.portId)||!old.terminalId.equals(b.terminalId)))return new Result(Decision.CONFLICT,"BERTH PARENTAGE CHANGED");
  if(old!=null&&same(old,b)){sourceBinding.put(sk,b.berthId);return new Result(Decision.DUPLICATE,"UNCHANGED");}
  byId.put(b.berthId,b);sourceBinding.put(sk,b.berthId);return new Result(old==null?Decision.ADDED:Decision.UPDATED,old==null?"ADDED":"UPDATED");
 }
 public synchronized PortBerthRecord get(String id){return byId.get(id==null?"":id.trim());}
 public synchronized List<PortBerthRecord> forPort(String p){ArrayList<PortBerthRecord>o=new ArrayList<>();for(PortBerthRecord b:byId.values())if(b.portId.equals(p))o.add(b);return Collections.unmodifiableList(o);}
 public synchronized List<PortBerthRecord> forTerminal(String t){ArrayList<PortBerthRecord>o=new ArrayList<>();for(PortBerthRecord b:byId.values())if(b.terminalId.equals(t))o.add(b);return Collections.unmodifiableList(o);}
 public synchronized List<PortBerthRecord> search(String q){String x=q==null?"":q.trim().toLowerCase(Locale.US);ArrayList<PortBerthRecord>o=new ArrayList<>();for(PortBerthRecord b:byId.values())if(x.isEmpty()||b.name.toLowerCase(Locale.US).contains(x)||b.berthId.toLowerCase(Locale.US).contains(x)||b.berthType.toLowerCase(Locale.US).contains(x))o.add(b);return Collections.unmodifiableList(o);}
 public synchronized int size(){return byId.size();}
 private static boolean same(PortBerthRecord a,PortBerthRecord b){return a.portId.equals(b.portId)&&a.terminalId.equals(b.terminalId)&&a.name.equals(b.name)&&a.berthType.equals(b.berthType)&&Double.compare(a.latitude,b.latitude)==0&&Double.compare(a.longitude,b.longitude)==0&&Double.compare(a.lengthM,b.lengthM)==0&&Double.compare(a.depthM,b.depthM)==0&&a.observedAtMs==b.observedAtMs;}
}
