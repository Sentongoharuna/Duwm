package com.sentongoharuna.worldsituationroom;
import java.nio.charset.StandardCharsets;import java.security.MessageDigest;import java.util.*;
/** Immutable raw-provider payload evidence captured before parsing/normalization. */
public final class AisRawMessageEvidence {
 public final String providerId,payloadSha256,payload;public final long receivedAtMs;public final int utf8Bytes;
 AisRawMessageEvidence(String p,String x,long t){providerId=p==null?"":p;payload=x==null?"":x;receivedAtMs=t;byte[] b=payload.getBytes(StandardCharsets.UTF_8);utf8Bytes=b.length;payloadSha256=sha(b);}
 private static String sha(byte[]b){try{MessageDigest d=MessageDigest.getInstance("SHA-256");StringBuilder s=new StringBuilder();for(byte x:d.digest(b))s.append(String.format("%02x",x));return s.toString();}catch(Exception e){throw new IllegalStateException(e);}}
}
