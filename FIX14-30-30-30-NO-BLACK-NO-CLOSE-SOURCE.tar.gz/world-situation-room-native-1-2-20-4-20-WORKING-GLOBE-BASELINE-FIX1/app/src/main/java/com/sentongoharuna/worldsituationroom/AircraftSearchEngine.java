package com.sentongoharuna.worldsituationroom;
import java.util.ArrayList;import java.util.Collections;import java.util.Comparator;import java.util.List;import java.util.Locale;
public final class AircraftSearchEngine {
 public enum MatchBasis { ICAO24, REGISTRATION, CALLSIGN, FLIGHT_NUMBER, AIRCRAFT_TYPE, TITLE }
 public static final class Result {
  public final Signal signal;public final MatchBasis basis;public final int score;
  Result(Signal s,MatchBasis b,int score){signal=s;basis=b;this.score=score;}
  public String label(){
   AircraftTelemetry t=AircraftTelemetry.from(signal);
   String id=t!=null&&!t.callsign.isEmpty()?t.callsign:t!=null&&!t.registration.isEmpty()?t.registration:signal.title;
   return id+" • MATCH "+basis.name().replace('_',' ')+" • "+TruthEnforcement.label(signal);
  }
 }
 private AircraftSearchEngine(){}
 public static List<Result> search(String query,List<Signal> flights){
  ArrayList<Result> out=new ArrayList<>();if(query==null||flights==null)return out;
  String q=norm(query);if(q.isEmpty())return out;
  for(Signal s:flights){
   if(s==null||s.layer!=Signal.Layer.FLIGHTS)continue;
   AircraftTelemetry t=AircraftTelemetry.from(s);if(t==null)continue;
   Result best=null;
   best=better(best,match(s,q,t.icao24,MatchBasis.ICAO24,100));
   best=better(best,match(s,q,t.registration,MatchBasis.REGISTRATION,95));
   best=better(best,match(s,q,t.callsign,MatchBasis.CALLSIGN,90));
   best=better(best,match(s,q,t.flightNumber,MatchBasis.FLIGHT_NUMBER,85));
   best=better(best,match(s,q,t.aircraftType,MatchBasis.AIRCRAFT_TYPE,70));
   best=better(best,match(s,q,s.title,MatchBasis.TITLE,50));
   if(best!=null)out.add(best);
  }
  Collections.sort(out,Comparator.comparingInt((Result r)->r.score).reversed());
  return out;
 }
 private static Result match(Signal s,String q,String value,MatchBasis b,int base){
  String v=norm(value);if(v.isEmpty())return null;
  if(v.equals(q))return new Result(s,b,base+20);
  if(v.startsWith(q))return new Result(s,b,base+10);
  if(v.contains(q))return new Result(s,b,base);
  return null;
 }
 private static Result better(Result a,Result b){return b==null?a:a==null||b.score>a.score?b:a;}
 private static String norm(String v){return v==null?"":v.trim().toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]","");}
}
