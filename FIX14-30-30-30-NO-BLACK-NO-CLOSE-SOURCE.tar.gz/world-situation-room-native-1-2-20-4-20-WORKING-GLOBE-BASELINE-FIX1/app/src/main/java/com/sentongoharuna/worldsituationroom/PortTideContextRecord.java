package com.sentongoharuna.worldsituationroom;
/** Source-attributed tide/water-level context. Observation and prediction remain distinct. */
public final class PortTideContextRecord {
 public enum Kind { OBSERVATION, PREDICTION }
 public final String tideId,portId,stationId,datum,eventType,sourceId,sourceRecordId;public final Kind kind;
 public final double waterLevelM;public final long eventAtMs,issuedAtMs,receivedAtMs;
 public PortTideContextRecord(String id,String p,String station,String datum,Kind k,String event,double level,long at,long issued,long received,String source,String sr){
  tideId=c(id);portId=c(p);stationId=c(station);this.datum=c(datum);kind=k;eventType=c(event);waterLevelM=level;eventAtMs=at;issuedAtMs=issued;receivedAtMs=received;sourceId=c(source);sourceRecordId=c(sr);
 }
 public boolean valid(){return !tideId.isEmpty()&&!portId.isEmpty()&&!stationId.isEmpty()&&!datum.isEmpty()&&kind!=null&&!sourceId.isEmpty()&&!sourceRecordId.isEmpty()&&!Double.isNaN(waterLevelM)&&!Double.isInfinite(waterLevelM)&&eventAtMs>0&&issuedAtMs>=0&&receivedAtMs>=0;}
 private static String c(String s){return s==null?"":s.trim();}
}
