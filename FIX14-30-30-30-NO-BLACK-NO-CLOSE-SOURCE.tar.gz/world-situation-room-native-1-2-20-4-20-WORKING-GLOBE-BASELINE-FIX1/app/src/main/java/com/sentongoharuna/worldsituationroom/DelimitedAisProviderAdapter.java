package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Configurable adapter for provider payloads formatted as one key=value record per line. */
public final class DelimitedAisProviderAdapter implements AisProviderAdapter {
 private final String id,name;private final AisProviderFieldMap fieldMap;
 public DelimitedAisProviderAdapter(String id,String name,AisProviderFieldMap map){
  this.id=clean(id);this.name=clean(name);fieldMap=map;
  if(this.id.isEmpty()||fieldMap==null)throw new IllegalArgumentException("adapter config");
 }
 @Override public String providerId(){return id;}
 @Override public List<AisProviderRecord> parse(String payload,long receivedAtMs){
  ArrayList<AisProviderRecord> out=new ArrayList<>();if(payload==null||payload.trim().isEmpty())return out;
  String[] lines=payload.split("\\r?\\n");
  for(String line:lines){if(line.trim().isEmpty())continue;LinkedHashMap<String,String> raw=new LinkedHashMap<>();
   for(String part:line.split("\\|")){int x=part.indexOf('=');if(x>0)raw.put(part.substring(0,x).trim(),part.substring(x+1).trim());}
   Map<String,String> canonical=fieldMap.extract(raw);
   String record=first(canonical.get("record_id"),raw.get("record_id"));
   long ts=parseLong(first(canonical.get("timestamp_ms"),raw.get("timestamp_ms")));
   LinkedHashMap<String,String> preserved=new LinkedHashMap<>(raw);
   for(Map.Entry<String,String> e:canonical.entrySet())preserved.put("canonical."+e.getKey(),e.getValue());
   out.add(new AisProviderRecord(id,name,record,ts,receivedAtMs,preserved));
  }return out;
 }
 private static long parseLong(String s){try{return Long.parseLong(clean(s));}catch(Exception e){return 0L;}}
 private static String first(String a,String b){return !clean(a).isEmpty()?clean(a):clean(b);}
 private static String clean(String s){return s==null?"":s.trim();}
}
