package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Bounded raw-message evidence store. Raw payload is not rewritten by downstream parsing. */
public final class AisRawMessageStore {
 private static final int MAX_MESSAGES=1000;private static final long MAX_BYTES=8L*1024L*1024L;
 private final ArrayDeque<AisRawMessageEvidence> q=new ArrayDeque<>();private long bytes;
 public synchronized AisRawMessageEvidence preserve(String providerId,String payload,long receivedAtMs){
  AisRawMessageEvidence e=new AisRawMessageEvidence(providerId,payload,receivedAtMs);q.addLast(e);bytes+=e.utf8Bytes;trim();return e;
 }
 public synchronized List<AisRawMessageEvidence> snapshot(){return Collections.unmodifiableList(new ArrayList<>(q));}
 public synchronized int size(){return q.size();}public synchronized long retainedBytes(){return bytes;}
 public synchronized AisRawMessageEvidence findBySha256(String sha){if(sha==null)return null;for(AisRawMessageEvidence e:q)if(e.payloadSha256.equalsIgnoreCase(sha))return e;return null;}
 private void trim(){while(q.size()>MAX_MESSAGES||bytes>MAX_BYTES){AisRawMessageEvidence e=q.removeFirst();bytes-=e.utf8Bytes;}}
}
