package com.sentongoharuna.worldsituationroom;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
public final class Fix12MaritimeRelease {
 public static final String RELEASE="FIX12.30/30.30";
 private Fix12MaritimeRelease(){}
 public static List<String> capabilities(){
  return Collections.unmodifiableList(Arrays.asList(
   "CANONICAL_VESSEL_IDENTITY","REAL_VESSEL_TELEMETRY","MARITIME_MOVEMENT_2","HEADING_COG_ORIENTATION",
   "SPEED_INTELLIGENCE","RATE_OF_TURN","OBSERVED_AIS_TRAIL","HISTORICAL_FIX_INSPECTION",
   "VESSEL_INTELLIGENCE_2","AIS_NAV_STATUS","AIS_DESTINATION_ETA","PORT_OBJECTS","VESSEL_PORT_PROXIMITY",
   "OPERATIONAL_STATE","VESSEL_FOLLOW_2","VESSEL_CHASE","VESSEL_ORBIT","NEARBY_VESSELS",
   "RELATIVE_GEOMETRY","CPA_TCPA","MARITIME_WEATHER","MARITIME_SEARCH_2","PERSISTENT_WATCHLIST",
   "MEANINGFUL_CHANGES","TIMELINE_REPLAY","VESSEL_SHARE_CARD","PERFORMANCE_GOVERNOR","TRUTH_AUDIT"
  ));
 }
 public static boolean complete(){return capabilities().size()==28;}
}
