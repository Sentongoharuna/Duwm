package com.sentongoharuna.worldsituationroom;
/** Source-backed port intelligence. No berth/terminal facts are invented. */
public final class PortIntelligence {
 public final Signal signal;public final String name,unlocode,country,terminal,anchorage,berth,weather;
 private PortIntelligence(Signal s,String n,String u,String c,String t,String a,String b,String w){signal=s;name=n;unlocode=u;country=c;terminal=t;anchorage=a;berth=b;weather=w;}
 public static PortIntelligence from(Signal s){
  if(s==null||s.layer!=Signal.Layer.INFRASTRUCTURE)return null;
  String kind=fact(s,"INFRASTRUCTURE TYPE","TYPE","FACILITY TYPE","CATEGORY").toUpperCase();
  String code=fact(s,"UN/LOCODE","UNLOCODE","PORT CODE");
  boolean port=kind.contains("PORT")||kind.contains("HARBOUR")||kind.contains("HARBOR")||!code.isEmpty();
  if(!port)return null;
  return new PortIntelligence(s,first(fact(s,"PORT NAME","NAME"),s.title),code,
   fact(s,"COUNTRY","COUNTRY NAME"),fact(s,"TERMINAL","TERMINALS"),
   fact(s,"ANCHORAGE","ANCHORAGES"),fact(s,"BERTH","BERTHS"),fact(s,"WEATHER","PORT WEATHER"));
 }
 public String compact(){return (name.isEmpty()?"PORT":name)+" • "+(unlocode.isEmpty()?"UN/LOCODE UNKNOWN":unlocode)+" • "+(country.isEmpty()?"COUNTRY UNKNOWN":country);}
 private static String fact(Signal s,String...ks){for(String k:ks){String v=s.facts.get(k);if(v!=null&&!v.trim().isEmpty())return v.trim();}return "";}
 private static String first(String a,String b){return a==null||a.trim().isEmpty()?(b==null?"":b.trim()):a.trim();}
}
