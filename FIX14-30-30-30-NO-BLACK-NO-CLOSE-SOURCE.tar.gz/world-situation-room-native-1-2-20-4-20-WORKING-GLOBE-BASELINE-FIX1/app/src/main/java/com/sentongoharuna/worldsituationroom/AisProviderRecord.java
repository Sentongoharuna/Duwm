package com.sentongoharuna.worldsituationroom;
import java.util.Collections;import java.util.LinkedHashMap;import java.util.Map;
public final class AisProviderRecord {
 public final String providerId,providerName,providerRecordId;
 public final long providerTimestampMs,receivedAtMs;
 public final Map<String,String> fields;
 public AisProviderRecord(String id,String name,String record,long pt,long rt,Map<String,String> f){
  providerId=clean(id);providerName=clean(name);providerRecordId=clean(record);
  providerTimestampMs=pt;receivedAtMs=rt;
  fields=Collections.unmodifiableMap(new LinkedHashMap<>(f==null?Collections.emptyMap():f));
 }
 public boolean valid(){return !providerId.isEmpty()&&!providerRecordId.isEmpty()&&providerTimestampMs>0L;}
 private static String clean(String s){return s==null?"":s.trim();}
}
