package com.sentongoharuna.worldsituationroom;
import java.util.LinkedHashMap;import java.util.Map;
public final class AircraftVerticalHistory {
 public static final class Sample { public final double altitudeM; public final long timeMs;
  Sample(double a,long t){altitudeM=a;timeMs=t;} }
 private final Map<String,Sample> samples=new LinkedHashMap<>();
 public synchronized Sample previous(String key){return samples.get(key);}
 public synchronized void observe(String key,double altitude,long time){
  if(key==null||key.isEmpty()||Double.isNaN(altitude)||time<=0)return;
  samples.put(key,new Sample(altitude,time));
  while(samples.size()>5000){String first=samples.keySet().iterator().next();samples.remove(first);}
 }
}
