package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class PortIntelligenceSheetBuilder {
 private PortIntelligenceSheetBuilder(){}
 public static PortIntelligenceSheet build(PortRegistry r,String portId,long now){
  if(r==null||now<=0)return null;PortRecord p=r.get(portId);if(p==null)return null;
  List<PortTrafficCounters> h=r.trafficHistory(portId);PortTrafficCounters latest=h.isEmpty()?null:h.get(h.size()-1);
  return new PortIntelligenceSheet(p,r.unLocodeFor(portId),r.isPortFollowed(portId),
   r.terminalsForPort(portId).size(),r.anchoragesForPort(portId).size(),r.berthsForPort(portId).size(),r.approachesForPort(portId).size(),
   r.entrancesForPort(portId).size(),r.navigationChannelsForPort(portId).size(),r.restrictionsForPort(portId).size(),r.draughtContextForPort(portId).size(),
   r.weatherForPort(portId,null).size(),r.tideForPort(portId,null).size(),h.size(),latest,
   r.latestWeather(portId,PortWeatherContextRecord.Kind.OBSERVATION),r.latestWeather(portId,PortWeatherContextRecord.Kind.FORECAST),
   r.nearestTide(portId,PortTideContextRecord.Kind.OBSERVATION,now),r.nearestTide(portId,PortTideContextRecord.Kind.PREDICTION,now),now);
 }
}