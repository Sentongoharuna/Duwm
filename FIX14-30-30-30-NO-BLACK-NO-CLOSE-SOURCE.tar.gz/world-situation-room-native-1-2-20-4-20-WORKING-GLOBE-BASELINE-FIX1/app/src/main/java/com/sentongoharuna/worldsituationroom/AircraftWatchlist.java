package com.sentongoharuna.worldsituationroom;
import android.content.Context;import android.content.SharedPreferences;
import java.util.ArrayList;import java.util.LinkedHashSet;import java.util.List;import java.util.Set;
public final class AircraftWatchlist {
 private static final String PREF="duwm_aircraft_watchlist",KEY="identity_keys";
 private final SharedPreferences prefs;
 public AircraftWatchlist(Context c){prefs=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
 public String identityKey(Signal s){
  AircraftCanonicalIdentity.Identity id=AircraftCanonicalIdentity.from(s);
  if(id.basis==AircraftCanonicalIdentity.Basis.ICAO24||id.basis==AircraftCanonicalIdentity.Basis.REGISTRATION)return id.key;
  return "";
 }
 public boolean canPersist(Signal s){return !identityKey(s).isEmpty();}
 public boolean isWatched(Signal s){String k=identityKey(s);return !k.isEmpty()&&keys().contains(k);}
 public boolean toggle(Signal s){
  String k=identityKey(s);if(k.isEmpty())return false;
  Set<String> x=keys();boolean added;if(x.contains(k)){x.remove(k);added=false;}else{x.add(k);added=true;}
  prefs.edit().putStringSet(KEY,new LinkedHashSet<>(x)).apply();return added;
 }
 public Set<String> keys(){return new LinkedHashSet<>(prefs.getStringSet(KEY,new LinkedHashSet<>()));}
 public List<Signal> resolve(List<Signal> flights){
  ArrayList<Signal> out=new ArrayList<>();Set<String> wanted=keys();if(flights==null||wanted.isEmpty())return out;
  for(Signal s:flights){String k=identityKey(s);if(!k.isEmpty()&&wanted.contains(k))out.add(s);}return out;
 }
}
