package com.sentongoharuna.worldsituationroom;
/** One canonical port search result with matched-field disclosure. */
public final class PortSearchResult {
 public final String portId,portName,unLocode,countryCode,region,matchedField,matchedValue;
 public final int score;
 PortSearchResult(String id,String n,String u,String c,String r,String f,String v,int s){portId=id;portName=n;unLocode=u;countryCode=c;region=r;matchedField=f;matchedValue=v;score=s;}
}
