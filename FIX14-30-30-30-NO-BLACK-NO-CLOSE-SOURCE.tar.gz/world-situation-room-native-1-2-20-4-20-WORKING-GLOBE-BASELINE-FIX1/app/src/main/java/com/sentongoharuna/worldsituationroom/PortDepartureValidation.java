package com.sentongoharuna.worldsituationroom;
public final class PortDepartureValidation{private PortDepartureValidation(){}
 public static PortDepartureEvidence.State classify(boolean previousInside,boolean currentInside,double previousKm,double currentKm){
  if(Double.isNaN(previousKm)||Double.isNaN(currentKm))return PortDepartureEvidence.State.INSUFFICIENT;
  if(currentInside)return PortDepartureEvidence.State.STILL_INSIDE;
  double d=currentKm-previousKm;
  if(previousInside&&d>0.10)return PortDepartureEvidence.State.DEPARTING_EVIDENCE;
  if(d>0.10)return PortDepartureEvidence.State.RECEDING_NEARBY;
  return PortDepartureEvidence.State.INSUFFICIENT;
 }
}