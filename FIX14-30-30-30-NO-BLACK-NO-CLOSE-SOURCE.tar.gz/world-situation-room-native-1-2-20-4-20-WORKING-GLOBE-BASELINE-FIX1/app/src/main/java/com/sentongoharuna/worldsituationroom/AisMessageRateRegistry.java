package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Rolling per-provider throughput counters. Categories remain separate. */
public final class AisMessageRateRegistry {
 public enum Kind { ACCEPTED, DUPLICATE, REJECTED, NORMALIZED }
 public static final class Rates {
  public final String providerId;public final double acceptedPerMin,duplicatePerMin,rejectedPerMin,normalizedPerMin;public final long windowMs;
  Rates(String p,double a,double d,double r,double n,long w){providerId=p;acceptedPerMin=a;duplicatePerMin=d;rejectedPerMin=r;normalizedPerMin=n;windowMs=w;}
  public String disclosure(){return String.format(Locale.US,"RATE/min • ACCEPT %.1f • DUP %.1f • REJECT %.1f • NORMALIZED %.1f",acceptedPerMin,duplicatePerMin,rejectedPerMin,normalizedPerMin);}
 }
 private static final long WINDOW_MS=300000L;
 private static final class Event {final long t;final Kind k;Event(long x,Kind y){t=x;k=y;}}
 private final LinkedHashMap<String,ArrayDeque<Event>> events=new LinkedHashMap<>();
 public synchronized void record(String providerId,Kind kind,long nowMs){
  if(providerId==null||providerId.trim().isEmpty()||kind==null||nowMs<=0)return;
  ArrayDeque<Event> q=events.computeIfAbsent(providerId.trim(),k->new ArrayDeque<>());q.addLast(new Event(nowMs,kind));trim(q,nowMs);
 }
 public synchronized Rates rates(String providerId,long nowMs){
  ArrayDeque<Event> q=events.get(providerId);if(q==null)return new Rates(providerId,0,0,0,0,WINDOW_MS);trim(q,nowMs);
  long a=0,d=0,r=0,n=0;for(Event e:q)switch(e.k){case ACCEPTED:a++;break;case DUPLICATE:d++;break;case REJECTED:r++;break;case NORMALIZED:n++;break;}
  double factor=60000d/WINDOW_MS;return new Rates(providerId,a*factor,d*factor,r*factor,n*factor,WINDOW_MS);
 }
 private static void trim(ArrayDeque<Event>q,long now){while(!q.isEmpty()&&now-q.peekFirst().t>WINDOW_MS)q.removeFirst();}
}
