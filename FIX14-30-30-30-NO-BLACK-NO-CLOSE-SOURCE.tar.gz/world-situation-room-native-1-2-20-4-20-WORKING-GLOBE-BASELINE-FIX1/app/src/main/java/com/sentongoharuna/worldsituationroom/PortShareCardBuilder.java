package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class PortShareCardBuilder {
 private PortShareCardBuilder(){}
 public static PortShareCard build(PortIntelligenceSheet s){
  if(s==null||s.port==null)return null;ArrayList<String> f=new ArrayList<>();
  if(!s.unLocode.isEmpty())f.add("UN/LOCODE • "+s.unLocode);
  if(!s.port.countryCode.isEmpty())f.add("COUNTRY • "+s.port.countryCode);
  if(!s.port.region.isEmpty())f.add("REGION • "+s.port.region);
  f.add("INFRASTRUCTURE • "+s.terminals+" terminals • "+s.anchorages+" anchorages • "+s.berths+" berths");
  f.add("ACCESS • "+s.approaches+" approaches • "+s.entrances+" entrances • "+s.channels+" channels");
  if(s.restrictions>0)f.add("SOURCE RESTRICTIONS • "+s.restrictions);
  if(s.latestTraffic!=null)f.add("RECORDED TRAFFIC • "+s.latestTraffic.text());
  if(s.latestObservation!=null)f.add("WEATHER OBSERVATION • "+weather(s.latestObservation));
  if(s.latestForecast!=null)f.add("WEATHER FORECAST • "+weather(s.latestForecast));
  if(s.nearestObservedTide!=null)f.add("TIDE OBSERVATION • "+tide(s.nearestObservedTide));
  if(s.nearestPredictedTide!=null)f.add("TIDE PREDICTION • "+tide(s.nearestPredictedTide));
  String sub=(s.unLocode.isEmpty()?"":s.unLocode+" • ")+(s.port.countryCode.isEmpty()?"":s.port.countryCode);
  return new PortShareCard(s.port.portId,s.port.name,sub.trim(),f,"SOURCE-AWARE SNAPSHOT • missing data omitted • no navigation/safety verdict",s.generatedAtMs);
 }
 private static String weather(PortWeatherContextRecord w){ArrayList<String>x=new ArrayList<>();if(!Double.isNaN(w.temperatureC))x.add(fmt(w.temperatureC)+"°C");if(!Double.isNaN(w.windSpeedMps))x.add("wind "+fmt(w.windSpeedMps)+"m/s");if(!Double.isNaN(w.visibilityM))x.add("visibility "+fmt(w.visibilityM)+"m");return x.isEmpty()?"measurements unavailable":String.join(" • ",x);}
 private static String tide(PortTideContextRecord t){return fmt(t.waterLevelM)+"m • "+t.datum+" • event "+t.eventAtMs;}
 private static String fmt(double x){return String.format(Locale.US,"%.1f",x);}
}
