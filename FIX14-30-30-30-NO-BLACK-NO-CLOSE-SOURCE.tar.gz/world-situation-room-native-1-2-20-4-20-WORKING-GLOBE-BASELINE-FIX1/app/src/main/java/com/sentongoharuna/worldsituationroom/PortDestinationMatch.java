package com.sentongoharuna.worldsituationroom;
/** AIS destination text -> canonical port candidate. A match is evidence, never confirmed intent. */
public final class PortDestinationMatch {
 public enum Method { EXACT_LOCODE, EXACT_NAME, NORMALIZED_NAME, TOKEN_OVERLAP, NONE }
 public final String reportedText,portId,portName,unLocode;public final Method method;public final double confidence;public final boolean ambiguous;
 PortDestinationMatch(String text,String id,String name,String code,Method m,double c,boolean a){reportedText=text;portId=id;portName=name;unLocode=code;method=m;confidence=c;ambiguous=a;}
 public boolean matched(){return method!=Method.NONE&&!portId.isEmpty();}
 public String disclosure(){return matched()?(method+" • confidence "+String.format(java.util.Locale.US,"%.2f",confidence)+(ambiguous?" • AMBIGUOUS":"")+" • reported destination match, not confirmed intent"):"NO MATCH";}
}
