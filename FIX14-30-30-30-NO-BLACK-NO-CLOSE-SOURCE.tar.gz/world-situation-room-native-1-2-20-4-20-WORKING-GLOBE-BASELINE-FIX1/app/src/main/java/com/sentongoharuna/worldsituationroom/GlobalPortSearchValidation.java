package com.sentongoharuna.worldsituationroom;
public final class GlobalPortSearchValidation{private GlobalPortSearchValidation(){}
 public static int score(boolean exact,boolean prefix,boolean contains,int weight){return exact?weight+20:prefix?weight+10:contains?weight:-1;}
 public static boolean onePortPerResult(String a,String b){return a!=null&&b!=null&&!a.equals(b);}
}