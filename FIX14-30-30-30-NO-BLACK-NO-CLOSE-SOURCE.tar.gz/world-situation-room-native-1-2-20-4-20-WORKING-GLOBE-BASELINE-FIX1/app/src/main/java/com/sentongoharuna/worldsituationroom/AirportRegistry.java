package com.sentongoharuna.worldsituationroom;
import java.util.ArrayList;import java.util.LinkedHashMap;import java.util.List;import java.util.Map;
public final class AirportRegistry {
 private final Map<String,Signal> airports=new LinkedHashMap<>();
 public synchronized void ingest(List<Signal> signals){if(signals==null)return;for(Signal s:signals){AirportIntelligence a=AirportIntelligence.from(s);if(a==null)continue;String k=!a.icao.isEmpty()?"ICAO:"+a.icao:!a.iata.isEmpty()?"IATA:"+a.iata:s.canonicalId;airports.put(k,s);}while(airports.size()>3000){String k=airports.keySet().iterator().next();airports.remove(k);}}
 public synchronized Signal find(String code){if(code==null)return null;String q=code.trim().toUpperCase();Signal s=airports.get("ICAO:"+q);return s!=null?s:airports.get("IATA:"+q);}
 public synchronized List<Signal> all(){return new ArrayList<>(airports.values());}
}
