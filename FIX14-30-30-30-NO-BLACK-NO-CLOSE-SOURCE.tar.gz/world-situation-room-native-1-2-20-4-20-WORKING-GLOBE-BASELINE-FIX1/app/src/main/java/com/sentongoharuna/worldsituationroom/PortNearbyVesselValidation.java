package com.sentongoharuna.worldsituationroom;
public final class PortNearbyVesselValidation{private PortNearbyVesselValidation(){}
 public static PortNearbyVessel.Presence classify(boolean harbour,boolean anchorage){return anchorage?PortNearbyVessel.Presence.INSIDE_ANCHORAGE:harbour?PortNearbyVessel.Presence.INSIDE_HARBOUR:PortNearbyVessel.Presence.NEARBY;}
 public static boolean include(double distanceKm,double radiusKm){return distanceKm>=0&&radiusKm>=0&&distanceKm<=radiusKm;}
}