package com.sentongoharuna.worldsituationroom;
import java.util.ArrayList;import java.util.Collections;import java.util.Comparator;import java.util.List;import java.util.Locale;
/** FIX11.30/30.21 source-backed airspace context; proximity is not entry/violation. */
public final class AircraftAirspaceContext {
 public static final class Entry {
  public final Signal signal;public final double distanceKm;public final String type,name;
  Entry(Signal s,double d,String t,String n){signal=s;distanceKm=d;type=t;name=n;}
  public String label(){return String.format(Locale.US,"%.1f km • %s • %s • %s",distanceKm,type,name,TruthEnforcement.label(signal));}
 }
 private AircraftAirspaceContext(){}
 public static List<Entry> nearby(Signal aircraft,List<Signal> airspace,double radiusKm){
  ArrayList<Entry> out=new ArrayList<>();
  if(aircraft==null||aircraft.layer!=Signal.Layer.FLIGHTS||!aircraft.hasLocation()||airspace==null)return out;
  for(Signal s:airspace){
   if(s==null||!s.hasLocation())continue;
   double d=SatelliteMapView.distanceKm(aircraft.latitude,aircraft.longitude,s.latitude,s.longitude);
   if(Double.isNaN(d)||d>radiusKm)continue;
   String type=fact(s,"AIRSPACE TYPE","TYPE","NOTICE TYPE","WARNING TYPE");
   String name=fact(s,"AIRSPACE NAME","NAME","TITLE");
   if(type.isEmpty())type=s.layer.name();
   if(name.isEmpty())name=s.title;
   out.add(new Entry(s,d,type,name));
  }
  Collections.sort(out,Comparator.comparingDouble(e->e.distanceKm));return out;
 }
 private static String fact(Signal s,String...ks){for(String k:ks){String v=s.facts.get(k);if(v!=null&&!v.trim().isEmpty())return v.trim();}return "";}
}
