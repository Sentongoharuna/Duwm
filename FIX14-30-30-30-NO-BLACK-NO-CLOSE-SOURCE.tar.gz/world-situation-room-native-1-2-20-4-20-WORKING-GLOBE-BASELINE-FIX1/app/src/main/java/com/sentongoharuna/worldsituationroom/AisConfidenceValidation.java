package com.sentongoharuna.worldsituationroom;
public final class AisConfidenceValidation{private AisConfidenceValidation(){}
 public static int score(boolean strongId,boolean normalTime,boolean location,int providers,boolean conflict){
  int s=(strongId?25:0)+(normalTime?20:0)+(location?20:0)+(providers>=2?15:0)+(!conflict&&providers>=2?20:0)-(conflict?25:0);
  return Math.max(0,Math.min(100,s));
 }
 public static String band(int s){return s>=75?"STRONGER_EVIDENCE":s>=45?"MIXED_EVIDENCE":"LIMITED_EVIDENCE";}
}