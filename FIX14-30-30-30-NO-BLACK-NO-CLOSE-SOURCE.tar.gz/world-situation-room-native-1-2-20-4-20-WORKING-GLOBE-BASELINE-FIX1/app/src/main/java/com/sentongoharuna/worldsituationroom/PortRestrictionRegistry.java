package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class PortRestrictionRegistry {
 public enum Decision { ADDED, UPDATED, DUPLICATE, REJECTED, CONFLICT }
 public static final class Result {public final Decision decision;public final String reason;Result(Decision d,String r){decision=d;reason=r;}}
 private final LinkedHashMap<String,PortRestrictionRecord> byId=new LinkedHashMap<>();private final LinkedHashMap<String,String> sourceBinding=new LinkedHashMap<>();
 public synchronized Result upsert(PortRecord port,PortRestrictionRecord r){
  if(port==null||r==null||!r.valid()||!port.portId.equals(r.portId))return new Result(Decision.REJECTED,"INVALID RESTRICTION OR PARENT PORT");
  String sk=r.sourceId+"|"+r.sourceRecordId,prior=sourceBinding.get(sk);if(prior!=null&&!prior.equals(r.restrictionId))return new Result(Decision.CONFLICT,"SOURCE RECORD ALREADY BOUND TO "+prior);
  PortRestrictionRecord old=byId.get(r.restrictionId);if(old!=null&&!old.portId.equals(r.portId))return new Result(Decision.CONFLICT,"RESTRICTION PARENT PORT CHANGED");
  if(old!=null&&same(old,r)){sourceBinding.put(sk,r.restrictionId);return new Result(Decision.DUPLICATE,"UNCHANGED");}
  byId.put(r.restrictionId,r);sourceBinding.put(sk,r.restrictionId);return new Result(old==null?Decision.ADDED:Decision.UPDATED,old==null?"ADDED":"UPDATED");
 }
 public synchronized PortRestrictionRecord get(String id){return byId.get(id==null?"":id.trim());}
 public synchronized List<PortRestrictionRecord> forPort(String p){ArrayList<PortRestrictionRecord>o=new ArrayList<>();for(PortRestrictionRecord r:byId.values())if(r.portId.equals(p))o.add(r);return Collections.unmodifiableList(o);}
 public synchronized List<PortRestrictionRecord> effective(String p,long t){ArrayList<PortRestrictionRecord>o=new ArrayList<>();for(PortRestrictionRecord r:forPort(p))if(r.effectiveAt(t))o.add(r);return Collections.unmodifiableList(o);}
 public synchronized List<PortRestrictionRecord> affectingPoint(String p,double lat,double lon,long t){ArrayList<PortRestrictionRecord>o=new ArrayList<>();for(PortRestrictionRecord r:effective(p,t))if(r.contains(lat,lon))o.add(r);return Collections.unmodifiableList(o);}
 public synchronized int size(){return byId.size();}
 private static boolean same(PortRestrictionRecord a,PortRestrictionRecord b){return a.portId.equals(b.portId)&&a.title.equals(b.title)&&a.restrictionType.equals(b.restrictionType)&&a.description.equals(b.description)&&a.affectedObjectType.equals(b.affectedObjectType)&&a.affectedObjectId.equals(b.affectedObjectId)&&a.effectiveFromMs==b.effectiveFromMs&&a.effectiveUntilMs==b.effectiveUntilMs&&a.observedAtMs==b.observedAtMs&&a.area.size()==b.area.size();}
}
