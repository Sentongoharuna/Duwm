package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Deterministic synthetic bookkeeping/load acceptance for FIX14 registries. Not phone/network throughput. */
public final class PortLoadPerformanceHarness {
 public static final int PORTS=10000,EVENTS=250000,HISTORY_BOUND=720;
 public static final class Report {
  public final int ports,events,added,duplicates,updates,rejected,historyMax;public final long elapsedNs;
  Report(int p,int e,int a,int d,int u,int r,int h,long n){ports=p;events=e;added=a;duplicates=d;updates=u;rejected=r;historyMax=h;elapsedNs=n;}
  public boolean accounted(){return events==added+duplicates+updates+rejected;}
  public boolean bounded(){return historyMax<=HISTORY_BOUND;}
  public double eventsPerSecond(){return elapsedNs<=0?0:events/(elapsedNs/1_000_000_000d);}
 }
 public static Report run(){
  long start=System.nanoTime();HashMap<Integer,Integer> state=new HashMap<>();int added=0,dup=0,upd=0,rej=0,maxHist=0;int[] hist=new int[PORTS];
  for(int i=0;i<EVENTS;i++){
   int port=i%PORTS,kind=i%20;
   if(kind==19){rej++;continue;}
   Integer old=state.get(port);
   if(old==null){state.put(port,i);added++;}else if(kind<12){dup++;}else{state.put(port,i);upd++;}
   hist[port]=Math.min(HISTORY_BOUND,hist[port]+1);if(hist[port]>maxHist)maxHist=hist[port];
  }
  return new Report(PORTS,EVENTS,added,dup,upd,rej,maxHist,System.nanoTime()-start);
 }
}