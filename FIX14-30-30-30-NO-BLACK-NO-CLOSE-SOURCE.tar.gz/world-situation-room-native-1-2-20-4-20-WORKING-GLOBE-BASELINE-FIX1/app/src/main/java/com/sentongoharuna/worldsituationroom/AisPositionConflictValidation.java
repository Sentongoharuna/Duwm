package com.sentongoharuna.worldsituationroom;
public final class AisPositionConflictValidation{private AisPositionConflictValidation(){}
 public static boolean conflict(double a,double o,double b,double p){return AisPositionConflict.distanceKm(a,o,b,p)>2d;}
 public static boolean comparable(long a,long b){return Math.abs(a-b)<=120000L;}
}