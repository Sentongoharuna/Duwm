package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Bounded quarantine retaining malformed provider evidence and explicit reason codes. */
public final class AisQuarantineRegistry {
 private static final int MAX=2000;
 private final ArrayDeque<AisQuarantinedRecord> records=new ArrayDeque<>();
 private final LinkedHashMap<String,Long> reasons=new LinkedHashMap<>();
 public synchronized void add(AisProviderRecord r,String reason,long now){
  records.addLast(new AisQuarantinedRecord(r,reason,now));reasons.put(reason,reasons.getOrDefault(reason,0L)+1L);
  while(records.size()>MAX)records.removeFirst();
 }
 public synchronized int size(){return records.size();}
 public synchronized List<AisQuarantinedRecord> snapshot(){return Collections.unmodifiableList(new ArrayList<>(records));}
 public synchronized Map<String,Long> reasonCounts(){return Collections.unmodifiableMap(new LinkedHashMap<>(reasons));}
}
