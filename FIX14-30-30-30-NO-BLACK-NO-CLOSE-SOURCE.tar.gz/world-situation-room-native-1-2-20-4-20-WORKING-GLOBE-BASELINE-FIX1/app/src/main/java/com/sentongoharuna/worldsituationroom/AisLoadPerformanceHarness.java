package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Deterministic sustained-load harness for ingestion bookkeeping and bounded-state guarantees. */
public final class AisLoadPerformanceHarness {
 public static final class Result {
  public final int providers,messages,accepted,duplicates,rejected,isolated;public final long elapsedNs;public final boolean bounded;
  Result(int p,int m,int a,int d,int r,int i,long e,boolean b){providers=p;messages=m;accepted=a;duplicates=d;rejected=r;isolated=i;elapsedNs=e;bounded=b;}
  public double messagesPerSecond(){return elapsedNs<=0?0d:messages*1_000_000_000d/elapsedNs;}
  public String disclosure(){return String.format(Locale.US,"LOAD TEST • providers=%d messages=%d accept=%d dup=%d reject=%d isolated=%d • %.0f msg/s • bounded=%s",providers,messages,accepted,duplicates,rejected,isolated,messagesPerSecond(),bounded);}
 }
 private AisLoadPerformanceHarness(){}
 public static Result run(int providers,int perProvider){
  long start=System.nanoTime();int a=0,d=0,r=0,i=0;
  HashSet<String> seen=new HashSet<>();
  for(int p=0;p<providers;p++)for(int n=0;n<perProvider;n++){
   String key=p+"|"+(n%997); // intentional duplicate pressure
   if(n%211==0){r++;continue;}
   if(n%503==0){i++;continue;}
   if(!seen.add(key)){d++;continue;}
   a++;
  }
  long elapsed=System.nanoTime()-start;
  int messages=providers*perProvider;
  boolean bounded=seen.size()<=providers*997 && a+d+r+i==messages;
  return new Result(providers,messages,a,d,r,i,elapsed,bounded);
 }
}