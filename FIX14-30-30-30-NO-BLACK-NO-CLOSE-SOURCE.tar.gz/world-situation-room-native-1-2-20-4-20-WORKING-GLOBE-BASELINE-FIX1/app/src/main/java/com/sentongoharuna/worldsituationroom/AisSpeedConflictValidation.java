package com.sentongoharuna.worldsituationroom;
public final class AisSpeedConflictValidation{private AisSpeedConflictValidation(){}
 public static boolean conflict(double a,double b){return !Double.isNaN(a)&&!Double.isNaN(b)&&Math.abs(a-b)>3d;}
 public static boolean comparable(long a,long b){return Math.abs(a-b)<=120000L;}
 public static double knots(double mps){return mps*1.943844d;}
}