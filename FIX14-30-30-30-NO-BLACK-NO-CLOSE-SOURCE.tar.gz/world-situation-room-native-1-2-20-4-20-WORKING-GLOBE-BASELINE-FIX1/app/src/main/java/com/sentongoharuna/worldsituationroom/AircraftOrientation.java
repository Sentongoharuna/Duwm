package com.sentongoharuna.worldsituationroom;
/** FIX11.30/30.5 separates provider heading from ground track. */
public final class AircraftOrientation {
 public enum Basis { TRUE_HEADING, MAGNETIC_HEADING, GROUND_TRACK, UNKNOWN }
 public final double degrees;
 public final Basis basis;
 private AircraftOrientation(double d,Basis b){degrees=normalize(d);basis=b;}
 public static AircraftOrientation from(Signal signal){
  AircraftTelemetry t=AircraftTelemetry.from(signal);
  if(t==null)return new AircraftOrientation(Double.NaN,Basis.UNKNOWN);
  double trueHeading=num(signal,"TRUE HEADING","TRUE_HEADING");
  if(valid(trueHeading))return new AircraftOrientation(trueHeading,Basis.TRUE_HEADING);
  double magnetic=num(signal,"MAGNETIC HEADING","MAG HEADING","MAGNETIC_HEADING");
  if(valid(magnetic))return new AircraftOrientation(magnetic,Basis.MAGNETIC_HEADING);
  if(t.hasHeading())return new AircraftOrientation(t.headingDegrees,Basis.TRUE_HEADING);
  if(t.hasTrack())return new AircraftOrientation(t.trackDegrees,Basis.GROUND_TRACK);
  return new AircraftOrientation(Double.NaN,Basis.UNKNOWN);
 }
 public boolean known(){return !Double.isNaN(degrees);}
 private static boolean valid(double d){return !Double.isNaN(d)&&!Double.isInfinite(d);}
 private static double normalize(double d){if(!valid(d))return Double.NaN;d%=360d;if(d<0)d+=360d;return d;}
 private static double num(Signal s,String...ks){for(String k:ks){String v=s.facts.get(k);if(v!=null)try{return Double.parseDouble(v.trim().replaceAll("[^0-9+\\\\-.]",""));}catch(Exception ignored){}}return Double.NaN;}
}
