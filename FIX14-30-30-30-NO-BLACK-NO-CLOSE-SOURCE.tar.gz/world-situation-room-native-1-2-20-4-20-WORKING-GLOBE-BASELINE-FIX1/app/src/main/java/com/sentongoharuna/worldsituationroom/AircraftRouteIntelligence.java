package com.sentongoharuna.worldsituationroom;
import java.util.Locale;

/** FIX11.30/30.11 route evidence. Never turns inference into provider-confirmed route. */
public final class AircraftRouteIntelligence {
 public enum Basis { PROVIDER_CONFIRMED, PROVIDER_REPORTED, INFERRED, UNKNOWN }
 public final String origin,destination;
 public final Basis basis;
 public final String evidence;

 private AircraftRouteIntelligence(String o,String d,Basis b,String e){
  origin=o;destination=d;basis=b;evidence=e;
 }
 public static AircraftRouteIntelligence from(Signal s){
  if(s==null||s.layer!=Signal.Layer.FLIGHTS)return unknown();
  String origin=code(first(s,"ORIGIN","ORIGIN ICAO","ORIGIN IATA","DEPARTURE","FROM"));
  String dest=code(first(s,"DESTINATION","DESTINATION ICAO","DESTINATION IATA","ARRIVAL","TO"));
  String routeStatus=first(s,"ROUTE STATUS","ROUTE BASIS","ROUTE SOURCE").toUpperCase(Locale.ROOT);
  String evidence=first(s,"ROUTE SOURCE","ROUTE PROVIDER","SOURCE");
  if(!origin.isEmpty()&&!dest.isEmpty()){
   Basis b=routeStatus.contains("CONFIRM")?Basis.PROVIDER_CONFIRMED:
       routeStatus.contains("INFER")||routeStatus.contains("ESTIMAT")?Basis.INFERRED:
       Basis.PROVIDER_REPORTED;
   return new AircraftRouteIntelligence(origin,dest,b,evidence);
  }
  String inferredOrigin=code(first(s,"INFERRED ORIGIN","POSSIBLE ORIGIN"));
  String inferredDest=code(first(s,"INFERRED DESTINATION","POSSIBLE DESTINATION"));
  if(!inferredOrigin.isEmpty()&&!inferredDest.isEmpty())
   return new AircraftRouteIntelligence(inferredOrigin,inferredDest,Basis.INFERRED,evidence);
  return unknown();
 }
 public boolean known(){return !origin.isEmpty()&&!destination.isEmpty();}
 public boolean confirmed(){return basis==Basis.PROVIDER_CONFIRMED;}
 public String compact(){
  if(!known())return "ROUTE UNKNOWN";
  if(basis==Basis.INFERRED)return "POSSIBLE ROUTE • "+origin+" → "+destination+" • NOT PROVIDER CONFIRMED";
  if(basis==Basis.PROVIDER_CONFIRMED)return origin+" → "+destination+" • PROVIDER CONFIRMED";
  return origin+" → "+destination+" • PROVIDER REPORTED";
 }
 private static AircraftRouteIntelligence unknown(){return new AircraftRouteIntelligence("","",Basis.UNKNOWN,"");}
 private static String first(Signal s,String...ks){for(String k:ks){String v=s.facts.get(k);if(v!=null&&!v.trim().isEmpty())return v.trim();}return "";}
 private static String code(String v){if(v==null)return "";v=v.trim().toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]","");return v.length()>=3&&v.length()<=4?v:"";}
}
