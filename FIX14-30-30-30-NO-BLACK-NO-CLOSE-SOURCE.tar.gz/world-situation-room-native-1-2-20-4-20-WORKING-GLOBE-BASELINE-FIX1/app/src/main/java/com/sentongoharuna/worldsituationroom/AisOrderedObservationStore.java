package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Provider-neutral chronological AIS store. Late fixes may enrich history but never roll back live state. */
public final class AisOrderedObservationStore {
 public static final class Update {
  public final AisObservationOrder.Decision decision;public final NormalizedAisRecord live;public final int historySize;
  Update(AisObservationOrder.Decision d,NormalizedAisRecord l,int h){decision=d;live=l;historySize=h;}
 }
 private static final int MAX_PER_VESSEL=720;
 private final LinkedHashMap<String,ArrayList<NormalizedAisRecord>> history=new LinkedHashMap<>();
 private final LinkedHashMap<String,NormalizedAisRecord> live=new LinkedHashMap<>();
 public synchronized Update accept(String vesselKey,NormalizedAisRecord r){
  String key=vesselKey==null?"":vesselKey.trim();if(key.isEmpty()||r==null)return new Update(AisObservationOrder.Decision.TOO_OLD,null,0);
  NormalizedAisRecord old=live.get(key);
  AisObservationOrder.Decision d=AisObservationOrder.classify(old==null?0L:old.providerTimestampMs,r.providerTimestampMs);
  ArrayList<NormalizedAisRecord> h=history.computeIfAbsent(key,k->new ArrayList<>());
  if(d==AisObservationOrder.Decision.FIRST||d==AisObservationOrder.Decision.NEWER_LIVE){
   insertChronological(h,r);live.put(key,r);
  }else if(d==AisObservationOrder.Decision.LATE_HISTORY){
   insertChronological(h,r);
  }
  while(h.size()>MAX_PER_VESSEL)h.remove(0);
  return new Update(d,live.get(key),h.size());
 }
 public synchronized NormalizedAisRecord live(String key){return live.get(key);}
 public synchronized List<NormalizedAisRecord> history(String key){ArrayList<NormalizedAisRecord>h=history.get(key);return h==null?Collections.emptyList():Collections.unmodifiableList(new ArrayList<>(h));}
 private static void insertChronological(ArrayList<NormalizedAisRecord> h,NormalizedAisRecord r){
  for(NormalizedAisRecord x:h)if(x.providerId.equals(r.providerId)&&x.providerRecordId.equals(r.providerRecordId))return;
  int p=Collections.binarySearch(h,r,Comparator.comparingLong(x->x.providerTimestampMs));
  if(p<0)p=-p-1;else while(p<h.size()&&h.get(p).providerTimestampMs<=r.providerTimestampMs)p++;
  h.add(p,r);
 }
}
