package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Converts canonical.* adapter output into one typed AIS schema before vessel fusion. */
public final class AisSchemaNormalizer {
 public static final class Result {
  public final NormalizedAisRecord record;public final List<String> warnings,errors;
  Result(NormalizedAisRecord r,List<String>w,List<String>e){record=r;warnings=Collections.unmodifiableList(w);errors=Collections.unmodifiableList(e);}
  public boolean accepted(){return record!=null&&errors.isEmpty();}
 }
 private AisSchemaNormalizer(){}
 public static Result normalize(AisProviderRecord r){
  ArrayList<String>w=new ArrayList<>(),e=new ArrayList<>();if(r==null){e.add("NULL PROVIDER RECORD");return new Result(null,w,e);}
  Map<String,String> f=r.fields;
  String rawMmsi=text(f,"mmsi"),rawImo=text(f,"imo"),name=text(f,"name"),callsign=text(f,"callsign"),reg=text(f,"registration"),type=text(f,"vessel_type");
  AisImoValidation.Result imoResult=AisImoValidation.validate(rawImo);
  String imo=imoResult.accepted()?imoResult.imo:"";
  if(!rawImo.isEmpty()&&imo.isEmpty())w.add("IMO QUARANTINED • "+imoResult.state.name());
  AisMmsiValidation.Result mmsiResult=AisMmsiValidation.validate(rawMmsi);
  String mmsi=mmsiResult.accepted()&&mmsiResult.kind==AisMmsiValidation.Kind.SHIP_STATION?mmsiResult.mmsi:"";
  if(!rawMmsi.isEmpty()&&mmsi.isEmpty())w.add("MMSI QUARANTINED • "+mmsiResult.state.name()+" • "+mmsiResult.kind.name());
  double lat=num(f,"latitude"),lon=num(f,"longitude"),sog=num(f,"sog"),cog=num(f,"cog"),hdg=num(f,"heading"),rot=num(f,"rot"),draught=num(f,"draught");
  AisCoordinateValidation.Result coordinate=AisCoordinateValidation.validate(lat,lon);
  if(coordinate.state==AisCoordinateValidation.State.OUT_OF_RANGE){e.add("COORDINATE OUT OF RANGE");lat=Double.NaN;lon=Double.NaN;}
  else if(coordinate.state==AisCoordinateValidation.State.SENTINEL){e.add("AIS COORDINATE SENTINEL");lat=Double.NaN;lon=Double.NaN;}
  else if(coordinate.state==AisCoordinateValidation.State.MISSING){w.add("COORDINATE MISSING");}
  if(!Double.isNaN(sog)&&sog<0d){w.add("NEGATIVE SOG REJECTED");sog=Double.NaN;}
  if(!Double.isNaN(cog)){if(cog<0d||cog>=360d)w.add("COG NORMALIZED");cog=((cog%360d)+360d)%360d;}
  if(!Double.isNaN(hdg)){if(hdg<0d||hdg>=360d)w.add("HEADING NORMALIZED");hdg=((hdg%360d)+360d)%360d;}
  if(!Double.isNaN(draught)&&draught<0d){w.add("NEGATIVE DRAUGHT REJECTED");draught=Double.NaN;}
  if(mmsi.isEmpty()&&imo.isEmpty()&&callsign.isEmpty()&&reg.isEmpty())w.add("WEAK VESSEL IDENTITY");
  long processedAtMs=System.currentTimeMillis();
  NormalizedAisRecord n=new NormalizedAisRecord(r.providerId,r.providerName,r.providerRecordId,r.providerTimestampMs,r.receivedAtMs,processedAtMs,
   mmsi,imo,name,callsign,reg,type,lat,lon,sog,cog,hdg,rot,text(f,"navigation_status"),draught,text(f,"destination"),text(f,"eta"),f);
  return new Result(e.isEmpty()?n:null,w,e);
 }
 private static String text(Map<String,String>f,String k){String v=f.get("canonical."+k);if(v==null)v=f.get(k);return v==null?"":v.trim();}
 private static double num(Map<String,String>f,String k){try{String v=text(f,k);return v.isEmpty()?Double.NaN:Double.parseDouble(v);}catch(Exception x){return Double.NaN;}}
}
