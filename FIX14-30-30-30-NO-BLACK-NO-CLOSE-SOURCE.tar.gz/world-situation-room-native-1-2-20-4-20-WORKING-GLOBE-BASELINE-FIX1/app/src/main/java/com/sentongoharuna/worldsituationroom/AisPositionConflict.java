package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Detects provider position disagreement. Never averages conflicting positions. */
public final class AisPositionConflict {
 public enum State { NONE, CONFLICT, INSUFFICIENT }
 public static final class Result {
  public final State state;public final double maxSeparationKm;public final String providerA,providerB;
  Result(State s,double d,String a,String b){state=s;maxSeparationKm=d;providerA=a;providerB=b;}
  public String disclosure(){return state==State.CONFLICT?String.format(Locale.US,"POSITION CONFLICT • %.2f km • %s ↔ %s • NOT AVERAGED",maxSeparationKm,providerA,providerB):state.name();}
 }
 private AisPositionConflict(){}
 public static Result detect(List<NormalizedAisRecord> records){
  if(records==null||records.size()<2)return new Result(State.INSUFFICIENT,Double.NaN,"","");
  double max=0d;String pa="",pb="";boolean compared=false;
  for(int i=0;i<records.size();i++){NormalizedAisRecord a=records.get(i);if(a==null||!a.hasLocation())continue;
   for(int j=i+1;j<records.size();j++){NormalizedAisRecord b=records.get(j);if(b==null||!b.hasLocation()||a.providerId.equals(b.providerId))continue;
    // Only compare observations close enough in provider time to represent the same live moment.
    if(Math.abs(a.providerTimestampMs-b.providerTimestampMs)>120000L)continue;
    compared=true;double d=distanceKm(a.latitude,a.longitude,b.latitude,b.longitude);
    if(d>max){max=d;pa=a.providerId;pb=b.providerId;}
   }}
  if(!compared)return new Result(State.INSUFFICIENT,Double.NaN,"","");
  // 2 km is a material live-position disagreement for this generic provider fusion layer.
  return new Result(max>2d?State.CONFLICT:State.NONE,max,pa,pb);
 }
 public static double distanceKm(double a,double o,double b,double p){
  double r=6371.0088d,p1=Math.toRadians(a),p2=Math.toRadians(b),dp=Math.toRadians(b-a),dl=Math.toRadians(p-o);
  double x=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);
  return 2d*r*Math.atan2(Math.sqrt(x),Math.sqrt(Math.max(0d,1d-x)));
 }
}
