package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class AisProviderSelector{
 public static final class Selection{public final NormalizedAisRecord selected;public final List<NormalizedAisRecord> evidence;public final String reason;Selection(NormalizedAisRecord s,List<NormalizedAisRecord>e,String r){selected=s;evidence=Collections.unmodifiableList(new ArrayList<>(e));reason=r;}}
 private AisProviderSelector(){}
 public static Selection select(List<NormalizedAisRecord> c,AisProviderPriority p){ArrayList<NormalizedAisRecord>v=new ArrayList<>();if(c!=null)for(NormalizedAisRecord r:c)if(r!=null)v.add(r);if(v.isEmpty())return new Selection(null,v,"NO CANDIDATES");
  v.sort((a,b)->{int x=Integer.compare(p.rank(a.providerId),p.rank(b.providerId));if(x!=0)return x;x=Long.compare(b.providerTimestampMs,a.providerTimestampMs);if(x!=0)return x;x=Long.compare(b.receivedAtMs,a.receivedAtMs);if(x!=0)return x;return a.providerId.compareTo(b.providerId);});
  return new Selection(v.get(0),v,"LOWEST PRIORITY RANK • THEN NEWEST PROVIDER TIME • THEN RECEIVE TIME");
 }
}