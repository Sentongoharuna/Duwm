package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Bounded per-provider latency statistics. */
public final class AisLatencyRegistry {
 public static final class Stats {
  public final String providerId;public final long samples;public final double avgSourceToReceiveMs,avgReceiveToProcessMs;public final long maxSourceToReceiveMs,maxReceiveToProcessMs,clockSkewSamples;
  Stats(String p,long n,double a,double b,long ma,long mb,long s){providerId=p;samples=n;avgSourceToReceiveMs=a;avgReceiveToProcessMs=b;maxSourceToReceiveMs=ma;maxReceiveToProcessMs=mb;clockSkewSamples=s;}
 }
 private static final class Mutable {long n,sumA,sumB,maxA,maxB,skew;}
 private final LinkedHashMap<String,Mutable> map=new LinkedHashMap<>();
 public synchronized void add(AisIngestionLatency.Sample s){if(s==null)return;Mutable m=map.computeIfAbsent(s.providerId,k->new Mutable());m.n++;m.sumB+=s.receiveToProcessMs;m.maxB=Math.max(m.maxB,s.receiveToProcessMs);if(s.clockSkew)m.skew++;else{m.sumA+=s.providerToReceiveMs;m.maxA=Math.max(m.maxA,s.providerToReceiveMs);}}
 public synchronized Stats stats(String p){Mutable m=map.get(p);if(m==null)return new Stats(p,0,Double.NaN,Double.NaN,0,0,0);long valid=m.n-m.skew;return new Stats(p,m.n,valid>0?(double)m.sumA/valid:Double.NaN,m.n>0?(double)m.sumB/m.n:Double.NaN,m.maxA,m.maxB,m.skew);}
}
