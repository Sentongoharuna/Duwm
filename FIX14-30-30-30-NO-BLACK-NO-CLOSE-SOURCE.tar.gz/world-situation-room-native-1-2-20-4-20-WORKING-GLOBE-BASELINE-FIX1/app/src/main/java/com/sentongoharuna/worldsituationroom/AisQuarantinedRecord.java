package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Immutable rejected-record evidence. Never enters live vessel state. */
public final class AisQuarantinedRecord {
 public final String providerId,providerRecordId,reason;public final long providerTimestampMs,receivedAtMs,quarantinedAtMs;
 public final Map<String,String> rawFields;
 AisQuarantinedRecord(AisProviderRecord r,String why,long now){
  providerId=r==null?"":r.providerId;providerRecordId=r==null?"":r.providerRecordId;reason=why==null?"UNKNOWN":why;
  providerTimestampMs=r==null?0:r.providerTimestampMs;receivedAtMs=r==null?0:r.receivedAtMs;quarantinedAtMs=now;
  rawFields=Collections.unmodifiableMap(new LinkedHashMap<>(r==null?Collections.emptyMap():r.fields));
 }
}
