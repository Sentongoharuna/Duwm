package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class NearbyVesselIntelligence {
 public static final class Entry {
  public final Signal signal; public final double distanceKm,bearingDeg;
  Entry(Signal s,double d,double b){signal=s;distanceKm=d;bearingDeg=b;}
  public String label(){
   VesselTelemetry t=VesselTelemetry.from(signal); VesselSpeedIntelligence sp=VesselSpeedIntelligence.from(signal);
   String id=t!=null&&!t.name.isEmpty()?t.name:t!=null&&!t.mmsi.isEmpty()?"MMSI "+t.mmsi:signal.title;
   return String.format(Locale.US,"%s • %.2f km • %03.0f° • %s • %s",id,distanceKm,bearingDeg,sp.disclosure(),TruthEnforcement.label(signal));
  }
 }
 private NearbyVesselIntelligence(){}
 public static List<Entry> nearby(Signal selected,List<Signal> ships,double radiusKm){
  ArrayList<Entry> out=new ArrayList<>();
  if(selected==null||selected.layer!=Signal.Layer.SHIPS||!selected.hasLocation()||ships==null)return out;
  for(Signal s:ships){
   if(s==null||s==selected||s.layer!=Signal.Layer.SHIPS||!s.hasLocation())continue;
   if(VesselCanonicalIdentity.sameVessel(selected,s))continue;
   double d=SatelliteMapView.distanceKm(selected.latitude,selected.longitude,s.latitude,s.longitude);
   if(Double.isNaN(d)||d>radiusKm)continue;
   double b=VesselPortGeometryValidation.bearing(selected.latitude,selected.longitude,s.latitude,s.longitude);
   out.add(new Entry(s,d,b));
  }
  Collections.sort(out,Comparator.comparingDouble(e->e.distanceKm));return out;
 }
}
