package com.sentongoharuna.worldsituationroom;
public final class AisImoGate {
 private AisImoGate(){}
 public static String acceptedImo(String raw){AisImoValidation.Result r=AisImoValidation.validate(raw);return r.accepted()?r.imo:"";}
}
