package com.sentongoharuna.worldsituationroom;
import java.util.Locale;
public final class AircraftCanonicalIdentity {
 public enum Basis { ICAO24, REGISTRATION, PROVIDER_RECORD, UNKNOWN }
 public static final class Identity {
  public final String key,icao24,registration,callsign,flightNumber; public final Basis basis;
  Identity(String k,String i,String r,String c,String f,Basis b){key=k;icao24=i;registration=r;callsign=c;flightNumber=f;basis=b;}
 }
 private AircraftCanonicalIdentity(){}
 public static Identity from(Signal s){
  if(s==null||s.layer!=Signal.Layer.FLIGHTS)return new Identity("","","","","",Basis.UNKNOWN);
  String icao=hex(clean(first(s,"ICAO24","ICAO 24","ICAO","MODE S","MODE-S")));
  String reg=clean(first(s,"REGISTRATION","TAIL","TAIL NUMBER"));
  String call=clean(first(s,"CALLSIGN","CALL SIGN"));
  String flight=clean(first(s,"FLIGHT NUMBER","FLIGHT","FLT"));
  if(icao.matches("[0-9A-F]{6}"))return new Identity("aircraft:icao24:"+icao,icao,reg,call,flight,Basis.ICAO24);
  if(reg.length()>=3&&reg.length()<=12&&reg.matches("[A-Z0-9-]+"))return new Identity("aircraft:registration:"+reg,"",reg,call,flight,Basis.REGISTRATION);
  String provider=clean(s.providerId);String record=s.originalRecord==null?s.id:s.originalRecord.providerRecordId;
  if(record!=null&&!record.trim().isEmpty())return new Identity("aircraft:provider:"+provider+":"+clean(record),"",reg,call,flight,Basis.PROVIDER_RECORD);
  return new Identity("","",reg,call,flight,Basis.UNKNOWN);
 }
 public static boolean sameAircraft(Signal a,Signal b){
  Identity x=from(a),y=from(b);if(x.key.isEmpty()||y.key.isEmpty())return false;
  if(x.basis==Basis.PROVIDER_RECORD||y.basis==Basis.PROVIDER_RECORD)return x.basis==Basis.PROVIDER_RECORD&&y.basis==Basis.PROVIDER_RECORD&&x.key.equals(y.key);
  return x.key.equals(y.key);
 }
 public static boolean callsignOnlyMatch(Signal a,Signal b){
  Identity x=from(a),y=from(b);return !x.callsign.isEmpty()&&x.callsign.equals(y.callsign)&&!sameAircraft(a,b);
 }
 private static String first(Signal s,String...ks){for(String k:ks){String v=s.facts.get(k);if(v!=null&&!v.trim().isEmpty())return v;}return "";}
 private static String clean(String v){return v==null?"":v.trim().toUpperCase(Locale.ROOT).replaceAll("\\s+","");}
 private static String hex(String v){return v.replaceAll("[^0-9A-F]","");}
}
