package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Provider health transition tracker. Recovery is a source event, not a new-vessel observation. */
public final class AisProviderRecovery {
 public enum Event { NONE, DEGRADED, RECOVERED }
 public static final class Transition {
  public final String providerId;public final AisProviderFreshness.State previous,current;public final Event event;public final long atMs;
  Transition(String p,AisProviderFreshness.State a,AisProviderFreshness.State b,Event e,long t){providerId=p;previous=a;current=b;event=e;atMs=t;}
  public String disclosure(){return "PROVIDER "+providerId+" • "+event.name()+" • "+previous.name()+" → "+current.name();}
 }
 private final LinkedHashMap<String,AisProviderFreshness.State> last=new LinkedHashMap<>();
 public synchronized Transition update(AisProviderFreshness.Result now,long atMs){
  if(now==null)return null;AisProviderFreshness.State prev=last.put(now.providerId,now.state);
  if(prev==null)return new Transition(now.providerId,now.state,now.state,Event.NONE,atMs);
  boolean prevBad=bad(prev),nowBad=bad(now.state);Event e=prevBad&&!nowBad?Event.RECOVERED:!prevBad&&nowBad?Event.DEGRADED:Event.NONE;
  return new Transition(now.providerId,prev,now.state,e,atMs);
 }
 private static boolean bad(AisProviderFreshness.State s){return s==AisProviderFreshness.State.STALE||s==AisProviderFreshness.State.SILENT||s==AisProviderFreshness.State.UNKNOWN;}
}
