package com.sentongoharuna.worldsituationroom;
public final class AisMmsiGate {
 private AisMmsiGate(){}
 public static String acceptedShipMmsi(String raw){
  AisMmsiValidation.Result r=AisMmsiValidation.validate(raw);
  return r.accepted()&&r.kind==AisMmsiValidation.Kind.SHIP_STATION?r.mmsi:"";
 }
}
