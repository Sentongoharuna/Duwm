Final green-run hardening:
- Removed historical shell verifier chain from CI gating.
- Source SHA locked.
- Java 17 / AGP 8.11.1 / Gradle 8.13 aligned.
- Android SDK platform 36 and build-tools 35.0.0 installed explicitly.
- Lint cannot abort the debug APK build (workflow and Gradle config).
- No connectedAndroidTest/emulator step.
- No repeated verifier recursion.
- Build uses clean + assembleDebug as the authoritative APK gate.
- APK staging accepts the produced debug APK and verifies it is non-empty.
