FIX10.1 preserves the green FIX9 application/config baseline. No Android source changes. Java 17, Gradle 8.13, Android 36, assembleDebug only; no emulator, recursive verifier, or blocking lint gate.
