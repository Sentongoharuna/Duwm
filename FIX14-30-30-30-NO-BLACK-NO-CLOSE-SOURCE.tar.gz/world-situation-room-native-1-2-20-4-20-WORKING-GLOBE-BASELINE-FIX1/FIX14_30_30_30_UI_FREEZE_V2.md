Exact compile repair: removed stale crashReference assignment after recovery page deletion; logging retained; no new page restored.
