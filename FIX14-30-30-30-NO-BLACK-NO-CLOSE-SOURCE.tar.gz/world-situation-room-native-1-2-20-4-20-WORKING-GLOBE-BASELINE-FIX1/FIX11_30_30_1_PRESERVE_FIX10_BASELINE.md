# FIX11.30 / 30.1 — PRESERVE FIX10.30 FINAL BASELINE

Purpose: freeze the cumulative FIX10.30 Living Globe before aircraft-specific FIX11 work.

Built in this section:
1. Uses FIX10-30-FINAL-COMPLETE-SOURCE.tar.gz as the only parent baseline.
2. No aircraft behavior redesign in 30.1.
3. No Android application source behavior changed in 30.1.
4. Fingerprints MainActivity and SatelliteMapView.
5. Fingerprints TruthEnforcement.
6. Fingerprints IntelligencePreservationAudit.
7. Fingerprints NetworkDegradationPolicy and ObjectFreshness.
8. Fingerprints canonical identity/dedup infrastructure.
9. Fingerprints RecordTimestampChain and RegionalPriorityEngine.
10. Fingerprints AndroidManifest and all Gradle build scripts.
11. Static presence audit confirms major FIX10 Living Globe anchors.
12. FIX10 camera/inertia/fly-to remains frozen.
13. FIX10 interpolation/markers/density/clustering/selection remains frozen.
14. FIX10 intelligence sheet/layers/combinations remains frozen.
15. FIX10 truth/freshness/status/provider-health remains frozen.
16. FIX10 pulses/labels/Uganda Home/search/location actions remain frozen.
17. FIX10 performance/network/loading/no-fake-information remains frozen.
18. FIX10 intelligence-preservation architecture remains frozen.
19. Build path remains Java 17 + Android 36 + Gradle 8.13 + clean assembleDebug.
20. No emulator, connectedDebugAndroidTest, recursive historical verifier, or blocking lint gate.
21. CI verifies source archive SHA-256 before extraction.
22. CI verifies all baseline critical-file SHA-256 fingerprints after extraction.
23. CI requires exactly one non-empty debug APK.
24. CI emits APK SHA-256.
25. Future FIX11 sections must inherit this baseline and change only the aircraft-specific scope required by that section.
