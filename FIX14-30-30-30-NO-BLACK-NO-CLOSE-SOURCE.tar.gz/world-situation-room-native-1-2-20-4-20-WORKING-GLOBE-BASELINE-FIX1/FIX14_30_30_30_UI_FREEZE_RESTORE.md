FIX14.30/30.30 UI FREEZE RESTORE
Restores the established pre-existing app interface as the only startup surface. Removes the newly introduced startup shell and Command Deck recovery page from MainActivity. FIX14 remains backend/data enhancement only. Runtime failures are logged/contained and are not allowed to replace the existing interface with a new page. V2 compile repairs are retained.
