#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"; V="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/SatelliteMapView.java"
"$P/scripts/verify-1-2-20-4-19A-4-20-globe-motion.sh" "$P" || true
grep -F 'AUTO_ROTATION_DEG_PER_SECOND = 6.0d' "$V" >/dev/null
grep -F 'liveRotationPhaseDeg' "$V" >/dev/null
grep -F 'visualCenterLon = wrapLongitude(centerLon + liveRotationPhaseDeg)' "$V" >/dev/null
grep -F 'motionFrameCount++' "$V" >/dev/null
grep -F 'drawLiveMotionSweep(canvas)' "$V" >/dev/null
grep -F 'SystemClock.uptimeMillis() - motionHeartbeatMs > 750L' "$V" >/dev/null
! grep -F 'centerLon = wrapLongitude(centerLon' "$V" | grep -F 'AUTO_ROTATION_DEG_PER_SECOND'
echo "4.20 FIX1 PERSISTENT GLOBE MOTION GREEN GATE PASS"
