package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.FrameLayout;
import android.util.AttributeSet;
import java.lang.reflect.Constructor;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Operational home screen. Presentation never substitutes for observed source records. */
public final class OperationsMainActivity extends Activity {
    private static final int BG=Color.rgb(5, 13, 34), PANEL=Color.rgb(13, 31, 61), BORDER=Color.rgb(38, 72, 127);
    private static final int TEXT=Color.rgb(216, 230, 253), MUTED=Color.rgb(123, 151, 191), ACCENT=Color.rgb(76, 120, 196), WARN=Color.rgb(85, 139, 223);
    private static final long REFRESH_MS=180000L;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService network=Executors.newSingleThreadExecutor();
    private final AtomicBoolean fetching=new AtomicBoolean(false);
    private Duwm1670HomeTelemetryView newRail;
    private OperationsGlobeView earth;
    private OperationsGlobeView.Observation selectedShareObservation;
    private FrameLayout earthViewport;
    private View originalEarth;
    private TextView originalToggle, liveReadout;
    private LinearLayout originalHud;
    private OperationsTelemetryPanel telemetryPanel;
    private LinearLayout selectedObservation;
    private TextView selectedTitle,selectedDetail,selectedAction;
    private OperationsGlobeView.Observation selectedItem;
    // Build 99: event-driven alerts only, with persistent deduplication and user control.
    private boolean alertsEnabled(){return getSharedPreferences("duwm_alert_settings",MODE_PRIVATE).getBoolean("haptics",true);}
    private void alertHaptic(){
        if(!alertsEnabled())return;
        try{
            android.os.Vibrator vib=(android.os.Vibrator)getSystemService(VIBRATOR_SERVICE);
            if(vib==null||!vib.hasVibrator())return;
            if(android.os.Build.VERSION.SDK_INT>=26){
                vib.vibrate(android.os.VibrationEffect.createWaveform(new long[]{0,95,90,140},-1));
            }else{vib.vibrate(180);}
        }catch(SecurityException ignored){ /* No vibration permission: silent alert still shown. */ }
    }
    private void majorQuakeAlert(String eventId,String title,long eventTime){
        if(eventId==null||eventId.isEmpty()||eventTime<=0)return;
        long now=System.currentTimeMillis();
        if(eventTime>now+120000L||now-eventTime>30*60*1000L)return;
        android.content.SharedPreferences p=getSharedPreferences("duwm_major_alerts",MODE_PRIVATE);
        if(p.getBoolean(eventId,false))return;
        p.edit().putBoolean(eventId,true).apply();
        alertHaptic();
        new android.app.AlertDialog.Builder(this).setTitle("USGS  /  MAJOR EARTHQUAKE")
            .setMessage(title+"\n\nSource: USGS. Verify details and local safety guidance before acting.")
            .setPositiveButton("VIEW QUAKES",(d,w)->navigate("EARTHQUAKES"))
            .setNegativeButton("DISMISS",null).show();
    }
    private boolean originalMode=false;
    private boolean fullEarth=false;
    private boolean compactGlobeHud=true;
    private boolean globeCollisionAvoidance=true;
    private TextView hudModeControl, collisionModeControl;

    private TextView headerStatus,clock,updatedText,summaryText,airCount,quakeCount,issCount,airSource,quakeSource,issSource,detail;
    private TextView airLayer,quakeLayer,issLayer,rotationControl;
    private Duwm1166SignalView duwm1166AirLed,duwm1166QuakeLed,duwm1166IssLed;
    // V1159.4: the front-screen data receipt strip never displays synthetic observations.
    private TextView sourceHeartbeat;
    private boolean viewAir=true,viewQuakes=true,viewIss=true,rotate=true,foreground=false;
    private long lastAttempt=Long.MIN_VALUE/2;
    private final Runnable second=new Runnable(){@Override public void run(){
        if(!foreground)return;clock.setText(utc(System.currentTimeMillis())+" UTC");
        if(!fetching.get() && SystemClock.elapsedRealtime()-lastAttempt>=REFRESH_MS)refresh();
        main.postDelayed(this,1000);
    }};
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private String utc(long ms){SimpleDateFormat f=new SimpleDateFormat("dd MMM yyyy   HH:mm:ss",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(ms));}
    private TextView text(String s,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(sp);if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return t;}
    private GradientDrawable bg(int color,float corner,int line){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(corner));if(line!=0)d.setStroke(dp(1),line);return d;}
    private void rowAdd(LinearLayout row,View child,int width,int height){row.addView(child,new LinearLayout.LayoutParams(width<0?width:dp(width),height<0?height:dp(height)));}
    private TextView action(String label, String description){TextView t=text(label,11,ACCENT,true);t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12),dp(8),dp(12),dp(8));t.setBackground(bg(PANEL,5,BORDER));t.setContentDescription(description);return t;}
    private LinearLayout metric(LinearLayout parent,String title){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(10),dp(10),dp(9));card.setBackground(bg(PANEL,7,BORDER));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(168),dp(96));cp.rightMargin=dp(8);parent.addView(card,cp);
        TextView header=text(title,10,MUTED,true);card.addView(header);return card;
    }
    private void navigate(String mode){
        if("1671 MISSION".equals(mode)){startActivity(new Intent(this,Duwm1671MissionActivity.class));return;}
        if("1670 COMMAND".equals(mode)){startActivity(new Intent(this,Duwm1670CommandActivity.class));return;}
        if("1670 FLIGHT MAP".equals(mode)){startActivity(new Intent(this,Duwm1670FlightMapActivity.class));return;}
        if("1670 NEWS ATLAS".equals(mode)){startActivity(new Intent(this,Duwm1670NewsAtlasActivity.class));return;}
        if("200 SOURCES".equals(mode)){startActivity(new Intent(this,Duwm1669SourceDirectoryActivity.class));return;}
        if("GEO LENS".equals(mode)){startActivity(new Intent(this,Duwm1668GeopoliticalLensActivity.class));return;}
        if("ALL INTELLIGENCE".equals(mode)){startActivity(new Intent(this,Duwm1166DirectoryActivity.class));return;}
        if("WORLD NEWS".equals(mode)){startActivity(new Intent(this,Duwm1166NewsDeskActivity.class));return;}
        if("RADIO".equals(mode)){startActivity(new Intent(this,Duwm1166RadioAtlasActivity.class));return;}

        if("ORIGINAL COMMAND".equals(mode)){startActivity(new Intent(this,MainActivity.class));return;}
        if("AIRCRAFT".equals(mode)){startActivity(new Intent(this,AircraftOperationsActivity.class));return;}
        if("RADIO".equals(mode)||"TV STATIONS".equals(mode)||"WORLD NEWS".equals(mode)||"EARTH IMAGES".equals(mode)){
            Intent i=new Intent(this,MediaDeskActivity.class);i.putExtra("mode",mode);startActivity(i);return;
        }
        Intent intent=new Intent(this,WorldSourceHubActivity.class);intent.putExtra("mode",mode);startActivity(intent);
    }
    @Override public void onCreate(Bundle state){super.onCreate(state);setTheme(android.R.style.Theme_Material_NoActionBar);
        getWindow().setStatusBarColor(Color.rgb(3,12,29));getWindow().setNavigationBarColor(Color.rgb(3,12,29));
        LinearLayout root=new LinearLayout(this);root.setBackgroundColor(Color.rgb(3,12,29));root.setOrientation(LinearLayout.VERTICAL);setContentView(root);
        root.setFitsSystemWindows(true);
        if(android.os.Build.VERSION.SDK_INT >= 30){
            root.setOnApplyWindowInsetsListener((v,insets)->{
                android.graphics.Insets bars=insets.getInsets(android.view.WindowInsets.Type.statusBars()|android.view.WindowInsets.Type.navigationBars());
                root.setPadding(0,bars.top,0,bars.bottom);
                return insets;
            });
        }
        LinearLayout heading=new LinearLayout(this);heading.setGravity(Gravity.CENTER_VERTICAL);heading.setPadding(dp(16),dp(10),dp(16),dp(6));rowAdd(root,heading,-1,50);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.develop_uganda_logo);heading.addView(logo,new LinearLayout.LayoutParams(dp(36),dp(36)));
        LinearLayout brand=new LinearLayout(this);brand.setOrientation(LinearLayout.VERTICAL);brand.setPadding(dp(11),0,0,0);heading.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        brand.addView(text("◉  DUWM   /   WORLD LIVE",17,Color.rgb(244,250,255),true));brand.addView(text("WORLD SITUATION ROOM   •   OPERATIONS",9,Color.rgb(119,182,236),true));
        headerStatus=text("● CONNECTING",10,Color.rgb(65,215,173),true);headerStatus.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);rowAdd(heading,headerStatus,70,34);
        LinearLayout metadata=new LinearLayout(this);metadata.setPadding(dp(16),dp(2),dp(16),dp(8));metadata.setGravity(Gravity.CENTER_VERTICAL);rowAdd(root,metadata,-1,27);
        clock=text("UTC --",11,MUTED,false);metadata.addView(clock,new LinearLayout.LayoutParams(0,-2,1));
        updatedText=text("NO SOURCE SYNC",10,MUTED,true);metadata.addView(updatedText,new LinearLayout.LayoutParams(-2,-2));
        // Build 91: searchable monitoring directory; all destinations reuse existing navigation.
        TextView deskSearch=action("⌕ FIND","Search the monitoring desks");
        deskSearch.setTextSize(11);
        deskSearch.setTextColor(Color.rgb(112,212,242));
        deskSearch.setBackground(bg(Color.rgb(10,36,68),7,Color.rgb(56,133,185)));
        LinearLayout.LayoutParams findLp=new LinearLayout.LayoutParams(dp(72),dp(26));
        findLp.leftMargin=dp(8);
        metadata.addView(deskSearch,findLp);
        deskSearch.setOnClickListener(v->{
            final android.widget.EditText query=new android.widget.EditText(this);
            query.setSingleLine(true);query.setHint("Aircraft, ships, weather, news...");
            query.setTextColor(Color.WHITE);query.setHintTextColor(Color.LTGRAY);
            final String[] deskNames={"Aircraft","Vessels","Satellites","City Cameras","World News",
                "Radio","TV Stations","Weather","Earth Images","Internet","All Intelligence",
                "Original Command","Global Mission","Live Command","Flight Map","News Atlas"};
            final String[] deskModes={"AIRCRAFT","VESSELS","SATELLITES","CITY CAMERAS","WORLD NEWS",
                "RADIO","TV STATIONS","WEATHER","EARTH IMAGES","INTERNET","ALL INTELLIGENCE",
                "ORIGINAL COMMAND","1671 MISSION","1670 COMMAND","1670 FLIGHT MAP","1670 NEWS ATLAS"};
            new android.app.AlertDialog.Builder(this).setTitle("FIND A WORLD DESK")
                .setView(query).setNegativeButton("CANCEL",null)
                .setPositiveButton("SEARCH",(dialog,which)->{
                    String term=query.getText().toString().trim().toLowerCase(java.util.Locale.ROOT);
                    java.util.ArrayList<String> matches=new java.util.ArrayList<>();
                    java.util.ArrayList<String> modes=new java.util.ArrayList<>();
                    for(int k=0;k<deskNames.length;k++){
                        if(term.isEmpty()||deskNames[k].toLowerCase(java.util.Locale.ROOT).contains(term)){
                            matches.add(deskNames[k]);modes.add(deskModes[k]);
                        }
                    }
                    if(matches.isEmpty()){
                        new android.app.AlertDialog.Builder(this).setMessage("No matching monitoring desk. Try another search.")
                            .setPositiveButton("OK",null).show();return;
                    }
                    new android.app.AlertDialog.Builder(this).setTitle("MONITORING DESKS")
                        .setItems(matches.toArray(new String[0]),(d,index)->navigate(modes.get(index)))
                        .setNegativeButton("CLOSE",null).show();
                }).show();
        });
        // Build 91: searchable desk directory plus eight primary desks, retaining the original globe.
        LinearLayout deskBar=new LinearLayout(this);
        deskBar.setPadding(dp(11),dp(8),dp(11),dp(8));
        deskBar.setOrientation(LinearLayout.VERTICAL);
        deskBar.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable deskSurface=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{Color.rgb(11,32,62),Color.rgb(5,19,40)});
        deskSurface.setCornerRadius(dp(15));deskSurface.setStroke(dp(1),Color.rgb(35,83,129));
        deskBar.setBackground(deskSurface);
        LinearLayout.LayoutParams deskBarParams=new LinearLayout.LayoutParams(-1,dp(106));
        deskBarParams.setMargins(dp(8),dp(5),dp(8),dp(5));root.addView(deskBar,deskBarParams);
        // Mobile-first: keep the Earth visible; reveal the eight desk tiles only on request.
        deskBar.setVisibility(View.GONE);
        LinearLayout deskRowA=new LinearLayout(this),deskRowB=new LinearLayout(this);
        deskBar.addView(deskRowA,new LinearLayout.LayoutParams(-1,dp(43)));
        LinearLayout.LayoutParams secondRowParams=new LinearLayout.LayoutParams(-1,dp(43));
        secondRowParams.topMargin=dp(4);deskBar.addView(deskRowB,secondRowParams);
        String[][] quickDesks={{"✈ AIR","AIRCRAFT"},{"⚓ SEA","VESSELS"},{"◉ NEWS","WORLD NEWS"},{"▣ TV","TV STATIONS"},{"◈ SAT","SATELLITES"},{"◎ CAM","CITY CAMERAS"},{"♫ RADIO","RADIO"},{"☁ WX","WEATHER"}};
        int[] deskColors={Color.rgb(69,176,236),Color.rgb(45,171,205),Color.rgb(188,113,232),Color.rgb(61,205,153),Color.rgb(239,201,83),Color.rgb(58,209,220),Color.rgb(128,171,246),Color.rgb(77,193,238)};
        for(int j=0;j<quickDesks.length;j++){
            final String destination=quickDesks[j][1];
            final int deskAccent=deskColors[j];
            TextView quick=action(quickDesks[j][0],"Open "+destination+" full-screen desk");
            quick.setTextSize(10);quick.setTextColor(Color.rgb(240,249,255));
            quick.setLetterSpacing(0.035f);
            GradientDrawable tile=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(22,49,82),Color.rgb(9,28,55)});
            tile.setCornerRadius(dp(11));tile.setStroke(dp(1),deskColors[j]);
            quick.setBackground(tile);
            quick.setElevation(dp(2));
            LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(0,dp(43),1);
            qp.setMargins(dp(3),0,dp(3),0);(j<4?deskRowA:deskRowB).addView(quick,qp);
            // Build 92: visually mark favourite desks; long press toggles and persists the pin.
            final String favouriteKey="desk_favourite_"+destination.replace(' ','_');
            final String baseLabel=quickDesks[j][0];
            final android.content.SharedPreferences favourites=getSharedPreferences("duwm_desk_favourites",MODE_PRIVATE);
            if(favourites.getBoolean(favouriteKey,false)){
                quick.setText("★ "+baseLabel);
                quick.setBackground(bg(Color.rgb(19,48,80),8,Color.rgb(245,198,89)));
            }
            quick.setOnLongClickListener(v->{
                boolean pinned=!favourites.getBoolean(favouriteKey,false);
                favourites.edit().putBoolean(favouriteKey,pinned).apply();
                quick.setText(pinned?"★ "+baseLabel:baseLabel);
                quick.setBackground(bg(pinned?Color.rgb(19,48,80):Color.rgb(12,32,61),8,
                    pinned?Color.rgb(245,198,89):deskAccent));
                android.widget.Toast.makeText(this,pinned?"Desk pinned to favourites":"Desk unpinned",android.widget.Toast.LENGTH_SHORT).show();
                return true;
            });
            quick.setOnClickListener(v->{
                getSharedPreferences("duwm_recent_desk",MODE_PRIVATE).edit().putString("last",destination).apply();
                navigate(destination);
            });
        }
        // Build 93: visible recent-desk ribbon with one-tap return and reset.
        final android.content.SharedPreferences recentDesks=getSharedPreferences("duwm_recent_desk",MODE_PRIVATE);
        LinearLayout recentRibbon=new LinearLayout(this);
        recentRibbon.setGravity(Gravity.CENTER_VERTICAL);
        recentRibbon.setPadding(dp(9),dp(2),dp(9),dp(2));
        recentRibbon.setBackground(bg(Color.rgb(8,27,53),11,Color.rgb(39,85,135)));
        LinearLayout.LayoutParams recentParams=new LinearLayout.LayoutParams(-1,dp(39));
        recentParams.setMargins(dp(9),dp(2),dp(9),dp(4));root.addView(recentRibbon,recentParams);
        recentRibbon.setVisibility(View.GONE);
        TextView recentTitle=text("↺  RECENT",10,Color.rgb(108,195,239),true);
        recentRibbon.addView(recentTitle,new LinearLayout.LayoutParams(dp(83),-2));
        TextView recentOpen=action("NO RECENT DESK","Return to the last opened monitoring desk");
        recentOpen.setTextSize(11);
        recentOpen.setTextColor(Color.rgb(231,245,255));
        recentOpen.setBackground(bg(Color.rgb(12,45,79),6,Color.rgb(51,150,205)));
        recentRibbon.addView(recentOpen,new LinearLayout.LayoutParams(0,dp(32),1));
        TextView recentClear=action("×","Clear last opened monitoring desk");
        recentClear.setTextColor(Color.rgb(230,168,168));
        LinearLayout.LayoutParams clearParams=new LinearLayout.LayoutParams(dp(35),dp(32));
        clearParams.leftMargin=dp(6);
        recentRibbon.addView(recentClear,clearParams);
        String lastDesk=recentDesks.getString("last","");
        recentOpen.setText(lastDesk.isEmpty()?"NO RECENT DESK":"↗  "+lastDesk);
        recentOpen.setEnabled(!lastDesk.isEmpty());
        recentOpen.setOnClickListener(v->{
            String destination=recentDesks.getString("last","");
            if(!destination.isEmpty())navigate(destination);
        });
        recentClear.setOnClickListener(v->{
            recentDesks.edit().remove("last").apply();
            recentOpen.setText("NO RECENT DESK");recentOpen.setEnabled(false);
        });
        HorizontalScrollView scroller=new HorizontalScrollView(this);scroller.setHorizontalScrollBarEnabled(false);rowAdd(root,scroller,-1,44);
        scroller.setVisibility(View.GONE);
        LinearLayout tabs=new LinearLayout(this);tabs.setGravity(Gravity.CENTER_VERTICAL);tabs.setPadding(dp(14),0,dp(8),0);scroller.addView(tabs);
        String[][] categories={{"1673 GLOBAL MISSION","1671 MISSION"},{"1670 LIVE COMMAND","1670 COMMAND"},{"LIVE AIRCRAFT MAP","1670 FLIGHT MAP"},{"200 REGIONAL NEWS","1670 NEWS ATLAS"},{"200 WORLD SOURCES","200 SOURCES"},{"GEO LENS 1668","GEO LENS"},{"ALL DESKS","ALL INTELLIGENCE"},{"AIRCRAFT REGISTER","AIRCRAFT"},{"VESSELS","VESSELS"},{"SATELLITES","SATELLITES"},{"CITY CAMERAS","CITY CAMERAS"},
                {"NEWS","WORLD NEWS"},{"RADIO","RADIO"},{"TELEVISION","TV STATIONS"},{"INTERNET","INTERNET"},{"NASA IMAGES","EARTH IMAGES"},{"ORIGINAL COMMAND","ORIGINAL COMMAND"}};
        for(String[] c:categories){TextView tab=action(c[0],"Open " + c[1] + " monitoring sources");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(39));lp.rightMargin=dp(6);tabs.addView(tab,lp);tab.setOnClickListener(v->navigate(c[1]));}
        TextView allDesks=action("☷  DESKS & RECENTS  ▾","Expand mobile desk shortcuts and recent monitoring desk");
        allDesks.setTextColor(Color.rgb(174,201,245));
        allDesks.setBackground(bg(Color.rgb(14,38,73),5,Color.rgb(55,103,174)));
        rowAdd(root,allDesks,-1,30);
        allDesks.setVisibility(View.GONE); // Build 95: dock MORE replaces duplicate header expander.
        allDesks.setOnClickListener(v->{
            boolean open=deskBar.getVisibility()!=View.VISIBLE;
            deskBar.setVisibility(open?View.VISIBLE:View.GONE);
            recentRibbon.setVisibility(open?View.VISIBLE:View.GONE);
            scroller.setVisibility(View.GONE);
            allDesks.setText(open?"☷  CLOSE DESKS  ▴":"☷  DESKS & RECENTS  ▾");
        });
        // 1670: compact source-backed changing figures, no decorative fake counts.
        newRail=new Duwm1670HomeTelemetryView(this);
        newRail.setOnLongClickListener(v->{navigate("1671 MISSION");return true;});
        newRail.setContentDescription("Tap to expand or collapse live telemetry; long press for mission control. Figures use actual provider receipts.");
        LinearLayout.LayoutParams liveRailParams=new LinearLayout.LayoutParams(-1,dp(42));
        liveRailParams.setMargins(dp(8),dp(3),dp(8),dp(3));
        GradientDrawable liveRailSurface=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{Color.rgb(8,32,58),Color.rgb(6,24,48)});
        liveRailSurface.setCornerRadius(dp(12));
        liveRailSurface.setStroke(dp(1),Color.rgb(46,113,155));
        newRail.setBackground(liveRailSurface);
        root.addView(newRail,liveRailParams);
        // Tap the source-backed live strip to expand or collapse the telemetry board.
        LinearLayout globeFrame=new LinearLayout(this);globeFrame.setOrientation(LinearLayout.VERTICAL);globeFrame.setBackground(bg(Color.rgb(13, 31, 61),0,0));
        root.addView(globeFrame,new LinearLayout.LayoutParams(-1,0,1));
        globeFrame.setContentDescription("Interactive live Earth. Tap markers for source details; drag to rotate and pinch to zoom.");
        LinearLayout globeHeading=new LinearLayout(this);globeHeading.setGravity(Gravity.CENTER_VERTICAL);
        globeHeading.setPadding(dp(16),dp(4),dp(16),0);rowAdd(globeFrame,globeHeading,-1,29);
        // Two distinct rows prevent long geographic labels from being compressed by controls.
        LinearLayout globeControls=new LinearLayout(this);globeControls.setGravity(Gravity.CENTER_VERTICAL);
        globeControls.setPadding(dp(12),0,dp(12),dp(2));
        globeFrame.addView(globeControls,new LinearLayout.LayoutParams(-1,dp(39)));
        // Build 88 visible redesign: collapse advanced tools by default to return vertical
        // space to the actual Earth. The tools remain available with one tap.
        final boolean[] toolsExpanded={false};
        final TextView toolsToggle=action("TOOLS  +", "Expand advanced globe display controls");
        toolsToggle.setTextColor(Color.rgb(235,244,255));
        toolsToggle.setBackground(bg(Color.rgb(24,54,105),8,Color.rgb(85,146,236)));
        globeControls.addView(toolsToggle,new LinearLayout.LayoutParams(0,dp(35),1));
        // V1159.4 VISIBLE MAIN SCREEN: photo-backed share cards are one tap from the globe.
        LinearLayout photoRail=new LinearLayout(this);photoRail.setGravity(Gravity.CENTER_VERTICAL);
        photoRail.setPadding(dp(12),dp(3),dp(12),dp(3));
        globeFrame.addView(photoRail,new LinearLayout.LayoutParams(-1,dp(34)));
        TextView newsPhoto=action("NEWS / SHARE CARDS","Open WORLD NEWS source pictures and shareable details");
        newsPhoto.setTextColor(Color.rgb(221, 234, 254));
        newsPhoto.setBackground(bg(Color.rgb(40, 76, 135),8,Color.rgb(76, 120, 196)));
        LinearLayout.LayoutParams nlp=new LinearLayout.LayoutParams(0,dp(31),1);nlp.rightMargin=dp(5);photoRail.addView(newsPhoto,nlp);
        newsPhoto.setOnClickListener(v->startActivity(new Intent(this,Duwm1166NewsDeskActivity.class)));
        TextView earthPhotos=action("NASA / EARTH IMAGERY","Open NASA source Earth pictures and image share cards");
        earthPhotos.setTextColor(Color.rgb(221, 234, 254));
        earthPhotos.setBackground(bg(Color.rgb(30, 62, 114),8,Color.rgb(66, 104, 180)));
        LinearLayout.LayoutParams elp=new LinearLayout.LayoutParams(0,dp(31),1);elp.leftMargin=dp(5);photoRail.addView(earthPhotos,elp);
        earthPhotos.setOnClickListener(v->{Intent i=new Intent(this,MediaDeskActivity.class);i.putExtra("mode","EARTH IMAGES");startActivity(i);});
        sourceHeartbeat=text("SOURCE RECEIPTS   /   NOT YET CHECKED",11,ACCENT,true);
        sourceHeartbeat.setPadding(dp(12),dp(4),dp(4),dp(3));
        sourceHeartbeat.setSingleLine(true);
        sourceHeartbeat.setEllipsize(android.text.TextUtils.TruncateAt.END);
        sourceHeartbeat.setContentDescription("Real provider synchronization status; no simulated live counts");
        LinearLayout verifiedRailRow=new LinearLayout(this);verifiedRailRow.setGravity(Gravity.CENTER_VERTICAL);
        verifiedRailRow.addView(sourceHeartbeat,new LinearLayout.LayoutParams(0,dp(25),1));
        DuwmSignalRail verifiedLeds=DuwmSignalRail.embedded(this);
        LinearLayout.LayoutParams signalParams=new LinearLayout.LayoutParams(dp(106),dp(24));signalParams.rightMargin=dp(8);
        verifiedRailRow.addView(verifiedLeds,signalParams);
        globeFrame.addView(verifiedRailRow,new LinearLayout.LayoutParams(-1,dp(27)));
        TextView globeLabel=text("◉  LIVE EARTH   /   GLOBAL OPERATIONS",12,Color.rgb(223,242,255),true);
        globeLabel.setSingleLine(true);globeLabel.setEllipsize(android.text.TextUtils.TruncateAt.END);
        globeLabel.setContentDescription("Detailed rotating geographic Earth with Natural Earth coastlines and real source observations");
        globeHeading.addView(globeLabel,new LinearLayout.LayoutParams(-1,-2));
        rotationControl=action("ROTATION ON","Toggle visible globe auto-rotation");
        LinearLayout.LayoutParams rotateP=new LinearLayout.LayoutParams(0,dp(35),1);rotateP.rightMargin=dp(5);
        globeControls.addView(rotationControl,rotateP);
        rotationControl.setOnClickListener(v->{
            if(originalMode && originalEarth instanceof SatelliteMapView){
                rotate=!rotate;
                ((SatelliteMapView)originalEarth).setAutoRotationEnabled(rotate);
                rotationControl.setText(rotate?"ROTATION ON":"ROTATION OFF");
                detail.setText(rotate?"Original globe rotating; dragging pauses rotation temporarily":
                               "Original globe rotation paused; touch to inspect geographic features");
                return;
            }
            rotate=!rotate;rotationControl.setText(rotate?"ROTATION  ON":"ROTATION  OFF");
            if(rotate&&foreground)earth.resume();else earth.pause();
        });
        // One shared live Earth viewport: modern source globe and the actual preserved original renderer.
        // The two renderers belong to the SAME Android app and can be switched without launching a second dashboard.
        earthViewport=new FrameLayout(this);
        globeFrame.addView(earthViewport,new LinearLayout.LayoutParams(-1,0,1));
        earth=new OperationsGlobeView(this);
        android.content.SharedPreferences globePrefs=getSharedPreferences("duwm_globe_controls",MODE_PRIVATE);
        compactGlobeHud=globePrefs.getBoolean("compact_hud",true);
        globeCollisionAvoidance=globePrefs.getBoolean("avoid_collisions",true);
        earth.setCompactHud(compactGlobeHud);
        earth.setMarkerCollisionAvoidance(globeCollisionAvoidance);
        earthViewport.addView(earth,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout earthHud=new LinearLayout(this);originalHud=earthHud;earthHud.setOrientation(LinearLayout.VERTICAL);
        earthHud.setPadding(dp(12),dp(8),dp(12),dp(8));earthHud.setBackground(bg(Color.argb(205,8,24,36),7,BORDER));
        FrameLayout.LayoutParams earthHudParams=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT);
        earthHudParams.leftMargin=dp(13);earthHudParams.topMargin=dp(8);
        earthViewport.addView(earthHud,earthHudParams);
        earthHud.addView(text("ORIGINAL GLOBE / OBSERVED SIGNALS",11,TEXT,true));
        liveReadout=text("AWAITING SOURCE OBSERVATIONS",11,ACCENT,true);earthHud.addView(liveReadout);
        LinearLayout advancedGlobeControls=new LinearLayout(this);
        LinearLayout viewGlobeControls=new LinearLayout(this);
        hudModeControl=action(compactGlobeHud?"HUD: COMPACT":"HUD: DETAIL","Toggle compact globe status overlay");
        advancedGlobeControls.addView(hudModeControl,new LinearLayout.LayoutParams(0,dp(35),1));
        hudModeControl.setOnClickListener(v->{
            compactGlobeHud=!compactGlobeHud;
            earth.setCompactHud(compactGlobeHud);
            hudModeControl.setText(compactGlobeHud?"HUD: COMPACT":"HUD: DETAIL");
            getSharedPreferences("duwm_globe_controls",MODE_PRIVATE).edit().putBoolean("compact_hud",compactGlobeHud).apply();
        });
        collisionModeControl=action(globeCollisionAvoidance?"PINS: CLEAN":"PINS: ALL","Toggle crowded marker collision reduction");
        advancedGlobeControls.addView(collisionModeControl,new LinearLayout.LayoutParams(0,dp(35),1));
        collisionModeControl.setOnClickListener(v->{
            globeCollisionAvoidance=!globeCollisionAvoidance;
            earth.setMarkerCollisionAvoidance(globeCollisionAvoidance);
            collisionModeControl.setText(globeCollisionAvoidance?"PINS: CLEAN":"PINS: ALL");
            getSharedPreferences("duwm_globe_controls",MODE_PRIVATE).edit().putBoolean("avoid_collisions",globeCollisionAvoidance).apply();
        });
        final boolean[] freshOnly={globePrefs.getBoolean("fresh_only",false)};
        earth.setFreshObservationsOnly(freshOnly[0]);
        TextView freshOnlyControl=action(freshOnly[0]?"FEED: FRESH":"FEED: ALL",
                "Filter stale observation markers without deleting source records");
        advancedGlobeControls.addView(freshOnlyControl,new LinearLayout.LayoutParams(0,dp(35),1));
        freshOnlyControl.setOnClickListener(v->{
            freshOnly[0]=!freshOnly[0];
            earth.setFreshObservationsOnly(freshOnly[0]);
            freshOnlyControl.setText(freshOnly[0]?"FEED: FRESH":"FEED: ALL");
            globePrefs.edit().putBoolean("fresh_only",freshOnly[0]).apply();
        });
        // Build 83: real globe rendering controls, saved between launches.
        final int[] densitySetting={globePrefs.getInt("marker_density",1)};
        earth.setMarkerDensity(densitySetting[0]);
        final TextView densityControl=action("DENSITY: "+(densitySetting[0]==0?"LOW":densitySetting[0]==1?"NORMAL":"HIGH"),
                "Change observed marker spacing without changing provider data");
        viewGlobeControls.addView(densityControl,new LinearLayout.LayoutParams(0,dp(35),1));
        densityControl.setOnClickListener(v->{
            densitySetting[0]=(densitySetting[0]+1)%3;
            earth.setMarkerDensity(densitySetting[0]);
            densityControl.setText("DENSITY: "+(densitySetting[0]==0?"LOW":densitySetting[0]==1?"NORMAL":"HIGH"));
            globePrefs.edit().putInt("marker_density",densitySetting[0]).apply();
        });
        viewGlobeControls.setGravity(Gravity.CENTER_VERTICAL);
        viewGlobeControls.setPadding(dp(12),dp(2),dp(12),dp(2));
        globeFrame.addView(viewGlobeControls,new LinearLayout.LayoutParams(-1,dp(43)));
        final TextView resetGlobe=action("RESET EARTH", "Restore original globe orientation and zoom");
        viewGlobeControls.addView(resetGlobe,new LinearLayout.LayoutParams(0,dp(35),1));
        resetGlobe.setOnClickListener(v->{
            earth.resetView();
            if(originalEarth!=null){originalEarth.requestLayout();originalEarth.invalidate();}
        });
        // Build 84: separate advanced controls from the primary globe controls;
        // prevents seven buttons being compressed into a single unusable row.
        advancedGlobeControls.setGravity(Gravity.CENTER_VERTICAL);
        advancedGlobeControls.setPadding(dp(12),dp(2),dp(12),dp(2));
        globeFrame.addView(advancedGlobeControls,new LinearLayout.LayoutParams(-1,dp(43)));
        // The original control rows are retained, but no longer occupy the viewport
        // until explicitly opened. This makes the globe visibly larger on first launch.
        viewGlobeControls.setVisibility(View.GONE);
        advancedGlobeControls.setVisibility(View.GONE);
        toolsToggle.setOnClickListener(v->{
            toolsExpanded[0]=!toolsExpanded[0];
            viewGlobeControls.setVisibility(toolsExpanded[0]?View.VISIBLE:View.GONE);
            advancedGlobeControls.setVisibility(toolsExpanded[0]?View.VISIBLE:View.GONE);
            toolsToggle.setText(toolsExpanded[0]?"TOOLS  −":"TOOLS  +");
            toolsToggle.setContentDescription(toolsExpanded[0]?"Hide advanced globe controls":"Show advanced globe controls");
        });
        // Real renderer motion/freshness controls with saved preferences.
        final boolean[] reducedMotion={globePrefs.getBoolean("reduced_motion",false)};
        final boolean[] freshness={globePrefs.getBoolean("show_freshness",true)};
        earth.setReducedMotion(reducedMotion[0]);
        earth.setShowFreshness(freshness[0]);
        TextView motionControl=action(reducedMotion[0]?"MOTION: LOW":"MOTION: FULL","Reduce globe animations and movement");
        advancedGlobeControls.addView(motionControl,new LinearLayout.LayoutParams(0,dp(37),1));
        motionControl.setOnClickListener(v->{
            reducedMotion[0]=!reducedMotion[0];
            earth.setReducedMotion(reducedMotion[0]);
            motionControl.setText(reducedMotion[0]?"MOTION: LOW":"MOTION: FULL");
            globePrefs.edit().putBoolean("reduced_motion",reducedMotion[0]).apply();
        });
        TextView freshnessControl=action(freshness[0]?"AGE: SHOW":"AGE: HIDE","Toggle observation freshness indicators");
        advancedGlobeControls.addView(freshnessControl,new LinearLayout.LayoutParams(0,dp(37),1));
        freshnessControl.setOnClickListener(v->{
            freshness[0]=!freshness[0];
            earth.setShowFreshness(freshness[0]);
            freshnessControl.setText(freshness[0]?"AGE: SHOW":"AGE: HIDE");
            globePrefs.edit().putBoolean("show_freshness",freshness[0]).apply();
        });
        originalToggle=action("LEGACY", "Optionally show the alternative legacy Canvas globe");
        // Mode control belongs beside the globe title, never over the coastline or markers.
        originalToggle.setText("LEGACY");
        LinearLayout.LayoutParams nativeP=new LinearLayout.LayoutParams(0,dp(35),1);nativeP.rightMargin=dp(5);
        viewGlobeControls.addView(originalToggle,nativeP);
        // Human-readable inspector belongs to the very same geo-viewport as live globe pins.
        selectedObservation=new LinearLayout(this);
        selectedObservation.setOrientation(LinearLayout.VERTICAL);
        selectedObservation.setPadding(dp(12),dp(9),dp(12),dp(10));
        selectedObservation.setBackground(bg(Color.argb(243,8,24,36),8,ACCENT));
        FrameLayout.LayoutParams inspectorParams=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM|Gravity.LEFT);
        inspectorParams.leftMargin=dp(12);inspectorParams.rightMargin=dp(12);inspectorParams.bottomMargin=dp(57);
        earthViewport.addView(selectedObservation,inspectorParams);
        selectedTitle=text("OBSERVATION",15,TEXT,true);selectedObservation.addView(selectedTitle);
        selectedDetail=text("Source is connecting",12,MUTED,false);selectedDetail.setMaxLines(3);selectedObservation.addView(selectedDetail);
        selectedAction=action("VIEW AIRCRAFT REGISTER","Open original observed aircraft record");
        selectedObservation.addView(selectedAction,new LinearLayout.LayoutParams(-1,dp(36)));
        selectedAction.setOnClickListener(v->{if(selectedItem!=null&&selectedItem.type==OperationsGlobeView.AIR){
            Intent i=new Intent(this,AircraftOperationsActivity.class);i.putExtra("query",selectedItem.title.trim());startActivity(i);
        }});
        selectedObservation.setVisibility(View.GONE);
        originalToggle.setOnClickListener(v->switchOriginalRenderer());
        // This control actually reflows the native globe viewport.
        TextView focusControl=action("FOCUS","Expand modern HD Earth globe full-screen");
        viewGlobeControls.addView(focusControl,new LinearLayout.LayoutParams(0,dp(35),1));
        earth.setOnObservationSelected(item->{selectedShareObservation=item;
            inspectObservation(item,false);
            detail.setText(item.title+"  •  "+item.detail+"  |  "+item.source+"  |  "+(item.timeMillis>0?utc(item.timeMillis)+" UTC":"TIME NOT SUPPLIED")
                +(item.type==OperationsGlobeView.AIR?"  •  TAP FOR AIRCRAFT INSPECTOR":""));
            detail.setOnClickListener(v->{
                if(item.type!=OperationsGlobeView.AIR)return;
                Intent i=new Intent(this,AircraftOperationsActivity.class);
                i.putExtra("query",item.title.trim());startActivity(i);
            });
        });
        TextView shareObserved=action("SHARE SELECTED OBSERVATION  /  SOURCE DATA","Export selected genuine aircraft, quake or satellite point");
        shareObserved.setTextColor(Color.rgb(222, 234, 254));
        shareObserved.setBackground(bg(Color.rgb(39, 73, 133),7,Color.rgb(76, 120, 196)));
        shareObserved.setGravity(Gravity.CENTER);
        globeFrame.addView(shareObserved,new LinearLayout.LayoutParams(-1,dp(34)));
        shareObserved.setOnClickListener(v->{OperationsGlobeView.Observation o=selectedShareObservation;
          if(o==null){android.widget.Toast.makeText(this,"Tap an observed marker first",android.widget.Toast.LENGTH_SHORT).show();return;}
          String type=o.type==OperationsGlobeView.AIR?"AIRCRAFT":o.type==OperationsGlobeView.QUAKE?"EARTHQUAKE":"SATELLITE / ISS";
          String url=o.type==OperationsGlobeView.AIR?"https://opensky-network.org/":o.type==OperationsGlobeView.QUAKE?"https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson":"https://api.wheretheiss.at/v1/satellites/25544";
          V115941ShareCards.share(this,type,o.title,o.detail,o.source,o.timeMillis,o.lat,o.lon,url,null);
        });
        TextView pulseEntry=action("MAPS  /  LIVE GEOSPATIAL DATA",
                "Source-observed aircraft, earthquakes, ISS and news; visual radar and point sharing");
        pulseEntry.setTextColor(Color.rgb(85, 139, 223));
        pulseEntry.setOnClickListener(v->startActivity(new Intent(this,DuwmPlaceMapActivity.class)));
        globeFrame.addView(pulseEntry,new LinearLayout.LayoutParams(-1,dp(35)));
        // P3 observed-position actions. No new or synthetic world markers.
        LinearLayout p3GlobeControls=new LinearLayout(this);
        p3GlobeControls.setPadding(dp(10),dp(2),dp(10),dp(3));
        p3GlobeControls.setGravity(Gravity.CENTER_VERTICAL);
        TextView p3Center=action("CENTER SELECTED","Smoothly focus globe on the selected real observation");
        TextView p3Map=action("VIEW ON MAP","Open selected observation coordinates in the real geographic map");
        LinearLayout.LayoutParams p3a=new LinearLayout.LayoutParams(0,dp(39),1);p3a.rightMargin=dp(4);
        p3GlobeControls.addView(p3Center,p3a);
        LinearLayout.LayoutParams p3b=new LinearLayout.LayoutParams(0,dp(39),1);p3b.leftMargin=dp(4);
        p3GlobeControls.addView(p3Map,p3b);
        globeFrame.addView(p3GlobeControls,new LinearLayout.LayoutParams(-1,dp(35)));
        p3Center.setOnClickListener(v->{
            OperationsGlobeView.Observation item=selectedShareObservation;
            if(item==null){
                android.widget.Toast.makeText(this,"Select an observed point first",android.widget.Toast.LENGTH_SHORT).show();return;
            }
            // Center the renderer actually visible on screen; the modern globe may be hidden.
            if(originalMode && originalEarth instanceof SatelliteMapView){inspectObservation(item,true);}
            else if(!earth.duwmP3FocusObservation(item)){
                android.widget.Toast.makeText(this,"Observation is no longer current",android.widget.Toast.LENGTH_SHORT).show();
            }
        });
        p3Map.setOnClickListener(v->{
            OperationsGlobeView.Observation item=selectedShareObservation;
            if(item==null || !Double.isFinite(item.lat) || !Double.isFinite(item.lon)){
                android.widget.Toast.makeText(this,"Select an observed point first",android.widget.Toast.LENGTH_SHORT).show();return;
            }
            Intent i=new Intent(this,DuwmPlaceMapActivity.class);
            i.putExtra("focus_lat",String.valueOf(item.lat));
            i.putExtra("focus_lon",String.valueOf(item.lon));
            startActivity(i);
        });
        LinearLayout layers=new LinearLayout(this);layers.setGravity(Gravity.CENTER_VERTICAL);layers.setPadding(dp(15),0,dp(12),0);rowAdd(globeFrame,layers,-1,35);
        airLayer=layer(layers,"AIRCRAFT",OperationsGlobeView.AIR);
        quakeLayer=layer(layers,"EARTHQUAKES",OperationsGlobeView.QUAKE);
        issLayer=layer(layers,"ISS",OperationsGlobeView.SPACE);
        detail=text("Drag to turn • pinch to zoom • tap an observed marker for details",11,MUTED,false);detail.setPadding(dp(16),dp(5),dp(16),dp(7));
        detail.setMaxLines(2);rowAdd(globeFrame,detail,-1,32);
        ScrollView infoScroll=new ScrollView(this);infoScroll.setFillViewport(false);root.addView(infoScroll,new LinearLayout.LayoutParams(-1,dp(0)));
        // Visible native observation board replaces the formerly truncated scroll of decorative metrics.
        // Older source cards stay in the view hierarchy for compatibility; all readings are sourced from the same payload.
        telemetryPanel=new OperationsTelemetryPanel(this);
        root.addView(telemetryPanel,new LinearLayout.LayoutParams(-1,dp(0)));
        newRail.setOnClickListener(v->{
            boolean expanded=telemetryPanel.getLayoutParams().height==0;
            LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)telemetryPanel.getLayoutParams();
            lp.height=dp(expanded?76:0);
            telemetryPanel.setLayoutParams(lp);
            android.widget.Toast.makeText(this,expanded?"Live source details expanded":"Live source details collapsed",
                android.widget.Toast.LENGTH_SHORT).show();
        });
        // Phone-native bottom dock: thumb reachable, one row, no permanent desktop grid.
        LinearLayout mobileDock=new LinearLayout(this);
        mobileDock.setGravity(Gravity.CENTER);
        mobileDock.setPadding(dp(9),dp(7),dp(9),dp(7));
        mobileDock.setContentDescription("DUWM five-tab mobile navigation");
        GradientDrawable dockBackground=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{Color.rgb(10,31,59),Color.rgb(4,17,37)});
        dockBackground.setStroke(dp(1),Color.rgb(40,92,145));
        mobileDock.setBackground(dockBackground);
        final android.content.SharedPreferences mobileUiPrefs=getSharedPreferences("duwm_mobile_ui",MODE_PRIVATE);
        final boolean[] compactDock={mobileUiPrefs.getBoolean("compact_dock",false)};
        root.addView(mobileDock,new LinearLayout.LayoutParams(-1,dp(compactDock[0]?56:72)));
        String[][] mobileDestinations={{"◉\\nEARTH","EARTH"},{"✈\\nAIRCRAFT","AIRCRAFT"},{"⚓\\nVESSELS","VESSELS"},
            {"▣\\nNEWS","WORLD NEWS"},{"☷\\nEXPLORE","MORE"}};
        int[] dockAccents={Color.rgb(89,212,225),Color.rgb(89,174,239),Color.rgb(66,186,214),
            Color.rgb(187,131,239),Color.rgb(240,196,101)};
        for(int m=0;m<mobileDestinations.length;m++){
            final String target=mobileDestinations[m][1];
            TextView dockItem=action(mobileDestinations[m][0],"Open "+mobileDestinations[m][0]);
            dockItem.setTextSize(10);dockItem.setTextColor(dockAccents[m]);
            dockItem.setMaxLines(2);dockItem.setLineSpacing(dp(2),1.0f);
            dockItem.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));
            dockItem.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));
            dockItem.setLetterSpacing(0.035f);
            dockItem.setGravity(Gravity.CENTER);
            dockItem.setMinHeight(dp(48));
            dockItem.setContentDescription("Open "+mobileDestinations[m][1]+" monitoring desk. Long press for shortcut actions.");
            dockItem.setFocusable(true);
            dockItem.setClickable(true);
            GradientDrawable dockTile=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(19,46,79),Color.rgb(7,25,50)});
            dockTile.setCornerRadius(dp(15));
            dockTile.setStroke(dp(1),dockAccents[m]);
            dockItem.setElevation(dp(3));
            dockItem.setBackground(dockTile);
            if("EARTH".equals(target)){
                dockTile.setStroke(dp(2),dockAccents[m]);
                dockItem.setTextColor(Color.WHITE);
                dockItem.setSelected(true);
            }
            LinearLayout.LayoutParams dockItemParams=new LinearLayout.LayoutParams(0,dp(compactDock[0]?42:54),1);
            dockItemParams.setMargins(dp(3),0,dp(3),0);
            mobileDock.addView(dockItem,dockItemParams);
            // Long press: access the existing favourite/last-desk controls from the thumb dock.
            dockItem.setOnLongClickListener(v->{
                dockItem.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                if("MORE".equals(target)){
                    deskSearch.performClick();
                }else if("EARTH".equals(target)){
                    focusControl.performClick();
                }else{
                    android.content.SharedPreferences prefs=getSharedPreferences("duwm_favourite_desks",MODE_PRIVATE);
                    boolean pinned=prefs.getBoolean(target,false);
                    prefs.edit().putBoolean(target,!pinned).apply();
                    android.widget.Toast.makeText(this,!pinned?"Pinned "+target:"Unpinned "+target,
                        android.widget.Toast.LENGTH_SHORT).show();
                    dockItem.setText((!pinned?"★  ":"")+mobileDestinations[("AIRCRAFT".equals(target)?1:"VESSELS".equals(target)?2:3)][0]);
                    dockItem.setContentDescription((!pinned?"Pinned ":"Unpinned ")+target+" monitoring desk");
                }
                return true;
            });
            if(!"EARTH".equals(target)&&!"MORE".equals(target)&&
                getSharedPreferences("duwm_favourite_desks",MODE_PRIVATE).getBoolean(target,false)){
                dockItem.setText("★  "+mobileDestinations[m][0]);
                dockItem.setContentDescription("Pinned "+target+" monitoring desk. Long press to unpin.");
            }
            dockItem.setOnClickListener(v->{
                dockItem.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
                if("MORE".equals(target)){
                    // Phone-native desk chooser: no tall dashboard grid obscuring the globe.
                    dockItem.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
                    final String[] names={"MOBILE DISPLAY","ALERT SETTINGS","SEARCH DESKS","RECENT DESK","SATELLITES","CITY CAMERAS","RADIO","TV STATIONS",
                        "WEATHER","EARTHQUAKES","EARTH IMAGES","INTERNET",
                        "ALL INTELLIGENCE","ORIGINAL COMMAND","1671 MISSION",
                        "1670 FLIGHT MAP","1670 NEWS ATLAS"};
                    final String[] labels={"▤  Mobile Display  ·  Dock size & globe space","⚠  Alert & Haptic Settings","⌕  Search Monitoring Desks","↺  Return to Recent Desk","◈  SATELLITES  ·  Orbital positions","◎  CITY CAMERAS  ·  Public feeds",
                        "♫  RADIO  ·  Listen live","▣  TELEVISION  ·  Watch stations",
                        "☁  WEATHER  ·  Forecasts & radar","◉  EARTHQUAKES  ·  USGS reports",
                        "◈  EARTH IMAGERY  ·  Source photos","⌁  INTERNET  ·  Network desk",
                        "☷  All Monitoring Desks","◉  Original Command",
                        "◈  Mission Control","✈  Flight Map","▣  News Atlas"};
                    new android.app.AlertDialog.Builder(this,android.app.AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                        .setTitle("WORLD SITUATION ROOM  /  EXPLORE")
                        .setItems(labels,(dialog,index)->{
                            String chosen=names[index];
                            if("ALERT SETTINGS".equals(chosen)){
                                boolean enabled=alertsEnabled();
                                new android.app.AlertDialog.Builder(this).setTitle("ALERT HAPTICS")
                                    .setMessage("Major earthquake alerts use source timestamps and are shown once per event. Vibration is optional.\n\nCurrent: "+(enabled?"ON":"OFF"))
                                    .setPositiveButton(enabled?"TURN OFF":"TURN ON",(d,w)->{
                                        getSharedPreferences("duwm_alert_settings",MODE_PRIVATE).edit().putBoolean("haptics",!enabled).apply();
                                        android.widget.Toast.makeText(this,"Alert haptics "+(!enabled?"enabled":"disabled"),android.widget.Toast.LENGTH_SHORT).show();
                                    }).setNegativeButton("CANCEL",null).show();
                                return;
                            }
                            if("MOBILE DISPLAY".equals(chosen)){
                                String[] options={"COMFORTABLE  ·  Larger 72dp navigation","COMPACT  ·  More globe space, 56dp navigation"};
                                new android.app.AlertDialog.Builder(this,android.app.AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                                    .setTitle("MOBILE DISPLAY")
                                    .setSingleChoiceItems(options,compactDock[0]?1:0,(choiceDialog,selected)->{
                                        compactDock[0]=(selected==1);
                                        mobileUiPrefs.edit().putBoolean("compact_dock",compactDock[0]).apply();
                                        LinearLayout.LayoutParams dockParams=(LinearLayout.LayoutParams)mobileDock.getLayoutParams();
                                        dockParams.height=dp(compactDock[0]?56:72);
                                        mobileDock.setLayoutParams(dockParams);
                                        for(int child=0;child<mobileDock.getChildCount();child++){
                                            android.view.View dockChild=mobileDock.getChildAt(child);
                                            LinearLayout.LayoutParams childParams=(LinearLayout.LayoutParams)dockChild.getLayoutParams();
                                            childParams.height=dp(compactDock[0]?42:54);
                                            dockChild.setLayoutParams(childParams);
                                        }
                                        mobileDock.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
                                        choiceDialog.dismiss();
                                    }).setNegativeButton("CANCEL",null).show();
                                return;
                            }
                            if("SEARCH DESKS".equals(chosen)){deskSearch.performClick();return;}
                            if("RECENT DESK".equals(chosen)){
                                String last=getSharedPreferences("duwm_recent_desk",MODE_PRIVATE).getString("last","");
                                if(last.isEmpty()){
                                    android.widget.Toast.makeText(this,"No recent monitoring desk yet",android.widget.Toast.LENGTH_SHORT).show();
                                }else{navigate(last);}
                                return;
                            }
                            getSharedPreferences("duwm_recent_desk",MODE_PRIVATE)
                                .edit().putString("last",chosen).apply();
                            navigate(chosen);
                        })
                        .setNegativeButton("CLOSE",null).show();
                }else if("EARTH".equals(target)){
                    if(fullEarth)focusControl.performClick();
                    globeFrame.requestLayout();
                }else{
                    getSharedPreferences("duwm_recent_desk",MODE_PRIVATE).edit().putString("last",target).apply();
                    navigate(target);
                }
            });
        }
        // Build 101 mobile-first: maximize the Earth viewport instead of stacking toolbars.
        // All original controls remain available through the DETAILS toggle.
        final boolean[] detailsExpanded={false};
        final android.view.View[] compactPanels={photoRail,verifiedRailRow,shareObserved,
            pulseEntry,p3GlobeControls,layers,detail};
        final TextView detailsToggle=action("DETAILS  +","Show additional Earth tools and source information");
        detailsToggle.setTextSize(11);
        detailsToggle.setTextColor(Color.rgb(224,244,255));
        detailsToggle.setBackground(bg(Color.rgb(11,42,77),10,Color.rgb(62,161,210)));
        LinearLayout.LayoutParams detailsParams=new LinearLayout.LayoutParams(0,dp(35),1);
        detailsParams.leftMargin=dp(6);
        globeControls.addView(detailsToggle,detailsParams);
        for(android.view.View panel:compactPanels)panel.setVisibility(View.GONE);
        detailsToggle.setOnClickListener(v->{
            detailsExpanded[0]=!detailsExpanded[0];
            for(android.view.View panel:compactPanels)
                panel.setVisibility(detailsExpanded[0]?View.VISIBLE:View.GONE);
            detailsToggle.setText(detailsExpanded[0]?"DETAILS  −":"DETAILS  +");
            detailsToggle.setContentDescription(detailsExpanded[0]?
                "Hide additional Earth controls":"Show additional Earth controls");
            detailsToggle.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
        });
        focusControl.setOnClickListener(v->{
            fullEarth=!fullEarth;
            // The preserved native SatelliteMapView grows when the weighted frame remeasures.
            photoRail.setVisibility(!fullEarth&&detailsExpanded[0]?View.VISIBLE:View.GONE);
            verifiedRailRow.setVisibility(!fullEarth&&detailsExpanded[0]?View.VISIBLE:View.GONE);
            shareObserved.setVisibility(!fullEarth&&detailsExpanded[0]?View.VISIBLE:View.GONE);
            pulseEntry.setVisibility(!fullEarth&&detailsExpanded[0]?View.VISIBLE:View.GONE);
            p3GlobeControls.setVisibility(!fullEarth&&detailsExpanded[0]?View.VISIBLE:View.GONE);
            advancedGlobeControls.setVisibility(fullEarth?View.GONE:(toolsExpanded[0]?View.VISIBLE:View.GONE));
            viewGlobeControls.setVisibility(fullEarth?View.GONE:(toolsExpanded[0]?View.VISIBLE:View.GONE));
            metadata.setVisibility(fullEarth?View.GONE:View.VISIBLE);
            scroller.setVisibility(fullEarth?View.GONE:View.GONE);
            deskBar.setVisibility(View.GONE);
            recentRibbon.setVisibility(View.GONE);
            allDesks.setText("☷  DESKS & RECENTS  ▾");
            allDesks.setVisibility(View.GONE);
            mobileDock.setVisibility(fullEarth?View.GONE:View.VISIBLE);
            detailsToggle.setVisibility(fullEarth?View.GONE:View.VISIBLE);
            telemetryPanel.setVisibility(fullEarth?View.GONE:View.VISIBLE);
            // Hide overlays in focus mode to keep the original globe unobstructed.
            selectedObservation.setVisibility(fullEarth?View.GONE:(selectedItem==null?View.GONE:View.VISIBLE));
            originalHud.setVisibility(fullEarth?View.GONE:(originalMode?View.GONE:View.VISIBLE));
            layers.setVisibility(!fullEarth&&detailsExpanded[0]?View.VISIBLE:View.GONE);
            detail.setVisibility(!fullEarth&&detailsExpanded[0]?View.VISIBLE:View.GONE);
            focusControl.setText(fullEarth?"RESTORE":"FOCUS");
            focusControl.setContentDescription(fullEarth?"Restore source panels and tabs":"Expand modern HD Earth globe full-screen");
            globeLabel.setText(fullEarth?"MODERN HD EARTH  /  FULL-SCREEN LIVE GLOBE":
                originalMode?"ORIGINAL GLOBE  /  OBSERVED WORLD POSITIONS":"MODERN HD EARTH  /  OBSERVED WORLD POSITIONS");
            if(originalMode && originalEarth!=null){
                originalEarth.requestLayout();originalEarth.postInvalidateOnAnimation();
            }else{earth.requestLayout();earth.postInvalidateOnAnimation();}
        });
        telemetryPanel.setOnSelect(item->inspectObservation(item,true));
        LinearLayout information=new LinearLayout(this);information.setOrientation(LinearLayout.VERTICAL);information.setPadding(dp(13),dp(11),dp(13),dp(14));infoScroll.addView(information);
        LinearLayout titleRow=new LinearLayout(this);titleRow.setGravity(Gravity.CENTER_VERTICAL);information.addView(titleRow,new LinearLayout.LayoutParams(-1,dp(32)));
        TextView section=text("OBSERVATION STATUS / LIVE RECEIPTS",12,TEXT,true);titleRow.addView(section,new LinearLayout.LayoutParams(0,-2,1));
        TextView refresh=action("REFRESH","Request updated observed records");rowAdd(titleRow,refresh,94,36);refresh.setOnClickListener(v->refresh());
        summaryText=text("No remote source has responded",11,MUTED,false);summaryText.setPadding(dp(2),dp(7),0,dp(9));information.addView(summaryText);
        android.widget.HorizontalScrollView metricScroll=new android.widget.HorizontalScrollView(this);metricScroll.setHorizontalScrollBarEnabled(false);
        information.addView(metricScroll,new LinearLayout.LayoutParams(-1,dp(104)));
        LinearLayout cards=new LinearLayout(this);metricScroll.addView(cards);
        LinearLayout airCard=metric(cards,"AIRCRAFT / OPENSKY");duwm1166AirLed=new Duwm1166SignalView(this);airCard.addView(duwm1166AirLed,new LinearLayout.LayoutParams(dp(27),dp(22)));airCount=text("—",19,TEXT,true);airCard.addView(airCount);airSource=text("NOT CHECKED",10,MUTED,false);airSource.setMaxLines(2);airCard.addView(airSource);
        LinearLayout quakeCard=metric(cards,"QUAKES / USGS");duwm1166QuakeLed=new Duwm1166SignalView(this);quakeCard.addView(duwm1166QuakeLed,new LinearLayout.LayoutParams(dp(27),dp(22)));quakeCount=text("—",19,TEXT,true);quakeCard.addView(quakeCount);quakeSource=text("NOT CHECKED",10,MUTED,false);quakeSource.setMaxLines(2);quakeCard.addView(quakeSource);
        LinearLayout issCard=metric(cards,"ISS / OBSERVED");duwm1166IssLed=new Duwm1166SignalView(this);issCard.addView(duwm1166IssLed,new LinearLayout.LayoutParams(dp(27),dp(22)));issCount=text("—",19,TEXT,true);issCard.addView(issCount);issSource=text("NOT CHECKED",10,MUTED,false);issSource.setMaxLines(2);issCard.addView(issSource);
        LinearLayout seaCard=metric(cards,"VESSELS / AIS");Duwm1166SignalView vesselLed=new Duwm1166SignalView(this);
        vesselLed.source("VESSEL",0,0,false,false);seaCard.addView(vesselLed,new LinearLayout.LayoutParams(dp(27),dp(22)));
        TextView vesselCount=text("—",19,TEXT,true);seaCard.addView(vesselCount);
        seaCard.addView(text("FINNISH AIS  •  SEE SOURCE BOARD",10,MUTED,false));
        seaCard.setOnClickListener(v->{Intent i=new Intent(this,Duwm1166RecordsActivity.class);i.putExtra("kind","VESSELS");startActivity(i);});
        TextView foot=text("Source counts and markers are based on received records. An unavailable feed is not evidence of no activity. AIS vessels and embedded cameras require approved providers.",11,MUTED,false);
        foot.setPadding(dp(3),dp(12),dp(3),dp(8));information.addView(foot);
        TextView original=action("ORIGINAL COMMAND  /  ALL LEGACY TOOLS","Open the preserved command centre in this same app");
        information.addView(original,new LinearLayout.LayoutParams(-1,dp(48)));original.setOnClickListener(v->{Intent i=new Intent(this,MainActivity.class);startActivity(i);});
        // V1159.4: MODERN HD globe remains the first screen. Protected original is optional.
        earth.setVisibility(View.VISIBLE);
        originalHud.setVisibility(View.GONE);
        // 1165 DETAIL RESTORE: show the actual high-resolution Natural Earth coastline
        // renderer on first launch. The alternate legacy Canvas globe remains available
        // via the LEGACY button, but must not replace the preferred detailed Earth.
        // Do not call switchOriginalRenderer() on startup: it installs simplified
        // LAND_MASSES polygons and white triangle flight icons over the detailed coast.
        originalMode=false;
        earth.setVisibility(View.VISIBLE);
        originalHud.setVisibility(View.GONE);
        earth.postInvalidateOnAnimation();
    }
    /** Reuse the actual original native SatelliteMapView in the same screen, without copying or replacing it.
     * Original legacy globe and wallpaper code are kept intact. This fails visibly when the old renderer
     * requires application-specific setup; it never substitutes invented positions.
     */
    private void inspectObservation(OperationsGlobeView.Observation item,boolean focus){
        if(item==null)return;
        // The original view remains available, but geolocating always uses the real observation-aware globe.
        // Keep the actual original globe on-screen even when locating a source observation.
        selectedItem=item;
        String sector=item.type==OperationsGlobeView.AIR?"AIRCRAFT":item.type==OperationsGlobeView.QUAKE?"EARTHQUAKE":"ISS SATELLITE";
        selectedTitle.setText(sector+"  /  "+item.title);
        selectedDetail.setText(item.detail+"  •  "+item.source+"  •  "+(item.timeMillis>0?utc(item.timeMillis)+" UTC":"SOURCE TIME UNKNOWN"));
        selectedAction.setVisibility(item.type==OperationsGlobeView.AIR?View.VISIBLE:View.GONE);
        selectedObservation.setVisibility(View.VISIBLE);
        detail.setText("LOCATED "+item.title+"  •  "+String.format(Locale.US,"%.4f°, %.4f°",item.lat,item.lon));
        if(focus){
            if(originalMode && originalEarth instanceof SatelliteMapView){
                SatelliteMapView nativeGlobe=(SatelliteMapView)originalEarth;
                // The coordinates are supplied by OpenSky, USGS or the observed ISS source.
                nativeGlobe.setCenter(item.lat,item.lon,nativeGlobe.getZoom());
                nativeGlobe.setGlobeMode(true);
                nativeGlobe.invalidate();
            }else{
                rotate=false;rotationControl.setText("ROTATION  OFF");earth.pause();earth.focusAt(item.lat,item.lon);
            }
        }
    }
    private final List<OperationsGlobeView.Observation> earthObservations=new ArrayList<>();
    /** Adapt only received geolocated source records for the protected original globe renderer.
     * Never create random aircraft, approximate positions or invented timestamps. */
    private List<Signal> toNativeSignals(List<OperationsGlobeView.Observation> received){
        List<Signal> plotted=new ArrayList<>();
        for(OperationsGlobeView.Observation a:received){
            if(a==null||a.timeMillis<=0||!valid(a.lat,a.lon))continue;
            if(a.type==OperationsGlobeView.AIR&&!viewAir)continue;
            if(a.type==OperationsGlobeView.QUAKE&&!viewQuakes)continue;
            if(a.type==OperationsGlobeView.SPACE&&!viewIss)continue;
            Signal.Layer layer=a.type==OperationsGlobeView.AIR?Signal.Layer.FLIGHTS:
                a.type==OperationsGlobeView.QUAKE?Signal.Layer.NATURAL:Signal.Layer.SATELLITES;
            String url=a.type==OperationsGlobeView.AIR?"https://opensky-network.org/":
                a.type==OperationsGlobeView.QUAKE?"https://earthquake.usgs.gov/":"https://wheretheiss.at/";
            // Unknown speed and heading remain unknown; 0 would incorrectly imply observed stationarity.
            String id="observed-"+a.type+"-"+a.title+"-"+(a.type==OperationsGlobeView.AIR?a.source:a.timeMillis);
            plotted.add(new Signal(id,layer,a.title,a.detail,a.lat,a.lon,
                Double.NaN,Double.NaN,a.timeMillis,a.source,url,Signal.Credibility.PUBLIC_SOURCE,
                "","OBSERVED_SOURCE_RECORD",0,java.util.Collections.emptyMap()));
        }
        return plotted;
    }
    private void switchOriginalRenderer(){
        if(originalMode){
            if(originalEarth!=null){earthViewport.removeView(originalEarth);originalEarth=null;}
            earth.setVisibility(View.VISIBLE);originalMode=false;
            originalHud.setVisibility(View.GONE);
            rotationControl.setText(rotate?"ROTATION  ON":"ROTATION  OFF");
            originalToggle.setText("LEGACY");
            originalToggle.setContentDescription("Switch to alternate legacy globe for comparison");
            if(foreground&&rotate)earth.resume();
            return;
        }
        try{
            Class<?> type=Class.forName("com.sentongoharuna.worldsituationroom.SatelliteMapView");
            Object instance=null;
            try {Constructor<?> ctor=type.getDeclaredConstructor(android.content.Context.class);ctor.setAccessible(true);instance=ctor.newInstance(this);}
            catch(NoSuchMethodException missing){
                Constructor<?> ctor=type.getDeclaredConstructor(android.content.Context.class,AttributeSet.class);
                ctor.setAccessible(true);instance=ctor.newInstance(this,null);
            }
            if(!(instance instanceof SatelliteMapView))throw new IllegalStateException("Original globe renderer not found");
            SatelliteMapView nativeGlobe=(SatelliteMapView)instance;
            // Verified original V24 class has a dedicated full-sphere globe mode and its own rotation engine.
            nativeGlobe.setGlobeMode(true);
            nativeGlobe.setAutoRotationEnabled(rotate);
            // Restore exact-record tapping on the original detailed globe.
            // Only a source observation already present in this app may be shared.
            nativeGlobe.setListener(new SatelliteMapView.Listener(){
                @Override public void onSignalTap(Signal signal){
                    if(signal==null)return;
                    for(OperationsGlobeView.Observation observed:earthObservations){
                        if(observed==null || observed.title==null)continue;
                        if(observed.title.equals(signal.title) &&
                           Math.abs(observed.lat-signal.latitude)<0.0001d &&
                           Math.abs(observed.lon-signal.longitude)<0.0001d){
                            selectedShareObservation=observed;
                            inspectObservation(observed,false);
                            return;
                        }
                    }
                    detail.setText("SOURCE SIGNAL / "+signal.title+" / no matching current observation to share");
                }
                @Override public void onViewportChanged(SatelliteMapView.Bounds bounds){}
            });
            originalEarth=nativeGlobe;
            earth.pause();earth.setVisibility(View.GONE);
            earthViewport.addView(originalEarth,0,new FrameLayout.LayoutParams(-1,-1));
            originalHud.setVisibility(View.GONE);
            originalMode=true;originalToggle.setText("DETAILED");
            originalToggle.setContentDescription("Return to preferred detailed Earth globe");
            rotationControl.setText(rotate?"ROTATION ON":"ROTATION OFF");
            nativeGlobe.setSignals(toNativeSignals(earthObservations));
            nativeGlobe.invalidate();
            liveReadout.setText("ORIGINAL GLOBE  /  OBSERVED DATA  /  NATIVE MOTION");
        }catch(Exception ex){
            if(originalEarth!=null)earthViewport.removeView(originalEarth);
            originalMode=false;originalEarth=null;earth.setVisibility(View.VISIBLE);originalHud.setVisibility(View.VISIBLE);
            originalToggle.setText("ORIGINAL VIEW FAILED");rotationControl.setText("OFFLINE");
            if(foreground&&rotate)earth.resume();
            String msg=ex.getCause()!=null?ex.getCause().getClass().getSimpleName():ex.getClass().getSimpleName();
            liveReadout.setText("ORIGINAL VIEW UNAVAILABLE: "+msg);
        }
    }
    private TextView layer(LinearLayout parent,String label,int type){TextView v=text("● "+label,11,type==OperationsGlobeView.AIR?ACCENT:type==OperationsGlobeView.QUAKE?WARN:Color.rgb(76, 120, 196),true);
        v.setGravity(Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(44),type==OperationsGlobeView.QUAKE?1.25f:1);parent.addView(v,p);
        v.setContentDescription("Toggle " + label + " map layer");v.setOnClickListener(w->{boolean next;if(type==OperationsGlobeView.AIR){viewAir=!viewAir;next=viewAir;}
            else if(type==OperationsGlobeView.QUAKE){viewQuakes=!viewQuakes;next=viewQuakes;}else {viewIss=!viewIss;next=viewIss;}
            earth.showLayer(type,next);v.setAlpha(next?1f:.35f);
            if(telemetryPanel!=null)telemetryPanel.setVisibilityLayers(viewAir,viewQuakes,viewIss);
            if(originalMode&&originalEarth instanceof SatelliteMapView){
                ((SatelliteMapView)originalEarth).setSignals(toNativeSignals(earthObservations));
            }});return v;}
    private void applyFocus(Intent intent){
        if(earth==null||intent==null||!intent.hasExtra("focus_lat")||!intent.hasExtra("focus_lon"))return;
        double lat=intent.getDoubleExtra("focus_lat",Double.NaN),lon=intent.getDoubleExtra("focus_lon",Double.NaN);
        if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)return;
        rotate=false;rotationControl.setText("ROTATION  OFF");earth.pause();earth.focusAt(lat,lon);
        detail.setText(intent.getStringExtra("focus_label")+"  |  "+String.format(Locale.US,"%.4f°, %.4f°",lat,lon));
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);applyFocus(intent);}
    @Override protected void onResume(){super.onResume();foreground=true;applyFocus(getIntent());
        if(newRail!=null)newRail.resume();
        if(rotate&&!originalMode)earth.resume();
        if(originalMode&&originalEarth!=null)originalEarth.postInvalidateOnAnimation();
        main.post(second);
    }
    @Override protected void onPause(){foreground=false;if(newRail!=null)newRail.pause();earth.pause();main.removeCallbacks(second);super.onPause();}
    @Override protected void onDestroy(){network.shutdownNow();super.onDestroy();}

    private String get(String address,int limit) throws Exception {
        if(!address.startsWith("https://"))throw new java.io.IOException("HTTPS required");
        HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);
        c.setRequestProperty("User-Agent","DevelopUgandaOperations/1155");c.setRequestProperty("Accept","application/json");
        try{int code=c.getResponseCode();if(code!=200)throw new java.io.IOException("HTTP "+code);
            StringBuilder s=new StringBuilder();try(InputStream in=c.getInputStream();BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"))){
                char[] buf=new char[4096];int n;while((n=r.read(buf))!=-1){s.append(buf,0,n);if(s.length()>limit)throw new java.io.IOException("Response exceeds source limit");}}
            return s.toString();
        }finally{c.disconnect();}
    }
    private boolean valid(double lat,double lon){return Double.isFinite(lat)&&Double.isFinite(lon)&&lat>=-90&&lat<=90&&lon>=-180&&lon<=180;}
    private String error(Exception ex){String e=ex.getMessage();if(e==null)e=ex.getClass().getSimpleName();return e.length()>65?e.substring(0,65):e;}
    private void refresh(){if(!fetching.compareAndSet(false,true))return;lastAttempt=SystemClock.elapsedRealtime();
        headerStatus.setText("SYNCING");summaryText.setText("Requesting observed records from source providers…");
        if(telemetryPanel!=null)telemetryPanel.setSyncing();
        network.execute(()->{
            List<OperationsGlobeView.Observation> observations=new ArrayList<>();
            int sourceOk=0,sourceCount=3, aircraftReported=0,located=0,quakesReported=0;
            String air="NO RESPONSE",quake="NO RESPONSE",iss="NO RESPONSE",issValue="—";
            String aircraftValue="—",quakeValue="—";
            String majorEventId=null,majorEventTitle=null;long majorEventTime=0;
            try{
                JSONObject payload=new JSONObject(get("https://opensky-network.org/api/states/all",6500000));
                AirTrackStore.publish(payload); // Same real OpenSky snapshot powers globe and searchable register.
                JSONArray a=payload.optJSONArray("states");if(a==null)throw new java.io.IOException("States array absent");
                aircraftReported=a.length();int skip=Math.max(1,a.length()/900);long observedTime=payload.optLong("time",0)*1000L;
                for(int i=0;i<a.length();i++){JSONArray x=a.optJSONArray(i);if(x==null||x.isNull(5)||x.isNull(6))continue;
                    double lon=x.optDouble(5,Double.NaN),lat=x.optDouble(6,Double.NaN);if(!valid(lat,lon))continue;located++;
                    if(i%skip!=0)continue;String callsign=x.optString(1,"").trim();String ident=x.optString(0,"");if(callsign.isEmpty())callsign=ident;
                    double altitude=x.optDouble(7,Double.NaN),speed=x.optDouble(9,Double.NaN);
                    String info=String.format(Locale.US,"%.3f°, %.3f° • alt %s • speed %s",lat,lon,Double.isFinite(altitude)?String.format(Locale.US,"%.0f m",altitude):"unknown",Double.isFinite(speed)?String.format(Locale.US,"%.0f m/s",speed):"unknown");
                    observations.add(new OperationsGlobeView.Observation(OperationsGlobeView.AIR,lat,lon,callsign,info,"OpenSky",observedTime));
                }
                sourceOk++;aircraftValue=String.format(Locale.US,"%,d",aircraftReported);
                air="Observed "+(observedTime>0?utc(observedTime)+" UTC":"UTC not supplied");
            }catch(Exception ex){air="Unavailable: "+error(ex);}
            try{
                JSONObject payload=new JSONObject(get("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson",1500000));
                JSONArray arr=payload.getJSONArray("features");quakesReported=arr.length();
                for(int i=0;i<Math.min(arr.length(),350);i++){JSONObject event=arr.optJSONObject(i);if(event==null)continue;
                    JSONObject g=event.optJSONObject("geometry"),prop=event.optJSONObject("properties");if(g==null||prop==null)continue;
                    JSONArray coords=g.optJSONArray("coordinates");if(coords==null||coords.length()<2)continue;
                    double lon=coords.optDouble(0,Double.NaN),lat=coords.optDouble(1,Double.NaN);if(!valid(lat,lon))continue;
                    double magnitude=prop.optDouble("mag",0);
                    String title="M"+String.format(Locale.US,"%.1f",magnitude) + "  "+prop.optString("place","location not reported");
                    long eventTime=prop.optLong("time",0);
                    if(magnitude>=6.0 && eventTime>majorEventTime){
                        majorEventId=event.optString("id","");majorEventTitle=title;majorEventTime=eventTime;
                    }
                    observations.add(new OperationsGlobeView.Observation(OperationsGlobeView.QUAKE,lat,lon,title,String.format(Locale.US,"%.3f°, %.3f°",lat,lon),"USGS",prop.optLong("time",0)));
                }
                sourceOk++;quakeValue=Integer.toString(quakesReported);quake="M4.5+ / last 24 h";
            }catch(Exception ex){quake="Unavailable: "+error(ex);}
            try{
                JSONObject data=new JSONObject(get("https://api.wheretheiss.at/v1/satellites/25544",85000));
                double lat=data.optDouble("latitude",Double.NaN),lon=data.optDouble("longitude",Double.NaN);
                long seen=data.optLong("timestamp",0)*1000L;
                if(!valid(lat,lon)||seen<=0||Math.abs(System.currentTimeMillis()-seen)>900000L)throw new java.io.IOException("Stale or missing reported position");
                observations.add(new OperationsGlobeView.Observation(OperationsGlobeView.SPACE,lat,lon,"ISS — International Space Station",String.format(Locale.US,"%.3f°, %.3f° • altitude %.1f km",lat,lon,data.optDouble("altitude",0)),"Where The ISS At",seen));
                issValue="POSITION";iss="Observed "+utc(seen)+" UTC";sourceOk++;
            }catch(Exception ex){iss="Unavailable: "+error(ex);}
            final String fa=air,fq=quake,fi=iss,fav=aircraftValue,fqv=quakeValue,fiv=issValue;
            final int ok=sourceOk, plotted=observations.size(),validPositions=located,totalAir=aircraftReported,totalQuakes=quakesReported;
            final String alertId=majorEventId,alertTitle=majorEventTitle;
            final long alertTime=majorEventTime;
            main.post(()->{fetching.set(false);if(isFinishing()||isDestroyed())return;
                if(alertId!=null)majorQuakeAlert(alertId,alertTitle,alertTime);
                airCount.setText(fav);quakeCount.setText(fqv);issCount.setText(fiv);
                airSource.setText(fa);quakeSource.setText(fq);issSource.setText(fi);
                long lastAir=0,lastQuake=0,lastISS=0;
                for(OperationsGlobeView.Observation report:observations){
                  if(report.type==OperationsGlobeView.AIR)lastAir=Math.max(lastAir,report.timeMillis);
                  else if(report.type==OperationsGlobeView.QUAKE)lastQuake=Math.max(lastQuake,report.timeMillis);
                  else if(report.type==OperationsGlobeView.SPACE)lastISS=Math.max(lastISS,report.timeMillis);
                }
                long reportedAt=System.currentTimeMillis();
                duwm1166AirLed.source("AIRCRAFT",lastAir,fa.startsWith("Unavailable")?0:reportedAt,false,fa.startsWith("Unavailable"));
                duwm1166QuakeLed.source("EARTHQUAKE",lastQuake,fq.startsWith("Unavailable")?0:reportedAt,false,fq.startsWith("Unavailable"));
                duwm1166IssLed.source("ISS",lastISS,fi.startsWith("Unavailable")?0:reportedAt,false,fi.startsWith("Unavailable"));
                // 1668: make the same real provider fixes available to the optional geo lens.
                // Never publish an empty or failed provider response as a synthetic record.
                for(String kind:new String[]{"AIRCRAFT","EARTHQUAKE","ISS"}){
                    ArrayList<DuwmGeoObservationStore.Fix> fresh=new ArrayList<>();
                    for(OperationsGlobeView.Observation o:observations){
                        String observedKind=o.type==OperationsGlobeView.AIR?"AIRCRAFT":
                            o.type==OperationsGlobeView.QUAKE?"EARTHQUAKE":"ISS";
                        if(!kind.equals(observedKind)||o.timeMillis<=0)continue;
                        String providerUrl=kind.equals("AIRCRAFT")?"https://opensky-network.org/":
                            kind.equals("EARTHQUAKE")?"https://earthquake.usgs.gov/":"https://wheretheiss.at/";
                        String stableId=kind+":"+o.source+":"+o.title+
                            (kind.equals("EARTHQUAKE")?":"+o.timeMillis:"");
                        if(fresh.size()>=155)break; // reserve space for other actual source types
                        fresh.add(new DuwmGeoObservationStore.Fix(stableId,kind,o.title,o.detail,
                            o.source,providerUrl,o.timeMillis,reportedAt,o.lat,o.lon,null,null,0));
                    }
                    if(!fresh.isEmpty())DuwmGeoObservationStore.publishType(this,kind,fresh);
                }
                earth.setObservations(observations);
                earthObservations.clear();earthObservations.addAll(observations);
                if(originalMode && originalEarth instanceof SatelliteMapView){
                    ((SatelliteMapView)originalEarth).setSignals(toNativeSignals(earthObservations));
                }
                if(telemetryPanel!=null)telemetryPanel.update(observations,ok,totalAir,totalQuakes,fa,fq,fi,System.currentTimeMillis());
                liveReadout.setText((originalMode?"ORIGINAL NATIVE GLOBE  /  ":"LIVE EARTH  /  ")+ok+"/3 SOURCES  •  "+plotted+" VERIFIED PINS");
                headerStatus.setText(ok>0?ok+"/3 READY":"OFFLINE");
                sourceHeartbeat.setText(ok>0?(ok+"/3 SOURCES  ·  "+plotted+" VERIFIED LOCATIONS"):
                   "NO SOURCE RESPONSE");
                sourceHeartbeat.setContentDescription(ok>0?("Source receipts: "+ok+" of 3 providers connected, "+plotted+" observed locations"):
                   "No source responded. Counts are not zero observations.");
                updatedText.setText(ok>0?"SYNC " + utc(System.currentTimeMillis()).substring(12)+" UTC":"SOURCE UNAVAILABLE");
                summaryText.setText(ok+" of "+sourceCount+" providers responded • "+plotted+" mapped observations • "+validPositions+" located aircraft of "+totalAir+" reported");
            });
        });
    }
}
