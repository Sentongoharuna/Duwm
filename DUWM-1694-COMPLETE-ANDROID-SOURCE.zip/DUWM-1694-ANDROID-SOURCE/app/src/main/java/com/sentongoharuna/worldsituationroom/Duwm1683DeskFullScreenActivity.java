package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Real, full-screen source-detail destination for all nineteen intelligence desks.
 * Data comes from the on-device receipt of its linked provider; unavailable stays unavailable.
 */
public final class Duwm1683DeskFullScreenActivity extends Activity {
    public static final String EXTRA_DESK_INDEX="duwm1683_desk_index";
    private Duwm1683DeskCatalog.Desk desk;
    private TextView receipt,provider,headline,countBadge,sourceAge,coverage,errorBadge;
    private int deskIndex=-1;
    private final Handler clock=new Handler(Looper.getMainLooper());
    private boolean visible;
    private final Runnable poll=new Runnable(){@Override public void run(){
        if(!visible)return;updateReceipt();clock.postDelayed(this,30000L);
    }};
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView label(String value,int size,int color,boolean bold){
        TextView v=new TextView(this);v.setText(value);v.setTextColor(color);v.setTextSize(size);
        if(bold)v.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        v.setPadding(dp(7),dp(7),dp(7),dp(7));return v;
    }
    private GradientDrawable panel(){
        GradientDrawable d=new GradientDrawable();d.setColor(DuwmUnifiedTheme.PANEL);
        d.setCornerRadius(dp(10));d.setStroke(dp(1),DuwmUnifiedTheme.BORDER);return d;
    }
    private TextView action(String value,Runnable fn){
        TextView t=label(value,12,DuwmUnifiedTheme.ACCENT_BRIGHT,true);
        t.setGravity(Gravity.CENTER);t.setBackground(panel());t.setOnClickListener(v->fn.run());return t;
    }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        int index=getIntent().getIntExtra(EXTRA_DESK_INDEX,-1);
        deskIndex=index;
        if(index<0 || index>=Duwm1683DeskCatalog.ALL.length){finish();return;}
        desk=Duwm1683DeskCatalog.ALL[index];
        LinearLayout screen=new LinearLayout(this);screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(DuwmUnifiedTheme.BACKGROUND);setContentView(screen);
        LinearLayout toolbar=new LinearLayout(this);toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(9),dp(4),dp(9),dp(4));screen.addView(toolbar,new LinearLayout.LayoutParams(-1,dp(52)));
        toolbar.addView(action("‹ BACK",this::finish),new LinearLayout.LayoutParams(dp(86),-1));
        TextView name=label(desk.title.toUpperCase(java.util.Locale.US),15,DuwmUnifiedTheme.TEXT,true);
        name.setMaxLines(1);name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        toolbar.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        toolbar.addView(action("OPEN",()->startActivity(Duwm1683DeskCatalog.intent(this,desk))),new LinearLayout.LayoutParams(dp(80),-1));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);screen.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(13),dp(8),dp(13),dp(20));scroll.addView(body);
        TextView category=label("DUWM 1694  /  "+desk.category+"  /  FULL SCREEN",11,DuwmUnifiedTheme.ACCENT,true);body.addView(category);
        Duwm1684SectorVisual sectorCanvas=new Duwm1684SectorVisual(this,desk.title,true);
        LinearLayout.LayoutParams canvasLp=new LinearLayout.LayoutParams(-1,dp(207));
        canvasLp.topMargin=dp(9);canvasLp.bottomMargin=dp(11);
        body.addView(sectorCanvas,canvasLp);
        LinearLayout summaryBar=new LinearLayout(this);summaryBar.setGravity(Gravity.CENTER_VERTICAL);
        summaryBar.setPadding(dp(9),dp(5),dp(9),dp(5));summaryBar.setBackground(panel());
        TextView sector=label(Duwm1684SectorVisual.mode(desk.title).toUpperCase(java.util.Locale.US)+"  /  ORIGINAL DATA VIEW",12,DuwmUnifiedTheme.ACCENT_BRIGHT,true);
        summaryBar.addView(sector,new LinearLayout.LayoutParams(0,dp(40),1));
        TextView viewSource=action("OPEN DATA ↗",()->startActivity(Duwm1683DeskCatalog.intent(this,desk)));
        summaryBar.addView(viewSource,new LinearLayout.LayoutParams(dp(116),dp(42)));
        body.addView(summaryBar);
        TextView taskHeadline=label("WHAT YOU CAN INSPECT IN THIS DESK",12,DuwmUnifiedTheme.ACCENT,true);
        taskHeadline.setPadding(dp(4),dp(15),dp(4),dp(8));body.addView(taskHeadline);
        LinearLayout tasks=new LinearLayout(this);tasks.setOrientation(LinearLayout.VERTICAL);
        tasks.setPadding(dp(10),dp(5),dp(10),dp(6));tasks.setBackground(panel());
        for(String feature:features(desk.title))tasks.addView(label("◆  "+feature,13,DuwmUnifiedTheme.TEXT,false));
        body.addView(tasks);
        TextView sub=label(desk.subtitle,16,DuwmUnifiedTheme.TEXT,true);
        sub.setPadding(dp(5),dp(14),dp(5),dp(8));body.addView(sub);
        TextView sourceHeading=label("REAL PROVIDER RECEIPT  /  OBSERVATION STATUS",12,DuwmUnifiedTheme.ACCENT,true);
        sourceHeading.setPadding(dp(4),dp(15),dp(4),dp(7));body.addView(sourceHeading);
        LinearLayout compact=new LinearLayout(this);compact.setOrientation(LinearLayout.VERTICAL);
        compact.setPadding(dp(11),dp(8),dp(11),dp(8));compact.setBackground(panel());body.addView(compact);
        headline=label("CHECKING PROVIDER",17,DuwmUnifiedTheme.ACCENT_BRIGHT,true);compact.addView(headline);
        countBadge=label("RECORDS: --",16,DuwmUnifiedTheme.TEXT,true);compact.addView(countBadge);
        sourceAge=label("LAST RECEIPT: NOT RECEIVED",13,DuwmUnifiedTheme.MUTED,false);compact.addView(sourceAge);
        coverage=label("COVERAGE: UNKNOWN",12,DuwmUnifiedTheme.TEXT,false);compact.addView(coverage);
        errorBadge=label("LAST ERROR: NONE",12,DuwmUnifiedTheme.MUTED,false);compact.addView(errorBadge);
        LinearLayout control=new LinearLayout(this);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(48));cp.topMargin=dp(9);body.addView(control,cp);
        TextView refresh=action("REFRESH ACTUAL SOURCE",this::refreshSource);
        control.addView(refresh,new LinearLayout.LayoutParams(0,-1,1));
        TextView options=action("ALL DESKS",()->startActivity(new Intent(this,DuwmOptionsActivity.class)));
        LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(0,-1,1);op.leftMargin=dp(7);control.addView(options,op);
        receipt=label("CHECKING RECEIVED SOURCE",15,DuwmUnifiedTheme.ACCENT_BRIGHT,true);receipt.setBackground(panel());
        LinearLayout.LayoutParams recLp=new LinearLayout.LayoutParams(-1,-2);recLp.topMargin=dp(12);body.addView(receipt,recLp);
        TextView details=label("INFORMATION AVAILABLE",12,DuwmUnifiedTheme.ACCENT,true);details.setPadding(0,dp(20),0,dp(5));body.addView(details);
        body.addView(label(desk.description,15,DuwmUnifiedTheme.TEXT,false));
        body.addView(label("INTERPRETATION & COVERAGE",12,DuwmUnifiedTheme.ACCENT,true));
        body.addView(label(desk.howToRead,14,DuwmUnifiedTheme.TEXT,false));
        body.addView(label("PROVIDER / RECEIPTS / LAST ERROR",12,DuwmUnifiedTheme.ACCENT,true));
        provider=label("Waiting for latest local receipt",13,DuwmUnifiedTheme.MUTED,false);
        provider.setBackground(panel());body.addView(provider);
        LinearLayout row=new LinearLayout(this);LinearLayout.LayoutParams rowLp=new LinearLayout.LayoutParams(-1,dp(48));rowLp.topMargin=dp(15);body.addView(row,rowLp);
        row.addView(action("SOURCE HEALTH",()->startActivity(new Intent(this,Duwm1671SourceStatusActivity.class))),new LinearLayout.LayoutParams(0,-1,1));
        TextView share=action("SHARE",this::share);
        LinearLayout.LayoutParams shareLp=new LinearLayout.LayoutParams(0,-1,1);shareLp.leftMargin=dp(8);row.addView(share,shareLp);
        LinearLayout pager=new LinearLayout(this);
        LinearLayout.LayoutParams pagerLp=new LinearLayout.LayoutParams(-1,dp(46));pagerLp.topMargin=dp(9);body.addView(pager,pagerLp);
        pager.addView(action("‹ PREVIOUS DESK",()->move(-1)),new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout.LayoutParams nextLp=new LinearLayout.LayoutParams(0,-1,1);nextLp.leftMargin=dp(8);
        pager.addView(action("NEXT DESK ›",()->move(1)),nextLp);
        body.addView(label("VISUALIZATION NOTICE  /  The sector drawing is interface artwork, not a plotted track or new observation. Movement, reports, maps and media remain inside the native data page. Receipt timestamps distinguish real reports from saved data.",12,DuwmUnifiedTheme.MUTED,false));
        LinearLayout newWorkspace=panelShortcut();
        body.addView(newWorkspace);
        body.addView(Duwm1685MissionBoard.createShortcuts(this,desk));
        TextView trace=label("1687 PROVIDER RECEIPT HISTORY / NO FABRICATED TRACKS",12,DuwmUnifiedTheme.ACCENT,true);
        trace.setPadding(dp(4),dp(17),0,dp(8));body.addView(trace);
        Duwm1685ReceiptHistory.capture(this,desk);
        body.addView(new Duwm1685ReceiptChart(this,desk),new LinearLayout.LayoutParams(-1,dp(172)));
        updateReceipt();
    }
    private LinearLayout panelShortcut(){
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(8),dp(8),dp(8),dp(8));p.setBackground(panel());
        p.addView(label("DUWM 1686 / FIVE-PANEL DEEP INTELLIGENCE WORKSPACE",13,DuwmUnifiedTheme.ACCENT_BRIGHT,true));
        p.addView(action("OPEN FULL-SCREEN WORKSPACE / OVERVIEW • OBSERVATIONS • HISTORY • SOURCES • ACTIONS",
            ()->Duwm1687WorkspaceActivity.open(this,desk)),new LinearLayout.LayoutParams(-1,dp(59)));
        return p;
    }
    private void updateReceipt(){
        if(desk==null)return;
        Duwm1685ReceiptHistory.capture(this,desk);
        Duwm1684DeskDiagnostics.Snapshot snap=Duwm1684DeskDiagnostics.read(this,desk);
        receipt.setText(snap.shortLabel());
        provider.setText(snap.report());
        headline.setText("SOURCE STATE  /  "+snap.state);
        countBadge.setText("RECEIVED VALUE  /  "+snap.count);
        sourceAge.setText("LAST LOCAL RECEIPT  /  "+snap.received+"\nSOURCE OBSERVATION  /  "+snap.sourceTime);
        coverage.setText("COVERAGE  /  "+snap.coverage);
        errorBadge.setText("PROVIDER ERROR  /  "+snap.error);
    }
    /** Each sector exposes its own inspection checklist, not the same generic detail card. */
    private static String[] features(String title){
        String mode=Duwm1684SectorVisual.mode(title);
        switch(mode){
            case "AVIATION": return new String[]{"Actual aircraft identifier, callsign and position", "Altitude, velocity, heading and dated track fixes", "Provider limitation and receipt age"};
            case "MARITIME": return new String[]{"Select regional AIS receiver coverage", "Inspect MMSI, vessel speed, course and timestamp", "Compare separate authentic fixes before drawing movement"};
            case "SEISMIC": return new String[]{"USGS epicentre and event timestamp", "Magnitude, depth and geographic distance", "Source receipt and event record details"};
            case "WEATHER": return new String[]{"Temperature, wind and forecast period", "Regional model-grid coverage", "Issued-time versus observation-time comparison"};
            case "SPACE": return new String[]{"Orbital identifiers and time-labelled observations", "NASA imagery provenance or calculated trajectory", "Image acquisition timestamp and source credits"};
            case "NEWSROOM": return new String[]{"Verified publisher headline and publication time", "Story photograph when available with attribution", "Open original story and share its source"};
            case "RADIO": return new String[]{"Stations and countries in the real radio directory", "In-app stream playback where supported", "Source URL, stream status and station information"};
            case "TELEVISION": return new String[]{"Country, channel and media source", "Native video controls for playable sources", "Explain codec, access and network failures"};
            case "CAMERAS": return new String[]{"Public camera location and ownership", "Actual live stream or dated camera snapshot", "Source permissions and image provenance"};
            case "MARKETS": return new String[]{"Reference exchange rate and currency pair", "Source date and rate retrieval age", "Historical chart only when distinct receipts exist"};
            case "GEOGRAPHY": return new String[]{"Geographic source coordinates and map layers", "Saved regions and watch radius", "No invented incident coordinates or traffic flow"};
            case "SOURCE HEALTH": return new String[]{"Last successful provider receipt", "Provider errors, empty datasets and stale caches", "Source-by-source regional limitations"};
            case "EVIDENCE": return new String[]{"Captured, dated source-state records", "Compare receipts with different timestamps", "Export genuine original observations"};
            default: return new String[]{"Open the original native intelligence view", "Inspect provider/source metadata", "Distinguish local tools from actual live observations"};
        }
    }
    private void move(int offset){
        int n=Duwm1683DeskCatalog.ALL.length;
        int next=(deskIndex+offset+n)%n;
        Intent i=new Intent(this,Duwm1683DeskFullScreenActivity.class);
        i.putExtra(EXTRA_DESK_INDEX,next);startActivity(i);finish();
    }
    private void refreshSource(){
        if(desk.source==0){
            receipt.setText("REQUESTING AIRCRAFT PROVIDER / RESULTS MAY BE RATE LIMITED");
            RunningballV25GlobalAircraftData.refreshNow(this,this::updateReceipt);
        }else if(desk.source==2){
            receipt.setText("REQUESTING SELECTED REGIONAL AIS / COVERAGE NOT GUARANTEED");
            Duwm1674MaritimeRefresh.refresh(this,this::updateReceipt);
        }else if(desk.source==5){
            receipt.setText("REQUESTING NEWS PUBLISHER FEEDS / VERIFY ATTRIBUTION");
            RunningballV25NewsRepository.refresh(this,true,this::updateReceipt);
            RunningballV17Feeds.request(this,true,this::updateReceipt);
        }else{
            receipt.setText("NO ONE-TAP REFRESH FOR THIS DESK / OPEN SOURCE HEALTH");
            startActivity(new Intent(this,Duwm1671SourceStatusActivity.class));
        }
    }
    @Override protected void onResume(){super.onResume();visible=true;updateReceipt();clock.removeCallbacks(poll);clock.postDelayed(poll,30000L);}
    @Override protected void onPause(){visible=false;clock.removeCallbacks(poll);super.onPause();}
    private void share(){
        Duwm1687ShareCard.share(this,desk);
    }
}
