package com.sentongoharuna.worldsituationroom;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.TextView;

/** Unified title bar applied to existing screens in place. No extra overlay or command globe. */
public final class Duwm1693Chrome {
    private Duwm1693Chrome(){}
    public static TextView title(TextView title){
        Context context=title.getContext();
        float density=context.getResources().getDisplayMetrics().density;
        GradientDrawable background=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{0xFF174E5A,0xFF123A49,0xFF0B2331});
        background.setCornerRadius(12*density);
        background.setStroke(Math.max(1,(int)density),0xFF368C98);
        title.setBackground(background);
        title.setTextColor(0xFFF0FCFD);
        title.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));
        title.setPadding(Math.round(15*density),Math.round(9*density),Math.round(10*density),Math.round(9*density));
        title.setMinHeight(Math.round(52*density));
        title.setContentDescription(title.getText().toString()+". Tap to open provider health or original globe.");
        title.setText(title.getText().toString()+"  ↗");
        title.setOnClickListener(v->new AlertDialog.Builder(context)
            .setTitle("DUWM 1694 / SOURCE NAVIGATION")
            .setItems(new String[]{"VIEW ACTUAL PROVIDER RECEIPTS","RETURN TO ORIGINAL GLOBE"},
                (dialog,which)->{Intent intent=new Intent(context,which==0?Duwm1671SourceStatusActivity.class:MainActivity.class);
                    if(which==1)intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    context.startActivity(intent);}).show());
        return title;
    }
}
