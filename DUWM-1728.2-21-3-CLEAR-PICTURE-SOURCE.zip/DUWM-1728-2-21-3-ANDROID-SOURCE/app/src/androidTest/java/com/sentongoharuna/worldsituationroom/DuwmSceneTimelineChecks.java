package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.SystemClock;
import android.util.AtomicFile;
import android.widget.CheckBox;
import android.widget.EditText;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import org.json.JSONArray;
import org.json.JSONObject;

/** Test-APK-only synthetic observations -> real editor/renderer/codec evidence.
 * No image model is called. This stage does not verify model or camera accuracy. */
final class DuwmSceneTimelineChecks {
    private static final String FIRST="ALPHA TEST FRAME",SECOND="SECOND FIXTURE VIEW";
    private final DuwmNativeEvidence proof;private int checks;
    DuwmSceneTimelineChecks(DuwmNativeEvidence proof){this.proof=proof;}
    int count(){return checks;}
    private void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    private interface Action {void run()throws Exception;}
    private interface Condition {boolean ready()throws Exception;}
    private static void rethrow(Throwable failure)throws Exception{
        if(failure instanceof InvocationTargetException){rethrow(((InvocationTargetException)failure).getTargetException());return;}
        if(failure instanceof Error)throw (Error)failure;if(failure instanceof Exception)throw (Exception)failure;if(failure!=null)throw new RuntimeException(failure);
    }
    private void ui(Instrumentation runner,Action action)throws Exception{AtomicReference<Throwable> error=new AtomicReference<>();runner.runOnMainSync(()->{try{action.run();}catch(Throwable failure){error.set(failure);}});rethrow(error.get());}
    private static Object field(Object object,String name)throws Exception{java.lang.reflect.Field f=object.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(object);}
    private static void set(Object object,String name,Object value)throws Exception{java.lang.reflect.Field f=object.getClass().getDeclaredField(name);f.setAccessible(true);f.set(object,value);}
    private static Object call(Object object,String name)throws Exception{java.lang.reflect.Method m=object.getClass().getDeclaredMethod(name);m.setAccessible(true);try{return m.invoke(object);}catch(InvocationTargetException failure){rethrow(failure);return null;}}
    private void await(Instrumentation runner,Condition condition,String label)throws Exception{
        AtomicBoolean ready=new AtomicBoolean();long deadline=SystemClock.elapsedRealtime()+15000;
        do{ui(runner,()->ready.set(condition.ready()));if(ready.get())break;Thread.sleep(75);}while(SystemClock.elapsedRealtime()<deadline);check(ready.get(),label);
    }
    private Activity open(Instrumentation runner,Uri source,boolean storageFailure)throws Exception{
        Intent intent=new Intent(runner.getTargetContext(),Duwm1728VideoEditorActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(Duwm1728VideoEditorActivity.EXTRA_VIDEO_URI,source.toString())
            .putExtra("notes","Synthetic notes must not become a visual observation");
        if(storageFailure)intent.putExtra("scene_capture_enabled",true).putExtra("scene_capture_storage_error",true);
        Activity editor=runner.startActivitySync(intent);await(runner,()->(Boolean)field(editor,"prepared"),"Scene fixture editor prepares the actual source video");return editor;
    }
    private void finish(Instrumentation runner,Activity editor)throws Exception{if(editor==null)return;ui(runner,editor::finish);await(runner,editor::isDestroyed,"Scene fixture editor is destroyed before cleanup");}
    private static void copy(InputStream in,OutputStream out)throws Exception{byte[] bytes=new byte[65536];int count;while((count=in.read(bytes))!=-1)out.write(bytes,0,count);}
    private static List<Duwm1728SceneTimeline.Entry> supplied(){return Arrays.asList(
        new Duwm1728SceneTimeline.Entry(400,950,FIRST,"First synthetic observation belongs to this source time.",Duwm1728SceneTimeline.SOURCE),
        new Duwm1728SceneTimeline.Entry(1100,1700,SECOND,"Different fixture words appear after the recorded boundary.",Duwm1728SceneTimeline.SOURCE));}
    private void clearDraft(Context target,String key){check(target.getSharedPreferences("duwm_production_drafts",Context.MODE_PRIVATE).edit().remove(key).commit(),"Remove only this fixture-owned editor draft");}
    private Duwm1728OverlayRenderer.Spec editorContract(Instrumentation runner,Uri source)throws Exception{
        Context target=runner.getTargetContext();String key=Duwm1728CaptureTelemetry.storageKey(source);Activity editor=null;
        try{
            proof.phase("scene_timeline.empty_and_failed_capture");
            check(Duwm1728SceneStore.save(target,source,Collections.emptyList()),"Persist empty scene-enabled capture marker");
            check(Duwm1728SceneStore.hasCapture(target,source)&&Duwm1728SceneStore.load(target,source).isEmpty(),"Empty capture is distinct from imported footage");
            editor=open(runner,source,false);final Activity empty=editor;ui(runner,()->{
                Duwm1728OverlayRenderer.Spec s=(Duwm1728OverlayRenderer.Spec)field(empty,"previewSpec");
                check(s.automaticSceneTitles&&s.sceneTrack.isEmpty(),"Empty capture automatically selects neutral scene mode");
                check(!Duwm1728BroadcastLayout.currentScene(Duwm1728OverlayRenderer.reportAt(s,500),500),"Empty capture does not turn source notes into vision");
                check(s.title.isEmpty(),"Neutral scene fixture has no manually supplied static headline");Duwm1728OverlayRenderer.prepare(s);
                check(s.automaticSceneTitles,"Neutral scene export does not require personal headline entry");
            });finish(runner,editor);editor=null;clearDraft(target,key);
            new AtomicFile(new File(new File(target.getFilesDir(),"scene-timelines"),key+".json")).delete();
            check(!Duwm1728SceneStore.hasCapture(target,source),"Storage-failure fixture has no saved scene marker");
            editor=open(runner,source,true);final Activity failed=editor;ui(runner,()->{
                Duwm1728OverlayRenderer.Spec s=(Duwm1728OverlayRenderer.Spec)field(failed,"previewSpec");
                check(s.automaticSceneTitles&&s.sceneTrack.isEmpty(),"Storage failure retains neutral scene mode");
                check(((android.widget.TextView)field(failed,"automaticReportInfo")).getText().toString().contains("Frame descriptions could not be saved"),"Storage failure is explicitly reported");
            });finish(runner,editor);editor=null;
            editor=open(runner,source,false);final Activity restoredFailure=editor;ui(runner,()->{
                Duwm1728OverlayRenderer.Spec s=(Duwm1728OverlayRenderer.Spec)field(restoredFailure,"previewSpec");
                check(s.automaticSceneTitles&&s.sceneTrack.isEmpty()&&(Boolean)field(restoredFailure,"sceneCapture"),"Saved failed-capture draft stays neutral when reopened without camera extras");
                check((Boolean)field(restoredFailure,"sceneStorageError"),"Saved failed-capture status survives reopening");
            });finish(runner,editor);editor=null;clearDraft(target,key);
            check(Duwm1728SceneStore.save(target,source,supplied()),"Persist explicitly synthetic test observations");
            List<Duwm1728SceneTimeline.Entry> stored=Duwm1728SceneStore.load(target,source);check(stored.size()==2&&stored.get(1).atMs==1100&&SECOND.equals(stored.get(1).title),"Scene sidecar restores exact text and original milliseconds");
            proof.phase("scene_timeline.editor_and_draft");editor=open(runner,source,false);final Activity current=editor;
            AtomicReference<Duwm1728OverlayRenderer.Spec> selected=new AtomicReference<>();
            ui(runner,()->{
                check((Boolean)field(current,"automaticSceneTitles"),"New marked capture enables scene titles without manual selection");
                ((EditText)field(current,"from")).setText("0.250");((EditText)field(current,"to")).setText("1.900");
                ((EditText)field(current,"title")).setText("MANUAL FIXTURE HEADLINE");
                check(!(Boolean)field(current,"automaticSceneTitles")&&!((CheckBox)field(current,"sceneTitlesToggle")).isChecked(),"Manual headline edit switches scene titles off");
                check((Boolean)call(current,"saveDraft"),"Save manual scene takeover");call(current,"loadDraft");call(current,"refresh");
                check(!(Boolean)field(current,"automaticSceneTitles"),"Manual takeover survives draft reload");
                CheckBox toggle=(CheckBox)field(current,"sceneTitlesToggle");check(toggle.isEnabled(),"Recorded scene track can be deliberately reselected");toggle.setChecked(true);
                // Stage17 retains its original scene-description panel assertions;
                // stage19 separately verifies the new clear-picture default.
                ((CheckBox)field(current,"clearPictureToggle")).setChecked(false);
                set(current,"selectedComposition",Duwm1728BroadcastComposition.COMPACT);set(current,"selectedRatio","ORIGINAL");call(current,"refresh");
                check((Boolean)call(current,"saveDraft"),"Save selected scene track");call(current,"loadDraft");call(current,"refresh");
                check((Boolean)field(current,"automaticSceneTitles"),"Automatic scene selection survives draft reload");
                selected.set((Duwm1728OverlayRenderer.Spec)call(current,"spec"));
            });
            SharedPreferences drafts=target.getSharedPreferences("duwm_production_drafts",Context.MODE_PRIVATE);String valid=drafts.getString(key,"");
            JSONObject invalid=new JSONObject(valid).put("automatic_scene_titles","true");String bad=invalid.toString();check(drafts.edit().putString(key,bad).commit(),"Seed only fixture-owned malformed scene selection");
            ui(runner,()->{call(current,"loadDraft");check((Boolean)field(current,"draftRestoreBlocked"),"Malformed scene flag blocks partial draft restore");check(!(Boolean)call(current,"saveDraft"),"Malformed original draft is not overwritten");});
            check(bad.equals(drafts.getString(key,"")),"Rejected draft bytes remain unchanged");check(drafts.edit().putString(key,valid).commit(),"Restore this fixture's valid scene draft");
            ui(runner,()->{call(current,"loadDraft");call(current,"refresh");});
            Duwm1728OverlayRenderer.Spec spec=selected.get();check(spec!=null&&spec.automaticSceneTitles&&spec.fromMs==250&&spec.toMs==1900,"Actual editor specification preserves selected source-time trim");
            boolean immutable=false;try{spec.sceneTrack.add(supplied().get(0));}catch(UnsupportedOperationException expected){immutable=true;}check(immutable,"Export receives an immutable observation-list snapshot");
            return spec;
        }finally{finish(runner,editor);}
    }
    private void timeline(Duwm1728OverlayRenderer.Spec spec){
        proof.phase("scene_timeline.source_time_boundaries");
        for(long elapsed:new long[]{0,149,150,699,700,849,850,1449,1450,1649}){
            long source=spec.fromMs+elapsed;String expected=source>=400&&source<950?FIRST:source>=1100&&source<1700?SECOND:"";
            Duwm1728BroadcastLayout.Report report=Duwm1728OverlayRenderer.reportAt(spec,elapsed);
            check(report.automaticSceneTitles,"Scene mode remains enabled during gaps");
            check(Duwm1728BroadcastLayout.currentScene(report,elapsed)==!expected.isEmpty(),"Exact no-future/no-stale selection at source "+source);
            check(expected.equals(report.sceneTitle),"Preview/export resolves the expected original-time observation at "+source);
            if(!expected.isEmpty())check(report.sceneAtMs==Math.max(0,(FIRST.equals(expected)?400:1100)-250)&&report.sceneUntilMs==(FIRST.equals(expected)?950:1700)-250,"Trim offset is applied exactly once");
        }
        Duwm1728OverlayRenderer.Spec during=new Duwm1728OverlayRenderer.Spec();during.fromMs=600;during.toMs=1900;during.automaticSceneTitles=true;during.sceneTrack=spec.sceneTrack;
        Duwm1728BroadcastLayout.Report existing=Duwm1728OverlayRenderer.reportAt(during,0);
        check(FIRST.equals(existing.sceneTitle)&&existing.sceneAtMs==0&&existing.sceneUntilMs==350&&Duwm1728BroadcastLayout.currentScene(existing,0),"Trim starting within a current observation retains only its remaining valid interval");
        during.sceneTrack=Arrays.asList(new Duwm1728SceneTimeline.Entry(400,1800,FIRST,"Older overlapping test observation",Duwm1728SceneTimeline.SOURCE),new Duwm1728SceneTimeline.Entry(1100,1300,SECOND,"Newer shorter test observation",Duwm1728SceneTimeline.SOURCE));
        check(Duwm1728OverlayRenderer.reportAt(during,800).sceneTitle.isEmpty(),"Expired newer observation cannot revive an older overlapping title");
    }
    private static final class Expected {
        final Bitmap image;final Duwm1728BroadcastLayout.Geometry geometry;
        Expected(Duwm1728OverlayRenderer.Spec spec,int width,int height,long elapsed){image=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);geometry=Duwm1728BroadcastLayout.draw(new Duwm1728BroadcastCanvas(new Canvas(image)),width,height,Duwm1728OverlayRenderer.reportAt(spec,elapsed),elapsed);}
        void close(){image.recycle();}
    }
    private static boolean white(int pixel){return Color.red(pixel)>170&&Color.green(pixel)>170&&Color.blue(pixel)>170;}
    private double dice(Bitmap actual,Bitmap expected,Rect region){
        int seen=0,wanted=0,both=0;for(int y=region.top;y<region.bottom;y++)for(int x=region.left;x<region.right;x++){
            boolean a=white(actual.getPixel(x,y)),e=white(expected.getPixel(x,y));if(a)seen++;if(e)wanted++;if(a&&e)both++;
        }check(seen>20&&wanted>20,"Decoded and expected scene regions contain real glyph pixels");return 2d*both/(seen+wanted);
    }
    private void picture(Bitmap actual,Bitmap original){
        for(float fraction:new float[]{.10f,.50f,.90f}){
            int x=Math.round((actual.getWidth()-1)*fraction),y=actual.getHeight()/2,a=actual.getPixel(x,y),e=original.getPixel(x,y);
            check(Math.abs(Color.red(a)-Color.red(e))<40&&Math.abs(Color.green(a)-Color.green(e))<40&&Math.abs(Color.blue(a)-Color.blue(e))<40,"Encoded scene graphics retain unobscured source-picture markers");
        }
    }
    private JSONArray decoded(File output,File source,Duwm1728OverlayRenderer.Spec spec,File folder)throws Exception{
        proof.phase("scene_timeline.decode");MediaMetadataRetriever reader=new MediaMetadataRetriever(),original=new MediaMetadataRetriever();
        try{
            reader.setDataSource(output.getAbsolutePath());original.setDataSource(source.getAbsolutePath());
            check("960".equals(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH))&&"540".equals(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)),"Encoded scene export retains full source dimensions");
            check(Math.abs(Long.parseLong(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION))-(spec.toMs-spec.fromMs))<180,"Encoded scene duration matches the selected trim");
            check("yes".equalsIgnoreCase(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)),"Encoded scene MP4 retains an audio track");
            JSONArray samples=new JSONArray();
            for(long elapsed:new long[]{100,350,750,1050,1550}){
                Bitmap actual=reader.getFrameAtTime(elapsed*1000,MediaMetadataRetriever.OPTION_CLOSEST),sourceFrame=original.getFrameAtTime((spec.fromMs+elapsed)*1000,MediaMetadataRetriever.OPTION_CLOSEST);
                check(actual!=null&&sourceFrame!=null,"Actual source and encoded scene frames decode at "+elapsed);
                Expected expected=new Expected(spec,960,540,elapsed),wrong=new Expected(spec,960,540,elapsed==350?1050:350);
                try{
                    Duwm1728BroadcastLayout.Geometry g=expected.geometry;float u=g.unit;
                    Rect header=new Rect((int)(g.x+9*u),(int)(g.headerTop+1*u),(int)(g.x+g.width*.62f-4*u),(int)(g.headerTop+51*u));
                    Rect description=new Rect((int)(g.x+19*u),(int)(g.headlineTop+3*u),(int)(g.x+g.width-19*u),(int)(g.headlineTop+57*u));
                    double titleScore=dice(actual,expected.image,header),wrongTitle=dice(actual,wrong.image,header),descriptionScore=dice(actual,expected.image,description),wrongDescription=dice(actual,wrong.image,description);
                    check(titleScore>.72&&descriptionScore>.72,"Decoded title and description match shared native painter at "+elapsed+": "+titleScore+", "+descriptionScore);
                    check(titleScore>wrongTitle+.08&&descriptionScore>wrongDescription+.08,"Decoded scene is time-aligned, not a repeated stale scene at "+elapsed);
                    picture(actual,sourceFrame);
                    if(elapsed==350||elapsed==1050)try(OutputStream out=new FileOutputStream(new File(folder,elapsed==350?"ANDROID-SCENE-FIRST.png":"ANDROID-SCENE-SECOND.png"))){check(actual.compress(Bitmap.CompressFormat.PNG,100,out),"Write actual decoded scene image");}
                    samples.put(new JSONObject().put("elapsed_ms",elapsed).put("source_ms",spec.fromMs+elapsed).put("scene_current",Duwm1728BroadcastLayout.currentScene(Duwm1728OverlayRenderer.reportAt(spec,elapsed),elapsed))
                        .put("title_glyph_dice",titleScore).put("wrong_title_glyph_dice",wrongTitle).put("description_glyph_dice",descriptionScore).put("wrong_description_glyph_dice",wrongDescription));
                }finally{expected.close();wrong.close();actual.recycle();sourceFrame.recycle();}
            }return samples;
        }finally{reader.release();original.release();}
    }
    private static final class Packet {final long time;final byte[] hash;Packet(long time,byte[] hash){this.time=time;this.hash=hash;}}
    private List<Packet> audio(File video,long fromUs,long toUs,long originUs)throws Exception{
        MediaExtractor reader=new MediaExtractor();try{
            reader.setDataSource(video.getAbsolutePath());int audio=-1;
            for(int index=0;index<reader.getTrackCount();index++){MediaFormat format=reader.getTrackFormat(index);if("audio/mp4a-latm".equals(format.getString(MediaFormat.KEY_MIME))){audio=index;check(format.getInteger(MediaFormat.KEY_SAMPLE_RATE)==48000&&format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)==1,"Retained AAC track has original 48 kHz mono format");break;}}
            check(audio>=0,"Actual AAC source track exists");reader.selectTrack(audio);reader.seekTo(fromUs,MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            ArrayList<Packet> packets=new ArrayList<>();ByteBuffer bytes=ByteBuffer.allocate(2*1024*1024);MessageDigest hash=MessageDigest.getInstance("SHA-256");
            while(reader.getSampleTime()>=0&&reader.getSampleTime()<toUs){long at=reader.getSampleTime();bytes.clear();int size=reader.readSampleData(bytes,0);if(size<0)break;
                if(at>=fromUs){byte[] payload=new byte[size];bytes.position(0);bytes.get(payload);packets.add(new Packet(at-originUs,hash.digest(payload)));}if(!reader.advance())break;
            }return packets;
        }finally{reader.release();}
    }
    private int audioPreserved(File source,File output,Duwm1728OverlayRenderer.Spec spec)throws Exception{
        List<Packet> before=audio(source,spec.fromMs*1000,spec.toMs*1000,spec.fromMs*1000),after=audio(output,0,Long.MAX_VALUE,0);
        check(before.size()>10&&before.size()==after.size(),"Scene export retains every selected AAC packet");
        for(int index=0;index<before.size();index++)check(before.get(index).time==after.get(index).time&&Arrays.equals(before.get(index).hash,after.get(index).hash),"Original AAC packet bytes and normalized timestamp preserved at "+index);
        return before.size();
    }
    void run(Instrumentation runner,File folder)throws Exception{
        Context target=runner.getTargetContext();File source=new File(target.getCacheDir(),"scene-fixture-"+UUID.randomUUID()+".mp4");Uri uri=Uri.fromFile(source);String key=Duwm1728CaptureTelemetry.storageKey(uri);File produced=null;JSONObject result=null;Throwable failure=null;
        try{
            proof.phase("scene_timeline.fixture");try(InputStream in=runner.getContext().getAssets().open("framing_fixture.mp4");OutputStream out=new FileOutputStream(source)){copy(in,out);}String sourceHash=DuwmNativeEvidence.hash(source);
            Duwm1728OverlayRenderer.Spec spec=editorContract(runner,uri);timeline(spec);Duwm1728OverlayRenderer.prepare(spec);
            proof.phase("scene_timeline.encode");produced=Duwm1728OverlayRenderer.export(target,uri,spec);File output=new File(folder,"ANDROID-SCENE-TIMELINE.mp4");
            try(InputStream in=new FileInputStream(produced);OutputStream out=new FileOutputStream(output)){copy(in,out);}int packets=audioPreserved(source,output,spec);JSONArray samples=decoded(output,source,spec,folder);
            check(sourceHash.equals(DuwmNativeEvidence.hash(source)),"Scene export leaves the original recording byte-for-byte unchanged");
            result=new JSONObject().put("schema",1).put("status","PASS").put("scene_source","synthetic-native-fixture")
                .put("model_inference_verified",false).put("physical_camera_verified",false).put("encoded_timeline_verified",true)
                .put("fixture_observations","SYNTHETIC_TEST_DATA").put("timebase","original_source_ms").put("from_ms",spec.fromMs).put("to_ms",spec.toMs)
                .put("source_audio_preserved",true).put("source_aac_packets",packets).put("source_file_unchanged",true).put("source_file_sha256",sourceHash)
                .put("preview_export_scene_match",true).put("future_and_expired_hidden",true).put("trim_applied_once",true).put("decoded_samples",samples)
                .put("comparison","Actual Android painter glyph masks against decoded MP4. Supplied test observations; no OCR, image-model execution or physical-camera verification.");
        }catch(Throwable error){failure=error;rethrow(error);}
        finally{
            try{clearDraft(target,key);new AtomicFile(new File(new File(target.getFilesDir(),"scene-timelines"),key+".json")).delete();check(!Duwm1728SceneStore.hasCapture(target,uri),"Remove only fixture-owned scene sidecar");
                if(produced!=null&&produced.exists())check(produced.delete(),"Remove fixture-owned temporary export");if(source.exists())check(source.delete(),"Remove fixture-owned source copy");
            }catch(Throwable cleanup){if(failure!=null)failure.addSuppressed(cleanup);else rethrow(cleanup);}
        }
        check(result!=null,"Scene timeline checks and owned-fixture cleanup completed");result.put("checks",checks).put("fixture_cleanup_complete",true);
        try(OutputStream out=new FileOutputStream(new File(folder,"SCENE-TIMELINE-NATIVE.json"))){out.write((result.toString(2)+"\n").getBytes(StandardCharsets.UTF_8));}proof.phase("scene_timeline.complete");
    }
}
