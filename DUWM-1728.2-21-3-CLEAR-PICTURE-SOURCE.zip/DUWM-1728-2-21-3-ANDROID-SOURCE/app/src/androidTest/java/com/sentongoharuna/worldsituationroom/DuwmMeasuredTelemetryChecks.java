package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.SystemClock;
import android.util.AtomicFile;
import android.widget.CheckBox;
import android.widget.EditText;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import org.json.JSONArray;
import org.json.JSONObject;

/** Synthetic typed sensor/provider inputs through actual Android storage,
 * editor, shared renderer and codec. Never a physical sensor/network/model test. */
final class DuwmMeasuredTelemetryChecks {
    private static final long UTC=1794052800000L;
    private final DuwmNativeEvidence proof;private int checks;
    DuwmMeasuredTelemetryChecks(DuwmNativeEvidence proof){this.proof=proof;}
    int count(){return checks;}
    private void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    private interface Action{void run()throws Exception;}
    private interface Condition{boolean ready()throws Exception;}
    private static void rethrow(Throwable error)throws Exception{if(error instanceof InvocationTargetException){rethrow(((InvocationTargetException)error).getTargetException());return;}if(error instanceof Error)throw (Error)error;if(error instanceof Exception)throw (Exception)error;if(error!=null)throw new RuntimeException(error);}
    private void ui(Instrumentation runner,Action action)throws Exception{AtomicReference<Throwable> error=new AtomicReference<>();runner.runOnMainSync(()->{try{action.run();}catch(Throwable failure){error.set(failure);}});rethrow(error.get());}
    private static Object field(Object object,String name)throws Exception{java.lang.reflect.Field f=object.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(object);}
    private static void set(Object object,String name,Object value)throws Exception{java.lang.reflect.Field f=object.getClass().getDeclaredField(name);f.setAccessible(true);f.set(object,value);}
    private static Object call(Object object,String name)throws Exception{java.lang.reflect.Method m=object.getClass().getDeclaredMethod(name);m.setAccessible(true);try{return m.invoke(object);}catch(InvocationTargetException error){rethrow(error);return null;}}
    private void await(Instrumentation runner,Condition condition,String label)throws Exception{AtomicBoolean ready=new AtomicBoolean();long until=SystemClock.elapsedRealtime()+15000;do{ui(runner,()->ready.set(condition.ready()));if(ready.get())break;Thread.sleep(75);}while(SystemClock.elapsedRealtime()<until);check(ready.get(),label);}
    private static void copy(InputStream in,OutputStream out)throws Exception{byte[] bytes=new byte[65536];int n;while((n=in.read(bytes))!=-1)out.write(bytes,0,n);}
    private static Duwm1728Measurements.Input input(long at,boolean second){
        Duwm1728Measurements.Input in=new Duwm1728Measurements.Input();in.sourceMs=at;in.nowElapsedMs=100000+at;in.utcMs=UTC+at;in.recording=true;in.coordinatesAllowed=true;
        in.locationEnabled=true;in.locationAvailable=true;in.fixElapsedMs=in.nowElapsedMs-29500;in.latitude=second?.33667:.33567;in.longitude=second?32.56990:32.56890;in.horizontalAccuracyMeters=second?12:4;in.altitudeMeters=second?1430:1235;in.verticalAccuracyMeters=8;in.speedMps=second?.05:4;in.speedAccuracyMps=.1;in.locationSource="synthetic-native-fixture";
        in.headingDegrees=second?250:78;in.headingAccuracy=3;in.headingElapsedMs=in.nowElapsedMs-2500;in.previewFps=second?27:18;in.fpsFrames=second?28:19;in.fpsWindowMs=1000;in.fpsElapsedMs=in.nowElapsedMs-2500;
        in.place=second?"RIVER ACCESS FIXTURE":"NORTH CAMPUS FIXTURE";in.placeSource="synthetic-native-fixture";in.placeQueryLatitude=in.latitude;in.placeQueryLongitude=in.longitude;in.placeFixElapsedMs=in.fixElapsedMs;in.placeReceivedElapsedMs=in.nowElapsedMs-1000;
        in.weatherEnabled=true;in.weatherProvider="Open-Meteo";in.weatherSource="synthetic-native-fixture";in.weatherDescription=second?"Heavy rain":"Clear";in.weatherCode=second?65:0;in.temperatureC=second?17.5:26.5;in.windMps=second?12.3:3.2;in.weatherUtcMs=UTC-300000;in.weatherReceivedElapsedMs=in.nowElapsedMs-1000;in.weatherQueryLatitude=in.latitude;in.weatherQueryLongitude=in.longitude;return in;
    }
    private static List<Duwm1728Measurements.Sample> samples(){return Arrays.asList(Duwm1728Measurements.sample(input(400,false)),Duwm1728Measurements.sample(input(1100,true)));}
    private JSONObject weather()throws Exception{return new JSONObject().put("current_units",new JSONObject().put("temperature_2m","°C").put("wind_speed_10m","m/s").put("time","unixtime"))
        .put("current",new JSONObject().put("temperature_2m",26.5).put("wind_speed_10m",3.2).put("weather_code",2).put("time",UTC/1000));}
    private int weatherParser()throws Exception{
        proof.phase("measured_telemetry.provider_parser");Duwm1728MeasurementSources.Weather valid=Duwm1728MeasurementSources.parseWeather(weather().toString(),UTC);
        check(valid.temperatureC==26.5&&valid.windMps==3.2&&valid.code==2&&valid.utcMs==UTC&&!valid.description.isEmpty(),"Actual Android JSON parser preserves supplied weather numbers, units and model time");
        ArrayList<String> invalid=new ArrayList<>();
        for(String key:new String[]{"temperature_2m","wind_speed_10m","weather_code","time"}){JSONObject nullValue=weather();nullValue.getJSONObject("current").put(key,JSONObject.NULL);invalid.add(nullValue.toString());JSONObject stringValue=weather();stringValue.getJSONObject("current").put(key,"26.5");invalid.add(stringValue.toString());}
        Object[][] ranges={{"temperature_2m",71},{"temperature_2m",-101},{"wind_speed_10m",-1},{"wind_speed_10m",151},{"weather_code",1000},{"weather_code",2.5},{"time",UTC/1000-3601},{"time",UTC/1000+301}};
        for(Object[] value:ranges){JSONObject changed=weather();changed.getJSONObject("current").put((String)value[0],value[1]);invalid.add(changed.toString());}
        for(String key:new String[]{"temperature_2m","wind_speed_10m","time"}){JSONObject changed=weather();changed.getJSONObject("current_units").put(key,"wrong unit");invalid.add(changed.toString());}
        invalid.add(weather().toString().replace("26.5","1e309"));invalid.add(weather().toString().replace("26.5","NaN"));
        for(String body:invalid){boolean rejected=false;try{Duwm1728MeasurementSources.parseWeather(body,UTC);}catch(Exception expected){rejected=true;}check(rejected,"Malformed/nonfinite/stale/future/unknown-code/wrong-unit provider data is rejected");}return invalid.size()+1;
    }
    private Duwm1728OverlayRenderer.Spec editor(Instrumentation runner,Uri source)throws Exception{
        Context target=runner.getTargetContext();String key=Duwm1728CaptureTelemetry.storageKey(source);
        check(Duwm1728MeasurementStore.save(target,source,Collections.emptyList(),false),"Persist empty measured capture with coordinate permission off");
        check(Duwm1728MeasurementStore.hasCapture(target,source)&&!Duwm1728MeasurementStore.coordinatesAllowed(target,source)&&Duwm1728MeasurementStore.load(target,source).isEmpty(),"Empty capture marker and coordinate policy round-trip through actual Android JSON");
        check(Duwm1728MeasurementStore.save(target,source,samples(),true),"Persist synthetic typed measurements");List<Duwm1728Measurements.Sample> loaded=Duwm1728MeasurementStore.load(target,source);
        check(loaded.size()==2&&loaded.get(0).atMs==400&&loaded.get(1).heading.value==250&&loaded.get(1).weatherProvider.equals("Open-Meteo")&&Duwm1728MeasurementStore.coordinatesAllowed(target,source),"Typed values, provider identity, timestamps and coordinate permission round-trip exactly");
        check(Duwm1728SceneStore.save(target,source,Arrays.asList(new Duwm1728SceneTimeline.Entry(0,2000,"SYNTHETIC SCENE","Supplied measurement fixtures on recorded source video.",Duwm1728SceneTimeline.SOURCE))),"Persist explicitly synthetic scene fixture alongside separate measurements");
        Activity editor=runner.startActivitySync(new Intent(target,Duwm1728VideoEditorActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(Duwm1728VideoEditorActivity.EXTRA_VIDEO_URI,source.toString()));
        try{
            await(runner,()->(Boolean)field(editor,"prepared"),"Actual measured-source editor player is ready");AtomicReference<Duwm1728OverlayRenderer.Spec> selected=new AtomicReference<>();
            ui(runner,()->{
                check((Boolean)field(editor,"measurementCapture")&&((CheckBox)field(editor,"sourceSummary")).isChecked()&&((CheckBox)field(editor,"preciseExport")).isChecked(),"New capture loads measured summary and persisted coordinate preset automatically");
                // Retain stage18's previous measured-layout coverage. Stage19
                // verifies the new default and its larger clear picture area.
                ((CheckBox)field(editor,"clearPictureToggle")).setChecked(false);
                ((EditText)field(editor,"from")).setText("0.250");((EditText)field(editor,"to")).setText("1.900");set(editor,"selectedRatio","ORIGINAL");set(editor,"selectedComposition",Duwm1728BroadcastComposition.COMPACT);
                ((CheckBox)field(editor,"sourceSummary")).setChecked(false);((CheckBox)field(editor,"preciseExport")).setChecked(false);check((Boolean)call(editor,"saveDraft"),"Save independent manual summary/coordinate choices");call(editor,"loadDraft");call(editor,"refresh");
                check(!((CheckBox)field(editor,"sourceSummary")).isChecked()&&!((CheckBox)field(editor,"preciseExport")).isChecked(),"Explicit summary/coordinate-off choices survive draft reload");
                ((CheckBox)field(editor,"sourceSummary")).setChecked(true);((CheckBox)field(editor,"preciseExport")).setChecked(true);call(editor,"refresh");check((Boolean)call(editor,"saveDraft"),"Save selected measured export");selected.set((Duwm1728OverlayRenderer.Spec)call(editor,"spec"));
            });
            SharedPreferences drafts=target.getSharedPreferences("duwm_production_drafts",Context.MODE_PRIVATE);String saved=drafts.getString(key,"");String bad=new JSONObject(saved).put("include_coordinates","true").toString();check(drafts.edit().putString(key,bad).commit(),"Seed only test-owned malformed coordinate selection");
            ui(runner,()->{call(editor,"loadDraft");check((Boolean)field(editor,"draftRestoreBlocked")&&!(Boolean)call(editor,"saveDraft"),"Malformed measurement boolean blocks partial overwrite");});check(bad.equals(drafts.getString(key,"")),"Rejected coordinate-policy draft remains byte-for-byte intact");check(drafts.edit().putString(key,saved).commit(),"Restore valid test draft");ui(runner,()->{call(editor,"loadDraft");call(editor,"refresh");});
            Duwm1728OverlayRenderer.Spec result=selected.get();boolean immutable=false;try{result.measurementTrack.add(samples().get(0));}catch(UnsupportedOperationException expected){immutable=true;}check(immutable,"Export specification owns an immutable sample-list snapshot");return result;
        }finally{ui(runner,editor::finish);await(runner,editor::isDestroyed,"Measured-source editor closes before encoding/cleanup");}
    }
    private void timing(Duwm1728OverlayRenderer.Spec spec){
        proof.phase("measured_telemetry.source_time_and_metadata");
        Duwm1728CaptureTelemetry.Snapshot end=new Duwm1728CaptureTelemetry.Snapshot(UTC+1900,"END HEADING LEAK","END ALT LEAK","END ACC LEAK","END WX LEAK","END GPS LEAK",true);spec.capturedTelemetry=end;
        Duwm1728BroadcastLayout.Report before=Duwm1728OverlayRenderer.reportAt(spec,100),first=Duwm1728OverlayRenderer.reportAt(spec,350),stale=Duwm1728OverlayRenderer.reportAt(spec,750),second=Duwm1728OverlayRenderer.reportAt(spec,1050),tail=Duwm1728OverlayRenderer.reportAt(spec,1550);
        check(before.measuredSummary&&before.measuredCoordinates.isEmpty()&&before.measuredHeading.isEmpty(),"No future typed sample or capture-end fallback before first observation");
        check(first.measuredCoordinates.contains("0.33567")&&second.measuredCoordinates.contains("0.33667")&&first.measuredHeading.contains("078")&&second.measuredHeading.contains("250"),"Selected original source times, including trim, resolve different actual fixture measurements");
        check(first.measuredFps.contains("18.0")&&second.measuredFps.contains("27.0")&&first.measuredFps.contains("PREVIEW"),"Measured preview FPS is independently labelled and time-aligned");
        check(first.measuredWeather.contains("MODEL")&&first.measuredWeather.contains("Open-Meteo")&&first.measuredWeather.contains("UTC"),"Weather retains model/provider/time provenance");
        check(stale.measuredCoordinates.contains("STALE")&&!stale.measuredCoordinates.contains("0.33567")&&tail.measuredHeading.contains("STALE")&&!tail.measuredHeading.contains("250"),"Per-field stale states replace prior numbers rather than holding them indefinitely");
        check(first.clock.equals("RECORDED • "+Duwm1728Measurements.display(spec.measurementTrack.get(0),600,true).time),"Source UTC clock applies original-time trim exactly once");
        spec.includeCoordinates=false;check(Duwm1728OverlayRenderer.reportAt(spec,350).measuredCoordinates.isEmpty(),"Manual coordinate-off selection withholds exact values");spec.includeCoordinates=true;spec.measurementCoordinatesAllowed=false;
        check(Duwm1728OverlayRenderer.reportAt(spec,350).measuredCoordinates.isEmpty(),"Capture coordinate policy cannot be bypassed by an editor checkbox");spec.measurementCoordinatesAllowed=true;
        Duwm1728OverlayRenderer.Spec legacy=new Duwm1728OverlayRenderer.Spec();legacy.fromMs=0;legacy.toMs=1900;legacy.includeSourceSummary=true;legacy.includeCoordinates=true;legacy.capturedTelemetry=end;
        check(Duwm1728OverlayRenderer.reportAt(legacy,200).heading.isEmpty()&&Duwm1728OverlayRenderer.reportAt(legacy,200).gps.isEmpty()&&Duwm1728OverlayRenderer.reportAt(legacy,200).clock.isEmpty(),"End-only metadata is never burned onto earlier frames");
        Duwm1728CaptureTelemetry.Snapshot actual=new Duwm1728CaptureTelemetry.Snapshot(UTC+800,"LEGACY SAMPLE","SAMPLE ALT","SAMPLE ACC","SAMPLE WX","SAMPLE COORDS",true);legacy.recordedTrack=Arrays.asList(new Duwm1728TelemetryTimeline.Point(800,actual));
        check(Duwm1728OverlayRenderer.reportAt(legacy,799).heading.isEmpty(),"Legacy timeline has no future or end-snapshot fallback");check("LEGACY SAMPLE".equals(Duwm1728OverlayRenderer.reportAt(legacy,800).heading),"Actual legacy sample appears at its original timestamp");check(Duwm1728OverlayRenderer.reportAt(legacy,3800).heading.isEmpty(),"Legacy string samples expire after their bounded interval");
        check(Duwm1728OverlayRenderer.reportAt(spec,3850).measuredHeading.isEmpty(),"Whole typed-sample gaps also expire without reviving old observations");
    }
    private static boolean ink(int pixel){int r=Color.red(pixel),g=Color.green(pixel),b=Color.blue(pixel);return r>150&&g>150&&b>150||g>100&&b>110&&r<g*.8;}
    private double dice(Bitmap actual,Bitmap expected,Rect box){int a=0,e=0,both=0;for(int y=box.top;y<box.bottom;y++)for(int x=box.left;x<box.right;x++){boolean aa=ink(actual.getPixel(x,y)),ee=ink(expected.getPixel(x,y));if(aa)a++;if(ee)e++;if(aa&&ee)both++;}check(a>20&&e>20,"Decoded and expected measured regions contain actual glyph pixels");return 2d*both/(a+e);}
    private Bitmap expected(Duwm1728OverlayRenderer.Spec spec,long at){Bitmap image=Bitmap.createBitmap(960,540,Bitmap.Config.ARGB_8888);Duwm1728OverlayRenderer.drawOverlay(new Canvas(image),spec,at,null);return image;}
    private JSONArray decoded(File output,File source,Duwm1728OverlayRenderer.Spec spec,File folder)throws Exception{
        MediaMetadataRetriever video=new MediaMetadataRetriever(),original=new MediaMetadataRetriever();try{
            video.setDataSource(output.getAbsolutePath());original.setDataSource(source.getAbsolutePath());check("960".equals(video.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH))&&"540".equals(video.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)),"Measured export retains original full picture dimensions");check("yes".equalsIgnoreCase(video.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)),"Measured export has source audio");check(Math.abs(Long.parseLong(video.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION))-(spec.toMs-spec.fromMs))<180,"Measured export retains selected trim duration");
            JSONArray results=new JSONArray();for(long at:new long[]{100,350,750,1050,1550}){
                Bitmap actual=video.getFrameAtTime(at*1000,MediaMetadataRetriever.OPTION_CLOSEST),sourceFrame=original.getFrameAtTime((spec.fromMs+at)*1000,MediaMetadataRetriever.OPTION_CLOSEST),wanted=expected(spec,at),wrong=expected(spec,at==350?1050:350);check(actual!=null&&sourceFrame!=null,"Actual measured MP4 and source frames decode");
                try{Duwm1728BroadcastLayout.Geometry g=Duwm1728BroadcastLayout.draw(new Duwm1728BroadcastCanvas(new Canvas(wanted)),960,540,Duwm1728OverlayRenderer.reportAt(spec,at),at);Rect region=new Rect((int)(g.x+20*g.unit),(int)(g.telemetryTop+3*g.unit),(int)(g.x+g.width-20*g.unit),(int)(g.tickerTop-3*g.unit));double correct=dice(actual,wanted,region),incorrect=dice(actual,wrong,region);
                    check(correct>.72&&correct>incorrect+.04,"Decoded measurements match their actual source-time renderer, not a stale/wrong sample: "+at+" "+correct+" / "+incorrect);
                    for(float fraction:new float[]{.1f,.5f,.9f}){int x=Math.round(959*fraction),y=220,a=actual.getPixel(x,y),b=sourceFrame.getPixel(x,y);check(Math.abs(Color.red(a)-Color.red(b))<40&&Math.abs(Color.green(a)-Color.green(b))<40&&Math.abs(Color.blue(a)-Color.blue(b))<40,"Measured overlay preserves unobscured source picture");}
                    if(at==350||at==1050)try(OutputStream out=new FileOutputStream(new File(folder,at==350?"ANDROID-MEASURED-FIRST.png":"ANDROID-MEASURED-SECOND.png"))){check(actual.compress(Bitmap.CompressFormat.PNG,100,out),"Write actual decoded measured frame");}
                    results.put(new JSONObject().put("elapsed_ms",at).put("source_ms",spec.fromMs+at).put("expected_glyph_dice",correct).put("wrong_sample_glyph_dice",incorrect));
                }finally{actual.recycle();sourceFrame.recycle();wanted.recycle();wrong.recycle();}
            }return results;
        }finally{video.release();original.release();}
    }
    private static final class Packet{final long time;final byte[] hash;Packet(long time,byte[] hash){this.time=time;this.hash=hash;}}
    private List<Packet> audio(File file,long from,long to,long origin)throws Exception{MediaExtractor reader=new MediaExtractor();try{reader.setDataSource(file.getAbsolutePath());int selected=-1;for(int i=0;i<reader.getTrackCount();i++){MediaFormat f=reader.getTrackFormat(i);if("audio/mp4a-latm".equals(f.getString(MediaFormat.KEY_MIME))){selected=i;check(f.getInteger(MediaFormat.KEY_SAMPLE_RATE)==48000&&f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)==1,"Original AAC format is retained");break;}}check(selected>=0,"Actual AAC track exists");reader.selectTrack(selected);reader.seekTo(from,MediaExtractor.SEEK_TO_PREVIOUS_SYNC);List<Packet> result=new ArrayList<>();ByteBuffer buffer=ByteBuffer.allocate(2*1024*1024);MessageDigest hash=MessageDigest.getInstance("SHA-256");while(reader.getSampleTime()>=0&&reader.getSampleTime()<to){long at=reader.getSampleTime();buffer.clear();int count=reader.readSampleData(buffer,0);if(count<0)break;if(at>=from){byte[] bytes=new byte[count];buffer.position(0);buffer.get(bytes);result.add(new Packet(at-origin,hash.digest(bytes)));}if(!reader.advance())break;}return result;}finally{reader.release();}}
    void run(Instrumentation runner,File folder)throws Exception{
        Context target=runner.getTargetContext();File source=new File(target.getCacheDir(),"measured-fixture-"+UUID.randomUUID()+".mp4");Uri uri=Uri.fromFile(source);String key=Duwm1728CaptureTelemetry.storageKey(uri);File temporary=null;JSONObject result=null;Throwable failure=null;
        try{
            int parserCases=weatherParser();proof.phase("measured_telemetry.fixture");try(InputStream in=runner.getContext().getAssets().open("framing_fixture.mp4");OutputStream out=new FileOutputStream(source)){copy(in,out);}String before=DuwmNativeEvidence.hash(source);
            Duwm1728OverlayRenderer.Spec spec=editor(runner,uri);timing(spec);Duwm1728OverlayRenderer.prepare(spec);Duwm1728ExportPreflight.Result plan=Duwm1728ExportPreflight.inspect(target,uri,spec.fromMs,spec.toMs,spec.ratio,spec.frameMode,spec.frameX,spec.frameY);
            check(plan.fps!=18&&plan.fps!=27,"Preview measurements never become the source encoder frame-rate target");proof.phase("measured_telemetry.encode");temporary=Duwm1728OverlayRenderer.export(target,uri,spec);File output=new File(folder,"ANDROID-MEASURED-TELEMETRY.mp4");try(InputStream in=new FileInputStream(temporary);OutputStream out=new FileOutputStream(output)){copy(in,out);}
            List<Packet> a=audio(source,spec.fromMs*1000,spec.toMs*1000,spec.fromMs*1000),b=audio(output,0,Long.MAX_VALUE,0);check(a.size()>10&&a.size()==b.size(),"Every selected source audio packet is retained");for(int i=0;i<a.size();i++)check(a.get(i).time==b.get(i).time&&Arrays.equals(a.get(i).hash,b.get(i).hash),"Original AAC bytes and normalized time retained at packet "+i);
            proof.phase("measured_telemetry.decode");JSONArray frames=decoded(output,source,spec,folder);check(before.equals(DuwmNativeEvidence.hash(source)),"Original source file remains unchanged");
            result=new JSONObject().put("schema",1).put("status","PASS").put("measurement_source","synthetic-native-fixture").put("physical_sensor_verified",false).put("physical_camera_verified",false).put("model_inference_verified",false).put("provider_network_verified",false).put("encoded_timeline_verified",true)
                .put("source_time_trim_verified",true).put("no_capture_end_leak",true).put("stale_values_removed",true).put("coordinate_consent_verified",true).put("source_audio_preserved",true).put("source_aac_packets",a.size()).put("source_file_unchanged",true).put("source_file_sha256",before)
                .put("provider_parser_cases",parserCases).put("preview_rate_not_used_as_encoder_target",true).put("from_ms",spec.fromMs).put("to_ms",spec.toMs).put("decoded_samples",frames).put("comparison","Synthetic typed observations and provider JSON; actual Android storage/editor/renderer/codec/AAC packet checks. No physical sensor, provider network or image-model execution.");
        }catch(Throwable error){failure=error;rethrow(error);}
        finally{try{check(target.getSharedPreferences("duwm_production_drafts",Context.MODE_PRIVATE).edit().remove(key).commit(),"Remove only fixture-owned draft");new AtomicFile(new File(new File(target.getFilesDir(),"measurement-timelines"),key.substring("capture_".length())+".json")).delete();new AtomicFile(new File(new File(target.getFilesDir(),"scene-timelines"),key+".json")).delete();check(!Duwm1728MeasurementStore.hasCapture(target,uri)&&!Duwm1728SceneStore.hasCapture(target,uri),"Remove only fixture-owned sidecars");if(temporary!=null&&temporary.exists())check(temporary.delete(),"Remove fixture-owned temporary output");if(source.exists())check(source.delete(),"Remove fixture-owned source copy");}catch(Throwable cleanup){if(failure!=null)failure.addSuppressed(cleanup);else rethrow(cleanup);}}
        check(result!=null,"Measured checks and fixture cleanup complete");result.put("checks",checks).put("fixture_cleanup_complete",true);try(OutputStream out=new FileOutputStream(new File(folder,"MEASURED-TELEMETRY-NATIVE.json"))){out.write((result.toString(2)+"\n").getBytes(StandardCharsets.UTF_8));}proof.phase("measured_telemetry.complete");
    }
}
