package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.appwidget.AppWidgetManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.text.TextUtils;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Deque;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Native mission-control activity. Every surface is an Android View, not browser content. */
public final class MainActivity extends Activity implements WorldDataRepository.Listener {
    private static final String LOG_TAG = "WorldSituationRoom";
    private static final String APP_BRAND = ShareCardData.BRAND;
    private static final long STARTUP_UI_DELAY_MS = 90L;
    private static final long STARTUP_FEED_DELAY_MS = 320L;
    private static final long ANALYSIS_REFRESH_MS = 5_500L;
    private static final int MAX_ACQUISITION_SCAN = 640;
    // R18: restrained newsroom palette. Colour communicates state, not decoration.
    private static final int BG = Color.rgb(5, 8, 12);
    private static final int PANEL = Color.rgb(8, 12, 17);
    private static final int PANEL_ALT = Color.rgb(14, 21, 29);
    private static final int CYAN = Color.rgb(112, 177, 201);
    private static final int RED = Color.rgb(219, 73, 80);
    private static final int GREEN = Color.rgb(75, 166, 124);
    private static final int AMBER = Color.rgb(199, 151, 68);
    private static final int MUTED = Color.rgb(139, 155, 166);
    private static final int TEXT = Color.rgb(235, 241, 244);
    private static final int LINE = Color.rgb(39, 53, 65);
    private static final String[] TYPES = {"ALL", "CONFLICT", "PROTEST", "DISASTER", "POLITICS", "OTHER"};
    private static final String[] REGIONS = {"ALL", "AFRICA", "MIDDLE EAST", "EUROPE", "ASIA", "AMERICAS", "OCEANIA", "GLOBAL"};
    private static final String[] TIME_WINDOWS = {"1H", "6H", "24H", "72H"};
    private static final long[] TIME_WINDOW_MS = {
            60L * 60L * 1000L,
            6L * 60L * 60L * 1000L,
            24L * 60L * 60L * 1000L,
            72L * 60L * 60L * 1000L
    };
    private static final String[] CATALOG_CATEGORIES = {
            "BRIEF", "MONITORS", "FUSION", "RISK", "ANALYST", "WIDGETS", "AIRCRAFT", "SHIPS", "BOATS", "WEATHER",
            "AIRSPACE", "EVENTS", "NEWS", "ORBITS", "MARKETS", "AIRPORTS", "RUNWAYS", "PORTS", "SPACE",
            "INFRA", "RADIO", "CALLS", "TV", "CAMERAS", "SOURCES"
    };
    private static final String[] NEWS_CATEGORIES = {
            "ALL", "FOR YOU", "UGANDA", "E.AFRICA", "WORLD", "BREAKING", "BUSINESS", "SPORTS",
            "ENTERTAIN", "HEALTH", "TECH", "COURTS", "LUGANDA", "CONFLICT", "PROTEST", "DISASTER", "POLITICS", "OTHER"
    };

    private final EnumMap<Signal.Layer, Boolean> enabled = new EnumMap<>(Signal.Layer.class);
    private final EnumMap<Signal.Layer, CheckBox> layerChecks = new EnumMap<>(Signal.Layer.class);
    private final EnumMap<Signal.Layer, FeedStatus> feedStatuses = new EnumMap<>(Signal.Layer.class);
    private final EnumMap<Signal.Layer, List<Signal>> layerSignals = new EnumMap<>(Signal.Layer.class);
    private final AircraftIdentityRegistry aircraftIdentityRegistry = new AircraftIdentityRegistry();
    private final VesselIdentityRegistry vesselIdentityRegistry = new VesselIdentityRegistry();
    private final AircraftVerticalHistory aircraftVerticalHistory = new AircraftVerticalHistory();
    private final AirportRegistry airportRegistry = new AirportRegistry();
    private final PortRegistry portRegistry = new PortRegistry();
    private AircraftWatchlist aircraftWatchlist;
    private VesselWatchlist vesselWatchlist;
    private final VesselChangeRegistry vesselChangeRegistry = new VesselChangeRegistry();
    private final AisMultiProviderIngestor aisMultiProviderIngestor = new AisMultiProviderIngestor();

    private final AircraftChangeRegistry aircraftChangeRegistry = new AircraftChangeRegistry();
    private final EnumMap<Signal.Layer, LastGoodRecordRegistry> lastGoodRecords = new EnumMap<>(Signal.Layer.class);
    private final Handler clockHandler = new Handler(Looper.getMainLooper());
    private final Handler activityHandler = new Handler(Looper.getMainLooper());
    private final Handler startupHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService analysisExecutor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean analysisRunning = new AtomicBoolean(false);
    private final Deque<Signal> acquisitionQueue = new ArrayDeque<>();
    private final Set<String> seenAcquisitions = new LinkedHashSet<>();
    private final MovementAnalyzer movementAnalyzer = new MovementAnalyzer();
    private final LiveOperationsEngine operationsEngine = new LiveOperationsEngine();
    private final TemporalReplayEngine replayEngine = new TemporalReplayEngine();
    private final SimpleDateFormat utcClock = new SimpleDateFormat("HH:mm:ss 'UTC'", Locale.US);
    private final SimpleDateFormat localClock = new SimpleDateFormat("HH:mm:ss", Locale.US);
    private final SimpleDateFormat eventTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US);

    private WorldDataRepository repository;
    private CanonicalWatchStore canonicalWatchStore;
    private final RelationshipRegistry relationshipRegistry = new RelationshipRegistry();
    private final CanonicalTimelineRegistry canonicalTimelineRegistry = new CanonicalTimelineRegistry();
    private final LiveChangeRegistry liveChangeRegistry = new LiveChangeRegistry();
    private List<GeographicActivityZones.Zone> geographicActivityZones = Collections.emptyList();
    private List<IncidentFormationEngine.Incident> incidentCandidates = Collections.emptyList();
    private MonitorStore monitorStore;
    private SatelliteMapView mapView;
    private LinearLayout layersPanel;
    private LinearLayout compactLayerRail;
    private LinearLayout wirePanel;
    private LinearLayout tickerContainer;
    private LinearLayout catalogPanel;
    private LinearLayout catalogList;
    private LinearLayout newsCategoryBar;
    private LinearLayout detailPanel;
    private ScrollView detailScroll;
    private Button detailExpandButton;
    private boolean detailExpanded;
    private LinearLayout replayPanel;
    private TextView detailBadge;
    private TextView detailTitle;
    private TextView detailBody;
    private TextView counterText;
    private TextView clockText;
    private TextView liveText;
    private TextView feedPulse;
    private TextView telemetryText;
    private TextView globeStatusStrip;
    private Button providerHealthButton;
    private String lastGlobeStatus = "";
    private enum NetworkWorldState { ONLINE, DEGRADED, OFFLINE, RECOVERING }
    private NetworkWorldState networkWorldState = NetworkWorldState.RECOVERING;
    private long networkStateChangedMs = System.currentTimeMillis();
    private long lastAnyProviderSuccessMs;
    private enum ProgressiveLoadStage { WORLD_READY, LOADING_SOURCES, PARTIAL_DATA, DATA_READY }
    private ProgressiveLoadStage progressiveLoadStage = ProgressiveLoadStage.WORLD_READY;
    private long progressiveLoadStartedMs = System.currentTimeMillis();
    private int loadedLayerCount;
    private TextView acquisitionText;
    private SignalBeaconView signalBeaconView;
    private SourceMatrixView sourceMatrixView;
    private TextView crawlText;
    private TextView correlationText;
    private TextView catalogTitle;
    private TextView catalogStatus;
    private TextView leftReadout;
    private TextView rightReadout;
    private Button sourceButton;
    private Button detailWatchButton;
    private Button detailShareButton;
    private Button catalogPageShareButton;
    private Button localButton;
    private Button typeButton;
    private Button regionButton;
    private Button severityButton;
    private Button timeWindowButton;
    private Button projectionButton;
    private Button catalogMoreButton;
    private Button replayPlayButton;
    private SeekBar replaySeek;
    private TextView replayStatus;
    private EditText searchInput;
    private EditText catalogSearch;
    private boolean wideLayout;
    private boolean localMode;
    private double localLatitude;
    private double localLongitude;
    private double localSouth = Double.NaN;
    private double localWest = Double.NaN;
    private double localNorth = Double.NaN;
    private double localEast = Double.NaN;
    private boolean localCountryScope;
    private String localCountryCode = "";
    private String localName = "";
    private int typeIndex;
    private int regionIndex;
    private int minimumSeverity = 1;
    private int timeWindowIndex = 2;
    private String selectedSourceUrl = "";
    private Signal selectedSignal;
    private Signal currentAcquisition;
    private boolean currentActivityIsAcquisition;
    private MediaPlayer radioPlayer;
    private String playingRadioId = "";
    private long acquisitionCount;
    private long lastWeatherFrame;
    private List<WorldDataRepository.RadarFrame> radarFrames = Collections.emptyList();
    private int scanStep;
    private int watchCursor;
    private int acquisitionAnimationToken;
    private int briefRotationCursor;
    private long lastFreshAcquisitionAtMs;
    private String catalogCategory = "AIRCRAFT";
    private String catalogNewsType = "ALL";
    private String f9CountryLens = "UGANDA";
    private String f12ReplayWindow = "NOW";
    private long f13ReplayAnchorMs = 0L;
    private int catalogVisibleLimit = 60;
    private boolean repositoryStarted;
    private boolean destroyed;
    private boolean safeMode;
    private volatile SituationAnalyzer.Brief latestBrief;
    private long lastAnalysisRequestedMs;
    private String lastCounterText = "";
    private RegionalFocus regionalFocus;
    private static final double UGANDA_HOME_LAT = 1.3733d;
    private static final double UGANDA_HOME_LON = 32.2903d;
    private static final double UGANDA_HOME_ZOOM = 4.4d;
    private Button homeButton;
    private final List<String> localMapMarks = new ArrayList<>();
    private double watchedAreaLat = Double.NaN;
    private double watchedAreaLon = Double.NaN;
    private String watchedAreaName = "";
    private boolean replayMode;
    private boolean replayPlaying;
    private long replayTimeMs;
    private long replayFrameAtMs;
    private String pendingCatalog = "";
    private String pendingNewsStoryId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        aircraftWatchlist = new AircraftWatchlist(this);
        vesselWatchlist = new VesselWatchlist(this);
        if(mapView!=null)mapView.setWatchedVesselKeys(vesselWatchlist.keys());
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        utcClock.setTimeZone(TimeZone.getTimeZone("UTC"));
        eventTime.setTimeZone(TimeZone.getTimeZone("UTC"));
        regionalFocus = RegionalFocus.detect();
        canonicalWatchStore = new CanonicalWatchStore(this);
        captureWidgetDeepLink(getIntent());
        safeMode = getIntent().getBooleanExtra("safe_mode", false)
                || CrashLedger.shouldUseSafeMode(this);

        for (Signal.Layer layer : Signal.Layer.values()) {
            enabled.put(layer, true);
            layerSignals.put(layer, Collections.emptyList());
            feedStatuses.put(layer, FeedStatus.loading("Starting"));
        }

        wideLayout = getResources().getConfiguration().screenWidthDp >= 840;
        // Return from onCreate with a tiny usable surface first. Android can paint this frame
        // immediately instead of holding its launch screen while the full newsroom view is
        // inflated. Live feeds are attached only after the command deck is already responsive.
        showStartupShell(safeMode
                ? "OPENING RECOVERY MODE • NETWORK FEEDS PAUSED"
                : "PREPARING NATIVE COMMAND DECK");
        startupHandler.postDelayed(this::initializeApplication, STARTUP_UI_DELAY_MS);
    }

    private void showStartupShell(String message) {
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setGravity(Gravity.CENTER);
        shell.setPadding(dp(28), dp(28), dp(28), dp(28));
        shell.setBackgroundColor(BG);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.du_brand_mark);
        logo.setContentDescription("DU World Monitor globe mark");
        shell.addView(logo, new LinearLayout.LayoutParams(dp(92), dp(92)));

        TextView title = text(APP_BRAND, TEXT, 20, true);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.08f);
        shell.addView(title, marginParams(0, 8, 0, 3));

        TextView promise = text("GLOBAL SIGNALS • LOCAL WITNESSES • SOURCE AWARE",
                AMBER, 8, true);
        promise.setGravity(Gravity.CENTER);
        shell.addView(promise, marginParams(0, 0, 0, 14));

        ProgressBar progress = new ProgressBar(this);
        progress.setIndeterminateTintList(ColorStateList.valueOf(CYAN));
        shell.addView(progress, new LinearLayout.LayoutParams(dp(38), dp(38)));

        TextView state = text(message, CYAN, 9, true);
        state.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        state.setGravity(Gravity.CENTER);
        shell.addView(state, marginParams(0, 14, 0, 0));

        TextView disclosure = text(
                "THE INTERFACE OPENS FIRST • LIVE SOURCES JOIN IN THE BACKGROUND",
                MUTED, 8, false);
        disclosure.setGravity(Gravity.CENTER);
        shell.addView(disclosure, marginParams(0, 8, 0, 0));
        setContentView(shell);
    }

    private void initializeApplication() {
        if (destroyed || isFinishing()) return;
        try {
            monitorStore = new MonitorStore(this);
            buildInterface();
            repository = safeMode ? null : new WorldDataRepository(this, this);
            latestBrief = SituationAnalyzer.analyze(
                    new EnumMap<>(layerSignals), new EnumMap<>(feedStatuses),
                    System.currentTimeMillis());
            tickClockGuarded();
            tickActivityGuarded();
            applyWidgetDeepLink();
            if (safeMode) {
                feedPulse.setText("RECOVERY MODE • LIVE NETWORK FEEDS PAUSED • LOCAL DATA SAFE");
                feedPulse.setTextColor(AMBER);
            } else {
                startupHandler.postDelayed(this::startRepositoryWhenReady,
                        STARTUP_FEED_DELAY_MS);
            }
            startupHandler.postDelayed(() -> {
                if (!destroyed) CrashLedger.markStable(this);
            }, 8_000L);
        } catch (RuntimeException error) {
            Log.e(LOG_TAG, "Unable to initialise native command deck", error);
            String reference = CrashLedger.recordRecovered(
                    this, "MainActivity.initializeApplication", error);
            showStartupRecovery(reference);
        }
    }

    private void startRepositoryWhenReady() {
        if (destroyed || repositoryStarted || repository == null) return;
        repositoryStarted = true;
        try {
            repository.start();
            feedPulse.setText("SOURCE HEALTH / APP READY • LIVE SOURCES JOINING");
            feedPulse.setTextColor(CYAN);
        } catch (RuntimeException error) {
            Log.e(LOG_TAG, "Live source coordinator failed to start", error);
            feedPulse.setText("SOURCE HEALTH / APP READY • FEEDS OFFLINE • RETRY FROM MENU");
            feedPulse.setTextColor(RED);
        }
    }

    private void showStartupRecovery(String reference) {
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setGravity(Gravity.CENTER);
        shell.setPadding(dp(28), dp(28), dp(28), dp(28));
        shell.setBackgroundColor(BG);
        TextView title = text("COMMAND DECK DID NOT OPEN", RED, 15, true);
        title.setGravity(Gravity.CENTER);
        shell.addView(title, marginParams(0, 0, 0, 10));
        TextView explanation = text(
                "The failing part was contained. Open recovery mode without live network feeds, or retry the complete command deck.",
                MUTED, 10, false);
        explanation.setGravity(Gravity.CENTER);
        shell.addView(explanation, marginParams(0, 0, 0, 18));
        shell.addView(text("CRASH REFERENCE • "
                        + (reference == null || reference.isEmpty() ? "NOT AVAILABLE" : reference),
                CYAN, 8, true), marginParams(0, 0, 0, 14));
        Button safe = actionButton("OPEN RECOVERY MODE", AMBER);
        safe.setOnClickListener(view -> restartMain(true));
        shell.addView(safe, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        Button retry = actionButton("RETRY COMPLETE COMMAND DECK", CYAN);
        retry.setOnClickListener(view -> {
            safeMode = false;
            showStartupShell("RETRYING NATIVE COMMAND DECK");
            startupHandler.postDelayed(this::initializeApplication, STARTUP_UI_DELAY_MS);
        });
        shell.addView(retry, marginParams(0, 8, 0, 0));
        setContentView(shell);
    }

    private void restartMain(boolean recovery) {
        Intent restart = new Intent(this, MainActivity.class);
        restart.putExtra("safe_mode", recovery);
        startActivity(restart);
        finish();
    }

    private void buildInterface() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int top = insets.getSystemWindowInsetTop();
            int bottom = insets.getSystemWindowInsetBottom();
            if (view.getPaddingTop() != top || view.getPaddingBottom() != bottom) {
                view.setPadding(0, top, 0, bottom);
            }
            return insets;
        });

        FrameLayout commandDeck = new FrameLayout(this);
        mapView = new SatelliteMapView(this);
        mapView.setListener(new SatelliteMapView.Listener() {
            @Override
            public void onSignalTap(Signal signal) {
                routeUniversalGlobeTap(signal);
            }

            @Override
            public void onSignalTapCandidates(List<Signal> signals) {
                showGlobeObjectChooser(signals);
            }

            @Override
            public void onLocationLongPress(double latitude, double longitude) {
                showGestureLocationActions(latitude, longitude);
            }

            @Override
            public void onAircraftTrailPointTap(Signal signal,long observedAtMs,
                    double latitude,double longitude) {
                showAircraftHistoricalPosition(signal,observedAtMs,latitude,longitude);
            }
            @Override
            public void onVesselTrailPointTap(Signal signal,long observedAtMs,
                    double latitude,double longitude) {
                showVesselHistoricalPosition(signal,observedAtMs,latitude,longitude);
            }

            @Override
            public void onEmptyGlobeTap() {
                if (detailPanel != null && detailPanel.getVisibility() == View.VISIBLE) {
                    detailPanel.setVisibility(View.GONE);
                }
                if (mapView != null) mapView.clearSelection();
            }

            @Override
            public void onViewportChanged(SatelliteMapView.Bounds bounds) {
                if (repository != null) {
                    repository.updateTrackingViewport(
                            bounds, !mapView.isGlobeMode(), mapView.getZoom());
                }
                if (projectionButton != null) {
                    projectionButton.setText(mapView.isGlobeMode()
                            ? "DISPLAY • GLOBE" : "DISPLAY • SATELLITE TRACKER");
                }
            }
        });
        // A broad timezone-derived lens makes the first useful view relevant immediately.
        // It uses no GPS, account, location permission or network lookup.
        mapView.setCenter(regionalFocus.latitude, regionalFocus.longitude, 2.25d);
        commandDeck.addView(mapView, fullFrame());

        View search = buildSearchBar();
        FrameLayout.LayoutParams searchParams = new FrameLayout.LayoutParams(
                wideLayout ? dp(760) : ViewGroup.LayoutParams.MATCH_PARENT,
                dp(52), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        searchParams.setMargins(wideLayout ? dp(148) : dp(12), dp(wideLayout ? 66 : 70),
                wideLayout ? dp(148) : dp(12), 0);
        search.setElevation(dp(6));
        commandDeck.addView(search, searchParams);

        View liveHud = buildLiveHud();
        FrameLayout.LayoutParams hudParams = new FrameLayout.LayoutParams(
                wideLayout ? dp(760) : ViewGroup.LayoutParams.MATCH_PARENT,
                dp(wideLayout ? 82 : 78), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        hudParams.setMargins(wideLayout ? dp(148) : dp(12), dp(wideLayout ? 128 : 126),
                wideLayout ? dp(148) : dp(12), 0);
        liveHud.setElevation(dp(5));
        commandDeck.addView(liveHud, hudParams);

        if (!wideLayout) {
            leftReadout = buildSideReadout(true);
            FrameLayout.LayoutParams leftParams = new FrameLayout.LayoutParams(
                    dp(62), dp(168), Gravity.START | Gravity.TOP);
            leftParams.setMargins(dp(7), dp(210), 0, 0);
            commandDeck.addView(leftReadout, leftParams);

            rightReadout = buildSideReadout(false);
            FrameLayout.LayoutParams rightParams = new FrameLayout.LayoutParams(
                    dp(86), dp(172), Gravity.END | Gravity.TOP);
            rightParams.setMargins(0, dp(210), dp(7), 0);
            commandDeck.addView(rightReadout, rightParams);
        }

        layersPanel = buildLayersPanel();
        FrameLayout.LayoutParams layersParams = new FrameLayout.LayoutParams(
                dp(232), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START);
        layersParams.setMargins(dp(8), dp(132), 0, dp(8));
        commandDeck.addView(layersPanel, layersParams);
        layersPanel.setElevation(dp(10));
        // The globe always owns the opening screen. Full panels appear only when requested.
        layersPanel.setVisibility(View.GONE);

        compactLayerRail = buildCompactLayerRail();
        FrameLayout.LayoutParams railParams = new FrameLayout.LayoutParams(
                dp(wideLayout ? 58 : 50), ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.START | Gravity.CENTER_VERTICAL);
        railParams.setMargins(dp(6), dp(56), 0, dp(56));
        compactLayerRail.setElevation(dp(12));
        commandDeck.addView(compactLayerRail, railParams);

        wirePanel = buildWirePanel();
        FrameLayout.LayoutParams wireParams = new FrameLayout.LayoutParams(
                dp(334), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END);
        wireParams.setMargins(0, dp(132), dp(8), dp(8));
        commandDeck.addView(wirePanel, wireParams);
        wirePanel.setElevation(dp(10));
        wirePanel.setVisibility(View.GONE);

        LinearLayout zoomRail = new LinearLayout(this);
        zoomRail.setOrientation(LinearLayout.VERTICAL);
        Button zoomIn = compactButton("+");
        Button zoomOut = compactButton("−");
        zoomIn.setOnClickListener(view -> mapView.zoomBy(1d));
        zoomOut.setOnClickListener(view -> mapView.zoomBy(-1d));
        zoomRail.addView(zoomIn, new LinearLayout.LayoutParams(dp(48), dp(48)));
        zoomRail.addView(zoomOut, new LinearLayout.LayoutParams(dp(48), dp(48)));
        FrameLayout.LayoutParams zoomParams = new FrameLayout.LayoutParams(
                dp(48), dp(100), Gravity.END | Gravity.CENTER_VERTICAL);
        zoomParams.setMargins(0, 0, dp(14), 0);
        commandDeck.addView(zoomRail, zoomParams);

        feedPulse = text("SOURCE HEALTH / INITIALISING", CYAN, 8, true);
        feedPulse.setGravity(Gravity.CENTER);
        feedPulse.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        feedPulse.setSingleLine(true);
        feedPulse.setEllipsize(TextUtils.TruncateAt.END);
        feedPulse.setShadowLayer(dp(4), 0f, dp(1), Color.BLACK);
        feedPulse.setBackgroundColor(Color.TRANSPARENT);
        feedPulse.setElevation(dp(5));
        FrameLayout.LayoutParams pulseParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 28 : 22), Gravity.BOTTOM);
        pulseParams.setMargins(wideLayout ? dp(148) : dp(12), 0,
                wideLayout ? dp(148) : dp(12), dp(wideLayout ? 10 : 5));
        commandDeck.addView(feedPulse, pulseParams);

        crawlText = text("SCANNING PUBLIC SOURCES • WAITING FOR FIRST DATA PACKET",
                TEXT, 8, true);
        crawlText.setSingleLine(true);
        crawlText.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        crawlText.setMarqueeRepeatLimit(-1);
        crawlText.setSelected(true);
        crawlText.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        crawlText.setGravity(Gravity.CENTER_VERTICAL);
        crawlText.setPadding(dp(10), 0, dp(10), 0);
        crawlText.setShadowLayer(dp(4), 0f, dp(1), Color.BLACK);
        crawlText.setBackgroundColor(Color.TRANSPARENT);
        crawlText.setElevation(dp(4));
        FrameLayout.LayoutParams crawlParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 28 : 22), Gravity.BOTTOM);
        crawlParams.setMargins(wideLayout ? dp(148) : dp(12), 0,
                wideLayout ? dp(148) : dp(12), dp(wideLayout ? 46 : 29));
        commandDeck.addView(crawlText, crawlParams);

        View missionDock = buildMissionDock();
        FrameLayout.LayoutParams dockParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 44 : 40), Gravity.BOTTOM);
        dockParams.setMargins(wideLayout ? dp(148) : dp(12), 0,
                wideLayout ? dp(148) : dp(12), dp(wideLayout ? 82 : 55));
        commandDeck.addView(missionDock, dockParams);

        correlationText = text(
                "ANALYSIS DESK / WAITING FOR SOURCE-ATTRIBUTED RECORDS\n"
                        + "CORRELATION IS NOT CONFIRMATION • NO PREDICTION",
                MUTED, wideLayout ? 8 : 7, true);
        correlationText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        correlationText.setGravity(Gravity.CENTER);
        correlationText.setMaxLines(2);
        correlationText.setEllipsize(TextUtils.TruncateAt.END);
        correlationText.setPadding(dp(8), dp(2), dp(8), dp(2));
        correlationText.setShadowLayer(dp(5), 0f, dp(1), Color.BLACK);
        correlationText.setBackgroundColor(Color.TRANSPARENT);
        correlationText.setContentDescription(
                "Observed cross-source watch. Tap to open the intelligence brief.");
        correlationText.setOnClickListener(view -> openCatalog("BRIEF"));
        FrameLayout.LayoutParams correlationParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 38 : 32), Gravity.BOTTOM);
        correlationParams.setMargins(wideLayout ? dp(148) : dp(12), 0,
                wideLayout ? dp(148) : dp(12), dp(wideLayout ? 130 : 99));
        commandDeck.addView(correlationText, correlationParams);

        replayPanel = buildReplayPanel();
        FrameLayout.LayoutParams replayParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 68 : 62), Gravity.BOTTOM);
        replayParams.setMargins(wideLayout ? dp(148) : dp(12), 0,
                wideLayout ? dp(148) : dp(12), dp(wideLayout ? 174 : 136));
        commandDeck.addView(replayPanel, replayParams);
        replayPanel.setElevation(dp(7));
        replayPanel.setVisibility(View.GONE);

        catalogPanel = buildCatalogPanel();
        FrameLayout.LayoutParams catalogParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER);
        catalogParams.setMargins(dp(wideLayout ? 70 : 10), dp(10),
                dp(wideLayout ? 70 : 10), dp(10));
        commandDeck.addView(catalogPanel, catalogParams);
        catalogPanel.setElevation(dp(20));
        catalogPanel.setVisibility(View.GONE);

        detailPanel = buildDetailPanel();
        FrameLayout.LayoutParams detailParams = new FrameLayout.LayoutParams(
                wideLayout ? dp(500) : ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | (wideLayout ? Gravity.CENTER_HORIZONTAL : Gravity.CENTER_HORIZONTAL));
        detailParams.setMargins(wideLayout ? dp(148) : dp(12), 0,
                wideLayout ? dp(148) : dp(12), dp(134));
        commandDeck.addView(detailPanel, detailParams);
        detailPanel.setElevation(dp(24));
        detailPanel.setVisibility(View.GONE);

        root.addView(commandDeck, fullFrame());

        // FIX10.30 / F10.30 / 10.2 — the globe owns the full operational canvas.
        // Navigation remains available as a compact translucent overlay instead of
        // permanently consuming vertical map space.
        View header = buildHeader();
        FrameLayout.LayoutParams headerParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 58 : 62),
                Gravity.TOP);
        header.setAlpha(0.94f);
        header.setElevation(dp(30));
        root.addView(header, headerParams);

        setContentView(root);
    }

    private View buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(6), dp(4), dp(6), dp(4));
        header.setBackgroundColor(PANEL);
        header.setElevation(dp(4));

        Button menu = headerButton(wideLayout ? "LAYERS" : "MENU");
        menu.setOnClickListener(view -> togglePanel(layersPanel));
        header.addView(menu, new LinearLayout.LayoutParams(
                dp(wideLayout ? 76 : 48), dp(44)));

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.HORIZONTAL);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        brand.setPadding(dp(wideLayout ? 12 : 7), 0, dp(wideLayout ? 12 : 5), 0);
        ImageView mark = new ImageView(this);
        mark.setImageResource(R.drawable.du_brand_mark);
        mark.setContentDescription("DU World Monitor");
        brand.addView(mark, new LinearLayout.LayoutParams(
                dp(wideLayout ? 40 : 30), dp(wideLayout ? 40 : 30)));
        LinearLayout wordmark = new LinearLayout(this);
        wordmark.setOrientation(LinearLayout.VERTICAL);
        wordmark.setPadding(dp(6), 0, 0, 0);
        TextView title = text(APP_BRAND, TEXT, wideLayout ? 15 : 10, true);
        title.setSingleLine(true);
        liveText = text(wideLayout
                        ? "● LIVE / GLOBAL SIGNALS • " + regionalFocus.name + " LENS"
                        : "● LIVE / " + regionalFocus.name,
                RED, wideLayout ? 8 : 7, true);
        wordmark.addView(title);
        wordmark.addView(liveText);
        brand.addView(wordmark, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        brand.setContentDescription(
                "DU World Monitor. Global signals, local witnesses, source-aware intelligence.");
        brand.setOnClickListener(view -> showBrandStory());
        header.addView(brand, new LinearLayout.LayoutParams(
                wideLayout ? dp(330) : 0, ViewGroup.LayoutParams.WRAP_CONTENT,
                wideLayout ? 0f : 1f));

        counterText = text("AIR 0  SEA 0  EVENTS 0", MUTED, 9, true);
        counterText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        counterText.setGravity(Gravity.CENTER);
        if (wideLayout) {
            header.addView(counterText, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        }

        clockText = text("--:--:-- UTC", TEXT, wideLayout ? 9 : 8, true);
        clockText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        clockText.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        header.addView(clockText, new LinearLayout.LayoutParams(
                wideLayout ? dp(220) : dp(86), ViewGroup.LayoutParams.MATCH_PARENT));

        Button index = headerButton("INTEL");
        index.setContentDescription("Open live intelligence brief and source index");
        index.setOnClickListener(view -> openCatalog("BRIEF"));
        header.addView(index, new LinearLayout.LayoutParams(
                dp(wideLayout ? 60 : 46), dp(44)));

        Button settings = headerButton("SET");
        settings.setContentDescription("Provider settings");
        settings.setOnClickListener(view -> showSettings());
        header.addView(settings, new LinearLayout.LayoutParams(
                dp(wideLayout ? 48 : 42), dp(44)));
        return header;
    }

    private void showBrandStory() {
        LinearLayout story = new LinearLayout(this);
        story.setOrientation(LinearLayout.VERTICAL);
        story.setPadding(dp(20), dp(14), dp(20), dp(8));
        ImageView mark = new ImageView(this);
        mark.setImageResource(R.drawable.du_brand_mark);
        mark.setContentDescription("DU World Monitor globe mark");
        story.addView(mark, new LinearLayout.LayoutParams(dp(78), dp(78)));
        story.addView(text("DU WORLD MONITOR", TEXT, 18, true),
                marginParams(0, 8, 0, 2));
        story.addView(text("SEE THE WORLD. HEAR THE LOCAL WITNESS.", AMBER, 10, true));
        story.addView(text(
                "A native global situation room for public-source aviation, maritime, hazards, weather, markets, space activity and source-labelled reports from local monitors.",
                TEXT, 10, false), marginParams(0, 10, 0, 0));
        story.addView(text(
                "Built for clarity: live source health, visible timestamps, credibility labels and local-first reporting without presenting unverified information as confirmed fact.",
                MUTED, 9, false), marginParams(0, 8, 0, 0));
        String crashReference = CrashLedger.lastReference(this);
        if (!crashReference.isEmpty()) {
            story.addView(text("LAST RECOVERY REFERENCE • " + crashReference,
                    CYAN, 8, true), marginParams(0, 10, 0, 0));
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(story)
                .setNegativeButton("CLOSE", null)
                .setPositiveButton("OPEN LOCAL MONITORS", (ignored, which) -> openLocalMonitors())
                .create();
        dialog.show();
    }

    private View buildLiveHud() {
        LinearLayout hud = new LinearLayout(this);
        hud.setOrientation(LinearLayout.VERTICAL);
        hud.setPadding(dp(8), dp(3), dp(8), dp(3));
        // Keep the globe visually dominant. This heads-up display is information painted over
        // the map, not a pair of opaque side cards.
        hud.setBackgroundColor(Color.TRANSPARENT);

        globeStatusStrip = text("DU WORLD MONITOR • DATA INITIALISING",
                TEXT, wideLayout ? 9 : 8, true);
        globeStatusStrip.setSingleLine(true);
        globeStatusStrip.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        globeStatusStrip.setGravity(Gravity.CENTER_VERTICAL);
        globeStatusStrip.setEllipsize(TextUtils.TruncateAt.END);
        hud.addView(globeStatusStrip, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 20 : 17)));

        providerHealthButton = compactButton("SOURCE HEALTH");
        providerHealthButton.setContentDescription("Open provider health details");
        providerHealthButton.setOnClickListener(view -> showProviderHealth());
        hud.addView(providerHealthButton, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 28 : 24)));

        telemetryText = text("LENS / " + regionalFocus.name
                        + " • SECTOR / BOOT • AIR 0 • SEA 0 • EVENT 0 • RADIO 0 • TV 0",
                MUTED, wideLayout ? 8 : 7, true);
        telemetryText.setSingleLine(true);
        telemetryText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        telemetryText.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        telemetryText.setMarqueeRepeatLimit(-1);
        telemetryText.setSelected(true);
        telemetryText.setGravity(Gravity.CENTER_VERTICAL);
        hud.addView(telemetryText, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 20 : 16)));

        if (!wideLayout) {
            // The phone layout still exposes real provider totals; the header no longer has
            // to surrender most of its width to a long counter line.
            hud.addView(counterText, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(14)));
        }

        LinearLayout matrixRow = new LinearLayout(this);
        matrixRow.setOrientation(LinearLayout.HORIZONTAL);
        matrixRow.setGravity(Gravity.CENTER_VERTICAL);
        sourceMatrixView = new SourceMatrixView(this);
        matrixRow.addView(sourceMatrixView, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        signalBeaconView = new SignalBeaconView(this);
        matrixRow.addView(signalBeaconView, new LinearLayout.LayoutParams(
                dp(wideLayout ? 245 : 132), ViewGroup.LayoutParams.MATCH_PARENT));
        hud.addView(matrixRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 22 : 18)));

        acquisitionText = text("LATEST ACQUISITION / STARTING PUBLIC SOURCES",
                TEXT, wideLayout ? 9 : 8, true);
        acquisitionText.setSingleLine(true);
        acquisitionText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        acquisitionText.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        acquisitionText.setMarqueeRepeatLimit(-1);
        acquisitionText.setSelected(true);
        acquisitionText.setGravity(Gravity.CENTER_VERTICAL);
        acquisitionText.setContentDescription(
                "Newest source-attributed acquisition. Tap to open full details.");
        acquisitionText.setOnClickListener(view -> {
            if (currentAcquisition != null) showDetail(currentAcquisition);
            else togglePanel(wirePanel);
        });
        hud.addView(acquisitionText, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 32 : 24)));
        return hud;
    }

    /**
     * A small, always-available mission dock replaces persistent side panels. Every action
     * opens an existing native page or map mode; it never launches a hosted dashboard.
     */
    private View buildMissionDock() {
        HorizontalScrollView scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        scroller.setFillViewport(true);
        scroller.setBackground(panelBackground(Color.argb(212, 8, 12, 17), LINE, 14));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(4), 0, dp(4), 0);
        addMissionAction(row, "GLOBE", view -> showGlobeOverview());
        addMissionAction(row, "MONITORS", view -> openLocalMonitors());
        addMissionAction(row, "NEWS", view -> openCatalog("NEWS")); // F9 owns REGION + REPLAY lenses (F11-F13).
        addMissionAction(row, "FUSE", view -> openCatalog("FUSION"));
        addMissionAction(row, "AIR", view -> openCatalog("AIRCRAFT"));
        addMissionAction(row, "SEA", view -> openCatalog("SHIPS"));
        addMissionAction(row, "WX", view -> openCatalog("WEATHER"));
        addMissionAction(row, "AIRWX", view -> openCatalog("AIRSPACE"));
        addMissionAction(row, "ORBIT", view -> openCatalog("ORBITS"));
        addMissionAction(row, "EVENTS", view -> openCatalog("EVENTS"));
        addMissionAction(row, "WIRE", view -> togglePanel(wirePanel));
        addMissionAction(row, "BRIEF", view -> openCatalog("BRIEF"));
        addMissionAction(row, "RISK", view -> openCatalog("RISK"));
        addMissionAction(row, "ANALYST", view -> openCatalog("ANALYST"));
        addMissionAction(row, "WIDGETS", view -> openCatalog("WIDGETS"));
        addMissionAction(row, "MARKETS", view -> openCatalog("MARKETS"));
        addMissionAction(row, "AIRPORTS", view -> openCatalog("AIRPORTS"));
        addMissionAction(row, "PORTS", view -> openCatalog("PORTS"));
        addMissionAction(row, "CAM", view -> openCatalog("CAMERAS"));
        addMissionAction(row, "RADIO", view -> openCatalog("RADIO"));
        addMissionAction(row, "TV", view -> openCatalog("TV"));
        addMissionAction(row, "SPACE", view -> openCatalog("SPACE"));
        addMissionAction(row, "INFRA", view -> openCatalog("INFRA"));
        addMissionAction(row, "CALLS", view -> openCatalog("CALLS"));
        addMissionAction(row, "SOURCES", view -> openCatalog("SOURCES"));
        scroller.addView(row);
        return scroller;
    }

    private LinearLayout buildReplayPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(7), dp(3), dp(7), dp(3));
        panel.setBackground(panelBackground(Color.argb(226, 8, 12, 17), CYAN, 14));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        replayStatus = text("4D REPLAY / WAITING FOR ACQUIRED FRAMES", CYAN,
                wideLayout ? 8 : 7, true);
        replayStatus.setSingleLine(true);
        replayStatus.setEllipsize(TextUtils.TruncateAt.END);
        replayStatus.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        row.addView(replayStatus, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        replayPlayButton = compactButton("PLAY");
        replayPlayButton.setOnClickListener(view -> toggleReplayPlayback());
        row.addView(replayPlayButton, new LinearLayout.LayoutParams(dp(56), dp(29)));
        Button live = compactButton("LIVE");
        live.setTextColor(GREEN);
        live.setOnClickListener(view -> returnToLive());
        row.addView(live, new LinearLayout.LayoutParams(dp(56), dp(29)));
        Button close = compactButton("×");
        close.setOnClickListener(view -> replayPanel.setVisibility(View.GONE));
        row.addView(close, new LinearLayout.LayoutParams(dp(34), dp(29)));
        panel.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(30)));

        replaySeek = new SeekBar(this);
        replaySeek.setMax(1_000);
        replaySeek.setProgress(1_000);
        replaySeek.setProgressTintList(ColorStateList.valueOf(CYAN));
        replaySeek.setThumbTintList(ColorStateList.valueOf(TEXT));
        replaySeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar seekBar) {
                replayPlaying = false;
                replayPlayButton.setText("PLAY");
            }

            @Override public void onProgressChanged(
                    SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) enterReplayProgress(progress);
            }

            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        panel.addView(replaySeek, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));
        return panel;
    }

    private void addMissionAction(
            LinearLayout parent,
            String label,
            View.OnClickListener listener) {
        Button action = headerButton(label);
        action.setTextColor(TEXT);
        action.setOnClickListener(listener);
        int width = Math.max(62, label.length() * 9 + 22);
        parent.addView(action, new LinearLayout.LayoutParams(dp(width), dp(40)));
    }

    private void toggleReplayPanel() {
        if (replayPanel == null) return;
        if (replayPanel.getVisibility() == View.VISIBLE) {
            replayPanel.setVisibility(View.GONE);
            return;
        }
        replayPanel.setVisibility(View.VISIBLE);
        replayPanel.bringToFront();
        updateReplayStatus();
        if (replayEngine.frameCount() == 0) {
            Toast.makeText(this,
                    "Replay begins after the first mapped source frame is acquired",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void enterReplayProgress(int progress) {
        long oldest = replayEngine.oldestMs();
        long newest = replayEngine.newestMs();
        if (oldest <= 0L || newest <= 0L) {
            replayMode = false;
            updateReplayStatus();
            return;
        }
        replayMode = true;
        replayTimeMs = oldest + Math.round((newest - oldest)
                * Math.max(0, Math.min(1_000, progress)) / 1_000d);
        applyFilters();
    }

    private void toggleReplayPlayback() {
        if (replayEngine.frameCount() == 0) {
            Toast.makeText(this, "No acquired replay frame yet", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!replayMode) enterReplayProgress(0);
        replayPlaying = !replayPlaying;
        replayPlayButton.setText(replayPlaying ? "PAUSE" : "PLAY");
        updateReplayStatus();
    }

    private void returnToLive() {
        replayMode = false;
        replayPlaying = false;
        replayTimeMs = 0L;
        replayFrameAtMs = 0L;
        if (replaySeek != null) replaySeek.setProgress(1_000);
        if (replayPlayButton != null) replayPlayButton.setText("PLAY");
        if (mapView != null) mapView.setReplayState(false, 0L);
        if (mapView != null) mapView.setRadarAnimationPlaying(true);
        applyFilters();
        updateReplayStatus();
    }

    private void advanceReplay() {
        if (!replayMode || !replayPlaying) return;
        long newest = replayEngine.newestMs();
        long oldest = replayEngine.oldestMs();
        if (newest <= 0L || oldest <= 0L) {
            returnToLive();
            return;
        }
        replayTimeMs = Math.min(newest, replayTimeMs + 15_000L);
        if (replayTimeMs >= newest) replayPlaying = false;
        int progress = newest == oldest ? 1_000 : (int) Math.round(
                (replayTimeMs - oldest) * 1_000d / (newest - oldest));
        replaySeek.setProgress(Math.max(0, Math.min(1_000, progress)));
        replayPlayButton.setText(replayPlaying ? "PAUSE" : "PLAY");
        applyFilters();
    }

    private void updateReplayStatus() {
        if (replayStatus == null) return;
        int frames = replayEngine.frameCount();
        if (!replayMode) {
            long span = Math.max(0L, replayEngine.newestMs() - replayEngine.oldestMs());
            replayStatus.setText(String.format(Locale.US,
                    "LIVE / 4D BUFFER %d FRAMES • %dm • THIS SESSION",
                    frames, span / 60_000L));
            replayStatus.setTextColor(GREEN);
            return;
        }
        long shown = replayFrameAtMs > 0L ? replayFrameAtMs : replayTimeMs;
        replayStatus.setText("4D REPLAY / " + eventTime.format(new Date(shown))
                + " • ACQUIRED FRAMES ONLY" + (replayPlaying ? " • PLAYING" : " • PAUSED"));
        replayStatus.setTextColor(AMBER);
    }

    private long currentTimelineMs() {
        return replayMode && replayFrameAtMs > 0L
                ? replayFrameAtMs : System.currentTimeMillis();
    }

    private void showGlobeOverview() {
        if (layersPanel != null) layersPanel.setVisibility(View.GONE);
        if (wirePanel != null) wirePanel.setVisibility(View.GONE);
        if (catalogPanel != null) catalogPanel.setVisibility(View.GONE);
        if (detailPanel != null) detailPanel.setVisibility(View.GONE);
        mapView.stopFollowing();
        mapView.setGlobeMode(true);
        Toast.makeText(this, "Global live globe", Toast.LENGTH_SHORT).show();
    }

    private void showRegionalOverview() {
        if (layersPanel != null) layersPanel.setVisibility(View.GONE);
        if (wirePanel != null) wirePanel.setVisibility(View.GONE);
        if (catalogPanel != null) catalogPanel.setVisibility(View.GONE);
        if (detailPanel != null) detailPanel.setVisibility(View.GONE);
        mapView.stopFollowing();
        mapView.setCenter(regionalFocus.latitude, regionalFocus.longitude, 5.0d);
        Toast.makeText(this,
                "REGIONAL LENS — " + regionalFocus.name
                        + " • derived from timezone only, not GPS",
                Toast.LENGTH_LONG).show();
    }

    private TextView buildSideReadout(boolean left) {
        // Side readouts are words and figures only: no cards, rails or touch-blocking
        // full-height panels over the globe.
        TextView rail = text(left
                        ? regionalFocus.name
                        + "\nBOOT • 24H\n\nAIR 0\nSEA 0\nEVT 0\nCAM 0\nMEDIA 0"
                        : "LATEST SIGNAL\n\nSCANNING\nPUBLIC SOURCES",
                MUTED, 7, true);
        rail.setGravity(left ? Gravity.TOP | Gravity.START : Gravity.TOP | Gravity.END);
        rail.setPadding(dp(2), dp(4), dp(2), dp(4));
        rail.setLineSpacing(dp(2), 1.08f);
        rail.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        rail.setLetterSpacing(0.04f);
        rail.setShadowLayer(dp(5), 0f, dp(1), Color.BLACK);
        rail.setBackgroundColor(Color.TRANSPARENT);
        rail.setMaxLines(left ? 8 : 10);
        rail.setEllipsize(TextUtils.TruncateAt.END);
        if (left) {
            rail.setContentDescription("Live layer counts. Tap to open Layers.");
            rail.setOnClickListener(view -> togglePanel(layersPanel));
        } else {
            rail.setContentDescription("Newest acquired activity. Tap for full details.");
            rail.setOnClickListener(view -> {
                if (currentAcquisition != null) showDetail(currentAcquisition);
                else togglePanel(wirePanel);
            });
        }
        return rail;
    }

    private View buildSearchBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(5), dp(4), dp(5), dp(4));
        bar.setBackground(panelBackground(Color.argb(232, 8, 12, 17), LINE, 20));

        searchInput = new EditText(this);
        searchInput.setHint("SEARCH PLACE / AIR / SHIP / EVENT / CAM / INFRA");
        searchInput.setHintTextColor(MUTED);
        searchInput.setTextColor(TEXT);
        searchInput.setTextSize(12);
        searchInput.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        searchInput.setSingleLine(true);
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchInput.setBackgroundColor(Color.TRANSPARENT);
        searchInput.setPadding(dp(10), 0, dp(6), 0);
        searchInput.setOnEditorActionListener((view, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                runSearch();
                return true;
            }
            return false;
        });
        bar.addView(searchInput, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        Button search = compactButton("GO");
        search.setOnClickListener(view -> runSearch());
        bar.addView(search, new LinearLayout.LayoutParams(dp(48), dp(42)));
        homeButton = compactButton("UG HOME");
        homeButton.setContentDescription("Return to Uganda operational home");
        homeButton.setOnClickListener(view -> returnToUgandaHome());
        homeButton.setOnLongClickListener(view -> { showUgandaHomeOptions(); return true; });
        bar.addView(homeButton, new LinearLayout.LayoutParams(dp(72), dp(42)));


        localButton = compactButton("LOCAL OFF");
        localButton.setOnClickListener(view -> toggleLocalMode());
        bar.addView(localButton, new LinearLayout.LayoutParams(dp(90), dp(42)));
        return bar;
    }

    /**
     * Full-screen native source index. Large provider responses are rendered in batches so a
     * phone never has to inflate thousands of cards at once.
     */
    private LinearLayout buildCatalogPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(10), dp(12), dp(10));
        panel.setBackground(panelBackground(Color.argb(250, 5, 8, 12), LINE, 20));

        LinearLayout command = new LinearLayout(this);
        command.setGravity(Gravity.CENTER_VERTICAL);
        catalogTitle = text("LIVE SOURCE INDEX / AIRCRAFT", TEXT, wideLayout ? 15 : 12, true);
        command.addView(catalogTitle, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button close = compactButton("CLOSE");
        close.setOnClickListener(view -> panel.setVisibility(View.GONE));
        command.addView(close, new LinearLayout.LayoutParams(dp(72), dp(44)));
        panel.addView(command);

        TextView disclosure = text(
                "PROVIDER-RETURNED RECORDS • PUBLIC SOURCES • AVAILABILITY VARIES",
                MUTED, 8, true);
        disclosure.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        panel.addView(disclosure, marginParams(0, 2, 0, 8));

        catalogPageShareButton = actionButton("SHARE THIS PAGE AS CARD", GREEN);
        catalogPageShareButton.setContentDescription(
                "Create a DU World Monitor image card for this information page");
        catalogPageShareButton.setOnClickListener(view -> shareCurrentPage());
        panel.addView(catalogPageShareButton, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        HorizontalScrollView categoryScroller = new HorizontalScrollView(this);
        categoryScroller.setHorizontalScrollBarEnabled(false);
        LinearLayout categories = new LinearLayout(this);
        categories.setOrientation(LinearLayout.HORIZONTAL);
        for (String category : CATALOG_CATEGORIES) {
            Button button = compactButton(category);
            button.setOnClickListener(view -> openCatalog(category));
            categories.addView(button, new LinearLayout.LayoutParams(
                    dp(Math.max(72, category.length() * 9 + 22)), dp(42)));
        }
        categoryScroller.addView(categories);
        panel.addView(categoryScroller, marginParams(0, 0, 0, 8));

        catalogSearch = new EditText(this);
        catalogSearch.setHint("FILTER THIS PAGE BY NAME, COUNTRY, CALL SIGN OR DETAIL");
        catalogSearch.setHintTextColor(MUTED);
        catalogSearch.setTextColor(TEXT);
        catalogSearch.setTextSize(11);
        catalogSearch.setSingleLine(true);
        catalogSearch.setPadding(dp(12), 0, dp(12), 0);
        catalogSearch.setBackground(panelBackground(PANEL_ALT, LINE, 14));
        catalogSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence value, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence value, int start, int before, int count) {
                catalogVisibleLimit = 60;
                rebuildCatalogPage();
            }
            @Override public void afterTextChanged(Editable value) { }
        });
        panel.addView(catalogSearch, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        newsCategoryBar = new LinearLayout(this);
        newsCategoryBar.setOrientation(LinearLayout.HORIZONTAL);
        for (String type : NEWS_CATEGORIES) {
            Button button = compactButton(type);
            button.setOnClickListener(view -> {
                catalogNewsType = type;
                catalogVisibleLimit = 60;
                rebuildCatalogPage();
            });
            newsCategoryBar.addView(button, new LinearLayout.LayoutParams(dp(92), dp(40)));
        }
        HorizontalScrollView newsScroller = new HorizontalScrollView(this);
        newsScroller.setHorizontalScrollBarEnabled(false);
        newsScroller.addView(newsCategoryBar);
        panel.addView(newsScroller, marginParams(0, 7, 0, 5));

        catalogStatus = text("WAITING FOR AIRCRAFT SOURCE", CYAN, 9, true);
        catalogStatus.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        panel.addView(catalogStatus, marginParams(0, 2, 0, 6));

        catalogList = new LinearLayout(this);
        catalogList.setOrientation(LinearLayout.VERTICAL);
        ScrollView listScroller = new ScrollView(this);
        listScroller.setFillViewport(true);
        listScroller.addView(catalogList);
        panel.addView(listScroller, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        catalogMoreButton = actionButton("LOAD 60 MORE", CYAN);
        catalogMoreButton.setOnClickListener(view -> {
            catalogVisibleLimit += 60;
            rebuildCatalogPage();
        });
        panel.addView(catalogMoreButton, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
        return panel;
    }

    private void openCatalog(String category) {
        catalogCategory = category == null ? "AIRCRAFT"
                : category.trim().toUpperCase(Locale.ROOT);
        if ("MONITORS".equals(catalogCategory)) {
            openLocalMonitors();
            return;
        }
        catalogVisibleLimit = 60;
        catalogNewsType = "NEWS".equals(catalogCategory) ? "UGANDA" : "ALL";
        if ("NEWS".equals(catalogCategory)) f17RestoreState();
        if (catalogSearch != null) catalogSearch.setText("");
        detailPanel.setVisibility(View.GONE);
        if (!wideLayout) {
            layersPanel.setVisibility(View.GONE);
            wirePanel.setVisibility(View.GONE);
        }
        catalogPanel.setVisibility(View.VISIBLE);
        catalogPanel.bringToFront();
        rebuildCatalogPage();
        if ("NEWS".equals(catalogCategory)) { maybeAskNewsPermission(); refreshLocalNews(false); }
    }

    private void openLocalMonitors() {
        openLocalMonitors("");
    }

    private void openLocalMonitors(String reportId) {
        Intent intent = new Intent(this, LocalMonitorActivity.class);
        if (reportId != null && !reportId.trim().isEmpty()) {
            intent.putExtra("report_id", reportId.trim());
        }
        startActivity(intent);
    }

    private String categoryForLayer(Signal.Layer layer) {
        switch (layer) {
            case FLIGHTS: return "AIRCRAFT";
            case SHIPS: return "SHIPS";
            case WEATHER: return "WEATHER";
            case AIRSPACE: return "AIRSPACE";
            case NATURAL: return "EVENTS";
            case NEWS: return "NEWS";
            case SATELLITES: return "ORBITS";
            case SPACE_WEATHER: return "SPACE";
            case INFRASTRUCTURE: return "INFRA";
            case MARKETS: return "MARKETS";
            case WEBCAMS: return "CAMERAS";
            case RADIO: return "RADIO";
            case TV: return "TV";
            case MEDIA: return "CALLS";
            default: return "AIRCRAFT";
        }
    }

    private Signal.Layer layerForCategory(String category) {
        switch (category) {
            case "AIRCRAFT": return Signal.Layer.FLIGHTS;
            case "SHIPS":
            case "BOATS": return Signal.Layer.SHIPS;
            case "WEATHER": return Signal.Layer.WEATHER;
            case "AIRSPACE": return Signal.Layer.AIRSPACE;
            case "EVENTS": return Signal.Layer.NATURAL;
            case "NEWS": return Signal.Layer.NEWS;
            case "ORBITS": return Signal.Layer.SATELLITES;
            case "SPACE": return Signal.Layer.SPACE_WEATHER;
            case "INFRA": return Signal.Layer.INFRASTRUCTURE;
            case "AIRPORTS":
            case "RUNWAYS":
            case "PORTS": return Signal.Layer.INFRASTRUCTURE;
            case "MARKETS": return Signal.Layer.MARKETS;
            case "CAMERAS": return Signal.Layer.WEBCAMS;
            case "RADIO": return Signal.Layer.RADIO;
            case "TV": return Signal.Layer.TV;
            case "CALLS": return Signal.Layer.MEDIA;
            default: return Signal.Layer.FLIGHTS;
        }
    }

    private void rebuildCatalogPage() {
        if (catalogPanel == null || catalogPanel.getVisibility() != View.VISIBLE
                || catalogList == null) return;
        if ("BRIEF".equals(catalogCategory)) {
            rebuildSituationBrief();
            return;
        }
        if ("FUSION".equals(catalogCategory)) {
            rebuildFusionPage();
            return;
        }
        if ("RISK".equals(catalogCategory)) {
            rebuildCountryRiskPage();
            return;
        }
        if ("ANALYST".equals(catalogCategory)) {
            rebuildAnalystPage();
            return;
        }
        if ("WIDGETS".equals(catalogCategory)) {
            rebuildWidgetsPage();
            return;
        }
        if ("SOURCES".equals(catalogCategory)) {
            rebuildSourcesPage();
            return;
        }
        if ("WEATHER".equals(catalogCategory)) {
            rebuildWeatherPage();
            return;
        }
        if ("NEWS".equals(catalogCategory)) {
            rebuildLocalNewsPage();
            return;
        }
        Signal.Layer layer = layerForCategory(catalogCategory);
        FeedStatus status = feedStatuses.get(layer);
        List<Signal> values = catalogSignals();
        catalogList.removeAllViews();
        catalogSearch.setVisibility(View.VISIBLE);
        catalogTitle.setText("LIVE SOURCE INDEX / " + catalogCategory
                + ("NEWS".equals(catalogCategory) && !"ALL".equals(catalogNewsType)
                ? " / " + catalogNewsType : ""));
        newsCategoryBar.setVisibility("NEWS".equals(catalogCategory)
                ? View.VISIBLE : View.GONE);

        String state = status == null ? "STARTING" : status.state.name();
        String message = status == null ? "Waiting for source" : status.message;
        String age = sourceAgeText(layer);
        int visible = Math.min(catalogVisibleLimit, values.size());
        catalogStatus.setText(String.format(Locale.US,
                "SHOWING %,d / %,d RETAINED • PROVIDER %,d • %s • SOURCE AGE %s • %s",
                visible, values.size(), status == null ? values.size() : status.count,
                state, age, message));
        catalogStatus.setTextColor(status != null && status.state == FeedStatus.State.OFFLINE
                ? RED : status != null && (status.state == FeedStatus.State.KEY_REQUIRED
                || status.state == FeedStatus.State.LOADING
                || status.state == FeedStatus.State.DELAYED
                || status.state == FeedStatus.State.CACHED) ? AMBER : GREEN);

        if (values.isEmpty()) {
            String reason;
            if ("WEATHER".equals(catalogCategory)) {
                reason = "WEATHER IS A LIVE MAP LAYER. USE SOURCE CONTROL TO DISPLAY THE LATEST RAINVIEWER FRAME.";
            } else if (status != null && status.state == FeedStatus.State.KEY_REQUIRED) {
                reason = status.message + " — OPEN PROVIDER SETTINGS TO CONNECT THIS OPTIONAL SOURCE.";
            } else {
                reason = "NO PROVIDER RECORDS MATCH THIS PAGE AND FILTER YET.";
            }
            TextView empty = text(reason, MUTED, 11, true);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(20), dp(40), dp(20), dp(40));
            catalogList.addView(empty, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        } else {
            for (int index = 0; index < visible; index++) {
                catalogList.addView(buildCatalogCard(values.get(index)),
                        marginParams(0, 0, 0, 7));
            }
        }
        catalogMoreButton.setVisibility(visible < values.size() ? View.VISIBLE : View.GONE);
    }

    /** Full-screen source-aware brief inspired by a newsroom assignment desk, not a forecast. */
    private void rebuildSituationBrief() {
        long now = currentTimelineMs();
        SituationAnalyzer.Brief brief = replayMode
                ? SituationAnalyzer.analyze(layersForTimeline(), feedStatuses, now)
                : latestBrief;
        if (brief == null) {
            brief = SituationAnalyzer.analyze(layerSignals, feedStatuses, now);
            latestBrief = brief;
        }
        final SituationAnalyzer.Brief shareBrief = brief;
        updateAnalysisRibbon();
        catalogList.removeAllViews();
        catalogTitle.setText("GLOBAL INTELLIGENCE BRIEF / SOURCE-AWARE");
        catalogSearch.setVisibility(View.GONE);
        newsCategoryBar.setVisibility(View.GONE);
        catalogMoreButton.setVisibility(View.GONE);
        catalogStatus.setText(String.format(Locale.US,
                "UPDATED %s • %,d PROVIDER RECORDS • %,d FRESH BY LAYER-SPECIFIC WINDOWS",
                eventTime.format(new Date(now)), brief.totalRecords, brief.freshRecords));
        catalogStatus.setTextColor(brief.offlineFeeds > 0 ? AMBER : GREEN);

        List<NewsItem> briefNews = new NewsStore(this).topUganda(3);
        if (!briefNews.isEmpty()) {
            catalogList.addView(text("UGANDA / TOP LOCAL NEWS", CYAN, 10, true), marginParams(0,0,0,4));
            for (NewsItem item : briefNews) catalogList.addView(buildLocalNewsCard(item), marginParams(0,0,0,5));
        }

        TextView disclosure = text(
                "OBSERVED OPEN-SOURCE SIGNALS ONLY • CORRELATION IS NOT CONFIRMATION • NO PREDICTION",
                AMBER, 9, true);
        disclosure.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        disclosure.setPadding(0, dp(4), 0, dp(8));
        catalogList.addView(disclosure);

        HorizontalScrollView metricScroller = new HorizontalScrollView(this);
        metricScroller.setHorizontalScrollBarEnabled(false);
        LinearLayout metrics = new LinearLayout(this);
        metrics.setOrientation(LinearLayout.HORIZONTAL);
        metrics.addView(buildBriefMetric("READY", brief.onlineFeeds, GREEN));
        metrics.addView(buildBriefMetric("CACHED", brief.cachedFeeds, AMBER));
        metrics.addView(buildBriefMetric("OFFLINE", brief.offlineFeeds, RED));
        metrics.addView(buildBriefMetric("OPTIONAL", brief.optionalFeeds, CYAN));
        metrics.addView(buildBriefMetric("PRIORITY", brief.prioritySignals, RED));
        metrics.addView(buildBriefMetric("DOMAIN WATCH", brief.domainWatches.size(), CYAN));
        metrics.addView(buildBriefMetric("CORRELATED", brief.correlations.size(), AMBER));
        metricScroller.addView(metrics);
        catalogList.addView(metricScroller, marginParams(0, 0, 0, 12));

        addBriefHeading("REGIONAL OBSERVED SIGNAL DENSITY",
                "Weighted from recent event records, age and stated credibility. Not a risk forecast.");
        for (SituationAnalyzer.RegionalState region : brief.regions) {
            int color = region.observedScore >= 55 ? RED
                    : region.observedScore >= 30 ? AMBER : GREEN;
            TextView line = text(String.format(Locale.US,
                    "● %-12s  %02d/99  %-21s  RECORDS %,d  PRIORITY %,d  12H Δ%+d  •  SHARE CARD",
                    region.region, region.observedScore, region.level,
                    region.recordCount, region.priorityCount,
                    region.twelveHourMovement()), color, 9, true);
            line.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            line.setPadding(dp(8), dp(7), dp(8), dp(7));
            line.setOnClickListener(view -> {
                Map<String, String> regionalFacts = new LinkedHashMap<>();
                regionalFacts.put("OBSERVED SCORE", region.observedScore + " / 99");
                regionalFacts.put("LEVEL", region.level);
                regionalFacts.put("RECORDS", String.format(Locale.US, "%,d", region.recordCount));
                regionalFacts.put("PRIORITY", String.format(Locale.US, "%,d", region.priorityCount));
                regionalFacts.put("12-HOUR MOVEMENT", String.format(Locale.US, "%+d",
                        region.twelveHourMovement()));
                ShareCardRenderer.share(this, customShareCard(
                        region.region + " observed signal density",
                        "Weighted from recent source-attributed event records, age and stated credibility.",
                        region.level, "OBSERVED INDICATOR — NOT CONFIRMATION",
                        "REGIONAL BRIEF", region.region,
                        Math.max(1, Math.min(5, 1 + region.observedScore / 20)),
                        APP_BRAND + " intelligence brief", now,
                        Double.NaN, Double.NaN, regionalFacts, color,
                        "Observed density is not a risk forecast. Provider coverage varies by region."));
            });
            catalogList.addView(line);
        }

        addBriefHeading("CROSS-DOMAIN PROXIMITY WATCHES",
                "Recent mapped event records compared with nearby provider aircraft and vessel fixes. Proximity is not causation or confirmation.");
        if (brief.domainWatches.isEmpty()) {
            catalogList.addView(text(
                    "NO EVENT COORDINATE CURRENTLY OVERLAPS RECENT AIR OR SEA TELEMETRY INSIDE THE STATED WINDOWS.",
                    MUTED, 10, true), marginParams(0, 4, 0, 10));
        } else {
            for (SituationAnalyzer.DomainWatch watch : brief.domainWatches) {
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(12), dp(10), dp(12), dp(10));
                int accent = watch.severity >= 4 ? RED : CYAN;
                card.setBackground(panelBackground(PANEL_ALT, accent, 14));
                card.addView(text("● OBSERVED PROXIMITY • " + watch.observedDomains
                        + " DOMAINS • NOT CONFIRMATION", accent, 8, true));
                card.addView(text(watch.label, TEXT, 11, true),
                        marginParams(0, 4, 0, 3));
                card.addView(text(String.format(Locale.US,
                        "AIR %,d / 500 km   •   SEA %,d / 300 km   •   EVENTS %,d   •   PUBLISHERS %,d",
                        watch.aircraftNearby, watch.vesselsNearby, watch.relatedEvents,
                        watch.distinctSources), Color.rgb(202, 215, 222), 9, true));
                card.addView(text(watch.explanation, MUTED, 8, false),
                        marginParams(0, 5, 0, 0));
                TextView source = text("ANCHOR  " + watch.anchor.source + "  •  "
                        + eventTime.format(new Date(watch.anchor.timestampMs)),
                        MUTED, 8, false);
                source.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
                card.addView(source, marginParams(0, 6, 0, 0));
                Button share = compactButton("SHARE CARD");
                share.setTextColor(GREEN);
                share.setOnClickListener(view -> {
                    Map<String, String> watchFacts = new LinkedHashMap<>();
                    watchFacts.put("OBSERVED DOMAINS", String.valueOf(watch.observedDomains));
                    watchFacts.put("AIR WITHIN 500 KM", String.valueOf(watch.aircraftNearby));
                    watchFacts.put("SEA WITHIN 300 KM", String.valueOf(watch.vesselsNearby));
                    watchFacts.put("RELATED EVENTS", String.valueOf(watch.relatedEvents));
                    watchFacts.put("DISTINCT PUBLISHERS", String.valueOf(watch.distinctSources));
                    ShareCardRenderer.share(this, customShareCard(
                            watch.label, watch.explanation, "CROSS-DOMAIN WATCH",
                            "OBSERVED PROXIMITY — NOT CONFIRMATION", "INTELLIGENCE BRIEF",
                            watch.anchor.region, watch.severity, watch.anchor.source,
                            watch.anchor.timestampMs, watch.anchor.latitude,
                            watch.anchor.longitude, watchFacts, accent,
                            "Proximity is not causation or confirmation. Verify the anchor event at its original source."));
                });
                card.addView(share, marginParams(0, 7, 0, 0));
                card.setOnClickListener(view -> showDetail(watch.anchor));
                catalogList.addView(card, marginParams(0, 0, 0, 7));
            }
        }

        addBriefHeading("CROSS-SOURCE CORRELATIONS",
                "Distinct publisher records aligned by place or headline language inside 12 hours.");
        if (brief.correlations.isEmpty()) {
            catalogList.addView(text(
                    "NO MULTI-SOURCE CLUSTERS MEET THE CURRENT TRANSPARENT RULES.",
                    MUTED, 10, true), marginParams(0, 4, 0, 10));
        } else {
            for (SituationAnalyzer.Correlation correlation : brief.correlations) {
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(12), dp(10), dp(12), dp(10));
                int accent = correlation.severity >= 4 ? RED : AMBER;
                card.setBackground(panelBackground(PANEL_ALT, accent, 14));
                card.addView(text("● CORRELATED SIGNALS • NOT CONFIRMATION • SEV "
                        + correlation.severity, accent, 8, true));
                card.addView(text(correlation.label, TEXT, 11, true),
                        marginParams(0, 4, 0, 3));
                card.addView(text(correlation.explanation, Color.rgb(202, 215, 222),
                        9, false));
                TextView source = text("SOURCES  " + correlation.sources + "  •  "
                        + eventTime.format(new Date(correlation.newestTimestampMs)),
                        MUTED, 8, false);
                source.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
                card.addView(source, marginParams(0, 6, 0, 0));
                Button share = compactButton("SHARE CARD");
                share.setTextColor(GREEN);
                share.setOnClickListener(view -> {
                    Map<String, String> correlationFacts = new LinkedHashMap<>();
                    correlationFacts.put("RECORDS", String.valueOf(correlation.recordCount));
                    correlationFacts.put("DISTINCT SOURCES", correlation.sources);
                    correlationFacts.put("SEVERITY", String.valueOf(correlation.severity));
                    ShareCardRenderer.share(this, customShareCard(
                            correlation.label, correlation.explanation,
                            "CROSS-SOURCE WATCH", "CORRELATED SIGNALS — NOT CONFIRMATION",
                            "INTELLIGENCE BRIEF", correlation.primary.region,
                            correlation.severity, correlation.sources,
                            correlation.newestTimestampMs, correlation.primary.latitude,
                            correlation.primary.longitude, correlationFacts, accent,
                            "Language or place alignment across sources is not confirmation. Read the original reports."));
                });
                card.addView(share, marginParams(0, 7, 0, 0));
                card.setOnClickListener(view -> showDetail(correlation.primary));
                catalogList.addView(card, marginParams(0, 0, 0, 7));
            }
        }

        addBriefHeading("SOURCE HEALTH AND COVERAGE",
                "Counts are provider-returned coverage, never a claim to show every object on Earth.");
        for (Signal.Layer layer : Signal.Layer.values()) {
            FeedStatus status = feedStatuses.get(layer);
            if (status == null) continue;
            TextView line = text(String.format(Locale.US,
                    "● %-17s  %-12s  %,6d  AGE %-7s  %s  •  %s",
                    feedDisplayName(layer), status.state.name(), status.count,
                    sourceAgeText(layer),
                    eventTime.format(new Date(status.updatedAtMs)), status.message),
                    feedStateColor(status), 8, true);
            line.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
            line.setPadding(dp(8), dp(7), dp(8), dp(7));
            line.append("  •  SHARE CARD");
            line.setOnClickListener(view -> {
                Map<String, String> healthFacts = new LinkedHashMap<>();
                healthFacts.put("STATE", status.state.name());
                healthFacts.put("RECORDS", String.format(Locale.US, "%,d", status.count));
                healthFacts.put("MESSAGE", status.message);
                ShareCardRenderer.share(this, customShareCard(
                        feedDisplayName(layer) + " source health",
                        status.message, status.state.name(),
                        "PROVIDER HEALTH — NOT EVENT CONFIRMATION", "SOURCE HEALTH",
                        "GLOBAL", status.state == FeedStatus.State.OFFLINE ? 4 : 1,
                        feedDisplayName(layer), status.updatedAtMs, Double.NaN, Double.NaN,
                        healthFacts, feedStateColor(status),
                        "Counts are provider-returned coverage and never a claim to show every object on Earth."));
            });
            catalogList.addView(line);
        }

        addBriefHeading("CREDIBILITY INVENTORY",
                "Urgency lights and truth status remain separate throughout the app.");
        TextView credibility = text(String.format(Locale.US,
                "RAW TELEMETRY %,d   •   CALCULATED %,d   •   REPORTED %,d   •   OFFICIAL/CONFIRMED %,d",
                brief.rawSignals, brief.calculatedSignals,
                brief.reportedSignals, brief.officialSignals),
                CYAN, 10, true);
        credibility.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        credibility.setPadding(dp(8), dp(8), dp(8), dp(16));
        credibility.append("\nSHARE CARD");
        credibility.setOnClickListener(view -> {
            Map<String, String> credibilityFacts = new LinkedHashMap<>();
            credibilityFacts.put("RAW TELEMETRY", String.format(Locale.US, "%,d", shareBrief.rawSignals));
            credibilityFacts.put("CALCULATED FROM PUBLIC ELEMENTS",
                    String.format(Locale.US, "%,d", shareBrief.calculatedSignals));
            credibilityFacts.put("REPORTED", String.format(Locale.US, "%,d", shareBrief.reportedSignals));
            credibilityFacts.put("OFFICIAL / CONFIRMED",
                    String.format(Locale.US, "%,d", shareBrief.officialSignals));
            ShareCardRenderer.share(this, customShareCard(
                    "Credibility inventory",
                    "Current inventory keeps operational urgency separate from corroboration status.",
                    "INVENTORY", "MIXED SOURCE STATES", "INTELLIGENCE BRIEF", "GLOBAL",
                    1, APP_BRAND + " credibility desk", now, Double.NaN, Double.NaN,
                    credibilityFacts, CYAN,
                    "Open individual records for their source, timestamp and exact credibility status."));
        });
        catalogList.addView(credibility);
    }

    private void rebuildFusionPage() {
        long now = currentTimelineMs();
        List<IncidentFusionEngine.Scene> scenes = IncidentFusionEngine.build(
                layersForTimeline(), now);
        prepareSpecialCatalog("4D INCIDENT FUSION / OBSERVED ALIGNMENT",
                String.format(Locale.US,
                        "%s • %,d SCENES • AIR ≤500 KM • SEA ≤300 KM • ORBIT ≤900 KM • AIRSPACE ≤650 KM",
                        replayMode ? "REPLAY " + eventTime.format(new Date(now)) : "LIVE",
                        scenes.size()), scenes.isEmpty() ? MUTED : AMBER);

        TextView disclosure = text(
                "PROXIMITY, TIMING AND SOURCE ALIGNMENT ARE ANALYST LEADS — NEVER CAUSATION OR CONFIRMATION",
                AMBER, 9, true);
        disclosure.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        disclosure.setPadding(0, dp(4), 0, dp(10));
        catalogList.addView(disclosure);
        if (scenes.isEmpty()) {
            catalogList.addView(text(
                    "NO MAPPED NEWS OR NATURAL-EVENT ANCHOR CURRENTLY MEETS THE FUSION WINDOW. LIVE PROVIDERS CONTINUE IN THE BACKGROUND.",
                    MUTED, 10, true), marginParams(0, 18, 0, 0));
            return;
        }

        int limit = Math.min(catalogVisibleLimit, scenes.size());
        for (int index = 0; index < limit; index++) {
            IncidentFusionEngine.Scene scene = scenes.get(index);
            Signal anchor = scene.anchor;
            int accent = anchor.severity >= 4 ? RED : AMBER;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(10), dp(12), dp(10));
            card.setBackground(panelBackground(PANEL_ALT, accent, 14));
            card.addView(text(String.format(Locale.US,
                    "● %s • OBSERVED ALIGNMENT %02d/99 • NOT CONFIRMATION",
                    scene.label, scene.observedScore), accent, 8, true));
            card.addView(text(anchor.title, TEXT, 11, true), marginParams(0, 5, 0, 3));
            TextView matrix = text(String.format(Locale.US,
                    "AIR %,d   SEA %,d   ORBIT %,d   AIRWX %,d   RELATED %,d   SOURCES %,d",
                    scene.nearbyAircraft, scene.nearbyVessels,
                    scene.nearbyOrbitalObjects, scene.nearbyWarnings,
                    scene.relatedReports, scene.independentSources),
                    Color.rgb(202, 215, 222), 9, true);
            matrix.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            card.addView(matrix);
            card.addView(text("SOURCES  " + scene.sourceNames + "\nANCHOR  "
                    + anchor.source + " • " + eventTime.format(new Date(anchor.timestampMs)),
                    MUTED, 8, false), marginParams(0, 6, 0, 0));

            LinearLayout actions = new LinearLayout(this);
            Button open = compactButton("OPEN ANCHOR");
            open.setTextColor(CYAN);
            open.setOnClickListener(view -> showDetail(anchor));
            Button share = compactButton("SHARE FUSION CARD");
            share.setTextColor(GREEN);
            share.setOnClickListener(view -> {
                Map<String, String> facts = new LinkedHashMap<>();
                facts.put("OBSERVED ALIGNMENT", scene.observedScore + " / 99");
                facts.put("AIRCRAFT WITHIN 500 KM", String.valueOf(scene.nearbyAircraft));
                facts.put("VESSELS WITHIN 300 KM", String.valueOf(scene.nearbyVessels));
                facts.put("ORBITAL OBJECTS WITHIN 900 KM",
                        String.valueOf(scene.nearbyOrbitalObjects));
                facts.put("AIRSPACE WARNINGS WITHIN 650 KM",
                        String.valueOf(scene.nearbyWarnings));
                facts.put("RELATED EVENT RECORDS", String.valueOf(scene.relatedReports));
                facts.put("INDEPENDENT SOURCES", String.valueOf(scene.independentSources));
                facts.put("SOURCES", scene.sourceNames);
                ShareCardRenderer.share(this, customShareCard(
                        anchor.title,
                        "Cross-layer public-source alignment around a mapped anchor. Proximity is not causation.",
                        scene.label + " " + scene.observedScore + "/99",
                        "OBSERVED ALIGNMENT — NOT CONFIRMATION", "4D FUSION",
                        anchor.region, anchor.severity, scene.sourceNames,
                        anchor.timestampMs, anchor.latitude, anchor.longitude, facts, accent,
                        "This card reports proximity and timing only. It does not prove identity, intent, causation or confirmation."));
            });
            actions.addView(open, new LinearLayout.LayoutParams(0, dp(42), 1f));
            LinearLayout.LayoutParams shareParams =
                    new LinearLayout.LayoutParams(0, dp(42), 1f);
            shareParams.setMargins(dp(7), 0, 0, 0);
            actions.addView(share, shareParams);
            card.addView(actions, marginParams(0, 8, 0, 0));
            card.setOnClickListener(view -> showDetail(anchor));
            catalogList.addView(card, marginParams(0, 0, 0, 7));
        }
        catalogMoreButton.setVisibility(limit < scenes.size() ? View.VISIBLE : View.GONE);
    }

    private void prepareSpecialCatalog(String title, String status, int color) {
        catalogList.removeAllViews();
        catalogTitle.setText(title);
        catalogSearch.setVisibility(View.GONE);
        newsCategoryBar.setVisibility(View.GONE);
        catalogMoreButton.setVisibility(View.GONE);
        catalogStatus.setText(status);
        catalogStatus.setTextColor(color);
    }

    private void rebuildWeatherPage() {
        FeedStatus status = feedStatuses.get(Signal.Layer.WEATHER);
        String state = status == null ? "STARTING" : status.state.name();
        prepareSpecialCatalog("WEATHER OPERATIONS / RADAR TIMELINE",
                String.format(Locale.US, "RAINVIEWER • %s • %,d FRAMES • %s",
                        state, radarFrames.size(), status == null ? "Waiting" : status.message),
                status != null && status.state == FeedStatus.State.OFFLINE ? RED : CYAN);

        if (!radarFrames.isEmpty()) {
            int intelligenceIndex = mapView.getRadarFrameIndex();
            if (intelligenceIndex < 0 || intelligenceIndex >= radarFrames.size())
                intelligenceIndex = radarFrames.size() - 1;
            TextView intelligence = text(weatherFrameIntelligence(
                    radarFrames.get(intelligenceIndex), intelligenceIndex), TEXT, 9, true);
            intelligence.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            intelligence.setPadding(dp(10),dp(8),dp(10),dp(8));
            intelligence.setBackground(panelBackground(PANEL_ALT, CYAN, 12));
            catalogList.addView(intelligence, marginParams(0,0,0,9));
        }

        TextView disclosure = text(
                "PAST TWO HOURS • 10-MINUTE FRAME STEPS • MAX RADAR ZOOM 7 • NOT A FORECAST",
                AMBER, 9, true);
        disclosure.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        catalogList.addView(disclosure, marginParams(0, 3, 0, 10));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        Button open = actionButton("OPEN RADAR MAP", CYAN);
        open.setOnClickListener(view -> {
            catalogPanel.setVisibility(View.GONE);
            enabled.put(Signal.Layer.WEATHER, true);
            CheckBox toggle = layerChecks.get(Signal.Layer.WEATHER);
            if (toggle != null) toggle.setChecked(true);
            mapView.setWeatherVisible(true);
            mapView.setGlobeMode(false);
        });
        Button animate = actionButton(mapView.isRadarAnimationPlaying()
                ? "PAUSE LOOP" : "PLAY LOOP", GREEN);
        animate.setOnClickListener(view -> {
            mapView.setRadarAnimationPlaying(!mapView.isRadarAnimationPlaying());
            rebuildWeatherPage();
        });
        controls.addView(open, new LinearLayout.LayoutParams(0, dp(46), 1f));
        LinearLayout.LayoutParams second = new LinearLayout.LayoutParams(0, dp(46), 1f);
        second.setMargins(dp(7), 0, 0, 0);
        controls.addView(animate, second);
        catalogList.addView(controls, marginParams(0, 0, 0, 12));

        if (radarFrames.isEmpty()) {
            catalogList.addView(text(
                    "NO RADAR HISTORY IS AVAILABLE YET. THE GLOBE REMAINS RESPONSIVE WHILE THE FEED RETRIES.",
                    MUTED, 10, true), marginParams(0, 12, 0, 12));
        } else {
            int selected = mapView.getRadarFrameIndex();
            for (int index = radarFrames.size() - 1; index >= 0; index--) {
                final int frameIndex = index;
                final WorldDataRepository.RadarFrame frame = radarFrames.get(index);
                boolean active = index == selected;
                LinearLayout frameRow = new LinearLayout(this);
                frameRow.setOrientation(LinearLayout.HORIZONTAL);
                frameRow.setGravity(Gravity.CENTER_VERTICAL);
                frameRow.setPadding(dp(8), dp(4), dp(5), dp(4));
                frameRow.setBackground(panelBackground(PANEL_ALT, active ? GREEN : LINE, 12));
                TextView row = text(String.format(Locale.US,
                        "%s FRAME %02d / %02d   %s",
                        active ? "▶" : "•", index + 1, radarFrames.size(),
                        eventTime.format(new Date(frame.timestampMs))),
                        active ? GREEN : TEXT, 10, true);
                row.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
                row.setPadding(dp(12), dp(10), dp(12), dp(10));
                row.setOnClickListener(view -> {
                    mapView.selectRadarFrame(frameIndex);
                    rebuildWeatherPage();
                });
                frameRow.addView(row, new LinearLayout.LayoutParams(
                        0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                Button share = compactButton("SHARE");
                share.setTextColor(GREEN);
                share.setOnClickListener(view -> {
                    Map<String, String> frameFacts = new LinkedHashMap<>();
                    frameFacts.put("FRAME", String.format(Locale.US, "%02d / %02d",
                            frameIndex + 1, radarFrames.size()));
                    frameFacts.put("INTERVAL", "10-minute historical radar frame");
                    frameFacts.put("MAP LIMIT", "RainViewer public tiles; maximum zoom 7");
                    ShareCardRenderer.share(this, customShareCard(
                            "RainViewer radar frame",
                            "Historical precipitation radar frame selected in the weather operations timeline.",
                            active ? "SELECTED FRAME" : "RADAR HISTORY",
                            "PUBLIC SOURCE — NOT A FORECAST",
                            "WEATHER", "GLOBAL", 1, "RainViewer Weather Maps API",
                            frame.timestampMs, Double.NaN, Double.NaN, frameFacts, CYAN,
                            "Radar coverage varies by country. Frame generation time is not a forecast or a report of ground impact."));
                });
                frameRow.addView(share, new LinearLayout.LayoutParams(dp(78), dp(42)));
                catalogList.addView(frameRow, marginParams(0, 0, 0, 6));
            }
        }
        addBriefHeading("SOURCE AND LIMITS",
                "RainViewer public Weather Maps API. Radar coverage varies by country; frame time is generation time and individual observations inside a frame can differ.");
    }

    private void rebuildCountryRiskPage() {
        long now = currentTimelineMs();
        List<CountrySituationEngine.CountryState> countries =
                CountrySituationEngine.analyze(layersForTimeline(), now);
        prepareSpecialCatalog("COUNTRY WATCH / OBSERVED SIGNAL PRESSURE",
                String.format(Locale.US,
                        "%,d COUNTRY LENSES • UPDATED %s • TRANSPARENT ON-DEVICE SCORING",
                        countries.size(), eventTime.format(new Date(now))), CYAN);
        TextView disclosure = text(
                "NOT A FORECAST • NOT AN OFFICIAL RISK RATING • COARSE COUNTRY ENVELOPES • SOURCE COVERAGE VARIES",
                AMBER, 9, true);
        disclosure.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        catalogList.addView(disclosure, marginParams(0, 3, 0, 10));

        for (CountrySituationEngine.CountryState country : countries) {
            int accent = country.score >= 70 ? RED
                    : country.score >= 45 ? AMBER : country.score >= 20 ? CYAN : GREEN;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(10), dp(12), dp(10));
            card.setBackground(panelBackground(PANEL_ALT, accent, 14));
            LinearLayout top = new LinearLayout(this);
            top.setGravity(Gravity.CENTER_VERTICAL);
            TextView name = text(country.name + " / " + country.iso, TEXT, 11, true);
            TextView score = text(String.format(Locale.US, "%02d/99", country.score),
                    accent, 16, true);
            score.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            top.addView(name, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            top.addView(score);
            card.addView(top);
            card.addView(text("● " + country.level + " • 6H Δ"
                    + String.format(Locale.US, "%+d", country.movement()), accent, 8, true));
            TextView facts = text(String.format(Locale.US,
                    "EVENTS %,d   •   PRIORITY %,d   •   SOURCES %,d   •   AIR %,d   •   SEA %,d",
                    country.eventRecords, country.priorityRecords, country.sourceCount,
                    country.aircraft, country.vessels), Color.rgb(202, 215, 222), 9, false);
            facts.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
            card.addView(facts, marginParams(0, 5, 0, 0));
            Button share = compactButton("SHARE CARD");
            share.setTextColor(GREEN);
            share.setOnClickListener(view -> {
                Map<String, String> riskFacts = new LinkedHashMap<>();
                riskFacts.put("OBSERVED SCORE", country.score + " / 99");
                riskFacts.put("SIX-HOUR MOVEMENT", String.format(Locale.US, "%+d",
                        country.movement()));
                riskFacts.put("EVENT RECORDS", String.format(Locale.US, "%,d",
                        country.eventRecords));
                riskFacts.put("PRIORITY RECORDS", String.format(Locale.US, "%,d",
                        country.priorityRecords));
                riskFacts.put("DISTINCT SOURCES", String.format(Locale.US, "%,d",
                        country.sourceCount));
                riskFacts.put("AIR / SEA CONTEXT", String.format(Locale.US, "%,d / %,d",
                        country.aircraft, country.vessels));
                ShareCardRenderer.share(this, customShareCard(
                        country.name + " observed signal pressure",
                        "Transparent on-device score made from recent mapped event severity, age, credibility and publisher diversity.",
                        country.level,
                        "OBSERVED OPEN-SOURCE INDICATOR — NOT AN OFFICIAL RATING",
                        "COUNTRY WATCH", country.name, Math.max(1, Math.min(5,
                        1 + country.score / 20)),
                        "Source-attributed records visible in " + APP_BRAND,
                        now, country.latitude, country.longitude, riskFacts, accent,
                        "Not a forecast and not an official risk rating. Source coverage varies by country."));
            });
            card.addView(share, marginParams(0, 7, 0, 0));
            card.setOnClickListener(view -> {
                catalogPanel.setVisibility(View.GONE);
                mapView.setCenter(country.latitude, country.longitude, 5.0d);
            });
            catalogList.addView(card, marginParams(0, 0, 0, 7));
        }
        addBriefHeading("HOW THE NUMBER IS MADE",
                "Recent mapped event severity, age, credibility and publisher diversity are combined. Aircraft and vessel counts are displayed for context but do not raise the event score.");
    }

    private void rebuildAnalystPage() {
        List<MovementAnalyzer.Watch> watches = movementAnalyzer.snapshot();
        SituationAnalyzer.Brief brief = latestBrief;
        prepareSpecialCatalog("ON-DEVICE ANALYST / OBSERVED PATTERNS",
                String.format(Locale.US,
                        "%,d MOVEMENT WATCHES • %,d PROXIMITY WATCHES • %,d NEWS CORRELATIONS",
                        watches.size(), brief == null ? 0 : brief.domainWatches.size(),
                        brief == null ? 0 : brief.correlations.size()),
                watches.isEmpty() ? CYAN : AMBER);
        TextView disclosure = text(
                "DETERMINISTIC LOCAL RULES • NO CLOUD AI • NO PREDICTION • EVERY RESULT LINKS TO PROVIDER DATA",
                AMBER, 9, true);
        disclosure.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        catalogList.addView(disclosure, marginParams(0, 3, 0, 10));

        addBriefHeading("AIR / SEA MOVEMENT WATCHES",
                "Thresholds examine recent fixes for emergency squawks, rapid descent, turning, holding-like or low-speed patterns. Intent is never inferred.");
        if (watches.isEmpty()) {
            catalogList.addView(text(
                    "NO CURRENT TRACK HAS CROSSED THE TRANSPARENT WATCH THRESHOLDS. MORE FIXES MAY BE NEEDED.",
                    MUTED, 10, true), marginParams(0, 2, 0, 10));
        }
        for (MovementAnalyzer.Watch watch : watches) {
            int accent = watch.severity >= 4 ? RED : watch.severity >= 3 ? AMBER : CYAN;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(10), dp(12), dp(10));
            card.setBackground(panelBackground(PANEL_ALT, accent, 14));
            card.addView(text("● " + watch.kind + " • OBSERVED / NOT CONFIRMED",
                    accent, 8, true));
            card.addView(text(watch.signal.title, TEXT, 11, true),
                    marginParams(0, 4, 0, 3));
            card.addView(text(watch.detail, Color.rgb(202, 215, 222), 9, false));
            card.addView(text("SOURCE  " + watch.signal.source + "  •  "
                    + eventTime.format(new Date(watch.signal.timestampMs)), MUTED, 8, false),
                    marginParams(0, 6, 0, 0));
            Button share = compactButton("SHARE CARD");
            share.setTextColor(GREEN);
            share.setOnClickListener(view -> {
                Map<String, String> watchFacts = new LinkedHashMap<>(watch.signal.facts);
                watchFacts.put("OBSERVED PATTERN", watch.kind);
                watchFacts.put("ANALYST DETAIL", watch.detail);
                ShareCardRenderer.share(this, customShareCard(
                        watch.signal.title,
                        watch.detail,
                        watch.kind,
                        "OBSERVED PATTERN — NOT CONFIRMED",
                        "ON-DEVICE ANALYST", watch.signal.region, watch.severity,
                        watch.signal.source, watch.signal.timestampMs,
                        watch.signal.latitude, watch.signal.longitude, watchFacts, accent,
                        "A deterministic threshold was crossed. It does not establish identity, intent or an incident."));
            });
            card.addView(share, marginParams(0, 7, 0, 0));
            card.setOnClickListener(view -> showDetail(watch.signal));
            catalogList.addView(card, marginParams(0, 0, 0, 7));
        }

        addBriefHeading("IDENTITY LIMIT",
                "OpenSky's public state vectors do not reliably identify military ownership. The app can flag a special-use callsign pattern, but it never labels an aircraft military without a provider fact.");
        addBriefHeading("LOCAL INTELLIGENCE ENGINE",
                "Country scores, source corroboration, cross-domain proximity and track-pattern checks run on this device. No Ollama server, MCP agent or hidden synthetic feed is required.");
    }

    private void rebuildSourcesPage() {
        prepareSpecialCatalog("SOURCE REGISTRY / COVERAGE AND LIMITS",
                "EVERY PROVIDER STATE IS VISIBLE • OFFLINE FEEDS DO NOT FREEZE THE APP", CYAN);
        Button settings = actionButton("OPEN PROVIDER SETTINGS", AMBER);
        settings.setOnClickListener(view -> showSettings());
        catalogList.addView(settings, marginParams(0, 2, 0, 12));

        for (Signal.Layer layer : Signal.Layer.values()) {
            FeedStatus status = feedStatuses.get(layer);
            if (status == null) continue;
            addSourceRow(feedDisplayName(layer), status.state.name(), status.count,
                    "Source age " + sourceAgeText(layer) + " • " + status.message,
                    feedStateColor(status));
        }
        addBriefHeading("PROVIDER CONTRACTS", "What is connected and what remains conditional.");
        addSourceRow("GDELT DOC + GKG", "ACTIVE", count(Signal.Layer.NEWS),
                "DOC headline polling plus bounded newest 15-minute GKG theme archive", GREEN);
        addSourceRow("OPENSKY", "RATE LIMITED", count(Signal.Layer.FLIGHTS),
                "Anonymous global interval is conservative; OAuth enables faster sector refresh", CYAN);
        addSourceRow("AVIATION WEATHER CENTER", "OFFICIAL SIGMET", count(Signal.Layer.AIRSPACE),
                "Worldwide aviation warnings; map markers use representative polygon points", CYAN);
        addSourceRow("CELESTRAK GP", "CALCULATED", count(Signal.Layer.SATELLITES),
                "Elements refresh no more than every two hours; positions are calculated locally and are not live telemetry", Color.rgb(174, 139, 224));
        addSourceRow("4D REPLAY BUFFER", "THIS SESSION", replayEngine.frameCount(),
                "Up to 60 minutes of frames actually acquired by this device; no manufactured history", CYAN);
        SecurePrefs providerPrefs = repository == null
                ? new SecurePrefs(this) : repository.securePrefs();
        addSourceRow("AISSTREAM", providerPrefs.get(SecurePrefs.AIS_KEY).isEmpty()
                        ? "KEY REQUIRED" : "CONFIGURED", count(Signal.Layer.SHIPS),
                "Personal encrypted key; provider coverage and vessel transmission vary", AMBER);
        addSourceRow("WINDY WEBCAMS", providerPrefs.get(SecurePrefs.WINDY_KEY).isEmpty()
                        ? "KEY REQUIRED" : "CONFIGURED", count(Signal.Layer.WEBCAMS),
                "Provider-permitted listing window; never described as every camera", AMBER);
        addSourceRow("REUTERS / AP / AFP", "LICENSED URL REQUIRED", 0,
                "No unlicensed feed is bundled. Add an authorized HTTPS RSS URL in Settings.", MUTED);
        addSourceRow("PUBLIC SAFETY AUDIO",
                providerPrefs.get(SecurePrefs.PUBLIC_SAFETY_STREAM).isEmpty()
                        ? "NOT CONNECTED" : "USER FEED CONFIGURED", count(Signal.Layer.MEDIA),
                "Native playback only for a lawful direct HTTPS stream supplied by the user", AMBER);
        addSourceRow("MILITARY IDENTITY", "NOT ASSERTED", 0,
                "Public state vectors do not provide dependable ownership or mission identity", MUTED);
        addSourceRow("COMMODITIES", "NO QUOTE SOURCE", 0,
                "Gold/oil values remain blank until a trustworthy authorized provider is connected", MUTED);
        addSourceRow("CAMERA / TV / RADIO", "PUBLIC DIRECT MEDIA", count(Signal.Layer.WEBCAMS)
                        + count(Signal.Layer.TV) + count(Signal.Layer.RADIO),
                "Availability, geoblocking and publisher uptime vary; no WebView is used", CYAN);
    }

    /** R27 launcher intelligence deck, visible and controllable in-app. */
    private void rebuildWidgetsPage() {
        prepareSpecialCatalog("R27 HOME INTELLIGENCE / LIVE MOTION WIDGET DECK",
                "8 NATIVE WIDGETS • REAL PICKER PREVIEWS • SAFE RUNTIME • LIVE SNAPSHOTS",
                GREEN);

        WidgetSnapshot snapshot = WidgetSnapshot.load(this);
        TextView truth = text(
                "ANDROID HOME WIDGETS ARE SNAPSHOTS, NOT A SECOND ALWAYS-RUNNING APP. "
                        + "THEY SHOW THE LAST ACQUIRED PROVIDER RECORD, SOURCE, CREDIBILITY "
                        + "AND AGE; TAP ANY WIDGET TO ENTER THE MATCHING LIVE PAGE.",
                AMBER, 9, true);
        truth.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        catalogList.addView(truth, marginParams(0, 3, 0, 10));

        LinearLayout summary = new LinearLayout(this);
        summary.setOrientation(LinearLayout.VERTICAL);
        summary.setPadding(dp(12), dp(10), dp(12), dp(10));
        summary.setBackground(panelBackground(PANEL_ALT, CYAN, 14));
        summary.addView(text("● CURRENT WIDGET SOURCE INDEX", CYAN, 9, true));
        summary.addView(text(snapshot.sourceHealthLine(), TEXT, 10, true),
                marginParams(0, 4, 0, 2));
        summary.addView(text("LAST ACQUIRED  "
                + WidgetSnapshot.ageText(snapshot.lastSourceUpdateMs,
                System.currentTimeMillis())
                + "  •  BACKGROUND IS NETWORK-AWARE AND ANDROID-BATCHED",
                MUTED, 8, false));
        Button refresh = actionButton("REFRESH WIDGET SNAPSHOTS NOW", CYAN);
        refresh.setOnClickListener(view -> {
            DuWidgetUpdater.updateAll(this);
            WidgetRefreshScheduler.scheduleImmediate(this);
            Toast.makeText(this,
                    "Widget refresh requested; Android will run network work when allowed",
                    Toast.LENGTH_LONG).show();
        });
        summary.addView(refresh, marginParams(0, 8, 0, 0));
        catalogList.addView(summary, marginParams(0, 0, 0, 12));

        for (DuWidgetContract.Kind widget : DuWidgetContract.Kind.values()) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(11), dp(12), dp(11));
            card.setBackground(panelBackground(PANEL_ALT,
                    widget == DuWidgetContract.Kind.ALERT ? RED
                            : widget == DuWidgetContract.Kind.COMMAND ? GREEN : CYAN, 14));
            card.addView(text("● " + widget.title + "  •  "
                    + widget.targetWidth + "×" + widget.targetHeight + " TARGET",
                    widget == DuWidgetContract.Kind.ALERT ? RED : CYAN, 9, true));
            card.addView(text(widget.description, TEXT, 10, false),
                    marginParams(0, 5, 0, 3));
            card.addView(text(widgetCapabilityLine(widget), MUTED, 8, false));
            Button pin = actionButton("PIN " + widget.title + " TO HOME", GREEN);
            pin.setOnClickListener(view -> requestPinWidget(widget));
            card.addView(pin, marginParams(0, 8, 0, 0));
            catalogList.addView(card, marginParams(0, 0, 0, 8));
        }

        addBriefHeading("PROFILE CONTROLS",
                "Each copy can use a different label, region, minimum severity and optional "
                        + "250–3,000 km timezone-derived distance lens. No GPS permission is used.");
        addBriefHeading("REFRESH CONTRACT",
                "App activity updates the shared cache immediately. Manual ↻ requests a bounded "
                        + "acquisition window. Periodic work targets about 15 minutes, but Android "
                        + "may defer it for battery, network or launcher policy.");
        addBriefHeading("COVERAGE CONTRACT",
                "Counts are provider-returned records, not every aircraft, vessel, camera or event. "
                        + "AISStream and Windy remain optional keyed sources; offline feeds remain visible.");
    }

    private String widgetCapabilityLine(DuWidgetContract.Kind widget) {
        switch (widget) {
            case ALERT:
                return "SEVERITY FILTER • RED PRIORITY STATE • EVENT AGE • SOURCE CREDIBILITY";
            case COUNTERS:
                return "AIR • SEA • EVENTS • ORBITS • MEDIA • WEATHER SOURCE STATE";
            case LOCAL:
                return "REGION/RADIUS PROFILE • LOCAL AIR/SEA COUNTS • NEWEST LOCAL SIGNAL";
            case WIRE:
                return "NEWEST-FIRST WIRE • PREVIOUS/NEXT • REPORTED/UNVERIFIED BADGE";
            case AIR_SEA:
                return "CALLSIGN/VESSEL • SPEED • ALTITUDE/DESTINATION • HEADING • SOURCE";
            case HAZARDS:
                return "EARTHQUAKE/FIRE/STORM • SIGMET • SPACE WEATHER • RADAR HEALTH";
            case MEDIA:
                return "PUBLIC CAM/RADIO/TV DIRECTORY • AVAILABILITY • SAFE APP DEEP LINK";
            case COMMAND:
            default:
                return "UTC+LOCAL CLOCKS • RESPONSIVE GLOBE SNAPSHOT • COUNTS • TOP SIGNALS";
        }
    }

    private void requestPinWidget(DuWidgetContract.Kind widget) {
        if (android.os.Build.VERSION.SDK_INT < 26) {
            Toast.makeText(this,
                    "Open your launcher's widget picker and choose " + widget.title,
                    Toast.LENGTH_LONG).show();
            return;
        }
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        if (!manager.isRequestPinAppWidgetSupported()) {
            Toast.makeText(this,
                    "This launcher does not support one-tap pinning. Long-press the home screen, "
                            + "choose Widgets, then DU World Monitor.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        ComponentName provider = DuWidgetContract.component(this, widget);
        boolean requested = manager.requestPinAppWidget(provider, null, null);
        Toast.makeText(this, requested
                        ? "Confirm " + widget.title + " in your launcher"
                        : "The launcher did not accept this pin request",
                Toast.LENGTH_LONG).show();
    }

    private void captureWidgetDeepLink(Intent intent) {
        if (intent == null) return;
        String requested = intent.getStringExtra(DuWidgetContract.EXTRA_OPEN_CATALOG);
        if (requested != null && !requested.trim().isEmpty()) {
            pendingCatalog = requested.trim().toUpperCase(Locale.ROOT);
        }
        String story = intent.getStringExtra("story_id");
        if (story != null) pendingNewsStoryId = story;
    }

    private void applyWidgetDeepLink() {
        if (pendingCatalog.isEmpty() || catalogPanel == null) return;
        String requested = pendingCatalog;
        pendingCatalog = "";
        if ("LOCAL_NEWS".equals(requested)) openCatalog("NEWS");
        else openCatalog(requested);
        if ("NEWS".equals(requested) && !pendingNewsStoryId.isEmpty()) {
            NewsItem item = new NewsStore(this).byId(pendingNewsStoryId);
            pendingNewsStoryId = "";
            if (item != null) f17BeforeDetail();showLocalNewsDetail(item);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        captureWidgetDeepLink(intent);
        applyWidgetDeepLink();
    }

    private void addSourceRow(String name, String state, int records,
                              String message, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(12), dp(9), dp(12), dp(9));
        row.setBackground(panelBackground(PANEL_ALT, color, 12));
        row.addView(text(String.format(Locale.US, "● %-20s  %s  •  %,d",
                name, state, records), color, 9, true));
        row.addView(text(message, Color.rgb(202, 215, 222), 8, false),
                marginParams(0, 3, 0, 0));
        Button share = compactButton("SHARE CARD");
        share.setTextColor(GREEN);
        share.setOnClickListener(view -> {
            Map<String, String> sourceFacts = new LinkedHashMap<>();
            sourceFacts.put("PROVIDER STATE", state);
            sourceFacts.put("RECORDS", String.format(Locale.US, "%,d", records));
            sourceFacts.put("COVERAGE NOTE", message);
            ShareCardRenderer.share(this, customShareCard(
                    name + " source status", message, state,
                    "PROVIDER HEALTH — NOT EVENT CONFIRMATION", "SOURCE REGISTRY",
                    "GLOBAL", state.contains("OFFLINE") ? 4 : 1,
                    name, System.currentTimeMillis(), Double.NaN, Double.NaN,
                    sourceFacts, color,
                    "Provider availability and returned coverage can change. This card reports the app's visible source state."));
        });
        row.addView(share, marginParams(0, 6, 0, 0));
        catalogList.addView(row, marginParams(0, 0, 0, 6));
    }

    private View buildBriefMetric(String label, int value, int color) {
        LinearLayout metric = new LinearLayout(this);
        metric.setOrientation(LinearLayout.VERTICAL);
        metric.setPadding(dp(12), dp(9), dp(12), dp(9));
        metric.setBackground(panelBackground(PANEL_ALT, color, 13));
        TextView number = text(String.format(Locale.US, "%,d", value), TEXT, 18, true);
        number.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        TextView caption = text("● " + label, color, 8, true);
        TextView share = text("SHARE CARD", GREEN, 7, true);
        metric.addView(number);
        metric.addView(caption);
        metric.addView(share);
        metric.setContentDescription(label + " " + value + ". Tap to share as a card.");
        metric.setOnClickListener(view -> {
            Map<String, String> metricFacts = new LinkedHashMap<>();
            metricFacts.put(label, String.format(Locale.US, "%,d", value));
            ShareCardRenderer.share(this, customShareCard(
                    label + " brief metric", String.format(Locale.US,
                    "The current intelligence brief shows %,d for %s.", value, label),
                    "BRIEF METRIC", "MIXED SOURCE STATES", "INTELLIGENCE BRIEF",
                    "GLOBAL", 1, APP_BRAND + " intelligence brief",
                    System.currentTimeMillis(), Double.NaN, Double.NaN,
                    metricFacts, color,
                    "This is a current page metric. Open individual items for source-level credibility."));
        });
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(112), dp(88));
        params.setMargins(0, 0, dp(7), 0);
        metric.setLayoutParams(params);
        return metric;
    }

    private void addBriefHeading(String title, String explanation) {
        TextView heading = text(title, TEXT, 11, true);
        heading.setLetterSpacing(0.04f);
        catalogList.addView(heading, marginParams(0, 10, 0, 2));
        catalogList.addView(text(explanation, MUTED, 8, false),
                marginParams(0, 0, 0, 7));
    }

    private String feedDisplayName(Signal.Layer layer) {
        switch (layer) {
            case FLIGHTS: return "AIRCRAFT";
            case SHIPS: return "VESSELS";
            case WEATHER: return "WEATHER";
            case AIRSPACE: return "AIRSPACE WEATHER";
            case NATURAL: return "NATURAL EVENTS";
            case NEWS: return "GLOBAL WIRE";
            case SATELLITES: return "ORBITAL OBJECTS";
            case SPACE_WEATHER: return "SPACE WEATHER";
            case INFRASTRUCTURE: return "REFERENCE";
            case MARKETS: return "MARKETS";
            case WEBCAMS: return "CAMERAS";
            case RADIO: return "RADIO";
            case TV: return "TELEVISION";
            case MEDIA: return "PUBLIC CALLS";
            default: return layer.name();
        }
    }

    private int feedStateColor(FeedStatus status) {
        if (status.state == FeedStatus.State.OFFLINE) return RED;
        if (status.state == FeedStatus.State.LOADING
                || status.state == FeedStatus.State.DELAYED
                || status.state == FeedStatus.State.CACHED
                || status.state == FeedStatus.State.KEY_REQUIRED) return AMBER;
        return GREEN;
    }

    private List<Signal> catalogSignals() {
        Signal.Layer layer = layerForCategory(catalogCategory);
        List<Signal> source = layerSignals.get(layer);
        List<Signal> result = new ArrayList<>();
        String query = catalogSearch == null ? ""
                : catalogSearch.getText().toString().trim().toLowerCase(Locale.ROOT);
        if (source == null) return result;
        for (Signal signal : source) {
            if ("BOATS".equals(catalogCategory) && !isBoat(signal)) continue;
            if ("SHIPS".equals(catalogCategory) && isBoat(signal)) continue;
            String infraCategory = signal.facts.get("CATEGORY");
            String infra = infraCategory == null ? "" : infraCategory.toUpperCase(Locale.ROOT);
            if ("AIRPORTS".equals(catalogCategory) && !infra.contains("AIRPORT")) continue;
            if ("RUNWAYS".equals(catalogCategory) && !infra.contains("RUNWAY")) continue;
            if ("PORTS".equals(catalogCategory)
                    && !infra.contains("PORT") && !infra.contains("MARITIME")) continue;
            if ("NEWS".equals(catalogCategory) && !"ALL".equals(catalogNewsType)
                    && !catalogNewsType.equals(signal.eventType)) continue;
            if (!query.isEmpty() && !catalogHaystack(signal).contains(query)) continue;
            result.add(signal);
        }
        if (layer != Signal.Layer.TV && layer != Signal.Layer.RADIO
                && layer != Signal.Layer.MEDIA && layer != Signal.Layer.WEBCAMS) {
            Collections.sort(result, (first, second) ->
                    compareNewestFirst(first.timestampMs, second.timestampMs));
        }
        return result;
    }

    private String catalogHaystack(Signal signal) {
        StringBuilder text = new StringBuilder()
                .append(signal.title).append(' ')
                .append(signal.summary).append(' ')
                .append(signal.source).append(' ')
                .append(signal.eventType).append(' ')
                .append(signal.region);
        for (Map.Entry<String, String> fact : signal.facts.entrySet()) {
            text.append(' ').append(fact.getKey()).append(' ').append(fact.getValue());
        }
        return text.toString().toLowerCase(Locale.ROOT);
    }

    private boolean isBoat(Signal signal) {
        String type = signal.facts.get("TYPE");
        if (type == null) return false;
        String value = type.toLowerCase(Locale.ROOT);
        return value.contains("fishing") || value.contains("towing")
                || value.contains("sailing") || value.contains("service")
                || value.contains("special craft") || value.contains("high-speed")
                || value.contains("pleasure") || value.contains("pilot")
                || value.contains("tug");
    }

    private View buildCatalogCard(Signal signal) {
        if (signal != null && signal.layer == Signal.Layer.NEWS) {
            String nid = signal.facts.get("NEWS ID");
            NewsItem local = nid == null ? null : new NewsStore(this).byId(nid);
            if (local != null) return buildLocalNewsCard(local);
        }
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(10), dp(12), dp(10));
        card.setBackground(panelBackground(PANEL_ALT, layerAccent(signal.layer), 14));

        LinearLayout headline = new LinearLayout(this);
        headline.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text(signal.title, TEXT, 11, true);
        headline.addView(title, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(headline);

        TextView state = text("● " + signalStateText(signal) + " • "
                + badgeText(signal), signalStateColor(signal), 8, true);
        card.addView(state, marginParams(0, 2, 0, 4));

        int included = 0;
        StringBuilder compactFacts = new StringBuilder();
        for (Map.Entry<String, String> fact : signal.facts.entrySet()) {
            if (included >= 4) break;
            if (compactFacts.length() > 0) compactFacts.append("   •   ");
            compactFacts.append(fact.getKey()).append(' ').append(fact.getValue());
            included++;
        }
        if (compactFacts.length() > 0) {
            TextView facts = text(compactFacts.toString(), Color.rgb(202, 215, 222), 9, false);
            facts.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
            card.addView(facts);
        }
        TextView source = text("SOURCE  " + signal.source + "   •   "
                + eventTime.format(new Date(signal.timestampMs)) + "   •   FEED "
                + sourceStateText(signal.layer) + " / AGE " + sourceAgeText(signal.layer),
                MUTED, 8, false);
        source.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        card.addView(source, marginParams(0, 5, 0, 0));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button action = compactButton(catalogActionLabel(signal));
        action.setTextColor(layerAccent(signal.layer));
        action.setOnClickListener(view -> activateCatalogSignal(signal));
        Button share = compactButton("SHARE CARD");
        share.setTextColor(GREEN);
        share.setContentDescription("Share " + signal.title + " as a DU World Monitor card");
        share.setOnClickListener(view -> shareSignal(signal));
        actions.addView(action, new LinearLayout.LayoutParams(0, dp(42), 1f));
        LinearLayout.LayoutParams shareParams = new LinearLayout.LayoutParams(0, dp(42), 1f);
        shareParams.setMargins(dp(7), 0, 0, 0);
        actions.addView(share, shareParams);
        card.addView(actions, marginParams(0, 8, 0, 0));
        card.setOnClickListener(view -> showDetail(signal));
        return card;
    }

    private String catalogActionLabel(Signal signal) {
        switch (signal.layer) {
            case FLIGHTS:
            case SHIPS:
                return mapView.isFollowing(signal.canonicalId) ? "FOLLOWING" : "TRACK";
            case RADIO:
                return signal.id.equals(playingRadioId) ? "STOP" : "PLAY";
            case TV: return "WATCH";
            case WEBCAMS: return "VIEW FRAME";
            case MEDIA:
                return signal.sourceUrl.startsWith("https://")
                        && "AUDIO".equalsIgnoreCase(signal.facts.get("MEDIA TYPE"))
                        ? signal.id.equals(playingRadioId) ? "STOP" : "PLAY"
                        : "REFERENCE";
            default: return "DETAIL";
        }
    }

    private void activateCatalogSignal(Signal signal) {
        selectedSignal = signal;
        selectedSourceUrl = signal.sourceUrl;
        if (signal.layer == Signal.Layer.FLIGHTS || signal.layer == Signal.Layer.SHIPS) {
            followTraffic(signal);
        } else if (signal.layer == Signal.Layer.RADIO) {
            toggleRadio(signal);
            rebuildCatalogPage();
        } else if (signal.layer == Signal.Layer.TV) {
            launchNativeMedia(signal, NativeMediaActivity.KIND_VIDEO);
        } else if (signal.layer == Signal.Layer.WEBCAMS) {
            if (signal.sourceUrl.isEmpty()) {
                Toast.makeText(this, "This camera has no current safe direct frame",
                        Toast.LENGTH_LONG).show();
            } else {
                launchNativeMedia(signal, NativeMediaActivity.KIND_IMAGE);
            }
        } else if (signal.layer == Signal.Layer.MEDIA
                && signal.sourceUrl.startsWith("https://")
                && "AUDIO".equalsIgnoreCase(signal.facts.get("MEDIA TYPE"))) {
            toggleRadio(signal);
            rebuildCatalogPage();
        } else {
            showDetail(signal);
        }
    }

    private void followTraffic(Signal signal) {
        if (signal == null || !signal.hasLocation()) {
            Toast.makeText(this, "This record has no current provider position",
                    Toast.LENGTH_LONG).show();
            return;
        }
        if (replayMode) {
            returnToLive();
            Toast.makeText(this,
                    "Returned to LIVE before following the latest provider fix",
                    Toast.LENGTH_SHORT).show();
        }
        catalogPanel.setVisibility(View.GONE);
        layersPanel.setVisibility(View.GONE);
        wirePanel.setVisibility(View.GONE);
        mapView.followSignal(signal);
        showDetail(signal);
        Toast.makeText(this,
                "Following provider fixes; short motion between fixes is estimated and labelled",
                Toast.LENGTH_LONG).show();
    }

    private void launchNativeMedia(Signal signal, String kind) {
        if (signal == null || signal.sourceUrl == null
                || !PublicMediaPolicy.isSafePublicHttpsUrl(signal.sourceUrl)) {
            Toast.makeText(this, "No safe direct media stream is available",
                    Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent(this, NativeMediaActivity.class);
        intent.putExtra(NativeMediaActivity.EXTRA_KIND, kind);
        intent.putExtra(NativeMediaActivity.EXTRA_TITLE, signal.title);
        intent.putExtra(NativeMediaActivity.EXTRA_SOURCE, signal.source);
        intent.putExtra(NativeMediaActivity.EXTRA_URL, signal.sourceUrl);
        intent.putExtra(NativeMediaActivity.EXTRA_REFERRER,
                signal.facts.get("PLAYBACK REFERRER"));
        intent.putExtra(NativeMediaActivity.EXTRA_USER_AGENT,
                signal.facts.get("PLAYBACK USER AGENT"));
        startActivity(intent);
    }

    private LinearLayout buildCompactLayerRail() {
        LinearLayout rail = new LinearLayout(this);
        rail.setOrientation(LinearLayout.VERTICAL);
        rail.setGravity(Gravity.CENTER_HORIZONTAL);
        rail.setPadding(dp(3), dp(5), dp(3), dp(5));
        rail.setBackground(panelBackground(Color.argb(205, 7, 12, 17), LINE, 16));

        Button all = compactButton("≡");
        all.setContentDescription("Open all layers and source controls");
        all.setOnClickListener(view -> togglePanel(layersPanel));
        rail.addView(all, new LinearLayout.LayoutParams(dp(44), dp(44)));

        addCompactLayerButton(rail, Signal.Layer.FLIGHTS, "✈", "Aircraft");
        addCompactLayerButton(rail, Signal.Layer.SHIPS, "◈", "Ships");
        addCompactLayerButton(rail, Signal.Layer.SATELLITES, "◇", "Satellites");
        addCompactLayerButton(rail, Signal.Layer.WEATHER, "☁", "Weather");
        addCompactLayerButton(rail, Signal.Layer.NATURAL, "!", "Natural events");
        addCompactLayerButton(rail, Signal.Layer.WEBCAMS, "▣", "Public cameras");

        Button combos = compactButton("⊕");
        combos.setContentDescription("Open multi-layer combinations");
        combos.setOnClickListener(view -> showLayerCombinations());
        LinearLayout.LayoutParams comboParams = new LinearLayout.LayoutParams(dp(44), dp(44));
        comboParams.setMargins(0, dp(5), 0, 0);
        rail.addView(combos, comboParams);
        return rail;
    }

    private void addCompactLayerButton(
            LinearLayout rail, Signal.Layer layer, String symbol, String label) {
        Button button = compactButton(symbol);
        button.setContentDescription(label + " layer. Tap to toggle.");
        button.setTextColor(Boolean.TRUE.equals(enabled.get(layer)) ? GREEN : MUTED);
        button.setOnClickListener(view -> {
            boolean next = !Boolean.TRUE.equals(enabled.get(layer));
            enabled.put(layer, next);
            button.setTextColor(next ? GREEN : MUTED);
            applyFilters();
            Toast.makeText(this, label + (next ? " ON" : " OFF"), Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(44), dp(44));
        params.setMargins(0, dp(3), 0, 0);
        rail.addView(button, params);
    }

    private void showLayerCombinations() {
        final String[] names = {
                "AIR + WEATHER",
                "SEA + WEATHER + INFRASTRUCTURE",
                "EVENTS + NEWS + CAMERAS",
                "SPACE + WEATHER",
                "ALL TRANSPORT",
                "RESTORE ALL"
        };
        new android.app.AlertDialog.Builder(this)
                .setTitle("LAYER COMBINATIONS")
                .setItems(names, (dialog, which) -> {
                    switch (which) {
                        case 0:
                            applyLayerCombination(Signal.Layer.FLIGHTS, Signal.Layer.WEATHER);
                            break;
                        case 1:
                            applyLayerCombination(Signal.Layer.SHIPS, Signal.Layer.WEATHER,
                                    Signal.Layer.INFRASTRUCTURE);
                            break;
                        case 2:
                            applyLayerCombination(Signal.Layer.NATURAL, Signal.Layer.NEWS,
                                    Signal.Layer.WEBCAMS);
                            break;
                        case 3:
                            applyLayerCombination(Signal.Layer.SATELLITES,
                                    Signal.Layer.SPACE_WEATHER, Signal.Layer.WEATHER);
                            break;
                        case 4:
                            applyLayerCombination(Signal.Layer.FLIGHTS, Signal.Layer.SHIPS,
                                    Signal.Layer.SATELLITES, Signal.Layer.AIRSPACE);
                            break;
                        default:
                            for (Signal.Layer layer : Signal.Layer.values()) enabled.put(layer, true);
                            applyFilters();
                            Toast.makeText(this, "ALL LAYERS RESTORED", Toast.LENGTH_SHORT).show();
                    }
                }).show();
    }

    private void applyLayerCombination(Signal.Layer... layers) {
        // A combination is an intentional view preset. It never merges provider records or
        // changes provenance; it only controls which independent layers are rendered together.
        for (Signal.Layer layer : Signal.Layer.values()) enabled.put(layer, false);
        StringBuilder active = new StringBuilder();
        for (Signal.Layer layer : layers) {
            enabled.put(layer, true);
            if (active.length() > 0) active.append(" + ");
            active.append(layer.name());
        }
        applyFilters();
        Toast.makeText(this, active.toString(), Toast.LENGTH_SHORT).show();
    }

    private LinearLayout buildLayersPanel() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(12), dp(12), dp(12));
        content.setBackground(panelBackground(Color.argb(242, 8, 12, 17), LINE, 18));
        content.addView(text("SOURCE CONTROL", TEXT, 11, true));
        content.addView(text("TOGGLE SOURCE / OPEN ITS NATIVE PAGE", MUTED, 8, false),
                marginParams(0, 2, 0, 10));

        addLayerToggle(content, Signal.Layer.FLIGHTS, "FLIGHTS");
        addLayerToggle(content, Signal.Layer.SHIPS, "SHIPS");
        addLayerToggle(content, Signal.Layer.WEATHER, "WEATHER RADAR");
        addLayerToggle(content, Signal.Layer.AIRSPACE, "AVIATION WARNINGS");
        addLayerToggle(content, Signal.Layer.NATURAL, "NATURAL EVENTS");
        addLayerToggle(content, Signal.Layer.NEWS, "BREAKING WIRE");
        addLayerToggle(content, Signal.Layer.SATELLITES, "CALCULATED ORBITS");
        addLayerToggle(content, Signal.Layer.SPACE_WEATHER, "SPACE WEATHER");
        addLayerToggle(content, Signal.Layer.INFRASTRUCTURE, "STRATEGIC REFERENCE");
        addLayerToggle(content, Signal.Layer.MARKETS, "MARKET RADAR");
        addLayerToggle(content, Signal.Layer.WEBCAMS, "WORLD PUBLIC CAMERAS");
        addLayerToggle(content, Signal.Layer.RADIO, "PUBLIC RADIO");
        addLayerToggle(content, Signal.Layer.TV, "PUBLIC TV STREAMS");
        addLayerToggle(content, Signal.Layer.MEDIA, "PUBLIC CALLS / FREQUENCIES");

        Button combinations = actionButton("LAYER COMBINATIONS", CYAN);
        combinations.setContentDescription("Choose a multi-layer operational view");
        combinations.setOnClickListener(view -> showLayerCombinations());
        content.addView(combinations, marginParams(0, 10, 0, 4));

        projectionButton = actionButton("DISPLAY • GLOBE", GREEN);
        projectionButton.setOnClickListener(view -> {
            boolean globe = !mapView.isGlobeMode();
            mapView.setGlobeMode(globe);
            projectionButton.setText(globe ? "DISPLAY • GLOBE" : "DISPLAY • SATELLITE MAP");
            Toast.makeText(this, globe
                            ? "Global source overview"
                            : "Detailed satellite tracker with place labels and radar",
                    Toast.LENGTH_SHORT).show();
        });
        content.addView(projectionButton, marginParams(0, 12, 0, 8));

        Button refresh = actionButton("REFRESH ALL NOW", CYAN);
        refresh.setOnClickListener(view -> {
            if (repository != null) repository.refreshNow();
            else Toast.makeText(this,
                    "Live sources are paused in recovery mode",
                    Toast.LENGTH_LONG).show();
        });
        content.addView(refresh, marginParams(0, 0, 0, 8));

        Button configure = actionButton("PROVIDER SETTINGS", AMBER);
        configure.setOnClickListener(view -> showSettings());
        content.addView(configure, marginParams(0, 0, 0, 14));

        Button brief = actionButton("OPEN INTELLIGENCE BRIEF", AMBER);
        brief.setOnClickListener(view -> openCatalog("BRIEF"));
        content.addView(brief, marginParams(0, 0, 0, 14));

        content.addView(text("SIGNAL LIGHTS", TEXT, 10, true));
        content.addView(text("Urgency/operations — not a truth rating", MUTED, 8, false));
        content.addView(legendLine("GREEN • ONLINE", GREEN,
                "Normal feed or non-priority public telemetry"));
        content.addView(legendLine("AMBER • DEVELOPING", AMBER,
                "Unverified/reported item, cached data or feed syncing"));
        content.addView(legendLine("RED • PRIORITY", RED,
                "Severity 4–5 signal or feed fault; still check credibility"));

        content.addView(text("CREDIBILITY DESK", TEXT, 10, true),
                marginParams(0, 14, 0, 0));
        content.addView(legendLine("RAW SIGNAL", CYAN, "Fast telemetry; not a reported story"));
        content.addView(legendLine("CALCULATED", Color.rgb(174, 139, 224),
                "Position derived from named public elements; not live telemetry"));
        content.addView(legendLine("UNVERIFIED", RED, "Developing headline; details not confirmed"));
        content.addView(legendLine("REPORTED", AMBER, "Published or independently corroborated"));
        content.addView(legendLine("CONFIRMED", GREEN, "Official structured source"));
        content.addView(legendLine("PUBLIC SOURCE", CYAN,
                "Open station or publisher directory; availability varies"));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(content);
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return wrapper;
    }

    private void addLayerToggle(LinearLayout parent, Signal.Layer layer, String label) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        CheckBox toggle = new CheckBox(this);
        toggle.setChecked(true);
        toggle.setText(label + "  •  LOADING");
        toggle.setTextColor(TEXT);
        toggle.setTextSize(9);
        toggle.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        toggle.setGravity(Gravity.CENTER_VERTICAL);
        toggle.setButtonTintList(new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{CYAN, MUTED}));
        toggle.setOnCheckedChangeListener((button, checked) -> {
            enabled.put(layer, checked);
            if (layer == Signal.Layer.WEATHER) mapView.setWeatherVisible(checked);
            applyFilters();
        });
        layerChecks.put(layer, toggle);
        row.addView(toggle, new LinearLayout.LayoutParams(0, dp(48), 1f));
        Button open = compactButton("OPEN");
        open.setContentDescription("Open " + label + " page");
        open.setOnClickListener(view -> openCatalog(categoryForLayer(layer)));
        row.addView(open, new LinearLayout.LayoutParams(dp(52), dp(40)));
        parent.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
    }

    private LinearLayout buildWirePanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(10), dp(10), dp(10));
        panel.setBackground(panelBackground(Color.argb(242, 8, 12, 17), LINE, 18));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = text("LATEST INTELLIGENCE / NEWEST FIRST", TEXT, 10, true);
        top.addView(heading, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button close = compactButton("×");
        close.setOnClickListener(view -> wirePanel.setVisibility(View.GONE));
        top.addView(close, new LinearLayout.LayoutParams(dp(42), dp(42)));
        panel.addView(top);

        HorizontalScrollView filters = new HorizontalScrollView(this);
        filters.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        typeButton = compactButton("TYPE: ALL");
        regionButton = compactButton("REGION: ALL");
        severityButton = compactButton("SEV: 1+");
        timeWindowButton = compactButton("TIME: 24H");
        typeButton.setOnClickListener(view -> {
            typeIndex = (typeIndex + 1) % TYPES.length;
            typeButton.setText("TYPE: " + TYPES[typeIndex]);
            applyFilters();
        });
        regionButton.setOnClickListener(view -> {
            regionIndex = (regionIndex + 1) % REGIONS.length;
            regionButton.setText("REGION: " + REGIONS[regionIndex]);
            applyFilters();
        });
        severityButton.setOnClickListener(view -> {
            minimumSeverity = minimumSeverity == 5 ? 1 : minimumSeverity + 1;
            severityButton.setText("SEV: " + minimumSeverity + "+");
            applyFilters();
        });
        timeWindowButton.setOnClickListener(view -> {
            timeWindowIndex = (timeWindowIndex + 1) % TIME_WINDOWS.length;
            timeWindowButton.setText("TIME: " + TIME_WINDOWS[timeWindowIndex]);
            applyFilters();
        });
        row.addView(typeButton, new LinearLayout.LayoutParams(dp(116), dp(44)));
        row.addView(regionButton, new LinearLayout.LayoutParams(dp(132), dp(44)));
        row.addView(severityButton, new LinearLayout.LayoutParams(dp(82), dp(44)));
        row.addView(timeWindowButton, new LinearLayout.LayoutParams(dp(92), dp(44)));
        filters.addView(row);
        panel.addView(filters, marginParams(0, 5, 0, 7));

        tickerContainer = new LinearLayout(this);
        tickerContainer.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(tickerContainer);
        panel.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return panel;
    }

    private LinearLayout buildDetailPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(12), dp(14), dp(12));
        panel.setBackground(panelBackground(Color.argb(246, 8, 12, 17), LINE, 18));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        detailBadge = text("RAW SIGNAL", CYAN, 10, true);
        top.addView(detailBadge, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        detailExpandButton = compactButton("MORE");
        detailExpandButton.setContentDescription("Expand or collapse object intelligence");
        detailExpandButton.setOnClickListener(view -> setDetailExpanded(!detailExpanded));
        top.addView(detailExpandButton, new LinearLayout.LayoutParams(dp(62), dp(42)));
        Button close = compactButton("×");
        close.setOnClickListener(view -> {
            panel.setVisibility(View.GONE);
            detailExpanded = false;
            if (mapView != null) mapView.clearSelection();
        });
        top.addView(close, new LinearLayout.LayoutParams(dp(42), dp(42)));
        panel.addView(top);

        detailTitle = text("", TEXT, 14, true);
        panel.addView(detailTitle, marginParams(0, 5, 0, 6));
        detailBody = text("", Color.rgb(210, 226, 233), 11, false);
        detailBody.setMaxLines(5);
        detailBody.setEllipsize(TextUtils.TruncateAt.END);
        detailScroll = new ScrollView(this);
        detailScroll.setFillViewport(false);
        detailScroll.addView(detailBody);
        panel.addView(detailScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        sourceButton = actionButton("OPEN SOURCE", CYAN);
        sourceButton.setOnClickListener(view -> handleSelectedSource());
        sourceButton.setOnLongClickListener(view -> {
            if(selectedSignal!=null&&selectedSignal.layer==Signal.Layer.FLIGHTS){
                if(mapView.isAircraftChaseMode())mapView.stopAircraftChase();else mapView.startAircraftChase(selectedSignal);
                Toast.makeText(this,mapView.aircraftChaseStatus(),Toast.LENGTH_LONG).show();showDetail(selectedSignal);return true;
            } return false;
        });
        detailWatchButton = actionButton("WATCH", AMBER);
        detailWatchButton.setOnLongClickListener(view -> {
            if(selectedSignal!=null&&selectedSignal.layer==Signal.Layer.SHIPS){
                String[] vesselTools={"TRAIL WINDOW","TIMELINE / REPLAY","CHASE CAMERA","ORBIT CAMERA","NEARBY VESSELS","WEATHER CONTEXT","TOGGLE WATCH","WATCHED VESSELS","AIS DIAGNOSTICS","PROVIDER HEALTH"};
                new AlertDialog.Builder(this).setTitle("VESSEL VIEW").setItems(vesselTools,(dialog,which)->{
                    if(which==0)showVesselTrailWindowPicker();
                    else if(which==1)showVesselReplayPicker(selectedSignal);
                    else if(which==2){
                        if(mapView.isVesselChaseMode())mapView.stopVesselChase();else mapView.startVesselChase(selectedSignal);
                        Toast.makeText(this,mapView.vesselChaseStatus(),Toast.LENGTH_LONG).show();showDetail(selectedSignal);
                    } else if(which==3) {
                        if(mapView.isVesselOrbitMode())mapView.stopVesselOrbit();else mapView.startVesselOrbit(selectedSignal);
                        Toast.makeText(this,mapView.vesselOrbitStatus(),Toast.LENGTH_LONG).show();showDetail(selectedSignal);
                    } else if(which==4)showNearbyVesselRadius(selectedSignal);
                    else if(which==5)showMaritimeWeatherContext(selectedSignal);
                    else if(which==6){
                        boolean watched=vesselWatchlist.toggle(selectedSignal);
                        mapView.setWatchedVesselKeys(vesselWatchlist.keys());
                        Toast.makeText(this,watched?"VESSEL WATCHED":"VESSEL WATCH REMOVED",Toast.LENGTH_SHORT).show();
                        showDetail(selectedSignal);
                    } else if(which==7)showWatchedVessels();
                    else if(which==8)showAisDiagnostics();
                    else showAisProviderHealth();
                }).show();return true;
            }
            if(selectedSignal!=null&&selectedSignal.layer==Signal.Layer.FLIGHTS){
                String[] aircraftTools={"TRAIL WINDOW","ORBIT CAMERA","NEARBY AIRCRAFT","AIRSPACE CONTEXT","WEATHER CONTEXT","WATCHED AIRCRAFT","TIMELINE / REPLAY"};
                new AlertDialog.Builder(this).setTitle("AIRCRAFT VIEW")
                        .setItems(aircraftTools,(dialog,which)->{
                            if(which==0)showAircraftTrailWindowPicker();
                            else if(which==1){
                                if(mapView.isAircraftOrbitMode())mapView.stopAircraftOrbit();
                                else mapView.startAircraftOrbit(selectedSignal);
                                Toast.makeText(this,mapView.aircraftOrbitStatus(),Toast.LENGTH_LONG).show();
                                showDetail(selectedSignal);
                            } else if(which==2) showNearbyAircraftRadius(selectedSignal);
                            else if(which==3) showAircraftAirspaceContext(selectedSignal);
                            else if(which==4) showAircraftWeatherContext(selectedSignal);
                            else if(which==5) showWatchedAircraft();
                            else showAircraftReplayPicker(selectedSignal);

                        }).show();
                return true;
            }
            return false;
        });
        detailWatchButton.setOnClickListener(view -> {
            if (selectedSignal == null) return;
            if(selectedSignal.layer==Signal.Layer.FLIGHTS && aircraftWatchlist.canPersist(selectedSignal)){
                boolean added=aircraftWatchlist.toggle(selectedSignal);
                Toast.makeText(this,added?"AIRCRAFT WATCHED":"AIRCRAFT WATCH REMOVED",Toast.LENGTH_SHORT).show();
                showDetail(selectedSignal);return;
            }
            boolean next = !canonicalWatchStore.watched(selectedSignal.canonicalId);
            canonicalWatchStore.setWatched(selectedSignal,next);
            detailWatchButton.setText(next ? "WATCHING" : "WATCH");
            showDetail(selectedSignal);
        });
        detailShareButton = actionButton("SHARE CARD", GREEN);
        detailShareButton.setContentDescription(
                "Share the selected information as a DU World Monitor card");
        detailShareButton.setOnClickListener(view -> {
            if (selectedSignal != null) shareSignal(selectedSignal);
        });
        detailShareButton.setOnLongClickListener(view -> {
            if(selectedSignal!=null&&selectedSignal.layer==Signal.Layer.FLIGHTS){
                if(mapView.isAircraftCockpitMode())mapView.stopAircraftCockpit();
                else mapView.startAircraftCockpit(selectedSignal);
                Toast.makeText(this,mapView.aircraftCockpitStatus(),Toast.LENGTH_LONG).show();
                showDetail(selectedSignal);return true;
            }
            return false;
        });
        actions.addView(sourceButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        LinearLayout.LayoutParams watchParams = new LinearLayout.LayoutParams(0, dp(48), 0.72f);
        watchParams.setMargins(dp(7),0,0,0);
        actions.addView(detailWatchButton, watchParams);
        LinearLayout.LayoutParams shareParams = new LinearLayout.LayoutParams(0, dp(48), 1f);
        shareParams.setMargins(dp(7), 0, 0, 0);
        actions.addView(detailShareButton, shareParams);
        panel.addView(actions, marginParams(0, 10, 0, 0));
        return panel;
    }

    private void setDetailExpanded(boolean expanded) {
        detailExpanded = expanded;
        if (detailExpandButton != null) detailExpandButton.setText(expanded ? "LESS" : "MORE");
        if (detailBody != null) {
            detailBody.setMaxLines(expanded ? Integer.MAX_VALUE : 5);
            detailBody.setEllipsize(expanded ? null : TextUtils.TruncateAt.END);
        }
        if (detailScroll != null) {
            ViewGroup.LayoutParams params = detailScroll.getLayoutParams();
            params.height = expanded ? dp(wideLayout ? 420 : 330)
                    : ViewGroup.LayoutParams.WRAP_CONTENT;
            detailScroll.setLayoutParams(params);
            if (!expanded) detailScroll.scrollTo(0, 0);
        }
        if (detailPanel != null) {
            detailPanel.requestLayout();
            detailPanel.bringToFront();
        }
    }

    @Override
    public void onLayer(Signal.Layer layer, List<Signal> signals, FeedStatus status) {
        runUiBoundary("MainActivity.onLayer." + (layer == null ? "unknown" : layer.name()),
                () -> onLayerUnsafe(layer, signals, status));
    }

    private void onLayerUnsafe(Signal.Layer layer, List<Signal> signals, FeedStatus status) {
        if (layer == null) return;
        List<Signal> safeSignals = CanonicalRecordDeduplicator.deduplicate(
                signals == null ? Collections.emptyList() : signals);
        airportRegistry.ingest(safeSignals);
        portRegistry.ingest(safeSignals);
        List<String> pipelineFailures = PipelineIntegrity.inspect(safeSignals);
        List<String> preservationFailures = IntelligencePreservationAudit.inspect(safeSignals);
        if (!preservationFailures.isEmpty()) {
            CrashLedger.recordRecovered(this, "FIX10.28.IntelligencePreservation",
                    new IllegalStateException(preservationFailures.get(0)));
        }
        if (!pipelineFailures.isEmpty()) {
            CrashLedger.recordRecovered(this, "PipelineIntegrity." + layer.name(),
                    new IllegalStateException(pipelineFailures.get(0)));
        }
        LastGoodRecordRegistry lastGood = lastGoodRecords.get(layer);
        if (lastGood == null) { lastGood = new LastGoodRecordRegistry(); lastGoodRecords.put(layer,lastGood); }
        if (!safeSignals.isEmpty()) lastGood.accept(safeSignals);
        // 1.2/20/1: keep the last good layer visible during a transient provider failure.
        // Empty LIVE/READY results remain honest empty results; only failure/delay states retain.
        if (safeSignals.isEmpty() && NetworkDegradationPolicy.retainLastGood(status)) {
            List<Signal> retained = lastGood.snapshot();
            if (!retained.isEmpty()) safeSignals = retained;
        }
        long freshnessNow = System.currentTimeMillis();
        for (Signal signal : safeSignals) {
            if (signal != null && signal.layer == Signal.Layer.SHIPS) {
                VesselCanonicalIdentity.Identity vesselIdentity=VesselCanonicalIdentity.from(signal);
                String resolvedVesselCanonical=vesselIdentityRegistry.resolve(signal);
                if(!vesselIdentity.key.isEmpty())signal.relationshipId=resolvedVesselCanonical;
                if(!vesselIdentity.mmsi.isEmpty())signal.facts.put("VESSEL MMSI",vesselIdentity.mmsi);
                if(!vesselIdentity.imo.isEmpty())signal.facts.put("VESSEL IMO",vesselIdentity.imo);
                if(!vesselIdentity.registration.isEmpty())signal.facts.put("VESSEL REGISTRATION",vesselIdentity.registration);
                if(!vesselIdentity.callsign.isEmpty())signal.facts.put("VESSEL CALLSIGN",vesselIdentity.callsign);
                if(!vesselIdentity.name.isEmpty())signal.facts.put("VESSEL NAME",vesselIdentity.name);
                signal.facts.put("VESSEL ID BASIS",vesselIdentity.basis.name());
                if(vesselWatchlist!=null)signal.facts.put("VESSEL WATCH",vesselWatchlist.isWatched(signal)?"WATCHED":"NOT WATCHED");
                VesselTelemetry vesselTelemetry=VesselTelemetry.from(signal);
                if(vesselTelemetry!=null){
                    if(vesselTelemetry.hasSog())signal.facts.put("VESSEL SOG M/S",
                            String.format(Locale.US,"%.2f",vesselTelemetry.sogMps));
                    if(vesselTelemetry.hasCog())signal.facts.put("VESSEL COG DEG",
                            String.format(Locale.US,"%.1f",VesselTelemetry.normalize(vesselTelemetry.cogDegrees)));
                    if(vesselTelemetry.hasHeading())signal.facts.put("VESSEL HEADING DEG",
                            String.format(Locale.US,"%.1f",VesselTelemetry.normalize(vesselTelemetry.headingDegrees)));
                    if(vesselTelemetry.hasRot())signal.facts.put("VESSEL ROT DEG/MIN",
                            String.format(Locale.US,"%.2f",vesselTelemetry.rateOfTurnDegPerMin));
                    if(vesselTelemetry.hasDraught())signal.facts.put("VESSEL DRAUGHT M",
                            String.format(Locale.US,"%.2f",vesselTelemetry.draughtM));
                    if(!vesselTelemetry.vesselType.isEmpty())signal.facts.put("VESSEL TYPE",vesselTelemetry.vesselType);
                    if(!vesselTelemetry.navigationStatus.isEmpty())signal.facts.put("AIS NAVIGATION STATUS",vesselTelemetry.navigationStatus);
                    if(!vesselTelemetry.destination.isEmpty())signal.facts.put("AIS DESTINATION",vesselTelemetry.destination);
                    if(!vesselTelemetry.eta.isEmpty())signal.facts.put("AIS ETA",vesselTelemetry.eta);
                    if(vesselTelemetry.providerTimestampMs>0L)signal.facts.put("VESSEL PROVIDER TIME MS",
                            String.valueOf(vesselTelemetry.providerTimestampMs));
                    signal.facts.put("VESSEL MOTION",vesselTelemetry.compactMotion());
                    VesselOperationalState vesselOperational=VesselOperationalState.from(signal);
                    signal.facts.put("VESSEL OPERATIONAL STATE",vesselOperational.state.name());
                    signal.facts.put("VESSEL OPERATIONAL DISCLOSURE",vesselOperational.disclosure());
                    VesselPortProximity vesselPort=VesselPortProximity.nearest(signal,portRegistry.allSignals());
                    if(vesselPort!=null){
                        signal.facts.put("NEAREST KNOWN PORT",vesselPort.port.name);
                        signal.facts.put("NEAREST PORT DISTANCE KM",String.format(Locale.US,"%.1f",vesselPort.distanceKm));
                        signal.facts.put("NEAREST PORT BEARING DEG",String.format(Locale.US,"%03.0f",vesselPort.bearingDeg));
                        signal.facts.put("PORT PROXIMITY DISCLOSURE",vesselPort.disclosure());
                    }
                    List<VesselChangeDetector.Change> vesselChanges=vesselChangeRegistry.update(signal,vesselWatchlist,vesselPort);
                    if(!vesselChanges.isEmpty()){
                        StringBuilder changeText=new StringBuilder();
                        for(VesselChangeDetector.Change c:vesselChanges){if(changeText.length()>0)changeText.append(" | ");changeText.append(c.label());}
                        signal.facts.put("VESSEL MEANINGFUL CHANGES",changeText.toString());
                    }
                    VesselDestinationIntelligence vesselDestination=VesselDestinationIntelligence.from(signal);
                    signal.facts.put("AIS DESTINATION DISCLOSURE",vesselDestination.destinationDisclosure());
                    signal.facts.put("AIS ETA DISCLOSURE",vesselDestination.etaDisclosure());
                    signal.facts.put("AIS VOYAGE EVIDENCE",vesselDestination.evidence.name());
                    VesselNavigationStatus vesselNav=VesselNavigationStatus.from(signal);
                    signal.facts.put("AIS NAV STATUS NORMALIZED",vesselNav.state.name());
                    signal.facts.put("AIS NAV STATUS DISCLOSURE",vesselNav.disclosure());
                    VesselTurnIntelligence vesselTurn=VesselTurnIntelligence.from(signal);
                    signal.facts.put("VESSEL TRAIL EVIDENCE","OBSERVED AIS FIXES ONLY");
                    signal.facts.put("VESSEL TURN STATE",vesselTurn.state.name());
                    signal.facts.put("VESSEL TURN DISCLOSURE",vesselTurn.disclosure());
                    if(vesselTurn.known())signal.facts.put("VESSEL ROT NORMALIZED DEG/MIN",
                            String.format(Locale.US,"%+.2f",vesselTurn.rotDegPerMin));
                    VesselSpeedIntelligence vesselSpeed=VesselSpeedIntelligence.from(signal);
                    signal.facts.put("VESSEL SPEED STATE",vesselSpeed.state.name());
                    signal.facts.put("VESSEL SPEED DISCLOSURE",vesselSpeed.disclosure());
                    if(vesselSpeed.known()){
                        signal.facts.put("VESSEL SPEED KNOTS",String.format(Locale.US,"%.1f",vesselSpeed.knots));
                        signal.facts.put("VESSEL SPEED KM/H",String.format(Locale.US,"%.1f",vesselSpeed.kmh));
                    }
                    VesselOrientation vesselOrientation=VesselOrientation.from(signal);
                    signal.facts.put("VESSEL ORIENTATION BASIS",vesselOrientation.basis.name());
                    if(vesselOrientation.known())signal.facts.put("VESSEL ORIENTATION DEG",String.format(Locale.US,"%.1f",vesselOrientation.degrees));
                    if(vesselOrientation.hasHeadingCogDifference())signal.facts.put("VESSEL HEADING-COG DELTA DEG",String.format(Locale.US,"%+.1f",vesselOrientation.headingCogDifference()));
                    signal.facts.put("VESSEL MOVEMENT ENGINE","AIS SOG/COG • SMOOTH DISPLAY • OBSERVATIONS IMMUTABLE");
                    signal.facts.put("VESSEL PREDICTION LIMIT MS",String.valueOf(vesselTelemetry.hasSog()?VesselMovementValidation.predictionLimitMs(vesselTelemetry.sogMps):0L));
                }
                MaritimeReliabilityTruthAudit.Result maritimeAudit=MaritimeReliabilityTruthAudit.audit(signal);
                signal.facts.put("MARITIME TRUTH AUDIT",maritimeAudit.summary());
                signal.facts.put("MARITIME RELEASE",Fix12MaritimeRelease.RELEASE);
                signal.facts.put("FIX13 AIS INGESTION","MULTI-PROVIDER FOUNDATION ACTIVE");
                signal.facts.put("FIX13 REGISTERED AIS PROVIDERS",String.valueOf(aisMultiProviderIngestor.providerCount()));
                signal.facts.put("FIX13 PROVIDER ADAPTER FRAMEWORK","ACTIVE • CONFIGURABLE FIELD MAP");
                signal.facts.put("FIX13 AIS SCHEMA NORMALIZATION","ACTIVE • TYPED PROVIDER-NEUTRAL RECORD");
                signal.facts.put("FIX13 AIS TIMESTAMP NORMALIZATION","PROVIDER / RECEIVE / PROCESSING CLOCKS SEPARATE");
                signal.facts.put("FIX13 AIS COORDINATE VALIDATION","STRICT BOUNDS • SENTINEL REJECTION • 45m/s JUMP GATE");
                signal.facts.put("FIX13 MMSI VALIDATION","9-DIGIT • MID STRUCTURE • SENTINEL/DEVICE QUARANTINE");
                signal.facts.put("FIX13 IMO VALIDATION","7-DIGIT • IMO CHECK DIGIT • INVALID ID QUARANTINE");
                signal.facts.put("FIX13 AIS DUPLICATE FILTER","PROVIDER-SCOPED RECORD-ID + CONTENT FINGERPRINT");
                signal.facts.put("FIX13 AIS ORDERING","LATE FIXES→HISTORY • NEVER ROLLBACK LIVE STATE");
                signal.facts.put("FIX13 PROVIDER PRIORITY","DETERMINISTIC RANK • LOWER-PRIORITY EVIDENCE RETAINED");
                signal.facts.put("FIX13 CROSS-PROVIDER FUSION","FIELD-LEVEL PROVENANCE • ALL PROVIDER EVIDENCE RETAINED");
                signal.facts.put("FIX13 POSITION CONFLICT","CROSS-PROVIDER • ≤120s COMPARISON • >2km MATERIAL • NOT AVERAGED");
                signal.facts.put("FIX13 SPEED CONFLICT","CROSS-PROVIDER SOG • ≤120s • >3m/s MATERIAL • ORIGINALS RETAINED");
                signal.facts.put("FIX13 HEADING/COG CONFLICT","CIRCULAR ANGLE • ≤120s • >25° MATERIAL • ORIGINALS RETAINED");
                signal.facts.put("FIX13 SOURCE CONFIDENCE","TRANSPARENT EVIDENCE QUALITY • NOT CERTAINTY");
                signal.facts.put("FIX13 STALE SOURCE DETECTION","PER-PROVIDER FRESHNESS • STALE SOURCE DOES NOT POISON HEALTHY SOURCE");
                signal.facts.put("FIX13 SOURCE RECOVERY","STALE/SILENT→HEALTHY TRACKED AS PROVIDER EVENT • NOT NEW VESSEL");
                signal.facts.put("FIX13 INGESTION LATENCY","SOURCE→RECEIVE + RECEIVE→PROCESS MEASURED SEPARATELY");
                signal.facts.put("FIX13 MESSAGE RATE","5-MIN ROLLING PER-PROVIDER ACCEPT/DUPLICATE/REJECT/NORMALIZED THROUGHPUT");
                signal.facts.put("FIX13 PROVIDER HEALTH","FRESHNESS + LATENCY + THROUGHPUT + RECOVERY • OPERATIONAL, NOT TRUTH");
                signal.facts.put("FIX13 MALFORMED QUARANTINE","BAD RECORDS ISOLATED • RAW PROVENANCE + REASON RETAINED");
                signal.facts.put("FIX13 PROVIDER FAILURE ISOLATION","PER-PROVIDER CIRCUIT • 3 FAILURES → 60s ISOLATION • HEALTHY PROVIDERS CONTINUE");
                signal.facts.put("FIX13 RAW AIS EVIDENCE","PAYLOAD PRESERVED BEFORE PARSE • SHA-256 TRACE • BOUNDED STORE");
                signal.facts.put("FIX13 NORMALIZED AIS EVIDENCE","POST-NORMALIZATION / PRE-FUSION IMMUTABLE SNAPSHOT • RAW SHA TRACE");
                signal.facts.put("FIX13 AIS PROVENANCE","RAW SHA → PROVIDER RECORD → NORMALIZED EVIDENCE → FUSED FIELD → DISPLAY");
                signal.facts.put("FIX13 AIS DIAGNOSTICS UI","PROVIDER HEALTH/LATENCY/RATE/CIRCUIT + QUARANTINE/EVIDENCE COUNTS");
                signal.facts.put("FIX13 PROVIDER HEALTH UI","PER-PROVIDER FRESHNESS/RECOVERY/RATES/LATENCY/CIRCUIT/ERROR DETAILS");
                signal.facts.put("FIX13 LOAD/PERFORMANCE","SUSTAINED MULTI-PROVIDER ACCEPTANCE HARNESS • BOUNDED-STATE CHECK");
                signal.facts.put("FIX13 MULTI-PROVIDER TRUTH AUDIT","RAW/NORMALIZED/FUSION/CONFLICT/CONFIDENCE/PROVENANCE SEPARATION");
                signal.facts.put("FIX13 RELEASE",Fix13MultiProviderRelease.RELEASE);
                signal.facts.put("FIX13 RELEASE CAPABILITIES",String.valueOf(Fix13MultiProviderRelease.capabilities().size()));
                signal.facts.put("FIX14 PORT REGISTRY","SOURCE-BACKED CANONICAL PORT REGISTRY ACTIVE");
                signal.facts.put("FIX14 REGISTERED PORTS",String.valueOf(portRegistry.size()));
                signal.facts.put("FIX14 UN/LOCODE","SOURCE-PROVIDED STRUCTURAL VALIDATION + ONE-TO-ONE INDEX");
                signal.facts.put("FIX14 INDEXED UN/LOCODES",String.valueOf(portRegistry.unLocodeCount()));
                signal.facts.put("FIX14 PORT COORDINATES","SOURCE-SPECIFIC EVIDENCE • ACCURACY RETAINED • NO AVERAGING");
                signal.facts.put("FIX14 PORT COORDINATE EVIDENCE",String.valueOf(portRegistry.coordinateEvidenceCount()));
                signal.facts.put("FIX14 PORT GEOGRAPHY","SOURCE-BACKED COUNTRY/REGION METADATA • CONFLICTS EXPOSED • NO COORDINATE INFERENCE");
                signal.facts.put("FIX14 PORT GEOGRAPHY EVIDENCE",String.valueOf(portRegistry.geographyEvidenceCount()));
                signal.facts.put("FIX14 HARBOUR BOUNDARIES","SOURCE-BACKED POLYGONS • POINT-IN-HARBOUR • MULTI-SOURCE CONFLICTS");
                signal.facts.put("FIX14 HARBOUR BOUNDARY COUNT",String.valueOf(portRegistry.harbourBoundaryCount()));
                signal.facts.put("FIX14 PORT TERMINALS","SOURCE-BACKED TERMINALS • STRICT PARENT-PORT RELATIONSHIP • PROVENANCE RETAINED");
                signal.facts.put("FIX14 TERMINAL COUNT",String.valueOf(portRegistry.terminalCount()));
                signal.facts.put("FIX14 ANCHORAGES","SOURCE-BACKED POINT/POLYGON • PARENT PORT • POINT-IN-ANCHORAGE");
                signal.facts.put("FIX14 ANCHORAGE COUNT",String.valueOf(portRegistry.anchorageCount()));
                signal.facts.put("FIX14 BERTHS","SOURCE-BACKED BERTHS • PORT/OPTIONAL TERMINAL PARENTAGE • DIMENSIONS ONLY WHEN SUPPLIED");
                signal.facts.put("FIX14 BERTH COUNT",String.valueOf(portRegistry.berthCount()));
                signal.facts.put("FIX14 PORT APPROACHES","SOURCE-BACKED ROUTE/CORRIDOR • ≥2 WAYPOINTS • NO STRAIGHT-LINE INFERENCE");
                signal.facts.put("FIX14 APPROACH COUNT",String.valueOf(portRegistry.approachCount()));
                signal.facts.put("FIX14 PORT ENTRANCES","SOURCE-BACKED ENTRANCE POINT/GATE • OPTIONAL WIDTH • NO APPROACH-ENDPOINT INFERENCE");
                signal.facts.put("FIX14 ENTRANCE COUNT",String.valueOf(portRegistry.entranceCount()));
                signal.facts.put("FIX14 NAVIGATION CHANNELS","SOURCE-BACKED CENTERLINE • OPTIONAL WIDTH/DEPTH • NOT A NAVIGATION ASSURANCE");
                signal.facts.put("FIX14 NAVIGATION CHANNEL COUNT",String.valueOf(portRegistry.navigationChannelCount()));
                signal.facts.put("FIX14 PORT RESTRICTIONS","SOURCE-BACKED DESCRIPTIVE RESTRICTIONS • EFFECTIVE PERIODS/AREAS • NOT NAVIGATION CLEARANCE");
                signal.facts.put("FIX14 RESTRICTION COUNT",String.valueOf(portRegistry.restrictionCount()));
                signal.facts.put("FIX14 DRAUGHT CONTEXT","SOURCE DEPTH/DRAUGHT/UKC + DATUM/TIME • CONTEXT ONLY • NOT SAFE DRAUGHT");
                signal.facts.put("FIX14 DRAUGHT CONTEXT COUNT",String.valueOf(portRegistry.draughtContextCount()));
                signal.facts.put("FIX14 PORT WEATHER","SOURCE-ATTRIBUTED OBSERVATION/FORECAST • SEPARATE KINDS • NO NAVIGATION JUDGMENT");
                signal.facts.put("FIX14 PORT WEATHER COUNT",String.valueOf(portRegistry.weatherContextCount()));
                signal.facts.put("FIX14 TIDE CONTEXT","SOURCE OBSERVATION/PREDICTION • STATION/DATUM/EVENT TIME • NO SAFE-PASSAGE CALCULATION");
                signal.facts.put("FIX14 TIDE CONTEXT COUNT",String.valueOf(portRegistry.tideContextCount()));
                signal.facts.put("FIX14 NEARBY VESSELS","FIX13 FUSED AIS + FIX14 PORT/HARBOUR/ANCHORAGE GEOMETRY • PROXIMITY ≠ PORT CALL");
                signal.facts.put("FIX14 APPROACHING VESSELS","TWO OBSERVED AIS FIXES → DISTANCE TREND/RADIAL RATE • NO ETA/ARRIVAL CLAIM");
                signal.facts.put("FIX14 DEPARTING VESSELS","PRIOR HARBOUR/ANCHORAGE PRESENCE + OBSERVED EXIT/RECEDING TREND • NOT CONFIRMED VOYAGE DEPARTURE");
                signal.facts.put("FIX14 ANCHORED VESSELS","ANCHORAGE POLYGON + LOW SOG + LIMITED DISPLACEMENT • SLOW ALONE ≠ ANCHORED");
                signal.facts.put("FIX14 LIVE PORT COUNTERS","UNIQUE VESSEL PRESENCE BUCKETS + SEPARATE APPROACH/DEPARTURE/ANCHORED EVIDENCE COUNTS");
                signal.facts.put("FIX14 HISTORICAL PORT TRAFFIC","BOUNDED OBSERVED COUNTER SNAPSHOTS • CHRONOLOGICAL ONLY • NO RECONSTRUCTED HISTORY");
                signal.facts.put("FIX14 DESTINATION MATCHING","AIS REPORTED TEXT → LOCODE/NAME CANDIDATE + METHOD/CONFIDENCE/AMBIGUITY • NOT CONFIRMED INTENT");
                signal.facts.put("FIX14 GLOBAL PORT SEARCH","PORT/LOCODE/COUNTRY/REGION/TERMINAL/ANCHORAGE/BERTH/APPROACH/ENTRANCE/CHANNEL INDEX");
                signal.facts.put("FIX14 PORT FOLLOW","CANONICAL PORT FOLLOW/UNFOLLOW STATE • USER SELECTION ONLY • NO SYNTHETIC OBSERVATIONS");
                signal.facts.put("FIX14 FOLLOWED PORT COUNT",String.valueOf(portRegistry.followedPortCount()));
                signal.facts.put("FIX14 PORT OVERVIEW CAMERA","CANONICAL PORT POINT → DETERMINISTIC GLOBE CAMERA TARGET • DATA REMAINS UNCHANGED");
                signal.facts.put("FIX14 PORT INTELLIGENCE SHEET","READ-ONLY SOURCE-AWARE ASSEMBLY OF IDENTITY/INFRASTRUCTURE/CONTEXT/TRAFFIC");
                signal.facts.put("FIX14 PORT SHARE CARDS","INTELLIGENCE-SHEET SNAPSHOT • PRESENT EVIDENCE ONLY • MISSING VALUES OMITTED");
                signal.facts.put("FIX14 PORT LOAD ACCEPTANCE","10K PORT / 250K SYNTHETIC BOOKKEEPING ACCEPTANCE • 720 HISTORY BOUND");
                signal.facts.put("FIX14 TRUTH/PROVENANCE AUDIT","22 CONTRACTS • SOURCE/EVIDENCE/INTERPRETATION SEPARATION");
                signal.facts.put("FIX14 FINAL RELEASE",Fix14GlobalPortRelease.RELEASE+" • "+Fix14GlobalPortRelease.CAPABILITY_COUNT+" CAPABILITIES • SOURCE-AWARE");

                signal.facts.put("FIX13 CANONICAL EXTRACTION FIELD COUNT",String.valueOf(AisCanonicalFields.SUPPORTED.size()));
                signal.facts.put("MARITIME RELEASE CAPABILITIES",String.valueOf(Fix12MaritimeRelease.capabilities().size()));
                if(!maritimeAudit.pass)signal.facts.put("MARITIME TRUTH AUDIT FAILURES",String.join(" | ",maritimeAudit.failures));
            }
            if (signal != null && signal.layer == Signal.Layer.FLIGHTS) {
                AircraftCanonicalIdentity.Identity aircraftIdentity = AircraftCanonicalIdentity.from(signal);
                String resolvedAircraftCanonical = aircraftIdentityRegistry.resolve(signal);
                if (!aircraftIdentity.key.isEmpty()) signal.relationshipId = resolvedAircraftCanonical;
                if (!aircraftIdentity.icao24.isEmpty()) signal.facts.put("AIRCRAFT ICAO24", aircraftIdentity.icao24);
                if (!aircraftIdentity.registration.isEmpty()) signal.facts.put("AIRCRAFT REGISTRATION", aircraftIdentity.registration);
                signal.facts.put("AIRCRAFT ID BASIS", aircraftIdentity.basis.name());
                AircraftTelemetry telemetry = AircraftTelemetry.from(signal);
                if (telemetry != null) {
                    signal.facts.put("AIRCRAFT ALTITUDE", telemetry.altitudeDisclosure());
                    if (telemetry.hasSpeed()) signal.facts.put("GROUND SPEED M/S",
                            String.format(Locale.US, "%.1f", telemetry.groundSpeedMps));
                    if (telemetry.hasTrack()) signal.facts.put("TRACK DEG",
                            String.format(Locale.US, "%.1f", telemetry.trackDegrees));
                    if (telemetry.hasHeading()) signal.facts.put("HEADING DEG",
                            String.format(Locale.US, "%.1f", telemetry.headingDegrees));
                    if (telemetry.hasVerticalRate()) signal.facts.put("VERTICAL RATE M/S",
                            String.format(Locale.US, "%.1f", telemetry.verticalRateMps));
                    if (telemetry.onGround != null) signal.facts.put("ON GROUND",
                            telemetry.onGround ? "TRUE" : "FALSE");
                    if (!telemetry.squawk.isEmpty()) signal.facts.put("SQUAWK", telemetry.squawk);
                    if (!telemetry.aircraftType.isEmpty()) signal.facts.put("AIRCRAFT TYPE", telemetry.aircraftType);
                    if (telemetry.providerTimestampMs > 0L) signal.facts.put("AIRCRAFT PROVIDER TIME MS",
                            String.valueOf(telemetry.providerTimestampMs));
                    AircraftOrientation orientation = AircraftOrientation.from(signal);
                    signal.facts.put("ORIENTATION BASIS", orientation.basis.name());
                    if (orientation.known()) signal.facts.put("ORIENTATION DEG",
                            String.format(Locale.US, "%.1f", orientation.degrees));
                    AircraftAltitudeIntelligence altitude = AircraftAltitudeIntelligence.from(signal);
                    signal.facts.put("ALTITUDE STATE", altitude.state.name());
                    signal.facts.put("ALTITUDE DETAIL", altitude.dualAltitude());
                    signal.facts.put("ALTITUDE SUMMARY", altitude.compact());
                    signal.facts.put("ALTITUDE BASIS", altitude.preferredBasis);
                    String aircraftHistoryKey = aircraftIdentity.key.isEmpty()
                            ? signal.canonicalId : aircraftIdentity.key;
                    AircraftVerticalHistory.Sample previousVertical =
                            aircraftVerticalHistory.previous(aircraftHistoryKey);
                    AircraftVerticalMovement verticalMovement = AircraftVerticalMovement.from(
                            signal,
                            previousVertical == null ? null : previousVertical.altitudeM,
                            previousVertical == null ? null : previousVertical.timeMs);
                    signal.facts.put("VERTICAL MOVEMENT", verticalMovement.state.name());
                    signal.facts.put("VERTICAL MOVEMENT BASIS", verticalMovement.basis.name());
                    signal.facts.put("VERTICAL MOVEMENT DETAIL", verticalMovement.disclosure());
                    AircraftFlightPhase flightPhase = AircraftFlightPhase.from(signal);
                    signal.facts.put("FLIGHT PHASE", flightPhase.phase.name());
                    signal.facts.put("FLIGHT PHASE BASIS", flightPhase.basis);
                    signal.facts.put("FLIGHT PHASE DISCLOSURE", flightPhase.disclosure());
                    AircraftRouteIntelligence route = AircraftRouteIntelligence.from(signal);
                    signal.facts.put("ROUTE BASIS", route.basis.name());
                    signal.facts.put("ROUTE DISPLAY", route.compact());
                    if (route.known()) {
                        signal.facts.put("ROUTE ORIGIN", route.origin);
                        signal.facts.put("ROUTE DESTINATION", route.destination);
                    }
                    AircraftAirportProximity airportProximity =
                            AircraftAirportProximity.nearest(signal, airportRegistry.allSignals());
                    if (airportProximity != null) {
                        signal.facts.put("NEAREST AIRPORT", airportProximity.airport.code());
                        signal.facts.put("NEAREST AIRPORT DISTANCE KM",
                                String.format(Locale.US, "%.1f", airportProximity.distanceKm));
                        signal.facts.put("NEAREST AIRPORT BEARING DEG",
                                String.format(Locale.US, "%.1f", airportProximity.bearingDegrees));
                        signal.facts.put("NEAREST AIRPORT RELATION", airportProximity.routeRelation);
                    }
                    List<AircraftChangeDetector.Change> aircraftChanges=aircraftChangeRegistry.observe(signal);
                    if(!aircraftChanges.isEmpty()){
                        StringBuilder changes=new StringBuilder();
                        for(AircraftChangeDetector.Change change:aircraftChanges){
                            if(changes.length()>0)changes.append(" • ");
                            changes.append(change.name().replace('_',' '));
                        }
                        signal.facts.put("MEANINGFUL CHANGES",changes.toString());
                    }
                    if (!Double.isNaN(altitude.preferredM) && telemetry.providerTimestampMs > 0L) {
                        aircraftVerticalHistory.observe(
                                aircraftHistoryKey, altitude.preferredM, telemetry.providerTimestampMs);
                    }
                }
            }
            if (signal != null) signal.freshness =
                    ObjectFreshness.evaluate(signal.timestampChain, status, freshnessNow);
            if(signal!=null&&signal.layer==Signal.Layer.FLIGHTS){
                String aircraftAudit=AircraftReliabilityTruthAudit.summary(signal);
                signal.facts.put("AIRCRAFT RELIABILITY AUDIT",aircraftAudit);
                if(!"AIRCRAFT TRUTH CHAIN OK".equals(aircraftAudit))
                    CrashLedger.recordRecovered(this,"FIX11.30.29.AircraftTruthAudit",
                            new IllegalStateException(aircraftAudit));
            }
        }
        LiveOperationsEngine.LayerSnapshot operational = operationsEngine.accept(
                layer, safeSignals, status, freshnessNow);
        FeedStatus previous = feedStatuses.get(layer);
        layerSignals.put(layer, operational.signals);
        feedStatuses.put(layer, operational.status);
        relationshipRegistry.accept(operational.signals);
        canonicalTimelineRegistry.accept(operational.signals);
        liveChangeRegistry.accept(layer, operational.signals, freshnessNow);
        geographicActivityZones = GeographicActivityZones.detect(layerSignals.values());
        incidentCandidates = IncidentFormationEngine.form(layerSignals.values());
        if (selectedSignal != null && detailPanel != null
                && detailPanel.getVisibility() == View.VISIBLE
                && mapView != null && mapView.isFollowing(selectedSignal.canonicalId)) {
            Signal trackedUpdate = findCanonical(operational.signals, selectedSignal.canonicalId);
            if (trackedUpdate != null) refreshTrackedAircraftSheet(trackedUpdate);
        }
        if (TemporalReplayEngine.isTemporalLayer(layer)) {
            replayEngine.capture(layerSignals, System.currentTimeMillis());
        }
        movementAnalyzer.ingest(layer, operational.signals, System.currentTimeMillis());
        ingestAcquisitions(operational.newAcquisitions, operational.status);
        if (sourceMatrixView != null) sourceMatrixView.update(layer, operational);
        if (mapView != null) mapView.setLayerActivity(layer, operational.status);
        updateLayerLabel(layer, operational.status);
        updateCounters();
        updateFeedPulse();
        updateSignalBeacons();
        pulseFeedTransition(previous, operational.status);
        applyFilters();
        updateAnalysisRibbon();
        if (catalogPanel != null && catalogPanel.getVisibility() == View.VISIBLE
                && ("BRIEF".equals(catalogCategory)
                || "FUSION".equals(catalogCategory)
                || "RISK".equals(catalogCategory)
                || "ANALYST".equals(catalogCategory)
                || "SOURCES".equals(catalogCategory)
                || layer == layerForCategory(catalogCategory))) {
            rebuildCatalogPage();
        }
    }

    @Override
    public void onWeather(String host, List<WorldDataRepository.RadarFrame> frames,
                          FeedStatus status) {
        runUiBoundary("MainActivity.onWeather",
                () -> onWeatherUnsafe(host, frames, status));
    }

    private void onWeatherUnsafe(
            String host,
            List<WorldDataRepository.RadarFrame> frames,
            FeedStatus status) {
        LiveOperationsEngine.LayerSnapshot operational = operationsEngine.accept(
                Signal.Layer.WEATHER, Collections.emptyList(), status,
                System.currentTimeMillis());
        FeedStatus previous = feedStatuses.get(Signal.Layer.WEATHER);
        feedStatuses.put(Signal.Layer.WEATHER, operational.status);
        if (sourceMatrixView != null) {
            sourceMatrixView.update(Signal.Layer.WEATHER, operational);
        }
        if (mapView != null) {
            mapView.setLayerActivity(Signal.Layer.WEATHER, operational.status);
        }
        if (frames != null && !frames.isEmpty()) {
            radarFrames = Collections.unmodifiableList(new ArrayList<>(frames));
            mapView.setRadarFrames(host, frames);
            long frameTimeMs = frames.get(frames.size() - 1).timestampMs;
            if (frameTimeMs > 0L && frameTimeMs != lastWeatherFrame) {
                lastWeatherFrame = frameTimeMs;
                acquisitionCount++;
                showSystemAcquisition("WEATHER FRAME", "RainViewer",
                        eventTime.format(new Date(frameTimeMs)));
            }
        }
        updateLayerLabel(Signal.Layer.WEATHER, operational.status);
        updateFeedPulse();
        updateSignalBeacons();
        pulseFeedTransition(previous, operational.status);
        updateAnalysisRibbon();
        if (catalogPanel != null && catalogPanel.getVisibility() == View.VISIBLE
                && ("BRIEF".equals(catalogCategory) || "WEATHER".equals(catalogCategory)
                || "SOURCES".equals(catalogCategory))) {
            rebuildCatalogPage();
        }
    }

    @Override
    public void onSearchResult(WorldDataRepository.Place place, String error) {
        runUiBoundary("MainActivity.onSearchResult",
                () -> onSearchResultUnsafe(place, error));
    }

    private void onSearchResultUnsafe(WorldDataRepository.Place place, String error) {
        if (place == null) {
            Toast.makeText(this, error == null || error.trim().isEmpty()
                    ? "Location search did not return a result" : error,
                    Toast.LENGTH_LONG).show();
            if (searchInput != null) searchInput.setEnabled(true);
            return;
        }
        searchInput.setEnabled(true);
        searchInput.setText(place.name.split(",")[0]);
        localLatitude = place.latitude;
        localLongitude = place.longitude;
        localSouth = place.south;
        localWest = place.west;
        localNorth = place.north;
        localEast = place.east;
        localCountryScope = place.countryScope;
        localCountryCode = place.countryCode;
        localName = place.name;
        localMode = true;
        localButton.setText("LOCAL ON");
        localButton.setTextColor(GREEN);
        // F10.30/10.5: geographic search now drives the camera instead of teleporting it.
        mapView.flyTo(place.latitude, place.longitude, place.countryScope ? 4.2d : 6.2d);
        applyFilters();
        Toast.makeText(this, "LOCAL MODE — " + place.name + (place.countryScope
                ? " • country bounds" : " • 650 km city lens"), Toast.LENGTH_LONG).show();
    }

    // 1.2/20/3-16 — search live canonical objects before falling back to place lookup.
    // 1.2/20/4-16 — unified operational search; exact canonical routing remains authoritative.
    private Signal findLiveIntelligenceSearchObject(String raw) {
        List<LiveIntelligenceSearch.Hit> hits=LiveIntelligenceSearch.search(
                raw,layerSignals.values(),canonicalWatchStore,liveChangeRegistry,12);
        return hits.isEmpty()?null:hits.get(0).signal;
    }

    private Signal findSearchObject(String raw) {
        String q=raw==null?"":raw.trim().toLowerCase(Locale.ROOT);
        if(q.isEmpty())return null;
        Signal partial=null;
        for(List<Signal> values:layerSignals.values())for(Signal s:values){
            if(s==null)continue;
            String title=s.title==null?"":s.title.toLowerCase(Locale.ROOT);
            String canonical=s.canonicalId==null?"":s.canonicalId.toLowerCase(Locale.ROOT);
            String nativeId=s.id==null?"":s.id.toLowerCase(Locale.ROOT);
            String callsign=s.facts.get("CALLSIGN");if(callsign==null)callsign="";
            String norad=s.facts.get("NORAD CATALOG");if(norad==null)norad="";
            if(q.equals(canonical)||q.equals(nativeId)||q.equals(callsign.toLowerCase(Locale.ROOT))
                    ||q.equals(norad.toLowerCase(Locale.ROOT)))return s;
            if(partial==null&&(title.contains(q)||canonical.contains(q)))partial=s;
        }
        return partial;
    }

    private void focusSearchObject(Signal signal) {
        Signal exact=resolveExactSignal(signal);
        if(exact==null)return;
        if(exact.hasLocation()){
            double targetZoom = exact.layer == Signal.Layer.FLIGHTS ? 8.0d
                    : exact.layer == Signal.Layer.SHIPS ? 9.0d
                    : exact.layer == Signal.Layer.SATELLITES ? 5.4d
                    : Math.max(mapView.getZoom(), 5.8d);
            mapView.flyTo(exact.latitude, exact.longitude, targetZoom);
            mapView.highlightSignal(exact);
        }
        routeUniversalGlobeTap(exact);
    }

    private void returnToUgandaHome() {
        if (mapView == null) return;
        mapView.flyTo(UGANDA_HOME_LAT, UGANDA_HOME_LON, UGANDA_HOME_ZOOM);
        Toast.makeText(this, "UGANDA HOME • national operational view", Toast.LENGTH_SHORT).show();
    }

    private void showUgandaHomeOptions() {
        final String[] options = {"UGANDA NATIONAL", "KAMPALA", "ENTEBBE", "EAST AFRICA"};
        new AlertDialog.Builder(this)
                .setTitle("UGANDA HOME")
                .setItems(options, (dialog, which) -> {
                    switch (which) {
                        case 1: mapView.flyTo(0.3476d, 32.5825d, 8.0d); break;
                        case 2: mapView.flyTo(0.0512d, 32.4637d, 9.0d); break;
                        case 3: mapView.flyTo(1.3d, 35.0d, 3.7d); break;
                        default: returnToUgandaHome();
                    }
                }).show();
    }

    private Signal findAnyLocatedSearchObject(String raw) {
        if (raw == null) return null;
        String q = raw.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) return null;
        Signal partial = null;
        for (Map.Entry<Signal.Layer, List<Signal>> entry : layerSignals.entrySet()) {
            for (Signal signal : entry.getValue()) {
                if (signal == null || !signal.hasLocation()) continue;
                String title = signal.title == null ? "" : signal.title.toLowerCase(Locale.ROOT);
                String id = signal.id == null ? "" : signal.id.toLowerCase(Locale.ROOT);
                String canonical = signal.canonicalId == null ? "" : signal.canonicalId.toLowerCase(Locale.ROOT);
                String source = signal.source == null ? "" : signal.source.toLowerCase(Locale.ROOT);
                String call = String.valueOf(signal.facts.get("CALLSIGN")).toLowerCase(Locale.ROOT);
                String name = String.valueOf(signal.facts.get("NAME")).toLowerCase(Locale.ROOT);
                if (q.equals(id) || q.equals(canonical) || q.equals(call) || q.equals(name)) return signal;
                if (partial == null && (title.contains(q) || id.contains(q)
                        || canonical.contains(q) || source.contains(q) || call.contains(q)
                        || name.contains(q))) partial = signal;
            }
        }
        return partial;
    }

    private double searchTargetZoom(Signal signal) {
        if (signal == null) return 6.0d;
        switch (signal.layer) {
            case FLIGHTS: return 8.0d;
            case SHIPS: return 9.0d;
            case SATELLITES: return 5.4d;
            case WEBCAMS: return 10.0d;
            case INFRASTRUCTURE: return 8.2d;
            case NATURAL: return signal.severity >= 4 ? 7.2d : 6.5d;
            case WEATHER: return 6.0d;
            case NEWS:
            case AIRSPACE: return 6.8d;
            default: return 6.2d;
        }
    }

    private void navigateToSearchObject(Signal signal) {
        Signal exact = resolveExactSignal(signal);
        if (exact == null || !exact.hasLocation()) return;
        mapView.flyTo(exact.latitude, exact.longitude, searchTargetZoom(exact));
        mapView.highlightSignal(exact);
        showDetail(exact);
    }

    private void showGestureLocationActions(double latitude, double longitude) {
        String coord = String.format(Locale.US, "%.4f, %.4f", latitude, longitude);
        String[] actions = {"INSPECT HERE", "WATCH AREA", "MARK LOCATION", "SHARE LOCATION", "NEARBY"};
        new AlertDialog.Builder(this).setTitle("LOCATION • " + coord)
                .setItems(actions, (dialog, which) -> {
                    switch (which) {
                        case 0: inspectLocation(latitude, longitude); break;
                        case 1: watchLocationArea(latitude, longitude, coord); break;
                        case 2: markLocation(latitude, longitude, coord); break;
                        case 3: shareLocationPoint(latitude, longitude, coord); break;
                        default: showNearbyAt(latitude, longitude, coord);
                    }
                }).show();
    }

    private void inspectLocation(double latitude, double longitude) {
        mapView.flyTo(latitude, longitude, 7.0d);
        List<Signal> nearby = nearbySignals(latitude, longitude, 75d);
        StringBuilder body = new StringBuilder();
        body.append(String.format(Locale.US, "POINT  %.4f, %.4f\n", latitude, longitude));
        body.append("NEARBY LOADED RECORDS  ").append(nearby.size()).append("\n");
        int limit = Math.min(8, nearby.size());
        for (int i=0;i<limit;i++) {
            Signal s=nearby.get(i);
            body.append("• ").append(s.layer.name()).append("  ").append(s.title).append("\n");
        }
        new AlertDialog.Builder(this).setTitle("INSPECT HERE")
                .setMessage(body.toString().trim()).setPositiveButton("CLOSE", null).show();
    }

    private void watchLocationArea(double latitude, double longitude, String coord) {
        watchedAreaLat=latitude; watchedAreaLon=longitude; watchedAreaName=coord;
        localLatitude=latitude; localLongitude=longitude; localName=coord;
        localCountryScope=false; localMode=true;
        if(localButton!=null){localButton.setText("LOCAL ON");localButton.setTextColor(GREEN);}
        applyFilters();
        mapView.flyTo(latitude, longitude, 6.0d);
        Toast.makeText(this,"WATCH AREA • "+coord+" • 650 km lens",Toast.LENGTH_LONG).show();
    }

    private void markLocation(double latitude, double longitude, String coord) {
        String mark="MARK "+(localMapMarks.size()+1)+" • "+coord;
        localMapMarks.add(mark);
        while(localMapMarks.size()>50)localMapMarks.remove(0);
        Toast.makeText(this,mark+" • stored locally for this session",Toast.LENGTH_LONG).show();
    }

    private void shareLocationPoint(double latitude, double longitude, String coord) {
        Intent share=new Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT,"DU WORLD MONITOR LOCATION\n"+coord
                        +"\nSelected map point — not a provider observation.");
        startActivity(Intent.createChooser(share,"Share location"));
    }

    private void showNearbyAt(double latitude, double longitude, String coord) {
        List<Signal> nearby=nearbySignals(latitude,longitude,250d);
        if(nearby.isEmpty()){
            Toast.makeText(this,"No loaded nearby records around "+coord,Toast.LENGTH_LONG).show();
            return;
        }
        int limit=Math.min(12,nearby.size());
        String[] labels=new String[limit];
        for(int i=0;i<limit;i++){
            Signal s=nearby.get(i);
            double km=SatelliteMapView.distanceKm(latitude,longitude,s.latitude,s.longitude);
            labels[i]=String.format(Locale.US,"%.0f km • %s • %s",km,s.layer.name(),s.title);
        }
        new AlertDialog.Builder(this).setTitle("NEARBY • "+coord)
                .setItems(labels,(dialog,which)->navigateToSearchObject(nearby.get(which))).show();
    }

    private List<Signal> nearbySignals(double latitude,double longitude,double radiusKm){
        ArrayList<Signal> out=new ArrayList<>();
        for(List<Signal> layer:layerSignals.values()){
            for(Signal s:layer){
                if(s!=null&&s.hasLocation()
                        && SatelliteMapView.distanceKm(latitude,longitude,s.latitude,s.longitude)<=radiusKm){
                    out.add(s);
                }
            }
        }
        Collections.sort(out,(a,b)->Double.compare(
                SatelliteMapView.distanceKm(latitude,longitude,a.latitude,a.longitude),
                SatelliteMapView.distanceKm(latitude,longitude,b.latitude,b.longitude)));
        return out;
    }

    private boolean runMaritimeSearch2(String query){
        List<MaritimeSearchEngine.Match> matches=MaritimeSearchEngine.search(query,
                layerSignals.get(Signal.Layer.SHIPS),portRegistry.allSignals());
        if(matches.isEmpty())return false;
        if(matches.size()==1){navigateToSearchObject(matches.get(0).signal);return true;}
        int limit=Math.min(40,matches.size());String[] labels=new String[limit];
        for(int i=0;i<limit;i++)labels[i]=matches.get(i).label();
        new AlertDialog.Builder(this).setTitle("MARITIME SEARCH 2.0")
                .setMessage("MMSI • IMO • CALLSIGN • VESSEL • TYPE • AIS DESTINATION • PORT / UN/LOCODE")
                .setItems(labels,(dialog,which)->navigateToSearchObject(matches.get(which).signal)).show();
        return true;
    }

    private boolean runAircraftSearch2(String query) {
        List<AircraftSearchEngine.Result> results=AircraftSearchEngine.search(
                query,layerSignals.get(Signal.Layer.FLIGHTS));
        if(results.isEmpty())return false;
        if(results.size()==1){navigateToSearchObject(results.get(0).signal);return true;}
        int limit=Math.min(20,results.size());String[] labels=new String[limit];
        for(int i=0;i<limit;i++)labels[i]=results.get(i).label();
        new AlertDialog.Builder(this).setTitle("AIRCRAFT SEARCH")
                .setItems(labels,(dialog,which)->navigateToSearchObject(results.get(which).signal))
                .show();
        return true;
    }

    private void runSearch() {
        String query=searchInput==null?"":searchInput.getText().toString();
        if(runMaritimeSearch2(query))return;
        Signal airportMatch=airportRegistry.findSignal(query);
        if(airportMatch!=null){navigateToSearchObject(airportMatch);return;}
        Signal portMatch=portRegistry.findSignal(query);
        if(portMatch!=null){navigateToSearchObject(portMatch);return;}
        if(runAircraftSearch2(query))return;
        Signal objectMatch=findLiveIntelligenceSearchObject(query);
        if(objectMatch==null)objectMatch=findSearchObject(query);
        if(objectMatch==null)objectMatch=findAnyLocatedSearchObject(query);
        if(objectMatch!=null){
            navigateToSearchObject(objectMatch);
            return;
        }
        if (repository == null) {
            Toast.makeText(this,
                    "Location search is paused in recovery mode. Restart the complete command deck to use live search.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        searchInput.setEnabled(false);
        Toast.makeText(this, "Locating…", Toast.LENGTH_SHORT).show();
        repository.search(searchInput.getText().toString());
    }

    private void runUiBoundary(String component, Runnable action) {
        if (destroyed || action == null) return;
        if (Looper.myLooper() != Looper.getMainLooper()) {
            runOnUiThread(() -> runUiBoundary(component, action));
            return;
        }
        try {
            action.run();
        } catch (RuntimeException error) {
            String reference = CrashLedger.recordRecovered(this, component, error);
            Log.e(LOG_TAG, "Recovered UI boundary " + component + " / " + reference, error);
            if (feedPulse != null) {
                feedPulse.setText("SOURCE UPDATE ISOLATED • APP REMAINS OPEN • " + reference);
                feedPulse.setTextColor(AMBER);
            }
        }
    }

    private void toggleLocalMode() {
        if (!localMode && localName.trim().isEmpty()) {
            Toast.makeText(this, "Search a city or country first", Toast.LENGTH_LONG).show();
            return;
        }
        localMode = !localMode;
        localButton.setText(localMode ? "LOCAL ON" : "LOCAL OFF");
        localButton.setTextColor(localMode ? GREEN : CYAN);
        applyFilters();
    }

    private void applyFilters() {
        List<Signal> mapSignals = new ArrayList<>();
        List<Signal> ticker = new ArrayList<>();
        EnumMap<Signal.Layer, List<Signal>> viewLayers = layersForTimeline();
        for (Map.Entry<Signal.Layer, List<Signal>> entry : viewLayers.entrySet()) {
            if (!Boolean.TRUE.equals(enabled.get(entry.getKey()))) continue;
            for (Signal signal : entry.getValue()) {
                if (!matchesLocal(signal)) continue;
                if ((signal.layer == Signal.Layer.NEWS || signal.layer == Signal.Layer.NATURAL
                        || signal.layer == Signal.Layer.AIRSPACE)
                        && !matchesEventFilters(signal)) continue;
                if (signal.hasLocation()) mapSignals.add(signal);
                if (isDeskLayer(signal.layer) && isLiveDeskSignal(signal)) {
                    ticker.add(signal);
                }
            }
        }
        if (!replayMode && Boolean.TRUE.equals(enabled.get(Signal.Layer.MEDIA))) {
            for (Signal monitor : localMonitorSignals()) {
                if (matchesLocal(monitor)) mapSignals.add(monitor);
            }
        }
        mapView.setSignals(mapSignals);
        mapView.setReplayState(replayMode, replayFrameAtMs);
        if (replayMode) mapView.setRadarReplayTime(replayFrameAtMs);
        Collections.sort(ticker, (first, second) ->
                compareNewestFirst(first.timestampMs, second.timestampMs));
        // Inflating dozens of ticker cards while the wire drawer is closed wastes the
        // phone's first interactive frames. The full list remains in layerSignals and is
        // rendered immediately when the user opens WIRE.
        if (wirePanel != null && wirePanel.getVisibility() == View.VISIBLE) {
            rebuildTicker(ticker);
        }
        updateCrawl(ticker);
        updateReplayStatus();
    }

    /** Converts coordinate-bearing Local Monitor reports into clearly labelled globe markers. */
    private List<Signal> localMonitorSignals() {
        List<Signal> signals = new ArrayList<>();
        if (monitorStore == null) return signals;
        for (MonitorReport report : monitorStore.reports()) {
            if (report.isDraft()) continue;
            double latitude = report.latitude;
            double longitude = report.longitude;
            boolean inferredPlace = false;
            if (!Double.isFinite(latitude) || !Double.isFinite(longitude)) {
                GeoIndex.Point point = GeoIndex.find(report.locationName);
                if (point == null) continue;
                latitude = point.latitude;
                longitude = point.longitude;
                inferredPlace = true;
            }
            Signal.Credibility credibility = "CONFIRMED".equals(report.truthState)
                    ? Signal.Credibility.CONFIRMED
                    : "REPORTED".equals(report.truthState)
                    ? Signal.Credibility.REPORTED : Signal.Credibility.UNVERIFIED;
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("REPORTER", report.displayName + " " + report.handle);
            facts.put("LOCATION", report.locationName);
            facts.put("REPORT STATE", report.stateLine());
            facts.put("SOURCE LABEL", report.sourceLabel);
            facts.put("LOCATION PRECISION", inferredPlace
                    ? "BUILT-IN PLACE CENTROID / APPROXIMATE"
                    : report.locationApproximate ? "APPROXIMATE" : "REPORTER ATTACHED");
            facts.put("REPORT ID", report.id);
            String title = report.headline.isEmpty()
                    ? report.category + " • " + report.locationName : report.headline;
            signals.add(new Signal(
                    "local-monitor:" + report.id,
                    Signal.Layer.MEDIA,
                    title,
                    report.caption,
                    latitude,
                    longitude,
                    Double.NaN,
                    report.createdAtMs,
                    "Local Monitor / " + report.handle,
                    report.shareUrl,
                    credibility,
                    "OTHER",
                    "GLOBAL",
                    report.live ? 3 : 2,
                    facts));
        }
        return signals;
    }

    private EnumMap<Signal.Layer, List<Signal>> layersForTimeline() {
        EnumMap<Signal.Layer, List<Signal>> result = new EnumMap<>(Signal.Layer.class);
        result.putAll(layerSignals);
        if (!replayMode) {
            replayFrameAtMs = 0L;
            return result;
        }
        TemporalReplayEngine.Snapshot snapshot = replayEngine.snapshotAt(replayTimeMs);
        replayFrameAtMs = snapshot.capturedAtMs;
        for (Signal.Layer layer : Signal.Layer.values()) {
            if (TemporalReplayEngine.isTemporalLayer(layer)) {
                result.put(layer, new ArrayList<>());
            }
        }
        for (Signal signal : snapshot.signals) {
            List<Signal> values = result.get(signal.layer);
            if (values != null) values.add(signal);
        }
        return result;
    }

    private boolean isDeskLayer(Signal.Layer layer) {
        return layer == Signal.Layer.NEWS
                || layer == Signal.Layer.NATURAL
                || layer == Signal.Layer.AIRSPACE
                || layer == Signal.Layer.SPACE_WEATHER
                || layer == Signal.Layer.MARKETS
                || layer == Signal.Layer.WEBCAMS
                || layer == Signal.Layer.RADIO
                || layer == Signal.Layer.TV
                || layer == Signal.Layer.MEDIA;
    }

    private boolean isLiveDeskSignal(Signal signal) {
        if (signal.layer != Signal.Layer.MEDIA) return true;
        return signal.sourceUrl.startsWith("https://")
                && "AUDIO".equalsIgnoreCase(signal.facts.get("MEDIA TYPE"));
    }

    private boolean matchesLocal(Signal signal) {
        if (!localMode) return true;
        if (localCountryScope && signal.hasLocation()
                && !Double.isNaN(localSouth) && !Double.isNaN(localWest)
                && !Double.isNaN(localNorth) && !Double.isNaN(localEast)) {
            boolean longitudeMatch = localWest <= localEast
                    ? signal.longitude >= localWest && signal.longitude <= localEast
                    : signal.longitude >= localWest || signal.longitude <= localEast;
            return signal.latitude >= localSouth && signal.latitude <= localNorth
                    && longitudeMatch;
        }
        return signal.hasLocation()
                && SatelliteMapView.distanceKm(localLatitude, localLongitude,
                signal.latitude, signal.longitude) <= 650d;
    }

    private boolean matchesEventFilters(Signal signal) {
        if (!TYPES[typeIndex].equals("ALL") && !TYPES[typeIndex].equals(signal.eventType)) return false;
        if (!REGIONS[regionIndex].equals("ALL") && !REGIONS[regionIndex].equals(signal.region)) return false;
        if (signal.severity < minimumSeverity) return false;
        if (signal.timestampMs <= 0L) return false;
        long age = Math.max(0L, currentTimelineMs() - signal.timestampMs);
        return age <= TIME_WINDOW_MS[timeWindowIndex];
    }

    private void rebuildTicker(List<Signal> signals) {
        tickerContainer.removeAllViews();
        if (signals.isEmpty()) {
            TextView empty = text(localMode
                    ? "NO MATCHING SIGNALS IN LOCAL MODE" : "WAITING FOR WIRE SIGNALS",
                    MUTED, 10, true);
            empty.setGravity(Gravity.CENTER);
            tickerContainer.addView(empty, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(100)));
            return;
        }
        int limit = Math.min(80, signals.size());
        for (int index = 0; index < limit; index++) {
            Signal signal = signals.get(index);
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(10), dp(9), dp(10), dp(9));
            card.setBackground(panelBackground(PANEL_ALT, signalStateColor(signal), 14));
            TextView light = text("● " + signalStateText(signal)
                    + "  •  SEV " + signal.severity, signalStateColor(signal), 8, true);
            TextView badge = text(badgeText(signal), badgeColor(signal.credibility), 9, true);
            TextView title = text(signal.title, TEXT, 10, true);
            TextView source = text(signal.source + "  •  " + eventTime.format(new Date(signal.timestampMs)),
                    MUTED, 8, false);
            source.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
            card.addView(light);
            card.addView(badge, marginParams(0, 3, 0, 0));
            card.addView(title, marginParams(0, 4, 0, 4));
            card.addView(source);
            Button share = compactButton("SHARE CARD");
            share.setTextColor(GREEN);
            share.setOnClickListener(view -> shareSignal(signal));
            card.addView(share, marginParams(0, 7, 0, 0));
            card.setOnClickListener(view -> showDetail(signal));
            tickerContainer.addView(card, marginParams(0, 0, 0, 7));
        }
    }

    private void updateCrawl(List<Signal> signals) {
        if (crawlText == null) return;
        if (signals.isEmpty()) {
            crawlText.setText(localMode
                    ? "LOCAL SCAN • NO MATCHING PUBLIC SIGNALS YET"
                    : "SCANNING PUBLIC SOURCES • WAITING FOR FIRST DATA PACKET");
            return;
        }
        StringBuilder crawl = new StringBuilder("  ");
        int limit = Math.min(14, signals.size());
        for (int index = 0; index < limit; index++) {
            Signal signal = signals.get(index);
            if (index > 0) crawl.append("     ◆     ");
            crawl.append('[').append(signalStateText(signal)).append('/')
                    .append(shortBadge(signal)).append("] ")
                    .append(signal.title)
                    .append(" — ").append(signal.source)
                    .append(" — ").append(utcClock.format(new Date(signal.timestampMs)));
        }
        crawl.append("     ◆     ");
        crawlText.setText(crawl.toString());
        crawlText.setSelected(true);
    }

    private void shareSignal(Signal signal) {
        if (signal == null) return;
        if(signal.layer==Signal.Layer.FLIGHTS){
            AircraftTelemetry telemetry=AircraftTelemetry.from(signal);
            String observed=telemetry!=null&&telemetry.providerTimestampMs>0L
                    ?eventTime.format(new Date(telemetry.providerTimestampMs)):"UNKNOWN";
            String timeline=mapView!=null&&mapView.isAircraftReplayActive(signal)
                    ?mapView.aircraftReplayStatus()+" • HISTORICAL OBSERVED POSITION":"LIVE";
            signal.facts.put("AIRCRAFT SHARE TEXT",
                    AircraftShareCardData.from(signal,observed,timeline).text());
        }
        if(signal.layer==Signal.Layer.SHIPS){
            VesselTelemetry telemetry=VesselTelemetry.from(signal);
            String observed=telemetry!=null&&telemetry.providerTimestampMs>0L
                    ?eventTime.format(new Date(telemetry.providerTimestampMs)):"UNKNOWN";
            String timeline=mapView!=null&&mapView.isVesselReplayActive(signal)
                    ?mapView.vesselReplayStatus()+" • HISTORICAL OBSERVED POSITION":"LIVE";
            signal.facts.put("VESSEL SHARE TEXT",VesselShareCardData.from(signal,observed,timeline).text());
            signal.facts.put("VESSEL SHARE TIMELINE",timeline);
        }
        ShareCardRenderer.share(this, shareDataForSignal(signal));
    }

    private ShareCardData shareDataForSignal(Signal signal) {
        String disclaimer;
        if (signal.credibility == Signal.Credibility.RAW_SIGNAL) {
            disclaimer = "Raw telemetry is not confirmation of identity, intent or an incident. Verify at the original source.";
        } else if (signal.credibility == Signal.Credibility.CALCULATED) {
            disclaimer = "Calculated from named public orbital elements; not live telemetry, tasking proof, navigation or safety data.";
        } else if (signal.credibility == Signal.Credibility.UNVERIFIED) {
            disclaimer = "Unverified developing information. Do not present it as confirmed fact; verify at the original source.";
        } else {
            disclaimer = "Verify timestamp and context at the original source. Observed information is not a forecast.";
        }
        // 1.2/20/2-18: share the exact canonical record provenance, not reconstructed UI text.
        signal = resolveExactSignal(signal);
        Map<String, String> cardFacts = new LinkedHashMap<>(signal.nativePayload == null
                ? signal.facts : signal.nativePayload.facts);
        cardFacts.put("CANONICAL OBJECT ID", signal.canonicalId);
        cardFacts.put("PROVIDER ID", signal.providerId);
        cardFacts.put("PROVIDER NAME", signal.providerName);
        cardFacts.put("PROVIDER RECORD ID", signal.originalRecord == null ? signal.id : signal.originalRecord.providerRecordId);
        cardFacts.put("COORDINATE ORIGIN", signal.coordinateProvenance == null ? "UNAVAILABLE" : signal.coordinateProvenance.origin.name());
        cardFacts.put("FRESHNESS", signal.freshness == null ? "UNKNOWN" : signal.freshness.state.name());
        cardFacts.put("PROVIDER TIME", signal.timestampChain == null ? String.valueOf(signal.timestampMs) : String.valueOf(signal.timestampChain.providerTimeMs));
        cardFacts.put("FIRST SEEN", signal.timestampChain == null ? "" : String.valueOf(signal.timestampChain.firstSeenMs));
        cardFacts.put("FETCHED AT", signal.timestampChain == null ? "" : String.valueOf(signal.timestampChain.fetchedAtMs));
        cardFacts.put("RELATIONSHIP ID", signal.relationshipId == null ? "" : signal.relationshipId);
        if(signal.layer==Signal.Layer.SHIPS){
            VesselTelemetry vt=VesselTelemetry.from(signal);
            String observed=vt!=null&&vt.providerTimestampMs>0L?eventTime.format(new Date(vt.providerTimestampMs)):"UNKNOWN";
            String timeline=mapView!=null&&mapView.isVesselReplayActive(signal)
                    ?mapView.vesselReplayStatus()+" • HISTORICAL OBSERVED POSITION":"LIVE";
            cardFacts.put("VESSEL INTELLIGENCE CARD",VesselShareCardData.from(signal,observed,timeline).text());
            cardFacts.put("VESSEL TIMELINE",timeline);
        }
        // 1.2/20/3-18 human-readable Object Share Card 2.0, preserving exact provenance above.
        cardFacts.put("OBJECT TYPE", signal.layer.name());
        cardFacts.put("OBJECT STATE", signalStateText(signal));
        cardFacts.put("FRESHNESS", signal.freshness == null ? "UNKNOWN" : signal.freshness.state.name());
        cardFacts.put("OBSERVED / PUBLISHED", eventTime.format(new Date(signal.timestampMs)));
        cardFacts.put("LOCATION", signal.hasLocation()
                ? String.format(Locale.US,"%.4f, %.4f",signal.latitude,signal.longitude) : "UNAVAILABLE");
        cardFacts.put("CREDIBILITY", signal.credibility.name());
        if (signal.layer == Signal.Layer.SATELLITES)
            cardFacts.put("DISCLOSURE", "CALCULATED FROM PUBLIC ELEMENTS — NOT LIVE TELEMETRY");
        if (signal.layer == Signal.Layer.WEATHER)
            cardFacts.put("DISCLOSURE", "RADAR HISTORY / OBSERVATION — NOT A FORECAST");
        cardFacts.put("FEED STATE", sourceStateText(signal.layer));
        cardFacts.put("SOURCE UPDATE AGE", sourceAgeText(signal.layer));
        cardFacts.put("PROVIDER-RETURNED COUNT",
                String.format(Locale.US, "%,d", count(signal.layer)));
        return new ShareCardData(
                signal.title,
                signal.summary,
                signalStateText(signal) + " • "
                        + (signal.freshness == null ? "UNKNOWN" : signal.freshness.state.name()),
                badgeText(signal),
                feedDisplayName(signal.layer),
                signal.region,
                signal.severity,
                signal.source,
                signal.sourceUrl,
                signal.timestampMs,
                signal.latitude,
                signal.longitude,
                cardFacts,
                signalStateColor(signal),
                disclaimer);
    }

    private void shareCurrentPage() {
        Map<String, String> facts = new LinkedHashMap<>();
        facts.put("PAGE", catalogCategory);
        facts.put("MODE", replayMode
                ? "4D REPLAY — " + eventTime.format(new Date(replayFrameAtMs)) : "LIVE");
        facts.put("PAGE STATUS", catalogStatus == null ? "Visible" : catalogStatus.getText().toString());
        facts.put("LOCAL MODE", localMode ? "ON — " + localName : "OFF");
        facts.put("TIME WINDOW", TIME_WINDOWS[timeWindowIndex]);
        facts.put("TYPE FILTER", TYPES[typeIndex]);
        facts.put("REGION FILTER", REGIONS[regionIndex]);
        facts.put("MINIMUM SEVERITY", String.valueOf(minimumSeverity));
        facts.put("GENERATED", eventTime.format(new Date()));
        ShareCardRenderer.share(this, new ShareCardData(
                catalogTitle == null ? catalogCategory : catalogTitle.getText().toString(),
                "A shareable summary of the information currently visible on this native operations page.",
                "PAGE SUMMARY",
                "MIXED SOURCE STATES — OPEN EACH ITEM FOR ITS STATUS",
                catalogCategory,
                localMode ? localName : "GLOBAL",
                1,
                APP_BRAND + " on-device operations desk",
                "",
                System.currentTimeMillis(),
                localMode ? localLatitude : Double.NaN,
                localMode ? localLongitude : Double.NaN,
                facts,
                CYAN,
                "Page totals depend on provider coverage and active filters. Verify individual items at their original sources."));
    }

    private ShareCardData customShareCard(
            String title,
            String summary,
            String status,
            String credibility,
            String category,
            String region,
            int severity,
            String source,
            long timestampMs,
            double latitude,
            double longitude,
            Map<String, String> facts,
            int accent,
            String disclaimer) {
        return new ShareCardData(title, summary, status, credibility, category, region,
                severity, source, "", timestampMs, latitude, longitude, facts,
                accent, disclaimer);
    }

    // 1.2/20/3-1 — every rendered Globe object enters one exact-record tap router.
    private void routeUniversalGlobeTap(Signal signal) {
        if (signal == null) return;
        Signal exact = resolveExactSignal(signal);
        if (exact != null && exact.id.startsWith("local-monitor:")) {
            openLocalMonitors(exact.id.substring("local-monitor:".length()));
        } else if (exact != null && exact.layer == Signal.Layer.NEWS) {
            NewsItem exactNews = resolveExactNewsItem(exact);
            if (exactNews != null) { f17BeforeDetail(); showLocalNewsDetail(exactNews); }
            else showDetail(exact);
        } else {
            showDetail(exact);
        }
    }

    private void showGlobeObjectChooser(List<Signal> candidates) {
        if (candidates == null || candidates.isEmpty()) return;
        if (candidates.size() == 1) { routeUniversalGlobeTap(candidates.get(0)); return; }
        final ArrayList<Signal> exact = new ArrayList<>();
        final ArrayList<String> labels = new ArrayList<>();
        for (Signal candidate : candidates) {
            Signal current = resolveExactSignal(candidate);
            if (current == null) continue;
            exact.add(current);
            String provider = current.providerName == null || current.providerName.trim().isEmpty()
                    ? current.providerId : current.providerName;
            String freshness=current.freshness==null?"UNKNOWN":current.freshness.state.name();
            String record=current.originalRecord==null?current.id:current.originalRecord.providerRecordId;
            labels.add(current.layer.name()+"  •  "+current.title+"\n"+provider+"  •  "+freshness+"  •  "+record);
        }
        if (exact.isEmpty()) return;
        new android.app.AlertDialog.Builder(this)
                .setTitle(exact.size() + " OBJECTS HERE • SELECT EXACT RECORD")
                .setMessage("Overlapping Globe markers remain separate canonical objects.")
                .setItems(labels.toArray(new String[0]), (dialog, which) -> routeUniversalGlobeTap(exact.get(which)))
                .setNegativeButton("CLOSE", null)
                .show();
    }

    // 1.2/20/2-16 detail -> Globe round-trip snapshot.
    private boolean detailReturnCaptured;
    private boolean detailReturnGlobeMode;
    private double detailReturnLat, detailReturnLon, detailReturnZoom;
    private String detailReturnCanonicalId = "";

    private void captureDetailReturnState(Signal signal) {
        if (mapView == null) return;
        detailReturnCaptured = true;
        detailReturnGlobeMode = mapView.isGlobeMode();
        detailReturnLat = mapView.getCenterLatitude();
        detailReturnLon = mapView.getCenterLongitude();
        detailReturnZoom = mapView.getZoom();
        detailReturnCanonicalId = signal == null ? "" : signal.canonicalId;
    }

    private void restoreDetailReturnState() {
        if (!detailReturnCaptured || mapView == null) return;
        if (detailReturnGlobeMode) mapView.setGlobeMode(true);
        else mapView.setCenter(detailReturnLat, detailReturnLon, detailReturnZoom);
        if (!detailReturnCanonicalId.isEmpty()) {
            for (List<Signal> values : layerSignals.values()) {
                Signal s = findCanonical(values, detailReturnCanonicalId);
                if (s != null) { mapView.highlightSignal(s); break; }
            }
        }
        detailReturnCaptured = false;
    }

    private Signal findCanonical(List<Signal> values, String canonicalId) {
        if (values == null || canonicalId == null) return null;
        for (Signal s : values) if (s != null && canonicalId.equals(s.canonicalId)) return s;
        return null;
    }

    // 1.2/20/2-15 — TAP -> EXACT CURRENT PROVIDER RECORD.
    private Signal resolveExactSignal(Signal tapped) {
        if (tapped == null || tapped.originalRecord == null) return tapped;
        List<Signal> current = layerSignals.get(tapped.layer);
        Signal exact = OriginalRecordResolver.resolve(tapped.originalRecord, current);
        return exact == null ? tapped : exact;
    }

    private NewsItem resolveExactNewsItem(Signal signal) {
        if (signal == null || signal.layer != Signal.Layer.NEWS) return null;
        String newsId = signal.nativePayload == null ? "" : signal.nativePayload.value("NEWS ID");
        if (newsId.isEmpty()) return null;
        for (NewsItem n : new NewsStore(this).load()) if (newsId.equals(n.id)) return n;
        return null;
    }

    // 1.2/20/3-2 — compact Object Intelligence Sheet over the frozen Globe.
    // 1.2/20/3-3 — provider-backed Aircraft Intelligence. No inferred airline/destination/flight number.
    // 1.2/20/3-6 — earthquake/natural-event intelligence from the exact provider payload.
    // 1.2/20/3-7 — orbit intelligence; calculated positions are never presented as live telemetry.
    // 1.2/20/3-8 — RainViewer frame intelligence; radar history is not a forecast.
    // 1.2/20/3-11 — related records stay independent; relationship is not confirmation.
    // 1.2/20/3-12 — bounded chronological history from the canonical provider record chain.
    // 1.2/20/3-14 — provider health for the exact selected object.
    // 1.2/20/3-15 — WATCH state follows canonical identity across refresh and provider loss.
    // 1.2/20/4-1 — factual changes detected between provider refreshes.
    // 1.2/20/4-2 — movement derived only from consecutive retained provider observations.
    // 1.2/20/4-3 — current observational density around the selected object.
    // 1.2/20/4-4 — evidence workspace; related records are never merged into a new fact.
    // 1.2/20/4-5 — Uganda/East Africa relevance without changing source severity.
    // 1.2/20/4-6 — nearby objects are geometric context only, never implied relationships.
    // 1.2/20/4-7 — meaningful change history, distinct from raw provider observation timeline.
    // 1.2/20/4-8 — evidence panel keeps attribution/identity visible and does not score truth.
    // 1.2/20/4-9 — candidate links between NEWS and event records; never causal/confirmatory.
    // 1.2/20/4-10 — location snapshot around the selected object's observed coordinates.
    // 1.2/20/4-11 — Uganda view is a filtered lens over the same worldwide records.
    // 1.2/20/4-12 — East Africa lens retains Uganda and global engine ownership.
    // 1.2/20/4-13 — one operational board over persistent canonical WATCH identities.
    // 1.2/20/4-14 — meaningful changes surfaced only for persistent watched identities.
    // 1.2/20/4-15 — operational attention is separate from provider severity and danger claims.
    // 1.2/20/4-16 — searchable identity summary for the exact selected record.
    // 1.2/20/4-17 — factual brief generated from the same current canonical records.
    private String situationBriefIntelligence(Signal signal) {
        RegionalPriorityEngine.Band band=RegionalPriorityEngine.evaluate(signal).band;
        String scope=band==RegionalPriorityEngine.Band.UGANDA?"UGANDA":band==RegionalPriorityEngine.Band.EAST_AFRICA?"EAST_AFRICA":"WORLD";
        SituationBriefGenerator.Brief brief=SituationBriefGenerator.build(scope,layerSignals.values(),canonicalWatchStore,liveChangeRegistry,12);
        StringBuilder out=new StringBuilder("SITUATION BRIEF  •  ").append(scope).append("\n");
        out.append("CURRENT RECORDS  ").append(brief.records).append("\n").append("DISTINCT PROVIDERS  ").append(brief.providers).append("\n");
        out.append("LIVE / FRESH  ").append(brief.liveFresh).append("\n").append("WITH DETECTED CHANGES  ").append(brief.changed).append("\n").append("WATCHED  ").append(brief.watched).append("\n");
        out.append("LAYER SNAPSHOT\n"); for(Map.Entry<Signal.Layer,Integer> e:brief.layers.entrySet())out.append(e.getKey().name()).append("  ").append(e.getValue()).append("\n");
        out.append("LATEST RECORDS\n"); int shown=0; for(Signal r:brief.newest){String provider=r.providerName==null||r.providerName.isEmpty()?r.providerId:r.providerName;out.append(eventTime.format(new Date(r.timestampMs))).append("  •  ").append(r.layer.name()).append("  •  ").append(r.title).append("  •  ").append(provider).append("\n");if(++shown>=6)break;}
        if(brief.records==0)out.append("NO CURRENT RECORDS IN SCOPE\n");
        out.append("RULE  FACTUAL SNAPSHOT • NO PREDICTION • NO UNSOURCED CONCLUSION"); return out.toString();
    }

    private String liveSearchIdentity(Signal signal) {
        if(signal==null)return "LIVE INTELLIGENCE SEARCH  UNAVAILABLE";
        StringBuilder out=new StringBuilder("LIVE INTELLIGENCE SEARCH IDENTITY\n");
        out.append("CANONICAL  ").append(signal.canonicalId).append("\n");
        out.append("NATIVE ID  ").append(signal.id).append("\n");
        out.append("LAYER  ").append(signal.layer.name()).append("\n");
        out.append("PROVIDER  ").append(signal.providerName==null||signal.providerName.isEmpty()?signal.providerId:signal.providerName).append("\n");
        String callsign=signal.facts.get("CALLSIGN");if(callsign!=null&&!callsign.isEmpty())out.append("CALLSIGN  ").append(callsign).append("\n");
        String norad=signal.facts.get("NORAD CATALOG");if(norad!=null&&!norad.isEmpty())out.append("NORAD  ").append(norad).append("\n");
        out.append("RULE  SEARCH RETURNS CURRENT CANONICAL RECORDS • PLACE SEARCH REMAINS FALLBACK");
        return out.toString();
    }

    private String operationalPriorityIntelligence(Signal signal) {
        RegionalPriorityEngine.Result region=RegionalPriorityEngine.evaluate(signal);
        IncidentFormationEngine.Incident incident=IncidentFormationEngine.forObject(
                incidentCandidates,signal==null?null:signal.canonicalId);
        OperationalPriorityEngine.Result p=OperationalPriorityEngine.evaluate(
                signal,canonicalWatchStore,liveChangeRegistry,region,incident);
        StringBuilder out=new StringBuilder("OPERATIONAL PRIORITY\n");
        out.append("ATTENTION BAND  ").append(p.band.name()).append("\n");
        out.append("ATTENTION POINTS  ").append(p.points).append(" / 100\n");
        out.append("SOURCE SEVERITY  ").append(signal==null?"UNKNOWN":signal.severity).append("\n");
        out.append("FACTORS\n");
        for(String reason:p.reasons)out.append("• ").append(reason).append("\n");
        out.append("RULE  PRIORITY ≠ DANGER ≠ CONFIRMATION • SOURCE SEVERITY UNCHANGED");
        return out.toString();
    }

    private String watchChangeIntelligence() {
        List<WatchChangeDetection.Item> items=WatchChangeDetection.build(
                canonicalWatchStore,layerSignals.values(),liveChangeRegistry,20);
        StringBuilder out=new StringBuilder("WATCH CHANGE DETECTION\n");
        out.append("WATCHED OBJECTS WITH CHANGES  ").append(items.size()).append("\n");
        int shown=0;for(WatchChangeDetection.Item item:items){
            String title=item.current==null?item.watch.title:item.current.title;
            String layer=item.current==null?item.watch.layer:item.current.layer.name();
            out.append(eventTime.format(new Date(item.latest.detectedAtMs))).append("  •  ")
                    .append(layer).append("  •  ").append(title).append("\n");
            out.append(item.latest.kind.name()).append("  •  ").append(item.latest.detail)
                    .append("  •  ").append(WatchChangeDetection.state(item))
                    .append("  •  TOTAL ").append(item.totalChanges).append("\n");
            if(++shown>=8)break;
        }
        if(items.isEmpty())out.append("NO MATERIAL WATCHED-OBJECT CHANGE DETECTED YET\n");
        out.append("RULE  CHANGE ≠ ALERT ≠ INCIDENT • WATCHED IDENTITY ONLY");
        return out.toString();
    }

    private String watchlistOperationsIntelligence() {
        WatchlistOperationsBoard.Snapshot snap=WatchlistOperationsBoard.build(
                canonicalWatchStore,layerSignals.values(),liveChangeRegistry,30);
        StringBuilder out=new StringBuilder("WATCHLIST OPERATIONS BOARD\n");
        out.append("TOTAL WATCHED  ").append(snap.total).append("\n");
        out.append("CURRENTLY PRESENT  ").append(snap.present).append("\n");
        out.append("TEMPORARILY MISSING  ").append(snap.missing).append("\n");
        out.append("LIVE / FRESH  ").append(snap.liveFresh).append("\n");
        out.append("WITH CHANGE HISTORY  ").append(snap.changed).append("\n");
        int shown=0;for(WatchlistOperationsBoard.Row row:snap.rows){
            if(row.current!=null){
                out.append(row.current.layer.name()).append("  •  ").append(row.current.title).append("  •  ")
                        .append(row.current.freshness==null?"UNKNOWN":row.current.freshness.state.name())
                        .append("  •  CHANGES ").append(row.changeCount).append("\n");
            }else{
                out.append(row.watch.layer).append("  •  ").append(row.watch.title)
                        .append("  •  LAST WATCHED IDENTITY RETAINED  •  CURRENT RECORD MISSING\n");
            }
            if(++shown>=10)break;
        }
        if(snap.total==0)out.append("NO WATCHED OBJECTS\n");
        out.append("RULE  MISSING ≠ ENDED • WATCH IDENTITY SURVIVES PROVIDER LOSS");
        return out.toString();
    }

    private String eastAfricaOperationsIntelligence() {
        EastAfricaOperationsView.Snapshot snap=EastAfricaOperationsView.build(
                layerSignals.values(),canonicalWatchStore,liveChangeRegistry,40);
        StringBuilder out=new StringBuilder("EAST AFRICA OPERATIONS VIEW\n");
        out.append("CURRENT REGIONAL RECORDS  ").append(snap.records.size()).append("\n");
        out.append("DISTINCT PROVIDERS  ").append(snap.providerCount).append("\n");
        out.append("LIVE / FRESH  ").append(snap.liveFreshCount).append("\n");
        out.append("WATCHED  ").append(snap.watchedCount).append("\n");
        out.append("WITH DETECTED CHANGES  ").append(snap.changeCount).append("\n");
        out.append("COUNTRY / AREA COUNTS\n");
        for(Map.Entry<String,Integer> e:snap.places.entrySet())out.append(e.getKey()).append("  ").append(e.getValue()).append("\n");
        out.append("LAYER COUNTS\n");
        for(Map.Entry<Signal.Layer,Integer> e:snap.layers.entrySet())out.append(e.getKey().name()).append("  ").append(e.getValue()).append("\n");
        out.append("LATEST REGIONAL RECORDS\n");
        int shown=0;for(Signal r:snap.records){
            out.append(r.layer.name()).append("  •  ").append(r.title).append("  •  ")
                    .append(r.freshness==null?"UNKNOWN":r.freshness.state.name()).append("\n");
            if(++shown>=8)break;
        }
        if(snap.records.isEmpty())out.append("NO CURRENT EAST-AFRICA-RELEVANT RECORDS\n");
        out.append("RULE  REGIONAL LENS ≠ SEVERITY • UGANDA + WORLDWIDE MONITORING REMAIN ACTIVE");
        return out.toString();
    }

    private String ugandaOperationsIntelligence() {
        UgandaOperationsView.Snapshot snap=UgandaOperationsView.build(
                layerSignals.values(),canonicalWatchStore,liveChangeRegistry,30);
        StringBuilder out=new StringBuilder("UGANDA OPERATIONS VIEW\n");
        out.append("CURRENT UGANDA RECORDS  ").append(snap.records.size()).append("\n");
        out.append("DISTINCT PROVIDERS  ").append(snap.providerCount).append("\n");
        out.append("LIVE / FRESH  ").append(snap.liveFreshCount).append("\n");
        out.append("WATCHED  ").append(snap.watchedCount).append("\n");
        out.append("WITH DETECTED CHANGES  ").append(snap.changeCount).append("\n");
        for(Map.Entry<Signal.Layer,Integer> e:snap.layers.entrySet())
            out.append(e.getKey().name()).append("  ").append(e.getValue()).append("\n");
        out.append("LATEST UGANDA RECORDS\n");
        int shown=0;
        for(Signal r:snap.records){
            out.append(r.layer.name()).append("  •  ").append(r.title).append("  •  ")
                    .append(r.freshness==null?"UNKNOWN":r.freshness.state.name()).append("\n");
            if(++shown>=8)break;
        }
        if(snap.records.isEmpty())out.append("NO CURRENT UGANDA-RELEVANT RECORDS\n");
        out.append("RULE  REGIONAL VIEW ONLY • WORLDWIDE ENGINE REMAINS ACTIVE");
        return out.toString();
    }

    private String locationIntelligence(Signal signal) {
        StringBuilder out=new StringBuilder("LOCATION INTELLIGENCE\n");
        if(signal==null||!signal.hasLocation()){
            out.append("LOCATION UNAVAILABLE\n");
        }else{
            LocationIntelligence.Snapshot snap=LocationIntelligence.around(
                    signal.latitude,signal.longitude,100d,layerSignals.values(),canonicalWatchStore,20);
            out.append(String.format(Locale.US,"CENTER  %.4f, %.4f\n",snap.latitude,snap.longitude));
            out.append(String.format(Locale.US,"RADIUS  %.0f km\n",snap.radiusKm));
            out.append("CURRENT OBJECTS  ").append(snap.records.size()).append("\n");
            out.append("DISTINCT PROVIDERS  ").append(snap.providerCount).append("\n");
            out.append("WATCHED OBJECTS  ").append(snap.watchedCount).append("\n");
            for(Map.Entry<Signal.Layer,Integer> e:snap.layerCounts.entrySet())
                out.append(e.getKey().name()).append("  ").append(e.getValue()).append("\n");
            out.append("NEAREST RECORDS\n");
            int shown=0;
            for(Signal r:snap.records){
                out.append(r.layer.name()).append("  •  ").append(r.title).append("  •  ")
                        .append(r.freshness==null?"UNKNOWN":r.freshness.state.name()).append("\n");
                if(++shown>=8)break;
            }
        }
        out.append("RULE  LOCATION SNAPSHOT ≠ INCIDENT • CURRENT LOCATED RECORDS ONLY");
        return out.toString();
    }

    private String newsEventLinkIntelligence(Signal signal) {
        StringBuilder out=new StringBuilder("NEWS ↔ EVENT LINKS\n");
        List<NewsEventLinkEngine.Link> links=NewsEventLinkEngine.linksFor(signal,layerSignals.values(),6);
        out.append("CANDIDATE LINKS  ").append(links.size()).append("\n");
        for(NewsEventLinkEngine.Link link:links){
            out.append(link.basis.name()).append("  •  NEWS: ").append(link.news.title)
                    .append("  ↔  EVENT: ").append(link.event.title);
            if(Double.isFinite(link.distanceKm))
                out.append(String.format(Locale.US,"  •  %.1f km",link.distanceKm));
            out.append("  •  ΔT ").append(Math.max(0L,link.timeDeltaMs/60000L)).append(" min\n");
        }
        if(links.isEmpty())out.append("NO CONSERVATIVE NEWS/EVENT LINK CANDIDATE\n");
        out.append("RULE  LINK ≠ CAUSATION ≠ CORROBORATION ≠ CONFIRMATION");
        return out.toString();
    }

    private String crossSourceEvidenceIntelligence(Signal signal) {
        StringBuilder out=new StringBuilder("CROSS-SOURCE EVIDENCE\n");
        if(signal==null){
            out.append("UNAVAILABLE\n");
        }else{
            List<Signal> related=relationshipRegistry.relatedTo(signal);
            List<CrossSourceEvidencePanel.Evidence> evidence=CrossSourceEvidencePanel.build(signal,related,8);
            out.append("INDEPENDENT RECORDS  ").append(evidence.size()).append("\n");
            out.append("DISTINCT PROVIDERS  ").append(CrossSourceEvidencePanel.distinctProviders(evidence)).append("\n");
            out.append("DISTINCT LAYERS  ").append(CrossSourceEvidencePanel.distinctLayers(evidence)).append("\n");
            for(CrossSourceEvidencePanel.Evidence e:evidence){
                Signal r=e.signal;
                String provider=r.providerName==null||r.providerName.isEmpty()?r.providerId:r.providerName;
                String fresh=r.freshness==null?"UNKNOWN":r.freshness.state.name();
                out.append(e.role.name()).append("  •  ").append(r.layer.name()).append("  •  ")
                        .append(provider).append("  •  ").append(fresh).append("  •  ").append(r.title).append("\n");
            }
        }
        out.append("RULE  RELATED EVIDENCE ≠ CORROBORATION ≠ CONFIRMATION • NO TRUTH SCORE");
        return out.toString();
    }

    private String liveChangeTimelineIntelligence(Signal signal) {
        StringBuilder out=new StringBuilder("LIVE CHANGE TIMELINE\n");
        if(signal==null||signal.canonicalId==null){
            out.append("UNAVAILABLE\n");
        }else{
            List<LiveChangeTimeline.Entry> entries=LiveChangeTimeline.forObject(
                    liveChangeRegistry,signal.canonicalId,12);
            out.append("SUMMARY  ").append(LiveChangeTimeline.transitionSummary(entries)).append("\n");
            int shown=0;
            for(LiveChangeTimeline.Entry e:entries){
                out.append(eventTime.format(new Date(e.detectedAtMs))).append("  •  ")
                        .append(e.kind.name()).append("  •  ").append(e.detail).append("\n");
                if(++shown>=8)break;
            }
            if(entries.isEmpty())out.append("NO MATERIAL CHANGE DETECTED YET\n");
        }
        out.append("RULE  CHANGE HISTORY ≠ RAW OBSERVATION HISTORY • NO PREDICTION");
        return out.toString();
    }

    private String proximityIntelligence(Signal signal) {
        StringBuilder out=new StringBuilder("PROXIMITY INTELLIGENCE\n");
        if(signal==null||!signal.hasLocation()){
            out.append("LOCATION UNAVAILABLE\n");
        }else{
            List<ProximityIntelligence.Nearby> nearby=ProximityIntelligence.around(
                    signal,layerSignals.values(),150d,8);
            out.append("RADIUS  150 km\n");
            out.append("NEARBY OBJECTS  ").append(nearby.size()).append("\n");
            for(ProximityIntelligence.Nearby n:nearby){
                String provider=n.signal.providerName==null||n.signal.providerName.isEmpty()?n.signal.providerId:n.signal.providerName;
                out.append(String.format(Locale.US,"%s  •  %.1f km %s / %.0f°  •  %s  •  %s\n",
                        n.signal.layer.name(),n.distanceKm,n.direction,n.bearingDeg,n.signal.title,provider));
            }
            if(nearby.isEmpty())out.append("NO CURRENT LOCATED OBJECTS WITHIN RADIUS\n");
        }
        out.append("RULE  PROXIMITY ≠ RELATIONSHIP ≠ INCIDENT • CURRENT LOCATED RECORDS ONLY");
        return out.toString();
    }

    private String regionalPriorityIntelligence(Signal signal) {
        RegionalPriorityEngine.Result r=RegionalPriorityEngine.evaluate(signal);
        StringBuilder out=new StringBuilder("REGIONAL PRIORITY\n");
        out.append("BAND  ").append(r.band.name()).append("\n");
        out.append("RELEVANCE  ").append(r.relevance).append(" / 100\n");
        out.append("BASIS  ").append(r.reason).append("\n");
        out.append("SOURCE SEVERITY  ").append(signal==null?"UNKNOWN":signal.severity).append("\n");
        out.append("RULE  RELEVANCE ≠ SEVERITY • NO SOURCE RECORD IS REWRITTEN");
        return out.toString();
    }

    private String incidentFormationIntelligence(Signal signal) {
        IncidentFormationEngine.Incident incident=IncidentFormationEngine.forObject(incidentCandidates,
                signal==null?null:signal.canonicalId);
        StringBuilder out=new StringBuilder("INCIDENT FORMATION\n");
        if(incident==null){out.append("NO RELATED INCIDENT CANDIDATE\n");}
        else{
            out.append("INCIDENT ID  ").append(incident.incidentId).append("\n");
            out.append("STATE  ").append(incident.state.name()).append("\n");
            out.append("INDEPENDENT RECORDS  ").append(incident.records.size()).append("\n");
            out.append("PROVIDERS  ").append(incident.providerCount).append("\n");
            out.append("LAYERS  ").append(incident.layerCount).append("\n");
            out.append(String.format(Locale.US,"OBSERVED SPREAD  %.1f km\n",incident.radiusKm));
            int shown=0;
            for(Signal r:incident.records){
                out.append(r.layer.name()).append(" • ").append(r.title).append(" • ")
                        .append(r.providerName==null||r.providerName.isEmpty()?r.providerId:r.providerName).append("\n");
                if(++shown>=6)break;
            }
        }
        out.append("RULE  INCIDENT CANDIDATE ≠ CONFIRMED INCIDENT • RECORDS REMAIN INDEPENDENT");
        return out.toString();
    }

    private String geographicActivityContext(Signal signal) {
        if(signal==null||!signal.hasLocation())return "GEOGRAPHIC ACTIVITY  UNAVAILABLE";
        GeographicActivityZones.Zone nearest=null;double best=Double.MAX_VALUE;
        for(GeographicActivityZones.Zone z:geographicActivityZones){
            double d=SatelliteMapView.distanceKm(signal.latitude,signal.longitude,z.latitude,z.longitude);
            if(d<best){best=d;nearest=z;}
        }
        StringBuilder out=new StringBuilder("GEOGRAPHIC ACTIVITY ZONE\n");
        if(nearest==null||best>150d){
            out.append("NO CURRENT DENSE ACTIVITY ZONE WITHIN 150 km\n");
        }else{
            out.append(String.format(Locale.US,"ZONE CENTER  %.3f, %.3f\n",nearest.latitude,nearest.longitude));
            out.append(String.format(Locale.US,"DISTANCE TO CENTER  %.1f km\n",best));
            out.append("OBSERVED OBJECTS  ").append(nearest.objectCount).append("\n");
            out.append("ACTIVE LAYERS  ").append(nearest.layerCount).append("\n");
            out.append("DOMINANT LAYER  ").append(nearest.dominantLayer).append("\n");
            out.append(String.format(Locale.US,"OBSERVED RADIUS  %.1f km\n",nearest.radiusKm));
        }
        out.append("RULE  DENSITY ≠ INCIDENT • CURRENT LOCATED RECORDS ONLY");
        return out.toString();
    }

    private String objectMovementIntelligence(Signal signal) {
        if(signal==null||signal.canonicalId==null)return "MOVEMENT INTELLIGENCE  UNAVAILABLE";
        MovementIntelligence.State state=MovementIntelligence.from(
                canonicalTimelineRegistry.timeline(signal.canonicalId));
        StringBuilder out=new StringBuilder("OBJECT MOVEMENT INTELLIGENCE\n");
        if(!state.available){
            out.append("INSUFFICIENT OBSERVED FIXES\n");
        }else{
            out.append(String.format(Locale.US,"DIRECTION  %s / %.0f°\n",state.direction,state.bearingDeg));
            out.append(String.format(Locale.US,"OBSERVED DISPLACEMENT  %.2f km\n",state.distanceKm));
            out.append(String.format(Locale.US,"DERIVED BETWEEN-FIX SPEED  %.1f m/s\n",state.derivedSpeedMps));
            out.append("INTERVAL  ").append(Math.max(1L,state.elapsedMs/1000L)).append(" s\n");
            out.append("FROM  ").append(eventTime.format(new Date(state.fromProviderMs))).append("\n");
            out.append("TO  ").append(eventTime.format(new Date(state.toProviderMs))).append("\n");
        }
        out.append("RULE  TWO OBSERVED PROVIDER FIXES • NO PREDICTED PATH");
        return out.toString();
    }

    private String liveChangeIntelligence(Signal signal) {
        if(signal==null||signal.canonicalId==null)return "LIVE CHANGE  UNAVAILABLE";
        List<LiveChangeRegistry.Change> changes=liveChangeRegistry.changesFor(signal.canonicalId);
        StringBuilder out=new StringBuilder("LIVE CHANGE DETECTION  ").append(changes.size()).append("\n");
        int shown=0;
        for(LiveChangeRegistry.Change c:changes){
            out.append(c.kind.name()).append("  •  ").append(c.detail)
               .append("  •  ").append(eventTime.format(new Date(c.detectedAtMs))).append("\n");
            if(++shown>=6)break;
        }
        if(changes.isEmpty())out.append("NO MATERIAL CHANGE DETECTED YET\n");
        out.append("RULE  CHANGE ≠ INCIDENT • PROVIDER OBSERVATIONS ONLY");
        return out.toString();
    }

    private String watchIntelligence(Signal signal) {
        if (signal == null || signal.canonicalId == null) return "WATCH  UNAVAILABLE";
        CanonicalWatchStore.Watch watch=canonicalWatchStore.read(signal.canonicalId);
        if(watch==null)return "WATCH  OFF\nWATCH ID  "+signal.canonicalId;
        String age=watch.watchedAtMs<=0L?"UNKNOWN":localNewsAge(watch.watchedAtMs);
        return "WATCH  ON\nWATCH ID  "+watch.canonicalId
                +"\nWATCHED  "+age
                +"\nPROVIDER  "+watch.providerId
                +"\nNATIVE RECORD  "+watch.recordId
                +"\nRULE  Canonical watch survives movement, refresh and temporary provider loss";
    }

    private String objectProviderHealth(Signal signal) {
        if (signal == null) return "PROVIDER HEALTH  UNKNOWN";
        FeedStatus status=feedStatuses.get(signal.layer);
        String state=status==null?"CHECKING":status.state.name();
        long checked=status==null?0L:status.updatedAtMs;
        long providerTime=signal.timestampChain==null?signal.timestampMs:signal.timestampChain.providerTimeMs;
        long age=providerTime<=0L?-1L:Math.max(0L,System.currentTimeMillis()-providerTime);
        String provider=signal.providerName==null||signal.providerName.trim().isEmpty()?signal.providerId:signal.providerName;
        StringBuilder out=new StringBuilder("PROVIDER HEALTH\n");
        out.append("PROVIDER  ").append(provider).append("\n");
        out.append("STATE  ").append(state).append("\n");
        out.append("LAST CHECK/UPDATE  ").append(checked>0L?eventTime.format(new Date(checked)):"UNKNOWN").append("\n");
        out.append("LATEST RECORD AGE  ").append(age<0L?"UNKNOWN":ObjectFreshness.evaluate(signal.layer,signal.timestampChain,status,System.currentTimeMillis()).ageText());
        if(signal.layer==Signal.Layer.NEWS){
            NewsSource match=null;
            for(NewsSource source:NewsSourceCatalog.ALL)if(source.id.equals(signal.providerId)){match=source;break;}
            if(match!=null){
                NewsSourceHealth h=NewsSourceHealth.read(this,match);
                out.append("\nF9 SOURCE STATE  ").append(h.state.name());
                out.append("\nF9 LAST SUCCESS  ").append(h.lastSuccessMs>0L?eventTime.format(new Date(h.lastSuccessMs)):"UNKNOWN");
                out.append("\nF9 LAST CHECK  ").append(h.lastCheckedMs>0L?eventTime.format(new Date(h.lastCheckedMs)):"UNKNOWN");
            }
        }
        return out.toString();
    }

    private String objectTimeline(Signal focus) {
        if (focus == null || focus.canonicalId == null) return "";
        List<CanonicalTimelineRegistry.Entry> entries=canonicalTimelineRegistry.timeline(focus.canonicalId);
        StringBuilder out=new StringBuilder("OBJECT TIMELINE  ").append(entries.size()).append("\n");
        int shown=0;
        for(CanonicalTimelineRegistry.Entry e:entries){
            out.append(eventTime.format(new Date(e.providerTimeMs))).append("  •  ")
                    .append(e.state).append("  •  ").append(e.summary).append("\n");
            if(++shown>=8)break;
        }
        if(entries.isEmpty())out.append("No provider observation history retained yet\n");
        out.append("RULE  PROVIDER OBSERVATIONS ONLY • NEWEST FIRST • MAX 24");
        return out.toString();
    }

    private String relatedIntelligence(Signal focus) {
        if (focus == null) return "";
        List<Signal> related=relationshipRegistry.relatedTo(focus);
        StringBuilder out=new StringBuilder("RELATED INTELLIGENCE  ").append(related.size()).append("\n");
        int shown=0;
        for(Signal item:related){
            if(item==null)continue;
            out.append(item.layer.name()).append("  •  ").append(item.title)
                    .append("  •  ").append(item.providerName==null||item.providerName.isEmpty()?item.providerId:item.providerName)
                    .append("\n");
            if(++shown>=6)break;
        }
        if(related.isEmpty())out.append("No related provider records currently indexed\n");
        out.append("RULE  RELATIONSHIP ≠ CONFIRMATION • RECORDS REMAIN INDEPENDENT");
        return out.toString();
    }

    private String weatherFrameIntelligence(WorldDataRepository.RadarFrame frame, int index) {
        FeedStatus status = feedStatuses.get(Signal.Layer.WEATHER);
        if (frame == null) return "WEATHER INTELLIGENCE\nFRAME  UNAVAILABLE\nPROVIDER  RainViewer";
        long ageMs = frame.timestampMs <= 0L ? -1L : Math.max(0L,System.currentTimeMillis()-frame.timestampMs);
        String age = ageMs < 0L ? "UNKNOWN" : Math.max(0L,ageMs/60000L)+" min";
        return "WEATHER INTELLIGENCE\nTYPE  RADAR OBSERVATION/HISTORY FRAME"
                + "\nFRAME  " + String.format(Locale.US,"%02d / %02d",index+1,radarFrames.size())
                + "\nFRAME TIME  " + eventTime.format(new Date(frame.timestampMs))
                + "\nFRAME AGE  " + age
                + "\nPROVIDER  RainViewer"
                + "\nSTATE  " + (status == null ? "UNKNOWN" : status.state.name())
                + "\nANIMATION  " + (mapView.isRadarAnimationPlaying() ? "PLAYING" : "PAUSED")
                + "\nDATA RULE  Historical radar frame — not a forecast or ground-impact report";
    }

    private String orbitIntelligence(Signal signal) {
        if (signal == null || signal.layer != Signal.Layer.SATELLITES) return "";
        Map<String,String> f = signal.nativePayload == null ? signal.facts : signal.nativePayload.facts;
        StringBuilder out = new StringBuilder("ORBIT INTELLIGENCE\n");
        String[] keys = {"NORAD CATALOG","OBJECT ID","OBJECT TYPE","CELESTRAK GROUP","ELEMENT EPOCH",
                "ELEMENT AGE","CALCULATED AT","ALTITUDE ESTIMATE","ORBITAL SPEED ESTIMATE",
                "ORBIT PERIOD","INCLINATION","MODEL"};
        for (String key : keys) {
            String value=f.get(key);
            if(value!=null&&!value.trim().isEmpty()) out.append(key).append("  ").append(value).append("\n");
        }
        out.append("POSITION ORIGIN  ").append(signal.coordinateProvenance == null
                ? "UNAVAILABLE" : signal.coordinateProvenance.origin.name()).append("\n");
        out.append("PROVIDER  ").append(signal.providerName == null || signal.providerName.isEmpty()
                ? signal.providerId : signal.providerName).append("\n");
        out.append("DISCLOSURE  CALCULATED FROM PUBLIC ELEMENTS — NOT LIVE TELEMETRY");
        return out.toString();
    }

    private String naturalEventIntelligence(Signal signal) {
        if (signal == null || signal.layer != Signal.Layer.NATURAL) return "";
        Map<String,String> f = signal.nativePayload == null ? signal.facts : signal.nativePayload.facts;
        StringBuilder out = new StringBuilder("EVENT INTELLIGENCE\n");
        String[] keys = {"MAGNITUDE","DEPTH","FELT REPORTS","ALERT","CATEGORY","STATUS","EVENT ID"};
        for (String key : keys) {
            String value=f.get(key);
            if (value!=null&&!value.trim().isEmpty()) out.append(key).append("  ").append(value).append("\n");
        }
        out.append("LOCATION  ").append(signal.region == null || signal.region.isEmpty() ? "Not reported" : signal.region).append("\n");
        out.append("EVENT TIME  ").append(eventTime.format(new Date(signal.timestampMs))).append("\n");
        out.append("FRESHNESS  ").append(signal.freshness == null ? "UNKNOWN" : signal.freshness.state.name()).append("\n");
        out.append("PROVIDER  ").append(signal.providerName == null || signal.providerName.isEmpty() ? signal.providerId : signal.providerName).append("\n");
        out.append("SOURCE RECORD  ").append(signal.originalRecord == null ? signal.id : signal.originalRecord.providerRecordId);
        return out.toString();
    }

    private String aircraftIntelligence(Signal signal) {
        if (signal == null || signal.layer != Signal.Layer.FLIGHTS) return "";
        Map<String,String> f = signal.nativePayload == null ? signal.facts : signal.nativePayload.facts;
        String[] keys = {"CALLSIGN","ICAO24","ORIGIN COUNTRY","ALTITUDE","SPEED","HEADING",
                "VERTICAL RATE","STATE","AIRCRAFT CATEGORY","SQUAWK","POSITION SOURCE","LAST CONTACT"};
        StringBuilder out = new StringBuilder("AIRCRAFT INTELLIGENCE\n");
        for (String key : keys) {
            String value = f.get(key);
            if (value != null && !value.trim().isEmpty()) out.append(key).append("  ").append(value).append("\n");
        }
        long providerTime = signal.timestampChain == null ? signal.timestampMs : signal.timestampChain.providerTimeMs;
        long ageSeconds = Math.max(0L,(currentTimelineMs()-providerTime)/1000L);
        out.append("POSITION AGE  ").append(ageSeconds).append(" s\n");
        out.append("PROVIDER  ").append(signal.providerName == null || signal.providerName.isEmpty()
                ? signal.providerId : signal.providerName).append("\n");
        out.append("OBSERVED TRAIL  ").append(mapView == null ? 0 : mapView.getObservedFixCount(signal))
                .append(" provider fixes\n");
        out.append("TRAIL RULE  Observed provider positions only; no interpolated history\n");
        out.append("DATA RULE  Provider-returned fields only; airline, destination and flight number are not inferred");
        return out.toString();
    }

    private String objectIntelligenceHeader(Signal signal) {
        if (signal == null) return "OBJECT INTELLIGENCE";
        String provider = signal.providerName == null || signal.providerName.trim().isEmpty()
                ? signal.providerId : signal.providerName;
        String recordId = signal.originalRecord == null ? signal.id : signal.originalRecord.providerRecordId;
        String freshness = signal.freshness == null ? "UNKNOWN" : signal.freshness.state.name();
        return signal.layer.name() + "  •  " + signalStateText(signal) + "  •  " + freshness
                + "\nPROVIDER  " + provider + "  •  RECORD  " + recordId;
    }

    private String displayTruthState(Signal signal) {
        return TruthEnforcement.label(signal);
    }

    private void showVesselHistoricalPosition(Signal signal,long observedAtMs,
            double latitude,double longitude) {
        String when=observedAtMs>0L?eventTime.format(new Date(observedAtMs)):"UNKNOWN";
        VesselTelemetry telemetry=VesselTelemetry.from(signal);
        String motion=telemetry==null?"SOG/COG UNKNOWN":telemetry.compactMotion();
        String message="OBSERVED AIS FIX\nTIME  "+when+
                String.format(Locale.US,"\nPOSITION  %.5f, %.5f",latitude,longitude)+
                "\n"+motion+
                "\nHistorical provider observation — not an interpolated or predicted position.";
        new AlertDialog.Builder(this).setTitle("VESSEL HISTORICAL POSITION")
                .setMessage(message)
                .setPositiveButton("CENTER",(dialog,which)->mapView.flyTo(latitude,longitude,Math.max(9d,mapView.getZoom())))
                .setNegativeButton("CLOSE",null).show();
    }

    private void showAircraftHistoricalPosition(Signal signal,long observedAtMs,
            double latitude,double longitude) {
        String when=observedAtMs>0L?eventTime.format(new Date(observedAtMs)):"TIME UNKNOWN";
        String body=String.format(Locale.US,
                "OBSERVED PROVIDER FIX\n%s\n%.5f, %.5f\n\nThis point is historical observation data, not the current interpolated display position.",
                when,latitude,longitude);
        new AlertDialog.Builder(this)
                .setTitle(signal==null?"AIRCRAFT HISTORY":signal.title)
                .setMessage(body)
                .setPositiveButton("CENTER",(d,w)->mapView.flyTo(latitude,longitude,9.0d))
                .setNegativeButton("CLOSE",null).show();
    }

    private void showAisProviderHealth(){
        java.util.List<AisProviderHealthSnapshot> providers=aisMultiProviderIngestor.providerHealthSnapshots(System.currentTimeMillis());
        if(providers.isEmpty()){
            new AlertDialog.Builder(this).setTitle("AIS PROVIDER HEALTH").setMessage("NO AIS PROVIDERS REGISTERED").setPositiveButton("CLOSE",null).show();
            return;
        }
        String[] names=new String[providers.size()];
        for(int i=0;i<providers.size();i++)names[i]=providers.get(i).providerId+" • "+providers.get(i).health+" • "+providers.get(i).freshness;
        new AlertDialog.Builder(this).setTitle("AIS PROVIDER HEALTH").setItems(names,(d,which)->
            new AlertDialog.Builder(this).setTitle(providers.get(which).providerId).setMessage(providers.get(which).text()).setPositiveButton("CLOSE",null).show()
        ).setNegativeButton("CLOSE",null).show();
    }

    private void showAisDiagnostics(){
        AisDiagnosticsSnapshot snapshot=aisMultiProviderIngestor.diagnostics(System.currentTimeMillis());
        new AlertDialog.Builder(this)
                .setTitle("AIS INGESTION DIAGNOSTICS")
                .setMessage(snapshot.text())
                .setPositiveButton("CLOSE",null)
                .show();
    }

    private void showVesselReplayPicker(Signal vessel){
        String[] options={"LIVE","−15 MIN","−30 MIN","−1 HOUR","−3 HOURS","AVAILABLE HISTORY"};
        new AlertDialog.Builder(this).setTitle("VESSEL TIMELINE / REPLAY").setItems(options,(dialog,which)->{
            SatelliteMapView.VesselReplayWindow w=which==0?SatelliteMapView.VesselReplayWindow.LIVE:
                    which==1?SatelliteMapView.VesselReplayWindow.FIFTEEN_MINUTES:
                    which==2?SatelliteMapView.VesselReplayWindow.THIRTY_MINUTES:
                    which==3?SatelliteMapView.VesselReplayWindow.ONE_HOUR:
                    which==4?SatelliteMapView.VesselReplayWindow.THREE_HOURS:
                    SatelliteMapView.VesselReplayWindow.AVAILABLE_HISTORY;
            mapView.setVesselReplay(vessel,w);
            Toast.makeText(this,mapView.vesselReplayStatus(),Toast.LENGTH_LONG).show();showDetail(vessel);
        }).show();
    }

    private void showVesselTrailWindowPicker() {
        String[] options={"15 MIN","30 MIN","1 HOUR","3 HOURS","AVAILABLE HISTORY"};
        new AlertDialog.Builder(this).setTitle("VESSEL AIS TRAIL")
                .setItems(options,(dialog,which)->{
                    SatelliteMapView.VesselTrailWindow w=which==0?SatelliteMapView.VesselTrailWindow.FIFTEEN_MINUTES:
                            which==1?SatelliteMapView.VesselTrailWindow.THIRTY_MINUTES:
                            which==2?SatelliteMapView.VesselTrailWindow.ONE_HOUR:
                            which==3?SatelliteMapView.VesselTrailWindow.THREE_HOURS:
                            SatelliteMapView.VesselTrailWindow.AVAILABLE_HISTORY;
                    mapView.setVesselTrailWindow(w);
                    Toast.makeText(this,"VESSEL TRAIL • "+options[which],Toast.LENGTH_SHORT).show();
                }).show();
    }

    private void showAircraftTrailWindowPicker() {
        String[] options={"5 MIN","15 MIN","30 MIN","AVAILABLE HISTORY"};
        new AlertDialog.Builder(this).setTitle("AIRCRAFT TRAIL").setItems(options,(dialog,which)->{
            SatelliteMapView.AircraftTrailWindow w=which==0?SatelliteMapView.AircraftTrailWindow.FIVE_MINUTES:which==1?SatelliteMapView.AircraftTrailWindow.FIFTEEN_MINUTES:which==2?SatelliteMapView.AircraftTrailWindow.THIRTY_MINUTES:SatelliteMapView.AircraftTrailWindow.AVAILABLE_HISTORY;
            mapView.setAircraftTrailWindow(w);Toast.makeText(this,"AIRCRAFT TRAIL • "+options[which],Toast.LENGTH_SHORT).show();
        }).show();
    }

    private String vesselCompactIntelligence(Signal signal) {
        VesselTelemetry t=VesselTelemetry.from(signal); if(t==null)return "VESSEL TELEMETRY UNKNOWN";
        VesselSpeedIntelligence speed=VesselSpeedIntelligence.from(signal);
        String name=!t.name.isEmpty()?t.name:!t.mmsi.isEmpty()?"MMSI "+t.mmsi:signal.title;
        String type=t.vesselType.isEmpty()?"TYPE UNKNOWN":t.vesselType;
        String nav=t.navigationStatus.isEmpty()?"NAV UNKNOWN":t.navigationStatus;
        String age=t.providerTimestampMs>0L?Math.max(0L,(currentTimelineMs()-t.providerTimestampMs)/1000L)+"s":"UNKNOWN";
        VesselDestinationIntelligence destination=VesselDestinationIntelligence.from(signal);
        String dest=destination.hasDestination()?" • AIS DEST "+destination.normalizedDestination:"";
        return name+" • "+type+" • "+speed.disclosure()+" • "+(t.hasCog()?String.format(Locale.US,"COG %03.0f°",VesselTelemetry.normalize(t.cogDegrees)):"COG UNKNOWN")+" • "+nav+dest+" • AGE "+age+" • "+TruthEnforcement.label(signal);
    }

    private String vesselExpandedIntelligence(Signal signal) {
        VesselTelemetry t=VesselTelemetry.from(signal); if(t==null)return "\nVESSEL INTELLIGENCE 2.0\nTELEMETRY UNKNOWN\n";
        VesselSpeedIntelligence speed=VesselSpeedIntelligence.from(signal);
        VesselOrientation orientation=VesselOrientation.from(signal);
        VesselTurnIntelligence turn=VesselTurnIntelligence.from(signal);
        StringBuilder out=new StringBuilder("\nVESSEL INTELLIGENCE 2.0\n");
        out.append("IDENTITY BASIS  ").append(signal.facts.get("VESSEL ID BASIS")).append("\n");
        out.append("MMSI  ").append(t.mmsi.isEmpty()?"UNKNOWN":t.mmsi).append("\n");
        out.append("IMO  ").append(t.imo.isEmpty()?"UNKNOWN":t.imo).append("\n");
        out.append("NAME  ").append(t.name.isEmpty()?"UNKNOWN":t.name).append("\n");
        out.append("CALLSIGN  ").append(t.callsign.isEmpty()?"UNKNOWN":t.callsign).append("\n");
        out.append("REGISTRATION  ").append(t.registration.isEmpty()?"UNKNOWN":t.registration).append("\n");
        out.append("TYPE  ").append(t.vesselType.isEmpty()?"UNKNOWN":t.vesselType).append("\n");
        out.append("SPEED  ").append(speed.disclosure()).append("\n");        VesselOperationalState operational=VesselOperationalState.from(signal);
        out.append("OPERATIONAL STATE  ").append(operational.disclosure()).append("\n");

        out.append("COG  ").append(t.hasCog()?String.format(Locale.US,"%03.1f°",VesselTelemetry.normalize(t.cogDegrees)):"UNKNOWN").append("\n");
        out.append("HEADING  ").append(t.hasHeading()?String.format(Locale.US,"%03.1f°",VesselTelemetry.normalize(t.headingDegrees)):"UNKNOWN").append("\n");
        out.append("ORIENTATION BASIS  ").append(orientation.basis.name()).append("\n");
        out.append("ROT  ").append(turn.disclosure()).append("\n");
        VesselNavigationStatus navStatus=VesselNavigationStatus.from(signal);
        out.append("AIS NAV STATUS  ").append(navStatus.disclosure()).append("\n");
        out.append("DRAUGHT  ").append(t.hasDraught()?String.format(Locale.US,"%.2f m",t.draughtM):"UNKNOWN").append("\n");
        VesselDestinationIntelligence destination=VesselDestinationIntelligence.from(signal);
        VesselPortProximity nearestPort=VesselPortProximity.nearest(signal,portRegistry.allSignals());
        out.append("DESTINATION  ").append(destination.destinationDisclosure()).append("\n");
        out.append("NEAREST PORT  ").append(nearestPort==null?"UNKNOWN":nearestPort.disclosure()).append("\n");
        out.append("ETA  ").append(destination.etaDisclosure()).append("\n");
        out.append("POSITION  ").append(signal.hasLocation()?String.format(Locale.US,"%.5f, %.5f",signal.latitude,signal.longitude):"UNKNOWN").append("\n");
        out.append("PROVIDER  ").append(t.providerId==null||t.providerId.isEmpty()?"UNKNOWN":t.providerId).append("\n");
        out.append("OBSERVED  ").append(t.providerTimestampMs>0L?eventTime.format(new Date(t.providerTimestampMs)):"UNKNOWN").append("\n");
        ArrayList<Signal> maritimeWeatherRecords=new ArrayList<>();
        if(layerSignals.get(Signal.Layer.WEATHER)!=null)maritimeWeatherRecords.addAll(layerSignals.get(Signal.Layer.WEATHER));
        if(layerSignals.get(Signal.Layer.NATURAL)!=null)maritimeWeatherRecords.addAll(layerSignals.get(Signal.Layer.NATURAL));
        List<MaritimeWeatherContext.Entry> maritimeWeather=MaritimeWeatherContext.nearby(signal,maritimeWeatherRecords,250d);
        out.append("MARITIME WEATHER  ").append(maritimeWeather.isEmpty()?"NONE LOADED WITHIN 250 km":maritimeWeather.get(0).label()).append(" • PROXIMITY ONLY\n");
        List<NearbyVesselIntelligence.Entry> nearby10=NearbyVesselIntelligence.nearby(signal,layerSignals.get(Signal.Layer.SHIPS),10d);
        out.append("NEARBY VESSELS  ").append(nearby10.size()).append(" within 10 km • OBSERVED POSITIONS\n");        if(!nearby10.isEmpty()){
            RelativeVesselGeometry nearestGeometry=RelativeVesselGeometry.between(signal,nearby10.get(0).signal);
            if(nearestGeometry!=null)out.append("NEAREST VESSEL GEOMETRY  ").append(nearestGeometry.disclosure()).append("\n");            VesselCpaTcpa nearestCpa=VesselCpaTcpa.between(signal,nearby10.get(0).signal);
            if(nearestCpa!=null)out.append("CPA/TCPA  ").append(nearestCpa.disclosure()).append("\n");

        }

        out.append("TRAIL  OBSERVED AIS FIXES ONLY\n");        out.append("TIMELINE  ").append(mapView==null?"UNKNOWN":mapView.vesselReplayStatus()).append("\n");        out.append("MARITIME PERFORMANCE  ").append(mapView==null?"UNKNOWN":mapView.getVesselPerformanceModeName()).append("\n");

        out.append("SEARCH  MARITIME SEARCH 2.0 • MMSI/IMO/CALLSIGN/NAME/TYPE/DESTINATION/PORT\n");        out.append("WATCH  ").append(vesselWatchlist!=null&&vesselWatchlist.isWatched(signal)?"WATCHED • "+vesselWatchlist.keyFor(signal):"NOT WATCHED").append("\n");        List<VesselChangeDetector.Change> changes=vesselChangeRegistry.latest(signal,vesselWatchlist);
        out.append("CHANGES  ").append(changes.isEmpty()?"NO NEW MEANINGFUL CHANGE":changes.get(0).label()).append("\n");


        if(mapView!=null&&mapView.isFollowing(signal.canonicalId))
            out.append("CAMERA  ").append(mapView.followModeStatus()).append("\n");

        out.append("TRUTH  ").append(TruthEnforcement.observationDisclosure(signal)).append("\n");        MaritimeReliabilityTruthAudit.Result audit=MaritimeReliabilityTruthAudit.audit(signal);
        out.append("MARITIME RELEASE  ").append(Fix12MaritimeRelease.RELEASE).append(" • ").append(Fix12MaritimeRelease.capabilities().size()).append(" CAPABILITIES\n");        out.append("FIX13.1 AIS INGESTION  MULTI-PROVIDER FOUNDATION • REGISTERED ")
                .append(aisMultiProviderIngestor.providerCount()).append("\n");        out.append("FIX13.2 PROVIDER ADAPTERS  CONFIGURABLE FIELD MAP • ")
                .append(AisCanonicalFields.SUPPORTED.size()).append(" CANONICAL EXTRACTION FIELDS\n");        out.append("FIX13.3 AIS SCHEMA  TYPED PROVIDER-NEUTRAL NORMALIZATION • UNKNOWN NUMERICS=NaN\n");        out.append("FIX13.4 AIS TIME  PROVIDER OBSERVATION / RECEIVE / PROCESSING CLOCKS SEPARATE\n");        out.append("FIX13.5 AIS POSITION  STRICT COORDINATE VALIDATION • IMPLAUSIBLE JUMPS QUARANTINED\n");        out.append("FIX13.6 MMSI  STRICT 9-DIGIT SHIP IDENTITY • MID STRUCTURE • INVALID IDs QUARANTINED\n");        out.append("FIX13.7 IMO  7-DIGIT SHIP IDENTITY • CHECK-DIGIT VERIFIED • INVALID IDs QUARANTINED\n");        out.append("FIX13.8 AIS DEDUP  PROVIDER-SCOPED RECORD-ID + CONTENT DUPLICATES REJECTED BEFORE OBSERVATION\n");        out.append("FIX13.9 AIS ORDER  OUT-OF-ORDER FIXES RETAINED HISTORICALLY • LIVE STATE MONOTONIC\n");
        out.append("FIX13.10 PROVIDER PRIORITY  RANK → PROVIDER TIME → RECEIVE TIME • ALL EVIDENCE RETAINED\n");        out.append("FIX13.11 AIS FUSION  SAME-VESSEL PROVIDER EVIDENCE • FIELD-LEVEL SOURCE PROVENANCE\n");        out.append("FIX13.12 POSITION CONFLICT  CROSS-PROVIDER DISAGREEMENT DETECTION • CONFLICTS NOT AVERAGED\n");        out.append("FIX13.13 SPEED CONFLICT  NEAR-SIMULTANEOUS PROVIDER SOG DISAGREEMENT • ORIGINAL VALUES RETAINED\n");        out.append("FIX13.14 HEADING/COG CONFLICT  CIRCULAR-ANGLE DIFFERENCE • 359°↔1° = 2° • NO AVERAGING\n");        out.append("FIX13.15 SOURCE CONFIDENCE  IDENTITY + FRESHNESS + LOCATION + PROVIDER AGREEMENT • NOT CERTAINTY\n");        out.append("FIX13.16 SOURCE FRESHNESS  LIVE / AGING / STALE / SILENT PER PROVIDER • FUSED HEALTH SEPARATE\n");        out.append("FIX13.17 SOURCE RECOVERY  PROVIDER HEALTH TRANSITIONS • RECOVERY ≠ NEW VESSEL OBSERVATION\n");        out.append("FIX13.18 INGESTION LATENCY  PROVIDER→RECEIVE / RECEIVE→PROCESS / END-TO-END • CLOCK-SKEW AWARE\n");        out.append("FIX13.19 MESSAGE RATE  5-MIN ROLLING PER-PROVIDER THROUGHPUT • CATEGORIES SEPARATE\n");        out.append("FIX13.20 PROVIDER HEALTH  HEALTHY / DEGRADED / UNHEALTHY / UNKNOWN • OPERATIONAL FEED HEALTH ≠ TRUTH\n");        out.append("FIX13.21 QUARANTINE  MALFORMED RECORDS BLOCKED FROM LIVE ENGINE • PROVENANCE/REASON RETAINED\n");        out.append("FIX13.22 FAILURE ISOLATION  PER-PROVIDER CIRCUIT BREAKER • FAILING ADAPTER CANNOT STOP HEALTHY PROVIDERS\n");        out.append("FIX13.23 RAW AIS EVIDENCE  ORIGINAL PROVIDER PAYLOAD PRESERVED BEFORE PARSING • SHA-256 TRACE\n");        out.append("FIX13.24 NORMALIZED EVIDENCE  IMMUTABLE POST-NORMALIZATION / PRE-FUSION RECORD • RAW PAYLOAD SHA LINK\n");        out.append("FIX13.25 PROVENANCE  FIELD-LEVEL RAW→PROVIDER→NORMALIZED→FUSED→DISPLAY TRACE\n");        out.append("FIX13.26 DIAGNOSTICS UI  VESSEL VIEW → AIS DIAGNOSTICS • READ-ONLY OPERATIONAL PANEL\n");        out.append("FIX13.27 PROVIDER HEALTH UI  VESSEL VIEW → PROVIDER HEALTH • DRILL-DOWN PER SOURCE\n");        out.append("FIX13.28 LOAD TEST  MULTI-PROVIDER INGESTION ACCOUNTING + BOUNDED-STATE ACCEPTANCE HARNESS\n");        out.append("FIX13.29 TRUTH AUDIT  RAW→ADAPTER→VALIDATION→NORMALIZATION→FUSION→PROVENANCE INTEGRITY\n");        out.append("FIX13.30 FINAL  ").append(Fix13MultiProviderRelease.RELEASE).append(" • ")
                .append(Fix13MultiProviderRelease.capabilities().size()).append(" MULTI-PROVIDER CAPABILITIES ACCEPTED\n");        out.append("FIX14.1 PORT REGISTRY  SOURCE-BACKED CANONICAL REGISTRY • ")
                .append(portRegistry.size()).append(" PORTS LOADED\n");        out.append("FIX14.2 UN/LOCODE  SOURCE-PROVIDED IDENTITY • ")
                .append(portRegistry.unLocodeCount()).append(" CODES INDEXED • NO INFERENCE\n");
        out.append("FIX14.3 PORT COORDINATES  SOURCE EVIDENCE + ACCURACY + >2km CONFLICT DETECTION • NO AVERAGING\n");        out.append("FIX14.4 COUNTRY/REGION  SOURCE-BACKED METADATA • CANONICAL COUNTRY CHECK • CONFLICTS RETAINED\n");        out.append("FIX14.5 HARBOUR BOUNDARIES  SOURCE POLYGONS • POINT-IN-POLYGON • DISAGREEMENT RETAINED • NO POINT-DERIVED BOUNDARY\n");        out.append("FIX14.6 PORT TERMINALS  CANONICAL TERMINAL ID • PARENT PORT • SOURCE PROVENANCE • SEARCH/LOOKUP\n");        out.append("FIX14.7 ANCHORAGES  CANONICAL ID • SOURCE POINT/POLYGON • PARENT PORT • CONTAINMENT QUERY\n");        out.append("FIX14.8 BERTHS  CANONICAL ID • PORT/TERMINAL PARENTAGE • SOURCE LENGTH/DEPTH • NO CAPACITY INFERENCE\n");        out.append("FIX14.9 PORT APPROACHES  SOURCE CENTERLINE/CORRIDOR • PARENT PORT • NO CALCULATED ROUTE CLAIMED OFFICIAL\n");        out.append("FIX14.10 PORT ENTRANCES  SOURCE POINT/GATE LINE • OPTIONAL WIDTH • STRICT PARENT PORT • NO INFERENCE\n");        out.append("FIX14.11 NAVIGATION CHANNELS  SOURCE CENTERLINE/WIDTH/DEPTH • NO NAVIGABLE-LIMIT INFERENCE\n");        out.append("FIX14.12 PORT RESTRICTIONS  SOURCE TEXT/TIME/AREA/OBJECT • DESCRIPTIVE ONLY • NOT CLEARANCE\n");
        out.append("FIX14.13 DRAUGHT CONTEXT  SOURCE DEPTH/DRAUGHT/UKC • DATUM + VALIDITY • NO SAFE-DRAUGHT INFERENCE\n");        out.append("FIX14.14 PORT WEATHER  OBSERVATION ≠ FORECAST • SOURCE/STATION/TIMES RETAINED • NO SAFETY VERDICT\n");        out.append("FIX14.15 TIDE CONTEXT  OBSERVATION ≠ PREDICTION • DATUM/STATION/WATER LEVEL RETAINED • NO CLEARANCE VERDICT\n");        out.append("FIX14.16 NEARBY VESSELS  DISTANCE-SORTED AIS • NEARBY / HARBOUR / ANCHORAGE STATES • NO PORT-CALL INFERENCE\n");        out.append("FIX14.17 APPROACHING VESSELS  DECREASING OBSERVED PORT DISTANCE • RADIAL TREND • NOT ARRIVAL PREDICTION\n");        out.append("FIX14.18 DEPARTING VESSELS  PRIOR INSIDE + EXIT + INCREASING DISTANCE • EVIDENCE ONLY, NOT VOYAGE CONFIRMATION\n");        out.append("FIX14.19 ANCHORED VESSELS  SOURCED ANCHORAGE + ≤0.5m/s + ≤150m OBSERVED DISPLACEMENT • EVIDENCE ONLY\n");        out.append("FIX14.20 LIVE TRAFFIC COUNTERS  UNIQUE = NEARBY + HARBOUR + ANCHORAGE • BEHAVIOR EVIDENCE DOES NOT INFLATE TOTAL\n");        out.append("FIX14.21 HISTORICAL TRAFFIC  ≤720 OBSERVED SNAPSHOTS/PORT • RANGE + NEAREST LOOKUP • NO INVENTED PAST\n");        out.append("FIX14.22 DESTINATION MATCH  EXACT LOCODE/NAME + NORMALIZED/FUZZY CANDIDATE • CONFIDENCE DISCLOSED • NOT INTENT\n");        out.append("FIX14.23 GLOBAL PORT SEARCH  LOADED REGISTRY CONTENT • MATCH FIELD DISCLOSED • NO FALSE GLOBAL-COVERAGE CLAIM\n");        out.append("FIX14.24 PORT FOLLOW  FOLLOW/UNFOLLOW CANONICAL PORTS • STATE COUNT • MONITORING TARGET, NOT DATA GENERATOR\n");        out.append("FIX14.25 PORT OVERVIEW CAMERA  CANONICAL LAT/LON • 18km OVERVIEW • 45° PITCH • NON-MUTATING TARGET\n");        out.append("FIX14.26 PORT INTELLIGENCE SHEET  IDENTITY + INFRASTRUCTURE + RESTRICTIONS + WEATHER/TIDE + TRAFFIC • MISSING STAYS MISSING\n");        out.append("FIX14.27 PORT SHARE CARDS  SOURCE-AWARE FACTS • OBSERVATION/FORECAST LABELS • MISSING DATA OMITTED\n");        out.append("FIX14.28 LOAD ACCEPTANCE  10K PORTS • 250K EVENTS • ACCOUNTING + BOUNDED HISTORY • SYNTHETIC HARNESS\n");        out.append("FIX14.29 TRUTH/PROVENANCE AUDIT  22 CONTRACTS • NO SILENT SOURCE→INFERENCE PROMOTION\n");        out.append("FIX14.30 FINAL  ").append(Fix14GlobalPortRelease.RELEASE).append(" • ")
                .append(Fix14GlobalPortRelease.capabilities().size()).append(" GLOBAL PORT/HARBOUR CAPABILITIES ACCEPTED\n");

























































        out.append("MARITIME AUDIT  ").append(audit.summary()).append("\n");
        if(!audit.pass)out.append("AUDIT FAILURES  ").append(String.join(" | ",audit.failures)).append("\n");

        return out.toString();
    }

    private String aircraftCompactIntelligence(Signal signal) {
        AircraftTelemetry t=AircraftTelemetry.from(signal);
        if(t==null)return "";
        AircraftAltitudeIntelligence alt=AircraftAltitudeIntelligence.from(signal);
        AircraftOrientation orientation=AircraftOrientation.from(signal);
        String identity=!t.callsign.isEmpty()?t.callsign:!t.registration.isEmpty()?t.registration:
                !t.icao24.isEmpty()?t.icao24:"AIRCRAFT";
        String speed=t.hasSpeed()?String.format(Locale.US,"%.0f kt",t.groundSpeedMps*1.943844d):"SPD UNKNOWN";
        String direction=orientation.known()?String.format(Locale.US,"%03.0f° %s",
                orientation.degrees,orientation.basis.name().replace('_',' ')):"DIR UNKNOWN";
        String age=signal.freshness==null?"AGE UNKNOWN":signal.freshness.ageText();
        AircraftRouteIntelligence route=AircraftRouteIntelligence.from(signal);
        String routeText=route.known()?" • "+route.compact():"";
        return identity+" • "+alt.compact()+" • "+speed+" • "+direction+" • "+age+
                " • "+TruthEnforcement.label(signal)+routeText;
    }

    private String aircraftExpandedIntelligence(Signal signal) {
        AircraftTelemetry t=AircraftTelemetry.from(signal);
        if(t==null)return "";
        AircraftAltitudeIntelligence alt=AircraftAltitudeIntelligence.from(signal);
        AircraftOrientation o=AircraftOrientation.from(signal);
        StringBuilder out=new StringBuilder();
        out.append("\n\nAIRCRAFT TELEMETRY\n");
        out.append("IDENTITY BASIS  ").append(signal.facts.get("AIRCRAFT ID BASIS")).append("\n");        out.append("WATCHLIST  ").append(aircraftWatchlist!=null&&aircraftWatchlist.isWatched(signal)?"WATCHED":"NOT WATCHED").append("\n");

        out.append("ICAO24  ").append(t.icao24.isEmpty()?"UNKNOWN":t.icao24).append("\n");
        out.append("REGISTRATION  ").append(t.registration.isEmpty()?"UNKNOWN":t.registration).append("\n");
        out.append("CALLSIGN  ").append(t.callsign.isEmpty()?"UNKNOWN":t.callsign).append("\n");
        out.append("FLIGHT NUMBER  ").append(t.flightNumber.isEmpty()?"UNKNOWN":t.flightNumber).append("\n");
        out.append("AIRCRAFT TYPE  ").append(t.aircraftType.isEmpty()?"UNKNOWN":t.aircraftType).append("\n");
        out.append("SQUAWK  ").append(t.squawk.isEmpty()?"UNKNOWN":t.squawk).append("\n");
        AircraftRouteIntelligence route=AircraftRouteIntelligence.from(signal);
        out.append("ROUTE  ").append(route.compact()).append("\n");
        out.append("ROUTE BASIS  ").append(route.basis.name()).append("\n");
        if(!route.evidence.isEmpty()) out.append("ROUTE EVIDENCE  ").append(route.evidence).append("\n");
        out.append("ALTITUDE  ").append(alt.dualAltitude()).append("\n");
        out.append("VERTICAL STATE  ").append(signal.facts.get("VERTICAL MOVEMENT DETAIL")).append("\n");
        AircraftFlightPhase phase=AircraftFlightPhase.from(signal);
        out.append("FLIGHT PHASE  ").append(phase.disclosure()).append("\n");        String meaningful=signal.facts.get("MEANINGFUL CHANGES");
        if(meaningful!=null&&!meaningful.trim().isEmpty())out.append("CHANGES  ").append(meaningful).append("\n");

        out.append("GROUND SPEED  ").append(t.hasSpeed()?String.format(Locale.US,"%.1f m/s • %.0f kt",
                t.groundSpeedMps,t.groundSpeedMps*1.943844d):"UNKNOWN").append("\n");
        out.append("TRACK  ").append(t.hasTrack()?String.format(Locale.US,"%.1f°",t.trackDegrees):"UNKNOWN").append("\n");
        out.append("ORIENTATION  ").append(o.known()?String.format(Locale.US,"%.1f° • %s",o.degrees,o.basis.name()):"UNKNOWN").append("\n");
        out.append("ON GROUND  ").append(t.onGround==null?"UNKNOWN":t.onGround?"TRUE":"FALSE").append("\n");
        out.append("PROVIDER TIME  ").append(t.providerTimestampMs>0L?eventTime.format(new Date(t.providerTimestampMs)):"UNKNOWN").append("\n");
        out.append("PROVIDER  ").append(t.providerId==null||t.providerId.isEmpty()?"UNKNOWN":t.providerId).append("\n");
        List<AircraftWeatherContext.Entry> weatherContext=AircraftWeatherContext.nearby(
                signal,loadedWeatherContextRecords(),500d);
        out.append("WEATHER CONTEXT  ").append(weatherContext.size())
                .append(" loaded records within 500 km • PROXIMITY ONLY\n");
        if(!weatherContext.isEmpty()) out.append("NEAREST WEATHER  ")
                .append(weatherContext.get(0).label()).append("\n");
        List<AircraftAirspaceContext.Entry> airspaceContext=AircraftAirspaceContext.nearby(
                signal,layerSignals.get(Signal.Layer.AIRSPACE),250d);
        out.append("AIRSPACE CONTEXT  ").append(airspaceContext.size())
                .append(" loaded records within 250 km • PROXIMITY ONLY\n");
        if(!airspaceContext.isEmpty()) out.append("NEAREST AIRSPACE  ")
                .append(airspaceContext.get(0).label()).append("\n");
        AircraftAirportProximity proximity=AircraftAirportProximity.nearest(signal,airportRegistry.allSignals());
        if(proximity!=null){
            out.append("NEAREST AIRPORT  ").append(proximity.compact()).append("\n");
            out.append("AIRPORT CONTEXT  geometric proximity only — not a landing/approach claim\n");
        } else {
            out.append("NEAREST AIRPORT  UNKNOWN\n");
        }
        if(mapView!=null && mapView.isFollowing(signal.canonicalId))
            out.append("CAMERA  ").append(mapView.followModeStatus()).append("\n");        if(mapView!=null) out.append("TIMELINE  ").append(mapView.isAircraftReplayActive(signal)
                ? mapView.aircraftReplayStatus()+" • HISTORICAL OBSERVED POSITION":"LIVE").append("\n");

        out.append("AIRCRAFT RENDER  ").append(mapView==null?"UNKNOWN":
                mapView.getAircraftPerformanceModeName()+" • "+mapView.getRenderedAircraftCount()+" DRAWN").append("\n");        out.append("RELIABILITY  ").append(AircraftReliabilityTruthAudit.summary(signal)).append("\n");

        out.append("OBSERVATION  ").append(TruthEnforcement.observationDisclosure(signal));
        return out.toString();
    }

    private void showNearbyAircraftRadius(Signal aircraft) {
        String[] options={"10 KM","25 KM","50 KM","100 KM"};
        double[] radii={10d,25d,50d,100d};
        new AlertDialog.Builder(this).setTitle("NEARBY AIRCRAFT").setItems(options,(dialog,which)->
                showNearbyAircraft(aircraft,radii[which])).show();
    }

    private void showNearbyAircraft(Signal aircraft,double radiusKm) {
        List<Signal> flights=layerSignals.get(Signal.Layer.FLIGHTS);
        List<NearbyAircraftIntelligence.Entry> nearby=
                NearbyAircraftIntelligence.find(aircraft,flights,radiusKm);
        if(nearby.isEmpty()){
            Toast.makeText(this,String.format(Locale.US,
                    "No loaded aircraft within %.0f km",radiusKm),Toast.LENGTH_LONG).show();
            return;
        }
        int limit=Math.min(20,nearby.size());
        String[] labels=new String[limit];
        for(int i=0;i<limit;i++)labels[i]=nearby.get(i).label();
        new AlertDialog.Builder(this)
                .setTitle(String.format(Locale.US,"NEARBY AIRCRAFT • %.0f KM",radiusKm))
                .setItems(labels,(dialog,which)->{
                    NearbyAircraftIntelligence.Entry entry=nearby.get(which);
                    String detail=entry.geometry==null?"GEOMETRY UNKNOWN":entry.geometry.disclosure();
                    new AlertDialog.Builder(this).setTitle("RELATIVE AIRCRAFT GEOMETRY").setMessage(detail)
                            .setPositiveButton("OPEN AIRCRAFT",(d,w)->navigateToSearchObject(entry.signal))
                            .setNegativeButton("CLOSE",null).show();
                })
                .show();
    }

    private void showAircraftAirspaceContext(Signal aircraft) {
        List<Signal> source=layerSignals.get(Signal.Layer.AIRSPACE);
        List<AircraftAirspaceContext.Entry> entries=AircraftAirspaceContext.nearby(aircraft,source,250d);
        if(entries.isEmpty()){
            Toast.makeText(this,"No loaded airspace context within 250 km",Toast.LENGTH_LONG).show();return;
        }
        int limit=Math.min(20,entries.size());String[] labels=new String[limit];
        for(int i=0;i<limit;i++)labels[i]=entries.get(i).label();
        new AlertDialog.Builder(this).setTitle("AIRSPACE CONTEXT • 250 KM")
                .setMessage("Geographic proximity only — not a claim that the aircraft entered, violated, or is affected by the airspace.")
                .setItems(labels,(dialog,which)->navigateToSearchObject(entries.get(which).signal)).show();
    }

    private List<Signal> loadedWeatherContextRecords() {
        ArrayList<Signal> all=new ArrayList<>();
        List<Signal> natural=layerSignals.get(Signal.Layer.NATURAL);
        if(natural!=null)for(Signal s:natural){
            String type=(String.valueOf(s.facts.get("WEATHER TYPE"))+" "+String.valueOf(s.facts.get("TYPE"))+" "+s.title).toUpperCase(Locale.ROOT);
            if(type.contains("WEATHER")||type.contains("STORM")||type.contains("CYCLONE")||type.contains("RAIN")||type.contains("WIND")||type.contains("METAR"))all.add(s);
        }
        return all;
    }

    private void showAircraftWeatherContext(Signal aircraft) {
        List<AircraftWeatherContext.Entry> entries=AircraftWeatherContext.nearby(
                aircraft,loadedWeatherContextRecords(),500d);
        if(entries.isEmpty()){
            Toast.makeText(this,"No loaded weather-context records within 500 km",Toast.LENGTH_LONG).show();return;
        }
        int limit=Math.min(20,entries.size());String[] labels=new String[limit];
        for(int i=0;i<limit;i++)labels[i]=entries.get(i).label();
        new AlertDialog.Builder(this).setTitle("WEATHER CONTEXT • 500 KM")
                .setMessage("Source-backed geographic context only — proximity does not prove the aircraft is inside hazardous weather.")
                .setItems(labels,(dialog,which)->navigateToSearchObject(entries.get(which).signal)).show();
    }

    private void showWatchedAircraft() {
        List<Signal> resolved=aircraftWatchlist.resolve(layerSignals.get(Signal.Layer.FLIGHTS));
        if(resolved.isEmpty()){
            Toast.makeText(this,"No watched aircraft currently resolved in loaded data",Toast.LENGTH_LONG).show();return;
        }
        int limit=Math.min(30,resolved.size());String[] labels=new String[limit];
        for(int i=0;i<limit;i++)labels[i]=aircraftCompactIntelligence(resolved.get(i));
        new AlertDialog.Builder(this).setTitle("WATCHED AIRCRAFT")
                .setItems(labels,(dialog,which)->navigateToSearchObject(resolved.get(which))).show();
    }

    private void showAircraftReplayPicker(Signal aircraft) {
        String[] options={"LIVE","-5 MIN","-15 MIN","-30 MIN","AVAILABLE HISTORY"};
        new AlertDialog.Builder(this).setTitle("AIRCRAFT TIMELINE / REPLAY")
                .setItems(options,(dialog,which)->{
                    SatelliteMapView.AircraftReplayWindow w=which==0?SatelliteMapView.AircraftReplayWindow.LIVE:
                            which==1?SatelliteMapView.AircraftReplayWindow.FIVE_MINUTES:
                            which==2?SatelliteMapView.AircraftReplayWindow.FIFTEEN_MINUTES:
                            which==3?SatelliteMapView.AircraftReplayWindow.THIRTY_MINUTES:
                            SatelliteMapView.AircraftReplayWindow.AVAILABLE_HISTORY;
                    mapView.setAircraftReplay(aircraft,w);
                    Toast.makeText(this,mapView.aircraftReplayStatus(),Toast.LENGTH_LONG).show();
                    showDetail(aircraft);
                }).show();
    }

    private void showNearbyVesselRadius(Signal vessel){
        String[] radii={"1 KM","5 KM","10 KM","25 KM","50 KM"};
        double[] values={1d,5d,10d,25d,50d};
        new AlertDialog.Builder(this).setTitle("NEARBY VESSELS").setItems(radii,(dialog,which)->showNearbyVessels(vessel,values[which])).show();
    }

    private void showRelativeVesselGeometry(Signal reference,Signal target){
        RelativeVesselGeometry g=RelativeVesselGeometry.between(reference,target);
        if(g==null){Toast.makeText(this,"Relative vessel geometry unavailable",Toast.LENGTH_SHORT).show();return;}
        String targetName=VesselTelemetry.from(target)!=null&&!VesselTelemetry.from(target).name.isEmpty()
                ?VesselTelemetry.from(target).name:target.title;
        VesselCpaTcpa cpa=VesselCpaTcpa.between(reference,target);
        String cpaText=cpa==null?"CPA/TCPA  UNKNOWN • INSUFFICIENT CURRENT SOG/COG":cpa.disclosure();
        new AlertDialog.Builder(this).setTitle("RELATIVE VESSEL GEOMETRY • "+targetName)
                .setMessage(g.disclosure()+"\n\n"+cpaText)
                .setPositiveButton("OPEN VESSEL",(dialog,which)->navigateToSearchObject(target))
                .setNegativeButton("CLOSE",null).show();
    }

    private void showNearbyVessels(Signal vessel,double radiusKm){
        List<NearbyVesselIntelligence.Entry> entries=NearbyVesselIntelligence.nearby(vessel,layerSignals.get(Signal.Layer.SHIPS),radiusKm);
        if(entries.isEmpty()){Toast.makeText(this,String.format(Locale.US,"No loaded vessels within %.0f km",radiusKm),Toast.LENGTH_LONG).show();return;}
        int limit=Math.min(40,entries.size());String[] labels=new String[limit];
        for(int i=0;i<limit;i++)labels[i]=entries.get(i).label();
        new AlertDialog.Builder(this).setTitle(String.format(Locale.US,"NEARBY VESSELS • %.0f KM",radiusKm))
                .setMessage("Observed vessel positions • nearest first")
                .setItems(labels,(dialog,which)->showRelativeVesselGeometry(vessel,entries.get(which).signal)).show();
    }

    private void showMaritimeWeatherContext(Signal vessel){
        ArrayList<Signal> weatherRecords=new ArrayList<>();
        List<Signal> w=layerSignals.get(Signal.Layer.WEATHER);if(w!=null)weatherRecords.addAll(w);
        List<Signal> n=layerSignals.get(Signal.Layer.NATURAL);if(n!=null)weatherRecords.addAll(n);
        List<MaritimeWeatherContext.Entry> entries=MaritimeWeatherContext.nearby(vessel,weatherRecords,250d);
        if(entries.isEmpty()){Toast.makeText(this,"No loaded source-backed weather within 250 km",Toast.LENGTH_LONG).show();return;}
        int limit=Math.min(30,entries.size());String[] labels=new String[limit];
        for(int i=0;i<limit;i++)labels[i]=entries.get(i).label();
        new AlertDialog.Builder(this).setTitle("MARITIME WEATHER CONTEXT • 250 KM")
                .setMessage("PROXIMITY ONLY • DOES NOT PROVE VESSEL IMPACT")
                .setItems(labels,(dialog,which)->navigateToSearchObject(entries.get(which).signal)).show();
    }

    private void showWatchedVessels(){
        List<Signal> watched=vesselWatchlist==null?Collections.emptyList():vesselWatchlist.resolve(layerSignals.get(Signal.Layer.SHIPS));
        if(watched.isEmpty()){Toast.makeText(this,"No currently loaded watched vessels",Toast.LENGTH_LONG).show();return;}
        String[] labels=new String[watched.size()];
        for(int i=0;i<watched.size();i++){VesselTelemetry t=VesselTelemetry.from(watched.get(i));labels[i]=(t!=null&&!t.name.isEmpty()?t.name:watched.get(i).title)+" • "+vesselWatchlist.keyFor(watched.get(i));}
        new AlertDialog.Builder(this).setTitle("WATCHED VESSELS").setItems(labels,(dialog,which)->navigateToSearchObject(watched.get(which))).show();
    }

    private void showDetail(Signal signal) {
        signal = resolveExactSignal(signal);
        captureDetailReturnState(signal);
        selectedSignal = signal;
        if (mapView != null) mapView.highlightSignal(signal);
        detailExpanded = false;
        detailBadge.setText("● " + displayTruthState(signal) + "  •  "
                + signalStateText(signal) + "  •  SEVERITY "
                + signal.severity + "  •  " + badgeText(signal));
        detailBadge.setTextColor(signalStateColor(signal));
        detailTitle.setText(signal.title);
        detailWatchButton.setText(canonicalWatchStore.watched(signal.canonicalId) ? "WATCHING" : "WATCH");
        detailPanel.setContentDescription("Object Intelligence: " + signal.title);
        StringBuilder body = new StringBuilder();
        body.append(objectIntelligenceHeader(signal)).append("\n");
        if(signal.layer==Signal.Layer.FLIGHTS){
            body.append("AIRCRAFT  ").append(aircraftCompactIntelligence(signal)).append("\n");
        }
        if(signal.layer==Signal.Layer.SHIPS){
            body.append("VESSEL  ").append(vesselCompactIntelligence(signal)).append("\n");
        }
        body.append("OBSERVATION  ").append(TruthEnforcement.observationDisclosure(signal)).append("\n");        PortIntelligence port=PortIntelligence.from(signal);
        if(port!=null){
            body.append("PORT  ").append(port.compact()).append("\n");
            if(!port.terminal.isEmpty())body.append("TERMINAL SOURCE DATA  ").append(port.terminal).append("\n");
            if(!port.anchorage.isEmpty())body.append("ANCHORAGE SOURCE DATA  ").append(port.anchorage).append("\n");
            if(!port.berth.isEmpty())body.append("BERTH SOURCE DATA  ").append(port.berth).append("\n");
            if(!port.weather.isEmpty())body.append("PORT WEATHER SOURCE DATA  ").append(port.weather).append("\n");
            body.append("PORT EVIDENCE  SOURCE-BACKED INFRASTRUCTURE RECORD\n");
        }
        AirportIntelligence airport=AirportIntelligence.from(signal);
        if(airport!=null){
            body.append("AIRPORT  ").append(airport.compact()).append("\n");
            body.append("ICAO  ").append(airport.icao.isEmpty()?"UNKNOWN":airport.icao).append("\n");
            body.append("IATA  ").append(airport.iata.isEmpty()?"UNKNOWN":airport.iata).append("\n");
            if(!airport.runway.isEmpty()) body.append("RUNWAY  ").append(airport.runway).append("\n");
            if(!airport.weather.isEmpty()) body.append("WEATHER SOURCE DATA  ").append(airport.weather).append("\n");
            if(!airport.arrivalsDepartures.isEmpty()) body.append("ARRIVALS/DEPARTURES SOURCE DATA  ").append(airport.arrivalsDepartures).append("\n");
        }

        body.append("CANONICAL  ").append(signal.canonicalId == null ? "" : signal.canonicalId).append("\n");
        if (signal.layer == Signal.Layer.FLIGHTS) body.append("\n").append(aircraftIntelligence(signal)).append("\n");
        if (signal.layer == Signal.Layer.NATURAL) body.append("\n").append(naturalEventIntelligence(signal)).append("\n");
        if (signal.layer == Signal.Layer.SATELLITES) body.append("\n").append(orbitIntelligence(signal)).append("\n");
        RegionalPriorityEngine.Band regionalBand = RegionalPriorityEngine.evaluate(signal).band;
        if (regionalBand == RegionalPriorityEngine.Band.UGANDA)
            body.append("\n").append(ugandaOperationsIntelligence()).append("\n");
        if (regionalBand == RegionalPriorityEngine.Band.UGANDA || regionalBand == RegionalPriorityEngine.Band.EAST_AFRICA)
            body.append("\n").append(eastAfricaOperationsIntelligence()).append("\n");
        body.append("\n").append(locationIntelligence(signal)).append("\n");
        body.append("\n").append(newsEventLinkIntelligence(signal)).append("\n");
        body.append("\n").append(crossSourceEvidenceIntelligence(signal)).append("\n");
        body.append("\n").append(liveChangeTimelineIntelligence(signal)).append("\n");
        body.append("\n").append(situationBriefIntelligence(signal)).append("\n");
        body.append("\n").append(liveSearchIdentity(signal)).append("\n");
        body.append("\n").append(operationalPriorityIntelligence(signal)).append("\n");
        body.append("\n").append(proximityIntelligence(signal)).append("\n");
        body.append("\n").append(regionalPriorityIntelligence(signal)).append("\n");
        body.append("\n").append(incidentFormationIntelligence(signal)).append("\n");
        body.append("\n").append(geographicActivityContext(signal)).append("\n");
        body.append("\n").append(objectMovementIntelligence(signal)).append("\n");
        body.append("\n").append(liveChangeIntelligence(signal)).append("\n");
        body.append("\n").append(watchIntelligence(signal)).append("\n");
        if (signal != null && canonicalWatchStore.watched(signal.canonicalId)) {
            body.append("\n").append(watchChangeIntelligence()).append("\n");
            body.append("\n").append(watchlistOperationsIntelligence()).append("\n");
        }
        body.append("\n").append(objectProviderHealth(signal)).append("\n");
        body.append("\n").append(objectTimeline(signal)).append("\n");
        body.append("\n").append(relatedIntelligence(signal)).append("\n");
        if (!signal.summary.trim().isEmpty()) body.append("\n").append(signal.summary).append("\n\n");
        for (Map.Entry<String, String> fact : signal.facts.entrySet()) {
            body.append(fact.getKey()).append("  ").append(fact.getValue()).append('\n');
        }
        body.append("\nSOURCE  ").append(signal.source)
                .append("\nTIMESTAMP  ").append(eventTime.format(new Date(signal.timestampMs)))
                .append("\nDISPLAY MODE  ").append(replayMode
                        ? "4D REPLAY — acquired frame "
                        + eventTime.format(new Date(replayFrameAtMs))
                        : TruthEnforcement.label(signal))
                .append("\nFEED STATE  ").append(sourceStateText(signal.layer))
                .append("\nSOURCE UPDATE AGE  ").append(sourceAgeText(signal.layer));
        if (signal.layer == Signal.Layer.FLIGHTS || signal.layer == Signal.Layer.SHIPS) {
            long ageSeconds = Math.max(0L,
                    (currentTimelineMs() - signal.timestampMs) / 1000L);
            body.append("\nSOURCE POSITION AGE  ").append(ageSeconds).append(" s")
                    .append("\nTRACK DISPLAY  Observed trail = provider fixes; hollow point = latest fix; linked marker = capped estimate");
        }
        if(signal.layer==Signal.Layer.FLIGHTS) body.append(aircraftExpandedIntelligence(signal));
        if(signal.layer==Signal.Layer.SHIPS) body.append(vesselExpandedIntelligence(signal));
        detailBody.setText(body.toString().trim());
        setDetailExpanded(false);
        selectedSourceUrl = signal.sourceUrl;
        if (signal.layer == Signal.Layer.FLIGHTS || signal.layer == Signal.Layer.SHIPS) {
            sourceButton.setText(mapView.isFollowing(signal.canonicalId)
                    ? "STOP FOLLOWING" : "FOLLOW ON SATELLITE MAP");
        } else if (signal.layer == Signal.Layer.WEBCAMS) {
            sourceButton.setText("VIEW CAMERA IN APP");
        } else if (signal.layer == Signal.Layer.RADIO) {
            sourceButton.setText(signal.id.equals(playingRadioId)
                    ? "STOP PUBLIC RADIO" : "PLAY PUBLIC RADIO");
        } else if (signal.layer == Signal.Layer.TV) {
            sourceButton.setText("WATCH TV IN APP");
        } else if (signal.layer == Signal.Layer.MEDIA) {
            sourceButton.setText(signal.sourceUrl.startsWith("https://")
                    && "AUDIO".equalsIgnoreCase(signal.facts.get("MEDIA TYPE"))
                    ? signal.id.equals(playingRadioId)
                    ? "STOP PUBLIC SAFETY AUDIO" : "PLAY PUBLIC SAFETY AUDIO"
                    : "REFERENCE ONLY");
        } else {
            sourceButton.setText("OPEN ORIGINAL SOURCE");
        }
        boolean traffic = signal.layer == Signal.Layer.FLIGHTS
                || signal.layer == Signal.Layer.SHIPS;
        boolean playableMedia = signal.layer == Signal.Layer.MEDIA
                && selectedSourceUrl.startsWith("https://")
                && "AUDIO".equalsIgnoreCase(signal.facts.get("MEDIA TYPE"));
        sourceButton.setVisibility(traffic || playableMedia
                || !selectedSourceUrl.trim().isEmpty()
                && signal.layer != Signal.Layer.MEDIA ? View.VISIBLE : View.GONE);
        detailPanel.setVisibility(View.VISIBLE);
        detailPanel.bringToFront();
    }

    // 1.2/20/3-4 — update tracked aircraft telemetry in the open sheet without reopening it.
    private void refreshTrackedAircraftSheet(Signal signal) {
        if (signal == null || signal.layer != Signal.Layer.FLIGHTS) return;
        selectedSignal = signal;
        if (mapView != null) mapView.highlightSignal(signal);
        detailExpanded = false;
        detailBadge.setText("● " + displayTruthState(signal) + "  •  "
                + signalStateText(signal) + "  •  SEVERITY "
                + signal.severity + "  •  " + badgeText(signal));
        detailBadge.setTextColor(signalStateColor(signal));
        detailTitle.setText(signal.title);
        StringBuilder body = new StringBuilder();
        body.append(objectIntelligenceHeader(signal)).append("\n")
                .append("CANONICAL  ").append(signal.canonicalId).append("\n\n")
                .append(aircraftIntelligence(signal)).append("\n\n");
        if (!signal.summary.trim().isEmpty()) body.append(signal.summary).append("\n\n");
        for (Map.Entry<String,String> fact : signal.facts.entrySet())
            body.append(fact.getKey()).append("  ").append(fact.getValue()).append('\n');
        body.append("\nTRACK MODE  LIVE CANONICAL FOLLOW")
                .append("\nTRACK ID  ").append(signal.canonicalId);
        detailBody.setText(body.toString().trim());
        sourceButton.setText("STOP FOLLOWING");
    }

    private void updateLayerLabel(Signal.Layer layer, FeedStatus status) {
        CheckBox toggle = layerChecks.get(layer);
        if (toggle == null) return;
        String name;
        switch (layer) {
            case FLIGHTS: name = "FLIGHTS"; break;
            case SHIPS: name = "SHIPS"; break;
            case WEATHER: name = "WEATHER RADAR"; break;
            case AIRSPACE: name = "AVIATION WARNINGS"; break;
            case NATURAL: name = "NATURAL EVENTS"; break;
            case NEWS: name = "BREAKING WIRE"; break;
            case SATELLITES: name = "CALCULATED ORBITS"; break;
            case SPACE_WEATHER: name = "SPACE WEATHER"; break;
            case INFRASTRUCTURE: name = "STRATEGIC REFERENCE"; break;
            case MARKETS: name = "MARKET RADAR"; break;
            case WEBCAMS: name = "WORLD PUBLIC CAMERAS"; break;
            case RADIO: name = "PUBLIC RADIO"; break;
            case TV: name = "PUBLIC TV STREAMS"; break;
            case MEDIA: name = "PUBLIC CALLS / FREQUENCIES"; break;
            default: name = layer.name();
        }
        String state = status.state == FeedStatus.State.KEY_REQUIRED
                ? "KEY NEEDED" : status.state.name();
        toggle.setText(name + "  •  " + status.count + "  " + state);
        toggle.setTextColor(status.state == FeedStatus.State.OFFLINE ? RED
                : status.state == FeedStatus.State.KEY_REQUIRED
                || status.state == FeedStatus.State.DELAYED
                || status.state == FeedStatus.State.CACHED ? AMBER : TEXT);
    }

    private String providerHealthLine(Signal.Layer layer) {
        FeedStatus status = feedStatuses.get(layer);
        if (status == null) return layer.name() + " • UNKNOWN";
        long ageMs = status.updatedAtMs <= 0L ? -1L
                : Math.max(0L, System.currentTimeMillis() - status.updatedAtMs);
        String age = ageMs < 0L ? "age unknown"
                : ageMs < 60_000L ? (ageMs / 1000L) + "s"
                : (ageMs / 60_000L) + "m";
        String message = status.message == null || status.message.trim().isEmpty()
                ? "" : " • " + status.message.trim();
        return String.format(Locale.US, "%s • %s • %,d records • %s%s",
                layer.name(), status.state.name(), status.count, age, message);
    }

    private void showProviderHealth() {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14), dp(10), dp(14), dp(10));
        body.addView(text("PROVIDER HEALTH", TEXT, 14, true));
        body.addView(text("Independent source state • status is not a truth rating",
                MUTED, 9, false), marginParams(0, 2, 0, 10));
        for (Signal.Layer layer : Signal.Layer.values()) {
            TextView line = text(providerHealthLine(layer), providerHealthColor(layer), 9, true);
            line.setPadding(0, dp(4), 0, dp(4));
            body.addView(line);
        }
        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        new AlertDialog.Builder(this)
                .setView(scroll)
                .setNegativeButton("CLOSE", null)
                .setPositiveButton("REFRESH ALL", (dialog, which) -> {
                    if (repository != null) repository.refreshNow();
                }).show();
    }

    private int providerHealthColor(Signal.Layer layer) {
        FeedStatus status = feedStatuses.get(layer);
        if (status == null) return MUTED;
        switch (status.state) {
            case OFFLINE: return RED;
            case KEY_REQUIRED:
            case DELAYED:
            case CACHED: return AMBER;
            case LIVE:
            case READY: return GREEN;
            case LOADING:
            default: return CYAN;
        }
    }

    private void updateProviderHealthButton() {
        if (providerHealthButton == null) return;
        int online = 0, delayed = 0, offline = 0, loading = 0;
        for (FeedStatus status : feedStatuses.values()) {
            if (status == null) continue;
            switch (status.state) {
                case OFFLINE:
                case KEY_REQUIRED: offline++; break;
                case DELAYED:
                case CACHED: delayed++; break;
                case LIVE:
                case READY: online++; break;
                default: loading++;
            }
        }
        providerHealthButton.setText(String.format(Locale.US,
                "SOURCES • %d OK • %d DELAYED • %d OFFLINE%s",
                online, delayed, offline, loading > 0 ? " • " + loading + " LOADING" : ""));
        providerHealthButton.setTextColor(offline > 0 ? RED : delayed > 0 ? AMBER
                : online > 0 ? GREEN : CYAN);
    }

    private ProgressiveLoadStage evaluateProgressiveLoadStage() {
        int resolved=0, withRecords=0, total=0;
        for(Signal.Layer layer:Signal.Layer.values()){
            total++;
            FeedStatus status=feedStatuses.get(layer);
            if(status!=null && status.state!=FeedStatus.State.LOADING) resolved++;
            List<Signal> records=layerSignals.get(layer);
            if(records!=null && !records.isEmpty()) withRecords++;
        }
        loadedLayerCount=withRecords;
        if(resolved==0) progressiveLoadStage=ProgressiveLoadStage.WORLD_READY;
        else if(resolved<Math.max(1,total/2)) progressiveLoadStage=ProgressiveLoadStage.LOADING_SOURCES;
        else if(resolved<total || withRecords==0) progressiveLoadStage=ProgressiveLoadStage.PARTIAL_DATA;
        else progressiveLoadStage=ProgressiveLoadStage.DATA_READY;
        return progressiveLoadStage;
    }

    private String progressiveLoadText() {
        ProgressiveLoadStage stage=evaluateProgressiveLoadStage();
        switch(stage){
            case WORLD_READY:return "WORLD READY";
            case LOADING_SOURCES:return "LOADING SOURCES";
            case PARTIAL_DATA:return "PARTIAL DATA • "+loadedLayerCount+" LAYERS POPULATED";
            case DATA_READY:
            default:return "DATA READY • "+loadedLayerCount+" LAYERS POPULATED";
        }
    }

    private NetworkWorldState evaluateNetworkWorldState() {
        int usable=0, degraded=0, failed=0;
        long newestSuccess=0L;
        for (FeedStatus status : feedStatuses.values()) {
            if (status == null) continue;
            switch (status.state) {
                case LIVE:
                case READY:
                    usable++;
                    newestSuccess=Math.max(newestSuccess,status.updatedAtMs);
                    break;
                case CACHED:
                case DELAYED:
                    degraded++;
                    newestSuccess=Math.max(newestSuccess,status.updatedAtMs);
                    break;
                case OFFLINE:
                case KEY_REQUIRED:
                    failed++;
                    break;
                default:
                    break;
            }
        }
        if(newestSuccess>0L)lastAnyProviderSuccessMs=Math.max(lastAnyProviderSuccessMs,newestSuccess);
        NetworkWorldState next;
        if(usable>0 && failed==0 && degraded==0) next=NetworkWorldState.ONLINE;
        else if(usable>0 || degraded>0) next=NetworkWorldState.DEGRADED;
        else if(failed>0) next=NetworkWorldState.OFFLINE;
        else next=NetworkWorldState.RECOVERING;
        if(next!=networkWorldState){
            networkWorldState=next;
            networkStateChangedMs=System.currentTimeMillis();
        }
        return networkWorldState;
    }

    private String retainedWorldAgeText() {
        if(lastAnyProviderSuccessMs<=0L)return "NO LAST-GOOD TIMESTAMP";
        long age=Math.max(0L,System.currentTimeMillis()-lastAnyProviderSuccessMs);
        if(age<60_000L)return (age/1000L)+"s SINCE PROVIDER UPDATE";
        if(age<3_600_000L)return (age/60_000L)+"m SINCE PROVIDER UPDATE";
        return (age/3_600_000L)+"h SINCE PROVIDER UPDATE";
    }

    private String factualGlobeStatus() {
        int air = count(Signal.Layer.FLIGHTS);
        int sea = count(Signal.Layer.SHIPS);
        int events = count(Signal.Layer.NATURAL) + count(Signal.Layer.NEWS)
                + count(Signal.Layer.AIRSPACE) + count(Signal.Layer.SPACE_WEATHER);
        int cameras = count(Signal.Layer.WEBCAMS);
        int freshFeeds = 0, delayedFeeds = 0, offlineFeeds = 0;
        for (FeedStatus status : feedStatuses.values()) {
            if (status == null) continue;
            if (status.state == FeedStatus.State.OFFLINE
                    || status.state == FeedStatus.State.KEY_REQUIRED) offlineFeeds++;
            else if (status.state == FeedStatus.State.DELAYED
                    || status.state == FeedStatus.State.CACHED) delayedFeeds++;
            else freshFeeds++;
        }
        NetworkWorldState worldState=evaluateNetworkWorldState();
        String state=worldState.name();
        String retained=worldState==NetworkWorldState.ONLINE ? ""
                : "   LAST GOOD " + retainedWorldAgeText();
        return String.format(Locale.US,
                "DU WORLD MONITOR • %s • %s   PERF %s   AIR %,d   SEA %,d   EVENTS %,d   CAM %,d%s",
                state, progressiveLoadText(),
                mapView == null ? "UNKNOWN" : mapView.getPerformanceModeName(),
                air, sea, events, cameras, retained);
    }

    private void updateGlobeStatusStrip() {
        if (globeStatusStrip == null) return;
        String next = factualGlobeStatus();
        if (next.equals(lastGlobeStatus)) return;
        lastGlobeStatus = next;
        globeStatusStrip.animate().cancel();
        globeStatusStrip.setText(next);
        globeStatusStrip.setAlpha(0.62f);
        globeStatusStrip.animate().alpha(1f).setDuration(160L).start();
    }

    private void updateCounters() {
        updateGlobeStatusStrip();
        updateProviderHealthButton();
        int flights = count(Signal.Layer.FLIGHTS);
        int ships = count(Signal.Layer.SHIPS);
        int events = count(Signal.Layer.NATURAL) + count(Signal.Layer.NEWS)
                + count(Signal.Layer.AIRSPACE) + count(Signal.Layer.SPACE_WEATHER);
        int orbits = count(Signal.Layer.SATELLITES);
        int cameras = count(Signal.Layer.WEBCAMS);
        int radio = count(Signal.Layer.RADIO);
        int tv = count(Signal.Layer.TV);
        int markets = count(Signal.Layer.MARKETS);
        String next = String.format(Locale.US,
                "AIR %,d  SEA %,d  EVT %,d  ORBIT %,d  CAM %,d  RADIO %,d  TV %,d  MKT %,d",
                flights, ships, events, orbits, cameras, radio, tv, markets);
        if (next.equals(lastCounterText)) return;
        lastCounterText = next;
        counterText.animate().cancel();
        counterText.setText(next);
        counterText.setAlpha(0.48f);
        counterText.setTranslationY(dp(3));
        counterText.animate().alpha(1f).translationY(0f).setDuration(170L).start();
    }

    /** Keeps the three front-panel indicators meaningful rather than decorative. */
    private void updateSignalBeacons() {
        if (signalBeaconView == null) return;
        int onlineFeeds = 0;
        int offlineFeeds = 0;
        int transitionalFeeds = 0;
        for (FeedStatus status : feedStatuses.values()) {
            if (status == null) continue;
            if (status.state == FeedStatus.State.LIVE
                    || status.state == FeedStatus.State.READY) onlineFeeds++;
            if (status.state == FeedStatus.State.OFFLINE) offlineFeeds++;
            if (status.state == FeedStatus.State.LOADING
                    || status.state == FeedStatus.State.DELAYED
                    || status.state == FeedStatus.State.CACHED
                    || status.state == FeedStatus.State.KEY_REQUIRED) transitionalFeeds++;
        }
        int developing = transitionalFeeds;
        int priority = offlineFeeds;
        Signal.Layer[] eventLayers = {
                Signal.Layer.NEWS, Signal.Layer.NATURAL,
                Signal.Layer.AIRSPACE, Signal.Layer.SPACE_WEATHER
        };
        for (Signal.Layer layer : eventLayers) {
            List<Signal> signals = layerSignals.get(layer);
            if (signals == null) continue;
            for (Signal signal : signals) {
                if (signal.credibility == Signal.Credibility.UNVERIFIED
                        || signal.credibility == Signal.Credibility.REPORTED) developing++;
                if (signal.severity >= 4) priority++;
            }
        }
        signalBeaconView.setCounts(onlineFeeds, developing, priority);
    }

    private void pulseFeedTransition(FeedStatus previous, FeedStatus current) {
        if (signalBeaconView == null || current == null
                || previous != null && previous.state == current.state) return;
        if (current.state == FeedStatus.State.OFFLINE) {
            signalBeaconView.pulse(SignalBeaconView.RED);
        } else if (current.state == FeedStatus.State.LOADING
                || current.state == FeedStatus.State.DELAYED
                || current.state == FeedStatus.State.CACHED
                || current.state == FeedStatus.State.KEY_REQUIRED) {
            signalBeaconView.pulse(SignalBeaconView.AMBER);
        } else {
            signalBeaconView.pulse(SignalBeaconView.GREEN);
        }
    }

    private int count(Signal.Layer layer) {
        FeedStatus status = feedStatuses.get(layer);
        return status == null ? 0 : status.count;
    }

    private String sourceStateText(Signal.Layer layer) {
        LiveOperationsEngine.LayerSnapshot snapshot = operationsEngine.snapshot(layer);
        if (snapshot != null) return snapshot.condition.name();
        FeedStatus status = feedStatuses.get(layer);
        return status == null ? "ACQUIRING" : status.state.name();
    }

    private String sourceAgeText(Signal.Layer layer) {
        LiveOperationsEngine.LayerSnapshot snapshot = operationsEngine.snapshot(layer);
        if (snapshot == null) return "UNKNOWN";
        return LiveOperationsEngine.ageLabel(snapshot.sourceAgeMs).toUpperCase(Locale.ROOT);
    }

    /** Applies stale-record expiry even while a provider is quiet or reconnecting. */
    private void refreshOperationalStates() {
        boolean mapChanged = false;
        EnumMap<Signal.Layer, LiveOperationsEngine.LayerSnapshot> refreshed =
                operationsEngine.refreshAll(System.currentTimeMillis());
        for (Map.Entry<Signal.Layer, LiveOperationsEngine.LayerSnapshot> entry
                : refreshed.entrySet()) {
            Signal.Layer layer = entry.getKey();
            LiveOperationsEngine.LayerSnapshot snapshot = entry.getValue();
            List<Signal> previousSignals = layerSignals.get(layer);
            FeedStatus previousStatus = feedStatuses.get(layer);
            if (previousSignals == null
                    || previousSignals.size() != snapshot.signals.size()) mapChanged = true;
            layerSignals.put(layer, snapshot.signals);
            feedStatuses.put(layer, snapshot.status);
            if (sourceMatrixView != null) sourceMatrixView.update(layer, snapshot);
            updateLayerLabel(layer, snapshot.status);
            pulseFeedTransition(previousStatus, snapshot.status);
        }
        updateCounters();
        updateFeedPulse();
        updateSignalBeacons();
        if (mapChanged) applyFilters();
    }

    private void updateFeedPulse() {
        int loading = 0;
        int offline = 0;
        int live = 0;
        int delayed = 0;
        int keys = 0;
        for (FeedStatus status : feedStatuses.values()) {
            if (status == null) continue;
            if (status.state == FeedStatus.State.LOADING) loading++;
            else if (status.state == FeedStatus.State.DELAYED
                    || status.state == FeedStatus.State.CACHED) delayed++;
            else if (status.state == FeedStatus.State.OFFLINE) offline++;
            else if (status.state == FeedStatus.State.KEY_REQUIRED) keys++;
            else if (status.state == FeedStatus.State.LIVE
                    || status.state == FeedStatus.State.READY) live++;
        }
        if (loading > 0) {
            feedPulse.setText("SOURCE HEALTH / SYNCING  •  " + live + " READY  •  "
                    + loading + " UPDATING");
            feedPulse.setTextColor(AMBER);
        } else if (offline > 0) {
            feedPulse.setText("SOURCE HEALTH / DEGRADED  •  " + live + " READY  •  "
                    + offline + " OFFLINE");
            feedPulse.setTextColor(RED);
        } else if (delayed > 0) {
            feedPulse.setText("SOURCE HEALTH / PARTIAL  •  " + live + " FRESH  •  "
                    + delayed + " DELAYED OR CACHED"
                    + (keys > 0 ? "  •  " + keys + " OPTIONAL KEY" : ""));
            feedPulse.setTextColor(AMBER);
        } else {
            feedPulse.setText("SOURCE HEALTH / OPERATIONAL  •  " + live + " SOURCES READY"
                    + (keys > 0 ? "  •  " + keys + " OPTIONAL KEY" + (keys == 1 ? "" : "S") : ""));
            feedPulse.setTextColor(GREEN);
        }
    }

    private void ingestAcquisitions(List<Signal> signals, FeedStatus status) {
        List<Signal> incoming = new ArrayList<>();
        boolean announce = status != null && (status.state == FeedStatus.State.LIVE
                || status.state == FeedStatus.State.READY);
        int stride = Math.max(1,
                (signals.size() + MAX_ACQUISITION_SCAN - 1) / MAX_ACQUISITION_SCAN);
        for (int index = 0; index < signals.size(); index += stride) {
            Signal signal = signals.get(index);
            boolean directoryRecord = signal.layer == Signal.Layer.WEBCAMS
                    || signal.layer == Signal.Layer.RADIO
                    || signal.layer == Signal.Layer.TV
                    || signal.layer == Signal.Layer.MEDIA
                    || signal.layer == Signal.Layer.SATELLITES;
            String token = directoryRecord ? signal.id : signal.id + "@" + signal.timestampMs;
            if (seenAcquisitions.add(token)) {
                if (announce && isLiveDeskSignal(signal)) {
                    incoming.add(signal);
                    acquisitionCount++;
                }
            }
        }
        while (seenAcquisitions.size() > 20_000) {
            Iterator<String> iterator = seenAcquisitions.iterator();
            if (!iterator.hasNext()) break;
            iterator.next();
            iterator.remove();
        }
        if (incoming.isEmpty()) return;
        Collections.sort(incoming, (first, second) ->
                compareNewestFirst(first.timestampMs, second.timestampMs));
        int limit = Math.min(36, incoming.size());
        for (int index = 0; index < limit; index++) {
            acquisitionQueue.addLast(incoming.get(index));
        }
        while (acquisitionQueue.size() > 48) acquisitionQueue.pollFirst();
        Signal newest = acquisitionQueue.pollFirst();
        if (newest != null) showAcquisition(newest);
    }

    private void showAcquisition(Signal signal) {
        if (acquisitionText == null) return;
        currentAcquisition = signal;
        currentActivityIsAcquisition = true;
        lastFreshAcquisitionAtMs = android.os.SystemClock.uptimeMillis();
        acquisitionText.setText(activityVerb(signal) + " • " + signal.layer.name() + " • "
                + signal.title + " • " + signal.source + " • "
                + utcClock.format(new Date(signal.timestampMs)));
        acquisitionText.setTextColor(signalStateColor(signal));
        runAcquisitionAnimation();
        mapView.highlightSignal(signal);
        mapView.recordActivityPulse(signal, signalStateColor(signal));
        if (signalBeaconView != null) signalBeaconView.pulse(signalChannel(signal));
        updateSideReadouts(activityVerb(signal));
    }

    /** Rotates through real received records between acquisitions; it is labelled TRACKING. */
    private void showTrackedSignal(Signal signal) {
        if (signal == null || acquisitionText == null) return;
        currentAcquisition = signal;
        currentActivityIsAcquisition = false;
        acquisitionText.setText("LIVE TRACK • " + signal.layer.name() + " • "
                + signal.title + " • " + signal.source + " • "
                + utcClock.format(new Date(signal.timestampMs)));
        acquisitionText.setTextColor(layerAccent(signal.layer));
        acquisitionText.setSelected(true);
        acquisitionText.animate().cancel();
        acquisitionText.setAlpha(0.82f);
        acquisitionText.setTranslationX(0f);
        updateSideReadouts("TRACK");
    }

    private Signal nextTrackedSignal() {
        Signal.Layer[] sequence = {
                Signal.Layer.FLIGHTS, Signal.Layer.AIRSPACE, Signal.Layer.NATURAL,
                Signal.Layer.NEWS, Signal.Layer.SHIPS, Signal.Layer.SATELLITES,
                Signal.Layer.SPACE_WEATHER,
                Signal.Layer.WEBCAMS, Signal.Layer.RADIO,
                Signal.Layer.TV, Signal.Layer.MEDIA, Signal.Layer.INFRASTRUCTURE
        };
        for (int attempt = 0; attempt < sequence.length; attempt++) {
            Signal.Layer layer = sequence[Math.floorMod(watchCursor++, sequence.length)];
            if (!Boolean.TRUE.equals(enabled.get(layer))) continue;
            List<Signal> available = layerSignals.get(layer);
            if (available == null || available.isEmpty()) continue;
            int index = Math.floorMod(watchCursor * 31, available.size());
            return available.get(index);
        }
        return null;
    }

    private void showSystemAcquisition(String kind, String source, String timestamp) {
        if (acquisitionText == null) return;
        acquisitionText.setText("ACQUIRED • " + kind + " • " + source + " • " + timestamp);
        acquisitionText.setTextColor(CYAN);
        runAcquisitionAnimation();
        if (signalBeaconView != null) signalBeaconView.pulse(SignalBeaconView.GREEN);
    }

    private void runAcquisitionAnimation() {
        int token = ++acquisitionAnimationToken;
        acquisitionText.animate().cancel();
        acquisitionText.setAlpha(1f);
        acquisitionText.setTranslationX(dp(24));
        acquisitionText.animate().translationX(0f).setDuration(180L).start();
        activityHandler.postDelayed(() -> {
            if (token == acquisitionAnimationToken && acquisitionText != null) {
                acquisitionText.animate().alpha(0.34f).setDuration(220L).start();
            }
        }, 1_250L);
    }

    private void tickActivityGuarded() {
        runUiBoundary("MainActivity.activityTick", this::tickActivityFrame);
    }

    private void tickActivityFrame() {
        if (scanStep % 24 == 0) refreshOperationalStates();
        if ((scanStep & 1) == 0) advanceReplay();
        String[] phases = {"AIR", "SEA", "WIRE", "SEISMIC", "WEATHER", "AIRSPACE",
                "GKG THEMES", "ORBITS", "SPACE", "CAM", "RADIO", "TV", "PUBLIC CALLS",
                "MARKETS", "AIRPORTS", "PORTS", "REFERENCE"};
        String phase = phases[scanStep % phases.length];
        int events = count(Signal.Layer.NATURAL) + count(Signal.Layer.NEWS)
                + count(Signal.Layer.AIRSPACE) + count(Signal.Layer.SPACE_WEATHER);
        telemetryText.setText(String.format(Locale.US,
                "MODE / %s   LENS / %s   WINDOW / %s   SECTOR / %s   CYCLE / %05d   GLOBE / %06.1f°   PACKETS / %,d   FRAMES / %,d   AIR / %,d   SEA / %,d   AIRWX / %,d   EVENTS / %,d   ORBIT / %,d   SPACE / %,d   CAM / %,d   RADIO / %,d   TV / %,d   CALLS / %,d   MARKET / %,d   INFRA / %,d",
                replayMode ? "4D REPLAY" : "OPERATING", regionalFocus.name,
                TIME_WINDOWS[timeWindowIndex], phase,
                Math.floorMod(scanStep, 100_000), mapView.getCenterLongitude(),
                acquisitionCount, replayEngine.frameCount(), count(Signal.Layer.FLIGHTS),
                count(Signal.Layer.SHIPS), count(Signal.Layer.AIRSPACE), events,
                count(Signal.Layer.SATELLITES), count(Signal.Layer.SPACE_WEATHER),
                count(Signal.Layer.WEBCAMS),
                count(Signal.Layer.RADIO), count(Signal.Layer.TV),
                count(Signal.Layer.MEDIA), count(Signal.Layer.MARKETS),
                count(Signal.Layer.INFRASTRUCTURE)));
        if ((scanStep & 1) == 1 && !acquisitionQueue.isEmpty()) {
            Signal next = acquisitionQueue.pollFirst();
            if (next != null) showAcquisition(next);
        } else if (acquisitionQueue.isEmpty() && scanStep % 6 == 0
                && android.os.SystemClock.uptimeMillis() - lastFreshAcquisitionAtMs > 2_400L) {
            showTrackedSignal(nextTrackedSignal());
        }
        // Text and controls stay steady. Only real arrivals trigger the finite coloured
        // pulses; continuous motion lives on the map behind the information surfaces.
        feedPulse.setAlpha(1f);
        if (liveText != null) liveText.setAlpha(1f);
        updateSideReadouts(phase);
        if (scanStep % 8 == 0) updateAnalysisRibbon();
        scanStep++;
        activityHandler.postDelayed(this::tickActivityGuarded, 420L);
    }

    /**
     * Rotates a compact desk readout through real on-device analysis. It deliberately says
     * WATCH/OBSERVED and NOT CONFIRMATION so a busy interface never turns correlation into fact.
     */
    private void updateAnalysisRibbon() {
        if (correlationText == null) return;
        SituationAnalyzer.Brief current = latestBrief;
        if (current != null) renderAnalysisRibbon(current);

        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastAnalysisRequestedMs < ANALYSIS_REFRESH_MS
                || !analysisRunning.compareAndSet(false, true)) {
            return;
        }
        lastAnalysisRequestedMs = now;
        EnumMap<Signal.Layer, List<Signal>> layerSnapshot =
                new EnumMap<>(Signal.Layer.class);
        EnumMap<Signal.Layer, FeedStatus> statusSnapshot =
                new EnumMap<>(Signal.Layer.class);
        layerSnapshot.putAll(layerSignals);
        statusSnapshot.putAll(feedStatuses);
        try {
            analysisExecutor.execute(() -> {
                SituationAnalyzer.Brief calculated = SituationAnalyzer.analyze(
                        layerSnapshot, statusSnapshot, System.currentTimeMillis());
                runOnUiThread(() -> {
                    analysisRunning.set(false);
                    if (destroyed) return;
                    latestBrief = calculated;
                    renderAnalysisRibbon(calculated);
                    if (catalogPanel != null
                            && catalogPanel.getVisibility() == View.VISIBLE
                            && ("BRIEF".equals(catalogCategory)
                            || "ANALYST".equals(catalogCategory)
                            || "RISK".equals(catalogCategory))) {
                        rebuildCatalogPage();
                    }
                });
            });
        } catch (RuntimeException error) {
            analysisRunning.set(false);
            Log.w(LOG_TAG, "Analysis refresh skipped", error);
        }
    }

    private void renderAnalysisRibbon(SituationAnalyzer.Brief brief) {
        if (brief == null || correlationText == null) return;
        if (!brief.domainWatches.isEmpty()
                && (brief.correlations.isEmpty() || Math.floorMod(briefRotationCursor++, 2) == 0)) {
            SituationAnalyzer.DomainWatch watch = brief.domainWatches.get(
                    Math.floorMod(briefRotationCursor, brief.domainWatches.size()));
            correlationText.setText("CROSS-DOMAIN WATCH / "
                    + shortForRail(watch.label, wideLayout ? 108 : 58)
                    + "\nAIR " + watch.aircraftNearby + " ≤500 KM • SEA "
                    + watch.vesselsNearby + " ≤300 KM • PROXIMITY IS NOT CONFIRMATION");
            correlationText.setTextColor(watch.severity >= 4 ? RED : CYAN);
            return;
        }
        if (!brief.correlations.isEmpty()) {
            SituationAnalyzer.Correlation correlation = brief.correlations.get(
                    Math.floorMod(briefRotationCursor++, brief.correlations.size()));
            correlationText.setText("CROSS-SOURCE WATCH / "
                    + shortForRail(correlation.label, wideLayout ? 112 : 62)
                    + "\n" + correlation.recordCount + " RECORDS • "
                    + shortForRail(correlation.sources, wideLayout ? 92 : 50)
                    + " • NOT CONFIRMATION");
            correlationText.setTextColor(correlation.severity >= 4 ? RED : AMBER);
            return;
        }

        List<SituationAnalyzer.RegionalState> observed = new ArrayList<>();
        for (SituationAnalyzer.RegionalState region : brief.regions) {
            if (region.recordCount > 0) observed.add(region);
        }
        if (!observed.isEmpty()) {
            SituationAnalyzer.RegionalState region = observed.get(
                    Math.floorMod(briefRotationCursor++, observed.size()));
            int color = region.observedScore >= 55 ? RED
                    : region.observedScore >= 30 ? AMBER : GREEN;
            correlationText.setText(String.format(Locale.US,
                    "OBSERVED SIGNAL DENSITY / %s %02d/99 • %s\n"
                            + "%,d RECENT RECORDS • %,d PRIORITY • NOT A FORECAST",
                    region.region, region.observedScore, region.level,
                    region.recordCount, region.priorityCount));
            correlationText.setTextColor(color);
            return;
        }

        correlationText.setText(String.format(Locale.US,
                "ANALYSIS DESK / %,d RECORDS • %,d SOURCES READY\n"
                        + "WAITING FOR CROSS-SOURCE ALIGNMENT • NO PREDICTION",
                brief.totalRecords, brief.onlineFeeds));
        correlationText.setTextColor(brief.offlineFeeds > 0 ? AMBER : CYAN);
    }

    private void updateSideReadouts(String phase) {
        if (leftReadout != null) {
            leftReadout.setText(String.format(Locale.US,
                    "%s\n%s • %s\n\nAIR %,d\nSEA %,d\nEVT %,d\nCAM %,d\nMEDIA %,d",
                    shortForRail(regionalFocus.name, 14), phase,
                    TIME_WINDOWS[timeWindowIndex], count(Signal.Layer.FLIGHTS),
                    count(Signal.Layer.SHIPS),
                    count(Signal.Layer.NATURAL) + count(Signal.Layer.NEWS)
                            + count(Signal.Layer.AIRSPACE)
                            + count(Signal.Layer.SPACE_WEATHER),
                    count(Signal.Layer.WEBCAMS),
                    count(Signal.Layer.RADIO) + count(Signal.Layer.TV)));
            leftReadout.setAlpha(1f);
        }
        if (rightReadout != null) {
            Signal signal = currentAcquisition;
            if (signal == null) {
                rightReadout.setText("LATEST / SIGNAL\n\nSCANNING\nPUBLIC SOURCES");
                rightReadout.setTextColor(CYAN);
            } else {
                rightReadout.setText((currentActivityIsAcquisition
                                ? "ACQUIRED" : "TRACK")
                        + "\n" + signal.layer.name() + "  "
                        + utcClock.format(new Date(signal.timestampMs))
                        + "\n\n" + shortForRail(signal.title, 52)
                        + "\n" + shortForRail(signal.source, 30));
                rightReadout.setTextColor(layerAccent(signal.layer));
            }
            rightReadout.setAlpha(1f);
        }
    }

    private String activityVerb(Signal signal) {
        switch (signal.layer) {
            case FLIGHTS:
            case SHIPS: return "TRACK ACQUIRED";
            case AIRSPACE: return "AIRSPACE WARNING ACQUIRED";
            case SATELLITES: return "ORBIT CALCULATED";
            case WEBCAMS: return "CAMERA INDEXED";
            case RADIO: return "STATION INDEXED";
            case TV: return "TV CHANNEL INDEXED";
            case MEDIA: return "REFERENCE READY";
            case SPACE_WEATHER: return "SPACE WEATHER ACQUIRED";
            case INFRASTRUCTURE: return "REFERENCE READY";
            case MARKETS: return "MARKET QUOTE ACQUIRED";
            default: return "SIGNAL ACQUIRED";
        }
    }

    private String shortForRail(String value, int maximum) {
        String clean = value == null ? "" : value.trim().replaceAll("\\s+", " ");
        return clean.length() <= maximum
                ? clean : clean.substring(0, Math.max(1, maximum - 1)) + "…";
    }

    private int layerAccent(Signal.Layer layer) {
        switch (layer) {
            case SHIPS: return GREEN;
            case NATURAL: return AMBER;
            case NEWS: return RED;
            case AIRSPACE: return Color.rgb(225, 158, 61);
            case SATELLITES: return Color.rgb(174, 139, 224);
            case SPACE_WEATHER: return Color.rgb(165, 133, 214);
            case INFRASTRUCTURE: return Color.rgb(111, 130, 143);
            case MARKETS: return Color.rgb(99, 177, 160);
            case WEBCAMS: return GREEN;
            case RADIO: return Color.rgb(143, 124, 171);
            case TV: return Color.rgb(108, 148, 196);
            case MEDIA: return Color.rgb(113, 143, 173);
            case FLIGHTS:
            case WEATHER:
            default: return CYAN;
        }
    }

    private void tickClockGuarded() {
        runUiBoundary("MainActivity.clockTick", this::tickClockFrame);
    }

    private void tickClockFrame() {
        Date now = new Date();
        if (wideLayout) {
            clockText.setText(utcClock.format(now) + "  |  "
                    + localClock.format(now) + " LOCAL");
        } else {
            clockText.setText(utcClock.format(now) + "\n"
                    + localClock.format(now) + " LOCAL");
        }
        clockHandler.postDelayed(this::tickClockGuarded,
                1000L - System.currentTimeMillis() % 1000L);
    }


    // F11 / 20 — COUNTRY LENSES. These never own data: they filter F9 NewsStore records in-place.
    private static final String[] F11_COUNTRIES = {"UGANDA","KENYA","TANZANIA","RWANDA","BURUNDI","DR CONGO","SOUTH SUDAN"};
    private boolean f11CountryMatches(NewsItem n,String country){
        if(n==null||country==null||"ALL".equals(country))return true;
        String r=n.region==null?"":n.region.toUpperCase(Locale.ROOT);
        if("UGANDA".equals(country))return "UGANDA".equals(r)||"KAMPALA".equals(r)||r.endsWith(" UGANDA")||Arrays.asList("CENTRAL UGANDA","EASTERN UGANDA","NORTHERN UGANDA","WESTERN UGANDA","WEST NILE","KARAMOJA").contains(r);
        return country.equals(r);
    }
    private int f11CountryCount(List<NewsItem> items,String country){
        int n=0;for(NewsItem x:items)if(f11CountryMatches(x,country))n++;return n;
    }
    private long f11CountryNewest(List<NewsItem> items,String country){
        long newest=0;for(NewsItem x:items)if(f11CountryMatches(x,country)&&x.publishedAt>newest)newest=x.publishedAt;return newest;
    }
    private View buildF11CountryBar(List<NewsItem> source){
        HorizontalScrollView hs=new HorizontalScrollView(this);LinearLayout row=new LinearLayout(this);
        for(String country:F11_COUNTRIES){
            int count=f11CountryCount(source,country);long newest=f11CountryNewest(source,country);
            String label=(country.equals(f9CountryLens)?"● ":"")+country+" "+count+(newest>0?" · "+localNewsAge(newest):"");
            Button b=compactButton(label);b.setEnabled(!country.equals(f9CountryLens));b.setOnClickListener(v->{f9CountryLens=country;catalogNewsType="UGANDA".equals(country)?"UGANDA":"ALL";f17SaveState();rebuildLocalNewsPage();});row.addView(b);
        }
        hs.addView(row);return hs;
    }

    // F12 / 20 — REPLAY TIME LENS. F9 remains the only NewsStore and chronological owner.
    private static final String[] F12_WINDOWS={"NOW","1H","6H","12H","24H","3D","7D"};
    private long f12WindowMs(String w){if("1H".equals(w))return 3600000L;if("6H".equals(w))return 21600000L;if("12H".equals(w))return 43200000L;if("24H".equals(w))return 86400000L;if("3D".equals(w))return 259200000L;if("7D".equals(w))return 604800000L;return Long.MAX_VALUE;}
    private boolean f12ReplayMatches(NewsItem n){
        if(n==null||"NOW".equals(f12ReplayWindow))return true;
        long stamp=n.publishedAt>0?n.publishedAt:n.firstSeenAt;
        long end=f13ReplayAnchorMs>0?f13ReplayAnchorMs:System.currentTimeMillis();
        long start=end-f12WindowMs(f12ReplayWindow);
        return stamp>0&&stamp<=end&&stamp>=start;
    }
    private View buildF12ReplayBar(){
        HorizontalScrollView hs=new HorizontalScrollView(this);LinearLayout row=new LinearLayout(this);
        Button prev=compactButton("‹ PREVIOUS");prev.setOnClickListener(v->{long step=f12WindowMs(f12ReplayWindow);if(step==Long.MAX_VALUE)step=3600000L;long end=f13ReplayAnchorMs>0?f13ReplayAnchorMs:System.currentTimeMillis();f13ReplayAnchorMs=end-step;f17SaveState();rebuildLocalNewsPage();});row.addView(prev);
        for(String w:F12_WINDOWS){Button b=compactButton((w.equals(f12ReplayWindow)?"● ":"")+w);b.setEnabled(!w.equals(f12ReplayWindow));b.setOnClickListener(v->{f12ReplayWindow=w;f13ReplayAnchorMs=0L;f17SaveState();rebuildLocalNewsPage();});row.addView(b);}
        Button next=compactButton("NEXT ›");next.setEnabled(f13ReplayAnchorMs>0);next.setOnClickListener(v->{long step=f12WindowMs(f12ReplayWindow);if(step==Long.MAX_VALUE)step=3600000L;f13ReplayAnchorMs=Math.min(System.currentTimeMillis(),f13ReplayAnchorMs+step);if(f13ReplayAnchorMs>=System.currentTimeMillis()-1000L)f13ReplayAnchorMs=0L;f17SaveState();rebuildLocalNewsPage();});row.addView(next);
        Button live=compactButton("LIVE");live.setOnClickListener(v->{f13ReplayAnchorMs=0L;f12ReplayWindow="NOW";f17SaveState();rebuildLocalNewsPage();});row.addView(live);
        hs.addView(row);return hs;
    }

    // F14 / 20 — RELATED INTELLIGENCE. F9 NewsStore/cluster records stay canonical.
    private List<NewsItem> f14Related(NewsItem focus){
        ArrayList<NewsItem> out=new ArrayList<>();if(focus==null)return out;
        for(NewsItem n:new NewsStore(this).load()){
            if(n==null||n.id.equals(focus.id))continue;
            boolean sameCluster=focus.clusterId!=null&&!focus.clusterId.isEmpty()&&focus.clusterId.equals(n.clusterId);
            boolean sameRegion=focus.region!=null&&!focus.region.isEmpty()&&focus.region.equalsIgnoreCase(n.region);
            boolean sameTopic=focus.topic!=null&&!focus.topic.isEmpty()&&focus.topic.equalsIgnoreCase(n.topic);
            if(sameCluster||(sameRegion&&sameTopic))out.add(n);
        }
        Collections.sort(out,(a,b)->Long.compare(b.publishedAt,a.publishedAt));return out;
    }
    private void addF14Related(LinearLayout host,NewsItem focus){
        List<NewsItem> related=f14Related(focus);if(related.isEmpty())return;
        host.addView(text("RELATED INTELLIGENCE · "+related.size()+" · SAME F9 STORE",AMBER,10,true),marginParams(0,10,0,4));
        for(int i=0;i<Math.min(6,related.size());i++){NewsItem n=related.get(i);Button b=actionButton((n.sourceName==null?"SOURCE":n.sourceName)+" · "+n.title,CYAN);b.setOnClickListener(v->{f17BeforeDetail();showLocalNewsDetail(n);});host.addView(b,marginParams(0,2,0,2));}
    }

    // F15 / 20 — UNIFIED SEARCH. Existing F9 search field; no parallel index/store.
    private boolean f15Contains(String v,String q){return v!=null&&v.toLowerCase(Locale.ROOT).contains(q);}
    private List<NewsItem> f15NewsSearch(String q){ArrayList<NewsItem>o=new ArrayList<>();if(q==null||q.trim().isEmpty())return o;String x=q.trim().toLowerCase(Locale.ROOT);for(NewsItem n:new NewsStore(this).load())if(f15Contains(n.title,x)||f15Contains(n.summary,x)||f15Contains(n.sourceName,x)||f15Contains(n.region,x)||f15Contains(n.topic,x))o.add(n);Collections.sort(o,(a,b)->Long.compare(b.publishedAt,a.publishedAt));return o;}
    private List<MonitorReport> f15MonitorSearch(String q){ArrayList<MonitorReport>o=new ArrayList<>();if(q==null||q.trim().isEmpty())return o;String x=q.trim().toLowerCase(Locale.ROOT);for(MonitorReport m:new MonitorStore(this).reports())if(f15Contains(m.headline,x)||f15Contains(m.caption,x)||f15Contains(m.displayName,x)||f15Contains(m.handle,x)||f15Contains(m.locationName,x)||f15Contains(m.category,x))o.add(m);return o;}
    private List<Signal> f15SignalSearch(String q){ArrayList<Signal>o=new ArrayList<>();if(q==null||q.trim().isEmpty())return o;String x=q.trim().toLowerCase(Locale.ROOT);for(Map.Entry<Signal.Layer,List<Signal>>e:layerSignals.entrySet())for(Signal s:e.getValue())if(f15Contains(s.title,x)||f15Contains(s.summary,x)||f15Contains(s.source,x)||f15Contains(s.region,x)||f15Contains(s.eventType,x))o.add(s);Collections.sort(o,(a,b)->Long.compare(b.timestampMs,a.timestampMs));return o;}
    private void addF15UnifiedResults(LinearLayout host,String q){if(q==null||q.trim().isEmpty())return;List<NewsItem>news=f15NewsSearch(q);List<MonitorReport>mon=f15MonitorSearch(q);List<Signal>sig=f15SignalSearch(q);host.addView(text("UNIFIED SEARCH · "+(news.size()+mon.size()+sig.size())+" RESULTS",AMBER,10,true),marginParams(0,6,0,4));int k=0;for(NewsItem n:news){if(k++>=8)break;Button b=actionButton("NEWS · "+n.sourceName+" · "+n.title,CYAN);b.setOnClickListener(v->{f17BeforeDetail();showLocalNewsDetail(n);});host.addView(b,marginParams(0,2,0,2));}k=0;for(MonitorReport m:mon){if(k++>=5)break;Button b=actionButton("MONITOR · "+m.displayName+" · "+(m.headline.isEmpty()?m.category:m.headline),GREEN);b.setOnClickListener(v->openLocalMonitors(m.id));host.addView(b,marginParams(0,2,0,2));}k=0;for(Signal s:sig){if(k++>=8)break;Button b=actionButton(s.layer.name()+" · "+s.title,AMBER);b.setOnClickListener(v->showDetail(s));host.addView(b,marginParams(0,2,0,2));}if(news.isEmpty()&&mon.isEmpty()&&sig.isEmpty())host.addView(text("NO MATCHING RECORDS · F9 NEWS / MONITORS / OPERATIONAL SIGNALS",MUTED,9,false));}

    // F16 / 20 — HONEST DATA STATES. Empty/stale/offline is explicit; never represented as a dead card.
    private String f16NewsState(List<NewsItem> all,boolean offline,NewsPreferences prefs){
        if(offline&&all.isEmpty())return "OFFLINE · NO SAVED NEWS";
        if(offline)return "OFFLINE · SHOWING SAVED NEWS";
        if(all.isEmpty())return "NO CURRENT RECORDS · SOURCES CHECKING";
        long last=prefs.time("last_refresh",0);if(last<=0)return "FRESHNESS UNKNOWN";
        long age=System.currentTimeMillis()-last;if(age>6L*60*60*1000)return "STALE · LAST REFRESH "+localNewsAge(last);
        return "LIVE · UPDATED "+localNewsAge(last);
    }
    private TextView f16StateLine(String state){
        int c=state.startsWith("LIVE")?GREEN:(state.startsWith("OFFLINE")||state.startsWith("STALE")?AMBER:MUTED);
        return text(state,c,9,true);
    }
    private String f16MissingLocation(NewsItem n){return n==null||n.region==null||n.region.trim().isEmpty()?"LOCATION UNKNOWN":n.region;}

    // F17 / 20 — STATE & BACK NAVIGATION. Persist the F9 lens, never create a parallel navigation stack.
    private static final String F17_PREFS="f9_view_state";
    private void f17SaveState(){
        try{getSharedPreferences(F17_PREFS,MODE_PRIVATE).edit()
            .putString("country",f9CountryLens).putString("window",f12ReplayWindow).putLong("anchor",f13ReplayAnchorMs)
            .putString("category",catalogNewsType).putString("query",catalogSearch==null?"":catalogSearch.getText().toString())
            .putInt("visible",catalogVisibleLimit).apply();}catch(Exception e){CrashLedger.recordRecovered(this,"F17_SAVE",e);}
    }
    private void f17RestoreState(){
        try{android.content.SharedPreferences p=getSharedPreferences(F17_PREFS,MODE_PRIVATE);
            f9CountryLens=p.getString("country","UGANDA");f12ReplayWindow=p.getString("window","NOW");f13ReplayAnchorMs=p.getLong("anchor",0L);
            catalogNewsType=p.getString("category","UGANDA");catalogVisibleLimit=Math.max(20,p.getInt("visible",20));
            if(catalogSearch!=null)catalogSearch.setText(p.getString("query",""));}catch(Exception e){CrashLedger.recordRecovered(this,"F17_RESTORE",e);}
    }
    private void f17BeforeDetail(){f17SaveState();}

    // F19 / 20 — FUNCTIONAL TAP GATE. Runtime-visible controls register real action ownership.
    private final LinkedHashMap<String,String> f19TapOwners=new LinkedHashMap<>();
    private void f19Own(String label,String owner){if(label!=null&&owner!=null)f19TapOwners.put(label,owner);}
    private void f19RegisterCoreTapOwners(){
        f19TapOwners.clear();
        f19Own("GLOBE","showGlobeOverview");f19Own("MONITORS","openLocalMonitors");f19Own("NEWS","openCatalog:NEWS");
        f19Own("COUNTRY","F11:f9CountryLens");f19Own("REPLAY","F12/F13:f9Chronology");f19Own("SEARCH","F15:catalogSearch");
        f19Own("NEWS DETAIL","showLocalNewsDetail");f19Own("RELATED","F14:showLocalNewsDetail");
        f19Own("MONITOR DETAIL","DuMonitorPlayer.open");f19Own("SIGNAL DETAIL","showDetail");
        f19Own("OPEN FULL ARTICLE","Intent.ACTION_VIEW");f19Own("SHARE","Intent.ACTION_SEND");
        f19Own("MARK READ","NewsStore.markRead");f19Own("HIDE THIS OUTLET","NewsPreferences.source");
        f19Own("FOLLOW TOPIC","NewsPreferences.topic");f19Own("SHOW ON GLOBE","showDetail:NEWS");
    }
    private boolean f19CoreTapsReady(){
        String[] required={"GLOBE","MONITORS","NEWS","COUNTRY","REPLAY","SEARCH","NEWS DETAIL","RELATED","MONITOR DETAIL","SIGNAL DETAIL","OPEN FULL ARTICLE","SHARE","MARK READ","HIDE THIS OUTLET","FOLLOW TOPIC","SHOW ON GLOBE"};
        for(String x:required)if(!f19TapOwners.containsKey(x)||f19TapOwners.get(x).trim().isEmpty())return false;return true;
    }

    // F20 / 20 — FULL FUNCTIONAL GREEN GATE. Final cumulative contract; no new feature owner.
    private boolean f20FunctionalGreen(){return f19CoreTapsReady()&&f9CountryLens!=null&&f12ReplayWindow!=null&&new NewsStore(this).load()!=null&&catalogSearch!=null;}

    // F9 / 20-REGION OPERATIONAL FEED — Local News lives inside the existing NEWS catalog.
    private void rebuildLocalNewsPage() {
        catalogList.removeAllViews();
        catalogSearch.setVisibility(View.VISIBLE);
        newsCategoryBar.setVisibility(View.VISIBLE);
        String unifiedQuery=catalogSearch==null?"":catalogSearch.getText().toString().trim();
        addF15UnifiedResults(catalogList,unifiedQuery);
        NewsStore store = new NewsStore(this);
        NewsPreferences prefs = new NewsPreferences(this);
        List<NewsItem> all = store.load();
        Collections.sort(all,(a,b)->Long.compare(b.publishedAt,a.publishedAt)); // F9 owns chronology.
        String q = catalogSearch == null ? "" : catalogSearch.getText().toString().trim().toLowerCase(Locale.ROOT);
        ArrayList<NewsItem> show = new ArrayList<>();
        for (NewsItem n : all) {
            String hay = (n.title+" "+n.summary+" "+n.sourceName+" "+n.region).toLowerCase(Locale.ROOT);
            if (!q.isEmpty() && !hay.contains(q)) continue;
            if (!f11CountryMatches(n,f9CountryLens)) continue;
            if (!f12ReplayMatches(n)) continue;
            if (!localNewsMatches(n, catalogNewsType, prefs)) continue;
            show.add(n);
        }
        int working=0; for(NewsSource s:NewsSourceCatalog.ALL) if("Working".equals(prefs.status(s.id))) working++;
        boolean offline = !isNetworkConnectedForNews();
        catalogTitle.setText("F9 / 20-REGION OPERATIONAL FEED");
        f19RegisterCoreTapOwners();
        catalogList.addView(text("F20 FUNCTIONAL GREEN · "+(f20FunctionalGreen()?"READY":"CHECK REQUIRED")+" · F9 SOURCE / DETAIL / CHRONOLOGY OWNED",f20FunctionalGreen()?GREEN:AMBER,8,true),marginParams(0,0,0,3));
        catalogList.addView(text("F19 TAP GATE · "+(f19CoreTapsReady()?"READY":"ACTION CONTRACT INCOMPLETE")+" · "+f19TapOwners.size()+" owned actions",f19CoreTapsReady()?GREEN:AMBER,8,true),marginParams(0,0,0,3));
        catalogList.addView(text("F18 SINGLE OWNER · REGION = country lens · REPLAY = timeline controls",MUTED,8,true),marginParams(0,0,0,4));
        catalogStatus.setText((offline?"Offline — showing saved news • ":"Updated "+localNewsAge(prefs.time("last_refresh",0))+" • ")
                +working+" sources • "+NewsRegions.ALL.length+" regions • "+show.size()+" stories");
        catalogStatus.setTextColor(offline?MUTED:GREEN);
        catalogList.addView(f16StateLine(f16NewsState(all,offline,prefs)));
        catalogList.addView(buildF11CountryBar(all));
        catalogList.addView(buildF12ReplayBar());
        String replayAnchor=f13ReplayAnchorMs>0?new java.text.SimpleDateFormat("dd MMM HH:mm",Locale.getDefault()).format(new java.util.Date(f13ReplayAnchorMs)):"LIVE";
        TextView replay=text("F13 REPLAY · "+f12ReplayWindow+" · "+replayAnchor+" · F9 chronology · original record IDs / clusters / detail",MUTED,9,true);
        catalogList.addView(replay,marginParams(0,4,0,4));
        TextView lens=text("F11 COUNTRY LENS · "+f9CountryLens+" · "+show.size()+" records · same F9 source IDs / clusters / chronology",MUTED,9,true);
        catalogList.addView(lens,marginParams(0,4,0,6));
        LinkedHashMap<String,Integer> counts=new LinkedHashMap<>();
        LinkedHashMap<String,Long> newest=new LinkedHashMap<>();
        for(NewsItem n:show){counts.put(n.region,counts.containsKey(n.region)?counts.get(n.region)+1:1);Long z=newest.get(n.region);if(z==null||n.publishedAt>z)newest.put(n.region,n.publishedAt);}
        if(!counts.isEmpty()){HorizontalScrollView hs=new HorizontalScrollView(this);LinearLayout rr=new LinearLayout(this);for(Map.Entry<String,Integer>e:counts.entrySet()){Button b=compactButton(e.getKey()+" "+e.getValue()+" · "+localNewsAge(newest.get(e.getKey())));b.setOnClickListener(v->{catalogSearch.setText(e.getKey());rebuildLocalNewsPage();});rr.addView(b);}hs.addView(rr);catalogList.addView(hs);}
        if (show.isEmpty()) {
            String reason=offline?"OFFLINE · NO SAVED RECORDS MATCH THIS FILTER":"NO CURRENT RECORDS · "+f9CountryLens+" · "+f12ReplayWindow+(q.isEmpty()?"":" · SEARCH “"+q+"”");
            TextView empty=text(reason,MUTED,11,true);
            empty.setGravity(Gravity.CENTER); empty.setPadding(dp(20),dp(40),dp(20),dp(40)); catalogList.addView(empty);
        } else {
            int visible=Math.min(catalogVisibleLimit,show.size());
            for(int i=0;i<visible;i++){Signal ns=NewsSignals.from(java.util.Collections.singletonList(show.get(i))).get(0);catalogList.addView(buildCatalogCard(ns),marginParams(0,0,0,7));}
            catalogMoreButton.setVisibility(visible<show.size()?View.VISIBLE:View.GONE);
        }
        syncLocalNewsSignals(all);
    }

    private boolean localNewsMatches(NewsItem n,String f,NewsPreferences prefs){
        if(f==null||"ALL".equals(f))return true;
        if("FOR YOU".equals(f)){NewsSource src=NewsSourceCatalog.byId(n.sourceId);return src!=null&&prefs.source(src)&&prefs.topic(n.topic);}
        if("UGANDA".equals(f))return "UGANDA".equals(n.region)||"KAMPALA".equals(n.region)||n.region.contains("UGANDA");
        if("E.AFRICA".equals(f))return "EAST_AFRICA".equals(n.region)||Arrays.asList("KENYA","TANZANIA","RWANDA","SOUTH SUDAN","DR CONGO","BURUNDI").contains(n.region);
        if("WORLD".equals(f))return !localNewsMatches(n,"UGANDA",prefs)&&!localNewsMatches(n,"E.AFRICA",prefs);
        if("BREAKING".equals(f))return n.isBreaking;
        if("ENTERTAIN".equals(f))return "ENTERTAINMENT".equals(n.topic);
        if("COURTS".equals(f))return "CRIME & COURTS".equals(n.topic);
        if(Arrays.asList("BUSINESS","SPORTS","HEALTH","TECH","LUGANDA","POLITICS").contains(f))return f.equals(n.topic);
        return f.equals(NewsTopics.existingType(n));
    }

    private View buildLocalNewsCard(NewsItem n){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(9),dp(12),dp(9));card.setBackground(panelBackground(PANEL_ALT,LINE,12));card.setAlpha(n.isRead ? .62f : 1f);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setBackgroundColor(LINE);top.addView(image,new LinearLayout.LayoutParams(dp(88),dp(64)));
        LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);TextView h=text((n.isBreaking?"BREAKING • ":"")+n.title,n.isBreaking?RED:TEXT,13,true);h.setMaxLines(3);words.addView(h);
        TextView meta=text(n.sourceName+" • "+n.region+" • "+localNewsAge(n.publishedAt)+" • "+n.topic+("LG".equals(n.language)?" • LUGANDA":""),CYAN,9,true);words.addView(meta);top.addView(words,new LinearLayout.LayoutParams(0,-2,1));card.addView(top);
        if(new NewsPreferences(this).images()&&!n.imageUrl.isEmpty())NewsImageLoader.load(this,n.imageUrl,image);
        else image.setImageResource(R.drawable.ic_du_news);
        if(!n.summary.isEmpty()){TextView s=text(n.summary,MUTED,10,false);s.setMaxLines(3);card.addView(s);}
        if(!n.alsoReportedBy.isEmpty())card.addView(text("Also reported by: "+TextUtils.join(", ",n.alsoReportedBy),CYAN,9,false));
        card.setOnClickListener(v->showLocalNewsDetail(n));return card;
    }

    // 1.2/20/3-9 — F9 News -> Globe intelligence from the exact NewsItem record.
    private String f9NewsIntelligence(NewsItem n) {
        if (n == null) return "NEWS INTELLIGENCE\nRECORD  UNAVAILABLE";
        String outlet=n.sourceName==null||n.sourceName.trim().isEmpty()?"SOURCE UNKNOWN":n.sourceName;
        StringBuilder out=new StringBuilder("NEWS INTELLIGENCE\n");
        out.append("OUTLET  ").append(outlet).append("\n");
        out.append("SOURCE ID  ").append(n.sourceId).append("\n");
        out.append("NEWS ID  ").append(n.id).append("\n");
        out.append("PUBLISHED  ").append(n.publishedAt>0?eventTime.format(new Date(n.publishedAt)):"TIME UNKNOWN").append("\n");
        out.append("FIRST SEEN  ").append(n.firstSeenAt>0?eventTime.format(new Date(n.firstSeenAt)):"TIME UNKNOWN").append("\n");
        out.append("REGION  ").append(n.region==null||n.region.isEmpty()?"REGION UNKNOWN":n.region).append("\n");
        out.append("TOPIC  ").append(n.topic==null||n.topic.isEmpty()?"TOPIC UNKNOWN":n.topic).append("\n");
        out.append("CLUSTER  ").append(n.clusterId==null||n.clusterId.isEmpty()?"NONE":n.clusterId).append("\n");
        out.append("ALSO REPORTED BY  ").append(n.alsoReportedBy.isEmpty()?"NONE":TextUtils.join(", ",n.alsoReportedBy)).append("\n");
        GeoIndex.Point gp=GeoIndex.findSpecific(n.title+" "+n.summary+" "+n.region);
        out.append("GLOBE LOCATION  ").append(gp==null?"UNRESOLVED — NO MARKER INVENTED":"RESOLVED FROM NAMED PLACE");
        return out.toString();
    }

    private void showLocalNewsDetail(NewsItem n){
        new NewsStore(this).markRead(n.id);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(14),dp(8),dp(14),dp(8));
        TextView h=text(n.title,TEXT,15,true);box.addView(h);
        TextView intelligence=text(f9NewsIntelligence(n),TEXT,9,true);
        intelligence.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);
        intelligence.setPadding(dp(9),dp(7),dp(9),dp(7));
        intelligence.setBackground(panelBackground(PANEL_ALT,CYAN,12));
        box.addView(intelligence,marginParams(0,5,0,7));
        box.addView(text((n.sourceName==null||n.sourceName.trim().isEmpty()?"SOURCE UNKNOWN":n.sourceName)+" • "+f16MissingLocation(n)+" • "+(n.publishedAt>0?localNewsAge(n.publishedAt):"TIME UNKNOWN")+" • "+(n.topic==null||n.topic.isEmpty()?"TOPIC UNKNOWN":n.topic),CYAN,9,true));
        ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);box.addView(image,new LinearLayout.LayoutParams(-1,dp(180)));if(new NewsPreferences(this).images()&&!n.imageUrl.isEmpty())NewsImageLoader.load(this,n.imageUrl,image);else image.setImageResource(R.drawable.ic_du_news);
        box.addView(text(n.summary.isEmpty()?"No summary supplied by this outlet.":n.summary,MUTED,11,false));
        if(!n.alsoReportedBy.isEmpty())box.addView(text("Also reported by: "+TextUtils.join(", ",n.alsoReportedBy),CYAN,9,false));
        addF14Related(box,n);
        String[] labels={"OPEN FULL ARTICLE","SHARE","MARK READ","HIDE THIS OUTLET","FOLLOW TOPIC","SHOW ON GLOBE"};
        for(String label:labels){Button b=actionButton(label,CYAN);GeoIndex.Point gp=GeoIndex.findSpecific(n.title+" "+n.summary+" "+n.region);if("SHOW ON GLOBE".equals(label))b.setEnabled(gp!=null);b.setOnClickListener(v->{NewsPreferences prefs=new NewsPreferences(this);if("OPEN FULL ARTICLE".equals(label)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(n.link)));}catch(Exception ignored){}}else if("SHARE".equals(label))startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,n.title+"\n"+n.link),"Share news"));else if("MARK READ".equals(label))new NewsStore(this).markRead(n.id);else if("HIDE THIS OUTLET".equals(label))prefs.source(n.sourceId,false);else if("FOLLOW TOPIC".equals(label))prefs.topic(n.topic,true);else if("SHOW ON GLOBE".equals(label)&&gp!=null){Signal s=NewsSignals.from(java.util.Collections.singletonList(n)).get(0);showDetail(s);}});box.addView(b,marginParams(0,4,0,0));}
        ScrollView sc=new ScrollView(this);sc.addView(box);new AlertDialog.Builder(this).setTitle("Local News").setView(sc).setNegativeButton("CLOSE",(d,w)->{f17RestoreState();rebuildLocalNewsPage();}).show();
    }

    private void syncLocalNewsSignals(List<NewsItem> items){
        List<Signal> s=NewsSignals.from(items);layerSignals.put(Signal.Layer.NEWS,s);FeedStatus st=new FeedStatus(FeedStatus.State.LIVE,s.size(),"Local News aggregator",System.currentTimeMillis());feedStatuses.put(Signal.Layer.NEWS,st);operationsEngine.accept(Signal.Layer.NEWS,s,st,System.currentTimeMillis());refreshOperationalStates();
    }

    private void refreshLocalNews(boolean force){
        NewsPreferences p=new NewsPreferences(this);if(!isNetworkConnectedForNews())return;if(!force&&System.currentTimeMillis()-p.time("last_refresh",0)<5L*60*1000)return;
        NewsAggregator a=new NewsAggregator(this);a.refresh((items,working)->runOnUiThread(()->{syncLocalNewsSignals(items);if("NEWS".equals(catalogCategory))rebuildLocalNewsPage();a.shutdown();}));
    }
    private boolean isNetworkConnectedForNews(){try{android.net.ConnectivityManager m=(android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);return m!=null&&m.getActiveNetwork()!=null;}catch(Exception e){return false;}}
    private String localNewsAge(long t){if(t<=0)return"never";long m=Math.max(0,(System.currentTimeMillis()-t)/60000);return m<1?"now":m<60?m+" min ago":m<1440?(m/60)+" h ago":(m/1440)+" d ago";}

    private void maybeAskNewsPermission(){
        NewsPreferences p=new NewsPreferences(this);NewsNotifier.channels(this);
        if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED&&!p.flag("asked",false)){
            new AlertDialog.Builder(this).setTitle("Local News").setMessage("Get alerts when big news breaks in Uganda").setPositiveButton("TURN ON NEWS ALERTS",(d,w)->{p.setFlag("asked",true);requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},3301);}).setNegativeButton("NOT NOW",(d,w)->p.setFlag("asked",true)).show();
        }
    }

    private void appendLocalNewsSettings(LinearLayout form){
        NewsPreferences p=new NewsPreferences(this);form.addView(text("LOCAL NEWS",TEXT,12,true),marginParams(0,14,0,4));
        form.addView(text("Outlets • topics • alerts",MUTED,9,false));
        String lastGroup="";
        for(NewsSource s:NewsSourceCatalog.ALL){String group=s.region.name()+" / "+s.category.name();if(!group.equals(lastGroup)){form.addView(text(group,MUTED,9,true),marginParams(0,8,0,2));lastGroup=group;}CheckBox x=new CheckBox(this);x.setText(s.name+" • "+p.status(s.id));x.setTextColor(TEXT);x.setChecked(p.source(s));x.setOnCheckedChangeListener((b,v)->p.source(s.id,v));form.addView(x);}
        for(String topic:new String[]{"POLITICS","BUSINESS","SPORTS","ENTERTAINMENT","HEALTH","TECH","CRIME & COURTS","WORLD","LUGANDA"}){CheckBox x=new CheckBox(this);x.setText("Follow "+topic);x.setTextColor(TEXT);x.setChecked(p.topic(topic));x.setOnCheckedChangeListener((b,v)->p.topic(topic,v));form.addView(x);}
        String[][] flags={{"alerts","News alerts"},{"breaking","Breaking alerts"},{"grouped","Grouped alerts"},{"digest","06:30 digest"},{"quiet","Quiet hours 22:00–06:00"},{"images","Load news images"}};
        for(String[]f:flags){CheckBox x=new CheckBox(this);x.setText(f[1]);x.setTextColor(TEXT);x.setChecked("images".equals(f[0])?p.images():p.flag(f[0],true));x.setOnCheckedChangeListener((b,v)->{if("images".equals(f[0]))p.images(v);else p.setFlag(f[0],v);});form.addView(x);}
        if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED){Button on=actionButton("TURN ON NEWS ALERTS",AMBER);on.setOnClickListener(v->requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},3301));form.addView(on);}
    }

    private void showSettings() {
        SecurePrefs secrets = repository == null
                ? new SecurePrefs(this) : repository.securePrefs();
        AppPreferences appPrefs = repository == null
                ? new AppPreferences(this) : repository.preferences();
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), dp(8), dp(18), dp(8));
        form.addView(text(safeMode
                ? "RECOVERY MODE • PROVIDER SETTINGS"
                : "OPTIONAL KEYED PROVIDERS", TEXT, 12, true));
        form.addView(text("Keyless weather, earthquakes, NASA events, GDELT DOC/GKG, market reference rates, public radio, safe public TV indexing, call/frequency references and anonymous OpenSky work immediately. Optional keys and direct stream settings are encrypted by Android Keystore on this device.",
                MUTED, 10, false), marginParams(0, 4, 0, 12));

        EditText ais = settingsField("AISStream API key", secrets.get(SecurePrefs.AIS_KEY), true);
        EditText windy = settingsField("Windy Webcams API key", secrets.get(SecurePrefs.WINDY_KEY), true);
        EditText openSkyId = settingsField("OpenSky OAuth client ID", secrets.get(SecurePrefs.OPENSKY_CLIENT_ID), false);
        EditText openSkySecret = settingsField("OpenSky OAuth client secret", secrets.get(SecurePrefs.OPENSKY_CLIENT_SECRET), true);
        EditText coinGecko = settingsField("CoinGecko Demo API key — optional", secrets.get(SecurePrefs.COINGECKO_KEY), true);
        EditText publicSafetyName = settingsField("Public-safety feed name — optional", secrets.get(SecurePrefs.PUBLIC_SAFETY_NAME), false);
        EditText publicSafetyStream = settingsField("Lawful direct HTTPS public-safety audio URL", secrets.get(SecurePrefs.PUBLIC_SAFETY_STREAM), false);
        EditText rss = settingsField("Additional HTTPS RSS URLs — one per line", appPrefs.customRss(), false);
        rss.setSingleLine(false);
        rss.setMinLines(3);
        rss.setGravity(Gravity.TOP);
        form.addView(ais, marginParams(0, 0, 0, 8));
        form.addView(windy, marginParams(0, 0, 0, 8));
        form.addView(openSkyId, marginParams(0, 0, 0, 8));
        form.addView(openSkySecret, marginParams(0, 0, 0, 8));
        form.addView(coinGecko, marginParams(0, 0, 0, 8));
        form.addView(publicSafetyName, marginParams(0, 0, 0, 8));
        form.addView(publicSafetyStream, marginParams(0, 0, 0, 8));
        form.addView(rss, marginParams(0, 0, 0, 8));
        appendLocalNewsSettings(form);
        form.addView(text("A Windy key enables the worldwide camera atlas. The provider tier exposes a limited listing window; DU World Monitor indexes permitted pages and never labels that window as every camera on Earth.",
                CYAN, 9, false), marginParams(0, 2, 0, 8));
        form.addView(text("AISStream recommends a server-side proxy for widely distributed apps. A personal key entered here remains local to this installed device and is not compiled into the APK.",
                AMBER, 9, false));
        form.addView(text("Public-safety audio must be a direct lawful HTTPS stream you are authorized to access. The app does not scrape directories, bypass authentication or decrypt protected communications.",
                AMBER, 9, false), marginParams(0, 8, 0, 0));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(form);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("DU World Monitor — Providers")
                .setView(scroll)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE & RECONNECT", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    try {
                        String requestedPublicAudio = publicSafetyStream.getText()
                                .toString().trim();
                        if (!requestedPublicAudio.isEmpty()
                                && !PublicMediaPolicy.isSafePublicHttpsUrl(
                                requestedPublicAudio)) {
                            publicSafetyStream.setError(
                                    PublicMediaPolicy.validationError(requestedPublicAudio));
                            publicSafetyStream.requestFocus();
                            return;
                        }
                        secrets.put(SecurePrefs.AIS_KEY, ais.getText().toString());
                        secrets.put(SecurePrefs.WINDY_KEY, windy.getText().toString());
                        secrets.put(SecurePrefs.OPENSKY_CLIENT_ID, openSkyId.getText().toString());
                        secrets.put(SecurePrefs.OPENSKY_CLIENT_SECRET, openSkySecret.getText().toString());
                        secrets.put(SecurePrefs.COINGECKO_KEY, coinGecko.getText().toString());
                        secrets.put(SecurePrefs.PUBLIC_SAFETY_NAME, publicSafetyName.getText().toString());
                        secrets.put(SecurePrefs.PUBLIC_SAFETY_STREAM, requestedPublicAudio);
                        appPrefs.setCustomRss(rss.getText().toString());
                        if (repository != null) repository.reloadCredentials();
                        dialog.dismiss();
                        Toast.makeText(this, repository == null
                                        ? "Settings saved. Restart the complete command deck to reconnect."
                                        : "Provider settings saved",
                                repository == null ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT).show();
                    } catch (Exception error) {
                        Toast.makeText(this, "Could not protect settings: " + error.getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                }));
        dialog.show();
    }

    private EditText settingsField(String hint, String value, boolean secret) {
        EditText field = new EditText(this);
        field.setHint(hint);
        field.setHintTextColor(MUTED);
        field.setTextColor(TEXT);
        field.setText(value);
        field.setTextSize(11);
        field.setSingleLine(true);
        field.setPadding(dp(10), dp(6), dp(10), dp(6));
        field.setBackground(panelBackground(PANEL_ALT, LINE, 12));
        if (secret) {
            field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        }
        return field;
    }

    private void handleSelectedSource() {
        if (selectedSignal != null && (selectedSignal.layer == Signal.Layer.FLIGHTS
                || selectedSignal.layer == Signal.Layer.SHIPS)) {
            if (mapView.isFollowing(selectedSignal.canonicalId)) {
                mapView.stopFollowing();
                sourceButton.setText("FOLLOW ON SATELLITE MAP");
                Toast.makeText(this, "Traffic follow stopped", Toast.LENGTH_SHORT).show();
            } else {
                followTraffic(selectedSignal);
                sourceButton.setText("STOP FOLLOWING");
            }
        } else if (selectedSignal != null && selectedSignal.layer == Signal.Layer.RADIO) {
            toggleRadio(selectedSignal);
        } else if (selectedSignal != null && selectedSignal.layer == Signal.Layer.TV) {
            launchNativeMedia(selectedSignal, NativeMediaActivity.KIND_VIDEO);
        } else if (selectedSignal != null && selectedSignal.layer == Signal.Layer.WEBCAMS) {
            launchNativeMedia(selectedSignal, NativeMediaActivity.KIND_IMAGE);
        } else if (selectedSignal != null && selectedSignal.layer == Signal.Layer.MEDIA) {
            if (selectedSignal.sourceUrl.startsWith("https://")
                    && "AUDIO".equalsIgnoreCase(selectedSignal.facts.get("MEDIA TYPE"))) {
                toggleRadio(selectedSignal);
            } else {
                Toast.makeText(this,
                        "Reference only — this provider does not expose a verified direct stream",
                        Toast.LENGTH_LONG).show();
            }
        } else {
            openExternal(selectedSourceUrl);
        }
    }

    private void toggleRadio(Signal signal) {
        if (signal.id.equals(playingRadioId) && radioPlayer != null) {
            stopRadio();
            Toast.makeText(this, "Public radio stopped", Toast.LENGTH_SHORT).show();
            return;
        }
        stopRadio();
        if (!PublicMediaPolicy.isSafePublicHttpsUrl(signal.sourceUrl)) {
            Toast.makeText(this, "This station does not offer a secure stream",
                    Toast.LENGTH_LONG).show();
            return;
        }
        try {
            MediaPlayer player = new MediaPlayer();
            if (repository != null) repository.recordRadioClick(signal.id);
            radioPlayer = player;
            playingRadioId = signal.id;
            sourceButton.setText("CONNECTING PUBLIC RADIO…");
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            player.setDataSource(signal.sourceUrl);
            player.setOnPreparedListener(ready -> {
                if (ready != radioPlayer) return;
                ready.start();
                if (selectedSignal != null && signal.id.equals(selectedSignal.id)) {
                    sourceButton.setText("STOP PUBLIC RADIO");
                }
                Toast.makeText(this, "Playing " + signal.title,
                        Toast.LENGTH_SHORT).show();
            });
            player.setOnCompletionListener(done -> stopRadio());
            player.setOnErrorListener((failed, what, extra) -> {
                if (failed == radioPlayer) {
                    stopRadio();
                    Toast.makeText(this, "Station stream is currently unavailable",
                            Toast.LENGTH_LONG).show();
                }
                return true;
            });
            player.prepareAsync();
        } catch (Exception error) {
            stopRadio();
            Toast.makeText(this, "Could not open this public station",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void stopRadio() {
        MediaPlayer player = radioPlayer;
        radioPlayer = null;
        playingRadioId = "";
        if (player != null) {
            try {
                player.reset();
            } catch (Exception ignored) {
                // The player may still be connecting.
            }
            try {
                player.release();
            } catch (RuntimeException ignored) {
                // Vendor media stacks can throw while an async prepare is being cancelled.
            }
        }
        if (sourceButton != null && selectedSignal != null
                && (selectedSignal.layer == Signal.Layer.RADIO
                || selectedSignal.layer == Signal.Layer.MEDIA)) {
            sourceButton.setText(selectedSignal.layer == Signal.Layer.MEDIA
                    ? "PLAY PUBLIC SAFETY AUDIO" : "PLAY PUBLIC RADIO");
        }
    }

    private void openExternal(String url) {
        if (!PublicMediaPolicy.isSafePublicHttpsUrl(url)) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (ActivityNotFoundException ignored) {
            Toast.makeText(this, "No browser available for this source", Toast.LENGTH_LONG).show();
        }
    }

    private void togglePanel(View panel) {
        panel.animate().cancel();
        if (panel.getVisibility() == View.VISIBLE) {
            panel.animate()
                    .alpha(0f)
                    .translationY(dp(14))
                    .setDuration(160L)
                    .withEndAction(() -> {
                        panel.setVisibility(View.GONE);
                        panel.setTranslationY(0f);
                    })
                    .start();
        } else {
            panel.setAlpha(0f);
            panel.setTranslationY(dp(14));
            panel.setVisibility(View.VISIBLE);
            if (panel == wirePanel) applyFilters();
            panel.animate().alpha(1f).translationY(0f).setDuration(180L).start();
        }
    }

    private TextView legendLine(String label, int color, String explanation) {
        TextView view = text("● " + label + "\n   " + explanation, color, 9, false);
        view.setPadding(0, dp(7), 0, 0);
        return view;
    }

    private Button compactButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(TEXT);
        button.setTextSize(9);
        button.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        button.setLetterSpacing(0.04f);
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(dp(4), 0, dp(4), 0);
        button.setBackground(pressableBackground(Color.argb(220, 14, 21, 29), LINE, 12));
        return button;
    }

    private Button headerButton(String label) {
        Button button = compactButton(label);
        button.setTextColor(MUTED);
        button.setBackground(pressableBackground(Color.argb(1, 8, 12, 17),
                Color.TRANSPARENT, 12));
        return button;
    }

    private Button actionButton(String label, int color) {
        Button button = compactButton(label);
        button.setTextColor(color);
        button.setBackground(pressableBackground(Color.argb(232, 14, 21, 29), color, 12));
        button.setMinHeight(dp(48));
        return button;
    }

    private TextView text(String value, int color, int sizeSp, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(color);
        view.setTextSize(sizeSp);
        view.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif",
                Typeface.NORMAL));
        view.setLineSpacing(0f, 1.08f);
        return view;
    }

    private GradientDrawable panelBackground(int fill, int stroke, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setStroke(dp(1), stroke);
        drawable.setCornerRadius(dp(Math.max(0, Math.min(24, radiusDp))));
        return drawable;
    }

    private RippleDrawable pressableBackground(int fill, int stroke, int radiusDp) {
        return new RippleDrawable(
                ColorStateList.valueOf(Color.argb(58, 112, 177, 201)),
                panelBackground(fill, stroke, radiusDp),
                panelBackground(Color.WHITE, Color.WHITE, radiusDp));
    }

    private LinearLayout.LayoutParams marginParams(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return params;
    }

    private FrameLayout.LayoutParams fullFrame() {
        return new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private int badgeColor(Signal.Credibility credibility) {
        switch (credibility) {
            case CONFIRMED: return GREEN;
            case REPORTED: return AMBER;
            case UNVERIFIED: return RED;
            case PUBLIC_SOURCE: return CYAN;
            case CALCULATED: return Color.rgb(174, 139, 224);
            case RAW_SIGNAL: default: return CYAN;
        }
    }

    /** Operational urgency is intentionally separate from corroboration/credibility. */
    private int signalChannel(Signal signal) {
        if (signal.severity >= 4
                && (signal.layer == Signal.Layer.NEWS
                || signal.layer == Signal.Layer.NATURAL
                || signal.layer == Signal.Layer.AIRSPACE
                || signal.layer == Signal.Layer.SPACE_WEATHER)) {
            return SignalBeaconView.RED;
        }
        if (signal.credibility == Signal.Credibility.UNVERIFIED
                || signal.credibility == Signal.Credibility.REPORTED) {
            return SignalBeaconView.AMBER;
        }
        return SignalBeaconView.GREEN;
    }

    private int signalStateColor(Signal signal) {
        int channel = signalChannel(signal);
        if (channel == SignalBeaconView.RED) return RED;
        if (channel == SignalBeaconView.AMBER) return AMBER;
        return GREEN;
    }

    private String signalStateText(Signal signal) {
        int channel = signalChannel(signal);
        if (channel == SignalBeaconView.RED) return "PRIORITY";
        if (channel == SignalBeaconView.AMBER) return "DEVELOPING";
        return "ONLINE";
    }

    private String badgeText(Signal signal) {
        switch (signal.credibility) {
            case CONFIRMED: return "CONFIRMED — OFFICIAL SOURCE";
            case CALCULATED: return "CALCULATED — PUBLIC ELEMENTS, NOT TELEMETRY";
            case REPORTED: return "REPORTED";
            case UNVERIFIED: return "UNVERIFIED — DEVELOPING";
            case PUBLIC_SOURCE: return "PUBLIC SOURCE — AVAILABILITY VARIES";
            case RAW_SIGNAL: default: return "RAW SIGNAL — LIVE TELEMETRY";
        }
    }

    private String shortBadge(Signal signal) {
        switch (signal.credibility) {
            case CONFIRMED: return "CONFIRMED";
            case CALCULATED: return "CALCULATED";
            case REPORTED: return "REPORTED";
            case UNVERIFIED: return "UNVERIFIED";
            case PUBLIC_SOURCE: return "PUBLIC SOURCE";
            case RAW_SIGNAL:
            default: return "RAW";
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static int compareNewestFirst(long first, long second) {
        return first == second ? 0 : first < second ? 1 : -1;
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (detailPanel != null && detailPanel.getVisibility() == View.VISIBLE) {
            detailPanel.setVisibility(View.GONE);
            restoreDetailReturnState();
        } else if (catalogPanel != null && catalogPanel.getVisibility() == View.VISIBLE) {
            catalogPanel.setVisibility(View.GONE);
        } else if (replayPanel != null && replayPanel.getVisibility() == View.VISIBLE) {
            replayPanel.setVisibility(View.GONE);
        } else if (!wideLayout && wirePanel != null
                && wirePanel.getVisibility() == View.VISIBLE) {
            wirePanel.setVisibility(View.GONE);
        } else if (!wideLayout && layersPanel != null
                && layersPanel.getVisibility() == View.VISIBLE) {
            layersPanel.setVisibility(View.GONE);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!destroyed && mapView != null) applyFilters();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        startupHandler.removeCallbacksAndMessages(null);
        clockHandler.removeCallbacksAndMessages(null);
        activityHandler.removeCallbacksAndMessages(null);
        analysisExecutor.shutdownNow();
        stopRadio();
        if (repository != null) {
            try {
                repository.stop();
            } catch (RuntimeException error) {
                CrashLedger.recordRecovered(this, "MainActivity.repositoryStop", error);
            }
        }
        super.onDestroy();
    }
}
