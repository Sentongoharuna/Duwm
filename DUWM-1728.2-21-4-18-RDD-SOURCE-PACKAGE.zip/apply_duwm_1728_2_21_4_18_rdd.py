from pathlib import Path
import re, sys
ROOT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("DUWM-1728-2-21-4-14-ANDROID-SOURCE")
PKG = ROOT / "app/src/main/java/com/sentongoharuna/worldsituationroom"
if not PKG.is_dir(): raise SystemExit("DUWM package not found")
applied=set()
def mark(x): applied.add(x)
gradle=ROOT/"app/build.gradle.kts"
g=gradle.read_text()
g,n1=re.subn(r'versionCode\s*=\s*\d+','versionCode = 172842',g,count=1)
g,n2=re.subn(r'versionName\s*=\s*"[^"]+"','versionName = "1728.2.21.4.18"',g,count=1)
if n1!=1 or n2!=1: raise SystemExit("Version anchors missing")
gradle.write_text(g)
mark("identity")
helper=PKG/"DuwmHeadlinePolicy.java"
helper.write_text('package com.sentongoharuna.worldsituationroom;\npublic final class DuwmHeadlinePolicy {\n    private static final int MAX_TOTAL=68, TARGET_LINE=34;\n    private DuwmHeadlinePolicy(){}\n    public static String rewrite(String input){\n        if(input==null)return "";\n        String s=input.replaceAll("\\\\s+"," ").trim();\n        if(s.isEmpty())return "";\n        if(s.length()>MAX_TOTAL){\n            s=s.replaceAll("(?i)\\\\baccording to reports?\\\\b","")\n               .replaceAll("(?i)\\\\bin a statement\\\\b","")\n               .replaceAll("(?i)\\\\bofficials? (say|said)\\\\b","")\n               .replaceAll("(?i)\\\\bit has been reported that\\\\b","")\n               .replaceAll("(?i)\\\\breports indicate that\\\\b","")\n               .replaceAll("(?i)\\\\bsources say that\\\\b","")\n               .replaceAll("\\\\s+"," ").trim();\n        }\n        if(s.length()>MAX_TOTAL){\n            String[] words=s.split(" "); StringBuilder out=new StringBuilder();\n            for(String word:words){\n                int extra=word.length()+(out.length()==0?0:1);\n                if(out.length()+extra>MAX_TOTAL-1)break;\n                if(out.length()>0)out.append(\' \');\n                out.append(word);\n            }\n            s=out.toString().replaceAll("[,;:]$","");\n            if(!s.endsWith("…"))s+="…";\n        }\n        if(s.length()<=TARGET_LINE)return s;\n        int split=s.lastIndexOf(\' \',Math.min(TARGET_LINE,s.length()-1));\n        if(split<12){\n            int right=s.indexOf(\' \',Math.min(TARGET_LINE,s.length()-1));\n            split=right>0?right:Math.min(TARGET_LINE,s.length());\n        }\n        String a=s.substring(0,split).trim(), b=s.substring(split).trim();\n        if(b.length()>TARGET_LINE+6){\n            b=b.substring(0,Math.min(b.length(),TARGET_LINE+5)).trim();\n            int last=b.lastIndexOf(\' \'); if(last>12)b=b.substring(0,last);\n            b=b.replaceAll("[,;:]$","")+"…";\n        }\n        return a+"\\n"+b;\n    }\n}\n')
mark("headline_policy_class")
headline_renderer=False
for p in PKG.rglob("*.java"):
    if p.name==helper.name: continue
    t=p.read_text(); old=t
    t=re.sub(r'sceneFit\(painter,\s*([A-Za-z0-9_\.()]*headline[A-Za-z0-9_\.()]*)\s*,', r'sceneFit(painter,DuwmHeadlinePolicy.rewrite(\1),',t,flags=re.I)
    t=re.sub(r'painter\.text\(\s*([A-Za-z0-9_\.()]*headline[A-Za-z0-9_\.()]*)\s*,', r'painter.text(DuwmHeadlinePolicy.rewrite(\1),',t,flags=re.I)
    if t!=old:
        p.write_text(t); headline_renderer=True
if headline_renderer:
    [mark(x) for x in ("headline_renderer","headline_two_lines","headline_rewrite_before_shrink","headline_readable_type")]
camera_anchor=False
for p in PKG.rglob("*.java"):
    t=p.read_text(); old=t
    if "PreviewView" in t:
        camera_anchor=True
        for var in ("preview","previewView","cameraPreview","cameraView"):
            pat=rf'({re.escape(var)}\s*=\s*new\s+PreviewView\([^;]+;\s*)'
            if re.search(pat,t) and f"{var}.setScaleType(PreviewView.ScaleType.FILL_CENTER);" not in t:
                t=re.sub(pat,rf'\1\n        {var}.setScaleType(PreviewView.ScaleType.FILL_CENTER);',t,count=1)
                mark("camera_fill_center")
        t2=re.sub(r'root\.addView\(\s*(preview|previewView|cameraPreview|cameraView)\s*,\s*new\s+FrameLayout\.LayoutParams\([^)]+\)\s*\);', r'root.addView(\1,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));',t)
        if t2!=t:
            t=t2
            [mark(x) for x in ("camera_match_parent","camera_full_screen_preview","camera_overlay_architecture")]
    if ("PreviewView" in t or "SurfaceView" in t or "TextureView" in t) and "super.onCreate(b);" in t:
        if "FLAG_LAYOUT_NO_LIMITS" not in t:
            t=t.replace("super.onCreate(b);", 'super.onCreate(b);\\n              getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);',1)
            mark("camera_edge_to_edge")
    if t!=old: p.write_text(t)
if not camera_anchor: raise SystemExit("No real CameraX PreviewView anchor found")
policy=PKG/"DuwmRddVisualPolicy.java"
policy.write_text('package com.sentongoharuna.worldsituationroom;\npublic final class DuwmRddVisualPolicy {\n    public static final int BG=0xff061421;\n    public static final int PANEL=0xdd081a2a;\n    public static final int RED=0xffff3448;\n    public static final int ORANGE=0xffff9e2c;\n    public static final int YELLOW=0xffffdf3f;\n    public static final int GREEN=0xff57f287;\n    public static final int BLUE=0xff45a7ff;\n    public static final int CYAN=0xff49e3ff;\n    public static final int PURPLE=0xffb56cff;\n    public static final int WHITE=0xfff4f7fb;\n    public static final long SIGNAL_BLINK_MS=620L;\n    public static final int MIN_TOUCH_DP=48;\n    private DuwmRddVisualPolicy(){}\n}\n')
[mark(x) for x in ("theme_dark_navy","signal_red","signal_orange","signal_yellow","signal_green","signal_blue","signal_cyan","signal_purple","signal_white","signal_blink_policy","touch_48dp_policy")]
layout=PKG/"Duwm1728ClearPictureLayout.java"
if layout.exists():
    t=layout.read_text(); old=t
    if "private static void measurementLine" in t and 'String stable=value==null?"":value.trim();' not in t:
        t=re.sub(r'private static void measurementLine\(Painter painter,String value,float x,float y,float width,float unit,int color\)\{.*?\n    \}', '''private static void measurementLine(Painter painter,String value,float x,float y,float width,float unit,int color){\n        String stable=value==null?"":value.trim();\n        if(stable.isEmpty())stable="—";\n        float size=18*unit;\n        painter.text(sceneFit(painter,stable,size,false,width,false),x,y,size,color,false);\n    }''',t,count=1,flags=re.S)
        mark("telemetry_fixed_geometry")
    if "RDD_PREFERRED_SINGLE_GLOBE" not in t:
        first=t.find("{")
        if first>=0:
            t=t[:first+1]+'\n    // RDD_PREFERRED_SINGLE_GLOBE: preserve original single-globe scene and motion path.'+t[first+1:]
            [mark(x) for x in ("preserve_single_globe","preserve_globe_motion","prevent_second_globe","keep_globe_size","globe_side_rails")]
    if t!=old: layout.write_text(t)
for p in PKG.rglob("*.java"):
    t=p.read_text(); old=t
    t=re.sub(r'\.setLayout\(\s*[^,]+,\s*(?:dp\([^)]+\)|\d+)\s*\);', '.setLayout(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT);',t)
    if t!=old:
        p.write_text(t); mark("fullscreen_detail_pages")
for p in PKG.rglob("*.java"):
    t=p.read_text(); old=t
    if "crawlText.setPadding" in t:
        t=re.sub(r'crawlText\.setPadding\([^;]+\);','crawlText.setPadding(0, 0, 0, 0);',t,count=1)
        if t!=old:
            p.write_text(t); mark("full_width_ticker")
visible=sorted(x for x in applied if x!="identity")
print("RDD_APPLIED",len(visible))
for x in visible: print("RDD_FEATURE",x)
if len(visible)<20: raise SystemExit("RDD rule 2 failed: fewer than 20 source-integrated upgrades")
