package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.appwidget.AppWidgetManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.text.TextUtils;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Deque;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Native mission-control activity. Every surface is an Android View, not browser content. */
public final class MainActivity extends Activity implements WorldDataRepository.Listener {
    private static final String LOG_TAG = "WorldSituationRoom";
    private static final String APP_BRAND = ShareCardData.BRAND;
    private static final long STARTUP_UI_DELAY_MS = 90L;
    private static final long STARTUP_FEED_DELAY_MS = 320L;
    private static final long ANALYSIS_REFRESH_MS = 5_500L;
    private static final int MAX_ACQUISITION_SCAN = 640;
    // R18: restrained newsroom palette. Colour communicates state, not decoration.
    private static final int BG = Color.rgb(5, 8, 12);
    private static final int PANEL = Color.rgb(8, 12, 17);
    private static final int PANEL_ALT = Color.rgb(14, 21, 29);
    private static final int CYAN = Color.rgb(112, 177, 201);
    private static final int RED = Color.rgb(219, 73, 80);
    private static final int GREEN = Color.rgb(75, 166, 124);
    private static final int AMBER = Color.rgb(199, 151, 68);
    private static final int MUTED = Color.rgb(139, 155, 166);
    private static final int TEXT = Color.rgb(235, 241, 244);
    private static final int LINE = Color.rgb(39, 53, 65);
    private static final String[] TYPES = {"ALL", "CONFLICT", "PROTEST", "DISASTER", "POLITICS", "OTHER"};
    private static final String[] REGIONS = {"ALL", "AFRICA", "MIDDLE EAST", "EUROPE", "ASIA", "AMERICAS", "OCEANIA", "GLOBAL"};
    private static final String[] TIME_WINDOWS = {"1H", "6H", "24H", "72H"};
    private static final long[] TIME_WINDOW_MS = {
            60L * 60L * 1000L,
            6L * 60L * 60L * 1000L,
            24L * 60L * 60L * 1000L,
            72L * 60L * 60L * 1000L
    };
    private static final String[] CATALOG_CATEGORIES = {
            "BRIEF", "MONITORS", "FUSION", "RISK", "ANALYST", "WIDGETS", "AIRCRAFT", "SHIPS", "BOATS", "WEATHER",
            "AIRSPACE", "EVENTS", "NEWS", "ORBITS", "MARKETS", "AIRPORTS", "RUNWAYS", "PORTS", "SPACE",
            "INFRA", "RADIO", "CALLS", "TV", "CAMERAS", "SOURCES"
    };
    private static final String[] NEWS_CATEGORIES = {
            "ALL", "FOR YOU", "UGANDA", "E.AFRICA", "WORLD", "BREAKING", "BUSINESS", "SPORTS",
            "ENTERTAIN", "HEALTH", "TECH", "COURTS", "LUGANDA", "CONFLICT", "PROTEST", "DISASTER", "POLITICS", "OTHER"
    };

    private final EnumMap<Signal.Layer, Boolean> enabled = new EnumMap<>(Signal.Layer.class);
    private final EnumMap<Signal.Layer, CheckBox> layerChecks = new EnumMap<>(Signal.Layer.class);
    private final EnumMap<Signal.Layer, FeedStatus> feedStatuses = new EnumMap<>(Signal.Layer.class);
    private final EnumMap<Signal.Layer, List<Signal>> layerSignals = new EnumMap<>(Signal.Layer.class);
    private final Handler clockHandler = new Handler(Looper.getMainLooper());
    private final Handler activityHandler = new Handler(Looper.getMainLooper());
    private final Handler startupHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService analysisExecutor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean analysisRunning = new AtomicBoolean(false);
    private final Deque<Signal> acquisitionQueue = new ArrayDeque<>();
    private final Set<String> seenAcquisitions = new LinkedHashSet<>();
    private final MovementAnalyzer movementAnalyzer = new MovementAnalyzer();
    private final LiveOperationsEngine operationsEngine = new LiveOperationsEngine();
    private final TemporalReplayEngine replayEngine = new TemporalReplayEngine();
    private final SimpleDateFormat utcClock = new SimpleDateFormat("HH:mm:ss 'UTC'", Locale.US);
    private final SimpleDateFormat localClock = new SimpleDateFormat("HH:mm:ss", Locale.US);
    private final SimpleDateFormat eventTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US);

    private WorldDataRepository repository;
    private MonitorStore monitorStore;
    private SatelliteMapView mapView;
    private LinearLayout layersPanel;
    private LinearLayout wirePanel;
    private LinearLayout tickerContainer;
    private LinearLayout catalogPanel;
    private LinearLayout catalogList;
    private LinearLayout newsCategoryBar;
    private LinearLayout detailPanel;
    private LinearLayout replayPanel;
    private TextView detailBadge;
    private TextView detailTitle;
    private TextView detailBody;
    private TextView counterText;
    private TextView clockText;
    private TextView liveText;
    private TextView feedPulse;
    private TextView telemetryText;
    private TextView acquisitionText;
    private SignalBeaconView signalBeaconView;
    private SourceMatrixView sourceMatrixView;
    private TextView crawlText;
    private TextView correlationText;
    private TextView catalogTitle;
    private TextView catalogStatus;
    private TextView leftReadout;
    private TextView rightReadout;
    private Button sourceButton;
    private Button detailShareButton;
    private Button catalogPageShareButton;
    private Button localButton;
    private Button typeButton;
    private Button regionButton;
    private Button severityButton;
    private Button timeWindowButton;
    private Button projectionButton;
    private Button catalogMoreButton;
    private Button replayPlayButton;
    private SeekBar replaySeek;
    private TextView replayStatus;
    private EditText searchInput;
    private EditText catalogSearch;
    private boolean wideLayout;
    private boolean localMode;
    private double localLatitude;
    private double localLongitude;
    private double localSouth = Double.NaN;
    private double localWest = Double.NaN;
    private double localNorth = Double.NaN;
    private double localEast = Double.NaN;
    private boolean localCountryScope;
    private String localCountryCode = "";
    private String localName = "";
    private int typeIndex;
    private int regionIndex;
    private int minimumSeverity = 1;
    private int timeWindowIndex = 2;
    private String selectedSourceUrl = "";
    private Signal selectedSignal;
    private Signal currentAcquisition;
    private boolean currentActivityIsAcquisition;
    private MediaPlayer radioPlayer;
    private String playingRadioId = "";
    private long acquisitionCount;
    private long lastWeatherFrame;
    private List<WorldDataRepository.RadarFrame> radarFrames = Collections.emptyList();
    private int scanStep;
    private int watchCursor;
    private int acquisitionAnimationToken;
    private int briefRotationCursor;
    private long lastFreshAcquisitionAtMs;
    private String catalogCategory = "AIRCRAFT";
    private String catalogNewsType = "ALL";
    private String f9CountryLens = "UGANDA";
    private String f12ReplayWindow = "NOW";
    private long f13ReplayAnchorMs = 0L;
    private int catalogVisibleLimit = 60;
    private boolean repositoryStarted;
    private boolean destroyed;
    private boolean safeMode;
    private volatile SituationAnalyzer.Brief latestBrief;
    private long lastAnalysisRequestedMs;
    private String lastCounterText = "";
    private RegionalFocus regionalFocus;
    private boolean replayMode;
    private boolean replayPlaying;
    private long replayTimeMs;
    private long replayFrameAtMs;
    private String pendingCatalog = "";
    private String pendingNewsStoryId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        utcClock.setTimeZone(TimeZone.getTimeZone("UTC"));
        eventTime.setTimeZone(TimeZone.getTimeZone("UTC"));
        regionalFocus = RegionalFocus.detect();
        captureWidgetDeepLink(getIntent());
        safeMode = getIntent().getBooleanExtra("safe_mode", false)
                || CrashLedger.shouldUseSafeMode(this);

        for (Signal.Layer layer : Signal.Layer.values()) {
            enabled.put(layer, true);
            layerSignals.put(layer, Collections.emptyList());
            feedStatuses.put(layer, FeedStatus.loading("Starting"));
        }

        wideLayout = getResources().getConfiguration().screenWidthDp >= 840;
        // Return from onCreate with a tiny usable surface first. Android can paint this frame
        // immediately instead of holding its launch screen while the full newsroom view is
        // inflated. Live feeds are attached only after the command deck is already responsive.
        showStartupShell(safeMode
                ? "OPENING RECOVERY MODE • NETWORK FEEDS PAUSED"
                : "PREPARING NATIVE COMMAND DECK");
        startupHandler.postDelayed(this::initializeApplication, STARTUP_UI_DELAY_MS);
    }

    private void showStartupShell(String message) {
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setGravity(Gravity.CENTER);
        shell.setPadding(dp(28), dp(28), dp(28), dp(28));
        shell.setBackgroundColor(BG);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.du_brand_mark);
        logo.setContentDescription("DU World Monitor globe mark");
        shell.addView(logo, new LinearLayout.LayoutParams(dp(92), dp(92)));

        TextView title = text(APP_BRAND, TEXT, 20, true);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.08f);
        shell.addView(title, marginParams(0, 8, 0, 3));

        TextView promise = text("GLOBAL SIGNALS • LOCAL WITNESSES • SOURCE AWARE",
                AMBER, 8, true);
        promise.setGravity(Gravity.CENTER);
        shell.addView(promise, marginParams(0, 0, 0, 14));

        ProgressBar progress = new ProgressBar(this);
        progress.setIndeterminateTintList(ColorStateList.valueOf(CYAN));
        shell.addView(progress, new LinearLayout.LayoutParams(dp(38), dp(38)));

        TextView state = text(message, CYAN, 9, true);
        state.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        state.setGravity(Gravity.CENTER);
        shell.addView(state, marginParams(0, 14, 0, 0));

        TextView disclosure = text(
                "THE INTERFACE OPENS FIRST • LIVE SOURCES JOIN IN THE BACKGROUND",
                MUTED, 8, false);
        disclosure.setGravity(Gravity.CENTER);
        shell.addView(disclosure, marginParams(0, 8, 0, 0));
        setContentView(shell);
    }

    private void initializeApplication() {
        if (destroyed || isFinishing()) return;
        try {
            monitorStore = new MonitorStore(this);
            buildInterface();
            repository = safeMode ? null : new WorldDataRepository(this, this);
            latestBrief = SituationAnalyzer.analyze(
                    new EnumMap<>(layerSignals), new EnumMap<>(feedStatuses),
                    System.currentTimeMillis());
            tickClockGuarded();
            tickActivityGuarded();
            applyWidgetDeepLink();
            if (safeMode) {
                feedPulse.setText("RECOVERY MODE • LIVE NETWORK FEEDS PAUSED • LOCAL DATA SAFE");
                feedPulse.setTextColor(AMBER);
            } else {
                startupHandler.postDelayed(this::startRepositoryWhenReady,
                        STARTUP_FEED_DELAY_MS);
            }
            startupHandler.postDelayed(() -> {
                if (!destroyed) CrashLedger.markStable(this);
            }, 8_000L);
        } catch (RuntimeException error) {
            Log.e(LOG_TAG, "Unable to initialise native command deck", error);
            String reference = CrashLedger.recordRecovered(
                    this, "MainActivity.initializeApplication", error);
            showStartupRecovery(reference);
        }
    }

    private void startRepositoryWhenReady() {
        if (destroyed || repositoryStarted || repository == null) return;
        repositoryStarted = true;
        try {
            repository.start();
            feedPulse.setText("SOURCE HEALTH / APP READY • LIVE SOURCES JOINING");
            feedPulse.setTextColor(CYAN);
        } catch (RuntimeException error) {
            Log.e(LOG_TAG, "Live source coordinator failed to start", error);
            feedPulse.setText("SOURCE HEALTH / APP READY • FEEDS OFFLINE • RETRY FROM MENU");
            feedPulse.setTextColor(RED);
        }
    }

    private void showStartupRecovery(String reference) {
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setGravity(Gravity.CENTER);
        shell.setPadding(dp(28), dp(28), dp(28), dp(28));
        shell.setBackgroundColor(BG);
        TextView title = text("COMMAND DECK DID NOT OPEN", RED, 15, true);
        title.setGravity(Gravity.CENTER);
        shell.addView(title, marginParams(0, 0, 0, 10));
        TextView explanation = text(
                "The failing part was contained. Open recovery mode without live network feeds, or retry the complete command deck.",
                MUTED, 10, false);
        explanation.setGravity(Gravity.CENTER);
        shell.addView(explanation, marginParams(0, 0, 0, 18));
        shell.addView(text("CRASH REFERENCE • "
                        + (reference == null || reference.isEmpty() ? "NOT AVAILABLE" : reference),
                CYAN, 8, true), marginParams(0, 0, 0, 14));
        Button safe = actionButton("OPEN RECOVERY MODE", AMBER);
        safe.setOnClickListener(view -> restartMain(true));
        shell.addView(safe, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        Button retry = actionButton("RETRY COMPLETE COMMAND DECK", CYAN);
        retry.setOnClickListener(view -> {
            safeMode = false;
            showStartupShell("RETRYING NATIVE COMMAND DECK");
            startupHandler.postDelayed(this::initializeApplication, STARTUP_UI_DELAY_MS);
        });
        shell.addView(retry, marginParams(0, 8, 0, 0));
        setContentView(shell);
    }

    private void restartMain(boolean recovery) {
        Intent restart = new Intent(this, MainActivity.class);
        restart.putExtra("safe_mode", recovery);
        startActivity(restart);
        finish();
    }

    private void buildInterface() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int top = insets.getSystemWindowInsetTop();
            int bottom = insets.getSystemWindowInsetBottom();
            if (view.getPaddingTop() != top || view.getPaddingBottom() != bottom) {
                view.setPadding(0, top, 0, bottom);
            }
            return insets;
        });

        root.addView(buildHeader(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 58 : 62)));

        FrameLayout commandDeck = new FrameLayout(this);
        mapView = new SatelliteMapView(this);
        mapView.setListener(new SatelliteMapView.Listener() {
            @Override
            public void onSignalTap(Signal signal) {
                if (signal != null && signal.id.startsWith("local-monitor:")) {
                    openLocalMonitors(signal.id.substring("local-monitor:".length()));
                } else {
                    showDetail(signal);
                }
            }

            @Override
            public void onViewportChanged(SatelliteMapView.Bounds bounds) {
                if (repository != null) {
                    repository.updateTrackingViewport(
                            bounds, !mapView.isGlobeMode(), mapView.getZoom());
                }
                if (projectionButton != null) {
                    projectionButton.setText(mapView.isGlobeMode()
                            ? "DISPLAY • GLOBE" : "DISPLAY • SATELLITE TRACKER");
                }
            }
        });
        // A broad timezone-derived lens makes the first useful view relevant immediately.
        // It uses no GPS, account, location permission or network lookup.
        mapView.setCenter(regionalFocus.latitude, regionalFocus.longitude, 2.25d);
        commandDeck.addView(mapView, fullFrame());

        View search = buildSearchBar();
        FrameLayout.LayoutParams searchParams = new FrameLayout.LayoutParams(
                wideLayout ? dp(760) : ViewGroup.LayoutParams.MATCH_PARENT,
                dp(52), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        searchParams.setMargins(wideLayout ? dp(148) : dp(12), dp(10),
                wideLayout ? dp(148) : dp(12), 0);
        search.setElevation(dp(6));
        commandDeck.addView(search, searchParams);

        View liveHud = buildLiveHud();
        FrameLayout.LayoutParams hudParams = new FrameLayout.LayoutParams(
                wideLayout ? dp(760) : ViewGroup.LayoutParams.MATCH_PARENT,
                dp(wideLayout ? 82 : 78), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        hudParams.setMargins(wideLayout ? dp(148) : dp(12), dp(wideLayout ? 72 : 66),
                wideLayout ? dp(148) : dp(12), 0);
        liveHud.setElevation(dp(5));
        commandDeck.addView(liveHud, hudParams);

        if (!wideLayout) {
            leftReadout = buildSideReadout(true);
            FrameLayout.LayoutParams leftParams = new FrameLayout.LayoutParams(
                    dp(62), dp(168), Gravity.START | Gravity.TOP);
            leftParams.setMargins(dp(7), dp(150), 0, 0);
            commandDeck.addView(leftReadout, leftParams);

            rightReadout = buildSideReadout(false);
            FrameLayout.LayoutParams rightParams = new FrameLayout.LayoutParams(
                    dp(86), dp(172), Gravity.END | Gravity.TOP);
            rightParams.setMargins(0, dp(150), dp(7), 0);
            commandDeck.addView(rightReadout, rightParams);
        }

        layersPanel = buildLayersPanel();
        FrameLayout.LayoutParams layersParams = new FrameLayout.LayoutParams(
                dp(232), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START);
        layersParams.setMargins(dp(8), dp(70), 0, dp(8));
        commandDeck.addView(layersPanel, layersParams);
        layersPanel.setElevation(dp(10));
        // The globe always owns the opening screen. Full panels appear only when requested.
        layersPanel.setVisibility(View.GONE);

        wirePanel = buildWirePanel();
        FrameLayout.LayoutParams wireParams = new FrameLayout.LayoutParams(
                dp(334), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END);
        wireParams.setMargins(0, dp(70), dp(8), dp(8));
        commandDeck.addView(wirePanel, wireParams);
        wirePanel.setElevation(dp(10));
        wirePanel.setVisibility(View.GONE);

        LinearLayout zoomRail = new LinearLayout(this);
        zoomRail.setOrientation(LinearLayout.VERTICAL);
        Button zoomIn = compactButton("+");
        Button zoomOut = compactButton("−");
        zoomIn.setOnClickListener(view -> mapView.zoomBy(1d));
        zoomOut.setOnClickListener(view -> mapView.zoomBy(-1d));
        zoomRail.addView(zoomIn, new LinearLayout.LayoutParams(dp(48), dp(48)));
        zoomRail.addView(zoomOut, new LinearLayout.LayoutParams(dp(48), dp(48)));
        FrameLayout.LayoutParams zoomParams = new FrameLayout.LayoutParams(
                dp(48), dp(100), Gravity.END | Gravity.CENTER_VERTICAL);
        zoomParams.setMargins(0, 0, dp(14), 0);
        commandDeck.addView(zoomRail, zoomParams);

        feedPulse = text("SOURCE HEALTH / INITIALISING", CYAN, 8, true);
        feedPulse.setGravity(Gravity.CENTER);
        feedPulse.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        feedPulse.setSingleLine(true);
        feedPulse.setEllipsize(TextUtils.TruncateAt.END);
        feedPulse.setShadowLayer(dp(4), 0f, dp(1), Color.BLACK);
        feedPulse.setBackgroundColor(Color.TRANSPARENT);
        feedPulse.setElevation(dp(5));
        FrameLayout.LayoutParams pulseParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 28 : 22), Gravity.BOTTOM);
        pulseParams.setMargins(wideLayout ? dp(148) : dp(12), 0,
                wideLayout ? dp(148) : dp(12), dp(wideLayout ? 10 : 5));
        commandDeck.addView(feedPulse, pulseParams);

        crawlText = text("SCANNING PUBLIC SOURCES • WAITING FOR FIRST DATA PACKET",
                TEXT, 8, true);
        crawlText.setSingleLine(true);
        crawlText.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        crawlText.setMarqueeRepeatLimit(-1);
        crawlText.setSelected(true);
        crawlText.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        crawlText.setGravity(Gravity.CENTER_VERTICAL);
        crawlText.setPadding(dp(10), 0, dp(10), 0);
        crawlText.setShadowLayer(dp(4), 0f, dp(1), Color.BLACK);
        crawlText.setBackgroundColor(Color.TRANSPARENT);
        crawlText.setElevation(dp(4));
        FrameLayout.LayoutParams crawlParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 28 : 22), Gravity.BOTTOM);
        crawlParams.setMargins(wideLayout ? dp(148) : dp(12), 0,
                wideLayout ? dp(148) : dp(12), dp(wideLayout ? 46 : 29));
        commandDeck.addView(crawlText, crawlParams);

        View missionDock = buildMissionDock();
        FrameLayout.LayoutParams dockParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 44 : 40), Gravity.BOTTOM);
        dockParams.setMargins(wideLayout ? dp(148) : dp(12), 0,
                wideLayout ? dp(148) : dp(12), dp(wideLayout ? 82 : 55));
        commandDeck.addView(missionDock, dockParams);

        correlationText = text(
                "ANALYSIS DESK / WAITING FOR SOURCE-ATTRIBUTED RECORDS\n"
                        + "CORRELATION IS NOT CONFIRMATION • NO PREDICTION",
                MUTED, wideLayout ? 8 : 7, true);
        correlationText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        correlationText.setGravity(Gravity.CENTER);
        correlationText.setMaxLines(2);
        correlationText.setEllipsize(TextUtils.TruncateAt.END);
        correlationText.setPadding(dp(8), dp(2), dp(8), dp(2));
        correlationText.setShadowLayer(dp(5), 0f, dp(1), Color.BLACK);
        correlationText.setBackgroundColor(Color.TRANSPARENT);
        correlationText.setContentDescription(
                "Observed cross-source watch. Tap to open the intelligence brief.");
        correlationText.setOnClickListener(view -> openCatalog("BRIEF"));
        FrameLayout.LayoutParams correlationParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 38 : 32), Gravity.BOTTOM);
        correlationParams.setMargins(wideLayout ? dp(148) : dp(12), 0,
                wideLayout ? dp(148) : dp(12), dp(wideLayout ? 130 : 99));
        commandDeck.addView(correlationText, correlationParams);

        replayPanel = buildReplayPanel();
        FrameLayout.LayoutParams replayParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 68 : 62), Gravity.BOTTOM);
        replayParams.setMargins(wideLayout ? dp(148) : dp(12), 0,
                wideLayout ? dp(148) : dp(12), dp(wideLayout ? 174 : 136));
        commandDeck.addView(replayPanel, replayParams);
        replayPanel.setElevation(dp(7));
        replayPanel.setVisibility(View.GONE);

        catalogPanel = buildCatalogPanel();
        FrameLayout.LayoutParams catalogParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER);
        catalogParams.setMargins(dp(wideLayout ? 70 : 10), dp(10),
                dp(wideLayout ? 70 : 10), dp(10));
        commandDeck.addView(catalogPanel, catalogParams);
        catalogPanel.setElevation(dp(20));
        catalogPanel.setVisibility(View.GONE);

        detailPanel = buildDetailPanel();
        FrameLayout.LayoutParams detailParams = new FrameLayout.LayoutParams(
                wideLayout ? dp(500) : ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | (wideLayout ? Gravity.CENTER_HORIZONTAL : Gravity.CENTER_HORIZONTAL));
        detailParams.setMargins(wideLayout ? dp(148) : dp(12), 0,
                wideLayout ? dp(148) : dp(12), dp(134));
        commandDeck.addView(detailPanel, detailParams);
        detailPanel.setElevation(dp(24));
        detailPanel.setVisibility(View.GONE);

        root.addView(commandDeck, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private View buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(6), dp(4), dp(6), dp(4));
        header.setBackgroundColor(PANEL);
        header.setElevation(dp(4));

        Button menu = headerButton(wideLayout ? "LAYERS" : "MENU");
        menu.setOnClickListener(view -> togglePanel(layersPanel));
        header.addView(menu, new LinearLayout.LayoutParams(
                dp(wideLayout ? 76 : 48), dp(44)));

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.HORIZONTAL);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        brand.setPadding(dp(wideLayout ? 12 : 7), 0, dp(wideLayout ? 12 : 5), 0);
        ImageView mark = new ImageView(this);
        mark.setImageResource(R.drawable.du_brand_mark);
        mark.setContentDescription("DU World Monitor");
        brand.addView(mark, new LinearLayout.LayoutParams(
                dp(wideLayout ? 40 : 30), dp(wideLayout ? 40 : 30)));
        LinearLayout wordmark = new LinearLayout(this);
        wordmark.setOrientation(LinearLayout.VERTICAL);
        wordmark.setPadding(dp(6), 0, 0, 0);
        TextView title = text(APP_BRAND, TEXT, wideLayout ? 15 : 10, true);
        title.setSingleLine(true);
        liveText = text(wideLayout
                        ? "● LIVE / GLOBAL SIGNALS • " + regionalFocus.name + " LENS"
                        : "● LIVE / " + regionalFocus.name,
                RED, wideLayout ? 8 : 7, true);
        wordmark.addView(title);
        wordmark.addView(liveText);
        brand.addView(wordmark, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        brand.setContentDescription(
                "DU World Monitor. Global signals, local witnesses, source-aware intelligence.");
        brand.setOnClickListener(view -> showBrandStory());
        header.addView(brand, new LinearLayout.LayoutParams(
                wideLayout ? dp(330) : 0, ViewGroup.LayoutParams.WRAP_CONTENT,
                wideLayout ? 0f : 1f));

        counterText = text("AIR 0  SEA 0  EVENTS 0", MUTED, 9, true);
        counterText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        counterText.setGravity(Gravity.CENTER);
        if (wideLayout) {
            header.addView(counterText, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        }

        clockText = text("--:--:-- UTC", TEXT, wideLayout ? 9 : 8, true);
        clockText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        clockText.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        header.addView(clockText, new LinearLayout.LayoutParams(
                wideLayout ? dp(220) : dp(86), ViewGroup.LayoutParams.MATCH_PARENT));

        Button index = headerButton("INTEL");
        index.setContentDescription("Open live intelligence brief and source index");
        index.setOnClickListener(view -> openCatalog("BRIEF"));
        header.addView(index, new LinearLayout.LayoutParams(
                dp(wideLayout ? 60 : 46), dp(44)));

        Button settings = headerButton("SET");
        settings.setContentDescription("Provider settings");
        settings.setOnClickListener(view -> showSettings());
        header.addView(settings, new LinearLayout.LayoutParams(
                dp(wideLayout ? 48 : 42), dp(44)));
        return header;
    }

    private void showBrandStory() {
        LinearLayout story = new LinearLayout(this);
        story.setOrientation(LinearLayout.VERTICAL);
        story.setPadding(dp(20), dp(14), dp(20), dp(8));
        ImageView mark = new ImageView(this);
        mark.setImageResource(R.drawable.du_brand_mark);
        mark.setContentDescription("DU World Monitor globe mark");
        story.addView(mark, new LinearLayout.LayoutParams(dp(78), dp(78)));
        story.addView(text("DU WORLD MONITOR", TEXT, 18, true),
                marginParams(0, 8, 0, 2));
        story.addView(text("SEE THE WORLD. HEAR THE LOCAL WITNESS.", AMBER, 10, true));
        story.addView(text(
                "A native global situation room for public-source aviation, maritime, hazards, weather, markets, space activity and source-labelled reports from local monitors.",
                TEXT, 10, false), marginParams(0, 10, 0, 0));
        story.addView(text(
                "Built for clarity: live source health, visible timestamps, credibility labels and local-first reporting without presenting unverified information as confirmed fact.",
                MUTED, 9, false), marginParams(0, 8, 0, 0));
        String crashReference = CrashLedger.lastReference(this);
        if (!crashReference.isEmpty()) {
            story.addView(text("LAST RECOVERY REFERENCE • " + crashReference,
                    CYAN, 8, true), marginParams(0, 10, 0, 0));
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(story)
                .setNegativeButton("CLOSE", null)
                .setPositiveButton("OPEN LOCAL MONITORS", (ignored, which) -> openLocalMonitors())
                .create();
        dialog.show();
    }

    private View buildLiveHud() {
        LinearLayout hud = new LinearLayout(this);
        hud.setOrientation(LinearLayout.VERTICAL);
        hud.setPadding(dp(8), dp(3), dp(8), dp(3));
        // Keep the globe visually dominant. This heads-up display is information painted over
        // the map, not a pair of opaque side cards.
        hud.setBackgroundColor(Color.TRANSPARENT);

        telemetryText = text("LENS / " + regionalFocus.name
                        + " • SECTOR / BOOT • AIR 0 • SEA 0 • EVENT 0 • RADIO 0 • TV 0",
                MUTED, wideLayout ? 8 : 7, true);
        telemetryText.setSingleLine(true);
        telemetryText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        telemetryText.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        telemetryText.setMarqueeRepeatLimit(-1);
        telemetryText.setSelected(true);
        telemetryText.setGravity(Gravity.CENTER_VERTICAL);
        hud.addView(telemetryText, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 20 : 16)));

        if (!wideLayout) {
            // The phone layout still exposes real provider totals; the header no longer has
            // to surrender most of its width to a long counter line.
            hud.addView(counterText, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(14)));
        }

        LinearLayout matrixRow = new LinearLayout(this);
        matrixRow.setOrientation(LinearLayout.HORIZONTAL);
        matrixRow.setGravity(Gravity.CENTER_VERTICAL);
        sourceMatrixView = new SourceMatrixView(this);
        matrixRow.addView(sourceMatrixView, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        signalBeaconView = new SignalBeaconView(this);
        matrixRow.addView(signalBeaconView, new LinearLayout.LayoutParams(
                dp(wideLayout ? 245 : 132), ViewGroup.LayoutParams.MATCH_PARENT));
        hud.addView(matrixRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 22 : 18)));

        acquisitionText = text("LATEST ACQUISITION / STARTING PUBLIC SOURCES",
                TEXT, wideLayout ? 9 : 8, true);
        acquisitionText.setSingleLine(true);
        acquisitionText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        acquisitionText.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        acquisitionText.setMarqueeRepeatLimit(-1);
        acquisitionText.setSelected(true);
        acquisitionText.setGravity(Gravity.CENTER_VERTICAL);
        acquisitionText.setContentDescription(
                "Newest source-attributed acquisition. Tap to open full details.");
        acquisitionText.setOnClickListener(view -> {
            if (currentAcquisition != null) showDetail(currentAcquisition);
            else togglePanel(wirePanel);
        });
        hud.addView(acquisitionText, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(wideLayout ? 32 : 24)));
        return hud;
    }

    /**
     * A small, always-available mission dock replaces persistent side panels. Every action
     * opens an existing native page or map mode; it never launches a hosted dashboard.
     */
    // GLOBE-ONLY RULE — THE GLOBE IS THE APP.
    private void globeOnlyRoute(String feature){
        showGlobeOverview();
        if(feature==null)return;
        String f=feature.toUpperCase(Locale.ROOT);
        if("REPLAY".equals(f)||"TIMELINE".equals(f))toggleReplayPanel();
        else if("SETTINGS".equals(f)||"SET".equals(f))showSettings();
        else if("SEARCH".equals(f))showGlobeOverview();
        else showGlobeOverview();
    }

    private View buildMissionDock() {
        HorizontalScrollView scroller=new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);scroller.setFillViewport(true);
        scroller.setBackground(panelBackground(Color.argb(212,8,12,17),LINE,14));
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(4),0,dp(4),0);
        addMissionAction(row,"GLOBE",view->showGlobeOverview());
        addMissionAction(row,"LAYERS",view->showGlobeOverview());
        addMissionAction(row,"SEARCH",view->showGlobeOverview());
        addMissionAction(row,"TIMELINE",view->toggleReplayPanel());
        addMissionAction(row,"SET",view->showSettings());
        scroller.addView(row,new HorizontalScrollView.LayoutParams(-2,-1));
        return scroller;
    }

    private LinearLayout buildReplayPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(7), dp(3), dp(7), dp(3));
        panel.setBackground(panelBackground(Color.argb(226, 8, 12, 17), CYAN, 14));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        replayStatus = text("4D REPLAY / WAITING FOR ACQUIRED FRAMES", CYAN,
                wideLayout ? 8 : 7, true);
        replayStatus.setSingleLine(true);
        replayStatus.setEllipsize(TextUtils.TruncateAt.END);
        replayStatus.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        row.addView(replayStatus, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        replayPlayButton = compactButton("PLAY");
        replayPlayButton.setOnClickListener(view -> toggleReplayPlayback());
        row.addView(replayPlayButton, new LinearLayout.LayoutParams(dp(56), dp(29)));
        Button live = compactButton("LIVE");
        live.setTextColor(GREEN);
        live.setOnClickListener(view -> returnToLive());
        row.addView(live, new LinearLayout.LayoutParams(dp(56), dp(29)));
        Button close = compactButton("×");
        close.setOnClickListener(view -> replayPanel.setVisibility(View.GONE));
        row.addView(close, new LinearLayout.LayoutParams(dp(34), dp(29)));
        panel.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(30)));

        replaySeek = new SeekBar(this);
        replaySeek.setMax(1_000);
        replaySeek.setProgress(1_000);
        replaySeek.setProgressTintList(ColorStateList.valueOf(CYAN));
        replaySeek.setThumbTintList(ColorStateList.valueOf(TEXT));
        replaySeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar seekBar) {
                replayPlaying = false;
                replayPlayButton.setText("PLAY");
            }

            @Override public void onProgressChanged(
                    SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) enterReplayProgress(progress);
            }

            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        panel.addView(replaySeek, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));
        return panel;
    }

    private void addMissionAction(
            LinearLayout parent,
            String label,
            View.OnClickListener listener) {
        Button action = headerButton(label);
        action.setTextColor(TEXT);
        action.setOnClickListener(listener);
        int width = Math.max(62, label.length() * 9 + 22);
        parent.addView(action, new LinearLayout.LayoutParams(dp(width), dp(40)));
    }

    private void toggleReplayPanel() {
        if (replayPanel == null) return;
        if (replayPanel.getVisibility() == View.VISIBLE) {
            replayPanel.setVisibility(View.GONE);
            return;
        }
        replayPanel.setVisibility(View.VISIBLE);
        replayPanel.bringToFront();
        updateReplayStatus();
        if (replayEngine.frameCount() == 0) {
            Toast.makeText(this,
                    "Replay begins after the first mapped source frame is acquired",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void enterReplayProgress(int progress) {
        long oldest = replayEngine.oldestMs();
        long newest = replayEngine.newestMs();
        if (oldest <= 0L || newest <= 0L) {
            replayMode = false;
            updateReplayStatus();
            return;
        }
        replayMode = true;
        replayTimeMs = oldest + Math.round((newest - oldest)
                * Math.max(0, Math.min(1_000, progress)) / 1_000d);
        applyFilters();
    }

    private void toggleReplayPlayback() {
        if (replayEngine.frameCount() == 0) {
            Toast.makeText(this, "No acquired replay frame yet", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!replayMode) enterReplayProgress(0);
        replayPlaying = !replayPlaying;
        replayPlayButton.setText(replayPlaying ? "PAUSE" : "PLAY");
        updateReplayStatus();
    }

    private void returnToLive() {
        replayMode = false;
        replayPlaying = false;
        replayTimeMs = 0L;
        replayFrameAtMs = 0L;
        if (replaySeek != null) replaySeek.setProgress(1_000);
        if (replayPlayButton != null) replayPlayButton.setText("PLAY");
        if (mapView != null) mapView.setReplayState(false, 0L);
        if (mapView != null) mapView.setRadarAnimationPlaying(true);
        applyFilters();
        updateReplayStatus();
    }

    private void advanceReplay() {
        if (!replayMode || !replayPlaying) return;
        long newest = replayEngine.newestMs();
        long oldest = replayEngine.oldestMs();
        if (newest <= 0L || oldest <= 0L) {
            returnToLive();
            return;
        }
        replayTimeMs = Math.min(newest, replayTimeMs + 15_000L);
        if (replayTimeMs >= newest) replayPlaying = false;
        int progress = newest == oldest ? 1_000 : (int) Math.round(
                (replayTimeMs - oldest) * 1_000d / (newest - oldest));
        replaySeek.setProgress(Math.max(0, Math.min(1_000, progress)));
        replayPlayButton.setText(replayPlaying ? "PAUSE" : "PLAY");
        applyFilters();
    }

    private void updateReplayStatus() {
        if (replayStatus == null) return;
        int frames = replayEngine.frameCount();
        if (!replayMode) {
            long span = Math.max(0L, replayEngine.newestMs() - replayEngine.oldestMs());
            replayStatus.setText(String.format(Locale.US,
                    "LIVE / 4D BUFFER %d FRAMES • %dm • THIS SESSION",
                    frames, span / 60_000L));
            replayStatus.setTextColor(GREEN);
            return;
        }
        long shown = replayFrameAtMs > 0L ? replayFrameAtMs : replayTimeMs;
        replayStatus.setText("4D REPLAY / " + eventTime.format(new Date(shown))
                + " • ACQUIRED FRAMES ONLY" + (replayPlaying ? " • PLAYING" : " • PAUSED"));
        replayStatus.setTextColor(AMBER);
    }

    private long currentTimelineMs() {
        return replayMode && replayFrameAtMs > 0L
                ? replayFrameAtMs : System.currentTimeMillis();
    }

    private void showGlobeOverview() { 
        // All systems now belong to the Globe: NEWS · MONITORS · REGION · REPLAY · AIR · SEA · WX · ORBIT · EVENTS · INFRA.

        if (layersPanel != null) layersPanel.setVisibility(View.GONE);
        if (wirePanel != null) wirePanel.setVisibility(View.GONE);
        if (catalogPanel != null) catalogPanel.setVisibility(View.GONE);
        if (detailPanel != null) detailPanel.setVisibility(View.GONE);
        mapView.stopFollowing();
        mapView.setGlobeMode(true);
        Toast.makeText(this, "Global live globe", Toast.LENGTH_SHORT).show();
    }

    private void showRegionalOverview() {
        if (layersPanel != null) layersPanel.setVisibility(View.GONE);
        if (wirePanel != null) wirePanel.setVisibility(View.GONE);
        if (catalogPanel != null) catalogPanel.setVisibility(View.GONE);
        if (detailPanel != null) detailPanel.setVisibility(View.GONE);
        mapView.stopFollowing();
        mapView.setCenter(regionalFocus.latitude, regionalFocus.longitude, 5.0d);
        Toast.makeText(this,
                "REGIONAL LENS — " + regionalFocus.name
                        + " • derived from timezone only, not GPS",
                Toast.LENGTH_LONG).show();
    }

    private TextView buildSideReadout(boolean left) {
        // Side readouts are words and figures only: no cards, rails or touch-blocking
        // full-height panels over the globe.
        TextView rail = text(left
                        ? regionalFocus.name
                        + "\nBOOT • 24H\n\nAIR 0\nSEA 0\nEVT 0\nCAM 0\nMEDIA 0"
                        : "LATEST SIGNAL\n\nSCANNING\nPUBLIC SOURCES",
                MUTED, 7, true);
        rail.setGravity(left ? Gravity.TOP | Gravity.START : Gravity.TOP | Gravity.END);
        rail.setPadding(dp(2), dp(4), dp(2), dp(4));
        rail.setLineSpacing(dp(2), 1.08f);
        rail.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        rail.setLetterSpacing(0.04f);
        rail.setShadowLayer(dp(5), 0f, dp(1), Color.BLACK);
        rail.setBackgroundColor(Color.TRANSPARENT);
        rail.setMaxLines(left ? 8 : 10);
        rail.setEllipsize(TextUtils.TruncateAt.END);
        if (left) {
            rail.setContentDescription("Live layer counts. Tap to open Layers.");
            rail.setOnClickListener(view -> togglePanel(layersPanel));
        } else {
            rail.setContentDescription("Newest acquired activity. Tap for full details.");
            rail.setOnClickListener(view -> {
                if (currentAcquisition != null) showDetail(currentAcquisition);
                else togglePanel(wirePanel);
            });
        }
        return rail;
    }

    private View buildSearchBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(5), dp(4), dp(5), dp(4));
        bar.setBackground(panelBackground(Color.argb(232, 8, 12, 17), LINE, 20));

        searchInput = new EditText(this);
        searchInput.setHint("LOCATE CITY OR COUNTRY");
        searchInput.setHintTextColor(MUTED);
        searchInput.setTextColor(TEXT);
        searchInput.setTextSize(12);
        searchInput.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        searchInput.setSingleLine(true);
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchInput.setBackgroundColor(Color.TRANSPARENT);
        searchInput.setPadding(dp(10), 0, dp(6), 0);
        searchInput.setOnEditorActionListener((view, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                runSearch();
                return true;
            }
            return false;
        });
        bar.addView(searchInput, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        Button search = compactButton("GO");
        search.setOnClickListener(view -> runSearch());
        bar.addView(search, new LinearLayout.LayoutParams(dp(48), dp(42)));

        localButton = compactButton("LOCAL OFF");
        localButton.setOnClickListener(view -> toggleLocalMode());
        bar.addView(localButton, new LinearLayout.LayoutParams(dp(90), dp(42)));
        return bar;
    }

    /**
     * Full-screen native source index. Large provider responses are rendered in batches so a
     * phone never has to inflate thousands of cards at once.
     */
    private LinearLayout buildCatalogPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(10), dp(12), dp(10));
        panel.setBackground(panelBackground(Color.argb(250, 5, 8, 12), LINE, 20));

        LinearLayout command = new LinearLayout(this);
        command.setGravity(Gravity.CENTER_VERTICAL);
        catalogTitle = text("LIVE SOURCE INDEX / AIRCRAFT", TEXT, wideLayout ? 15 : 12, true);
        command.addView(catalogTitle, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button close = compactButton("CLOSE");
        close.setOnClickListener(view -> panel.setVisibility(View.GONE));
        command.addView(close, new LinearLayout.LayoutParams(dp(72), dp(44)));
        panel.addView(command);

        TextView disclosure = text(
                "PROVIDER-RETURNED RECORDS • PUBLIC SOURCES • AVAILABILITY VARIES",
                MUTED, 8, true);
        disclosure.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        panel.addView(disclosure, marginParams(0, 2, 0, 8));

        catalogPageShareButton = actionButton("SHARE THIS PAGE AS CARD", GREEN);
        catalogPageShareButton.setContentDescription(
                "Create a DU World Monitor image card for this information page");
        catalogPageShareButton.setOnClickListener(view -> shareCurrentPage());
        panel.addView(catalogPageShareButton, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        HorizontalScrollView categoryScroller = new HorizontalScrollView(this);
        categoryScroller.setHorizontalScrollBarEnabled(false);
        LinearLayout categories = new LinearLayout(this);
        categories.setOrientation(LinearLayout.HORIZONTAL);
        for (String category : CATALOG_CATEGORIES) {
            Button button = compactButton(category);
            button.setOnClickListener(view -> openCatalog(category));
            categories.addView(button, new LinearLayout.LayoutParams(
                    dp(Math.max(72, category.length() * 9 + 22)), dp(42)));
        }
        categoryScroller.addView(categories);
        panel.addView(categoryScroller, marginParams(0, 0, 0, 8));

        catalogSearch = new EditText(this);
        catalogSearch.setHint("FILTER THIS PAGE BY NAME, COUNTRY, CALL SIGN OR DETAIL");
        catalogSearch.setHintTextColor(MUTED);
        catalogSearch.setTextColor(TEXT);
        catalogSearch.setTextSize(11);
        catalogSearch.setSingleLine(true);
        catalogSearch.setPadding(dp(12), 0, dp(12), 0);
        catalogSearch.setBackground(panelBackground(PANEL_ALT, LINE, 14));
        catalogSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence value, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence value, int start, int before, int count) {
                catalogVisibleLimit = 60;
                rebuildCatalogPage();
            }
            @Override public void afterTextChanged(Editable value) { }
        });
        panel.addView(catalogSearch, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        newsCategoryBar = new LinearLayout(this);
        newsCategoryBar.setOrientation(LinearLayout.HORIZONTAL);
        for (String type : NEWS_CATEGORIES) {
            Button button = compactButton(type);
            button.setOnClickListener(view -> {
                catalogNewsType = type;
                catalogVisibleLimit = 60;
                rebuildCatalogPage();
            });
            newsCategoryBar.addView(button, new LinearLayout.LayoutParams(dp(92), dp(40)));
        }
        HorizontalScrollView newsScroller = new HorizontalScrollView(this);
        newsScroller.setHorizontalScrollBarEnabled(false);
        newsScroller.addView(newsCategoryBar);
        panel.addView(newsScroller, marginParams(0, 7, 0, 5));

        catalogStatus = text("WAITING FOR AIRCRAFT SOURCE", CYAN, 9, true);
        catalogStatus.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        panel.addView(catalogStatus, marginParams(0, 2, 0, 6));

        catalogList = new LinearLayout(this);
        catalogList.setOrientation(LinearLayout.VERTICAL);
        ScrollView listScroller = new ScrollView(this);
        listScroller.setFillViewport(true);
        listScroller.addView(catalogList);
        panel.addView(listScroller, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        catalogMoreButton = actionButton("LOAD 60 MORE", CYAN);
        catalogMoreButton.setOnClickListener(view -> {
            catalogVisibleLimit += 60;
            rebuildCatalogPage();
        });
        panel.addView(catalogMoreButton, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
        return panel;
    }

    private void openCatalog(String category) {
        catalogCategory = category == null ? "AIRCRAFT"
                : category.trim().toUpperCase(Locale.ROOT);
        if ("MONITORS".equals(catalogCategory)) {
            openLocalMonitors();
            return;
        }
        catalogVisibleLimit = 60;
        catalogNewsType = "NEWS".equals(catalogCategory) ? "UGANDA" : "ALL";
        if ("NEWS".equals(catalogCategory)) f17RestoreState();
        if (catalogSearch != null) catalogSearch.setText("");
        detailPanel.setVisibility(View.GONE);
        if (!wideLayout) {
            layersPanel.setVisibility(View.GONE);
            wirePanel.setVisibility(View.GONE);
        }
        catalogPanel.setVisibility(View.VISIBLE);
        catalogPanel.bringToFront();
        rebuildCatalogPage();
        if ("NEWS".equals(catalogCategory)) { maybeAskNewsPermission(); refreshLocalNews(false); }
    }

    private void openLocalMonitors() {
        openLocalMonitors("");
    }

    private void openLocalMonitors(String reportId) {
        Intent intent = new Intent(this, LocalMonitorActivity.class);
        if (reportId != null && !reportId.trim().isEmpty()) {
            intent.putExtra("report_id", reportId.trim());
        }
        startActivity(intent);
    }

    private String categoryForLayer(Signal.Layer layer) {
        switch (layer) {
            case FLIGHTS: return "AIRCRAFT";
            case SHIPS: return "SHIPS";
            case WEATHER: return "WEATHER";
            case AIRSPACE: return "AIRSPACE";
            case NATURAL: return "EVENTS";
            case NEWS: return "NEWS";
            case SATELLITES: return "ORBITS";
            case SPACE_WEATHER: return "SPACE";
            case INFRASTRUCTURE: return "INFRA";
            case MARKETS: return "MARKETS";
            case WEBCAMS: return "CAMERAS";
            case RADIO: return "RADIO";
            case TV: return "TV";
            case MEDIA: return "CALLS";
            default: return "AIRCRAFT";
        }
    }

    private Signal.Layer layerForCategory(String category) {
        switch (category) {
            case "AIRCRAFT": return Signal.Layer.FLIGHTS;
            case "SHIPS":
            case "BOATS": return Signal.Layer.SHIPS;
            case "WEATHER": return Signal.Layer.WEATHER;
            case "AIRSPACE": return Signal.Layer.AIRSPACE;
            case "EVENTS": return Signal.Layer.NATURAL;
            case "NEWS": return Signal.Layer.NEWS;
            case "ORBITS": return Signal.Layer.SATELLITES;
            case "SPACE": return Signal.Layer.SPACE_WEATHER;
            case "INFRA": return Signal.Layer.INFRASTRUCTURE;
            case "AIRPORTS":
            case "RUNWAYS":
            case "PORTS": return Signal.Layer.INFRASTRUCTURE;
            case "MARKETS": return Signal.Layer.MARKETS;
            case "CAMERAS": return Signal.Layer.WEBCAMS;
            case "RADIO": return Signal.Layer.RADIO;
            case "TV": return Signal.Layer.TV;
            case "CALLS": return Signal.Layer.MEDIA;
            default: return Signal.Layer.FLIGHTS;
        }
    }

    private void rebuildCatalogPage() {
        if (catalogPanel == null || catalogPanel.getVisibility() != View.VISIBLE
                || catalogList == null) return;
        if ("BRIEF".equals(catalogCategory)) {
            rebuildSituationBrief();
            return;
        }
        if ("FUSION".equals(catalogCategory)) {
            rebuildFusionPage();
            return;
        }
        if ("RISK".equals(catalogCategory)) {
            rebuildCountryRiskPage();
            return;
        }
        if ("ANALYST".equals(catalogCategory)) {
            rebuildAnalystPage();
            return;
        }
        if ("WIDGETS".equals(catalogCategory)) {
            rebuildWidgetsPage();
            return;
        }
        if ("SOURCES".equals(catalogCategory)) {
            rebuildSourcesPage();
            return;
        }
        if ("WEATHER".equals(catalogCategory)) {
            rebuildWeatherPage();
            return;
        }
        if ("NEWS".equals(catalogCategory)) {
            rebuildLocalNewsPage();
            return;
        }
        Signal.Layer layer = layerForCategory(catalogCategory);
        FeedStatus status = feedStatuses.get(layer);
        List<Signal> values = catalogSignals();
        catalogList.removeAllViews();
        catalogSearch.setVisibility(View.VISIBLE);
        catalogTitle.setText("LIVE SOURCE INDEX / " + catalogCategory
                + ("NEWS".equals(catalogCategory) && !"ALL".equals(catalogNewsType)
                ? " / " + catalogNewsType : ""));
        newsCategoryBar.setVisibility("NEWS".equals(catalogCategory)
                ? View.VISIBLE : View.GONE);

        String state = status == null ? "STARTING" : status.state.name();
        String message = status == null ? "Waiting for source" : status.message;
        String age = sourceAgeText(layer);
        int visible = Math.min(catalogVisibleLimit, values.size());
        catalogStatus.setText(String.format(Locale.US,
                "SHOWING %,d / %,d RETAINED • PROVIDER %,d • %s • SOURCE AGE %s • %s",
                visible, values.size(), status == null ? values.size() : status.count,
                state, age, message));
        catalogStatus.setTextColor(status != null && status.state == FeedStatus.State.OFFLINE
                ? RED : status != null && (status.state == FeedStatus.State.KEY_REQUIRED
                || status.state == FeedStatus.State.LOADING
                || status.state == FeedStatus.State.DELAYED
                || status.state == FeedStatus.State.CACHED) ? AMBER : GREEN);

        if (values.isEmpty()) {
            String reason;
            if ("WEATHER".equals(catalogCategory)) {
                reason = "WEATHER IS A LIVE MAP LAYER. USE SOURCE CONTROL TO DISPLAY THE LATEST RAINVIEWER FRAME.";
            } else if (status != null && status.state == FeedStatus.State.KEY_REQUIRED) {
                reason = status.message + " — OPEN PROVIDER SETTINGS TO CONNECT THIS OPTIONAL SOURCE.";
            } else {
                reason = "NO PROVIDER RECORDS MATCH THIS PAGE AND FILTER YET.";
            }
            TextView empty = text(reason, MUTED, 11, true);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(20), dp(40), dp(20), dp(40));
            catalogList.addView(empty, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        } else {
            for (int index = 0; index < visible; index++) {
                catalogList.addView(buildCatalogCard(values.get(index)),
                        marginParams(0, 0, 0, 7));
            }
        }
        catalogMoreButton.setVisibility(visible < values.size() ? View.VISIBLE : View.GONE);
    }

    /** Full-screen source-aware brief inspired by a newsroom assignment desk, not a forecast. */
    private void rebuildSituationBrief() {
        long now = currentTimelineMs();
        SituationAnalyzer.Brief brief = replayMode
                ? SituationAnalyzer.analyze(layersForTimeline(), feedStatuses, now)
                : latestBrief;
        if (brief == null) {
            brief = SituationAnalyzer.analyze(layerSignals, feedStatuses, now);
            latestBrief = brief;
        }
        final SituationAnalyzer.Brief shareBrief = brief;
        updateAnalysisRibbon();
        catalogList.removeAllViews();
        catalogTitle.setText("GLOBAL INTELLIGENCE BRIEF / SOURCE-AWARE");
        catalogSearch.setVisibility(View.GONE);
        newsCategoryBar.setVisibility(View.GONE);
        catalogMoreButton.setVisibility(View.GONE);
        catalogStatus.setText(String.format(Locale.US,
                "UPDATED %s • %,d PROVIDER RECORDS • %,d FRESH BY LAYER-SPECIFIC WINDOWS",
                eventTime.format(new Date(now)), brief.totalRecords, brief.freshRecords));
        catalogStatus.setTextColor(brief.offlineFeeds > 0 ? AMBER : GREEN);

        List<NewsItem> briefNews = new NewsStore(this).topUganda(3);
        if (!briefNews.isEmpty()) {
            catalogList.addView(text("UGANDA / TOP LOCAL NEWS", CYAN, 10, true), marginParams(0,0,0,4));
            for (NewsItem item : briefNews) catalogList.addView(buildLocalNewsCard(item), marginParams(0,0,0,5));
        }

        TextView disclosure = text(
                "OBSERVED OPEN-SOURCE SIGNALS ONLY • CORRELATION IS NOT CONFIRMATION • NO PREDICTION",
                AMBER, 9, true);
        disclosure.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        disclosure.setPadding(0, dp(4), 0, dp(8));
        catalogList.addView(disclosure);

        HorizontalScrollView metricScroller = new HorizontalScrollView(this);
        metricScroller.setHorizontalScrollBarEnabled(false);
        LinearLayout metrics = new LinearLayout(this);
        metrics.setOrientation(LinearLayout.HORIZONTAL);
        metrics.addView(buildBriefMetric("READY", brief.onlineFeeds, GREEN));
        metrics.addView(buildBriefMetric("CACHED", brief.cachedFeeds, AMBER));
        metrics.addView(buildBriefMetric("OFFLINE", brief.offlineFeeds, RED));
        metrics.addView(buildBriefMetric("OPTIONAL", brief.optionalFeeds, CYAN));
        metrics.addView(buildBriefMetric("PRIORITY", brief.prioritySignals, RED));
        metrics.addView(buildBriefMetric("DOMAIN WATCH", brief.domainWatches.size(), CYAN));
        metrics.addView(buildBriefMetric("CORRELATED", brief.correlations.size(), AMBER));
        metricScroller.addView(metrics);
        catalogList.addView(metricScroller, marginParams(0, 0, 0, 12));

        addBriefHeading("REGIONAL OBSERVED SIGNAL DENSITY",
                "Weighted from recent event records, age and stated credibility. Not a risk forecast.");
        for (SituationAnalyzer.RegionalState region : brief.regions) {
            int color = region.observedScore >= 55 ? RED
                    : region.observedScore >= 30 ? AMBER : GREEN;
            TextView line = text(String.format(Locale.US,
                    "● %-12s  %02d/99  %-21s  RECORDS %,d  PRIORITY %,d  12H Δ%+d  •  SHARE CARD",
                    region.region, region.observedScore, region.level,
                    region.recordCount, region.priorityCount,
                    region.twelveHourMovement()), color, 9, true);
            line.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            line.setPadding(dp(8), dp(7), dp(8), dp(7));
            line.setOnClickListener(view -> {
                Map<String, String> regionalFacts = new LinkedHashMap<>();
                regionalFacts.put("OBSERVED SCORE", region.observedScore + " / 99");
                regionalFacts.put("LEVEL", region.level);
                regionalFacts.put("RECORDS", String.format(Locale.US, "%,d", region.recordCount));
                regionalFacts.put("PRIORITY", String.format(Locale.US, "%,d", region.priorityCount));
                regionalFacts.put("12-HOUR MOVEMENT", String.format(Locale.US, "%+d",
                        region.twelveHourMovement()));
                ShareCardRenderer.share(this, customShareCard(
                        region.region + " observed signal density",
                        "Weighted from recent source-attributed event records, age and stated credibility.",
                        region.level, "OBSERVED INDICATOR — NOT CONFIRMATION",
                        "REGIONAL BRIEF", region.region,
                        Math.max(1, Math.min(5, 1 + region.observedScore / 20)),
                        APP_BRAND + " intelligence brief", now,
                        Double.NaN, Double.NaN, regionalFacts, color,
                        "Observed density is not a risk forecast. Provider coverage varies by region."));
            });
            catalogList.addView(line);
        }

        addBriefHeading("CROSS-DOMAIN PROXIMITY WATCHES",
                "Recent mapped event records compared with nearby provider aircraft and vessel fixes. Proximity is not causation or confirmation.");
        if (brief.domainWatches.isEmpty()) {
            catalogList.addView(text(
                    "NO EVENT COORDINATE CURRENTLY OVERLAPS RECENT AIR OR SEA TELEMETRY INSIDE THE STATED WINDOWS.",
                    MUTED, 10, true), marginParams(0, 4, 0, 10));
        } else {
            for (SituationAnalyzer.DomainWatch watch : brief.domainWatches) {
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(12), dp(10), dp(12), dp(10));
                int accent = watch.severity >= 4 ? RED : CYAN;
                card.setBackground(panelBackground(PANEL_ALT, accent, 14));
                card.addView(text("● OBSERVED PROXIMITY • " + watch.observedDomains
                        + " DOMAINS • NOT CONFIRMATION", accent, 8, true));
                card.addView(text(watch.label, TEXT, 11, true),
                        marginParams(0, 4, 0, 3));
                card.addView(text(String.format(Locale.US,
                        "AIR %,d / 500 km   •   SEA %,d / 300 km   •   EVENTS %,d   •   PUBLISHERS %,d",
                        watch.aircraftNearby, watch.vesselsNearby, watch.relatedEvents,
                        watch.distinctSources), Color.rgb(202, 215, 222), 9, true));
                card.addView(text(watch.explanation, MUTED, 8, false),
                        marginParams(0, 5, 0, 0));
                TextView source = text("ANCHOR  " + watch.anchor.source + "  •  "
                        + eventTime.format(new Date(watch.anchor.timestampMs)),
                        MUTED, 8, false);
                source.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
                card.addView(source, marginParams(0, 6, 0, 0));
                Button share = compactButton("SHARE CARD");
                share.setTextColor(GREEN);
                share.setOnClickListener(view -> {
                    Map<String, String> watchFacts = new LinkedHashMap<>();
                    watchFacts.put("OBSERVED DOMAINS", String.valueOf(watch.observedDomains));
                    watchFacts.put("AIR WITHIN 500 KM", String.valueOf(watch.aircraftNearby));
                    watchFacts.put("SEA WITHIN 300 KM", String.valueOf(watch.vesselsNearby));
                    watchFacts.put("RELATED EVENTS", String.valueOf(watch.relatedEvents));
                    watchFacts.put("DISTINCT PUBLISHERS", String.valueOf(watch.distinctSources));
                    ShareCardRenderer.share(this, customShareCard(
                            watch.label, watch.explanation, "CROSS-DOMAIN WATCH",
                            "OBSERVED PROXIMITY — NOT CONFIRMATION", "INTELLIGENCE BRIEF",
                            watch.anchor.region, watch.severity, watch.anchor.source,
                            watch.anchor.timestampMs, watch.anchor.latitude,
                            watch.anchor.longitude, watchFacts, accent,
                            "Proximity is not causation or confirmation. Verify the anchor event at its original source."));
                });
                card.addView(share, marginParams(0, 7, 0, 0));
                card.setOnClickListener(view -> showDetail(watch.anchor));
                catalogList.addView(card, marginParams(0, 0, 0, 7));
            }
        }

        addBriefHeading("CROSS-SOURCE CORRELATIONS",
                "Distinct publisher records aligned by place or headline language inside 12 hours.");
        if (brief.correlations.isEmpty()) {
            catalogList.addView(text(
                    "NO MULTI-SOURCE CLUSTERS MEET THE CURRENT TRANSPARENT RULES.",
                    MUTED, 10, true), marginParams(0, 4, 0, 10));
        } else {
            for (SituationAnalyzer.Correlation correlation : brief.correlations) {
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(12), dp(10), dp(12), dp(10));
                int accent = correlation.severity >= 4 ? RED : AMBER;
                card.setBackground(panelBackground(PANEL_ALT, accent, 14));
                card.addView(text("● CORRELATED SIGNALS • NOT CONFIRMATION • SEV "
                        + correlation.severity, accent, 8, true));
                card.addView(text(correlation.label, TEXT, 11, true),
                        marginParams(0, 4, 0, 3));
                card.addView(text(correlation.explanation, Color.rgb(202, 215, 222),
                        9, false));
                TextView source = text("SOURCES  " + correlation.sources + "  •  "
                        + eventTime.format(new Date(correlation.newestTimestampMs)),
                        MUTED, 8, false);
                source.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
                card.addView(source, marginParams(0, 6, 0, 0));
                Button share = compactButton("SHARE CARD");
                share.setTextColor(GREEN);
                share.setOnClickListener(view -> {
                    Map<String, String> correlationFacts = new LinkedHashMap<>();
                    correlationFacts.put("RECORDS", String.valueOf(correlation.recordCount));
                    correlationFacts.put("DISTINCT SOURCES", correlation.sources);
                    correlationFacts.put("SEVERITY", String.valueOf(correlation.severity));
                    ShareCardRenderer.share(this, customShareCard(
                            correlation.label, correlation.explanation,
                            "CROSS-SOURCE WATCH", "CORRELATED SIGNALS — NOT CONFIRMATION",
                            "INTELLIGENCE BRIEF", correlation.primary.region,
                            correlation.severity, correlation.sources,
                            correlation.newestTimestampMs, correlation.primary.latitude,
                            correlation.primary.longitude, correlationFacts, accent,
                            "Language or place alignment across sources is not confirmation. Read the original reports."));
                });
                card.addView(share, marginParams(0, 7, 0, 0));
                card.setOnClickListener(view -> showDetail(correlation.primary));
                catalogList.addView(card, marginParams(0, 0, 0, 7));
            }
        }

        addBriefHeading("SOURCE HEALTH AND COVERAGE",
                "Counts are provider-returned coverage, never a claim to show every object on Earth.");
        for (Signal.Layer layer : Signal.Layer.values()) {
            FeedStatus status = feedStatuses.get(layer);
            if (status == null) continue;
            TextView line = text(String.format(Locale.US,
                    "● %-17s  %-12s  %,6d  AGE %-7s  %s  •  %s",
                    feedDisplayName(layer), status.state.name(), status.count,
                    sourceAgeText(layer),
                    eventTime.format(new Date(status.updatedAtMs)), status.message),
                    feedStateColor(status), 8, true);
            line.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
            line.setPadding(dp(8), dp(7), dp(8), dp(7));
            line.append("  •  SHARE CARD");
            line.setOnClickListener(view -> {
                Map<String, String> healthFacts = new LinkedHashMap<>();
                healthFacts.put("STATE", status.state.name());
                healthFacts.put("RECORDS", String.format(Locale.US, "%,d", status.count));
                healthFacts.put("MESSAGE", status.message);
                ShareCardRenderer.share(this, customShareCard(
                        feedDisplayName(layer) + " source health",
                        status.message, status.state.name(),
                        "PROVIDER HEALTH — NOT EVENT CONFIRMATION", "SOURCE HEALTH",
                        "GLOBAL", status.state == FeedStatus.State.OFFLINE ? 4 : 1,
                        feedDisplayName(layer), status.updatedAtMs, Double.NaN, Double.NaN,
                        healthFacts, feedStateColor(status),
                        "Counts are provider-returned coverage and never a claim to show every object on Earth."));
            });
            catalogList.addView(line);
        }

        addBriefHeading("CREDIBILITY INVENTORY",
                "Urgency lights and truth status remain separate throughout the app.");
        TextView credibility = text(String.format(Locale.US,
                "RAW TELEMETRY %,d   •   CALCULATED %,d   •   REPORTED %,d   •   OFFICIAL/CONFIRMED %,d",
                brief.rawSignals, brief.calculatedSignals,
                brief.reportedSignals, brief.officialSignals),
                CYAN, 10, true);
        credibility.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        credibility.setPadding(dp(8), dp(8), dp(8), dp(16));
        credibility.append("\nSHARE CARD");
        credibility.setOnClickListener(view -> {
            Map<String, String> credibilityFacts = new LinkedHashMap<>();
            credibilityFacts.put("RAW TELEMETRY", String.format(Locale.US, "%,d", shareBrief.rawSignals));
            credibilityFacts.put("CALCULATED FROM PUBLIC ELEMENTS",
                    String.format(Locale.US, "%,d", shareBrief.calculatedSignals));
            credibilityFacts.put("REPORTED", String.format(Locale.US, "%,d", shareBrief.reportedSignals));
            credibilityFacts.put("OFFICIAL / CONFIRMED",
                    String.format(Locale.US, "%,d", shareBrief.officialSignals));
            ShareCardRenderer.share(this, customShareCard(
                    "Credibility inventory",
                    "Current inventory keeps operational urgency separate from corroboration status.",
                    "INVENTORY", "MIXED SOURCE STATES", "INTELLIGENCE BRIEF", "GLOBAL",
                    1, APP_BRAND + " credibility desk", now, Double.NaN, Double.NaN,
                    credibilityFacts, CYAN,
                    "Open individual records for their source, timestamp and exact credibility status."));
        });
        catalogList.addView(credibility);
    }

    private void rebuildFusionPage() {
        long now = currentTimelineMs();
        List<IncidentFusionEngine.Scene> scenes = IncidentFusionEngine.build(
                layersForTimeline(), now);
        prepareSpecialCatalog("4D INCIDENT FUSION / OBSERVED ALIGNMENT",
                String.format(Locale.US,
                        "%s • %,d SCENES • AIR ≤500 KM • SEA ≤300 KM • ORBIT ≤900 KM • AIRSPACE ≤650 KM",
                        replayMode ? "REPLAY " + eventTime.format(new Date(now)) : "LIVE",
                        scenes.size()), scenes.isEmpty() ? MUTED : AMBER);

        TextView disclosure = text(
                "PROXIMITY, TIMING AND SOURCE ALIGNMENT ARE ANALYST LEADS — NEVER CAUSATION OR CONFIRMATION",
                AMBER, 9, true);
        disclosure.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        disclosure.setPadding(0, dp(4), 0, dp(10));
        catalogList.addView(disclosure);
        if (scenes.isEmpty()) {
            catalogList.addView(text(
                    "NO MAPPED NEWS OR NATURAL-EVENT ANCHOR CURRENTLY MEETS THE FUSION WINDOW. LIVE PROVIDERS CONTINUE IN THE BACKGROUND.",
                    MUTED, 10, true), marginParams(0, 18, 0, 0));
            return;
        }

        int limit = Math.min(catalogVisibleLimit, scenes.size());
        for (int index = 0; index < limit; index++) {
            IncidentFusionEngine.Scene scene = scenes.get(index);
            Signal anchor = scene.anchor;
            int accent = anchor.severity >= 4 ? RED : AMBER;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(10), dp(12), dp(10));
            card.setBackground(panelBackground(PANEL_ALT, accent, 14));
            card.addView(text(String.format(Locale.US,
                    "● %s • OBSERVED ALIGNMENT %02d/99 • NOT CONFIRMATION",
                    scene.label, scene.observedScore), accent, 8, true));
            card.addView(text(anchor.title, TEXT, 11, true), marginParams(0, 5, 0, 3));
            TextView matrix = text(String.format(Locale.US,
                    "AIR %,d   SEA %,d   ORBIT %,d   AIRWX %,d   RELATED %,d   SOURCES %,d",
                    scene.nearbyAircraft, scene.nearbyVessels,
                    scene.nearbyOrbitalObjects, scene.nearbyWarnings,
                    scene.relatedReports, scene.independentSources),
                    Color.rgb(202, 215, 222), 9, true);
            matrix.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            card.addView(matrix);
            card.addView(text("SOURCES  " + scene.sourceNames + "\nANCHOR  "
                    + anchor.source + " • " + eventTime.format(new Date(anchor.timestampMs)),
                    MUTED, 8, false), marginParams(0, 6, 0, 0));

            LinearLayout actions = new LinearLayout(this);
            Button open = compactButton("OPEN ANCHOR");
            open.setTextColor(CYAN);
            open.setOnClickListener(view -> showDetail(anchor));
            Button share = compactButton("SHARE FUSION CARD");
            share.setTextColor(GREEN);
            share.setOnClickListener(view -> {
                Map<String, String> facts = new LinkedHashMap<>();
                facts.put("OBSERVED ALIGNMENT", scene.observedScore + " / 99");
                facts.put("AIRCRAFT WITHIN 500 KM", String.valueOf(scene.nearbyAircraft));
                facts.put("VESSELS WITHIN 300 KM", String.valueOf(scene.nearbyVessels));
                facts.put("ORBITAL OBJECTS WITHIN 900 KM",
                        String.valueOf(scene.nearbyOrbitalObjects));
                facts.put("AIRSPACE WARNINGS WITHIN 650 KM",
                        String.valueOf(scene.nearbyWarnings));
                facts.put("RELATED EVENT RECORDS", String.valueOf(scene.relatedReports));
                facts.put("INDEPENDENT SOURCES", String.valueOf(scene.independentSources));
                facts.put("SOURCES", scene.sourceNames);
                ShareCardRenderer.share(this, customShareCard(
                        anchor.title,
                        "Cross-layer public-source alignment around a mapped anchor. Proximity is not causation.",
                        scene.label + " " + scene.observedScore + "/99",
                        "OBSERVED ALIGNMENT — NOT CONFIRMATION", "4D FUSION",
                        anchor.region, anchor.severity, scene.sourceNames,
                        anchor.timestampMs, anchor.latitude, anchor.longitude, facts, accent,
                        "This card reports proximity and timing only. It does not prove identity, intent, causation or confirmation."));
            });
            actions.addView(open, new LinearLayout.LayoutParams(0, dp(42), 1f));
            LinearLayout.LayoutParams shareParams =
                    new LinearLayout.LayoutParams(0, dp(42), 1f);
            shareParams.setMargins(dp(7), 0, 0, 0);
            actions.addView(share, shareParams);
            card.addView(actions, marginParams(0, 8, 0, 0));
            card.setOnClickListener(view -> showDetail(anchor));
            catalogList.addView(card, marginParams(0, 0, 0, 7));
        }
        catalogMoreButton.setVisibility(limit < scenes.size() ? View.VISIBLE : View.GONE);
    }

    private void prepareSpecialCatalog(String title, String status, int color) {
        catalogList.removeAllViews();
        catalogTitle.setText(title);
        catalogSearch.setVisibility(View.GONE);
        newsCategoryBar.setVisibility(View.GONE);
        catalogMoreButton.setVisibility(View.GONE);
        catalogStatus.setText(status);
        catalogStatus.setTextColor(color);
    }

    private void rebuildWeatherPage() {
        FeedStatus status = feedStatuses.get(Signal.Layer.WEATHER);
        String state = status == null ? "STARTING" : status.state.name();
        prepareSpecialCatalog("WEATHER OPERATIONS / RADAR TIMELINE",
                String.format(Locale.US, "RAINVIEWER • %s • %,d FRAMES • %s",
                        state, radarFrames.size(), status == null ? "Waiting" : status.message),
                status != null && status.state == FeedStatus.State.OFFLINE ? RED : CYAN);

        TextView disclosure = text(
                "PAST TWO HOURS • 10-MINUTE FRAME STEPS • MAX RADAR ZOOM 7 • NOT A FORECAST",
                AMBER, 9, true);
        disclosure.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        catalogList.addView(disclosure, marginParams(0, 3, 0, 10));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        Button open = actionButton("OPEN RADAR MAP", CYAN);
        open.setOnClickListener(view -> {
            catalogPanel.setVisibility(View.GONE);
            enabled.put(Signal.Layer.WEATHER, true);
            CheckBox toggle = layerChecks.get(Signal.Layer.WEATHER);
            if (toggle != null) toggle.setChecked(true);
            mapView.setWeatherVisible(true);
            mapView.setGlobeMode(false);
        });
        Button animate = actionButton(mapView.isRadarAnimationPlaying()
                ? "PAUSE LOOP" : "PLAY LOOP", GREEN);
        animate.setOnClickListener(view -> {
            mapView.setRadarAnimationPlaying(!mapView.isRadarAnimationPlaying());
            rebuildWeatherPage();
        });
        controls.addView(open, new LinearLayout.LayoutParams(0, dp(46), 1f));
        LinearLayout.LayoutParams second = new LinearLayout.LayoutParams(0, dp(46), 1f);
        second.setMargins(dp(7), 0, 0, 0);
        controls.addView(animate, second);
        catalogList.addView(controls, marginParams(0, 0, 0, 12));

        if (radarFrames.isEmpty()) {
            catalogList.addView(text(
                    "NO RADAR HISTORY IS AVAILABLE YET. THE GLOBE REMAINS RESPONSIVE WHILE THE FEED RETRIES.",
                    MUTED, 10, true), marginParams(0, 12, 0, 12));
        } else {
            int selected = mapView.getRadarFrameIndex();
            for (int index = radarFrames.size() - 1; index >= 0; index--) {
                final int frameIndex = index;
                final WorldDataRepository.RadarFrame frame = radarFrames.get(index);
                boolean active = index == selected;
                LinearLayout frameRow = new LinearLayout(this);
                frameRow.setOrientation(LinearLayout.HORIZONTAL);
                frameRow.setGravity(Gravity.CENTER_VERTICAL);
                frameRow.setPadding(dp(8), dp(4), dp(5), dp(4));
                frameRow.setBackground(panelBackground(PANEL_ALT, active ? GREEN : LINE, 12));
                TextView row = text(String.format(Locale.US,
                        "%s FRAME %02d / %02d   %s",
                        active ? "▶" : "•", index + 1, radarFrames.size(),
                        eventTime.format(new Date(frame.timestampMs))),
                        active ? GREEN : TEXT, 10, true);
                row.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
                row.setPadding(dp(12), dp(10), dp(12), dp(10));
                row.setOnClickListener(view -> {
                    mapView.selectRadarFrame(frameIndex);
                    rebuildWeatherPage();
                });
                frameRow.addView(row, new LinearLayout.LayoutParams(
                        0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                Button share = compactButton("SHARE");
                share.setTextColor(GREEN);
                share.setOnClickListener(view -> {
                    Map<String, String> frameFacts = new LinkedHashMap<>();
                    frameFacts.put("FRAME", String.format(Locale.US, "%02d / %02d",
                            frameIndex + 1, radarFrames.size()));
                    frameFacts.put("INTERVAL", "10-minute historical radar frame");
                    frameFacts.put("MAP LIMIT", "RainViewer public tiles; maximum zoom 7");
                    ShareCardRenderer.share(this, customShareCard(
                            "RainViewer radar frame",
                            "Historical precipitation radar frame selected in the weather operations timeline.",
                            active ? "SELECTED FRAME" : "RADAR HISTORY",
                            "PUBLIC SOURCE — NOT A FORECAST",
                            "WEATHER", "GLOBAL", 1, "RainViewer Weather Maps API",
                            frame.timestampMs, Double.NaN, Double.NaN, frameFacts, CYAN,
                            "Radar coverage varies by country. Frame generation time is not a forecast or a report of ground impact."));
                });
                frameRow.addView(share, new LinearLayout.LayoutParams(dp(78), dp(42)));
                catalogList.addView(frameRow, marginParams(0, 0, 0, 6));
            }
        }
        addBriefHeading("SOURCE AND LIMITS",
                "RainViewer public Weather Maps API. Radar coverage varies by country; frame time is generation time and individual observations inside a frame can differ.");
    }

    private void rebuildCountryRiskPage() {
        long now = currentTimelineMs();
        List<CountrySituationEngine.CountryState> countries =
                CountrySituationEngine.analyze(layersForTimeline(), now);
        prepareSpecialCatalog("COUNTRY WATCH / OBSERVED SIGNAL PRESSURE",
                String.format(Locale.US,
                        "%,d COUNTRY LENSES • UPDATED %s • TRANSPARENT ON-DEVICE SCORING",
                        countries.size(), eventTime.format(new Date(now))), CYAN);
        TextView disclosure = text(
                "NOT A FORECAST • NOT AN OFFICIAL RISK RATING • COARSE COUNTRY ENVELOPES • SOURCE COVERAGE VARIES",
                AMBER, 9, true);
        disclosure.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        catalogList.addView(disclosure, marginParams(0, 3, 0, 10));

        for (CountrySituationEngine.CountryState country : countries) {
            int accent = country.score >= 70 ? RED
                    : country.score >= 45 ? AMBER : country.score >= 20 ? CYAN : GREEN;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(10), dp(12), dp(10));
            card.setBackground(panelBackground(PANEL_ALT, accent, 14));
            LinearLayout top = new LinearLayout(this);
            top.setGravity(Gravity.CENTER_VERTICAL);
            TextView name = text(country.name + " / " + country.iso, TEXT, 11, true);
            TextView score = text(String.format(Locale.US, "%02d/99", country.score),
                    accent, 16, true);
            score.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            top.addView(name, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            top.addView(score);
            card.addView(top);
            card.addView(text("● " + country.level + " • 6H Δ"
                    + String.format(Locale.US, "%+d", country.movement()), accent, 8, true));
            TextView facts = text(String.format(Locale.US,
                    "EVENTS %,d   •   PRIORITY %,d   •   SOURCES %,d   •   AIR %,d   •   SEA %,d",
                    country.eventRecords, country.priorityRecords, country.sourceCount,
                    country.aircraft, country.vessels), Color.rgb(202, 215, 222), 9, false);
            facts.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
            card.addView(facts, marginParams(0, 5, 0, 0));
            Button share = compactButton("SHARE CARD");
            share.setTextColor(GREEN);
            share.setOnClickListener(view -> {
                Map<String, String> riskFacts = new LinkedHashMap<>();
                riskFacts.put("OBSERVED SCORE", country.score + " / 99");
                riskFacts.put("SIX-HOUR MOVEMENT", String.format(Locale.US, "%+d",
                        country.movement()));
                riskFacts.put("EVENT RECORDS", String.format(Locale.US, "%,d",
                        country.eventRecords));
                riskFacts.put("PRIORITY RECORDS", String.format(Locale.US, "%,d",
                        country.priorityRecords));
                riskFacts.put("DISTINCT SOURCES", String.format(Locale.US, "%,d",
                        country.sourceCount));
                riskFacts.put("AIR / SEA CONTEXT", String.format(Locale.US, "%,d / %,d",
                        country.aircraft, country.vessels));
                ShareCardRenderer.share(this, customShareCard(
                        country.name + " observed signal pressure",
                        "Transparent on-device score made from recent mapped event severity, age, credibility and publisher diversity.",
                        country.level,
                        "OBSERVED OPEN-SOURCE INDICATOR — NOT AN OFFICIAL RATING",
                        "COUNTRY WATCH", country.name, Math.max(1, Math.min(5,
                        1 + country.score / 20)),
                        "Source-attributed records visible in " + APP_BRAND,
                        now, country.latitude, country.longitude, riskFacts, accent,
                        "Not a forecast and not an official risk rating. Source coverage varies by country."));
            });
            card.addView(share, marginParams(0, 7, 0, 0));
            card.setOnClickListener(view -> {
                catalogPanel.setVisibility(View.GONE);
                mapView.setCenter(country.latitude, country.longitude, 5.0d);
            });
            catalogList.addView(card, marginParams(0, 0, 0, 7));
        }
        addBriefHeading("HOW THE NUMBER IS MADE",
                "Recent mapped event severity, age, credibility and publisher diversity are combined. Aircraft and vessel counts are displayed for context but do not raise the event score.");
    }

    private void rebuildAnalystPage() {
        List<MovementAnalyzer.Watch> watches = movementAnalyzer.snapshot();
        SituationAnalyzer.Brief brief = latestBrief;
        prepareSpecialCatalog("ON-DEVICE ANALYST / OBSERVED PATTERNS",
                String.format(Locale.US,
                        "%,d MOVEMENT WATCHES • %,d PROXIMITY WATCHES • %,d NEWS CORRELATIONS",
                        watches.size(), brief == null ? 0 : brief.domainWatches.size(),
                        brief == null ? 0 : brief.correlations.size()),
                watches.isEmpty() ? CYAN : AMBER);
        TextView disclosure = text(
                "DETERMINISTIC LOCAL RULES • NO CLOUD AI • NO PREDICTION • EVERY RESULT LINKS TO PROVIDER DATA",
                AMBER, 9, true);
        disclosure.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        catalogList.addView(disclosure, marginParams(0, 3, 0, 10));

        addBriefHeading("AIR / SEA MOVEMENT WATCHES",
                "Thresholds examine recent fixes for emergency squawks, rapid descent, turning, holding-like or low-speed patterns. Intent is never inferred.");
        if (watches.isEmpty()) {
            catalogList.addView(text(
                    "NO CURRENT TRACK HAS CROSSED THE TRANSPARENT WATCH THRESHOLDS. MORE FIXES MAY BE NEEDED.",
                    MUTED, 10, true), marginParams(0, 2, 0, 10));
        }
        for (MovementAnalyzer.Watch watch : watches) {
            int accent = watch.severity >= 4 ? RED : watch.severity >= 3 ? AMBER : CYAN;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(10), dp(12), dp(10));
            card.setBackground(panelBackground(PANEL_ALT, accent, 14));
            card.addView(text("● " + watch.kind + " • OBSERVED / NOT CONFIRMED",
                    accent, 8, true));
            card.addView(text(watch.signal.title, TEXT, 11, true),
                    marginParams(0, 4, 0, 3));
            card.addView(text(watch.detail, Color.rgb(202, 215, 222), 9, false));
            card.addView(text("SOURCE  " + watch.signal.source + "  •  "
                    + eventTime.format(new Date(watch.signal.timestampMs)), MUTED, 8, false),
                    marginParams(0, 6, 0, 0));
            Button share = compactButton("SHARE CARD");
            share.setTextColor(GREEN);
            share.setOnClickListener(view -> {
                Map<String, String> watchFacts = new LinkedHashMap<>(watch.signal.facts);
                watchFacts.put("OBSERVED PATTERN", watch.kind);
                watchFacts.put("ANALYST DETAIL", watch.detail);
                ShareCardRenderer.share(this, customShareCard(
                        watch.signal.title,
                        watch.detail,
                        watch.kind,
                        "OBSERVED PATTERN — NOT CONFIRMED",
                        "ON-DEVICE ANALYST", watch.signal.region, watch.severity,
                        watch.signal.source, watch.signal.timestampMs,
                        watch.signal.latitude, watch.signal.longitude, watchFacts, accent,
                        "A deterministic threshold was crossed. It does not establish identity, intent or an incident."));
            });
            card.addView(share, marginParams(0, 7, 0, 0));
            card.setOnClickListener(view -> showDetail(watch.signal));
            catalogList.addView(card, marginParams(0, 0, 0, 7));
        }

        addBriefHeading("IDENTITY LIMIT",
                "OpenSky's public state vectors do not reliably identify military ownership. The app can flag a special-use callsign pattern, but it never labels an aircraft military without a provider fact.");
        addBriefHeading("LOCAL INTELLIGENCE ENGINE",
                "Country scores, source corroboration, cross-domain proximity and track-pattern checks run on this device. No Ollama server, MCP agent or hidden synthetic feed is required.");
    }

    private void rebuildSourcesPage() {
        prepareSpecialCatalog("SOURCE REGISTRY / COVERAGE AND LIMITS",
                "EVERY PROVIDER STATE IS VISIBLE • OFFLINE FEEDS DO NOT FREEZE THE APP", CYAN);
        Button settings = actionButton("OPEN PROVIDER SETTINGS", AMBER);
        settings.setOnClickListener(view -> showSettings());
        catalogList.addView(settings, marginParams(0, 2, 0, 12));

        for (Signal.Layer layer : Signal.Layer.values()) {
            FeedStatus status = feedStatuses.get(layer);
            if (status == null) continue;
            addSourceRow(feedDisplayName(layer), status.state.name(), status.count,
                    "Source age " + sourceAgeText(layer) + " • " + status.message,
                    feedStateColor(status));
        }
        addBriefHeading("PROVIDER CONTRACTS", "What is connected and what remains conditional.");
        addSourceRow("GDELT DOC + GKG", "ACTIVE", count(Signal.Layer.NEWS),
                "DOC headline polling plus bounded newest 15-minute GKG theme archive", GREEN);
        addSourceRow("OPENSKY", "RATE LIMITED", count(Signal.Layer.FLIGHTS),
                "Anonymous global interval is conservative; OAuth enables faster sector refresh", CYAN);
        addSourceRow("AVIATION WEATHER CENTER", "OFFICIAL SIGMET", count(Signal.Layer.AIRSPACE),
                "Worldwide aviation warnings; map markers use representative polygon points", CYAN);
        addSourceRow("CELESTRAK GP", "CALCULATED", count(Signal.Layer.SATELLITES),
                "Elements refresh no more than every two hours; positions are calculated locally and are not live telemetry", Color.rgb(174, 139, 224));
        addSourceRow("4D REPLAY BUFFER", "THIS SESSION", replayEngine.frameCount(),
                "Up to 60 minutes of frames actually acquired by this device; no manufactured history", CYAN);
        SecurePrefs providerPrefs = repository == null
                ? new SecurePrefs(this) : repository.securePrefs();
        addSourceRow("AISSTREAM", providerPrefs.get(SecurePrefs.AIS_KEY).isEmpty()
                        ? "KEY REQUIRED" : "CONFIGURED", count(Signal.Layer.SHIPS),
                "Personal encrypted key; provider coverage and vessel transmission vary", AMBER);
        addSourceRow("WINDY WEBCAMS", providerPrefs.get(SecurePrefs.WINDY_KEY).isEmpty()
                        ? "KEY REQUIRED" : "CONFIGURED", count(Signal.Layer.WEBCAMS),
                "Provider-permitted listing window; never described as every camera", AMBER);
        addSourceRow("REUTERS / AP / AFP", "LICENSED URL REQUIRED", 0,
                "No unlicensed feed is bundled. Add an authorized HTTPS RSS URL in Settings.", MUTED);
        addSourceRow("PUBLIC SAFETY AUDIO",
                providerPrefs.get(SecurePrefs.PUBLIC_SAFETY_STREAM).isEmpty()
                        ? "NOT CONNECTED" : "USER FEED CONFIGURED", count(Signal.Layer.MEDIA),
                "Native playback only for a lawful direct HTTPS stream supplied by the user", AMBER);
        addSourceRow("MILITARY IDENTITY", "NOT ASSERTED", 0,
                "Public state vectors do not provide dependable ownership or mission identity", MUTED);
        addSourceRow("COMMODITIES", "NO QUOTE SOURCE", 0,
                "Gold/oil values remain blank until a trustworthy authorized provider is connected", MUTED);
        addSourceRow("CAMERA / TV / RADIO", "PUBLIC DIRECT MEDIA", count(Signal.Layer.WEBCAMS)
                        + count(Signal.Layer.TV) + count(Signal.Layer.RADIO),
                "Availability, geoblocking and publisher uptime vary; no WebView is used", CYAN);
    }

    /** R27 launcher intelligence deck, visible and controllable in-app. */
    private void rebuildWidgetsPage() {
        prepareSpecialCatalog("R27 HOME INTELLIGENCE / LIVE MOTION WIDGET DECK",
                "8 NATIVE WIDGETS • REAL PICKER PREVIEWS • SAFE RUNTIME • LIVE SNAPSHOTS",
                GREEN);

        WidgetSnapshot snapshot = WidgetSnapshot.load(this);
        TextView truth = text(
                "ANDROID HOME WIDGETS ARE SNAPSHOTS, NOT A SECOND ALWAYS-RUNNING APP. "
                        + "THEY SHOW THE LAST ACQUIRED PROVIDER RECORD, SOURCE, CREDIBILITY "
                        + "AND AGE; TAP ANY WIDGET TO ENTER THE MATCHING LIVE PAGE.",
                AMBER, 9, true);
        truth.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        catalogList.addView(truth, marginParams(0, 3, 0, 10));

        LinearLayout summary = new LinearLayout(this);
        summary.setOrientation(LinearLayout.VERTICAL);
        summary.setPadding(dp(12), dp(10), dp(12), dp(10));
        summary.setBackground(panelBackground(PANEL_ALT, CYAN, 14));
        summary.addView(text("● CURRENT WIDGET SOURCE INDEX", CYAN, 9, true));
        summary.addView(text(snapshot.sourceHealthLine(), TEXT, 10, true),
                marginParams(0, 4, 0, 2));
        summary.addView(text("LAST ACQUIRED  "
                + WidgetSnapshot.ageText(snapshot.lastSourceUpdateMs,
                System.currentTimeMillis())
                + "  •  BACKGROUND IS NETWORK-AWARE AND ANDROID-BATCHED",
                MUTED, 8, false));
        Button refresh = actionButton("REFRESH WIDGET SNAPSHOTS NOW", CYAN);
        refresh.setOnClickListener(view -> {
            DuWidgetUpdater.updateAll(this);
            WidgetRefreshScheduler.scheduleImmediate(this);
            Toast.makeText(this,
                    "Widget refresh requested; Android will run network work when allowed",
                    Toast.LENGTH_LONG).show();
        });
        summary.addView(refresh, marginParams(0, 8, 0, 0));
        catalogList.addView(summary, marginParams(0, 0, 0, 12));

        for (DuWidgetContract.Kind widget : DuWidgetContract.Kind.values()) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(11), dp(12), dp(11));
            card.setBackground(panelBackground(PANEL_ALT,
                    widget == DuWidgetContract.Kind.ALERT ? RED
                            : widget == DuWidgetContract.Kind.COMMAND ? GREEN : CYAN, 14));
            card.addView(text("● " + widget.title + "  •  "
                    + widget.targetWidth + "×" + widget.targetHeight + " TARGET",
                    widget == DuWidgetContract.Kind.ALERT ? RED : CYAN, 9, true));
            card.addView(text(widget.description, TEXT, 10, false),
                    marginParams(0, 5, 0, 3));
            card.addView(text(widgetCapabilityLine(widget), MUTED, 8, false));
            Button pin = actionButton("PIN " + widget.title + " TO HOME", GREEN);
            pin.setOnClickListener(view -> requestPinWidget(widget));
            card.addView(pin, marginParams(0, 8, 0, 0));
            catalogList.addView(card, marginParams(0, 0, 0, 8));
        }

        addBriefHeading("PROFILE CONTROLS",
                "Each copy can use a different label, region, minimum severity and optional "
                        + "250–3,000 km timezone-derived distance lens. No GPS permission is used.");
        addBriefHeading("REFRESH CONTRACT",
                "App activity updates the shared cache immediately. Manual ↻ requests a bounded "
                        + "acquisition window. Periodic work targets about 15 minutes, but Android "
                        + "may defer it for battery, network or launcher policy.");
        addBriefHeading("COVERAGE CONTRACT",
                "Counts are provider-returned records, not every aircraft, vessel, camera or event. "
                        + "AISStream and Windy remain optional keyed sources; offline feeds remain visible.");
    }

    private String widgetCapabilityLine(DuWidgetContract.Kind widget) {
        switch (widget) {
            case ALERT:
                return "SEVERITY FILTER • RED PRIORITY STATE • EVENT AGE • SOURCE CREDIBILITY";
            case COUNTERS:
                return "AIR • SEA • EVENTS • ORBITS • MEDIA • WEATHER SOURCE STATE";
            case LOCAL:
                return "REGION/RADIUS PROFILE • LOCAL AIR/SEA COUNTS • NEWEST LOCAL SIGNAL";
            case WIRE:
                return "NEWEST-FIRST WIRE • PREVIOUS/NEXT • REPORTED/UNVERIFIED BADGE";
            case AIR_SEA:
                return "CALLSIGN/VESSEL • SPEED • ALTITUDE/DESTINATION • HEADING • SOURCE";
            case HAZARDS:
                return "EARTHQUAKE/FIRE/STORM • SIGMET • SPACE WEATHER • RADAR HEALTH";
            case MEDIA:
                return "PUBLIC CAM/RADIO/TV DIRECTORY • AVAILABILITY • SAFE APP DEEP LINK";
            case COMMAND:
            default:
                return "UTC+LOCAL CLOCKS • RESPONSIVE GLOBE SNAPSHOT • COUNTS • TOP SIGNALS";
        }
    }

    private void requestPinWidget(DuWidgetContract.Kind widget) {
        if (android.os.Build.VERSION.SDK_INT < 26) {
            Toast.makeText(this,
                    "Open your launcher's widget picker and choose " + widget.title,
                    Toast.LENGTH_LONG).show();
            return;
        }
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        if (!manager.isRequestPinAppWidgetSupported()) {
            Toast.makeText(this,
                    "This launcher does not support one-tap pinning. Long-press the home screen, "
                            + "choose Widgets, then DU World Monitor.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        ComponentName provider = DuWidgetContract.component(this, widget);
        boolean requested = manager.requestPinAppWidget(provider, null, null);
        Toast.makeText(this, requested
                        ? "Confirm " + widget.title + " in your launcher"
                        : "The launcher did not accept this pin request",
                Toast.LENGTH_LONG).show();
    }

    private void captureWidgetDeepLink(Intent intent) {
        if (intent == null) return;
        String requested = intent.getStringExtra(DuWidgetContract.EXTRA_OPEN_CATALOG);
        if (requested != null && !requested.trim().isEmpty()) {
            pendingCatalog = requested.trim().toUpperCase(Locale.ROOT);
        }
        String story = intent.getStringExtra("story_id");
        if (story != null) pendingNewsStoryId = story;
    }

    private void applyWidgetDeepLink() {
        if (pendingCatalog.isEmpty() || catalogPanel == null) return;
        String requested = pendingCatalog;
        pendingCatalog = "";
        if ("LOCAL_NEWS".equals(requested)) globeOnlyRoute("NEWS");
        else openCatalog(requested);
        if ("NEWS".equals(requested) && !pendingNewsStoryId.isEmpty()) {
            NewsItem item = new NewsStore(this).byId(pendingNewsStoryId);
            pendingNewsStoryId = "";
            if (item != null) f17BeforeDetail();showLocalNewsDetail(item);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        captureWidgetDeepLink(intent);
        applyWidgetDeepLink();
    }

    private void addSourceRow(String name, String state, int records,
                              String message, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(12), dp(9), dp(12), dp(9));
        row.setBackground(panelBackground(PANEL_ALT, color, 12));
        row.addView(text(String.format(Locale.US, "● %-20s  %s  •  %,d",
                name, state, records), color, 9, true));
        row.addView(text(message, Color.rgb(202, 215, 222), 8, false),
                marginParams(0, 3, 0, 0));
        Button share = compactButton("SHARE CARD");
        share.setTextColor(GREEN);
        share.setOnClickListener(view -> {
            Map<String, String> sourceFacts = new LinkedHashMap<>();
            sourceFacts.put("PROVIDER STATE", state);
            sourceFacts.put("RECORDS", String.format(Locale.US, "%,d", records));
            sourceFacts.put("COVERAGE NOTE", message);
            ShareCardRenderer.share(this, customShareCard(
                    name + " source status", message, state,
                    "PROVIDER HEALTH — NOT EVENT CONFIRMATION", "SOURCE REGISTRY",
                    "GLOBAL", state.contains("OFFLINE") ? 4 : 1,
                    name, System.currentTimeMillis(), Double.NaN, Double.NaN,
                    sourceFacts, color,
                    "Provider availability and returned coverage can change. This card reports the app's visible source state."));
        });
        row.addView(share, marginParams(0, 6, 0, 0));
        catalogList.addView(row, marginParams(0, 0, 0, 6));
    }

    private View buildBriefMetric(String label, int value, int color) {
        LinearLayout metric = new LinearLayout(this);
        metric.setOrientation(LinearLayout.VERTICAL);
        metric.setPadding(dp(12), dp(9), dp(12), dp(9));
        metric.setBackground(panelBackground(PANEL_ALT, color, 13));
        TextView number = text(String.format(Locale.US, "%,d", value), TEXT, 18, true);
        number.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        TextView caption = text("● " + label, color, 8, true);
        TextView share = text("SHARE CARD", GREEN, 7, true);
        metric.addView(number);
        metric.addView(caption);
        metric.addView(share);
        metric.setContentDescription(label + " " + value + ". Tap to share as a card.");
        metric.setOnClickListener(view -> {
            Map<String, String> metricFacts = new LinkedHashMap<>();
            metricFacts.put(label, String.format(Locale.US, "%,d", value));
            ShareCardRenderer.share(this, customShareCard(
                    label + " brief metric", String.format(Locale.US,
                    "The current intelligence brief shows %,d for %s.", value, label),
                    "BRIEF METRIC", "MIXED SOURCE STATES", "INTELLIGENCE BRIEF",
                    "GLOBAL", 1, APP_BRAND + " intelligence brief",
                    System.currentTimeMillis(), Double.NaN, Double.NaN,
                    metricFacts, color,
                    "This is a current page metric. Open individual items for source-level credibility."));
        });
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(112), dp(88));
        params.setMargins(0, 0, dp(7), 0);
        metric.setLayoutParams(params);
        return metric;
    }

    private void addBriefHeading(String title, String explanation) {
        TextView heading = text(title, TEXT, 11, true);
        heading.setLetterSpacing(0.04f);
        catalogList.addView(heading, marginParams(0, 10, 0, 2));
        catalogList.addView(text(explanation, MUTED, 8, false),
                marginParams(0, 0, 0, 7));
    }

    private String feedDisplayName(Signal.Layer layer) {
        switch (layer) {
            case FLIGHTS: return "AIRCRAFT";
            case SHIPS: return "VESSELS";
            case WEATHER: return "WEATHER";
            case AIRSPACE: return "AIRSPACE WEATHER";
            case NATURAL: return "NATURAL EVENTS";
            case NEWS: return "GLOBAL WIRE";
            case SATELLITES: return "ORBITAL OBJECTS";
            case SPACE_WEATHER: return "SPACE WEATHER";
            case INFRASTRUCTURE: return "REFERENCE";
            case MARKETS: return "MARKETS";
            case WEBCAMS: return "CAMERAS";
            case RADIO: return "RADIO";
            case TV: return "TELEVISION";
            case MEDIA: return "PUBLIC CALLS";
            default: return layer.name();
        }
    }

    private int feedStateColor(FeedStatus status) {
        if (status.state == FeedStatus.State.OFFLINE) return RED;
        if (status.state == FeedStatus.State.LOADING
                || status.state == FeedStatus.State.DELAYED
                || status.state == FeedStatus.State.CACHED
                || status.state == FeedStatus.State.KEY_REQUIRED) return AMBER;
        return GREEN;
    }

    private List<Signal> catalogSignals() {
        Signal.Layer layer = layerForCategory(catalogCategory);
        List<Signal> source = layerSignals.get(layer);
        List<Signal> result = new ArrayList<>();
        String query = catalogSearch == null ? ""
                : catalogSearch.getText().toString().trim().toLowerCase(Locale.ROOT);
        if (source == null) return result;
        for (Signal signal : source) {
            if ("BOATS".equals(catalogCategory) && !isBoat(signal)) continue;
            if ("SHIPS".equals(catalogCategory) && isBoat(signal)) continue;
            String infraCategory = signal.facts.get("CATEGORY");
            String infra = infraCategory == null ? "" : infraCategory.toUpperCase(Locale.ROOT);
            if ("AIRPORTS".equals(catalogCategory) && !infra.contains("AIRPORT")) continue;
            if ("RUNWAYS".equals(catalogCategory) && !infra.contains("RUNWAY")) continue;
            if ("PORTS".equals(catalogCategory)
                    && !infra.contains("PORT") && !infra.contains("MARITIME")) continue;
            if ("NEWS".equals(catalogCategory) && !"ALL".equals(catalogNewsType)
                    && !catalogNewsType.equals(signal.eventType)) continue;
            if (!query.isEmpty() && !catalogHaystack(signal).contains(query)) continue;
            result.add(signal);
        }
        if (layer != Signal.Layer.TV && layer != Signal.Layer.RADIO
                && layer != Signal.Layer.MEDIA && layer != Signal.Layer.WEBCAMS) {
            Collections.sort(result, (first, second) ->
                    compareNewestFirst(first.timestampMs, second.timestampMs));
        }
        return result;
    }

    private String catalogHaystack(Signal signal) {
        StringBuilder text = new StringBuilder()
                .append(signal.title).append(' ')
                .append(signal.summary).append(' ')
                .append(signal.source).append(' ')
                .append(signal.eventType).append(' ')
                .append(signal.region);
        for (Map.Entry<String, String> fact : signal.facts.entrySet()) {
            text.append(' ').append(fact.getKey()).append(' ').append(fact.getValue());
        }
        return text.toString().toLowerCase(Locale.ROOT);
    }

    private boolean isBoat(Signal signal) {
        String type = signal.facts.get("TYPE");
        if (type == null) return false;
        String value = type.toLowerCase(Locale.ROOT);
        return value.contains("fishing") || value.contains("towing")
                || value.contains("sailing") || value.contains("service")
                || value.contains("special craft") || value.contains("high-speed")
                || value.contains("pleasure") || value.contains("pilot")
                || value.contains("tug");
    }

    private View buildCatalogCard(Signal signal) {
        if (signal != null && signal.layer == Signal.Layer.NEWS) {
            String nid = signal.facts.get("NEWS ID");
            NewsItem local = nid == null ? null : new NewsStore(this).byId(nid);
            if (local != null) return buildLocalNewsCard(local);
        }
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(10), dp(12), dp(10));
        card.setBackground(panelBackground(PANEL_ALT, layerAccent(signal.layer), 14));

        LinearLayout headline = new LinearLayout(this);
        headline.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text(signal.title, TEXT, 11, true);
        headline.addView(title, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(headline);

        TextView state = text("● " + signalStateText(signal) + " • "
                + badgeText(signal), signalStateColor(signal), 8, true);
        card.addView(state, marginParams(0, 2, 0, 4));

        int included = 0;
        StringBuilder compactFacts = new StringBuilder();
        for (Map.Entry<String, String> fact : signal.facts.entrySet()) {
            if (included >= 4) break;
            if (compactFacts.length() > 0) compactFacts.append("   •   ");
            compactFacts.append(fact.getKey()).append(' ').append(fact.getValue());
            included++;
        }
        if (compactFacts.length() > 0) {
            TextView facts = text(compactFacts.toString(), Color.rgb(202, 215, 222), 9, false);
            facts.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
            card.addView(facts);
        }
        TextView source = text("SOURCE  " + signal.source + "   •   "
                + eventTime.format(new Date(signal.timestampMs)) + "   •   FEED "
                + sourceStateText(signal.layer) + " / AGE " + sourceAgeText(signal.layer),
                MUTED, 8, false);
        source.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        card.addView(source, marginParams(0, 5, 0, 0));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button action = compactButton(catalogActionLabel(signal));
        action.setTextColor(layerAccent(signal.layer));
        action.setOnClickListener(view -> activateCatalogSignal(signal));
        Button share = compactButton("SHARE CARD");
        share.setTextColor(GREEN);
        share.setContentDescription("Share " + signal.title + " as a DU World Monitor card");
        share.setOnClickListener(view -> shareSignal(signal));
        actions.addView(action, new LinearLayout.LayoutParams(0, dp(42), 1f));
        LinearLayout.LayoutParams shareParams = new LinearLayout.LayoutParams(0, dp(42), 1f);
        shareParams.setMargins(dp(7), 0, 0, 0);
        actions.addView(share, shareParams);
        card.addView(actions, marginParams(0, 8, 0, 0));
        card.setOnClickListener(view -> showDetail(signal));
        return card;
    }

    private String catalogActionLabel(Signal signal) {
        switch (signal.layer) {
            case FLIGHTS:
            case SHIPS:
                return mapView.isFollowing(signal.id) ? "FOLLOWING" : "TRACK";
            case RADIO:
                return signal.id.equals(playingRadioId) ? "STOP" : "PLAY";
            case TV: return "WATCH";
            case WEBCAMS: return "VIEW FRAME";
            case MEDIA:
                return signal.sourceUrl.startsWith("https://")
                        && "AUDIO".equalsIgnoreCase(signal.facts.get("MEDIA TYPE"))
                        ? signal.id.equals(playingRadioId) ? "STOP" : "PLAY"
                        : "REFERENCE";
            default: return "DETAIL";
        }
    }

    private void activateCatalogSignal(Signal signal) {
        selectedSignal = signal;
        selectedSourceUrl = signal.sourceUrl;
        if (signal.layer == Signal.Layer.FLIGHTS || signal.layer == Signal.Layer.SHIPS) {
            followTraffic(signal);
        } else if (signal.layer == Signal.Layer.RADIO) {
            toggleRadio(signal);
            rebuildCatalogPage();
        } else if (signal.layer == Signal.Layer.TV) {
            launchNativeMedia(signal, NativeMediaActivity.KIND_VIDEO);
        } else if (signal.layer == Signal.Layer.WEBCAMS) {
            if (signal.sourceUrl.isEmpty()) {
                Toast.makeText(this, "This camera has no current safe direct frame",
                        Toast.LENGTH_LONG).show();
            } else {
                launchNativeMedia(signal, NativeMediaActivity.KIND_IMAGE);
            }
        } else if (signal.layer == Signal.Layer.MEDIA
                && signal.sourceUrl.startsWith("https://")
                && "AUDIO".equalsIgnoreCase(signal.facts.get("MEDIA TYPE"))) {
            toggleRadio(signal);
            rebuildCatalogPage();
        } else {
            showDetail(signal);
        }
    }

    private void followTraffic(Signal signal) {
        if (signal == null || !signal.hasLocation()) {
            Toast.makeText(this, "This record has no current provider position",
                    Toast.LENGTH_LONG).show();
            return;
        }
        if (replayMode) {
            returnToLive();
            Toast.makeText(this,
                    "Returned to LIVE before following the latest provider fix",
                    Toast.LENGTH_SHORT).show();
        }
        catalogPanel.setVisibility(View.GONE);
        layersPanel.setVisibility(View.GONE);
        wirePanel.setVisibility(View.GONE);
        mapView.followSignal(signal);
        showDetail(signal);
        Toast.makeText(this,
                "Following provider fixes; short motion between fixes is estimated and labelled",
                Toast.LENGTH_LONG).show();
    }

    private void launchNativeMedia(Signal signal, String kind) {
        if (signal == null || signal.sourceUrl == null
                || !PublicMediaPolicy.isSafePublicHttpsUrl(signal.sourceUrl)) {
            Toast.makeText(this, "No safe direct media stream is available",
                    Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent(this, NativeMediaActivity.class);
        intent.putExtra(NativeMediaActivity.EXTRA_KIND, kind);
        intent.putExtra(NativeMediaActivity.EXTRA_TITLE, signal.title);
        intent.putExtra(NativeMediaActivity.EXTRA_SOURCE, signal.source);
        intent.putExtra(NativeMediaActivity.EXTRA_URL, signal.sourceUrl);
        intent.putExtra(NativeMediaActivity.EXTRA_REFERRER,
                signal.facts.get("PLAYBACK REFERRER"));
        intent.putExtra(NativeMediaActivity.EXTRA_USER_AGENT,
                signal.facts.get("PLAYBACK USER AGENT"));
        startActivity(intent);
    }

    private LinearLayout buildLayersPanel() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(12), dp(12), dp(12));
        content.setBackground(panelBackground(Color.argb(242, 8, 12, 17), LINE, 18));
        content.addView(text("SOURCE CONTROL", TEXT, 11, true));
        content.addView(text("TOGGLE SOURCE / OPEN ITS NATIVE PAGE", MUTED, 8, false),
                marginParams(0, 2, 0, 10));

        addLayerToggle(content, Signal.Layer.FLIGHTS, "FLIGHTS");
        addLayerToggle(content, Signal.Layer.SHIPS, "SHIPS");
        addLayerToggle(content, Signal.Layer.WEATHER, "WEATHER RADAR");
        addLayerToggle(content, Signal.Layer.AIRSPACE, "AVIATION WARNINGS");
        addLayerToggle(content, Signal.Layer.NATURAL, "NATURAL EVENTS");
        addLayerToggle(content, Signal.Layer.NEWS, "BREAKING WIRE");
        addLayerToggle(content, Signal.Layer.SATELLITES, "CALCULATED ORBITS");
        addLayerToggle(content, Signal.Layer.SPACE_WEATHER, "SPACE WEATHER");
        addLayerToggle(content, Signal.Layer.INFRASTRUCTURE, "STRATEGIC REFERENCE");
        addLayerToggle(content, Signal.Layer.MARKETS, "MARKET RADAR");
        addLayerToggle(content, Signal.Layer.WEBCAMS, "WORLD PUBLIC CAMERAS");
        addLayerToggle(content, Signal.Layer.RADIO, "PUBLIC RADIO");
        addLayerToggle(content, Signal.Layer.TV, "PUBLIC TV STREAMS");
        addLayerToggle(content, Signal.Layer.MEDIA, "PUBLIC CALLS / FREQUENCIES");

        projectionButton = actionButton("DISPLAY • GLOBE", GREEN);
        projectionButton.setOnClickListener(view -> {
            boolean globe = !mapView.isGlobeMode();
            mapView.setGlobeMode(globe);
            projectionButton.setText(globe ? "DISPLAY • GLOBE" : "DISPLAY • SATELLITE MAP");
            Toast.makeText(this, globe
                            ? "Global source overview"
                            : "Detailed satellite tracker with place labels and radar",
                    Toast.LENGTH_SHORT).show();
        });
        content.addView(projectionButton, marginParams(0, 12, 0, 8));

        Button refresh = actionButton("REFRESH ALL NOW", CYAN);
        refresh.setOnClickListener(view -> {
            if (repository != null) repository.refreshNow();
            else Toast.makeText(this,
                    "Live sources are paused in recovery mode",
                    Toast.LENGTH_LONG).show();
        });
        content.addView(refresh, marginParams(0, 0, 0, 8));

        Button configure = actionButton("PROVIDER SETTINGS", AMBER);
        configure.setOnClickListener(view -> showSettings());
        content.addView(configure, marginParams(0, 0, 0, 14));

        Button brief = actionButton("OPEN INTELLIGENCE BRIEF", AMBER);
        brief.setOnClickListener(view -> openCatalog("BRIEF"));
        content.addView(brief, marginParams(0, 0, 0, 14));

        content.addView(text("SIGNAL LIGHTS", TEXT, 10, true));
        content.addView(text("Urgency/operations — not a truth rating", MUTED, 8, false));
        content.addView(legendLine("GREEN • ONLINE", GREEN,
                "Normal feed or non-priority public telemetry"));
        content.addView(legendLine("AMBER • DEVELOPING", AMBER,
                "Unverified/reported item, cached data or feed syncing"));
        content.addView(legendLine("RED • PRIORITY", RED,
                "Severity 4–5 signal or feed fault; still check credibility"));

        content.addView(text("CREDIBILITY DESK", TEXT, 10, true),
                marginParams(0, 14, 0, 0));
        content.addView(legendLine("RAW SIGNAL", CYAN, "Fast telemetry; not a reported story"));
        content.addView(legendLine("CALCULATED", Color.rgb(174, 139, 224),
                "Position derived from named public elements; not live telemetry"));
        content.addView(legendLine("UNVERIFIED", RED, "Developing headline; details not confirmed"));
        content.addView(legendLine("REPORTED", AMBER, "Published or independently corroborated"));
        content.addView(legendLine("CONFIRMED", GREEN, "Official structured source"));
        content.addView(legendLine("PUBLIC SOURCE", CYAN,
                "Open station or publisher directory; availability varies"));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(content);
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return wrapper;
    }

    private void addLayerToggle(LinearLayout parent, Signal.Layer layer, String label) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        CheckBox toggle = new CheckBox(this);
        toggle.setChecked(true);
        toggle.setText(label + "  •  LOADING");
        toggle.setTextColor(TEXT);
        toggle.setTextSize(9);
        toggle.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        toggle.setGravity(Gravity.CENTER_VERTICAL);
        toggle.setButtonTintList(new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{CYAN, MUTED}));
        toggle.setOnCheckedChangeListener((button, checked) -> {
            enabled.put(layer, checked);
            if (layer == Signal.Layer.WEATHER) mapView.setWeatherVisible(checked);
            applyFilters();
        });
        layerChecks.put(layer, toggle);
        row.addView(toggle, new LinearLayout.LayoutParams(0, dp(48), 1f));
        Button open = compactButton("OPEN");
        open.setContentDescription("Open " + label + " page");
        open.setOnClickListener(view -> openCatalog(categoryForLayer(layer)));
        row.addView(open, new LinearLayout.LayoutParams(dp(52), dp(40)));
        parent.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
    }

    private LinearLayout buildWirePanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(10), dp(10), dp(10));
        panel.setBackground(panelBackground(Color.argb(242, 8, 12, 17), LINE, 18));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = text("LATEST INTELLIGENCE / NEWEST FIRST", TEXT, 10, true);
        top.addView(heading, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button close = compactButton("×");
        close.setOnClickListener(view -> wirePanel.setVisibility(View.GONE));
        top.addView(close, new LinearLayout.LayoutParams(dp(42), dp(42)));
        panel.addView(top);

        HorizontalScrollView filters = new HorizontalScrollView(this);
        filters.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        typeButton = compactButton("TYPE: ALL");
        regionButton = compactButton("REGION: ALL");
        severityButton = compactButton("SEV: 1+");
        timeWindowButton = compactButton("TIME: 24H");
        typeButton.setOnClickListener(view -> {
            typeIndex = (typeIndex + 1) % TYPES.length;
            typeButton.setText("TYPE: " + TYPES[typeIndex]);
            applyFilters();
        });
        regionButton.setOnClickListener(view -> {
            regionIndex = (regionIndex + 1) % REGIONS.length;
            regionButton.setText("REGION: " + REGIONS[regionIndex]);
            applyFilters();
        });
        severityButton.setOnClickListener(view -> {
            minimumSeverity = minimumSeverity == 5 ? 1 : minimumSeverity + 1;
            severityButton.setText("SEV: " + minimumSeverity + "+");
            applyFilters();
        });
        timeWindowButton.setOnClickListener(view -> {
            timeWindowIndex = (timeWindowIndex + 1) % TIME_WINDOWS.length;
            timeWindowButton.setText("TIME: " + TIME_WINDOWS[timeWindowIndex]);
            applyFilters();
        });
        row.addView(typeButton, new LinearLayout.LayoutParams(dp(116), dp(44)));
        row.addView(regionButton, new LinearLayout.LayoutParams(dp(132), dp(44)));
        row.addView(severityButton, new LinearLayout.LayoutParams(dp(82), dp(44)));
        row.addView(timeWindowButton, new LinearLayout.LayoutParams(dp(92), dp(44)));
        filters.addView(row);
        panel.addView(filters, marginParams(0, 5, 0, 7));

        tickerContainer = new LinearLayout(this);
        tickerContainer.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(tickerContainer);
        panel.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return panel;
    }

    private LinearLayout buildDetailPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(12), dp(14), dp(12));
        panel.setBackground(panelBackground(Color.argb(246, 8, 12, 17), LINE, 18));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        detailBadge = text("RAW SIGNAL", CYAN, 10, true);
        top.addView(detailBadge, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button close = compactButton("×");
        close.setOnClickListener(view -> panel.setVisibility(View.GONE));
        top.addView(close, new LinearLayout.LayoutParams(dp(42), dp(42)));
        panel.addView(top);

        detailTitle = text("", TEXT, 14, true);
        panel.addView(detailTitle, marginParams(0, 5, 0, 6));
        detailBody = text("", Color.rgb(210, 226, 233), 11, false);
        panel.addView(detailBody);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        sourceButton = actionButton("OPEN SOURCE", CYAN);
        sourceButton.setOnClickListener(view -> handleSelectedSource());
        detailShareButton = actionButton("SHARE CARD", GREEN);
        detailShareButton.setContentDescription(
                "Share the selected information as a DU World Monitor card");
        detailShareButton.setOnClickListener(view -> {
            if (selectedSignal != null) shareSignal(selectedSignal);
        });
        actions.addView(sourceButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        LinearLayout.LayoutParams shareParams = new LinearLayout.LayoutParams(0, dp(48), 1f);
        shareParams.setMargins(dp(7), 0, 0, 0);
        actions.addView(detailShareButton, shareParams);
        panel.addView(actions, marginParams(0, 10, 0, 0));
        return panel;
    }

    @Override
    public void onLayer(Signal.Layer layer, List<Signal> signals, FeedStatus status) {
        runUiBoundary("MainActivity.onLayer." + (layer == null ? "unknown" : layer.name()),
                () -> onLayerUnsafe(layer, signals, status));
    }

    private void onLayerUnsafe(Signal.Layer layer, List<Signal> signals, FeedStatus status) {
        if (layer == null) return;
        List<Signal> safeSignals = signals == null ? Collections.emptyList() : signals;
        LiveOperationsEngine.LayerSnapshot operational = operationsEngine.accept(
                layer, safeSignals, status, System.currentTimeMillis());
        FeedStatus previous = feedStatuses.get(layer);
        layerSignals.put(layer, operational.signals);
        feedStatuses.put(layer, operational.status);
        if (TemporalReplayEngine.isTemporalLayer(layer)) {
            replayEngine.capture(layerSignals, System.currentTimeMillis());
        }
        movementAnalyzer.ingest(layer, operational.signals, System.currentTimeMillis());
        ingestAcquisitions(operational.newAcquisitions, operational.status);
        if (sourceMatrixView != null) sourceMatrixView.update(layer, operational);
        if (mapView != null) mapView.setLayerActivity(layer, operational.status);
        updateLayerLabel(layer, operational.status);
        updateCounters();
        updateFeedPulse();
        updateSignalBeacons();
        pulseFeedTransition(previous, operational.status);
        applyFilters();
        updateAnalysisRibbon();
        if (catalogPanel != null && catalogPanel.getVisibility() == View.VISIBLE
                && ("BRIEF".equals(catalogCategory)
                || "FUSION".equals(catalogCategory)
                || "RISK".equals(catalogCategory)
                || "ANALYST".equals(catalogCategory)
                || "SOURCES".equals(catalogCategory)
                || layer == layerForCategory(catalogCategory))) {
            rebuildCatalogPage();
        }
    }

    @Override
    public void onWeather(String host, List<WorldDataRepository.RadarFrame> frames,
                          FeedStatus status) {
        runUiBoundary("MainActivity.onWeather",
                () -> onWeatherUnsafe(host, frames, status));
    }

    private void onWeatherUnsafe(
            String host,
            List<WorldDataRepository.RadarFrame> frames,
            FeedStatus status) {
        LiveOperationsEngine.LayerSnapshot operational = operationsEngine.accept(
                Signal.Layer.WEATHER, Collections.emptyList(), status,
                System.currentTimeMillis());
        FeedStatus previous = feedStatuses.get(Signal.Layer.WEATHER);
        feedStatuses.put(Signal.Layer.WEATHER, operational.status);
        if (sourceMatrixView != null) {
            sourceMatrixView.update(Signal.Layer.WEATHER, operational);
        }
        if (mapView != null) {
            mapView.setLayerActivity(Signal.Layer.WEATHER, operational.status);
        }
        if (frames != null && !frames.isEmpty()) {
            radarFrames = Collections.unmodifiableList(new ArrayList<>(frames));
            mapView.setRadarFrames(host, frames);
            long frameTimeMs = frames.get(frames.size() - 1).timestampMs;
            if (frameTimeMs > 0L && frameTimeMs != lastWeatherFrame) {
                lastWeatherFrame = frameTimeMs;
                acquisitionCount++;
                showSystemAcquisition("WEATHER FRAME", "RainViewer",
                        eventTime.format(new Date(frameTimeMs)));
            }
        }
        updateLayerLabel(Signal.Layer.WEATHER, operational.status);
        updateFeedPulse();
        updateSignalBeacons();
        pulseFeedTransition(previous, operational.status);
        updateAnalysisRibbon();
        if (catalogPanel != null && catalogPanel.getVisibility() == View.VISIBLE
                && ("BRIEF".equals(catalogCategory) || "WEATHER".equals(catalogCategory)
                || "SOURCES".equals(catalogCategory))) {
            rebuildCatalogPage();
        }
    }

    @Override
    public void onSearchResult(WorldDataRepository.Place place, String error) {
        runUiBoundary("MainActivity.onSearchResult",
                () -> onSearchResultUnsafe(place, error));
    }

    private void onSearchResultUnsafe(WorldDataRepository.Place place, String error) {
        if (place == null) {
            Toast.makeText(this, error == null || error.trim().isEmpty()
                    ? "Location search did not return a result" : error,
                    Toast.LENGTH_LONG).show();
            if (searchInput != null) searchInput.setEnabled(true);
            return;
        }
        searchInput.setEnabled(true);
        searchInput.setText(place.name.split(",")[0]);
        localLatitude = place.latitude;
        localLongitude = place.longitude;
        localSouth = place.south;
        localWest = place.west;
        localNorth = place.north;
        localEast = place.east;
        localCountryScope = place.countryScope;
        localCountryCode = place.countryCode;
        localName = place.name;
        localMode = true;
        localButton.setText("LOCAL ON");
        localButton.setTextColor(GREEN);
        mapView.setCenter(place.latitude, place.longitude, place.countryScope ? 4.2d : 6.2d);
        applyFilters();
        Toast.makeText(this, "LOCAL MODE — " + place.name + (place.countryScope
                ? " • country bounds" : " • 650 km city lens"), Toast.LENGTH_LONG).show();
    }

    private void runSearch() {
        if (repository == null) {
            Toast.makeText(this,
                    "Location search is paused in recovery mode. Restart the complete command deck to use live search.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        searchInput.setEnabled(false);
        Toast.makeText(this, "Locating…", Toast.LENGTH_SHORT).show();
        repository.search(searchInput.getText().toString());
    }

    private void runUiBoundary(String component, Runnable action) {
        if (destroyed || action == null) return;
        if (Looper.myLooper() != Looper.getMainLooper()) {
            runOnUiThread(() -> runUiBoundary(component, action));
            return;
        }
        try {
            action.run();
        } catch (RuntimeException error) {
            String reference = CrashLedger.recordRecovered(this, component, error);
            Log.e(LOG_TAG, "Recovered UI boundary " + component + " / " + reference, error);
            if (feedPulse != null) {
                feedPulse.setText("SOURCE UPDATE ISOLATED • APP REMAINS OPEN • " + reference);
                feedPulse.setTextColor(AMBER);
            }
        }
    }

    private void toggleLocalMode() {
        if (!localMode && localName.trim().isEmpty()) {
            Toast.makeText(this, "Search a city or country first", Toast.LENGTH_LONG).show();
            return;
        }
        localMode = !localMode;
        localButton.setText(localMode ? "LOCAL ON" : "LOCAL OFF");
        localButton.setTextColor(localMode ? GREEN : CYAN);
        applyFilters();
    }

    private void applyFilters() {
        List<Signal> mapSignals = new ArrayList<>();
        List<Signal> ticker = new ArrayList<>();
        EnumMap<Signal.Layer, List<Signal>> viewLayers = layersForTimeline();
        for (Map.Entry<Signal.Layer, List<Signal>> entry : viewLayers.entrySet()) {
            if (!Boolean.TRUE.equals(enabled.get(entry.getKey()))) continue;
            for (Signal signal : entry.getValue()) {
                if (!matchesLocal(signal)) continue;
                if ((signal.layer == Signal.Layer.NEWS || signal.layer == Signal.Layer.NATURAL
                        || signal.layer == Signal.Layer.AIRSPACE)
                        && !matchesEventFilters(signal)) continue;
                if (signal.hasLocation()) mapSignals.add(signal);
                if (isDeskLayer(signal.layer) && isLiveDeskSignal(signal)) {
                    ticker.add(signal);
                }
            }
        }
        if (!replayMode && Boolean.TRUE.equals(enabled.get(Signal.Layer.MEDIA))) {
            for (Signal monitor : localMonitorSignals()) {
                if (matchesLocal(monitor)) mapSignals.add(monitor);
            }
        }
        mapView.setSignals(mapSignals);
        mapView.setReplayState(replayMode, replayFrameAtMs);
        if (replayMode) mapView.setRadarReplayTime(replayFrameAtMs);
        Collections.sort(ticker, (first, second) ->
                compareNewestFirst(first.timestampMs, second.timestampMs));
        // Inflating dozens of ticker cards while the wire drawer is closed wastes the
        // phone's first interactive frames. The full list remains in layerSignals and is
        // rendered immediately when the user opens WIRE.
        if (wirePanel != null && wirePanel.getVisibility() == View.VISIBLE) {
            rebuildTicker(ticker);
        }
        updateCrawl(ticker);
        updateReplayStatus();
    }

    /** Converts coordinate-bearing Local Monitor reports into clearly labelled globe markers. */
    private List<Signal> localMonitorSignals() {
        List<Signal> signals = new ArrayList<>();
        if (monitorStore == null) return signals;
        for (MonitorReport report : monitorStore.reports()) {
            if (report.isDraft()) continue;
            double latitude = report.latitude;
            double longitude = report.longitude;
            boolean inferredPlace = false;
            if (!Double.isFinite(latitude) || !Double.isFinite(longitude)) {
                GeoIndex.Point point = GeoIndex.find(report.locationName);
                if (point == null) continue;
                latitude = point.latitude;
                longitude = point.longitude;
                inferredPlace = true;
            }
            Signal.Credibility credibility = "CONFIRMED".equals(report.truthState)
                    ? Signal.Credibility.CONFIRMED
                    : "REPORTED".equals(report.truthState)
                    ? Signal.Credibility.REPORTED : Signal.Credibility.UNVERIFIED;
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("REPORTER", report.displayName + " " + report.handle);
            facts.put("LOCATION", report.locationName);
            facts.put("REPORT STATE", report.stateLine());
            facts.put("SOURCE LABEL", report.sourceLabel);
            facts.put("LOCATION PRECISION", inferredPlace
                    ? "BUILT-IN PLACE CENTROID / APPROXIMATE"
                    : report.locationApproximate ? "APPROXIMATE" : "REPORTER ATTACHED");
            facts.put("REPORT ID", report.id);
            String title = report.headline.isEmpty()
                    ? report.category + " • " + report.locationName : report.headline;
            signals.add(new Signal(
                    "local-monitor:" + report.id,
                    Signal.Layer.MEDIA,
                    title,
                    report.caption,
                    latitude,
                    longitude,
                    Double.NaN,
                    report.createdAtMs,
                    "Local Monitor / " + report.handle,
                    report.shareUrl,
                    credibility,
                    "OTHER",
                    "GLOBAL",
                    report.live ? 3 : 2,
                    facts));
        }
        return signals;
    }

    private EnumMap<Signal.Layer, List<Signal>> layersForTimeline() {
        EnumMap<Signal.Layer, List<Signal>> result = new EnumMap<>(Signal.Layer.class);
        result.putAll(layerSignals);
        if (!replayMode) {
            replayFrameAtMs = 0L;
            return result;
        }
        TemporalReplayEngine.Snapshot snapshot = replayEngine.snapshotAt(replayTimeMs);
        replayFrameAtMs = snapshot.capturedAtMs;
        for (Signal.Layer layer : Signal.Layer.values()) {
            if (TemporalReplayEngine.isTemporalLayer(layer)) {
                result.put(layer, new ArrayList<>());
            }
        }
        for (Signal signal : snapshot.signals) {
            List<Signal> values = result.get(signal.layer);
            if (values != null) values.add(signal);
        }
        return result;
    }

    private boolean isDeskLayer(Signal.Layer layer) {
        return layer == Signal.Layer.NEWS
                || layer == Signal.Layer.NATURAL
                || layer == Signal.Layer.AIRSPACE
                || layer == Signal.Layer.SPACE_WEATHER
                || layer == Signal.Layer.MARKETS
                || layer == Signal.Layer.WEBCAMS
                || layer == Signal.Layer.RADIO
                || layer == Signal.Layer.TV
                || layer == Signal.Layer.MEDIA;
    }

    private boolean isLiveDeskSignal(Signal signal) {
        if (signal.layer != Signal.Layer.MEDIA) return true;
        return signal.sourceUrl.startsWith("https://")
                && "AUDIO".equalsIgnoreCase(signal.facts.get("MEDIA TYPE"));
    }

    private boolean matchesLocal(Signal signal) {
        if (!localMode) return true;
        if (localCountryScope && signal.hasLocation()
                && !Double.isNaN(localSouth) && !Double.isNaN(localWest)
                && !Double.isNaN(localNorth) && !Double.isNaN(localEast)) {
            boolean longitudeMatch = localWest <= localEast
                    ? signal.longitude >= localWest && signal.longitude <= localEast
                    : signal.longitude >= localWest || signal.longitude <= localEast;
            return signal.latitude >= localSouth && signal.latitude <= localNorth
                    && longitudeMatch;
        }
        return signal.hasLocation()
                && SatelliteMapView.distanceKm(localLatitude, localLongitude,
                signal.latitude, signal.longitude) <= 650d;
    }

    private boolean matchesEventFilters(Signal signal) {
        if (!TYPES[typeIndex].equals("ALL") && !TYPES[typeIndex].equals(signal.eventType)) return false;
        if (!REGIONS[regionIndex].equals("ALL") && !REGIONS[regionIndex].equals(signal.region)) return false;
        if (signal.severity < minimumSeverity) return false;
        if (signal.timestampMs <= 0L) return false;
        long age = Math.max(0L, currentTimelineMs() - signal.timestampMs);
        return age <= TIME_WINDOW_MS[timeWindowIndex];
    }

    private void rebuildTicker(List<Signal> signals) {
        tickerContainer.removeAllViews();
        if (signals.isEmpty()) {
            TextView empty = text(localMode
                    ? "NO MATCHING SIGNALS IN LOCAL MODE" : "WAITING FOR WIRE SIGNALS",
                    MUTED, 10, true);
            empty.setGravity(Gravity.CENTER);
            tickerContainer.addView(empty, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(100)));
            return;
        }
        int limit = Math.min(80, signals.size());
        for (int index = 0; index < limit; index++) {
            Signal signal = signals.get(index);
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(10), dp(9), dp(10), dp(9));
            card.setBackground(panelBackground(PANEL_ALT, signalStateColor(signal), 14));
            TextView light = text("● " + signalStateText(signal)
                    + "  •  SEV " + signal.severity, signalStateColor(signal), 8, true);
            TextView badge = text(badgeText(signal), badgeColor(signal.credibility), 9, true);
            TextView title = text(signal.title, TEXT, 10, true);
            TextView source = text(signal.source + "  •  " + eventTime.format(new Date(signal.timestampMs)),
                    MUTED, 8, false);
            source.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
            card.addView(light);
            card.addView(badge, marginParams(0, 3, 0, 0));
            card.addView(title, marginParams(0, 4, 0, 4));
            card.addView(source);
            Button share = compactButton("SHARE CARD");
            share.setTextColor(GREEN);
            share.setOnClickListener(view -> shareSignal(signal));
            card.addView(share, marginParams(0, 7, 0, 0));
            card.setOnClickListener(view -> showDetail(signal));
            tickerContainer.addView(card, marginParams(0, 0, 0, 7));
        }
    }

    private void updateCrawl(List<Signal> signals) {
        if (crawlText == null) return;
        if (signals.isEmpty()) {
            crawlText.setText(localMode
                    ? "LOCAL SCAN • NO MATCHING PUBLIC SIGNALS YET"
                    : "SCANNING PUBLIC SOURCES • WAITING FOR FIRST DATA PACKET");
            return;
        }
        StringBuilder crawl = new StringBuilder("  ");
        int limit = Math.min(14, signals.size());
        for (int index = 0; index < limit; index++) {
            Signal signal = signals.get(index);
            if (index > 0) crawl.append("     ◆     ");
            crawl.append('[').append(signalStateText(signal)).append('/')
                    .append(shortBadge(signal)).append("] ")
                    .append(signal.title)
                    .append(" — ").append(signal.source)
                    .append(" — ").append(utcClock.format(new Date(signal.timestampMs)));
        }
        crawl.append("     ◆     ");
        crawlText.setText(crawl.toString());
        crawlText.setSelected(true);
    }

    private void shareSignal(Signal signal) {
        if (signal == null) return;
        ShareCardRenderer.share(this, shareDataForSignal(signal));
    }

    private ShareCardData shareDataForSignal(Signal signal) {
        String disclaimer;
        if (signal.credibility == Signal.Credibility.RAW_SIGNAL) {
            disclaimer = "Raw telemetry is not confirmation of identity, intent or an incident. Verify at the original source.";
        } else if (signal.credibility == Signal.Credibility.CALCULATED) {
            disclaimer = "Calculated from named public orbital elements; not live telemetry, tasking proof, navigation or safety data.";
        } else if (signal.credibility == Signal.Credibility.UNVERIFIED) {
            disclaimer = "Unverified developing information. Do not present it as confirmed fact; verify at the original source.";
        } else {
            disclaimer = "Verify timestamp and context at the original source. Observed information is not a forecast.";
        }
        Map<String, String> cardFacts = new LinkedHashMap<>(signal.facts);
        cardFacts.put("FEED STATE", sourceStateText(signal.layer));
        cardFacts.put("SOURCE UPDATE AGE", sourceAgeText(signal.layer));
        cardFacts.put("PROVIDER-RETURNED COUNT",
                String.format(Locale.US, "%,d", count(signal.layer)));
        return new ShareCardData(
                signal.title,
                signal.summary,
                signalStateText(signal),
                badgeText(signal),
                feedDisplayName(signal.layer),
                signal.region,
                signal.severity,
                signal.source,
                signal.sourceUrl,
                signal.timestampMs,
                signal.latitude,
                signal.longitude,
                cardFacts,
                signalStateColor(signal),
                disclaimer);
    }

    private void shareCurrentPage() {
        Map<String, String> facts = new LinkedHashMap<>();
        facts.put("PAGE", catalogCategory);
        facts.put("MODE", replayMode
                ? "4D REPLAY — " + eventTime.format(new Date(replayFrameAtMs)) : "LIVE");
        facts.put("PAGE STATUS", catalogStatus == null ? "Visible" : catalogStatus.getText().toString());
        facts.put("LOCAL MODE", localMode ? "ON — " + localName : "OFF");
        facts.put("TIME WINDOW", TIME_WINDOWS[timeWindowIndex]);
        facts.put("TYPE FILTER", TYPES[typeIndex]);
        facts.put("REGION FILTER", REGIONS[regionIndex]);
        facts.put("MINIMUM SEVERITY", String.valueOf(minimumSeverity));
        facts.put("GENERATED", eventTime.format(new Date()));
        ShareCardRenderer.share(this, new ShareCardData(
                catalogTitle == null ? catalogCategory : catalogTitle.getText().toString(),
                "A shareable summary of the information currently visible on this native operations page.",
                "PAGE SUMMARY",
                "MIXED SOURCE STATES — OPEN EACH ITEM FOR ITS STATUS",
                catalogCategory,
                localMode ? localName : "GLOBAL",
                1,
                APP_BRAND + " on-device operations desk",
                "",
                System.currentTimeMillis(),
                localMode ? localLatitude : Double.NaN,
                localMode ? localLongitude : Double.NaN,
                facts,
                CYAN,
                "Page totals depend on provider coverage and active filters. Verify individual items at their original sources."));
    }

    private ShareCardData customShareCard(
            String title,
            String summary,
            String status,
            String credibility,
            String category,
            String region,
            int severity,
            String source,
            long timestampMs,
            double latitude,
            double longitude,
            Map<String, String> facts,
            int accent,
            String disclaimer) {
        return new ShareCardData(title, summary, status, credibility, category, region,
                severity, source, "", timestampMs, latitude, longitude, facts,
                accent, disclaimer);
    }

    private void showDetail(Signal signal) {
        selectedSignal = signal;
        detailBadge.setText("● " + signalStateText(signal) + "  •  SEVERITY "
                + signal.severity + "  •  " + badgeText(signal));
        detailBadge.setTextColor(signalStateColor(signal));
        detailTitle.setText(signal.title);
        StringBuilder body = new StringBuilder();
        if (!signal.summary.trim().isEmpty()) body.append(signal.summary).append("\n\n");
        for (Map.Entry<String, String> fact : signal.facts.entrySet()) {
            body.append(fact.getKey()).append("  ").append(fact.getValue()).append('\n');
        }
        body.append("\nSOURCE  ").append(signal.source)
                .append("\nTIMESTAMP  ").append(eventTime.format(new Date(signal.timestampMs)))
                .append("\nDISPLAY MODE  ").append(replayMode
                        ? "4D REPLAY — acquired frame "
                        + eventTime.format(new Date(replayFrameAtMs)) : "LIVE")
                .append("\nFEED STATE  ").append(sourceStateText(signal.layer))
                .append("\nSOURCE UPDATE AGE  ").append(sourceAgeText(signal.layer));
        if (signal.layer == Signal.Layer.FLIGHTS || signal.layer == Signal.Layer.SHIPS) {
            long ageSeconds = Math.max(0L,
                    (currentTimelineMs() - signal.timestampMs) / 1000L);
            body.append("\nSOURCE POSITION AGE  ").append(ageSeconds).append(" s")
                    .append("\nTRACK DISPLAY  Observed trail = provider fixes; hollow point = latest fix; linked marker = capped estimate");
        }
        detailBody.setText(body.toString().trim());
        selectedSourceUrl = signal.sourceUrl;
        if (signal.layer == Signal.Layer.FLIGHTS || signal.layer == Signal.Layer.SHIPS) {
            sourceButton.setText(mapView.isFollowing(signal.id)
                    ? "STOP FOLLOWING" : "FOLLOW ON SATELLITE MAP");
        } else if (signal.layer == Signal.Layer.WEBCAMS) {
            sourceButton.setText("VIEW CAMERA IN APP");
        } else if (signal.layer == Signal.Layer.RADIO) {
            sourceButton.setText(signal.id.equals(playingRadioId)
                    ? "STOP PUBLIC RADIO" : "PLAY PUBLIC RADIO");
        } else if (signal.layer == Signal.Layer.TV) {
            sourceButton.setText("WATCH TV IN APP");
        } else if (signal.layer == Signal.Layer.MEDIA) {
            sourceButton.setText(signal.sourceUrl.startsWith("https://")
                    && "AUDIO".equalsIgnoreCase(signal.facts.get("MEDIA TYPE"))
                    ? signal.id.equals(playingRadioId)
                    ? "STOP PUBLIC SAFETY AUDIO" : "PLAY PUBLIC SAFETY AUDIO"
                    : "REFERENCE ONLY");
        } else {
            sourceButton.setText("OPEN ORIGINAL SOURCE");
        }
        boolean traffic = signal.layer == Signal.Layer.FLIGHTS
                || signal.layer == Signal.Layer.SHIPS;
        boolean playableMedia = signal.layer == Signal.Layer.MEDIA
                && selectedSourceUrl.startsWith("https://")
                && "AUDIO".equalsIgnoreCase(signal.facts.get("MEDIA TYPE"));
        sourceButton.setVisibility(traffic || playableMedia
                || !selectedSourceUrl.trim().isEmpty()
                && signal.layer != Signal.Layer.MEDIA ? View.VISIBLE : View.GONE);
        detailPanel.setVisibility(View.VISIBLE);
        detailPanel.bringToFront();
    }

    private void updateLayerLabel(Signal.Layer layer, FeedStatus status) {
        CheckBox toggle = layerChecks.get(layer);
        if (toggle == null) return;
        String name;
        switch (layer) {
            case FLIGHTS: name = "FLIGHTS"; break;
            case SHIPS: name = "SHIPS"; break;
            case WEATHER: name = "WEATHER RADAR"; break;
            case AIRSPACE: name = "AVIATION WARNINGS"; break;
            case NATURAL: name = "NATURAL EVENTS"; break;
            case NEWS: name = "BREAKING WIRE"; break;
            case SATELLITES: name = "CALCULATED ORBITS"; break;
            case SPACE_WEATHER: name = "SPACE WEATHER"; break;
            case INFRASTRUCTURE: name = "STRATEGIC REFERENCE"; break;
            case MARKETS: name = "MARKET RADAR"; break;
            case WEBCAMS: name = "WORLD PUBLIC CAMERAS"; break;
            case RADIO: name = "PUBLIC RADIO"; break;
            case TV: name = "PUBLIC TV STREAMS"; break;
            case MEDIA: name = "PUBLIC CALLS / FREQUENCIES"; break;
            default: name = layer.name();
        }
        String state = status.state == FeedStatus.State.KEY_REQUIRED
                ? "KEY NEEDED" : status.state.name();
        toggle.setText(name + "  •  " + status.count + "  " + state);
        toggle.setTextColor(status.state == FeedStatus.State.OFFLINE ? RED
                : status.state == FeedStatus.State.KEY_REQUIRED
                || status.state == FeedStatus.State.DELAYED
                || status.state == FeedStatus.State.CACHED ? AMBER : TEXT);
    }

    private void updateCounters() {
        int flights = count(Signal.Layer.FLIGHTS);
        int ships = count(Signal.Layer.SHIPS);
        int events = count(Signal.Layer.NATURAL) + count(Signal.Layer.NEWS)
                + count(Signal.Layer.AIRSPACE) + count(Signal.Layer.SPACE_WEATHER);
        int orbits = count(Signal.Layer.SATELLITES);
        int cameras = count(Signal.Layer.WEBCAMS);
        int radio = count(Signal.Layer.RADIO);
        int tv = count(Signal.Layer.TV);
        int markets = count(Signal.Layer.MARKETS);
        String next = String.format(Locale.US,
                "AIR %,d  SEA %,d  EVT %,d  ORBIT %,d  CAM %,d  RADIO %,d  TV %,d  MKT %,d",
                flights, ships, events, orbits, cameras, radio, tv, markets);
        if (next.equals(lastCounterText)) return;
        lastCounterText = next;
        counterText.animate().cancel();
        counterText.setText(next);
        counterText.setAlpha(0.48f);
        counterText.setTranslationY(dp(3));
        counterText.animate().alpha(1f).translationY(0f).setDuration(170L).start();
    }

    /** Keeps the three front-panel indicators meaningful rather than decorative. */
    private void updateSignalBeacons() {
        if (signalBeaconView == null) return;
        int onlineFeeds = 0;
        int offlineFeeds = 0;
        int transitionalFeeds = 0;
        for (FeedStatus status : feedStatuses.values()) {
            if (status == null) continue;
            if (status.state == FeedStatus.State.LIVE
                    || status.state == FeedStatus.State.READY) onlineFeeds++;
            if (status.state == FeedStatus.State.OFFLINE) offlineFeeds++;
            if (status.state == FeedStatus.State.LOADING
                    || status.state == FeedStatus.State.DELAYED
                    || status.state == FeedStatus.State.CACHED
                    || status.state == FeedStatus.State.KEY_REQUIRED) transitionalFeeds++;
        }
        int developing = transitionalFeeds;
        int priority = offlineFeeds;
        Signal.Layer[] eventLayers = {
                Signal.Layer.NEWS, Signal.Layer.NATURAL,
                Signal.Layer.AIRSPACE, Signal.Layer.SPACE_WEATHER
        };
        for (Signal.Layer layer : eventLayers) {
            List<Signal> signals = layerSignals.get(layer);
            if (signals == null) continue;
            for (Signal signal : signals) {
                if (signal.credibility == Signal.Credibility.UNVERIFIED
                        || signal.credibility == Signal.Credibility.REPORTED) developing++;
                if (signal.severity >= 4) priority++;
            }
        }
        signalBeaconView.setCounts(onlineFeeds, developing, priority);
    }

    private void pulseFeedTransition(FeedStatus previous, FeedStatus current) {
        if (signalBeaconView == null || current == null
                || previous != null && previous.state == current.state) return;
        if (current.state == FeedStatus.State.OFFLINE) {
            signalBeaconView.pulse(SignalBeaconView.RED);
        } else if (current.state == FeedStatus.State.LOADING
                || current.state == FeedStatus.State.DELAYED
                || current.state == FeedStatus.State.CACHED
                || current.state == FeedStatus.State.KEY_REQUIRED) {
            signalBeaconView.pulse(SignalBeaconView.AMBER);
        } else {
            signalBeaconView.pulse(SignalBeaconView.GREEN);
        }
    }

    private int count(Signal.Layer layer) {
        FeedStatus status = feedStatuses.get(layer);
        return status == null ? 0 : status.count;
    }

    private String sourceStateText(Signal.Layer layer) {
        LiveOperationsEngine.LayerSnapshot snapshot = operationsEngine.snapshot(layer);
        if (snapshot != null) return snapshot.condition.name();
        FeedStatus status = feedStatuses.get(layer);
        return status == null ? "ACQUIRING" : status.state.name();
    }

    private String sourceAgeText(Signal.Layer layer) {
        LiveOperationsEngine.LayerSnapshot snapshot = operationsEngine.snapshot(layer);
        if (snapshot == null) return "UNKNOWN";
        return LiveOperationsEngine.ageLabel(snapshot.sourceAgeMs).toUpperCase(Locale.ROOT);
    }

    /** Applies stale-record expiry even while a provider is quiet or reconnecting. */
    private void refreshOperationalStates() {
        boolean mapChanged = false;
        EnumMap<Signal.Layer, LiveOperationsEngine.LayerSnapshot> refreshed =
                operationsEngine.refreshAll(System.currentTimeMillis());
        for (Map.Entry<Signal.Layer, LiveOperationsEngine.LayerSnapshot> entry
                : refreshed.entrySet()) {
            Signal.Layer layer = entry.getKey();
            LiveOperationsEngine.LayerSnapshot snapshot = entry.getValue();
            List<Signal> previousSignals = layerSignals.get(layer);
            FeedStatus previousStatus = feedStatuses.get(layer);
            if (previousSignals == null
                    || previousSignals.size() != snapshot.signals.size()) mapChanged = true;
            layerSignals.put(layer, snapshot.signals);
            feedStatuses.put(layer, snapshot.status);
            if (sourceMatrixView != null) sourceMatrixView.update(layer, snapshot);
            updateLayerLabel(layer, snapshot.status);
            pulseFeedTransition(previousStatus, snapshot.status);
        }
        updateCounters();
        updateFeedPulse();
        updateSignalBeacons();
        if (mapChanged) applyFilters();
    }

    private void updateFeedPulse() {
        int loading = 0;
        int offline = 0;
        int live = 0;
        int delayed = 0;
        int keys = 0;
        for (FeedStatus status : feedStatuses.values()) {
            if (status == null) continue;
            if (status.state == FeedStatus.State.LOADING) loading++;
            else if (status.state == FeedStatus.State.DELAYED
                    || status.state == FeedStatus.State.CACHED) delayed++;
            else if (status.state == FeedStatus.State.OFFLINE) offline++;
            else if (status.state == FeedStatus.State.KEY_REQUIRED) keys++;
            else if (status.state == FeedStatus.State.LIVE
                    || status.state == FeedStatus.State.READY) live++;
        }
        if (loading > 0) {
            feedPulse.setText("SOURCE HEALTH / SYNCING  •  " + live + " READY  •  "
                    + loading + " UPDATING");
            feedPulse.setTextColor(AMBER);
        } else if (offline > 0) {
            feedPulse.setText("SOURCE HEALTH / DEGRADED  •  " + live + " READY  •  "
                    + offline + " OFFLINE");
            feedPulse.setTextColor(RED);
        } else if (delayed > 0) {
            feedPulse.setText("SOURCE HEALTH / PARTIAL  •  " + live + " FRESH  •  "
                    + delayed + " DELAYED OR CACHED"
                    + (keys > 0 ? "  •  " + keys + " OPTIONAL KEY" : ""));
            feedPulse.setTextColor(AMBER);
        } else {
            feedPulse.setText("SOURCE HEALTH / OPERATIONAL  •  " + live + " SOURCES READY"
                    + (keys > 0 ? "  •  " + keys + " OPTIONAL KEY" + (keys == 1 ? "" : "S") : ""));
            feedPulse.setTextColor(GREEN);
        }
    }

    private void ingestAcquisitions(List<Signal> signals, FeedStatus status) {
        List<Signal> incoming = new ArrayList<>();
        boolean announce = status != null && (status.state == FeedStatus.State.LIVE
                || status.state == FeedStatus.State.READY);
        int stride = Math.max(1,
                (signals.size() + MAX_ACQUISITION_SCAN - 1) / MAX_ACQUISITION_SCAN);
        for (int index = 0; index < signals.size(); index += stride) {
            Signal signal = signals.get(index);
            boolean directoryRecord = signal.layer == Signal.Layer.WEBCAMS
                    || signal.layer == Signal.Layer.RADIO
                    || signal.layer == Signal.Layer.TV
                    || signal.layer == Signal.Layer.MEDIA
                    || signal.layer == Signal.Layer.SATELLITES;
            String token = directoryRecord ? signal.id : signal.id + "@" + signal.timestampMs;
            if (seenAcquisitions.add(token)) {
                if (announce && isLiveDeskSignal(signal)) {
                    incoming.add(signal);
                    acquisitionCount++;
                }
            }
        }
        while (seenAcquisitions.size() > 20_000) {
            Iterator<String> iterator = seenAcquisitions.iterator();
            if (!iterator.hasNext()) break;
            iterator.next();
            iterator.remove();
        }
        if (incoming.isEmpty()) return;
        Collections.sort(incoming, (first, second) ->
                compareNewestFirst(first.timestampMs, second.timestampMs));
        int limit = Math.min(36, incoming.size());
        for (int index = 0; index < limit; index++) {
            acquisitionQueue.addLast(incoming.get(index));
        }
        while (acquisitionQueue.size() > 48) acquisitionQueue.pollFirst();
        Signal newest = acquisitionQueue.pollFirst();
        if (newest != null) showAcquisition(newest);
    }

    private void showAcquisition(Signal signal) {
        if (acquisitionText == null) return;
        currentAcquisition = signal;
        currentActivityIsAcquisition = true;
        lastFreshAcquisitionAtMs = android.os.SystemClock.uptimeMillis();
        acquisitionText.setText(activityVerb(signal) + " • " + signal.layer.name() + " • "
                + signal.title + " • " + signal.source + " • "
                + utcClock.format(new Date(signal.timestampMs)));
        acquisitionText.setTextColor(signalStateColor(signal));
        runAcquisitionAnimation();
        mapView.highlightSignal(signal);
        mapView.recordActivityPulse(signal, signalStateColor(signal));
        if (signalBeaconView != null) signalBeaconView.pulse(signalChannel(signal));
        updateSideReadouts(activityVerb(signal));
    }

    /** Rotates through real received records between acquisitions; it is labelled TRACKING. */
    private void showTrackedSignal(Signal signal) {
        if (signal == null || acquisitionText == null) return;
        currentAcquisition = signal;
        currentActivityIsAcquisition = false;
        acquisitionText.setText("LIVE TRACK • " + signal.layer.name() + " • "
                + signal.title + " • " + signal.source + " • "
                + utcClock.format(new Date(signal.timestampMs)));
        acquisitionText.setTextColor(layerAccent(signal.layer));
        acquisitionText.setSelected(true);
        acquisitionText.animate().cancel();
        acquisitionText.setAlpha(0.82f);
        acquisitionText.setTranslationX(0f);
        updateSideReadouts("TRACK");
    }

    private Signal nextTrackedSignal() {
        Signal.Layer[] sequence = {
                Signal.Layer.FLIGHTS, Signal.Layer.AIRSPACE, Signal.Layer.NATURAL,
                Signal.Layer.NEWS, Signal.Layer.SHIPS, Signal.Layer.SATELLITES,
                Signal.Layer.SPACE_WEATHER,
                Signal.Layer.WEBCAMS, Signal.Layer.RADIO,
                Signal.Layer.TV, Signal.Layer.MEDIA, Signal.Layer.INFRASTRUCTURE
        };
        for (int attempt = 0; attempt < sequence.length; attempt++) {
            Signal.Layer layer = sequence[Math.floorMod(watchCursor++, sequence.length)];
            if (!Boolean.TRUE.equals(enabled.get(layer))) continue;
            List<Signal> available = layerSignals.get(layer);
            if (available == null || available.isEmpty()) continue;
            int index = Math.floorMod(watchCursor * 31, available.size());
            return available.get(index);
        }
        return null;
    }

    private void showSystemAcquisition(String kind, String source, String timestamp) {
        if (acquisitionText == null) return;
        acquisitionText.setText("ACQUIRED • " + kind + " • " + source + " • " + timestamp);
        acquisitionText.setTextColor(CYAN);
        runAcquisitionAnimation();
        if (signalBeaconView != null) signalBeaconView.pulse(SignalBeaconView.GREEN);
    }

    private void runAcquisitionAnimation() {
        int token = ++acquisitionAnimationToken;
        acquisitionText.animate().cancel();
        acquisitionText.setAlpha(1f);
        acquisitionText.setTranslationX(dp(24));
        acquisitionText.animate().translationX(0f).setDuration(180L).start();
        activityHandler.postDelayed(() -> {
            if (token == acquisitionAnimationToken && acquisitionText != null) {
                acquisitionText.animate().alpha(0.34f).setDuration(220L).start();
            }
        }, 1_250L);
    }

    private void tickActivityGuarded() {
        runUiBoundary("MainActivity.activityTick", this::tickActivityFrame);
    }

    private void tickActivityFrame() {
        if (scanStep % 24 == 0) refreshOperationalStates();
        if ((scanStep & 1) == 0) advanceReplay();
        String[] phases = {"AIR", "SEA", "WIRE", "SEISMIC", "WEATHER", "AIRSPACE",
                "GKG THEMES", "ORBITS", "SPACE", "CAM", "RADIO", "TV", "PUBLIC CALLS",
                "MARKETS", "AIRPORTS", "PORTS", "REFERENCE"};
        String phase = phases[scanStep % phases.length];
        int events = count(Signal.Layer.NATURAL) + count(Signal.Layer.NEWS)
                + count(Signal.Layer.AIRSPACE) + count(Signal.Layer.SPACE_WEATHER);
        telemetryText.setText(String.format(Locale.US,
                "MODE / %s   LENS / %s   WINDOW / %s   SECTOR / %s   CYCLE / %05d   GLOBE / %06.1f°   PACKETS / %,d   FRAMES / %,d   AIR / %,d   SEA / %,d   AIRWX / %,d   EVENTS / %,d   ORBIT / %,d   SPACE / %,d   CAM / %,d   RADIO / %,d   TV / %,d   CALLS / %,d   MARKET / %,d   INFRA / %,d",
                replayMode ? "4D REPLAY" : "LIVE", regionalFocus.name,
                TIME_WINDOWS[timeWindowIndex], phase,
                Math.floorMod(scanStep, 100_000), mapView.getCenterLongitude(),
                acquisitionCount, replayEngine.frameCount(), count(Signal.Layer.FLIGHTS),
                count(Signal.Layer.SHIPS), count(Signal.Layer.AIRSPACE), events,
                count(Signal.Layer.SATELLITES), count(Signal.Layer.SPACE_WEATHER),
                count(Signal.Layer.WEBCAMS),
                count(Signal.Layer.RADIO), count(Signal.Layer.TV),
                count(Signal.Layer.MEDIA), count(Signal.Layer.MARKETS),
                count(Signal.Layer.INFRASTRUCTURE)));
        if ((scanStep & 1) == 1 && !acquisitionQueue.isEmpty()) {
            Signal next = acquisitionQueue.pollFirst();
            if (next != null) showAcquisition(next);
        } else if (acquisitionQueue.isEmpty() && scanStep % 6 == 0
                && android.os.SystemClock.uptimeMillis() - lastFreshAcquisitionAtMs > 2_400L) {
            showTrackedSignal(nextTrackedSignal());
        }
        // Text and controls stay steady. Only real arrivals trigger the finite coloured
        // pulses; continuous motion lives on the map behind the information surfaces.
        feedPulse.setAlpha(1f);
        if (liveText != null) liveText.setAlpha(1f);
        updateSideReadouts(phase);
        if (scanStep % 8 == 0) updateAnalysisRibbon();
        scanStep++;
        activityHandler.postDelayed(this::tickActivityGuarded, 420L);
    }

    /**
     * Rotates a compact desk readout through real on-device analysis. It deliberately says
     * WATCH/OBSERVED and NOT CONFIRMATION so a busy interface never turns correlation into fact.
     */
    private void updateAnalysisRibbon() {
        if (correlationText == null) return;
        SituationAnalyzer.Brief current = latestBrief;
        if (current != null) renderAnalysisRibbon(current);

        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastAnalysisRequestedMs < ANALYSIS_REFRESH_MS
                || !analysisRunning.compareAndSet(false, true)) {
            return;
        }
        lastAnalysisRequestedMs = now;
        EnumMap<Signal.Layer, List<Signal>> layerSnapshot =
                new EnumMap<>(Signal.Layer.class);
        EnumMap<Signal.Layer, FeedStatus> statusSnapshot =
                new EnumMap<>(Signal.Layer.class);
        layerSnapshot.putAll(layerSignals);
        statusSnapshot.putAll(feedStatuses);
        try {
            analysisExecutor.execute(() -> {
                SituationAnalyzer.Brief calculated = SituationAnalyzer.analyze(
                        layerSnapshot, statusSnapshot, System.currentTimeMillis());
                runOnUiThread(() -> {
                    analysisRunning.set(false);
                    if (destroyed) return;
                    latestBrief = calculated;
                    renderAnalysisRibbon(calculated);
                    if (catalogPanel != null
                            && catalogPanel.getVisibility() == View.VISIBLE
                            && ("BRIEF".equals(catalogCategory)
                            || "ANALYST".equals(catalogCategory)
                            || "RISK".equals(catalogCategory))) {
                        rebuildCatalogPage();
                    }
                });
            });
        } catch (RuntimeException error) {
            analysisRunning.set(false);
            Log.w(LOG_TAG, "Analysis refresh skipped", error);
        }
    }

    private void renderAnalysisRibbon(SituationAnalyzer.Brief brief) {
        if (brief == null || correlationText == null) return;
        if (!brief.domainWatches.isEmpty()
                && (brief.correlations.isEmpty() || Math.floorMod(briefRotationCursor++, 2) == 0)) {
            SituationAnalyzer.DomainWatch watch = brief.domainWatches.get(
                    Math.floorMod(briefRotationCursor, brief.domainWatches.size()));
            correlationText.setText("CROSS-DOMAIN WATCH / "
                    + shortForRail(watch.label, wideLayout ? 108 : 58)
                    + "\nAIR " + watch.aircraftNearby + " ≤500 KM • SEA "
                    + watch.vesselsNearby + " ≤300 KM • PROXIMITY IS NOT CONFIRMATION");
            correlationText.setTextColor(watch.severity >= 4 ? RED : CYAN);
            return;
        }
        if (!brief.correlations.isEmpty()) {
            SituationAnalyzer.Correlation correlation = brief.correlations.get(
                    Math.floorMod(briefRotationCursor++, brief.correlations.size()));
            correlationText.setText("CROSS-SOURCE WATCH / "
                    + shortForRail(correlation.label, wideLayout ? 112 : 62)
                    + "\n" + correlation.recordCount + " RECORDS • "
                    + shortForRail(correlation.sources, wideLayout ? 92 : 50)
                    + " • NOT CONFIRMATION");
            correlationText.setTextColor(correlation.severity >= 4 ? RED : AMBER);
            return;
        }

        List<SituationAnalyzer.RegionalState> observed = new ArrayList<>();
        for (SituationAnalyzer.RegionalState region : brief.regions) {
            if (region.recordCount > 0) observed.add(region);
        }
        if (!observed.isEmpty()) {
            SituationAnalyzer.RegionalState region = observed.get(
                    Math.floorMod(briefRotationCursor++, observed.size()));
            int color = region.observedScore >= 55 ? RED
                    : region.observedScore >= 30 ? AMBER : GREEN;
            correlationText.setText(String.format(Locale.US,
                    "OBSERVED SIGNAL DENSITY / %s %02d/99 • %s\n"
                            + "%,d RECENT RECORDS • %,d PRIORITY • NOT A FORECAST",
                    region.region, region.observedScore, region.level,
                    region.recordCount, region.priorityCount));
            correlationText.setTextColor(color);
            return;
        }

        correlationText.setText(String.format(Locale.US,
                "ANALYSIS DESK / %,d RECORDS • %,d SOURCES READY\n"
                        + "WAITING FOR CROSS-SOURCE ALIGNMENT • NO PREDICTION",
                brief.totalRecords, brief.onlineFeeds));
        correlationText.setTextColor(brief.offlineFeeds > 0 ? AMBER : CYAN);
    }

    private void updateSideReadouts(String phase) {
        if (leftReadout != null) {
            leftReadout.setText(String.format(Locale.US,
                    "%s\n%s • %s\n\nAIR %,d\nSEA %,d\nEVT %,d\nCAM %,d\nMEDIA %,d",
                    shortForRail(regionalFocus.name, 14), phase,
                    TIME_WINDOWS[timeWindowIndex], count(Signal.Layer.FLIGHTS),
                    count(Signal.Layer.SHIPS),
                    count(Signal.Layer.NATURAL) + count(Signal.Layer.NEWS)
                            + count(Signal.Layer.AIRSPACE)
                            + count(Signal.Layer.SPACE_WEATHER),
                    count(Signal.Layer.WEBCAMS),
                    count(Signal.Layer.RADIO) + count(Signal.Layer.TV)));
            leftReadout.setAlpha(1f);
        }
        if (rightReadout != null) {
            Signal signal = currentAcquisition;
            if (signal == null) {
                rightReadout.setText("LATEST / SIGNAL\n\nSCANNING\nPUBLIC SOURCES");
                rightReadout.setTextColor(CYAN);
            } else {
                rightReadout.setText((currentActivityIsAcquisition
                                ? "ACQUIRED" : "TRACK")
                        + "\n" + signal.layer.name() + "  "
                        + utcClock.format(new Date(signal.timestampMs))
                        + "\n\n" + shortForRail(signal.title, 52)
                        + "\n" + shortForRail(signal.source, 30));
                rightReadout.setTextColor(layerAccent(signal.layer));
            }
            rightReadout.setAlpha(1f);
        }
    }

    private String activityVerb(Signal signal) {
        switch (signal.layer) {
            case FLIGHTS:
            case SHIPS: return "TRACK ACQUIRED";
            case AIRSPACE: return "AIRSPACE WARNING ACQUIRED";
            case SATELLITES: return "ORBIT CALCULATED";
            case WEBCAMS: return "CAMERA INDEXED";
            case RADIO: return "STATION INDEXED";
            case TV: return "TV CHANNEL INDEXED";
            case MEDIA: return "REFERENCE READY";
            case SPACE_WEATHER: return "SPACE WEATHER ACQUIRED";
            case INFRASTRUCTURE: return "REFERENCE READY";
            case MARKETS: return "MARKET QUOTE ACQUIRED";
            default: return "SIGNAL ACQUIRED";
        }
    }

    private String shortForRail(String value, int maximum) {
        String clean = value == null ? "" : value.trim().replaceAll("\\s+", " ");
        return clean.length() <= maximum
                ? clean : clean.substring(0, Math.max(1, maximum - 1)) + "…";
    }

    private int layerAccent(Signal.Layer layer) {
        switch (layer) {
            case SHIPS: return GREEN;
            case NATURAL: return AMBER;
            case NEWS: return RED;
            case AIRSPACE: return Color.rgb(225, 158, 61);
            case SATELLITES: return Color.rgb(174, 139, 224);
            case SPACE_WEATHER: return Color.rgb(165, 133, 214);
            case INFRASTRUCTURE: return Color.rgb(111, 130, 143);
            case MARKETS: return Color.rgb(99, 177, 160);
            case WEBCAMS: return GREEN;
            case RADIO: return Color.rgb(143, 124, 171);
            case TV: return Color.rgb(108, 148, 196);
            case MEDIA: return Color.rgb(113, 143, 173);
            case FLIGHTS:
            case WEATHER:
            default: return CYAN;
        }
    }

    private void tickClockGuarded() {
        runUiBoundary("MainActivity.clockTick", this::tickClockFrame);
    }

    private void tickClockFrame() {
        Date now = new Date();
        if (wideLayout) {
            clockText.setText(utcClock.format(now) + "  |  "
                    + localClock.format(now) + " LOCAL");
        } else {
            clockText.setText(utcClock.format(now) + "\n"
                    + localClock.format(now) + " LOCAL");
        }
        clockHandler.postDelayed(this::tickClockGuarded,
                1000L - System.currentTimeMillis() % 1000L);
    }


    // F11 / 20 — COUNTRY LENSES. These never own data: they filter F9 NewsStore records in-place.
    private static final String[] F11_COUNTRIES = {"UGANDA","KENYA","TANZANIA","RWANDA","BURUNDI","DR CONGO","SOUTH SUDAN"};
    private boolean f11CountryMatches(NewsItem n,String country){
        if(n==null||country==null||"ALL".equals(country))return true;
        String r=n.region==null?"":n.region.toUpperCase(Locale.ROOT);
        if("UGANDA".equals(country))return "UGANDA".equals(r)||"KAMPALA".equals(r)||r.endsWith(" UGANDA")||Arrays.asList("CENTRAL UGANDA","EASTERN UGANDA","NORTHERN UGANDA","WESTERN UGANDA","WEST NILE","KARAMOJA").contains(r);
        return country.equals(r);
    }
    private int f11CountryCount(List<NewsItem> items,String country){
        int n=0;for(NewsItem x:items)if(f11CountryMatches(x,country))n++;return n;
    }
    private long f11CountryNewest(List<NewsItem> items,String country){
        long newest=0;for(NewsItem x:items)if(f11CountryMatches(x,country)&&x.publishedAt>newest)newest=x.publishedAt;return newest;
    }
    private View buildF11CountryBar(List<NewsItem> source){
        HorizontalScrollView hs=new HorizontalScrollView(this);LinearLayout row=new LinearLayout(this);
        for(String country:F11_COUNTRIES){
            int count=f11CountryCount(source,country);long newest=f11CountryNewest(source,country);
            String label=(country.equals(f9CountryLens)?"● ":"")+country+" "+count+(newest>0?" · "+localNewsAge(newest):"");
            Button b=compactButton(label);b.setEnabled(!country.equals(f9CountryLens));b.setOnClickListener(v->{f9CountryLens=country;catalogNewsType="UGANDA".equals(country)?"UGANDA":"ALL";f17SaveState();rebuildLocalNewsPage();});row.addView(b);
        }
        hs.addView(row);return hs;
    }

    // F12 / 20 — REPLAY TIME LENS. F9 remains the only NewsStore and chronological owner.
    private static final String[] F12_WINDOWS={"NOW","1H","6H","12H","24H","3D","7D"};
    private long f12WindowMs(String w){if("1H".equals(w))return 3600000L;if("6H".equals(w))return 21600000L;if("12H".equals(w))return 43200000L;if("24H".equals(w))return 86400000L;if("3D".equals(w))return 259200000L;if("7D".equals(w))return 604800000L;return Long.MAX_VALUE;}
    private boolean f12ReplayMatches(NewsItem n){
        if(n==null||"NOW".equals(f12ReplayWindow))return true;
        long stamp=n.publishedAt>0?n.publishedAt:n.firstSeenAt;
        long end=f13ReplayAnchorMs>0?f13ReplayAnchorMs:System.currentTimeMillis();
        long start=end-f12WindowMs(f12ReplayWindow);
        return stamp>0&&stamp<=end&&stamp>=start;
    }
    private View buildF12ReplayBar(){
        HorizontalScrollView hs=new HorizontalScrollView(this);LinearLayout row=new LinearLayout(this);
        Button prev=compactButton("‹ PREVIOUS");prev.setOnClickListener(v->{long step=f12WindowMs(f12ReplayWindow);if(step==Long.MAX_VALUE)step=3600000L;long end=f13ReplayAnchorMs>0?f13ReplayAnchorMs:System.currentTimeMillis();f13ReplayAnchorMs=end-step;f17SaveState();rebuildLocalNewsPage();});row.addView(prev);
        for(String w:F12_WINDOWS){Button b=compactButton((w.equals(f12ReplayWindow)?"● ":"")+w);b.setEnabled(!w.equals(f12ReplayWindow));b.setOnClickListener(v->{f12ReplayWindow=w;f13ReplayAnchorMs=0L;f17SaveState();rebuildLocalNewsPage();});row.addView(b);}
        Button next=compactButton("NEXT ›");next.setEnabled(f13ReplayAnchorMs>0);next.setOnClickListener(v->{long step=f12WindowMs(f12ReplayWindow);if(step==Long.MAX_VALUE)step=3600000L;f13ReplayAnchorMs=Math.min(System.currentTimeMillis(),f13ReplayAnchorMs+step);if(f13ReplayAnchorMs>=System.currentTimeMillis()-1000L)f13ReplayAnchorMs=0L;f17SaveState();rebuildLocalNewsPage();});row.addView(next);
        Button live=compactButton("LIVE");live.setOnClickListener(v->{f13ReplayAnchorMs=0L;f12ReplayWindow="NOW";f17SaveState();rebuildLocalNewsPage();});row.addView(live);
        hs.addView(row);return hs;
    }

    // F14 / 20 — RELATED INTELLIGENCE. F9 NewsStore/cluster records stay canonical.
    private List<NewsItem> f14Related(NewsItem focus){
        ArrayList<NewsItem> out=new ArrayList<>();if(focus==null)return out;
        for(NewsItem n:new NewsStore(this).load()){
            if(n==null||n.id.equals(focus.id))continue;
            boolean sameCluster=focus.clusterId!=null&&!focus.clusterId.isEmpty()&&focus.clusterId.equals(n.clusterId);
            boolean sameRegion=focus.region!=null&&!focus.region.isEmpty()&&focus.region.equalsIgnoreCase(n.region);
            boolean sameTopic=focus.topic!=null&&!focus.topic.isEmpty()&&focus.topic.equalsIgnoreCase(n.topic);
            if(sameCluster||(sameRegion&&sameTopic))out.add(n);
        }
        Collections.sort(out,(a,b)->Long.compare(b.publishedAt,a.publishedAt));return out;
    }
    private void addF14Related(LinearLayout host,NewsItem focus){
        List<NewsItem> related=f14Related(focus);if(related.isEmpty())return;
        host.addView(text("RELATED INTELLIGENCE · "+related.size()+" · SAME F9 STORE",AMBER,10,true),marginParams(0,10,0,4));
        for(int i=0;i<Math.min(6,related.size());i++){NewsItem n=related.get(i);Button b=actionButton((n.sourceName==null?"SOURCE":n.sourceName)+" · "+n.title,CYAN);b.setOnClickListener(v->{f17BeforeDetail();showLocalNewsDetail(n);});host.addView(b,marginParams(0,2,0,2));}
    }

    // F15 / 20 — UNIFIED SEARCH. Existing F9 search field; no parallel index/store.
    private boolean f15Contains(String v,String q){return v!=null&&v.toLowerCase(Locale.ROOT).contains(q);}
    private List<NewsItem> f15NewsSearch(String q){ArrayList<NewsItem>o=new ArrayList<>();if(q==null||q.trim().isEmpty())return o;String x=q.trim().toLowerCase(Locale.ROOT);for(NewsItem n:new NewsStore(this).load())if(f15Contains(n.title,x)||f15Contains(n.summary,x)||f15Contains(n.sourceName,x)||f15Contains(n.region,x)||f15Contains(n.topic,x))o.add(n);Collections.sort(o,(a,b)->Long.compare(b.publishedAt,a.publishedAt));return o;}
    private List<MonitorReport> f15MonitorSearch(String q){ArrayList<MonitorReport>o=new ArrayList<>();if(q==null||q.trim().isEmpty())return o;String x=q.trim().toLowerCase(Locale.ROOT);for(MonitorReport m:new MonitorStore(this).reports())if(f15Contains(m.headline,x)||f15Contains(m.caption,x)||f15Contains(m.displayName,x)||f15Contains(m.handle,x)||f15Contains(m.locationName,x)||f15Contains(m.category,x))o.add(m);return o;}
    private List<Signal> f15SignalSearch(String q){ArrayList<Signal>o=new ArrayList<>();if(q==null||q.trim().isEmpty())return o;String x=q.trim().toLowerCase(Locale.ROOT);for(Map.Entry<Signal.Layer,List<Signal>>e:layerSignals.entrySet())for(Signal s:e.getValue())if(f15Contains(s.title,x)||f15Contains(s.summary,x)||f15Contains(s.source,x)||f15Contains(s.region,x)||f15Contains(s.eventType,x))o.add(s);Collections.sort(o,(a,b)->Long.compare(b.timestampMs,a.timestampMs));return o;}
    private void addF15UnifiedResults(LinearLayout host,String q){if(q==null||q.trim().isEmpty())return;List<NewsItem>news=f15NewsSearch(q);List<MonitorReport>mon=f15MonitorSearch(q);List<Signal>sig=f15SignalSearch(q);host.addView(text("UNIFIED SEARCH · "+(news.size()+mon.size()+sig.size())+" RESULTS",AMBER,10,true),marginParams(0,6,0,4));int k=0;for(NewsItem n:news){if(k++>=8)break;Button b=actionButton("NEWS · "+n.sourceName+" · "+n.title,CYAN);b.setOnClickListener(v->{f17BeforeDetail();showLocalNewsDetail(n);});host.addView(b,marginParams(0,2,0,2));}k=0;for(MonitorReport m:mon){if(k++>=5)break;Button b=actionButton("MONITOR · "+m.displayName+" · "+(m.headline.isEmpty()?m.category:m.headline),GREEN);b.setOnClickListener(v->DuMonitorPlayer.open(this,m.id));host.addView(b,marginParams(0,2,0,2));}k=0;for(Signal s:sig){if(k++>=8)break;Button b=actionButton(s.layer.name()+" · "+s.title,AMBER);b.setOnClickListener(v->showDetail(s));host.addView(b,marginParams(0,2,0,2));}if(news.isEmpty()&&mon.isEmpty()&&sig.isEmpty())host.addView(text("NO MATCHING RECORDS · F9 NEWS / MONITORS / OPERATIONAL SIGNALS",MUTED,9,false));}

    // F16 / 20 — HONEST DATA STATES. Empty/stale/offline is explicit; never represented as a dead card.
    private String f16NewsState(List<NewsItem> all,boolean offline,NewsPreferences prefs){
        if(offline&&all.isEmpty())return "OFFLINE · NO SAVED NEWS";
        if(offline)return "OFFLINE · SHOWING SAVED NEWS";
        if(all.isEmpty())return "NO CURRENT RECORDS · SOURCES CHECKING";
        long last=prefs.time("last_refresh",0);if(last<=0)return "FRESHNESS UNKNOWN";
        long age=System.currentTimeMillis()-last;if(age>6L*60*60*1000)return "STALE · LAST REFRESH "+localNewsAge(last);
        return "LIVE · UPDATED "+localNewsAge(last);
    }
    private TextView f16StateLine(String state){
        int c=state.startsWith("LIVE")?GREEN:(state.startsWith("OFFLINE")||state.startsWith("STALE")?AMBER:MUTED);
        return text(state,c,9,true);
    }
    private String f16MissingLocation(NewsItem n){return n==null||n.region==null||n.region.trim().isEmpty()?"LOCATION UNKNOWN":n.region;}

    // F17 / 20 — STATE & BACK NAVIGATION. Persist the F9 lens, never create a parallel navigation stack.
    private static final String F17_PREFS="f9_view_state";
    private void f17SaveState(){
        try{getSharedPreferences(F17_PREFS,MODE_PRIVATE).edit()
            .putString("country",f9CountryLens).putString("window",f12ReplayWindow).putLong("anchor",f13ReplayAnchorMs)
            .putString("category",catalogNewsType).putString("query",catalogSearch==null?"":catalogSearch.getText().toString())
            .putInt("visible",catalogVisibleLimit).apply();}catch(Exception e){CrashLedger.record(this,"F17_SAVE",e);}
    }
    private void f17RestoreState(){
        try{android.content.SharedPreferences p=getSharedPreferences(F17_PREFS,MODE_PRIVATE);
            f9CountryLens=p.getString("country","UGANDA");f12ReplayWindow=p.getString("window","NOW");f13ReplayAnchorMs=p.getLong("anchor",0L);
            catalogNewsType=p.getString("category","UGANDA");catalogVisibleLimit=Math.max(20,p.getInt("visible",20));
            if(catalogSearch!=null)catalogSearch.setText(p.getString("query",""));}catch(Exception e){CrashLedger.record(this,"F17_RESTORE",e);}
    }
    private void f17BeforeDetail(){f17SaveState();}

    // F19 / 20 — FUNCTIONAL TAP GATE. Runtime-visible controls register real action ownership.
    private final LinkedHashMap<String,String> f19TapOwners=new LinkedHashMap<>();
    private void f19Own(String label,String owner){if(label!=null&&owner!=null)f19TapOwners.put(label,owner);}
    private void f19RegisterCoreTapOwners(){
        f19TapOwners.clear();
        f19Own("GLOBE","showGlobeOverview");f19Own("MONITORS","openLocalMonitors");f19Own("NEWS","openCatalog:NEWS");
        f19Own("COUNTRY","F11:f9CountryLens");f19Own("REPLAY","F12/F13:f9Chronology");f19Own("SEARCH","F15:catalogSearch");
        f19Own("NEWS DETAIL","showLocalNewsDetail");f19Own("RELATED","F14:showLocalNewsDetail");
        f19Own("MONITOR DETAIL","DuMonitorPlayer.open");f19Own("SIGNAL DETAIL","showDetail");
        f19Own("OPEN FULL ARTICLE","Intent.ACTION_VIEW");f19Own("SHARE","Intent.ACTION_SEND");
        f19Own("MARK READ","NewsStore.markRead");f19Own("HIDE THIS OUTLET","NewsPreferences.source");
        f19Own("FOLLOW TOPIC","NewsPreferences.topic");f19Own("SHOW ON GLOBE","showDetail:NEWS");
    }
    private boolean f19CoreTapsReady(){
        String[] required={"GLOBE","MONITORS","NEWS","COUNTRY","REPLAY","SEARCH","NEWS DETAIL","RELATED","MONITOR DETAIL","SIGNAL DETAIL","OPEN FULL ARTICLE","SHARE","MARK READ","HIDE THIS OUTLET","FOLLOW TOPIC","SHOW ON GLOBE"};
        for(String x:required)if(!f19TapOwners.containsKey(x)||f19TapOwners.get(x).trim().isEmpty())return false;return true;
    }

    // F20 / 20 — FULL FUNCTIONAL GREEN GATE. Final cumulative contract; no new feature owner.
    private boolean f20FunctionalGreen(){return f19CoreTapsReady()&&f9CountryLens!=null&&f12ReplayWindow!=null&&new NewsStore(this).load()!=null&&catalogSearch!=null;}

    // F9 / 20-REGION OPERATIONAL FEED — Local News lives inside the existing NEWS catalog.
    private void rebuildLocalNewsPage() {
        catalogList.removeAllViews();
        catalogSearch.setVisibility(View.VISIBLE);
        newsCategoryBar.setVisibility(View.VISIBLE);
        String unifiedQuery=catalogSearch==null?"":catalogSearch.getText().toString().trim();
        addF15UnifiedResults(catalogList,unifiedQuery);
        NewsStore store = new NewsStore(this);
        NewsPreferences prefs = new NewsPreferences(this);
        List<NewsItem> all = store.load();
        Collections.sort(all,(a,b)->Long.compare(b.publishedAt,a.publishedAt)); // F9 owns chronology.
        String q = catalogSearch == null ? "" : catalogSearch.getText().toString().trim().toLowerCase(Locale.ROOT);
        ArrayList<NewsItem> show = new ArrayList<>();
        for (NewsItem n : all) {
            String hay = (n.title+" "+n.summary+" "+n.sourceName+" "+n.region).toLowerCase(Locale.ROOT);
            if (!q.isEmpty() && !hay.contains(q)) continue;
            if (!f11CountryMatches(n,f9CountryLens)) continue;
            if (!f12ReplayMatches(n)) continue;
            if (!localNewsMatches(n, catalogNewsType, prefs)) continue;
            show.add(n);
        }
        int working=0; for(NewsSource s:NewsSourceCatalog.ALL) if("Working".equals(prefs.status(s.id))) working++;
        boolean offline = !isNetworkConnectedForNews();
        catalogTitle.setText("F9 / 20-REGION OPERATIONAL FEED");
        f19RegisterCoreTapOwners();
        catalogList.addView(text("F20 FUNCTIONAL GREEN · "+(f20FunctionalGreen()?"READY":"CHECK REQUIRED")+" · F9 SOURCE / DETAIL / CHRONOLOGY OWNED",f20FunctionalGreen()?GREEN:AMBER,8,true),marginParams(0,0,0,3));
        catalogList.addView(text("F19 TAP GATE · "+(f19CoreTapsReady()?"READY":"ACTION CONTRACT INCOMPLETE")+" · "+f19TapOwners.size()+" owned actions",f19CoreTapsReady()?GREEN:AMBER,8,true),marginParams(0,0,0,3));
        catalogList.addView(text("F18 SINGLE OWNER · REGION = country lens · REPLAY = timeline controls",MUTED,8,true),marginParams(0,0,0,4));
        catalogStatus.setText((offline?"Offline — showing saved news • ":"Updated "+localNewsAge(prefs.time("last_refresh",0))+" • ")
                +working+" sources • "+NewsRegions.ALL.length+" regions • "+show.size()+" stories");
        catalogStatus.setTextColor(offline?MUTED:GREEN);
        catalogList.addView(f16StateLine(f16NewsState(all,offline,prefs)));
        catalogList.addView(buildF11CountryBar(all));
        catalogList.addView(buildF12ReplayBar());
        String replayAnchor=f13ReplayAnchorMs>0?new java.text.SimpleDateFormat("dd MMM HH:mm",Locale.getDefault()).format(new java.util.Date(f13ReplayAnchorMs)):"LIVE";
        TextView replay=text("F13 REPLAY · "+f12ReplayWindow+" · "+replayAnchor+" · F9 chronology · original record IDs / clusters / detail",MUTED,9,true);
        catalogList.addView(replay,marginParams(0,4,0,4));
        TextView lens=text("F11 COUNTRY LENS · "+f9CountryLens+" · "+show.size()+" records · same F9 source IDs / clusters / chronology",MUTED,9,true);
        catalogList.addView(lens,marginParams(0,4,0,6));
        LinkedHashMap<String,Integer> counts=new LinkedHashMap<>();
        LinkedHashMap<String,Long> newest=new LinkedHashMap<>();
        for(NewsItem n:show){counts.put(n.region,counts.containsKey(n.region)?counts.get(n.region)+1:1);Long z=newest.get(n.region);if(z==null||n.publishedAt>z)newest.put(n.region,n.publishedAt);}
        if(!counts.isEmpty()){HorizontalScrollView hs=new HorizontalScrollView(this);LinearLayout rr=new LinearLayout(this);for(Map.Entry<String,Integer>e:counts.entrySet()){Button b=compactButton(e.getKey()+" "+e.getValue()+" · "+localNewsAge(newest.get(e.getKey())));b.setOnClickListener(v->{catalogSearch.setText(e.getKey());rebuildLocalNewsPage();});rr.addView(b);}hs.addView(rr);catalogList.addView(hs);}
        if (show.isEmpty()) {
            String reason=offline?"OFFLINE · NO SAVED RECORDS MATCH THIS FILTER":"NO CURRENT RECORDS · "+f9CountryLens+" · "+f12ReplayWindow+(q.isEmpty()?"":" · SEARCH “"+q+"”");
            TextView empty=text(reason,MUTED,11,true);
            empty.setGravity(Gravity.CENTER); empty.setPadding(dp(20),dp(40),dp(20),dp(40)); catalogList.addView(empty);
        } else {
            int visible=Math.min(catalogVisibleLimit,show.size());
            for(int i=0;i<visible;i++){Signal ns=NewsSignals.from(java.util.Collections.singletonList(show.get(i))).get(0);catalogList.addView(buildCatalogCard(ns),marginParams(0,0,0,7));}
            catalogMoreButton.setVisibility(visible<show.size()?View.VISIBLE:View.GONE);
        }
        syncLocalNewsSignals(all);
    }

    private boolean localNewsMatches(NewsItem n,String f,NewsPreferences prefs){
        if(f==null||"ALL".equals(f))return true;
        if("FOR YOU".equals(f)){NewsSource src=NewsSourceCatalog.byId(n.sourceId);return src!=null&&prefs.source(src)&&prefs.topic(n.topic);}
        if("UGANDA".equals(f))return "UGANDA".equals(n.region)||"KAMPALA".equals(n.region)||n.region.contains("UGANDA");
        if("E.AFRICA".equals(f))return "EAST_AFRICA".equals(n.region)||Arrays.asList("KENYA","TANZANIA","RWANDA","SOUTH SUDAN","DR CONGO","BURUNDI").contains(n.region);
        if("WORLD".equals(f))return !localNewsMatches(n,"UGANDA",prefs)&&!localNewsMatches(n,"E.AFRICA",prefs);
        if("BREAKING".equals(f))return n.isBreaking;
        if("ENTERTAIN".equals(f))return "ENTERTAINMENT".equals(n.topic);
        if("COURTS".equals(f))return "CRIME & COURTS".equals(n.topic);
        if(Arrays.asList("BUSINESS","SPORTS","HEALTH","TECH","LUGANDA","POLITICS").contains(f))return f.equals(n.topic);
        return f.equals(NewsTopics.existingType(n));
    }

    private View buildLocalNewsCard(NewsItem n){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(9),dp(12),dp(9));card.setBackground(panelBackground(PANEL_ALT,LINE,12));card.setAlpha(n.isRead ? .62f : 1f);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setBackgroundColor(LINE);top.addView(image,new LinearLayout.LayoutParams(dp(88),dp(64)));
        LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);TextView h=text((n.isBreaking?"BREAKING • ":"")+n.title,n.isBreaking?RED:TEXT,13,true);h.setMaxLines(3);words.addView(h);
        TextView meta=text(n.sourceName+" • "+n.region+" • "+localNewsAge(n.publishedAt)+" • "+n.topic+("LG".equals(n.language)?" • LUGANDA":""),CYAN,9,true);words.addView(meta);top.addView(words,new LinearLayout.LayoutParams(0,-2,1));card.addView(top);
        if(new NewsPreferences(this).images()&&!n.imageUrl.isEmpty())NewsImageLoader.load(this,n.imageUrl,image);
        else image.setImageResource(R.drawable.ic_du_news);
        if(!n.summary.isEmpty()){TextView s=text(n.summary,MUTED,10,false);s.setMaxLines(3);card.addView(s);}
        if(!n.alsoReportedBy.isEmpty())card.addView(text("Also reported by: "+TextUtils.join(", ",n.alsoReportedBy),CYAN,9,false));
        card.setOnClickListener(v->showLocalNewsDetail(n));return card;
    }

    private void showLocalNewsDetail(NewsItem n){
        new NewsStore(this).markRead(n.id);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(14),dp(8),dp(14),dp(8));
        TextView h=text(n.title,TEXT,15,true);box.addView(h);box.addView(text((n.sourceName==null||n.sourceName.trim().isEmpty()?"SOURCE UNKNOWN":n.sourceName)+" • "+f16MissingLocation(n)+" • "+(n.publishedAt>0?localNewsAge(n.publishedAt):"TIME UNKNOWN")+" • "+(n.topic==null||n.topic.isEmpty()?"TOPIC UNKNOWN":n.topic),CYAN,9,true));
        ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);box.addView(image,new LinearLayout.LayoutParams(-1,dp(180)));if(new NewsPreferences(this).images()&&!n.imageUrl.isEmpty())NewsImageLoader.load(this,n.imageUrl,image);else image.setImageResource(R.drawable.ic_du_news);
        box.addView(text(n.summary.isEmpty()?"No summary supplied by this outlet.":n.summary,MUTED,11,false));
        if(!n.alsoReportedBy.isEmpty())box.addView(text("Also reported by: "+TextUtils.join(", ",n.alsoReportedBy),CYAN,9,false));
        addF14Related(box,n);
        String[] labels={"OPEN FULL ARTICLE","SHARE","MARK READ","HIDE THIS OUTLET","FOLLOW TOPIC","SHOW ON GLOBE"};
        for(String label:labels){Button b=actionButton(label,CYAN);GeoIndex.Point gp=GeoIndex.find(n.title+" "+n.summary+" "+n.region);if("SHOW ON GLOBE".equals(label))b.setEnabled(gp!=null);b.setOnClickListener(v->{NewsPreferences prefs=new NewsPreferences(this);if("OPEN FULL ARTICLE".equals(label)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(n.link)));}catch(Exception ignored){}}else if("SHARE".equals(label))startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,n.title+"\n"+n.link),"Share news"));else if("MARK READ".equals(label))new NewsStore(this).markRead(n.id);else if("HIDE THIS OUTLET".equals(label))prefs.source(n.sourceId,false);else if("FOLLOW TOPIC".equals(label))prefs.topic(n.topic,true);else if("SHOW ON GLOBE".equals(label)&&gp!=null){Signal s=NewsSignals.from(java.util.Collections.singletonList(n)).get(0);showDetail(s);}});box.addView(b,marginParams(0,4,0,0));}
        ScrollView sc=new ScrollView(this);sc.addView(box);new AlertDialog.Builder(this).setTitle("Local News").setView(sc).setNegativeButton("CLOSE",(d,w)->{f17RestoreState();rebuildLocalNewsPage();}).show();
    }

    private void syncLocalNewsSignals(List<NewsItem> items){
        List<Signal> s=NewsSignals.from(items);layerSignals.put(Signal.Layer.NEWS,s);FeedStatus st=new FeedStatus(FeedStatus.State.LIVE,s.size(),"Local News aggregator",System.currentTimeMillis());feedStatuses.put(Signal.Layer.NEWS,st);operationsEngine.accept(Signal.Layer.NEWS,s,st,System.currentTimeMillis());refreshOperationalStates();
    }

    private void refreshLocalNews(boolean force){
        NewsPreferences p=new NewsPreferences(this);if(!isNetworkConnectedForNews())return;if(!force&&System.currentTimeMillis()-p.time("last_refresh",0)<5L*60*1000)return;
        NewsAggregator a=new NewsAggregator(this);a.refresh((items,working)->runOnUiThread(()->{syncLocalNewsSignals(items);if("NEWS".equals(catalogCategory))rebuildLocalNewsPage();a.shutdown();}));
    }
    private boolean isNetworkConnectedForNews(){try{android.net.ConnectivityManager m=(android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);return m!=null&&m.getActiveNetwork()!=null;}catch(Exception e){return false;}}
    private String localNewsAge(long t){if(t<=0)return"never";long m=Math.max(0,(System.currentTimeMillis()-t)/60000);return m<1?"now":m<60?m+" min ago":m<1440?(m/60)+" h ago":(m/1440)+" d ago";}

    private void maybeAskNewsPermission(){
        NewsPreferences p=new NewsPreferences(this);NewsNotifier.channels(this);
        if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED&&!p.flag("asked",false)){
            new AlertDialog.Builder(this).setTitle("Local News").setMessage("Get alerts when big news breaks in Uganda").setPositiveButton("TURN ON NEWS ALERTS",(d,w)->{p.setFlag("asked",true);requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},3301);}).setNegativeButton("NOT NOW",(d,w)->p.setFlag("asked",true)).show();
        }
    }

    private void appendLocalNewsSettings(LinearLayout form){
        NewsPreferences p=new NewsPreferences(this);form.addView(text("LOCAL NEWS",TEXT,12,true),marginParams(0,14,0,4));
        form.addView(text("Outlets • topics • alerts",MUTED,9,false));
        String lastGroup="";
        for(NewsSource s:NewsSourceCatalog.ALL){String group=s.region.name()+" / "+s.category.name();if(!group.equals(lastGroup)){form.addView(text(group,MUTED,9,true),marginParams(0,8,0,2));lastGroup=group;}CheckBox x=new CheckBox(this);x.setText(s.name+" • "+p.status(s.id));x.setTextColor(TEXT);x.setChecked(p.source(s));x.setOnCheckedChangeListener((b,v)->p.source(s.id,v));form.addView(x);}
        for(String topic:new String[]{"POLITICS","BUSINESS","SPORTS","ENTERTAINMENT","HEALTH","TECH","CRIME & COURTS","WORLD","LUGANDA"}){CheckBox x=new CheckBox(this);x.setText("Follow "+topic);x.setTextColor(TEXT);x.setChecked(p.topic(topic));x.setOnCheckedChangeListener((b,v)->p.topic(topic,v));form.addView(x);}
        String[][] flags={{"alerts","News alerts"},{"breaking","Breaking alerts"},{"grouped","Grouped alerts"},{"digest","06:30 digest"},{"quiet","Quiet hours 22:00–06:00"},{"images","Load news images"}};
        for(String[]f:flags){CheckBox x=new CheckBox(this);x.setText(f[1]);x.setTextColor(TEXT);x.setChecked("images".equals(f[0])?p.images():p.flag(f[0],true));x.setOnCheckedChangeListener((b,v)->{if("images".equals(f[0]))p.images(v);else p.setFlag(f[0],v);});form.addView(x);}
        if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED){Button on=actionButton("TURN ON NEWS ALERTS",AMBER);on.setOnClickListener(v->requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},3301));form.addView(on);}
    }

    private void showSettings() {
        SecurePrefs secrets = repository == null
                ? new SecurePrefs(this) : repository.securePrefs();
        AppPreferences appPrefs = repository == null
                ? new AppPreferences(this) : repository.preferences();
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), dp(8), dp(18), dp(8));
        form.addView(text(safeMode
                ? "RECOVERY MODE • PROVIDER SETTINGS"
                : "OPTIONAL KEYED PROVIDERS", TEXT, 12, true));
        form.addView(text("Keyless weather, earthquakes, NASA events, GDELT DOC/GKG, market reference rates, public radio, safe public TV indexing, call/frequency references and anonymous OpenSky work immediately. Optional keys and direct stream settings are encrypted by Android Keystore on this device.",
                MUTED, 10, false), marginParams(0, 4, 0, 12));

        EditText ais = settingsField("AISStream API key", secrets.get(SecurePrefs.AIS_KEY), true);
        EditText windy = settingsField("Windy Webcams API key", secrets.get(SecurePrefs.WINDY_KEY), true);
        EditText openSkyId = settingsField("OpenSky OAuth client ID", secrets.get(SecurePrefs.OPENSKY_CLIENT_ID), false);
        EditText openSkySecret = settingsField("OpenSky OAuth client secret", secrets.get(SecurePrefs.OPENSKY_CLIENT_SECRET), true);
        EditText coinGecko = settingsField("CoinGecko Demo API key — optional", secrets.get(SecurePrefs.COINGECKO_KEY), true);
        EditText publicSafetyName = settingsField("Public-safety feed name — optional", secrets.get(SecurePrefs.PUBLIC_SAFETY_NAME), false);
        EditText publicSafetyStream = settingsField("Lawful direct HTTPS public-safety audio URL", secrets.get(SecurePrefs.PUBLIC_SAFETY_STREAM), false);
        EditText rss = settingsField("Additional HTTPS RSS URLs — one per line", appPrefs.customRss(), false);
        rss.setSingleLine(false);
        rss.setMinLines(3);
        rss.setGravity(Gravity.TOP);
        form.addView(ais, marginParams(0, 0, 0, 8));
        form.addView(windy, marginParams(0, 0, 0, 8));
        form.addView(openSkyId, marginParams(0, 0, 0, 8));
        form.addView(openSkySecret, marginParams(0, 0, 0, 8));
        form.addView(coinGecko, marginParams(0, 0, 0, 8));
        form.addView(publicSafetyName, marginParams(0, 0, 0, 8));
        form.addView(publicSafetyStream, marginParams(0, 0, 0, 8));
        form.addView(rss, marginParams(0, 0, 0, 8));
        appendLocalNewsSettings(form);
        form.addView(text("A Windy key enables the worldwide camera atlas. The provider tier exposes a limited listing window; DU World Monitor indexes permitted pages and never labels that window as every camera on Earth.",
                CYAN, 9, false), marginParams(0, 2, 0, 8));
        form.addView(text("AISStream recommends a server-side proxy for widely distributed apps. A personal key entered here remains local to this installed device and is not compiled into the APK.",
                AMBER, 9, false));
        form.addView(text("Public-safety audio must be a direct lawful HTTPS stream you are authorized to access. The app does not scrape directories, bypass authentication or decrypt protected communications.",
                AMBER, 9, false), marginParams(0, 8, 0, 0));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(form);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("DU World Monitor — Providers")
                .setView(scroll)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE & RECONNECT", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    try {
                        String requestedPublicAudio = publicSafetyStream.getText()
                                .toString().trim();
                        if (!requestedPublicAudio.isEmpty()
                                && !PublicMediaPolicy.isSafePublicHttpsUrl(
                                requestedPublicAudio)) {
                            publicSafetyStream.setError(
                                    PublicMediaPolicy.validationError(requestedPublicAudio));
                            publicSafetyStream.requestFocus();
                            return;
                        }
                        secrets.put(SecurePrefs.AIS_KEY, ais.getText().toString());
                        secrets.put(SecurePrefs.WINDY_KEY, windy.getText().toString());
                        secrets.put(SecurePrefs.OPENSKY_CLIENT_ID, openSkyId.getText().toString());
                        secrets.put(SecurePrefs.OPENSKY_CLIENT_SECRET, openSkySecret.getText().toString());
                        secrets.put(SecurePrefs.COINGECKO_KEY, coinGecko.getText().toString());
                        secrets.put(SecurePrefs.PUBLIC_SAFETY_NAME, publicSafetyName.getText().toString());
                        secrets.put(SecurePrefs.PUBLIC_SAFETY_STREAM, requestedPublicAudio);
                        appPrefs.setCustomRss(rss.getText().toString());
                        if (repository != null) repository.reloadCredentials();
                        dialog.dismiss();
                        Toast.makeText(this, repository == null
                                        ? "Settings saved. Restart the complete command deck to reconnect."
                                        : "Provider settings saved",
                                repository == null ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT).show();
                    } catch (Exception error) {
                        Toast.makeText(this, "Could not protect settings: " + error.getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                }));
        dialog.show();
    }

    private EditText settingsField(String hint, String value, boolean secret) {
        EditText field = new EditText(this);
        field.setHint(hint);
        field.setHintTextColor(MUTED);
        field.setTextColor(TEXT);
        field.setText(value);
        field.setTextSize(11);
        field.setSingleLine(true);
        field.setPadding(dp(10), dp(6), dp(10), dp(6));
        field.setBackground(panelBackground(PANEL_ALT, LINE, 12));
        if (secret) {
            field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        }
        return field;
    }

    private void handleSelectedSource() {
        if (selectedSignal != null && (selectedSignal.layer == Signal.Layer.FLIGHTS
                || selectedSignal.layer == Signal.Layer.SHIPS)) {
            if (mapView.isFollowing(selectedSignal.id)) {
                mapView.stopFollowing();
                sourceButton.setText("FOLLOW ON SATELLITE MAP");
                Toast.makeText(this, "Traffic follow stopped", Toast.LENGTH_SHORT).show();
            } else {
                followTraffic(selectedSignal);
                sourceButton.setText("STOP FOLLOWING");
            }
        } else if (selectedSignal != null && selectedSignal.layer == Signal.Layer.RADIO) {
            toggleRadio(selectedSignal);
        } else if (selectedSignal != null && selectedSignal.layer == Signal.Layer.TV) {
            launchNativeMedia(selectedSignal, NativeMediaActivity.KIND_VIDEO);
        } else if (selectedSignal != null && selectedSignal.layer == Signal.Layer.WEBCAMS) {
            launchNativeMedia(selectedSignal, NativeMediaActivity.KIND_IMAGE);
        } else if (selectedSignal != null && selectedSignal.layer == Signal.Layer.MEDIA) {
            if (selectedSignal.sourceUrl.startsWith("https://")
                    && "AUDIO".equalsIgnoreCase(selectedSignal.facts.get("MEDIA TYPE"))) {
                toggleRadio(selectedSignal);
            } else {
                Toast.makeText(this,
                        "Reference only — this provider does not expose a verified direct stream",
                        Toast.LENGTH_LONG).show();
            }
        } else {
            openExternal(selectedSourceUrl);
        }
    }

    private void toggleRadio(Signal signal) {
        if (signal.id.equals(playingRadioId) && radioPlayer != null) {
            stopRadio();
            Toast.makeText(this, "Public radio stopped", Toast.LENGTH_SHORT).show();
            return;
        }
        stopRadio();
        if (!PublicMediaPolicy.isSafePublicHttpsUrl(signal.sourceUrl)) {
            Toast.makeText(this, "This station does not offer a secure stream",
                    Toast.LENGTH_LONG).show();
            return;
        }
        try {
            MediaPlayer player = new MediaPlayer();
            if (repository != null) repository.recordRadioClick(signal.id);
            radioPlayer = player;
            playingRadioId = signal.id;
            sourceButton.setText("CONNECTING PUBLIC RADIO…");
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            player.setDataSource(signal.sourceUrl);
            player.setOnPreparedListener(ready -> {
                if (ready != radioPlayer) return;
                ready.start();
                if (selectedSignal != null && signal.id.equals(selectedSignal.id)) {
                    sourceButton.setText("STOP PUBLIC RADIO");
                }
                Toast.makeText(this, "Playing " + signal.title,
                        Toast.LENGTH_SHORT).show();
            });
            player.setOnCompletionListener(done -> stopRadio());
            player.setOnErrorListener((failed, what, extra) -> {
                if (failed == radioPlayer) {
                    stopRadio();
                    Toast.makeText(this, "Station stream is currently unavailable",
                            Toast.LENGTH_LONG).show();
                }
                return true;
            });
            player.prepareAsync();
        } catch (Exception error) {
            stopRadio();
            Toast.makeText(this, "Could not open this public station",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void stopRadio() {
        MediaPlayer player = radioPlayer;
        radioPlayer = null;
        playingRadioId = "";
        if (player != null) {
            try {
                player.reset();
            } catch (Exception ignored) {
                // The player may still be connecting.
            }
            try {
                player.release();
            } catch (RuntimeException ignored) {
                // Vendor media stacks can throw while an async prepare is being cancelled.
            }
        }
        if (sourceButton != null && selectedSignal != null
                && (selectedSignal.layer == Signal.Layer.RADIO
                || selectedSignal.layer == Signal.Layer.MEDIA)) {
            sourceButton.setText(selectedSignal.layer == Signal.Layer.MEDIA
                    ? "PLAY PUBLIC SAFETY AUDIO" : "PLAY PUBLIC RADIO");
        }
    }

    private void openExternal(String url) {
        if (!PublicMediaPolicy.isSafePublicHttpsUrl(url)) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (ActivityNotFoundException ignored) {
            Toast.makeText(this, "No browser available for this source", Toast.LENGTH_LONG).show();
        }
    }

    private void togglePanel(View panel) {
        panel.animate().cancel();
        if (panel.getVisibility() == View.VISIBLE) {
            panel.animate()
                    .alpha(0f)
                    .translationY(dp(14))
                    .setDuration(160L)
                    .withEndAction(() -> {
                        panel.setVisibility(View.GONE);
                        panel.setTranslationY(0f);
                    })
                    .start();
        } else {
            panel.setAlpha(0f);
            panel.setTranslationY(dp(14));
            panel.setVisibility(View.VISIBLE);
            if (panel == wirePanel) applyFilters();
            panel.animate().alpha(1f).translationY(0f).setDuration(180L).start();
        }
    }

    private TextView legendLine(String label, int color, String explanation) {
        TextView view = text("● " + label + "\n   " + explanation, color, 9, false);
        view.setPadding(0, dp(7), 0, 0);
        return view;
    }

    private Button compactButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(TEXT);
        button.setTextSize(9);
        button.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        button.setLetterSpacing(0.04f);
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(dp(4), 0, dp(4), 0);
        button.setBackground(pressableBackground(Color.argb(220, 14, 21, 29), LINE, 12));
        return button;
    }

    private Button headerButton(String label) {
        Button button = compactButton(label);
        button.setTextColor(MUTED);
        button.setBackground(pressableBackground(Color.argb(1, 8, 12, 17),
                Color.TRANSPARENT, 12));
        return button;
    }

    private Button actionButton(String label, int color) {
        Button button = compactButton(label);
        button.setTextColor(color);
        button.setBackground(pressableBackground(Color.argb(232, 14, 21, 29), color, 12));
        button.setMinHeight(dp(48));
        return button;
    }

    private TextView text(String value, int color, int sizeSp, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(color);
        view.setTextSize(sizeSp);
        view.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif",
                Typeface.NORMAL));
        view.setLineSpacing(0f, 1.08f);
        return view;
    }

    private GradientDrawable panelBackground(int fill, int stroke, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setStroke(dp(1), stroke);
        drawable.setCornerRadius(dp(Math.max(0, Math.min(24, radiusDp))));
        return drawable;
    }

    private RippleDrawable pressableBackground(int fill, int stroke, int radiusDp) {
        return new RippleDrawable(
                ColorStateList.valueOf(Color.argb(58, 112, 177, 201)),
                panelBackground(fill, stroke, radiusDp),
                panelBackground(Color.WHITE, Color.WHITE, radiusDp));
    }

    private LinearLayout.LayoutParams marginParams(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return params;
    }

    private FrameLayout.LayoutParams fullFrame() {
        return new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private int badgeColor(Signal.Credibility credibility) {
        switch (credibility) {
            case CONFIRMED: return GREEN;
            case REPORTED: return AMBER;
            case UNVERIFIED: return RED;
            case PUBLIC_SOURCE: return CYAN;
            case CALCULATED: return Color.rgb(174, 139, 224);
            case RAW_SIGNAL: default: return CYAN;
        }
    }

    /** Operational urgency is intentionally separate from corroboration/credibility. */
    private int signalChannel(Signal signal) {
        if (signal.severity >= 4
                && (signal.layer == Signal.Layer.NEWS
                || signal.layer == Signal.Layer.NATURAL
                || signal.layer == Signal.Layer.AIRSPACE
                || signal.layer == Signal.Layer.SPACE_WEATHER)) {
            return SignalBeaconView.RED;
        }
        if (signal.credibility == Signal.Credibility.UNVERIFIED
                || signal.credibility == Signal.Credibility.REPORTED) {
            return SignalBeaconView.AMBER;
        }
        return SignalBeaconView.GREEN;
    }

    private int signalStateColor(Signal signal) {
        int channel = signalChannel(signal);
        if (channel == SignalBeaconView.RED) return RED;
        if (channel == SignalBeaconView.AMBER) return AMBER;
        return GREEN;
    }

    private String signalStateText(Signal signal) {
        int channel = signalChannel(signal);
        if (channel == SignalBeaconView.RED) return "PRIORITY";
        if (channel == SignalBeaconView.AMBER) return "DEVELOPING";
        return "ONLINE";
    }

    private String badgeText(Signal signal) {
        switch (signal.credibility) {
            case CONFIRMED: return "CONFIRMED — OFFICIAL SOURCE";
            case CALCULATED: return "CALCULATED — PUBLIC ELEMENTS, NOT TELEMETRY";
            case REPORTED: return "REPORTED";
            case UNVERIFIED: return "UNVERIFIED — DEVELOPING";
            case PUBLIC_SOURCE: return "PUBLIC SOURCE — AVAILABILITY VARIES";
            case RAW_SIGNAL: default: return "RAW SIGNAL — LIVE TELEMETRY";
        }
    }

    private String shortBadge(Signal signal) {
        switch (signal.credibility) {
            case CONFIRMED: return "CONFIRMED";
            case CALCULATED: return "CALCULATED";
            case REPORTED: return "REPORTED";
            case UNVERIFIED: return "UNVERIFIED";
            case PUBLIC_SOURCE: return "PUBLIC SOURCE";
            case RAW_SIGNAL:
            default: return "RAW";
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static int compareNewestFirst(long first, long second) {
        return first == second ? 0 : first < second ? 1 : -1;
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (detailPanel != null && detailPanel.getVisibility() == View.VISIBLE) {
            detailPanel.setVisibility(View.GONE);
        } else if (catalogPanel != null && catalogPanel.getVisibility() == View.VISIBLE) {
            catalogPanel.setVisibility(View.GONE);
        } else if (replayPanel != null && replayPanel.getVisibility() == View.VISIBLE) {
            replayPanel.setVisibility(View.GONE);
        } else if (!wideLayout && wirePanel != null
                && wirePanel.getVisibility() == View.VISIBLE) {
            wirePanel.setVisibility(View.GONE);
        } else if (!wideLayout && layersPanel != null
                && layersPanel.getVisibility() == View.VISIBLE) {
            layersPanel.setVisibility(View.GONE);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!destroyed && mapView != null) applyFilters();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        startupHandler.removeCallbacksAndMessages(null);
        clockHandler.removeCallbacksAndMessages(null);
        activityHandler.removeCallbacksAndMessages(null);
        analysisExecutor.shutdownNow();
        stopRadio();
        if (repository != null) {
            try {
                repository.stop();
            } catch (RuntimeException error) {
                CrashLedger.recordRecovered(this, "MainActivity.repositoryStop", error);
            }
        }
        super.onDestroy();
    }
}
