#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
grep -F 'GLOBE-ONLY RULE — THE GLOBE IS THE APP' "$M" >/dev/null
grep -F 'addMissionAction(row,"GLOBE",view->showGlobeOverview())' "$M" >/dev/null
grep -F 'addMissionAction(row,"LAYERS",view->showGlobeOverview())' "$M" >/dev/null
grep -F 'addMissionAction(row,"SEARCH",view->showGlobeOverview())' "$M" >/dev/null
grep -F 'addMissionAction(row,"TIMELINE",view->toggleReplayPanel())' "$M" >/dev/null
grep -F 'addMissionAction(row,"SET",view->showSettings())' "$M" >/dev/null
! grep -F 'addMissionAction(row, "NEWS"' "$M"
! grep -F 'addMissionAction(row, "REGION"' "$M"
! grep -F 'addMissionAction(row, "REPLAY"' "$M"
! grep -F 'addMissionAction(row, "MONITORS"' "$M"
grep -F 'All systems now belong to the Globe' "$M" >/dev/null
# Underlying information engines are retained.
test -s "$P/app/src/main/java/com/sentongoharuna/worldsituationroom/NewsStore.java"
test -s "$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MonitorStore.java"
echo "GLOBE-ONLY PRIMARY UI CONTRACT PASS"
