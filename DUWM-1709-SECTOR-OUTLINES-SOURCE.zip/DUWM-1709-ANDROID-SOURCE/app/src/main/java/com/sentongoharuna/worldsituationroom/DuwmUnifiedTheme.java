package com.sentongoharuna.worldsituationroom;

/** 1708 Approved Midnight Navy: one original command center, one visual language across
 * every native page. Cosmetic values never modify source records or freshness.
 */
public final class DuwmUnifiedTheme {
    private DuwmUnifiedTheme() {}
    public static final int BACKGROUND = 0xFF050D22;
    public static final int PANEL = 0xFF08162E;
    public static final int PANEL_SELECTED = 0xFF122545;
    public static final int BORDER = 0xFF243E69;
    public static final int ACCENT = 0xFF558BDF;
    public static final int ACCENT_BRIGHT = 0xFF97BBF7;
    // Whole-screen backgrounds must be the approved navy, not cobalt panels.
    public static final int APPROVED_NAVY = 0xFF050D22;
    public static final int RAISED_CARD = 0xFF08162E;
    public static final int OVERLAY = 0xF2050D22;
    public static final int TEXT = 0xFFE4EDFE;
    public static final int MUTED = 0xFF90A6CD;
    public static final int UNAVAILABLE = 0xFF6C7F9C;
    // Limited status accents: always label the status; never portray synthetic data.
    public static final int LIVE = 0xFF67CBA6;
    public static final int WARNING = 0xFFDBAC64;
    public static final int DANGER = 0xFFDF777B;
}
