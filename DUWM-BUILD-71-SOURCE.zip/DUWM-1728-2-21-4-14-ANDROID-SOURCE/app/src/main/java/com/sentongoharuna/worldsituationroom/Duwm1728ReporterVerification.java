package com.sentongoharuna.worldsituationroom;

/** Truthful automatic reporter-profile status. A verified reporter profile is
 * separate from report credibility and never confirms the report itself. */
public final class Duwm1728ReporterVerification {
    public static final String VERIFIED="REPORTER ACCOUNT • VERIFIED";
    public static final String ACTIVE="REPORTER ACCOUNT • ACTIVE";
    public static final String PENDING="REPORTER ACCOUNT • VERIFICATION PENDING";
    public static final String UNVERIFIED="REPORTER ACCOUNT • UNVERIFIED";
    private Duwm1728ReporterVerification(){}
    public static String resolve(boolean profileVerified, boolean verificationPending, boolean activeReporter, String reporter){
        String identity=reporter==null?"":reporter.trim();
        if(identity.isEmpty()) return UNVERIFIED;
        if(profileVerified) return VERIFIED;
        if(verificationPending) return PENDING;
        if(activeReporter) return ACTIVE;
        return UNVERIFIED;
    }
    public static boolean isVerified(String value){return VERIFIED.equals(value);}
}
