package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.view.View;
import android.view.Window;

/** Build 32 shared command-deck chrome, applied to existing screens without replacing layouts. */
public final class DuwmPageMotion32 {
    private DuwmPageMotion32(){}
    public static void apply(Activity activity){
        if(activity==null)return;
        Window w=activity.getWindow();
        if(w==null)return;
        w.setStatusBarColor(Color.rgb(3,14,33));
        w.setNavigationBarColor(Color.rgb(3,14,33));
        View decor=w.getDecorView();
        int flags=decor.getSystemUiVisibility();
        flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if(Build.VERSION.SDK_INT>=26)flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        decor.setSystemUiVisibility(flags);
        if(Build.VERSION.SDK_INT>=29)w.setNavigationBarContrastEnforced(false);
        // Respect system-wide animation disable / reduced-motion preferences.
        try{
            float scale=android.provider.Settings.Global.getFloat(
                activity.getContentResolver(),
                android.provider.Settings.Global.TRANSITION_ANIMATION_SCALE,1f);
            if(scale>0f)activity.overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
        }catch(Exception ignored){}
    }
}
