package com.sentongoharuna.worldsituationroom;

import java.util.Locale;

/** /21.4/9 truthful ticker attribution: evidence source type + original recording time. */
public final class Duwm1728TickerAttribution {
    private Duwm1728TickerAttribution(){}
    private static String clean(String v,int maximum){
        if(v==null)return "";v=v.replaceAll("[\\p{Cntrl}]+"," " ).trim();
        if(v.length()<=maximum)return v;int end=maximum;if(end>0&&Character.isHighSurrogate(v.charAt(end-1)))end--;return v.substring(0,end);
    }
    private static String clock(long ms){
        long total=Math.max(0,ms)/1000,h=total/3600,m=(total%3600)/60,s=total%60;
        return h>0?String.format(Locale.ROOT,"%d:%02d:%02d",h,m,s):String.format(Locale.ROOT,"%02d:%02d",m,s);
    }
    public static String source(String raw){
        String s=clean(raw,40).toUpperCase(Locale.ROOT).trim();
        if(s.isEmpty())return "REPORTER ENTRY";
        if(s.equals("RECORDED_SPEECH")||s.equals("RECORDED SPEECH"))return "RECORDED SPEECH";
        if(s.equals("CAPTURE_NOTES")||s.equals("CAPTURE NOTES"))return "CAPTURE NOTES";
        if(s.equals("AI SCENE")||s.equals("AI_SCENE"))return "AI SCENE";
        if(s.equals("REPORTER ENTRY")||s.equals("MANUAL"))return "REPORTER ENTRY";
        return s;
    }
    public static String decorate(String source,long originalMs,String text){
        String body=clean(text,500);if(body.isEmpty())return "";
        return source(source)+"  •  "+clock(Math.max(0,originalMs))+"  |  "+body;
    }
}
