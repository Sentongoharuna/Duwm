package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.net.Uri;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import android.location.Geocoder;
import android.location.Address;
import java.util.List;
import java.net.HttpURLConnection;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

/**
 * Live place maps with actual OSM-derived terrain/roads, source positions and observed traces.
 * Atmospheric light is decorative; no inferred vehicle routes, ship detections or traffic.
 * No new Android home-screen widgets and no replacement of the original globe.
 */
public final class DuwmPlaceMapActivity extends Activity {
  private static final int BG=Color.rgb(5, 13, 34), PANEL=Color.rgb(13, 31, 61), TEXT=Color.rgb(221, 234, 254);
  private static final int MUTED=Color.rgb(76, 120, 196), CYAN=Color.rgb(76, 120, 196);
  private static final long REFRESH_MS=110000L;
  private final Handler main=new Handler(Looper.getMainLooper());
  private final HashMap<String,JSONObject> reports=new HashMap<>();
  private final HashMap<String,JSONObject> prior=new HashMap<>();
  private final ArrayList<JSONObject> traces=new ArrayList<>();
  private WebView web;
  private TextView receipt,focusDetail,share,cityStatus;
  private LinearLayout modes;
  private volatile boolean busy=false,started=false,webReady=false;
  private volatile boolean mapEngineReady=false;
  private final Runnable mapProbe=new Runnable(){@Override public void run(){if(!started||web==null)return;checkMapRuntime();main.postDelayed(this,12000L);}};
  private String mode="CITY",place="Kampala — starting view",selectedId="";
  private double centerLat=.3476,centerLon=32.5825;
  private long updated=0,lastSearch=0;
  private final String[] kinds={"CITY","AIR","SEA","QUAKE","SAT","WEATHER","NEWS"};
  private final Runnable ticker=new Runnable(){@Override public void run(){if(!started)return;fetchNow();main.postDelayed(this,REFRESH_MS);}};

  private int dp(float v){return (int)(getResources().getDisplayMetrics().density*v+.5f);}
  private TextView label(String text,int size,int color){TextView t=new TextView(this);t.setText(text);t.setTextSize(size);t.setTextColor(color);t.setPadding(dp(9),dp(7),dp(9),dp(7));return t;}
  private void panel(View v){GradientDrawable d=new GradientDrawable();d.setColor(PANEL);d.setCornerRadius(dp(7));d.setStroke(dp(1),Color.rgb(40, 76, 135));v.setBackground(d);}
  private LinearLayout strip(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
  private String jsonString(String s){return JSONObject.quote(s==null?"":s);}
  private void js(String expr){if(webReady&&web!=null)web.evaluateJavascript(expr,null);}

  @Override public void onCreate(Bundle b){super.onCreate(b);
        DuwmPageMotion32.apply(this); DuwmPageMotion33.configure(this, "PLACE MAP · locations"); // Build 32: consistent full-page navy chrome and transition

    getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    // 1166 geographic intelligence launches as a genuinely full-screen map surface.
    getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,
                         android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
    root.setPadding(dp(8),dp(3),dp(8),dp(4));setContentView(root);
    root.setFitsSystemWindows(true);
    if(android.os.Build.VERSION.SDK_INT >= 30){
      root.setOnApplyWindowInsetsListener((v,insets)->{
        android.graphics.Insets bars=insets.getInsets(android.view.WindowInsets.Type.statusBars()|android.view.WindowInsets.Type.navigationBars());
        root.setPadding(dp(8),bars.top+dp(3),dp(8),bars.bottom+dp(4));
        return insets;
      });
    }
    LinearLayout title=strip();
    TextView back=label("‹",27,CYAN);title.addView(back,new LinearLayout.LayoutParams(dp(38),-2));back.setOnClickListener(v->finish());
    TextView heading=label("DEVELOP.UGANDA  /  PLACE INTELLIGENCE",14,TEXT);heading.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
    title.addView(heading,new LinearLayout.LayoutParams(0,-2,1));root.addView(title,new LinearLayout.LayoutParams(-1,-2));
    TextView intel=label("WORLD INTELLIGENCE  /  9 SOURCE CHANNELS",11,CYAN);intel.setGravity(Gravity.CENTER);panel(intel);
    LinearLayout.LayoutParams intelParams=new LinearLayout.LayoutParams(-1,dp(32));intelParams.bottomMargin=dp(5);root.addView(intel,intelParams);
    intel.setOnClickListener(v->startActivity(new Intent(this,DuwmWorldIntelligenceActivity.class)));
    intel.setVisibility(View.GONE); // map-first; worldwide source dashboard remains reachable from the directory
    cityStatus=label("KAMPALA   •   SOURCE MAP  /  NOT LIVE TRAFFIC",10,MUTED);cityStatus.setSingleLine(true);cityStatus.setEllipsize(android.text.TextUtils.TruncateAt.END);
    LinearLayout mapStatusRow=strip();mapStatusRow.addView(cityStatus,new LinearLayout.LayoutParams(0,dp(30),1));
    DuwmSignalRail embeddedSignals=DuwmSignalRail.embedded(this);
    LinearLayout.LayoutParams sigp=new LinearLayout.LayoutParams(dp(106),dp(24));sigp.rightMargin=dp(3);
    mapStatusRow.addView(embeddedSignals,sigp);root.addView(mapStatusRow);
    LinearLayout loc=strip();EditText search=new EditText(this);search.setSingleLine(true);search.setTextSize(13);search.setTextColor(TEXT);
    search.setHintTextColor(MUTED);search.setHint("Search any city or place");search.setPadding(dp(9),0,dp(5),0);
    panel(search);loc.addView(search,new LinearLayout.LayoutParams(0,dp(39),1));
    TextView go=label("LOCATE",11,CYAN);go.setGravity(Gravity.CENTER);panel(go);
    LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(dp(79),dp(39));gp.leftMargin=dp(6);loc.addView(go,gp);
    go.setOnClickListener(v->{String name=search.getText().toString().trim();if(name.length()>1)geocode(name);});
    root.addView(loc,new LinearLayout.LayoutParams(-1,dp(43)));
    HorizontalScrollView scroller=new HorizontalScrollView(this);scroller.setHorizontalScrollBarEnabled(false);
    modes=strip();scroller.addView(modes,new HorizontalScrollView.LayoutParams(-2,dp(37)));
    root.addView(scroller,new LinearLayout.LayoutParams(-1,dp(39)));drawModes();
    FrameLayout frame=new FrameLayout(this);panel(frame);
    LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,0,1);fp.topMargin=dp(4);root.addView(frame,fp);
    web=new WebView(this);web.setBackgroundColor(BG);web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(false);
    web.getSettings().setLoadsImagesAutomatically(true);
    web.getSettings().setBlockNetworkImage(false);
    web.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    web.getSettings().setUserAgentString(web.getSettings().getUserAgentString()+" DEVELOP.UGANDA/1166 (+https://github.com/Sentongoharuna/Duwm)");
    web.setWebChromeClient(new android.webkit.WebChromeClient(){
      @Override public boolean onConsoleMessage(android.webkit.ConsoleMessage message){
        if(message.messageLevel()==android.webkit.ConsoleMessage.MessageLevel.ERROR){
          android.util.Log.w("DUWM-MAP-JS",message.message()+" @ "+message.lineNumber());
        }
        return true;
      }
    });
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest r){return intercept(r.getUrl());}
      @Override public boolean shouldOverrideUrlLoading(WebView view,String url){return intercept(Uri.parse(url));}
      @Override public void onPageFinished(WebView view,String url){webReady=true;
        checkMapRuntime();
        js("window.duwmFocus("+centerLat+","+centerLon+",11,"+jsonString(place)+");");
        applyMode();sendPoints();}
    });
    frame.addView(web,new FrameLayout.LayoutParams(-1,-1));
    try(java.io.InputStream in=getAssets().open("duwm_place_map.html");
        ByteArrayOutputStream out=new ByteArrayOutputStream()){
      byte[] buffer=new byte[8192];int n;
      while((n=in.read(buffer))!=-1){
        if(out.size()+n>1000000)throw new java.io.IOException("Map asset unexpectedly large");
        out.write(buffer,0,n);
      }
      // Use the Android app-assets HTTPS origin; never impersonate the tile provider.
      // HTTPS OSM tile requests remain network-dependent and are not claimed as offline streets.
      web.loadDataWithBaseURL("https://appassets.androidplatform.net/assets/",
         out.toString("UTF-8"),"text/html","UTF-8",null);
    }catch(Exception ex){android.util.Log.e("DUWM-MAP", "Map HTML asset failed",ex);
      cityStatus.setText("MAP SOURCE UNAVAILABLE — ASSET ERROR");}
    receipt=label("Real OpenStreetMap geometry • provider observations only • tiles require internet.",10,MUTED);root.addView(receipt);
    focusDetail=label("SELECT A VERIFIED MAP RECORD TO VIEW DETAILS AND SHARE",12,TEXT);panel(focusDetail);
    LinearLayout.LayoutParams d=new LinearLayout.LayoutParams(-1,-2);d.topMargin=dp(4);root.addView(focusDetail,d);
    share=label("SHARE SELECTED VERIFIED DATA POINT",12,CYAN);share.setGravity(Gravity.CENTER);panel(share);
    root.addView(share,new LinearLayout.LayoutParams(-1,dp(32)));
    share.setVisibility(View.GONE); // selected record opens detail/share bottom-sheet when tapped
    share.setOnClickListener(v->shareSelected());focusDetail.setOnClickListener(v->shareSelected());
    String lat=getIntent().getStringExtra("focus_lat"),lon=getIntent().getStringExtra("focus_lon");
    if(lat!=null&&lon!=null){try{focus(Double.parseDouble(lat),Double.parseDouble(lon),10.7,"Selected observed location");}catch(Exception ignored){}}
  }
  /** Checks the renderer's real tile/record state, rather than calling the screen LIVE from a timer. */
  private void checkMapRuntime(){
    if(web==null||!webReady)return;
    web.evaluateJavascript("JSON.stringify(window.duwmRenderStatus ? window.duwmRenderStatus() : {engine:'MISSING'})", result->{
      if(web==null||!started)return;
      try{
        // Android wraps evaluateJavascript string results as JSON strings.
        String payload=result==null?"":result;
        Object decoded=new org.json.JSONTokener(payload).nextValue();
        JSONObject status=decoded instanceof String ? new JSONObject((String)decoded):new JSONObject(payload);
        String engine=status.optString("engine","MISSING");
        mapEngineReady="NATIVE_OSM_CANVAS".equals(engine);
        if(!mapEngineReady){cityStatus.setText("MAP RENDERER NOT INITIALIZED — RETRY");return;}
        int tiles=status.optInt("tileLoadSuccess",0), errors=status.optInt("tileLoadErrors",0);
        if(tiles>0)cityStatus.setText("STREET MAP READY  •  "+tiles+" REAL TILES");
        else if(errors>0)cityStatus.setText("MAP TILE SERVER UNAVAILABLE  •  RETRY OR CHECK INTERNET");
        else cityStatus.setText("MAP RENDERER READY  •  FETCHING REAL STREETS");
      }catch(Exception ex){
        cityStatus.setText("MAP RENDERER STATUS UNAVAILABLE");
        android.util.Log.w("DUWM-MAP","Render status unavailable",ex);
      }
    });
  }
  private String formatSourceTime(long millis){
    java.text.SimpleDateFormat format=new java.text.SimpleDateFormat("dd MMM yyyy HH:mm 'UTC'",java.util.Locale.US);
    format.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));return format.format(new java.util.Date(millis));
  }
  private boolean intercept(Uri uri){if(!"duwm".equalsIgnoreCase(uri.getScheme()))return false;
    if("select".equals(uri.getHost())){
      String id=uri.getQueryParameter("id");if(id!=null){selectedId=id;JSONObject p=reports.get(id);
        if(p!=null){long measured=p.optLong("time",0);
          String when=measured<=0?"SOURCE TIME UNAVAILABLE":formatSourceTime(measured);
          focusDetail.setText(p.optString("kind")+"  •  "+p.optString("title")+"\n"+p.optString("detail")+"\nSOURCE  "+p.optString("source")+"  •  "+when+"\nTap SHARE to send this record");}}
    }return true;}
  private void drawModes(){modes.removeAllViews();for(String kind:kinds){TextView t=label(kind,10,kind.equals(mode)?Color.rgb(225, 237, 255):MUTED);t.setGravity(Gravity.CENTER);
    GradientDrawable bg=new GradientDrawable();bg.setColor(kind.equals(mode)?Color.rgb(34, 67, 121):PANEL);bg.setCornerRadius(dp(5));
    bg.setStroke(dp(1),kind.equals(mode)?CYAN:Color.rgb(40, 76, 135));t.setBackground(bg);
    LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(kind.equals("WEATHER")?79:kind.equals("CITY")?59:67),dp(32));p.rightMargin=dp(5);modes.addView(t,p);
    t.setOnClickListener(v->{mode=kind;drawModes();applyMode();sendPoints();showSummary();});}}
  private void applyMode(){js("window.duwmMode("+jsonString(mode)+");");}
  private void focus(double lat,double lon,double zoom,String name){if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>85||Math.abs(lon)>180)return;
    centerLat=lat;centerLon=lon;place=name;cityStatus.setText(place.toUpperCase(Locale.US)+"   •   MAP TILES ARE NOT REAL-TIME TRAFFIC");
    js("window.duwmFocus("+lat+","+lon+","+zoom+","+jsonString(name)+");");fetchNow();}
  /** User-triggered place lookup through Android system Geocoder (not a public bulk-search API). */
  private void geocode(String query){
    long now=System.currentTimeMillis();if(now-lastSearch<1500L){Toast.makeText(this,"One search at a time",Toast.LENGTH_SHORT).show();return;}
    lastSearch=now;cityStatus.setText("LOOKING UP REQUESTED PLACE / DEVICE GEOCODER");
    new Thread(()->{try{
      Geocoder geocoder=new Geocoder(this,Locale.US);
      java.util.List<Address> addresses=geocoder.getFromLocationName(query,1);
      if(addresses==null||addresses.isEmpty())throw new Exception("No matching place or geocoder unavailable");
      Address a=addresses.get(0);double la=a.getLatitude(),lo=a.getLongitude();
      if(!Double.isFinite(la)||!Double.isFinite(lo)||Math.abs(la)>85||Math.abs(lo)>180)throw new Exception("No usable coordinates");
      runOnUiThread(()->focus(la,lo,11.8,query));
    }catch(Exception e){runOnUiThread(()->cityStatus.setText("PLACE LOOKUP UNAVAILABLE / "+String.valueOf(e.getMessage())));}}
      ,"DUWM-user-place-search").start();
  }
  @Override public void onStart(){super.onStart();started=true;main.post(ticker);main.postDelayed(mapProbe,1500L);}
  @Override public void onStop(){started=false;main.removeCallbacks(ticker);main.removeCallbacks(mapProbe);super.onStop();}
  @Override public void onDestroy(){main.removeCallbacks(mapProbe);if(web!=null){web.stopLoading();web.destroy();web=null;}super.onDestroy();}
  private String get(String url,int max)throws Exception{
    HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(9000);c.setReadTimeout(10000);
    c.setRequestProperty("User-Agent","DEVELOP.UGANDA/1162 (+https://github.com/Sentongoharuna/Duwm)");c.setRequestProperty("Accept","application/json");
    try{if(c.getResponseCode()!=200)throw new java.io.IOException("HTTP "+c.getResponseCode());
      try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
        byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){if(out.size()+n>max)throw new java.io.IOException("Provider response too large");out.write(buf,0,n);}return out.toString("UTF-8");}
    }finally{c.disconnect();}}
  private void fetchNow(){if(busy||!started)return;busy=true;final double lat=centerLat,lon=centerLon;
    new Thread(()->{HashMap<String,JSONObject> incoming=new HashMap<>();StringBuilder state=new StringBuilder("SOURCE STATUS  •  ");
      // All geographic markers are from source coordinates; no inferred movement or route geometry.
      try{String url="https://opensky-network.org/api/states/all?lamin="+Math.max(-85,lat-2)+"&lomin="+Math.max(-180,lon-2)+"&lamax="+Math.min(85,lat+2)+"&lomax="+Math.min(180,lon+2);
        JSONArray arr=new JSONObject(get(url,2500000)).getJSONArray("states");int count=0;
        for(int i=0;i<arr.length()&&count<250;i++){JSONArray s=arr.optJSONArray(i);if(s==null||s.length()<11||s.isNull(5)||s.isNull(6))continue;
          double x=s.optDouble(5,Double.NaN),y=s.optDouble(6,Double.NaN);if(!Double.isFinite(x)||!Double.isFinite(y))continue;
          String id=s.optString(0,"").trim();if(id.isEmpty())continue;long stamp=s.optLong(4,0)*1000L;
          String details="ICAO24 "+id+" • Altitude "+(s.isNull(7)?"unreported":s.optString(7)+" m")+" • Groundspeed "+(s.isNull(9)?"unreported":s.optString(9)+" m/s");
          put(incoming,"AIR:"+id,"AIRCRAFT",s.optString(1,id).trim(),details,"OpenSky Network","https://opensky-network.org/",stamp,y,x);count++;}
        state.append("AIR ").append(count).append("  /  ");
      }catch(Exception ex){state.append("AIR UNAVAILABLE  /  ");}
      try{JSONArray arr=new JSONObject(get("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson",1200000)).getJSONArray("features");int n=0;
        for(int i=0;i<arr.length()&&i<140;i++){JSONObject f=arr.getJSONObject(i),prop=f.getJSONObject("properties");JSONArray geo=f.getJSONObject("geometry").getJSONArray("coordinates");
          if(geo.length()<2)continue;String id=f.optString("id","");if(id.isEmpty())continue;
          put(incoming,"QUAKE:"+id,"EARTHQUAKE",prop.optString("title","USGS event"),"Magnitude "+prop.optString("mag","unknown")+" • "+prop.optString("place","unreported"),
              "USGS Earthquake Hazards Program",prop.optString("url",""),prop.optLong("time",0),geo.getDouble(1),geo.getDouble(0));n++;}
        state.append("QUAKE ").append(n).append("  /  ");
      }catch(Exception ex){state.append("QUAKE UNAVAILABLE  /  ");}
      try{JSONObject f=new JSONObject(get("https://api.wheretheiss.at/v1/satellites/25544",100000));
        if(f.has("latitude")&&f.has("longitude")){put(incoming,"ISS:25544","ISS","International Space Station","Altitude "+f.optString("altitude","unknown")+" km",
             "Where The ISS At","https://api.wheretheiss.at/v1/satellites/25544",f.optLong("timestamp",0)*1000L,f.getDouble("latitude"),f.getDouble("longitude"));
          state.append("ISS RECEIVED  /  ");}else state.append("ISS UNAVAILABLE  /  ");
      }catch(Exception ex){state.append("ISS UNAVAILABLE  /  ");}
      try{String url="https://api.open-meteo.com/v1/forecast?latitude="+lat+"&longitude="+lon+"&current=temperature_2m,precipitation,weather_code&timezone=UTC";
        JSONObject f=new JSONObject(get(url,100000)).getJSONObject("current");String t=f.optString("time","");long stamp=0;
        try{SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm",Locale.US);df.setTimeZone(TimeZone.getTimeZone("UTC"));stamp=df.parse(t).getTime();}catch(Exception ignored){}
        String desc="Modelled at selected coordinates · Temp "+f.optString("temperature_2m","unknown")+" °C • Rain "+f.optString("precipitation","unknown")+" mm";
        put(incoming,"WEATHER:"+lat+":"+lon,"WEATHER","Model weather · "+place,desc,"Open-Meteo model forecast","https://open-meteo.com/",stamp,lat,lon);
        state.append("WEATHER MODEL RECEIVED  /  ");
      }catch(Exception ex){state.append("WEATHER UNAVAILABLE  /  ");}
      state.append("SEA: NO AIS FEED CONFIGURED");long now=System.currentTimeMillis();
      runOnUiThread(()->{if(!started){busy=false;return;}
        for(JSONObject p:incoming.values()){
          String id=p.optString("id");JSONObject old=prior.get(id);
          if(old==null)continue;long from=old.optLong("time"),to=p.optLong("time");
          double a=old.optDouble("lat",Double.NaN),b=old.optDouble("lon",Double.NaN),c=p.optDouble("lat",Double.NaN),d=p.optDouble("lon",Double.NaN);
          if(from<=0||to<=from||to-from>900000||!Double.isFinite(a)||!Double.isFinite(b)||!Double.isFinite(c)||!Double.isFinite(d))continue;
          if(Math.abs(a-c)+Math.abs(b-d)<.00005)continue;
          if(!p.optString("kind").equals("AIRCRAFT")&&!p.optString("kind").equals("ISS"))continue;
          JSONObject tr=new JSONObject();try{tr.put("id",id);tr.put("kind",p.optString("kind"));tr.put("lat1",a);tr.put("lon1",b);tr.put("lat2",c);tr.put("lon2",d);tr.put("from",from);tr.put("to",to);}catch(Exception ignored){}
          traces.add(tr);
        }
        while(traces.size()>100)traces.remove(0);for(int i=traces.size()-1;i>=0;i--)if(now-traces.get(i).optLong("to")>900000)traces.remove(i);
        prior.clear();prior.putAll(incoming);reports.clear();reports.putAll(incoming);updated=now;
        if(!reports.containsKey(selectedId))selectedId="";
        receipt.setText(state.toString()+"\nLAST ATTEMPT "+new Date(now)+" · Traces require TWO verified position reports");
        busy=false;sendPoints();showSummary();
      });
    },"DUWM-place-source-refresh").start();
  }
  private static void put(HashMap<String,JSONObject> to,String id,String kind,String title,String detail,String source,String url,long stamp,double lat,double lon){
    if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)return;
    try{JSONObject p=new JSONObject();p.put("id",id);p.put("kind",kind);p.put("title",title);p.put("detail",detail);p.put("source",source);p.put("url",url);p.put("time",stamp);p.put("lat",lat);p.put("lon",lon);to.put(id,p);}catch(Exception ignored){}
  }
  /** Merge only fresh actual provider coordinates from the worldwide dashboard. */
  private java.util.List<DuwmGeoObservationStore.Fix> mergeWorldwidePositions(){
    java.util.List<DuwmGeoObservationStore.Fix> actual=DuwmGeoObservationStore.read(this);
    long now=System.currentTimeMillis();
    for(DuwmGeoObservationStore.Fix f:actual){
      if(f.sourceTime<=0||now-f.sourceTime>3600000L||now-f.receivedAt>3600000L)continue;
      if(!f.type.equals("AIRCRAFT")&&!f.type.equals("EARTHQUAKE")&&!f.type.equals("ISS"))continue;
      if(!reports.containsKey(f.id))put(reports,f.id,f.type,f.title,f.detail,f.provider,f.url,f.sourceTime,f.lat,f.lon);
    }
    return actual;
  }
  private void sendPoints(){java.util.List<DuwmGeoObservationStore.Fix> worldwide=mergeWorldwidePositions();
    JSONArray array=new JSONArray(),lines=new JSONArray();for(JSONObject p:reports.values())array.put(p);for(JSONObject t:traces)lines.put(t);
    long now=System.currentTimeMillis();for(DuwmGeoObservationStore.Fix f:worldwide){
      if(!f.hasActualTrack()||now-f.receivedAt>900000L)continue;
      JSONObject tr=new JSONObject();try{tr.put("id",f.id);tr.put("kind",f.type);tr.put("lat1",f.oldLat);tr.put("lon1",f.oldLon);
        tr.put("lat2",f.lat);tr.put("lon2",f.lon);tr.put("from",f.oldTime);tr.put("to",f.sourceTime);lines.put(tr);
      }catch(Exception ignored){}
    }

    JSONObject payload=new JSONObject();try{payload.put("points",array);payload.put("traces",lines);payload.put("received",updated);}catch(Exception ignored){}
    js("window.duwmReceive("+payload.toString()+");");
  }
  private void showSummary(){if(!selectedId.isEmpty()&&reports.containsKey(selectedId))return;
    focusDetail.setText("MAP STATUS  /  "+reports.size()+" VERIFIED POSITIONS IN CURRENT SOURCE CYCLE. Tap a real marker to inspect and share its data.");
  }
  private void shareSelected(){JSONObject p=reports.get(selectedId);
    if(p==null){Toast.makeText(this,"Select a real map record first",Toast.LENGTH_SHORT).show();return;}
    long sourceTime=p.optLong("time",0);
    V115941ShareCards.share(this,p.optString("kind"),p.optString("title"),p.optString("detail"),p.optString("source"),sourceTime,
        p.optDouble("lat"),p.optDouble("lon"),p.optString("url"),null);
  }
}
