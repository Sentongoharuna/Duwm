package com.sentongoharuna.worldsituationroom;

import java.util.Locale;

/** Compact truthful state shown in the former top-right test/clock card. */
public final class Duwm1728ProductionStatus {
    private Duwm1728ProductionStatus(){}

    public static String elapsed(long sourceMs){
        long total=Math.max(0,sourceMs)/1000L;
        long h=total/3600L,m=(total%3600L)/60L,s=total%60L;
        return String.format(Locale.US,"%02d:%02d:%02d",h,m,s);
    }
    public static String text(Duwm1728BroadcastLayout.Report r,long ms){
        String mode=r.productionRecording?"REC":r.productionLive?"LIVE":"VIEW";
        long source=r.measuredSourceMs>=0?r.measuredSourceMs:Math.max(0,ms);
        String gps=r.gpsLocked?"GPS LOCK":"GPS —";
        String ai=(r.aiStatus==null||r.aiStatus.trim().isEmpty())?"AI WAIT":r.aiStatus.trim().toUpperCase(Locale.ROOT);
        if(ai.length()>14)ai=ai.substring(0,14).trim();
        return mode+" • "+elapsed(source)+" • "+gps+" • "+ai;
    }
}
