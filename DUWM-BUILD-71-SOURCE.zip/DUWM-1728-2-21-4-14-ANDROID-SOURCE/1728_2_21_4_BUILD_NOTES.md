# DUWM 1728.2/21/4 — Automatic Finishing / Export

This build continues from the repaired 1728.2/21/3 clear-picture source.

## Visible/functional change

After a fresh camera recording, DUWM can continue the existing automatic edit flow through final export without requiring a manual approval step. The automatic export is only marked VIDEO READY after the durable content URI can actually be reopened. A completed local MP4 is retained when Gallery confirmation is unavailable, and automatic production no longer interrupts the hands-free path with a recovery dialog.

## Retained behavior

- Original single DUWM app and command-center UI.
- Dark navy visual system and original globe.
- On-device scene descriptions when supported.
- Real source-time scene timeline and measured telemetry.
- Clear-picture layout with the center of the source image reserved.
- Original source audio is remuxed, not regenerated.
- No server-address, API-key, or cloud-AI form is required for the automatic camera flow.

## Native verification

The required native stages increase from 19 to 20 with `automatic_finish`. This stage checks the finalization state policy and reopens a real test-owned MediaStore content URI. It does not claim a physical-camera, provider-network, or model-inference test.
