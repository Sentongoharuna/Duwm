DUWM 1728.2/21.4/27 - 20+ source changes

1. Deeper navy ocean colour
2. Extended pinch zoom range
3. Extended adjustable rotation speed
4. Slower minimum rotation speed
5. Longer touch pause before auto rotation
6. Smoother auto-rotation acceleration
7. Frame delta clamp to reduce animation jumps
8. Reduce observation interpolation latency
9. Synchronize trails with position interpolation
10. More legible movement trail dash pattern
11. More fluid moving trail phase
12. Higher contrast real movement trails
13. Less distracting location pulse cadence
14. Larger animated location pulse range
15. More dynamic radar rotation
16. Brighter radar sector
17. Distinct deep-navy globe palettes
18. Brighter coastline outlines
19. Sharper illuminated coastlines
20. More visible atmospheric edge
21. Gentler outer beacon orbit
22. More visible orbit beacons
23. Brighter outer orbit frame
24. Improved secondary orbital contrast
25. Refresh full-screen preview after app regains focus
26. Refresh full-screen crop when camera resumes

Not verified on device or as a compiled APK. Live vessel and aircraft coverage depends on providers.
