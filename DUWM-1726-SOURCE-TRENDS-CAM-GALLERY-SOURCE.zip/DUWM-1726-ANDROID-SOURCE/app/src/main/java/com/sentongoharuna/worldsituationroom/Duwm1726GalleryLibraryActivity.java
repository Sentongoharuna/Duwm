package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** User-visible list of this installation's successful Gallery exports, not an artificial feed. */
public final class Duwm1726GalleryLibraryActivity extends Activity {
    private int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);}
    private TextView label(String value,int size){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size);
        t.setTextColor(DuwmUnifiedTheme.TEXT);t.setGravity(Gravity.CENTER_VERTICAL);
        t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        t.setPadding(dp(14),dp(10),dp(14),dp(10));return t;
    }
    @Override public void onCreate(Bundle b){super.onCreate(b);
        getWindow().setStatusBarColor(DuwmUnifiedTheme.APPROVED_NAVY);
        getWindow().setNavigationBarColor(DuwmUnifiedTheme.APPROVED_NAVY);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(DuwmUnifiedTheme.APPROVED_NAVY);root.setPadding(dp(10),dp(7),dp(10),dp(7));
        root.addView(label("MONITORS CAM  /  MY GALLERY RECORDINGS",17));
        root.addView(label("Completed MP4 exports from this installation • Movies / DUWM Monitors Cam",11));
        ScrollView scroll=new ScrollView(this);LinearLayout cards=new LinearLayout(this);cards.setOrientation(LinearLayout.VERTICAL);
        java.util.List<String[]> recordings=Duwm1726GalleryIndex.list(this);
        if(recordings.isEmpty())cards.addView(label("No Gallery exports recorded on this installation. Record a video in MONITORS CAM to add one.",13));
        for(String[] record:recordings){
            final Uri uri=Uri.parse(record[0]);
            TextView item=label("▶  "+record[1]+"\nSaved on this device • Tap to play",13);
            GradientDrawable shape=new GradientDrawable();shape.setColor(DuwmUnifiedTheme.APPROVED_NAVY);
            shape.setStroke(dp(1),DuwmUnifiedTheme.BORDER);shape.setCornerRadius(dp(16));item.setBackground(shape);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(5),0,dp(7));cards.addView(item,p);
            item.setOnClickListener(v->{
                try{Intent play=new Intent(Intent.ACTION_VIEW);play.setDataAndType(uri,"video/mp4");
                    play.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(play);
                }catch(Exception e){new android.app.AlertDialog.Builder(this).setTitle("Gallery video unavailable")
                    .setMessage("The Gallery entry may have been moved or deleted. No recording was replaced.")
                    .setPositiveButton("OK",null).show();}
            });
        }
        scroll.addView(cards);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));
        TextView back=label("BACK TO MONITORS CAM",13);back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v->finish());root.addView(back,new LinearLayout.LayoutParams(-1,dp(51)));
        setContentView(root);
    }
}
