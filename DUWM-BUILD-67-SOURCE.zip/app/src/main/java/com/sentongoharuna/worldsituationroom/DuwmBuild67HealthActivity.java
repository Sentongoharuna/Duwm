package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.text.DateFormat;
import java.util.Date;

/** Build 67: real device and app readiness checks; never fabricates LIVE status. */
public final class DuwmBuild67HealthActivity extends Activity {
    private LinearLayout content;
    private int pass, warn;
    private TextView summary;
    private int navy = Color.rgb(5, 15, 39), cyan = Color.rgb(56, 204, 232);
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(navy);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(navy);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(24, 24, 24, 32);
        scroll.addView(content);
        setContentView(scroll);
        TextView title = label("BUILD 67  /  SYSTEM READINESS", 22, cyan);
        content.addView(title);
        summary = label("", 15, Color.WHITE);
        content.addView(summary);
        Button refresh = new Button(this);
        refresh.setText("RECHECK DEVICE & APP");
        refresh.setTextColor(Color.WHITE);
        refresh.setBackgroundColor(Color.rgb(17, 58, 91));
        content.addView(refresh);
        refresh.setOnClickListener(v -> runChecks());
        runChecks();
    }
    private TextView label(String value, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(sp); t.setTextColor(color);
        t.setPadding(12, 12, 12, 12);
        return t;
    }
    private void check(String title, boolean good, String detail) {
        if (good) pass++; else warn++;
        TextView t = label((good ? "● READY   " : "● CHECK   ") + title + "\n" + detail, 14,
                good ? Color.rgb(105, 233, 168) : Color.rgb(255, 191, 86));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(9, 29, 58)); bg.setCornerRadius(14);
        bg.setStroke(1, good ? Color.rgb(28, 118, 99) : Color.rgb(138, 88, 33));
        t.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 5, 0, 5); content.addView(t, lp);
    }
    private boolean permission(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }
    private void runChecks() {
        while (content.getChildCount() > 3) content.removeViewAt(3);
        pass = 0; warn = 0;
        ConnectivityManager cm = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        NetworkCapabilities caps = cm == null ? null : cm.getNetworkCapabilities(cm.getActiveNetwork());
        boolean connected = caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        boolean validated = caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
        check("Network transport", connected, connected ? "Internet-capable network detected" : "Connect Wi-Fi or mobile data");
        check("Validated internet", validated, validated ? "Android reports internet validation" : "Network may have no internet access");
        check("Camera permission", permission("android.permission.CAMERA"), "Required for MONITORS CAM recording");
        check("Microphone permission", permission("android.permission.RECORD_AUDIO"), "Required for video sound");
        check("Fine location", permission("android.permission.ACCESS_FINE_LOCATION"), "Optional: precise telemetry with permission");
        check("Coarse location", permission("android.permission.ACCESS_COARSE_LOCATION"), "Optional: approximate location telemetry");
        check("Notifications", Build.VERSION.SDK_INT < 33 || permission("android.permission.POST_NOTIFICATIONS"), "Required for notification alerts on Android 13+");
        File files = getFilesDir();
        check("App storage", files != null && files.canWrite(), "Private app files writable");
        File cache = getCacheDir();
        check("Cache storage", cache != null && cache.canWrite(), "Temporary media and feed cache writable");
        long free = files == null ? 0 : files.getUsableSpace();
        check("Free disk space", free > 250L * 1024L * 1024L, (free / (1024L * 1024L)) + " MB available; 250 MB recommended");
        check("Camera hardware", getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY), "Physical camera required for capture");
        check("Microphone hardware", getPackageManager().hasSystemFeature(PackageManager.FEATURE_MICROPHONE), "Physical microphone required for audio capture");
        check("Android API", Build.VERSION.SDK_INT >= 26, "Device API " + Build.VERSION.SDK_INT + "; minimum 26");
        check("App identity", getPackageName().contains("worldsituationroom"), getPackageName());
        check("Secure network policy", getApplicationInfo().flags != 0, "App installed; network endpoints must still be verified independently");
        summary.setText("LOCAL READINESS  " + pass + " READY  /  " + warn + " NEED ATTENTION\nChecked " + DateFormat.getDateTimeInstance().format(new Date()) + "\nThese are device checks, not claims of live external feed availability.");
    }
}
