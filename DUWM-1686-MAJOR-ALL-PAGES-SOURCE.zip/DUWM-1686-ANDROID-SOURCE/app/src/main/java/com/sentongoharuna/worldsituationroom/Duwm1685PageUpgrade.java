package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** R1685: a substantial source-aware command console on all nineteen EXISTING native desks.
 * Original globe, native maps and player widgets remain owned by their existing Activity.
 * Every number displayed is read from a real provider receipt or explicitly marked local tool.
 */
public final class Duwm1685PageUpgrade {
    private static final String TAG="duwm-1685-intelligence-console";
    private static final String LIVE="duwm-1685-receipt-live";
    private Duwm1685PageUpgrade(){}
    private static final java.util.WeakHashMap<Activity,Duwm1683DeskCatalog.Desk> selectedModes=new java.util.WeakHashMap<>();
    /** The legacy multi-sector selector can change its data category while Activity stays open. */
    public static void onSectorChanged(Activity a,String selected){
        if(a==null||selected==null)return;
        int index;
        switch(selected){
            case "AIRCRAFT":index=0;break;
            case "VESSELS":index=1;break;
            case "EARTHQUAKES":index=2;break;
            case "WEATHER":index=3;break;
            case "SATELLITES":index=4;break;
            case "NEWS":index=7;break;
            case "RADIO":index=9;break;
            case "TV STATIONS":index=10;break;
            case "PUBLIC CAMERAS":index=11;break;
            case "MARKETS":index=13;break;
            default:return;
        }
        Duwm1683DeskCatalog.Desk d=Duwm1683DeskCatalog.ALL[index];
        selectedModes.put(a,d);
        FrameLayout content=a.findViewById(android.R.id.content);
        if(content==null)return;
        View old=content.findViewWithTag(TAG);
        if(old!=null && old.getParent() instanceof LinearLayout){
            LinearLayout parent=(LinearLayout)old.getParent();
            int location=parent.indexOfChild(old);
            ViewGroup.LayoutParams dimensions=old.getLayoutParams();
            parent.removeView(old);
            parent.addView(stage(a,d),location,dimensions);
        }
        Duwm1685ReceiptHistory.capture(a,d);
        refreshVisible(a,d);
    }
    private static int dp(Activity a,float v){return Math.round(a.getResources().getDisplayMetrics().density*v);}
    public static void install(Application app){
        app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks(){
            @Override public void onActivityCreated(Activity a,Bundle b){}
            @Override public void onActivityStarted(Activity a){}
            @Override public void onActivityResumed(Activity a){
                a.getWindow().getDecorView().post(()->{
                    if(a.isFinishing()||a.isDestroyed())return;
                    Duwm1683DeskCatalog.Desk d=selectedModes.containsKey(a)?selectedModes.get(a):Duwm1683DeskCatalog.find(a);
                    if(d==null)return;
                    Duwm1685ReceiptHistory.capture(a,d);
                    enhance(a,d);
                    refreshVisible(a,d);
                });
            }
            @Override public void onActivityPaused(Activity a){}
            @Override public void onActivityStopped(Activity a){}
            @Override public void onActivitySaveInstanceState(Activity a,Bundle b){}
            @Override public void onActivityDestroyed(Activity a){selectedModes.remove(a);}
        });
    }
    private static GradientDrawable surface(Activity a,boolean selected){
        GradientDrawable d=new GradientDrawable();
        d.setColor(selected?DuwmUnifiedTheme.PANEL_SELECTED:DuwmUnifiedTheme.PANEL);
        d.setCornerRadius(dp(a,10));d.setStroke(dp(a,1),selected?DuwmUnifiedTheme.ACCENT:DuwmUnifiedTheme.BORDER);
        return d;
    }
    private static TextView label(Activity a,String s,int size,int color,boolean bold){
        TextView v=new TextView(a);v.setText(s);v.setTextColor(color);v.setTextSize(size);
        v.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",Typeface.NORMAL));
        v.setGravity(Gravity.CENTER_VERTICAL);return v;
    }
    private static TextView button(Activity a,String s,Runnable action){
        TextView b=label(a,s,11,DuwmUnifiedTheme.ACCENT_BRIGHT,true);
        b.setGravity(Gravity.CENTER);b.setBackground(surface(a,true));b.setOnClickListener(v->action.run());
        b.setContentDescription(s);return b;
    }
    private static void appendButton(Activity a,LinearLayout bar,String s,Runnable action){
        TextView v=button(a,s,action);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(a,45),1);
        p.rightMargin=dp(a,5);bar.addView(v,p);
    }
    private static String focus(Duwm1683DeskCatalog.Desk d){
        String m=Duwm1684SectorVisual.mode(d.title);
        switch(m){
            case "AVIATION":return "AIRCRAFT FIXES / CALLSIGNS / ALTITUDE";
            case "MARITIME":return "REGIONAL AIS / MMSI / COURSE";
            case "SEISMIC":return "USGS EVENTS / DEPTH / MAGNITUDE";
            case "WEATHER":return "FORECAST GRID / WIND / TEMPERATURE";
            case "SPACE":return "SATELLITES / NASA / OBSERVATION TIME";
            case "NEWSROOM":return "PUBLISHER / STORY TIME / MEDIA";
            case "RADIO":return "RADIO STREAM / STATION / COUNTRY";
            case "TELEVISION":return "CHANNEL / PLAYBACK / SOURCE";
            case "CAMERAS":return "PUBLIC CAMERA / FRAMES / LOCATION";
            case "MARKETS":return "REFERENCE FX / ISSUED TIME / PAIRS";
            case "GEOGRAPHY":return "MAPPED SOURCES / COORDINATES / PLACES";
            case "SOURCE HEALTH":return "SUCCESS / FAILURE / LAST RECEIPT";
            case "EVIDENCE":return "ORIGINAL RECORD / TIME / COMPARISON";
            default:return d.subtitle.toUpperCase(java.util.Locale.US);
        }
    }
    private static View stage(Activity a,Duwm1683DeskCatalog.Desk d){
        View panel=Duwm1686Console.page(a,d);
        panel.setTag(TAG);
        return panel;
    }
    private static void refreshVisible(Activity a,Duwm1683DeskCatalog.Desk d){
        FrameLayout root=a.findViewById(android.R.id.content);
        if(root==null)return;
        Duwm1684DeskDiagnostics.Snapshot s=Duwm1684DeskDiagnostics.read(a,d);
        View v=root.findViewWithTag(LIVE);
        if(v instanceof TextView)((TextView)v).setText("PROVIDER / "+s.state+"\nVALUE / "+s.count);
        View t=root.findViewWithTag(LIVE+"-time");
        if(t instanceof TextView)((TextView)t).setText("RECEIPT\n"+s.received);
    }
    private static void enhance(Activity a,Duwm1683DeskCatalog.Desk d){
        FrameLayout content=a.findViewById(android.R.id.content);
        if(content==null||content.getChildCount()==0||content.findViewWithTag(TAG)!=null)return;
        a.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        View base=content.getChildAt(0);
        LinearLayout list=null;
        if(base instanceof ScrollView){
            ScrollView scroll=(ScrollView)base;
            if(scroll.getChildCount()>0 && scroll.getChildAt(0) instanceof LinearLayout)list=(LinearLayout)scroll.getChildAt(0);
        }else if(base instanceof LinearLayout && !(a instanceof MediaDeskActivity))list=(LinearLayout)base;
        if(list!=null&&list.getOrientation()==LinearLayout.VERTICAL){
            View panel=stage(a,d);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
            lp.leftMargin=dp(a,8);lp.rightMargin=dp(a,8);lp.topMargin=dp(a,6);lp.bottomMargin=dp(a,14);
            list.addView(panel,0,lp);
        }else{
            // Map/camera/video first screens retain the original full canvas and player.
            // This compact panel opens the full 1686 workspace and can be hidden at once.
            LinearLayout overlay=(LinearLayout)Duwm1686Console.compact(a,d);
            overlay.setTag(TAG);
            overlay.setElevation(dp(a,8));
            LinearLayout row=new LinearLayout(a);
            overlay.addView(row,new LinearLayout.LayoutParams(-1,dp(a,45)));
            appendButton(a,row,"DETAILS",()->Duwm1686WorkspaceActivity.open(a,d));
            appendButton(a,row,"SHARE",()->Duwm1686ShareCard.share(a,d));
            appendButton(a,row,"HIDE",()->overlay.setVisibility(View.GONE));
            FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(-1,-2,Gravity.TOP);
            p.leftMargin=dp(a,12);p.rightMargin=dp(a,12);p.topMargin=dp(a,12);
            content.addView(overlay,p);
            TextView restore=button(a,"1686 / WORKSPACE ›",()->overlay.setVisibility(View.VISIBLE));
            FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(-2,dp(a,42),Gravity.RIGHT|Gravity.TOP);
            rp.rightMargin=dp(a,10);rp.topMargin=dp(a,178);content.addView(restore,rp);
        }
        View previous=content.findViewWithTag("duwm1683-detail-chip");
        if(previous!=null)previous.setVisibility(View.GONE);
    }
}
