package com.sentongoharuna.worldsituationroom;

import android.app.Instrumentation;
import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityNodeInfo;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import org.json.JSONArray;
import org.json.JSONObject;

/** Test-APK-only evidence. A stage cannot inherit a pass or a file from another APK/run. */
final class DuwmNativeEvidence {
    static final String[] STAGES={"signals","graphics","exports4","framing","inset1","review","editor_controls","review_controls","recovery","composition","caption_editing","caption_files","automatic_production"};
    static final class EnvironmentObstruction extends AssertionError {
        EnvironmentObstruction(String message){super(message);}
    }
    private final Instrumentation runner;
    private final File root;
    private final String runId,appHash,testHash;
    private final JSONObject identity;
    private File stageDir,proofDir;
    private String stage="",lastPhase="";
    private long startedMs,startedElapsed;

    DuwmNativeEvidence(Instrumentation runner,String requestedRunId)throws Exception {
        this.runner=runner;
        runId=requestedRunId==null||requestedRunId.isEmpty()?"native-"+System.currentTimeMillis():requestedRunId;
        if(!runId.matches("[A-Za-z0-9][A-Za-z0-9._-]{0,95}"))throw new IllegalArgumentException("run_id must use 1–96 letters, numbers, dots, underscores or hyphens");
        root=new File(runner.getTargetContext().getFilesDir(),"native-stage-proof");
        if(!root.isDirectory()&&!root.mkdirs())throw new IOException("Cannot create native stage evidence");
        appHash=hash(new File(runner.getTargetContext().getApplicationInfo().sourceDir));
        testHash=hash(new File(runner.getContext().getApplicationInfo().sourceDir));
        PackageInfo app=runner.getTargetContext().getPackageManager().getPackageInfo(runner.getTargetContext().getPackageName(),0);
        identity=new JSONObject().put("schema",1).put("run_id",runId)
            .put("application_id",runner.getTargetContext().getPackageName())
            .put("app_apk_sha256",appHash).put("test_apk_sha256",testHash)
            .put("version_name",app.versionName).put("version_code",android.os.Build.VERSION.SDK_INT>=28?app.getLongVersionCode():app.versionCode)
            .put("sdk",android.os.Build.VERSION.SDK_INT).put("device_fingerprint",android.os.Build.FINGERPRINT)
            .put("physical_camera_verified",false);
    }
    String runId(){return runId;}
    File directory(){return proofDir;}
    void start(String name)throws Exception {
        if(!Arrays.asList(STAGES).contains(name))throw new IllegalArgumentException("Unknown native stage: "+name);
        stage=name;stageDir=new File(root,name);remove(stageDir);
        proofDir=new File(stageDir,"evidence");if(!proofDir.mkdirs())throw new IOException("Cannot create evidence for "+stage);
        startedMs=System.currentTimeMillis();startedElapsed=SystemClock.elapsedRealtime();lastPhase="start";
        writeResult("RUNNING",0,null);
        phase("start");
    }
    void phase(String name) {
        lastPhase=name;
        String marker="DUWM_NATIVE_STAGE_PHASE stage="+stage+" run_id="+runId+" phase="+name;
        try(FileOutputStream out=new FileOutputStream(new File(stageDir,"PHASES.txt"),true)) {
            out.write((System.currentTimeMillis()+" "+(SystemClock.elapsedRealtime()-startedElapsed)+"ms "+marker+"\n").getBytes(StandardCharsets.UTF_8));
        }catch(IOException error){throw new IllegalStateException("Could not save native phase",error);}
        status(marker);
    }
    void finish(int checks,Throwable failure)throws Exception {
        String status=failure==null?"PASS":"FAIL";
        writeResult(status,checks,failure);
        String marker="DUWM_NATIVE_STAGE_"+status+" stage="+stage+" run_id="+runId+" checks="+checks;
        if(failure!=null)marker+=" failure_kind="+failureKind(failure)+" phase="+lastPhase;
        status(marker);
    }
    private void status(String text){Bundle progress=new Bundle();progress.putString("stream",text+"\n");runner.sendStatus(0,progress);}
    private void writeResult(String status,int checks,Throwable failure)throws Exception {
        JSONObject result=new JSONObject(identity.toString()).put("stage",stage).put("status",status)
            .put("checks",checks).put("started_at_ms",startedMs).put("finished_at_ms",status.equals("RUNNING")?JSONObject.NULL:System.currentTimeMillis())
            .put("elapsed_ms",SystemClock.elapsedRealtime()-startedElapsed).put("last_phase",lastPhase);
        JSONArray evidence=new JSONArray();List<File> files=new ArrayList<>();collect(proofDir,files);
        for(File file:files)evidence.put(new JSONObject().put("path","evidence/"+file.getName()).put("bytes",file.length()).put("sha256",hash(file)));
        result.put("evidence",evidence);
        if(failure!=null)result.put("failure_kind",failureKind(failure)).put("failure",android.util.Log.getStackTraceString(failure));
        File temporary=new File(stageDir,"RESULT.json.tmp");
        try(FileOutputStream out=new FileOutputStream(temporary)){out.write((result.toString(2)+"\n").getBytes(StandardCharsets.UTF_8));out.getFD().sync();}
        File destination=new File(stageDir,"RESULT.json");if(!temporary.renameTo(destination))throw new IOException("Cannot commit stage result");
    }
    private static String failureKind(Throwable error){
        for(Throwable cause=error;cause!=null;cause=cause.getCause())if(cause instanceof EnvironmentObstruction)return "environment_overlay";
        return error instanceof AssertionError?"assertion":"runtime_error";
    }

    /** Snapshot an obstructing dialog for diagnosis; never dismiss it or permit a pixel check to pass through it. */
    void assertUnobstructed(String label)throws Exception {
        StringBuilder tree=new StringBuilder();AccessibilityNodeInfo active=runner.getUiAutomation().getRootInActiveWindow();
        if(active==null)tree.append("No accessibility root available\n");
        else try{dump(active,tree,0,new int[]{0});}finally{active.recycle();}
        try(FileOutputStream out=new FileOutputStream(new File(proofDir,label+"-UI.txt"))){out.write(tree.toString().getBytes(StandardCharsets.UTF_8));}
        String visible=tree.toString().toLowerCase(Locale.ROOT).replace('\u2019','\'');
        if(visible.contains("system ui isn't responding")||visible.contains("system ui is not responding")||visible.contains("system ui not responding"))
            throw new EnvironmentObstruction("System UI ANR dialog obstructs "+label+"; screenshot and UI tree retained, stage remains failed");
        if(visible.contains("pixel launcher isn't responding")||visible.contains("pixel launcher is not responding")||visible.contains("pixel launcher not responding"))
            throw new EnvironmentObstruction("Pixel Launcher ANR dialog obstructs "+label+"; screenshot and UI tree retained, stage remains failed");
    }
    private static void dump(AccessibilityNodeInfo node,StringBuilder out,int depth,int[] count){
        if(depth>24||count[0]++>=500)return;
        for(int i=0;i<depth;i++)out.append(' ');
        out.append(node.getPackageName()).append(' ').append(node.getClassName()).append(" id=").append(node.getViewIdResourceName())
            .append(" text=").append(node.getText()).append(" description=").append(node.getContentDescription()).append('\n');
        for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo child=node.getChild(i);if(child!=null)try{dump(child,out,depth+1,count);}finally{child.recycle();}}
    }

    /** Reuse is optional and only from a completed same-run stage with both installed APK identities and file digest matching. */
    boolean reuse(String fromStage,String basename,File destination)throws Exception {
        if(!Arrays.asList(STAGES).contains(fromStage)||!basename.matches("[A-Za-z0-9._-]+"))throw new IllegalArgumentException("Invalid evidence input");
        File previous=new File(root,fromStage),manifest=new File(previous,"RESULT.json");if(!manifest.isFile())return false;
        JSONObject result;
        try(InputStream in=new FileInputStream(manifest)){result=new JSONObject(read(in));}
        if(!"PASS".equals(result.optString("status"))||!runId.equals(result.optString("run_id"))||!appHash.equals(result.optString("app_apk_sha256"))||!testHash.equals(result.optString("test_apk_sha256")))return false;
        JSONArray evidence=result.optJSONArray("evidence");if(evidence==null)return false;
        for(int i=0;i<evidence.length();i++){
            JSONObject item=evidence.getJSONObject(i);if(!("evidence/"+basename).equals(item.optString("path")))continue;
            File source=new File(previous,item.getString("path"));
            if(!source.isFile()||source.length()!=item.getLong("bytes")||!hash(source).equals(item.getString("sha256")))return false;
            try(InputStream in=new FileInputStream(source);OutputStream out=new FileOutputStream(destination)){byte[] block=new byte[65536];int n;while((n=in.read(block))!=-1)out.write(block,0,n);}
            phase("fixture.reused."+fromStage);return true;
        }
        return false;
    }
    private static String read(InputStream input)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=input.read(b))!=-1)out.write(b,0,n);return out.toString("UTF-8");}
    private static void collect(File directory,List<File> files){File[] entries=directory.listFiles();if(entries==null)return;Arrays.sort(entries,Comparator.comparing(File::getName));for(File file:entries)if(file.isFile())files.add(file);}
    private static void remove(File file)throws IOException{if(!file.exists())return;if(file.isDirectory()){File[] children=file.listFiles();if(children==null)throw new IOException("Cannot inspect old stage evidence");for(File child:children)remove(child);}if(!file.delete())throw new IOException("Cannot clear old stage evidence");}
    static String hash(File file)throws Exception{MessageDigest digest=MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(file)){byte[] block=new byte[65536];int n;while((n=in.read(block))!=-1)digest.update(block,0,n);}StringBuilder value=new StringBuilder();for(byte b:digest.digest())value.append(String.format(Locale.ROOT,"%02x",b&255));return value.toString();}
}
