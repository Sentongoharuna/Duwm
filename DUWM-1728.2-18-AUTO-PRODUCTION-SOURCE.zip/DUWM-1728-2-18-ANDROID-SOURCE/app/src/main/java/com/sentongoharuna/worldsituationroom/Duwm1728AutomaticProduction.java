package com.sentongoharuna.worldsituationroom;

import java.util.Collections;
import java.util.List;

/** Built-in editing policy. Speech recognition is separate and may be unavailable. */
public final class Duwm1728AutomaticProduction {
    public static final String PREFS="duwm_automatic_production";
    public static final long SPEECH_CHUNK_MS=45000;
    private Duwm1728AutomaticProduction() {}

    public static boolean shouldStart(boolean freshCapture,boolean enabled,boolean attempted,
                                      boolean savedOutput,boolean existingDraft,boolean unavailable) {
        return freshCapture&&enabled&&!attempted&&!savedOutput&&!existingDraft&&!unavailable;
    }
    public static String receiptKey(String sourceKey) {
        if(sourceKey==null||sourceKey.isEmpty())throw new IllegalArgumentException("Recording identity is missing");
        return "attempt_"+sourceKey;
    }
    public static long chunkEnd(long start,long duration) {
        if(start<0||duration<=start)throw new IllegalArgumentException("Invalid speech range");
        return duration-start>SPEECH_CHUNK_MS?start+SPEECH_CHUNK_MS:duration;
    }
    public static final class Plan {
        public final long fromMs,toMs;
        public final String title,description,ratio,frameMode,composition,provenance,captionStatus;
        public final List<Duwm1728BroadcastLayout.Cue> cues;
        private Plan(long duration,List<Duwm1728BroadcastLayout.Cue> captions,String status) {
            fromMs=0;toMs=duration;ratio="ORIGINAL";frameMode=Duwm1728FramePlan.FIT;
            composition=Duwm1728BroadcastComposition.COMPACT;
            title="RECORDED REPORT";
            cues=Collections.unmodifiableList(Duwm1728CaptionEditPolicy.copyAndValidate(captions,duration));
            captionStatus=status==null?"":status;
            provenance=cues.isEmpty()?"AUTO-EDITED • UNVERIFIED":"AUTO-CAPTIONS • UNREVIEWED";
            description=cues.isEmpty()?"Automatically formatted recording. Original soundtrack retained."
                    :"Automatically formatted recording with on-device speech captions. Caption end times are derived.";
        }
    }
    /** Full source and original aspect retain visual context; no events, places or speech are invented. */
    public static Plan plan(long duration,List<Duwm1728BroadcastLayout.Cue> captions,String status) {
        if(duration<1||duration>Integer.MAX_VALUE)throw new IllegalArgumentException("Unsupported recording duration");
        if(captions==null)throw new IllegalArgumentException("Captions are missing");
        return new Plan(duration,captions,status);
    }
}
