package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.Intent;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.speech.RecognitionListener;
import android.speech.RecognitionSupport;
import android.speech.RecognitionSupportCallback;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** Optional on-device transcription of decoded source audio. Exact-intent support
 * and segmented file-session callbacks are required. Ordinary microphone-style
 * results are never accepted. These API checks cannot audit a recognizer service's
 * implementation; unavailable or indeterminate support fails closed.
 */
public final class Duwm1728RecordedAudioTranscriber {
    public interface Listener {void done(Result result);void error(String message);}
    public static final class Result {
        public final String text,timedCaptions,timingKind,timingNote;
        /** Compatibility name: validated REPORTED starts, not independently verified speech or measured ends. */
        public final boolean hasVerifiedWordTimes;
        public final List<Duwm1728BroadcastLayout.Cue> cues;
        Result(String text,List<Duwm1728BroadcastLayout.Cue> cues,String note,long fromMs){
            this.text=text;this.cues=Collections.unmodifiableList(new ArrayList<>(cues));
            hasVerifiedWordTimes=!cues.isEmpty();timingKind=hasVerifiedWordTimes?Duwm1728SpeechCues.REPORTED_STARTS_DERIVED_ENDS:Duwm1728SpeechCues.TEXT_ONLY_UNTIMED;
            timingNote=note;timedCaptions=hasVerifiedWordTimes?Duwm1728SpeechCues.legacy(cues,fromMs):"";
        }
    }
    private final Context context;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final AtomicBoolean started=new AtomicBoolean(),finished=new AtomicBoolean();
    private final Object audioLock=new Object();
    private SpeechRecognizer recognizer;
    private ParcelFileDescriptor readPipe,writePipe;
    private OutputStream activeWriteStream;
    private volatile Thread decodeThread;
    private Listener callbacks;
    private long fromMs,toMs;
    private boolean supportConfirmed,recognitionStarted,segmentedEnded,audioComplete,timingUsable=true;
    private int segments;
    private String timingProblem="Word timestamps were not supplied";
    private final StringBuilder transcript=new StringBuilder();
    private final ArrayList<Duwm1728SpeechCues.Word> words=new ArrayList<>();
    private final Runnable supportTimeout=()->fail("On-device service did not confirm recorded-file support within 5 seconds");
    private final Runnable recognitionTimeout=()->fail("On-device service did not complete a confirmed recorded-file session in time");

    public Duwm1728RecordedAudioTranscriber(Context context){this.context=context.getApplicationContext();}
    public static boolean canAttempt(Context context){
        if(Build.VERSION.SDK_INT<33)return false;
        try{return SpeechRecognizer.isOnDeviceRecognitionAvailable(context);}catch(RuntimeException unavailable){return false;}
    }
    public void transcribe(Uri video,long fromMs,long toMs,Listener listener){
        if(Looper.myLooper()!=Looper.getMainLooper())throw new IllegalStateException("Start transcription on the UI thread");
        if(listener==null)throw new IllegalArgumentException("A transcription listener is required");
        if(!started.compareAndSet(false,true)||finished.get()){listener.error("This transcription request is already finished or in use");return;}
        callbacks=listener;this.fromMs=fromMs;this.toMs=toMs;
        if(!canAttempt(context)){fail("On-device recorded-audio recognition is unavailable on this phone");return;}
        if(video==null||fromMs<0||toMs<=fromMs||toMs-fromMs>Duwm1728PcmTimeline.MAX_DURATION_MS||toMs>Long.MAX_VALUE/1000){fail("Select an audio range of at most 45 seconds");return;}
        try {
            ParcelFileDescriptor[] pipes=ParcelFileDescriptor.createPipe();
            synchronized(audioLock){readPipe=pipes[0];writePipe=pipes[1];}
            recognizer=SpeechRecognizer.createOnDeviceSpeechRecognizer(context);
            recognizer.setRecognitionListener(recognitionListener());
            final String language=Locale.getDefault().toLanguageTag();
            final Intent request=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE,language)
                    .putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE,readPipe)
                    .putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT,1)
                    .putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING,AudioFormat.ENCODING_PCM_16BIT)
                    .putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE,Duwm1728PcmTimeline.OUTPUT_RATE)
                    .putExtra(RecognizerIntent.EXTRA_SEGMENTED_SESSION,RecognizerIntent.EXTRA_AUDIO_SOURCE)
                    .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true);
            if(Build.VERSION.SDK_INT>=34)request.putExtra(RecognizerIntent.EXTRA_REQUEST_WORD_TIMING,true);
            main.postDelayed(supportTimeout,5000);
            // The same unmodified Intent, including PCM descriptor and segmented
            // mode, is checked before startListening. No model download is requested.
            recognizer.checkRecognitionSupport(request,command->main.post(command),new RecognitionSupportCallback(){
                @Override public void onSupportResult(RecognitionSupport support){
                    if(finished.get()||recognitionStarted)return;
                    if(!installedLanguage(support,language)){fail("The requested offline speech language is not confirmed installed");return;}
                    supportConfirmed=true;main.removeCallbacks(supportTimeout);
                    try {
                        recognitionStarted=true;recognizer.startListening(request);
                        main.postDelayed(recognitionTimeout,Math.min(55000,Math.max(10000,toMs-fromMs+10000)));
                        startAudio(video);
                    }catch(Exception unavailable){fail("Cannot start the confirmed recorded-file session: "+message(unavailable));}
                }
                @Override public void onError(int error){fail("Recorded-file recognition support is unavailable or indeterminate ("+error+")");}
            });
        }catch(Exception unavailable){fail("Cannot check recorded-file recognition: "+message(unavailable));}
    }
    private static boolean installedLanguage(RecognitionSupport support,String requested){
        if(support==null)return false;String normalized=requested.replace('_','-');
        String primary=Locale.forLanguageTag(normalized).getLanguage();
        for(String installed:support.getInstalledOnDeviceLanguages())if(installed!=null){String tag=installed.replace('_','-');
            if(tag.equalsIgnoreCase(normalized)||tag.equalsIgnoreCase(primary))return true;}
        return false;
    }
    private RecognitionListener recognitionListener(){return new RecognitionListener(){
        @Override public void onReadyForSpeech(Bundle parameters){}
        @Override public void onBeginningOfSpeech(){}
        @Override public void onRmsChanged(float value){}
        @Override public void onBufferReceived(byte[] buffer){}
        @Override public void onEndOfSpeech(){}
        @Override public void onPartialResults(Bundle results){}
        @Override public void onEvent(int type,Bundle parameters){}
        @Override public void onResults(Bundle ordinary){
            // Some segmented services also send this callback. It is neither a
            // success signal nor an immediate failure; wait for the file-session end.
        }
        @Override public void onSegmentResults(Bundle results){acceptSegment(results);}
        @Override public void onEndOfSegmentedSession(){if(finished.get())return;segmentedEnded=true;finishIfComplete();}
        @Override public void onError(int error){fail("Recorded-file recognition failed (service error "+error+")");}
    };}
    private void acceptSegment(Bundle bundle){
        if(finished.get())return;
        if(!supportConfirmed||!recognitionStarted||segmentedEnded){fail("Unexpected recognition callback outside the confirmed file session");return;}
        try {
            if(bundle==null)throw new IllegalArgumentException("Empty segment bundle");
            ArrayList<String> candidates=bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            String text=candidates==null||candidates.isEmpty()?"":candidates.get(0);
            text=text==null?"":text.trim();if(text.isEmpty())return;
            if(transcript.length()+text.length()+1>250000)throw new IllegalArgumentException("Recognized transcript exceeds the safe document limit");
            if(transcript.length()>0)transcript.append(' ');transcript.append(text);segments++;
            if(Build.VERSION.SDK_INT<34){timingUsable=false;timingProblem="This Android version did not provide requested word starts";return;}
            ArrayList<android.speech.RecognitionPart> parts=bundle.getParcelableArrayList(SpeechRecognizer.RECOGNITION_PARTS,android.speech.RecognitionPart.class);
            if(parts==null||parts.isEmpty()){timingUsable=false;return;}
            StringBuilder partText=new StringBuilder();
            for(android.speech.RecognitionPart part:parts){
                if(part==null)throw new IllegalArgumentException("Null recognition part");
                String value=part.getFormattedText();if(value==null||value.trim().isEmpty())value=part.getRawText();
                if(value==null||value.trim().isEmpty()){timingUsable=false;timingProblem="A word timing part contained no words";continue;}
                if(words.size()>=Duwm1728CaptionEditPolicy.MAX_CUES)throw new IllegalArgumentException("Too many recognition parts");
                words.add(new Duwm1728SpeechCues.Word(part.getTimestampMillis(),value));
                if(partText.length()>0)partText.append(' ');partText.append(value);
            }
            if(!letters(text).equals(letters(partText.toString()))){timingUsable=false;timingProblem="Reported word timing did not cover the complete returned transcript";}
        }catch(Exception invalid){fail("Recorded-file recognition returned malformed data: "+message(invalid));}
    }
    private static String letters(String text){StringBuilder result=new StringBuilder();
        for(int i=0;i<text.length();){int cp=text.codePointAt(i);i+=Character.charCount(cp);if(Character.isLetterOrDigit(cp))result.appendCodePoint(Character.toLowerCase(cp));}return result.toString();}
    private void finishIfComplete(){
        if(finished.get()||!segmentedEnded||!audioComplete)return;
        if(!supportConfirmed||segments==0||transcript.length()==0){fail("No recognizable speech completed the recorded-file session");return;}
        List<Duwm1728BroadcastLayout.Cue> cues=Collections.emptyList();String note=timingProblem;
        if(timingUsable&&!words.isEmpty())try{
            boolean nonzero=false;for(Duwm1728SpeechCues.Word word:words)if(word.offsetMs>0)nonzero=true;
            if(!nonzero&&words.size()>1)throw new IllegalArgumentException("All word timestamps were zero; timing support is ambiguous");
            cues=Duwm1728SpeechCues.fromWords(words,fromMs,toMs);
            note="Word starts reported by the on-device service; caption display ends are inferred and bounded, not measured word ends.";
        }catch(IllegalArgumentException unavailable){note=unavailable.getMessage();}
        Result result=new Result(transcript.toString(),cues,note,fromMs);
        if(finished.compareAndSet(false,true)){Listener listener=callbacks;cleanup();if(listener!=null)listener.done(result);}
    }
    private void startAudio(Uri video){
        decodeThread=new Thread(()->{
            OutputStream output=null;
            try {
                synchronized(audioLock){
                    if(finished.get()||writePipe==null)throw new InterruptedIOException("Recorded-audio request cancelled");
                    output=new ParcelFileDescriptor.AutoCloseOutputStream(writePipe);writePipe=null;activeWriteStream=output;
                }
                try(OutputStream stream=output){decodePcm(context,video,fromMs,toMs,stream);}
                main.post(()->{if(!finished.get()){audioComplete=true;finishIfComplete();}});
            }catch(Exception failure){if(!finished.get())main.post(()->fail("Cannot provide recorded audio: "+message(failure)));}
            finally{synchronized(audioLock){if(activeWriteStream==output)activeWriteStream=null;}}
        },"duwm-recorded-audio-decode");decodeThread.start();
    }
    private void checkCancelled()throws InterruptedIOException{
        if(finished.get()||Thread.currentThread().isInterrupted())throw new InterruptedIOException("Recorded-audio conversion cancelled");
    }
    private void decodePcm(Context context,Uri video,long fromMs,long toMs,OutputStream output)throws Exception{
        MediaExtractor extractor=new MediaExtractor();MediaCodec decoder=null;Duwm1728PcmTimeline timeline=new Duwm1728PcmTimeline(fromMs,toMs);
        try {
            checkCancelled();extractor.setDataSource(context,video,null);int selected=-1;
            for(int i=0;i<extractor.getTrackCount();i++){String mime=extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME);if(mime!=null&&mime.startsWith("audio/")){selected=i;break;}}
            if(selected<0)throw new IOException("Video contains no audio track");MediaFormat format=extractor.getTrackFormat(selected);
            extractor.selectTrack(selected);extractor.seekTo(fromMs*1000,MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            format.setInteger(MediaFormat.KEY_PCM_ENCODING,AudioFormat.ENCODING_PCM_16BIT);
            decoder=MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME));decoder.configure(format,null,null,0);decoder.start();
            boolean inputDone=false,outputDone=false;MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();long limit=toMs*1000,deadline=SystemClock.elapsedRealtime()+20000;
            int channels=format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)?format.getInteger(MediaFormat.KEY_CHANNEL_COUNT):1;
            int sampleRate=format.containsKey(MediaFormat.KEY_SAMPLE_RATE)?format.getInteger(MediaFormat.KEY_SAMPLE_RATE):44100;
            while(!outputDone){
                checkCancelled();if(SystemClock.elapsedRealtime()>deadline)throw new IOException("Audio decoder did not finish within its bounded preparation time");
                if(!inputDone){int index=decoder.dequeueInputBuffer(10000);if(index>=0){
                    ByteBuffer input=decoder.getInputBuffer(index);if(input==null)throw new IOException("Audio decoder input unavailable");input.clear();
                    int count=extractor.readSampleData(input,0);long pts=extractor.getSampleTime();
                    if(count<0||pts>=limit){decoder.queueInputBuffer(index,0,0,limit,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputDone=true;}
                    else{decoder.queueInputBuffer(index,0,count,pts,0);extractor.advance();}
                }}
                int index=decoder.dequeueOutputBuffer(info,10000);
                if(index==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){MediaFormat changed=decoder.getOutputFormat();
                    channels=changed.containsKey(MediaFormat.KEY_CHANNEL_COUNT)?changed.getInteger(MediaFormat.KEY_CHANNEL_COUNT):channels;
                    sampleRate=changed.containsKey(MediaFormat.KEY_SAMPLE_RATE)?changed.getInteger(MediaFormat.KEY_SAMPLE_RATE):sampleRate;
                    int encoding=changed.containsKey(MediaFormat.KEY_PCM_ENCODING)?changed.getInteger(MediaFormat.KEY_PCM_ENCODING):AudioFormat.ENCODING_PCM_16BIT;
                    if(encoding!=AudioFormat.ENCODING_PCM_16BIT)throw new IOException("Unsupported decoded PCM encoding");
                }else if(index>=0){try{
                    if(info.size>0&&(info.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)==0){
                        if(channels<1||channels>8||sampleRate<8000||sampleRate>192000||info.size%(channels*2)!=0)throw new IOException("Invalid decoded PCM format");
                        ByteBuffer buffer=decoder.getOutputBuffer(index);if(buffer==null)throw new IOException("Decoded PCM unavailable");
                        ByteBuffer pcm=buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN);pcm.position(info.offset);pcm.limit(info.offset+info.size);
                        short[] mono=new short[info.size/(channels*2)];for(int frame=0;frame<mono.length;frame++){
                            int total=0;for(int channel=0;channel<channels;channel++)total+=pcm.getShort();mono[frame]=(short)(total/channels);
                        }
                        timeline.accept(info.presentationTimeUs,sampleRate,mono);
                    }
                    outputDone=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                }finally{decoder.releaseOutputBuffer(index,false);}}
            }
            checkCancelled();if(timeline.coveredSampleCount()==0)throw new IOException("The selected source range contains no decoded audio samples");timeline.writeTo(output);
        }finally{if(decoder!=null){try{decoder.stop();}catch(Exception ignored){}try{decoder.release();}catch(Exception ignored){}}extractor.release();}
    }
    private static String message(Exception failure){return failure.getMessage()==null?failure.getClass().getSimpleName():failure.getMessage();}
    private void fail(String message){
        if(Looper.myLooper()!=Looper.getMainLooper()){main.post(()->fail(message));return;}
        if(finished.compareAndSet(false,true)){Listener listener=callbacks;cleanup();if(listener!=null)listener.error(message);}
    }
    private void cleanup(){
        main.removeCallbacks(supportTimeout);main.removeCallbacks(recognitionTimeout);callbacks=null;
        Thread worker=decodeThread;if(worker!=null)worker.interrupt();
        synchronized(audioLock){
            try{if(activeWriteStream!=null)activeWriteStream.close();}catch(IOException ignored){}activeWriteStream=null;
            try{if(writePipe!=null)writePipe.close();}catch(IOException ignored){}writePipe=null;
            try{if(readPipe!=null)readPipe.close();}catch(IOException ignored){}readPipe=null;
        }
        Runnable destroy=()->{if(recognizer!=null){try{recognizer.cancel();}catch(RuntimeException ignored){}try{recognizer.destroy();}catch(RuntimeException ignored){}recognizer=null;}};
        if(Looper.myLooper()==Looper.getMainLooper())destroy.run();else main.post(destroy);
    }
    public void close(){if(finished.compareAndSet(false,true))cleanup();}
}
