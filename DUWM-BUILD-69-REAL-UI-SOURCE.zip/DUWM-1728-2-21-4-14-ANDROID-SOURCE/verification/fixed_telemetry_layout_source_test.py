from pathlib import Path
p=Path('app/src/main/java/com/sentongoharuna/worldsituationroom/Duwm1728BroadcastLayout.java')
s=p.read_text()
assert 'float column=w/4f' in s
for token in ['{"HDG"','{"ALT"','{"WX"','{"GPS"']:
    assert token in s, token
assert 'fields.size()' not in s[s.index('// /21.4/14'):s.index('if(g.tickerVisible)')]
assert 'WITHHELD' in s
print('fixed telemetry in-place source policy: PASS')
