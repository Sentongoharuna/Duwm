#!/usr/bin/env python3
"""Exercise actual subprocess failures and retained CI diagnostics."""
from pathlib import Path
import io
import json
import os
import signal
import sys
import tempfile
import unittest

from ci_host_checks import error_excerpt, run_checks, workflow_escape


class HostCiDiagnosticsTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='duwm-host-diagnostics-')
        self.root = Path(self.temporary.name)
        self.proof = self.root / 'proof'
        self.console = io.StringIO()
        self.summary = self.root / 'JOB-SUMMARY.md'

    def tearDown(self):
        self.temporary.cleanup()

    def run_commands(self, checks):
        return run_checks(checks, self.root, self.proof, stream=self.console,
                          summary_path=self.summary)

    @staticmethod
    def python(code):
        return [sys.executable, '-c', code]

    def test_success_retains_both_streams_and_scope(self):
        result = self.run_commands([
            ('first', self.python("import sys;print('stdout before');sys.stderr.write('stderr after\\n')")),
            ('second', self.python("print('second complete')")),
        ])
        self.assertEqual((result['status'], result['exit_code']), ('PASS', 0))
        log = (self.proof / 'HOST-CI.log').read_text()
        self.assertLess(log.index('stdout before'), log.index('stderr after'))
        self.assertLess(log.index('stderr after'), log.index('second complete'))
        self.assertEqual(result['commands_attempted'], 2)
        self.assertFalse(result['official_sdk_compilation_verified'])
        self.assertFalse(result['android_native_executed'])
        self.assertEqual(json.loads((self.proof / 'HOST-CI-RESULT.json').read_text()), result)
        self.assertIn('PASSED', self.summary.read_text())
        self.assertNotIn('::error', self.console.getvalue())

    def test_original_assertion_is_retained_and_later_command_never_runs(self):
        assertion = 'Exception in thread "main" java.lang.AssertionError: essential measurement remains whole: STATIONARY'
        result = self.run_commands([
            ('prior passing check', self.python("print('PASS prior')")),
            ('measured layout', self.python('import sys;sys.stderr.write(' + repr(assertion + '\n    at MeasuredLayoutTest.java:99\n') + ');sys.exit(23)')),
            ('must not run', self.python("from pathlib import Path;Path('incorrectly-continued').write_text('bad')")),
        ])
        self.assertEqual((result['status'], result['exit_code']), ('FAIL', 23))
        self.assertFalse((self.root / 'incorrectly-continued').exists())
        self.assertEqual(result['commands_attempted'], 2)
        self.assertEqual(result['first_error'], assertion)
        self.assertEqual(result['failed_check'], 'measured layout')
        self.assertIn('MeasuredLayoutTest.java:99', self.summary.read_text())
        self.assertIn(assertion, (self.proof / 'HOST-CI.log').read_text())
        self.assertIn('::error title=Host verification failed::', self.console.getvalue())

    def test_missing_executable_is_a_retained_failure(self):
        result = self.run_commands([('missing command', [str(self.root / 'absent-program')])])
        self.assertEqual(result['exit_code'], 127)
        self.assertEqual(result['status'], 'FAIL')
        self.assertIn('Could not start host command', result['first_error'])
        self.assertTrue((self.proof / 'HOST-CI-SUMMARY.md').is_file())

    def test_failure_without_known_error_marker_still_fails(self):
        result = self.run_commands([('unknown failure', self.python("import sys;print('aborted operation');sys.exit(7)"))])
        self.assertEqual(result['exit_code'], 7)
        self.assertEqual(result['first_error'], 'aborted operation')
        self.assertIn('aborted operation', self.summary.read_text())

    @unittest.skipUnless(os.name == 'posix', 'POSIX signal status')
    def test_signal_exit_is_not_mistaken_for_success(self):
        result = self.run_commands([('terminated', self.python('import os,signal;os.kill(os.getpid(),signal.SIGTERM)'))])
        self.assertEqual(result['exit_code'], 128 + signal.SIGTERM)
        self.assertEqual(result['commands'][0]['process_returncode'], -signal.SIGTERM)
        self.assertEqual(result['status'], 'FAIL')

    def test_first_actual_error_precedes_wrapper_traceback(self):
        text = ('PASS retained check\nException in thread "main" java.lang.AssertionError: STATIONARY\n'
                '    at MeasuredLayoutTest.java:99\nTraceback (most recent call last):\n'
                'subprocess.CalledProcessError: returned non-zero exit status 1\n')
        first, excerpt = error_excerpt(text)
        self.assertTrue(first.endswith('STATIONARY'))
        self.assertIn('MeasuredLayoutTest.java:99', excerpt)

    def test_workflow_annotation_data_is_escaped(self):
        self.assertEqual(workflow_escape('100%\r\nnext'), '100%25%0D%0Anext')


if __name__ == '__main__':
    unittest.main(verbosity=2)
