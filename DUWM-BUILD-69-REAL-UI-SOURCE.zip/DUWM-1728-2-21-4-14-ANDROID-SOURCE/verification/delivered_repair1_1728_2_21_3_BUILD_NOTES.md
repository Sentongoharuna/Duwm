# DUWM 1728.2/21/3 — CI Repair 1

## Exact repair and identity

This repair starts from the exact delivered /21/3 source archive, SHA-256
`658fc5f137b76480be516eaa1590fcccb46049b99bc6825f5ced6cfafb566f49`.
It fixes the real measured-layout failure reported by the user after that
release. It keeps application version `1728.2.21.3`, code `172824`, and the
original globe, nineteen desks, navy presentation and complete clear-picture
upgrade. The workflow identifies this attempt as Repair 1.

The preceding source manifest, acceptance file and build notes are retained as
explicit original-release provenance. Their old check results do not replace the
repair's current verification. Current results are recorded in
`1728_2_21_3_ACCEPTANCE.json` and the matching verification archive.

## Observed GitHub failure

Actual run: https://github.com/Sentongoharuna/Duwm/actions/runs/42409599382

Commit: `ebbe0f1a5ad0ed8eea35c89e27b4b9028cbf58fd`.
Compile-development job: `128514647935`.

The first failing assertion was:

```
Reserved cells keep extreme actual numbers/units/provider/time visible: STATIONARY
```

It came from `MeasuredLayoutTest.java:99`. The run stopped in the host-test
stage, before official SDK resolution, Java compilation or APK assembly.
The dependent native job was skipped. The host-evidence upload was also skipped
because it had no failure condition, and the run returned no downloadable
artifacts. The verification bundle includes the exact first-error excerpt and
read-only job metadata.

## Root cause and production correction

The original measurement row divided location, speed/movement and altitude into
fixed percentages. The speed/movement cell could not contain the full real
status text with wider font metrics. The same original source and unchanged
historical assertion reproduce the exact STATIONARY failure with installed
DejaVu Sans; the narrower local font had passed.

Java logical fonts such as SansSerif can map to different physical fonts across
runtime environments, with different measured widths. Official reference:
https://docs.oracle.com/en/java/javase/17/docs/api/java.desktop/java/awt/Font.html

The repair reserves measurement cells from bounded value/status widths using
the actual painter's font metrics. Reservation depends on font and frame size,
not current readings, so updates do not move the cells. Numeric readings and
complete status labels take priority over the descriptive place name.

The band keeps exactly three rows and its existing height. Coordinates and the
compass remain in row one. Place, speed/movement and altitude remain in row two.
Preview FPS receives a fixed right-hand cell on row three, allowing complete
unavailable or unreliable status text. Weather retains its provider, values,
units and observation time before the descriptive condition text is shortened.
The existing readable minimum and clear mode's fixed font size remain.

Both legacy measured layouts and clear-picture mode use the same reservation
logic. The clear clock also keeps its time and UTC qualifier together when
wrapping, inside the same fixed card. No original-source timestamp, sensor
policy, coordinate permission or AI inference logic is replaced.

## Failure diagnostics and strict workflow gates

The workflow runs its existing host commands through a persistent logging
wrapper. The wrapper keeps combined output, returns the first failed command's
nonzero status and places the first real assertion/error in the job summary.
Host evidence is uploaded after a failure as well as after success.

The font regression explicitly requires DejaVu Sans and reports physical font
selection. The workflow provisions the official Ubuntu font package only when
needed. It does not replace the normal runtime font configuration to hide the
problem. Existing host Java assertions remain unchanged.

Official ML Kit resolution, real compilation, actual APK class definitions and
all nineteen native stages remain mandatory. There is no continue-on-error path
that converts a test or build failure into success. The earlier repair for
`PER_APP_BATTERY_USE_QUOTA_EXCEEDED` and `BACKGROUND_USE_BLOCKED` remains, including
its two negative compiler probes.

## Safe source restoration

The matching new source ZIP is used directly after exact hash validation. The
workflow can also repair the exact known original /21/3 ZIP using its checked
embedded patch. Earlier supported /21/2, /21/1, /21 and /20 baselines remain
available. An unknown or corrupted same-name source archive is rejected.

Use the source ZIP at the repository root and the matching YAML in
`.github/workflows/`. Their basenames are unchanged so they replace the failed
/21/3 files. Both replacement-file delivery and exact original-/21/3 restoration
are checked before delivery.

## Current verification results

- Full retained host suite: PASS. All 563 current application/test/fixture inputs
  remained unchanged throughout the authoritative run.
- The original measured-layout test: 1,905 checks PASS. The original clear-picture
  test: 6,808 checks PASS. Their delivered Java assertions are byte-identical.
- Explicit font regression: 11,947 checks PASS across SansSerif, DejaVu Sans,
  Liberation Sans, Noto Sans and DejaVu Math TeX Gyre, at four frame sizes.
  No optional font was skipped in this local run. Actual production UTC and
  REC/VIEW elapsed-time formatting is covered.
- The exact original STATIONARY failure was reproduced with DejaVu Sans before
  the repair and passed afterward. The immutable measured and clear tests also
  passed separately under every recorded physical font. Different numbers of
  drawn rows cause small font-dependent assertion-count differences.
- Clear-picture cadence: 73 checks PASS; Android report adapter: 62 PASS;
  actual scene controller: 283 PASS plus both missing-field compiler probes.
- CI diagnostics: seven subprocess tests PASS. Native evidence gate: 46 tests
  PASS. SDK/measured/clear-picture DEX gate tests: 8/3/4 PASS. Workflow expression
  context tests: 10 PASS. These validate gates, not native execution.
- Retained server contract tests: 14 PASS, with provider/model operations mocked.
- Selected 18 actual Android presentation/native-stage sources compile against
  cached Android API 36 and recorded compiled dependencies without temporary
  Google declarations. This does not establish full application compilation.
- Whole-source diagnostic: 316 application and 13 instrumentation Java files
  PASS against real Android API 36 plus isolated restricted Google declarations.
  Those declarations are diagnostic-only and never enter the build or APK.
- Foundation checks: PASS, with all 441 checked inputs unchanged.
- Final host portrait/landscape and DejaVu fixtures were visually reviewed: the
  center stays clear, the critical numeric/status fields remain complete, and
  title, clock, subtitles and measurement rows do not overlap.
- Exactly two production Java files change from the delivered /21/3 release.
  All other 314 application Java files and all 13 native Java files are preserved.
- One actual offline Gradle attempt stopped before compilation because the pinned
  official ML Kit artifact is not cached. All 444 build inputs remained unchanged.
  No APK was produced; official SDK compilation and nineteen native stages still
  need execution by the matching GitHub workflow.

The retained comparison PNG's old `/21/2 COMPACT` caption means the compact and
clear selections of the repaired painter. It is not an exact historical /21/2
render. The matching verification archive contains the checked restoration,
actionlint, package hashes, source bindings and scoped logs.

## Verification limits

Host rendering and font tests do not establish Android encoding, attached-view
lifecycle, physical camera/sensors, provider network operation or model inference.
The selected Android source check and whole-source diagnostic record their
actual dependency scope. Temporary Google API declarations never enter Gradle
or the APK. The actual offline Gradle result is retained separately.

A new green GitHub Actions run is a separate observed result. Preparing and
validating the corrected YAML does not itself run it or produce an APK.
