#!/usr/bin/env bash
set -euo pipefail
font_project="$(cd "$(dirname "$0")/.." && pwd)"
font_proof="${1:-$font_project/verification/clear-font-host-proof}"
font_javac="${JAVAC:-${JAVA_HOME:+$JAVA_HOME/bin/}javac}"
font_java="${JAVA:-${JAVA_HOME:+$JAVA_HOME/bin/}java}"
font_build="$(mktemp -d "${TMPDIR:-/tmp}/duwm-clear-font.XXXXXX")"
trap 'rm -rf -- "$font_build"' EXIT
font_source="$font_project/app/src/main/java/com/sentongoharuna/worldsituationroom"
"$font_javac" --release 17 -encoding UTF-8 -d "$font_build" \
  "$font_source/Duwm1728BroadcastComposition.java" "$font_source/Duwm1728BroadcastLayout.java" \
  "$font_source/Duwm1728ClearPictureLayout.java" "$font_source/Duwm1728HeadlineFit.java" \
  "$font_source/Duwm1728CaptionPages.java" "$font_source/Duwm1728Measurements.java" \
  "$font_source/Duwm1728MeasurementMath.java" \
  "$font_project/verification/broadcast/ClearPictureFontCompatibilityTest.java"
"$font_java" -Xmx512m -Djava.awt.headless=true -cp "$font_build" \
  com.sentongoharuna.worldsituationroom.ClearPictureFontCompatibilityTest "$font_proof"
