#!/usr/bin/env python3
"""1723 source acceptance gates: Android compile and device validation remain separate."""
from pathlib import Path
import json, re, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
read=lambda x:(j/x).read_text(encoding='utf-8')
cam=read('Duwm1718MonitorsCamActivity.java')
world=read('Duwm1718GlobalDiscoverActivity.java')
weather=read('Duwm1723GlobalWeatherActivity.java')
main=read('MainActivity.java')
my=read('Duwm1719MyWorldActivity.java')
quake=read('Duwm1721GlobalQuakesActivity.java')
navy=read('DuwmUnifiedTheme.java')
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
settings=(root/'app/build.gradle.kts').read_text()
strings=(root/'app/src/main/res/values/strings.xml').read_text()
ui=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert 'versionCode = 172300' in settings and 'versionName = "1723"' in settings
assert 'DUWM 1723 • DEVELOP.UGANDA' in strings
assert ui['uiRevision']=='1723' and ui['uiVersionCode']==172300 and ui['singleOriginalGlobe']
assert main.count('new SatelliteMapView(this)')==1
assert all('new SatelliteMapView' not in x for x in (cam,world,my,quake,weather))
assert 'BACKGROUND = 0xFF041424' in navy
assert 'BORDER = 0xFFDEE5EF' in navy
assert 'TEXT = 0xFFF5F7FA' in navy
assert 'MUTED = 0xFFA0A5AE' in navy
assert '<activity android:name=".Duwm1723GlobalWeatherActivity" android:exported="false"' in manifest
assert 'android.permission.INTERNET' in manifest
assert 'Duwm1723GlobalWeatherActivity.class' in main and 'Duwm1723GlobalWeatherActivity.class' in world and 'Duwm1723GlobalWeatherActivity.class' in my
assert '7-DAY WORLD WEATHER FOR THIS PLACE' in world
for phrase in ('CACHED FORECAST / NOT LIVE','No network request has been made.',
              'https://api.open-meteo.com/v1/forecast?',
              'hourly=temperature_2m,precipitation_probability,weather_code',
              'daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code',
              'private void fetchForecast()','private void openMap()', 'private void shareCurrent()',
              'getSharedPreferences(PREFS,MODE_PRIVATE)','FORECAST UNAVAILABLE',
              'shownRequestedLat','shownRequestedLon'):
    assert phrase in weather, ('Missing real worldwide weather feature:',phrase)
assert 'private void shareCurrent()' in weather and 'Math.abs(c[0]-shownRequestedLat)>0.005' in weather
assert 'Double.isFinite(lat)' in weather and 'Math.abs(lat)>90' in weather
assert 'new Thread(' in weather and 'setConnectTimeout(8000)' in weather and 'setReadTimeout(9000)' in weather
assert 'CACHED FORECAST / NOT LIVE' in weather and 'Open-Meteo model forecast; not official warning information.' in weather
assert 'new ScaleGestureDetector(this' in cam and 'preview.setOnTouchListener((view,event)->{' in cam
assert 'camera.getParameters()' in cam and 'settings.setZoom(target)' in cam and 'camera.setParameters(settings)' in cam
assert 'focusOnce();' in cam and 'recording||camera==null' in cam
assert 'TAP CAMERA PREVIEW TO FOCUS' in cam and 'PINCH TO ZOOM' in cam
assert 'recorderSurface.lockCanvas(null)' in cam and 'saveCaptureReceipt(f,lastFile' in cam
assert 'preciseLocation.setChecked(false)' in cam
assert 'DUWM 1723  /  MONITORS CAM' in cam
assert 'DUWM 1723  /  GLOBAL DISCOVERY' in world
assert 'DUWM 1723  /  MY WORLD' in my
assert 'DUWM 1723  /  GLOBAL EARTHQUAKES' in quake
assert 'DUWM 1723  /  WORLD WEATHER' in weather
assert len(list(j.glob('*.java')))>=254
for path in (root/'app/src/main/res').rglob('*.xml'):ET.parse(path)
ET.parse(root/'app/src/main/AndroidManifest.xml')
print('PASS 1723 single original globe, same approved palette, worldwide weather with explicit opt-in, model-source labels, cached receipt matching, 7-day+hourly data and map/share actions')
print('PASS 1723 camera real touch focus and pinch zoom APIs, privacy defaults, MP4 telemetry pipeline and receipt preservation; 254 Java files')
print('NOT VERIFIED by source-only tests: successful Android Gradle compilation, a real external forecast, or device recording/overlay compatibility')
