package com.sentongoharuna.worldsituationroom;

import java.util.HashSet;
import java.util.Set;

/** Executes saved-video state rules without Android classes, storage, or player mocks. */
public final class BroadcastReviewStateTest {
    private static int checks;
    private static void check(boolean condition,String description) {
        checks++;if(!condition)throw new AssertionError(description);
    }
    private static void position(long requested,long duration,int expected,String description) {
        check(Duwm1728BroadcastReviewState.resumePosition(requested,duration)==expected,description);
    }
    private static void rejects(String value) {
        boolean rejected=false;
        try{Duwm1728BroadcastReviewState.key(value);}catch(IllegalArgumentException expected){rejected=true;}
        check(rejected,"reject invalid/non-content URI: "+value);
    }
    public static void main(String[] args) {
        String saved="content://media/external_primary/video/media/172813";
        String key=Duwm1728BroadcastReviewState.key(saved);
        check(key.matches("video_[0-9a-f]{64}"),"bounded preference key with SHA-256 digest");
        check(key.equals(Duwm1728BroadcastReviewState.key(saved)),"same saved URI keeps stable preferences");
        check(!key.contains("172813")&&!key.contains("media"),"preference key does not expose the original URI");
        String[] different={saved,saved+"0",saved+"?revision=1",saved+"?revision=2",saved+"#a",
                "content://another.provider/external_primary/video/media/172813",
                "content://media/external/video/media/172813",
                "content://media/external_primary/video/media/%31%37%32%38%31%33"};
        Set<String> keys=new HashSet<>();
        for(String uri:different)check(keys.add(Duwm1728BroadcastReviewState.key(uri)),"full URI variants stay isolated: "+uri);
        rejects(null);rejects("");rejects("file:///tmp/video.mp4");rejects("https://example.com/video.mp4");
        rejects("content:///video/1");rejects("content://");rejects("content://media/unescaped space");

        position(-1,1500,0,"negative history restarts");
        position(Long.MIN_VALUE,1500,0,"extreme negative history restarts");
        position(500,0,0,"unknown duration restarts");
        position(500,-1,0,"invalid duration restarts");
        position(0,1500,0,"new clip starts at zero");
        position(200,1500,200,"short clip ordinary resume survives");
        position(1000,1500,1000,"two-thirds seek survives reopening");
        position(1424,1500,1424,"last position before short-clip tail survives");
        position(1425,1500,0,"final five percent restarts a short clip");
        position(1499,1500,0,"near-complete short clip restarts");
        position(1500,1500,0,"completed clip restarts");
        position(1700,1500,0,"replaced shorter clip restarts");
        position(Long.MAX_VALUE,1500,0,"corrupt large history restarts");
        position(59749,60000,59749,"long clip does not lose useful progress");
        position(59750,60000,0,"long clip final 250ms restarts");
        position(59800,60000,0,"near-complete long clip restarts");
        position(10,20,10,"tiny clip midpoint survives");
        position(19,20,0,"tiny clip final millisecond restarts");
        position(0,1,0,"one-millisecond clip is safe");
        position((long)Integer.MAX_VALUE+10,Long.MAX_VALUE,Integer.MAX_VALUE,"VideoView integer position is bounded");
        position(Long.MAX_VALUE,Long.MAX_VALUE,0,"maximum duration completion does not overflow");
        for(long duration:new long[]{1,2,19,20,100,1500,5000,60000,Long.MAX_VALUE}) {
            long original=duration/3;
            int normalized=Duwm1728BroadcastReviewState.resumePosition(original,duration);
            check(normalized>=0&&normalized<duration,"resume always inside duration");
            check(Duwm1728BroadcastReviewState.resumePosition(normalized,duration)==normalized,"resume normalization is stable");
        }
        System.out.println("PASS "+checks+" saved-video review state assertions: full-URI isolation, stable keys, invalid URI rejection, resume, completion/tail reset, bounds. Native playback/UI are separate gates.");
    }
}
