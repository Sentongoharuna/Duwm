#!/usr/bin/env python3
"""Check the real editor AST and mutation regressions for the local /18 route.
These checks do not type-check Android APIs or run speech/model inference.
The legacy cloud admission policy is tested only for compatibility.
"""
from pathlib import Path
import re
import subprocess
import sys
import tempfile

root=Path(__file__).resolve().parents[1]
java=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
editor=java/'Duwm1728VideoEditorActivity.java'
proof=Path(sys.argv[1]) if len(sys.argv)>1 else root/'verification/results/1728_2_18'
proof.mkdir(parents=True,exist_ok=True)
lines=[]

def record(message):
    print(message,end='')
    lines.append(message)

with tempfile.TemporaryDirectory() as tmp:
    subprocess.run(['javac','--release','17','-d',tmp,
        str(root/'verification/EditorAiEntrypointCheck.java'),
        str(java/'Duwm1728AiStartPolicy.java'),str(root/'verification/AiStartPolicyTest.java')],check=True)
    for classname,arguments in [('EditorAiEntrypointCheck',[str(editor)]),
                               ('com.sentongoharuna.worldsituationroom.AiStartPolicyTest',[])]:
        run=subprocess.run(['java','-cp',tmp,classname,*arguments],text=True,capture_output=True,check=True)
        if classname.endswith('AiStartPolicyTest'):
            record('Legacy cloud opt-in compatibility policy only; this is not the default automatic route:\n')
        record(run.stdout)
    source=editor.read_text()
    entry=r'(\bprivate\s+void\s+requestAi\s*\(\s*\)\s*\{)\s*startAutomaticProduction\s*\(\s*\)\s*;'
    assert len(re.findall(entry,source))==1,'Unexpected manual automatic entry layout'
    faulty=Path(tmp)/'Duwm1728VideoEditorActivity.java'
    mutations=[
        ('unresolved historical /8 call','startAi(spec());','UNRESOLVED_AI_SELF_CALL startAi/1'),
        ('unresolved automatic argument count','startAutomaticProduction(spec());','UNRESOLVED_AI_SELF_CALL startAutomaticProduction/1'),
        ('restored cloud entry','beginAi(spec());','FORBIDDEN_CLOUD_SELF_CALL beginAi/1'),
        ('forged human approval','approval.setChecked(true);startAutomaticProduction();','FORGED_REVIEW_APPROVAL'),
        ('removed real automatic entry','','MISSING_LOCAL_AUTOMATIC_ROUTE requestAi'),
    ]
    for label,replacement,expected in mutations:
        changed,count=re.subn(entry,lambda found:found.group(1)+replacement,source,count=1)
        assert count==1,label
        faulty.write_text(changed)
        negative=subprocess.run(['java','-cp',tmp,'EditorAiEntrypointCheck',str(faulty)],capture_output=True,text=True)
        assert negative.returncode!=0 and expected in negative.stderr,negative.stdout+negative.stderr
        record('PASS negative editor regression: '+label+' is rejected.\n')
    changed,count=re.subn(r'(\bprivate\s+void\s+aiSettings\s*\(\s*\)\s*\{)',
                          lambda found:found.group(1)+'EditText serverAddress=new EditText(this);',source,count=1)
    assert count==1,'Missing built-in help method'
    faulty.write_text(changed)
    negative=subprocess.run(['java','-cp',tmp,'EditorAiEntrypointCheck',str(faulty)],capture_output=True,text=True)
    assert negative.returncode!=0 and 'FORBIDDEN_SERVER_INPUT' in negative.stderr,negative.stdout+negative.stderr
    record('PASS negative editor regression: a server-address input in built-in help is rejected.\n')

(proof/'ai-entrypoint-regression.txt').write_text(''.join(lines))
