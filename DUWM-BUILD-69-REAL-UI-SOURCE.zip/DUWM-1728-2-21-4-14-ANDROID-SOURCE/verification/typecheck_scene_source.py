#!/usr/bin/env python3
"""Check app cross-file/Android API wiring when the real ML Kit SDK is unavailable.

This is deliberately NOT a dependency-backed build or an APK compilation. Tiny
test-only declarations below represent the documented Google API surface. They
are generated in a temporary directory, never in an Android source set, never
passed to Gradle, and never packaged. CI must separately resolve and compile the
official artifacts and inspect the resulting APK's actual class definitions.
"""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
DECLARATIONS = {
    'com/google/common/util/concurrent/ListenableFuture.java': '''
package com.google.common.util.concurrent;
public interface ListenableFuture<V> extends java.util.concurrent.Future<V> {
 void addListener(Runnable listener, java.util.concurrent.Executor executor);
}''',
    'com/google/mlkit/genai/common/FeatureStatus.java': '''
package com.google.mlkit.genai.common;
public final class FeatureStatus {
 public static final int UNAVAILABLE=0, DOWNLOADABLE=1, DOWNLOADING=2, AVAILABLE=3;
}''',
    'com/google/mlkit/genai/common/GenAiException.java': '''
package com.google.mlkit.genai.common;
public class GenAiException extends Exception {
 public int getErrorCode(){throw new AssertionError("Declaration only");}
 public interface ErrorCode {
  int BUSY=1, PER_APP_BATTERY_USE_QUOTA_EXCEEDED=2, BACKGROUND_USE_BLOCKED=3,
      AICORE_INCOMPATIBLE=4, NEEDS_SYSTEM_UPDATE=5, NOT_AVAILABLE=6,
      NOT_SUPPORTED=7, NOT_ENOUGH_DISK_SPACE=8;
 }
}''',
    'com/google/mlkit/genai/imagedescription/ImageDescriberOptions.java': '''
package com.google.mlkit.genai.imagedescription;
public final class ImageDescriberOptions {
 public static Builder builder(android.content.Context context){throw new AssertionError("Declaration only");}
 public static final class Builder {
  public ImageDescriberOptions build(){throw new AssertionError("Declaration only");}
 }
}''',
    'com/google/mlkit/genai/imagedescription/ImageDescription.java': '''
package com.google.mlkit.genai.imagedescription;
public final class ImageDescription {
 public static ImageDescriber getClient(ImageDescriberOptions options){throw new AssertionError("Declaration only");}
}''',
    'com/google/mlkit/genai/imagedescription/ImageDescriptionRequest.java': '''
package com.google.mlkit.genai.imagedescription;
public final class ImageDescriptionRequest {
 public static Builder builder(android.graphics.Bitmap bitmap){throw new AssertionError("Declaration only");}
 public static final class Builder {
  public ImageDescriptionRequest build(){throw new AssertionError("Declaration only");}
 }
}''',
    'com/google/mlkit/genai/imagedescription/ImageDescriptionResult.java': '''
package com.google.mlkit.genai.imagedescription;
public final class ImageDescriptionResult {
 public String getDescription(){throw new AssertionError("Declaration only");}
}''',
    'com/google/mlkit/genai/imagedescription/ImageDescriber.java': '''
package com.google.mlkit.genai.imagedescription;
import com.google.common.util.concurrent.ListenableFuture;
public class ImageDescriber implements java.lang.AutoCloseable {
 public ListenableFuture<Integer> checkFeatureStatus(){throw new AssertionError("Declaration only");}
 public ListenableFuture<Void> prepareInferenceEngine(){throw new AssertionError("Declaration only");}
 public ListenableFuture<ImageDescriptionResult> runInference(ImageDescriptionRequest request){throw new AssertionError("Declaration only");}
 public void close(){throw new AssertionError("Declaration only");}
}''',
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--android-jar', required=True, type=Path)
    parser.add_argument('--resources-jar', required=True, type=Path)
    parser.add_argument('--javac', default='javac')
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    assert args.android_jar.is_file() and args.resources_jar.is_file()
    args.out.mkdir(parents=True, exist_ok=True)
    sources = sorted((ROOT/'app/src/main/java').rglob('*.java'))
    native = sorted((ROOT/'app/src/androidTest/java').rglob('*.java'))
    before = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sources + native}
    results = []
    with tempfile.TemporaryDirectory(prefix='duwm-documentation-typecheck-') as temporary:
        work = Path(temporary)
        declarations = []
        for name, content in DECLARATIONS.items():
            path = work/'DECLARATIONS-NOT-SDK'/name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content)
            declarations.append(path)
        classes = work/'classes'
        classes.mkdir()
        base = [args.javac, '-encoding', 'UTF-8', '-source', '17', '-target', '17',
                '-proc:none', '-Xmaxerrs', '100', '-d', str(classes)]
        for label, paths, classpath in (
            ('application-source', sources + declarations,
             str(args.android_jar) + ':' + str(args.resources_jar)),
            ('instrumentation-source', native,
             str(classes) + ':' + str(args.android_jar) + ':' + str(args.resources_jar)),
        ):
            arguments = work/(label + '.args')
            arguments.write_text('\n'.join('"' + str(path) + '"' for path in paths))
            command = base + ['-classpath', classpath, '@' + str(arguments)]
            run = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT)
            (args.out/(label + '.txt')).write_text(run.stdout)
            results.append({'scope': label, 'returncode': run.returncode,
                            'real_source_files': len(sources if label.startswith('application') else native)})
            print(label, 'PASS' if run.returncode == 0 else 'FAIL')
            if run.returncode:
                print(run.stdout[-12000:])
                break
    unchanged = before == {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                           for p in sources + native}
    record = {'build': '1728.2/21/1',
              'scope': 'ANDROID_API_AND_CROSS_FILE_SOURCE_WITH_DOCUMENTATION_DECLARATIONS',
              'official_mlkit_dependency_resolved': False, 'apk_built': False,
              'model_inference_executed': False, 'android_native_executed': False,
              'test_only_declarations': sorted(DECLARATIONS),
              'android_jar_sha256': hashlib.sha256(args.android_jar.read_bytes()).hexdigest(),
              'resource_symbols_jar_sha256': hashlib.sha256(args.resources_jar.read_bytes()).hexdigest(),
              'inputs_unchanged_during_check': unchanged, 'source_hashes': before,
              'results': results}
    (args.out/'SOURCE-TYPECHECK.json').write_text(json.dumps(record, indent=2) + '\n')
    if not unchanged or len(results) != 2 or any(result['returncode'] for result in results):
        raise SystemExit(1)
    print('PASS source wiring only. Official SDK build and physical model inference NOT VERIFIED.')


if __name__ == '__main__':
    main()
