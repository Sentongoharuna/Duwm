package com.sentongoharuna.worldsituationroom;

public final class PreviewRateTest {
    private static int checks;
    private static void ok(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
    private static void near(double got,double want,String why){ok(Math.abs(got-want)<.0001,why+": "+got);}
    public static void main(String[]args){
        Duwm1728PreviewRate rate=new Duwm1728PreviewRate();
        ok(Double.isNaN(rate.at(0).framesPerSecond),"No frames are not a configured target rate");
        rate.onFrame(1000,1);rate.onFrame(1100,2);
        ok(Double.isNaN(rate.at(1100).framesPerSecond),"Short windows remain unavailable");
        for(int i=2;i<=20;i++)rate.onFrame(1000+i*100,i+1);
        Duwm1728PreviewRate.Reading ten=rate.at(3000);
        near(ten.framesPerSecond,10,"Actual 100ms frame intervals");
        ok(ten.frames==21&&ten.windowMs==2000&&ten.observedAtMs==3000,"Retain measured window and count");
        rate.onFrame(3050,21);rate.onFrame(3060,20);
        near(rate.at(3000).framesPerSecond,10,"Repeated/backward producer stamps do not inflate throughput");
        ok(Double.isNaN(rate.at(2999).framesPerSecond),"Never use a future arrival");
        ok(Double.isNaN(rate.at(4001).framesPerSecond),"Stalled preview is not kept at 10fps");
        for(int i=0;i<=20;i++)rate.onFrame(5000+i*50,100+i);
        near(rate.at(6000).framesPerSecond,20,"Window follows the changed real arrival rate");
        rate.reset();ok(Double.isNaN(rate.at(6000).framesPerSecond),"New camera session has no inherited rate");
        for(int i=0;i<=10;i++)rate.onFrame(1000+i*100,0);
        near(rate.at(2000).framesPerSecond,10,"Missing producer stamp still uses actual callback intervals");
        rate.onFrame(2000,0);near(rate.at(2000).framesPerSecond,10,"Same-millisecond callback does not count twice");
        rate.onFrame(10,500);ok(Double.isNaN(rate.at(10).framesPerSecond),"Clock rollback resets the window");
        rate.onFrame(-1,600);ok(Double.isNaN(rate.at(10).framesPerSecond),"Negative timestamps ignored");
        System.out.println("PASS PREVIEW-RATE-HOST checks="+checks+"; actual arrival policy only; no physical camera or encoder executed");
    }
}
