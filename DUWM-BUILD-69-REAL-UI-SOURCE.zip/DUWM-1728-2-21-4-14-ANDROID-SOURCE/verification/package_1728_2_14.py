#!/usr/bin/env python3
"""Package exact /14 source and a matching, independently gated GitHub workflow.

Usage (from this recovered workspace):
  python3 verification/package_1728_2_14.py

Optional --baseline paths let this generator run after moving the project. The known
/10, /11, /12 and /13 sources must be supplied. The
workflow can subsequently restore /14 from any one if the /14 ZIP is absent.
This script never edits app code, changes version fields, or marks tests passed.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile
import tempfile
import xml.etree.ElementTree as ET
import zipfile

import yaml

SOURCE_NAME = 'DUWM-1728.2-14-EXPORT-RECOVERY-SOURCE.zip'
WORKFLOW_NAME = 'DUWM-1728.2-14-EXPORT-RECOVERY-APK.yml'
SOURCE_FOLDER = 'DUWM-1728-2-14-ANDROID-SOURCE'
MANIFEST_NAME = '1728_2_14_SOURCE_SHA256.json'
KNOWN_BASELINES = {
    'DUWM-1728.2-13-BROADCAST-CONTROLS-SOURCE.zip':
        '2bedae2dd91869b7e74c88e8b10877c94bcae1eae6bbf7c74630ec332e6cda3f',
    'DUWM-1728.2-10-BROADCAST-TIMING-OUTPUT-CHECKS-SOURCE.zip':
        'a9f98fc58040b8d8159b798aecdf9de7e60d5e5f39207ba3a2b30466059f3b0e',
    'DUWM-1728.2-11-FRAMING-CONTROLS-SOURCE.zip':
        '69bc048391d8b5b9113d5198c3a4a75a3e22d0bfe7484b30716858f61784e347',
    'DUWM-1728.2-12-BROADCAST-REVIEW-SOURCE.zip':
        'eef462e29c12fdbd2d49a7241c4d794f0107a781d4c3ea5326fe573455125c14',
}
SKIP_DIRS = {'.git', '.gradle', '.idea', '__pycache__', '.pytest_cache',
             '.mypy_cache', '.ruff_cache', 'node_modules', 'build'}
FIXED_DATE = (2026, 11, 7, 0, 0, 0)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def include_file(path: Path, root: Path) -> bool:
    relative = path.relative_to(root)
    parts = relative.parts
    if any(part in SKIP_DIRS for part in parts):
        return False
    if parts[:2] == ('verification', 'results') or parts[0] == '.github':
        return False
    if relative.as_posix() in {MANIFEST_NAME, 'local.properties'}:
        return False
    return path.name != '.DS_Store' and path.suffix not in {'.pyc', '.class', '.apk', '.aab'}


def source_snapshot(root: Path) -> dict[str, bytes]:
    files = {}
    for path in sorted(root.rglob('*')):
        if not path.is_file() or not include_file(path, root):
            continue
        if path.is_symlink():
            raise ValueError(f'Package source must not be a symlink: {path}')
        files[path.relative_to(root).as_posix()] = path.read_bytes()
    return files


def require_current_identity(root: Path) -> None:
    build = (root / 'app/build.gradle.kts').read_text()
    assert re.search(r'versionCode\s*=\s*172814\b', build), 'Set actual app versionCode to 172814 before packaging'
    assert re.search(r'versionName\s*=\s*"1728\.2\.14"', build), 'Set actual app versionName to 1728.2.14 before packaging'
    ui = json.loads((root / 'app/src/main/assets/duwm_release_ui.json').read_text())
    assert ui['uiRevision'] == '1728.2.14' and ui['uiVersionCode'] == 172814, 'UI identity must match /14'
    strings = ET.parse(root / 'app/src/main/res/values/strings.xml').getroot()
    names = [el.text for el in strings.findall('string') if el.get('name') == 'app_name']
    assert names == ['DUWM 1728.2/14 • DEVELOP.UGANDA'], 'Launcher label must identify the actual /14 build'
    for name in ('verification/check_1728_2_14.py', '1728_2_14_BUILD_NOTES.md', '1728_2_14_ACCEPTANCE.json'):
        assert (root / name).is_file(), f'Required /14 file missing: {name}'


def archive_files(path: Path) -> dict[str, bytes]:
    raw = path.read_bytes()
    assert path.name in KNOWN_BASELINES, f'Unknown baseline filename: {path.name}'
    assert digest(raw) == KNOWN_BASELINES[path.name], f'Baseline bytes do not match the verified source: {path.name}'
    result = {}
    roots = set()
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        assert archive.testzip() is None, f'Corrupt baseline ZIP: {path.name}'
        for info in archive.infolist():
            if info.is_dir():
                continue
            entry = PurePosixPath(info.filename)
            assert not entry.is_absolute() and '..' not in entry.parts and len(entry.parts) >= 2, 'Unsafe baseline archive member'
            assert not stat.S_ISLNK(info.external_attr >> 16), 'Symlinks are not source files'
            roots.add(entry.parts[0])
            name = PurePosixPath(*entry.parts[1:]).as_posix()
            assert name not in result, f'Duplicate source member: {name}'
            result[name] = archive.read(info)
    assert len(roots) == 1, 'A source ZIP must contain exactly one project root'
    return result


def make_zip(files: dict[str, bytes]) -> bytes:
    data = io.BytesIO()
    with zipfile.ZipFile(data, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, payload in sorted(files.items()):
            info = zipfile.ZipInfo(SOURCE_FOLDER + '/' + name, FIXED_DATE)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            mode = 0o755 if name.endswith('.sh') else 0o644
            info.external_attr = (stat.S_IFREG | mode) << 16
            archive.writestr(info, payload)
    return data.getvalue()


def make_patch(files: dict[str, bytes], baselines: dict[str, dict[str, bytes]]) -> tuple[bytes, list[str]]:
    # A union patch must be sufficient for every permitted predecessor, not just
    # whichever source happens to exist on the packaging machine.
    changed = sorted(name for name, payload in files.items()
                     if any(old.get(name) != payload for old in baselines.values()))
    data = io.BytesIO()
    with tarfile.open(fileobj=data, mode='w:xz', preset=9) as archive:
        for name in changed:
            info = tarfile.TarInfo(name)
            info.size = len(files[name])
            info.mtime = 0
            info.mode = 0o755 if name.endswith('.sh') else 0o644
            archive.addfile(info, io.BytesIO(files[name]))
    return data.getvalue(), changed


RESTORE = r'''set -euo pipefail
python3 - <<'PY_RESTORE'
import pathlib,os,hashlib,json,zipfile,tarfile,base64,io,shutil,stat
root=pathlib.Path(os.environ['RUNNER_TEMP'])/'duwm1728214'
root.mkdir(parents=True,exist_ok=True)
project=root/'DUWM-1728-2-14-ANDROID-SOURCE'
if project.exists():shutil.rmtree(project)
project.mkdir()
full=pathlib.Path('DUWM-1728.2-14-EXPORT-RECOVERY-SOURCE.zip')
expected_full=__FULL_SHA__
parents=__PARENTS__
def safe_target(name):
    rel=pathlib.PurePosixPath(name)
    if rel.is_absolute() or '..' in rel.parts or not rel.parts:raise ValueError('Unsafe source path')
    target=project.joinpath(*rel.parts)
    if not target.resolve().is_relative_to(project.resolve()):raise ValueError('Escaping source path')
    return target
def unzip_project(archive):
    roots=set();seen=set()
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None,'Corrupt source ZIP'
        for info in z.infolist():
            if info.is_dir():continue
            rel=pathlib.PurePosixPath(info.filename)
            if rel.is_absolute() or '..' in rel.parts or len(rel.parts)<2:raise ValueError('Unsafe ZIP member')
            if stat.S_ISLNK(info.external_attr>>16):raise ValueError('Source symlink rejected')
            roots.add(rel.parts[0]);name='/'.join(rel.parts[1:])
            if name in seen:raise ValueError('Duplicate ZIP member')
            seen.add(name);target=safe_target(name);target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(z.read(info))
        assert len(roots)==1,'Expected one source project root'
if full.is_file():
    assert hashlib.sha256(full.read_bytes()).hexdigest()==expected_full,'The /14 source ZIP and workflow must be a matching pair'
    unzip_project(full)
else:
    baseline=None
    for name,expected_hash in parents.items():
        p=pathlib.Path(name)
        if p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==expected_hash:baseline=p;break
    if baseline is None:raise SystemExit('Upload the matching /14 SOURCE.zip to repository root; no exact /10, /11, /12 or /13 baseline is present')
    print('Recovering exact /14 source from',baseline)
    unzip_project(baseline)
    patch=base64.b64decode(''.join(os.environ['DUWM_PATCH_%03d'%i] for i in range(__CHUNKS__)),validate=True)
    assert hashlib.sha256(patch).hexdigest()==__PATCH_SHA__,'Embedded patch hash mismatch'
    with tarfile.open(fileobj=io.BytesIO(patch),mode='r:xz') as tar:
        seen=set()
        for member in tar.getmembers():
            if not member.isfile() or member.name in seen:raise ValueError('Only unique regular patch files allowed')
            seen.add(member.name);target=safe_target(member.name);target.parent.mkdir(parents=True,exist_ok=True)
            with tar.extractfile(member) as data:target.write_bytes(data.read())
manifest=project/'1728_2_14_SOURCE_SHA256.json'
assert hashlib.sha256(manifest.read_bytes()).hexdigest()==__MANIFEST_SHA__,'Source manifest mismatch'
expected=json.loads(manifest.read_text())
# Remove only obsolete files in this isolated restored tree, never the repository.
for p in list(project.rglob('*')):
    if p.is_file() and p!=manifest and p.relative_to(project).as_posix() not in expected:p.unlink()
for name,want in expected.items():
    p=safe_target(name)
    assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==want,'Source integrity failed: '+name
actual={p.relative_to(project).as_posix() for p in project.rglob('*') if p.is_file()}
assert actual==set(expected)|{manifest.name},'Unexpected source files after restoration'
print('PASS exact /14 source:',len(expected),'packaged file hashes')
with open(os.environ['GITHUB_ENV'],'a') as env:env.write('PROJECT='+str(project)+'\n')
PY_RESTORE
'''

NATIVE = r'''set -euo pipefail
cp tests/run_native_stages.sh "$RUNNER_TEMP/duwm-native.sh"
cp tests/verify_native_stages.py "$RUNNER_TEMP/verify_native_stages.py"
chmod +x "$RUNNER_TEMP/duwm-native.sh"
bash -n "$RUNNER_TEMP/duwm-native.sh"
'''



def upgrade_strings(value):
    if isinstance(value, dict):
        return {upgrade_strings(k): upgrade_strings(v) for k, v in value.items()}
    if isinstance(value, list):
        return [upgrade_strings(v) for v in value]
    if not isinstance(value, str):
        return value
    for old, new in [('1728.2/11', '1728.2/14'), ('1728.2.11', '1728.2.14'),
                     ('1728.2-11', '1728.2-14'), ('1728_2_11', '1728_2_14'),
                     ('1728-2-11', '1728-2-14'), ('1728211', '1728214'),
                     ('172811', '172814'), ('FRAMING-CONTROLS', 'EXPORT-RECOVERY')]:
        value = value.replace(old, new)
    return value


class WorkflowDumper(yaml.SafeDumper):
    pass


def represent_string(dumper, data):
    return dumper.represent_scalar('tag:yaml.org,2002:str', data, style='|' if '\n' in data else None)


WorkflowDumper.add_representer(str, represent_string)


def build_workflow(root: Path, full: bytes, patch: bytes, manifest: bytes):
    template = json.loads((root / 'verification/ci_broadcast_workflow_template.json').read_text())
    flow = upgrade_strings(template)
    flow['name'] = 'DUWM 1728.2/14 | Retained broadcast exports and staged native proof'
    flow['run-name'] = 'DUWM 1728.2/14 | Compile and verify retained exports and recovery'
    flow['on']['push']['branches'] = ['main', 'build/duwm-1728-2-14']
    flow['on']['push']['paths'] = ['.github/workflows/' + WORKFLOW_NAME, SOURCE_NAME]
    job = flow['jobs']['compile-development']
    job['env'] = {'BUILD_LOG_DIR': '${{ runner.temp }}/duwm1728214-logs'}
    encoded = base64.b64encode(patch).decode('ascii')
    chunks = [encoded[i:i+12000] for i in range(0, len(encoded), 12000)]
    restore = RESTORE
    for old, new in [('__FULL_SHA__', repr(digest(full))), ('__PARENTS__', repr(KNOWN_BASELINES)),
                     ('__CHUNKS__', str(len(chunks))), ('__PATCH_SHA__', repr(digest(patch))),
                     ('__MANIFEST_SHA__', repr(digest(manifest)))]:
        restore = restore.replace(old, new)
    steps = job['steps']
    restore_step = steps[1]
    assert restore_step['run'] == '__GENERATED_RESTORE__'
    restore_step.update(name='Restore exact /14 source or checked patch over /10, /11, /12 or /13', run=restore,
                        env={f'DUWM_PATCH_{i:03d}': chunk for i, chunk in enumerate(chunks)})
    for step in steps:
        if step.get('name', '').startswith('Test framing,'):
            step['name'] = 'Test /14 recovery, trim, framing, timing, privacy and service contracts'
        if step.get('name') == 'Publish scoped host-render evidence':
            step['with']['path'] = '${{ env.PROJECT }}/verification/results/1728_2_14/'
    for step in steps:
        if step.get('name') == 'Assemble real application and instrumentation APKs':
            step['run'] += 'cp verification/run_native_stages.sh verification/verify_native_stages.py "$RUNNER_TEMP/duwm-native-test/"\n'
        if step.get('name') == 'Verify actual APK identity, signature and compiled components':
            step['run'] = step['run'].replace("b'shareIntent')", "b'shareIntent',b'Duwm1728EditorTrimPolicy',b'Duwm1728BroadcastReviewState',b'Duwm1728ExportRecovery',b'Duwm1728ExportRecoveryActivity',b'Duwm1728ExportRecoveryProvider')")
    flow['jobs']['native-broadcast-tests']['timeout-minutes'] = 60
    for step in flow['jobs']['native-broadcast-tests']['steps']:
        if step.get('name') == 'Prepare persistent native test and evidence script':
            step['run'] = NATIVE
        if step.get('uses', '').startswith('reactivecircus/android-emulator-runner@'):
            step['name'] = 'Required nine native stages with exact APK and evidence verification'
            step['with']['script'] = 'bash "$RUNNER_TEMP/duwm-native.sh" apk/DUWM-1728.2-14-EXPORT-RECOVERY.apk tests/DUWM-native-tests.apk native-evidence'
    for job in flow['jobs'].values():
        for step in job['steps']:
            assert len(step.get('run', '')) < 20000, 'GitHub run block exceeds the size budget'
            assert step.get('continue-on-error') not in {True, 'true'}, 'Required gates must fail the workflow'
    text = yaml.dump(flow, Dumper=WorkflowDumper, sort_keys=False, allow_unicode=True, width=120)
    assert yaml.safe_load(text) == flow, 'Workflow round trip changed values'
    assert len(text.encode()) < 1_000_000, 'Workflow is too large; inspect the patch selection'
    return flow, text, len(chunks)


def verify_recovery(workflow, files, full_path, baseline_paths):
    step = workflow['jobs']['compile-development']['steps'][1]
    shell_steps = [s['run'] for job in workflow['jobs'].values() for s in job['steps'] if 'run' in s]
    for code in shell_steps:
        subprocess.run(['bash', '-n'], input=code, text=True, check=True)
    modes = [('full source ZIP', full_path), *((p.name, p) for p in baseline_paths)]
    outcomes = []
    for mode, source in modes:
        with tempfile.TemporaryDirectory(prefix='duwm14-recovery-') as temp:
            work = Path(temp)
            (work / source.name).symlink_to(source.resolve())
            environment = {**os.environ, **step['env'], 'RUNNER_TEMP': str(work / 'runtime'), 'GITHUB_ENV': str(work / 'env')}
            result = subprocess.run(['bash', '-c', step['run']], cwd=work, env=environment,
                                    capture_output=True, text=True, check=True)
            project = Path((work / 'env').read_text().split('PROJECT=', 1)[1].strip())
            actual = {p.relative_to(project).as_posix(): p.read_bytes()
                      for p in project.rglob('*') if p.is_file()}
            assert actual == files, f'Restored bytes differ from the full /14 source: {mode}'
            outcomes.append({'route': mode, 'result': 'exact source match', 'files': len(actual)})
            print(result.stdout.strip())
    # Execute the actual generated restoration code against a broken full ZIP.
    # A corrupt upload must fail instead of quietly using a different version.
    with tempfile.TemporaryDirectory(prefix='duwm14-reject-') as temp:
        work = Path(temp)
        (work / SOURCE_NAME).write_bytes(b'not the matching source archive')
        environment = {**os.environ, **step['env'], 'RUNNER_TEMP': str(work / 'runtime'), 'GITHUB_ENV': str(work / 'env')}
        result = subprocess.run(['bash', '-c', step['run']], cwd=work, env=environment,
                                capture_output=True, text=True)
        assert result.returncode != 0 and 'matching pair' in result.stderr, 'Corrupt /14 source must fail closed'
    outcomes.append({'route': 'mismatched full source', 'result': 'rejected'})
    return outcomes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--output-dir', type=Path)
    parser.add_argument('--baseline', action='append', type=Path)
    args = parser.parse_args()
    root = args.project.resolve()
    output = (args.output_dir or root.parent / 'deliverables_1728_2_14').resolve()
    assert not output.is_relative_to(root), 'Deliverables must be outside the source tree'
    recovered = root.parent / 'recovered'
    paths = args.baseline or [recovered / 'DUWM-1728.2-10' / 'DUWM-1728.2-10-BROADCAST-TIMING-OUTPUT-CHECKS-SOURCE.zip',
                             recovered / 'DUWM-1728.2-11-FRAMING-CONTROLS-SOURCE.zip',
                             root.parent / 'deliverables_1728_2_12' / 'DUWM-1728.2-12-BROADCAST-REVIEW-SOURCE.zip',
                             root.parent / 'deliverables_1728_2_13' / 'DUWM-1728.2-13-BROADCAST-CONTROLS-SOURCE.zip']
    assert len(paths) == 4 and {p.name for p in paths} == set(KNOWN_BASELINES), 'Exact /10, /11, /12 and /13 source baselines are required'
    baselines = {p.name: archive_files(p) for p in paths}
    require_current_identity(root)
    files = source_snapshot(root)
    hashes = {name: digest(data) for name, data in files.items()}
    manifest = (json.dumps(hashes, indent=2, sort_keys=True) + '\n').encode()
    (root / MANIFEST_NAME).write_bytes(manifest)
    files[MANIFEST_NAME] = manifest
    full = make_zip(files)
    patch, changed = make_patch(files, baselines)
    workflow, yaml_text, chunk_count = build_workflow(root, full, patch, manifest)
    output.mkdir(parents=True, exist_ok=True)
    full_path = output / SOURCE_NAME
    full_path.write_bytes(full)
    (output / WORKFLOW_NAME).write_text(yaml_text)
    outcomes = verify_recovery(workflow, files, full_path, paths)
    assert source_snapshot(root) == {k: v for k, v in files.items() if k != MANIFEST_NAME}, 'Source changed during packaging; regenerate after edits finish'
    report = {
        'build': '1728.2/14', 'version_code': 172814,
        'verification_scope': 'packaging, exact predecessor recovery, shell syntax and identity only; Android compile and native tests run separately',
        'source_zip': {'name': SOURCE_NAME, 'bytes': len(full), 'sha256': digest(full)},
        'workflow': {'name': WORKFLOW_NAME, 'bytes': len(yaml_text.encode()), 'sha256': digest(yaml_text.encode()),
                     'maximum_run_characters': max(len(s.get('run', '')) for j in workflow['jobs'].values() for s in j['steps'])},
        'manifest_sha256': digest(manifest), 'source_files': len(files),
        'baseline_sha256': KNOWN_BASELINES, 'patch_sha256': digest(patch),
        'patch_bytes': len(patch), 'patch_env_chunks': chunk_count, 'patch_files': changed,
        'recovery_checks': outcomes,
    }
    (output / '1728_2_14_PACKAGE_VERIFICATION.json').write_text(json.dumps(report, indent=2) + '\n')
    (output / 'SHA256SUMS.txt').write_text(f'{digest(full)}  {SOURCE_NAME}\n{digest(yaml_text.encode())}  {WORKFLOW_NAME}\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'patch_files'}, indent=2))


if __name__ == '__main__':
    main()
