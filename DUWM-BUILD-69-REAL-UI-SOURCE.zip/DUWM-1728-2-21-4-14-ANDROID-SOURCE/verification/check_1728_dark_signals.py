#!/usr/bin/env python3
"""Current visual contract + EXECUTED production colour/motion policy.
Android drawing/installation is a distinct CI/device test, not claimed here.
"""
from pathlib import Path
import json, re, hashlib, subprocess, tempfile, shutil, xml.etree.ElementTree as ET
p=Path(__file__).resolve().parents[1]
j=p/'app/src/main/java/com/sentongoharuna/worldsituationroom'
read=lambda n:(j/n).read_text()
theme=read('DuwmUnifiedTheme.java'); lamp=read('Duwm1728StatusLampView.java')
rail=read('Duwm1715SignalLights.java'); globe=read('SatelliteMapView.java')
assert 'BACKGROUND = 0xFF041424' in theme and 'BORDER = 0xFFDEE5EF' in theme
assert 'MAP_COAST = 0xFF28547A' in theme and 'MAP_RIM = 0xFF184472' in theme
assert 'setStage(state.stage,i,true)' in rail and 'v.animate().alpha' not in rail
assert 'setStroke(dp(c,1),Color.rgb(222,229,239))' not in rail
assert 'REFRESH_MS = 2_000L' in rail
assert 'bindSector(index)' in rail and 'new Duwm1728StatusLampView' in rail
assert 'ValueAnimator.areAnimatorsEnabled()' in lamp
assert 'onWindowVisibilityChanged' in lamp and 'onDetachedFromWindow' in lamp
assert 'removeCallbacks(frame)' in lamp and 'getWindowVisibility() == VISIBLE' in lamp
assert 'ink.setAlpha(255)' in lamp and 'setAlpha(1f)' in lamp
assert 'stage == Duwm1724SignalFlow.Stage.LOCAL' in lamp and 'Paint.Style.STROKE' in lamp
assert 'showStaticColor' in lamp and 'animateStatus = false' in lamp
assert 'Color.rgb(27, 57, 109)' not in globe and 'Color.argb(213, 139, 168, 228)' not in globe
assert 'DuwmUnifiedTheme.MAP_COAST' in globe and 'DuwmUnifiedTheme.MAP_OCEAN' in globe
assert 'stageForLayer(layer,status)' in globe
assert 'worldStatusLamp1728.setStage(worst,197,true)' in read('MainActivity.java')
assert read('MainActivity.java').count('new SatelliteMapView(this)')==1
assert 'Duwm1715SignalLights.attach(a)' in read('DuWorldApplication.java')
assert 'boolean animate=false' not in read('Duwm1166SignalView.java')
assert 'Color.rgb(85, 139, 223)' not in read('DuwmSignalRail.java')
assert 'DuwmUnifiedTheme.STATUS_RED' in read('SignalBeaconView.java')
from release_contract import assert_release_at_least
assert_release_at_least(p,1728)
meta=json.loads((p/'app/src/main/assets/duwm_release_ui.json').read_text())
assert meta['uiRevision'] in ('1728.2.6','1728.2.7')
assert meta['uiVersionCode']==(172806 if meta['uiRevision']=='1728.2.6' else 172807)
for name,expected in json.loads((p/'verification/1728_2_5_camera_baseline.json').read_text()).items():
    if name=='Duwm1718MonitorsCamActivity.java' and meta['uiRevision']=='1728.2.7':
        amendment=json.loads((p/'1728_2_7_INTENTIONAL_CHANGES.json').read_text())
        item=amendment['app/src/main/java/com/sentongoharuna/worldsituationroom/'+name]
        assert item['before']==expected,'Camera changes must descend from the exact previous checkpoint'
        expected=item['after']
    assert hashlib.sha256((j/name).read_bytes()).hexdigest()==expected,('unapproved camera/editor change',name)
xml=list((p/'app/src/main').rglob('*.xml'))
for f in xml:ET.parse(f)
# Only the enum dependency is extracted into a test fixture. All decision and
# animation algorithms compiled here are the real app sources, not rewritten mocks.
with tempfile.TemporaryDirectory() as td:
    out=Path(td);pkg=out/'com/sentongoharuna/worldsituationroom';pkg.mkdir(parents=True)
    for name in ('FeedStatus.java','Duwm1724SignalFlow.java','DuwmUnifiedTheme.java','Duwm1728SignalMotion.java'):
        shutil.copyfile(j/name,pkg/name)
    enum=re.search(r'public enum Layer\s*\{([^}]+)\}',read('Signal.java')).group(1)
    (pkg/'Signal.java').write_text('package com.sentongoharuna.worldsituationroom; public final class Signal {public enum Layer {'+enum+'}}')
    shutil.copyfile(p/'verification/SignalMotionTest.java',pkg/'SignalMotionTest.java')
    subprocess.run(['javac','-d',td,*map(str,pkg.glob('*.java'))],check=True)
    subprocess.run(['java','-cp',td,'com.sentongoharuna.worldsituationroom.SignalMotionTest'],check=True)
print('PASS colour wiring, solid cores, lifecycle, retained editor and explicitly hash-audited camera changes, single globe, identity and',len(xml),'XML files')
print('NOT VERIFIED HERE: full Android compilation, phone appearance, provider connectivity or camera/video output')
