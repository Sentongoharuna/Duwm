#!/usr/bin/env bash
set -euo pipefail
clear_project="$(cd "$(dirname "$0")/.." && pwd)"
clear_proof="${1:-$clear_project/verification/clear-picture-layout-host-proof}"
clear_javac="${JAVAC:-${JAVA_HOME:+$JAVA_HOME/bin/}javac}"
clear_java="${JAVA:-${JAVA_HOME:+$JAVA_HOME/bin/}java}"
clear_build="$(mktemp -d "${TMPDIR:-/tmp}/duwm-clear-picture-layout.XXXXXX")"
trap 'rm -rf -- "$clear_build"' EXIT
clear_source="$clear_project/app/src/main/java/com/sentongoharuna/worldsituationroom"
"$clear_javac" --release 17 -encoding UTF-8 -d "$clear_build" \
  "$clear_source/Duwm1728BroadcastComposition.java" "$clear_source/Duwm1728BroadcastLayout.java" \
  "$clear_source/Duwm1728ClearPictureLayout.java" "$clear_source/Duwm1728HeadlineFit.java" \
  "$clear_source/Duwm1728CaptionPages.java" \
  "$clear_project/verification/broadcast/BroadcastRenderTest.java" \
  "$clear_project/verification/broadcast/ClearPictureLayoutTest.java"
"$clear_java" -Xmx512m -Djava.awt.headless=true -cp "$clear_build" \
  com.sentongoharuna.worldsituationroom.ClearPictureLayoutTest "$clear_proof"
