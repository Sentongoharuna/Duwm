#!/usr/bin/env python3
"""Executable host regressions plus preservation. Not an Android/API compilation claim."""
from pathlib import Path
import hashlib,json,subprocess,tempfile,xml.etree.ElementTree as ET,shutil,re,sys
root=Path(__file__).resolve().parents[1]
java=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
from release_contract import assert_release_at_least
assert assert_release_at_least(root,1728)==172810
ui=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1728.2.10' and ui['uiVersionCode']==172810
protected=json.loads((root/'verification/1728_2_9_PRESERVED_JAVA.json').read_text())
for name,digest in protected.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
assert any(n.endswith('SatelliteMapView.java') for n in protected)
assert any(n.endswith('Duwm1718MonitorsCamActivity.java') for n in protected)
print('PASS',len(protected),'unchanged /9 Java components, including original globe and clean camera.')
for file in (root/'app/src').rglob('*.xml'):ET.parse(file)
editor=(java/'Duwm1728VideoEditorActivity.java').read_text();renderer=(java/'Duwm1728OverlayRenderer.java').read_text()
assert 'parseSrtCues' in editor and 'convertSrt(text)' not in editor
assert 'Duwm1728ExportPreflight.inspect' in editor and 'Duwm1728ExportPreflight.inspect' in renderer
assert 'outputPlan!=null' in editor and 'prepareTimelines(s)' in editor
assert 'sourceAtProgress' in editor and 'ticker_origin_ms' in editor
assert 'clipEnd-clipStart' in editor and 'caption_timebase' in editor
assert 'renderedCaptions' in renderer and 'renderedTickers' in renderer
assert '45000L' not in renderer and 'fps=24' not in renderer
assert 'planWorker.shutdownNow()' in editor and 'main.removeCallbacks(planKick)' in editor
assert 'startAi(spec())' not in editor
proof=root/'verification/results/1728_2_10';proof.mkdir(parents=True,exist_ok=True)
subprocess.run([sys.executable,str(root/'verification/check_ai_entrypoints.py')],check=True)
with tempfile.TemporaryDirectory() as temp:
    sources=['Duwm1728BroadcastLayout.java','Duwm1728BroadcastTimeline.java','Duwm1728TickerTimeline.java','Duwm1728SubtitleImport.java']
    subprocess.run(['javac','--release','17','-d',temp,*[str(java/n) for n in sources],str(root/'verification/broadcast/BroadcastRenderTest.java'),str(root/'verification/broadcast/BroadcastTimelineTest.java')],check=True)
    for name,args in [('BroadcastRenderTest',[str(proof)]),('BroadcastTimelineTest',[])]:
        result=subprocess.run(['java','-Djava.awt.headless=true','-cp',temp,'com.sentongoharuna.worldsituationroom.'+name,*args],capture_output=True,text=True,check=True)
        print(result.stdout,end='');(proof/(name+'.txt')).write_text(result.stdout)
    pkg=Path(temp)/'src/com/sentongoharuna/worldsituationroom';pkg.mkdir(parents=True)
    for name in ('FeedStatus.java','Duwm1724SignalFlow.java','DuwmUnifiedTheme.java','Duwm1728SignalMotion.java','Duwm1728CaptureHealth.java'):
        shutil.copyfile(java/name,pkg/name)
    layer=re.search(r'public enum Layer\s*\{([^}]+)\}',(java/'Signal.java').read_text()).group(1)
    (pkg/'Signal.java').write_text('package com.sentongoharuna.worldsituationroom; public final class Signal {public enum Layer {'+layer+'}}')
    for name in ('SignalMotionTest.java','CaptureHealthTest.java'):shutil.copyfile(root/'verification'/name,pkg/name)
    subprocess.run(['javac','--release','17','-d',temp,*map(str,pkg.glob('*.java'))],check=True)
    for name in ('SignalMotionTest','CaptureHealthTest'):
        result=subprocess.run(['java','-cp',temp,'com.sentongoharuna.worldsituationroom.'+name],capture_output=True,text=True,check=True)
        print(result.stdout,end='');(proof/(name+'.txt')).write_text(result.stdout)
print('PASS /10 wiring, exact identity and XML. Android compilation, new native exports, physical phone and live AI remain separate gates.')
