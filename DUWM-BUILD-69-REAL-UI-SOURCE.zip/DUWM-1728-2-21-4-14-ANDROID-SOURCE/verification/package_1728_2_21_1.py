#!/usr/bin/env python3
"""Package exact /21/1 source and a matching, independently gated GitHub workflow.

Usage (from this recovered workspace):
  python3 verification/package_1728_2_21_1.py

Optional --baseline paths let this generator run after moving the project. The exact delivered /21 and /20 sources must be supplied. The workflow can
restore /21/1 from either checked predecessor when the new source ZIP is absent.
This script never edits app code, changes version fields, or marks tests passed.
"""
from __future__ import annotations

import argparse
import ast
import base64
import copy
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import runpy
import stat
import subprocess
import tarfile
import tempfile
import xml.etree.ElementTree as ET
import zipfile

SOURCE_NAME = 'DUWM-1728.2-21-1-SCENE-VISION-SOURCE.zip'
WORKFLOW_NAME = 'DUWM-1728.2-21-1-SCENE-VISION-APK.yml'
SOURCE_FOLDER = 'DUWM-1728-2-21-1-ANDROID-SOURCE'
MANIFEST_NAME = '1728_2_21_1_SOURCE_SHA256.json'
BASELINE20_MANIFEST_SHA256 = 'c7fca074cb2f7400272cc7355657bf6562243099744a17f391cca57734af95f5'
BASELINE21_MANIFEST_SHA256 = '716757857758af2469af34497acf1b64c0a364d517955cf54d92c2cd1d1be772'
KNOWN_BASELINES = {
    'DUWM-1728.2-21-AUTO-FIT-SOURCE.zip':
        '3117973d5e1cce4f0e257bf179a3c81bf91a5f903605c8b59fde524744558a2d',
    'DUWM-1728.2-20-AUTO-READY-SOURCE.zip':
        '600a819b4e3ce031c2c9bab6e91582300857467026a78a41262e683fa1761ca5',
}

SKIP_DIRS = {'.git', '.gradle', '.idea', '__pycache__', '.pytest_cache',
             '.mypy_cache', '.ruff_cache', 'node_modules', 'build'}
FIXED_DATE = (2026, 11, 7, 0, 0, 0)
EXPECTED_NATIVE_STAGES = ('signals', 'graphics', 'exports4', 'framing', 'inset1',
                          'review', 'editor_controls', 'review_controls', 'recovery',
                          'composition', 'caption_editing', 'caption_files', 'automatic_production', 'automatic_report', 'automatic_ready', 'automatic_fit', 'scene_timeline')
# Official tagged metadata for these minimum runtime migrations declares node24.
# Upload v5 and download v6 still declared node20; their next majors switch it.
NODE24_ACTIONS = {
    'actions/checkout@v4': 'actions/checkout@v5',
    'actions/setup-python@v5': 'actions/setup-python@v6',
    'actions/upload-artifact@v4': 'actions/upload-artifact@v6',
    'actions/download-artifact@v4': 'actions/download-artifact@v7',
    'gradle/actions/setup-gradle@v4': 'gradle/actions/setup-gradle@v5',
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def include_file(path: Path, root: Path) -> bool:
    relative = path.relative_to(root)
    parts = relative.parts
    if any(part in SKIP_DIRS for part in parts):
        return False
    if parts[:2] == ('verification', 'results') or parts[0] in {'.github', 'artifacts'}:
        return False
    if relative.as_posix() in {MANIFEST_NAME, 'local.properties'}:
        return False
    return path.name != '.DS_Store' and path.suffix not in {'.pyc', '.class', '.apk', '.aab'}


def source_snapshot(root: Path) -> dict[str, bytes]:
    files = {}
    for path in sorted(root.rglob('*')):
        if not path.is_file() or not include_file(path, root):
            continue
        if path.is_symlink():
            raise ValueError(f'Package source must not be a symlink: {path}')
        files[path.relative_to(root).as_posix()] = path.read_bytes()
    return files


def require_current_identity(root: Path) -> None:
    build = (root / 'app/build.gradle.kts').read_text()
    assert re.search(r'versionCode\s*=\s*172822\b', build), 'Set actual app versionCode to 172822 before packaging'
    assert re.search(r'versionName\s*=\s*"1728\.2\.21\.1"', build), 'Set actual app versionName to 1728.2.21.1 before packaging'
    ui = json.loads((root / 'app/src/main/assets/duwm_release_ui.json').read_text())
    assert ui['uiRevision'] == '1728.2.21.1' and ui['uiVersionCode'] == 172822, 'UI identity must match /21/1'
    strings = ET.parse(root / 'app/src/main/res/values/strings.xml').getroot()
    names = [el.text for el in strings.findall('string') if el.get('name') == 'app_name']
    assert names == ['DUWM 1728.2/21/1 • DEVELOP.UGANDA'], 'Launcher label must identify the actual /21/1 build'
    assert digest((root / '1728_2_20_SOURCE_SHA256.json').read_bytes()) == BASELINE20_MANIFEST_SHA256, 'Immutable delivered /20 source manifest changed'
    assert digest((root / '1728_2_21_SOURCE_SHA256.json').read_bytes()) == BASELINE21_MANIFEST_SHA256, 'Immutable delivered /21 source manifest changed'
    assert re.search(r'minSdk\s*=\s*26\b', build), 'The real ML Kit SDK requires the declared API 26 baseline'
    assert 'implementation("com.google.mlkit:genai-image-description:1.0.0-beta1")' in build, 'Real pinned SDK dependency missing'
    assert 'android.useAndroidX=true' in (root / 'gradle.properties').read_text(), 'SDK AndroidX integration missing'
    for name in ('verification/check_1728_2_21_1.py', 'verification/preserved_sources_1728_2_21_1.json', '1728_2_21_1_BUILD_NOTES.md', '1728_2_21_1_ACCEPTANCE.json'):
        assert (root / name).is_file(), f'Required /21/1 file missing: {name}'


def archive_files(path: Path) -> dict[str, bytes]:
    raw = path.read_bytes()
    assert path.name in KNOWN_BASELINES, f'Unknown baseline filename: {path.name}'
    assert digest(raw) == KNOWN_BASELINES[path.name], f'Baseline bytes do not match the verified source: {path.name}'
    result = {}
    roots = set()
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        assert archive.testzip() is None, f'Corrupt baseline ZIP: {path.name}'
        for info in archive.infolist():
            if info.is_dir():
                continue
            entry = PurePosixPath(info.filename)
            assert not entry.is_absolute() and '..' not in entry.parts and len(entry.parts) >= 2, 'Unsafe baseline archive member'
            assert not stat.S_ISLNK(info.external_attr >> 16), 'Symlinks are not source files'
            roots.add(entry.parts[0])
            name = PurePosixPath(*entry.parts[1:]).as_posix()
            assert name not in result, f'Duplicate source member: {name}'
            result[name] = archive.read(info)
    assert len(roots) == 1, 'A source ZIP must contain exactly one project root'
    return result


def make_zip(files: dict[str, bytes]) -> bytes:
    data = io.BytesIO()
    with zipfile.ZipFile(data, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, payload in sorted(files.items()):
            info = zipfile.ZipInfo(SOURCE_FOLDER + '/' + name, FIXED_DATE)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            mode = 0o755 if name.endswith('.sh') else 0o644
            info.external_attr = (stat.S_IFREG | mode) << 16
            archive.writestr(info, payload)
    return data.getvalue()


def make_patch(files: dict[str, bytes], baselines: dict[str, dict[str, bytes]]) -> tuple[bytes, list[str]]:
    # A union patch must be sufficient for every permitted predecessor, not just
    # whichever source happens to exist on the packaging machine.
    changed = sorted(name for name, payload in files.items()
                     if any(old.get(name) != payload for old in baselines.values()))
    data = io.BytesIO()
    with tarfile.open(fileobj=data, mode='w:xz', preset=9) as archive:
        for name in changed:
            info = tarfile.TarInfo(name)
            info.size = len(files[name])
            info.mtime = 0
            info.mode = 0o755 if name.endswith('.sh') else 0o644
            archive.addfile(info, io.BytesIO(files[name]))
    return data.getvalue(), changed


RESTORE = r'''set -euo pipefail
python3 - <<'PY_RESTORE'
import pathlib,os,hashlib,json,zipfile,tarfile,base64,io,shutil,stat
root=pathlib.Path(os.environ['RUNNER_TEMP'])/'duwm1728221-1'
root.mkdir(parents=True,exist_ok=True)
project=root/'DUWM-1728-2-21-1-ANDROID-SOURCE'
if project.exists():shutil.rmtree(project)
project.mkdir()
full=pathlib.Path('DUWM-1728.2-21-1-SCENE-VISION-SOURCE.zip')
expected_full=__FULL_SHA__
parents=__PARENTS__
def safe_target(name):
    rel=pathlib.PurePosixPath(name)
    if rel.is_absolute() or '..' in rel.parts or not rel.parts:raise ValueError('Unsafe source path')
    target=project.joinpath(*rel.parts)
    if not target.resolve().is_relative_to(project.resolve()):raise ValueError('Escaping source path')
    return target
def unzip_project(archive):
    roots=set();seen=set()
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None,'Corrupt source ZIP'
        for info in z.infolist():
            if info.is_dir():continue
            rel=pathlib.PurePosixPath(info.filename)
            if rel.is_absolute() or '..' in rel.parts or len(rel.parts)<2:raise ValueError('Unsafe ZIP member')
            if stat.S_ISLNK(info.external_attr>>16):raise ValueError('Source symlink rejected')
            roots.add(rel.parts[0]);name='/'.join(rel.parts[1:])
            if name in seen:raise ValueError('Duplicate ZIP member')
            seen.add(name);target=safe_target(name);target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(z.read(info))
        assert len(roots)==1,'Expected one source project root'
if full.is_file():
    assert hashlib.sha256(full.read_bytes()).hexdigest()==expected_full,'The /21/1 source ZIP and workflow must be a matching pair'
    unzip_project(full)
else:
    baseline=None
    for name,expected_hash in parents.items():
        p=pathlib.Path(name)
        if p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==expected_hash:baseline=p;break
    if baseline is None:raise SystemExit('Upload the matching /21 SOURCE.zip to repository root; no exact delivered /21 or /20 baseline is present')
    print('Recovering exact /21/1 source from',baseline)
    unzip_project(baseline)
    patch=base64.b64decode(''.join(os.environ['DUWM_PATCH_%03d'%i] for i in range(__CHUNKS__)),validate=True)
    assert hashlib.sha256(patch).hexdigest()==__PATCH_SHA__,'Embedded patch hash mismatch'
    with tarfile.open(fileobj=io.BytesIO(patch),mode='r:xz') as tar:
        seen=set()
        for member in tar.getmembers():
            if not member.isfile() or member.name in seen:raise ValueError('Only unique regular patch files allowed')
            seen.add(member.name);target=safe_target(member.name);target.parent.mkdir(parents=True,exist_ok=True)
            with tar.extractfile(member) as data:target.write_bytes(data.read())
manifest=project/'1728_2_21_1_SOURCE_SHA256.json'
assert hashlib.sha256(manifest.read_bytes()).hexdigest()==__MANIFEST_SHA__,'Source manifest mismatch'
expected=json.loads(manifest.read_text())
# Remove only obsolete files in this isolated restored tree, never the repository.
for p in list(project.rglob('*')):
    if p.is_file() and p!=manifest and p.relative_to(project).as_posix() not in expected:p.unlink()
for name,want in expected.items():
    p=safe_target(name)
    assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==want,'Source integrity failed: '+name
actual={p.relative_to(project).as_posix() for p in project.rglob('*') if p.is_file()}
assert actual==set(expected)|{manifest.name},'Unexpected source files after restoration'
print('PASS exact /21/1 source:',len(expected),'packaged file hashes')
with open(os.environ['GITHUB_ENV'],'a') as env:
    env.write('PROJECT='+str(project)+'\n')
    env.write('BUILD_LOG_DIR='+str(pathlib.Path(os.environ['RUNNER_TEMP'])/'duwm1728221-1-logs')+'\n')
PY_RESTORE
'''

NATIVE = r'''set -euo pipefail
cp tests/run_native_stages.sh "$RUNNER_TEMP/duwm-native.sh"
cp tests/verify_native_stages.py "$RUNNER_TEMP/verify_native_stages.py"
chmod +x "$RUNNER_TEMP/duwm-native.sh"
bash -n "$RUNNER_TEMP/duwm-native.sh"
'''



def upgrade_strings(value):
    if isinstance(value, dict):
        return {upgrade_strings(k): upgrade_strings(v) for k, v in value.items()}
    if isinstance(value, list):
        return [upgrade_strings(v) for v in value]
    if not isinstance(value, str):
        return value
    for old, new in [('1728.2/11', '1728.2/21/1'), ('1728.2.11', '1728.2.21.1'),
                     ('1728.2-11', '1728.2-21-1'), ('1728_2_11', '1728_2_21_1'),
                     ('1728-2-11', '1728-2-21-1'), ('1728211', '1728221-1'),
                     ('172811', '172822'), ('FRAMING-CONTROLS', 'SCENE-VISION')]:
        value = value.replace(old, new)
    return value


def validate_workflow_contexts(flow: dict) -> None:
    """Validate expression context scopes used by this generated workflow.

    This is a focused context-availability gate, not a substitute for GitHub's
    complete workflow/schema validator. Unsupported expression scopes fail closed.
    Source: https://docs.github.com/en/actions/reference/workflows-and-actions/contexts
    The actual /15 rejection was runner.temp in jobs.compile-development.env.
    """
    job_contexts = {'github', 'needs', 'strategy', 'matrix', 'vars', 'inputs'}
    step_contexts = job_contexts | {'job', 'runner', 'env', 'secrets', 'steps'}
    conditions = {'always', 'cancelled', 'success', 'failure'}
    special_functions = conditions | {'hashFiles'}

    def walk(value, path, allowed, special=(), implicit=False):
        if isinstance(value, dict):
            for key, child in value.items():
                walk(child, path + '.' + str(key), allowed, special, implicit)
        elif isinstance(value, list):
            for index, child in enumerate(value):
                walk(child, f'{path}[{index}]', allowed, special, implicit)
        elif isinstance(value, str):
            expressions = re.findall(r'\$\{\{(.*?)\}\}', value, re.S)
            assert len(expressions) == value.count('${{'), f'Unclosed expression at {path}'
            if implicit and not expressions:
                expressions = [value]
            for expression in expressions:
                # Single-quoted strings use doubled quotes for escaping in Actions.
                unquoted = re.sub(r"'(?:[^']|'')*'", "''", expression)
                contexts, functions = set(), set()
                for match in re.finditer(r'(?<![\w.-])([A-Za-z_][A-Za-z0-9_-]*)', unquoted):
                    name = match.group(1)
                    if unquoted[match.end():].lstrip().startswith('('):
                        functions.add(name)
                    elif name not in {'true', 'false', 'null'}:
                        contexts.add(name)
                assert not contexts - set(allowed), f'Unavailable context at {path}: {sorted(contexts - set(allowed))}'
                assert not (functions & special_functions) - set(special), f'Unavailable function at {path}: {sorted((functions & special_functions) - set(special))}'

    top_scopes = {'run-name': {'github', 'inputs', 'vars'},
                  'concurrency': {'github', 'inputs', 'vars'},
                  'env': {'github', 'secrets', 'inputs', 'vars'}}
    for key, value in flow.items():
        if key != 'jobs':
            walk(value, str(key), top_scopes.get(key, set()))
    for job_name, job in flow.get('jobs', {}).items():
        prefix = 'jobs.' + job_name
        job_scopes = {key: job_contexts for key in ('name', 'runs-on', 'timeout-minutes', 'continue-on-error', 'concurrency', 'with')}
        job_scopes.update(env=job_contexts | {'secrets'}, outputs=step_contexts,
                          strategy={'github', 'needs', 'vars', 'inputs'},
                          secrets=job_contexts | {'secrets'})
        for key, value in job.items():
            path = prefix + '.' + key
            if key == 'steps':
                for index, step in enumerate(value):
                    for step_key, step_value in step.items():
                        step_path = f'{path}[{index}].{step_key}'
                        if step_key == 'if':
                            walk(step_value, step_path, step_contexts - {'secrets'}, conditions | {'hashFiles'}, True)
                        elif step_key in {'name', 'env', 'run', 'with', 'timeout-minutes', 'continue-on-error', 'working-directory'}:
                            walk(step_value, step_path, step_contexts, {'hashFiles'})
                        else:
                            walk(step_value, step_path, set())
            elif key == 'if':
                walk(value, path, {'github', 'needs', 'vars', 'inputs'}, conditions, True)
            elif key == 'defaults':
                for default_key, default_value in value.items():
                    walk(default_value, path + '.' + default_key, job_contexts | {'env'} if default_key == 'run' else set())
            elif key == 'environment' and isinstance(value, dict):
                for environment_key, environment_value in value.items():
                    walk(environment_value, path + '.' + environment_key,
                         step_contexts - {'secrets'} if environment_key == 'url' else job_contexts)
            else:
                walk(value, path, job_contexts if key == 'environment' else job_scopes.get(key, set()))


def verify_context_guard() -> int:
    """Exercise the actual /15 startup failure and allowed runtime alternatives."""
    valid = {'run-name': '${{ github.workflow }}', 'env': {'CI_LABEL': '${{ vars.CI_LABEL }}'},
             'jobs': {'compile-development': {'runs-on': 'ubuntu-24.04',
                 'env': {'LITERAL': "${{ 'runner.temp' }}"},
                 'steps': [{'name': 'Runtime directory', 'env': {'STEP_TMP': '${{ runner.temp }}'},
                            'run': 'printf \'BUILD_LOG_DIR=%s\\n\' "$RUNNER_TEMP/duwm1728221-1-logs" >> "$GITHUB_ENV"'},
                           {'if': 'success()', 'uses': 'actions/upload-artifact@v4',
                            'with': {'path': '${{ runner.temp }}/duwm1728221-1-logs'}}]}}}
    validate_workflow_contexts(valid)
    bad_values = ('${{ runner.temp }}/duwm1728215-logs', "${{ runner['temp'] }}",
                  '${{\nrunner.temp\n}}', '${{ toJSON(runner) }}', '${{ env.PROJECT }}')
    checks = 1
    for expression in bad_values:
        bad = copy.deepcopy(valid)
        bad['jobs']['compile-development']['env']['BUILD_LOG_DIR'] = expression
        try:
            validate_workflow_contexts(bad)
        except AssertionError as error:
            assert 'jobs.compile-development.env.BUILD_LOG_DIR' in str(error)
        else:
            raise AssertionError('Workflow context gate accepted unavailable job-env context')
        checks += 1
    for scope in ('workflow_env', 'job_if', 'job_defaults', 'step_if'):
        bad = copy.deepcopy(valid)
        job = bad['jobs']['compile-development']
        if scope == 'workflow_env':
            bad['env']['LOGS'] = '${{ runner.temp }}'
        elif scope == 'job_if':
            job['if'] = "${{ runner.os == 'Linux' }}"
        elif scope == 'job_defaults':
            job['defaults'] = {'run': {'working-directory': '${{ runner.temp }}'}}
        else:
            job['steps'][0]['if'] = "${{ secrets.KEY != '' }}"
        try:
            validate_workflow_contexts(bad)
        except AssertionError as error:
            assert 'Unavailable context' in str(error)
        else:
            raise AssertionError('Workflow context gate accepted invalid ' + scope)
        checks += 1
    return checks


def require_native_contract(root: Path) -> None:
    """Packaging requires all seventeen stages; this does not execute Android tests."""
    tree = ast.parse((root / 'verification/verify_native_stages.py').read_text())
    assignments = {target.id: node.value for node in tree.body if isinstance(node, ast.Assign)
                   for target in node.targets if isinstance(target, ast.Name)}
    stages = ast.literal_eval(assignments['STAGES'])
    assert tuple(stages) == EXPECTED_NATIVE_STAGES, 'Native verifier must require all seventeen stages'
    required = assignments['REQUIRED']
    assert isinstance(required, ast.Dict) and {ast.literal_eval(key) for key in required.keys} == set(stages), 'Every native stage needs mandatory evidence'
    shell = (root / 'verification/run_native_stages.sh').read_text()
    match = re.search(r'for stage in ([\w\s]+); do', shell)
    assert match, 'Cannot inspect native runner stage list'
    ordered = match.group(1).split()
    assert len(ordered) == len(stages) and set(ordered) == set(stages), 'Native runner must execute all seventeen stages exactly once'
    package = root / 'app/src/androidTest/java/com/sentongoharuna/worldsituationroom'
    native = (package / 'DuwmNativeEvidence.java').read_text()
    declared = re.search(r'STAGES\s*=\s*\{([^}]+)\}', native)
    assert declared and tuple(re.findall(r'"([a-z0-9_]+)"', declared.group(1))) == EXPECTED_NATIVE_STAGES, 'Instrumentation evidence stages differ from verifier'
    dispatcher = (package / 'DuwmSignalInstrumentation.java').read_text()
    cases = set(re.findall(r'case\s+"([a-z0-9_]+)"\s*:', dispatcher))
    assert set(stages) <= cases, 'Instrumentation dispatcher omits a required stage'
    legacy_path = root / 'verification/native_contract_1728_2_21.json'
    assert digest(legacy_path.read_bytes()) == 'a79182fb2d84da9f3b5f425ce1232d9c465cc439b6275860f3e6e5533d967cc3', 'Immutable /21 native contract changed'
    legacy = json.loads(legacy_path.read_text())
    assert tuple(legacy['stages']) == tuple(stages[:-1]) and stages[-1] == 'scene_timeline', 'The original sixteen stages must be retained in order'
    actual = runpy.run_path(str(root / 'verification/verify_native_stages.py'))
    for stage, evidence in legacy['required'].items():
        assert actual['REQUIRED'][stage] == tuple(evidence), 'Original mandatory evidence changed: ' + stage
    assert actual['REQUIRED']['scene_timeline'] == (
        'ANDROID-SCENE-TIMELINE.mp4', 'ANDROID-SCENE-FIRST.png',
        'ANDROID-SCENE-SECOND.png', 'SCENE-TIMELINE-NATIVE.json'), 'Scene native evidence incomplete'


def represent_string(dumper, data):
    return dumper.represent_scalar('tag:yaml.org,2002:str', data, style='|' if '\n' in data else None)


def upgrade_action_runtimes(flow: dict) -> None:
    """Replace only the eleven warned action references; preserve every input."""
    changed = []
    for job in flow['jobs'].values():
        for step in job['steps']:
            previous = step.get('uses')
            if previous in NODE24_ACTIONS:
                step['uses'] = NODE24_ACTIONS[previous]
                changed.append(previous)
    assert len(changed) == 11 and set(changed) == set(NODE24_ACTIONS), 'Unexpected workflow action migration scope'


def build_workflow(root: Path, full: bytes, patch: bytes, manifest: bytes):
    # The CI --check-workflow-contexts path is deliberately stdlib-only. PyYAML
    # is a packaging dependency and is loaded only when generating the YAML.
    import yaml
    class WorkflowDumper(yaml.SafeDumper):
        pass
    WorkflowDumper.add_representer(str, represent_string)
    template = json.loads((root / 'verification/ci_broadcast_workflow_template.json').read_text())
    flow = upgrade_strings(template)
    upgrade_action_runtimes(flow)
    flow['name'] = 'DUWM 1728.2/21/1 | Automatic scene descriptions and timed video titles'
    flow['run-name'] = 'DUWM 1728.2/21/1 | Compile scene SDK and verify timed video titles'
    flow['on']['push']['branches'] = ['main', 'build/duwm-1728-2-21-1']
    flow['on']['push']['paths'] = ['.github/workflows/' + WORKFLOW_NAME, SOURCE_NAME]
    job = flow['jobs']['compile-development']
    # runner is unavailable in job-level env. RESTORE exports BUILD_LOG_DIR at
    # runtime through GITHUB_ENV; step-level runner expressions remain valid.
    encoded = base64.b64encode(patch).decode('ascii')
    chunks = [encoded[i:i+12000] for i in range(0, len(encoded), 12000)]
    restore = RESTORE
    for old, new in [('__FULL_SHA__', repr(digest(full))), ('__PARENTS__', repr(KNOWN_BASELINES)),
                     ('__CHUNKS__', str(len(chunks))), ('__PATCH_SHA__', repr(digest(patch))),
                     ('__MANIFEST_SHA__', repr(digest(manifest)))]:
        restore = restore.replace(old, new)
    steps = job['steps']
    restore_step = steps[1]
    assert restore_step['run'] == '__GENERATED_RESTORE__'
    restore_step.update(name='Restore exact /21/1 source or checked patch over delivered /21 or /20', run=restore,
                        env={f'DUWM_PATCH_{i:03d}': chunk for i, chunk in enumerate(chunks)})
    for step in steps:
        if step.get('name', '').startswith('Test framing,'):
            step['name'] = 'Test /21/1 scene policies and retained broadcast contracts'
        if step.get('name') == 'Publish scoped host-render evidence':
            step['with']['path'] = '${{ env.PROJECT }}/verification/results/1728_2_21_1/'
    for step in steps:
        if step.get('name') == 'Assemble real application and instrumentation APKs':
            step['run'] += 'cp verification/run_native_stages.sh verification/verify_native_stages.py "$RUNNER_TEMP/duwm-native-test/"\n'
        if step.get('name') == 'Verify actual APK identity, signature and compiled components':
            step['run'] = step['run'].replace("b'shareIntent')", "b'shareIntent',b'Duwm1728EditorTrimPolicy',b'Duwm1728BroadcastReviewState',b'Duwm1728ExportRecovery',b'Duwm1728ExportRecoveryActivity',b'Duwm1728ExportRecoveryProvider',b'Duwm1728BroadcastComposition',b'Duwm1728CaptionEditPolicy',b'Duwm1728CaptionEditorDialog',b'Duwm1728CaptionSrt',b'Duwm1728CaptionFilesController',b'Duwm1728CaptionFileStore',b'Duwm1728CaptionFileProvider',b'Duwm1728AutomaticProduction',b'Duwm1728PcmTimeline',b'Duwm1728SpeechCues',b'Duwm1728CaptionPages',b'Duwm1728SpeechSessionPolicy',b'Duwm1728SpeechLanguagePolicy',b'Duwm1728SpeechReadiness',b'Duwm1728HeadlineFit',b'Duwm1728OutputSizePolicy')")
            # Retain the prior playback-repair helper and the new caption-files stage.
            # Check its actual compiled test DEX, separately from production DEX.
            test_gate = """test_apk=pathlib.Path(os.environ['RUNNER_TEMP'])/'duwm-native-test'/'DUWM-native-tests.apk'
assert test_apk.stat().st_size>50000
with zipfile.ZipFile(test_apk) as z:
    assert z.testzip() is None
    test_dex=b''.join(z.read(n) for n in z.namelist() if n.startswith('classes') and n.endswith('.dex'))
    for token in (b'DuwmRenderedFrameCapture',b'review.missing_file.verified',b'ANDROID-EDITOR-TRIM-LANDSCAPE-BOUNDS.json',b'-CAPTURE.txt',b'caption_files',b'DuwmCaptionFilesChecks',b'automatic_production',b'DuwmAutomaticProductionChecks',b'automatic_report',b'DuwmAutomaticReportChecks',b'automatic_ready',b'DuwmAutomaticReadyChecks',b'automatic_fit',b'DuwmAutomaticFitChecks',b'scene_timeline',b'DuwmSceneTimelineChecks'):
        assert token in test_dex,token
"""
            assert "tools=pathlib.Path" in step['run'], 'APK verification anchor changed'
            step['run'] = step['run'].replace("tools=pathlib.Path", test_gate + "tools=pathlib.Path", 1)
    gradle_index = next(i for i, step in enumerate(steps) if step.get('uses', '').startswith('gradle/actions/setup-gradle@'))
    steps.insert(gradle_index + 1, {
        'name': 'Resolve actual pinned ML Kit SDK and retain dependency diagnostics',
        'shell': 'bash',
        'run': 'set -euo pipefail\ncd "$PROJECT"\nbash verification/ci_scene_dependency.sh\n',
    })
    identity_index = next(i for i, step in enumerate(steps) if step.get('name') == 'Verify actual APK identity, signature and compiled components')
    steps.insert(identity_index + 1, {
        'name': 'Verify actual ML Kit class definitions in the compiled APK',
        'shell': 'bash',
        'run': (
            'set -euo pipefail\ncd "$PROJECT"\n'
            'python3 verification/verify_scene_sdk_apk.py '
            '"$RUNNER_TEMP/duwm-apk/DUWM-1728.2-21-1-SCENE-VISION.apk" '
            '"$BUILD_LOG_DIR/SCENE-SDK-DEPENDENCY.json" '
            '"$RUNNER_TEMP/duwm-apk/SCENE-SDK-APK-INTEGRATION.json"\n'
            'cp "$BUILD_LOG_DIR/SCENE-SDK-DEPENDENCY.json" "$RUNNER_TEMP/duwm-apk/"\n'
        ),
    })
    flow['jobs']['native-broadcast-tests']['timeout-minutes'] = 60
    for step in flow['jobs']['native-broadcast-tests']['steps']:
        if step.get('name') == 'Prepare persistent native test and evidence script':
            step['run'] = NATIVE
        if step.get('uses', '').startswith('reactivecircus/android-emulator-runner@'):
            step['name'] = 'Required seventeen native stages with exact APK and evidence verification'
            step['with']['script'] = 'bash "$RUNNER_TEMP/duwm-native.sh" apk/DUWM-1728.2-21-1-SCENE-VISION.apk tests/DUWM-native-tests.apk native-evidence'
    for job in flow['jobs'].values():
        assert job.get('continue-on-error') in (None, False, 'false'), 'Required jobs must fail the workflow'
        for step in job['steps']:
            assert len(step.get('run', '')) < 20000, 'GitHub run block exceeds the size budget'
            assert step.get('continue-on-error') in (None, False, 'false'), 'Required gates must fail the workflow'
    validate_workflow_contexts(flow)
    text = yaml.dump(flow, Dumper=WorkflowDumper, sort_keys=False, allow_unicode=True, width=120)
    assert yaml.safe_load(text) == flow, 'Workflow round trip changed values'
    assert len(text.encode()) < 1_000_000, 'Workflow is too large; inspect the patch selection'
    return flow, text, len(chunks)


def verify_recovery(workflow, files, full_path, baseline_paths):
    step = workflow['jobs']['compile-development']['steps'][1]
    shell_steps = [s['run'] for job in workflow['jobs'].values() for s in job['steps'] if 'run' in s]
    for code in shell_steps:
        subprocess.run(['bash', '-n'], input=code, text=True, check=True)
    modes = [('full source ZIP', full_path), *((p.name, p) for p in baseline_paths)]
    outcomes = []
    for mode, source in modes:
        with tempfile.TemporaryDirectory(prefix='duwm21-recovery-') as temp:
            work = Path(temp)
            (work / source.name).symlink_to(source.resolve())
            environment = {**os.environ, **step['env'], 'RUNNER_TEMP': str(work / 'runtime'), 'GITHUB_ENV': str(work / 'env')}
            result = subprocess.run(['bash', '-c', step['run']], cwd=work, env=environment,
                                    capture_output=True, text=True, check=True)
            exported = dict(line.split('=', 1) for line in (work / 'env').read_text().splitlines())
            project = Path(exported['PROJECT'])
            assert exported['BUILD_LOG_DIR'] == str(work / 'runtime' / 'duwm1728221-1-logs'), 'Build log directory must be exported at runtime'
            actual = {p.relative_to(project).as_posix(): p.read_bytes()
                      for p in project.rglob('*') if p.is_file()}
            assert actual == files, f'Restored bytes differ from the full /21/1 source: {mode}'
            outcomes.append({'route': mode, 'result': 'exact source match', 'files': len(actual)})
            print(result.stdout.strip())
    # Execute the actual generated restoration code against a broken full ZIP.
    # A corrupt upload must fail instead of quietly using a different version.
    with tempfile.TemporaryDirectory(prefix='duwm21-reject-') as temp:
        work = Path(temp)
        (work / SOURCE_NAME).write_bytes(b'not the matching source archive')
        environment = {**os.environ, **step['env'], 'RUNNER_TEMP': str(work / 'runtime'), 'GITHUB_ENV': str(work / 'env')}
        result = subprocess.run(['bash', '-c', step['run']], cwd=work, env=environment,
                                capture_output=True, text=True)
        assert result.returncode != 0 and 'matching pair' in result.stderr, 'Corrupt /21/1 source must fail closed'
    outcomes.append({'route': 'mismatched full source', 'result': 'rejected'})
    return outcomes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--output-dir', type=Path)
    parser.add_argument('--baseline', action='append', type=Path)
    parser.add_argument('--check-workflow-contexts', action='store_true',
                        help='Run context-scope regressions without packaging or writing release files')
    args = parser.parse_args()
    root = args.project.resolve()
    context_checks = verify_context_guard()
    if args.check_workflow_contexts:
        validate_workflow_contexts(upgrade_strings(json.loads((root / 'verification/ci_broadcast_workflow_template.json').read_text())))
        print(json.dumps({'status': 'PASS', 'scope': 'supported workflow context scopes', 'regression_checks': context_checks}, indent=2))
        return
    require_native_contract(root)
    output = (args.output_dir or root.parent / 'deliverables_1728_2_21_1').resolve()
    assert not output.is_relative_to(root), 'Deliverables must be outside the source tree'
    paths = args.baseline or [
        root.parent / 'deliverables_1728_2_21' / 'DUWM-1728.2-21-AUTO-FIT-SOURCE.zip',
        root.parent / 'deliverables_1728_2_20' / 'DUWM-1728.2-20-AUTO-READY-SOURCE.zip',
    ]
    assert len(paths) == 2 and {p.name for p in paths} == set(KNOWN_BASELINES), 'Exact delivered /21 and /20 source baselines are required'
    baselines = {p.name: archive_files(p) for p in paths}
    require_current_identity(root)
    files = source_snapshot(root)
    hashes = {name: digest(data) for name, data in files.items()}
    manifest = (json.dumps(hashes, indent=2, sort_keys=True) + '\n').encode()
    (root / MANIFEST_NAME).write_bytes(manifest)
    files[MANIFEST_NAME] = manifest
    full = make_zip(files)
    patch, changed = make_patch(files, baselines)
    workflow, yaml_text, chunk_count = build_workflow(root, full, patch, manifest)
    output.mkdir(parents=True, exist_ok=True)
    full_path = output / SOURCE_NAME
    full_path.write_bytes(full)
    (output / WORKFLOW_NAME).write_text(yaml_text)
    outcomes = verify_recovery(workflow, files, full_path, paths)
    assert source_snapshot(root) == {k: v for k, v in files.items() if k != MANIFEST_NAME}, 'Source changed during packaging; regenerate after edits finish'
    report = {
        'build': '1728.2/21/1', 'version_code': 172822,
        'verification_scope': 'packaging, exact predecessor recovery, supported workflow context scopes, shell syntax and identity only; Android compile and native tests run separately',
        'workflow_context_regression_checks': context_checks,
        'required_native_stages': list(EXPECTED_NATIVE_STAGES),
        'scene_native_evidence_scope': 'real Android rendering and encoding from explicitly synthetic observations; not model inference',
        'actual_model_inference_verified': False,
        'sdk_integration_gate': 'strict actual dependency resolution and actual APK DEX class definitions, executed by CI after compilation',
        'source_zip': {'name': SOURCE_NAME, 'bytes': len(full), 'sha256': digest(full)},
        'workflow': {'name': WORKFLOW_NAME, 'bytes': len(yaml_text.encode()), 'sha256': digest(yaml_text.encode()),
                     'maximum_run_characters': max(len(s.get('run', '')) for j in workflow['jobs'].values() for s in j['steps'])},
        'manifest_sha256': digest(manifest), 'source_files': len(files),
        'baseline_sha256': KNOWN_BASELINES, 'patch_sha256': digest(patch),
        'patch_bytes': len(patch), 'patch_env_chunks': chunk_count, 'patch_files': changed,
        'recovery_checks': outcomes,
    }
    (output / '1728_2_21_1_PACKAGE_VERIFICATION.json').write_text(json.dumps(report, indent=2) + '\n')
    (output / 'SHA256SUMS.txt').write_text(f'{digest(full)}  {SOURCE_NAME}\n{digest(yaml_text.encode())}  {WORKFLOW_NAME}\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'patch_files'}, indent=2))


if __name__ == '__main__':
    main()
