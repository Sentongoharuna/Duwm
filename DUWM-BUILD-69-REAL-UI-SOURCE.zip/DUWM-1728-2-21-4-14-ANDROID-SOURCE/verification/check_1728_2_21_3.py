#!/usr/bin/env python3
"""Run all retained /21 host regressions plus /21/3 Repair 2 scoped regressions.

The immutable historical checker is adapted only at its release/preservation
prelude, exact current studio label, output directory, stage-list prefix,
and the one newly required pure layout compiler input. The historical headline
test's temporary copy compares every original geometry field and pixel, with
explicit neutral assertions for all six newly added geometry fields.
Every historical behavioral assertion and host test still executes on CURRENT
production source. None of these checks claims actual ML Kit compilation,
native Android execution, or physical-device model inference.
"""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

import package_1728_2_21_3 as packaging
from release_contract import assert_release_at_least
import verify_native_stages as native_gate

ROOT = Path(__file__).resolve().parents[1]
JAVA_ROOT = "app/src/main/java/com/sentongoharuna/worldsituationroom/"
CHANGED_JAVA = {JAVA_ROOT + name for name in (
    "Duwm1728VideoEditorActivity.java", "Duwm1728BroadcastLayout.java",
    "Duwm1728OverlayRenderer.java", "Duwm1728LiveSceneView.java", "Duwm1728SceneAnalyzer.java",
    "Duwm1728BroadcastReviewActivity.java")}
ADDED_JAVA = {JAVA_ROOT + name for name in (
    "Duwm1728ClearPictureLayout.java", "Duwm1728OverlayCadence.java")}
LAYOUT_COMPILER_INPUTS = {
    "run_automatic_headline_fit_host_tests.sh": "headline_source",
    "run_automatic_ticker_pages_host_tests.sh": "ticker_source",
    "run_caption_edit_host_tests.sh": "caption_source",
    "run_caption_pages_host_tests.sh": "pages_source",
    "run_caption_srt_host_tests.sh": "srt_source",
    "run_recorded_audio_host_tests.sh": "audio_source",
    "run_scene_layout_host_tests.sh": "scene_layout_source",
    "run_measured_layout_host_tests.sh": "measured_source",
}



def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_current_release() -> tuple[dict, dict]:
    packaging.require_repair_source_scope(ROOT)
    baseline_path = ROOT / "1728_2_21_2_SOURCE_SHA256.json"
    assert digest(baseline_path) == packaging.BASELINE21_2_MANIFEST_SHA256, "Immutable delivered /21/2 manifest changed"
    baseline = json.loads(baseline_path.read_text())
    for name in ("verification/check_1728_2_21.py", "verification/package_1728_2_21.py",
                 "verification/preserved_sources_1728_2_21.json",
                 "1728_2_21_BUILD_NOTES.md", "1728_2_21_ACCEPTANCE.json",
                 "verification/check_1728_2_21_1.py", "verification/package_1728_2_21_1.py",
                 "verification/preserved_sources_1728_2_21_1.json",
                 "1728_2_21_1_BUILD_NOTES.md", "1728_2_21_1_ACCEPTANCE.json",
                 "verification/check_1728_2_21_2.py", "verification/package_1728_2_21_2.py",
                 "verification/preserved_sources_1728_2_21_2.json",
                 "1728_2_21_2_BUILD_NOTES.md", "1728_2_21_2_ACCEPTANCE.json"):
        assert digest(ROOT / name) == baseline[name], "Historical /21, /21/1 or /21/2 evidence changed: " + name
    assert assert_release_at_least(ROOT, 1728) == 172824
    ui = json.loads((ROOT / "app/src/main/assets/duwm_release_ui.json").read_text())
    assert ui["uiRevision"] == "1728.2.21.3" and ui["uiVersionCode"] == 172824
    assert ui["displayRevision"] == "1728.2/21/3"
    names = [el.text for el in ET.parse(ROOT / "app/src/main/res/values/strings.xml").getroot().findall("string")
             if el.get("name") == "app_name"]
    assert names == ["DUWM 1728.2/21/3 • DEVELOP.UGANDA"]
    build = (ROOT / "app/build.gradle.kts").read_text()
    assert re.search(r'minSdk\s*=\s*26\b', build), "Real SDK API baseline missing"
    assert 'implementation("com.google.mlkit:genai-image-description:1.0.0-beta1")' in build
    assert "android.useAndroidX=true" in (ROOT / "gradle.properties").read_text()
    baseline_java = {name: sha for name, sha in baseline.items()
                     if name.startswith("app/src/main/java/") and name.endswith(".java")}
    assert len(baseline_java) == 314 and CHANGED_JAVA <= set(baseline_java)
    preserved = json.loads((ROOT / "verification/preserved_sources_1728_2_21_3.json").read_text())
    assert preserved == {name: sha for name, sha in baseline_java.items() if name not in CHANGED_JAVA}
    assert len(preserved) == 308, "Preservation must cover every unscoped /21/2 production Java source"
    actual_java = {p.relative_to(ROOT).as_posix() for p in (ROOT / "app/src/main/java").rglob("*.java")}
    assert actual_java == set(baseline_java) | ADDED_JAVA, "Unexpected production Java addition or removal"
    for name, sha in preserved.items():
        assert digest(ROOT / name) == sha, "Unscoped production change: " + name
    # Historical Java sources stay byte-identical. Eight active compiler lists
    # gain the new layout class. The headline wrapper also adapts one temporary
    # reflection loop to the old schema and checks all six new neutral fields.
    for runner, variable in LAYOUT_COMPILER_INPUTS.items():
        name = "verification/" + runner
        text = (ROOT / name).read_text()
        addition = ' "$' + variable + '/Duwm1728ClearPictureLayout.java"'
        assert text.count(addition) == 1, "Expected exactly one additional layout compiler input: " + runner
        text = text.replace(addition, "", 1)
        if runner == "run_automatic_headline_fit_host_tests.sh":
            adapter = 'python3 "$headline_project/verification/adapt_legacy_headline_geometry.py" "$headline_project/verification/broadcast/AutomaticHeadlineFitTest.java" "$headline_build/AutomaticHeadlineFitTest.java"\n'
            assert text.count(adapter) == 1
            text = text.replace(adapter, "", 1)
            compiled = '  "$headline_build/AutomaticHeadlineFitTest.java"'
            assert text.count(compiled) == 1
            text = text.replace(compiled, '  "$headline_project/verification/broadcast/AutomaticHeadlineFitTest.java"', 1)
        assert hashlib.sha256(text.encode()).hexdigest() == baseline[name], "Inherited host harness changed beyond declared layout/schema inputs: " + runner
    host_java = {name: sha for name, sha in baseline.items() if name.startswith("verification/") and name.endswith(".java")}
    for name, sha in host_java.items():
        assert digest(ROOT / name) == sha, "Historical host assertion or fixture changed: " + name
    packaging.require_native_contract(ROOT)
    assert native_gate.STAGES == packaging.EXPECTED_NATIVE_STAGES and len(native_gate.STAGES) == 19
    print("PASS /21/3 Repair 2 identity, genuine SDK dependency declaration, all 308 preserved /21/2 Java components, exact Repair 1 scope, and retained nineteen native contracts.")
    return baseline, preserved


def replace_once(source: str, before: str, after: str) -> str:
    assert source.count(before) == 1, "Historical checker adaptation anchor changed: " + before
    return source.replace(before, after, 1)


def run_retained_checks() -> None:
    original = ROOT / "verification/check_1728_2_21.py"
    source = original.read_text()
    assert digest(original) == "89f7536560872ac1869ed7d2498c96d88c521467449db7eb71352db8231a2ac7"
    start = source.index("from release_contract import assert_release_at_least\n")
    end = source.index("for file in (root/'app/src').rglob('*.xml'):ET.parse(file)\n")
    assert end > start
    source = source[:start] + "baseline,protected=_validate_current_release()\n" + source[end:]
    source = replace_once(source, "'BROADCAST STUDIO  /21'", "'BROADCAST STUDIO  /21/3'")
    source = replace_once(source, "assert native_gate.STAGES==(", "assert native_gate.STAGES[:16]==(")
    source = replace_once(source, "proof=root/'verification/results/1728_2_21';",
                          "proof=root/'verification/results/1728_2_21_3';")
    source = replace_once(source, 'root/"verification/package_1728_2_21.py"',
                          'root/"verification/package_1728_2_21_3.py"')
    source = replace_once(source, "sources=['Duwm1728BroadcastComposition.java'",
                          "sources=['Duwm1728ClearPictureLayout.java','Duwm1728BroadcastComposition.java'")
    # The historical body runs against this release's actual source, not a copied
    # baseline or selectively restored old layout. No assertion is disabled.
    namespace = {"__name__": "__main__", "__file__": str(original),
                 "_validate_current_release": validate_current_release}
    exec(compile(source, str(original) + " [/21/3 release adapter]", "exec"), namespace)


def main() -> None:
    tested_sources = {name: digest(ROOT / name) for name in sorted(CHANGED_JAVA | ADDED_JAVA)}
    bound_native_sources = {name: digest(ROOT / name)
                            for name in sorted(packaging.REPAIR_MUTABLE_NATIVE | packaging.REPAIR_ADDED_NATIVE)}
    run_retained_checks()
    proof = ROOT / "verification/results/1728_2_21_3"
    for runner, folder in (("run_scene_timeline_host_tests.sh", "scene-timeline"),
                           ("run_scene_change_host_tests.sh", "scene-change"),
                           ("run_scene_layout_host_tests.sh", "scene-layout"),
                           ("run_measurement_policy_host_tests.sh", "measurement-policy"),
                           ("run_preview_rate_host_tests.sh", "preview-rate"),
                           ("run_measured_layout_host_tests.sh", "measured-layout"),
                           ("run_clear_picture_layout_host_tests.sh", "clear-picture-layout"),
                           ("run_clear_picture_font_host_tests.sh", "font-compatibility"),
                           ("run_overlay_cadence_host_tests.sh", "overlay-cadence"),
                           ("run_overlay_report_host_tests.sh", "overlay-report"),
                           ("run_automatic_headline_fixture_host_tests.sh", "automatic-headline-fixture"),
                           ("run_aac_packet_host_tests.sh", "aac-packet")):
        path = ROOT / "verification" / runner
        assert path.is_file(), "Required scene host runner missing: " + runner
        subprocess.run(["bash", str(path), str(proof / folder)], check=True)
    subprocess.run([sys.executable, str(ROOT / "verification/run_scene_analyzer_host_tests.py"),
                    "--out", str(proof / "scene-analyzer")], check=True)
    result = subprocess.run([sys.executable, str(ROOT / "verification/SceneSdkApkGateTest.py")],
                            capture_output=True, text=True)
    (proof / "SCENE-SDK-CLASS-GATE-HOST.txt").write_text(result.stdout + result.stderr)
    print(result.stdout + result.stderr, end="")
    result.check_returncode()
    diagnostics = subprocess.run([sys.executable, str(ROOT / 'verification/HostCiDiagnosticsTest.py')],
                                 capture_output=True, text=True)
    (proof / 'HOST-CI-DIAGNOSTICS-TESTS.txt').write_text(diagnostics.stdout + diagnostics.stderr)
    print(diagnostics.stdout + diagnostics.stderr, end='')
    diagnostics.check_returncode()
    stage_summary = subprocess.run([sys.executable, str(ROOT / 'verification/NativeStageSummaryTest.py')],
                                   capture_output=True, text=True)
    (proof / 'NATIVE-STAGE-SUMMARY-TESTS.txt').write_text(stage_summary.stdout + stage_summary.stderr)
    print(stage_summary.stdout + stage_summary.stderr, end='')
    stage_summary.check_returncode()
    measured_gate = subprocess.run([sys.executable, str(ROOT / "verification/MeasuredApkGateTest.py")],
                                   capture_output=True, text=True)
    (proof / "MEASURED-APK-CLASS-GATE-HOST.txt").write_text(measured_gate.stdout + measured_gate.stderr)
    print(measured_gate.stdout + measured_gate.stderr, end="")
    measured_gate.check_returncode()
    clear_gate = subprocess.run([sys.executable, str(ROOT / "verification/ClearPictureApkGateTest.py")],
                               capture_output=True, text=True)
    (proof / "CLEAR-PICTURE-APK-CLASS-GATE-HOST.txt").write_text(clear_gate.stdout + clear_gate.stderr)
    print(clear_gate.stdout + clear_gate.stderr, end="")
    clear_gate.check_returncode()
    analyzer = (ROOT / JAVA_ROOT / "Duwm1728SceneAnalyzer.java").read_text()
    missing_fields = {"PER_APP_BATTERY_USE_QUOTA_EXCEEDED", "BACKGROUND_USE_BLOCKED"}
    for field in missing_fields:
        assert "GenAiException.ErrorCode." + field not in analyzer, "Inherited official SDK compiler error reintroduced: " + field
    for file, variable in (("run_scene_analyzer_host_tests.py", "DOUBLES"),
                           ("typecheck_clear_picture_source.py", "DECLARATIONS")):
        tree = ast.parse((ROOT / "verification" / file).read_text())
        declaration = next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign)
                           and any(isinstance(t, ast.Name) and t.id == variable for t in node.targets))
        error_api = declaration["com/google/mlkit/genai/common/GenAiException.java"]
        assert not any(field in error_api for field in missing_fields), "Test declarations must not invent absent SDK fields: " + file
        assert re.search(r"int\s+BUSY\s*=\s*9\s*;", error_api), "Restricted known ErrorCode surface changed: " + file
    controller = json.loads((proof / "scene-analyzer/SCENE-ANALYZER-HOST.json").read_text())
    cases = controller["sdk_field_compatibility_cases"]
    assert len(cases) == 2 and {case["missing_sdk_field"] for case in cases} == missing_fields
    assert all(case["reintroduced_error_rejected"] is True for case in cases), "Missing-field regression did not reject compiler errors"
    assert controller["official_sdk_compilation_verified"] is False

    for name in ("ImageDescription", "ImageDescriber", "ImageDescriberOptions",
                 "ImageDescriptionRequest", "ImageDescriptionResult"):
        assert "import com.google.mlkit.genai.imagedescription." + name + ";" in analyzer, name
    for invocation in ("ImageDescription.getClient(", ".checkFeatureStatus(", ".runInference("):
        assert invocation in analyzer, "Actual SDK invocation missing: " + invocation
    assert tested_sources == {name: digest(ROOT / name) for name in tested_sources}, "Production source changed during host verification; rerun after edits finish"
    assert bound_native_sources == {name: digest(ROOT / name) for name in bound_native_sources}, "Native check source changed during host verification; rerun after edits finish"
    report = {
        "schema": 1, "build": "1728.2/21/3", "repair": 2, "status": "PASS",
        "repair_source_scope": packaging.require_repair_source_scope(ROOT),
        "scope": "retained host regressions, clear-picture layout and cadence, actual native AAC packet/clock fixture replay, headline two-row fixture premise, nineteen-stage failure summaries, inherited SDK-field compile regressions, source wiring and release contracts",
        "preserved_production_java": 308, "required_native_stages": list(native_gate.STAGES),
        "tested_production_sources_sha256": tested_sources,
        "bound_native_check_sources_sha256": bound_native_sources,
        "actual_sdk_compilation_verified": False, "native_encoder_verified": False,
        "physical_sensor_verified": False, "encoded_picture_verified": False,
        "sdk_field_compatibility_cases": cases,
        "legacy_headline_schema_adaptation": "Temporary copy compares every /20 Geometry field and retains every pixel assertion; all six new fields are separately neutral in legacy mode; historical Java is byte-identical",
        "host_failure_diagnostics": "First failed child exit retained, later checks blocked, combined output and first real assertion preserved; seven negative/positive diagnostics tests",
        "font_compatibility_scope": "Required real DejaVu Sans, logical SansSerif and installed optional physical families; complete measured values and clear clock groups remain checked",
        "aac_regression_scope": "Actual prior native source/output packet and MP4 clock fixtures replay the exact tick/byte contract with deliberate corruption rejection; repaired native rendering and extraction remain separate gates",
        "native_failure_summary_scope": "Reports every required stage and preserves nonzero status for failed, missing or invalid stages; supplements the unchanged strict native verifier",
        "model_inference_verified": False, "physical_camera_verified": False,
    }
    (proof / "CLEAR-PICTURE-HOST-RESULT.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
