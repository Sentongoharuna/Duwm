#!/usr/bin/env python3
"""Record real host font selections and require DejaVu Sans without fallback."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

REQUIRED = 'DejaVu Sans'
QUERIES = ('sans-serif', REQUIRED, 'Liberation Sans', 'Noto Sans')


def inspect_fonts() -> dict:
    matcher = shutil.which('fc-match')
    lister = shutil.which('fc-list')
    matches = {}
    families = set()
    if lister:
        listing = subprocess.run([lister, '-f', '%{family}\n'], capture_output=True,
                                 text=True, timeout=30)
        if listing.returncode == 0:
            for line in listing.stdout.splitlines():
                families.update(value.strip() for value in line.split(',') if value.strip())
    if matcher:
        for name in QUERIES:
            run = subprocess.run([matcher, '-f', '%{family}\n%{file}\n', name],
                                 capture_output=True, text=True, timeout=30)
            lines = run.stdout.splitlines()
            selected = [part.strip() for part in (lines[0] if lines else '').split(',')]
            file = Path(lines[1]) if len(lines) > 1 and lines[1] else None
            exact = name in families and name in selected and file is not None and file.is_file()
            matches[name] = {
                'exit_code': run.returncode,
                'selected_families': selected,
                'file': str(file) if file else '',
                'file_sha256': hashlib.sha256(file.read_bytes()).hexdigest() if file and file.is_file() else None,
                'exact_physical_family_available': exact and run.returncode == 0,
                'stderr': run.stderr.strip(),
            }
    available = matches.get(REQUIRED, {}).get('exact_physical_family_available', False)
    return {
        'schema': 1, 'status': 'PASS' if available else 'FAIL',
        'scope': 'Host rendering regression font dependency; no Android font or rendering proof',
        'required_physical_family': REQUIRED,
        'required_family_available_without_fallback': available,
        'font_matches': matches,
        'installed_optional_families': [name for name in QUERIES[2:] if matches.get(name, {}).get('exact_physical_family_available')],
        'missing_optional_families': [name for name in QUERIES[2:] if not matches.get(name, {}).get('exact_physical_family_available')],
        'fontconfig_environment': {name: os.environ.get(name, '') for name in ('FONTCONFIG_FILE', 'FONTCONFIG_PATH')},
        'fontconfig_overrides_set_by_this_helper': False,
    }


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit('Usage: verify_host_fonts.py OUTPUT.json')
    output = Path(sys.argv[1])
    output.parent.mkdir(parents=True, exist_ok=True)
    try:
        result = inspect_fonts()
    except (OSError, subprocess.TimeoutExpired) as error:
        result = {'schema': 1, 'status': 'FAIL', 'required_physical_family': REQUIRED,
                  'required_family_available_without_fallback': False, 'error': str(error)}
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    if result['status'] != 'PASS':
        raise SystemExit('The host regression requires real DejaVu Sans; substituting another family is not accepted.')


if __name__ == '__main__':
    main()
