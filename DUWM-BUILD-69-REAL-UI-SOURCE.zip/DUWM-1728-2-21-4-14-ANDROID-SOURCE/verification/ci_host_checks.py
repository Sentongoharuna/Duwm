#!/usr/bin/env python3
"""Run the strict CI host gate while retaining the first actual failing check.

Child stdout/stderr share one unbuffered stream. The first nonzero child status
stops the gate; logging and summaries never convert it into success. Android SDK
compilation, emulator execution and physical-camera proof remain separate gates.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
from typing import TextIO

ROOT = Path(__file__).resolve().parents[1]
FIRST_ERROR = re.compile(
    r'Exception in thread|(?:java\.lang\.)?AssertionError(?:\b|:)|\berror:'
    r'|^ERROR(?:[:\s])|^FAIL(?:URE|ED)?(?:[:\s])|command not found|No such file or directory'
)


def error_excerpt(output: str) -> tuple[str, str]:
    lines = output.splitlines()
    for index, line in enumerate(lines):
        if FIRST_ERROR.search(line):
            return line, '\n'.join(lines[index:index + 14])
    useful = [line for line in lines if line.strip()]
    return (useful[-1] if useful else 'The command returned a nonzero status without output',
            '\n'.join(lines[-20:]))


def workflow_escape(value: str) -> str:
    return value.replace('%', '%25').replace('\r', '%0D').replace('\n', '%0A')


def run_checks(checks: list[tuple[str, list[str]]], project: Path, proof: Path,
               environment: dict[str, str] | None = None,
               stream: TextIO | None = None,
               summary_path: Path | None = None) -> dict:
    """Execute real child commands; callers cannot turn a failure into a pass."""
    proof.mkdir(parents=True, exist_ok=True)
    destination = stream if stream is not None else sys.stdout
    env = dict(os.environ if environment is None else environment)
    env['PYTHONUNBUFFERED'] = '1'
    attempted = []
    code = 0
    failed_output = ''
    log_path = proof / 'HOST-CI.log'
    with log_path.open('w', encoding='utf-8') as log:
        def emit(line: str) -> None:
            log.write(line)
            log.flush()
            destination.write(line)
            destination.flush()

        for label, command in checks:
            emit('\n[HOST CHECK] ' + label + '\n')
            lines = []
            try:
                child = subprocess.Popen(command, cwd=project, env=env,
                                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                         text=True, encoding='utf-8', errors='replace')
                assert child.stdout is not None
                for line in child.stdout:
                    lines.append(line)
                    emit(line)
                child.stdout.close()
                raw_status = child.wait()
            except OSError as error:
                raw_status = 127
                line = 'ERROR: Could not start host command: ' + str(error) + '\n'
                lines.append(line)
                emit(line)
            code = 128 - raw_status if raw_status < 0 else raw_status
            attempted.append({'label': label, 'command': command,
                              'process_returncode': raw_status, 'exit_code': code})
            if code:
                failed_output = ''.join(lines)
                break
    first_error, excerpt = error_excerpt(failed_output) if code else ('', '')
    result = {
        'schema': 1, 'build': '1728.2/21/3', 'repair': 2,
        'status': 'FAIL' if code else 'PASS', 'exit_code': code,
        'scope': 'Host contracts, rendering, policy and Java syntax only',
        'log': log_path.name, 'commands': attempted,
        'commands_planned': len(checks), 'commands_attempted': len(attempted),
        'failed_check': attempted[-1]['label'] if code else '',
        'first_error': first_error,
        'official_sdk_compilation_verified': False,
        'android_native_executed': False, 'physical_camera_verified': False,
        'physical_sensor_verified': False, 'model_inference_verified': False,
    }
    (proof / 'HOST-CI-RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    summary = '## Host verification: ' + ('FAILED' if code else 'PASSED') + f' (exit {code})\n\n'
    summary += 'Host checks do not establish an Android SDK build, native export, physical sensors or AI inference.\n\n'
    if code:
        summary += '**First failed check:** ' + result['failed_check'] + '\n\n'
        summary += 'The first error and nearby lines from that command are below. The complete combined output is in `HOST-CI.log`.\n\n'
        summary += '~~~text\n' + (excerpt or first_error).replace('~~~', '---') + '\n~~~\n'
        destination.write('::error title=Host verification failed::' + workflow_escape(first_error[:600]) + '\n')
    else:
        summary += f'All {len(attempted)} required host commands completed. The official SDK build and nineteen native stages remain separate gates.\n'
    (proof / 'HOST-CI-SUMMARY.md').write_text(summary)
    if summary_path is not None:
        with summary_path.open('a', encoding='utf-8') as output:
            output.write(summary)
    destination.write(summary)
    destination.flush()
    return result


def main() -> None:
    proof = ROOT / 'verification/results/1728_2_21_3'
    proof.mkdir(parents=True, exist_ok=True)
    parser_classes = Path(os.environ.get('RUNNER_TEMP', str(proof))) / 'duwm-parser'
    parser_classes.mkdir(parents=True, exist_ok=True)
    font_tool = shutil.which('fc-match')
    font = None
    if font_tool:
        query = subprocess.run([font_tool, 'sans-serif'], capture_output=True, text=True)
        font = {'exit_code': query.returncode, 'selection': query.stdout.strip(),
                'stderr': query.stderr.strip()}
    manifest = ROOT / '1728_2_21_3_SOURCE_SHA256.json'
    environment = {
        'schema': 1, 'platform': platform.platform(), 'python': sys.version,
        'java_home': os.environ.get('JAVA_HOME', ''),
        'observed_source_manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest() if manifest.is_file() else None,
        'fontconfig_sans_serif': font,
    }
    (proof / 'HOST-CI-ENVIRONMENT.json').write_text(json.dumps(environment, indent=2) + '\n')
    checks = [
        ('Java runtime', ['java', '-version']),
        ('Install host test dependencies', [sys.executable, '-m', 'pip', 'install', '-r', 'ai-production-server/requirements-test.txt']),
        ('Original source contracts', [sys.executable, 'verification/check_source.py']),
        ('Retained and clear-picture host contracts', [sys.executable, 'verification/check_1728_2_21_3.py']),
        ('AI server policy tests', [sys.executable, '-m', 'pytest', '-q', 'ai-production-server/test_server.py']),
        ('Compile Java syntax checker', ['javac', '-d', str(parser_classes), 'verification/JavaSyntaxCheck.java']),
        ('Parse application Java', ['java', '-cp', str(parser_classes), 'JavaSyntaxCheck']),
        ('Parse instrumentation Java', ['java', '-cp', str(parser_classes), 'JavaSyntaxCheck', 'app/src/androidTest/java']),
    ]
    summary = Path(os.environ['GITHUB_STEP_SUMMARY']) if os.environ.get('GITHUB_STEP_SUMMARY') else None
    result = run_checks(checks, ROOT, proof, summary_path=summary)
    raise SystemExit(result['exit_code'])


if __name__ == '__main__':
    main()
