#!/usr/bin/env python3
"""1724 source and pure-Java functional gates; Android compilation is separate."""
from pathlib import Path
import json, re, subprocess, tempfile, shutil, textwrap, xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
j=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
get=lambda n:(j/n).read_text()
cam=get('Duwm1718MonitorsCamActivity.java')
gallery=get('Duwm1724GalleryPublisher.java')
flow=get('Duwm1724SignalFlow.java')
history=get('Duwm1724SignalHistory.java')
rail=get('Duwm1715SignalLights.java')
center=get('Duwm1716SignalCenterActivity.java')
theme=get('DuwmUnifiedTheme.java')
main=get('MainActivity.java')
assert 'versionCode = 172400' in (r/'app/build.gradle.kts').read_text()
assert 'versionName = "1724"' in (r/'app/build.gradle.kts').read_text()
assert 'DUWM 1724 • DEVELOP.UGANDA' in (r/'app/src/main/res/values/strings.xml').read_text()
meta=json.loads((r/'app/src/main/assets/duwm_release_ui.json').read_text())
assert meta['uiRevision']=='1724' and meta['uiVersionCode']==172400 and meta['singleOriginalGlobe']
assert main.count('new SatelliteMapView(this)')==1
assert len(list(j.glob('*.java')))>=257
for x in ('BACKGROUND = 0xFF041424','PANEL = 0xFF041424','BORDER = 0xFFDEE5EF','TEXT = 0xFFF5F7FA'):
    assert x in theme,x
for marker in ('MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)',
               'MediaStore.Video.Media.IS_PENDING,1','MediaStore.Video.Media.IS_PENDING,0',
               'MediaStore.Video.Media.RELATIVE_PATH','Environment.DIRECTORY_MOVIES',
               'MediaScannerConnection.scanFile','Gallery rejected video entry',
               'if(!completed)resolver.delete(video,null,null)',
               'IOException','publish(Context context,File mp4,String name'):
    assert marker in gallery,('Gallery contract',marker)
for marker in ('outputW=ratioIndex==0?(qualityIndex==0?720:1080)',
               'outputH=ratioIndex==0?(qualityIndex==0?800:1200)',
               'outputW/720f,outputH/800f',
               'outputFps=qualityIndex==0?24:30',
               'outputBitrate=qualityIndex==0?5_000_000:12_000_000',
               'recorder.setVideoSize(outputW,outputH)',
               'recorder.setVideoFrameRate(outputFps)',
               'recorder.setVideoEncodingBitRate(outputBitrate)',
               'MediaMetadataRetriever.METADATA_KEY_DURATION',
               'Duwm1724GalleryPublisher.publish(getApplicationContext()',
               'pendingGallerySave=true',
               'if(!hasAdequateCameraSource())',
               'savedUri!=null', 'setRequestedOrientation(',
               'ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE',
               'REPORT DETAILS & CAMERA SETTINGS',
               'recorderSurface.lockCanvas(null)',
               'saveCaptureReceipt(f,lastFile'):
    assert marker in cam,('Camera contract',marker)
assert 'videoClock.scheduleAtFixedRate(this::drawVideoFrame,0,1000/outputFps' in cam
assert 'recorder.setVideoSize(W,H)' not in cam
assert 'lastFile="";if(keep)note("Video not completed' in cam
for marker in ('RED','ORANGE','YELLOW','BLUE','CYAN','GREEN'):
    # Names are documented through legend/Stage colors, not repetitive literal values.
    assert marker in (center+rail+flow).upper(),marker
for marker in ('fromFeed(FeedStatus status,long now,long budgetMs,boolean newAccepted)',
               'Stage.RECEIVING:Stage.HEALTHY','case CACHED:return Stage.AGED',
               'case OFFLINE:return Stage.OUTAGE','return Stage.UNKNOWN'):
    assert marker in flow,('Signal policy',marker)
for marker in ('stageFor(Context context,int sector)','Duwm1724SignalHistory.observe(c,i,state.stage,state.state)',
               'candidate.rank<selected.rank','stage==Duwm1724SignalFlow.Stage.RECEIVING'):
    assert marker in rail,('Signal wiring',marker)
assert 'Duwm1724SignalHistory.read(this,index)' in center
assert 'if(state.name().equals(old))return;' in history
manifest=(r/'app/src/main/AndroidManifest.xml').read_text()
assert 'android.permission.WRITE_EXTERNAL_STORAGE' in manifest and 'android:maxSdkVersion="28"' in manifest
assert 'android:screenOrientation="portrait"' not in manifest.split('Duwm1718MonitorsCamActivity')[1][:100]
ET.parse(r/'app/src/main/AndroidManifest.xml')
for f in (r/'app/src/main/res').rglob('*.xml'): ET.parse(f)
# Compile real FeedStatus + policy against a minimal Layer enum, exercising changes
# without Android SDK to catch Java TYPE errors (parser-only tests miss these).
with tempfile.TemporaryDirectory() as td:
    tmp=Path(td)/'com/sentongoharuna/worldsituationroom';tmp.mkdir(parents=True)
    shutil.copyfile(j/'FeedStatus.java',tmp/'FeedStatus.java')
    shutil.copyfile(j/'Duwm1724SignalFlow.java',tmp/'Duwm1724SignalFlow.java')
    (tmp/'Signal.java').write_text('''package com.sentongoharuna.worldsituationroom;
public class Signal {public enum Layer {FLIGHTS,AIRSPACE,SHIPS,NEWS,WEATHER,SATELLITES,SPACE_WEATHER,MARKETS,TV,RADIO,NATURAL}}''')
    (tmp/'SignalFlowTest.java').write_text(textwrap.dedent('''
        package com.sentongoharuna.worldsituationroom;
        public final class SignalFlowTest {
          static void eq(Object a,Object b){if(!a.equals(b))throw new AssertionError(a+" != "+b);}
          public static void main(String[] args) {
            long now=1_800_000_000_000L;
            eq(Duwm1724SignalFlow.fromText("NO RECEIPT"),Duwm1724SignalFlow.Stage.UNKNOWN);
            eq(Duwm1724SignalFlow.fromText("LOCAL TOOL"),Duwm1724SignalFlow.Stage.LOCAL);
            eq(Duwm1724SignalFlow.fromText("SOURCE READ FAILED"),Duwm1724SignalFlow.Stage.OUTAGE);
            eq(Duwm1724SignalFlow.fromText("SAVED / AGED"),Duwm1724SignalFlow.Stage.AGED);
            for(FeedStatus.State state:FeedStatus.State.values()) {
              FeedStatus f=new FeedStatus(state,4,"actual source",now-1000);
              Duwm1724SignalFlow.Stage expected=state==FeedStatus.State.OFFLINE?Duwm1724SignalFlow.Stage.OUTAGE:
                state==FeedStatus.State.KEY_REQUIRED||state==FeedStatus.State.DELAYED?Duwm1724SignalFlow.Stage.DEGRADED:
                state==FeedStatus.State.CACHED?Duwm1724SignalFlow.Stage.AGED:
                state==FeedStatus.State.LOADING?Duwm1724SignalFlow.Stage.CONNECTING:Duwm1724SignalFlow.Stage.HEALTHY;
              eq(Duwm1724SignalFlow.fromFeed(f,now,60000,false),expected);
            }
            FeedStatus fresh=new FeedStatus(FeedStatus.State.LIVE,3,"",now-1000);
            eq(Duwm1724SignalFlow.fromFeed(fresh,now,60000,true),Duwm1724SignalFlow.Stage.RECEIVING);
            eq(Duwm1724SignalFlow.fromFeed(fresh,now+90_000,60000,false),Duwm1724SignalFlow.Stage.AGED);
            eq(Duwm1724SignalFlow.fromFeed(null,now,60000,false),Duwm1724SignalFlow.Stage.UNKNOWN);
            FeedStatus stuck=new FeedStatus(FeedStatus.State.LOADING,0,"",now-600_000);
            eq(Duwm1724SignalFlow.fromFeed(stuck,now,60_000,false),Duwm1724SignalFlow.Stage.DEGRADED);
            if(!(Duwm1724SignalFlow.Stage.OUTAGE.rank < Duwm1724SignalFlow.Stage.HEALTHY.rank))throw new AssertionError("rank");
            System.out.println("PASS 1724: seven real-source flow stages, neutral no-data, and freshness transitions");
          }
        }
    '''))
    paths=list(tmp.glob('*.java'))
    subprocess.run(['javac','-d',td,*map(str,paths)],check=True)
    subprocess.run(['java','-cp',td,'com.sentongoharuna.worldsituationroom.SignalFlowTest'],check=True)
print('PASS 1724: one original globe, exact navy/silver theme, media-store gallery, 9:10/16:9, HD/PRO, MP4 overlays, source-backed multicolour signal rail and history')
print('NOT VERIFIED: Android build, media codec support, Gallery visibility and real-device 24/30 fps performance')
