#!/usr/bin/env python3
"""Negative release-gate tests. Synthetic records here are never native proof."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

import verify_native_stages as gate


class NativeStageGateTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="duwm-gate-unit-")
        self.root = Path(self.temporary.name)
        self.proof = self.root / "native-stage-proof"
        self.logs = self.root / "logs"
        self.logs.mkdir()
        self.app, self.test = self.root / "app.apk", self.root / "test.apk"
        self.app.write_bytes(b"unit-only app identity")
        self.test.write_bytes(b"unit-only test identity")
        self.run = "unit-gate-negative-tests"
        (self.root / "RETURN-CODE.txt").write_text("0\n")
        self.manifests = {}
        for stage in gate.STAGES:
            directory = self.proof / stage
            evidence = directory / "evidence"
            evidence.mkdir(parents=True)
            listed = []
            for name in gate.REQUIRED[stage]:
                data = ((b"\x00\x00\x00\x18ftypmp42" + b"x" * 11000) if name.endswith(".mp4")
                        else b"1\n00:00:00,437 --> 00:00:00,650\nSynthetic gate-only subtitle\n\n" if name.endswith(".srt")
                        else b"\x89PNG\r\n\x1a\nunit-only-image-record")
                if name == "SCENE-TIMELINE-NATIVE.json":
                    data = json.dumps({"schema": 1, "status": "PASS", "scene_source": "synthetic-native-fixture",
                                       "model_inference_verified": False, "physical_camera_verified": False,
                                       "encoded_timeline_verified": True, "checks": 10}).encode()
                if name == "MEASURED-TELEMETRY-NATIVE.json":
                    data = json.dumps({"schema": 1, "status": "PASS", "measurement_source": "synthetic-native-fixture",
                                       "physical_sensor_verified": False, "model_inference_verified": False,
                                       "physical_camera_verified": False, "encoded_timeline_verified": True, "checks": 10}).encode()
                if name == "CLEAR-PICTURE-NATIVE.json":
                    data = json.dumps({"schema": 1, "status": "PASS", "fixture_source": "synthetic-native-fixture",
                        "physical_sensor_verified": False, "physical_camera_verified": False,
                        "model_inference_verified": False, "provider_network_verified": False,
                        "encoded_picture_verified": True, "stable_geometry_verified": True, "center_picture_preserved": True,
                        "source_time_trim_verified": True, "source_audio_preserved": True, "source_file_unchanged": True,
                        "fixture_cleanup_complete": True, "clear_default_and_saved_choices_verified": True,
                        "older_draft_composition_preserved": True, "malformed_draft_rejected": True,
                        "source_file_sha256": "0" * 64, "source_aac_packets": 30, "checks": 10,
                        "from_ms": 250, "to_ms": 1900, "decoded_samples": [{
                            "elapsed_ms": at, "source_ms": at + 250,
                            "measurement_glyph_dice": .95, "wrong_measurement_glyph_dice": .4,
                            "title_glyph_dice": .95, "wrong_title_glyph_dice": .4,
                            "center_grid_mean_rgb_error": 5.0, "center_grid_p95_rgb_error": 10,
                            "center_grid_points": 153, "clear_safe_area_fraction": .68} for at in (350, 1050)]}).encode()
                path = evidence / name
                path.write_bytes(data)
                listed.append({"path": "evidence/" + name, "bytes": len(data), "sha256": gate.sha256(path)})
            manifest = {"schema": 1, "stage": stage, "status": "PASS", "run_id": self.run,
                        "application_id": "com.sentongoharuna.worldsituationroom.rb2live25",
                        "app_apk_sha256": gate.sha256(self.app), "test_apk_sha256": gate.sha256(self.test),
                        "physical_camera_verified": False, "checks": 10, "started_at_ms": 100, "finished_at_ms": 200,
                        "elapsed_ms": 100, "evidence": listed}
            self.manifests[stage] = manifest
            self.write_manifest(stage, manifest)
            (directory / "PHASES.txt").write_text(f"100 0ms DUWM_NATIVE_STAGE_PHASE stage={stage} run_id={self.run} phase=start\n")
            self.log(stage).write_text(f"INSTRUMENTATION_RESULT: stream=DUWM_NATIVE_STAGE_PASS stage={stage} run_id={self.run} checks=10\nINSTRUMENTATION_CODE: -1\n")
            (self.logs / f"RETURN-CODE-{stage}.txt").write_text("0\n")

    def tearDown(self):
        self.temporary.cleanup()

    def log(self, stage):
        return self.logs / f"INSTRUMENTATION-{stage}.txt"

    def write_manifest(self, stage, manifest):
        (self.proof / stage / "RESULT.json").write_text(json.dumps(manifest))

    def verify(self):
        return gate.verify(self.proof, self.app, self.test, self.run, logs_dir=self.logs)

    def test_complete_staged_contract(self):
        result = self.verify()
        self.assertEqual("PASS", result["status"])
        self.assertEqual(19, len(result["stages"]))
        self.assertIs(False, result["physical_camera_verified"])

    def test_complete_full_log_contract(self):
        log = self.root / "full.txt"
        log.write_text("".join(f"DUWM_NATIVE_STAGE_PASS stage={stage} run_id={self.run} checks=10\n" for stage in gate.STAGES)
                       + f"DUWM_NATIVE_BROADCAST_PASS run_id={self.run}\nINSTRUMENTATION_CODE: -1\n")
        self.assertEqual("PASS", gate.verify(self.proof, self.app, self.test, self.run, full_log=log)["status"])

    def test_previous_sixteen_stages_cannot_replace_scene_timeline(self):
        (self.proof / "scene_timeline" / "RESULT.json").unlink()
        with self.assertRaisesRegex(ValueError, "scene_timeline: missing result"):
            self.verify()

    def test_previous_seventeen_stages_cannot_replace_measured_telemetry(self):
        (self.proof / "measured_telemetry" / "RESULT.json").unlink()
        with self.assertRaisesRegex(ValueError, "measured_telemetry: missing result"):
            self.verify()

    def clear_report(self):
        return json.loads((self.proof / "clear_picture/evidence/CLEAR-PICTURE-NATIVE.json").read_text())

    def write_clear_report(self, report):
        path = self.proof / "clear_picture/evidence/CLEAR-PICTURE-NATIVE.json"
        path.write_text(json.dumps(report))
        manifest = copy.deepcopy(self.manifests["clear_picture"])
        item = next(item for item in manifest["evidence"] if item["path"].endswith(path.name))
        item.update(bytes=path.stat().st_size, sha256=gate.sha256(path))
        self.write_manifest("clear_picture", manifest)

    def test_previous_eighteen_stages_cannot_replace_clear_picture(self):
        (self.proof / "clear_picture/RESULT.json").unlink()
        with self.assertRaisesRegex(ValueError, "clear_picture: missing result"):
            self.verify()

    def test_clear_picture_requires_all_encoded_evidence(self):
        for required in gate.REQUIRED["clear_picture"]:
            with self.subTest(required=required):
                manifest = copy.deepcopy(self.manifests["clear_picture"])
                manifest["evidence"] = [item for item in manifest["evidence"] if item["path"] != "evidence/" + required]
                self.write_manifest("clear_picture", manifest)
                with self.assertRaisesRegex(ValueError, "clear_picture: mandatory evidence missing"):
                    self.verify()

    def test_clear_picture_fixture_cannot_claim_external_or_model_proof(self):
        original = self.clear_report()
        for field, value in (("physical_sensor_verified", True), ("physical_camera_verified", True),
                             ("model_inference_verified", True), ("provider_network_verified", True),
                             ("fixture_source", "physical-phone")):
            with self.subTest(field=field):
                self.write_clear_report({**original, field: value})
                with self.assertRaisesRegex(ValueError, "clear_picture:"):
                    self.verify()

    def test_clear_picture_requires_completed_geometry_audio_and_editor_checks(self):
        original = self.clear_report()
        for field in ("encoded_picture_verified", "stable_geometry_verified", "center_picture_preserved",
                      "source_time_trim_verified", "source_audio_preserved", "source_file_unchanged",
                      "fixture_cleanup_complete", "clear_default_and_saved_choices_verified",
                      "older_draft_composition_preserved", "malformed_draft_rejected"):
            with self.subTest(field=field):
                self.write_clear_report({**original, field: False})
                with self.assertRaisesRegex(ValueError, "clear_picture: missing verified"):
                    self.verify()

    def test_clear_picture_requires_source_hash_interval_packets_and_assertions(self):
        original = self.clear_report()
        for field, value in (("checks", 0), ("checks", True), ("source_aac_packets", 0),
                             ("source_file_sha256", "previous-source"), ("from_ms", -1), ("to_ms", 100),
                             ("decoded_samples", [])):
            with self.subTest(field=field, value=value):
                self.write_clear_report({**original, field: value})
                with self.assertRaisesRegex(ValueError, "clear_picture:"):
                    self.verify()

    def test_clear_picture_rejects_wrong_trim_nonfinite_metrics_and_weak_picture_matches(self):
        original = self.clear_report()
        mutations = (("source_ms", 350), ("elapsed_ms", -1), ("elapsed_ms", 1800),
                     ("center_grid_points", 10), ("center_grid_mean_rgb_error", 24),
                     ("center_grid_p95_rgb_error", 50), ("clear_safe_area_fraction", .59),
                     ("measurement_glyph_dice", .69), ("wrong_measurement_glyph_dice", .94),
                     ("title_glyph_dice", .69), ("wrong_title_glyph_dice", .94),
                     ("title_glyph_dice", float("nan")), ("center_grid_mean_rgb_error", float("inf")))
        for field, value in mutations:
            with self.subTest(field=field, value=value):
                report = copy.deepcopy(original)
                report["decoded_samples"][0][field] = value
                self.write_clear_report(report)
                with self.assertRaisesRegex(ValueError, "clear_picture:"):
                    self.verify()

    def test_clear_picture_cannot_duplicate_one_decoded_moment(self):
        report = self.clear_report()
        report["decoded_samples"][1] = copy.deepcopy(report["decoded_samples"][0])
        self.write_clear_report(report)
        with self.assertRaisesRegex(ValueError, "clear_picture: decoded source time"):
            self.verify()

    def test_measured_telemetry_requires_all_encoded_fixture_evidence(self):
        for required in gate.REQUIRED["measured_telemetry"]:
            with self.subTest(required=required):
                manifest = copy.deepcopy(self.manifests["measured_telemetry"])
                manifest["evidence"] = [item for item in manifest["evidence"] if item["path"] != "evidence/" + required]
                self.write_manifest("measured_telemetry", manifest)
                with self.assertRaisesRegex(ValueError, "measured_telemetry: mandatory evidence missing"):
                    self.verify()
        self.write_manifest("measured_telemetry", self.manifests["measured_telemetry"])

    def test_measured_fixture_cannot_claim_physical_or_model_proof(self):
        path = self.proof / "measured_telemetry" / "evidence/MEASURED-TELEMETRY-NATIVE.json"
        original = json.loads(path.read_text())
        for field, value in (("physical_sensor_verified", True), ("physical_camera_verified", True),
                             ("model_inference_verified", True), ("encoded_timeline_verified", False),
                             ("measurement_source", "phone-gps"), ("checks", 0)):
            with self.subTest(field=field):
                path.write_text(json.dumps({**original, field: value}))
                manifest = copy.deepcopy(self.manifests["measured_telemetry"])
                item = next(item for item in manifest["evidence"] if item["path"].endswith(path.name))
                item.update(bytes=path.stat().st_size, sha256=gate.sha256(path))
                self.write_manifest("measured_telemetry", manifest)
                with self.assertRaisesRegex(ValueError, "measured_telemetry:"):
                    self.verify()

    def test_scene_timeline_requires_all_encoded_and_declared_fixture_evidence(self):
        for required in gate.REQUIRED["scene_timeline"]:
            with self.subTest(required=required):
                manifest = copy.deepcopy(self.manifests["scene_timeline"])
                manifest["evidence"] = [item for item in manifest["evidence"] if item["path"] != "evidence/" + required]
                self.write_manifest("scene_timeline", manifest)
                with self.assertRaisesRegex(ValueError, "scene_timeline: mandatory evidence missing"):
                    self.verify()
        self.write_manifest("scene_timeline", self.manifests["scene_timeline"])

    def test_scene_fixture_cannot_claim_model_or_camera_inference(self):
        path = self.proof / "scene_timeline" / "evidence/SCENE-TIMELINE-NATIVE.json"
        original = json.loads(path.read_text())
        for field, value in (("model_inference_verified", True), ("physical_camera_verified", True),
                             ("encoded_timeline_verified", False), ("scene_source", "actual-camera"),
                             ("checks", 0)):
            with self.subTest(field=field):
                changed = {**original, field: value}
                path.write_text(json.dumps(changed))
                manifest = copy.deepcopy(self.manifests["scene_timeline"])
                item = next(item for item in manifest["evidence"] if item["path"].endswith(path.name))
                item.update(bytes=path.stat().st_size, sha256=gate.sha256(path))
                self.write_manifest("scene_timeline", manifest)
                with self.assertRaisesRegex(ValueError, "scene_timeline:"):
                    self.verify()

    def test_missing_stage_never_passes(self):
        (self.proof / "framing" / "RESULT.json").unlink()
        with self.assertRaisesRegex(ValueError, "missing result"):
            self.verify()

    def test_previous_eight_stages_cannot_replace_recovery(self):
        (self.proof / "recovery" / "RESULT.json").unlink()
        with self.assertRaisesRegex(ValueError, "recovery: missing result"):
            self.verify()

    def test_previous_nine_stages_cannot_replace_composition(self):
        (self.proof / "composition" / "RESULT.json").unlink()
        with self.assertRaisesRegex(ValueError, "composition: missing result"):
            self.verify()

    def test_previous_ten_stages_cannot_replace_caption_editing(self):
        (self.proof / "caption_editing" / "RESULT.json").unlink()
        with self.assertRaisesRegex(ValueError, "caption_editing: missing result"):
            self.verify()

    def test_previous_eleven_stages_cannot_replace_caption_files(self):
        (self.proof / "caption_files" / "RESULT.json").unlink()
        with self.assertRaisesRegex(ValueError, "caption_files: missing result"):
            self.verify()

    def test_caption_files_require_saved_roundtrip_and_ui_evidence(self):
        for required in gate.REQUIRED["caption_files"]:
            with self.subTest(required=required):
                manifest = copy.deepcopy(self.manifests["caption_files"])
                manifest["evidence"] = [item for item in manifest["evidence"] if item["path"] != "evidence/" + required]
                self.write_manifest("caption_files", manifest)
                with self.assertRaisesRegex(ValueError, "caption_files: mandatory evidence missing"):
                    self.verify()
        self.write_manifest("caption_files", self.manifests["caption_files"])

    def test_previous_twelve_stages_cannot_replace_automatic_export(self):
        (self.proof / "automatic_production" / "RESULT.json").unlink()
        with self.assertRaisesRegex(ValueError, "automatic_production: missing result"):
            self.verify()

    def test_previous_fourteen_stages_cannot_replace_automatic_ready(self):
        (self.proof / "automatic_ready" / "RESULT.json").unlink()
        with self.assertRaisesRegex(ValueError, "automatic_ready: missing result"):
            self.verify()

    def test_previous_fifteen_stages_cannot_replace_automatic_fit(self):
        (self.proof / "automatic_fit" / "RESULT.json").unlink()
        with self.assertRaisesRegex(ValueError, "automatic_fit: missing result"):
            self.verify()

    def test_automatic_fit_requires_encoded_headline_and_native_result(self):
        for required in gate.REQUIRED["automatic_fit"]:
            with self.subTest(required=required):
                manifest = copy.deepcopy(self.manifests["automatic_fit"])
                manifest["evidence"] = [item for item in manifest["evidence"] if item["path"] != "evidence/" + required]
                self.write_manifest("automatic_fit", manifest)
                with self.assertRaisesRegex(ValueError, "automatic_fit: mandatory evidence missing"):
                    self.verify()
        self.write_manifest("automatic_fit", self.manifests["automatic_fit"])

    def test_automatic_ready_requires_encoded_first_and_last_ticker_pages(self):
        for required in gate.REQUIRED["automatic_ready"]:
            with self.subTest(required=required):
                manifest = copy.deepcopy(self.manifests["automatic_ready"])
                manifest["evidence"] = [item for item in manifest["evidence"] if item["path"] != "evidence/" + required]
                self.write_manifest("automatic_ready", manifest)
                with self.assertRaisesRegex(ValueError, "automatic_ready: mandatory evidence missing"):
                    self.verify()
        self.write_manifest("automatic_ready", self.manifests["automatic_ready"])

    def test_automatic_production_requires_saved_video_and_review_evidence(self):
        for required in gate.REQUIRED["automatic_production"]:
            with self.subTest(required=required):
                manifest = copy.deepcopy(self.manifests["automatic_production"])
                manifest["evidence"] = [item for item in manifest["evidence"] if item["path"] != "evidence/" + required]
                self.write_manifest("automatic_production", manifest)
                with self.assertRaisesRegex(ValueError, "automatic_production: mandatory evidence missing"):
                    self.verify()
        self.write_manifest("automatic_production", self.manifests["automatic_production"])

    def test_binary_file_cannot_be_relabelled_as_saved_srt(self):
        name = "evidence/ANDROID-CAPTIONS-ORIGINAL.srt"
        path = self.proof / "caption_files" / name
        path.write_bytes(b"\x89PNG\xff\xfeinvalid subtitle")
        manifest = copy.deepcopy(self.manifests["caption_files"])
        for item in manifest["evidence"]:
            if item["path"] == name:
                item.update(bytes=path.stat().st_size, sha256=gate.sha256(path))
        self.write_manifest("caption_files", manifest)
        with self.assertRaisesRegex(ValueError, "caption_files: invalid UTF-8 SRT"):
            self.verify()

    def test_previous_thirteen_stages_cannot_replace_automatic_report(self):
        (self.proof / "automatic_report" / "RESULT.json").unlink()
        with self.assertRaisesRegex(ValueError, "automatic_report: missing result"):
            self.verify()

    def test_automatic_report_requires_editor_saved_video_and_both_caption_pages(self):
        for required in gate.REQUIRED["automatic_report"]:
            with self.subTest(required=required):
                manifest = copy.deepcopy(self.manifests["automatic_report"])
                manifest["evidence"] = [item for item in manifest["evidence"] if item["path"] != "evidence/" + required]
                self.write_manifest("automatic_report", manifest)
                with self.assertRaisesRegex(ValueError, "automatic_report: mandatory evidence missing"):
                    self.verify()
        self.write_manifest("automatic_report", self.manifests["automatic_report"])

    def test_caption_edit_requires_ui_restore_and_encoded_evidence(self):
        for required in ("ANDROID-CAPTION-APPLIED.png", "ANDROID-CAPTION-RESTORED.png", "ANDROID-CAPTION-EDITED.mp4", "ANDROID-CAPTION-DECODED.png", "CAPTION-EDITING-NATIVE.json"):
            with self.subTest(required=required):
                manifest = copy.deepcopy(self.manifests["caption_editing"])
                manifest["evidence"] = [item for item in manifest["evidence"] if item["path"] != "evidence/" + required]
                self.write_manifest("caption_editing", manifest)
                with self.assertRaisesRegex(ValueError, "caption_editing: mandatory evidence missing"):
                    self.verify()
        self.write_manifest("caption_editing", self.manifests["caption_editing"])

    def test_caption_editor_environment_failure_is_not_a_pass(self):
        manifest = copy.deepcopy(self.manifests["caption_editing"])
        manifest.update(status="FAIL", failure_kind="environment_overlay", checks=70, last_phase="caption_editing.apply")
        self.write_manifest("caption_editing", manifest)
        with self.assertRaisesRegex(ValueError, "caption_editing: status is FAIL"):
            self.verify()

    def test_landscape_repair_requires_actual_control_bounds(self):
        manifest = copy.deepcopy(self.manifests["editor_controls"])
        manifest["evidence"] = [item for item in manifest["evidence"] if item["path"] != "evidence/ANDROID-EDITOR-TRIM-LANDSCAPE-BOUNDS.json"]
        self.write_manifest("editor_controls", manifest)
        with self.assertRaisesRegex(ValueError, "editor_controls: mandatory evidence missing"):
            self.verify()

    def test_fullscreen_repair_requires_render_readiness_evidence(self):
        manifest = copy.deepcopy(self.manifests["review_controls"])
        manifest["evidence"] = [item for item in manifest["evidence"] if item["path"] != "evidence/ANDROID-REVIEW-FULLSCREEN-CAPTURE.txt"]
        self.write_manifest("review_controls", manifest)
        with self.assertRaisesRegex(ValueError, "review_controls: mandatory evidence missing"):
            self.verify()

    def test_composition_canvas_success_cannot_replace_missing_encoder_or_ui_proof(self):
        for required in ("ANDROID-COMPOSITION-CAPTIONS.mp4", "ANDROID-EDITOR-LAYOUT-CAPTIONS.png", "ANDROID-EDITOR-LAYOUT-RESTORED.png"):
            with self.subTest(required=required):
                manifest = copy.deepcopy(self.manifests["composition"])
                manifest["evidence"] = [item for item in manifest["evidence"] if item["path"] != "evidence/" + required]
                self.write_manifest("composition", manifest)
                with self.assertRaisesRegex(ValueError, "composition: mandatory evidence missing"):
                    self.verify()
        self.write_manifest("composition", self.manifests["composition"])

    def test_composition_obstructed_ui_cannot_become_a_native_pass(self):
        manifest = copy.deepcopy(self.manifests["composition"])
        manifest.update(status="FAIL", failure_kind="environment_overlay", checks=100, last_phase="composition.editor")
        self.write_manifest("composition", manifest)
        with self.assertRaisesRegex(ValueError, "composition: status is FAIL"):
            self.verify()

    def test_recovery_storage_success_cannot_replace_obstructed_ui(self):
        manifest = copy.deepcopy(self.manifests["recovery"])
        manifest.update(status="FAIL", failure_kind="environment_overlay", checks=40, last_phase="recovery.ui")
        self.write_manifest("recovery", manifest)
        with self.assertRaisesRegex(ValueError, "recovery: status is FAIL"):
            self.verify()

    def test_different_run_or_either_apk_never_passes(self):
        for key in ("run_id", "app_apk_sha256", "test_apk_sha256"):
            with self.subTest(key=key):
                manifest = copy.deepcopy(self.manifests["review_controls"])
                manifest[key] = "stale-value"
                self.write_manifest("review_controls", manifest)
                with self.assertRaisesRegex(ValueError, "another"):
                    self.verify()
        self.write_manifest("review_controls", self.manifests["review_controls"])

    def test_changed_delivered_apk_never_passes(self):
        self.app.write_bytes(b"different compiled APK")
        with self.assertRaisesRegex(ValueError, "another app APK"):
            self.verify()

    def test_altered_media_never_passes(self):
        path = self.proof / "inset1" / "evidence" / "ANDROID-PIP-PORTRAIT.mp4"
        changed = bytearray(path.read_bytes())
        changed[-1] ^= 1
        path.write_bytes(changed)
        with self.assertRaisesRegex(ValueError, "digest differs"):
            self.verify()

    def test_missing_required_media_never_passes_even_if_manifest_omits_it(self):
        manifest = copy.deepcopy(self.manifests["exports4"])
        manifest["evidence"].pop()
        self.write_manifest("exports4", manifest)
        with self.assertRaisesRegex(ValueError, "mandatory evidence missing"):
            self.verify()

    def test_environment_failure_or_incomplete_stage_never_passes(self):
        for status in ("FAIL", "RUNNING"):
            with self.subTest(status=status):
                manifest = copy.deepcopy(self.manifests["framing"])
                manifest.update(status=status, failure_kind="environment_overlay")
                self.write_manifest("framing", manifest)
                with self.assertRaisesRegex(ValueError, "status is"):
                    self.verify()

    def test_failed_or_partial_instrumentation_never_passes(self):
        path = self.log("editor_controls")
        good = path.read_text()
        for broken in (good.replace("CODE: -1", "CODE: 0"),
                       good.replace("DUWM_NATIVE_STAGE_PASS", "DUWM_NATIVE_STAGE_PHASE"),
                       "DUWM_NATIVE_STAGE_FAIL stage=editor_controls failure_kind=environment_overlay\n" + good):
            with self.subTest(log=broken):
                path.write_text(broken)
                with self.assertRaises(ValueError):
                    self.verify()

    def test_full_summary_alone_never_passes(self):
        log = self.root / "full.txt"
        log.write_text(f"DUWM_NATIVE_BROADCAST_PASS run_id={self.run}\nINSTRUMENTATION_CODE: -1\n")
        with self.assertRaisesRegex(ValueError, "no explicit current-run PASS"):
            gate.verify(self.proof, self.app, self.test, self.run, full_log=log)

    def test_missing_breadcrumbs_never_passes(self):
        (self.proof / "review" / "PHASES.txt").unlink()
        with self.assertRaisesRegex(ValueError, "phase breadcrumbs"):
            self.verify()

    def test_nonzero_timeout_or_missing_wrapper_result_never_passes(self):
        path = self.logs / "RETURN-CODE-review_controls.txt"
        for code in ("1\n", "124\n", "", "0\n124\n"):
            with self.subTest(code=code):
                path.write_text(code)
                with self.assertRaisesRegex(ValueError, "wrapper did not exit"):
                    self.verify()
        path.unlink()
        with self.assertRaisesRegex(ValueError, "Missing wrapper return code"):
            self.verify()


if __name__ == "__main__":
    unittest.main(verbosity=2)
