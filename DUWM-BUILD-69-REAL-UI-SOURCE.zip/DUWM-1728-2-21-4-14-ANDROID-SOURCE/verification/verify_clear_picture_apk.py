#!/usr/bin/env python3
"""Retain real SDK/measurement gates and require the clear-picture runtime.

Compiled class presence does not prove model inference, physical capture,
Android rendering or encoded picture quality. Those need separate evidence.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
import zipfile
import verify_measured_telemetry_apk as measured_gate

CLEAR_PICTURE_CLASSES = tuple("Lcom/sentongoharuna/worldsituationroom/" + name + ";" for name in (
    "Duwm1728ClearPictureLayout", "Duwm1728OverlayCadence"))


def verify(apk: Path, dependency_report: Path) -> dict:
    report = measured_gate.verify(apk, dependency_report)
    defined = set()
    with zipfile.ZipFile(apk) as archive:
        for name in archive.namelist():
            if re.fullmatch(r"classes(?:[2-9]|[1-9][0-9]+)?\.dex", name):
                defined.update(measured_gate.scene_gate.definitions(archive.read(name)))
    missing = sorted(set(CLEAR_PICTURE_CLASSES) - defined)
    assert not missing, "Actual clear-picture runtime DEX class definitions missing: " + ", ".join(missing)
    report.update(required_clear_picture_definitions=list(CLEAR_PICTURE_CLASSES),
                  scope="resolved SDK and actual packaged SDK, measurement and clear-picture runtime class definitions",
                  native_encoder_verified=False, encoded_picture_verified=False)
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("apk", type=Path)
    parser.add_argument("dependency_report", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    report = verify(args.apk, args.dependency_report)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
