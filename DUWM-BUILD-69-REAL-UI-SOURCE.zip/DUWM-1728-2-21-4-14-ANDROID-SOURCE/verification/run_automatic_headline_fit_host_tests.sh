#!/usr/bin/env bash
set -euo pipefail
headline_project="$(cd "$(dirname "$0")/.." && pwd)"
headline_proof="${1:-$headline_project/verification/automatic-headline-fit-host-proof}"
headline_javac="${JAVAC:-${JAVA_HOME:+$JAVA_HOME/bin/}javac}"
headline_java="${JAVA:-${JAVA_HOME:+$JAVA_HOME/bin/}java}"
headline_build="$(mktemp -d "${TMPDIR:-/tmp}/duwm-headline-fit.XXXXXX")"
trap 'rm -rf -- "$headline_build"' EXIT
headline_source="$headline_project/app/src/main/java/com/sentongoharuna/worldsituationroom"
python3 "$headline_project/verification/adapt_legacy_headline_geometry.py" "$headline_project/verification/broadcast/AutomaticHeadlineFitTest.java" "$headline_build/AutomaticHeadlineFitTest.java"
"$headline_javac" --release 17 -encoding UTF-8 -d "$headline_build" \
  "$headline_source/Duwm1728BroadcastComposition.java" \
  "$headline_source/Duwm1728BroadcastLayout.java" "$headline_source/Duwm1728ClearPictureLayout.java" \
  "$headline_source/Duwm1728HeadlineFit.java" \
  "$headline_source/Duwm1728CaptionPages.java" \
  "$headline_source/Duwm1728TickerTimeline.java" \
  "$headline_source/Duwm1728BroadcastTimeline.java" \
  "$headline_source/Duwm1728CaptionEditPolicy.java" \
  "$headline_source/Duwm1728CaptionSrt.java" \
  "$headline_source/Duwm1728FramePlan.java" \
  "$headline_source/Duwm1728PcmTimeline.java" \
  "$headline_source/Duwm1728AutomaticProduction.java" \
  "$headline_source/Duwm1728SpeechCues.java" \
  "$headline_project/verification/broadcast/BroadcastRenderTest.java" \
  "$headline_project/verification/broadcast/baseline/Duwm1728BroadcastLayout20.java" \
  "$headline_build/AutomaticHeadlineFitTest.java"
"$headline_java" -Xmx512m -Djava.awt.headless=true -cp "$headline_build" \
  com.sentongoharuna.worldsituationroom.AutomaticHeadlineFitTest "$headline_proof"
