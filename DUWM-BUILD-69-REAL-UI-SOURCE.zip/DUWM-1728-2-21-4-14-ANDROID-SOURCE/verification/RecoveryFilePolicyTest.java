package com.sentongoharuna.worldsituationroom;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Comparator;

/** Real host filesystem checks; no Android mocks or simulated publication success. */
public final class RecoveryFilePolicyTest {
    private static int checks;
    private interface Attempt {void run()throws Exception;}
    private static void check(boolean value,String name){checks++;if(!value)throw new AssertionError(name);}
    private static void rejects(Attempt action,String name)throws Exception {
        boolean rejected=false;try{action.run();}catch(IllegalArgumentException|IOException expected){rejected=true;}check(rejected,name);
    }
    public static void main(String[] args)throws Exception {
        String id="0123456789abcdef0123456789abcdef";
        Duwm1728RecoveryFilePolicy.requireId(id);
        for(String invalid:new String[]{null,"","0","0123456789ABCDEF0123456789ABCDEF","../"+id,id+"/x",id+"%2f",id+".mp4"})
            rejects(()->Duwm1728RecoveryFilePolicy.requireId(invalid),"reject unsafe recovery id");
        Duwm1728RecoveryFilePolicy.requireName("DUWM_BROADCAST_172814.mp4");
        for(String invalid:new String[]{null,"","../video.mp4","nested/video.mp4","video\\name.mp4",".hidden.mp4","video.mp4.exe","video.MP4","video name.mp4"})
            rejects(()->Duwm1728RecoveryFilePolicy.requireName(invalid),"reject unsafe/non-MP4 display name");
        Path work=Files.createTempDirectory("duwm-recovery-policy-");
        try {
            File root=Files.createDirectory(work.resolve("private-root")).toFile();
            File entry=Duwm1728RecoveryFilePolicy.entryDirectory(root,id);
            check(entry.getParentFile().equals(root.getCanonicalFile()),"entry stays in private store");
            check(!entry.exists(),"path resolution does not create a record");
            check(entry.mkdir(),"create isolated test record");
            for(String name:new String[]{"video.mp4","video.part","record.json","record.json.part"})
                check(Duwm1728RecoveryFilePolicy.ownedFile(entry,name).getParentFile().equals(entry.getCanonicalFile()),"known file remains inside record");
            for(String invalid:new String[]{"../outside.mp4","another.mp4","video.mp4/other","/tmp/video.mp4","record.json.bak"})
                rejects(()->Duwm1728RecoveryFilePolicy.ownedFile(entry,invalid),"reject non-owned recovery path");

            Path outside=Files.createDirectory(work.resolve("outside"));
            String linkedId="abcdef0123456789abcdef0123456789";
            Files.createSymbolicLink(root.toPath().resolve(linkedId),outside);
            rejects(()->Duwm1728RecoveryFilePolicy.entryDirectory(root,linkedId),"entry symlink cannot leave root");
            File outsideFile=outside.resolve("video.mp4").toFile();Files.write(outsideFile.toPath(),new byte[]{1,2,3});
            Files.createSymbolicLink(entry.toPath().resolve("video.mp4"),outsideFile.toPath());
            rejects(()->Duwm1728RecoveryFilePolicy.ownedFile(entry,"video.mp4"),"video symlink cannot expose another directory");
            Files.delete(entry.toPath().resolve("video.mp4"));
            Files.write(entry.toPath().resolve("record.json"),"private metadata".getBytes(StandardCharsets.UTF_8));
            Files.createSymbolicLink(entry.toPath().resolve("video.mp4"),entry.toPath().resolve("record.json"));
            rejects(()->Duwm1728RecoveryFilePolicy.ownedFile(entry,"video.mp4"),"video symlink cannot expose metadata in same directory");
            Files.delete(entry.toPath().resolve("video.mp4"));

            File small=work.resolve("abc.mp4").toFile();Files.write(small.toPath(),"abc".getBytes(StandardCharsets.UTF_8));
            Duwm1728RecoveryFilePolicy.Identity abc=Duwm1728RecoveryFilePolicy.identity(small);
            check(abc.bytes==3&&abc.sha256.equals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"),"SHA-256 known-answer identity");
            byte[] payload=new byte[131137];for(int i=0;i<payload.length;i++)payload[i]=(byte)(i*31+7);
            File source=work.resolve("completed.mp4").toFile();Files.write(source.toPath(),payload);
            Duwm1728RecoveryFilePolicy.Identity expected=Duwm1728RecoveryFilePolicy.identity(source);
            check(expected.bytes==payload.length,"identity counts every source byte");
            check(expected.sha256.equals("ef2966dea71889e422ca3c956c33241f1c7861c023d5cf6bf05e28dde7956d30"),"multi-buffer copy has independent known SHA-256");
            File partial=Duwm1728RecoveryFilePolicy.ownedFile(entry,"video.part");
            Duwm1728RecoveryFilePolicy.copyExact(source,partial,expected.bytes,expected.sha256);
            check(Arrays.equals(payload,Files.readAllBytes(partial.toPath())),"recovery copy preserves all bytes across buffer boundaries");
            check(Arrays.equals(payload,Files.readAllBytes(source.toPath())),"retention never changes caller's completed file");
            check(Duwm1728RecoveryFilePolicy.matches(partial,expected.bytes,expected.sha256),"completed exact copy validates");
            rejects(()->Duwm1728RecoveryFilePolicy.copyExact(source,source,expected.bytes,expected.sha256),"same-path copy cannot truncate source");
            check(Arrays.equals(payload,Files.readAllBytes(source.toPath())),"same-path rejection preserves original bytes");
            byte[] tampered=payload.clone();tampered[65536]^=0x40;Files.write(partial.toPath(),tampered);
            check(!Duwm1728RecoveryFilePolicy.matches(partial,expected.bytes,expected.sha256),"same-length corruption is rejected");
            Files.write(partial.toPath(),Arrays.copyOf(payload,payload.length-1));
            check(!Duwm1728RecoveryFilePolicy.matches(partial,expected.bytes,expected.sha256),"truncated partial is not a completed copy");
            rejects(()->Duwm1728RecoveryFilePolicy.copyExact(source,partial,expected.bytes,abc.sha256),"changed source identity cannot be accepted");
            check(Arrays.equals(payload,Files.readAllBytes(source.toPath())),"failed copy identity check retains original");
            Files.delete(partial.toPath());
            check(!Duwm1728RecoveryFilePolicy.matches(partial,expected.bytes,expected.sha256),"missing copy is never reported present");
            rejects(()->Duwm1728RecoveryFilePolicy.identity(partial),"missing source raises an error");
            rejects(()->Duwm1728RecoveryFilePolicy.identity(entry),"directory is not a completed file");
            System.out.println("PASS "+checks+" recovery file assertions: canonical containment, symlink/path rejection, source preservation, exact bytes/SHA-256, corrupt/truncated/missing copies. Android publication and process state are separate native gates.");
        }finally{
            try(java.util.stream.Stream<Path> paths=Files.walk(work)){
                for(Path path:paths.sorted(Comparator.reverseOrder()).toArray(Path[]::new))Files.deleteIfExists(path);
            }
        }
    }
}
