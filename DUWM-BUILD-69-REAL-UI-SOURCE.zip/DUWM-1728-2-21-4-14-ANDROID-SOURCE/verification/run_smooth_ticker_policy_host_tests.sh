#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac -d "$TMP" \
  "$ROOT/app/src/main/java/com/sentongoharuna/worldsituationroom/Duwm1728SmoothTicker.java" \
  "$ROOT/verification/broadcast/SmoothTickerPolicyTest.java"
java -cp "$TMP" com.sentongoharuna.worldsituationroom.SmoothTickerPolicyTest
