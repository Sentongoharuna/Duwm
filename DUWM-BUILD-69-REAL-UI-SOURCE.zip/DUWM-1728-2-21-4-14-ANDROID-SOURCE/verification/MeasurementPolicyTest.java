package com.sentongoharuna.worldsituationroom;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Synthetic sensor/provider inputs exercise actual pure production policy, not hardware. */
public final class MeasurementPolicyTest {
    private static int checks;
    private static void check(boolean condition,String explanation) {
        checks++;if(!condition)throw new AssertionError(explanation);
    }
    private static void near(double actual,double expected,double tolerance,String reason) {
        check(Double.isFinite(actual)&&Math.abs(actual-expected)<=tolerance,reason+": "+actual);
    }
    private static void state(Duwm1728Measurements.Status actual,Duwm1728Measurements.Status expected,String reason) {
        check(actual==expected,reason+": "+actual);
    }
    private static Duwm1728Measurements.Input fresh() {
        Duwm1728Measurements.Input in=new Duwm1728Measurements.Input();
        in.nowElapsedMs=2_000_000;in.sourceMs=1000;in.utcMs=Instant.parse("2026-11-07T12:00:00Z").toEpochMilli();
        in.recording=true;in.coordinatesAllowed=true;
        in.locationEnabled=true;in.locationAvailable=true;in.fixElapsedMs=in.nowElapsedMs-1000;
        in.latitude=0.3136;in.longitude=32.5811;in.horizontalAccuracyMeters=4;
        in.locationSource="gps";in.altitudeMeters=1200;in.altitudeReference="MSL";in.verticalAccuracyMeters=5;
        in.speedMps=1.4;in.speedAccuracyMps=0.2;
        in.headingDegrees=270;in.headingElapsedMs=in.nowElapsedMs-200;in.headingAccuracy=3;
        in.previewFps=30;in.fpsElapsedMs=in.nowElapsedMs-100;in.fpsFrames=61;in.fpsWindowMs=2000;
        in.place="Kampala";in.placeSource="Android Geocoder";
        in.placeQueryLatitude=in.latitude;in.placeQueryLongitude=in.longitude;
        in.placeFixElapsedMs=in.fixElapsedMs;in.placeReceivedElapsedMs=in.nowElapsedMs-500;
        in.weatherEnabled=true;in.weatherProvider="Open-Meteo";in.weatherSource="forecast model";
        in.weatherDescription="Partly cloudy";in.weatherCode=2;in.temperatureC=26.5;in.windMps=3;
        in.weatherUtcMs=in.utcMs-600_000;in.weatherReceivedElapsedMs=in.nowElapsedMs-30_000;
        in.weatherQueryLatitude=in.latitude;in.weatherQueryLongitude=in.longitude;
        return in;
    }
    private static Duwm1728Measurements.Sample sample(Duwm1728Measurements.Input input) {
        return Duwm1728Measurements.sample(input);
    }
    private static Duwm1728Measurements.Display display(Duwm1728Measurements.Input input) {
        return Duwm1728Measurements.display(sample(input),input.sourceMs,true);
    }

    private static void cameraMath() {
        float[][] matrices={
            {1,0,0, 0,0,-1, 0,1,0},
            {0,0,-1, 1,0,0, 0,-1,0},
            {-1,0,0, 0,0,1, 0,1,0},
            {0,0,1, -1,0,0, 0,-1,0}
        };
        for(int i=0;i<matrices.length;i++) {
            near(Duwm1728MeasurementMath.cameraHeading(matrices[i],false),i*90,0.00001,"Back-camera cardinal");
            near(Duwm1728MeasurementMath.cameraHeading(matrices[i],true),(i*90+180)%360,0.00001,"Front-camera optical axis");
        }
        check(Double.isNaN(Duwm1728MeasurementMath.cameraHeading(new float[]{1,0,0,0,1,0,0,0,1},false)),
                "Vertical optical axis was labelled north");
        double angle=Math.toRadians(5);
        float[] nearVertical={1,0,0,0,(float)Math.cos(angle),(float)-Math.sin(angle),0,(float)Math.sin(angle),(float)Math.cos(angle)};
        check(Double.isNaN(Duwm1728MeasurementMath.cameraHeading(nearVertical,false)),"Near-vertical bearing not withheld");
        check(Double.isNaN(Duwm1728MeasurementMath.cameraHeading(null,false)),"Missing rotation matrix");
        check(Double.isNaN(Duwm1728MeasurementMath.cameraHeading(new float[16],false)),"Wrong matrix layout accepted");
        check(Double.isNaN(Duwm1728MeasurementMath.cameraHeading(new float[9],false)),"Zero matrix invented heading");
        float[] nonfinite=matrices[0].clone();nonfinite[7]=Float.NaN;
        check(Double.isNaN(Duwm1728MeasurementMath.cameraHeading(nonfinite,false)),"Nonfinite rotation matrix");
        float[] reflection={-1,0,0,0,0,-1,0,1,0};
        check(Double.isNaN(Duwm1728MeasurementMath.cameraHeading(reflection,false)),"Reflection accepted as rotation");
        near(Duwm1728MeasurementMath.distanceMeters(0,0,0,0),0,0.000001,"Coincident coordinates");
        double degree=Duwm1728MeasurementMath.distanceMeters(0,0,0,1);
        check(degree>111000&&degree<111300,"Distance units are not metres");
        double crossing=Duwm1728MeasurementMath.distanceMeters(0,179.999,0,-179.999);
        check(crossing>200&&crossing<250,"Antimeridian query mismatch");
        check(Double.isNaN(Duwm1728MeasurementMath.distanceMeters(91,0,0,0)),"Invalid latitude was used");
        near(Duwm1728MeasurementMath.previewFps(61,2000),30,0.000001,"Presented-frame endpoint count");
        near(Duwm1728MeasurementMath.previewFps(31,1000),30,0.000001,"FPS window duration");
        check(Double.isNaN(Duwm1728MeasurementMath.previewFps(1,2000)),"One frame invented frame rate");
        check(Double.isNaN(Duwm1728MeasurementMath.previewFps(61,0)),"Zero window invented FPS");
        check(Double.isNaN(Duwm1728MeasurementMath.previewFps(3,40)),"Unstable short FPS window");
    }

    private static void actualValuesAndMissing() {
        Duwm1728Measurements.Input in=fresh();Duwm1728Measurements.Sample sample=sample(in);
        state(sample.latitude.status,Duwm1728Measurements.Status.AVAILABLE,"Fresh measured latitude");
        near(sample.speed.value,1.4,0.000001,"Raw speed changed");
        check(sample.speed.unit.equals("m/s")&&sample.speed.source.equals("gps"),"Raw speed source/unit lost");
        check(sample.heading.unit.equals("deg MAG"),"Magnetic reference not retained");
        check(sample.fps.source.equals("TextureView presented frames"),"Presented frame provenance missing");
        Duwm1728Measurements.Display d=display(in);
        check(d.coordinates.contains("0.31360")&&d.coordinates.contains("32.58110"),"Actual coordinates absent");
        check(d.accuracy.contains("4 m"),"Horizontal accuracy absent");
        check(d.heading.contains("270")&&d.heading.contains("W")&&d.heading.contains("MAG"),"Camera compass label");
        check(d.movement.equals("MOVING")&&d.speed.contains("5.0 km/h"),"Measured motion and unit conversion");
        check(d.altitude.contains("1200 m MSL")&&d.altitude.contains("5 m"),"Altitude datum/accuracy lost");
        check(d.fps.equals("PREVIEW 30.0 fps"),"Target/encoded rate substituted for preview");
        check(d.weather.contains("Open-Meteo")&&d.weather.contains("11:50 UTC")&&d.weather.contains("26.5"),
                "Weather model provider/time/value not displayed");
        check(d.weatherProviderLabel.equals("MODEL WX Open-Meteo")&&d.weatherDescription.equals("Partly cloudy"),
                "Weather provider and description segments overlap");
        check(d.weatherNumbers.equals("26.5\u00b0C / WIND 3.0 m/s")&&d.weatherTime.equals("11:50 UTC"),
                "Weather numeric units/time cannot be laid out independently");
        check(d.time.contains("2026-11-07 12:00:00 UTC")&&d.time.contains("REC 00:00:01"),"Captured UTC/time anchor");
        Duwm1728Measurements.Display later=Duwm1728Measurements.display(sample,3000,true);
        check(later.time.contains("12:00:02 UTC")&&later.time.contains("REC 00:00:03"),"Source clock did not advance from anchor");
        check(!Duwm1728Measurements.display(sample,4000,true).hasSample,"Tail held beyond bounded interval");
        check(!Duwm1728Measurements.display(sample,999,true).hasSample,"Future sample appeared early");
        check(!Duwm1728Measurements.display(null,1000,true).hasSample,"Absent sample manufactured data");
        check(Duwm1728Measurements.display(null,1000,true).weatherNumbers.isEmpty(),"Absent weather manufactured numeric segment");
        in.latitude=80;in.place="Changed later";in.sourceMs=9999;
        near(sample.latitude.value,0.3136,0.000001,"Immutable sample aliases adapter input");
        check(sample.place.value.equals("Kampala")&&sample.atMs==1000,"Snapshot text/time mutated");
        Duwm1728Measurements.Input detached=sample.inputCopy();detached.longitude=120;
        near(sample.longitude.value,32.5811,0.000001,"Serialization copy aliases original");
        in=fresh();in.latitude=0;in.longitude=0;
        check(display(in).coordinates.contains("0.00000, 0.00000"),"Genuine zero coordinates treated as missing");
        in=fresh();in.speedMps=0;in.speedAccuracyMps=0.1;
        check(display(in).movement.equals("STATIONARY")&&display(in).speed.contains("0.0"),"Genuine zero speed erased");
        in=fresh();in.speedMps=Double.NaN;in.speedAccuracyMps=Double.NaN;
        state(sample(in).speed.status,Duwm1728Measurements.Status.MISSING,"Missing speed invented zero");
        check(display(in).movement.equals("MOVEMENT UNAVAILABLE"),"Missing speed invented stationary");
        in=fresh();in.speedAccuracyMps=Double.NaN;
        check(display(in).movement.equals("MOVEMENT UNCERTAIN"),"Unknown speed accuracy invented motion certainty");
        in=fresh();in.speedMps=0.4;in.speedAccuracyMps=0.3;
        check(display(in).movement.equals("MOVEMENT UNCERTAIN"),"Overlapping stationary/moving interval not uncertain");
        in=fresh();in.altitudeReference="WGS84";in.verticalAccuracyMeters=Double.NaN;
        check(display(in).altitude.contains("1200 m WGS84")&&display(in).altitude.contains("ACC UNAVAILABLE"),
                "Available altitude erased by absent vertical accuracy");
        in=fresh();in.coordinatesAllowed=false;
        check(display(in).coordinates.equals("LAT/LON WITHHELD"),"Capture disclosure preset ignored");
        check(Duwm1728Measurements.display(sample(fresh()),1000,false).coordinates.equals("LAT/LON WITHHELD"),
                "Independent export disclosure switch ignored");
    }

    private static void freshnessAndReliability() {
        Duwm1728Measurements.Input in=fresh();in.fixElapsedMs=in.nowElapsedMs-30_000;
        state(sample(in).latitude.status,Duwm1728Measurements.Status.AVAILABLE,"Exact GPS freshness boundary");
        check(Duwm1728Measurements.display(sample(in),1001,true).coordinates.equals("LAT/LON STALE"),
                "GPS freshness did not age inside a sample interval");
        in.fixElapsedMs--;
        state(sample(in).latitude.status,Duwm1728Measurements.Status.STALE,"Old GPS carried forward");
        in.speedMps=Double.NaN;in.altitudeMeters=Double.NaN;in.place="";
        state(sample(in).speed.status,Duwm1728Measurements.Status.MISSING,"Never-reported speed relabelled stale");
        state(sample(in).altitude.status,Duwm1728Measurements.Status.MISSING,"Never-reported altitude relabelled stale");
        state(sample(in).place.status,Duwm1728Measurements.Status.MISSING,"Never-returned place relabelled stale");
        in=fresh();in.fixElapsedMs=in.nowElapsedMs+1;
        state(sample(in).latitude.status,Duwm1728Measurements.Status.UNRELIABLE,"Future GPS timestamp accepted");
        in=fresh();in.locationMocked=true;
        state(sample(in).latitude.status,Duwm1728Measurements.Status.UNRELIABLE,"Mock fix displayed as reliable");
        state(sample(in).weather.status,Duwm1728Measurements.Status.UNRELIABLE,"Mock fix used for weather attribution");
        in=fresh();in.horizontalAccuracyMeters=1500;
        state(sample(in).latitude.status,Duwm1728Measurements.Status.UNRELIABLE,"Coarse coordinates imply precision");
        state(sample(in).horizontalAccuracy.status,Duwm1728Measurements.Status.AVAILABLE,"Actual uncertainty was hidden");
        state(sample(in).place.status,Duwm1728Measurements.Status.UNRELIABLE,"Place accepted outside location precision");
        state(sample(in).weather.status,Duwm1728Measurements.Status.AVAILABLE,"Coarse but region-valid weather discarded");
        in=fresh();in.horizontalAccuracyMeters=Double.NaN;
        state(sample(in).latitude.status,Duwm1728Measurements.Status.UNRELIABLE,"Missing GPS accuracy implies precision");
        in=fresh();in.headingAccuracy=1;
        check(!display(in).headingAvailable&&display(in).heading.contains("UNRELIABLE"),"Low-accuracy compass accepted");
        in=fresh();in.headingDegrees=Double.NaN;
        check(!display(in).headingAvailable&&Double.isNaN(display(in).headingDegrees),"Missing heading invented north");
        in=fresh();in.headingElapsedMs=in.nowElapsedMs-3000;
        check(display(in).headingAvailable,"Exact heading freshness boundary");
        check(!Duwm1728Measurements.display(sample(in),1001,true).headingAvailable,"Heading failed to expire inside sample");
        in=fresh();in.fpsElapsedMs=in.nowElapsedMs-3001;
        state(sample(in).fps.status,Duwm1728Measurements.Status.STALE,"Old preview rate still live");
        in=fresh();in.previewFps=60;
        state(sample(in).fps.status,Duwm1728Measurements.Status.UNRELIABLE,"Requested FPS contradicted actual frame window");
        in=fresh();in.fpsFrames=0;
        state(sample(in).fps.status,Duwm1728Measurements.Status.UNRELIABLE,"Target-only FPS accepted");
        in=fresh();in.previewFps=Double.NaN;in.fpsFrames=0;
        state(sample(in).fps.status,Duwm1728Measurements.Status.MISSING,"Missing frames invented rate");
        in=fresh();in.speedMps=-1;
        state(sample(in).speed.status,Duwm1728Measurements.Status.UNRELIABLE,"Negative speed accepted");
        in=fresh();in.altitudeReference="UNKNOWN";
        state(sample(in).altitude.status,Duwm1728Measurements.Status.UNRELIABLE,"Unknown altitude datum accepted");
        in=fresh();in.verticalAccuracyMeters=200;
        state(sample(in).altitude.status,Duwm1728Measurements.Status.UNRELIABLE,"Very uncertain altitude accepted");
        in=fresh();in.locationEnabled=false;
        Duwm1728Measurements.Sample off=sample(in);
        state(off.latitude.status,Duwm1728Measurements.Status.OFF,"Location off ignored");
        state(off.speed.status,Duwm1728Measurements.Status.OFF,"Location off still inferred movement");
        state(off.place.status,Duwm1728Measurements.Status.OFF,"Location off still attributed place");
        state(off.weather.status,Duwm1728Measurements.Status.OFF,"Location off still attributed weather");
        state(off.heading.status,Duwm1728Measurements.Status.AVAILABLE,"Location off disabled independent compass");
        state(off.fps.status,Duwm1728Measurements.Status.AVAILABLE,"Location off disabled camera frame rate");
    }

    private static void providerAttribution() {
        Duwm1728Measurements.Input in=fresh();in.placeReceivedElapsedMs=in.nowElapsedMs-300_001;
        state(sample(in).place.status,Duwm1728Measurements.Status.STALE,"Old place lookup held");
        in=fresh();in.placeFixElapsedMs=in.nowElapsedMs-300_001;
        state(sample(in).place.status,Duwm1728Measurements.Status.STALE,"Old query fix relabelled through recent receipt");
        in=fresh();in.latitude+=0.02;
        state(sample(in).place.status,Duwm1728Measurements.Status.STALE,"Moved more than 1km retained old place");
        state(sample(in).weather.status,Duwm1728Measurements.Status.AVAILABLE,"Weather region bound incorrectly equals place bound");
        in=fresh();in.longitude+=0.1;
        state(sample(in).weather.status,Duwm1728Measurements.Status.STALE,"Moved outside model weather region");
        in=fresh();in.weatherReceivedElapsedMs=in.nowElapsedMs-600_001;
        state(sample(in).weather.status,Duwm1728Measurements.Status.STALE,"Old model retrieval held");
        in=fresh();in.weatherUtcMs=in.utcMs-3_600_001;
        state(sample(in).weather.status,Duwm1728Measurements.Status.STALE,"Recent retrieval concealed old model timestamp");
        in=fresh();in.weatherUtcMs=in.utcMs-3_600_000;
        state(sample(in).weather.status,Duwm1728Measurements.Status.AVAILABLE,"Exact model time freshness boundary");
        check(Duwm1728Measurements.display(sample(in),1001,true).weather.equals("MODEL WX STALE"),
                "Model timestamp did not expire inside sample interval");
        in=fresh();in.weatherUtcMs=in.utcMs+300_001;
        state(sample(in).weather.status,Duwm1728Measurements.Status.UNRELIABLE,"Implausibly future model time accepted");
        in=fresh();in.weatherReceivedElapsedMs=in.nowElapsedMs+1;
        state(sample(in).weather.status,Duwm1728Measurements.Status.UNRELIABLE,"Future retrieval timestamp accepted");
        in=fresh();in.weatherQueryLatitude=Double.NaN;
        state(sample(in).weather.status,Duwm1728Measurements.Status.MISSING,"Weather without query location attributed locally");
        in=fresh();in.weatherProvider="";
        state(sample(in).weather.status,Duwm1728Measurements.Status.MISSING,"Unidentified weather source accepted");
        in=fresh();in.temperatureC=300;
        state(sample(in).temperature.status,Duwm1728Measurements.Status.UNRELIABLE,"Wrong temperature unit accepted");
        check(!display(in).weather.contains("300"),"Unreliable temperature entered overlay");
        in=fresh();in.weatherDescription="";in.weatherCode=-1;
        check(display(in).weather.contains("26.5")&&display(in).weather.contains("CONDITIONS UNAVAILABLE"),
                "Partial weather data invented conditions or hid valid temperature");
        check(display(in).weatherDescription.isEmpty()&&display(in).weatherNumbers.contains("26.5"),
                "Partial weather segments lost valid temperature");
        in=fresh();in.weatherDescription="Extended condition description ".repeat(8);
        check(display(in).weatherNumbers.contains("26.5")&&display(in).weatherTime.equals("11:50 UTC"),
                "Long description displaced weather numeric/time evidence");
    }

    private static void boundedHistory() {
        Duwm1728Measurements.Input first=fresh();first.sourceMs=0;
        Duwm1728Measurements.Input second=fresh();second.sourceMs=5000;
        Duwm1728Measurements.Input replacement=fresh();replacement.sourceMs=5000;replacement.headingDegrees=180;
        Duwm1728Measurements.Sample a=sample(first),b=sample(second),c=sample(replacement);
        List<Duwm1728Measurements.Sample> input=new ArrayList<>(Arrays.asList(b,a,c,null));
        List<Duwm1728Measurements.Sample> normalized=Duwm1728Measurements.normalize(input);
        check(normalized.size()==2&&normalized.get(0)==a&&normalized.get(1)==c,"History order/duplicate semantics");
        check(input.get(0)==b,"Normalization mutated capture-owned list");
        check(Duwm1728Measurements.at(input,-1)==null,"Negative source lookup");
        check(Duwm1728Measurements.at(input,3000)==null,"Gap borrowed an old observation");
        check(Duwm1728Measurements.at(input,4999)==null,"Future sample appeared early");
        check(Duwm1728Measurements.at(input,5000)==c,"Newest source sample not selected");
        check(Duwm1728Measurements.at(input,8000)==null,"Unbounded hold beyond recording tail");
        long trimStart=4500,exportPosition=600;
        check(Duwm1728Measurements.at(normalized,trimStart+exportPosition)==c,"Trim applied to wrong clock");
        check(Duwm1728Measurements.at(normalized,exportPosition)==a,"Fixture fails to distinguish wrong export clock");
        input.clear();check(normalized.size()==2,"Immutable snapshot aliases input");
        boolean immutable=false;
        try{normalized.clear();}catch(UnsupportedOperationException expected){immutable=true;}
        check(immutable,"Normalized samples mutable");
        List<Duwm1728Measurements.Sample> many=new ArrayList<>();
        for(int index=Duwm1728Measurements.MAX_SAMPLES;index>=0;index--) {
            Duwm1728Measurements.Input value=fresh();value.sourceMs=index*10000L;many.add(sample(value));
        }
        List<Duwm1728Measurements.Sample> bounded=Duwm1728Measurements.normalize(many);
        check(bounded.size()==2000&&bounded.get(0).atMs==0,"History bound discarded beginning");
        check(Duwm1728Measurements.at(bounded,20_000_000)==null,"Bound manufactured missing tail");
        check(Duwm1728Measurements.at(Collections.emptyList(),0)==null,"Empty track invented measurement");
        boolean invalid=false;
        try{Duwm1728Measurements.Input bad=fresh();bad.sourceMs=Long.MAX_VALUE;sample(bad);}
        catch(IllegalArgumentException expected){invalid=true;}
        check(invalid,"Source interval overflow accepted");
    }

    public static void main(String[] args)throws Exception {
        cameraMath();actualValuesAndMissing();freshnessAndReliability();providerAttribution();boundedHistory();
        String result="{\n  \"schema\":1,\n  \"status\":\"PASS\",\n"
                +"  \"scope\":\"REAL_PURE_MEASUREMENT_POLICY_WITH_SYNTHETIC_SENSOR_INPUTS\",\n"
                +"  \"checks\":"+checks+",\n"
                +"  \"physical_sensor_verified\":false,\n  \"camera_frame_rate_verified\":false,\n"
                +"  \"weather_network_verified\":false,\n  \"android_atomic_store_verified\":false,\n"
                +"  \"native_encoder_verified\":false\n}\n";
        Path output=Path.of(args[0]);Files.createDirectories(output);
        Files.writeString(output.resolve("MEASUREMENT-POLICY-HOST.json"),result);
        System.out.print(result);
    }
}
