from pathlib import Path
p=Path(__file__).resolve().parents[1]
j=p/'app/src/main/java/com/sentongoharuna/worldsituationroom'
g=(j/'Duwm1726GalleryLibraryActivity.java').read_text()
for t in ('Search saved recordings','TextWatcher','MediaMetadataRetriever','OpenableColumns.SIZE','Intent.ACTION_SEND','FLAG_GRANT_READ_URI_PERMISSION','PLAY','SHARE'):
    assert t in g,t
m=(j/'MainActivity.java').read_text()
for t in ('WORLD STATUS  /  OPEN','SatelliteMapView','refreshWorldStatusHeader1726'):
    assert t in m,t
t=(j/'DuwmUnifiedTheme.java').read_text()
for color in ('0xFF041424','0xFFDEE5EF','0xFFD50000','0xFF00C853','0xFF0D47A1'):
    assert color in t,color
assert 'versionCode = 172700' in (p/'app/build.gradle.kts').read_text()
assert 'versionName = "1727"' in (p/'app/build.gradle.kts').read_text()
print('PASS 1727 gallery search, metadata, sharing, original globe, live header, navy and status colours')
