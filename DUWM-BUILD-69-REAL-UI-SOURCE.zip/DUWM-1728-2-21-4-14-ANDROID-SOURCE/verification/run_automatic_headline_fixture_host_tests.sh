#!/usr/bin/env bash
set -euo pipefail
fixture_project="$(cd "$(dirname "$0")/.." && pwd)"
fixture_proof="${1:-$fixture_project/verification/automatic-headline-fixture-host-proof}"
fixture_javac="${JAVAC:-${JAVA_HOME:+$JAVA_HOME/bin/}javac}"
fixture_java="${JAVA:-${JAVA_HOME:+$JAVA_HOME/bin/}java}"
fixture_build="$(mktemp -d "${TMPDIR:-/tmp}/duwm-headline-fixture.XXXXXX")"
trap 'rm -rf -- "$fixture_build"' EXIT
fixture_source="$fixture_project/app/src/main/java/com/sentongoharuna/worldsituationroom"
"$fixture_javac" --release 17 -encoding UTF-8 -d "$fixture_build" \
  "$fixture_source/Duwm1728BroadcastComposition.java" "$fixture_source/Duwm1728BroadcastLayout.java" \
  "$fixture_source/Duwm1728ClearPictureLayout.java" "$fixture_source/Duwm1728HeadlineFit.java" \
  "$fixture_source/Duwm1728CaptionPages.java" "$fixture_source/Duwm1728TickerTimeline.java" \
  "$fixture_source/Duwm1728BroadcastTimeline.java" "$fixture_source/Duwm1728CaptionEditPolicy.java" \
  "$fixture_source/Duwm1728CaptionSrt.java" "$fixture_source/Duwm1728FramePlan.java" \
  "$fixture_source/Duwm1728PcmTimeline.java" "$fixture_source/Duwm1728AutomaticProduction.java" \
  "$fixture_source/Duwm1728SpeechCues.java" "$fixture_project/verification/broadcast/AutomaticHeadlineFixtureTest.java"
"$fixture_java" -Xmx512m -Djava.awt.headless=true -cp "$fixture_build" \
  com.sentongoharuna.worldsituationroom.AutomaticHeadlineFixtureTest \
  "$fixture_project/app/src/androidTest/java/com/sentongoharuna/worldsituationroom/DuwmAutomaticFitChecks.java" "$fixture_proof"
