#!/usr/bin/env python3
"""1725 high-contrast native UI/source-backed signal policy regression gate."""
from pathlib import Path
import subprocess,tempfile,shutil,textwrap,json,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
j=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
read=lambda n:(j/n).read_text()
theme=read('DuwmUnifiedTheme.java');flow=read('Duwm1724SignalFlow.java')
rail=read('Duwm1715SignalLights.java');center=read('Duwm1716SignalCenterActivity.java')
legacy=read('Duwm1166SignalView.java');eight=read('Duwm1674SignalBoardView.java')
assert 'versionCode = 172500' in (r/'app/build.gradle.kts').read_text()
assert 'versionName = "1725"' in (r/'app/build.gradle.kts').read_text()
assert 'DUWM 1725 • DEVELOP.UGANDA' in (r/'app/src/main/res/values/strings.xml').read_text()
assert read('MainActivity.java').count('new SatelliteMapView(this)')==1
assert len(list(j.glob('*.java')))>=257
assert all(x in theme for x in ('BACKGROUND = 0xFF041424','BORDER = 0xFFDEE5EF','TEXT = 0xFFF5F7FA'))
expected={'OUTAGE':'0xFFD50000','DEGRADED':'0xFFF57C00','AGED':'0xFFFBC02D','CONNECTING':'0xFF0D47A1','RECEIVING':'0xFF00ACC1','HEALTHY':'0xFF00C853','UNKNOWN':'0xFF687786','LOCAL':'0xFFDEE5EF'}
for stage,colour in expected.items():
    assert f'{stage}(' in flow and colour in flow,stage
assert 'title.setText(review>0 ? "REVIEW "+review' in rail
assert 'title.setTextColor(review>0 ? DuwmUnifiedTheme.STATUS_RED' in rail
assert 'Color.rgb(222,229,239)' in rail
assert 'state.newReceipt' in rail and 'genuinelyNew>0' in rail
assert all(f'DuwmUnifiedTheme.STATUS_{x}' in legacy for x in ('GREEN','YELLOW','RED','BLUE'))
assert 'DuwmUnifiedTheme.STATUS_GREEN:aged?DuwmUnifiedTheme.STATUS_YELLOW:DuwmUnifiedTheme.STATUS_UNKNOWN' in eight
assert 'RED WORST → GREEN BEST' in center
assert 'receivedCount > 0 ? DuwmUnifiedTheme.STATUS_GREEN' in read('SignalTickerRailView.java')
assert 'Duwm1724GalleryPublisher.publish(getApplicationContext()' in read('Duwm1718MonitorsCamActivity.java')
assert 'versionCode = 172500' in (r/'app/build.gradle.kts').read_text()
assert json.loads((r/'app/src/main/assets/duwm_release_ui.json').read_text())['uiVersionCode']==172500
ET.parse(r/'app/src/main/AndroidManifest.xml')
for f in (r/'app/src/main/res').rglob('*.xml'):ET.parse(f)
# Pure-java compiled policy test, catching type errors beyond source parsing.
with tempfile.TemporaryDirectory() as tmpdir:
    d=Path(tmpdir);pkg=d/'com/sentongoharuna/worldsituationroom';pkg.mkdir(parents=True)
    for f in ('FeedStatus.java','Duwm1724SignalFlow.java','DuwmUnifiedTheme.java'):
        shutil.copyfile(j/f,pkg/f)
    (pkg/'Signal.java').write_text('package com.sentongoharuna.worldsituationroom; public class Signal {public enum Layer {FLIGHTS,AIRSPACE,SHIPS,NEWS,WEATHER,SATELLITES,SPACE_WEATHER,MARKETS,TV,RADIO,NATURAL}}')
    (pkg/'Check1725.java').write_text(textwrap.dedent('''
       package com.sentongoharuna.worldsituationroom;
       public class Check1725 {
         public static void main(String[] args){
           int[] colors={0xFFD50000,0xFFF57C00,0xFFFBC02D,0xFF0D47A1,0xFF00ACC1,0xFF00C853};
           Duwm1724SignalFlow.Stage[] stages={Duwm1724SignalFlow.Stage.OUTAGE,Duwm1724SignalFlow.Stage.DEGRADED,Duwm1724SignalFlow.Stage.AGED,Duwm1724SignalFlow.Stage.CONNECTING,Duwm1724SignalFlow.Stage.RECEIVING,Duwm1724SignalFlow.Stage.HEALTHY};
           for(int i=0;i<6;i++){if(stages[i].color!=colors[i]||stages[i].rank!=i)throw new AssertionError("Stage "+i);}
           if(Duwm1724SignalFlow.Stage.UNKNOWN.rank!=-1||Duwm1724SignalFlow.Stage.LOCAL.rank!=-1)throw new AssertionError("Neutral status");
           long now=1800000000000L;
           if(Duwm1724SignalFlow.fromFeed(new FeedStatus(FeedStatus.State.OFFLINE,0,"provider",now),now,60000,false)!=Duwm1724SignalFlow.Stage.OUTAGE)throw new AssertionError("outage");
           if(Duwm1724SignalFlow.fromFeed(new FeedStatus(FeedStatus.State.LIVE,1,"provider",now-2000),now,60000,false)!=Duwm1724SignalFlow.Stage.HEALTHY)throw new AssertionError("healthy");
           if(Duwm1724SignalFlow.fromFeed(new FeedStatus(FeedStatus.State.LIVE,1,"provider",now-2000),now,60000,true)!=Duwm1724SignalFlow.Stage.RECEIVING)throw new AssertionError("receipt");
           if(Duwm1724SignalFlow.fromFeed(new FeedStatus(FeedStatus.State.LIVE,1,"provider",now-200000),now,60000,false)!=Duwm1724SignalFlow.Stage.AGED)throw new AssertionError("stale");
           System.out.println("PASS 1725: all six saturated severity states and receipt-driven changes");
         }
       }
    '''))
    subprocess.run(['javac','-d',tmpdir,*map(str,pkg.glob('*.java'))],check=True)
    subprocess.run(['java','-cp',tmpdir,'com.sentongoharuna.worldsituationroom.Check1725'],check=True)
print('PASS 1725: one globe, unified #041424 navy, silver cards, high-contrast source-health palette across native screens, real receipt policy, Gallery camera preserved')
print('NOT VERIFIED: full Android APK compilation / physical-device appearance / camera recording')
