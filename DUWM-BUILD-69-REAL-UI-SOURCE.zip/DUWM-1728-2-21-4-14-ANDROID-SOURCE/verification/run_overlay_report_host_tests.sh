#!/usr/bin/env bash
set -euo pipefail
report_project="$(cd "$(dirname "$0")/.." && pwd)"
report_output="${1:-$report_project/artifacts/overlay-report-host}"
report_sdk="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
report_android="${2:-${ANDROID_JAR:-$report_sdk/platforms/android-36/android.jar}}"
if [[ ! -f "$report_android" ]]; then
  printf '%s\n' 'A real Android 36 android.jar is required for this production-adapter check.' >&2
  exit 1
fi
report_build="$(mktemp -d)"
trap 'rm -rf "$report_build"' EXIT
report_javac="${JAVAC:-${JAVA_HOME:+$JAVA_HOME/bin/}javac}"
report_java="${JAVA:-${JAVA_HOME:+$JAVA_HOME/bin/}java}"
report_sources="$report_project/app/src/main/java"
"$report_javac" --release 17 -encoding UTF-8 -proc:none -classpath "$report_android" \
  -sourcepath "$report_sources" -d "$report_build" \
  "$report_sources/com/sentongoharuna/worldsituationroom/Duwm1728OverlayRenderer.java" \
  "$report_project/verification/OverlayReportTest.java"
"$report_java" -cp "$report_build:$report_android" com.sentongoharuna.worldsituationroom.OverlayReportTest "$report_output" "$report_android"
