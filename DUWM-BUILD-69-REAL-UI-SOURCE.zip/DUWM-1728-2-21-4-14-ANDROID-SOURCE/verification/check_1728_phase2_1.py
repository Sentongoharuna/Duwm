from pathlib import Path
import re
p=Path(__file__).resolve().parents[1]
j=p/'app/src/main/java/com/sentongoharuna/worldsituationroom'
ed=(j/'Duwm1728VideoEditorActivity.java').read_text()
renderer=(j/'Duwm1728OverlayRenderer.java').read_text()
timeline=(j/'Duwm1728TickerTimeline.java').read_text()
manifest=(p/'app/src/main/AndroidManifest.xml').read_text()
assert 'Duwm1728VideoEditorActivity' in manifest
assert 'new Intent(this,Duwm1728VideoEditorActivity.class)' in (j/'Duwm1726GalleryLibraryActivity.java').read_text()
assert 'SatelliteMapView' in (j/'MainActivity.java').read_text()
for token in ['BROADCAST NEWS TICKER', 'TICKER SPEED', 'selectedTemplate', 'spec.ticker', 'tickerClock.post', 'PREVIEW CLIP START', 'OVERLAY POSITION', 'Duwm1728GalleryPublisher']:
    if token == 'Duwm1728GalleryPublisher': token='Duwm1724GalleryPublisher'
    assert token in ed,token
for token in ['paintOverlay(canvas,paint,spec,(long)n*1000L/fps)', 'clipRect', 'offsetPixels', 'current=active.text', 'REPORTER UPDATE', 'REPORTER-ENTERED / UNVERIFIED', 'spec.tickerCues=Duwm1728TickerTimeline.parse', 'if(!success)output.delete()']:
    assert token in renderer,token
for token in ['Maximum 12', 'Duplicate ticker time', 'relativeMs', 'offsetPixels', 'active(List<Cue>']:
    assert token in timeline,token
assert 'MediaMuxer' in renderer and 'MediaCodec' in renderer
assert 'Duwm1728VideoEditorActivity' in ed
print('PASS 1728.2/1 broadcast ticker, editor integration, frame-by-frame overlay, original globe and failure reporting checks')
