#!/usr/bin/env bash
# Strict SDK resolution with retained diagnostics; no stub or reflection fallback.
set -euo pipefail
scene_project="$(cd "$(dirname "$0")/.." && pwd)"
scene_logs="${BUILD_LOG_DIR:?Source restoration must set BUILD_LOG_DIR}"
mkdir -p "$scene_logs"
cd "$scene_project"
set +e
gradle --no-daemon --no-configuration-cache --stacktrace --console=plain \
  -I verification/verify_scene_dependency.gradle :app:duwmVerifySceneDependency \
  2>&1 | tee "$scene_logs/scene-sdk-dependency.log"
scene_code=${PIPESTATUS[0]}
set -e
python3 - "$scene_logs/SCENE-SDK-RESOLUTION-STATUS.json" "$scene_code" <<'PY'
import json,pathlib,sys
code=int(sys.argv[2])
pathlib.Path(sys.argv[1]).write_text(json.dumps({
    "schema":1, "status":"PASS" if code==0 else "FAIL", "exit_code":code,
    "coordinate":"com.google.mlkit:genai-image-description:1.0.0-beta1",
    "scope":"actual SDK dependency resolution only", "model_inference_verified":False
},indent=2)+"\n")
PY
exit "$scene_code"
