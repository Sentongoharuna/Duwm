#!/usr/bin/env bash
set -euo pipefail
project_root="$(cd "$(dirname "$0")/.." && pwd)"
output_dir="${1:-$project_root/artifacts/measurement-policy-host}"
test_dir="$(mktemp -d)"
trap 'rm -rf "$test_dir"' EXIT
if [[ -n "${JAVA_HOME:-}" && -x "$JAVA_HOME/bin/javac" ]]; then
  compiler="$JAVA_HOME/bin/javac"
  runtime="$JAVA_HOME/bin/java"
else
  compiler="$(command -v javac)"
  runtime="$(command -v java)"
fi
package="$project_root/app/src/main/java/com/sentongoharuna/worldsituationroom"
"$compiler" -encoding UTF-8 -d "$test_dir" \
  "$package/Duwm1728MeasurementMath.java" \
  "$package/Duwm1728Measurements.java" \
  "$project_root/verification/MeasurementPolicyTest.java"
"$runtime" -cp "$test_dir" com.sentongoharuna.worldsituationroom.MeasurementPolicyTest "$output_dir"
