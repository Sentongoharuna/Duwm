#!/usr/bin/env python3
"""Structural negative gate fixtures only; never runnable or physical evidence."""
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
from SceneSdkApkGateTest import dex_fixture
import verify_clear_picture_apk as gate


class ClearPictureApkGateTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="clear-picture-dex-gate-unit-")
        self.root = Path(self.temp.name)
        self.apk = self.root / "unit-structure.zip"
        self.dependency = self.root / "unit-dependency.json"
        self.dependency.write_text(json.dumps({"status": "PASS", "coordinate": gate.measured_gate.scene_gate.COORDINATE,
                                               "artifact_sha256": "0" * 64, "artifact_bytes": 1}))
        self.prior = list(gate.measured_gate.scene_gate.SDK_CLASSES + gate.measured_gate.scene_gate.APP_CLASSES
                          + gate.measured_gate.MEASUREMENT_CLASSES)
        self.names = self.prior + list(gate.CLEAR_PICTURE_CLASSES)

    def tearDown(self):
        self.temp.cleanup()

    def archive(self, defined):
        with zipfile.ZipFile(self.apk, "w") as archive:
            archive.writestr("classes.dex", dex_fixture(self.names, defined))

    def test_all_definitions_preserve_explicit_scope_limits(self):
        self.archive(self.names)
        result = gate.verify(self.apk, self.dependency)
        self.assertEqual("PASS", result["status"])
        for name in ("physical_sensor_verified", "physical_camera_verified", "model_inference_verified",
                     "native_encoder_verified", "encoded_picture_verified"):
            self.assertIs(False, result[name])

    def test_reference_strings_cannot_replace_either_new_definition(self):
        for name in gate.CLEAR_PICTURE_CLASSES:
            with self.subTest(name=name):
                self.archive([entry for entry in self.names if entry != name])
                with self.assertRaisesRegex(AssertionError, "clear-picture runtime DEX class definitions missing"):
                    gate.verify(self.apk, self.dependency)

    def test_new_classes_cannot_replace_any_prior_sdk_or_measurement_definition(self):
        for name in self.prior:
            with self.subTest(name=name):
                self.archive([entry for entry in self.names if entry != name])
                with self.assertRaises(AssertionError):
                    gate.verify(self.apk, self.dependency)

    def test_dependency_gate_cannot_be_bypassed_by_complete_dex(self):
        self.archive(self.names)
        report = json.loads(self.dependency.read_text())
        report["status"] = "FAIL"
        self.dependency.write_text(json.dumps(report))
        with self.assertRaises(AssertionError):
            gate.verify(self.apk, self.dependency)


if __name__ == "__main__":
    unittest.main(verbosity=2)
