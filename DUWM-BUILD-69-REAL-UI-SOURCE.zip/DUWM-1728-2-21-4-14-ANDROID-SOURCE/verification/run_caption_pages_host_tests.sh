#!/usr/bin/env bash
set -euo pipefail
pages_project="$(cd "$(dirname "$0")/.." && pwd)"
pages_proof="${1:-$pages_project/verification/caption-pages-host-proof}"
pages_javac="${JAVAC:-${JAVA_HOME:+$JAVA_HOME/bin/}javac}"
pages_java="${JAVA:-${JAVA_HOME:+$JAVA_HOME/bin/}java}"
pages_build="$(mktemp -d "${TMPDIR:-/tmp}/duwm-caption-pages.XXXXXX")"
trap 'rm -rf -- "$pages_build"' EXIT
pages_source="$pages_project/app/src/main/java/com/sentongoharuna/worldsituationroom"
"$pages_javac" --release 17 -encoding UTF-8 -d "$pages_build" \
  "$pages_source/Duwm1728BroadcastComposition.java" \
  "$pages_source/Duwm1728BroadcastLayout.java" "$pages_source/Duwm1728ClearPictureLayout.java" \
  "$pages_source/Duwm1728HeadlineFit.java" \
  "$pages_source/Duwm1728CaptionPages.java" \
  "$pages_source/Duwm1728TickerTimeline.java" \
  "$pages_source/Duwm1728CaptionEditPolicy.java" \
  "$pages_source/Duwm1728CaptionSrt.java" \
  "$pages_project/verification/broadcast/BroadcastRenderTest.java" \
  "$pages_project/verification/broadcast/CaptionPagesTest.java"
"$pages_java" -Xmx512m -Djava.awt.headless=true -cp "$pages_build" \
  com.sentongoharuna.worldsituationroom.CaptionPagesTest "$pages_proof"
