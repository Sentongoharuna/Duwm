#!/usr/bin/env python3
"""Compile an immutable legacy assertion against the extended Geometry schema.

Every delivered /20 field and every pixel comparison remains checked. The six
new /21/3 fields are separately required to be present and neutral in legacy
mode. Only the temporary test copy changes, never the historical source file.
"""
from pathlib import Path
import argparse
import hashlib

SOURCE_SHA256 = "520c41675946d785b45662d69a77b4af603d4dae4d8941a2ff0b074d4708b711"
BEFORE = 'for(java.lang.reflect.Field field:Duwm1728BroadcastLayout.Geometry.class.getFields())check(field.get(ga).equals(Duwm1728BroadcastLayout20.Geometry.class.getField(field.getName()).get(gb)),"All manual geometry fields match delivered /20");'
AFTER = '''for(java.lang.reflect.Field field:Duwm1728BroadcastLayout20.Geometry.class.getFields())check(field.get(gb).equals(Duwm1728BroadcastLayout.Geometry.class.getField(field.getName()).get(ga)),"All manual geometry fields match delivered /20");
            java.util.Set<String> actualFields=new java.util.HashSet<>(),expectedFields=new java.util.HashSet<>();
            for(java.lang.reflect.Field field:Duwm1728BroadcastLayout.Geometry.class.getFields())actualFields.add(field.getName());
            for(java.lang.reflect.Field field:Duwm1728BroadcastLayout20.Geometry.class.getFields())expectedFields.add(field.getName());
            expectedFields.addAll(java.util.Arrays.asList("clearPicture","clearSafeLeft","clearSafeTop","clearSafeWidth","clearSafeHeight","clearSafeAreaFraction"));
            check(actualFields.equals(expectedFields),"Only the six explicitly scoped clear-picture geometry fields extend the delivered /20 schema");
            check(!ga.clearPicture,"Legacy geometry keeps clear-picture flag false");
            check(ga.clearSafeLeft==0,"Legacy geometry keeps clearSafeLeft neutral");
            check(ga.clearSafeTop==0,"Legacy geometry keeps clearSafeTop neutral");
            check(ga.clearSafeWidth==0,"Legacy geometry keeps clearSafeWidth neutral");
            check(ga.clearSafeHeight==0,"Legacy geometry keeps clearSafeHeight neutral");
            check(ga.clearSafeAreaFraction==0,"Legacy geometry keeps clearSafeAreaFraction neutral");'''


def adapt(original: bytes) -> str:
    assert hashlib.sha256(original).hexdigest() == SOURCE_SHA256, "Immutable headline regression source changed"
    text = original.decode("utf-8")
    assert text.count(BEFORE) == 1, "Legacy reflection comparison anchor changed"
    return text.replace(BEFORE, AFTER, 1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("original", type=Path)
    parser.add_argument("temporary_copy", type=Path)
    args = parser.parse_args()
    assert args.original.resolve() != args.temporary_copy.resolve(), "Never overwrite historical test source"
    args.temporary_copy.write_text(adapt(args.original.read_bytes()))


if __name__ == "__main__":
    main()
