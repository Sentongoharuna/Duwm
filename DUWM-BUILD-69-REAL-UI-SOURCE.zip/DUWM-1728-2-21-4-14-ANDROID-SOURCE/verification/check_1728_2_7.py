#!/usr/bin/env python3
"""1728.2/7 real policy execution plus integration/preservation checks.
This script does NOT certify Android rendering, camera hardware or news output.
"""
from pathlib import Path
import hashlib,json,re,shutil,subprocess,tempfile,xml.etree.ElementTree as ET
from release_contract import assert_release_at_least
p=Path(__file__).resolve().parents[1]
j=p/'app/src/main/java/com/sentongoharuna/worldsituationroom'
read=lambda name:(j/name).read_text()
assert_release_at_least(p,1728)
assert 'versionCode = 172807' in (p/'app/build.gradle.kts').read_text()
assert 'versionName = "1728.2.7"' in (p/'app/build.gradle.kts').read_text()
cam=read('Duwm1718MonitorsCamActivity.java');center=read('Duwm1716SignalCenterActivity.java')
for token in ['new Duwm1728CaptureHealthView(this)','refreshCaptureHealth();','decodedFrameAt=SystemClock.elapsedRealtime()',
              'microphonePeak=amplitude','in.gpsAgeMs=age/1_000_000L','in.mockLocation=location.isFromMockProvider()',
              'compassAccuracy=event.accuracy','galleryResult=savedUri!=null?1:-1',
              'generation!=weatherGeneration','cameraUiActive=false;main.removeCallbacks(telemetryRefresh)']:
    assert token in cam,token
assert cam.index('page.addView(captureHealthDock') < cam.index('page.addView(recordDock')
assert 'Math.random' not in read('Duwm1728CaptureHealth.java')
assert 'HttpURLConnection' not in read('Duwm1728CaptureHealthView.java')
assert 'getElapsedRealtimeNanos()' in cam
for token in ['liveUi.postDelayed(this,2000L)','if(!visiblePage||isFinishing())return;',
              'receiptScroll.scrollTo(0,y)','if(!key.equals(observedKey))','counts[4]',
              'Stage.CONNECTING)counts[3]++']:
    assert token in center,token
assert 'new URL' not in center
assert read('MainActivity.java').count('new SatelliteMapView(this)')==1
assert 'Duwm1715SignalLights.attach(a)' in read('DuWorldApplication.java')
styles=(p/'app/src/main/res/values/styles.xml').read_text()
assert '@style/Theme.Duwm.Dialog' in styles and '@drawable/duwm_navy_dialog' in styles
shape=(p/'app/src/main/res/drawable/duwm_navy_dialog.xml').read_text()
assert '#041424' in shape and '#DEE5EF' in shape
# Camera capture code changed deliberately; all post-production modules retain their exact bytes.
base=json.loads((p/'verification/1728_2_5_camera_baseline.json').read_text())
kept=0
for name,expected in base.items():
    if name=='Duwm1718MonitorsCamActivity.java':continue
    assert hashlib.sha256((j/name).read_bytes()).hexdigest()==expected,('Unexpected inherited video/editor change',name)
    kept+=1
for f in (p/'app/src').rglob('*.xml'): ET.parse(f)
with tempfile.TemporaryDirectory() as temp:
    root=Path(temp);pkg=root/'com/sentongoharuna/worldsituationroom';pkg.mkdir(parents=True)
    for name in ('FeedStatus.java','Duwm1724SignalFlow.java','Duwm1728CaptureHealth.java'):
        shutil.copyfile(j/name,pkg/name)
    enum=re.search(r'public enum Layer\s*\{([^}]+)\}',read('Signal.java')).group(1)
    (pkg/'Signal.java').write_text('package com.sentongoharuna.worldsituationroom;public class Signal{public enum Layer{'+enum+'}}')
    shutil.copyfile(p/'verification/CaptureHealthTest.java',pkg/'CaptureHealthTest.java')
    subprocess.run(['javac','-d',temp,*map(str,pkg.glob('*.java'))],check=True)
    subprocess.run(['java','-cp',temp,'com.sentongoharuna.worldsituationroom.CaptureHealthTest'],check=True)
# Strict version-contract regression: new names pass only with the exact corresponding code.
version_cases=0
with tempfile.TemporaryDirectory() as temp:
    root=Path(temp);(root/'app').mkdir()
    for code,name,expected in [(172806,'1728.2.6',True),(172807,'1728.2.7',True),
                               (172700,'1727',True),(172700,'1728.2.7',False),
                               (172806,'1728.2.7',False),(172807,'1727',False),
                               (172807,'1728.3.7',False),(172807,'1728.2.07',False)]:
        (root/'app/build.gradle.kts').write_text(f'versionCode = {code}\nversionName = "{name}"\n')
        try:assert_release_at_least(root,1670);accepted=True
        except AssertionError:accepted=False
        assert accepted==expected,(code,name,expected);version_cases+=1
print('PASS camera-health wiring, navy dialogs, live summaries,',kept,'preserved editor modules, and',version_cases,'strict version cases')
print('NOT VERIFIED: Android compilation, emulator pixels, physical camera signals, MP4 output or AI production')
