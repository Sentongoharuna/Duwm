import com.sun.source.tree.*;
import com.sun.source.util.*;
import javax.lang.model.element.Modifier;
import javax.tools.*;
import java.util.*;

/** Parses the production editor, checks local automatic routing and rejects
 * unresolved self calls. Android Gradle compilation and native execution remain
 * separate mandatory gates; this parser does not resolve Android API types. */
public final class EditorAiEntrypointCheck {
    private static final Set<String> ENTRY_POINTS = Set.of(
        "startAi", "beginAi", "requestAi", "maybeStartAiAfterCapture", "applyAi", "aiSettings",
        "startAutomaticProduction", "transcribeAutomaticChunk", "finishAutomaticPlan",
        "maybeExportAutomatic", "failAutomatic", "automaticKey", "automaticReceipt", "export");
    public static void main(String[] args) throws Exception {
        if(args.length!=1)throw new IllegalArgumentException("Pass the production editor Java file");
        JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
        if(compiler==null)throw new IllegalStateException("JDK required");
        DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
        try(StandardJavaFileManager files=compiler.getStandardFileManager(diagnostics,null,null)) {
            JavacTask task=(JavacTask)compiler.getTask(null,files,diagnostics,
                List.of("-proc:none"),null,files.getJavaFileObjects(args[0]));
            CompilationUnitTree unit=task.parse().iterator().next();
            ClassTree editor=null;
            for(Tree declaration:unit.getTypeDecls())if(declaration instanceof ClassTree&&
                ((ClassTree)declaration).getSimpleName().contentEquals("Duwm1728VideoEditorActivity"))
                editor=(ClassTree)declaration;
            require(editor!=null,"Expected actual editor class");
            Map<String,Set<Integer>> signatures=new HashMap<>();
            Map<String,List<MethodTree>> methods=new HashMap<>();
            for(Tree member:editor.getMembers())if(member instanceof MethodTree){
                MethodTree method=(MethodTree)member;String name=method.getName().toString();
                signatures.computeIfAbsent(name,key->new HashSet<>()).add(method.getParameters().size());
                methods.computeIfAbsent(name,key->new ArrayList<>()).add(method);
            }
            List<String> failures=new ArrayList<>();
            new TreeScanner<Void,Void>() {
                @Override public Void visitMethodInvocation(MethodInvocationTree call,Void unused){
                    String name=selfName(call.getMethodSelect());
                    if(name!=null&&ENTRY_POINTS.contains(name)&&
                        !signatures.getOrDefault(name,Set.of()).contains(call.getArguments().size()))
                        failures.add("UNRESOLVED_AI_SELF_CALL "+name+"/"+call.getArguments().size());
                    if("beginAi".equals(name))failures.add("FORBIDDEN_CLOUD_SELF_CALL beginAi/"+call.getArguments().size());
                    return super.visitMethodInvocation(call,unused);
                }
                @Override public Void visitMemberReference(MemberReferenceTree call,Void unused){
                    String name=call.getName().toString();
                    if(isSelf(call.getQualifierExpression())&&ENTRY_POINTS.contains(name)&&!signatures.containsKey(name))
                        failures.add("UNRESOLVED_AI_REFERENCE "+name);
                    if(isSelf(call.getQualifierExpression())&&"beginAi".equals(name))failures.add("FORBIDDEN_CLOUD_REFERENCE beginAi");
                    return super.visitMemberReference(call,unused);
                }
            }.scan(editor,null);
            require(failures.isEmpty(),String.join("; ",failures));
            MethodTree automatic=method(methods,"maybeStartAiAfterCapture",0);
            MethodTree manual=method(methods,"requestAi",0);
            MethodTree help=method(methods,"aiSettings",0);
            MethodTree start=method(methods,"startAutomaticProduction",0);
            MethodTree finish=method(methods,"finishAutomaticPlan",0);
            MethodTree pending=method(methods,"maybeExportAutomatic",0);
            MethodTree export=method(methods,"export",1);
            MethodTree legacy=method(methods,"beginAi",1);
            require(selfCalls(method(methods,"onCreate",1)).contains("maybeStartAiAfterCapture"),"Fresh-recording entry is not scheduled by onCreate");
            require(selfCalls(automatic).contains("startAutomaticProduction"),"MISSING_LOCAL_AUTOMATIC_ROUTE maybeStartAiAfterCapture");
            require(calls(automatic).contains("shouldStart"),"Fresh-recording admission policy missing");
            require(selfCalls(manual).contains("startAutomaticProduction"),"MISSING_LOCAL_AUTOMATIC_ROUTE requestAi");
            require(selfCalls(help).contains("startAutomaticProduction"),"Built-in help must offer the same automatic path");
            require(!calls(help).contains("field"),"FORBIDDEN_SERVER_INPUT aiSettings field");
            new TreeScanner<Void,Void>() {
                @Override public Void visitNewClass(NewClassTree created,Void unused){
                    require(!created.getIdentifier().toString().endsWith("EditText"),"FORBIDDEN_SERVER_INPUT aiSettings EditText");
                    return super.visitNewClass(created,unused);
                }
            }.scan(help,null);
            require(selfCalls(start).containsAll(Set.of("automaticReceipt","transcribeAutomaticChunk","finishAutomaticPlan")),
                "Automatic start must persist its attempt and support real speech/fallback paths");
            require(calls(start).contains("compositionEditable")&&calls(start).contains("isFinishing"),"Automatic start is missing busy/lifecycle guards");
            require(calls(finish).contains("plan")&&selfCalls(finish).containsAll(Set.of("refresh","maybeExportAutomatic")),
                "Automatic completion must apply the production policy and continue toward MP4 export");
            require(hasBooleanCall(pending,"export",true),"Automatic plan does not invoke export(true)");
            require(pending.toString().contains("outputPlan"),"Automatic export must wait for the output inspection");
            String exported=export.toString();
            require(exported.contains("Duwm1728OverlayRenderer.prepare")&&exported.contains("Duwm1728OverlayRenderer.export")&&
                exported.contains("Duwm1728ExportRecovery.retain")&&exported.contains("Duwm1728ExportRecovery.publish"),
                "Automatic/manual export must retain the real renderer and durable publication pipeline");
            require(legacy.getModifiers().getFlags().contains(Modifier.PRIVATE)&&calls(legacy).contains("produce"),
                "Legacy client implementation unexpectedly changed");
            Set<String> reachable=new HashSet<>();
            ArrayDeque<String> queue=new ArrayDeque<>(List.of("maybeStartAiAfterCapture","requestAi","aiSettings"));
            while(!queue.isEmpty()){
                String name=queue.removeFirst();if(!reachable.add(name))continue;
                for(MethodTree body:methods.getOrDefault(name,List.of()))
                    for(String called:selfCalls(body))if(methods.containsKey(called))queue.addLast(called);
            }
            for(String name:reachable)for(MethodTree body:methods.getOrDefault(name,List.of()))inspectLocalRoute(body);
            inspectReviewedProvenance(export);
            for(Diagnostic<?> diagnostic:diagnostics.getDiagnostics())
                if(diagnostic.getKind()==Diagnostic.Kind.ERROR)throw new AssertionError(diagnostic.toString());
            System.out.println("PASS actual editor AST: fresh/manual entries use local automatic production; attempt receipt, policy, preflight and real export retained; no cloud entry, server input or forged approval. Self-call signatures resolve. Not an Android API compile or model-inference test.");
        }
    }
    private static MethodTree method(Map<String,List<MethodTree>> methods,String name,int arity){
        for(MethodTree method:methods.getOrDefault(name,List.of()))if(method.getParameters().size()==arity)return method;
        throw new AssertionError("MISSING_AI_METHOD "+name+"/"+arity);
    }
    private static boolean isSelf(ExpressionTree receiver){
        String value=receiver.toString();return value.equals("this")||value.equals("Duwm1728VideoEditorActivity.this");
    }
    private static String selfName(ExpressionTree selected){
        if(selected instanceof IdentifierTree)return ((IdentifierTree)selected).getName().toString();
        if(selected instanceof MemberSelectTree){MemberSelectTree member=(MemberSelectTree)selected;
            if(isSelf(member.getExpression()))return member.getIdentifier().toString();}
        return null;
    }
    private static Set<String> selfCalls(MethodTree method){
        Set<String> names=new HashSet<>();
        new TreeScanner<Void,Void>(){
            @Override public Void visitMethodInvocation(MethodInvocationTree call,Void unused){
                String name=selfName(call.getMethodSelect());if(name!=null)names.add(name);
                return super.visitMethodInvocation(call,unused);
            }
            @Override public Void visitMemberReference(MemberReferenceTree call,Void unused){
                if(isSelf(call.getQualifierExpression()))names.add(call.getName().toString());
                return super.visitMemberReference(call,unused);
            }
        }.scan(method,null);return names;
    }
    private static Set<String> calls(MethodTree method){
        Set<String> names=new HashSet<>();
        new TreeScanner<Void,Void>(){
            @Override public Void visitMethodInvocation(MethodInvocationTree call,Void unused){
                ExpressionTree selected=call.getMethodSelect();
                if(selected instanceof IdentifierTree)names.add(((IdentifierTree)selected).getName().toString());
                else if(selected instanceof MemberSelectTree)names.add(((MemberSelectTree)selected).getIdentifier().toString());
                return super.visitMethodInvocation(call,unused);
            }
        }.scan(method,null);return names;
    }
    private static boolean hasBooleanCall(MethodTree method,String name,boolean value){
        final boolean[] found={false};
        new TreeScanner<Void,Void>(){
            @Override public Void visitMethodInvocation(MethodInvocationTree call,Void unused){
                if(name.equals(selfName(call.getMethodSelect()))&&call.getArguments().size()==1&&
                    call.getArguments().get(0) instanceof LiteralTree&&
                    Boolean.valueOf(value).equals(((LiteralTree)call.getArguments().get(0)).getValue()))found[0]=true;
                return super.visitMethodInvocation(call,unused);
            }
        }.scan(method,null);return found[0];
    }
    private static void inspectLocalRoute(MethodTree method){
        new TreeScanner<Void,Void>(){
            @Override public Void visitNewClass(NewClassTree created,Void unused){
                require(!created.getIdentifier().toString().endsWith("Duwm1728AiProductionClient"),"CLOUD_CLIENT_REACHABLE_FROM_AUTOMATIC "+method.getName());
                return super.visitNewClass(created,unused);
            }
            @Override public Void visitMethodInvocation(MethodInvocationTree call,Void unused){
                ExpressionTree selected=call.getMethodSelect();
                if(selected instanceof MemberSelectTree){MemberSelectTree member=(MemberSelectTree)selected;
                    String receiver=member.getExpression().toString(),name=member.getIdentifier().toString();
                    require(!(receiver.equals("aiClient")&&name.equals("produce"))&&
                        !receiver.endsWith("Duwm1728AiProductionClient"),"CLOUD_CLIENT_REACHABLE_FROM_AUTOMATIC "+method.getName());
                    if(receiver.equals("approval")&&name.equals("setChecked")&&call.getArguments().size()==1&&
                        call.getArguments().get(0) instanceof LiteralTree)
                        require(!Boolean.TRUE.equals(((LiteralTree)call.getArguments().get(0)).getValue()),"FORGED_REVIEW_APPROVAL "+method.getName());
                }
                return super.visitMethodInvocation(call,unused);
            }
        }.scan(method,null);
    }
    private static boolean guaranteesManual(ExpressionTree expression){
        if(expression instanceof ParenthesizedTree)return guaranteesManual(((ParenthesizedTree)expression).getExpression());
        if(expression.getKind()==Tree.Kind.LOGICAL_COMPLEMENT)return ((UnaryTree)expression).getExpression().toString().equals("automatic");
        if(expression.getKind()==Tree.Kind.CONDITIONAL_AND){BinaryTree pair=(BinaryTree)expression;
            return guaranteesManual(pair.getLeftOperand())||guaranteesManual(pair.getRightOperand());}
        if(expression.getKind()==Tree.Kind.CONDITIONAL_OR){BinaryTree pair=(BinaryTree)expression;
            return guaranteesManual(pair.getLeftOperand())&&guaranteesManual(pair.getRightOperand());}
        return false;
    }
    private static void inspectReviewedProvenance(MethodTree export){
        new TreeScanner<Void,Boolean>(){
            @Override public Void visitIf(IfTree branch,Boolean manual){
                scan(branch.getCondition(),manual);
                scan(branch.getThenStatement(),Boolean.TRUE.equals(manual)||guaranteesManual(branch.getCondition()));
                scan(branch.getElseStatement(),manual);return null;
            }
            @Override public Void visitAssignment(AssignmentTree assignment,Boolean manual){
                if(assignment.getVariable().toString().endsWith(".provenance")&&assignment.getExpression().toString().contains("REPORTER REVIEWED"))
                    require(Boolean.TRUE.equals(manual),"FORGED_REVIEW_PROVENANCE automatic export");
                return super.visitAssignment(assignment,manual);
            }
        }.scan(export,false);
    }
    private static void require(boolean value,String message){if(!value)throw new AssertionError(message);}
}
