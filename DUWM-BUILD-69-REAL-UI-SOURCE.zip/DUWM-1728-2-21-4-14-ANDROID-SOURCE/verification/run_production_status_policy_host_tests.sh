#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
PKG="$TMP/com/sentongoharuna/worldsituationroom"
mkdir -p "$PKG"
cat > "$PKG/Duwm1728BroadcastLayout.java" <<'JAVA'
package com.sentongoharuna.worldsituationroom;
public final class Duwm1728BroadcastLayout {
  public static final class Report {
    public boolean productionRecording, productionLive, gpsLocked;
    public String aiStatus="AI WAIT";
    public long measuredSourceMs=-1;
  }
}
JAVA
cp "$ROOT/app/src/main/java/com/sentongoharuna/worldsituationroom/Duwm1728ProductionStatus.java" "$PKG/"
cp "$ROOT/verification/broadcast/ProductionStatusPolicyTest.java" "$PKG/"
javac -d "$TMP/classes" "$PKG"/*.java
java -cp "$TMP/classes" com.sentongoharuna.worldsituationroom.ProductionStatusPolicyTest
