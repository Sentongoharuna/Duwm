package com.sentongoharuna.worldsituationroom;

import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Exercises the actual automatic policy/shared layout with the exact native
 * fixture. Desktop fonts and the explicit narrow-metric boundary below are
 * host evidence only; Android Paint and decoded-MP4 checks stay in instrumentation. */
public final class AutomaticHeadlineFixtureTest {
    private static int checks;
    private static final String OLD_WORDS="WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW TAIL";
    private static final int[][] PORTRAITS={{720,800},{720,1280},{1080,1920},{1072,1920},{540,960}};
    private static void check(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
    private static final class Text {
        final String value;final float x,y,size,width;final boolean bold;final int color;final Rectangle2D clip;
        Text(String value,float x,float y,float size,float width,boolean bold,int color,Rectangle2D clip){
            this.value=value;this.x=x;this.y=y;this.size=size;this.width=width;this.bold=bold;this.color=color;this.clip=clip;
        }
    }
    private static final class Painter implements Duwm1728BroadcastLayout.Painter {
        final String family;final float advanceScale;
        final FontRenderContext metrics=new FontRenderContext(new AffineTransform(),true,true);
        final List<Text> texts=new ArrayList<>();final Deque<Rectangle2D> clips=new ArrayDeque<>();
        Painter(String family,float scale){this.family=family;advanceScale=scale;}
        public void rect(float x,float y,float w,float h,int color,float radius){}
        public void line(float x,float y,float xx,float yy,int color,float width){}
        public void text(String value,float x,float y,float size,int color,boolean bold){
            texts.add(new Text(value,x,y,size,measure(value,size,bold),bold,color,
                clips.isEmpty()?null:(Rectangle2D)clips.peek().clone()));
        }
        public float measure(String value,float size,boolean bold){return advanceScale*(float)new Font(family,bold?Font.BOLD:Font.PLAIN,1).deriveFont(size).getStringBounds(value,metrics).getWidth();}
        public Object captionMeasurementKey(){return Arrays.asList(getClass(),family,advanceScale,metrics);}
        public void clip(float x,float y,float w,float h){Rectangle2D next=new Rectangle2D.Float(x,y,w,h);if(!clips.isEmpty())next=next.createIntersection(clips.peek());clips.push(next);}
        public void unclip(){clips.pop();}
    }
    private static Duwm1728AutomaticProduction.Plan automatic(String words){
        return Duwm1728AutomaticProduction.plan(2000,Arrays.asList(new Duwm1728BroadcastLayout.Cue(137,1937,words)),"SYNTHETIC SUPPLIED PORTRAIT WORDS","");
    }
    private static Duwm1728BroadcastLayout.Report report(Duwm1728AutomaticProduction.Plan plan,boolean fitted){
        Duwm1728BroadcastLayout.Report r=new Duwm1728BroadcastLayout.Report();r.title=plan.title;r.description=plan.description;
        r.composition=plan.composition;r.provenance=plan.provenance;r.automaticHeadlineFit=fitted;return r;
    }
    private static List<Text> rows(Painter p,Duwm1728BroadcastLayout.Geometry g){
        List<Text> result=new ArrayList<>();for(Text text:p.texts)if(text.bold&&text.color==Duwm1728BroadcastLayout.WHITE&&text.y>=g.headlineTop&&text.y<g.headlineTop+g.headlineHeight)result.add(text);return result;
    }
    private static String visible(List<Text> rows){StringBuilder result=new StringBuilder();for(Text text:rows)result.append(text.value.replace(" ",""));return result.toString();}
    private static void twoRows(String family,float scale,Duwm1728AutomaticProduction.Plan plan,int[] size){
        String label=family+" scale="+scale+" "+size[0]+"x"+size[1]+": ";Painter p=new Painter(family,scale);
        Duwm1728BroadcastLayout.Report r=report(plan,true);Duwm1728BroadcastLayout.Geometry g=Duwm1728BroadcastLayout.draw(p,size[0],size[1],r,1000);
        float available=g.width-44*g.unit;List<Text> rows=rows(p,g);
        check(!g.clearPicture&&g.headlineVisible&&"COMPACT".equals(g.composition),label+"actual retained compact headline path");
        check(p.measure(plan.title,28*g.unit,true)>available+.02f&&p.measure(plan.title,22*g.unit,true)>available+.02f,label+"fixture exceeds both unreduced and first wrapped widths");
        check(rows.size()==2,label+"actual shared painter draws two rows");
        check(visible(rows).equals(plan.title.replace(" ","")),label+"complete selected source headline retained");
        check(rows.get(1).value.endsWith("TAIL"),label+"final source marker in the second row");
        for(Text text:rows){check(Math.abs(text.x-(g.x+22*g.unit))<.02f&&text.width<=available+.02f,label+"complete measured row fits the original viewport");
            check(text.clip!=null&&text.clip.getMaxY()<=g.headlineTop+57*g.unit+.02f,label+"headline remains in its separate upper band");}
        List<Text> bylines=new ArrayList<>();for(Text text:p.texts)if(!text.bold&&text.color==Duwm1728BroadcastLayout.SILVER&&text.y>=g.headlineTop&&text.y<g.headlineTop+g.headlineHeight)bylines.add(text);
        check(bylines.size()==1&&bylines.get(0).clip.getMinY()>=g.headlineTop+59*g.unit-.02f,label+"byline remains in its separate lower band");
        Painter manual=new Painter(family,scale);Duwm1728BroadcastLayout.Geometry old=Duwm1728BroadcastLayout.draw(manual,size[0],size[1],report(plan,false),1000);
        check(rows(manual,old).size()==1&&!visible(rows(manual,old)).equals(plan.title.replace(" ","")),label+"unchanged manual mode demonstrates original overflow");
        check(g.headlineTop==old.headlineTop&&g.headlineHeight==old.headlineHeight&&g.width==old.width,label+"fitting does not enlarge or move the existing panel");
    }
    private static String sha(byte[] bytes)throws Exception {StringBuilder s=new StringBuilder();for(byte b:MessageDigest.getInstance("SHA-256").digest(bytes))s.append(String.format(Locale.ROOT,"%02x",b&255));return s.toString();}
    public static void main(String[] args)throws Exception {
        if(args.length!=2)throw new IllegalArgumentException("native fixture Java path and evidence directory required");
        byte[] nativeBytes=Files.readAllBytes(Path.of(args[0]));Matcher fixture=Pattern.compile("private static final String WORDS=\"([WTAIL]+)\";").matcher(new String(nativeBytes,StandardCharsets.UTF_8));
        check(fixture.find(),"read the actual native fixture literal, without a duplicate replacement string");String words=fixture.group(1);
        check(words.equals("W".repeat(44)+"TAIL")&&words.length()==Duwm1728AutomaticProduction.HEADLINE_EXCERPT_LIMIT,"fixture uses the existing 48-character source limit and distinct tail marker");
        Duwm1728AutomaticProduction.Plan plan=automatic(words);check(plan.title.equals("SOURCE WORDS • "+words)&&plan.title.length()==63,"real automatic policy keeps the complete labelled source without excerpt truncation");
        check(plan.cues.size()==1&&plan.cues.get(0).text.equals(words)&&plan.cues.get(0).startMs==137&&plan.cues.get(0).endMs==1937,"real automatic policy preserves source caption words and timing");
        Set<String> installed=new HashSet<>(Arrays.asList(GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames(Locale.ROOT)));
        List<String> fonts=new ArrayList<>(),skipped=new ArrayList<>();fonts.add("SansSerif");check(installed.contains("DejaVu Sans"),"required real DejaVu Sans is installed");fonts.add("DejaVu Sans");
        for(String family:new String[]{"Liberation Sans","Noto Sans","DejaVu Math TeX Gyre"})if(installed.contains(family))fonts.add(family);else skipped.add(family);
        for(String family:fonts){check(family.equals(new Font(family,Font.BOLD,1).getFamily(Locale.ROOT)),"font family resolves explicitly: "+family);for(int[] size:PORTRAITS)twoRows(family,1,plan,size);}
        // A deliberate metric-boundary model reproduces the lost coverage: the
        // former phrase is complete on one reduced-size row, while the fixed
        // fixture still needs two. This is not an Android-font measurement.
        Painter actual=new Painter("SansSerif",1);Duwm1728AutomaticProduction.Plan old=automatic(OLD_WORDS);
        float scale=968/((actual.measure(old.title,22,true)+actual.measure(plan.title,22,true))/2);
        check(scale>0&&scale<1,"narrow-metric model is explicitly compressed");Painter narrow=new Painter("SansSerif",scale);
        Duwm1728BroadcastLayout.Geometry g=Duwm1728BroadcastLayout.draw(narrow,720,1280,report(old,true),1000);List<Text> oldRows=rows(narrow,g);
        check(oldRows.size()==1&&visible(oldRows).equals(old.title.replace(" ","")),"old fixed-width assumption fails despite complete, correctly fitted source text");
        check(oldRows.get(0).width<=g.width-44*g.unit+.02f,"old one-row outcome remains inside its viewport");
        for(int[] size:PORTRAITS)twoRows("SansSerif",scale,plan,size);
        String json="{\n  \"status\": \"PASS\",\n  \"scope\": \"ACTUAL_NATIVE_FIXTURE_WITH_SHARED_HOST_POLICY_AND_LAYOUT\",\n  \"checks\": "+checks+",\n  \"native_fixture_java_sha256\": \""+sha(nativeBytes)+"\",\n  \"font_families\": [\""+String.join("\", \"",fonts)+"\"],\n  \"skipped_optional_font_families\": "+(skipped.isEmpty()?"[]":"[\""+String.join("\", \"",skipped)+"\"]")+",\n  \"native_execution\": false,\n  \"narrow_metric_boundary_is_synthetic\": true,\n  \"narrow_metric_advance_scale\": "+scale+",\n  \"old_fixture_complete_but_one_row_reproduced\": true,\n  \"fixed_fixture_two_row_cases\": "+((fonts.size()+1)*PORTRAITS.length)+"\n}\n";
        Path folder=Path.of(args[1]);Files.createDirectories(folder);Files.writeString(folder.resolve("AUTO-FIT-FIXTURE-HOST.json"),json,StandardCharsets.UTF_8);
        System.out.println("PASS "+checks+" native-fixture source, measured two-row, TAIL, byline and narrow-metric regression checks; "+fonts.size()+" host fonts. No Android rendering or decoding claim.");
    }
}
