package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Executes the SAME framing maths as TextureView and the EGL encoder, no Android stubs. */
public final class BroadcastFramingTest {
    private static int checks;
    private static void check(boolean ok,String label){checks++;if(!ok)throw new AssertionError(label);}
    private static void near(double a,double b,String label){check(Math.abs(a-b)<.0002,label+" "+a+" != "+b);}
    private static void rejected(Runnable r,String label){boolean failed=false;try{r.run();}catch(IllegalArgumentException e){failed=true;}check(failed,label);}
    public static void main(String[] args){
        int[][] sources={{1920,1080},{1080,1920},{720,800},{3840,2160},{2160,3840},{1921,1081}};
        for(int[] src:sources)for(String ratio:new String[]{"9:10","9:16","16:9","ORIGINAL"})for(String mode:new String[]{"FIT","FILL"}){
            int[] out=Duwm1728FramePlan.dimensions(src[0],src[1],ratio,mode);
            check(out[0]%2==0&&out[1]%2==0,"even encoder dimensions");
            if(!ratio.equals("ORIGINAL")){String[] q=ratio.split(":");check(out[0]*Integer.parseInt(q[1])==out[1]*Integer.parseInt(q[0]),"exact output shape");}
            Duwm1728FramePlan.Plan f=Duwm1728FramePlan.create(src[0],src[1],out[0],out[1],mode,.27f,.81f);
            near(out[0]*f.width/(src[0]*f.w),out[1]*f.height/(src[1]*f.h),"isotropic image scale, no stretch");
            check(out[0]*f.width<=src[0]*f.w+.002&&out[1]*f.height<=src[1]*f.h+.002,"captured image is not upscaled");
            check(f.x>=0&&f.y>=0&&f.x+f.w<=1.00001&&f.y+f.h<=1.00001,"source crop inside recorded frame");
            check(f.left>=0&&f.top>=0&&f.left+f.width<=1.00001&&f.top+f.height<=1.00001,"destination fits frame");
            near(f.x*f.scaleX()+f.translateX(),f.left,"preview left agrees with export");
            near(f.y*f.scaleY()+f.translateY(),f.top,"preview top agrees with export");
            near((f.x+f.w)*f.scaleX()+f.translateX(),f.left+f.width,"preview right agrees with export");
            near((f.y+f.h)*f.scaleY()+f.translateY(),f.top+f.height,"preview bottom agrees with export");
            if(mode.equals("FIT")){near(f.w,1,"whole source width");near(f.h,1,"whole source height");check(f.croppedPercent()==0,"no crop in keep-full mode");}
            else{near(f.width,1,"fill output width");near(f.height,1,"fill output height");}
        }
        Duwm1728FramePlan.Plan left=Duwm1728FramePlan.create(1920,1080,1080,1920,"FILL",0,.5f);
        Duwm1728FramePlan.Plan right=Duwm1728FramePlan.create(1920,1080,1080,1920,"FILL",1,.5f);
        near(left.x,0,"leftmost subject included");near(right.x+right.w,1,"rightmost subject included");check(right.x>left.x,"horizontal pan changes real crop");
        Duwm1728FramePlan.Plan top=Duwm1728FramePlan.create(1080,1920,1920,1080,"FILL",.5f,0);
        Duwm1728FramePlan.Plan bottom=Duwm1728FramePlan.create(1080,1920,1920,1080,"FILL",.5f,1);
        near(top.y,0,"topmost subject included");near(bottom.y+bottom.h,1,"bottommost subject included");check(bottom.y>top.y,"vertical pan changes real crop");
        rejected(()->Duwm1728FramePlan.validate("FILL",Float.NaN,.5f),"NaN rejected");
        rejected(()->Duwm1728FramePlan.validate("FIT",.5f,Float.POSITIVE_INFINITY),"infinity rejected");
        rejected(()->Duwm1728FramePlan.validate("FILL",-1,.5f),"negative anchor rejected");
        rejected(()->Duwm1728FramePlan.validate("FILL",.5f,1.01f),"out of bounds anchor rejected");
        rejected(()->Duwm1728FramePlan.validate("FAKE",.5f,.5f),"unknown mode rejected");
        rejected(()->Duwm1728FramePlan.dimensions(0,1080,"16:9","FIT"),"bad source rejected");
        rejected(()->Duwm1728FramePlan.dimensions(1920,1080,"unknown","FIT"),"bad ratio rejected");
        rejected(()->Duwm1728FramePlan.create(1920,1080,0,10,"FIT",.5f,.5f),"bad output rejected");
        Duwm1728FramePlan.Inset portrait=Duwm1728FramePlan.inset(960,540,90,160);
        near(portrait.width,85.05,"portrait inset retains narrow width");
        near(portrait.height,151.2,"portrait inset fits available height");
        near(portrait.width/portrait.height,90d/160d,"portrait inset has exact source proportions");
        Duwm1728FramePlan.Inset wide=Duwm1728FramePlan.inset(960,540,160,90);
        near(wide.width/wide.height,160d/90d,"landscape inset has exact source proportions");
        Duwm1728FramePlan.Inset small=Duwm1728FramePlan.inset(480,270,90,160);
        near(portrait.width,small.width*2,"preview and export inset geometry scales together");
        near(portrait.height,small.height*2,"preview and export inset height scales together");
        System.out.println("PASS "+checks+" executed framing assertions: ratios, fit, pan, preview/export equivalence, no-stretch/no-upscale, invalid inputs. Not an Android pixel test.");
    }
}
