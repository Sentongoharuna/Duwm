package com.sentongoharuna.worldsituationroom;

import java.awt.Color;
import java.awt.font.TextLayout;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.List;
import javax.imageio.ImageIO;

/** Synthetic observation fixtures exercise the real shared painter. This is
 * host layout evidence, never model inference, Android export or camera proof. */
public final class SceneLayoutTest {
    private static int checks;
    private static final int[][] SIZES={{720,800},{720,1280},{1280,720},{540,960},{960,540},{1080,1920},{1920,1080},{64,114}};
    private static final String TITLE="SYNTHETIC FRAME TITLE";
    private static final String DESCRIPTION="Returned fixture description follows the original recording time.";
    private static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    private static final class Text {
        final String value;final float x,y,size,width;final boolean bold;final int color;final Rectangle2D clip,ink;
        Text(String value,float x,float y,float size,float width,boolean bold,int color,Rectangle2D clip,Rectangle2D ink){
            this.value=value;this.x=x;this.y=y;this.size=size;this.width=width;this.bold=bold;this.color=color;this.clip=clip;this.ink=ink;
        }
    }
    private static final class Painter implements Duwm1728BroadcastLayout.Painter {
        final BroadcastRenderTest.Painter delegate;final List<Text> texts=new ArrayList<>();final Deque<Rectangle2D> clips=new ArrayDeque<>();
        final int width,height;
        Painter(BufferedImage image){delegate=new BroadcastRenderTest.Painter(image);width=image.getWidth();height=image.getHeight();}
        public void rect(float x,float y,float w,float h,int color,float radius){delegate.rect(x,y,w,h,color,radius);}
        public void line(float x,float y,float xx,float yy,int color,float thickness){delegate.line(x,y,xx,yy,color,thickness);}
        public void text(String value,float x,float y,float size,int color,boolean bold){
            delegate.text(value,x,y,size,color,bold);Rectangle2D glyphs=value.isEmpty()?new Rectangle2D.Float():new TextLayout(value,delegate.g.getFont(),delegate.g.getFontRenderContext()).getBounds();
            texts.add(new Text(value,x,y,size,measure(value,size,bold),bold,color,clips.isEmpty()?new Rectangle2D.Float(0,0,width,height):(Rectangle2D)clips.peek().clone(),
                new Rectangle2D.Double(x+glyphs.getX(),y+glyphs.getY(),glyphs.getWidth(),glyphs.getHeight())));
        }
        public float measure(String text,float size,boolean bold){return delegate.measure(text,size,bold);}
        public Object captionMeasurementKey(){return Arrays.asList(Painter.class,"SansSerif",delegate.g.getFontRenderContext());}
        public void clip(float x,float y,float w,float h){Rectangle2D box=new Rectangle2D.Float(x,y,w,h);if(!clips.isEmpty())box=box.createIntersection(clips.peek());clips.push(box);delegate.clip(x,y,w,h);}
        public void unclip(){clips.pop();delegate.unclip();}
        boolean has(String word){return texts.stream().anyMatch(row->row.value.contains(word));}
        String all(){StringBuilder text=new StringBuilder();for(Text row:texts)text.append(row.value).append('\n');return text.toString();}
    }
    private static final class Frame implements AutoCloseable {
        final BufferedImage image;final Painter painter;final Duwm1728BroadcastLayout.Geometry geometry;
        Frame(int width,int height,Duwm1728BroadcastLayout.Report report,long at){
            image=new BufferedImage(width,height,BufferedImage.TYPE_INT_ARGB);java.awt.Graphics2D background=image.createGraphics();background.setColor(new Color(0x233948));background.fillRect(0,0,width,height);background.dispose();
            painter=new Painter(image);geometry=Duwm1728BroadcastLayout.draw(painter,width,height,report,at);
        }
        public void close(){painter.delegate.g.dispose();}
    }
    private static Duwm1728BroadcastLayout.Report report(String mode){
        Duwm1728BroadcastLayout.Report r=new Duwm1728BroadcastLayout.Report();r.composition=mode;r.automaticSceneTitles=true;
        r.sceneAtMs=500;r.sceneUntilMs=1400;r.sceneTitle=TITLE;r.sceneDescription=DESCRIPTION;r.sceneSource=Duwm1728SceneTimeline.SOURCE;
        r.title="OLD SPEECH HEADLINE";r.description="OLD CAPTURE NOTE";r.clock="RECORDED • SYNTHETIC FIXTURE";return r;
    }
    private static void bounds(Frame frame){
        float u=frame.geometry.unit;int headerRows=0,descriptionRows=0;
        for(Text row:frame.painter.texts){
            if(!row.bold||row.color!=Duwm1728BroadcastLayout.WHITE||row.value.isEmpty())continue;
            if(row.y>=frame.geometry.headerTop&&row.y<frame.geometry.headerBottom){
                headerRows++;check(Math.abs(row.size-22*u)<.001f,"Scene title keeps its readable bounded font size");
                check(row.x+row.width<=row.clip.getMaxX()+.1f,"Scene title measured width stays inside its header");
                check(row.clip.getMaxX()<frame.image.getWidth()-frame.geometry.x,"Scene header leaves room for the recording clock");
            }else if(row.y>=frame.geometry.headlineTop&&row.y<frame.geometry.headlineTop+frame.geometry.headlineHeight){
                descriptionRows++;check(row.size>=22*u-.001f,"Scene description does not shrink below its readable layout size");
                check(row.x+row.width<=row.clip.getMaxX()+.1f,"Scene description measured width stays inside its panel");
            }else continue;
            if(u>=.5f)check(row.ink.getMinY()>=row.clip.getMinY()-.1&&row.ink.getMaxY()<=row.clip.getMaxY()+.1,
                "Actual scene glyphs fit vertically: "+row.value+" ink="+row.ink+" clip="+row.clip);
        }
        check(headerRows>0&&headerRows<=2,"Scene header has at most two static rows");
        check(descriptionRows<=2,"Scene description has at most two static rows");
        check(frame.painter.clips.isEmpty(),"Scene rendering restores all clips");
    }
    private static void semantics(File folder)throws Exception {
        for(int[] size:SIZES)for(String mode:new String[]{"FULL","COMPACT","CAPTIONS"}){
            Duwm1728BroadcastLayout.Report r=report(mode);
            for(long at:new long[]{0,499,500,1399,1400,5000})try(Frame frame=new Frame(size[0],size[1],r,at)){
                boolean active=at>=500&&at<1400;
                check(Duwm1728BroadcastLayout.currentScene(r,at)==active,"Exact source observation boundaries");
                check(!frame.painter.has("DUWM")&&!frame.painter.has("WORLD MONITOR"),"Scene mode replaces fixed branding");
                check(!frame.painter.has("OLD SPEECH")&&!frame.painter.has("OLD CAPTURE"),"Speech and notes are never substituted for a model scene");
                check(frame.painter.has("SYNTHETIC FRAME")==active,"No future or stale scene title at "+at);
                check(frame.painter.has("SCENE UNAVAILABLE")==!active,"Neutral scene status at missing or expired times");
                bounds(frame);
            }
            try(Frame frame=new Frame(size[0],size[1],r,900)){
                check(!"CAPTIONS".equals(mode)||!frame.painter.has("Returned fixture"),"Caption-only composition keeps lower description panel hidden");
                if(size[0]==720&&size[1]==1280&&"COMPACT".equals(mode))check(ImageIO.write(frame.image,"png",new File(folder,"HOST-SCENE-CURRENT.png")),"Save current scene host image");
            }
            r.automaticSceneTitles=false;try(Frame legacy=new Frame(size[0],size[1],r,900)){
                check(legacy.painter.has("DUWM")&&legacy.painter.has("WORLD MONITOR"),"Legacy/manual branding stays selected by default");
                check(!legacy.painter.has("SYNTHETIC FRAME"),"Manual takeover hides scene track");
            }
        }
        Duwm1728BroadcastLayout.Report r=report("COMPACT");r.sceneSource="recorded-speech";
        try(Frame frame=new Frame(720,1280,r,900)){check(!frame.painter.has("SYNTHETIC FRAME")&&frame.painter.has("SCENE UNAVAILABLE"),"Non-model provenance cannot activate a visual title");}
        r.sceneSource=Duwm1728SceneTimeline.SOURCE;r.sceneNeutralTitle="CAMERA VIEW";
        try(Frame frame=new Frame(720,1280,r,1600)){check(frame.painter.has("CAMERA VIEW")&&!frame.painter.has("SYNTHETIC FRAME"),"Live camera neutral label clears expired scene words");check(ImageIO.write(frame.image,"png",new File(folder,"HOST-SCENE-EXPIRED.png")),"Save expired scene host image");}
        r.sceneAtMs=500;r.sceneUntilMs=1400;r.tickers.add(new Duwm1728BroadcastLayout.Cue(700,1000,"SOURCE WORDS • separate supplied soundtrack excerpt"));
        r.automaticTickerPages=true;r.captions.add(new Duwm1728BroadcastLayout.Cue(700,1000,"SPEECH CAPTION FIXTURE"));
        try(Frame frame=new Frame(1280,720,r,900)){check(frame.painter.has("SOURCE WORDS")&&frame.painter.has("SPEECH CAPTION"),"Actual timed speech and scene sources remain separate");check(frame.painter.has("AI SCENE"),"Frame descriptions identify their model source once");}
    }
    private static void overflow(File folder)throws Exception {
        String[] words={
            "WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW TAIL",
            "This deliberately long synthetic description has many words to exercise a bounded display without reducing the font into an unreadable size. The complete observation remains stored while visible overflow has an ellipsis.",
            "東京の街で人々が歩いています。広場では新しい建物が見えます。長い説明の末尾まで表示するための合成テストです。",
            "Cafe\u0301 👩🏽‍💻 🇺🇬 WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW 👩🏽‍💻 🇺🇬 TAIL",
            "😀".repeat(384)
        };
        for(int[] size:SIZES)for(String mode:new String[]{"COMPACT","FULL"})for(int index=0;index<words.length;index++){
            Duwm1728BroadcastLayout.Report r=report(mode);r.sceneTitle=words[index];r.sceneDescription=words[index];
            try(Frame frame=new Frame(size[0],size[1],r,800)){
                bounds(frame);check(r.sceneTitle.equals(words[index])&&r.sceneDescription.equals(words[index]),"Display fitting never rewrites stored model words");
                for(Text row:frame.painter.texts)if(row.bold&&row.color==Duwm1728BroadcastLayout.WHITE){
                    String visible=row.value.endsWith("…")?row.value.substring(0,row.value.length()-1):row.value;if(visible.isEmpty())continue;
                    int start=words[index].indexOf(visible),end=start+visible.length();List<Integer> boundaries=Duwm1728CaptionPages.clusterEnds(words[index]);
                    check(start>=0&&(start==0||boundaries.contains(start))&&boundaries.contains(end),"Scene wrapping and ellipsis preserve source clusters");
                }
                if(size[0]==720&&size[1]==1280&&"COMPACT".equals(mode)&&index==1)check(ImageIO.write(frame.image,"png",new File(folder,"HOST-SCENE-LONG.png")),"Save long scene host image");
            }
        }
    }
    public static void main(String[] args)throws Exception {
        File folder=new File(args.length==0?"scene-layout-host-proof":args[0]);if(!folder.isDirectory()&&!folder.mkdirs())throw new IllegalStateException("Cannot create host proof folder");
        semantics(folder);overflow(folder);
        String evidence="{\n  \"schema\": 1,\n  \"status\": \"PASS\",\n  \"checks\": "+checks+",\n  \"fixture_observations\": \"SYNTHETIC_TEST_DATA\",\n  \"model_inference_verified\": false,\n  \"android_export_verified\": false,\n  \"physical_camera_verified\": false\n}\n";
        Files.write(new File(folder,"SCENE-LAYOUT-HOST.json").toPath(),evidence.getBytes(StandardCharsets.UTF_8));
        System.out.println("PASS "+checks+" scene interval, stale/future suppression, readable glyph bounds and legacy selection checks. HOST SYNTHETIC FIXTURES ONLY; no model inference or Android export claim.");
    }
}
