package com.sentongoharuna.worldsituationroom;
public final class ProductionStatusPolicyTest{
 private static void ok(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] x){
  Duwm1728BroadcastLayout.Report r=new Duwm1728BroadcastLayout.Report();
  r.productionLive=true;r.measuredSourceMs=65000;r.gpsLocked=false;r.aiStatus="AI WAIT";
  String a=Duwm1728ProductionStatus.text(r,65000);ok(a.contains("LIVE"),"live");ok(a.contains("00:01:05"),"elapsed");ok(a.contains("GPS —"),"gps no false lock");ok(a.contains("AI WAIT"),"ai wait");
  r.productionLive=false;r.productionRecording=true;r.gpsLocked=true;r.aiStatus="AI ACTIVE";
  String b=Duwm1728ProductionStatus.text(r,65000);ok(b.contains("REC"),"rec");ok(b.contains("GPS LOCK"),"gps lock");ok(b.contains("AI ACTIVE"),"ai active");
  System.out.println("production status policy: PASS");
 }
}
