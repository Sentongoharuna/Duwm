package com.sentongoharuna.worldsituationroom;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import javax.imageio.ImageIO;

/** Executes the actual caption planner and shared production draw path. These
 * are desktop raster/contract checks, never Android or speech-recognition proof. */
public final class CaptionPagesTest {
    private static int checks;
    private static final String REPRO="Workers are continuing construction at the building while equipment moves around the site and pedestrians walk past the main entrance beside Wilson Road today.";
    private static final String LONG=REPRO+" The recording continues while people pass the entrance and vehicles move through the same picture. These exact supplied words must also appear at the end of the caption.";
    private static final int[][] SIZES={{720,800},{720,1280},{1280,720}};
    private static final String[] RATIOS={"9-10","9-16","16-9"};
    private static final Object FONT_KEY=Arrays.asList("AWT SansSerif",Font.BOLD,"fractional metrics");
    private static void check(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
    private static final class Painter implements Duwm1728BroadcastLayout.Painter {
        final BroadcastRenderTest.Painter draw;final Object key;final float factor;
        final List<String> caption=new ArrayList<>();boolean captionStarted;int measures;
        Painter(BufferedImage image){this(image,FONT_KEY,1f);}
        Painter(BufferedImage image,Object identity,float scale){draw=new BroadcastRenderTest.Painter(image);key=identity;factor=scale;}
        public void rect(float x,float y,float w,float h,int color,float radius){if(color==0xE4041424)captionStarted=true;draw.rect(x,y,w,h,color,radius);}
        public void line(float x,float y,float xx,float yy,int color,float width){draw.line(x,y,xx,yy,color,width);}
        public void text(String text,float x,float y,float size,int color,boolean bold){if(captionStarted)caption.add(text);draw.text(text,x,y,size,color,bold);}
        public float measure(String text,float size,boolean bold){measures++;return factor*draw.measure(text,size,bold);}
        public Object captionMeasurementKey(){return key;}
        public void clip(float x,float y,float w,float h){draw.clip(x,y,w,h);}
        public void unclip(){draw.unclip();}
        void close(){draw.g.dispose();}
    }
    private static BufferedImage background(int width,int height){
        BufferedImage image=new BufferedImage(width,height,BufferedImage.TYPE_INT_ARGB);Graphics2D g=image.createGraphics();
        g.setColor(new Color(0x233644));g.fillRect(0,0,width,height);g.setColor(new Color(0x40596A));
        for(int x=0;x<width;x+=Math.max(1,width/12))g.drawLine(x,0,x,height);
        for(int y=0;y<height;y+=Math.max(1,height/16))g.drawLine(0,y,width,y);
        g.setFont(new Font("SansSerif",Font.BOLD,Math.max(12,width/34)));g.setColor(new Color(0xDCE4EA));
        String text="SYNTHETIC SOURCE • HOST RENDER";g.drawString(text,(width-g.getFontMetrics().stringWidth(text))/2,(int)(height*.30));g.dispose();return image;
    }
    private static Duwm1728BroadcastLayout.Report report(String text,String composition){
        Duwm1728BroadcastLayout.Report report=new Duwm1728BroadcastLayout.Report();report.composition=composition;
        report.title="SUPPLIED CAPTION FIXTURE";report.description="Display timing is derived; source cue times stay exact.";
        report.category="FIELD REPORT";report.provenance="TEST WORDS • NOT RECOGNITION PROOF";
        report.captions=Collections.singletonList(new Duwm1728BroadcastLayout.Cue(700,6700,text));return report;
    }
    private static final class Frame {
        final BufferedImage image;final Painter painter;final Duwm1728BroadcastLayout.Geometry geometry;
        Frame(int width,int height,Duwm1728BroadcastLayout.Report report,long ms){image=background(width,height);painter=new Painter(image);geometry=Duwm1728BroadcastLayout.draw(painter,width,height,report,ms);painter.close();}
    }
    private static Duwm1728CaptionPages.Plan plan(Painter painter,int width,int height,String composition,String text){
        boolean only="CAPTIONS".equals(composition);float unit=Math.min(width,height)/1080f;
        float available=Math.min(width-68*unit,width*(width>height?(only?.80f:.73f):.88f))-32*unit;
        return Duwm1728CaptionPages.plan(painter,text,(only?32:29)*unit,true,available,2);
    }
    private static void sourceCoverage(Duwm1728CaptionPages.Plan plan,String source,Painter painter,float available){
        check(plan.text.equals(source),"Canonical source text stays exact");int offset=0;StringBuilder ranges=new StringBuilder(),visible=new StringBuilder();
        List<Integer> clusters=Duwm1728CaptionPages.clusterEnds(source);
        for(Duwm1728CaptionPages.Page page:plan.pages){
            check(page.startChar==offset&&page.endChar>page.startChar,"Page source slices cover contiguous characters");
            check(page.startChar==0||clusters.contains(page.startChar),"Page starts at a protected Unicode boundary");
            check(clusters.contains(page.endChar),"Page ends at a protected Unicode boundary");
            ranges.append(source,page.startChar,page.endChar);offset=page.endChar;
            check(!page.lines.isEmpty()&&page.lines.size()<=2,"Every page has one or two actual rows");
            for(String row:page.lines){
                visible.append(row.replace(" ",""));check(painter.measure(row,plan.textSize,true)<=available+.02f,"Measured row fits the caption panel");
                for(int c=0;c<row.length();c++){
                    char value=row.charAt(c);
                    if(Character.isHighSurrogate(value)){check(c+1<row.length()&&Character.isLowSurrogate(row.charAt(c+1)),"No split high surrogate");c++;}
                    else check(!Character.isLowSurrogate(value),"No split low surrogate");
                }
            }
        }
        check(ranges.toString().equals(source),"Every original source character remains represented in page ranges");
        check(visible.toString().equals(source.replace(" ","")),"Every visible non-space character appears once, in order, without generated ellipsis");
    }
    private static void actualDrawAndTimes(int width,int height,String composition,String source)throws Exception {
        Painter measure=new Painter(new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB));Duwm1728CaptionPages.Plan pages=plan(measure,width,height,composition,source);
        boolean only="CAPTIONS".equals(composition);float unit=Math.min(width,height)/1080f;
        float available=Math.min(width-68*unit,width*(width>height?(only?.80f:.73f):.88f))-32*unit;
        sourceCoverage(pages,source,measure,available);Duwm1728BroadcastLayout.Report report=report(source,composition);
        byte[] before=Duwm1728CaptionSrt.exportCues(report.captions,Duwm1728CaptionSrt.TimeBase.ORIGINAL,7000,0,7000);
        float top=-1,heightBefore=-1;
        for(int page=0;page<pages.pageCount();page++){
            long start=pages.pageStartMs(page,6000),end=pages.pageEndMs(page,6000);
            check(end>start&&pages.pageIndex(start,6000)==page&&pages.pageIndex(end-1,6000)==page,"Exact inclusive/exclusive display page interval");
            Frame actual=new Frame(width,height,report,700+start);
            check(actual.painter.caption.equals(pages.pages.get(page).lines),"Actual shared layout draws the selected page's complete rows");
            check(actual.geometry.captionVisible&&actual.geometry.captionTop>actual.geometry.headerBottom&&actual.geometry.captionBottom<actual.geometry.tagTop,"Caption panel stays inside the safe picture region");
            if(top<0){top=actual.geometry.captionTop;heightBefore=actual.geometry.captionHeight;}
            check(actual.geometry.captionTop==top&&actual.geometry.captionHeight==heightBefore,"Caption panel does not jump at a page change");
        }
        check(!new Frame(width,height,report,699).geometry.captionVisible,"No page before original source cue");
        check(!new Frame(width,height,report,6700).geometry.captionVisible,"No page at or after original source cue end");
        check(report.captions.get(0).text.equals(source)&&report.captions.get(0).startMs==700&&report.captions.get(0).endMs==6700,"Drawing never changes source cue words or times");
        byte[] after=Duwm1728CaptionSrt.exportCues(report.captions,Duwm1728CaptionSrt.TimeBase.ORIGINAL,7000,0,7000);
        check(Arrays.equals(before,after),"Exact exported source SRT bytes survive pagination and every frame draw");measure.close();
    }
    private static List<String> legacyRows(Painter painter,String text,float size,float width){
        ArrayList<String> rows=new ArrayList<>();String remaining=text;
        while(!remaining.isEmpty()&&rows.size()<2){
            if(rows.size()==1){if(painter.measure(remaining,size,true)>width)return Collections.emptyList();rows.add(remaining);break;}
            int end=remaining.length();while(end>0&&painter.measure(remaining.substring(0,end),size,true)>width)end=remaining.offsetByCodePoints(end,-1);
            if(end==0)end=remaining.offsetByCodePoints(0,1);if(end<remaining.length()){int space=remaining.lastIndexOf(' ',end);if(space>0)end=space;}
            rows.add(remaining.substring(0,end).trim());remaining=remaining.substring(end).trim();
        }
        return rows;
    }
    private static void fittingRegression(){
        for(int[] size:SIZES)for(String composition:new String[]{"FULL","COMPACT","CAPTIONS"})for(String source:new String[]{"Short caption.","Separate captions stay above the news ticker.","CAPTION ONE • Active from 500 to 2700 ms",REPRO}){
            Painter painter=new Painter(new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB));boolean only="CAPTIONS".equals(composition);float unit=Math.min(size[0],size[1])/1080f,font=(only?32:29)*unit;
            float available=Math.min(size[0]-68*unit,size[0]*(size[0]>size[1]?(only?.80f:.73f):.88f))-32*unit;
            List<String> old=legacyRows(painter,source,font,available);Duwm1728CaptionPages.Plan pages=plan(painter,size[0],size[1],composition,source);
            if(!old.isEmpty()){
                check(pages.pageCount()==1&&pages.pages.get(0).lines.equals(old),"Already-fitting caption keeps its exact established line breaks");
                check(pages.textSize==font&&pages.rows==old.size(),"Already-fitting caption keeps font size and panel geometry");
            }
            painter.close();
        }
    }
    private static void unicodeAndDense(){
        String[] clusters={"e\u0301","👩🏽‍🚒","👨‍👩‍👧‍👦","🇺🇬","한","1️⃣","🏴\uDB40\uDC67\uDB40\uDC62\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67\uDB40\uDC7F"};
        for(String cluster:clusters){
            check(Duwm1728CaptionPages.clusterEnds(cluster).equals(Collections.singletonList(cluster.length())),"Protected combining/emoji/flag/Jamo cluster stays atomic");
            String source=(cluster+" ").repeat(18).trim();Painter painter=new Painter(new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB));
            Duwm1728CaptionPages.Plan pages=Duwm1728CaptionPages.plan(painter,source,22,true,50,2);sourceCoverage(pages,source,painter,50);
            Duwm1728CaptionPages.Plan narrow=Duwm1728CaptionPages.plan(painter,cluster,22,true,2,2);
            check(narrow.pages.size()==1&&narrow.pages.get(0).lines.get(0).equals(cluster),"Overwide protected cluster stays fully present");
            check(painter.measure(cluster,narrow.textSize,true)<=2.02f,"Overwide atomic cluster fits after explicit size reduction");painter.close();
        }
        Painter painter=new Painter(new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB));Duwm1728CaptionPages.Plan dense=Duwm1728CaptionPages.plan(painter,"世界".repeat(250),20,true,120,2);
        sourceCoverage(dense,dense.text,painter,120);check(dense.pageCount()>5,"Maximum-size dense cue creates actual multiple pages");
        check(dense.minimumPageDurationMs(1)==0&&dense.codePointsPerSecond(1)==500000,"Impossible-to-read density is measurable, never hidden by a readability claim");
        check(dense.pageAt(0,1)!=null,"One-millisecond cue remains deterministic without divide-by-zero");
        for(long duration:new long[]{1000,6001,Long.MAX_VALUE})for(int page=0;page<dense.pageCount();page++){
            long start=dense.pageStartMs(page,duration),end=dense.pageEndMs(page,duration);
            check(start>=0&&end>=start&&end<=duration,"Page interval arithmetic cannot overflow");
            if(start<end)check(dense.pageIndex(start,duration)==page&&dense.pageIndex(end-1,duration)==page,"Large and uneven duration boundaries select exact page");
        }
        painter.close();
    }
    private static void cacheAndLimits(){
        Duwm1728CaptionPages.clearCache();Painter first=new Painter(new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB),"font-one",1),same=new Painter(new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB),"font-one",1),different=new Painter(new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB),"font-two",2),unknown=new Painter(new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB),null,1);
        Duwm1728CaptionPages.Plan one=Duwm1728CaptionPages.plan(first,REPRO,20,true,300,2);int initial=first.measures;
        check(one==Duwm1728CaptionPages.plan(first,REPRO,20,true,300,2)&&first.measures==initial,"Repeated video frame reuses measured plan without line breaking");
        check(one==Duwm1728CaptionPages.plan(same,REPRO,20,true,300,2)&&same.measures==0,"New frame adapter with same explicit immutable metrics reuses plan");
        Duwm1728CaptionPages.Plan two=Duwm1728CaptionPages.plan(different,REPRO,20,true,300,2);
        check(one!=two&&two.pageCount()>one.pageCount(),"Same adapter class with different metrics never shares wrong line breaks");
        check(Duwm1728CaptionPages.plan(unknown,REPRO,20,true,300,2)!=Duwm1728CaptionPages.plan(unknown,REPRO,20,true,300,2),"Unknown measurement identity safely disables shared cache");
        for(int index=0;index<80;index++)Duwm1728CaptionPages.plan(first,"Distinct cue "+index,20,true,300,2);
        check(Duwm1728CaptionPages.cachedPlans()==64,"Shared measured-plan memory is bounded to64 entries");
        check(Duwm1728CaptionPages.plan(first,"",20,true,300,2).pageCount()==0,"Empty cue has no blank caption panel");
        boolean oversized=false;try{Duwm1728CaptionPages.plan(first,"x".repeat(501),20,true,300,2);}catch(IllegalArgumentException expected){oversized=true;}check(oversized,"Planner retains500-character source limit");
        first.close();same.close();different.close();unknown.close();
    }
    private static void joinedWhitespace(){
        Painter painter=new Painter(new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB));
        for(String source:new String[]{"a\u200D b","a \u0301b","x a\u200D b y","x  \u0301b y","👩\u200D 🚒 next"})for(float width:new float[]{12,20,35,70}){
            Duwm1728CaptionPages.Plan plan=Duwm1728CaptionPages.plan(painter,source,20,true,width,2);sourceCoverage(plan,source,painter,width);
            List<Integer> ends=Duwm1728CaptionPages.clusterEnds(source);int cursor=0;
            for(Duwm1728CaptionPages.Page page:plan.pages)for(String row:page.lines){
                while(cursor<source.length()&&source.charAt(cursor)==' '&&(cursor==0||ends.contains(cursor))&&ends.contains(cursor+1))cursor++;
                check(cursor==0||ends.contains(cursor),"A row never starts inside a whitespace-bearing protected cluster");
                check(source.startsWith(row,cursor),"Row text retains exact joined spaces and combining marks");cursor+=row.length();
                check(ends.contains(cursor),"A row never ends inside a whitespace-bearing protected cluster");
            }
            check(cursor==source.length(),"Joined-space regression displays the complete exact source sequence");
        }
        painter.close();
    }
    private static void randomCoverage(){
        Random random=new Random(172819);String[] words={"ordinary","word","e\u0301","世界","👩🏽‍🚒","🇺🇬","caption,","exact.","한"};
        Painter painter=new Painter(new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB));
        for(int run=0;run<80;run++){
            StringBuilder source=new StringBuilder();int total=5+random.nextInt(38);
            for(int word=0;word<total;word++){if(word>0)source.append(' ');source.append(words[random.nextInt(words.length)]);}
            float width=70+random.nextInt(300);Duwm1728CaptionPages.Plan pages=Duwm1728CaptionPages.plan(painter,source.toString(),19,true,width,2);sourceCoverage(pages,source.toString(),painter,width);
        }
        painter.close();
    }
    private static void title(Graphics2D g,String text,int x,int y,int size,boolean bold){g.setFont(new Font("SansSerif",bold?Font.BOLD:Font.PLAIN,size));g.setColor(new Color(0xDEE5EF));g.drawString(text,x,y);}
    private static String sheet(File folder,int index)throws Exception {
        int width=SIZES[index][0],height=SIZES[index][1],tile=width>height?560:360,gap=20,top=130,shown=Math.round(height*tile/(float)width);
        Painter measure=new Painter(new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB));Duwm1728CaptionPages.Plan pages=plan(measure,width,height,"COMPACT",LONG);measure.close();
        int count=pages.pageCount();BufferedImage sheet=new BufferedImage(tile*count+gap*(count+1),top+shown+92,BufferedImage.TYPE_INT_RGB);Graphics2D g=sheet.createGraphics();
        g.setColor(new Color(0x07121D));g.fillRect(0,0,sheet.getWidth(),sheet.getHeight());g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        title(g,"HOST RENDERED • 1728.2/21 • "+RATIOS[index].replace('-',':')+" • complete caption pages",gap,34,24,true);
        title(g,"Shared production renderer on desktop. Synthetic supplied words; not Android footage or recognition proof.",gap,65,15,false);
        title(g,"Original cue [700, 6700) ms remains unchanged. The full text is displayed across "+count+" pages without an inserted ellipsis.",gap,90,15,false);
        for(int page=0;page<count;page++){
            long ms=700+pages.pageStartMs(page,6000);int x=gap+page*(tile+gap);
            title(g,"Page "+(page+1)+" / "+count+" • "+ms+" ms",x,116,18,true);
            Frame actual=new Frame(width,height,report(LONG,"COMPACT"),ms);g.drawImage(actual.image,x,top,tile,shown,null);
        }
        title(g,"Page times are display intervals, not invented spoken-word timestamps. Source SRT words and times remain exact.",gap,top+shown+32,15,false);
        title(g,"Density: "+String.format(java.util.Locale.ROOT,"%.1f",pages.codePointsPerSecond(6000))+" characters/s; minimum page "+pages.minimumPageDurationMs(6000)+" ms. Human readability is not asserted.",gap,top+shown+58,15,false);
        g.dispose();check(ImageIO.write(sheet,"png",new File(folder,"HOST-CAPTION-PAGES-"+RATIOS[index]+".png")),"Write actual shared-renderer pagination sheet");
        return "{\"ratio\":\""+RATIOS[index].replace('-',':')+"\",\"pages\":"+count+",\"code_points\":"+pages.codePoints+",\"minimum_page_ms\":"+pages.minimumPageDurationMs(6000)+"}";
    }
    public static void main(String[] args)throws Exception {
        File folder=new File(args.length==0?"caption-pages-host-proof":args[0]);if(!folder.isDirectory()&&!folder.mkdirs())throw new IOException("Cannot create host proof folder");
        fittingRegression();unicodeAndDense();joinedWhitespace();cacheAndLimits();randomCoverage();
        for(int[] size:SIZES)for(String composition:new String[]{"FULL","COMPACT","CAPTIONS"})for(String source:new String[]{REPRO,LONG,"世界".repeat(80),"👩🏽‍🚒 e\u0301 🇺🇬 한 ".repeat(15).trim()})actualDrawAndTimes(size[0],size[1],composition,source);
        ArrayList<String> summaries=new ArrayList<>();for(int index=0;index<SIZES.length;index++)summaries.add(sheet(folder,index));
        String result="{\n  \"status\": \"PASS\",\n  \"version\": \"1728.2/21\",\n  \"scope\": \"HOST_RENDERED_SHARED_CAPTION_PAGES\",\n  \"checks\": "+checks+",\n  \"native_executed\": false,\n  \"native_status\": \"NOT RUN\",\n  \"physical_camera_verified\": false,\n  \"speech_recognition_verified\": false,\n  \"source_words_and_times_unchanged\": true,\n  \"source_srt_bytes_unchanged\": true,\n  \"display_timing_is_derived\": true,\n  \"human_readability_asserted\": false,\n  \"cache_limit\": 64,\n  \"examples\": ["+String.join(",",summaries)+"]\n}\n";
        Files.write(new File(folder,"CAPTION-PAGES-HOST-RESULT.json").toPath(),result.getBytes(StandardCharsets.UTF_8));
        System.out.println("PASS "+checks+" caption-page source preservation, actual drawing, bounds, Unicode, exact display boundaries and cache checks. HOST RENDERED; native NOT RUN.");
    }
}
