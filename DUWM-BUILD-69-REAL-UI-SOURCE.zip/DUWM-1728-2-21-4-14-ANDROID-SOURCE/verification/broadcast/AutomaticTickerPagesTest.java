package com.sentongoharuna.worldsituationroom;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import javax.imageio.ImageIO;

/** Actual shared production plan, measured display policy and draw calls.
 * Desktop evidence only: synthetic supplied words, no Android/recognition claim. */
public final class AutomaticTickerPagesTest {
    private static final String WORDS="BROADCASTING DEVELOPMENTS WITHIN KAMPALA CONSTRUCTION PROJECTS WHILE MONITORING PEDESTRIAN MOVEMENTS AND OPERATIONAL EQUIPMENT ACROSS THE MAIN ENTRANCE AND SURROUNDING BUSINESSES.";
    private static final String[] SOURCES={
        "Workers are continuing construction at the building while equipment moves around the site and pedestrians walk past the main entrance beside Wilson Road today.",
        "Construction equipment continues operating alongside pedestrian crossings while surrounding businesses maintain normal trading activities and delivery vehicles pass through the nearby junction.",WORDS};
    private static final int[][] SIZES={{720,800},{720,1280},{1280,720}};
    private static final Object FONT_KEY=Arrays.asList("AWT SansSerif","fractional metrics");
    private static int checks,legacyClipped,cases;
    private static void check(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
    private static final class Drawn {
        final String text;final float x,size,width;
        Drawn(String value,float left,float font,float measured){text=value;x=left;size=font;width=measured;}
    }
    private static final class Painter implements Duwm1728BroadcastLayout.Painter {
        final BroadcastRenderTest.Painter canvas;final List<Drawn> ticker=new ArrayList<>();
        final float tickerLeft,tickerWidth,tickerBaseline;float clipLeft,clipWidth;boolean clipped;
        Painter(BufferedImage image,String composition){
            canvas=new BroadcastRenderTest.Painter(image);
            Duwm1728BroadcastLayout.Geometry g=new Duwm1728BroadcastLayout.Geometry(image.getWidth(),image.getHeight(),false,composition,0);
            boolean compact="COMPACT".equals(g.composition);float label=(compact?95:115)*g.unit;
            tickerLeft=g.x+label+16*g.unit;tickerWidth=g.width-label-30*g.unit;tickerBaseline=g.tickerTop+(compact?27:36)*g.unit;
        }
        public void rect(float x,float y,float width,float height,int color,float radius){canvas.rect(x,y,width,height,color,radius);}
        public void line(float x,float y,float xx,float yy,int color,float width){canvas.line(x,y,xx,yy,color,width);}
        public void text(String value,float x,float y,float size,int color,boolean bold){
            if(clipped&&!bold&&color==Duwm1728BroadcastLayout.WHITE&&Math.abs(y-tickerBaseline)<.02f&&Math.abs(clipLeft-tickerLeft)<.02f&&Math.abs(clipWidth-tickerWidth)<.02f)
                ticker.add(new Drawn(value,x,size,measure(value,size,false)));
            canvas.text(value,x,y,size,color,bold);
        }
        public float measure(String value,float size,boolean bold){return canvas.measure(value,size,bold);}
        public Object captionMeasurementKey(){return FONT_KEY;}
        public void clip(float x,float y,float width,float height){clipLeft=x;clipWidth=width;clipped=true;canvas.clip(x,y,width,height);}
        public void unclip(){clipped=false;canvas.unclip();}
        void close(){canvas.g.dispose();}
    }
    private static BufferedImage background(int width,int height){
        BufferedImage image=new BufferedImage(width,height,BufferedImage.TYPE_INT_ARGB);Graphics2D g=image.createGraphics();
        g.setColor(new Color(0x172632));g.fillRect(0,0,width,height);g.setColor(new Color(0x304756));
        for(int x=0;x<width;x+=Math.max(1,width/12))g.drawLine(x,0,x,height);
        for(int y=0;y<height;y+=Math.max(1,height/16))g.drawLine(0,y,width,y);
        g.setFont(new Font("SansSerif",Font.BOLD,Math.max(12,width/34)));g.setColor(new Color(0xDEE5EF));
        String label="SYNTHETIC SOURCE • HOST RENDER";g.drawString(label,(width-g.getFontMetrics().stringWidth(label))/2,(int)(height*.32));g.dispose();return image;
    }
    private static final class Frame {
        final BufferedImage image;final Painter painter;
        Frame(int width,int height,Duwm1728BroadcastLayout.Report report,long at){image=background(width,height);painter=new Painter(image,report.composition);Duwm1728BroadcastLayout.draw(painter,width,height,report,at);painter.close();}
    }
    private static Duwm1728AutomaticProduction.Plan plan(String source,int spacing){
        ArrayList<Duwm1728SpeechCues.Word> words=new ArrayList<>();long at=137;
        for(String word:(source+" "+source).split(" ")){words.add(new Duwm1728SpeechCues.Word(at,word));at+=spacing;}
        List<Duwm1728BroadcastLayout.Cue> captions=Duwm1728SpeechCues.fromWords(words,0,at+2000);
        return Duwm1728AutomaticProduction.plan(at+2000,captions,"SYNTHETIC SUPPLIED WORDS; no recognition performed","");
    }
    private static Duwm1728BroadcastLayout.Report report(Duwm1728AutomaticProduction.Plan plan,boolean automatic){
        Duwm1728BroadcastLayout.Report report=new Duwm1728BroadcastLayout.Report();report.composition="COMPACT";
        report.title=plan.title;report.description=plan.description;report.provenance="SYNTHETIC WORDS • UNREVIEWED";
        report.tickers=plan.tickers;report.captions=plan.cues;report.automaticTickerPages=automatic;return report;
    }
    private static Duwm1728CaptionPages.Plan pages(Painter painter,Duwm1728BroadcastLayout.Report report,int width,int height,String text){
        float unit=Math.min(width,height)/1080f;return Duwm1728CaptionPages.plan(painter,text,("COMPACT".equals(report.composition)?20:23)*unit,false,painter.tickerWidth,1);
    }
    private static void coverage(int width,int height,Duwm1728BroadcastLayout.Report report,Duwm1728BroadcastLayout.Cue cue){
        Painter measure=new Painter(new BufferedImage(width,height,BufferedImage.TYPE_INT_ARGB),report.composition);
        Duwm1728CaptionPages.Plan pages=pages(measure,report,width,height,cue.text);long duration=cue.endMs-cue.startMs;StringBuilder ranges=new StringBuilder(),visible=new StringBuilder();int offset=0;
        for(int index=0;index<pages.pageCount();index++){
            Duwm1728CaptionPages.Page page=pages.pages.get(index);check(page.lines.size()==1,"Automatic ticker has exactly one measured visible row per page");
            check(page.startChar==offset&&page.endChar>offset,"Ticker pages cover contiguous original character ranges");ranges.append(cue.text,page.startChar,page.endChar);offset=page.endChar;
            String row=page.lines.get(0);visible.append(row.replace(" ",""));check(measure.measure(row,pages.textSize,false)<=measure.tickerWidth+.02f,"Every automatic ticker page fits completely in its actual viewport");
            long start=pages.pageStartMs(index,duration),end=pages.pageEndMs(index,duration);
            if(end>start)for(long at:new long[]{cue.startMs+start,cue.startMs+end-1}){
                Frame frame=new Frame(width,height,report,at);check(frame.painter.ticker.size()==1,"Actual shared renderer draws one ticker page without repeated or moving copies");Drawn actual=frame.painter.ticker.get(0);
                check(actual.text.equals(row)&&Math.abs(actual.x-frame.painter.tickerLeft)<.02f,"Actual ticker selects the complete measured row at both page boundaries");
                check(actual.x+actual.width<=frame.painter.tickerLeft+frame.painter.tickerWidth+.02f,"Actual drawn ticker tail stays inside the viewport");
            }
        }
        check(ranges.toString().equals(cue.text),"Display pagination preserves every original excerpt character");
        check(visible.toString().equals(cue.text.replace(" ","")),"Every selected excerpt non-space character appears once in order without added ellipsis");measure.close();
    }
    private static void realPlanRegression(){
        for(String source:SOURCES)for(int spacing:new int[]{200,250,300}){
            Duwm1728AutomaticProduction.Plan plan=plan(source,spacing);Duwm1728BroadcastLayout.Cue cue=plan.tickers.get(0);
            byte[] srt=Duwm1728CaptionSrt.exportCues(plan.cues,Duwm1728CaptionSrt.TimeBase.ORIGINAL,plan.toMs,0,plan.toMs);
            for(int[] size:SIZES){
                cases++;Duwm1728BroadcastLayout.Report legacy=report(plan,false);Frame old=new Frame(size[0],size[1],legacy,cue.endMs-1);Drawn tail=old.painter.ticker.get(0);
                if(tail.x+tail.width>old.painter.tickerLeft+old.painter.tickerWidth+2)legacyClipped++;
                Duwm1728BroadcastLayout.Report fixed=report(plan,true);coverage(size[0],size[1],fixed,cue);
                check(fixed.tickers.get(0)==cue&&cue.startMs==plan.cues.get(0).startMs&&cue.endMs==plan.cues.get(0).endMs,"Measured display never mutates source interval or excerpt document");
            }
            check(Arrays.equals(srt,Duwm1728CaptionSrt.exportCues(plan.cues,Duwm1728CaptionSrt.TimeBase.ORIGINAL,plan.toMs,0,plan.toMs)),"Exact source SRT bytes survive all ticker page renders");
        }
        check(cases==27&&legacyClipped>=6,"Real source-word grouping reproduces inherited unseen ticker tails before pagination");
    }
    private static void boundariesAndManual(){
        Duwm1728AutomaticProduction.Plan plan=plan(WORDS,250);Duwm1728BroadcastLayout.Report automatic=report(plan,true);Duwm1728BroadcastLayout.Cue original=automatic.tickers.get(0);
        List<Duwm1728BroadcastLayout.Cue> source=Collections.singletonList(new Duwm1728BroadcastLayout.Cue(137,3637,original.text));
        List<Duwm1728BroadcastLayout.Cue> rebased=Duwm1728BroadcastTimeline.captions(source,300,3200);
        check(rebased.size()==1&&rebased.get(0).startMs==0&&rebased.get(0).endMs==2900&&rebased.get(0).text.equals(original.text),"Trim intersects/rebases exact millisecond ticker bounds without rewriting excerpt");
        automatic.tickers=rebased;coverage(720,1280,automatic,rebased.get(0));
        check(source.get(0).startMs==137&&source.get(0).endMs==3637,"Trim leaves original source cue interval intact");
        Duwm1728BroadcastLayout.Report manual=report(plan,false);Frame a=new Frame(720,1280,manual,original.startMs+100),b=new Frame(720,1280,manual,original.startMs+600);
        check(a.painter.ticker.get(0).text.equals(original.text)&&b.painter.ticker.get(0).text.equals(original.text),"Manual marquee retains original complete string");
        check(Math.abs((a.painter.ticker.get(0).x-b.painter.ticker.get(0).x)-25)<.03f,"Manual marquee retains selected75px/s scaled movement");
        Duwm1728BroadcastLayout.Report gap=report(plan,true);gap.tickers=Collections.singletonList(new Duwm1728BroadcastLayout.Cue(700,1700,"Exact short update"));
        Frame before=new Frame(720,1280,gap,699),start=new Frame(720,1280,gap,700),end=new Frame(720,1280,gap,1700);
        check(before.painter.ticker.get(0).text.equals(gap.description)&&end.painter.ticker.get(0).text.equals(gap.description),"Outside original cue interval the neutral fallback retains its established behavior");
        check(start.painter.ticker.size()==1&&start.painter.ticker.get(0).text.equals("Exact short update"),"Short automatic ticker remains fully visible from exact start boundary");
        gap.composition="FULL";coverage(720,800,gap,gap.tickers.get(0));
        gap.composition="CAPTIONS";check(new Frame(720,800,gap,1000).painter.ticker.isEmpty(),"Caption-only composition still hides ticker entirely");
    }
    private static void unicodeAndDensity(){
        Duwm1728BroadcastLayout.Report report=new Duwm1728BroadcastLayout.Report();report.automaticTickerPages=true;report.composition="COMPACT";
        for(String text:new String[]{("👩🏽‍🚒 café 🇺🇬 世界 한 ").repeat(12).trim(),"Ｗ".repeat(118),"W".repeat(500)}){
            Duwm1728BroadcastLayout.Cue cue=new Duwm1728BroadcastLayout.Cue(0,6000,text);report.tickers=Collections.singletonList(cue);coverage(720,1280,report,cue);
        }
        Duwm1728BroadcastLayout.Cue dense=new Duwm1728BroadcastLayout.Cue(0,1,"W".repeat(500));report.tickers=Collections.singletonList(dense);
        Painter painter=new Painter(new BufferedImage(720,1280,BufferedImage.TYPE_INT_ARGB),report.composition);Duwm1728CaptionPages.Plan pages=pages(painter,report,720,1280,dense.text);
        check(pages.pageCount()>1&&pages.minimumPageDurationMs(1)==0,"Sub-frame dense cue is measurable without claiming all pages can reach encoded frames");
        check(new Frame(720,1280,report,0).painter.ticker.size()==1,"One-millisecond display remains deterministic without division by zero");painter.close();
    }
    private static void label(Graphics2D g,String text,int x,int y,int size,boolean bold){g.setFont(new Font("SansSerif",bold?Font.BOLD:Font.PLAIN,size));g.setColor(new Color(0xDEE5EF));g.drawString(text,x,y);}
    private static String sheet(File folder,int width,int height)throws Exception {
        Duwm1728AutomaticProduction.Plan plan=plan(WORDS,250);Duwm1728BroadcastLayout.Cue cue=plan.tickers.get(0);Duwm1728BroadcastLayout.Report fixed=report(plan,true);
        Painter measure=new Painter(new BufferedImage(width,height,BufferedImage.TYPE_INT_ARGB),"COMPACT");Duwm1728CaptionPages.Plan pages=pages(measure,fixed,width,height,cue.text);measure.close();long duration=cue.endMs-cue.startMs;
        int tile=width>height?560:360,gap=20,top=145,shown=Math.round(height*tile/(float)width);BufferedImage image=new BufferedImage(tile*3+gap*4,top+shown+96,BufferedImage.TYPE_INT_RGB);Graphics2D g=image.createGraphics();
        g.setColor(new Color(0x07121D));g.fillRect(0,0,image.getWidth(),image.getHeight());g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        label(g,"HOST RENDERED • 1728.2/21 • automatic source ticker pages",gap,34,24,true);
        label(g,"Actual shared production renderer. Synthetic supplied words; not Android footage or recognition evidence.",gap,63,15,false);
        label(g,"Selected excerpt and original interval ["+cue.startMs+", "+cue.endMs+") ms remain exact. Measured pages add no new source words.",gap,88,15,false);
        long first=cue.startMs,last=cue.endMs-1;Frame[] frames={new Frame(width,height,report(plan,false),last),new Frame(width,height,fixed,first),new Frame(width,height,fixed,last)};
        String[] labels={"Inherited fixed-speed path • cue end","Measured first page • "+first+" ms","Measured last page • "+last+" ms"};
        for(int i=0;i<frames.length;i++){int x=gap+i*(tile+gap);label(g,labels[i],x,120,16,true);g.drawImage(frames[i].image,x,top,tile,shown,null);}
        label(g,"Pages: "+pages.pageCount()+" • shortest display interval: "+pages.minimumPageDurationMs(duration)+" ms • "+String.format(Locale.ROOT,"%.1f",pages.codePointsPerSecond(duration))+" characters/s.",gap,top+shown+34,16,true);
        label(g,"Page time is derived display policy. Dense/short cues may remain too fast to read or may exceed video frame sampling.",gap,top+shown+61,14,false);g.dispose();
        String name="HOST-AUTOMATIC-TICKER-PAGES-"+width+"x"+height+".png";check(ImageIO.write(image,"png",new File(folder,name)),"Write actual shared renderer comparison sheet");
        return "{\"width\":"+width+",\"height\":"+height+",\"pages\":"+pages.pageCount()+",\"minimum_page_ms\":"+pages.minimumPageDurationMs(duration)+",\"human_readability_asserted\":false}";
    }
    public static void main(String[] args)throws Exception {
        File folder=new File(args.length==0?"verification/automatic-ticker-pages-host-proof":args[0]);Files.createDirectories(folder.toPath());
        realPlanRegression();boundariesAndManual();unicodeAndDensity();ArrayList<String> images=new ArrayList<>();for(int[] size:SIZES)images.add(sheet(folder,size[0],size[1]));
        String result="{\n  \"status\":\"PASS\",\n  \"scope\":\"ACTUAL_SHARED_PRODUCTION_PLAN_AND_RENDERER_HOST_ONLY\",\n  \"checks\":"+checks+",\n  \"source_word_cases\":"+cases+",\n  \"legacy_cases_with_unseen_tail\":"+legacyClipped+",\n  \"native_execution\":false,\n  \"speech_recognition_executed\":false,\n  \"excerpt_words_and_times_preserved\":true,\n  \"source_srt_bytes_unchanged\":true,\n  \"manual_marquee_preserved\":true,\n  \"human_readability_asserted\":false,\n  \"rendered_examples\":["+String.join(",",images)+"]\n}\n";
        Files.write(new File(folder,"AUTOMATIC-TICKER-PAGES-HOST.json").toPath(),result.getBytes(StandardCharsets.UTF_8));System.out.println("PASS "+checks+" automatic ticker page checks; "+legacyClipped+"/"+cases+" inherited unseen-tail cases repaired. Host only; no Android or recognition proof.");
    }
}
