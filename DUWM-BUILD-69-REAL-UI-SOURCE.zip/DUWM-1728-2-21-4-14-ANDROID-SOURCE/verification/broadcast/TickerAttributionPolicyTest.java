package com.sentongoharuna.worldsituationroom;
public final class TickerAttributionPolicyTest {
  private static void ok(boolean v,String m){if(!v)throw new AssertionError(m);}
  public static void main(String[] a){
    ok("RECORDED SPEECH  •  00:55  |  Road closed".equals(Duwm1728TickerAttribution.decorate("RECORDED_SPEECH",55000,"Road closed")),"speech + original time");
    ok(Duwm1728TickerAttribution.decorate("CAPTURE_NOTES",3723000,"Heavy rain").startsWith("CAPTURE NOTES  •  1:02:03  |"),"hour clock");
    ok(Duwm1728TickerAttribution.decorate("",0,"Update").startsWith("REPORTER ENTRY  •  00:00  |"),"truthful manual fallback");
    System.out.println("ticker attribution policy: PASS");
  }
}
