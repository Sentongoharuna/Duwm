package com.sentongoharuna.worldsituationroom;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import com.sentongoharuna.worldsituationroom.Duwm1728SpeechLanguagePolicy.Action;
import com.sentongoharuna.worldsituationroom.Duwm1728SpeechLanguagePolicy.Choice;
import com.sentongoharuna.worldsituationroom.Duwm1728SpeechLanguagePolicy.Decision;
import com.sentongoharuna.worldsituationroom.Duwm1728SpeechLanguagePolicy.SupportFlow;

/** Executes the real pure selection and two-query policy. Script values below
 * are explicit test inputs, not a substitute for Android ICU or a speech model.
 * No Android service, PCM delivery, callback transport or language accuracy is
 * claimed verified by these host-only boundary tests. */
public final class SpeechLanguagePolicyTest {
    private static int checks,selectionChecks,flowChecks;
    private static boolean flows;
    private static final List<String> EMPTY=Collections.emptyList();
    private static void check(boolean value,String message){
        checks++;if(flows)flowChecks++;else selectionChecks++;
        if(!value)throw new AssertionError(message);
    }
    private static String script(String tag){
        Locale locale=Locale.forLanguageTag(tag);String explicit=locale.getScript();
        if(!explicit.isEmpty())return explicit;
        switch(locale.getLanguage()){
            case "en":case "es":case "fr":case "de":case "sw":return "Latn";
            case "sr":case "ru":return "Cyrl";
            case "zh":return Arrays.asList("TW","HK","MO").contains(locale.getCountry())?"Hant":"Hans";
            case "pa":return "PK".equals(locale.getCountry())?"Arab":"Guru";
            default:return "";
        }
    }
    private static Choice choose(String requested,List<String> installed,List<String> pending,List<String> downloadable){
        return Duwm1728SpeechLanguagePolicy.choose(requested,installed,pending,downloadable,SpeechLanguagePolicyTest::script);
    }
    private static Choice installed(String requested,String... models){return choose(requested,Arrays.asList(models),EMPTY,EMPTY);}
    private static void choice(String requested,String expectedStatus,String selected,String... models){
        Choice got=installed(requested,models);
        check(expectedStatus.equals(got.status)&&selected.equals(got.selectedLanguage),
                requested+" / "+Arrays.toString(models)+" expected "+expectedStatus+" "+selected+" got "+got.status+" "+got.selectedLanguage);
    }
    private static SupportFlow flow(){return new SupportFlow("en-UG",SpeechLanguagePolicyTest::script);}
    private static Decision support(SupportFlow flow,int n,String... installed){return flow.support(n,Arrays.asList(installed),EMPTY,EMPTY);}
    private static void terminal(SupportFlow flow,int last){
        check(support(flow,last,"en-UG","en-GB").action==Action.IGNORE,"Late installed result cannot revive terminal flow");
        check(flow.error(last,"late error").action==Action.IGNORE,"Late error cannot change terminal flow");
        check(flow.begin().action==Action.IGNORE,"Terminal flow cannot restart");
    }
    public static void main(String[] args)throws Exception{
        check("en-UG".equals(Duwm1728SpeechLanguagePolicy.normalize("EN_ug")),"Normalize case and underscore without dropping region");
        check("zh-Hant-TW".equals(Duwm1728SpeechLanguagePolicy.normalize("zh_hANT_tw")),"Preserve explicit script");
        check("es-419".equals(Duwm1728SpeechLanguagePolicy.normalize("es-419")),"Numeric region remains usable");
        check("sl-rozaj".equals(Duwm1728SpeechLanguagePolicy.normalize("sl-rozaj")),"Valid variant survives");
        for(String invalid:new String[]{null,"","x","und","mul","mis","zxx","en--US","en/US","en-US!!!","en-US-bad!", "en-US-", "abcdefghi", "x-private", "en-u-ca-gregory", "en-US-x-private", "en\nUS", "\u202Een-US", "en-US-"+"a".repeat(70)})
            check(Duwm1728SpeechLanguagePolicy.normalize(invalid).isEmpty(),"Reject malformed/ambiguous model identity: "+invalid);
        choice("en-UG","INSTALLED","en-UG","en-US","en-GB","en","en-UG");
        choice("en-UG","INSTALLED","en","en-US","en-GB","en");
        choice("en-UG","INSTALLED","en-GB","en-US","en-GB");
        choice("en-UG","INSTALLED","en-GB","EN_gb","en-GB",null,"en--US");
        choice("en-UG","UNAVAILABLE","","fr-UG","sw-UG","de-DE");
        choice("en-UG","UNAVAILABLE","","en-Cyrl-US");
        choice("zh-Hant-TW","UNAVAILABLE","","zh-Hans-CN","zh-CN","zh");
        choice("zh-TW","UNAVAILABLE","","zh-CN","zh-SG","zh");
        choice("zh-TW","INSTALLED","zh-Hant-HK","zh-CN","zh-Hant-HK");
        choice("zh-Hans-CN","INSTALLED","zh","zh-Hant-TW","zh");
        choice("sr-Latn-RS","UNAVAILABLE","","sr","sr-RS","sr-Cyrl-RS");
        choice("sr-Latn-RS","INSTALLED","sr-Latn-BA","sr","sr-Latn-BA");
        choice("pa-PK","UNAVAILABLE","","pa-IN","pa");
        choice("pa-PK","INSTALLED","pa-Arab","pa-IN","pa-Arab");
        Choice bareUnknown=Duwm1728SpeechLanguagePolicy.choose("en-UG",Arrays.asList("en","en-US"),EMPTY,EMPTY,null);
        check("UNAVAILABLE".equals(bareUnknown.status),"Without effective-script evidence no regional fallback is guessed");
        check("en-UG".equals(Duwm1728SpeechLanguagePolicy.choose("en-UG",Arrays.asList("en-UG"),EMPTY,EMPTY,null).selectedLanguage),"Exact installed tag does not need script inference");
        check("en-Latn-GB".equals(Duwm1728SpeechLanguagePolicy.choose("en-Latn-UG",Arrays.asList("en-Latn-GB"),EMPTY,EMPTY,null).selectedLanguage),"Explicit matching scripts are sufficient");
        for(String unknown:new String[]{"","???","Zzzz","Zyyy","Zinh"})
            check("UNAVAILABLE".equals(Duwm1728SpeechLanguagePolicy.choose("en-UG",Arrays.asList("en-GB"),EMPTY,EMPTY,t->unknown).status),"Unknown/common script cannot authorize fallback");
        check("UNAVAILABLE".equals(Duwm1728SpeechLanguagePolicy.choose("en-UG",Arrays.asList("en-GB"),EMPTY,EMPTY,t->{throw new IllegalStateException();}).status),"Script lookup failure stays closed");
        check("UNAVAILABLE".equals(installed("en-UG").status),"No inventory does not invent a model");
        check("INDETERMINATE".equals(installed("bad/locale","en-US").status),"Invalid device language is indeterminate");
        check("UNAVAILABLE".equals(choose("en-UG",null,null,null).status),"Null lists cannot claim installation");
        List<String> tooMany=new ArrayList<>(Collections.nCopies(1025,"en-UG"));
        check("INDETERMINATE".equals(choose("en-UG",tooMany,EMPTY,EMPTY).status),"Oversized model inventory is bounded");
        Choice pending=choose("en-UG",EMPTY,Arrays.asList("en-GB"),Arrays.asList("en-US"));
        check("PENDING".equals(pending.status)&&"en-GB".equals(pending.selectedLanguage),"Pending has its own non-installed state");
        Choice downloadable=choose("en-UG",EMPTY,EMPTY,Arrays.asList("en-US"));
        check("DOWNLOADABLE".equals(downloadable.status)&&"en-US".equals(downloadable.selectedLanguage),"Downloadable has its own non-installed state");
        check("INSTALLED".equals(choose("en-UG",Arrays.asList("en-GB"),Arrays.asList("en-UG"),Arrays.asList("en-UG")).status),"Ready same-language model beats waiting for exact model");
        check("UNAVAILABLE".equals(choose("en-UG",EMPTY,Arrays.asList("fr-FR"),Arrays.asList("sw-UG")).status),"Pending/downloadable unrelated languages are not selected");
        // Ordering, invalid entries and duplicate tags must never alter the model
        // choice. This exercises the observed en-UG / installed en-GB gap.
        Random random=new Random(172820L);
        for(int i=0;i<1200;i++){
            ArrayList<String> models=new ArrayList<>(Arrays.asList("en-US","EN_gb","en-GB","fr-FR","en-Cyrl-US",null,"bad/locale"));
            Collections.shuffle(models,random);
            Choice got=choose("en-UG",models,Arrays.asList("en-UG"),Arrays.asList("en"));
            check("INSTALLED".equals(got.status)&&"en-GB".equals(got.selectedLanguage),"Stable compatible dialect with shuffled inventory "+i);
            models.add("en");Collections.shuffle(models,random);
            check("en".equals(choose("en-UG",models,EMPTY,EMPTY).selectedLanguage),"Primary priority across shuffled inventory "+i);
            models.add("en-UG");Collections.shuffle(models,random);
            check("en-UG".equals(choose("en-UG",models,EMPTY,EMPTY).selectedLanguage),"Exact priority across shuffled inventory "+i);
        }

        flows=true;
        SupportFlow exact=flow();Decision first=exact.begin();
        check(first.action==Action.CHECK&&first.checkNumber==1&&"en-UG".equals(first.selectedLanguage),"Initial request checks exact device language");
        check(exact.begin().action==Action.IGNORE,"Repeated begin cannot issue a second initial query");
        Decision ready=support(exact,1,"en-UG","en-GB");
        check(ready.action==Action.READY&&ready.checkNumber==1&&"CONFIRMED".equals(ready.recordingSupport),"Exact installed model requires one confirmed query");
        terminal(exact,1);

        SupportFlow changed=flow();changed.begin();Decision second=support(changed,1,"en-US","en-GB");
        check(second.action==Action.CHECK&&second.checkNumber==2&&"en-GB".equals(second.selectedLanguage),"Dialect choice requires its own second query");
        check(!"CONFIRMED".equals(second.recordingSupport),"Initial model inventory does not authorize a changed request");
        check(support(changed,1,"en-UG").action==Action.IGNORE,"Duplicate initial result cannot start the stale language");
        check(changed.error(1,"late initial failure").action==Action.IGNORE,"Late failure from first request cannot abort second request");
        check(support(changed,3,"en-GB").action==Action.IGNORE,"Unexpected check token cannot authorize audio");
        ready=support(changed,2,"en-GB");
        check(ready.action==Action.READY&&"en-GB".equals(ready.selectedLanguage)&&"en-UG".equals(ready.requestedLanguage),"Only the selected exact installed tag finishes the second query");
        terminal(changed,2);

        for(List<String> denied:Arrays.asList(Arrays.asList("en-US"),Arrays.asList("en"),EMPTY,Arrays.asList("fr-FR"),Arrays.asList("en--GB"))){
            SupportFlow f=flow();f.begin();support(f,1,"en-GB");Decision no=support(f,2,denied.toArray(new String[0]));
            check(no.action==Action.FAILED&&no.checkNumber==2&&!"CONFIRMED".equals(no.recordingSupport),"Second check cannot chase a third candidate: "+denied);
            terminal(f,2);
        }
        for(String state:new String[]{"PENDING","DOWNLOADABLE"}){
            for(int stage=1;stage<=2;stage++){
                SupportFlow f=flow();f.begin();if(stage==2)support(f,1,"en-GB");
                Decision no=f.support(stage,EMPTY,"PENDING".equals(state)?Arrays.asList("en-GB"):EMPTY,
                        "DOWNLOADABLE".equals(state)?Arrays.asList("en-GB"):EMPTY);
                check(no.action==Action.FAILED&&state.equals(no.status)&&!"CONFIRMED".equals(no.recordingSupport),"Model "+state+" at check "+stage+" cannot authorize audio");
                terminal(f,stage);
            }
        }
        for(int stage=1;stage<=2;stage++)for(String reason:new String[]{"support timeout","service cannot check support","language not supported","malformed response"}){
            SupportFlow f=flow();f.begin();if(stage==2)support(f,1,"en-GB");Decision failure=f.error(stage,reason);
            check(failure.action==Action.FAILED&&"INDETERMINATE".equals(failure.recordingSupport),"Error never authorizes audio at check "+stage);
            check(stage==1?failure.selectedLanguage.isEmpty():"en-GB".equals(failure.selectedLanguage),"Only an inventory-selected candidate is named after support failure");
            check(reason.equals(failure.message),"Concrete support failure is retained");terminal(f,stage);
        }
        for(int stage=0;stage<=2;stage++){
            SupportFlow f=flow();if(stage>0)f.begin();if(stage==2)support(f,1,"en-GB");f.cancel();
            terminal(f,Math.max(1,stage));
            check(f.support(0,Arrays.asList("en-UG"),EMPTY,EMPTY).action==Action.IGNORE,"Cancelled flow cannot accept pre-start callback");
        }
        SupportFlow invalid=new SupportFlow("und",SpeechLanguagePolicyTest::script);
        check(invalid.begin().action==Action.FAILED,"Invalid locale never starts a support request");terminal(invalid,1);
        SupportFlow notStarted=flow();
        check(support(notStarted,1,"en-UG").action==Action.IGNORE,"Unsolicited pre-start installed result is ignored");
        check(notStarted.error(0,"pre-start error").action==Action.IGNORE,"Unsolicited pre-start failure is ignored");

        Path folder=Path.of(args.length==0?"verification/results/1728_2_20/speech-language":args[0]);Files.createDirectories(folder);
        Files.writeString(folder.resolve("SPEECH-LANGUAGE-HOST-RESULT.json"),
                "{\n  \"status\": \"PASS\",\n  \"checks\": "+checks+",\n  \"model_selection_checks\": "+selectionChecks+",\n  \"support_flow_checks\": "+flowChecks+",\n  \"shuffled_inventory_cases\": 1200,\n  \"max_support_queries\": 2,\n  \"native_executed\": false,\n  \"scope\": \"real production language-selection and bounded support-flow policy with explicit host script inputs\",\n  \"pending_or_downloadable_accepted_as_installed\": false,\n  \"service_errors_promoted_to_success\": false,\n  \"android_icu_executed\": false,\n  \"android_callback_transport_verified\": false,\n  \"recognizer_or_model_verified\": false,\n  \"audio_delivered\": false\n}\n",StandardCharsets.UTF_8);
        System.out.println("PASS "+checks+" speech-language assertions ("+selectionChecks+" selection, "+flowChecks+" bounded support-flow); host policy only, no Android recognizer/model/audio verification");
    }
}
