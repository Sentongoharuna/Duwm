package com.sentongoharuna.worldsituationroom;
public final class SmoothTickerPolicyTest {
  private static void ok(boolean v,String m){if(!v)throw new AssertionError(m);}
  public static void main(String[] a){
    float u=1f,size=23f,width=420f,text=700f;
    float inset=Duwm1728SmoothTicker.safeInset(u);
    ok(inset>=12f,"protected edge inset");
    ok(Duwm1728SmoothTicker.period(text,u,size)>text,"repeat gap");
    float x0=Duwm1728SmoothTicker.firstX(0,text,width,75,u,size);
    float x1=Duwm1728SmoothTicker.firstX(100,text,width,75,u,size);
    float x2=Duwm1728SmoothTicker.firstX(200,text,width,75,u,size);
    ok(x1<x0 && x2<x1,"smooth monotonic motion");
    ok(Math.abs((x0-x1)-(x1-x2))<0.01f,"constant source-time velocity");
    float slow=Duwm1728SmoothTicker.firstX(1000,text,width,45,u,size);
    float fast=Duwm1728SmoothTicker.firstX(1000,text,width,115,u,size);
    ok(fast<slow,"speed control preserved");
    System.out.println("smooth ticker policy: PASS");
  }
}
