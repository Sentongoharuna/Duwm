package com.sentongoharuna.worldsituationroom;

import java.awt.Color;
import java.awt.font.TextLayout;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Deque;
import java.util.List;
import javax.imageio.ImageIO;

/** Actual automatic policy and shared painter, with the exact delivered /20
 * painter retained for manual pixel regression. Synthetic supplied text only. */
public final class AutomaticHeadlineFitTest {
    private static int checks,wrappedCases,baselineCases;
    private static final int[][] SIZES={{720,800},{720,1280},{1280,720},{1920,1080},{1080,1920},{1072,1920},{540,960},{64,114}};
    private static final String WIDE="WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW TAIL";
    private static final String[] SOURCES={
        "BROADCASTING DEVELOPMENTS WITHIN KAMPALA CONSTRUCTION PROJECTS WHILE MONITORING PEDESTRIAN MOVEMENTS.",
        "CONSTRUCTION EQUIPMENT CONTINUES OPERATING AROUND THE BUILDING WHILE WORKERS ARRIVE.",
        WIDE,"The workers are continuing construction at the building next to the road.",
        "東京の街で人々が歩いています。広場では新しい建物が見えます。",
        "Cafe\u0301 👩🏽‍💻 🇺🇬 WWWWWWWWWW WWWWWWWWWW TAIL"
    };
    private static void check(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
    private static final class Drawn {
        final String text;final float x,y,size,width;final boolean bold;final int color;final Rectangle2D clip,ink;
        Drawn(String text,float x,float y,float size,float width,boolean bold,int color,Rectangle2D clip,Rectangle2D ink){
            this.text=text;this.x=x;this.y=y;this.size=size;this.width=width;this.bold=bold;this.color=color;this.clip=clip;this.ink=ink;
        }
    }
    private static final class Painter implements Duwm1728BroadcastLayout20.Painter {
        final BroadcastRenderTest.Painter delegate;final List<Drawn> drawn=new ArrayList<>();final Deque<Rectangle2D> clips=new ArrayDeque<>();
        final int width,height;int measurements;
        Painter(BufferedImage image){delegate=new BroadcastRenderTest.Painter(image);width=image.getWidth();height=image.getHeight();}
        public void rect(float x,float y,float w,float h,int c,float radius){delegate.rect(x,y,w,h,c,radius);}
        public void line(float x,float y,float xx,float yy,int c,float stroke){delegate.line(x,y,xx,yy,c,stroke);}
        public void text(String value,float x,float y,float size,int color,boolean bold){
            delegate.text(value,x,y,size,color,bold);Rectangle2D ink=value.isEmpty()?new Rectangle2D.Float():new TextLayout(value,delegate.g.getFont(),delegate.g.getFontRenderContext()).getBounds();
            drawn.add(new Drawn(value,x,y,size,measure(value,size,bold),bold,color,clips.isEmpty()?new Rectangle2D.Float(0,0,width,height):(Rectangle2D)clips.peek().clone(),
                new Rectangle2D.Double(x+ink.getX(),y+ink.getY(),ink.getWidth(),ink.getHeight())));
        }
        public float measure(String value,float size,boolean bold){measurements++;return delegate.measure(value,size,bold);}
        public Object captionMeasurementKey(){return Arrays.asList(Painter.class,"SansSerif",delegate.g.getFontRenderContext());}
        public void clip(float x,float y,float w,float h){Rectangle2D next=new Rectangle2D.Float(x,y,w,h);if(!clips.isEmpty())next=next.createIntersection(clips.peek());clips.push(next);delegate.clip(x,y,w,h);}
        public void unclip(){clips.pop();delegate.unclip();}
        List<Drawn> headlines(Duwm1728BroadcastLayout.Geometry g){ArrayList<Drawn> rows=new ArrayList<>();for(Drawn row:drawn)
            if(row.bold&&row.color==Duwm1728BroadcastLayout.WHITE&&row.y>=g.headlineTop&&row.y<g.headlineTop+g.headlineHeight)rows.add(row);return rows;}
        void close(){delegate.g.dispose();}
    }
    private static BufferedImage image(int w,int h){BufferedImage result=new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);java.awt.Graphics2D g=result.createGraphics();g.setColor(new Color(0x172632));g.fillRect(0,0,w,h);g.dispose();return result;}
    private static Duwm1728AutomaticProduction.Plan automatic(String words,boolean notes){
        return Duwm1728AutomaticProduction.plan(4000,notes?Collections.emptyList():Arrays.asList(new Duwm1728BroadcastLayout.Cue(137,3637,words)),"SYNTHETIC PROVIDED WORDS",notes?words:"");
    }
    private static Duwm1728BroadcastLayout.Report report(Duwm1728AutomaticProduction.Plan plan,String composition){
        Duwm1728BroadcastLayout.Report r=new Duwm1728BroadcastLayout.Report();r.title=plan.title;r.description=plan.description;r.provenance=plan.provenance;
        r.composition=composition;r.automaticHeadlineFit=true;r.automaticTickerPages=true;r.tickers=plan.tickers;r.captions=plan.cues;return r;
    }
    private static Duwm1728BroadcastLayout20.Report legacy(Duwm1728BroadcastLayout.Report current)throws Exception {
        Duwm1728BroadcastLayout20.Report r=new Duwm1728BroadcastLayout20.Report();
        for(java.lang.reflect.Field field:Duwm1728BroadcastLayout20.Report.class.getFields()){
            Object value=Duwm1728BroadcastLayout.Report.class.getField(field.getName()).get(current);
            if(value instanceof List){ArrayList<Duwm1728BroadcastLayout20.Cue> cues=new ArrayList<>();for(Object raw:(List<?>)value){Duwm1728BroadcastLayout.Cue c=(Duwm1728BroadcastLayout.Cue)raw;cues.add(new Duwm1728BroadcastLayout20.Cue(c.startMs,c.endMs,c.text));}value=cues;}
            field.set(r,value);
        }return r;
    }
    private static String visible(List<Drawn> rows){StringBuilder s=new StringBuilder();for(Drawn row:rows)s.append(row.text.replace(" ",""));return s.toString();}
    private static void safeRows(Painter painter,List<Drawn> rows,Duwm1728BroadcastLayout.Report r,Duwm1728BroadcastLayout.Geometry g){
        check(!rows.isEmpty()&&rows.size()<=2,"Automatic headline has one or two static rows");
        check(visible(rows).equals(r.title.replace(" ","")),"Every selected headline character remains in the actual drawn rows");
        float left=g.x+22*g.unit,available=g.width-44*g.unit;
        int cursor=0;List<Integer> boundaries=Duwm1728CaptionPages.clusterEnds(r.title);
        for(Drawn row:rows){
            check(Math.abs(row.x-left)<.02&&row.width<=available+.02,"Actual font measurement keeps each complete row inside its viewport");
            check(row.size>0&&Float.isFinite(row.size),"Fitted font size remains positive and finite");
            int start=r.title.indexOf(row.text,cursor),end=start+row.text.length();check(start>=cursor&&(start==0||boundaries.contains(start))&&boundaries.contains(end),"Line boundaries preserve protected Unicode clusters");cursor=end;
            // Normal supplied fixture glyphs fit their vertical band; min64px
            // canvases may have subpixel raster rounding, never a layout resize.
            if(g.unit>=.5f)check(row.ink.getMinY()>=row.clip.getMinY()-.1&&row.ink.getMaxY()<=row.clip.getMaxY()+.1,"Actual headline glyph bounds fit the assigned vertical band");
        }
        if(rows.size()==2&&"COMPACT".equals(g.composition)){
            check(rows.get(1).clip.getMaxY()<=g.headlineTop+57*g.unit+.02,"Wrapped headline has a separate upper band");
            for(Drawn row:painter.drawn)if(!row.bold&&row.color==Duwm1728BroadcastLayout.SILVER&&row.y>=g.headlineTop&&row.y<g.headlineTop+g.headlineHeight){
                check(row.clip.getMinY()>=g.headlineTop+59*g.unit-.02,"Byline has a separate lower band with a gap");
                check(row.ink.getMaxY()<=g.headlineTop+g.headlineHeight+.1,"Byline glyphs stay inside the unchanged panel");
            }
        }
    }
    private static void actualPlans(File folder)throws Exception {
        for(int source=0;source<SOURCES.length;source++)for(boolean notes:new boolean[]{false,true}){
            Duwm1728AutomaticProduction.Plan plan=automatic(SOURCES[source],notes);
            byte[] original=plan.cues.isEmpty()?new byte[0]:Duwm1728CaptionSrt.exportCues(plan.cues,Duwm1728CaptionSrt.TimeBase.ORIGINAL,4000,0,4000);
            for(int[] size:SIZES)for(String composition:new String[]{"COMPACT","FULL","CAPTIONS"}){
                BufferedImage bitmap=image(size[0],size[1]);Painter p=new Painter(bitmap);Duwm1728BroadcastLayout.Report r=report(plan,composition);
                Duwm1728BroadcastLayout.Geometry g=Duwm1728BroadcastLayout.draw(p,size[0],size[1],r,1000);List<Drawn> rows=p.headlines(g);
                if("CAPTIONS".equals(composition))check(rows.isEmpty()&&!g.headlineVisible,"Captions-only composition does not add a headline");
                else{safeRows(p,rows,r,g);if("COMPACT".equals(composition)&&rows.size()==2)wrappedCases++;}
                check(Arrays.equals(original,plan.cues.isEmpty()?new byte[0]:Duwm1728CaptionSrt.exportCues(plan.cues,Duwm1728CaptionSrt.TimeBase.ORIGINAL,4000,0,4000)),"Headline fitting leaves original caption/SRT bytes unchanged");
                check(plan.title.equals(r.title)&&plan.tickers==r.tickers&&plan.cues==r.captions,"Selected source title and original documents are not rewritten");
                if(source==2&&!notes&&size[0]==720&&size[1]==1280&&"COMPACT".equals(composition)){
                    ImageIO.write(bitmap,"png",new File(folder,"HOST-AUTO-FIT-HEADLINE-PORTRAIT.png"));
                    BufferedImage before=image(size[0],size[1]);Painter old=new Painter(before);Duwm1728BroadcastLayout20.draw(old,size[0],size[1],legacy(r),1000);old.close();
                    ImageIO.write(before,"png",new File(folder,"HOST-DELIVERED20-HEADLINE-PORTRAIT.png"));
                    int outside=0,inside=0;for(int y=0;y<size[1];y++)for(int x=0;x<size[0];x++)if(bitmap.getRGB(x,y)!=before.getRGB(x,y)){
                        if(y>=Math.floor(g.headlineTop)&&y<=Math.ceil(g.headlineTop+g.headlineHeight)&&x>=Math.floor(g.x)&&x<=Math.ceil(g.x+g.width))inside++;else outside++;}
                    check(inside>100&&outside==0,"Only pixels inside existing headline panel change; caption/ticker/provenance and all external geometry stay exact");
                    before.flush();
                }
                p.close();bitmap.flush();
            }
        }
    }
    private static void manualRegression()throws Exception {
        for(int[] size:new int[][]{{720,800},{720,1280},{1280,720},{1072,1920}})for(String composition:new String[]{"COMPACT","FULL","CAPTIONS"})for(long at:new long[]{1000,3000}){
            Duwm1728BroadcastLayout.Report r=report(automatic(WIDE,false),composition);r.automaticHeadlineFit=false;r.automaticTickerPages=false;r.location="TEST LOCATION";r.reporter="SYNTHETIC REPORTER";r.heading="100°";r.weather="TEST ONLY";
            BufferedImage a=image(size[0],size[1]),b=image(size[0],size[1]);Painter pa=new Painter(a),pb=new Painter(b);
            Duwm1728BroadcastLayout.Geometry ga=Duwm1728BroadcastLayout.draw(pa,size[0],size[1],r,at);Duwm1728BroadcastLayout20.Geometry gb=Duwm1728BroadcastLayout20.draw(pb,size[0],size[1],legacy(r),at);
            for(java.lang.reflect.Field field:Duwm1728BroadcastLayout.Geometry.class.getFields())check(field.get(ga).equals(Duwm1728BroadcastLayout20.Geometry.class.getField(field.getName()).get(gb)),"All manual geometry fields match delivered /20");
            boolean same=true;for(int y=0;y<size[1]&&same;y++)for(int x=0;x<size[0];x++)if(a.getRGB(x,y)!=b.getRGB(x,y)){same=false;break;}
            check(same,"Manual output is pixel-identical to delivered /20 at "+size[0]+"x"+size[1]+" "+composition+" "+at);baselineCases++;pa.close();pb.close();a.flush();b.flush();
        }
    }
    private static void boundariesAndCache(){
        BufferedImage bitmap=image(720,1280);Painter p=new Painter(bitmap);float u=720/1080f,width=(1080-112)*u;
        for(String text:new String[]{"", "RECORDED REPORT", "SOURCE WORDS • "+"W".repeat(48),"SOURCE NOTES • "+"m".repeat(48),"SOURCE WORDS • A\u0301 🇺🇬 👨‍👩‍👧‍👦 🇯🇵 한 TAIL","W".repeat(500)}){
            Duwm1728HeadlineFit.Plan plan=Duwm1728HeadlineFit.plan(p,text,28*u,22*u,width,1);
            check(plan.text.equals(text)&&String.join("",plan.lines).replace(" ","").equals(text.replace(" ","")),"Static fit preserves complete text, including a defensive500-character input");
            check(plan.lines.size()<=2&&plan.attempts<=33,"Font selection is bounded and never adds a third row");
            check(plan.textSize>0&&plan.textSize<=28*u,"Fit never enlarges the selected title");
        }
        for(String text:new String[]{"RECORDED REPORT","SOURCE WORDS • short source"}){
            Duwm1728HeadlineFit.Plan plan=Duwm1728HeadlineFit.plan(p,text,28*u,22*u,width,1);check(!plan.compactWrapped&&plan.textSize==28*u&&plan.lines.size()==1,"A headline that already fits retains its original size and row count");
        }
        Duwm1728CaptionPages.clearCache();Duwm1728HeadlineFit.plan(p,"SOURCE WORDS • "+WIDE,28*u,22*u,width,1);int before=p.measurements;
        for(int i=0;i<120;i++)Duwm1728HeadlineFit.plan(p,"SOURCE WORDS • "+WIDE,28*u,22*u,width,1);
        check(p.measurements==before,"Repeated frames reuse immutable font/locale measurements without repeated fitting work");
        for(int i=0;i<80;i++)Duwm1728HeadlineFit.plan(p,"SOURCE WORDS • "+WIDE+i,28*u,22*u,width,1);
        check(Duwm1728CaptionPages.cachedPlans()<=64,"Shared measurement cache remains bounded after changing headlines");
        boolean invalid=false;try{Duwm1728HeadlineFit.plan(p,"W".repeat(501),28*u,22*u,width,1);}catch(IllegalArgumentException e){invalid=true;}check(invalid,"Oversize corrupted input is rejected rather than silently truncated");
        invalid=false;try{Duwm1728HeadlineFit.plan(p,"title",28*u,Float.NaN,width,1);}catch(IllegalArgumentException e){invalid=true;}check(invalid,"Non-finite sizing is rejected");
        invalid=false;try{Duwm1728HeadlineFit.plan(p,"title",28*u,22*u,0,1);}catch(IllegalArgumentException e){invalid=true;}check(invalid,"Non-positive viewport is rejected");
        check(!new Duwm1728BroadcastLayout.Report().automaticHeadlineFit,"Manual/legacy report default remains disabled");p.close();bitmap.flush();
    }
    public static void main(String[] args)throws Exception {
        File folder=new File(args.length==0?"automatic-headline-fit-host-proof":args[0]);if(!folder.isDirectory()&&!folder.mkdirs())throw new IllegalStateException("Cannot create proof directory");
        actualPlans(folder);manualRegression();boundariesAndCache();check(wrappedCases>0&&baselineCases==24,"Actual wrapped automatic cases and all manual regressions executed");
        String result="{\n  \"status\": \"PASS\",\n  \"scope\": \"ACTUAL_AUTOMATIC_POLICY_AND_SHARED_HOST_PAINTER\",\n  \"checks\": "+checks+",\n  \"wrapped_automatic_cases\": "+wrappedCases+",\n  \"manual_pixel_baseline_cases\": "+baselineCases+",\n  \"native_execution\": false,\n  \"recognition_executed\": false,\n  \"physical_camera_verified\": false,\n  \"human_readability_asserted\": false\n}\n";
        Files.write(new File(folder,"AUTO-FIT-HEADLINE-HOST.json").toPath(),result.getBytes(StandardCharsets.UTF_8));System.out.println("PASS "+checks+" automatic headline source preservation, actual glyph bounds, bounded cache, geometry and manual /20 pixel checks. HOST ONLY; no Android encoder or recognition claim.");
    }
}
