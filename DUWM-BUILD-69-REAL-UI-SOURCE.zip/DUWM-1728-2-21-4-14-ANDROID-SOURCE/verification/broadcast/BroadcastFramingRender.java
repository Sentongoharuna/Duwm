package com.sentongoharuna.worldsituationroom;
import java.awt.*;import java.awt.geom.*;import java.awt.image.*;import java.io.*;import javax.imageio.ImageIO;
public final class BroadcastFramingRender {
    static BufferedImage frame(int w,int h,String mode,float ax,float ay,long ms){
        BufferedImage image=new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);Graphics2D g=image.createGraphics();
        g.setColor(new Color(0x041424));g.fillRect(0,0,w,h);
        Duwm1728FramePlan.Plan f=Duwm1728FramePlan.create(1920,1080,w,h,mode,ax,ay);
        g.clip(new Rectangle2D.Float(f.left*w,f.top*h,f.width*w,f.height*h));
        AffineTransform transform=g.getTransform();g.translate(w*f.translateX(),h*f.translateY());g.scale(w*f.scaleX()/1920d,h*f.scaleY()/1080d);
        g.setColor(new Color(0x273746));g.fillRect(0,0,1920,1080);
        g.setColor(new Color(0x3B5569));for(int x=0;x<=1920;x+=160)g.drawLine(x,0,x,1080);for(int y=0;y<=1080;y+=120)g.drawLine(0,y,1920,y);
        int[] px={170,960,1750};int[] color={0xD50000,0x00C853,0x1565C0};String[] label={"LEFT","CENTRE","RIGHT"};
        for(int n=0;n<3;n++){g.setColor(new Color(color[n]));g.fillOval(px[n]-120,300,240,240);g.setFont(new Font("SansSerif",Font.BOLD,34));g.setColor(Color.WHITE);g.drawString(label[n],px[n]-g.getFontMetrics().stringWidth(label[n])/2,610);}
        g.setTransform(transform);g.setClip(null);g.dispose();
        Duwm1728BroadcastLayout.Report r=new Duwm1728BroadcastLayout.Report();r.category="FRAME TEST";r.title="KEEP THE SCENE. CHOOSE THE FRAME.";r.description="Technical render test, not live news";r.provenance="TEST FIXTURE • NOT A NEWS REPORT";r.clock="1728.2/11 TEST";
        r.tickers.add(new Duwm1728BroadcastLayout.Cue(0,30000,"KEEP FULL retains all three markers • FILL lets you move the crop • The original recording is unchanged"));
        BroadcastRenderTest.Painter painter=new BroadcastRenderTest.Painter(image);Duwm1728BroadcastLayout.draw(painter,w,h,r,ms);painter.g.dispose();return image;
    }
    public static void main(String[] args)throws Exception{
        if(args.length>0&&"video".equals(args[0])){try(BufferedOutputStream out=new BufferedOutputStream(System.out,1<<20)){for(int i=0;i<120;i++)ImageIO.write(frame(540,960,"FIT",.5f,.5f,i*1000L/30),"png",out);}return;}
        File dir=new File(args[0]);dir.mkdirs();String[] mode={"FIT","FILL","FILL","FILL"};float[] x={.5f,0,.5f,1};
        for(int i=0;i<mode.length;i++)ImageIO.write(frame(540,960,mode[i],x[i],.5f,1000),"png",new File(dir,"FRAME-"+i+"-"+mode[i]+".png"));
        ImageIO.write(frame(960,540,"FIT",.5f,.5f,1000),"png",new File(dir,"FRAME-16-9.png"));
        System.out.println("PASS wrote production-framing desktop visual fixtures; not Android camera footage.");
    }
}
