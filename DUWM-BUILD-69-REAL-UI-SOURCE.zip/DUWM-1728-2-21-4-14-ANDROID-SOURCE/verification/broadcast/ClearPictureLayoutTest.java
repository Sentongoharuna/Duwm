package com.sentongoharuna.worldsituationroom;

import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.font.TextLayout;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.List;
import java.util.Locale;
import javax.imageio.ImageIO;

/** Executes the production layout on synthetic observations and a transparent
 * raster. Pixel tests prove edge geometry and presentation, not real vision,
 * Android encoding, camera capture, sensor accuracy or weather network access. */
public final class ClearPictureLayoutTest {
    private static int checks;
    private static final int[][] SIZES={{720,800},{720,1280},{1280,720},{540,960},{960,540},{1080,1920},{1920,1080},{64,114},{114,64},{64,64}};
    private static final List<String> areaEvidence=new ArrayList<>();
    private static void check(boolean pass,String message){checks++;if(!pass)throw new AssertionError(message);}
    private static final class Text {
        final String value;final float x,y,width,size;final Rectangle2D ink,clip;
        Text(String value,float x,float y,float width,float size,Rectangle2D ink,Rectangle2D clip){this.value=value;this.x=x;this.y=y;this.width=width;this.size=size;this.ink=ink;this.clip=clip;}
    }
    private static final class Painter implements Duwm1728BroadcastLayout.Painter {
        final BroadcastRenderTest.Painter delegate;final List<Text> text=new ArrayList<>();
        final List<Rectangle2D> boxes=new ArrayList<>();final Deque<Rectangle2D> clips=new ArrayDeque<>();final int width,height;
        Painter(BufferedImage image){delegate=new BroadcastRenderTest.Painter(image);width=image.getWidth();height=image.getHeight();}
        public void rect(float x,float y,float w,float h,int color,float radius){boxes.add(new Rectangle2D.Float(x,y,w,h));delegate.rect(x,y,w,h,color,radius);}
        public void line(float x,float y,float xx,float yy,int color,float thickness){delegate.line(x,y,xx,yy,color,thickness);}
        public void text(String value,float x,float y,float size,int color,boolean bold){
            delegate.text(value,x,y,size,color,bold);
            Rectangle2D box=value.isEmpty()?new Rectangle2D.Float():new TextLayout(value,delegate.g.getFont(),delegate.g.getFontRenderContext()).getBounds();
            text.add(new Text(value,x,y,measure(value,size,bold),size,new Rectangle2D.Double(x+box.getX(),y+box.getY(),box.getWidth(),box.getHeight()),clips.isEmpty()?new Rectangle2D.Float(0,0,width,height):(Rectangle2D)clips.peek().clone()));
        }
        public float measure(String value,float size,boolean bold){return delegate.measure(value,size,bold);}
        public Object captionMeasurementKey(){return Arrays.asList(Painter.class,"SansSerif",delegate.g.getFontRenderContext());}
        public void clip(float x,float y,float w,float h){Rectangle2D box=new Rectangle2D.Float(x,y,w,h);if(!clips.isEmpty())box=box.createIntersection(clips.peek());clips.push(box);delegate.clip(x,y,w,h);}
        public void unclip(){clips.pop();delegate.unclip();}
        boolean has(String word){for(Text t:text)if(t.value.contains(word))return true;return false;}
    }
    private static final class Frame implements AutoCloseable {
        final BufferedImage image;final Painter painter;final Duwm1728BroadcastLayout.Geometry geometry;
        Frame(int w,int h,Duwm1728BroadcastLayout.Report report,long time){image=new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);painter=new Painter(image);geometry=Duwm1728BroadcastLayout.draw(painter,w,h,report,time);}
        public void close(){painter.delegate.g.dispose();}
    }
    private static Duwm1728BroadcastLayout.Report fixture(){
        Duwm1728BroadcastLayout.Report r=new Duwm1728BroadcastLayout.Report();r.clearPicture=true;r.composition="COMPACT";
        r.automaticSceneTitles=true;r.sceneAtMs=0;r.sceneUntilMs=10000;r.sceneSource="on-device-image-description";
        r.sceneTitle="A cyclist passes a campus gate";r.sceneDescription="The full synthetic observation must not become a duplicate lower panel.";
        r.title="UNUSED MANUAL TITLE";r.description="UNUSED LOWER DESCRIPTION";r.category="UNUSED CATEGORY";r.provenance="UNUSED PROVENANCE";
        r.clock="RECORDED 2026-11-07 12:00:00 UTC";r.measuredSummary=true;r.coordinatesAllowed=true;
        r.measuredLocation="PLACE Campus east gate";r.measuredCoordinates="LAT/LON 0.33567, 32.56890";r.measuredCoordinateState="LAT/LON WITHHELD";
        r.measuredAccuracy="ACC ±6 m";r.measuredHeading="CAM HDG 078° E MAG";r.measuredHeadingDegrees=78;
        r.measuredSpeed="SPEED 5.4 km/h";r.measuredMovement="MOVEMENT MOVING";r.measuredAltitude="ALT 1180 m WGS84 ±8 m";r.measuredFps="PREVIEW 30.0 fps";
        r.measuredWeatherProvider="MODEL WX Open-Meteo";r.measuredWeatherDescription="Partly cloudy";
        r.measuredWeatherNumbers="26.5°C / WIND 3.2 m/s";r.measuredWeatherTime="11:55 UTC";
        r.measuredWeather="MODEL WX Open-Meteo / Partly cloudy / 26.5°C / WIND 3.2 m/s / 11:55 UTC";
        r.captions.add(new Duwm1728BroadcastLayout.Cue(100,4000,"Synthetic subtitle: the source picture stays visible."));
        r.tickers.add(new Duwm1728BroadcastLayout.Cue(0,10000,"UNUSED LEGACY TICKER"));return r;
    }
    private static float[] bounds(Duwm1728BroadcastLayout.Geometry g){return new float[]{g.unit,g.x,g.width,g.headerTop,g.headerBottom,g.tagTop,g.headlineTop,g.telemetryTop,g.tickerTop,g.bottom,g.captionLeft,g.captionTop,g.captionWidth,g.captionHeight,g.captionBottom,g.clearSafeLeft,g.clearSafeTop,g.clearSafeWidth,g.clearSafeHeight,g.clearSafeAreaFraction};}
    private static void sameBounds(Duwm1728BroadcastLayout.Geometry a,Duwm1728BroadcastLayout.Geometry b){check(Arrays.equals(bounds(a),bounds(b)),"Text, time, scene validity and measurement status cannot move clear frame geometry");}
    private static int painted(BufferedImage image){int count=0;for(int y=0;y<image.getHeight();y++)for(int x=0;x<image.getWidth();x++)if((image.getRGB(x,y)>>>24)!=0)count++;return count;}
    private static void clearCenter(Frame frame){
        Duwm1728BroadcastLayout.Geometry g=frame.geometry;
        int left=(int)Math.ceil(g.clearSafeLeft),top=(int)Math.ceil(g.clearSafeTop),right=(int)Math.floor(g.clearSafeLeft+g.clearSafeWidth),bottom=(int)Math.floor(g.clearSafeTop+g.clearSafeHeight),painted=0;
        for(int y=top;y<bottom;y++)for(int x=left;x<right;x++)if((frame.image.getRGB(x,y)>>>24)!=0)painted++;
        check(right>left&&bottom>top,"Declared central safe rectangle contains actual pixels");
        check(painted==0,"Every central safe pixel remains completely unpainted");
        Rectangle2D safe=new Rectangle2D.Float(g.clearSafeLeft,g.clearSafeTop,g.clearSafeWidth,g.clearSafeHeight);
        for(Rectangle2D box:frame.painter.boxes){check(!box.intersects(safe),"Every background box stays outside the protected center");check(box.getWidth()*box.getHeight()<frame.image.getWidth()*frame.image.getHeight()*.15,"No broad picture scrim or full-frame fill");}
    }
    private static void textBounds(Frame frame){
        Duwm1728BroadcastLayout.Geometry g=frame.geometry;int subtitleRows=0;
        java.util.Map<Float,Float> right=new java.util.HashMap<>();java.util.Set<Float> measurementRows=new java.util.HashSet<>();
        for(Text text:frame.painter.text){
            check(text.width<=text.clip.getWidth()+.1,"Every visible text row fits its measured clip width");
            check(text.x>=text.clip.getMinX()-.1&&text.x+text.width<=text.clip.getMaxX()+.1,"Visible strings cannot cross their reserved cells");
            if(g.unit>=.5f)check(text.ink.getMinY()>=text.clip.getMinY()-.1&&text.ink.getMaxY()<=text.clip.getMaxY()+.1,"Actual text glyphs fit their reserved vertical band");
            if(text.y>=g.captionTop&&text.y<g.captionBottom)subtitleRows++;
            if(text.y>=g.telemetryTop&&text.y<g.tickerTop&&!text.value.isEmpty()){
                measurementRows.add(text.y);check(Math.abs(text.size-18*g.unit)<.001f,"Measurement font stays fixed at18u as digit counts or states change");
                check(!right.containsKey(text.y)||text.x>=right.get(text.y)-.1,"Independent measurement cells cannot overlap");right.put(text.y,text.x+text.width);
            }
        }
        check(subtitleRows<=2,"At most two source subtitle rows");
        check(!g.telemetryVisible||measurementRows.size()<=3,"No measurement band grows beyond three rows");
        check(frame.painter.clips.isEmpty(),"The renderer restores all painter clips");
    }
    private static void geometryAndArea(File folder)throws Exception{
        for(int[] size:SIZES){int w=size[0],h=size[1];Duwm1728BroadcastLayout.Report r=fixture();
            try(Frame clear=new Frame(w,h,r,500)){
                Duwm1728BroadcastLayout.Geometry g=clear.geometry;
                check(g.clearPicture&&!g.headlineVisible&&!g.tickerVisible,"Clear mode removes legacy lower headline and ticker");
                check(g.telemetryVisible&&Math.abs(g.telemetryHeight-93*g.unit)<.01,"Fixed measurement band keeps all three reserved rows");
                check(Math.abs(g.tickerTop-(g.telemetryTop+g.telemetryHeight))<.01,"Native measurement ROI uses tickerTop as band end");
                check(g.captionBottom<g.telemetryTop&&g.captionTop>g.headerBottom,"Fixed subtitle box remains between top cards and measurements");
                check(g.clearSafeAreaFraction>.60,"A central rectangle over60% of the picture stays protected in every supported aspect");
                check(!clear.painter.has("WORLD MONITOR")&&!clear.painter.has("DUWM")&&!clear.painter.has("UNUSED")&&!clear.painter.has("duplicate lower panel"),"No repeated brand/category/provenance/description/ticker panel in clear mode");
                for(String value:new String[]{"0.33567","32.56890","±6 m","078° E MAG","5.4 km/h","MOVING","1180 m WGS84","PREVIEW","30.0 fps","Open-Meteo","26.5°C","3.2 m/s","11:55 UTC","2026-11-07","12:00:00 UTC"})check(clear.painter.has(value),"Measured reading, unit, provider or source time remains visible: "+value);
                clearCenter(clear);textBounds(clear);
                try(Frame steady=new Frame(w,h,r,900)){sameBounds(g,steady.geometry);check(BroadcastRenderTest.difference(clear.image,steady.image,0,0,w,h)==0,"Unchanged content never scrolls or moves between source instants");}
                r.clearPicture=false;try(Frame legacy=new Frame(w,h,r,500)){
                    int before=painted(legacy.image),after=painted(clear.image);check(after<before*.85,"Clear layout paints at least15% fewer actual pixels than legacy COMPACT on the same input");
                    areaEvidence.add(String.format(Locale.ROOT,"{\"width\":%d,\"height\":%d,\"safe_rectangle_fraction\":%.6f,\"central_painted_pixels\":0,\"legacy_compact_painted_pixels\":%d,\"clear_painted_pixels\":%d,\"painted_area_reduction_fraction\":%.6f}",w,h,g.clearSafeAreaFraction,before,after,1-after/(double)before));
                    if(w==1280&&h==720)saveComparison(folder,legacy.image,clear.image);
                }r.clearPicture=true;
                for(String composition:new String[]{"FULL","COMPACT","CAPTIONS"}){r.composition=composition;try(Frame selected=new Frame(w,h,r,500)){sameBounds(g,selected.geometry);check(selected.geometry.captionVisible,"Active source captions remain visible in clear mode");check(BroadcastRenderTest.difference(clear.image,selected.image,0,0,w,h)==0,"Legacy composition does not override explicitly selected clear mode");}}
                if(w==720&&h==1280)save(folder,"HOST-CLEAR-PORTRAIT.png",clear.image);
                if(w==1280&&h==720)save(folder,"HOST-CLEAR-LANDSCAPE.png",clear.image);
                if(w==720&&h==800)save(folder,"HOST-CLEAR-9-10.png",clear.image);
                r.sceneTitle="A very long synthetic scene title with a joined emoji 👩‍💻 and accents é ".repeat(12);r.clock="RECORDED 2026-11-07 23:59:59 UTC";
                r.captions.clear();try(Frame changed=new Frame(w,h,r,500)){sameBounds(g,changed.geometry);check(changed.painter.has("…"),"Long titles are visibly abbreviated, never scrolled");clearCenter(changed);textBounds(changed);}
                r.sceneAtMs=1500;try(Frame future=new Frame(w,h,r,500)){sameBounds(g,future.geometry);check(!future.painter.has("very long synthetic")&&future.painter.has("SCENE UNAVAILABLE"),"Future model title is never displayed early");clearCenter(future);}
                r.sceneAtMs=0;r.sceneUntilMs=500;try(Frame stale=new Frame(w,h,r,500)){sameBounds(g,stale.geometry);check(!stale.painter.has("very long synthetic")&&stale.painter.has("RECORDED SCENE"),"Expired scene becomes neutral at its exact end");clearCenter(stale);}
                r.sceneUntilMs=10000;r.sceneSource="synthetic-untrusted";try(Frame untrusted=new Frame(w,h,r,500)){sameBounds(g,untrusted.geometry);check(!untrusted.painter.has("very long synthetic"),"Nonmodel source is not presented as an AI scene");}
                r=fixture();r.measuredCoordinates="LAT/LON STALE";r.measuredAccuracy="ACC STALE";r.measuredLocation="PLACE STALE";
                r.measuredWeather="MODEL WX STALE";r.measuredWeatherProvider=r.measuredWeatherDescription=r.measuredWeatherNumbers=r.measuredWeatherTime="";
                try(Frame stale=new Frame(w,h,r,500)){sameBounds(g,stale.geometry);check(stale.painter.has("LAT/LON STALE")&&stale.painter.has("MODEL WX STALE")&&stale.painter.has("MAG"),"Per-field states remain explicit while independent values stay current");check(!stale.painter.has("0.33567")&&!stale.painter.has("26.5°C"),"Stale values do not leak old numbers");clearCenter(stale);textBounds(stale);if(w==720&&h==1280)save(folder,"HOST-CLEAR-STALE.png",stale.image);}
                r.measuredLocation=r.measuredCoordinates=r.measuredCoordinateState=r.measuredAccuracy=r.measuredHeading=r.measuredSpeed=r.measuredMovement=r.measuredAltitude=r.measuredFps=r.measuredWeather="";r.measuredHeadingDegrees=Double.NaN;
                r.sceneUntilMs=500;r.clock="UTC UNAVAILABLE";r.captions.clear();try(Frame missing=new Frame(w,h,r,500)){sameBounds(g,missing.geometry);check(missing.painter.has("MEASUREMENTS UNAVAILABLE")&&!missing.painter.has("km/h")&&!missing.painter.has("fps"),"Whole-sample gaps keep a neutral state with no fake measurements");clearCenter(missing);textBounds(missing);if(w==720&&h==1280)save(folder,"HOST-CLEAR-UNAVAILABLE.png",missing.image);}
            }
        }
    }
    private static void sourceAndExtremes(File folder)throws Exception{
        for(int[] size:SIZES){Duwm1728BroadcastLayout.Report r=fixture();r.measuredLocation="PLACE "+"A long synthetic campus name ".repeat(18);
            r.sceneTitle="People walk past a campus gate and a courtyard with a long row of trees and benches in the background";
            r.measuredCoordinates="LAT/LON -89.99999, -179.99999";r.measuredAccuracy="ACC ±50 m";r.measuredHeading="CAM HDG 359° NW MAG";r.measuredHeadingDegrees=359;
            r.measuredSpeed="SPEED 3600.0 km/h";r.measuredMovement="STATIONARY";r.measuredAltitude="ALT 100000 m WGS84 ±50 m";r.measuredFps="PREVIEW 1000.0 fps";
            r.measuredWeatherDescription="An extremely long synthetic weather model description ".repeat(15);r.measuredWeatherNumbers="-100.0°C / WIND 150.0 m/s";r.measuredWeatherTime="23:59 UTC";
            r.captions.clear();r.captions.add(new Duwm1728BroadcastLayout.Cue(100,4100,"Long synthetic subtitle pages remain within the same two reserved rows while the source time advances. ".repeat(4)));
            try(Frame extreme=new Frame(size[0],size[1],r,500)){
                for(String value:new String[]{"-89.99999","-179.99999","±50 m","359° NW MAG","3600.0 km/h","STATIONARY","100000 m WGS84","1000.0 fps","Open-Meteo","-100.0°C","150.0 m/s","23:59 UTC"})check(extreme.painter.has(value),"Extreme readings retain reserved numeric/source space: "+value);
                check(extreme.painter.has("…"),"Long descriptive text yields to fixed geometry");clearCenter(extreme);textBounds(extreme);
                for(long time:new long[]{99,100,2000,4099,4100})try(Frame page=new Frame(size[0],size[1],r,time)){sameBounds(extreme.geometry,page.geometry);check(page.geometry.captionVisible==(time>=100&&time<4100),"Original caption interval remains half-open");clearCenter(page);textBounds(page);}
                if(size[0]==720&&size[1]==1280)save(folder,"HOST-CLEAR-LONG.png",extreme.image);
            }
            r.coordinatesAllowed=false;try(Frame hidden=new Frame(size[0],size[1],r,500)){check(!hidden.painter.has("-89.99999")&&!hidden.painter.has("-179.99999")&&hidden.painter.has("LAT/LON WITHHELD"),"Final coordinate guard respects independent consent even with a populated raw string");clearCenter(hidden);}
            r.measuredSummary=false;try(Frame disabled=new Frame(size[0],size[1],r,500)){check(!disabled.geometry.telemetryVisible&&!disabled.painter.has("km/h")&&!disabled.painter.has("Open-Meteo"),"Explicitly disabled measurements do not paint hidden fields");clearCenter(disabled);}
        }
        check(!new Duwm1728BroadcastLayout.Report().clearPicture,"Legacy/manual default remains false");
    }
    private static BufferedImage background(int w,int h){
        BufferedImage image=new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);Graphics2D g=image.createGraphics();
        g.setPaint(new GradientPaint(0,0,new Color(0x9ABACA),0,h,new Color(0xD7D1BA)));g.fillRect(0,0,w,h);
        g.setColor(new Color(0x6E8B74));g.fillRect(0,(int)(h*.48),w,h);g.setColor(new Color(0xB1B4A5));
        g.fillRect((int)(w*.06),(int)(h*.25),(int)(w*.28),(int)(h*.27));g.fillRect((int)(w*.69),(int)(h*.28),(int)(w*.28),(int)(h*.24));
        g.setColor(new Color(0x506270));for(int side:new int[]{6,69})for(int row=0;row<3;row++)for(int col=0;col<3;col++)g.fillRect((int)(w*(side/100.0+.035+col*.07)),(int)(h*(.29+row*.065)),Math.max(1,(int)(w*.035)),Math.max(1,(int)(h*.035)));
        g.setColor(new Color(0xB7AC92));g.fillPolygon(new Polygon(new int[]{(int)(w*.43),(int)(w*.57),w,0},new int[]{(int)(h*.49),(int)(h*.49),h,h},4));
        g.setColor(new Color(0x334A42));g.fillRect((int)(w*.45),(int)(h*.31),Math.max(1,(int)(w*.015)),(int)(h*.20));g.fillRect((int)(w*.55),(int)(h*.31),Math.max(1,(int)(w*.015)),(int)(h*.20));g.fillRect((int)(w*.45),(int)(h*.31),(int)(w*.115),Math.max(1,(int)(h*.015)));
        float u=Math.min(w,h)/1080f;g.setFont(new Font("SansSerif",Font.BOLD,Math.max(6,Math.round(20*u))));g.setColor(new Color(0x243E48));String label="HOST SYNTHETIC PICTURE";g.drawString(label,(w-g.getFontMetrics().stringWidth(label))/2,(int)(h*.67));g.dispose();return image;
    }
    private static void save(File folder,String name,BufferedImage overlay)throws Exception{BufferedImage output=background(overlay.getWidth(),overlay.getHeight());Graphics2D g=output.createGraphics();g.drawImage(overlay,0,0,null);g.dispose();check(ImageIO.write(output,"png",new File(folder,name)),"Save clear-layout host visual "+name);}
    private static void saveComparison(File folder,BufferedImage legacy,BufferedImage clear)throws Exception{
        int w=legacy.getWidth(),h=legacy.getHeight(),labelHeight=40;BufferedImage output=new BufferedImage(w*2,h+labelHeight,BufferedImage.TYPE_INT_ARGB);Graphics2D g=output.createGraphics();g.setColor(new Color(0xE8EDF2));g.fillRect(0,0,w*2,h+labelHeight);g.setColor(new Color(0x132735));g.setFont(new Font("SansSerif",Font.BOLD,18));g.drawString("/21/2 COMPACT — SAME SYNTHETIC INPUT",20,27);g.drawString("/21/3 CLEAR PICTURE — SAME SYNTHETIC INPUT",w+20,27);g.drawImage(background(w,h),0,labelHeight,null);g.drawImage(legacy,0,labelHeight,null);g.drawImage(background(w,h),w,labelHeight,null);g.drawImage(clear,w,labelHeight,null);g.dispose();check(ImageIO.write(output,"png",new File(folder,"HOST-CLEAR-BEFORE-AFTER.png")),"Save actual legacy/current painter comparison");
    }
    public static void main(String[] args)throws Exception{
        File folder=new File(args.length==0?"clear-picture-layout-host-proof":args[0]);if(!folder.isDirectory()&&!folder.mkdirs())throw new IllegalStateException("Cannot create clear picture proof folder");
        geometryAndArea(folder);sourceAndExtremes(folder);
        String result="{\n  \"schema\":1,\n  \"status\":\"PASS\",\n  \"checks\":"+checks+",\n  \"observation_source\":\"synthetic-host-fixture\",\n  \"physical_camera_verified\":false,\n  \"physical_sensor_verified\":false,\n  \"provider_network_verified\":false,\n  \"model_inference_verified\":false,\n  \"android_export_verified\":false,\n  \"maximum_subtitle_rows\":2,\n  \"geometry_invariant_across_content_changes\":true,\n  \"central_safe_pixels_unpainted\":true,\n  \"resolutions\":[\n    "+String.join(",\n    ",areaEvidence)+"\n  ]\n}\n";
        Files.write(new File(folder,"CLEAR-PICTURE-LAYOUT-HOST.json").toPath(),result.getBytes(StandardCharsets.UTF_8));
        System.out.println("PASS "+checks+" clear picture geometry, actual transparent-center pixels, fixed fields, subtitle, privacy and source-label checks. HOST SYNTHETIC FIXTURES ONLY; no Android/model/sensor/network claim.");
    }
}
