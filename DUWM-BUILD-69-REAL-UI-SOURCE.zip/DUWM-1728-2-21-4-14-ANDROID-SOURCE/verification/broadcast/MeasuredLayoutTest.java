package com.sentongoharuna.worldsituationroom;

import java.awt.Color;
import java.awt.font.TextLayout;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.List;
import javax.imageio.ImageIO;

/** Synthetic typed measurements exercise the actual pure display policy and
 * production painter. No physical sensor, provider request or encoder is run. */
public final class MeasuredLayoutTest {
    private static int checks;
    private static final int[][] SIZES={{720,800},{720,1280},{1280,720},{540,960},{960,540},{1080,1920},{1920,1080},{64,114}};
    private static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    private static final class Text {
        final String value;final float x,y,width,size;final Rectangle2D ink,clip;
        Text(String value,float x,float y,float width,float size,Rectangle2D ink,Rectangle2D clip){this.value=value;this.x=x;this.y=y;this.width=width;this.size=size;this.ink=ink;this.clip=clip;}
    }
    private static final class Painter implements Duwm1728BroadcastLayout.Painter {
        final BroadcastRenderTest.Painter delegate;final List<Text> text=new ArrayList<>();final Deque<Rectangle2D> clips=new ArrayDeque<>();final int width,height;
        Painter(BufferedImage image){delegate=new BroadcastRenderTest.Painter(image);width=image.getWidth();height=image.getHeight();}
        public void rect(float x,float y,float w,float h,int color,float radius){delegate.rect(x,y,w,h,color,radius);}
        public void line(float x,float y,float xx,float yy,int color,float thickness){delegate.line(x,y,xx,yy,color,thickness);}
        public void text(String value,float x,float y,float size,int color,boolean bold){delegate.text(value,x,y,size,color,bold);Rectangle2D box=value.isEmpty()?new Rectangle2D.Float():new TextLayout(value,delegate.g.getFont(),delegate.g.getFontRenderContext()).getBounds();
            text.add(new Text(value,x,y,measure(value,size,bold),size,new Rectangle2D.Double(x+box.getX(),y+box.getY(),box.getWidth(),box.getHeight()),clips.isEmpty()?new Rectangle2D.Float(0,0,width,height):(Rectangle2D)clips.peek().clone()));}
        public float measure(String value,float size,boolean bold){return delegate.measure(value,size,bold);}
        public Object captionMeasurementKey(){return Arrays.asList(Painter.class,"SansSerif",delegate.g.getFontRenderContext());}
        public void clip(float x,float y,float w,float h){Rectangle2D box=new Rectangle2D.Float(x,y,w,h);if(!clips.isEmpty())box=box.createIntersection(clips.peek());clips.push(box);delegate.clip(x,y,w,h);}
        public void unclip(){clips.pop();delegate.unclip();}
        boolean has(String value){return text.stream().anyMatch(row->row.value.contains(value));}
    }
    private static final class Frame implements AutoCloseable {
        final BufferedImage image;final Painter painter;final Duwm1728BroadcastLayout.Geometry geometry;
        Frame(int w,int h,Duwm1728BroadcastLayout.Report report){image=new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);java.awt.Graphics2D g=image.createGraphics();g.setColor(new Color(0x233948));g.fillRect(0,0,w,h);g.dispose();painter=new Painter(image);geometry=Duwm1728BroadcastLayout.draw(painter,w,h,report,500);}
        public void close(){painter.delegate.g.dispose();}
    }
    private static Duwm1728Measurements.Sample sample(){
        Duwm1728Measurements.Input in=new Duwm1728Measurements.Input();in.nowElapsedMs=100000;in.sourceMs=400;in.utcMs=1794052800000L;in.recording=true;in.coordinatesAllowed=true;
        in.locationEnabled=true;in.locationAvailable=true;in.fixElapsedMs=99900;in.latitude=.33567;in.longitude=32.56890;in.horizontalAccuracyMeters=6;in.altitudeMeters=1235;in.verticalAccuracyMeters=8;in.speedMps=4;in.speedAccuracyMps=.2;
        in.headingDegrees=78;in.headingElapsedMs=99900;in.headingAccuracy=3;in.previewFps=30;in.fpsFrames=31;in.fpsWindowMs=1000;in.fpsElapsedMs=99900;
        in.place="Synthetic campus";in.placeSource="Synthetic geocoder fixture";in.placeQueryLatitude=in.latitude;in.placeQueryLongitude=in.longitude;in.placeFixElapsedMs=99000;in.placeReceivedElapsedMs=99900;
        in.weatherEnabled=true;in.weatherProvider="Open-Meteo";in.weatherSource="Synthetic model response";in.weatherDescription="Partly cloudy";in.temperatureC=26.5;in.windMps=3.2;in.weatherCode=2;in.weatherQueryLatitude=in.latitude;in.weatherQueryLongitude=in.longitude;in.weatherUtcMs=in.utcMs-300000;in.weatherReceivedElapsedMs=99900;
        return Duwm1728Measurements.sample(in);
    }
    private static Duwm1728BroadcastLayout.Report report(String composition,boolean scene){
        Duwm1728Measurements.Display view=Duwm1728Measurements.display(sample(),500,true);Duwm1728BroadcastLayout.Report r=new Duwm1728BroadcastLayout.Report();r.composition=composition;r.title="SYNTHETIC MEASURED REPORT";r.description="Synthetic measurement layout, not physical sensor evidence";r.clock=view.time;
        r.automaticSceneTitles=scene;r.sceneAtMs=0;r.sceneUntilMs=2000;r.sceneTitle="Synthetic scene title";r.sceneDescription="Scene content stays separate from measured information.";r.sceneSource="on-device-image-description";
        r.measuredSummary=true;r.coordinatesAllowed=true;r.measuredLocation=view.location;r.measuredCoordinates=view.coordinates;r.measuredAccuracy=view.accuracy;r.measuredHeading=view.heading;r.measuredHeadingDegrees=view.headingDegrees;
        r.measuredSpeed=view.speed;r.measuredMovement=view.movement;r.measuredAltitude=view.altitude;r.measuredFps=view.fps;r.measuredWeather=view.weather;
        r.measuredWeatherProvider=view.weatherProviderLabel;r.measuredWeatherDescription=view.weatherDescription;r.measuredWeatherNumbers=view.weatherNumbers;r.measuredWeatherTime=view.weatherTime;
        r.captions.add(new Duwm1728BroadcastLayout.Cue(100,900,"Synthetic subtitle remains above the measured information strip."));return r;
    }
    private static void geometry(File folder)throws Exception{
        for(int[] size:SIZES)for(String mode:new String[]{"FULL","COMPACT","CAPTIONS"})for(boolean scene:new boolean[]{false,true}){
            Duwm1728BroadcastLayout.Report r=report(mode,scene);try(Frame f=new Frame(size[0],size[1],r)){
                Duwm1728BroadcastLayout.Geometry g=f.geometry;boolean visible=!"CAPTIONS".equals(mode);
                check(g.telemetryVisible==visible,"Caption-only composition keeps measured strip hidden");
                check(!visible||Math.abs(g.telemetryHeight-93*g.unit)<.01,"Measured strip reserves exactly three bounded rows");
                check(g.captionBottom<g.tagTop&&g.captionTop>g.headerBottom,"Measured panel and source caption do not overlap other graphics");
                java.util.Set<Float> rows=new java.util.HashSet<>();java.util.Map<Float,Float> right=new java.util.HashMap<>();for(Text text:f.painter.text)if(text.y>=g.telemetryTop&&text.y<g.tickerTop&&!text.value.isEmpty()){
                    rows.add(text.y);check(text.x>=g.x&&text.x+text.width<=g.x+g.width+.1f,"Actual measurement text fits the safe width");
                    check(!right.containsKey(text.y)||text.x>=right.get(text.y)-.1f,"Reserved measurement cells never overlap");right.put(text.y,text.x+text.width);
                    check(text.size>=18*g.unit-.001f,"Measurement text remains at its readable minimum size");
                    if(g.unit>=.5f)check(text.ink.getMinY()>=text.clip.getMinY()-.1&&text.ink.getMaxY()<=text.clip.getMaxY()+.1,"Actual measurement glyphs fit vertically");
                }
                check(rows.size()==(visible?3:0),"Measured information uses exactly three visible text rows");
                for(String word:new String[]{"LAT/LON 0.33567","MAG","km/h","MOVING","WGS84","PREVIEW","fps","MODEL","Open-Meteo","WIND","UTC"})check(!visible||f.painter.has(word),"Measured source label/value is actually visible: "+word);
                check(!f.painter.has("ENCODED FPS")&&!f.painter.has("TARGET FPS"),"Preview frame measurement is never relabelled as encoded frame rate");
                check(f.painter.clips.isEmpty(),"Measured renderer restores its clips");
                if(scene&&"COMPACT".equals(mode)&&size[0]==720&&size[1]==1280)check(ImageIO.write(f.image,"png",new File(folder,"HOST-MEASURED-PORTRAIT.png")),"Save host portrait measured rendering");
                if(scene&&"COMPACT".equals(mode)&&size[0]==1280&&size[1]==720)check(ImageIO.write(f.image,"png",new File(folder,"HOST-MEASURED-LANDSCAPE.png")),"Save host landscape measured rendering");
            }
            r.coordinatesAllowed=false;try(Frame f=new Frame(size[0],size[1],r)){check(!f.painter.has("0.33567")&&!f.painter.has("32.56890"),"Coordinate visibility has an independent final rendering guard");}
            r.measuredSummary=false;try(Frame inactive=new Frame(size[0],size[1],r)){
                r.measuredLocation=r.measuredCoordinates=r.measuredAccuracy=r.measuredHeading=r.measuredSpeed=r.measuredMovement=r.measuredAltitude=r.measuredFps=r.measuredWeather="";r.measuredHeadingDegrees=Double.NaN;
                try(Frame cleared=new Frame(size[0],size[1],r)){check(BroadcastRenderTest.difference(inactive.image,cleared.image,0,0,size[0],size[1])==0,"Inactive measurement fields cannot change legacy or scene-only pixels");}
            }
        }
    }
    private static void compassAndMissing(File folder)throws Exception{
        Duwm1728BroadcastLayout.Report r=report("COMPACT",true);r.measuredHeadingDegrees=0;try(Frame north=new Frame(720,1280,r)){
            r.measuredHeadingDegrees=90;try(Frame east=new Frame(720,1280,r)){Duwm1728BroadcastLayout.Geometry g=east.geometry;check(BroadcastRenderTest.difference(north.image,east.image,(int)(g.x+22*g.unit+(g.width-44*g.unit)*.52f),(int)(g.telemetryTop+3*g.unit),(int)(28*g.unit),(int)(27*g.unit))>2,"Actual compass pixels rotate with measured bearing");}
        }
        r.measuredLocation=r.measuredCoordinates=r.measuredAccuracy=r.measuredHeading=r.measuredSpeed=r.measuredMovement=r.measuredAltitude=r.measuredFps=r.measuredWeather="";r.measuredHeadingDegrees=Double.NaN;
        try(Frame missing=new Frame(720,1280,r)){check(missing.painter.has("MEASUREMENTS UNAVAILABLE"),"Missing measurements have one neutral state");check(!missing.painter.has("GPS 0.")&&!missing.painter.has("km/h")&&!missing.painter.has("Open-Meteo")&&!missing.painter.has("fps"),"Missing fields never acquire fabricated values");check(ImageIO.write(missing.image,"png",new File(folder,"HOST-MEASURED-UNAVAILABLE.png")),"Save unavailable measurement host rendering");}
        r=report("COMPACT",true);r.measuredLocation="PLACE "+"Very long synthetic campus name ".repeat(20);
        try(Frame longName=new Frame(720,1280,r)){check(longName.painter.has("…"),"Very long location is visibly abbreviated");check(longName.painter.has("0.33567")&&longName.painter.has("32.56890")&&longName.painter.has("±6 m"),"Long place names do not hide actual coordinates or accuracy");for(Text text:longName.painter.text)check(text.width<=text.clip.getWidth()+.1,"Long source names stay bounded");}
        r.measuredCoordinates="LAT/LON -89.99999, -179.99999";r.measuredAccuracy="ACC ±50 m";r.measuredHeading="CAM HDG 359° NW MAG";r.measuredHeadingDegrees=359;r.measuredSpeed="SPEED 3600.0 km/h";r.measuredMovement="STATIONARY";r.measuredAltitude="ALT 100000 m WGS84 ±50 m";r.measuredFps="PREVIEW 1000.0 fps";
        r.measuredWeatherDescription="Very long synthetic conditions description ".repeat(20);r.measuredWeatherNumbers="-100.0°C / WIND 150.0 m/s";r.measuredWeatherTime="23:59 UTC";
        for(int[] size:SIZES)try(Frame extreme=new Frame(size[0],size[1],r)){
            for(String value:new String[]{"-89.99999","-179.99999","±50 m","359° NW MAG","3600.0 km/h","STATIONARY","100000 m WGS84","1000.0 fps","Open-Meteo","-100.0°C","150.0 m/s","23:59 UTC"})check(extreme.painter.has(value),"Reserved cells keep extreme actual numbers/units/provider/time visible: "+value);
            if(size[0]==720&&size[1]==1280)check(ImageIO.write(extreme.image,"png",new File(folder,"HOST-MEASURED-EXTREME.png")),"Save extreme measured layout");
        }
        r=report("COMPACT",true);r.measuredCoordinates="LAT/LON STALE";r.measuredAccuracy="ACC STALE";r.measuredLocation="PLACE STALE";r.measuredWeather="MODEL WX STALE";r.measuredWeatherProvider=r.measuredWeatherDescription=r.measuredWeatherNumbers=r.measuredWeatherTime="";
        try(Frame stale=new Frame(720,1280,r)){check(stale.painter.has("MODEL WX STALE")&&stale.painter.has("LAT/LON STALE")&&stale.painter.has("MAG"),"Stale fields retain concise status while independent current fields stay visible");check(!stale.painter.has("0.33567")&&!stale.painter.has("26.5"),"Stale states contain no previous numbers");check(ImageIO.write(stale.image,"png",new File(folder,"HOST-MEASURED-STALE.png")),"Save partial stale measured layout");}
    }
    public static void main(String[] args)throws Exception{
        File folder=new File(args.length==0?"measured-layout-host-proof":args[0]);if(!folder.isDirectory()&&!folder.mkdirs())throw new IllegalStateException("Cannot create measured host proof folder");geometry(folder);compassAndMissing(folder);
        String result="{\n  \"schema\": 1,\n  \"status\": \"PASS\",\n  \"checks\": "+checks+",\n  \"measurement_source\": \"synthetic-host-fixture\",\n  \"physical_sensor_verified\": false,\n  \"provider_network_verified\": false,\n  \"model_inference_verified\": false,\n  \"android_export_verified\": false\n}\n";
        Files.write(new File(folder,"MEASURED-LAYOUT-HOST.json").toPath(),result.getBytes(StandardCharsets.UTF_8));System.out.println("PASS "+checks+" measured layout/source-label/privacy/compass/glyph/legacy checks. HOST SYNTHETIC FIXTURES ONLY; no sensor, provider or Android export claim.");
    }
}
