package com.sentongoharuna.worldsituationroom;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import com.sentongoharuna.worldsituationroom.Duwm1728SpeechSessionPolicy.Completion;

/** Host acceptance-policy evidence only. No recognizer, microphone, model or
 * Android callback is simulated and no conclusion about acoustic silence follows. */
public final class RecordedSpeechSessionTest {
    private static int checks;
    private static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    private static Completion state(int bits,int segments,int characters){
        return Duwm1728SpeechSessionPolicy.completion((bits&1)!=0,(bits&2)!=0,
                (bits&4)!=0,(bits&8)!=0,(bits&16)!=0,segments,characters);
    }
    public static void main(String[] args)throws Exception{
        // The only accepted state has exact request support, a started recognizer,
        // segmented end and completely written/closed PCM, with no termination.
        int acceptedEmpty=0,acceptedWords=0;
        for(int bits=0;bits<32;bits++){
            Completion empty=state(bits,0,0),words=state(bits,1,5);
            check((empty==Completion.NO_WORDS)==(bits==15),"Unexpected empty-session acceptance at state "+bits);
            check((words==Completion.WITH_WORDS)==(bits==15),"Unexpected word-session acceptance at state "+bits);
            if(empty==Completion.NO_WORDS)acceptedEmpty++;
            if(words==Completion.WITH_WORDS)acceptedWords++;
        }
        check(acceptedEmpty==1&&acceptedWords==1,"Completion must have exactly one fully confirmed success state");
        check(state(0,0,0)==Completion.WAITING,"Unstarted request is not completed silence");
        check(state(1,0,0)==Completion.WAITING,"Support confirmation alone cannot finish a request");
        check(state(3,0,0)==Completion.WAITING,"A started supported request still needs both completion signals");
        check(state(7,0,0)==Completion.WAITING,"Session end before the writer closes must wait");
        check(state(11,0,0)==Completion.WAITING,"Closed PCM before segmented end must wait");
        check(state(15,0,0)==Completion.NO_WORDS,"Both completion orders can finish without words");
        check(state(7,1,5)==Completion.WAITING&&state(11,1,5)==Completion.WAITING,
                "Returned text cannot bypass either completion signal");
        check(state(15,1,5)==Completion.WITH_WORDS,"Returned text remains a separate completed result");
        check(state(19,0,0)==Completion.TERMINATED&&state(31,0,0)==Completion.TERMINATED,
                "Failure or cancellation before completion remains terminated after late end/PCM signals");
        check(state(31,1,5)==Completion.TERMINATED,"Partial words cannot revive a failed request");
        check(state(4,0,0)==Completion.INVALID,"An unsolicited segmented end is rejected");
        check(state(8,0,0)==Completion.INVALID,"PCM delivery without a confirmed started request is rejected");
        check(state(2,0,0)==Completion.INVALID,"Start without exact request support is rejected");
        check(state(1,1,5)==Completion.INVALID,"Returned words before start are rejected");
        check(state(15,0,5)==Completion.INVALID,"Words without a nonempty segment cannot become no-word success");
        check(state(15,1,0)==Completion.INVALID,"A nonempty segment with no transcript is inconsistent");
        check(state(15,-1,0)==Completion.INVALID&&state(15,0,-1)==Completion.INVALID,"Negative evidence counts are rejected");
        check(state(15,6,5)==Completion.INVALID,"There cannot be more nonempty segments than transcript characters");
        check(Duwm1728SpeechSessionPolicy.NO_WORDS_RETURNED.equals("NO_WORDS_RETURNED"),
                "Observable no-word status must not claim proven acoustic silence");
        Path folder=Path.of(args.length==0?"verification/recorded-audio-host-proof":args[0]);Files.createDirectories(folder);
        Files.writeString(folder.resolve("RECORDED-SPEECH-SESSION-HOST-RESULT.json"),
                "{\n  \"status\": \"PASS\",\n  \"checks\": "+checks+",\n  \"native_executed\": false,\n  \"scope\": \"real production completion gate; supported started segmented session and complete PCM delivery required\",\n  \"state_combinations\": 32,\n  \"errors_are_no_words\": false,\n  \"recognizer_or_model_verified\": false,\n  \"acoustic_silence_inferred\": false\n}\n",StandardCharsets.UTF_8);
        System.out.println("PASS "+checks+" recorded-speech session assertions; host completion policy only, no Android recognizer or silence verification");
    }
}
