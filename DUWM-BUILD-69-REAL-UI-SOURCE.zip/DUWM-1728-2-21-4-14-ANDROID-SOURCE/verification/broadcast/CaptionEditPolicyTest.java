package com.sentongoharuna.worldsituationroom;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import javax.imageio.ImageIO;

/** Executed source-time editing and shared-Painter tests. No Android/runtime claim. */
public final class CaptionEditPolicyTest {
    private static int checks;
    private static void check(boolean ok,String message){checks++;if(!ok)throw new AssertionError(message);}
    private static void rejects(Runnable work,String message){
        boolean rejected=false;try{work.run();}catch(IllegalArgumentException expected){rejected=true;check(expected.getMessage()!=null&&!expected.getMessage().isEmpty(),message+" has actionable error");}
        check(rejected,message);
    }
    private static void immutable(List<Duwm1728BroadcastLayout.Cue> cues){
        boolean rejected=false;try{cues.add(new Duwm1728BroadcastLayout.Cue(0,1,"Mutation"));}catch(UnsupportedOperationException expected){rejected=true;}
        check(rejected,"Returned caption document cannot be mutated");
    }
    private static String fingerprint(List<Duwm1728BroadcastLayout.Cue> cues){
        StringBuilder result=new StringBuilder();for(Duwm1728BroadcastLayout.Cue c:cues)result.append(c.startMs).append('/').append(c.endMs).append('/').append(c.text.length()).append(':').append(c.text).append('\n');return result.toString();
    }
    private static void exact(Duwm1728BroadcastLayout.Cue cue,long start,long end,String text,String message){check(cue.startMs==start&&cue.endMs==end&&cue.text.equals(text),message);}
    private static Duwm1728BroadcastLayout.Cue cue(long start,long end,String text){return new Duwm1728BroadcastLayout.Cue(start,end,text);}
    private static void timeTests(){
        String[] inputs={"0","1","0.001","1.2","1.23","1.234","  0001.001  ","00:00.001","01:02.003","01:02","1:02:03.004","90:00.125","2562047788015:12:55.807","153722867280912:55.807","9223372036854775.807"};
        long[] expected={0,1000,1,1200,1230,1234,1001,1,62003,62000,3723004,5400125,Long.MAX_VALUE,Long.MAX_VALUE,Long.MAX_VALUE};
        for(int i=0;i<inputs.length;i++)check(Duwm1728CaptionEditPolicy.parseTime(inputs[i])==expected[i],"Exact time parse "+inputs[i]);
        for(String invalid:new String[]{null,""," ",".5","1.","-0","-1.2","+1","1e3","NaN","Infinity","0.0001","00:60.000","00:60:00.000","00:00:60.000","00::01.000","1:2","00:00:01.0000","1,5","1 :00","٠١.٠٠٠","9223372036854775.808","9223372036854776","2562047788015:12:55.808","153722867280912:55.808","99999999999999999999999999999999","1:00:00:00"})
            rejects(()->Duwm1728CaptionEditPolicy.parseTime(invalid),"Reject ambiguous, fractional or overflowing timestamp "+invalid);
        check(Duwm1728CaptionEditPolicy.formatTime(437).equals("00:00:00.437"),"Formatting includes exact milliseconds and hours");
        check(Duwm1728CaptionEditPolicy.formatTime(Long.MAX_VALUE).equals("2562047788015:12:55.807"),"Maximum timestamp formats without arithmetic overflow");
        Locale previous=Locale.getDefault();try{Locale.setDefault(new Locale("ar","EG"));
            check(Duwm1728CaptionEditPolicy.formatTime(3723004).equals("01:02:03.004"),"Saved clock text is locale-independent ASCII");
        }finally{Locale.setDefault(previous);}
        for(long value:new long[]{0,1,999,1000,59999,60000,3599999,3600000,86400000,59999999999999L,Long.MAX_VALUE-1,Long.MAX_VALUE})
            check(Duwm1728CaptionEditPolicy.parseTime(Duwm1728CaptionEditPolicy.formatTime(value))==value,"Time formatting round-trips exact boundary "+value);
        rejects(()->Duwm1728CaptionEditPolicy.formatTime(-1),"Negative formatted time rejected");
    }
    private static void textAndBounds(){
        String unicode="مرحبا 世界 👩🏾‍💻 e\u0301 ; = ✅";
        exact(Duwm1728CaptionEditPolicy.cue("0.437","1.567",unicode,2000),437,1567,unicode,"Unicode, combining marks and punctuation preserved");
        exact(Duwm1728CaptionEditPolicy.cue("0","0.001"," first\r\n\tsecond ",1),0,1,"first second","Multiline pasted words explicitly normalize to spaces");
        String emoji="🌍".repeat(250);check(Duwm1728CaptionEditPolicy.cue("0","1",emoji,1000).text.equals(emoji),"Maximum valid Unicode length is never split or truncated");
        for(String invalid:new String[]{null,""," \t\r\n ","\u00a0\u2003","\u200b\u200d","x".repeat(501),"x".repeat(499)+"🌍","bad\u0000text","bad\u001btext","bad\u007ftext","bad\u0085text","broken\ud83c","\udf0d"})
            rejects(()->Duwm1728CaptionEditPolicy.cue("0","1",invalid,1000),"Invalid or oversized raw words fail before Cue sanitization");
        for(String[] times:new String[][]{{"0","0"},{"1","0.999"},{"-1","1"},{"0","1.001"},{"1","2"}})
            rejects(()->Duwm1728CaptionEditPolicy.cue(times[0],times[1],"Words",1000),"Invalid source cue bounds rejected");
        for(long duration:new long[]{0,-1,Long.MIN_VALUE})rejects(()->Duwm1728CaptionEditPolicy.cue("0","0.001","Words",duration),"Unavailable source duration rejected");
        exact(Duwm1728CaptionEditPolicy.cue("9223372036854775.806","9223372036854775.807","Last millisecond",Long.MAX_VALUE),Long.MAX_VALUE-1,Long.MAX_VALUE,"Last millisecond","Valid final source millisecond preserved");
    }
    private static void copiesAndEdits(){
        ArrayList<Duwm1728BroadcastLayout.Cue> source=new ArrayList<>(Arrays.asList(cue(2400,3100,"Later"),cue(437,1567,"Original words"),cue(1000,1800,"Overlap")));
        String before=fingerprint(source);List<Duwm1728BroadcastLayout.Cue> copied=Duwm1728CaptionEditPolicy.copyAndValidate(source,4000);
        exact(copied.get(0),437,1567,"Original words","Copy is sorted by source start");
        check(before.equals(fingerprint(source)),"Sorting a copy leaves source order and cue bytes unchanged");
        check(copied.get(0)!=source.get(1),"Copy owns independent cue objects");immutable(copied);
        List<Duwm1728BroadcastLayout.Cue> changed=Duwm1728CaptionEditPolicy.replace(source,1,cue(437,1567,"Corrected words"),4000);
        exact(changed.get(0),437,1567,"Corrected words","Word correction targets original input index before sorting");
        exact(changed.get(1),1000,1800,"Overlap","Untouched overlap retains exact words and source bounds");
        exact(changed.get(2),2400,3100,"Later","Untouched later cue retains exact words and source bounds");
        check(before.equals(fingerprint(source)),"Valid edit leaves caller's document unchanged");immutable(changed);
        List<Duwm1728BroadcastLayout.Cue> retimed=Duwm1728CaptionEditPolicy.replace(changed,2,cue(100,350,"Later"),4000);
        exact(retimed.get(0),100,350,"Later","Changing source times reorders only the edited cue");
        exact(retimed.get(1),437,1567,"Corrected words","Reordering does not rebase an untouched cue");
        List<Duwm1728BroadcastLayout.Cue> added=Duwm1728CaptionEditPolicy.add(changed,cue(2000,2200,"Added"),4000);immutable(added);
        check(added.size()==4&&added.get(2).text.equals("Added"),"New cue is independently inserted in source order");
        List<Duwm1728BroadcastLayout.Cue> removed=Duwm1728CaptionEditPolicy.remove(source,0,4000);immutable(removed);
        check(removed.size()==2&&removed.stream().noneMatch(c->c.text.equals("Later")),"Delete targets original input index before sorting");
        for(int invalid:new int[]{-1,3,Integer.MAX_VALUE}){
            rejects(()->Duwm1728CaptionEditPolicy.replace(source,invalid,cue(0,1,"New"),4000),"Invalid replace index rejected");
            rejects(()->Duwm1728CaptionEditPolicy.remove(source,invalid,4000),"Invalid delete index rejected");
        }
        for(Duwm1728BroadcastLayout.Cue invalid:new Duwm1728BroadcastLayout.Cue[]{null,cue(1,2,""),cue(3999,4001,"Outside source")}){
            rejects(()->Duwm1728CaptionEditPolicy.replace(source,1,invalid,4000),"Invalid replacement rejected atomically");
            rejects(()->Duwm1728CaptionEditPolicy.add(source,invalid,4000),"Invalid addition rejected atomically");
            check(before.equals(fingerprint(source)),"Failed edit cannot partially mutate original words or times");
        }
        rejects(()->Duwm1728CaptionEditPolicy.copyAndValidate(null,4000),"Missing caption document rejected");
        rejects(()->Duwm1728CaptionEditPolicy.copyAndValidate(Arrays.asList(cue(0,1,"Valid"),null),4000),"Missing cue rejected instead of silently dropped");
        rejects(()->Duwm1728CaptionEditPolicy.copyAndValidate(Arrays.asList(cue(0,1,"Valid"),cue(4000,5000,"Outside")),4000),"Out-of-source existing cue is not silently dropped");
        source.clear();check(copied.size()==3&&changed.size()==3,"Returned documents survive later mutation of caller's list");
        List<Duwm1728BroadcastLayout.Cue> empty=Duwm1728CaptionEditPolicy.remove(Collections.singletonList(cue(0,1,"Only")),0,1);check(empty.isEmpty(),"Deleting final caption intentionally produces an empty document");immutable(empty);
    }
    private static void overlapsAndCapacity(){
        List<Duwm1728BroadcastLayout.Cue> source=Arrays.asList(cue(0,1000,"Earlier"),cue(500,1500,"Same start first"),cue(500,800,"Same start last"));
        List<Duwm1728BroadcastLayout.Cue> copied=Duwm1728CaptionEditPolicy.copyAndValidate(source,2000);
        check(fingerprint(source).equals(fingerprint(copied)),"Historical overlap and equal-start order survive copying");
        check(Duwm1728BroadcastLayout.active(copied,600).text.equals("Same start last"),"Latest stable equal-start cue retains renderer priority");
        check(Duwm1728BroadcastLayout.active(copied,800).text.equals("Same start first"),"Ending an overlapping cue reveals the still-active predecessor");
        List<Duwm1728BroadcastLayout.Cue> changed=Duwm1728CaptionEditPolicy.replace(copied,1,cue(500,1500,"Corrected first"),2000);
        check(Duwm1728BroadcastLayout.active(changed,600).text.equals("Same start last"),"Editing earlier equal-start text cannot change winner");
        List<Duwm1728BroadcastLayout.Cue> added=Duwm1728CaptionEditPolicy.add(changed,cue(500,700,"Added last"),2000);
        check(Duwm1728BroadcastLayout.active(added,600).text.equals("Added last"),"Added equal-start cue follows existing stable order");
        check(Duwm1728BroadcastLayout.active(Duwm1728CaptionEditPolicy.remove(copied,2,2000),600).text.equals("Same start first"),"Deleting equal-start winner preserves the other cue");
        ArrayList<Duwm1728BroadcastLayout.Cue> many=new ArrayList<>();
        for(int i=0;i<Duwm1728CaptionEditPolicy.MAX_CUES;i++)many.add(cue(i*2L,i*2L+1,"Cue "+i));
        String before=fingerprint(many);List<Duwm1728BroadcastLayout.Cue> maximum=Duwm1728CaptionEditPolicy.copyAndValidate(many,40001);
        check(maximum.size()==20000&&fingerprint(maximum).equals(before),"All 20000 valid source cues retained exactly");
        List<Duwm1728BroadcastLayout.Cue> edited=Duwm1728CaptionEditPolicy.replace(maximum,19999,cue(39998,39999,"Last correction"),40001);
        check(edited.size()==20000&&edited.get(19999).text.equals("Last correction"),"Final cue remains editable at capacity");
        rejects(()->Duwm1728CaptionEditPolicy.add(maximum,cue(40000,40001,"One too many"),40001),"Over-capacity addition fails atomically");
        check(fingerprint(many).equals(before)&&fingerprint(maximum).equals(before),"Large edit attempts preserve both source and prior snapshot");
        ArrayList<Duwm1728BroadcastLayout.Cue> tooMany=new ArrayList<>(many);tooMany.add(cue(40000,40001,"Too many"));
        rejects(()->Duwm1728CaptionEditPolicy.copyAndValidate(tooMany,40001),"Oversized imported caption document rejected");
        check(Duwm1728CaptionEditPolicy.add(Duwm1728CaptionEditPolicy.remove(maximum,0,40001),cue(40000,40001,"Replacement"),40001).size()==20000,"Capacity freed by deletion is usable without discarding another cue");
    }
    private static void legacyAndImport(){
        List<Duwm1728TickerTimeline.Cue> raw=Duwm1728TickerTimeline.parse("00:00=First;00:03=Second;00:12=Third");
        List<Duwm1728BroadcastLayout.Cue> migrated=Duwm1728CaptionEditPolicy.fromLegacy(raw,137,17000);immutable(migrated);
        exact(migrated.get(0),137,3137,"First","Migration uses saved millisecond origin and next start");
        exact(migrated.get(1),3137,9137,"Second","Migration keeps bounded six-second display");
        exact(migrated.get(2),12137,17000,"Third","Migration clips final display to complete source end");
        check(Duwm1728BroadcastLayout.active(migrated,10000)==null,"Migration retains manual silent gap");
        String before=fingerprint(migrated);
        List<Duwm1728BroadcastLayout.Cue> edited=Duwm1728CaptionEditPolicy.replace(migrated,1,cue(3137,9137,"Second corrected"),17000);
        List<Duwm1728BroadcastLayout.Cue> trim=Duwm1728BroadcastTimeline.captions(edited,5000,16000);
        exact(trim.get(0),0,4137,"Second corrected","Word edit after a later trim retains the original source anchor");
        exact(trim.get(1),7137,11000,"Third","Trim transforms untouched source timing without moving it");
        check(edited.size()==3&&edited.get(0).startMs==137,"Cues outside current trim remain editable in complete source document");
        check(before.equals(fingerprint(migrated)),"Trim projection cannot mutate original migrated document");
        ArrayList<Duwm1728TickerTimeline.Cue> reversed=new ArrayList<>(raw);Collections.reverse(reversed);
        check(before.equals(fingerprint(Duwm1728CaptionEditPolicy.fromLegacy(reversed,137,17000))),"Unsorted legacy input migrates in actual source order");
        exact(Duwm1728CaptionEditPolicy.fromLegacy(Collections.singletonList(new Duwm1728TickerTimeline.Cue(0,"Last")),Long.MAX_VALUE-100,Long.MAX_VALUE).get(0),Long.MAX_VALUE-100,Long.MAX_VALUE,"Last","Legacy six-second end calculation cannot overflow");
        exact(Duwm1728CaptionEditPolicy.fromLegacy(Collections.singletonList(new Duwm1728TickerTimeline.Cue(0,"One")),0,1).get(0),0,1,"One","Legacy cue survives shortest valid source");
        rejects(()->Duwm1728CaptionEditPolicy.fromLegacy(raw,-1,17000),"Negative saved origin rejected");
        rejects(()->Duwm1728CaptionEditPolicy.fromLegacy(raw,17000,17000),"Legacy starts at source end rejected, not discarded");
        rejects(()->Duwm1728CaptionEditPolicy.fromLegacy(raw,Long.MAX_VALUE-2,Long.MAX_VALUE),"Legacy origin addition overflow rejected");
        rejects(()->Duwm1728CaptionEditPolicy.fromLegacy(Arrays.asList(new Duwm1728TickerTimeline.Cue(0,"First"),new Duwm1728TickerTimeline.Cue(1000,"Outside")),0,1000),"One invalid legacy cue cannot silently disappear from a partial migration");
        rejects(()->Duwm1728CaptionEditPolicy.fromLegacy(Arrays.asList(new Duwm1728TickerTimeline.Cue(0,"One"),new Duwm1728TickerTimeline.Cue(0,"Two")),0,1000),"Duplicate start-only legacy cues require correction rather than silent loss");
        rejects(()->Duwm1728CaptionEditPolicy.fromLegacy(Collections.singletonList(new Duwm1728TickerTimeline.Cue(-1,"Bad")),0,1000),"Negative legacy offset rejected");
        StringBuilder srt=new StringBuilder();for(int i=0;i<24;i++)srt.append(i+1).append('\n').append(Duwm1728CaptionEditPolicy.formatTime(i*2000+125)).append(" --> ").append(Duwm1728CaptionEditPolicy.formatTime(i*2000+875)).append("\nImported ").append(i).append("\n\n");
        List<Duwm1728BroadcastLayout.Cue> imported=Duwm1728SubtitleImport.parseSrtCues(srt.toString());
        List<Duwm1728BroadcastLayout.Cue> corrected=Duwm1728CaptionEditPolicy.replace(imported,18,cue(36125,36875,"Reviewed words"),48000);
        check(corrected.size()==24,"Editing imported captions has no ticker twelve-cue limit");
        boolean untouched=true;for(int i=0;i<24;i++)if(i!=18){Duwm1728BroadcastLayout.Cue a=imported.get(i),b=corrected.get(i);untouched&=a.startMs==b.startMs&&a.endMs==b.endMs&&a.text.equals(b.text);}
        check(untouched,"Every other imported cue retains exact start, end, text and silent gaps");
        exact(imported.get(18),36125,36875,"Imported 18","Correcting imported words leaves source import unchanged");
    }

    private static final int WIDTH=960,HEIGHT=540;
    private static final String ORIGINAL="Rain starts today — original words",CORRECTED="Rain eased today — corrected words";
    private static List<Duwm1728BroadcastLayout.Cue> original(){return Duwm1728CaptionEditPolicy.copyAndValidate(Arrays.asList(cue(437,1567,ORIGINAL),cue(2400,3100,"Second cue unchanged")),4000);}
    private static List<Duwm1728BroadcastLayout.Cue> corrected(){return Duwm1728CaptionEditPolicy.replace(original(),0,Duwm1728CaptionEditPolicy.cue("0.437","1.567",CORRECTED,4000),4000);}
    private static final class Frame {
        final BufferedImage image;final Duwm1728BroadcastLayout.Geometry geometry;final ArrayList<String> words;
        Frame(String composition,List<Duwm1728BroadcastLayout.Cue> cues,long time){
            image=new BufferedImage(WIDTH,HEIGHT,BufferedImage.TYPE_INT_ARGB);Graphics2D g=image.createGraphics();g.setColor(new Color(0x23414E));g.fillRect(0,0,WIDTH,HEIGHT);
            g.setColor(new Color(0x3F6574));for(int x=0;x<WIDTH;x+=80)g.drawLine(x,0,x,HEIGHT);for(int y=0;y<HEIGHT;y+=54)g.drawLine(0,y,WIDTH,y);
            g.setColor(new Color(0xB6C8CF));g.fillOval(430,175,100,100);g.setFont(new Font("SansSerif",Font.BOLD,24));g.drawString("SYNTHETIC SOURCE",350,145);g.dispose();
            Duwm1728BroadcastLayout.Report report=new Duwm1728BroadcastLayout.Report();report.composition=composition;
            report.title="CAPTION EDITING TEST";report.category="WEATHER";report.clock="RECORDED • TEST";report.provenance="TEST FIXTURE • UNVERIFIED";
            report.location="Same words corrected, source timing preserved";report.description="Shared production renderer on desktop";report.captions=cues;
            BroadcastRenderTest.Painter painter=new BroadcastRenderTest.Painter(image);geometry=Duwm1728BroadcastLayout.draw(painter,WIDTH,HEIGHT,report,time);words=new ArrayList<>(painter.drawn);painter.g.dispose();
        }
    }
    private static boolean sameGeometry(Duwm1728BroadcastLayout.Geometry a,Duwm1728BroadcastLayout.Geometry b){
        return a.captionVisible==b.captionVisible&&a.captionLeft==b.captionLeft&&a.captionTop==b.captionTop&&a.captionWidth==b.captionWidth&&a.captionHeight==b.captionHeight&&a.captionBottom==b.captionBottom&&a.tagTop==b.tagTop&&a.bottom==b.bottom;
    }
    private static int changedOutsideCaption(Frame a,Frame b){
        Duwm1728BroadcastLayout.Geometry g=a.geometry;int changed=0;
        for(int y=0;y<HEIGHT;y++)for(int x=0;x<WIDTH;x++)if(a.image.getRGB(x,y)!=b.image.getRGB(x,y)&&!(x>=g.captionLeft-1&&x<=g.captionLeft+g.captionWidth+1&&y>=g.captionTop-1&&y<=g.captionBottom+1))changed++;
        return changed;
    }
    private static void renderTests(){
        List<Duwm1728BroadcastLayout.Cue> original=original(),corrected=corrected();String old=fingerprint(original);
        for(String mode:new String[]{"FULL","COMPACT","CAPTIONS"}){
            for(long time:new long[]{436,437,1566,1567,2000}){
                Frame before=new Frame(mode,original,time),after=new Frame(mode,corrected,time);boolean active=time>=437&&time<1567;
                check(sameGeometry(before.geometry,after.geometry),mode+" word edit preserves caption panel and report geometry at "+time);
                check(before.geometry.captionVisible==active&&after.geometry.captionVisible==active,mode+" original and corrected share exact start/end/gap at "+time);
                check(before.words.contains(ORIGINAL)==active&&after.words.contains(CORRECTED)==active,mode+" only supplied original/corrected words appear at "+time);
                int pixels=BroadcastRenderTest.difference(before.image,after.image,0,0,WIDTH,HEIGHT);
                check(active?pixels>20:pixels==0,mode+" correction changes real text pixels only while cue is active at "+time);
                check(changedOutsideCaption(before,after)==0,mode+" word correction leaves source picture and every other graphic unchanged");
            }
            List<Duwm1728BroadcastLayout.Cue> trimmed=Duwm1728BroadcastTimeline.captions(corrected,300,1900);
            exact(trimmed.get(0),137,1267,CORRECTED,mode+" trim rebases source cue without changing its end");
            Frame full=new Frame(mode,corrected,700),clip=new Frame(mode,trimmed,400);
            check(sameGeometry(full.geometry,clip.geometry),mode+" source-time and trim-time captions have identical placement");
            Duwm1728BroadcastLayout.Geometry box=full.geometry;
            check(BroadcastRenderTest.difference(full.image,clip.image,(int)box.captionLeft,(int)box.captionTop,(int)box.captionWidth,(int)box.captionHeight)==0,mode+" rebased caption has identical actual pixels");
            Frame ended=new Frame(mode,trimmed,1267);check(!ended.geometry.captionVisible,mode+" trimmed subtitle still ends at the exact source-derived boundary");
        }
        check(old.equals(fingerprint(original)),"All render and trim projections leave original source cue document unchanged");
    }
    private static void label(Graphics2D g,String text,int x,int y,int size,boolean bold){g.setFont(new Font("SansSerif",bold?Font.BOLD:Font.PLAIN,size));g.setColor(new Color(0xDEE5EF));g.drawString(text,x,y);}
    private static void renderProof(File folder)throws Exception{
        int tile=480,gap=18,top=112,frameHeight=270,rowHeight=310,boundaryTop=top+2*rowHeight+25;
        BufferedImage sheet=new BufferedImage(tile*3+gap*4,boundaryTop+255,BufferedImage.TYPE_INT_RGB);Graphics2D g=sheet.createGraphics();
        g.setColor(new Color(0x07121D));g.fillRect(0,0,sheet.getWidth(),sheet.getHeight());g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        label(g,"HOST RENDERED • CAPTION EDITING • 1728.2/21",gap,32,25,true);
        label(g,"NOT ANDROID FOOTAGE • Actual production Java Painter • Same source cue [437,1567 ms); only words changed.",gap,61,16,false);
        label(g,"All three layouts retain the original start, exact end and silence gap. No change to footage, timing or other graphics.",gap,87,15,false);
        String[] modes={"FULL","COMPACT","CAPTIONS"};
        for(int column=0;column<modes.length;column++)for(int row=0;row<2;row++){
            int x=gap+column*(tile+gap),y=top+row*rowHeight;
            label(g,modes[column]+" • "+(row==0?"ORIGINAL":"CORRECTED")+" • 700 ms",x,y+24,19,true);
            g.drawImage(new Frame(modes[column],row==0?original():corrected(),700).image,x,y+36,tile,frameHeight,null);
        }
        label(g,"Exact boundaries • CAPTIONS lower-picture crops • original and corrected share every visibility boundary",gap,boundaryTop+9,17,true);
        long[] times={436,437,1566,1567,2000};String[] names={"Before start","Start inclusive","Last active ms","End exclusive","Silence gap"};
        int small=280,spacing=18;
        for(int i=0;i<times.length;i++){
            int x=gap+i*(small+spacing),y=boundaryTop+25;label(g,times[i]+" ms • "+names[i],x,y+22,14,true);
            BufferedImage frame=new Frame("CAPTIONS",corrected(),times[i]).image;
            g.drawImage(frame,x,y+34,x+small,y+104,0,360,WIDTH,HEIGHT,null);
        }
        label(g,"HOST TESTS ALSO COMPARE FULL / COMPACT / CAPTIONS AT EVERY SHOWN BOUNDARY",gap,boundaryTop+160,16,true);
        label(g,"Trim [300,1900 ms) projects this unchanged source cue to [137,1267 ms). Original source cue data stays intact.",gap,boundaryTop+187,15,false);
        label(g,"This artifact proves desktop policy and raster behavior. Android editor, playback and MediaCodec execution are not demonstrated.",gap,boundaryTop+219,14,false);
        g.dispose();check(ImageIO.write(sheet,"png",new File(folder,"HOST-CAPTION-EDITING.png")),"Save visibly labeled host caption editing proof");
    }
    public static void main(String[] args)throws Exception{
        File folder=new File(args.length>0?args[0]:"caption-edit-host-proof");if(!folder.isDirectory()&&!folder.mkdirs())throw new IOException("Cannot create caption proof directory");
        timeTests();textAndBounds();copiesAndEdits();overlapsAndCapacity();legacyAndImport();renderTests();renderProof(folder);
        String result="{\n  \"status\": \"PASS\",\n  \"version\": \"1728.2/21\",\n  \"checks\": "+checks+",\n  \"scope\": \"HOST_CAPTION_EDIT_POLICY_AND_SHARED_PRODUCTION_PAINTER\",\n  \"native_executed\": false,\n  \"native_status\": \"NOT RUN\",\n  \"physical_camera_verified\": false,\n  \"source_cue_ms\": [437,1567],\n  \"sample_source_ms\": [436,437,1566,1567,2000],\n  \"source_trim_ms\": [300,1900],\n  \"trimmed_cue_ms\": [137,1267],\n  \"compositions\": [\"FULL\",\"COMPACT\",\"CAPTIONS\"],\n  \"original_cue_document_unchanged\": true,\n  \"caption_geometry_unchanged\": true,\n  \"outside_caption_pixels_unchanged\": true\n}\n";
        Files.write(new File(folder,"CAPTION-EDIT-HOST-RESULT.json").toPath(),result.getBytes(StandardCharsets.UTF_8));
        System.out.println("PASS "+checks+" caption edit, exact-time, migration, immutable-document and production-Painter assertions. HOST RENDERED; native /21 NOT RUN.");
    }
}
