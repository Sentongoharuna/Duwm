package com.sentongoharuna.worldsituationroom;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Executed pure-production-code tests; these are not Android document-provider tests. */
public final class CaptionSrtTest {
    private static int checks;
    private static int worstCaseBytes;
    private interface Attempt { void run() throws Exception; }
    private static void check(boolean condition,String message){checks++;if(!condition)throw new AssertionError(message);}
    private static void rejects(Attempt action,String message) throws Exception {
        boolean rejected=false;
        try{action.run();}catch(IllegalArgumentException expected){rejected=true;check(expected.getMessage()!=null&&!expected.getMessage().isEmpty(),message+" has an actionable error");}
        check(rejected,message);
    }
    private static void ioRejects(Attempt action,String message) throws Exception {
        boolean rejected=false;
        try{action.run();}catch(IOException expected){rejected=true;check(expected.getMessage()!=null&&!expected.getMessage().isEmpty(),message+" has an actionable error");}
        check(rejected,message);
    }
    private static Duwm1728BroadcastLayout.Cue cue(long start,long end,String words){return new Duwm1728BroadcastLayout.Cue(start,end,words);}
    private static String block(long start,long end,String words){
        return "1\n"+Duwm1728CaptionEditPolicy.formatTime(start).replace('.',',')+" --> "+
            Duwm1728CaptionEditPolicy.formatTime(end).replace('.',',')+"\n"+words+"\n\n";
    }
    private static String decoded(byte[] bytes) throws IOException{return Duwm1728CaptionSrt.read(new ByteArrayInputStream(bytes));}
    private static byte[] export(List<Duwm1728BroadcastLayout.Cue> source,Duwm1728CaptionSrt.TimeBase basis,long duration,long from,long to){
        return Duwm1728CaptionSrt.exportCues(source,basis,duration,from,to);
    }
    private static List<Duwm1728BroadcastLayout.Cue> imported(String text,Duwm1728CaptionSrt.TimeBase basis,long duration,long from,long to){
        return Duwm1728CaptionSrt.importCues(text,basis,duration,from,to);
    }
    private static void same(List<Duwm1728BroadcastLayout.Cue> expected,List<Duwm1728BroadcastLayout.Cue> actual,String name){
        check(expected.size()==actual.size(),name+" cue count");
        for(int i=0;i<expected.size();i++){
            Duwm1728BroadcastLayout.Cue first=expected.get(i),second=actual.get(i);
            check(first.startMs==second.startMs&&first.endMs==second.endMs&&first.text.equals(second.text),name+" cue "+i);
        }
    }
    private static void immutable(List<Duwm1728BroadcastLayout.Cue> list,String name){
        boolean rejected=false;try{list.add(cue(0,1,"changed"));}catch(UnsupportedOperationException expected){rejected=true;}
        check(rejected,name+" is immutable");
    }

    private static void exactAndLiteral() throws Exception {
        String literal="<b>مرحبا 世界</b> & <not markup>; value=42 🛰️ e\u0301";
        List<Duwm1728BroadcastLayout.Cue> source=Arrays.asList(cue(125,875,literal),cue(64500,66250,"Later recording"));
        byte[] bytes=export(source,Duwm1728CaptionSrt.TimeBase.ORIGINAL,70000,-5,-10);
        String srt=decoded(bytes);
        check(srt.startsWith("1\n00:00:00,125 --> 00:00:00,875\n"),"Canonical exact-ms SRT header");
        check(srt.contains(literal),"Literal markup, punctuation and Unicode are not stripped");
        check(srt.indexOf('\uFEFF')<0,"Export has no BOM");
        same(source,imported(srt,Duwm1728CaptionSrt.TimeBase.ORIGINAL,70000,Long.MAX_VALUE,Long.MIN_VALUE),"Original round trip ignores invalid trim");
        same(source,Duwm1728SubtitleImport.parseSrtCues(srt),"Compatibility parser shares exact codec");
        List<Duwm1728BroadcastLayout.Cue> bom=Duwm1728CaptionSrt.parse("\uFEFF"+srt.replace("\n","\r\n"));
        same(source,bom,"Leading BOM and CRLF");immutable(bom,"Parsed captions");
        same(source,Duwm1728CaptionSrt.parse(srt.replace('\n','\r')),"CR line endings");
        check(Duwm1728CaptionSrt.parse("00:00:00.125 --> 00:00:00.875\nFirst\nsecond\tline\n").get(0).text.equals("First second line"),"Optional index, dot milliseconds and ordinary multiline normalization");
        String timeWords="00:00:01,000 --> 00:00:02,000";
        List<Duwm1728BroadcastLayout.Cue> timeText=Collections.singletonList(cue(0,1,timeWords));
        same(timeText,Duwm1728CaptionSrt.parse(decoded(export(timeText,Duwm1728CaptionSrt.TimeBase.ORIGINAL,1,0,0))),"A literal timing-shaped text line remains words");
        List<Duwm1728BroadcastLayout.Cue> literalBom=Arrays.asList(cue(0,1,"Words\uFEFFmore"),cue(1,2,"\uFEFFleading words"));
        same(literalBom,Duwm1728CaptionSrt.parse(decoded(export(literalBom,Duwm1728CaptionSrt.TimeBase.ORIGINAL,2,-1,-2))),"U+FEFF within edited words is preserved, including the first text character");
        check(Duwm1728CaptionSrt.parse("  \t\n99999999999999999999999999999999999999\n00:00:00,000 --> 00:00:00,001\nWords\n\n \t").size()==1,"Sequence labels have no numeric overflow dependency");
    }

    private static void overlapsAndTrim() throws Exception {
        List<Duwm1728BroadcastLayout.Cue> unsorted=Arrays.asList(
            cue(1000,1300,"equal first"),cue(0,2000,"underlying"),cue(1000,1600,"equal last"));
        List<Duwm1728BroadcastLayout.Cue> ordered=Duwm1728CaptionEditPolicy.copyAndValidate(unsorted,2500);
        String full=decoded(export(unsorted,Duwm1728CaptionSrt.TimeBase.ORIGINAL,2500,2000,2100));
        List<Duwm1728BroadcastLayout.Cue> parsed=Duwm1728CaptionSrt.parse(full);same(ordered,parsed,"Stable overlapping order");
        check(Duwm1728BroadcastLayout.active(parsed,1100).text.equals("equal last"),"Equal-start last cue still wins");
        check(Duwm1728BroadcastLayout.active(parsed,1600).text.equals("underlying"),"Underlying overlapping cue resumes at exact end");
        check(Duwm1728BroadcastLayout.active(parsed,2000)==null,"Final exact end stays exclusive");
        List<Duwm1728BroadcastLayout.Cue> crossing=Arrays.asList(
            cue(50,150,"ends at trim start"),cue(50,200,"cross start"),cue(300,650,"corrected words"),
            cue(1000,1200,"unchanged"),cue(1400,1700,"cross end"),cue(1500,1700,"starts at trim end"),cue(1600,1850,"outside trim"));
        List<Duwm1728BroadcastLayout.Cue> before=new ArrayList<>(crossing);
        byte[] clip=export(crossing,Duwm1728CaptionSrt.TimeBase.SELECTED_CLIP,2000,150,1500);
        List<Duwm1728BroadcastLayout.Cue> relative=Duwm1728CaptionSrt.parse(decoded(clip));
        same(Duwm1728BroadcastTimeline.captions(crossing,150,1500),relative,"Selected export matches production timeline");
        check(relative.size()==4,"Only positive trim intersections are exported");
        check(relative.get(0).startMs==0&&relative.get(0).endMs==50,"Clip start crossing is clipped and rebased");
        check(relative.get(3).startMs==1250&&relative.get(3).endMs==1350,"Clip end crossing is clipped and rebased");
        check(Duwm1728BroadcastLayout.active(relative,50)==null&&Duwm1728BroadcastLayout.active(relative,149)==null,"Silent gap survives selected export");
        List<Duwm1728BroadcastLayout.Cue> absolute=imported(decoded(clip),Duwm1728CaptionSrt.TimeBase.SELECTED_CLIP,2000,150,1500);
        check(absolute.get(0).startMs==150&&absolute.get(0).endMs==200,"Clip import adds source origin exactly");
        check(absolute.get(3).startMs==1400&&absolute.get(3).endMs==1500,"Clip import retains clipped exact end");
        same(before,crossing,"Export does not mutate source");immutable(absolute,"Imported clip captions");
        List<Duwm1728BroadcastLayout.Cue> originalAgain=imported(decoded(export(crossing,Duwm1728CaptionSrt.TimeBase.ORIGINAL,2000,150,1500)),Duwm1728CaptionSrt.TimeBase.ORIGINAL,2000,150,1500);
        same(crossing,originalAgain,"Original export keeps cues outside trim");
        List<Duwm1728BroadcastLayout.Cue> collapsed=Duwm1728CaptionSrt.parse(decoded(export(ordered,Duwm1728CaptionSrt.TimeBase.SELECTED_CLIP,2500,1100,1700)));
        check(collapsed.get(0).startMs==0&&collapsed.get(1).startMs==0&&collapsed.get(2).startMs==0,"Clip can create equal-start intersections");
        check(Duwm1728BroadcastLayout.active(collapsed,0).text.equals("equal last"),"Stable clipping retains latest-start renderer priority");
        String justOne=block(1,2,"One millisecond");
        List<Duwm1728BroadcastLayout.Cue> one=imported(justOne,Duwm1728CaptionSrt.TimeBase.SELECTED_CLIP,Long.MAX_VALUE,Long.MAX_VALUE-2,Long.MAX_VALUE);
        check(one.get(0).startMs==Long.MAX_VALUE-1&&one.get(0).endMs==Long.MAX_VALUE,"Clip-origin addition stays exact at long boundary");
    }

    private static void rejectsMalformed() throws Exception {
        String valid=block(0,1000,"Words");
        rejects(()->Duwm1728CaptionSrt.parse(null),"Null file rejected");
        rejects(()->Duwm1728CaptionSrt.parse(" \t\r\n"),"Empty file rejected");
        rejects(()->Duwm1728CaptionSrt.parse(valid+"2\n"),"Dangling final index is not skipped");
        rejects(()->Duwm1728CaptionSrt.parse("1\n\n"+valid),"Missing indexed time is not skipped");
        rejects(()->Duwm1728CaptionSrt.parse("1\n00:00:00,000 --> 00:00:01,000\n\n"+valid),"Empty cue is not dropped");
        rejects(()->Duwm1728CaptionSrt.parse(valid+"2\nnot a time\nBroken\n\n"+valid),"Malformed middle block rejects the entire list");
        rejects(()->Duwm1728CaptionSrt.parse("1\n00:00:00,000 --> 00:00:01,000\nFirst\n2\n00:00:01,000 --> 00:00:02,000\nSecond"),"Missing blank before sequence-number and time-code pair is not merged");
        rejects(()->Duwm1728CaptionSrt.parse("00:00:00,000 --> 00:00:01,000\nFirst\n00:00:01,000 --> 00:00:02,000\nSecond"),"Missing blank before unnumbered next time code is not merged");
        rejects(()->Duwm1728CaptionSrt.parse(block(1000,500,"Reverse")),"Reverse interval rejected");
        rejects(()->Duwm1728CaptionSrt.parse(block(500,500,"Zero")),"Zero interval rejected");
        rejects(()->Duwm1728CaptionSrt.parse("00:60:00,000 --> 01:00:01,000\nWords"),"Invalid minute rejected");
        rejects(()->Duwm1728CaptionSrt.parse("00:00:60,000 --> 00:01:01,000\nWords"),"Invalid second rejected");
        rejects(()->Duwm1728CaptionSrt.parse("00:00:00,0001 --> 00:00:01,000\nWords"),"Submillisecond precision is not rounded");
        rejects(()->Duwm1728CaptionSrt.parse("00:00:00,000 --> 00:00:01,000 position:50%\nWords"),"Unsupported time-line suffix is not ignored");
        rejects(()->Duwm1728CaptionSrt.parse("\uFEFF\uFEFF"+valid),"Second leading BOM rejected");
        rejects(()->Duwm1728CaptionSrt.parse(valid+"\uFEFF"+valid),"BOM in a later block header is not stripped");
        rejects(()->Duwm1728CaptionSrt.parse(block(0,1,"Words\u0000more")),"NUL is not silently cleaned");
        rejects(()->Duwm1728CaptionSrt.parse(block(0,1,"Words\u000bmore")),"Unsupported text control rejected");
        rejects(()->Duwm1728CaptionSrt.parse(block(0,1,"Words\ud800")),"Incomplete high surrogate rejected");
        rejects(()->Duwm1728CaptionSrt.parse(block(0,1,"Words\udc00")),"Incomplete low surrogate rejected");
        rejects(()->Duwm1728CaptionSrt.parse(block(0,1,"x".repeat(501))),"501 UTF-16 words are not truncated");
        rejects(()->Duwm1728CaptionSrt.parse(block(0,1,"🛰".repeat(251))),"Surrogate pairs count as two UTF-16 units");
        check(Duwm1728CaptionSrt.parse(block(0,1,"🛰".repeat(250))).get(0).text.length()==500,"500 UTF-16 emoji boundary accepted");
        rejects(()->Duwm1728CaptionSrt.parse(block(0,1,"\u200b")),"Invisible-only cue rejected");
        rejects(()->imported(valid,Duwm1728CaptionSrt.TimeBase.ORIGINAL,999,0,999),"Original cue beyond source duration rejected");
        rejects(()->imported(valid,Duwm1728CaptionSrt.TimeBase.SELECTED_CLIP,2000,1000,1999),"Clip file beyond selected duration rejected rather than clipped");
        rejects(()->imported(valid,null,2000,0,2000),"Missing time basis rejected");
        rejects(()->imported(valid,Duwm1728CaptionSrt.TimeBase.ORIGINAL,0,0,1000),"Invalid source duration rejected");
        long[][] badRanges={{-1,1000},{1000,1000},{1001,1000},{0,2001},{Long.MIN_VALUE,Long.MAX_VALUE}};
        for(long[] range:badRanges){
            rejects(()->imported(valid,Duwm1728CaptionSrt.TimeBase.SELECTED_CLIP,2000,range[0],range[1]),"Invalid clip import range");
            rejects(()->export(Collections.singletonList(cue(0,1,"Words")),Duwm1728CaptionSrt.TimeBase.SELECTED_CLIP,2000,range[0],range[1]),"Invalid clip export range");
        }
        rejects(()->export(Collections.emptyList(),Duwm1728CaptionSrt.TimeBase.ORIGINAL,2000,0,1),"Empty original export rejected");
        rejects(()->export(Collections.singletonList(cue(1500,1600,"Outside")),Duwm1728CaptionSrt.TimeBase.SELECTED_CLIP,2000,0,1000),"Empty selected export rejected");
        rejects(()->export(null,Duwm1728CaptionSrt.TimeBase.ORIGINAL,2000,0,1),"Null source caption list rejected");
        rejects(()->export(Arrays.asList(cue(0,1,"Okay"),null),Duwm1728CaptionSrt.TimeBase.ORIGINAL,2000,0,1),"Null member rejected");
        rejects(()->export(Collections.singletonList(cue(0,2001,"Outside")),Duwm1728CaptionSrt.TimeBase.ORIGINAL,2000,0,1),"Export rejects invalid source end");
        rejects(()->export(Collections.singletonList(cue(0,1,"Words\ud800")),Duwm1728CaptionSrt.TimeBase.ORIGINAL,2000,0,1),"Export does not replace broken Unicode");
    }

    private static void longTimesAndSnapshots() throws Exception {
        String hours="123:45:56,789 --> 123:45:56,790\nLong hours";
        List<Duwm1728BroadcastLayout.Cue> parsed=Duwm1728CaptionSrt.parse(hours);
        check(parsed.get(0).startMs==445556789&&parsed.get(0).endMs==445556790,"More than two hour digits are exact");
        List<Duwm1728BroadcastLayout.Cue> boundary=Collections.singletonList(cue(Long.MAX_VALUE-1,Long.MAX_VALUE,"Last representable millisecond"));
        same(boundary,imported(decoded(export(boundary,Duwm1728CaptionSrt.TimeBase.ORIGINAL,Long.MAX_VALUE,-1,-2)),Duwm1728CaptionSrt.TimeBase.ORIGINAL,Long.MAX_VALUE,-1,-2),"Checked long timestamp round trip");
        rejects(()->Duwm1728CaptionSrt.parse("2562047788016:00:00,000 --> 2562047788017:00:00,000\nOverflow"),"Hour multiplication overflow rejected");
        rejects(()->Duwm1728CaptionSrt.parse("99999999999999999999999999999:00:00,000 --> 99999999999999999999999999999:00:00,001\nOverflow"),"Hour digits overflow rejected");
        String maximum=Duwm1728CaptionEditPolicy.formatTime(Long.MAX_VALUE).replace('.',',');
        rejects(()->Duwm1728CaptionSrt.parse(maximum+" --> 2562047788015:12:55,808\nOverflow"),"Final millisecond addition overflow rejected");
        ArrayList<Duwm1728BroadcastLayout.Cue> mutable=new ArrayList<>();mutable.add(cue(10,20,"Original"));
        byte[] captured=export(mutable,Duwm1728CaptionSrt.TimeBase.ORIGINAL,100,0,0);mutable.clear();
        List<Duwm1728BroadcastLayout.Cue> independent=Duwm1728CaptionSrt.parse(decoded(captured));
        check(independent.size()==1&&independent.get(0).text.equals("Original"),"Export is independent of later list edits");
        immutable(independent,"Round-trip list");
        List<Duwm1728BroadcastLayout.Cue> repeated=Duwm1728CaptionSrt.parse(decoded(captured));
        check(independent!=repeated&&independent.get(0)!=repeated.get(0),"Each parse owns independent cue objects");
    }

    private static final class CountingStream extends InputStream {
        private final long limit;private final boolean zeroBulk;long consumed;boolean closed;
        CountingStream(long byteCount,boolean zeroBulkReads){limit=byteCount;zeroBulk=zeroBulkReads;}
        @Override public int read(){if(consumed==limit)return -1;consumed++;return ' ';}
        @Override public int read(byte[] target,int offset,int length){
            if(zeroBulk)return 0;
            if(consumed==limit)return -1;int count=(int)Math.min(length,limit-consumed);
            Arrays.fill(target,offset,offset+count,(byte)' ');consumed+=count;return count;
        }
        @Override public void close(){closed=true;}
    }
    private static void strictBytes() throws Exception {
        byte[][] malformed={
            {(byte)0xc0,(byte)0xaf}, {(byte)0xe2,(byte)0x82}, {(byte)0x80},
            {(byte)0xed,(byte)0xa0,(byte)0x80}, {(byte)0xf4,(byte)0x90,(byte)0x80,(byte)0x80},
            {(byte)0xff}, {(byte)0xfe,(byte)0xff}
        };
        for(byte[] bytes:malformed)ioRejects(()->Duwm1728CaptionSrt.read(new ByteArrayInputStream(bytes)),"Malformed UTF-8 sequence");
        String valid="\uFEFF"+block(125,875,"مرحبا 世界 🛰");
        check(Duwm1728CaptionSrt.read(new ByteArrayInputStream(valid.getBytes(StandardCharsets.UTF_8))).equals(valid),"Strict UTF-8 decoding retains literal Unicode and leading BOM");
        CountingStream shortStream=new CountingStream(27,true);
        check(Duwm1728CaptionSrt.read(shortStream).length()==27&&shortStream.consumed==27,"Zero bulk reads make progress using single-byte reads");
        check(!shortStream.closed,"Read leaves ownership of the stream with the caller");
        CountingStream full=new CountingStream(Duwm1728CaptionSrt.MAX_BYTES,false);
        check(Duwm1728CaptionSrt.read(full).length()==Duwm1728CaptionSrt.MAX_BYTES,"Exact 32 MiB byte cap accepted by reader");
        check(full.consumed==Duwm1728CaptionSrt.MAX_BYTES&&!full.closed,"Exact-cap stream consumed and left open");
        CountingStream tooLarge=new CountingStream((long)Duwm1728CaptionSrt.MAX_BYTES+100000,false);
        ioRejects(()->Duwm1728CaptionSrt.read(tooLarge),"Oversized stream rejected");
        check(tooLarge.consumed==(long)Duwm1728CaptionSrt.MAX_BYTES+1,"Oversized stream stops after one detection byte");
        check(!tooLarge.closed,"Rejected stream also remains caller-owned");
        String overBytes="界".repeat(Duwm1728CaptionSrt.MAX_BYTES/3+1);
        rejects(()->Duwm1728CaptionSrt.parse(overBytes),"Direct String parser counts UTF-8 bytes, not UTF-16 length");
        rejects(()->Duwm1728CaptionSrt.read(null),"Null stream rejected");
    }

    private static void fullCapacity() throws Exception {
        final int count=Duwm1728CaptionEditPolicy.MAX_CUES;
        String worstWords="界".repeat(500);
        ArrayList<Duwm1728BroadcastLayout.Cue> source=new ArrayList<>(count);
        for(int i=0;i<count;i++)source.add(cue(i*10L,i*10L+9,worstWords));
        byte[] encoded=export(source,Duwm1728CaptionSrt.TimeBase.ORIGINAL,count*10L,1,2);worstCaseBytes=encoded.length;
        check(encoded.length>30000000&&encoded.length<=Duwm1728CaptionSrt.MAX_BYTES,"32 MiB accommodates 20000 cues with 500 three-byte UTF-8 characters each");
        String text=decoded(encoded);
        List<Duwm1728BroadcastLayout.Cue> imported=imported(text,Duwm1728CaptionSrt.TimeBase.ORIGINAL,count*10L,1,2);
        same(source,imported,"All 20000 full-length cues round trip");immutable(imported,"Maximum caption list");
        check(imported.get(count-1).text.length()==500,"Final large-file cue text is complete");
        check(Duwm1728SubtitleImport.parseSrtCues(text).size()==count,"Compatibility parser has no former 64 KiB or 5000-cue cutoff");
        rejects(()->Duwm1728CaptionSrt.parse(text+block(count*10L,count*10L+9,"Extra")),"20001st imported cue rejected without truncation");
        source.add(cue(count*10L,count*10L+9,"Extra"));
        rejects(()->export(source,Duwm1728CaptionSrt.TimeBase.ORIGINAL,(count+1)*10L,0,1),"20001st exported cue rejected without truncation");
    }

    public static void main(String[] args) throws Exception {
        exactAndLiteral();overlapsAndTrim();rejectsMalformed();longTimesAndSnapshots();strictBytes();fullCapacity();
        if(args.length>0){
            Path proof=Path.of(args[0]);Files.createDirectories(proof);
            String result="{\n  \"status\": \"PASS\",\n  \"scope\": \"pure Java caption SRT codec; no Android provider or native playback claim\",\n"+
                "  \"checks\": "+checks+",\n  \"maximum_cues\": "+Duwm1728CaptionEditPolicy.MAX_CUES+",\n"+
                "  \"maximum_bytes\": "+Duwm1728CaptionSrt.MAX_BYTES+",\n  \"worst_case_round_trip_bytes\": "+worstCaseBytes+"\n}\n";
            Files.writeString(proof.resolve("RESULT.json"),result,StandardCharsets.UTF_8);
        }
        System.out.println("PASS "+checks+" executed caption-file assertions; 20000 full-length Unicode cues, "+worstCaseBytes+" UTF-8 bytes; not an Android provider/native test.");
    }
}
