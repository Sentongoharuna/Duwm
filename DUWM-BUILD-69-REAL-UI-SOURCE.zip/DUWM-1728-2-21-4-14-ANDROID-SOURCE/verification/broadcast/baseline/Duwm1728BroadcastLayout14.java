/* TEST-ONLY BASELINE: exact /14 production layout, renamed solely to avoid a class-name collision.
 * Original source SHA-256: 07ec04b05a0163a560e5cbc53edc53fb03d94a89b10ebd2f30800e2b5d3899e5
 * This reference is never compiled into the Android app or instrumentation APK.
 */
package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** One composition for Android preview, encoded frames and executable desktop render tests.
 * This renderer does not infer events, fake telemetry or label content independently verified. */
public final class Duwm1728BroadcastLayout14 {
    public static final String SOURCE_SHA256="07ec04b05a0163a560e5cbc53edc53fb03d94a89b10ebd2f30800e2b5d3899e5";
    public static final int NAVY=0xFF041424,PANEL=0xFF041424,SILVER=0xFFDEE5EF,WHITE=0xFFF5F7FA,
        MUTED=0xFFA0A5AE,RED=0xFFD50000,GREEN=0xFF00C853,AMBER=0xFFFBC02D,CYAN=0xFF00ACC1;
    public interface Painter {
        void rect(float x,float y,float w,float h,int color,float radius);
        void line(float x,float y,float x2,float y2,int color,float thickness);
        void text(String text,float x,float baseline,float size,int color,boolean bold);
        float measure(String text,float size,boolean bold);
        void clip(float x,float y,float w,float h);void unclip();
    }
    public static final class Cue {
        public final long startMs,endMs;public final String text;
        public Cue(long start,long end,String words){if(start<0||end<=start)throw new IllegalArgumentException("Invalid cue");startMs=start;endMs=end;text=clean(words,500);}
    }
    public static final class Report {
        public String title="",location="",description="",category="FIELD REPORT",reporter="",clock="";
        public String heading="",altitude="",weather="",gps="",provenance="REPORTER ACCOUNT • UNVERIFIED";
        public boolean breakingApproved,coordinatesAllowed;public int tickerPixelsPerSecond=75;
        public List<Cue> tickers=new ArrayList<>(),captions=new ArrayList<>();
    }
    public static final class Geometry {
        public final float unit,x,width,headerTop,tagTop,headlineTop,telemetryTop,tickerTop,bottom;
        Geometry(int w,int h,boolean telemetry){unit=Math.min(w,h)/1080f;x=34*unit;width=w-2*x;
            headerTop=Math.max(h*.035f,24*unit);bottom=h-Math.max(h*.045f,26*unit);
            tickerTop=bottom-56*unit;telemetryTop=tickerTop-(telemetry?48*unit:0);
            headlineTop=telemetryTop-132*unit;tagTop=headlineTop-40*unit;}
    }
    public static String clean(String v,int maximum){if(v==null)return "";v=v.replaceAll("[\\p{Cntrl}]+"," ").trim();if(v.length()<=maximum)return v;int end=maximum;if(end>0&&Character.isHighSurrogate(v.charAt(end-1)))end--;return v.substring(0,end);}
    public static Cue active(List<Cue> list,long ms){Cue best=null;if(list!=null)for(Cue c:list)if(c.startMs<=ms&&ms<c.endMs&&(best==null||best.startMs<=c.startMs))best=c;return best;}
    /** Even encoded dimensions; exact requested ratio; never upscales the source. */
    public static int[] dimensions(int sourceW,int sourceH,String ratio){
        if(sourceW<2||sourceH<2)throw new IllegalArgumentException("Invalid source size");
        if("ORIGINAL".equals(ratio))return new int[]{sourceW&~1,sourceH&~1};
        int p,q;if("9:10".equals(ratio)){p=9;q=10;}else if("9:16".equals(ratio)){p=9;q=16;}
        else if("16:9".equals(ratio)){p=16;q=9;}else throw new IllegalArgumentException("Unknown aspect ratio");
        int k=Math.min(sourceW/p,sourceH/q)&~1;if(k<2)throw new IllegalArgumentException("Source too small");return new int[]{p*k,q*k};
    }
    /** Normalised centre crop in upright source space: x,y,width,height. */
    public static float[] crop(int sourceW,int sourceH,int outW,int outH){
        if(sourceW<=0||sourceH<=0||outW<=0||outH<=0)throw new IllegalArgumentException("Invalid frame size");
        float s=sourceW/(float)sourceH,t=outW/(float)outH,cw=s>t?t/s:1f,ch=s>t?1f:s/t;
        return new float[]{(1-cw)/2,(1-ch)/2,cw,ch};
    }
    private static String fit(Painter p,String text,float size,boolean bold,float width){
        String t=clean(text,700);if(p.measure(t,size,bold)<=width)return t;
        while(!t.isEmpty()&&p.measure(t+"…",size,bold)>width)t=t.substring(0,t.offsetByCodePoints(t.length(),-1));return t+"…";
    }
    private static List<String> wrap(Painter p,String value,float size,boolean bold,float width,int maximum){
        ArrayList<String> result=new ArrayList<>();String remaining=clean(value,700);
        while(!remaining.isEmpty()&&result.size()<maximum){
            if(result.size()==maximum-1){result.add(fit(p,remaining,size,bold,width));break;}
            int end=remaining.length();while(end>0&&p.measure(remaining.substring(0,end),size,bold)>width)end=remaining.offsetByCodePoints(end,-1);
            if(end==0)end=remaining.offsetByCodePoints(0,1);
            if(end<remaining.length()){int space=remaining.lastIndexOf(' ',end);if(space>0)end=space;}
            result.add(remaining.substring(0,end).trim());remaining=remaining.substring(end).trim();
        }return result;
    }
    public static Geometry draw(Painter p,int width,int height,Report r,long ms){
        if(width<64||height<64)throw new IllegalArgumentException("Canvas too small");
        boolean telemetry=!r.heading.isEmpty()||!r.altitude.isEmpty()||!r.weather.isEmpty()||(r.coordinatesAllowed&&!r.gps.isEmpty());
        Geometry g=new Geometry(width,height,telemetry);float u=g.unit,x=g.x,w=g.width,pad=22*u;
        p.rect(x,g.headerTop,282*u,66*u,PANEL,5*u);p.rect(x,g.headerTop,6*u,66*u,RED,0);
        p.text("DUWM",x+20*u,g.headerTop+35*u,32*u,WHITE,true);
        p.text("WORLD MONITOR",x+20*u,g.headerTop+55*u,14*u,SILVER,true);
        String clock=r.clock.isEmpty()?"RECORDED":r.clock;
        float cw=Math.min(w*.47f,Math.max(155*u,p.measure(clock,16*u,false)+28*u)),cx=width-x-cw;
        p.rect(cx,g.headerTop,cw,40*u,PANEL,4*u);p.text(fit(p,clock,16*u,false,cw-26*u),cx+13*u,g.headerTop+26*u,16*u,SILVER,false);
        String tag=r.breakingApproved?"BREAKING NEWS":clean(r.category,32).toUpperCase(Locale.ROOT);
        if(tag.isEmpty()||(!r.breakingApproved&&tag.contains("BREAKING")))tag="FIELD REPORT";
        float tagW=Math.max(195*u,Math.min(w*.53f,p.measure(tag,20*u,true)+40*u));
        p.rect(x,g.tagTop,tagW,40*u,r.breakingApproved?RED:NAVY,0);
        p.text(tag,x+20*u,g.tagTop+27*u,20*u,WHITE,true);
        p.rect(x+tagW,g.tagTop,w-tagW,40*u,PANEL,0);
        p.text(fit(p,r.provenance,13*u,false,w-tagW-24*u),x+tagW+12*u,g.tagTop+26*u,13*u,AMBER,false);
        p.rect(x,g.headlineTop,w,132*u,PANEL,0);
        float titleSize=(width>height?40:34)*u,ty=g.headlineTop+44*u;
        for(String row:wrap(p,r.title,titleSize,true,w-2*pad,2)){p.text(row,x+pad,ty,titleSize,WHITE,true);ty+=43*u;}
        String byline=clean(r.location,100);if(!r.reporter.isEmpty())byline+=(byline.isEmpty()?"":"  •  ")+clean(r.reporter,70);
        if(byline.isEmpty())byline=clean(r.description,140);
        p.text(fit(p,byline,18*u,false,w-2*pad),x+pad,g.headlineTop+115*u,18*u,SILVER,false);
        if(telemetry){
            p.rect(x,g.telemetryTop,w,48*u,NAVY,0);p.line(x,g.telemetryTop,x+w,g.telemetryTop,SILVER,u);
            ArrayList<String[]> fields=new ArrayList<>();
            if(!r.heading.isEmpty())fields.add(new String[]{"HDG",r.heading});if(!r.altitude.isEmpty())fields.add(new String[]{"ALT",r.altitude});
            if(!r.weather.isEmpty())fields.add(new String[]{"WX",r.weather});if(r.coordinatesAllowed&&!r.gps.isEmpty())fields.add(new String[]{"GPS",r.gps});
            float column=w/Math.max(1,fields.size());int i=0;
            for(String[] f:fields){float fx=x+pad+i++*column;p.text(f[0],fx,g.telemetryTop+14*u,11*u,MUTED,true);
                p.text(fit(p,f[1],22*u,false,column-pad*1.5f),fx,g.telemetryTop+41*u,22*u,CYAN,false);}
        }
        p.rect(x,g.tickerTop,w,56*u,NAVY,0);p.line(x,g.tickerTop,x+w,g.tickerTop,SILVER,u);
        float label=115*u;p.rect(x,g.tickerTop,label,56*u,RED,0);p.text("UPDATE",x+15*u,g.tickerTop+36*u,20*u,WHITE,true);
        Cue c=active(r.tickers,ms);String tick=c==null?clean(r.description,500):c.text;if(tick.isEmpty())tick=clean(r.title,500);
        if(!tick.isEmpty()){
            float start=x+label+16*u,available=w-label-30*u,size=23*u,period=p.measure(tick,size,false)+96*u;
            float speed=Math.max(20,Math.min(180,r.tickerPixelsPerSecond))*u;
            float shift=(Math.max(0,ms-(c==null?0:c.startMs))/1000f*speed)%period;
            p.clip(start,g.tickerTop,available,56*u);
            for(float tx=start-shift;tx<start+available;tx+=period)p.text(tick,tx,g.tickerTop+36*u,size,WHITE,false);
            p.unclip();
        }
        p.line(x,g.headlineTop,x+w,g.headlineTop,SILVER,1.2f*u);p.line(x,g.headlineTop,x,g.bottom,SILVER,1.4f*u);
        p.line(x+w,g.headlineTop,x+w,g.bottom,SILVER,1.4f*u);p.line(x,g.bottom,x+w,g.bottom,SILVER,u);
        Cue sub=active(r.captions,ms);
        if(sub!=null){float widthCap=Math.min(w,width*(width>height?.73f:.88f)),size=29*u;
            List<String> lines=wrap(p,sub.text,size,true,widthCap-32*u,2);float ch=(lines.size()*36+20)*u,top=g.tagTop-18*u-ch;
            p.rect((width-widthCap)/2,top,widthCap,ch,0xE4041424,6*u);float baseline=top+35*u;
            for(String row:lines){p.text(row,(width-p.measure(row,size,true))/2,baseline,size,WHITE,true);baseline+=36*u;}}
        return g;
    }
}
