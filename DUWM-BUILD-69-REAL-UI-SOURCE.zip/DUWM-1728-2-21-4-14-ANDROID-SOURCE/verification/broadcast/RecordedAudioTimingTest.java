package com.sentongoharuna.worldsituationroom;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** Executable source-time fixtures; this is not Android ASR/model availability evidence. */
public final class RecordedAudioTimingTest {
    private static int checks;
    private static void check(boolean condition,String message){checks++;if(!condition)throw new AssertionError(message);}
    private interface Operation{void run()throws Exception;}
    private static void rejects(Operation action,String message)throws Exception{
        boolean rejected=false;try{action.run();}catch(IllegalArgumentException expected){rejected=true;}check(rejected,message);
    }
    private static byte[] bytes(Duwm1728PcmTimeline timeline)throws Exception{
        ByteArrayOutputStream output=new ByteArrayOutputStream();timeline.writeTo(output);return output.toByteArray();
    }
    private static short[] samples(byte[] pcm){short[] result=new short[pcm.length/2];for(int i=0;i<result.length;i++)result[i]=(short)((pcm[2*i]&255)|(pcm[2*i+1]<<8));return result;}
    private static short[] constant(int count,int value){short[] result=new short[count];Arrays.fill(result,(short)value);return result;}
    private static void pcm()throws Exception{
        int[] rates={8000,16000,22050,32000,44100,48000};
        short[] expected=new short[160000];for(int i=0;i<expected.length;i++)expected[i]=(short)((i/16000)%2==0?1234:-2345);
        for(int rate:rates){
            short[] input=new short[rate*10];for(int i=0;i<input.length;i++)input[i]=(short)((i/rate)%2==0?1234:-2345);
            short[] original=input.clone();Duwm1728PcmTimeline whole=new Duwm1728PcmTimeline(0,10000);whole.accept(0,rate,input);
            check(whole.sampleCount()==160000,"Ten seconds produces exactly160000 samples at inputrate "+rate);
            check(whole.coveredSampleCount()==160000,"All source samples occupy the full ten-second grid "+rate);
            byte[] full=bytes(whole);check(full.length==320000,"PCM duration/byte count is unchanged "+rate);
            check(Arrays.equals(expected,samples(full)),"One-second waveform boundaries retain source timing "+rate);
            Duwm1728PcmTimeline chunked=new Duwm1728PcmTimeline(0,10000);
            for(int offset=0;offset<input.length;){int length=Math.min(offset%3==0?1024:777,input.length-offset);
                long pts=Math.round(offset*1000000d/rate);chunked.accept(pts,rate,Arrays.copyOfRange(input,offset,offset+length));offset+=length;}
            check(Arrays.equals(full,bytes(chunked)),"Codec packet boundaries do not change PCM clock or samples "+rate);
            check(Arrays.equals(input,original),"Source PCM array remains unchanged "+rate);
        }
        Duwm1728PcmTimeline upsample=new Duwm1728PcmTimeline(0,1);upsample.accept(0,8000,new short[]{1,2,3,4,5,6,7,8});
        check(Arrays.equals(samples(bytes(upsample)),new short[]{1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8}),"8kHz is expanded rather than played at double speed");
        Duwm1728PcmTimeline gaps=new Duwm1728PcmTimeline(1000,2000);
        gaps.accept(1100000,16000,constant(1600,1000));gaps.accept(1400000,16000,constant(1600,2000));
        short[] gapExpected=new short[16000];Arrays.fill(gapExpected,1600,3200,(short)1000);Arrays.fill(gapExpected,6400,8000,(short)2000);
        check(Arrays.equals(samples(bytes(gaps)),gapExpected),"Leading, internal and trailing source gaps stay silence at their real offsets");
        check(gaps.coveredSampleCount()==3200,"Gaps are not mislabeled as decoded source coverage");
        Duwm1728PcmTimeline trim=new Duwm1728PcmTimeline(4999,5137);short[] source=constant(6400,1000);Arrays.fill(source,3200,6400,(short)2000);
        trim.accept(4800000,16000,source);short[] trimmed=samples(bytes(trim));
        check(trimmed.length==138*16,"Non-whole-second trim retains exact millisecond duration");
        check(trimmed[0]==1000&&trimmed[15]==1000&&trimmed[16]==2000&&trimmed[trimmed.length-1]==2000,"Grid is anchored to the requested absolute source start");
        Duwm1728PcmTimeline changed=new Duwm1728PcmTimeline(0,1000);changed.accept(0,8000,constant(4000,300));changed.accept(500000,44100,constant(22050,600));
        short[] changedSamples=samples(bytes(changed));check(changedSamples.length==16000&&changedSamples[7999]==300&&changedSamples[8000]==600,"Output-format sample-rate changes preserve source time");
        Duwm1728PcmTimeline overlap=new Duwm1728PcmTimeline(0,1000);overlap.accept(0,16000,constant(11200,100));overlap.accept(500000,16000,constant(8000,200));
        short[] overlapSamples=samples(bytes(overlap));check(overlapSamples.length==16000&&overlapSamples[11199]==100&&overlapSamples[11200]==200,"Overlapping decoder buffers cannot duplicate output duration");
        Duwm1728PcmTimeline empty=new Duwm1728PcmTimeline(0,1000);check(empty.coveredSampleCount()==0,"No decoded audio is observable before accepting packets");
        rejects(()->new Duwm1728PcmTimeline(0,45001),"Per-call limit is enforced");
        rejects(()->new Duwm1728PcmTimeline(-1,1000),"Negative trim is rejected");
        rejects(()->new Duwm1728PcmTimeline(Long.MAX_VALUE-10,Long.MAX_VALUE),"Source timestamp conversion overflow is rejected");
        rejects(()->new Duwm1728PcmTimeline(0,1000).accept(0,7999,new short[1]),"Unsupported PCM rate is rejected");
        Duwm1728PcmTimeline backwards=new Duwm1728PcmTimeline(0,1000);backwards.accept(200000,16000,new short[1]);
        rejects(()->backwards.accept(100000,16000,new short[1]),"Backward decoder PTS is not silently reordered");
        boolean sealed=false;try{upsample.accept(0,8000,new short[1]);}catch(IllegalStateException expectedError){sealed=true;}check(sealed,"Published PCM cannot later be mutated");
        Duwm1728PcmTimeline cancelled=new Duwm1728PcmTimeline(0,1000);Thread.currentThread().interrupt();
        boolean interrupted=false;try{cancelled.writeTo(new ByteArrayOutputStream());}catch(InterruptedIOException expectedError){interrupted=true;}
        finally{Thread.interrupted();}check(interrupted,"Cancellation fails explicitly rather than accepting a partial PCM timeline");
        boolean writeFailure=false;try{new Duwm1728PcmTimeline(0,1000).writeTo(new OutputStream(){public void write(int value)throws IOException{throw new IOException("fixture close");}});}
        catch(IOException expectedError){writeFailure=true;}check(writeFailure,"Closed/failed audio streams are not reported as successful writes");
    }
    private static Duwm1728SpeechCues.Word word(long start,String text){return new Duwm1728SpeechCues.Word(start,text);}
    private static String joined(List<Duwm1728BroadcastLayout.Cue> cues){StringBuilder result=new StringBuilder();for(Duwm1728BroadcastLayout.Cue cue:cues){if(result.length()>0)result.append(' ');result.append(cue.text);}return result.toString();}
    private static void cues()throws Exception{
        List<Duwm1728SpeechCues.Word> source=Arrays.asList(word(123,"Hello"),word(789,"world"),word(3567,"again"),word(9000,"last"));
        List<Duwm1728BroadcastLayout.Cue> cues=Duwm1728SpeechCues.fromWords(source,60000,70000);
        check(cues.size()==3,"Large word gaps create independent display groups");
        check(cues.get(0).startMs==60123&&cues.get(1).startMs==63567&&cues.get(2).startMs==69000,"Exact reported starts retain absolute source origin, never four-second floors");
        check(cues.get(0).endMs==61989&&cues.get(1).endMs==64767&&cues.get(2).endMs==70000,"Derived ends are bounded after the last word and clipped to source end");
        check(cues.get(0).endMs<cues.get(1).startMs,"Long silent interval remains a visible caption gap");
        check(joined(cues).equals("Hello world again last"),"Every recognized word survives grouping");
        check(source.get(0).offsetMs==123&&source.get(0).text.equals("Hello"),"Word input remains unchanged");
        boolean immutable=false;try{cues.add(cues.get(0));}catch(UnsupportedOperationException expected){immutable=true;}check(immutable,"Structured results are immutable");
        ArrayList<Duwm1728SpeechCues.Word> many=new ArrayList<>();StringBuilder expectedWords=new StringBuilder();
        for(int i=0;i<80;i++){String text=String.format(Locale.ROOT,"word%02d_abcdefghijklmnop",i);many.add(word(37+i*200,text));if(i>0)expectedWords.append(' ');expectedWords.append(text);}
        List<Duwm1728BroadcastLayout.Cue> longText=Duwm1728SpeechCues.fromWords(many,10000,30000);
        check(longText.size()>12,"Readable grouping is not limited to twelve captions");
        check(joined(longText).equals(expectedWords.toString()),"Text beyond180 characters is split rather than dropped");
        check(longText.get(0).startMs==10037,"Fractional first-word timestamp remains precise");
        for(Duwm1728BroadcastLayout.Cue cue:longText)check(cue.text.length()<=500&&cue.startMs<cue.endMs&&cue.endMs<=30000,"Every derived display interval stays valid");
        check(Duwm1728SpeechCues.legacy(longText,10000).isEmpty(),"Inexact legacy representation is omitted without changing structured cues");
        String longWord="x".repeat(300);List<Duwm1728BroadcastLayout.Cue> one=Duwm1728SpeechCues.fromWords(Collections.singletonList(word(500,longWord)),0,2000);
        check(one.get(0).text.equals(longWord),"A valid long recognized part is not truncated at180");
        List<Duwm1728BroadcastLayout.Cue> equal=Duwm1728SpeechCues.fromWords(Arrays.asList(word(100,"one"),word(100,"two"),word(200,"three")),0,2000);
        check(equal.size()==1&&equal.get(0).startMs==100&&equal.get(0).text.equals("one two three"),"Equal reported starts retain all words in stable order");
        String unicode="Kampala 🌍 東京 <5> & café";
        check(Duwm1728SpeechCues.fromWords(Collections.singletonList(word(13,unicode)),0,2000).get(0).text.equals(unicode),"Unicode and literal punctuation survive conversion");
        List<Duwm1728BroadcastLayout.Cue> exact=Duwm1728SpeechCues.fromWords(Arrays.asList(word(0,"First"),word(3000,"Second")),5000,10000);
        check(Duwm1728SpeechCues.legacy(exact,5000).equals("00:00=First;00:03=Second"),"Whole-second legacy output remains available when lossless");
        rejects(()->Duwm1728SpeechCues.fromWords(Arrays.asList(word(400,"later"),word(300,"earlier")),0,2000),"Out-of-order reported starts are rejected");
        rejects(()->Duwm1728SpeechCues.fromWords(Collections.singletonList(word(2000,"outside")),0,2000),"Word at exclusive source end is rejected");
        rejects(()->Duwm1728SpeechCues.fromWords(Collections.singletonList(word(-1,"negative")),0,2000),"Negative timestamps are rejected");
        rejects(()->Duwm1728SpeechCues.fromWords(Collections.singletonList(word(0,"x".repeat(501))),0,2000),"Overlong indivisible text is rejected rather than truncated");
        rejects(()->Duwm1728SpeechCues.fromWords(Arrays.asList(word(0,longWord),word(0,longWord)),0,2000),"Unrepresentable simultaneous text is rejected without loss");
        rejects(()->Duwm1728SpeechCues.fromWords(Collections.singletonList(word(0,"\uD800")),0,2000),"Incomplete Unicode is rejected");
        rejects(()->Duwm1728SpeechCues.fromWords(Collections.emptyList(),0,2000),"Empty timing data cannot create invented captions");
    }
    public static void main(String[] args)throws Exception{
        pcm();cues();Path folder=Path.of(args.length==0?"verification/recorded-audio-host-proof":args[0]);Files.createDirectories(folder);
        String json="{\n  \"status\": \"PASS\",\n  \"checks\": "+checks+",\n  \"native_executed\": false,\n  \"scope\": \"PCM source grid and reported-start/derived-end policy\",\n  \"rates\": [8000,16000,22050,32000,44100,48000],\n  \"recognizer_or_model_verified\": false\n}\n";
        Files.writeString(folder.resolve("RECORDED-AUDIO-HOST-RESULT.json"),json,StandardCharsets.UTF_8);
        System.out.println("PASS "+checks+" recorded-audio timing assertions; host policy only, no Android recognizer execution");
    }
}
