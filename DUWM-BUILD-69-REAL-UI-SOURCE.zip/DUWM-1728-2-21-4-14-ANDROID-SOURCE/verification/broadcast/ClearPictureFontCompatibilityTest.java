package com.sentongoharuna.worldsituationroom;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.font.TextLayout;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Real production painter and source clock formatting with explicit desktop
 * font families. This is host presentation evidence, not Android rendering,
 * native export, provider activity, physical measurements or AI inference. */
public final class ClearPictureFontCompatibilityTest {
    private static int checks;
    private static final int[][] SIZES={{720,1280},{1280,720},{720,800},{64,114}};
    private static final Pattern UTC_TIME=Pattern.compile("[0-9]{2}:[0-9]{2}:[0-9]{2} UTC");
    private static final Pattern ELAPSED=Pattern.compile("(?:REC|VIEW) [0-9]+:[0-9]{2}:[0-9]{2}");
    private static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}

    private static final class Text {
        final String value;final float x,y,size,width;final Rectangle2D clip,ink;
        Text(String value,float x,float y,float size,float width,Rectangle2D clip,Rectangle2D ink){
            this.value=value;this.x=x;this.y=y;this.size=size;this.width=width;this.clip=clip;this.ink=ink;
        }
    }
    private static final class Painter implements Duwm1728BroadcastLayout.Painter,AutoCloseable {
        final String family;final Font regular,bold;final Graphics2D canvas;
        final int width,height;final List<Text> texts=new ArrayList<>();
        final Deque<Shape> clips=new LinkedList<>();
        final Deque<Rectangle2D> rectangles=new ArrayDeque<>();
        Painter(String family,int width,int height){
            this.family=family;this.width=width;this.height=height;
            regular=new Font(family,Font.PLAIN,1);bold=new Font(family,Font.BOLD,1);
            canvas=new BufferedImage(width,height,BufferedImage.TYPE_INT_ARGB).createGraphics();
            canvas.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
            canvas.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            canvas.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        }
        private void style(float size,boolean weight){canvas.setFont((weight?bold:regular).deriveFont(size));}
        public void rect(float x,float y,float w,float h,int color,float radius){canvas.setColor(new Color(color,true));canvas.fill(new RoundRectangle2D.Float(x,y,w,h,2*radius,2*radius));}
        public void line(float x,float y,float xx,float yy,int color,float thickness){canvas.setColor(new Color(color,true));canvas.setStroke(new java.awt.BasicStroke(Math.max(.7f,thickness)));canvas.draw(new Line2D.Float(x,y,xx,yy));}
        public void text(String value,float x,float y,float size,int color,boolean weight){
            style(size,weight);canvas.setColor(new Color(color,true));canvas.drawString(value,x,y);
            Rectangle2D ink=value.isEmpty()?new Rectangle2D.Float():new TextLayout(value,canvas.getFont(),canvas.getFontRenderContext()).getBounds();
            Rectangle2D clip=rectangles.isEmpty()?new Rectangle2D.Float(0,0,width,height):(Rectangle2D)rectangles.peek().clone();
            texts.add(new Text(value,x,y,size,measure(value,size,weight),clip,
                    new Rectangle2D.Double(x+ink.getX(),y+ink.getY(),ink.getWidth(),ink.getHeight())));
        }
        public float measure(String value,float size,boolean weight){style(size,weight);return (float)canvas.getFont().getStringBounds(value,canvas.getFontRenderContext()).getWidth();}
        public Object captionMeasurementKey(){return Arrays.asList(Painter.class,family,canvas.getFontRenderContext());}
        public void clip(float x,float y,float w,float h){
            clips.push(canvas.getClip());canvas.clip(new Rectangle2D.Float(x,y,w,h));
            Rectangle2D rectangle=new Rectangle2D.Float(x,y,w,h);if(!rectangles.isEmpty())rectangle=rectangle.createIntersection(rectangles.peek());rectangles.push(rectangle);
        }
        public void unclip(){canvas.setClip(clips.pop());rectangles.pop();}
        boolean has(String value){return texts.stream().anyMatch(text->text.value.contains(value));}
        public void close(){canvas.dispose();}
    }

    private static Duwm1728BroadcastLayout.Report report(){
        Duwm1728BroadcastLayout.Report r=new Duwm1728BroadcastLayout.Report();
        r.clearPicture=true;r.composition="COMPACT";r.automaticSceneTitles=true;
        r.sceneAtMs=0;r.sceneUntilMs=3000;r.sceneSource="on-device-image-description";
        r.sceneTitle="A synthetic scene for font verification";r.sceneDescription="Fixture words, not a model response.";
        r.measuredSummary=true;r.coordinatesAllowed=true;r.clock="RECORDED 2026-11-07 12:00:00 UTC";
        r.measuredLocation="PLACE A deliberately long descriptive campus location";
        r.measuredCoordinates="LAT/LON -89.99999, -179.99999";r.measuredAccuracy="ACC ±50 m";
        r.measuredHeading="CAM HDG 359° NW MAG";r.measuredHeadingDegrees=359;
        r.measuredFps="PREVIEW 1000.0 fps";r.measuredSpeed="SPEED 3600.0 km/h";r.measuredMovement="STATIONARY";
        r.measuredAltitude="ALT 100000 m WGS84 ±50 m";
        r.measuredWeatherProvider="MODEL WX Open-Meteo";r.measuredWeatherDescription="A deliberately long synthetic conditions description";
        r.measuredWeatherNumbers="-100.0°C / WIND 150.0 m/s";r.measuredWeatherTime="23:59 UTC";
        r.measuredWeather="MODEL WX Open-Meteo / -100.0°C / WIND 150.0 m/s / 23:59 UTC";
        return r;
    }
    private static String actualClock(String prefix,long sourceMs,boolean recording,long utcMs){
        Duwm1728Measurements.Input input=new Duwm1728Measurements.Input();
        input.nowElapsedMs=100000;input.sourceMs=sourceMs;input.utcMs=utcMs;input.recording=recording;
        return prefix+" • "+Duwm1728Measurements.display(Duwm1728Measurements.sample(input),sourceMs+377,false).time;
    }
    private static float[] geometry(Duwm1728BroadcastLayout.Geometry g){return new float[]{g.headerTop,g.headerBottom,g.telemetryTop,g.tickerTop,g.captionTop,g.captionBottom,g.clearSafeLeft,g.clearSafeTop,g.clearSafeWidth,g.clearSafeHeight};}
    private static String context(String family,int[] size){return family+" "+size[0]+"x"+size[1]+": ";}
    private static void textBounds(Painter p,Duwm1728BroadcastLayout.Geometry g,String label){
        Map<Float,Float> right=new HashMap<>();
        for(Text text:p.texts){
            check(text.x>=text.clip.getMinX()-.1&&text.x+text.width<=text.clip.getMaxX()+.1,label+"Text fits actual font/clip: "+text.value);
            if(g.unit>=.5f)check(text.ink.getMinY()>=text.clip.getMinY()-.1&&text.ink.getMaxY()<=text.clip.getMaxY()+.1,label+"Glyph ink fits vertical band: "+text.value);
            if(text.y>=g.telemetryTop&&text.y<g.tickerTop){
                check(Math.abs(text.size-18*g.unit)<.001,label+"Measured type stays at fixed18u");
                check(!right.containsKey(text.y)||text.x>=right.get(text.y)-.1,label+"Independent cells do not overlap: "+text.value);
                right.put(text.y,text.x+text.width);
            }
        }
        check(p.clips.isEmpty()&&p.rectangles.isEmpty(),label+"Clips are restored");
    }
    private static void clocks(String family,int[] size){
        String label=context(family,size);
        String[] values={"RECORDED 2026-11-07 12:00:00 UTC",
                actualClock("RECORDED",35000,true,1794052800000L),
                actualClock("RECORDING",45296000,true,1794052800000L),
                actualClock("RECORDED",445556000,true,1794052800000L),
                actualClock("PREVIEW",7000,false,1794052800000L),
                actualClock("PREVIEW",7000,false,-1),"UTC UNAVAILABLE","PREVIEW"};
        float[] fixed=null;
        for(String clock:values){
            Duwm1728BroadcastLayout.Report r=report();r.clock=clock;
            try(Painter p=new Painter(family,size[0],size[1])){
                Duwm1728BroadcastLayout.Geometry g=Duwm1728BroadcastLayout.draw(p,size[0],size[1],r,500);
                Duwm1728ClearPictureLayout.Frame card=Duwm1728ClearPictureLayout.geometry(size[0],size[1],true);
                List<String> rows=new ArrayList<>();
                for(Text text:p.texts)if(text.x>=card.clockLeft&&text.y>=card.headerTop&&text.y<card.headerTop+card.clockHeight){
                    rows.add(text.value);check(Math.abs(text.size-16*g.unit)<.001,label+"Clock type stays fixed16u");
                }
                check(!rows.isEmpty()&&rows.size()<=2,label+"Clock uses at most two reserved rows");
                check(String.join(" ",rows).equals(clock),label+"Complete production clock remains visible: expected="+clock+" rows="+rows);
                for(Pattern group:new Pattern[]{UTC_TIME,ELAPSED}){
                    Matcher matcher=group.matcher(clock);while(matcher.find()){
                        String value=matcher.group();check(rows.stream().anyMatch(row->row.contains(value)),label+"Clock value stays with its qualifier: "+value+" rows="+rows);
                    }
                }
                if(fixed==null)fixed=geometry(g);else check(Arrays.equals(fixed,geometry(g)),label+"Clock changes cannot move frame geometry");
                textBounds(p,g,label);
            }
        }
    }
    private static void values(String family,int[] size){
        String label=context(family,size);Duwm1728BroadcastLayout.Report r=report();
        float[] fixed=null;Map<String,Float> fixedCells=null;
        for(String state:new String[]{"EXTREME","UNAVAILABLE","STALE","OFF","UNRELIABLE","ALTITUDE_ACCURACY_MISSING"}){
            if(state.equals("ALTITUDE_ACCURACY_MISSING")){r=report();r.measuredAltitude="ALT 100000 m WGS84 / ACC UNAVAILABLE";}
            else if(!state.equals("EXTREME")){
                r=report();r.measuredLocation="PLACE "+state;r.measuredCoordinates="LAT/LON "+state;r.measuredAccuracy="ACC "+state;
                r.measuredHeading="CAM HDG "+state;r.measuredHeadingDegrees=Double.NaN;r.measuredFps="PREVIEW FPS "+state;
                r.measuredSpeed="SPEED "+state;r.measuredMovement="MOVEMENT "+(state.equals("UNRELIABLE")?"UNCERTAIN":state);r.measuredAltitude="ALT "+state;
            }
            try(Painter p=new Painter(family,size[0],size[1])){
                Duwm1728BroadcastLayout.Geometry g=Duwm1728BroadcastLayout.draw(p,size[0],size[1],r,500);
                for(String expected:new String[]{r.measuredCoordinates,r.measuredAccuracy,r.measuredHeading,r.measuredFps,r.measuredSpeed,
                        r.measuredMovement.replaceFirst("^MOVEMENT ",""),r.measuredAltitude,"Open-Meteo","-100.0°C","150.0 m/s","23:59 UTC"})
                    check(p.has(expected),label+state+" retains a complete actual field: "+expected);
                Map<String,Float> cells=new HashMap<>();
                for(Text text:p.texts)if(text.y>=g.telemetryTop&&text.y<g.tickerTop)
                    for(String name:new String[]{"LAT/LON","CAM HDG","PREVIEW","PLACE","SPEED","ALT"})if(text.value.startsWith(name))cells.put(name,text.x);
                check(cells.size()==6,label+"All six position/measurement cells remain visible");
                if(fixed==null){fixed=geometry(g);fixedCells=cells;}else{
                    check(Arrays.equals(fixed,geometry(g)),label+"Data/status changes cannot move frame geometry");
                    check(fixedCells.equals(cells),label+"Metric-dependent cells never move with live values or state");
                }
                textBounds(p,g,label);
            }
        }
    }
    public static void main(String[] args)throws Exception{
        Path output=Path.of(args.length==0?"clear-font-host-proof":args[0]);Files.createDirectories(output);
        Set<String> available=new HashSet<>(Arrays.asList(GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames(Locale.ROOT)));
        check(available.contains("DejaVu Sans"),"DejaVu Sans is required for the actual CI failure regression; never silently substitute a narrower font");
        List<String> families=new ArrayList<>(Arrays.asList("SansSerif","DejaVu Sans"));
        List<String> skipped=new ArrayList<>();
        for(String optional:new String[]{"Liberation Sans","Noto Sans","DejaVu Math TeX Gyre"}){
            if(available.contains(optional))families.add(optional);else skipped.add(optional);
        }
        for(String family:families){
            check(new Font(family,Font.PLAIN,1).getFamily(Locale.ROOT).equals(family),"Requested font family actually resolves: "+family);
            for(int[] size:SIZES){clocks(family,size);values(family,size);}
        }
        String fonts="\""+String.join("\",\"",families)+"\"";
        String skippedFonts=skipped.isEmpty()?"":"\""+String.join("\",\"",skipped)+"\"";
        String report="{\n  \"schema\":1,\n  \"status\":\"PASS\",\n  \"checks\":"+checks+",\n  \"font_families\":["+fonts+"],\n  \"skipped_optional_font_families\":["+skippedFonts+"],\n  \"frame_sizes\":4,\n  \"actual_production_clock_formatter\":true,\n  \"fixed_geometry_and_font_sizes\":true,\n  \"full_numeric_and_status_fields\":true,\n  \"android_rendering_verified\":false,\n  \"native_encoder_verified\":false,\n  \"physical_sensor_verified\":false,\n  \"provider_network_verified\":false,\n  \"model_inference_verified\":false\n}\n";
        Files.writeString(output.resolve("CLEAR-PICTURE-FONT-HOST.json"),report,StandardCharsets.UTF_8);
        System.out.println("PASS "+checks+" explicit-font clear-picture/clock/complete-field checks in "+families+"; missing optional families: "+skipped+". Host raster/formatting only; no Android/device/model/provider execution.");
    }
}
