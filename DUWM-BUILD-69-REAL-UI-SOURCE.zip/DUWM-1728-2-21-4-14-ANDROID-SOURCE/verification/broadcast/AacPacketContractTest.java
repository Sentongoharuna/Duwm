package com.sentongoharuna.worldsituationroom;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Host replay of packets from actual failed-run MP4s, plus corruption controls.
 * This does not execute Android or establish a repaired native run. */
public final class AacPacketContractTest {
    private static int checks,negativeCases;
    private static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    private interface Attempt{void run()throws Exception;}
    private static void rejects(String name,Attempt attempt)throws Exception {
        boolean rejected=false;try{attempt.run();}catch(AssertionError|IllegalArgumentException|IOException expected){rejected=true;}
        check(rejected,"Contract must reject "+name);negativeCases++;
    }
    private static final class Packets {
        final List<DuwmAacPacketContract.Packet> audio=new ArrayList<>();
        final List<Long> video=new ArrayList<>();
    }
    private static Packets read(Path file,long from,long to)throws Exception {
        Packets result=new Packets();
        for(String line:Files.readAllLines(file,StandardCharsets.UTF_8)) {
            if(line.startsWith("#")||line.isBlank())continue;
            String[] part=line.split("\t");long time=Long.parseLong(part[1]);if(time<from||time>=to)continue;
            if("A".equals(part[0])){byte[] payload=new byte[part[2].length()/2];for(int i=0;i<payload.length;i++)payload[i]=(byte)Integer.parseInt(part[2].substring(i*2,i*2+2),16);result.audio.add(new DuwmAacPacketContract.Packet(time,payload));}
            else if("V".equals(part[0]))result.video.add(time);else throw new AssertionError("Unknown recorded packet type");
        }
        Collections.sort(result.video);return result;
    }
    private static List<DuwmAacPacketContract.Packet> shifted(List<DuwmAacPacketContract.Packet> packets,long offset) {
        List<DuwmAacPacketContract.Packet> result=new ArrayList<>();for(DuwmAacPacketContract.Packet packet:packets)result.add(new DuwmAacPacketContract.Packet(packet.timeUs+offset,packet.bytes));return result;
    }
    private static DuwmAacPacketContract.Report verify(Packets source,Packets output,DuwmAacPacketContract.Clocks clocks) {
        return DuwmAacPacketContract.verify(source.audio,output.audio,source.video,output.video,48000,clocks,AacPacketContractTest::check);
    }
    private static Packets copy(Packets source) {
        Packets result=new Packets();result.audio.addAll(shifted(source.audio,0));result.video.addAll(source.video);return result;
    }
    public static void main(String[] args)throws Exception {
        if(args.length!=2)throw new IllegalArgumentException("Expected archived packet fixture directory and output directory");
        Path fixture=Path.of(args[0]),proof=Path.of(args[1]);Files.createDirectories(proof);
        Packets source=read(fixture.resolve("source.packets.tsv"),250000,1900000);
        check(source.audio.size()==78&&source.video.size()==49,"Unmodified source fixture selects 78 AAC packets and 49 video frames");
        DuwmAacPacketContract.Clocks sourceClocks=DuwmAacPacketContract.Clocks.read(fixture.resolve("source.moov.bin").toFile());
        check(sourceClocks.movie==1000&&sourceClocks.audio==48000&&sourceClocks.video==15360,"Read original source clocks from retained raw moov bytes");
        StringBuilder cases=new StringBuilder(),legacyFailures=new StringBuilder();
        for(String stage:new String[]{"scene_timeline","measured_telemetry","clear_picture"}) {
            Packets output=read(fixture.resolve(stage+".packets.tsv"),0,Long.MAX_VALUE);
            DuwmAacPacketContract.Clocks clocks=DuwmAacPacketContract.Clocks.read(fixture.resolve(stage+".moov.bin").toFile());
            check(clocks.movie==10000&&clocks.audio==48000&&clocks.video==90000,"Read "+stage+" actual movie and media clocks");
            check(source.audio.get(0).timeUs-250000==6000&&output.audio.get(0).timeUs==0,"Recorded packet zero reproduces the original invalid exact-trim assertion");
            boolean oldFailed=false;try {
                for(int i=0;i<source.audio.size();i++)check(source.audio.get(i).timeUs-250000==output.audio.get(i).timeUs&&Arrays.equals(source.audio.get(i).bytes,output.audio.get(i).bytes),"Original AAC bytes and normalized time retained at packet "+i);
            }catch(AssertionError expected){oldFailed=true;legacyFailures.append(stage).append(": ").append(expected).append("; source minus trim = 6000 us, output = 0 us, bytes identical = true\n");}
            check(oldFailed,"Original exact-trim-origin assertion fails on "+stage+" archived actual output");
            DuwmAacPacketContract.Report report=verify(source,output,clocks);
            check(report.originUs==256000&&report.audioStartMovieTicks==0&&report.videoStartMovieTicks==107,"A common 256 ms source origin preserves the measured A/V offset");
            check(report.byteCount==20054&&report.packetCount==78&&report.sampleCount==79872&&report.videoFrames==49,"Every selected byte, AAC sample and video frame is accounted for");
            if(cases.length()>0)cases.append(",");
            cases.append("\n    {\"stage\":\"").append(stage).append("\",\"packets\":78,\"payload_bytes\":20054,\"aac_samples\":79872,\"video_frames\":49,\"common_source_origin_us\":256000,\"audio_start_movie_ticks\":0,\"video_start_movie_ticks\":107,\"old_assertion_reproduced\":true}");
            Packets microseconds=copy(output);for(int i=1;i<microseconds.audio.size();i++){DuwmAacPacketContract.Packet p=microseconds.audio.get(i);microseconds.audio.set(i,new DuwmAacPacketContract.Packet(p.timeUs+1,p.bytes));}
            verify(source,microseconds,clocks); // Integer-microsecond rounding still resolves to the same exact AAC sample ticks.
            Packets missing=copy(output);missing.audio.remove(5);rejects(stage+" missing AAC packet",()->verify(source,missing,clocks));
            Packets duplicate=copy(output);duplicate.audio.set(5,duplicate.audio.get(4));rejects(stage+" duplicated AAC packet",()->verify(source,duplicate,clocks));
            Packets reordered=copy(output);Collections.swap(reordered.audio,4,5);rejects(stage+" reordered AAC packets",()->verify(source,reordered,clocks));
            Packets corrupt=copy(output);corrupt.audio.get(8).bytes[0]^=1;rejects(stage+" one changed AAC payload byte",()->verify(source,corrupt,clocks));
            Packets shifted=copy(output);shifted.audio.clear();shifted.audio.addAll(shifted(output.audio,21));rejects(stage+" one-sample audio track shift",()->verify(source,shifted,clocks));
            Packets drift=copy(output);int last=drift.audio.size()-1;DuwmAacPacketContract.Packet end=drift.audio.get(last);drift.audio.set(last,new DuwmAacPacketContract.Packet(end.timeUs+21,end.bytes));rejects(stage+" one-sample audio drift",()->verify(source,drift,clocks));
            Packets trimOrigin=copy(output);trimOrigin.audio.clear();trimOrigin.audio.addAll(shifted(output.audio,6000));rejects(stage+" wrong requested-trim audio origin",()->verify(source,trimOrigin,clocks));
            Packets independent=copy(output);for(int i=0;i<independent.video.size();i++)independent.video.set(i,independent.video.get(i)-10700);rejects(stage+" independently zeroed video",()->verify(source,independent,clocks));
            Packets videoDrift=copy(output);videoDrift.video.set(20,videoDrift.video.get(20)+12);rejects(stage+" one-video-tick drift",()->verify(source,videoDrift,clocks));
            Packets droppedVideo=copy(output);droppedVideo.video.remove(20);rejects(stage+" dropped video frame",()->verify(source,droppedVideo,clocks));
            rejects(stage+" incorrect movie clock",()->verify(source,output,new DuwmAacPacketContract.Clocks(1000,48000,90000)));
        }
        rejects("zero clock",()->new DuwmAacPacketContract.Clocks(0,48000,90000));
        rejects("unrepresentable microsecond clock",()->new DuwmAacPacketContract.Clocks(10000,1000001,90000));
        File truncated=proof.resolve("truncated-clock.bin").toFile();Files.write(truncated.toPath(),new byte[]{0,0,0,16,'m','o','o','v'});
        try{rejects("truncated MP4 clock box",()->DuwmAacPacketContract.Clocks.read(truncated));}finally{Files.delete(truncated.toPath());}
        String result="{\n  \"schema\":1,\n  \"status\":\"PASS\",\n  \"checks\":"+checks+",\n  \"negative_cases\":"+negativeCases+",\n  \"scope\":\"Host replay of packet bytes and timestamps extracted from original native run 42417837324; no repaired Android execution\",\n  \"repaired_native_execution\":false,\n  \"physical_camera_verified\":false,\n  \"cases\":["+cases+"\n  ]\n}\n";
        Files.writeString(proof.resolve("AAC-PACKET-CONTRACT-HOST.json"),result,StandardCharsets.UTF_8);
        Files.writeString(proof.resolve("LEGACY-AAC-FAILURES.txt"),legacyFailures.toString(),StandardCharsets.UTF_8);
        System.out.println("PASS "+checks+" AAC packet/origin/clock assertions, "+negativeCases+" deliberate corruption cases rejected; archived native packet replay, not repaired Android execution");
    }
}
