package com.sentongoharuna.worldsituationroom;
public final class ProfessionalTransitionPolicyTest {
  static void ok(boolean v,String m){if(!v)throw new AssertionError(m);}
  public static void main(String[] a){
    Duwm1728ProfessionalTransition.State h0=Duwm1728ProfessionalTransition.state(1000,1000,Duwm1728ProfessionalTransition.HEADLINE_MS);
    Duwm1728ProfessionalTransition.State h1=Duwm1728ProfessionalTransition.state(1130,1000,Duwm1728ProfessionalTransition.HEADLINE_MS);
    Duwm1728ProfessionalTransition.State h2=Duwm1728ProfessionalTransition.state(1260,1000,Duwm1728ProfessionalTransition.HEADLINE_MS);
    ok(h0.alpha< h1.alpha && h1.alpha<=h2.alpha,"headline fades in");
    ok(h0.offset>h1.offset && h1.offset>=h2.offset,"headline settles without bounce");
    ok(Math.abs(h2.alpha-1f)<.001f && Math.abs(h2.offset)<.001f,"headline ends stable");
    ok(Duwm1728ProfessionalTransition.active(1100,1000,180),"status active inside window");
    ok(!Duwm1728ProfessionalTransition.active(1180,1000,180),"status stops at deadline");
    int c=Duwm1728ProfessionalTransition.alpha(0xFFF5F7FA,.5f);
    ok(((c>>>24)&255)>=127&&((c>>>24)&255)<=128,"alpha applied");
    System.out.println("professional transition policy: PASS");
  }
}
