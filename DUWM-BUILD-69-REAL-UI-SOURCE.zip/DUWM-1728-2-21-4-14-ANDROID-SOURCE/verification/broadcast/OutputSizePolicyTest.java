package com.sentongoharuna.worldsituationroom;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import com.sentongoharuna.worldsituationroom.Duwm1728OutputSizePolicy.Encoder;
import com.sentongoharuna.worldsituationroom.Duwm1728OutputSizePolicy.Selection;

/** Real pure output policy with explicitly simulated codec advertisements.
 * This does not instantiate Android codecs, encode video, measure throughput,
 * verify audio/PTS, or establish any device's supported resolutions.
 */
public final class OutputSizePolicyTest {
    private static int checks;
    private static final List<String> cases=new ArrayList<>();
    private static void check(boolean condition,String message){checks++;if(!condition)throw new AssertionError(message);}
    private static void rejects(Runnable action,String name){
        boolean rejected=false;try{action.run();}catch(IllegalArgumentException expected){rejected=true;}
        check(rejected,"Reject "+name);
    }
    private static final class Query {
        final int w,h,fps,bitrate;
        Query(int w,int h,int fps,int bitrate){this.w=w;this.h=h;this.fps=fps;this.bitrate=bitrate;}
        @Override public String toString(){return w+"x"+h+"@"+fps+"/"+bitrate;}
    }
    private static final class Fixture {
        final List<Query> queries=new ArrayList<>();final Encoder encoder;
        Fixture(String name,int alignW,int alignH,int maxW,int maxH,int minB,int maxB,Duwm1728OutputSizePolicy.FormatSupport predicate){
            encoder=new Encoder(name,alignW,alignH,2,maxW,2,maxH,minB,maxB,(w,h,f,b)->{
                queries.add(new Query(w,h,f,b));return predicate.accepts(w,h,f,b);
            });
        }
    }
    private static Fixture all(String name,int maxW,int maxH){return new Fixture(name,2,2,maxW,maxH,1,80000000,(w,h,f,b)->true);}
    private static Selection choose(int w,int h,int fps,Fixture... fixtures){
        List<Encoder> encoders=new ArrayList<>();for(Fixture fixture:fixtures)encoders.add(fixture.encoder);
        return Duwm1728OutputSizePolicy.select(w,h,fps,encoders);
    }
    private static void selected(Selection s,int w,int h,int fps,String name){
        check(s!=null,"Expected selection: "+name);
        check(s.width==w&&s.height==h&&s.fps==fps,"Selected geometry/rate: "+name);
        check(name.equals(s.encoder),"Selected real fixture identity: "+name);
    }
    private static void record(String name,Selection selected,Fixture fixture){
        cases.add(name+": "+selected.width+"x"+selected.height+" @ "+selected.fps+" fps; queried "+fixture.queries);
    }
    public static void main(String[] args)throws Exception{
        Fixture nativeSize=all("advertised-native",4096,4096);
        Selection s=choose(3840,2160,30,nativeSize);selected(s,3840,2160,30,"advertised-native");
        check(s.formatsChecked==1,"Supported source size is not unnecessarily reduced");
        check(s.bitrate==49766400,"Native bitrate target retained when supported");record("native size",s,nativeSize);

        Fixture onlyHd=new Fixture("advertised-hd60",2,2,4096,4096,1,80000000,(w,h,f,b)->(long)w*h<=1920L*1080&&f==60);
        s=choose(3840,2160,60,onlyHd);selected(s,1920,1080,60,"advertised-hd60");
        check(onlyHd.queries.get(0).w==3840,"Try full output before reducing");
        check(s.formatsChecked==3,"Bounded full, 2560, then 1920 search with duplicate 3840 removed");
        for(Query q:onlyHd.queries)check(q.fps==60,"Resolution fallback never changes frame rate");
        record("simulated 4K60 rejection then 1080p60",s,onlyHd);

        Fixture portrait=new Fixture("advertised-portrait60",2,2,4096,4096,1,80000000,(w,h,f,b)->(long)w*h<=1080L*1920);
        s=choose(2160,3840,60,portrait);selected(s,1080,1920,60,"advertised-portrait60");record("upright portrait",s,portrait);
        Fixture bounds=all("advertised-bounded",1920,1080);
        s=choose(3840,2160,30,bounds);selected(s,1920,1080,30,"advertised-bounded");
        check(s.formatsChecked==1,"Do not query outside advertised width/height maxima");
        Fixture aligned=new Fixture("advertised-align16",16,16,4096,4096,1,80000000,(w,h,f,b)->true);
        s=choose(1080,1920,30,aligned);selected(s,1072,1920,30,"advertised-align16");record("alignment with FIT bars",s,aligned);

        Fixture preferred=all("platform-first",1920,1080),larger=all("platform-second",4096,4096);
        s=choose(3840,2160,30,preferred,larger);selected(s,3840,2160,30,"platform-second");
        check(preferred.queries.isEmpty(),"Larger valid canvas precedes a smaller preferred-codec canvas");
        Fixture tieA=all("tie-first",4096,4096),tieB=all("tie-second",4096,4096);
        s=choose(1920,1080,30,tieA,tieB);selected(s,1920,1080,30,"tie-first");
        check(tieB.queries.isEmpty(),"Equal geometry preserves platform codec preference");
        Fixture refused= new Fixture("reject-final-format",2,2,4096,4096,1,80000000,(w,h,f,b)->false);
        Fixture accepted=all("accept-final-format",1920,1080);
        s=choose(3840,2160,30,refused,accepted);selected(s,1920,1080,30,"accept-final-format");
        check(refused.queries.size()==3,"Final-format refusal is respected, including equal-size preference");

        Fixture lowBitrate=new Fixture("low-bitrate",2,2,1920,1080,100000,2000000,(w,h,f,b)->b<=2000000);
        s=choose(1920,1080,30,lowBitrate);check(s.bitrate==2000000,"Clamp to actual advertised maximum bitrate");
        Fixture highMinimum=new Fixture("high-minimum",2,2,1920,1080,8000000,20000000,(w,h,f,b)->b>=8000000);
        s=choose(640,360,30,highMinimum);check(s.bitrate==8000000,"Respect actual advertised minimum bitrate");
        for(int fps:new int[]{1,24,25,30,50,60,120}){
            Fixture rate=new Fixture("exact-rate",2,2,4096,4096,1,80000000,(w,h,f,b)->w<=1280);
            s=choose(3840,2160,fps,rate);selected(s,1280,720,fps,"exact-rate");
            for(Query q:rate.queries)check(q.fps==fps,"Every fallback preserves requested FPS "+fps);
        }
        Fixture noRate=new Fixture("requires-different-rate",2,2,4096,4096,1,80000000,(w,h,f,b)->f<=30);
        check(choose(3840,2160,60,noRate)==null,"Do not silently reduce FPS to get an advertised format");
        check(Duwm1728OutputSizePolicy.select(1920,1080,30,Collections.emptyList())==null,"No encoder inventory cannot certify support");
        Fixture broken=new Fixture("broken-advertisement",2,2,4096,4096,1,80000000,(w,h,f,b)->{throw new IllegalStateException("fixture");});
        s=choose(1920,1080,30,broken,all("working-advertisement",1920,1080));selected(s,1920,1080,30,"working-advertisement");
        check(choose(1920,1080,30,broken)==null,"A throwing advertisement is never treated as support");

        rejects(()->Duwm1728OutputSizePolicy.select(63,1920,30,Collections.emptyList()),"canvas below painter minimum");
        rejects(()->Duwm1728OutputSizePolicy.select(1920,1080,121,Collections.emptyList()),"unsupported high-speed conversion");
        rejects(()->Duwm1728OutputSizePolicy.select(1920,1080,0,Collections.emptyList()),"nonpositive FPS");
        rejects(()->Duwm1728OutputSizePolicy.select(1920,1080,30,null),"missing inventory");
        rejects(()->new Encoder("invalid",3,2,2,1920,2,1080,1,80000000,(w,h,f,b)->true),"invalid alignment");
        rejects(()->new Encoder("invalid",2,2,2000,1920,2,1080,1,80000000,(w,h,f,b)->true),"reversed width bounds");
        rejects(()->new Encoder("invalid",2,2,2,1920,2,1080,2000000,1000000,(w,h,f,b)->true),"reversed bitrate bounds");
        check(Duwm1728OutputSizePolicy.requestedBitrate(Integer.MAX_VALUE,Integer.MAX_VALUE,120)==80000000,"Huge dimensions cannot overflow bitrate target");
        check(Duwm1728OutputSizePolicy.requestedBitrate(64,64,1)==5000000,"Existing minimum bitrate target");

        // Property fixtures reject all candidates so the complete bounded query
        // list can be checked, including odd source sizes and codec alignment.
        Random random=new Random(172821L);
        for(int test=0;test<500;test++){
            int w=64+random.nextInt(8129),h=64+random.nextInt(8129),fps=1+random.nextInt(120);
            int aw=1<<random.nextInt(7),ah=1<<random.nextInt(7),mw=64+random.nextInt(8129),mh=64+random.nextInt(8129);
            int lower=1+random.nextInt(10000000),upper=lower+random.nextInt(70000000);
            Fixture f=new Fixture("property-"+test,aw,ah,mw,mh,lower,upper,(qw,qh,qf,qb)->false);
            check(choose(w,h,fps,f)==null,"Reject-only predicate cannot produce a selection");
            check(f.queries.size()<=Duwm1728OutputSizePolicy.MAX_CANDIDATES_PER_CODEC,"Bounded queries per codec");
            Set<String> unique=new HashSet<>();long previous=Long.MAX_VALUE;
            for(Query q:f.queries){
                check(q.w<=w&&q.h<=h&&q.w<=mw&&q.h<=mh,"No upscaling or out-of-bounds canvas");
                check(q.w>=64&&q.h>=64,"Painter can handle each proposed canvas");
                check(q.w%Math.max(2,aw)==0&&q.h%Math.max(2,ah)==0,"Both encoder and even-pixel alignment");
                check(q.fps==fps&&q.bitrate>=lower&&q.bitrate<=upper,"Fixed cadence and advertised bitrate range");
                check(unique.add(q.w+"x"+q.h),"No duplicate size queries per codec");
                long area=(long)q.w*q.h;check(area<=previous,"Descending canvas-area preference");previous=area;
            }
        }
        String proof="OUTPUT_SIZE_POLICY_PASS checks="+checks+"\n"+
            "Evidence kind: HOST_SIMULATED_CAPABILITY_POLICY. No Android codec or device support claim.\n"+
            "The actual pure selector ran against explicit fixture capabilities; encoding/audio/timestamps require native checks.\n"+
            String.join("\n",cases)+"\n";
        if(args.length>0){Path folder=Path.of(args[0]);Files.createDirectories(folder);Files.writeString(folder.resolve("OUTPUT-SIZE-POLICY.txt"),proof,StandardCharsets.UTF_8);}
        System.out.print(proof);
    }
}
