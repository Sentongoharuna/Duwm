package com.sentongoharuna.worldsituationroom;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import javax.imageio.ImageIO;

/** Executes the shared production Painter. These outputs are HOST RENDERED, not Android proof. */
public final class BroadcastCompositionTest {
    private static int checks;
    private static final String[] MODES={"FULL","COMPACT","CAPTIONS"};
    private static final int[][] SIZES={{720,800},{720,1280},{1280,720}};
    private static final String[] RATIOS={"9-10","9-16","16-9"};
    private static final String TITLE="TITLE TOKEN • Recorded weather observation";
    private static final String BYLINE="LOCATION TOKEN • SYNTHETIC SOURCE";
    private static final String TICKER="TICKER TOKEN • Shared source cue remains timed to the original recording";
    private static final String FIRST="CAPTION ONE • Active from 500 to 2700 ms";
    private static final String SECOND="CAPTION TWO • Active from 3200 to 5600 ms";
    private static final String STATUS="TEST FIXTURE • UNVERIFIED";
    private static void check(boolean ok,String label){checks++;if(!ok)throw new AssertionError(label);}
    private static void near(float a,float b,String label){check(Math.abs(a-b)<.001f,label+": "+a+" vs "+b);}

    private static Duwm1728BroadcastLayout.Report report(String composition){
        Duwm1728BroadcastLayout.Report r=new Duwm1728BroadcastLayout.Report();r.composition=composition;
        r.title=TITLE;r.location=BYLINE;r.description="Synthetic comparison fixture, not a weather report";
        r.category="WEATHER";r.clock="RECORDED • TEST";r.provenance=STATUS;
        r.heading="HEADING TOKEN";r.altitude="HEIGHT TOKEN";r.weather="WEATHER TOKEN";
        r.gps="PRIVATE TOKEN";r.coordinatesAllowed=false;
        r.tickers.add(new Duwm1728BroadcastLayout.Cue(0,3000,TICKER));
        r.tickers.add(new Duwm1728BroadcastLayout.Cue(3000,6000,"SECOND UPDATE • Same source-time timeline"));
        r.captions.add(new Duwm1728BroadcastLayout.Cue(500,2700,FIRST));
        r.captions.add(new Duwm1728BroadcastLayout.Cue(3200,5600,SECOND));return r;
    }
    private static Duwm1728BroadcastLayout14.Report oldReport(Duwm1728BroadcastLayout.Report r){
        Duwm1728BroadcastLayout14.Report old=new Duwm1728BroadcastLayout14.Report();
        old.title=r.title;old.location=r.location;old.description=r.description;old.category=r.category;old.reporter=r.reporter;
        old.clock=r.clock;old.provenance=r.provenance;old.heading=r.heading;old.altitude=r.altitude;old.weather=r.weather;
        old.gps=r.gps;old.coordinatesAllowed=r.coordinatesAllowed;old.breakingApproved=r.breakingApproved;old.tickerPixelsPerSecond=r.tickerPixelsPerSecond;
        for(Duwm1728BroadcastLayout.Cue c:r.tickers)old.tickers.add(new Duwm1728BroadcastLayout14.Cue(c.startMs,c.endMs,c.text));
        for(Duwm1728BroadcastLayout.Cue c:r.captions)old.captions.add(new Duwm1728BroadcastLayout14.Cue(c.startMs,c.endMs,c.text));return old;
    }
    private static final class Rect {
        final float x,y,w,h;final int color;
        Rect(float x,float y,float w,float h,int color){this.x=x;this.y=y;this.w=w;this.h=h;this.color=color;}
    }
    private static final class Painter implements Duwm1728BroadcastLayout.Painter,Duwm1728BroadcastLayout14.Painter {
        final BroadcastRenderTest.Painter delegate;final ArrayList<Rect> rects=new ArrayList<>();
        Painter(BufferedImage b){delegate=new BroadcastRenderTest.Painter(b);}
        public void rect(float x,float y,float w,float h,int c,float radius){rects.add(new Rect(x,y,w,h,c));delegate.rect(x,y,w,h,c,radius);}
        public void line(float x,float y,float x2,float y2,int c,float width){delegate.line(x,y,x2,y2,c,width);}
        public void text(String text,float x,float y,float size,int c,boolean bold){delegate.text(text,x,y,size,c,bold);}
        public float measure(String text,float size,boolean bold){return delegate.measure(text,size,bold);}
        public void clip(float x,float y,float w,float h){delegate.clip(x,y,w,h);}
        public void unclip(){delegate.unclip();}
        boolean has(String text){return delegate.drawn.stream().anyMatch(t->t.contains(text));}
        Rect caption(){for(Rect r:rects)if(r.color==0xE4041424)return r;return null;}
    }
    private static final class Frame {
        final BufferedImage image;final Painter painter;final Duwm1728BroadcastLayout.Geometry geometry;
        Frame(int w,int h,Duwm1728BroadcastLayout.Report r,long ms){image=background(w,h);painter=new Painter(image);geometry=Duwm1728BroadcastLayout.draw(painter,w,h,r,ms);painter.delegate.g.dispose();}
    }
    private static BufferedImage background(int w,int h){
        BufferedImage b=new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);Graphics2D g=b.createGraphics();
        g.setColor(new Color(0x26353F));g.fillRect(0,0,w,h);g.setColor(new Color(0x344C59));g.fillRect(w/3,0,w/3,h);
        g.setColor(new Color(0x2B414D));g.fillRect(2*w/3,0,w/3,h);g.setColor(new Color(0x56717C));
        for(int x=0;x<w;x+=Math.max(1,w/12))g.drawLine(x,0,x,h);for(int y=0;y<h;y+=Math.max(1,h/16))g.drawLine(0,y,w,y);
        int d=Math.min(w,h)/5;g.setColor(new Color(0xA9BAC1));g.fillOval((w-d)/2,(int)(h*.35),d,d);
        g.setFont(new Font("SansSerif",Font.BOLD,Math.max(15,w/34)));g.setColor(new Color(0xDCE4EA));
        String label="SYNTHETIC SOURCE";g.drawString(label,(w-g.getFontMetrics().stringWidth(label))/2,(int)(h*.28));g.dispose();return b;
    }
    private static BufferedImage oldFrame(int w,int h,Duwm1728BroadcastLayout.Report r,long ms){
        BufferedImage b=background(w,h);Painter p=new Painter(b);Duwm1728BroadcastLayout14.draw(p,w,h,oldReport(r),ms);p.delegate.g.dispose();return b;
    }
    private static void baselineGeometry(int w,int h){
        for(boolean sensors:new boolean[]{false,true}){
            Duwm1728BroadcastLayout.Report r=report("FULL");if(!sensors){r.heading="";r.altitude="";r.weather="";}
            Frame actual=new Frame(w,h,r,1000);BufferedImage b=background(w,h);Painter oldPainter=new Painter(b);
            Duwm1728BroadcastLayout14.Geometry old=Duwm1728BroadcastLayout14.draw(oldPainter,w,h,oldReport(r),1000);oldPainter.delegate.g.dispose();
            Duwm1728BroadcastLayout.Geometry g=actual.geometry;
            near(g.unit,old.unit,"FULL unit preserved");near(g.x,old.x,"FULL safe inset preserved");near(g.width,old.width,"FULL width preserved");
            near(g.headerTop,old.headerTop,"FULL header preserved");near(g.tagTop,old.tagTop,"FULL category position preserved");
            near(g.headlineTop,old.headlineTop,"FULL headline position preserved");near(g.telemetryTop,old.telemetryTop,"FULL sensor position preserved");
            near(g.tickerTop,old.tickerTop,"FULL ticker position preserved");near(g.bottom,old.bottom,"FULL safe bottom preserved");
            Rect cap=oldPainter.caption();check(cap!=null,"Baseline contains supplied caption");
            near(g.captionLeft,cap.x,"FULL caption horizontal placement preserved");near(g.captionTop,cap.y,"FULL caption vertical placement preserved");
            near(g.captionWidth,cap.w,"FULL caption width preserved");near(g.captionHeight,cap.h,"FULL caption height preserved");
        }
    }
    private static void semantics(int w,int h){
        Frame full=new Frame(w,h,report("FULL"),1000),compact=new Frame(w,h,report("COMPACT"),1000),captions=new Frame(w,h,report("CAPTIONS"),1000);
        check(full.geometry.tagTop<compact.geometry.tagTop&&compact.geometry.tagTop<captions.geometry.tagTop,"Layouts expose progressively more of the source");
        check(compact.geometry.headlineHeight<full.geometry.headlineHeight&&compact.geometry.tickerHeight<full.geometry.tickerHeight,"COMPACT reduces actual headline and ticker area");
        check((compact.geometry.bottom-compact.geometry.tagTop)<.70f*(full.geometry.bottom-full.geometry.tagTop),"COMPACT reclaims at least thirty percent of the lower strip");
        for(Frame f:new Frame[]{full,compact,captions}){
            Duwm1728BroadcastLayout.Geometry g=f.geometry;boolean hidden="CAPTIONS".equals(g.composition);
            check(g.headlineVisible==!hidden&&g.tickerVisible==!hidden&&g.telemetryVisible==!hidden,"Geometry exposes actual visible rows for "+g.composition);
            check(f.painter.has("DUWM")&&f.painter.has("RECORDED")&&f.painter.has("WEATHER")&&f.painter.has(STATUS),"Identity, recorded status, category and provenance survive "+g.composition);
            check(!f.painter.has("PRIVATE TOKEN")&&!f.painter.has("GPS"),"Private coordinates stay withheld in "+g.composition);
            check(f.painter.has("TITLE TOKEN")==!hidden&&f.painter.has("LOCATION TOKEN")==!hidden&&f.painter.has("TICKER TOKEN")==!hidden&&f.painter.has("HDG")==!hidden,"Hidden rows are not drawn in "+g.composition);
            check(g.captionVisible&&f.painter.has("CAPTION ONE"),"Actual timed caption drawn in "+g.composition);
            check(g.captionTop>g.headerBottom&&g.captionBottom<g.tagTop&&g.captionLeft>=g.x&&g.captionLeft+g.captionWidth<=g.x+g.width+.01f,"Caption stays inside safe picture bounds in "+g.composition);
            Duwm1728FramePlan.Inset pip=Duwm1728FramePlan.inset(w,h,9,16);
            check(g.captionTop>pip.top+pip.height+pip.border,"Caption remains below portrait inset in "+g.composition);
            int at=f.image.getRGB((int)(g.x+3*g.unit),(int)(g.headerTop+12*g.unit));check(at==Duwm1728BroadcastLayout.CYAN,"Actual WEATHER header uses cyan in "+g.composition);
            if(hidden){near(g.headlineHeight,0,"No hidden headline rectangle");near(g.tickerHeight,0,"No hidden ticker rectangle");near(g.telemetryHeight,0,"No hidden sensor rectangle");}
            Duwm1728BroadcastLayout.Report allowed=report(g.composition);allowed.coordinatesAllowed=true;
            check(new Frame(w,h,allowed,1000).painter.has("PRIVATE TOKEN")==!hidden,"Explicit coordinate consent obeys chosen sensor visibility");
        }
        Frame moved=new Frame(w,h,report("COMPACT"),1600);Duwm1728BroadcastLayout.Geometry g=compact.geometry;
        check(BroadcastRenderTest.difference(compact.image,moved.image,(int)(g.x+115*g.unit),(int)(g.tickerTop+2*g.unit),(int)(g.width-135*g.unit),(int)(g.tickerHeight-4*g.unit))>25,"COMPACT ticker really changes pixels");
        for(String mode:MODES)for(long time:new long[]{499,500,2699,2700,3199,3200,5599,5600}){
            Frame frame=new Frame(w,h,report(mode),time);boolean first=time>=500&&time<2700,second=time>=3200&&time<5600;
            check(frame.geometry.captionVisible==(first||second),mode+" exact inclusive/exclusive caption boundary "+time);
            check(frame.painter.has("CAPTION ONE")==first&&frame.painter.has("CAPTION TWO")==second,mode+" correct cue, no stale subtitle at "+time);
            check((frame.painter.caption()!=null)==(first||second),mode+" no empty caption panel at "+time);
        }
    }
    private static void categoryAndFallback(){
        String[] categories={"WEATHER","TRAFFIC","ENVIRONMENT","INTERVIEW","FIELD REPORT","BREAKING NEWS",""};
        int[] colors={0xFF00ACC1,0xFFFFA000,0xFF00C853,0xFFB39DDB,0xFFDEE5EF,0xFFDEE5EF,0xFFDEE5EF};
        for(String mode:MODES)for(int i=0;i<categories.length;i++){
            Duwm1728BroadcastLayout.Report r=report(mode);r.category=categories[i];Frame frame=new Frame(720,800,r,1000);
            check(Duwm1728BroadcastLayout.accent(r.category,false)==colors[i],"Category accent "+categories[i]);
            check(frame.painter.rects.stream().noneMatch(box->box.color==Duwm1728BroadcastLayout.RED),"No unapproved red background in "+mode+" / "+categories[i]);
            check(!frame.painter.has("BREAKING NEWS"),"No unapproved breaking claim");
            r.breakingApproved=true;Frame approved=new Frame(720,800,r,1000);Duwm1728BroadcastLayout.Geometry g=approved.geometry;
            check(approved.painter.has("BREAKING NEWS")&&approved.image.getRGB((int)(g.x+8*g.unit),(int)(g.tagTop+7*g.unit))==0xFFD50000,"Explicit breaking approval remains visible in "+mode);
        }
        for(String value:new String[]{null,"","old-value","compact","FULL"}){
            Frame fallback=new Frame(720,800,report(value),1000),normal=new Frame(720,800,report("FULL"),1000);
            check("FULL".equals(Duwm1728BroadcastComposition.normalize(value)),"Unknown draft value defaults to FULL");
            check(BroadcastRenderTest.difference(fallback.image,normal.image,0,0,720,800)==0,"Fallback draws established FULL composition");
        }
        for(String mode:MODES){check(Duwm1728BroadcastComposition.normalize(mode).equals(mode),"Stable composition value "+mode);check(!Duwm1728BroadcastComposition.label(mode).isEmpty()&&!Duwm1728BroadcastComposition.description(mode).isEmpty(),"Every choice has a clear label and description");}
    }
    private static void title(Graphics2D g,String text,int x,int y,int size,boolean bold){g.setFont(new Font("SansSerif",bold?Font.BOLD:Font.PLAIN,size));g.setColor(new Color(0xDEE5EF));g.drawString(text,x,y);}
    private static void sheet(File folder,int index)throws Exception{
        int w=SIZES[index][0],h=SIZES[index][1],tile=w>h?640:432,gap=18,top=120,bottom=58,shownHeight=Math.round(h*tile/(float)w);
        BufferedImage sheet=new BufferedImage(tile*4+gap*5,top+shownHeight+bottom,BufferedImage.TYPE_INT_RGB);Graphics2D g=sheet.createGraphics();
        g.setColor(new Color(0x07121D));g.fillRect(0,0,sheet.getWidth(),sheet.getHeight());g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        title(g,"HOST RENDERED • 1728.2/14 → /15 • "+RATIOS[index].replace('-',':'),gap,32,24,true);
        title(g,"Same synthetic source, report, recorded fields and 1,000 ms cue time. Production Java Painter on desktop; NOT ANDROID FOOTAGE.",gap,60,15,false);
        String[] labels={"/14 — FULL baseline","/15 — FULL REPORT","/15 — COMPACT","/15 — CAPTIONS"};
        for(int i=0;i<4;i++){int x=gap+i*(tile+gap);title(g,labels[i],x,99,20,true);BufferedImage frame=i==0?oldFrame(w,h,report("FULL"),1000):new Frame(w,h,report(MODES[i-1]),1000).image;g.drawImage(frame,x,top,tile,shownHeight,null);}
        title(g,"SOURCE PRESERVED • CAPTIONS removes headline, ticker and sensor graphics; category, report status and timed captions remain.",gap,top+shownHeight+33,15,false);
        g.dispose();check(ImageIO.write(sheet,"png",new File(folder,"HOST-COMPOSITION-"+RATIOS[index]+".png")),"Write host composition comparison");
    }
    private static void boundaries(File folder)throws Exception{
        long[] times={499,500,2699,2700,3200,5600};String[] labels={"Before first cue","First cue begins","Last active millisecond","First cue ends","Second cue begins","Second cue ends"};
        int tile=480,gap=18,top=112,cropTop=480,cropHeight=240,shown=90,cellHeight=shown+78;
        BufferedImage sheet=new BufferedImage(3*tile+4*gap,top+2*cellHeight+42,BufferedImage.TYPE_INT_RGB);Graphics2D g=sheet.createGraphics();
        g.setColor(new Color(0x07121D));g.fillRect(0,0,sheet.getWidth(),sheet.getHeight());g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        title(g,"HOST RENDERED • /15 CAPTIONS • Exact cue boundaries",gap,32,25,true);
        title(g,"Lower-picture crops from 1280×720 production-layout frames. First cue [500,2700); second [3200,5600).",gap,63,16,false);
        title(g,"These are desktop raster samples, not Android UI screenshots or decoded MP4 frames.",gap,87,15,false);
        for(int i=0;i<times.length;i++){int x=gap+(i%3)*(tile+gap),y=top+(i/3)*cellHeight;title(g,times[i]+" ms • "+labels[i],x,y+25,18,true);
            BufferedImage frame=new Frame(1280,720,report("CAPTIONS"),times[i]).image;g.drawImage(frame,x,y+42,x+tile,y+42+shown,0,cropTop,1280,cropTop+cropHeight,null);}
        title(g,"Cue absence removes the caption panel immediately. Header and report status remain unchanged outside the crop.",gap,sheet.getHeight()-18,15,false);
        g.dispose();check(ImageIO.write(sheet,"png",new File(folder,"HOST-CAPTION-BOUNDARIES.png")),"Write host cue-boundary comparison");
    }
    public static void main(String[] args)throws Exception{
        File folder=new File(args.length==0?"composition-host-proof":args[0]);if(!folder.isDirectory()&&!folder.mkdirs())throw new IOException("Cannot create host evidence directory");
        for(int i=0;i<SIZES.length;i++){baselineGeometry(SIZES[i][0],SIZES[i][1]);semantics(SIZES[i][0],SIZES[i][1]);sheet(folder,i);}
        categoryAndFallback();boundaries(folder);
        String result="{\n  \"status\": \"PASS\",\n  \"scope\": \"HOST_RENDERED_SHARED_PRODUCTION_PAINTER\",\n  \"checks\": "+checks+",\n  \"version\": \"1728.2/21\",\n  \"native_executed\": false,\n  \"native_status\": \"NOT RUN\",\n  \"physical_camera_verified\": false,\n  \"baseline_14_source_sha256\": \""+Duwm1728BroadcastLayout14.SOURCE_SHA256+"\",\n  \"compositions\": [\"FULL\",\"COMPACT\",\"CAPTIONS\"],\n  \"ratios\": [\"9:10\",\"9:16\",\"16:9\"]\n}\n";
        Files.write(new File(folder,"COMPOSITION-HOST-RESULT.json").toPath(),result.getBytes(StandardCharsets.UTF_8));
        System.out.println("PASS "+checks+" host composition, baseline geometry, pixels, privacy and exact-caption checks. HOST RENDERED; native /21 NOT RUN.");
    }
}
