package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class BroadcastTimelineTest {
    private static int passed;
    static void check(boolean ok,String message){passed++;if(!ok)throw new AssertionError(message);}
    static void rejects(Runnable action,String message){boolean failed=false;try{action.run();}catch(IllegalArgumentException e){failed=true;}check(failed,message);}
    static Duwm1728BroadcastLayout.Cue active(List<Duwm1728BroadcastLayout.Cue> cues,long t){return Duwm1728BroadcastLayout.active(cues,t);}
    public static void main(String[] args){
        String srt="1\n00:00:00,250 --> 00:00:00,750\nFirst words\n\n2\n00:00:02,125 --> 00:00:02,875\nSecond words\n\n3\n00:01:04,500 --> 00:01:06,250\nLonger recording\n";
        List<Duwm1728BroadcastLayout.Cue> cues=Duwm1728SubtitleImport.parseSrtCues(srt);
        check(cues.size()==3,"All cues including beyond 45 seconds");
        check(cues.get(0).startMs==250&&cues.get(0).endMs==750,"Exact milliseconds and ends");
        check(active(cues,749)!=null&&active(cues,750)==null,"Caption disappears at end, not next start");
        check(active(cues,2000)==null,"Silent gap has no stale caption");
        List<Duwm1728BroadcastLayout.Cue> trimmed=Duwm1728BroadcastTimeline.captions(cues,500,2300);
        check(trimmed.size()==2,"Trim intersects two captions");
        check(trimmed.get(0).startMs==0&&trimmed.get(0).endMs==250,"Clip start boundary");
        check(trimmed.get(1).startMs==1625&&trimmed.get(1).endMs==1800,"Clip end boundary");
        List<Duwm1728TickerTimeline.Cue> raw=Duwm1728TickerTimeline.parse("00:00=First;00:05=Second;00:10=Third");
        List<Duwm1728BroadcastLayout.Cue> ticks=Duwm1728BroadcastTimeline.tickers(raw,2000,8000,14000);
        check(ticks.size()==2,"Trim drops earlier ticker and keeps current update");
        check(active(ticks,0).text.equals("Second"),"Carry current ticker at trimmed start");
        check(active(ticks,3999).text.equals("Second")&&active(ticks,4000).text.equals("Third"),"Next update anchored to source time");
        check(active(ticks,6000)==null,"No update beyond clip end");
        check(Duwm1728BroadcastTimeline.tickers(raw,50000,0,2000).isEmpty(),"Future updates not invented");
        List<Duwm1728TickerTimeline.Cue> reversed=new ArrayList<>(raw);Collections.reverse(reversed);
        check(Duwm1728BroadcastTimeline.tickers(reversed,2000,8000,14000).get(0).text.equals("Second"),"Unsorted input deterministic");
        List<Duwm1728BroadcastLayout.Cue> manual=Duwm1728BroadcastTimeline.manualCaptions(Duwm1728TickerTimeline.parse("00:00=First;00:10=Second"),0,0,15000);
        check(active(manual,5999)!=null&&active(manual,6000)==null,"Manual cue does not persist indefinitely");
        check(active(manual,10000).text.equals("Second"),"Manual second update");
        check(Duwm1728BroadcastTimeline.sourceAtProgress(0,5000,10000)==5000,"Seek begins at selected trim");
        check(Duwm1728BroadcastTimeline.sourceAtProgress(500,5000,10000)==7500,"Seek midpoint");
        check(Duwm1728BroadcastTimeline.sourceAtProgress(1000,5000,10000)==9999,"Seek cannot leave selected range");
        check(Duwm1728BroadcastTimeline.elapsed(4000,5000,10000)==0,"Pre-start preview bounded");
        check(Duwm1728BroadcastTimeline.elapsed(15000,5000,10000)==4999,"Post-end preview bounded");
        check(Duwm1728BroadcastTimeline.clock(3661000).equals("1:01:01"),"Hours displayed correctly");
        rejects(()->Duwm1728BroadcastTimeline.range(-1,2),"Negative range rejected");
        rejects(()->Duwm1728BroadcastTimeline.range(2,2),"Empty range rejected");
        rejects(()->Duwm1728BroadcastTimeline.tickers(raw,Long.MAX_VALUE-2,0,1000),"Timestamp overflow rejected");
        rejects(()->Duwm1728SubtitleImport.parseSrtCues("1\n00:00:02,000 --> 00:00:01,000\nNo"),"Reverse cue rejected");
        rejects(()->Duwm1728SubtitleImport.parseSrtCues("1\n00:61:02,000 --> 00:62:01,000\nNo"),"Invalid minute rejected");
        List<Duwm1728BroadcastLayout.Cue> overlapping=Duwm1728SubtitleImport.parseSrtCues("1\n00:00:00,000 --> 00:00:02,000\nOne\n\n2\n00:00:01,000 --> 00:00:03,000\nTwo");
        check(overlapping.size()==2&&active(overlapping,1500).text.equals("Two"),"Overlaps retain both cues and latest-start renderer priority");
        rejects(()->Duwm1728SubtitleImport.parseSrtCues(" "),"Empty SRT rejected");
        StringBuilder longer=new StringBuilder();for(int i=0;i<20;i++)longer.append(i+1).append("\n00:01:").append(String.format(Locale.ROOT,"%02d",i*2)).append(",125 --> 00:01:").append(String.format(Locale.ROOT,"%02d",i*2+1)).append(",875\nWords ").append(i).append("\n\n");
        check(Duwm1728SubtitleImport.parseSrtCues(longer.toString()).size()==20,"More than twelve timed captions retained");
        check(Duwm1728SubtitleImport.parseSrtCues("\uFEFF1\r\n00:00:00,125 --> 00:00:00,875\r\n<b>مرحبا 世界</b>\r\n").get(0).text.equals("<b>مرحبا 世界</b>"),"Unicode and literal angle-bracket words survive a leading BOM");
        System.out.println("PASS "+passed+" executed subtitle-end, trim, ticker-anchor, seek and rejection cases; not an Android encoder test.");
    }
}
