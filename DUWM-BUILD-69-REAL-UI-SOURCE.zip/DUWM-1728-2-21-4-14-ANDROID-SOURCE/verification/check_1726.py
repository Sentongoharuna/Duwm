#!/usr/bin/env python3
from pathlib import Path
import json,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
j=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
read=lambda f:(j/f).read_text()
build=(r/'app/build.gradle.kts').read_text()
assert 'versionCode = 172600' in build and 'versionName = "1726"' in build
assert 'DUWM 1726 • DEVELOP.UGANDA' in (r/'app/src/main/res/values/strings.xml').read_text()
a=json.loads((r/'app/src/main/assets/duwm_release_ui.json').read_text());assert a['uiRevision']=='1726'
assert read('MainActivity.java').count('new SatelliteMapView(this)')==1
assert len(list(j.glob('*.java')))>=259
assert 'BACKGROUND = 0xFF041424' in read('DuwmUnifiedTheme.java')
for c in ('0xFFD50000','0xFFF57C00','0xFFFBC02D','0xFF0D47A1','0xFF00ACC1','0xFF00C853'):
    assert c in read('Duwm1724SignalFlow.java'),c
assert 'Duwm1724SignalHistory.stages(this,index)' in read('Duwm1716SignalCenterActivity.java')
assert 'OBSERVED STATUS CHANGES' in read('Duwm1716SignalCenterActivity.java')
assert 'getString("desk"+index+"_history"' in read('Duwm1724SignalHistory.java')
assert 'Duwm1726GalleryIndex.add(getApplicationContext(),savedUri,galleryName)' in read('Duwm1718MonitorsCamActivity.java')
assert 'MY RECORDINGS  /  OPEN GALLERY VIDEOS' in read('Duwm1718MonitorsCamActivity.java')
assert 'Intent.ACTION_VIEW' in read('Duwm1726GalleryLibraryActivity.java')
assert 'FLAG_GRANT_READ_URI_PERMISSION' in read('Duwm1726GalleryLibraryActivity.java')
assert 'new Intent(this,Duwm1726GalleryLibraryActivity.class)' in read('Duwm1718MonitorsCamActivity.java')
assert 'Duwm1726GalleryLibraryActivity' in (r/'app/src/main/AndroidManifest.xml').read_text()
assert 'Duwm1724GalleryPublisher.publish(' in read('Duwm1718MonitorsCamActivity.java')
assert '9:10 PORTRAIT' in read('Duwm1718MonitorsCamActivity.java')
assert '16:9 LANDSCAPE' in read('Duwm1718MonitorsCamActivity.java')
for p in (r/'app/src/main/res').rglob('*.xml'):ET.parse(p)
ET.parse(r/'app/src/main/AndroidManifest.xml')
print('PASS 1726: exact identity, one globe, recorded status history, Gallery library, palette and manifest')
