#!/usr/bin/env python3
"""CI diagnostics only; never changes a failed build into a successful build."""
import json,os,re,sys
from pathlib import Path
stage,code,filename=sys.argv[1],int(sys.argv[2]),sys.argv[3]
path=Path(filename)
text=path.read_text(errors='replace') if path.exists() else 'Compiler log unavailable'
lines=text.splitlines(); snippets=[]
for i,line in enumerate(lines):
    if re.search(r'\berror:|cannot find symbol|FAILURE:|Execution failed for task|BUILD FAILED|command not found',line):
        snippets.extend(lines[max(0,i):min(len(lines),i+5)])
        if len(snippets)>=45:break
summary=f'## Android {stage}: {"PASSED" if code==0 else "FAILED"} (exit {code})\n\n'
summary+='This is a Gradle/Android build result, not a camera, AI or playback test.\n\n'
if code:
    summary+='```text\n'+'\n'.join(snippets or lines[-35:]).replace('```','~~~')+'\n```\n'
    print(f'::error title=Android {stage} failed::See the first compiler errors in this job summary and gradle-{stage}.log in BUILD-DIAGNOSTICS.')
else:
    summary+='The requested Android tasks completed. Native export and physical-phone checks have separate statuses.\n'
(path.parent/f'{stage}-result.json').write_text(json.dumps({'stage':stage,'exit_code':code,'log':path.name,'success':code==0},indent=2)+'\n')
(path.parent/f'{stage}-summary.md').write_text(summary)
if os.environ.get('GITHUB_STEP_SUMMARY'):
    with open(os.environ['GITHUB_STEP_SUMMARY'],'a') as out:out.write(summary)
print(summary)
