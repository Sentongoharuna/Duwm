from pathlib import Path
import re
p=Path(__file__).resolve().parents[1]
s=(p/'app/src/main/java/com/sentongoharuna/worldsituationroom/Duwm1728SemanticSignalColors.java').read_text()
assert '0xFFD50000' in s and '0xFF00ACC1' in s and '0xFF0D47A1' in s and '0xFFFBC02D' in s and '0xFF00C853' in s
assert '!s.contains("UNVERIFIED")' in s
b=(p/'app/src/main/java/com/sentongoharuna/worldsituationroom/Duwm1728BroadcastLayout.java').read_text()
c=(p/'app/src/main/java/com/sentongoharuna/worldsituationroom/Duwm1728ClearPictureLayout.java').read_text()
for token in ['Duwm1728SemanticSignalColors.provenance','Duwm1728SemanticSignalColors.weather','Duwm1728SemanticSignalColors.live','Duwm1728SemanticSignalColors.telemetry']:
    assert token in b or token in c, token
g=(p/'app/build.gradle.kts').read_text(); assert 'versionCode = 172830' in g and 'versionName = "1728.2.21.4.6"' in g
print('PASS semantic signal colour contract')
