#!/usr/bin/env python3
"""Negative packaged-class gate fixtures, never compiled or physical evidence."""
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
from SceneSdkApkGateTest import dex_fixture
import verify_measured_telemetry_apk as gate


class MeasuredApkGateTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="measured-dex-gate-unit-")
        self.root = Path(self.temp.name)
        self.apk = self.root / "unit-structure.zip"
        self.dependency = self.root / "unit-dependency.json"
        self.dependency.write_text(json.dumps({
            "status": "PASS", "coordinate": gate.scene_gate.COORDINATE,
            "artifact_sha256": "0" * 64, "artifact_bytes": 1}))
        self.names = list(gate.scene_gate.SDK_CLASSES + gate.scene_gate.APP_CLASSES + gate.MEASUREMENT_CLASSES)
    def tearDown(self):
        self.temp.cleanup()
    def archive(self, defined):
        with zipfile.ZipFile(self.apk, "w") as archive:
            archive.writestr("classes.dex", dex_fixture(self.names, defined))
    def test_complete_class_definitions_keep_physical_scope_false(self):
        self.archive(self.names)
        result = gate.verify(self.apk, self.dependency)
        self.assertEqual("PASS", result["status"])
        self.assertIs(False, result["physical_sensor_verified"])
        self.assertIs(False, result["model_inference_verified"])
    def test_any_missing_measurement_definition_fails_despite_descriptor_reference(self):
        for name in gate.MEASUREMENT_CLASSES:
            with self.subTest(name=name):
                self.archive([n for n in self.names if n != name])
                with self.assertRaisesRegex(AssertionError, "measured runtime DEX class definitions missing"):
                    gate.verify(self.apk, self.dependency)
    def test_measurement_classes_do_not_replace_the_actual_sdk(self):
        self.archive(list(gate.scene_gate.APP_CLASSES + gate.MEASUREMENT_CLASSES))
        with self.assertRaisesRegex(AssertionError, "Actual DEX class definitions missing"):
            gate.verify(self.apk, self.dependency)


if __name__ == "__main__":
    unittest.main(verbosity=2)
