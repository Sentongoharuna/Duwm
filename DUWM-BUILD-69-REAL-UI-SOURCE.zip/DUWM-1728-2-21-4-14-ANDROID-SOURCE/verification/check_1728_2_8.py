#!/usr/bin/env python3
"""Run meaningful shared-renderer tests plus explicit integration/preservation checks.
This does NOT replace Android compilation or native export/device tests.
"""
from pathlib import Path
import hashlib,json,os,re,subprocess,tempfile,xml.etree.ElementTree as ET,shutil
root=Path(__file__).resolve().parents[1]
java=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
from release_contract import assert_release_at_least
assert assert_release_at_least(root,1728)==172808
meta=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text());assert meta['uiRevision']=='1728.2.8' and meta['uiVersionCode']==172808
protected=json.loads((root/'verification/1728_2_7_UNCHANGED_JAVA.json').read_text())
for name,digest in protected.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
cam=(java/'Duwm1718MonitorsCamActivity.java').read_text();editor=(java/'Duwm1728VideoEditorActivity.java').read_text();renderer=(java/'Duwm1728OverlayRenderer.java').read_text();gl=(java/'Duwm1728EglVideoPipe.java').read_text()
assert 'MediaRecorder.VideoSource.CAMERA' in cam and 'compressToJpeg(' not in cam and 'lockCanvas(' not in cam
assert 'new Intent(this,Duwm1728VideoEditorActivity.class)' in cam and 'DUWM_MASTER_' in cam
assert 'drawOverlay(c,previewSpec' in editor and 'Duwm1728OverlayRenderer.export(' in editor
assert 'drawOverlay(canvas,spec' in renderer and 'eglPresentationTimeANDROID' in gl
assert '45000L' not in renderer and '1280.0' not in renderer and 'fps=24' not in renderer
assert 'DUWM_BROADCAST_' in editor and 'approval.isChecked()' in editor
assert 'getBoolean("auto_after_capture",false)' in editor
assert 'AI production server is not configured' in (java/'Duwm1728AiProductionClient.java').read_text()
for f in (root/'app/src').rglob('*.xml'):ET.parse(f)
proof=root/'verification/results/1728_2_8';proof.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory() as folder:
    subprocess.run(['javac','--release','17','-d',folder,str(java/'Duwm1728BroadcastLayout.java'),str(root/'verification/broadcast/BroadcastRenderTest.java')],check=True)
    run=subprocess.run(['java','-Djava.awt.headless=true','-cp',folder,'com.sentongoharuna.worldsituationroom.BroadcastRenderTest',str(proof)],check=True,text=True,capture_output=True)
    print(run.stdout,end='');(proof/'host-render-tests.txt').write_text(run.stdout)
    # Existing production signal policy, not copied/reimplemented decisions.
    package=Path(folder)/'src/com/sentongoharuna/worldsituationroom';package.mkdir(parents=True)
    for name in ('FeedStatus.java','Duwm1724SignalFlow.java','DuwmUnifiedTheme.java','Duwm1728SignalMotion.java','Duwm1728CaptureHealth.java'):
        shutil.copyfile(java/name,package/name)
    layer=re.search(r'public enum Layer\s*\{([^}]+)\}',(java/'Signal.java').read_text()).group(1)
    (package/'Signal.java').write_text('package com.sentongoharuna.worldsituationroom; public final class Signal {public enum Layer {'+layer+'}}')
    for name in ('SignalMotionTest.java','CaptureHealthTest.java'):shutil.copyfile(root/'verification'/name,package/name)
    subprocess.run(['javac','--release','17','-d',folder,*map(str,package.glob('*.java'))],check=True)
    for name in ('SignalMotionTest','CaptureHealthTest'):
        run=subprocess.run(['java','-cp',folder,'com.sentongoharuna.worldsituationroom.'+name],check=True,text=True,capture_output=True)
        print(run.stdout,end='');(proof/(name+'.txt')).write_text(run.stdout)
print('PASS integration wiring, actual identity, XML and',len(protected),'unchanged baseline Java components.')
print('NOT TESTED HERE: Android API type-check, APK build, EGL on Android, real camera, live AI service.')
