#!/usr/bin/env bash
set -euo pipefail
ticker_project="$(cd "$(dirname "$0")/.." && pwd)"
ticker_proof="${1:-$ticker_project/verification/automatic-ticker-pages-host-proof}"
ticker_javac="${JAVAC:-${JAVA_HOME:+$JAVA_HOME/bin/}javac}"
ticker_java="${JAVA:-${JAVA_HOME:+$JAVA_HOME/bin/}java}"
ticker_build="$(mktemp -d "${TMPDIR:-/tmp}/duwm-ticker-pages.XXXXXX")"
trap 'rm -rf -- "$ticker_build"' EXIT
ticker_source="$ticker_project/app/src/main/java/com/sentongoharuna/worldsituationroom"
"$ticker_javac" --release 17 -encoding UTF-8 -d "$ticker_build" \
  "$ticker_source/Duwm1728BroadcastComposition.java" \
  "$ticker_source/Duwm1728BroadcastLayout.java" "$ticker_source/Duwm1728ClearPictureLayout.java" \
  "$ticker_source/Duwm1728HeadlineFit.java" \
  "$ticker_source/Duwm1728CaptionPages.java" \
  "$ticker_source/Duwm1728TickerTimeline.java" \
  "$ticker_source/Duwm1728BroadcastTimeline.java" \
  "$ticker_source/Duwm1728CaptionEditPolicy.java" \
  "$ticker_source/Duwm1728CaptionSrt.java" \
  "$ticker_source/Duwm1728FramePlan.java" \
  "$ticker_source/Duwm1728PcmTimeline.java" \
  "$ticker_source/Duwm1728AutomaticProduction.java" \
  "$ticker_source/Duwm1728SpeechCues.java" \
  "$ticker_project/verification/broadcast/BroadcastRenderTest.java" \
  "$ticker_project/verification/broadcast/AutomaticTickerPagesTest.java"
"$ticker_java" -Xmx512m -Djava.awt.headless=true -cp "$ticker_build" \
  com.sentongoharuna.worldsituationroom.AutomaticTickerPagesTest "$ticker_proof"
