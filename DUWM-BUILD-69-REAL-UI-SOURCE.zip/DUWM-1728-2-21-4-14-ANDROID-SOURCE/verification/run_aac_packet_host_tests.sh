#!/usr/bin/env bash
set -euo pipefail
aac_project="$(cd "$(dirname "$0")/.." && pwd)"
aac_proof="${1:-$aac_project/verification/aac-packet-host-proof}"
aac_javac="${JAVAC:-${JAVA_HOME:+$JAVA_HOME/bin/}javac}"
aac_java="${JAVA:-${JAVA_HOME:+$JAVA_HOME/bin/}java}"
aac_build="$(mktemp -d "${TMPDIR:-/tmp}/duwm-aac-packet-host.XXXXXX")"
trap 'rm -rf -- "$aac_build"' EXIT
"$aac_javac" --release 17 -encoding UTF-8 -d "$aac_build" \
  "$aac_project/app/src/androidTest/java/com/sentongoharuna/worldsituationroom/DuwmAacPacketContract.java" \
  "$aac_project/verification/broadcast/AacPacketContractTest.java"
"$aac_java" -cp "$aac_build" com.sentongoharuna.worldsituationroom.AacPacketContractTest \
  "$aac_project/verification/audio-fixtures/native-run-42417837324" "$aac_proof"
