#!/usr/bin/env python3
"""DUWM 1721 true source checks; Android bytecode verified separately by GitHub."""
from pathlib import Path
import json,re,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
java=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
read=lambda name:(java/name).read_text(encoding='utf-8')
main=read('MainActivity.java'); globe=read('SatelliteMapView.java')
cam=read('Duwm1718MonitorsCamActivity.java'); discovery=read('Duwm1718GlobalDiscoverActivity.java')
my=read('Duwm1719MyWorldActivity.java'); quakes=read('Duwm1721GlobalQuakesActivity.java')
theme=read('DuwmUnifiedTheme.java')
identity=(root/'app/build.gradle.kts').read_text()
assert 'versionCode = 172100' in identity and 'versionName = "1721"' in identity
assert 'DUWM 1721 • DEVELOP.UGANDA' in (root/'app/src/main/res/values/strings.xml').read_text()
ui=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1721' and ui['uiVersionCode']==172100
assert main.count('new SatelliteMapView(this)')==1
assert 'new SatelliteMapView' not in quakes+cam+my+discovery
for value in ('BACKGROUND = 0xFF041424','BORDER = 0xFFDEE5EF','TEXT = 0xFFF5F7FA','MUTED = 0xFFA0A5AE'):assert value in theme
assert 'DuwmUnifiedTheme.APPROVED_NAVY' in globe
for cls in ('Duwm1718MonitorsCamActivity','Duwm1718GlobalDiscoverActivity','Duwm1721GlobalQuakesActivity'):
    assert f'{cls}.class' in main
for name,content in [('Duwm1719MyWorldActivity',my),('Duwm1718GlobalDiscoverActivity',discovery)]:assert 'Duwm1721GlobalQuakesActivity.class' in content
assert 'https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_week.geojson' in quakes
for text in ('getFromLocationName' if False else 'HttpURLConnection','optJSONArray("coordinates")','FETCHED_WALL','getSharedPreferences','M %.1f','dateUtc','USGS STATUS','OPEN ON MAP','INVALID SOURCE DATA'):
    assert text in quakes,('Global earthquake feature missing',text)
assert 'new Thread' in quakes and 'setConnectTimeout(9000)' in quakes
assert 'LOCATION NOT PROVIDED' in quakes and 'NO VALID CACHE' in quakes
for text in ('MessageDigest.getInstance("SHA-256")','FileInputStream','PRIVATE' if False else 'CLIP_RECEIPTS',
             'getSharedPreferences(CLIP_RECEIPTS','UNVERIFIED','saveCaptureReceipt(f,lastFile',
             'bakedCategory=CATEGORIES[categoryIndex]','PRECISE GPS BURNED','SHORT' if False else 'showCaptureReceipt'):
    assert text in cam,('Camera receipt feature missing',text)
assert 'preciseLocation.setChecked(false)' in cam
assert 'recorderSurface.lockCanvas(null)' in cam
assert 'bakedPrecise=preciseLocation.isChecked()' in cam
assert 'recorderSurface.unlockCanvasAndPost(canvas)' in cam
assert 'private static java.lang.ref.WeakReference<SignalRail> visible' in read('Duwm1715SignalLights.java')
for xml in (root/'app/src/main/res').rglob('*.xml'):ET.parse(xml)
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
activities={x.get(ns+'name') for x in manifest.iter('activity')}
assert '.Duwm1721GlobalQuakesActivity' in activities
assert any(x.get(ns+'name')=='android.permission.INTERNET' for x in manifest.iter('uses-permission'))
assert len(list(java.glob('*.java')))>=253
print('PASS DUWM 1721: original globe, 19 desks, exact formal palette, native global USGS feed and camera receipt features')
