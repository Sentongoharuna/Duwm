#!/usr/bin/env python3
"""Source-contract tests for 1728.2/3, not device acceptance tests."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
cam=(base/'Duwm1718MonitorsCamActivity.java').read_text()
editor=(base/'Duwm1728VideoEditorActivity.java').read_text()
track=(base/'Duwm1728TelemetryTimeline.java').read_text()
render=(base/'Duwm1728OverlayRenderer.java').read_text()
provenance=(base/'Duwm1728CaptureTelemetry.java').read_text()
assert 'original' in (root/'1728_PHASE2_3_CHECKPOINT_NOT_RELEASED.md').read_text().lower()
checks={
  'real capture sampling': 'recordTelemetrySample();' in cam and 'new Duwm1728TelemetryTimeline.Point(ms' in cam,
  'sample cap and interval': 'telemetrySamples.size()>=200' in cam and 'ms-lastSampleElapsed<2000L' in cam,
  'save after Gallery success': 'Duwm1728TelemetryTimeline.save(getApplicationContext(),savedUri,capturedTrack)' in cam,
  'no source without local record': 'if(raw==null)return result;' in track,
  'precision withheld at capture': 's.preciseEnabled?s.coordinates:"WITHHELD"' in track,
  'precision withheld at editor export': 'spec.includeCoordinates=spec.includeSourceSummary && preciseExport.isChecked()' in editor,
  'recording timeline selected opt-in': 'recordedTrackToggle.setChecked(false)' in editor,
  'editor reads saved timeline': 'Duwm1728TelemetryTimeline.load(getApplicationContext(),source)' in editor,
  'frame-bound timeline': 'elapsedMs+s.fromMs' in render,
  'export marks old measurements': 'RECORDED, NOT LIVE' in render,
  'prompter explicitly shown': 'showPrompter=!prompterScript.isEmpty()' in cam,
  'prompter preview only': 'stage.addView(prompterDisplay' in cam and 'prompterDisplay' not in render,
  'dictation opt-in': 'ACTION_RECOGNIZE_SPEECH' in editor,
  'dictated words require approval': 'ADD CAPTION' in editor and 'DISCARD' in editor,
  'dictation not confused with source transcription': 'NOT source-video transcription' in editor,
  'original MP4 retained': 'Duwm1724GalleryPublisher.publish' in editor and 'source' in editor,
  'keying provenance unchanged': 'storageKey(video)' in provenance,
}
for name,yes in checks.items():
 if not yes:raise AssertionError(name)
print('PASS',len(checks),'1728.2/3 source contract assertions (NOT an Android or physical-camera test)')
