#!/usr/bin/env python3
"""1722 screenshot-led source gates; Android compile/device testing remain separate."""
from pathlib import Path
import json,re,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
j=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
read=lambda x:(j/x).read_text(encoding='utf-8')
main=read('MainActivity.java');cam=read('Duwm1718MonitorsCamActivity.java')
rail=read('DuwmSignalRail.java');native=read('Duwm1715SignalLights.java')
quakes=read('Duwm1721GlobalQuakesActivity.java')
theme=read('DuwmUnifiedTheme.java');world=read('Duwm1718GlobalDiscoverActivity.java')
my=read('Duwm1719MyWorldActivity.java')
gradle=(r/'app/build.gradle.kts').read_text(encoding='utf-8')
strings=(r/'app/src/main/res/values/strings.xml').read_text(encoding='utf-8')
ui=json.loads((r/'app/src/main/assets/duwm_release_ui.json').read_text(encoding='utf-8'))
assert 'versionCode = 172200' in gradle and 'versionName = "1722"' in gradle
assert 'DUWM 1722 • DEVELOP.UGANDA' in strings
assert ui['uiRevision']=='1722' and ui['uiVersionCode']==172200 and ui['singleOriginalGlobe']
assert main.count('new SatelliteMapView(this)')==1
assert all('new SatelliteMapView' not in s for s in (cam,quakes,world,my))
for x in ('BACKGROUND = 0xFF041424','BORDER = 0xFFDEE5EF',
          'TEXT = 0xFFF5F7FA','MUTED = 0xFFA0A5AE'):
    assert x in theme,x
assert 'return;' in rail[rail.index('public static void attach'):rail.index('public static final class Lifecycle')]
assert 'Never draw the legacy eight-light bubble' in rail
assert 'Duwm1715SignalLights.attach(a);' in read('DuWorldApplication.java')
assert 'private static java.lang.ref.WeakReference<SignalRail> visible' in native
assert 'shell.setOnApplyWindowInsetsListener' in native
assert 'LinearLayout quickActions = new LinearLayout(this);' in main
assert main.count('add1722BalancedAction(quickRow,')==5
assert main.count('add1722BalancedAction(row,globeEdgeTab(')==3
for action in ('show1722WorldMenu()', 'show1722GlobeMenu(globeToolsButton)',
               'Duwm1718GlobalDiscoverActivity.class','Duwm1721GlobalQuakesActivity.class',
               'Duwm1718MonitorsCamActivity.class','Duwm1719MyWorldActivity.class'):
    assert action in main,action
assert 'add1722BalancedAction' in main and 'MONITORS CAM' in main
for marker in ('page.addView(recordDock,new LinearLayout.LayoutParams(-1,dp(69)))',
               'root.addView(reportDetails,mp())','reportDetails.setVisibility(View.GONE)',
               'reportDetails.getVisibility()!=View.VISIBLE','previewGrid.invalidate()',
               'this::flipCamera','this::zoomCamera','this::focusOnce',
               'this::toggleRecording','this::showReadiness','preciseLocation.setChecked(false)',
               'MediaRecorder.VideoSource.SURFACE','recorderSurface.lockCanvas(null)',
               'recorderSurface.unlockCanvasAndPost(canvas)','saveCaptureReceipt(f,lastFile',
               'new AlertDialog.Builder(this).setTitle("Confirm MONITORS CAM recording")',
               'UNVERIFIED REPORT','sourceWeather()'):
    assert marker in cam,('MONITORS CAM gate',marker)
assert 'Duwm1718MonitorsCamActivity' in read('DuWorldApplication.java') or 'Duwm1718MonitorsCamActivity' in main
assert 'Geocoder.isPresent()' in world and 'getFromLocationName(q,1)' in world
assert 'TimeZone.getTimeZone' in world and 'TimeZone.getAvailableIDs()' in my
for marker in ('SORT: NEWEST FIRST','SORT: STRONGEST FIRST','shareQuake(Quake quake)',
               'Intent.ACTION_SEND','earthquake.usgs.gov','getSharedPreferences(STORE,MODE_PRIVATE)',
               'CACHED SOURCE','USGS STATUS','new Thread'):
    assert marker in quakes,('USGS source-backed feature',marker)
assert 'DUWM 1722  /  MONITORS CAM' in cam
assert 'DUWM 1722  /  GLOBAL EARTHQUAKES' in quakes
assert 'DUWM 1722  /  GLOBAL DISCOVERY' in world
assert 'DUWM 1722  /  MY WORLD' in my
for path in (r/'app/src/main/res').rglob('*.xml'):ET.parse(path)
ET.parse(r/'app/src/main/AndroidManifest.xml')
assert len(list(j.glob('*.java')))>=253
print('PASS 1722 original single globe, exactly matched navy/silver palette, signal chip de-duplication, accessible camera record dock, worldwide USGS sorting and sharing, manifest and XML')
print('NOT VERIFIED: Android Gradle compilation or actual MONITORS CAM video/audio encoding on a phone')
