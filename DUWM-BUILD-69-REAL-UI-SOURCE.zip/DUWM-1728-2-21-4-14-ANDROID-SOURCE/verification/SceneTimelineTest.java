package com.sentongoharuna.worldsituationroom;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Pure time/text policy fixtures. No model, Android camera or encoder is executed. */
public final class SceneTimelineTest {
    private static int checks;
    private static void check(boolean condition, String reason) {
        checks++;
        if (!condition) throw new AssertionError(reason);
    }
    private static Duwm1728SceneTimeline.Entry entry(long start, long end, String words) {
        return new Duwm1728SceneTimeline.Entry(start, end, words, words, Duwm1728SceneTimeline.SOURCE);
    }
    private static void rejects(Runnable action, String reason) {
        boolean rejected = false;
        try { action.run(); } catch (IllegalArgumentException expected) { rejected = true; }
        check(rejected, reason);
    }
    private static void wellFormed(String value) {
        for (int i=0;i<value.length();i++) {
            char ch=value.charAt(i);
            if (Character.isHighSurrogate(ch)) {
                check(i+1<value.length()&&Character.isLowSurrogate(value.charAt(i+1)), "split Unicode pair");
                i++;
            } else check(!Character.isLowSurrogate(ch), "orphan low surrogate");
        }
    }
    public static void main(String[] args) throws Exception {
        var first=entry(1000,11000,"Fixture: a tree.");
        var second=entry(4000,5000,"Fixture: a doorway.");
        List<Duwm1728SceneTimeline.Entry> unsorted=Arrays.asList(second,null,first);
        check(Duwm1728SceneTimeline.at(unsorted,-1)==null,"negative source time");
        check(Duwm1728SceneTimeline.at(unsorted,999)==null,"future observation shown early");
        check(Duwm1728SceneTimeline.at(unsorted,1000)==first,"inclusive source start");
        check(Duwm1728SceneTimeline.at(unsorted,3999)==first,"older current observation lost");
        check(Duwm1728SceneTimeline.at(unsorted,4000)==second,"new scene must own its source interval");
        check(Duwm1728SceneTimeline.at(unsorted,4999)==second,"scene valid just before end");
        check(Duwm1728SceneTimeline.at(unsorted,5000)==null,"older overlapping scene revived at expiry");
        check(Duwm1728SceneTimeline.at(unsorted,10000)==null,"expired newest scene revived older scene");
        check(Duwm1728SceneTimeline.at(unsorted,11000)==null,"expired final scene shown");
        check(Duwm1728SceneTimeline.at(null,0)==null,"absent track");
        check(Duwm1728SceneTimeline.at(List.of(),0)==null,"empty track");
        var replacement=entry(4000,6000,"Fixture: replacement observation.");
        List<Duwm1728SceneTimeline.Entry> mutable=new ArrayList<>(Arrays.asList(second,first,replacement));
        var normalized=Duwm1728SceneTimeline.normalize(mutable);
        check(normalized.size()==2&&normalized.get(0)==first&&normalized.get(1)==replacement,
                "stable time ordering and last duplicate semantics");
        check(mutable.get(0)==second,"normalization changed capture-owned list");
        mutable.clear();
        check(normalized.size()==2,"normalized immutable snapshot aliases input");
        boolean immutable=false;
        try { normalized.clear(); } catch(UnsupportedOperationException expected) { immutable=true; }
        check(immutable,"normalized track is mutable");
        check(Duwm1728SceneTimeline.at(normalized,5001)==replacement,"duplicate replacement lookup");
        // A trimmed export asks using original-source time once, never clip-relative time.
        long trimStart=2500,exportOffset=1600;
        check(Duwm1728SceneTimeline.at(normalized,trimStart+exportOffset)==replacement,"source-time trim mapping");
        check(Duwm1728SceneTimeline.at(normalized,exportOffset)==first,"fixture distinguishes incorrect missing trim offset");
        var many=new ArrayList<Duwm1728SceneTimeline.Entry>();
        for(int i=Duwm1728SceneTimeline.MAX_ENTRIES;i>=0;i--)many.add(entry(i*20000L,i*20000L+1000,"Fixture interval "+i));
        var bounded=Duwm1728SceneTimeline.normalize(many);
        check(bounded.size()==Duwm1728SceneTimeline.MAX_ENTRIES,"bounded track storage");
        check(bounded.get(0).atMs==0,"bounded normalization discarded recording start");
        check(Duwm1728SceneTimeline.at(bounded,Duwm1728SceneTimeline.MAX_ENTRIES*20000L)==null,
                "missing sample after track bound fabricated coverage");
        rejects(()->entry(-1,1,"fixture"),"negative sample accepted");
        rejects(()->entry(1,1,"fixture"),"zero-length sample accepted");
        rejects(()->entry(2,1,"fixture"),"backwards sample accepted");
        rejects(()->entry(0,Duwm1728SceneTimeline.MAX_VALIDITY_MS+1,"fixture"),"unbounded stale validity");
        rejects(()->new Duwm1728SceneTimeline.Entry(0,1,"fixture","fixture","gps-inference"),"sensor value relabelled as visual analysis");
        rejects(()->Duwm1728SceneTimeline.fromDescription(-1,"fixture"),"negative model source time");
        rejects(()->Duwm1728SceneTimeline.fromDescription(Long.MAX_VALUE,"fixture"),"source-time overflow");
        rejects(()->Duwm1728SceneTimeline.fromDescription(0," \n\t"),"empty description accepted");
        var words=Duwm1728SceneTimeline.fromDescription(721,"  A tree beside a doorway.  Leaves move. \n");
        check(words.title.equals("A tree beside a doorway."),"headline invented or changed original first sentence");
        check(words.description.equals("A tree beside a doorway. Leaves move."),"description should only normalize supplied text");
        check(words.atMs==721&&words.validUntilMs==721+Duwm1728SceneTimeline.MAX_VALIDITY_MS,"model source timestamp changed");
        check(words.source.equals(Duwm1728SceneTimeline.SOURCE),"model provenance lost");
        check(Duwm1728SceneTimeline.clean("A\u202e B\u0000\nC",64).equals("A B C"),"unsafe invisible control or whitespace retained");
        check(Duwm1728SceneTimeline.clean(null,64).isEmpty(),"null text");
        String family="👨‍👩‍👧‍👦";
        check(Duwm1728SceneTimeline.clean(family,64).equals(family),"family ZWJ sequence changed");
        check(Duwm1728SceneTimeline.clean("A"+family+"Z",8).equals("A…"),"family cluster split at title boundary");
        check(Duwm1728SceneTimeline.clean("e\u0301",64).equals("e\u0301"),"combining mark removed");
        check(Duwm1728SceneTimeline.clean("Ae\u0301Z",3).equals("A…"),"combining cluster split at title boundary");
        check(Duwm1728SceneTimeline.clean("A🇺🇬Z",3).equals("A…"),"regional flag split");
        check(Duwm1728SceneTimeline.clean("A👍🏽Z",3).equals("A…"),"emoji modifier split");
        check(Duwm1728SceneTimeline.clean("A각Z",4).equals("A…"),"Hangul cluster split");
        check(Duwm1728SceneTimeline.clean("ب\u200Cت",64).equals("ب\u200Cت"),"ZWNJ language text changed");
        String emoji="🌍";
        var unicode=Duwm1728SceneTimeline.fromDescription(0,emoji.repeat(500));
        check(unicode.title.codePointCount(0,unicode.title.length())<=Duwm1728SceneTimeline.MAX_TITLE_CODE_POINTS,"title Unicode limit");
        check(unicode.description.codePointCount(0,unicode.description.length())<=Duwm1728SceneTimeline.MAX_DESCRIPTION_CODE_POINTS,"description Unicode limit");
        check(unicode.title.endsWith("…")&&unicode.description.endsWith("…"),"truncation must be visible");
        wellFormed(unicode.title);
        wellFormed(unicode.description);
        String result="{\n  \"schema\":1,\n  \"status\":\"PASS\",\n  \"scope\":\"pure scene time and text policy with synthetic fixtures\",\n  \"checks\":"+checks+",\n  \"model_inference_verified\":false,\n  \"physical_camera_verified\":false,\n  \"native_encoder_verified\":false\n}\n";
        Path output=Path.of(args[0]);Files.createDirectories(output);Files.writeString(output.resolve("SCENE-TIMELINE-HOST.json"),result);
        System.out.print(result);
    }
}
