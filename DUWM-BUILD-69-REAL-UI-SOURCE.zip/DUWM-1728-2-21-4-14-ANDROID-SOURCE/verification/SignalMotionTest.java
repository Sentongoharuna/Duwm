package com.sentongoharuna.worldsituationroom;
import java.util.HashSet;
import java.util.Set;
/** Compiles and executes the REAL production policy, with only the Layer enum isolated. */
public final class SignalMotionTest {
    private static int checks=0;
    static void ok(boolean b,String message){checks++;if(!b)throw new AssertionError(message);}
    static void eq(Object a,Object b,String m){ok(a.equals(b),m+" ["+a+" != "+b+"]");}
    public static void main(String[] args){
        Duwm1724SignalFlow.Stage[] stages=Duwm1724SignalFlow.Stage.values();
        int[] expected={0xffd50000,0xfff57c00,0xfffbc02d,0xff0d47a1,0xff00acc1,0xff00c853,0xff526173,0xff798a9c};
        for(int n=0;n<stages.length;n++){
            Duwm1724SignalFlow.Stage s=stages[n];
            ok(s.color==expected[n],"exact colour "+s);
            Set<Integer> levels=new HashSet<>();float max=0f,min=1f;
            long period=Duwm1728SignalMotion.periodMs(s);
            ok(period>=800L,"blink rate limited "+s);
            for(int k=0;k<120;k++){
                long t=k*period/120;
                float b=Duwm1728SignalMotion.brightness(s,t,0,true);
                max=Math.max(max,b);min=Math.min(min,b);
                ok(b>=.29f&&b<=1f,"bounded level "+s);
                int rgb=Duwm1728SignalMotion.solidColor(s.color,b);levels.add(rgb);
                ok((rgb>>>24)==255,"opaque core "+s);
                ok(((rgb>>16)&255)<=((s.color>>16)&255),"no red whitening "+s);
                ok(((rgb>>8)&255)<=((s.color>>8)&255),"no green whitening "+s);
                ok((rgb&255)<=(s.color&255),"no blue whitening "+s);
                ok(Duwm1728SignalMotion.brightness(s,t,6,false)==1f,"reduced motion remains legible");
            }
            ok(max>.999f,"reaches exact saturated colour "+s);
            if(s.rank>=0){ok(levels.size()>1,"visible animation "+s);ok(max-min>.19f,"visible blink contrast "+s);}
            else ok(levels.size()==1,"unknown and local never fake live "+s);
            if(s==Duwm1724SignalFlow.Stage.OUTAGE)ok((s.color&0xffff)==0,"red has no green/blue contamination");
        }
        for(Duwm1724SignalFlow.Stage s:stages){
            if(s.rank<0)continue;
            boolean differs=false;
            for(int t=0;t<6000;t+=80)if(Math.abs(Duwm1728SignalMotion.brightness(s,t,0,true)-Duwm1728SignalMotion.brightness(s,t,1,true))>.025f)differs=true;
            ok(differs,"independent channel phases "+s);
        }
        long now=1_800_000_000_000L;
        FeedStatus live=new FeedStatus(FeedStatus.State.LIVE,12,"real source",now-1000);
        eq(Duwm1724SignalFlow.fromFeed(live,now,60000,false),Duwm1724SignalFlow.Stage.HEALTHY,"healthy from real timestamp");
        eq(Duwm1724SignalFlow.fromFeed(live,now,60000,true),Duwm1724SignalFlow.Stage.RECEIVING,"new record receipt");
        eq(Duwm1724SignalFlow.fromFeed(live,now+90_000,60000,false),Duwm1724SignalFlow.Stage.AGED,"freshness expires");
        eq(Duwm1724SignalFlow.fromFeed(null,now,60000,true),Duwm1724SignalFlow.Stage.UNKNOWN,"no source cannot blink receiving");
        eq(Duwm1724SignalFlow.fromFeed(new FeedStatus(FeedStatus.State.LIVE,12,"",now+900000),now,60000,true),Duwm1724SignalFlow.Stage.UNKNOWN,"future timestamp rejected");
        eq(Duwm1724SignalFlow.fromFeed(new FeedStatus(FeedStatus.State.LOADING,0,"",now-1000),now,60000,false),Duwm1724SignalFlow.Stage.CONNECTING,"actual request");
        eq(Duwm1724SignalFlow.fromFeed(new FeedStatus(FeedStatus.State.LOADING,0,"",now-200000),now,60000,false),Duwm1724SignalFlow.Stage.DEGRADED,"stuck request degrades");
        eq(Duwm1724SignalFlow.fromFeed(new FeedStatus(FeedStatus.State.OFFLINE,0,"",now),now,60000,true),Duwm1724SignalFlow.Stage.OUTAGE,"failure cannot pretend receipt");
        eq(Duwm1724SignalFlow.fromFeed(new FeedStatus(FeedStatus.State.CACHED,5,"",now),now,60000,true),Duwm1724SignalFlow.Stage.AGED,"cache cannot pretend receipt");
        ok(live.count==12&&live.updatedAtMs==now-1000,"animation leaves input data unchanged");
        System.out.println("PASS "+checks+" executed Java policy/animation assertions (not Android UI/device tests)");
    }
}
