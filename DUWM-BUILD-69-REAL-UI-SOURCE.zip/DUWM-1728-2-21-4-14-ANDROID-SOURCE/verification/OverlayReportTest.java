package com.sentongoharuna.worldsituationroom;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;

/** Executes actual production reportAt/applyMeasurements; no Android stub method is invoked. */
public final class OverlayReportTest {
    private static int checks;
    private static void check(boolean condition,String reason){checks++;if(!condition)throw new AssertionError(reason);}
    private static Duwm1728Measurements.Input input(long at,double heading){
        Duwm1728Measurements.Input in=new Duwm1728Measurements.Input();
        in.sourceMs=at;in.nowElapsedMs=100000;in.utcMs=Instant.parse("2026-11-07T12:00:00Z").toEpochMilli();
        in.recording=true;in.coordinatesAllowed=true;in.locationEnabled=true;in.locationAvailable=true;
        in.fixElapsedMs=in.nowElapsedMs;in.latitude=0.3136;in.longitude=32.5811;in.horizontalAccuracyMeters=4;
        in.locationSource="gps";in.altitudeMeters=1200;in.altitudeReference="MSL";in.verticalAccuracyMeters=3;
        in.headingDegrees=heading;in.headingElapsedMs=in.nowElapsedMs;in.headingAccuracy=3;
        in.previewFps=30;in.fpsElapsedMs=in.nowElapsedMs;in.fpsFrames=61;in.fpsWindowMs=2000;
        return in;
    }
    private static Duwm1728OverlayRenderer.Spec measuredSpec(){
        Duwm1728OverlayRenderer.Spec spec=new Duwm1728OverlayRenderer.Spec();
        spec.clearPicture=true;spec.includeSourceSummary=true;spec.measurementCapture=true;
        spec.includeCoordinates=true;spec.measurementCoordinatesAllowed=true;
        return spec;
    }
    private static Duwm1728BroadcastLayout.Report report(Duwm1728OverlayRenderer.Spec spec,long elapsed){return Duwm1728OverlayRenderer.reportAt(spec,elapsed);}
    private static void emptyMeasurements(Duwm1728BroadcastLayout.Report report,String reason){
        check(report.measuredSummary,reason+": band collapsed");
        check((report.measuredLocation+report.measuredCoordinates+report.measuredAccuracy+report.measuredHeading+report.measuredSpeed
                +report.measuredMovement+report.measuredAltitude+report.measuredFps+report.measuredWeather+report.measuredWeatherProvider
                +report.measuredWeatherDescription+report.measuredWeatherNumbers+report.measuredWeatherTime).isEmpty(),reason+": stale text survived");
        check(Double.isNaN(report.measuredHeadingDegrees),reason+": stale compass vector survived");
    }
    private static void trimSeekAndReplacement(){
        check(!new Duwm1728OverlayRenderer.Spec().clearPicture,"Clear mode changed the existing default");
        Duwm1728OverlayRenderer.Spec spec=measuredSpec();spec.fromMs=10000;
        Duwm1728Measurements.Sample before=Duwm1728Measurements.sample(input(9000,10));
        Duwm1728Measurements.Sample after=Duwm1728Measurements.sample(input(11000,210));
        spec.measurementTrack=Arrays.asList(after,before);
        Duwm1728BroadcastLayout.Report first=report(spec,0);
        check(first.clearPicture&&first.measuredSummary,"Clear flag/summary not propagated");
        check(first.measuredHeadingDegrees==10,"Trim start did not select the actual prior source sample");
        check(first.clock.contains("12:00:01 UTC")&&first.clock.contains("REC 00:00:10"),"Source UTC or recorded time uses export/wall clock");
        check(report(spec,999).measuredHeadingDegrees==10,"Future heading appeared early");
        check(report(spec,1000).measuredHeadingDegrees==210,"New measurement was delayed or interpolated");
        check(report(spec,0).measuredHeadingDegrees==10,"Backward seek retained future values");
        check(first.measuredHeadingDegrees==10,"A later report mutated an earlier rendered snapshot");
        emptyMeasurements(report(spec,4000),"Expired recorded tail");
        spec.fromMs=0;emptyMeasurements(report(spec,8999),"Before first sample");
        spec.measurementTrack=Collections.singletonList(before);
        emptyMeasurements(report(spec,13000),"Sample gap");
        spec.fromMs=-1;emptyMeasurements(report(spec,0),"Invalid source offset");
        spec.fromMs=Long.MAX_VALUE;emptyMeasurements(report(spec,1),"Overflowed source offset");
        spec.fromMs=0;spec.includeSourceSummary=false;
        check(!report(spec,9000).measuredSummary,"Explicitly hidden source summary still occupies a band");
    }
    private static void immediatePrivacyAndExpiry(){
        Duwm1728OverlayRenderer.Spec spec=measuredSpec();spec.fromMs=1000;
        Duwm1728Measurements.Input values=input(1000,90);values.headingElapsedMs=values.nowElapsedMs-2999;
        spec.measurementTrack=Collections.singletonList(Duwm1728Measurements.sample(values));
        Duwm1728BroadcastLayout.Report allowed=report(spec,0);
        check(allowed.coordinatesAllowed&&allowed.measuredCoordinates.contains("0.31360"),"Consenting measured coordinates missing");
        check(allowed.measuredHeadingDegrees==90,"Fresh heading missing");
        check(report(spec,1).measuredHeadingDegrees==90,"Exact freshness boundary expired too soon");
        Duwm1728BroadcastLayout.Report aged=report(spec,2);
        check(Double.isNaN(aged.measuredHeadingDegrees)&&aged.measuredHeading.contains("STALE"),"Expired field remained numerical within active sample");
        spec.includeCoordinates=false;
        Duwm1728BroadcastLayout.Report withheld=report(spec,0);
        check(!withheld.coordinatesAllowed&&withheld.measuredCoordinates.isEmpty(),"Export coordinate consent withdrawal was delayed");
        check(withheld.measuredCoordinateState.contains("WITHHELD"),"Coordinate absence masquerades as a zero reading");
        spec.includeCoordinates=true;spec.measurementCoordinatesAllowed=false;
        check(report(spec,0).measuredCoordinates.isEmpty(),"Capture disclosure gate bypassed");
        spec.measurementCoordinatesAllowed=true;values.coordinatesAllowed=false;
        spec.measurementTrack=Collections.singletonList(Duwm1728Measurements.sample(values));
        check(report(spec,0).measuredCoordinates.isEmpty(),"Per-sample disclosure gate bypassed");
        values.coordinatesAllowed=true;values.locationEnabled=false;
        spec.measurementTrack=Collections.singletonList(Duwm1728Measurements.sample(values));
        Duwm1728BroadcastLayout.Report off=report(spec,0);
        check(!off.measuredCoordinates.contains("0.31360")&&off.measuredCoordinates.contains("OFF"),"Off location retained old exact coordinates");
        Duwm1728BroadcastLayout.Report reused=new Duwm1728BroadcastLayout.Report();
        reused.heading="LEGACY HEADING";reused.weather="LEGACY WEATHER";reused.altitude="LEGACY ALTITUDE";reused.gps="LEGACY GPS";
        Duwm1728OverlayRenderer.applyMeasurements(reused,Duwm1728Measurements.sample(input(1000,180)),1000,true);
        check(reused.measuredHeadingDegrees==180&&reused.heading.isEmpty()&&reused.weather.isEmpty()&&reused.altitude.isEmpty()&&reused.gps.isEmpty(),"Typed adapter leaves legacy fallback values");
        Duwm1728OverlayRenderer.applyMeasurements(reused,null,1001,false);
        emptyMeasurements(reused,"Live missing/reset state");
        check(!reused.coordinatesAllowed&&reused.measuredCoordinateState.isEmpty(),"Reset retains coordinate permission/value state");
    }
    private static void sceneReplacement(){
        Duwm1728OverlayRenderer.Spec spec=measuredSpec();spec.fromMs=10050;spec.automaticSceneTitles=true;
        Duwm1728SceneTimeline.Entry a=new Duwm1728SceneTimeline.Entry(10000,12000,"A tree","A tree in the supplied frame",Duwm1728SceneTimeline.SOURCE);
        Duwm1728SceneTimeline.Entry b=new Duwm1728SceneTimeline.Entry(11000,11500,"A gate","A gate in a later supplied frame",Duwm1728SceneTimeline.SOURCE);
        spec.sceneTrack=Arrays.asList(a,b);
        Duwm1728BroadcastLayout.Report first=report(spec,0);
        check(first.sceneAtMs==0&&first.sceneUntilMs==1950&&first.sceneTitle.equals("A tree"),"Trim did not translate scene bounds exactly once");
        check(Duwm1728BroadcastLayout.currentScene(first,0),"Scene active across trim start disappeared");
        check(report(spec,949).sceneTitle.equals("A tree"),"Future replacement appeared early");
        check(report(spec,950).sceneTitle.equals("A gate"),"Scene replacement was delayed");
        check(report(spec,1450).sceneTitle.isEmpty(),"Expired replacement revived the old scene");
        check(report(spec,0).sceneTitle.equals("A tree"),"Scene lookup retained forward-seek state");
        spec.sceneTrack=Collections.emptyList();
        check(report(spec,0).sceneTitle.isEmpty()&&report(spec,0).sceneDescription.isEmpty(),"Cleared scene track retained model text");
    }
    private static void legacySourceSamples(){
        Duwm1728OverlayRenderer.Spec spec=new Duwm1728OverlayRenderer.Spec();spec.fromMs=2000;spec.includeSourceSummary=true;spec.includeCoordinates=true;
        Duwm1728CaptureTelemetry.Snapshot point=new Duwm1728CaptureTelemetry.Snapshot(1794052800000L,"045 MAG","1200 m","4 m","Recorded weather text","0.3,32.5",true);
        spec.recordedTrack=Collections.singletonList(new Duwm1728TelemetryTimeline.Point(1000,point));
        spec.capturedTelemetry=new Duwm1728CaptureTelemetry.Snapshot(1794052860000L,"END SECRET","END SECRET","END SECRET","END SECRET","END SECRET",true);
        Duwm1728BroadcastLayout.Report legacy=report(spec,0);
        check(!legacy.clearPicture&&!legacy.measuredSummary&&legacy.heading.equals("045 MAG")&&legacy.altitude.equals("1200 m")&&legacy.gps.equals("0.3,32.5"),"False-mode legacy presentation changed");
        spec.clearPicture=true;
        Duwm1728BroadcastLayout.Report clear=report(spec,0);
        check(clear.measuredSummary&&clear.measuredHeading.equals("DEVICE HDG 045 MAG"),"Clear mode hid or relabelled old device heading as camera heading");
        check(clear.measuredAltitude.equals("ALT 1200 m")&&clear.measuredAccuracy.equals("ACC 4 m"),"Clear mode hid actual old altitude/accuracy");
        check(clear.measuredCoordinates.equals("LAT/LON 0.3,32.5")&&clear.clock.startsWith("SAMPLE UTC"),"Old source sample lost coordinate/time labels");
        check(clear.measuredWeather.equals("Recorded weather text")&&clear.measuredWeatherProvider.isEmpty()&&clear.measuredFps.isEmpty()&&Double.isNaN(clear.measuredHeadingDegrees),"Old strings manufactured typed model weather/FPS/heading");
        spec.includeCoordinates=false;
        check(report(spec,0).measuredCoordinates.isEmpty()&&!report(spec,0).coordinatesAllowed,"Old sample bypasses independent export consent");
        spec.includeCoordinates=true;
        spec.recordedTrack=Collections.singletonList(new Duwm1728TelemetryTimeline.Point(1000,new Duwm1728CaptureTelemetry.Snapshot(1794052800000L,"045 MAG","1200 m","4 m","Recorded weather text","SECRET",false)));
        check(report(spec,0).measuredCoordinates.isEmpty(),"Old sample bypasses capture consent");
        emptyMeasurements(report(spec,2000),"Legacy 3-second expiry");
        spec.fromMs=0;emptyMeasurements(report(spec,999),"Legacy future sample");
        spec.recordedTrack=Collections.emptyList();emptyMeasurements(report(spec,1000),"Capture-end snapshot is not a timeline");
        spec.includeSourceSummary=false;check(!report(spec,1000).measuredSummary,"Legacy explicit summary-off ignored");
    }
    public static void main(String[] args)throws Exception{
        trimSeekAndReplacement();immediatePrivacyAndExpiry();sceneReplacement();legacySourceSamples();
        String androidHash=java.util.HexFormat.of().formatHex(java.security.MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(Path.of(args[1]))));
        String result="{\n  \"schema\":1,\n  \"status\":\"PASS\",\n  \"scope\":\"REAL_OVERLAY_REPORT_ADAPTER_WITH_SYNTHETIC_RECORDED_INPUTS\",\n  \"checks\":"+checks+",\n  \"android_jar_sha256\":\""+androidHash+"\",\n  \"official_android_api_compile\":true,\n  \"android_runtime_methods_executed\":false,\n  \"native_encoder_verified\":false,\n  \"model_inference_executed\":false,\n  \"physical_sensors_executed\":false\n}\n";
        Path output=Path.of(args[0]);Files.createDirectories(output);Files.writeString(output.resolve("OVERLAY-REPORT-HOST.json"),result);System.out.print(result);
    }
}
