"""Flexible release identity and explicit visible-layout revision, without a frozen globe SHA."""
from pathlib import Path
import json,re,xml.etree.ElementTree as ET

def assert_release_at_least(project: Path, minimum: int):
    build=(project/'app/build.gradle.kts').read_text()
    code=re.search(r'versionCode\s*=\s*(\d+)',build)
    label=re.search(r'versionName\s*=\s*"([^"]+)"',build)
    assert code and label, 'Version identity missing'
    code=int(code.group(1))
    assert code>=minimum*100, (code,minimum)
    name=label.group(1)
    phase=re.fullmatch(r"1728\.2\.([1-9][0-9]?)",name)
    revisions = {'1728.2.21.1': 172822, '1728.2.21.2': 172823, '1728.2.21.3': 172824}
    if name in revisions:
        assert code == revisions[name], '1728.2/21 subrelease must embed its declared installable version code'
    elif phase:
        assert code==172800+int(phase.group(1)), '1728.2/N must embed code 172800 + N' 
    else:
        assert name==str(code//100), 'Version name and code mismatch' 
    # Future versions may rewrite the entire globe without satisfying historic appearance checks.
    current=project/'app/src/main/assets/duwm_release_ui.json'
    if current.is_file():
        data=json.loads(current.read_text())
        assert data['uiRevision']==label.group(1), 'Visible UI revision must match app release'
        launcher=data.get('launchActivity','')
        assert launcher and re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*',launcher), 'Invalid launcher class name'
        java=project/'app/src/main/java/com/sentongoharuna/worldsituationroom'/f'{launcher}.java'
        assert java.is_file(), 'Declared launcher must have real Android source'
        manifest=ET.parse(project/'app/src/main/AndroidManifest.xml').getroot()
        ns='{http://schemas.android.com/apk/res/android}'
        actual=[]
        for activity in manifest.iter('activity'):
            for intent in activity.findall('intent-filter'):
                actions={x.get(ns+'name') for x in intent.findall('action')}
                categories={x.get(ns+'name') for x in intent.findall('category')}
                if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in categories:
                    actual.append(activity.get(ns+'name','').lstrip('.'))
        assert actual==[launcher], ('Launcher must match actual manifest, not any historic naming convention',actual,launcher)
    return code
