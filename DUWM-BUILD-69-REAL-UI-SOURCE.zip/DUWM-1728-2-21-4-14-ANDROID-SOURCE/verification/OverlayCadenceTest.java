package com.sentongoharuna.worldsituationroom;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

/** Synthetic clocks exercise the production cadence and source-time policy. */
public final class OverlayCadenceTest {
    private static int checks;
    private static void check(boolean condition,String reason){checks++;if(!condition)throw new AssertionError(reason);}
    private static void equal(long actual,long expected,String reason){check(actual==expected,reason+": "+actual+" != "+expected);}
    private static Duwm1728SceneTimeline.Entry scene(long start,long end,String title){
        return new Duwm1728SceneTimeline.Entry(start,end,title,title+" in a supplied test frame",Duwm1728SceneTimeline.SOURCE);
    }
    private static Duwm1728Measurements.Input input(long source){
        Duwm1728Measurements.Input in=new Duwm1728Measurements.Input();
        in.nowElapsedMs=100000;in.sourceMs=source;in.utcMs=1794052800000L+source%1000;in.recording=true;
        return in;
    }
    private static void advancingClock(){
        Duwm1728OverlayCadence clock=new Duwm1728OverlayCadence();
        equal(clock.sourceAt(10000),-1,"Unstarted clock invented a source instant");
        check(!clock.update(1000,10000),"First anchor spuriously reports a reset");
        equal(clock.sourceAt(10300),1300,"Source time froze without a producer callback");
        check(!clock.update(1000,10700),"Same-source callback spuriously resets session");
        equal(clock.sourceAt(11000),2000,"Repeated callback extended source lifetime");
        check(!clock.update(2000,11000),"Forward source anchor resets session");
        equal(clock.sourceAt(11400),2400,"Forward source anchor failed");
        check(clock.update(100,12000),"Source rewind did not request clearing old data");
        equal(clock.sourceAt(12200),300,"Rewound source inherited the previous time axis");
        equal(clock.sourceAt(11999),-1,"Elapsed-clock rollback invented a valid source instant");
        check(clock.update(200,11990),"Elapsed-clock rollback did not request clearing old data");
        equal(clock.sourceAt(12000),210,"Clock rollback did not install the new anchor");
        clock.reset();equal(clock.sourceAt(13000),-1,"Reset retained previous clock");
        check(!clock.update(0,0),"Zero is not accepted as a real source/elapsed anchor");
        equal(clock.sourceAt(1),1,"Zero clock does not advance");
        check(clock.update(-1,100),"Negative source must reset state");
        equal(clock.sourceAt(200),-1,"Invalid-source reset retained data");
        check(clock.update(1,-1),"Negative elapsed clock must reset state");
        clock.update(Long.MAX_VALUE-1,0);
        equal(clock.sourceAt(1),Long.MAX_VALUE,"Safe maximum source time changed");
        equal(clock.sourceAt(2),-1,"Source clock overflow wrapped into another session");
    }
    private static void sourceMapping(){
        equal(Duwm1728OverlayCadence.sourceTime(0,0),0,"First output frame");
        equal(Duwm1728OverlayCadence.sourceTime(5000,600),5600,"Trim offset applied incorrectly");
        equal(Duwm1728OverlayCadence.sourceTime(-1,100),-1,"Negative trim accepted");
        equal(Duwm1728OverlayCadence.sourceTime(100,-1),-1,"Negative output position accepted");
        equal(Duwm1728OverlayCadence.sourceTime(Long.MAX_VALUE,0),Long.MAX_VALUE,"Representable source boundary rejected");
        equal(Duwm1728OverlayCadence.sourceTime(Long.MAX_VALUE,1),-1,"Trim overflow accepted");
        Duwm1728SceneTimeline.Entry first=scene(100,2000,"First scene"),second=scene(5000,6000,"Second scene");
        check(Duwm1728SceneTimeline.at(Arrays.asList(first,second),Duwm1728OverlayCadence.sourceTime(4500,600))==second,"Trim used output time for scene selection");
        check(Duwm1728SceneTimeline.at(Arrays.asList(first,second),Duwm1728OverlayCadence.sourceTime(4500,499))==null,"Future scene leaked before its frame");
        check(Duwm1728SceneTimeline.at(Arrays.asList(first,second),Duwm1728OverlayCadence.sourceTime(4500,1500))==null,"Expired scene held at trim boundary");
        check(Duwm1728SceneTimeline.at(Arrays.asList(first,second),Duwm1728OverlayCadence.sourceTime(0,100))==first,"Backward seek retained later scene");
    }
    private static void deadlines(){
        equal(Duwm1728OverlayCadence.nextDelayMs(-1,null,null),-1,"Invalid clock scheduled a redraw");
        equal(Duwm1728OverlayCadence.nextDelayMs(0,null,null),-1,"No data started an endless timer");
        Duwm1728SceneTimeline.Entry observed=scene(100,3500,"A tree");
        equal(Duwm1728OverlayCadence.nextDelayMs(50,observed,null),50,"Scene start deadline skipped");
        equal(Duwm1728OverlayCadence.nextDelayMs(100,observed,null),3400,"Static scene redraws at frame rate");
        equal(Duwm1728OverlayCadence.nextDelayMs(3499,observed,null),1,"Last scene millisecond not scheduled");
        equal(Duwm1728OverlayCadence.nextDelayMs(3500,observed,null),-1,"Expired scene continued redrawing");
        Duwm1728Measurements.Sample sample=Duwm1728Measurements.sample(input(1250));
        equal(Duwm1728OverlayCadence.nextDelayMs(1000,null,sample),250,"Future sample deadline skipped");
        equal(Duwm1728OverlayCadence.nextDelayMs(1250,null,sample),750,"Recorded clock second not scheduled");
        equal(Duwm1728OverlayCadence.nextDelayMs(2000,null,sample),1000,"Static missing fields introduced a rapid redraw loop");
        equal(Duwm1728OverlayCadence.nextDelayMs(4249,null,sample),1,"Sample end deadline missed");
        equal(Duwm1728OverlayCadence.nextDelayMs(4250,null,sample),-1,"Expired sample kept polling");
        equal(Duwm1728OverlayCadence.nextDelayMs(1300,scene(1000,1400,"Changed scene"),sample),100,"Nearest independent deadline not selected");
        Duwm1728Measurements.Input heading=input(1250);
        heading.headingDegrees=90;heading.headingElapsedMs=heading.nowElapsedMs-2899;heading.headingAccuracy=3;
        sample=Duwm1728Measurements.sample(heading);
        equal(Duwm1728OverlayCadence.nextDelayMs(1300,null,sample),52,"Per-field expiry waits for a later sample/second");
        check(Duwm1728Measurements.display(sample,1351,false).headingAvailable,"Exact heading age limit expired early");
        equal(Duwm1728OverlayCadence.nextDelayMs(1351,null,sample),1,"Exact heading limit lacks removal deadline");
        check(!Duwm1728Measurements.display(sample,1352,false).headingAvailable,"Heading survived after freshness limit");
        equal(Duwm1728OverlayCadence.nextDelayMs(1352,null,sample),648,"Expired reading caused a zero-delay loop");
        heading.headingAccuracy=0;sample=Duwm1728Measurements.sample(heading);
        equal(Duwm1728OverlayCadence.nextDelayMs(1300,null,sample),52,"Unreliable reading state did not age to stale");
        heading.headingElapsedMs=heading.nowElapsedMs-3001;sample=Duwm1728Measurements.sample(heading);
        equal(Duwm1728OverlayCadence.nextDelayMs(1300,null,sample),700,"Already-stale field retained a past deadline");
        Duwm1728Measurements.Input gps=input(1250);
        gps.locationEnabled=gps.locationAvailable=true;gps.latitude=0.3;gps.longitude=32.5;gps.horizontalAccuracyMeters=3;
        gps.fixElapsedMs=gps.nowElapsedMs-29950;sample=Duwm1728Measurements.sample(gps);
        equal(Duwm1728OverlayCadence.nextDelayMs(1300,null,sample),1,"Location freshness not scheduled independently of sample age");
        equal(Duwm1728OverlayCadence.nextDelayMs(9000,observed,sample),-1,"Finished data retained refresh work");
    }
    private static void stoppedCallbacks(){
        Duwm1728OverlayCadence clock=new Duwm1728OverlayCadence();clock.update(1000,10000);
        Duwm1728Measurements.Input in=input(1000);in.headingDegrees=45;in.headingElapsedMs=in.nowElapsedMs;in.headingAccuracy=3;
        Duwm1728Measurements.Sample sample=Duwm1728Measurements.sample(in);
        Duwm1728SceneTimeline.Entry observed=scene(1000,5500,"A building");
        check(Duwm1728Measurements.display(sample,clock.sourceAt(12999),false).hasSample,"Current sample vanished early");
        check(!Duwm1728Measurements.display(sample,clock.sourceAt(13000),false).hasSample,"Stopped callback preserved sample beyond its interval");
        equal(Duwm1728OverlayCadence.nextDelayMs(clock.sourceAt(13000),observed,sample),1500,"Expired sensors obscured remaining scene deadline");
        check(Duwm1728SceneTimeline.at(Arrays.asList(observed),clock.sourceAt(14500))==null,"Stopped callback held expired scene");
        equal(Duwm1728OverlayCadence.nextDelayMs(clock.sourceAt(14500),observed,sample),-1,"Completed display never goes idle");
    }
    private static void differentClockAnchors(){
        Duwm1728Measurements.Input in=input(1250);in.utcMs=1794052800990L;
        Duwm1728Measurements.Sample sample=Duwm1728Measurements.sample(in);
        equal(Duwm1728OverlayCadence.nextDelayMs(1250,null,sample),10,"UTC second waited for recorded elapsed second");
        String before=Duwm1728Measurements.display(sample,1259,false).time;
        String after=Duwm1728Measurements.display(sample,1260,false).time;
        check(before.contains(":00 UTC")&&after.contains(":01 UTC"),"Fixture did not cross the actual displayed UTC second");
        equal(Duwm1728OverlayCadence.nextDelayMs(1260,null,sample),740,"UTC tick lost the next recorded second");
        in.utcMs=-1;sample=Duwm1728Measurements.sample(in);
        equal(Duwm1728OverlayCadence.nextDelayMs(1250,null,sample),750,"Invalid UTC supplied a false deadline");
        in.utcMs=0;sample=Duwm1728Measurements.sample(in);
        equal(Duwm1728OverlayCadence.nextDelayMs(1250,null,sample),750,"Absent UTC zero supplied a false deadline");
        in.utcMs=Long.MAX_VALUE-2;sample=Duwm1728Measurements.sample(in);
        equal(Duwm1728OverlayCadence.nextDelayMs(1250,null,sample),3,"UTC overflow removal not scheduled safely");
        equal(Duwm1728OverlayCadence.nextDelayMs(1253,null,sample),747,"Already-overflowed UTC produced a loop");
        check(Duwm1728Measurements.display(sample,1253,false).time.contains("UTC UNAVAILABLE"),"Overflowed UTC displayed a fabricated date");
    }
    private static void deadlinesCrossedWhileDrawing(){
        Duwm1728SceneTimeline.Entry scene=scene(100,3500,"A tree");
        equal(Duwm1728OverlayCadence.nextDelayAfterRenderMs(3499,3504,scene,null),1,"Draw crossed final scene expiry without arranging removal");
        equal(Duwm1728OverlayCadence.nextDelayAfterRenderMs(100,125,scene,null),3375,"Render time was added to scene validity");
        equal(Duwm1728OverlayCadence.nextDelayAfterRenderMs(3500,3510,scene,null),-1,"Already-cleared scene introduced polling");
        Duwm1728Measurements.Sample sample=Duwm1728Measurements.sample(input(1250));
        equal(Duwm1728OverlayCadence.nextDelayAfterRenderMs(4249,4260,null,sample),1,"Draw crossed final sample expiry without arranging removal");
        equal(Duwm1728OverlayCadence.nextDelayAfterRenderMs(1999,2005,null,sample),1,"Draw crossed clock second without arranging refresh");
        equal(Duwm1728OverlayCadence.nextDelayAfterRenderMs(2000,2010,null,sample),990,"Rendered clock duration extends refresh cadence");
        equal(Duwm1728OverlayCadence.nextDelayAfterRenderMs(4250,4260,null,sample),-1,"Already-cleared measurements introduced polling");
        equal(Duwm1728OverlayCadence.nextDelayAfterRenderMs(4000,0,null,sample),1,"Rewound session left old frame on screen");
        equal(Duwm1728OverlayCadence.nextDelayAfterRenderMs(100,-1,scene,sample),-1,"Invalid current clock scheduled work");
    }
    public static void main(String[] args)throws Exception{
        advancingClock();sourceMapping();deadlines();stoppedCallbacks();differentClockAnchors();deadlinesCrossedWhileDrawing();
        String result="{\n  \"schema\":1,\n  \"status\":\"PASS\",\n  \"scope\":\"REAL_PURE_OVERLAY_CADENCE_WITH_SYNTHETIC_CLOCKS_AND_MEASUREMENTS\",\n  \"checks\":"+checks+",\n  \"android_view_lifecycle_executed\":false,\n  \"native_encoder_verified\":false,\n  \"model_inference_executed\":false,\n  \"physical_sensors_executed\":false\n}\n";
        Path output=Path.of(args[0]);Files.createDirectories(output);Files.writeString(output.resolve("OVERLAY-CADENCE-HOST.json"),result);System.out.print(result);
    }
}
