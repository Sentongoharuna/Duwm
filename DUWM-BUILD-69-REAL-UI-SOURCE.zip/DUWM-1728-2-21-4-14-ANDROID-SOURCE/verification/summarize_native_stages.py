#!/usr/bin/env python3
"""Report every native stage after execution; the strict evidence gate is separate."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from verify_native_stages import STAGES


def collect(directory: Path) -> dict:
    rows = []
    for stage in STAGES:
        path = directory / 'native-stage-proof' / stage / 'RESULT.json'
        row = {'stage': stage, 'status': 'MISSING', 'checks': 0,
               'failure': 'No native stage result was collected.'}
        if path.is_file():
            try:
                result = json.loads(path.read_text())
                if not isinstance(result, dict) or result.get('stage') != stage:
                    raise ValueError('Result stage does not match its directory.')
                if result.get('status') not in {'PASS', 'FAIL'}:
                    raise ValueError('Result does not declare PASS or FAIL.')
                checks = result.get('checks')
                if type(checks) is not int or checks < 0:
                    raise ValueError('Result check count is invalid.')
                row.update(status=result['status'], checks=checks,
                           failure=str(result.get('failure') or ''))
                if row['status'] == 'FAIL' and not row['failure']:
                    row['failure'] = 'Stage failed; inspect its instrumentation log.'
            except (OSError, ValueError, TypeError) as error:
                row.update(status='INVALID', failure=str(error))
        rows.append(row)
    counts = {state: sum(row['status'] == state for row in rows)
              for state in ('PASS', 'FAIL', 'MISSING', 'INVALID')}
    return {'schema': 1, 'status': 'PASS' if counts['PASS'] == len(STAGES) else 'FAIL',
            'scope': 'Collected native stage reports; does not replace strict APK/evidence verification.',
            'required_stages': len(STAGES), 'counts': counts, 'stages': rows,
            'physical_camera_verified': False, 'physical_sensor_verified': False,
            'model_inference_verified': False}


def first_line(value: str) -> str:
    return (value.splitlines() or [''])[0][:360]


def markdown(report: dict) -> str:
    counts = report['counts']
    lines = ['## Native stage results', '',
             f"{counts['PASS']}/{report['required_stages']} reported PASS; "
             f"{counts['FAIL']} failed, {counts['MISSING']} missing, {counts['INVALID']} invalid.",
             '', '| Stage | Result | Checks | First error |', '|---|---|---:|---|']
    for row in report['stages']:
        detail = first_line(row['failure']).replace('|', '\\|').replace('`', "'")
        lines.append(f"| {row['stage']} | {row['status']} | {row['checks']} | {detail} |")
    lines += ['', 'These are collected stage reports. The separate APK and evidence gate remains required.',
              'Synthetic native fixtures do not verify a physical camera, physical sensors or model inference.', '']
    return '\n'.join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    args = parser.parse_args()
    args.directory.mkdir(parents=True, exist_ok=True)
    report = collect(args.directory)
    rendered = markdown(report)
    (args.directory / 'NATIVE-STAGE-SUMMARY.json').write_text(json.dumps(report, indent=2) + '\n')
    (args.directory / 'NATIVE-STAGE-SUMMARY.md').write_text(rendered)
    summary_path = os.environ.get('GITHUB_STEP_SUMMARY')
    if summary_path:
        with Path(summary_path).open('a') as stream:
            stream.write(rendered)
    print(rendered)
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
