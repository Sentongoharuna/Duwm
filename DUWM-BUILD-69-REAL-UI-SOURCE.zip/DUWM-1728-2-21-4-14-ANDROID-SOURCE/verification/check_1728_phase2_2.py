from pathlib import Path
p=Path(__file__).resolve().parents[1]
j=p/'app/src/main/java/com/sentongoharuna/worldsituationroom'
ed=(j/'Duwm1728VideoEditorActivity.java').read_text()
render=(j/'Duwm1728OverlayRenderer.java').read_text()
cam=(j/'Duwm1718MonitorsCamActivity.java').read_text()
prov=(j/'Duwm1728CaptureTelemetry.java').read_text()
for token in ['provenance=Duwm1728CaptureTelemetry.load','TIMED SUBTITLES','preciseExport.setChecked(false)','spec.captions=','spec.includeCoordinates=','spec.includeSourceSummary=']:
    assert token in ed,token
for token in ['spec.captionCues=Duwm1728TickerTimeline.parse','NOT LIVE','REPORTER CAPTION','!spec.captionCues.isEmpty()','No consenting captured coordinate source']:
    assert token in render,token
for token in ['captureEnd=new Duwm1728CaptureTelemetry.Snapshot','Duwm1728CaptureTelemetry.save','bakedPrecise','sourceWeather()']:
    assert token in cam,token
for token in ['getSharedPreferences','SHA-256','preciseEnabled&&exportPermission','capturedUtcMs','WITHHELD']:
    assert token in prov,token
assert 'SatelliteMapView' in (j/'MainActivity.java').read_text()
print('PASS 1728.2/2 captured provenance, opt-in precision, timed reporter captions, source labels and unchanged globe')
