#!/usr/bin/env bash
set -euo pipefail
cadence_project="$(cd "$(dirname "$0")/.." && pwd)"
cadence_output="${1:-$cadence_project/artifacts/overlay-cadence-host}"
cadence_build="$(mktemp -d)"
trap 'rm -rf "$cadence_build"' EXIT
cadence_javac="${JAVAC:-${JAVA_HOME:+$JAVA_HOME/bin/}javac}"
cadence_java="${JAVA:-${JAVA_HOME:+$JAVA_HOME/bin/}java}"
cadence_source="$cadence_project/app/src/main/java/com/sentongoharuna/worldsituationroom"
"$cadence_javac" --release 17 -encoding UTF-8 -d "$cadence_build" \
  "$cadence_source/Duwm1728SceneTimeline.java" \
  "$cadence_source/Duwm1728MeasurementMath.java" \
  "$cadence_source/Duwm1728Measurements.java" \
  "$cadence_source/Duwm1728OverlayCadence.java" \
  "$cadence_project/verification/OverlayCadenceTest.java"
"$cadence_java" -cp "$cadence_build" com.sentongoharuna.worldsituationroom.OverlayCadenceTest "$cadence_output"
