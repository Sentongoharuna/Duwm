#!/usr/bin/env bash
# Fail on real compiler errors, keep complete logs, and surface the first errors.
set -euo pipefail
cd "$(cd "$(dirname "$0")/.." && pwd)"
stage="${1:-assemble}"
case "$stage" in
  typecheck) tasks=(:app:compileDebugJavaWithJavac);;
  assemble) tasks=(:app:assembleDebug :app:assembleDebugAndroidTest);;
  *) echo "Unknown build stage: $stage" >&2; exit 2;;
esac
log_dir="${BUILD_LOG_DIR:-$PWD/verification/results/android-build}"
mkdir -p "$log_dir"
log_file="$log_dir/gradle-$stage.log"
set +e
gradle --no-daemon --no-configuration-cache --console=plain "${tasks[@]}" --stacktrace 2>&1 | tee "$log_file"
statuses=("${PIPESTATUS[@]}")
set -e
code="${statuses[0]}"
if [ "$code" -eq 0 ] && [ "${statuses[1]}" -ne 0 ]; then code="${statuses[1]}"; fi
python3 verification/summarize_android_build.py "$stage" "$code" "$log_file"
exit "$code"
