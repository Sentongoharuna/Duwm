#!/usr/bin/env bash
set -euo pipefail
measured_project="$(cd "$(dirname "$0")/.." && pwd)"
measured_proof="${1:-$measured_project/verification/measured-layout-host-proof}"
measured_javac="${JAVAC:-${JAVA_HOME:+$JAVA_HOME/bin/}javac}"
measured_java="${JAVA:-${JAVA_HOME:+$JAVA_HOME/bin/}java}"
measured_build="$(mktemp -d "${TMPDIR:-/tmp}/duwm-measured-layout.XXXXXX")"
trap 'rm -rf -- "$measured_build"' EXIT
measured_source="$measured_project/app/src/main/java/com/sentongoharuna/worldsituationroom"
"$measured_javac" --release 17 -encoding UTF-8 -d "$measured_build" \
  "$measured_source/Duwm1728BroadcastComposition.java" "$measured_source/Duwm1728BroadcastLayout.java" "$measured_source/Duwm1728ClearPictureLayout.java" \
  "$measured_source/Duwm1728HeadlineFit.java" "$measured_source/Duwm1728CaptionPages.java" \
  "$measured_source/Duwm1728Measurements.java" "$measured_source/Duwm1728MeasurementMath.java" \
  "$measured_project/verification/broadcast/BroadcastRenderTest.java" "$measured_project/verification/broadcast/MeasuredLayoutTest.java"
"$measured_java" -Xmx512m -Djava.awt.headless=true -cp "$measured_build" \
  com.sentongoharuna.worldsituationroom.MeasuredLayoutTest "$measured_proof"
