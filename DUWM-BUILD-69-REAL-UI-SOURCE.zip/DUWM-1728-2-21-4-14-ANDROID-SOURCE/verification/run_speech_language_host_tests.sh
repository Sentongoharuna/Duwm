#!/usr/bin/env bash
set -euo pipefail
speech_project="$(cd "$(dirname "$0")/.." && pwd)"
speech_proof="${1:-$speech_project/verification/results/1728_2_20/speech-language}"
speech_javac="${JAVAC:-${JAVA_HOME:+$JAVA_HOME/bin/}javac}"
speech_java="${JAVA:-${JAVA_HOME:+$JAVA_HOME/bin/}java}"
speech_build="$(mktemp -d "${TMPDIR:-/tmp}/duwm-speech-language.XXXXXX")"
trap 'rm -rf -- "$speech_build"' EXIT
speech_source="$speech_project/app/src/main/java/com/sentongoharuna/worldsituationroom"
"$speech_javac" --release 17 -encoding UTF-8 -d "$speech_build" \
  "$speech_source/Duwm1728SpeechLanguagePolicy.java" \
  "$speech_project/verification/broadcast/SpeechLanguagePolicyTest.java"
"$speech_java" -Xmx512m -Djava.awt.headless=true -cp "$speech_build" \
  com.sentongoharuna.worldsituationroom.SpeechLanguagePolicyTest "$speech_proof"
