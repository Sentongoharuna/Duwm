package com.sentongoharuna.worldsituationroom;
/** Exhaustive pure-Java policy tests. No phone, HTTP request or model inference. */
public final class AiStartPolicyTest {
    public static void main(String[] args){
        int checked=0,allowed=0;
        for(int bits=0;bits<128;bits++){
            boolean clean=(bits&1)!=0,empty=(bits&2)!=0,optIn=(bits&4)!=0,
                configured=(bits&8)!=0,closing=(bits&16)!=0,
                exporting=(bits&32)!=0,inFlight=(bits&64)!=0;
            boolean actual=Duwm1728AiStartPolicy.allowAutomatic(clean,empty,optIn,configured,closing,exporting,inFlight);
            // Exactly one admitted state: bits 0..3 set, all busy/closing flags clear.
            boolean expected=bits==15;
            if(actual!=expected)throw new AssertionError("State "+bits+" allowed="+actual);
            if(actual)allowed++;
            checked++;
        }
        if(allowed!=1)throw new AssertionError("Admission matrix wrong");
        System.out.println("PASS "+checked+" exhaustive AI admission states; no upload without opt-in/configuration, no duplicate/busy/closing start. Not an Android runtime test.");
    }
}
