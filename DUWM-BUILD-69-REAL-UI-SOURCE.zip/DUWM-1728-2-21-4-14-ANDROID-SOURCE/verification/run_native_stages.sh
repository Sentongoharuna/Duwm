#!/usr/bin/env bash
# A stage failure never becomes a full pass. Collect each result before moving on.
set -euo pipefail
app_apk="${1:?application APK required}"
test_apk="${2:?instrumentation APK required}"
evidence="${3:-native-evidence}"
if [ -n "${4:-}" ]; then
  run_id="$4"
elif [ -n "${GITHUB_RUN_ID:-}" ]; then
  run_id="duwm21-4-${GITHUB_RUN_ID}-${GITHUB_RUN_ATTEMPT:-1}"
else
  run_id="duwm21-4-local-$(python3 -c 'import uuid; print(uuid.uuid4().hex)')"
fi
helper="$(cd "$(dirname "$0")" && pwd)/verify_native_stages.py"
pkg=com.sentongoharuna.worldsituationroom.rb2live25
mkdir -p "$evidence"
current_stage=preparation
transport_failed=0
collect() {
  adb logcat -d -s AndroidRuntime:E > "$evidence/ANDROID-RUNTIME-$current_stage.txt" || true
  adb logcat -b crash -d > "$evidence/CRASH-BUFFER-$current_stage.txt" || true
  adb shell dumpsys activity exit-info "$pkg" > "$evidence/EXIT-REASONS-$current_stage.txt" || true
  # Never retain old host proof if this collection fails or is incomplete.
  rm -rf -- "$evidence/native-stage-proof"
  adb exec-out run-as "$pkg" tar -C files -cf - native-stage-proof > "$evidence/proof.tar" 2> "$evidence/PROOF-COLLECT-$current_stage.txt" || true
  if tar -tf "$evidence/proof.tar" >/dev/null 2>&1; then
    tar -xf "$evidence/proof.tar" -C "$evidence"
  fi
}
trap collect EXIT
adb install -r "$app_apk"
adb install -r "$test_apk"
# Scope removal to this test's private proof folder on the installed app.
adb shell run-as "$pkg" rm -rf files/native-stage-proof
adb logcat -c
for stage in signals graphics exports4 framing inset1 editor_controls review review_controls recovery composition caption_editing caption_files automatic_production automatic_report automatic_ready automatic_fit scene_timeline measured_telemetry clear_picture automatic_finish; do
  current_stage="$stage"
  set +e
  timeout 1500 adb shell am instrument -w -r -e stage "$stage" -e run_id "$run_id" \
    "$pkg.test/com.sentongoharuna.worldsituationroom.DuwmSignalInstrumentation" \
    > "$evidence/INSTRUMENTATION-$stage.txt" 2>&1
  stage_code=$?
  set -e
  printf '%s\n' "$stage_code" > "$evidence/RETURN-CODE-$stage.txt"
  cat "$evidence/INSTRUMENTATION-$stage.txt"
  if [ "$stage_code" -ne 0 ]; then transport_failed=1; fi
  if [ "$stage_code" -eq 124 ] || [ "$stage_code" -eq 137 ]; then
    adb shell am force-stop "$pkg" || true
  fi
  collect
done
set +e
python3 "$helper" "$evidence/native-stage-proof" --app-apk "$app_apk" \
  --test-apk "$test_apk" --run-id "$run_id" --logs-dir "$evidence" \
  > "$evidence/NATIVE-GATE.txt" 2>&1
gate_code=$?
set -e
cat "$evidence/NATIVE-GATE.txt"
trap - EXIT
if [ "$transport_failed" -ne 0 ]; then exit 1; fi
exit "$gate_code"
