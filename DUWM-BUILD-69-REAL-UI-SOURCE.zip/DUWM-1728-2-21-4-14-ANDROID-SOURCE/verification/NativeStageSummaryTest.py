#!/usr/bin/env python3
"""Check complete failure reporting without changing the strict native gate."""
from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile
import unittest

from summarize_native_stages import STAGES, collect, markdown

ROOT = Path(__file__).resolve().parent


class NativeStageSummaryTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='duwm-native-summary-')
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def write(self, stage, value):
        path = self.root / 'native-stage-proof' / stage / 'RESULT.json'
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value))
        return path

    def passing(self):
        for stage in STAGES:
            self.write(stage, {'stage': stage, 'status': 'PASS', 'checks': 10})

    def test_observed_five_failures_are_all_visible(self):
        fixture = json.loads((ROOT / 'fixtures/native_repair1_results.json').read_text())
        for row in fixture['results']:
            self.write(row['stage'], row)
        report = collect(self.root)
        self.assertEqual(report['status'], 'FAIL')
        self.assertEqual(report['counts'], {'PASS': 14, 'FAIL': 5, 'MISSING': 0, 'INVALID': 0})
        failures = {row['stage']: row['failure'] for row in report['stages'] if row['status'] == 'FAIL'}
        self.assertEqual(set(failures), {'review', 'automatic_fit', 'scene_timeline', 'measured_telemetry', 'clear_picture'})
        self.assertIn('SecurityException', failures['review'])
        text = markdown(report)
        for stage in failures:
            self.assertIn('| ' + stage + ' | FAIL |', text)

    def test_all_pass_cli_writes_summary_and_succeeds(self):
        self.passing()
        summary = self.root / 'github-summary.md'
        run = subprocess.run([sys.executable, str(ROOT / 'summarize_native_stages.py'), str(self.root)],
                             env=dict(os.environ, GITHUB_STEP_SUMMARY=str(summary)), capture_output=True, text=True)
        self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
        self.assertEqual(json.loads((self.root / 'NATIVE-STAGE-SUMMARY.json').read_text())['counts']['PASS'], 19)
        self.assertEqual(summary.read_text(), (self.root / 'NATIVE-STAGE-SUMMARY.md').read_text())

    def test_missing_stage_fails_cli_and_is_reported(self):
        self.passing()
        (self.root / 'native-stage-proof/review/RESULT.json').unlink()
        run = subprocess.run([sys.executable, str(ROOT / 'summarize_native_stages.py'), str(self.root)],
                             capture_output=True, text=True)
        self.assertEqual(run.returncode, 1)
        self.assertIn('| review | MISSING |', run.stdout)
        self.assertEqual(collect(self.root)['counts']['PASS'], 18)

    def test_malformed_json_is_invalid(self):
        self.passing()
        (self.root / 'native-stage-proof/review/RESULT.json').write_text('{unfinished')
        self.assertEqual(collect(self.root)['counts']['INVALID'], 1)
        self.assertEqual(collect(self.root)['status'], 'FAIL')

    def test_wrong_stage_cannot_supply_a_pass(self):
        self.passing()
        self.write('review', {'stage': 'graphics', 'status': 'PASS', 'checks': 10})
        self.assertEqual(collect(self.root)['counts']['INVALID'], 1)

    def test_boolean_or_negative_check_count_is_invalid(self):
        self.passing()
        for count in (True, -1):
            self.write('review', {'stage': 'review', 'status': 'PASS', 'checks': count})
            self.assertEqual(collect(self.root)['counts']['INVALID'], 1)


if __name__ == '__main__':
    unittest.main()
