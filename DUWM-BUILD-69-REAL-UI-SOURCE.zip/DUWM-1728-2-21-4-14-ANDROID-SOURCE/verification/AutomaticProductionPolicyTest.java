package com.sentongoharuna.worldsituationroom;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Executes the real pure production policy. No Android, model or encoder is
 * substituted by this test; those are independently checked on Android. */
public final class AutomaticProductionPolicyTest {
    private static int checks;
    private static void check(boolean value,String message){
        checks++;if(!value)throw new AssertionError(message);
    }
    private static void rejects(Runnable operation,String message){
        checks++;try{operation.run();}catch(IllegalArgumentException expected){return;}
        throw new AssertionError(message);
    }
    private static void immutable(Runnable operation,String message){
        checks++;try{operation.run();}catch(UnsupportedOperationException expected){return;}
        throw new AssertionError(message);
    }
    private static boolean unicode(String text){
        for(int i=0;i<text.length();i++){
            char c=text.charAt(i);
            if(Character.isHighSurrogate(c)){if(++i>=text.length()||!Character.isLowSurrogate(text.charAt(i)))return false;}
            else if(Character.isLowSurrogate(c))return false;
        }
        return true;
    }
    private static String body(String labelled,String label){
        check(labelled.startsWith(label),"Source excerpt lost its explicit origin label");
        String value=labelled.substring(label.length());return value.endsWith("…")?value.substring(0,value.length()-1):value;
    }
    private static void reportExcerpts(){
        final String words="SOURCE WORDS • ",notes="SOURCE NOTES • ";
        Duwm1728AutomaticProduction.Plan neutral=Duwm1728AutomaticProduction.plan(10000,Collections.emptyList(),"No audio track");
        check(neutral.contentSource.equals(Duwm1728AutomaticProduction.NEUTRAL),"Fallback has neutral source provenance");
        check(neutral.description.equals("RECORDED VIDEO • SOURCE FOOTAGE"),"No-audio source must not claim an original soundtrack");
        check(neutral.tickers.isEmpty()&&neutral.sourceCueCount==0&&neutral.tickerExcerptCount==0,"Neutral output invents no source-time ticker");
        check(neutral.headlineSourceStartMs==-1&&neutral.headlineSourceEndMs==-1,"Neutral headline cannot claim speech timing");
        check(neutral.sourceNotes.isEmpty(),"Absent capture notes remain absent");
        check(!neutral.description.contains("CAPTIONS")&&!neutral.description.contains("derived"),"Technical diagnostic text must not enter the neutral ticker");

        ArrayList<Duwm1728BroadcastLayout.Cue> precise=new ArrayList<>();
        for(int i=0;i<19;i++)precise.add(new Duwm1728BroadcastLayout.Cue(137+i*2000,1201+i*2000,"Literal "+i+" = café; 東京 🎥"));
        Duwm1728AutomaticProduction.Plan timeline=Duwm1728AutomaticProduction.plan(40000,precise,"Reported starts; derived ends","Reporter context");
        check(timeline.contentSource.equals(Duwm1728AutomaticProduction.RECORDED_SPEECH),"Timed recorded words take precedence over notes");
        check(timeline.sourceNotes.equals("Reporter context"),"Speech planning must retain the supplied notes separately");
        check(timeline.title.equals(words+precise.get(0).text),"Short headline is an exact labelled source excerpt");
        check(timeline.description.equals(neutral.description),"A later speech excerpt must not appear in every source gap");
        check(timeline.headlineSourceStartMs==137&&timeline.headlineSourceEndMs==1201,"Headline evidence retains exact millisecond interval");
        check(timeline.tickers.size()==19&&timeline.tickerExcerptCount==19&&timeline.sourceCueCount==19,"Structured tickers are not limited to twelve legacy cues");
        check(timeline.tickerOmittedCount==0,"Ordinary source words must not be omitted");
        for(int i=0;i<precise.size();i++){
            Duwm1728BroadcastLayout.Cue source=precise.get(i),ticker=timeline.tickers.get(i),caption=timeline.cues.get(i);
            check(ticker.startMs==source.startMs&&ticker.endMs==source.endMs,"Ticker must retain exact source interval "+i);
            check(ticker.text.equals(words+source.text),"Ticker must preserve literal delimiters and Unicode "+i);
            check(caption.text.equals(source.text)&&caption.startMs==source.startMs&&caption.endMs==source.endMs,"Full source caption cannot change "+i);
        }
        check(Duwm1728BroadcastLayout.active(timeline.tickers,136)==null&&Duwm1728BroadcastLayout.active(timeline.tickers,1201)==null,
                "Ticker excerpts must not leak before their source interval or across an exclusive end");
        check(Duwm1728BroadcastLayout.active(timeline.tickers,2137).text.equals(words+precise.get(1).text),"Next source excerpt activates at its exact fractional start");
        precise.clear();check(timeline.tickers.size()==19,"Ticker snapshots cannot depend on mutable caller lists");
        immutable(()->timeline.tickers.clear(),"Ticker document could be cleared after planning");
        immutable(()->timeline.tickers.set(0,new Duwm1728BroadcastLayout.Cue(0,1,"Changed")),"Ticker document could be replaced after planning");
        check(timeline.sourceEvidence.contains("19 original cues retained")&&timeline.sourceEvidence.contains("137..1201 ms"),"Source evidence must identify the document and headline interval");
        check(timeline.sourceEvidence.contains("Reported starts; derived ends"),"Timing caveat belongs in source evidence");

        String longText="Workers are continuing construction at the building while equipment moves around the site and pedestrians walk past the main entrance beside Wilson Road today.";
        Duwm1728AutomaticProduction.Plan excerpted=Duwm1728AutomaticProduction.plan(7000,
                List.of(new Duwm1728BroadcastLayout.Cue(123,6789,longText)),"Reported starts; derived ends");
        check(excerpted.title.length()<=words.length()+Duwm1728AutomaticProduction.HEADLINE_EXCERPT_LIMIT,"Headline length stays bounded for the compact layout");
        check(excerpted.title.endsWith("…"),"A shortened headline must visibly mark omitted source words");
        String headlineBody=body(excerpted.title,words);
        check(longText.startsWith(headlineBody)&&longText.charAt(headlineBody.length())==' ',"Headline ends at a whole source-word boundary");
        String ticker=excerpted.tickers.get(0).text,tickerBody=body(ticker,words);
        check(ticker.length()<=Duwm1728AutomaticProduction.TICKER_TEXT_LIMIT&&ticker.endsWith("…"),"Ticker label and ellipsis are included in its readable length bound");
        check(longText.startsWith(tickerBody)&&longText.charAt(tickerBody.length())==' ',"Ticker is a contiguous whole-word source excerpt");
        check(excerpted.cues.get(0).text.equals(longText),"Short display excerpts must not shorten the caption document");
        check(excerpted.tickers.get(0).startMs==123&&excerpted.tickers.get(0).endMs==6789,"Excerpt selection cannot round or invent timing");
        check(!excerpted.title.contains("BREAKING")&&!excerpted.description.contains("AI")&&!excerpted.description.contains("derived"),"Policy must not add news claims or implementation text to source excerpts");

        Duwm1728AutomaticProduction.Plan repeated=Duwm1728AutomaticProduction.plan(10000,List.of(
                new Duwm1728BroadcastLayout.Cue(123,1000,"Same source words"),
                new Duwm1728BroadcastLayout.Cue(1000,2000,"Same source words"),
                new Duwm1728BroadcastLayout.Cue(1500,2500,"Same source words"),
                new Duwm1728BroadcastLayout.Cue(3000,4000,"Same source words"),
                new Duwm1728BroadcastLayout.Cue(4000,5000,"Different source words")),"");
        check(repeated.cues.size()==5&&repeated.tickers.size()==3,"Only adjoining identical source ticker excerpts may be coalesced");
        check(repeated.tickers.get(0).startMs==123&&repeated.tickers.get(0).endMs==2500,"Coalescing preserves the union of actual adjoining source intervals");
        check(Duwm1728BroadcastLayout.active(repeated.tickers,2700)==null,"Coalescing must never bridge a source gap");
        check(repeated.tickers.get(1).startMs==3000&&repeated.tickers.get(2).startMs==4000,"Gap and changed words retain independent source starts");
        check(repeated.sourceEvidence.contains("2 adjacent identical source cues coalesced"),"Evidence reports ticker coalescing explicitly");
        String shared="The same repeated introductory words describe only the beginning of this long spoken sentence before a different ending arrives ";
        Duwm1728AutomaticProduction.Plan differentEnds=Duwm1728AutomaticProduction.plan(5000,List.of(
                new Duwm1728BroadcastLayout.Cue(0,2000,shared+"first"),
                new Duwm1728BroadcastLayout.Cue(2000,4000,shared+"second")),"");
        check(differentEnds.tickers.size()==2,"Matching short prefixes must not merge different full source cues");

        String rawNotes="Reporter observation: road repairs near the entrance.\nOriginal notes retained = yes; café 🎥";
        Duwm1728AutomaticProduction.Plan noted=Duwm1728AutomaticProduction.plan(10000,Collections.emptyList(),"Unavailable",rawNotes);
        check(noted.contentSource.equals(Duwm1728AutomaticProduction.CAPTURE_NOTES),"No-speech fallback retains the provided capture-note source");
        check(noted.sourceNotes.equals(rawNotes),"Full original capture notes must survive without normalization or truncation");
        check(noted.title.startsWith(notes)&&noted.description.startsWith(notes),"Capture notes must be clearly labelled as notes, never speech");
        check(noted.title.length()<=notes.length()+Duwm1728AutomaticProduction.HEADLINE_EXCERPT_LIMIT&&noted.description.length()<=Duwm1728AutomaticProduction.TICKER_TEXT_LIMIT,"Capture-note excerpts are bounded");
        check(noted.cues.isEmpty()&&noted.tickers.isEmpty()&&noted.headlineSourceStartMs==-1&&noted.headlineSourceEndMs==-1,"Capture notes cannot fabricate caption or speech timing");
        check(noted.captionStatus.equals("Unavailable")&&noted.provenance.equals("AUTO-EDITED • UNVERIFIED"),"Note fallback cannot upgrade speech availability or verification");
        check(Duwm1728AutomaticProduction.plan(1000,Collections.emptyList(),"",null).contentSource.equals(Duwm1728AutomaticProduction.NEUTRAL),"Missing optional notes choose a neutral report");
        check(Duwm1728AutomaticProduction.plan(1000,Collections.emptyList(),""," \n\t ").contentSource.equals(Duwm1728AutomaticProduction.NEUTRAL),"Blank notes cannot invent report content");

        String indivisible="x".repeat(500);
        Duwm1728AutomaticProduction.Plan unbroken=Duwm1728AutomaticProduction.plan(1000,List.of(new Duwm1728BroadcastLayout.Cue(0,999,indivisible)),"");
        check(unbroken.cues.size()==1&&unbroken.cues.get(0).text.equals(indivisible),"Overlong indivisible words remain intact in full captions");
        check(unbroken.tickers.isEmpty()&&unbroken.tickerOmittedCount==1&&unbroken.title.equals("RECORDED REPORT"),"Overlong indivisible tokens must not become fabricated word fragments");
        check(unbroken.contentSource.equals(Duwm1728AutomaticProduction.RECORDED_SPEECH)&&unbroken.sourceEvidence.contains("1 indivisible overlong excerpts omitted"),"Omitted display excerpt remains explicit without discarding source provenance");
        for(String multilingual:new String[]{"東京の街で人々が歩いています。".repeat(20),
                "Kampala 🎥 café e\u0301 family 👩‍👩‍👧‍👦 flag 🇺🇬 ".repeat(6)}){
            Duwm1728AutomaticProduction.Plan translated=Duwm1728AutomaticProduction.plan(2000,List.of(new Duwm1728BroadcastLayout.Cue(1,1999,multilingual)),"");
            check(translated.cues.get(0).text.equals(multilingual.trim()),"Multilingual full captions must remain unmodified");
            check(unicode(translated.title)&&unicode(translated.tickers.get(0).text),"Excerpts must never split Unicode surrogate pairs");
            check(multilingual.startsWith(body(translated.title,words)),"Multilingual headline stays a contiguous source prefix");
            check(multilingual.startsWith(body(translated.tickers.get(0).text,words)),"Multilingual ticker stays a contiguous source prefix");
            check(!translated.title.endsWith("\u200D…")&&!translated.tickers.get(0).text.endsWith("\u200D…"),"An excerpt must not end halfway through a joined emoji");
        }
        ArrayList<Duwm1728BroadcastLayout.Cue> maximum=new ArrayList<>();
        for(int i=0;i<Duwm1728CaptionEditPolicy.MAX_CUES;i++)maximum.add(new Duwm1728BroadcastLayout.Cue(i*100L,i*100L+99,"Source cue "+i));
        Duwm1728AutomaticProduction.Plan largest=Duwm1728AutomaticProduction.plan(2000000,maximum,"");
        check(largest.cues.size()==Duwm1728CaptionEditPolicy.MAX_CUES&&largest.tickers.size()==Duwm1728CaptionEditPolicy.MAX_CUES,"Every valid maximum-size source cue can have a structured ticker; no hidden twelve-cue or ten-thousand limit");
        check(largest.tickers.get(19999).startMs==1999900&&largest.tickers.get(19999).endMs==1999999,"Final source ticker is retained at exact milliseconds");
        check(largest.cues.get(19999).text.equals("Source cue 19999")&&largest.tickerOmittedCount==0,"Maximum-size planning cannot silently drop source words");
    }
    public static void main(String[] args)throws Exception{
        int admitted=0;
        for(int bits=0;bits<64;bits++){
            boolean actual=Duwm1728AutomaticProduction.shouldStart((bits&1)!=0,(bits&2)!=0,
                (bits&4)!=0,(bits&8)!=0,(bits&16)!=0,(bits&32)!=0);
            // Only a fresh, enabled source with none of the four stop conditions.
            check(actual==(bits==3),"Automatic admission state "+bits);
            if(actual)admitted++;
        }
        check(admitted==1,"Exactly one initial automatic state is permitted");
        String first=Duwm1728AutomaticProduction.receiptKey("recording-A");
        check(first.equals(Duwm1728AutomaticProduction.receiptKey("recording-A")),"Same recording finds the same attempt receipt");
        check(!first.equals(Duwm1728AutomaticProduction.receiptKey("recording-B")),"Different recordings have separate receipts");
        rejects(()->Duwm1728AutomaticProduction.receiptKey(null),"Missing receipt identity accepted");
        rejects(()->Duwm1728AutomaticProduction.receiptKey(""),"Empty receipt identity accepted");
        for(long duration:new long[]{1,44999,45000,45001,90000,90001,123456,Integer.MAX_VALUE}){
            Duwm1728AutomaticProduction.Plan plan=Duwm1728AutomaticProduction.plan(duration,Collections.emptyList(),"No compatible speech service");
            check(plan.fromMs==0&&plan.toMs==duration,"Automatic output must retain the complete source");
            check("ORIGINAL".equals(plan.ratio),"Automatic output must retain the source aspect ratio");
            check(Duwm1728FramePlan.FIT.equals(plan.frameMode),"Automatic output must not crop the source");
            check(Duwm1728BroadcastComposition.COMPACT.equals(plan.composition),"Automatic output uses the compact broadcast layout");
            check(plan.cues.isEmpty(),"Unavailable speech must not fabricate captions");
            check(plan.captionStatus.equals("No compatible speech service"),"Speech failure status must survive the plan");
            check(plan.provenance.equals("AUTO-EDITED • UNVERIFIED"),"No-caption output must remain unverified");
            check(plan.title.equals("RECORDED REPORT"),"Generic title must not invent event facts");
            check(!plan.description.contains("speech captions"),"Fallback description must not claim captions");
        }
        List<Duwm1728BroadcastLayout.Cue> input=new ArrayList<>(Arrays.asList(
            new Duwm1728BroadcastLayout.Cue(45000,59999,"Late words 🎥"),
            new Duwm1728BroadcastLayout.Cue(0,1200,"First words"),
            new Duwm1728BroadcastLayout.Cue(1200,4000,"Following words")));
        Duwm1728BroadcastLayout.Cue original=input.get(0);
        Duwm1728AutomaticProduction.Plan captioned=Duwm1728AutomaticProduction.plan(60000,input,"Word starts reported; cue ends derived");
        check(captioned.fromMs==0&&captioned.toMs==60000,"Caption presence must not trim the source");
        check(captioned.cues.size()==3,"No valid recognized cue may disappear");
        check(captioned.cues.get(0).startMs==0&&captioned.cues.get(1).startMs==1200&&captioned.cues.get(2).startMs==45000,
            "Caption cues remain in exact original-source milliseconds");
        check(captioned.cues.get(2).endMs==59999&&captioned.cues.get(2).text.equals("Late words 🎥"),"Caption ends and Unicode words retained");
        check(input.get(0)==original&&input.get(0).startMs==45000,"Planning must not reorder the caller's list");
        input.clear();
        check(captioned.cues.size()==3,"Plan owns an independent cue snapshot");
        immutable(()->captioned.cues.clear(),"Plan cues could be cleared after validation");
        immutable(()->captioned.cues.set(0,new Duwm1728BroadcastLayout.Cue(0,500,"Changed")),"Plan cues could be replaced");
        check(captioned.provenance.equals("AUTO-CAPTIONS • UNREVIEWED"),"Automatic speech must never claim human approval");
        check(captioned.captionStatus.equals("Word starts reported; cue ends derived"),"Derived timing disclosure retained");
        check(captioned.sourceEvidence.contains("Word starts reported; cue ends derived")&&!captioned.description.contains("derived"),"Caption timing limitation remains in evidence instead of the burned ticker");
        check(!captioned.provenance.contains("REPORTER REVIEWED"),"Policy fabricated reporter review");
        check(Duwm1728AutomaticProduction.plan(1000,Collections.emptyList(),null).captionStatus.isEmpty(),"Absent status is not invented");
        rejects(()->Duwm1728AutomaticProduction.plan(0,Collections.emptyList(),""),"Zero source accepted");
        rejects(()->Duwm1728AutomaticProduction.plan(-1,Collections.emptyList(),""),"Negative source accepted");
        rejects(()->Duwm1728AutomaticProduction.plan((long)Integer.MAX_VALUE+1,Collections.emptyList(),""),"Unsupported source duration accepted");
        rejects(()->Duwm1728AutomaticProduction.plan(1000,null,""),"Missing caption collection accepted");
        rejects(()->Duwm1728AutomaticProduction.plan(1000,Collections.singletonList(null),""),"Null caption accepted");
        rejects(()->Duwm1728AutomaticProduction.plan(1000,List.of(new Duwm1728BroadcastLayout.Cue(999,1001,"Outside")),""),"Out-of-source caption accepted");
        rejects(()->Duwm1728AutomaticProduction.plan(1000,List.of(new Duwm1728BroadcastLayout.Cue(0,500,"   ")),""),"Blank recognized caption accepted");
        rejects(()->Duwm1728AutomaticProduction.plan(1000,Collections.nCopies(Duwm1728CaptionEditPolicy.MAX_CUES+1,
            new Duwm1728BroadcastLayout.Cue(0,1000,"Too many")),""),"Unbounded automatic caption count accepted");
        check(Duwm1728AutomaticProduction.SPEECH_CHUNK_MS==45000,"Each speech request is bounded to 45 seconds");
        check(Duwm1728AutomaticProduction.chunkEnd(0,45000)==45000,"Exact chunk boundary");
        check(Duwm1728AutomaticProduction.chunkEnd(0,45001)==45000,"Long source splits at 45 seconds");
        check(Duwm1728AutomaticProduction.chunkEnd(45000,45001)==45001,"Final millisecond must be processed");
        check(Duwm1728AutomaticProduction.chunkEnd(Long.MAX_VALUE-1,Long.MAX_VALUE)==Long.MAX_VALUE,"Chunk arithmetic must not overflow");
        for(long duration:new long[]{1,45001,90000,135007}){
            long cursor=0,total=0;int parts=0;
            while(cursor<duration){
                long end=Duwm1728AutomaticProduction.chunkEnd(cursor,duration);
                check(end>cursor&&end<=duration&&end-cursor<=45000,"Chunk must advance within the original source");
                total+=end-cursor;cursor=end;parts++;
                check(parts<10,"Chunk partition failed to terminate");
            }
            check(cursor==duration&&total==duration,"Chunk partition must have no gap, overlap or omitted tail");
        }
        rejects(()->Duwm1728AutomaticProduction.chunkEnd(-1,1000),"Negative chunk start accepted");
        rejects(()->Duwm1728AutomaticProduction.chunkEnd(1000,1000),"Completed source accepted as another chunk");
        rejects(()->Duwm1728AutomaticProduction.chunkEnd(1001,1000),"Reversed chunk range accepted");
        reportExcerpts();
        System.out.println("PASS "+checks+" automatic production policy assertions: exhaustive fresh-source guards, full-source ORIGINAL/FIT/COMPACT output, immutable full captions, exact source-time labelled headline/ticker excerpts, note fallback, honest unreviewed status and gap-free speech chunks. Host policy only; Android speech, rendering and publication are separate native checks.");
        if(args.length==1){
            java.nio.file.Path folder=java.nio.file.Path.of(args[0]);java.nio.file.Files.createDirectories(folder);
            java.nio.file.Files.writeString(folder.resolve("AUTOMATIC-POLICY-HOST.json"),
                "{\"status\":\"PASS\",\"checks\":"+checks+",\"scope\":\"production Java policy on host JDK; no Android execution or model inference\",\"native_executed\":false,\"admission_states\":64,\"source_range\":\"full\",\"ratio\":\"ORIGINAL\",\"framing\":\"FIT\",\"composition\":\"COMPACT\",\"speech_chunk_ms\":45000,\"source_time_tickers\":true,\"source_caption_limit\":20000,\"ticker_text_limit\":120,\"full_source_cues_preserved\":true,\"capture_notes_preserved\":true,\"event_inference\":false}\n");
        }
    }
}
