import com.sentongoharuna.worldsituationroom.Duwm1728EditorTrimPolicy;

/** Source-time trim behavior, including subsecond marks and boundary crossings. */
public final class EditorTrimPolicyTest {
    private static int checks;
    private static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    private static void range(Duwm1728EditorTrimPolicy.Range value,long from,long to,String message){
        check(value.fromMs==from&&value.toMs==to,message+": "+value.fromMs+".."+value.toMs);
    }
    private static void bounded(Duwm1728EditorTrimPolicy.Range value,long duration,String message){
        check(value.fromMs>=0&&value.toMs<=duration&&value.fromMs<value.toMs,message);
    }
    private static void rejects(Runnable work,String message){boolean rejected=false;try{work.run();}catch(IllegalArgumentException expected){rejected=true;}check(rejected,message);}
    public static void main(String[] args){
        range(Duwm1728EditorTrimPolicy.reset(2000),0,2000,"Reset restores the complete recording");
        Duwm1728EditorTrimPolicy.Range in=Duwm1728EditorTrimPolicy.markIn(0,2000,437,2000);
        range(in,437,2000,"MARK IN preserves the actual subsecond source position");
        Duwm1728EditorTrimPolicy.Range out=Duwm1728EditorTrimPolicy.markOut(in.fromMs,in.toMs,1567,2000);
        range(out,437,1567,"MARK OUT preserves the actual subsecond source position");
        range(Duwm1728EditorTrimPolicy.markIn(437,1567,1900,2000),1566,1567,"Crossing MARK IN retains a one-millisecond range before OUT");
        range(Duwm1728EditorTrimPolicy.markOut(437,1567,100,2000),437,438,"Crossing MARK OUT retains a one-millisecond range after IN");
        range(Duwm1728EditorTrimPolicy.markIn(437,1567,-10,2000),0,1567,"Negative source positions clamp to the beginning");
        range(Duwm1728EditorTrimPolicy.markOut(437,1567,3000,2000),437,2000,"Out mark cannot extend beyond the recording");
        range(Duwm1728EditorTrimPolicy.reset(1),0,1,"Shortest valid recording remains selectable");
        for(long duration:new long[]{1,2,1999,60000,Long.MAX_VALUE}){
            long from=duration/4,to=Math.max(from+1,duration-duration/4);
            for(long playhead:new long[]{Long.MIN_VALUE,-1,0,1,437,1567,duration-1,duration,Long.MAX_VALUE}){
                Duwm1728EditorTrimPolicy.Range markedIn=Duwm1728EditorTrimPolicy.markIn(from,to,playhead,duration);
                bounded(markedIn,duration,"Every IN mark stays within the source");
                check(markedIn.toMs==to,"MARK IN preserves the existing valid OUT bound");
                Duwm1728EditorTrimPolicy.Range markedOut=Duwm1728EditorTrimPolicy.markOut(from,to,playhead,duration);
                bounded(markedOut,duration,"Every OUT mark stays within the source");
                check(markedOut.fromMs==from,"MARK OUT preserves the existing valid IN bound");
            }
            for(long[] invalid:new long[][]{{-10,-1},{duration,0},{Long.MAX_VALUE,Long.MIN_VALUE},{0,Long.MAX_VALUE}}){
                bounded(Duwm1728EditorTrimPolicy.markIn(invalid[0],invalid[1],437,duration),duration,"Invalid prior text range can recover through MARK IN");
                bounded(Duwm1728EditorTrimPolicy.markOut(invalid[0],invalid[1],437,duration),duration,"Invalid prior text range can recover through MARK OUT");
            }
        }
        for(long invalidDuration:new long[]{0,-1,Long.MIN_VALUE}){
            rejects(()->Duwm1728EditorTrimPolicy.reset(invalidDuration),"Reset rejects a recording with no duration");
            rejects(()->Duwm1728EditorTrimPolicy.markIn(0,1,0,invalidDuration),"MARK IN rejects an unavailable source duration");
            rejects(()->Duwm1728EditorTrimPolicy.markOut(0,1,1,invalidDuration),"MARK OUT rejects an unavailable source duration");
        }
        System.out.println("PASS "+checks+" editor trim policy assertions");
    }
}
