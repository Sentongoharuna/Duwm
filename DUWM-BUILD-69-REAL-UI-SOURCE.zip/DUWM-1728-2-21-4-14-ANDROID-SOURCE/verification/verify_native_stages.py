#!/usr/bin/env python3
"""Require every native stage, exact installed APK identities, and unmodified evidence.

An environment-obstructed or partially executed stage is a failure. This script
does not infer passes from an MP4, a screenshot, an earlier release, or a subset
of the instrumentation log.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import sys

STAGES = ("signals", "graphics", "exports4", "framing", "inset1", "review", "editor_controls", "review_controls", "recovery", "composition", "caption_editing", "caption_files", "automatic_production", "automatic_report", "automatic_ready", "automatic_fit", "scene_timeline", "measured_telemetry", "clear_picture", "automatic_finish")
REQUIRED = {
    "signals": tuple(f"{stage}-STATIC.png" for stage in ("OUTAGE", "DEGRADED", "AGED", "CONNECTING", "RECEIVING", "HEALTHY", "UNKNOWN", "LOCAL")) + ("CAMERA-HEALTH-TEST-FIXTURES.png",),
    "graphics": ("NATIVE-720x800.png", "NATIVE-720x1280.png", "NATIVE-1280x720.png", "NATIVE-PIP-PORTRAIT.png"),
    "exports4": ("ANDROID-EXPORT-9-10.mp4", "ANDROID-EXPORT-9-16.mp4", "ANDROID-EXPORT-16-9.mp4", "ANDROID-EXPORT-16-9-TRIMMED.mp4"),
    "framing": tuple(f"ANDROID-FRAMING-{i}-{'FIT' if i in (0, 3) else 'FILL'}.mp4" for i in range(6)) + tuple(f"ANDROID-EDITOR-FRAMING-{i}.png" for i in range(3)),
    "inset1": ("ANDROID-PIP-PORTRAIT.mp4",),
    "review": ("ANDROID-REVIEW-FIXTURE.mp4", "ANDROID-SAVED-VIDEO-REVIEW.png"),
    "editor_controls": ("ANDROID-EDITOR-TRIM-MARKS.png", "ANDROID-EDITOR-TRIM-RESET.png", "ANDROID-EDITOR-TRIM-RESTORED.png", "ANDROID-EDITOR-TRIM-LANDSCAPE.png", "ANDROID-EDITOR-TRIM-LANDSCAPE-BOUNDS.json"),
    "review_controls": ("ANDROID-REVIEW-CONTROLS-FIXTURE.mp4", "ANDROID-REVIEW-FULLSCREEN.png", "ANDROID-REVIEW-RESTORED.png", "ANDROID-REVIEW-FULLSCREEN-CAPTURE.txt"),
    "recovery": ("ANDROID-RECOVERY-FIXTURE.mp4", "RECOVERY-STORAGE.json", "ANDROID-EDITOR-RECOVERY-PENDING.png", "ANDROID-EXPORT-RECOVERY.png", "ANDROID-RECOVERY-LOCAL-REVIEW.png", "ANDROID-EXPORT-RECOVERY-UNCONFIRMED.png"),
    "composition": tuple(f"NATIVE-COMPOSITION-{mode}-{size}.png" for mode in ("FULL", "COMPACT", "CAPTIONS") for size in ("720x800", "720x1280", "1280x720"))
        + tuple(f"ANDROID-EDITOR-LAYOUT-{mode}.png" for mode in ("FULL", "COMPACT", "CAPTIONS"))
        + tuple(f"NATIVE-EDITOR-SPEC-{mode}.png" for mode in ("FULL", "COMPACT", "CAPTIONS"))
        + ("ANDROID-COMPOSITION-CAPTIONS.mp4", "ANDROID-EDITOR-LAYOUT-PICKER.png", "ANDROID-EDITOR-LAYOUT-RESTORED.png", "COMPOSITION-NATIVE.json"),
    "caption_editing": ("ANDROID-CAPTION-EDITOR.png", "ANDROID-CAPTION-INVALID.png", "ANDROID-CAPTION-APPLIED.png", "ANDROID-CAPTION-RESTORED.png", "ANDROID-CAPTION-EDITED.mp4", "ANDROID-CAPTION-DECODED.png", "CAPTION-EDITING-NATIVE.json"),
    "caption_files": ("ANDROID-CAPTIONS-ORIGINAL.srt", "ANDROID-CAPTIONS-CLIP.srt", "ANDROID-CAPTION-FILES.png", "ANDROID-CAPTION-FILES-CONFIRM.png", "ANDROID-CAPTION-FILES-ERROR.png", "ANDROID-CAPTION-FILES-RESTORED.png", "CAPTION-FILES-NATIVE.json"),
    "automatic_production": ("ANDROID-AUTOMATIC-BROADCAST.mp4", "ANDROID-AUTOMATIC-PRODUCTION.png", "ANDROID-AUTOMATIC-REVIEW.png", "AUTOMATIC-PRODUCTION-NATIVE.json"),
    "automatic_report": ("ANDROID-AUTO-REPORT.mp4", "ANDROID-AUTO-REPORT-EDITOR.png", "ANDROID-AUTO-REPORT-PAGE-1.png", "ANDROID-AUTO-REPORT-PAGE-LAST.png", "AUTO-REPORT-NATIVE.json"),
    "automatic_ready": ("ANDROID-AUTO-READY.mp4", "ANDROID-AUTO-READY-TICKER-FIRST.png", "ANDROID-AUTO-READY-TICKER-LAST.png", "AUTO-READY-NATIVE.json"),
    "automatic_fit": ("ANDROID-AUTO-FIT.mp4", "ANDROID-AUTO-FIT-HEADLINE.png", "AUTO-FIT-NATIVE.json"),
    "scene_timeline": ("ANDROID-SCENE-TIMELINE.mp4", "ANDROID-SCENE-FIRST.png", "ANDROID-SCENE-SECOND.png", "SCENE-TIMELINE-NATIVE.json"),
    "measured_telemetry": ("ANDROID-MEASURED-TELEMETRY.mp4", "ANDROID-MEASURED-FIRST.png", "ANDROID-MEASURED-SECOND.png", "MEASURED-TELEMETRY-NATIVE.json"),
    "clear_picture": ("ANDROID-CLEAR-PICTURE.mp4", "ANDROID-CLEAR-FIRST.png", "ANDROID-CLEAR-SECOND.png", "CLEAR-PICTURE-NATIVE.json"),
    "automatic_finish": ("AUTOMATIC-FINISH-NATIVE.json",),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def check_log(path: Path, stages: tuple[str, ...], run_id: str, full: bool) -> None:
    require(path.is_file(), f"Missing instrumentation log: {path.name}")
    log = path.read_text(encoding="utf-8", errors="replace")
    codes = re.findall(r"^INSTRUMENTATION_CODE:\s*(-?\d+)\s*$", log, re.MULTILINE)
    require(codes == ["-1"], f"{path.name}: instrumentation did not finish exactly once with -1")
    require(not re.search(r"DUWM_NATIVE_(?:STAGE|BROADCAST)_FAIL", log), f"{path.name}: a failure marker is present")
    for stage in stages:
        marker = rf"DUWM_NATIVE_STAGE_PASS stage={re.escape(stage)} run_id={re.escape(run_id)}(?:\s|$)"
        require(re.search(marker, log) is not None, f"{path.name}: no explicit current-run PASS for {stage}")
    if full:
        require(re.search(rf"DUWM_NATIVE_BROADCAST_PASS run_id={re.escape(run_id)}(?:\s|$)", log) is not None,
                f"{path.name}: full run has no complete pass marker")


def check_return_code(path: Path) -> None:
    require(path.is_file(), f"Missing wrapper return code: {path.name}")
    require(path.read_text(encoding="utf-8").strip() == "0", f"{path.name}: ADB wrapper did not exit successfully")


def verify(evidence_root: Path, app_apk: Path, test_apk: Path, run_id: str,
           logs_dir: Path | None = None, full_log: Path | None = None) -> dict:
    require(bool(logs_dir) != bool(full_log), "Supply exactly one of logs_dir or full_log")
    require(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,95}", run_id) is not None, "Invalid run_id")
    require(app_apk.is_file() and test_apk.is_file(), "Both exact installed APK files are required")
    app_hash, test_hash = sha256(app_apk), sha256(test_apk)
    if full_log:
        check_return_code(full_log.with_name("RETURN-CODE.txt"))
        check_log(full_log, STAGES, run_id, True)
    else:
        for stage in STAGES:
            check_return_code(logs_dir / f"RETURN-CODE-{stage}.txt")
            check_log(logs_dir / f"INSTRUMENTATION-{stage}.txt", (stage,), run_id, False)
    summaries = []
    for stage in STAGES:
        directory = evidence_root / stage
        result_file = directory / "RESULT.json"
        require(result_file.is_file(), f"{stage}: missing result manifest")
        result = json.loads(result_file.read_text(encoding="utf-8"))
        require(result.get("schema") == 1 and result.get("stage") == stage, f"{stage}: wrong manifest schema/stage")
        require(result.get("status") == "PASS", f"{stage}: status is {result.get('status')}; {result.get('failure_kind', '')}")
        require(result.get("run_id") == run_id, f"{stage}: evidence belongs to another run")
        require(result.get("app_apk_sha256") == app_hash, f"{stage}: evidence belongs to another app APK")
        require(result.get("test_apk_sha256") == test_hash, f"{stage}: evidence belongs to another instrumentation APK")
        require(result.get("application_id") == "com.sentongoharuna.worldsituationroom.rb2live25", f"{stage}: wrong application")
        require(result.get("physical_camera_verified") is False, f"{stage}: synthetic native checks must not claim physical-camera verification")
        checks = result.get("checks")
        require(type(checks) is int and checks > 0, f"{stage}: no recorded assertions")
        require(type(result.get("started_at_ms")) is int and type(result.get("finished_at_ms")) is int
                and result["finished_at_ms"] >= result["started_at_ms"], f"{stage}: stage did not finish")
        phases_file = directory / "PHASES.txt"
        require(phases_file.is_file() and phases_file.stat().st_size > 0, f"{stage}: missing phase breadcrumbs")
        phases = phases_file.read_text(encoding="utf-8", errors="replace")
        require(f"stage={stage} run_id={run_id} phase=start" in phases, f"{stage}: phase log belongs to another run")
        listed = result.get("evidence")
        require(isinstance(listed, list) and listed, f"{stage}: no evidence list")
        found = set()
        for item in listed:
            relative = item.get("path", "")
            require(re.fullmatch(r"evidence/[A-Za-z0-9._-]+", relative) is not None, f"{stage}: invalid evidence path")
            require(relative not in found, f"{stage}: duplicated evidence record")
            found.add(relative)
            path = directory / relative
            require(path.is_file() and not path.is_symlink(), f"{stage}: evidence file missing: {relative}")
            require(type(item.get("bytes")) is int and item["bytes"] > 0 and path.stat().st_size == item["bytes"], f"{stage}: evidence length differs: {relative}")
            require(sha256(path) == item.get("sha256"), f"{stage}: evidence digest differs: {relative}")
            if path.suffix == ".png":
                with path.open("rb") as stream:
                    require(stream.read(8) == b"\x89PNG\r\n\x1a\n", f"{stage}: invalid PNG: {relative}")
            elif path.suffix == ".mp4":
                with path.open("rb") as stream:
                    header = stream.read(12)
                require(path.stat().st_size > 10000 and header[4:8] == b"ftyp", f"{stage}: invalid/empty MP4: {relative}")
            elif path.suffix == ".srt":
                require(path.stat().st_size <= 32 * 1024 * 1024, f"{stage}: oversized SRT evidence: {relative}")
                try:
                    subtitle = path.read_text(encoding="utf-8")
                except UnicodeDecodeError as error:
                    raise ValueError(f"{stage}: invalid UTF-8 SRT evidence: {relative}") from error
                require(re.search(r"(?m)^\d+:\d{2}:\d{2},\d{3} --> \d+:\d{2}:\d{2},\d{3}$", subtitle) is not None,
                        f"{stage}: SRT evidence has no serialized cue timing: {relative}")
        for name in REQUIRED[stage]:
            require(f"evidence/{name}" in found, f"{stage}: mandatory evidence missing: {name}")
        if stage == "scene_timeline":
            # This stage proves real Android rendering/encoding from declared
            # fixture observations. It must never be reported as ML inference.
            scene = json.loads((directory / "evidence/SCENE-TIMELINE-NATIVE.json").read_text(encoding="utf-8"))
            require(scene.get("schema") == 1 and scene.get("status") == "PASS", "scene_timeline: missing completed scene evidence")
            require(scene.get("scene_source") == "synthetic-native-fixture", "scene_timeline: fixture provenance missing")
            require(scene.get("model_inference_verified") is False, "scene_timeline: fixture cannot claim model inference")
            require(scene.get("physical_camera_verified") is False, "scene_timeline: fixture cannot claim physical camera")
            require(scene.get("encoded_timeline_verified") is True, "scene_timeline: encoded timeline not verified")
            require(type(scene.get("checks")) is int and scene["checks"] > 0, "scene_timeline: no scene assertions")
        if stage == "measured_telemetry":
            # Deliberate source-time fixtures test the real encoder; they are
            # never evidence of physical GPS, compass, weather or frame capture.
            measured = json.loads((directory / "evidence/MEASURED-TELEMETRY-NATIVE.json").read_text(encoding="utf-8"))
            require(measured.get("schema") == 1 and measured.get("status") == "PASS", "measured_telemetry: missing completed measurement evidence")
            require(measured.get("measurement_source") == "synthetic-native-fixture", "measured_telemetry: fixture provenance missing")
            require(measured.get("physical_sensor_verified") is False, "measured_telemetry: fixture cannot claim physical sensors")
            require(measured.get("physical_camera_verified") is False, "measured_telemetry: fixture cannot claim physical camera")
            require(measured.get("model_inference_verified") is False, "measured_telemetry: fixture cannot claim model inference")
            require(measured.get("encoded_timeline_verified") is True, "measured_telemetry: encoded timeline not verified")
            require(type(measured.get("checks")) is int and measured["checks"] > 0, "measured_telemetry: no measurement assertions")
        if stage == "automatic_finish":
            finish = json.loads((directory / "evidence/AUTOMATIC-FINISH-NATIVE.json").read_text(encoding="utf-8"))
            require(finish.get("schema") == 1 and finish.get("status") == "PASS", "automatic_finish: missing completed evidence")
            for key in ("hands_free_finish_policy_verified", "actual_content_uri_reopen_verified", "verified_success_states", "local_copy_fallback_state"):
                require(finish.get(key) is True, "automatic_finish: missing verified " + key)
            require(finish.get("physical_camera_verified") is False and finish.get("model_inference_verified") is False, "automatic_finish: must not claim physical/model verification")
            require(type(finish.get("checks")) is int and finish["checks"] > 0, "automatic_finish: no assertions")
        if stage == "clear_picture":
            clear = json.loads((directory / "evidence/CLEAR-PICTURE-NATIVE.json").read_text(encoding="utf-8"))
            require(clear.get("schema") == 1 and clear.get("status") == "PASS", "clear_picture: missing completed picture evidence")
            require(clear.get("fixture_source") == "synthetic-native-fixture", "clear_picture: fixture provenance missing")
            for key in ("physical_sensor_verified", "physical_camera_verified", "model_inference_verified", "provider_network_verified"):
                require(clear.get(key) is False, "clear_picture: fixture cannot claim " + key)
            for key in ("encoded_picture_verified", "stable_geometry_verified", "center_picture_preserved",
                        "source_time_trim_verified", "source_audio_preserved", "source_file_unchanged",
                        "fixture_cleanup_complete", "clear_default_and_saved_choices_verified",
                        "older_draft_composition_preserved", "malformed_draft_rejected"):
                require(clear.get(key) is True, "clear_picture: missing verified " + key)
            require(type(clear.get("checks")) is int and clear["checks"] > 0, "clear_picture: no picture assertions")
            require(re.fullmatch(r"[a-f0-9]{64}", str(clear.get("source_file_sha256", ""))) is not None, "clear_picture: source hash missing")
            require(type(clear.get("source_aac_packets")) is int and clear["source_aac_packets"] > 10, "clear_picture: source AAC packet evidence missing")
            start, end = clear.get("from_ms"), clear.get("to_ms")
            require(type(start) is int and type(end) is int and 0 <= start < end, "clear_picture: invalid selected source interval")
            samples = clear.get("decoded_samples")
            require(isinstance(samples, list) and len(samples) >= 2, "clear_picture: missing decoded picture samples")
            previous = -1
            for sample in samples:
                require(isinstance(sample, dict), "clear_picture: invalid decoded sample")
                elapsed, source = sample.get("elapsed_ms"), sample.get("source_ms")
                require(type(elapsed) is int and type(source) is int and previous < elapsed < end - start
                        and source == start + elapsed, "clear_picture: decoded source time or trim differs")
                previous = elapsed
                values = {}
                for key in ("measurement_glyph_dice", "wrong_measurement_glyph_dice", "title_glyph_dice", "wrong_title_glyph_dice",
                            "center_grid_mean_rgb_error", "center_grid_p95_rgb_error", "clear_safe_area_fraction"):
                    value = sample.get(key)
                    require(type(value) in (int, float) and math.isfinite(value), "clear_picture: missing finite decoded metric " + key)
                    values[key] = value
                for prefix in ("measurement", "title"):
                    correct, wrong = values[prefix + "_glyph_dice"], values["wrong_" + prefix + "_glyph_dice"]
                    require(0 <= wrong <= 1 and .70 < correct <= 1 and correct > wrong + .035,
                            "clear_picture: decoded glyphs do not distinguish current " + prefix)
                require(type(sample.get("center_grid_points")) is int and sample["center_grid_points"] >= 153,
                        "clear_picture: central picture grid evidence incomplete")
                require(0 <= values["center_grid_mean_rgb_error"] < 24 and 0 <= values["center_grid_p95_rgb_error"] < 50,
                        "clear_picture: decoded center differs from original source")
                require(.60 < values["clear_safe_area_fraction"] <= 1, "clear_picture: protected central area too small")
        summaries.append({"stage": stage, "checks": checks, "files": len(found), "elapsed_ms": result.get("elapsed_ms")})
    return {"status": "PASS", "run_id": run_id, "app_apk_sha256": app_hash, "test_apk_sha256": test_hash,
            "stages": summaries, "physical_camera_verified": False, "physical_sensor_verified": False}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("evidence_root", type=Path, help="Pulled native-stage-proof directory")
    parser.add_argument("--app-apk", required=True, type=Path)
    parser.add_argument("--test-apk", required=True, type=Path)
    parser.add_argument("--run-id", required=True)
    logs = parser.add_mutually_exclusive_group(required=True)
    logs.add_argument("--logs-dir", type=Path, help="INSTRUMENTATION-<stage>.txt and RETURN-CODE-<stage>.txt for every stage")
    logs.add_argument("--full-log", type=Path, help="Log from one full run, with RETURN-CODE.txt in the same directory")
    args = parser.parse_args()
    try:
        summary = verify(args.evidence_root, args.app_apk, args.test_apk, args.run_id, args.logs_dir, args.full_log)
    except (ValueError, OSError, KeyError, TypeError) as error:
        print(f"FAIL DUWM_NATIVE_ALL_STAGES: {error}", file=sys.stderr)
        return 1
    print("PASS DUWM_NATIVE_ALL_STAGES " + json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
