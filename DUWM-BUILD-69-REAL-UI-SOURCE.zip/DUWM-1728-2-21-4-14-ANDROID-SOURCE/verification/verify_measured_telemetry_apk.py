#!/usr/bin/env python3
"""Retain the real SDK DEX gate and require the measured-information runtime.

Class integration is not proof of physical sensor accuracy or model inference.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
import zipfile
import verify_scene_sdk_apk as scene_gate

MEASUREMENT_CLASSES = tuple("Lcom/sentongoharuna/worldsituationroom/" + name + ";" for name in (
    "Duwm1728Measurements", "Duwm1728MeasurementMath", "Duwm1728MeasurementStore",
    "Duwm1728MeasurementSources", "Duwm1728PreviewRate"))


def verify(apk: Path, dependency_report: Path) -> dict:
    report = scene_gate.verify(apk, dependency_report)
    defined = set()
    with zipfile.ZipFile(apk) as archive:
        for name in archive.namelist():
            if re.fullmatch(r"classes(?:[2-9]|[1-9][0-9]+)?\.dex", name):
                defined.update(scene_gate.definitions(archive.read(name)))
    missing = sorted(set(MEASUREMENT_CLASSES) - defined)
    assert not missing, "Actual measured runtime DEX class definitions missing: " + ", ".join(missing)
    report.update(required_measurement_definitions=list(MEASUREMENT_CLASSES),
                  scope="resolved SDK, packaged SDK class definitions and measured telemetry runtime class definitions",
                  physical_sensor_verified=False)
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("apk", type=Path)
    parser.add_argument("dependency_report", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    report = verify(args.apk, args.dependency_report)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
