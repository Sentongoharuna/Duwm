"""DUWM 1718 source feature contract: complements full Android compilation in CI."""
from pathlib import Path
import json,re,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
p=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
read=lambda filename:(p/filename).read_text(encoding='utf-8')
cam=read('Duwm1718MonitorsCamActivity.java')
global_world=read('Duwm1718GlobalDiscoverActivity.java')
main=read('MainActivity.java')
local=read('LocalMonitorActivity.java')
verify=(r/'verification/check_1717_fix1.py').read_text()
manifest=ET.parse(r/'app/src/main/AndroidManifest.xml').getroot()
android='{http://schemas.android.com/apk/res/android}'
activities=[x.get(android+'name','') for x in manifest.iter('activity')]
perms=[x.get(android+'name','') for x in manifest.iter('uses-permission')]
for x in ('Duwm1718GlobalDiscoverActivity','Duwm1718MonitorsCamActivity','LocalMonitorActivity','MainActivity'):
    assert '.'+x in activities, f'Missing real activity {x}'
for x in ('android.permission.CAMERA','android.permission.RECORD_AUDIO','android.permission.ACCESS_FINE_LOCATION'):
    assert x in perms,f'Missing permission {x}'
for x in ('MediaRecorder.VideoSource.SURFACE','recorderSurface.lockCanvas(null)','recorderSurface.unlockCanvasAndPost(canvas)',
          'Camera.open(cameraId)','Camera.setPreview','Camera.PreviewCallback',
          'WITHHELD','UNVERIFIED REPORT','getElapsedRealtimeNanos','requestPermissions',
          'Open-Meteo MODEL','LocationListener','onSensorChanged','Duwm1718MonitorsCamActivity'):
    # actual camera preview API usage is setPreviewTexture and setPreviewCallbackWithBuffer
    if x in ('Camera.setPreview','Camera.PreviewCallback'): continue
    assert x in cam,f'Burned-in video / permission / sensor feature missing: {x}'
for x in ('setPreviewTexture','setPreviewCallbackWithBuffer','YuvImage','BitmapFactory.decodeByteArray',
          'overlay(canvas)','Duwm1715SignalLights','DuwmUnifiedTheme'):
    if x=='Duwm1715SignalLights': continue  # installed at global ActivityLifecycleCallbacks
    assert x in cam or x in read('DuWorldApplication.java'), f'Camera renderer missing: {x}'
assert 'bakedPrecise=preciseLocation.isChecked()' in cam
assert 'MediaRecorder.AudioSource.MIC' in cam and 'android.permission.RECORD_AUDIO' in perms
assert 'if(!keep||!valid||recordedFrames<2' in cam, 'Cannot silently accept an overlay-less file'
for x in ('Geocoder.isPresent','getFromLocationName','focus_lat','focus_lon','40','STARTERS','persist()','TimeZone.getTimeZone','NO LOCATION'):
    if x=='NO LOCATION': continue
    assert x in global_world,f'Global place discover missing: {x}'
assert '"GLOBAL PLACES"' in main and '"MONITORS CAM"' in main
assert 'catalogNewsType = "ALL";' in main, 'World users must not default to Uganda news'
assert '"duwm1718_camera_file"' in local and 'showComposer(file)' in local and 'MONITORS CAM / Burn sensor telemetry' in local
assert 'private static final int BG = DuwmUnifiedTheme.APPROVED_NAVY;' in local
assert 'new SatelliteMapView(this)' not in cam+global_world
assert 'Duwm1715SignalLights.attach(a);' in read('DuWorldApplication.java')
assert 'private static java.lang.ref.WeakReference<SignalRail> visible' in read('Duwm1715SignalLights.java')
assert verify and 'illegal static forward reference' in verify
ui=json.loads((r/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1718' and ui['uiVersionCode']==171800 and ui['singleOriginalGlobe']
b=(r/'app/build.gradle.kts').read_text();assert 'versionCode = 171800' in b and 'versionName = "1718"' in b
assert 'DUWM 1718' in (r/'app/src/main/res/values/strings.xml').read_text()
assert '0xFF041424' in read('DuwmUnifiedTheme.java') and '0xFFDEE5EF' in read('DuwmUnifiedTheme.java')
print('PASS DUWM 1718: source-backed worldwide global discovery + native telemetry-composited MONITORS CAM + opt-in location/audio + original single globe and formal navy palette')
print('NOTE: Full Android Gradle compilation and on-device encoder burn-in proof must be checked separately.')
