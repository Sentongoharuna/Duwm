#!/usr/bin/env python3
"""Executable host regressions plus preservation. Not an Android/API compilation claim."""
from pathlib import Path
import verify_native_stages as native_gate
import hashlib,json,subprocess,tempfile,xml.etree.ElementTree as ET,shutil,re,sys
root=Path(__file__).resolve().parents[1]
java=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
from release_contract import assert_release_at_least
assert assert_release_at_least(root,1728)==172817
ui=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1728.2.17' and ui['uiVersionCode']==172817
protected=json.loads((root/'verification/1728_2_16_PRESERVED_JAVA.json').read_text())
baseline=json.loads((root/'1728_2_16_SOURCE_SHA256.json').read_text())
baseline_java={name:digest for name,digest in baseline.items() if name.startswith('app/src/main/java/') and name.endswith('.java')}
editor_path='app/src/main/java/com/sentongoharuna/worldsituationroom/Duwm1728VideoEditorActivity.java'
assert len(baseline_java)==291 and len(protected)==290
assert protected=={name:digest for name,digest in baseline_java.items() if name!=editor_path},'Preservation must cover every /16 production Java file except the repaired editor'
actual_java={path.relative_to(root).as_posix() for path in (root/'app/src/main/java').rglob('*.java')}
assert actual_java==set(baseline_java),'Unexpected production Java addition/removal outside /17 repair scope'
for component in ('Duwm1728CaptionEditPolicy.java','Duwm1728CaptionEditorDialog.java','Duwm1728BroadcastReviewActivity.java'):
    assert any(name.endswith('/'+component) for name in protected),component
for name,digest in protected.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
assert any(n.endswith('SatelliteMapView.java') for n in protected)
assert any(n.endswith('Duwm1718MonitorsCamActivity.java') for n in protected)
print('PASS',len(protected),'unchanged /16 Java components, including original globe and clean camera.')
for file in (root/'app/src').rglob('*.xml'):ET.parse(file)
editor=(java/'Duwm1728VideoEditorActivity.java').read_text();renderer=(java/'Duwm1728OverlayRenderer.java').read_text()
# The reported /16 defect clips two-line marks within their own row; an
# ancestor ScrollView cannot reveal pixels clipped by that immediate parent.
trim_row=editor.split('LinearLayout trimControls=new LinearLayout(this);',1)[1].split('controlColumn.addView(trimControls);',1)[0]
assert 'trimControls.setBaselineAligned(false)' in trim_row and 'trimControls.setGravity(Gravity.CENTER_VERTICAL)' in trim_row
assert 't.setMinHeight(dp(48))' in editor and 'BROADCAST STUDIO  /17' in editor
assert native_gate.STAGES==('signals','graphics','exports4','framing','inset1','review','editor_controls','review_controls','recovery','composition','caption_editing'),'All eleven native stages remain mandatory'
# Source-wiring guards for the three observed /16 failures. These do not stand
# in for the Android assertions or claim that a frame was actually displayed.
native_dir=root/'app/src/androidTest/java/com/sentongoharuna/worldsituationroom'
native_checks=(native_dir/'DuwmBroadcastChecks.java').read_text()
saved_review=native_checks.split('void savedVideoReview(',1)[1].split('private File reviewFixture(',1)[0]
assert 'boolean publishedDeleted=false;' in saved_review
assert 'publishedDeleted=deleted==1;' in saved_review and 'check(publishedDeleted,' in saved_review
assert 'if(!publishedDeleted)target.getContentResolver().delete(published,null,null);' in saved_review
assert '"VIDEO UNAVAILABLE"' in saved_review and '!flag(runner,missing,"ready")' in saved_review and '!flag(runner,missing,"available")' in saved_review
assert '!missing.getWindow().getDecorView().findViewWithTag("broadcast-review-share").isEnabled()' in saved_review
assert 'phase("review.missing_file.verified")' in saved_review
landscape=native_checks.split('private void editorLandscape(',1)[1].split('private boolean reviewPlaying(',1)[0]
for token in ('visible.width()>=control.getWidth()-2','visible.height()>=control.getHeight()-2',
              '"local_bounds"','"visible_bounds"','"row_bounds"','"minimum_touch_height_px"',
              'texture==original.get()&&texture.getParent()==parent.get()',
              'getHeight()>=Math.round(48*editor.getResources().getDisplayMetrics().density)',
              'Math.abs(editorPosition(runner,editor)-before)<=80'):
    assert token in landscape,token
assert 'ANDROID-EDITOR-TRIM-LANDSCAPE-BOUNDS.json' in native_gate.REQUIRED['editor_controls']
fullscreen=native_checks.split('phase("review_controls.fullscreen")',1)[1].split('phase("review_controls.persist")',1)[0]
assert 'DuwmRenderedFrameCapture.captureReviewFullscreen(runner,first,originalVideo.get(),folder,"ANDROID-REVIEW-FULLSCREEN")' in fullscreen
assert 'origin=captured.origin,size=captured.size' in fullscreen
assert fullscreen.index('fullscreen.compress(')<fullscreen.index('proof.assertUnobstructed(')<fullscreen.index('check(captured.ready,')<fullscreen.index('screenColour(fullscreen,')<fullscreen.index('fullscreen.recycle()')
for token in ('video==originalVideo.get()','Arrays.equals(origin,currentOrigin)',
              'size[0]==video.getWidth()&&size[1]==video.getHeight()',
              '!Rect.intersects(picture,exitRect)', 'Math.abs(size[0]/(float)size[1]-16f/9f)<.03f',
              '.10f,.45f,0xFFC91010','.90f,.50f,0xFF1043D0'):
    assert token in fullscreen,token
capture_helper=(native_dir/'DuwmRenderedFrameCapture.java').read_text()
for token in ('TIMEOUT_MS = 5000','CHANNEL_TOLERANCE = 40','runner.getUiAutomation().takeScreenshot()',
              'before.matches(fence.geometry) && before.matches(after)','consecutive >= 2',
              'registerFrameCommitCallback','!layoutPending','name + "-CAPTURE.txt"'):
    assert token in capture_helper,token
assert 'Bitmap.createBitmap' not in capture_helper and 'new Canvas(' not in capture_helper
assert 'ANDROID-REVIEW-FULLSCREEN-CAPTURE.txt' in native_gate.REQUIRED['review_controls']
print('PASS /17 repair source wiring; actual layout, scoped cleanup and composed playback frames still require all eleven Android stages.')
assert 'parseSrtCues' in editor and 'convertSrt(text)' not in editor
assert 'Duwm1728ExportPreflight.inspect' in editor and 'Duwm1728ExportPreflight.inspect' in renderer
assert 'outputPlan!=null' in editor and 'prepareTimelines(s)' in editor
assert 'sourceAtProgress' in editor and 'ticker_origin_ms' in editor
assert 'clipEnd-clipStart' in editor and 'caption_timebase' in editor
assert 'renderedCaptions' in renderer and 'renderedTickers' in renderer
assert '45000L' not in renderer and 'fps=24' not in renderer
assert 'planWorker.shutdownNow()' in editor and 'main.removeCallbacks(planKick)' in editor
assert 'startAi(spec())' not in editor
proof=root/'verification/results/1728_2_17';proof.mkdir(parents=True,exist_ok=True)
subprocess.run([sys.executable,str(root/'verification/check_ai_entrypoints.py')],check=True)
with tempfile.TemporaryDirectory() as temp:
    sources=['Duwm1728BroadcastComposition.java','Duwm1728BroadcastLayout.java','Duwm1728BroadcastTimeline.java','Duwm1728TickerTimeline.java','Duwm1728SubtitleImport.java','Duwm1728FramePlan.java','Duwm1728EditorTrimPolicy.java','Duwm1728BroadcastReviewState.java','Duwm1728RecoveryFilePolicy.java']
    subprocess.run(['javac','--release','17','-d',temp,*[str(java/n) for n in sources],str(root/'verification/broadcast/BroadcastRenderTest.java'),str(root/'verification/broadcast/BroadcastCompositionTest.java'),str(root/'verification/broadcast/baseline/Duwm1728BroadcastLayout14.java'),str(root/'verification/broadcast/BroadcastTimelineTest.java'),str(root/'verification/broadcast/BroadcastFramingTest.java'),str(root/'verification/broadcast/BroadcastFramingRender.java'),str(root/'verification/EditorTrimPolicyTest.java'),str(root/'verification/BroadcastReviewStateTest.java'),str(root/'verification/RecoveryFilePolicyTest.java')],check=True)
    for name,args in [('BroadcastRenderTest',[str(proof)]),('BroadcastCompositionTest',[str(proof)]),('BroadcastTimelineTest',[]),('EditorTrimPolicyTest',[]),('BroadcastReviewStateTest',[]),('RecoveryFilePolicyTest',[]),('BroadcastFramingTest',[]),('BroadcastFramingRender',[str(proof)])]:
        result=subprocess.run(['java','-Djava.awt.headless=true','-cp',temp,name if name=='EditorTrimPolicyTest' else 'com.sentongoharuna.worldsituationroom.'+name,*args],capture_output=True,text=True,check=True)
        print(result.stdout,end='');(proof/(name+'.txt')).write_text(result.stdout)
    pkg=Path(temp)/'src/com/sentongoharuna/worldsituationroom';pkg.mkdir(parents=True)
    for name in ('FeedStatus.java','Duwm1724SignalFlow.java','DuwmUnifiedTheme.java','Duwm1728SignalMotion.java','Duwm1728CaptureHealth.java'):
        shutil.copyfile(java/name,pkg/name)
    layer=re.search(r'public enum Layer\s*\{([^}]+)\}',(java/'Signal.java').read_text()).group(1)
    (pkg/'Signal.java').write_text('package com.sentongoharuna.worldsituationroom; public final class Signal {public enum Layer {'+layer+'}}')
    for name in ('SignalMotionTest.java','CaptureHealthTest.java'):shutil.copyfile(root/'verification'/name,pkg/name)
    subprocess.run(['javac','--release','17','-d',temp,*map(str,pkg.glob('*.java'))],check=True)
    for name in ('SignalMotionTest','CaptureHealthTest'):
        result=subprocess.run(['java','-cp',temp,'com.sentongoharuna.worldsituationroom.'+name],capture_output=True,text=True,check=True)
        print(result.stdout,end='');(proof/(name+'.txt')).write_text(result.stdout)
print('PASS /17 wiring, exact identity and XML. Host composition evidence is not native recording or encoding proof; Android runtime, physical phone and live AI remain separate gates.')

pipe=(java/'Duwm1728EglVideoPipe.java').read_text();preflight=(java/'Duwm1728ExportPreflight.java').read_text()
for token in ('s.frameMode=frameMode','Duwm1728FramePlan.create','Duwm1728FramePlan.dimensions','setOpaque(false)','frame_mode','showFraming'):
    assert token in editor,token
assert 'destination' in pipe and 'Duwm1728FramePlan.create' in pipe
assert 'spec.frameMode,spec.frameX,spec.frameY' in renderer
assert 'Duwm1728FramePlan.dimensions' in preflight
assert 'broadcast.framingExports(this,proof.directory())' in (root/'app/src/androidTest/java/com/sentongoharuna/worldsituationroom/DuwmSignalInstrumentation.java').read_text()
assert 'showCompositionGuides' not in renderer and 'showBroadcast' not in renderer
review=(java/'Duwm1728BroadcastReviewActivity.java').read_text()
gallery=(java/'Duwm1726GalleryLibraryActivity.java').read_text()
publisher=(java/'Duwm1724GalleryPublisher.java').read_text()
assert 'Duwm1728BroadcastReviewActivity' in (root/'app/src/main/AndroidManifest.xml').read_text()
assert 'Duwm1728BroadcastReviewActivity.open' in gallery
assert 'Uri.fromFile(dest)' not in publisher
assert 'ACTION_SEND' in review and 'FLAG_GRANT_READ_URI_PERMISSION' in review and 'ClipData' in review
print('PASS shared framing integration, Gallery content URI and native review wiring. Runtime playback/share assertions run in Android.')

subprocess.run([sys.executable,str(root/'verification/NativeStageGateTest.py')],check=True)

composition=(java/'Duwm1728BroadcastComposition.java').read_text()
assert 'Duwm1728BroadcastComposition' in editor and 's.composition=' in editor
assert 'r.composition=' in renderer and 'composition' in (java/'Duwm1728BroadcastLayout.java').read_text()
assert 'composition' in (root/'verification/verify_native_stages.py').read_text()
print('PASS composition wiring from editor to shared preview/export layout; native execution remains separate.')

subprocess.run(["bash",str(root/"verification/run_caption_edit_host_tests.sh"),str(proof)],check=True)
print("PASS /17 caption editing host policy. Actual native UI/encoder acceptance remains separate.")

subprocess.run([sys.executable,str(root/"verification/package_1728_2_17.py"),"--check-workflow-contexts"],check=True)
