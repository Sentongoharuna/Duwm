#!/usr/bin/env python3
"""Complete-source 1719 acceptance gate; does not substitute for Android javac/APK runtime tests."""
from pathlib import Path
import json,re,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
j=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
get=lambda n:(j/n).read_text(encoding='utf-8')
my=get('Duwm1719MyWorldActivity.java')
cam=get('Duwm1718MonitorsCamActivity.java')
global_places=get('Duwm1718GlobalDiscoverActivity.java')
main=get('MainActivity.java')
manifest=ET.parse(r/'app/src/main/AndroidManifest.xml').getroot()
android='{http://schemas.android.com/apk/res/android}'
assert '.Duwm1719MyWorldActivity' in [a.get(android+'name','') for a in manifest.iter('activity')]
assert main.count('"MY WORLD"')==1 and main.count('"MONITORS CAM"')>=1
assert 'new Intent(this,Duwm1719MyWorldActivity.class)' in global_places
for value in ('duwm1718_follow_places','"followed"','TimeZone.getAvailableIDs()','TIME ZONE NOT SET',
              'getSharedPreferences(USER_PREFS,MODE_PRIVATE)','DuwmPlaceMapActivity','Duwm1716SignalCenterActivity',
              'LocalMonitorActivity','Duwm1718MonitorsCamActivity','DuwmOptionsActivity',
              'NO USER',):
    if value == 'NO USER':continue
    assert value in my,('My World feature missing',value)
for value in ('readiness()','showReadiness','SourceWeather' if False else 'sourceWeather()',
              'gpsAccuracy()','lastHeadingAt','TimeZone' if False else 'WITHHELD',
              'new AlertDialog.Builder(this).setTitle("Confirm MONITORS CAM recording")',
              'MediaRecorder.VideoSource.SURFACE','recorderSurface.lockCanvas(null)',
              'recorderSurface.unlockCanvasAndPost(canvas)','UNVERIFIED REPORT',
              'recordedFrames<2','locationFresh(lastLocation)','weatherReceivedAt=SystemClock.elapsedRealtime()'):
    assert value in cam,('Monitors Cam feature missing',value)
assert 'preciseLocation.setChecked(false)' in cam
assert 'new SatelliteMapView' not in my+cam+global_places
assert 'private static java.lang.ref.WeakReference<SignalRail> visible' in get('Duwm1715SignalLights.java')
assert '0xFF041424' in get('DuwmUnifiedTheme.java') and '0xFFDEE5EF' in get('DuwmUnifiedTheme.java')
ui=json.loads((r/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1719' and ui['uiVersionCode']==171900 and ui['singleOriginalGlobe']
gradle=(r/'app/build.gradle.kts').read_text();assert 'versionCode = 171900' in gradle and 'versionName = "1719"' in gradle
assert 'DUWM 1719' in (r/'app/src/main/res/values/strings.xml').read_text()
assert 'DUWM 1719  /  GLOBAL DISCOVERY' in global_places
print('PASS 1719 full-source: global local My World, IANA clocks, on-device interests, nonfabricated source states, MONITORS CAM preflight and original protected globe')
print('NOTE full Android compile, signing, actual camera recording and MP4 playback still require GitHub/device verification.')
