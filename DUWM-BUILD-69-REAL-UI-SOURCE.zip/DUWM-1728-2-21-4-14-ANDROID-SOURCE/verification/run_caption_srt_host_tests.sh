#!/usr/bin/env bash
# Pure Java caption-file bytes, source-time semantics and production timeline comparison.
set -euo pipefail
srt_project="$(cd "$(dirname "$0")/.." && pwd)"
srt_proof="${1:-$srt_project/verification/caption-srt-host-proof}"
srt_javac="${JAVAC:-${JAVA_HOME:+$JAVA_HOME/bin/}javac}"
srt_java="${JAVA:-${JAVA_HOME:+$JAVA_HOME/bin/}java}"
srt_build="$(mktemp -d "${TMPDIR:-/tmp}/duwm-caption-srt-host.XXXXXX")"
trap 'rm -rf -- "$srt_build"' EXIT
srt_source="$srt_project/app/src/main/java/com/sentongoharuna/worldsituationroom"
"$srt_javac" --release 17 -encoding UTF-8 -d "$srt_build" \
  "$srt_source/Duwm1728BroadcastComposition.java" \
  "$srt_source/Duwm1728BroadcastLayout.java" "$srt_source/Duwm1728ClearPictureLayout.java" \
  "$srt_source/Duwm1728HeadlineFit.java" \
  "$srt_source/Duwm1728CaptionPages.java" \
  "$srt_source/Duwm1728TickerTimeline.java" \
  "$srt_source/Duwm1728BroadcastTimeline.java" \
  "$srt_source/Duwm1728CaptionEditPolicy.java" \
  "$srt_source/Duwm1728CaptionSrt.java" \
  "$srt_source/Duwm1728SubtitleImport.java" \
  "$srt_project/verification/broadcast/CaptionSrtTest.java" \
  "$srt_project/verification/broadcast/BroadcastTimelineTest.java"
"$srt_java" -Xmx512m -Djava.awt.headless=true -cp "$srt_build" \
  com.sentongoharuna.worldsituationroom.CaptionSrtTest "$srt_proof"
"$srt_java" -Djava.awt.headless=true -cp "$srt_build" \
  com.sentongoharuna.worldsituationroom.BroadcastTimelineTest
