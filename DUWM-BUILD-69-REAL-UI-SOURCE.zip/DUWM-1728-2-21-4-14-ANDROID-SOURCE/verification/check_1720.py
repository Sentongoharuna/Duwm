#!/usr/bin/env python3
"""1720 screenshot-led UI, genuine sensor controls, worldwide navigation: source validation only."""
from pathlib import Path
import json,xml.etree.ElementTree as ET,re
r=Path(__file__).resolve().parents[1]
j=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
read=lambda name:(j/name).read_text(encoding='utf-8')
main=read('MainActivity.java');cam=read('Duwm1718MonitorsCamActivity.java')
world=read('Duwm1718GlobalDiscoverActivity.java');rail=read('Duwm1715SignalLights.java')
formal=read('Duwm1715FormalUi.java');mapview=read('SatelliteMapView.java')
my=read('Duwm1719MyWorldActivity.java');theme=read('DuwmUnifiedTheme.java')
gradle=(r/'app/build.gradle.kts').read_text();ui=json.loads((r/'app/src/main/assets/duwm_release_ui.json').read_text())
assert 'versionCode = 172000' in gradle and 'versionName = "1720"' in gradle
assert 'DUWM 1720' in (r/'app/src/main/res/values/strings.xml').read_text()
assert ui['uiRevision']=='1720' and ui['uiVersionCode']==172000 and ui['singleOriginalGlobe']
assert main.count('new SatelliteMapView(this)')==1 and 'SignalTickerRailView' in main
for k,v in {'BG':'APPROVED_NAVY','PANEL':'PANEL','PANEL_ALT':'PANEL_SELECTED','CYAN':'ACCENT',
            'TEXT':'TEXT','MUTED':'MUTED','LINE':'BORDER'}.items():
    assert f'private static final int {k} = DuwmUnifiedTheme.{v};' in main,k
for s in ('BACKGROUND = 0xFF041424','BORDER = 0xFFDEE5EF','TEXT = 0xFFF5F7FA','MUTED = 0xFFA0A5AE'):
    assert s in theme,s
assert 'Color.rgb(5, 13, 34)' not in mapview
assert 'DuwmUnifiedTheme.APPROVED_NAVY' in mapview
assert 'shell.setOnApplyWindowInsetsListener' in rail
assert 'insets.getSystemWindowInsetTop()' in rail and 'insets.getSystemWindowInsetBottom()' in rail
assert 'view.setPadding(0,top,0,bottom)' in rail
assert 'root.setOnApplyWindowInsetsListener' not in main, 'Do not double-inset globe root'
assert 'View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN' in formal and 'View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION' in formal
assert 'private static java.lang.ref.WeakReference<SignalRail> visible' in rail
assert rail.index('private static java.lang.ref.WeakReference<SignalRail> visible')<rail.index('private static final Runnable COALESCED_REFRESH')
for s in ('focusOnce()', 'adjustExposure(-1)','adjustExposure(1)','getMinExposureCompensation()',
          'getMaxExposureCompensation()','camera.autoFocus','PREVIEW GRID ON / OFF','previewGrid.invalidate()',
          'recorderSurface.lockCanvas(null)','recorderSurface.unlockCanvasAndPost(canvas)',
          'preciseLocation.setChecked(false)','UNVERIFIED REPORT','sourceWeather()',
          'localLocation' if False else 'locationFresh(lastLocation)'):
    assert s in cam,('Cam missing',s)
assert 'showGrid=true' in cam and 'new View(this)' in cam
assert 'MediaRecorder.VideoSource.SURFACE' in cam and 'recordedFrames<2' in cam
for s in ('REGIONS={"ALL","AFRICA","EUROPE","ASIA","MIDDLE EAST","AMERICAS","OCEANIA"}',
          'renderRegionControls()', 'activeRegion.equals(regionOf(raw))','Intent.ACTION_SEND',
          'getFromLocationName(q,1)', '"duwm1718_follow_places"'):
    if s == '"duwm1718_follow_places"': assert s in world
    else: assert s in world,s
assert 'Duwm1719MyWorldActivity.class' in world and 'Duwm1718GlobalDiscoverActivity.class' in my
assert 'new SatelliteMapView' not in world+cam+my
for f in (r/'app/src/main/res').rglob('*.xml'): ET.parse(f)
manifest=ET.parse(r/'app/src/main/AndroidManifest.xml').getroot()
android='{http://schemas.android.com/apk/res/android}'
activities=[x.attrib.get(android+'name','') for x in manifest.iter('activity')]
for activity in ('.Duwm1718MonitorsCamActivity','.Duwm1718GlobalDiscoverActivity','.Duwm1719MyWorldActivity'):
    assert activity in activities
assert len(list(j.glob('*.java')))>=252
print('PASS 1720 layout/insets, original globe, exact palette, genuine camera controls, geographic regional filtering and source-aware sharing')
print('NOTE: Real APK compilation, platform Camera API compatibility and MP4 burn-in on a physical device remain separate tests')
