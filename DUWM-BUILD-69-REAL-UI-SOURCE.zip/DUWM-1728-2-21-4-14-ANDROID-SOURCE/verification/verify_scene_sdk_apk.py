#!/usr/bin/env python3
"""Verify real SDK/app class definitions in an assembled APK, not string matches.

This does not execute the model. A supported physical device must separately
establish model availability and actual inference from camera pixels.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import zipfile

COORDINATE = "com.google.mlkit:genai-image-description:1.0.0-beta1"
SDK_CLASSES = tuple("Lcom/google/mlkit/genai/imagedescription/" + name + ";" for name in (
    "ImageDescription", "ImageDescriber", "ImageDescriberOptions",
    "ImageDescriptionRequest", "ImageDescriptionResult"))
APP_CLASSES = tuple("Lcom/sentongoharuna/worldsituationroom/" + name + ";" for name in (
    "Duwm1728SceneAnalyzer", "Duwm1728SceneTimeline", "Duwm1728SceneStore"))


def definitions(data: bytes) -> set[str]:
    """Read the DEX class_def table; a descriptor in string_ids is insufficient."""
    if len(data) < 112 or not re.fullmatch(rb"dex\n0[3-4][0-9]\x00", data[:8]):
        raise ValueError("Invalid or unsupported standard DEX header")
    def u32(at: int) -> int:
        if at < 0 or at + 4 > len(data):
            raise ValueError("DEX offset outside file")
        return struct.unpack_from("<I", data, at)[0]
    if u32(32) != len(data) or u32(36) != 112 or u32(40) != 0x12345678:
        raise ValueError("Unexpected DEX size, header or byte order")
    string_count, string_offset = u32(56), u32(60)
    type_count, type_offset = u32(64), u32(68)
    class_count, class_offset = u32(96), u32(100)
    for count, offset, width in ((string_count, string_offset, 4),
                                  (type_count, type_offset, 4),
                                  (class_count, class_offset, 32)):
        if count and (offset < 112 or offset + count * width > len(data)):
            raise ValueError("DEX table outside file")
    def descriptor(index: int) -> str:
        if index >= type_count:
            raise ValueError("DEX class has invalid type index")
        string_index = u32(type_offset + index * 4)
        if string_index >= string_count:
            raise ValueError("DEX type has invalid string index")
        start = u32(string_offset + string_index * 4)
        # Skip the bounded ULEB128 UTF-16 length prefix. Required descriptors
        # are ASCII, so no MUTF-8 interpretation is needed for exact matching.
        for _ in range(5):
            if start >= len(data):
                raise ValueError("Truncated DEX string length")
            byte = data[start]
            start += 1
            if byte < 128:
                break
        else:
            raise ValueError("Invalid DEX string length")
        end = data.find(b"\x00", start)
        if end < 0:
            raise ValueError("Unterminated DEX descriptor")
        return data[start:end].decode("utf-8", errors="replace")
    return {descriptor(u32(class_offset + i * 32)) for i in range(class_count)}


def verify(apk: Path, dependency_report: Path) -> dict:
    dependency = json.loads(dependency_report.read_text())
    assert dependency.get("status") == "PASS", "SDK dependency resolution did not pass"
    assert dependency.get("coordinate") == COORDINATE, "Wrong scene SDK coordinate"
    artifact_hash = dependency.get("artifact_sha256", "")
    assert re.fullmatch(r"[0-9a-f]{64}", artifact_hash), "Missing resolved SDK artifact digest"
    assert dependency.get("artifact_bytes", 0) > 0, "Empty resolved SDK artifact"
    defined = set()
    dex_files = []
    with zipfile.ZipFile(apk) as archive:
        assert archive.testzip() is None, "Corrupt APK ZIP"
        for name in archive.namelist():
            if re.fullmatch(r"classes(?:[2-9]|[1-9][0-9]+)?\.dex", name):
                payload = archive.read(name)
                classes = definitions(payload)
                assert not (classes & defined), "Duplicate class definition across DEX files"
                defined.update(classes)
                dex_files.append({"name": name, "bytes": len(payload),
                                  "sha256": hashlib.sha256(payload).hexdigest(),
                                  "class_definitions": len(classes)})
    assert dex_files, "APK contains no standard classes DEX"
    missing = sorted(set(SDK_CLASSES + APP_CLASSES) - defined)
    assert not missing, "Actual DEX class definitions missing: " + ", ".join(missing)
    return {"schema": 1, "status": "PASS", "scope": "resolved SDK and packaged DEX class definitions",
            "coordinate": COORDINATE, "dependency_artifact_sha256": artifact_hash,
            "apk_sha256": hashlib.sha256(apk.read_bytes()).hexdigest(),
            "required_sdk_definitions": list(SDK_CLASSES),
            "required_app_definitions": list(APP_CLASSES), "dex": dex_files,
            "model_inference_verified": False, "physical_camera_verified": False,
            "model_inference_status": "NOT_RUN_REQUIRES_SUPPORTED_PHYSICAL_DEVICE"}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("apk", type=Path)
    parser.add_argument("dependency_report", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    report = verify(args.apk, args.dependency_report)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
