#!/usr/bin/env python3
"""Run all retained /21 host regressions plus /21/2 measured telemetry policy/integration gates.

The immutable historical checker is adapted only at its release/preservation
prelude, exact current studio label, output directory, and stage-list prefix.
Every historical behavioral assertion and host test still executes on CURRENT
production source. None of these checks claims actual ML Kit compilation,
native Android execution, or physical-device model inference.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

import package_1728_2_21_2 as packaging
from release_contract import assert_release_at_least
import verify_native_stages as native_gate

ROOT = Path(__file__).resolve().parents[1]
JAVA_ROOT = "app/src/main/java/com/sentongoharuna/worldsituationroom/"
CHANGED_JAVA = {JAVA_ROOT + name for name in (
    "Duwm1718MonitorsCamActivity.java", "Duwm1728VideoEditorActivity.java",
    "Duwm1728BroadcastLayout.java", "Duwm1728OverlayRenderer.java", "Duwm1728LiveSceneView.java")}
ADDED_JAVA = {JAVA_ROOT + name for name in (
    "Duwm1728Measurements.java", "Duwm1728MeasurementMath.java", "Duwm1728MeasurementStore.java",
    "Duwm1728MeasurementSources.java", "Duwm1728PreviewRate.java")}



def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_current_release() -> tuple[dict, dict]:
    baseline_path = ROOT / "1728_2_21_1_SOURCE_SHA256.json"
    assert digest(baseline_path) == packaging.BASELINE21_1_MANIFEST_SHA256, "Immutable delivered /21/1 manifest changed"
    baseline = json.loads(baseline_path.read_text())
    for name in ("verification/check_1728_2_21.py", "verification/package_1728_2_21.py",
                 "verification/preserved_sources_1728_2_21.json",
                 "1728_2_21_BUILD_NOTES.md", "1728_2_21_ACCEPTANCE.json",
                 "verification/check_1728_2_21_1.py", "verification/package_1728_2_21_1.py",
                 "verification/preserved_sources_1728_2_21_1.json",
                 "1728_2_21_1_BUILD_NOTES.md", "1728_2_21_1_ACCEPTANCE.json"):
        assert digest(ROOT / name) == baseline[name], "Historical /21 or /21/1 evidence changed: " + name
    assert assert_release_at_least(ROOT, 1728) == 172823
    ui = json.loads((ROOT / "app/src/main/assets/duwm_release_ui.json").read_text())
    assert ui["uiRevision"] == "1728.2.21.2" and ui["uiVersionCode"] == 172823
    assert ui["displayRevision"] == "1728.2/21/2"
    names = [el.text for el in ET.parse(ROOT / "app/src/main/res/values/strings.xml").getroot().findall("string")
             if el.get("name") == "app_name"]
    assert names == ["DUWM 1728.2/21/2 • DEVELOP.UGANDA"]
    build = (ROOT / "app/build.gradle.kts").read_text()
    assert re.search(r'minSdk\s*=\s*26\b', build), "Real SDK API baseline missing"
    assert 'implementation("com.google.mlkit:genai-image-description:1.0.0-beta1")' in build
    assert "android.useAndroidX=true" in (ROOT / "gradle.properties").read_text()
    baseline_java = {name: sha for name, sha in baseline.items()
                     if name.startswith("app/src/main/java/") and name.endswith(".java")}
    assert len(baseline_java) == 309 and CHANGED_JAVA <= set(baseline_java)
    preserved = json.loads((ROOT / "verification/preserved_sources_1728_2_21_2.json").read_text())
    assert preserved == {name: sha for name, sha in baseline_java.items() if name not in CHANGED_JAVA}
    assert len(preserved) == 304, "Preservation must cover every unscoped /21/1 production Java source"
    actual_java = {p.relative_to(ROOT).as_posix() for p in (ROOT / "app/src/main/java").rglob("*.java")}
    assert actual_java == set(baseline_java) | ADDED_JAVA, "Unexpected production Java addition or removal"
    for name, sha in preserved.items():
        assert digest(ROOT / name) == sha, "Unscoped production change: " + name
    packaging.require_native_contract(ROOT)
    assert native_gate.STAGES == packaging.EXPECTED_NATIVE_STAGES and len(native_gate.STAGES) == 18
    print("PASS /21/2 identity, genuine SDK dependency declaration, all 304 preserved /21/1 Java components, and retained seventeen plus one native contract.")
    return baseline, preserved


def replace_once(source: str, before: str, after: str) -> str:
    assert source.count(before) == 1, "Historical checker adaptation anchor changed: " + before
    return source.replace(before, after, 1)


def run_retained_checks() -> None:
    original = ROOT / "verification/check_1728_2_21.py"
    source = original.read_text()
    assert digest(original) == "89f7536560872ac1869ed7d2498c96d88c521467449db7eb71352db8231a2ac7"
    start = source.index("from release_contract import assert_release_at_least\n")
    end = source.index("for file in (root/'app/src').rglob('*.xml'):ET.parse(file)\n")
    assert end > start
    source = source[:start] + "baseline,protected=_validate_current_release()\n" + source[end:]
    source = replace_once(source, "'BROADCAST STUDIO  /21'", "'BROADCAST STUDIO  /21/2'")
    source = replace_once(source, "assert native_gate.STAGES==(", "assert native_gate.STAGES[:16]==(")
    source = replace_once(source, "proof=root/'verification/results/1728_2_21';",
                          "proof=root/'verification/results/1728_2_21_2';")
    source = replace_once(source, 'root/"verification/package_1728_2_21.py"',
                          'root/"verification/package_1728_2_21_2.py"')
    # The historical body runs against this release's actual source, not a copied
    # baseline or selectively restored old layout. No assertion is disabled.
    namespace = {"__name__": "__main__", "__file__": str(original),
                 "_validate_current_release": validate_current_release}
    exec(compile(source, str(original) + " [/21/2 release adapter]", "exec"), namespace)


def main() -> None:
    tested_sources = {name: digest(ROOT / name) for name in sorted(CHANGED_JAVA | ADDED_JAVA)}
    run_retained_checks()
    proof = ROOT / "verification/results/1728_2_21_2"
    for runner, folder in (("run_scene_timeline_host_tests.sh", "scene-timeline"),
                           ("run_scene_change_host_tests.sh", "scene-change"),
                           ("run_scene_layout_host_tests.sh", "scene-layout"),
                           ("run_measurement_policy_host_tests.sh", "measurement-policy"),
                           ("run_preview_rate_host_tests.sh", "preview-rate"),
                           ("run_measured_layout_host_tests.sh", "measured-layout")):
        path = ROOT / "verification" / runner
        assert path.is_file(), "Required scene host runner missing: " + runner
        subprocess.run(["bash", str(path), str(proof / folder)], check=True)
    subprocess.run([sys.executable, str(ROOT / "verification/run_scene_analyzer_host_tests.py"),
                    "--out", str(proof / "scene-analyzer")], check=True)
    result = subprocess.run([sys.executable, str(ROOT / "verification/SceneSdkApkGateTest.py")],
                            capture_output=True, text=True)
    (proof / "SCENE-SDK-CLASS-GATE-HOST.txt").write_text(result.stdout + result.stderr)
    print(result.stdout + result.stderr, end="")
    result.check_returncode()
    measured_gate = subprocess.run([sys.executable, str(ROOT / "verification/MeasuredApkGateTest.py")],
                                   capture_output=True, text=True)
    (proof / "MEASURED-APK-CLASS-GATE-HOST.txt").write_text(measured_gate.stdout + measured_gate.stderr)
    print(measured_gate.stdout + measured_gate.stderr, end="")
    measured_gate.check_returncode()
    analyzer = (ROOT / JAVA_ROOT / "Duwm1728SceneAnalyzer.java").read_text()
    for name in ("ImageDescription", "ImageDescriber", "ImageDescriberOptions",
                 "ImageDescriptionRequest", "ImageDescriptionResult"):
        assert "import com.google.mlkit.genai.imagedescription." + name + ";" in analyzer, name
    for invocation in ("ImageDescription.getClient(", ".checkFeatureStatus(", ".runInference("):
        assert invocation in analyzer, "Actual SDK invocation missing: " + invocation
    assert tested_sources == {name: digest(ROOT / name) for name in tested_sources}, "Production source changed during host verification; rerun after edits finish"
    report = {
        "schema": 1, "build": "1728.2/21/2", "status": "PASS",
        "scope": "retained host regressions, scene and measured telemetry fixtures, source wiring and release contracts",
        "preserved_production_java": 304, "required_native_stages": list(native_gate.STAGES),
        "tested_production_sources_sha256": tested_sources,
        "actual_sdk_compilation_verified": False, "native_encoder_verified": False,
        "physical_sensor_verified": False,
        "model_inference_verified": False, "physical_camera_verified": False,
    }
    (proof / "MEASURED-TELEMETRY-HOST-RESULT.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
