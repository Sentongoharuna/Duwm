#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]
p=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
s=(p/'MainActivity.java').read_text()
t=(p/'DuwmUnifiedTheme.java').read_text()
f=(p/'Duwm1724SignalFlow.java').read_text()
assert s.count('new SatelliteMapView(this)')==1
assert 'brand.setOnClickListener(view -> startActivity(new Intent(this, Duwm1716SignalCenterActivity.class)))' in s
assert 'refreshWorldStatusHeader1726()' in s
assert 'Duwm1724SignalFlow.fromFeed(' in s and 'budgetFor(layer)' in s
assert '0xFF081B2B' in t and '0xFF0D47A1' in t and '0xFF0D47A1' in f
assert '0xFFD50000' in f and '0xFF00C853' in f
print('PASS 1726 FIX1 header is live and clickable; darker blue; original globe retained')
