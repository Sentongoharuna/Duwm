#!/usr/bin/env python3
"""Negative DEX-class gate fixtures. Temporary records are not compiled APKs."""
import json
from pathlib import Path
import struct
import tempfile
import unittest
import zipfile

import verify_scene_sdk_apk as gate


def dex_fixture(names, defined):
    # Just enough synthetic DEX-table structure to exercise our class_def
    # reader. This is deliberately not executable bytecode or native evidence.
    string_offset = 112
    type_offset = string_offset + len(names) * 4
    class_offset = type_offset + len(names) * 4
    payload_offset = class_offset + len(defined) * 32
    data = bytearray(payload_offset)
    data[:8] = b"dex\n035\x00"
    for offset, value in ((36,112),(40,0x12345678),(56,len(names)),(60,string_offset),
                          (64,len(names)),(68,type_offset),(96,len(defined)),(100,class_offset)):
        struct.pack_into("<I",data,offset,value)
    for index,name in enumerate(names):
        assert len(name.encode())<128
        struct.pack_into("<I",data,string_offset+index*4,len(data))
        struct.pack_into("<I",data,type_offset+index*4,index)
        data.extend(bytes([len(name)]));data.extend(name.encode());data.append(0)
    for index,name in enumerate(defined):
        struct.pack_into("<I",data,class_offset+index*32,names.index(name))
    struct.pack_into("<I",data,32,len(data))
    return bytes(data)


class SceneSdkApkGateTest(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix="scene-dex-gate-unit-")
        self.root=Path(self.temp.name)
        self.apc=self.root/"unit-structure.zip"
        self.dependency=self.root/"unit-dependency.json"
        self.dependency.write_text(json.dumps({
            "status":"PASS","coordinate":gate.COORDINATE,
            "artifact_sha256":"0"*64,"artifact_bytes":1}))
        self.names=list(gate.SDK_CLASSES+gate.APP_CLASSES)
    def tearDown(self):
        self.temp.cleanup()
    def archive(self,defined,filename="classes.dex"):
        with zipfile.ZipFile(self.apc,"w") as z:
            z.writestr(filename,dex_fixture(self.names,defined))
    def test_class_definition_tables_are_recognized_without_inference_claim(self):
        self.archive(self.names)
        report=gate.verify(self.apc,self.dependency)
        self.assertEqual("PASS",report["status"])
        self.assertIs(False,report["model_inference_verified"])
        self.assertIs(False,report["physical_camera_verified"])
    def test_references_and_descriptor_strings_cannot_replace_sdk_class_definitions(self):
        self.archive(list(gate.APP_CLASSES))
        with self.assertRaisesRegex(AssertionError,"class definitions missing"):
            gate.verify(self.apc,self.dependency)
    def test_any_missing_sdk_definition_fails(self):
        for name in gate.SDK_CLASSES:
            with self.subTest(name=name):
                self.archive([n for n in self.names if n!=name])
                with self.assertRaisesRegex(AssertionError,"class definitions missing"):
                    gate.verify(self.apc,self.dependency)
    def test_later_multidex_file_is_examined(self):
        self.archive(self.names,"classes10.dex")
        self.assertEqual("PASS",gate.verify(self.apc,self.dependency)["status"])
    def test_failed_dependency_resolution_cannot_pass(self):
        self.archive(self.names)
        self.dependency.write_text(json.dumps({"status":"FAIL","coordinate":gate.COORDINATE}))
        with self.assertRaisesRegex(AssertionError,"resolution did not pass"):
            gate.verify(self.apc,self.dependency)
    def test_other_sdk_version_cannot_pass(self):
        self.archive(self.names)
        data=json.loads(self.dependency.read_text());data["coordinate"]="com.google.mlkit:genai-image-description:unverified"
        self.dependency.write_text(json.dumps(data))
        with self.assertRaisesRegex(AssertionError,"Wrong scene SDK"):
            gate.verify(self.apc,self.dependency)
    def test_truncated_or_outside_dex_tables_are_rejected(self):
        for payload in (b"dex\n035\x00", dex_fixture(self.names,self.names)[:-1]):
            with self.subTest(length=len(payload)):
                with self.assertRaises(ValueError):gate.definitions(payload)
        payload=bytearray(dex_fixture(self.names,self.names))
        struct.pack_into("<I",payload,100,len(payload)+1)
        with self.assertRaisesRegex(ValueError,"table outside"):
            gate.definitions(bytes(payload))
    def test_duplicate_definitions_across_dex_fail(self):
        with zipfile.ZipFile(self.apc,"w") as z:
            z.writestr("classes.dex",dex_fixture(self.names,self.names))
            z.writestr("classes2.dex",dex_fixture(self.names,self.names))
        with self.assertRaisesRegex(AssertionError,"Duplicate class definition"):
            gate.verify(self.apc,self.dependency)


if __name__=="__main__":
    unittest.main(verbosity=2)
