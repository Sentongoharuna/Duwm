#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
out="${1:-verification/results/1728_2_21_2/preview-rate}"
mkdir -p "$out"
scratch="$(mktemp -d)"
trap 'rm -rf "$scratch"' EXIT
javac -d "$scratch" app/src/main/java/com/sentongoharuna/worldsituationroom/Duwm1728PreviewRate.java verification/PreviewRateTest.java
java -cp "$scratch" com.sentongoharuna.worldsituationroom.PreviewRateTest | tee "$out/PREVIEW-RATE-HOST.txt"
