#!/usr/bin/env python3
"""Development checkpoint contract tests; NOT APK or device verification."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
java=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
editor=(java/'Duwm1728VideoEditorActivity.java').read_text()
renderer=(java/'Duwm1728OverlayRenderer.java').read_text()
srt=(java/'Duwm1728SubtitleImport.java').read_text()
checks={
 'second video selection':'Intent.ACTION_OPEN_DOCUMENT' in editor and 'PIP_VIDEO_REQUEST' in editor,
 'permission for persisted source':'takePersistableUriPermission' in editor,
 'second video not original':'if(selected.equals(source))' in editor,
 'inset render requested':'spec.pipVideo=pipVideo;' in editor,
 'real second frame decoding':'insetRetriever.getFrameAtTime' in renderer,
 'canvas inset drawn':'paintInset(canvas,paint,small)' in renderer,
 'secondary frames recycled':'small.recycle()' in renderer,
 'main video audio unchanged':'audio/mp4a-latm' in renderer and 'audio.writeSampleData' not in renderer,
 'original untouched':'File.createTempFile("DUWM_EDIT_"' in renderer,
 'timed subtitle import':'Duwm1728SubtitleImport.convertSrt(text)' in editor,
 'caption review confirmation':'Review imported time codes' in editor,
 'import has size cap':'65536' in srt,
 'source transcription is not falsely claimed':'It does not transcribe original audio' in editor,
 'editor 45 sec guard':'spec.toMs-spec.fromMs>45000' in editor,
}
for label,ok in checks.items():
 if not ok: raise AssertionError(label)
print('PASS',len(checks),'1728.2/4 source assertions (not Android APK verification)')
