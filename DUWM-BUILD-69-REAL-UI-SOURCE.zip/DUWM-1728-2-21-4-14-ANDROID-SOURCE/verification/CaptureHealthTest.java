package com.sentongoharuna.worldsituationroom;
import static com.sentongoharuna.worldsituationroom.Duwm1724SignalFlow.Stage.*;
/** Executed against the actual production policy; no Android device simulated. */
public final class CaptureHealthTest {
    private static int checks;
    private static void ok(boolean b,String msg){checks++;if(!b)throw new AssertionError(msg);}
    private static Duwm1728CaptureHealth.Input blank(){Duwm1728CaptureHealth.Input i=new Duwm1728CaptureHealth.Input();i.now=1_000_000L;return i;}
    private static void eq(Duwm1728CaptureHealth.Input i,int k,Duwm1724SignalFlow.Stage state,String label){
        Duwm1728CaptureHealth.Reading r=Duwm1728CaptureHealth.read(i)[k];
        ok(r.stage==state,"state "+k+" expected "+state+", got "+r.stage);
        ok(r.label.equals(label),"label "+k+" expected "+label+", got "+r.label);
        ok(r.evidence!=null&&!r.evidence.trim().isEmpty(),"human-readable evidence "+k);
    }
    public static void main(String[] ignored){
        Duwm1728CaptureHealth.Input i=blank();
        eq(i,0,DEGRADED,"PERMISSION");i.cameraPermission=true;eq(i,0,UNKNOWN,"CLOSED");
        i.cameraOpen=true;eq(i,0,CONNECTING,"STARTING");i.frameAt=i.now-4000;eq(i,0,AGED,"NO FRAMES");
        i.frameAt=i.now;eq(i,0,DEGRADED,"RESOLUTION");i.adequateResolution=true;eq(i,0,HEALTHY,"READY");
        i.recording=true;i.recordingMs=5000;i.targetFps=30;i.sourceFps=10;eq(i,0,DEGRADED,"LOW FPS");
        i.sourceFps=29;eq(i,0,HEALTHY,"RECORDING");i.cameraError="Device connection lost";eq(i,0,OUTAGE,"ERROR");
        i.cameraError="";i.frameAt=i.now+1;eq(i,0,AGED,"NO FRAMES");
        i=blank();eq(i,1,LOCAL,"OFF");i.microphoneEnabled=true;eq(i,1,DEGRADED,"PERMISSION");
        i.microphonePermission=true;eq(i,1,UNKNOWN,"NOT TESTED");i.recording=true;eq(i,1,CONNECTING,"CHECKING");
        i.microphonePeak=0;i.microphoneAt=i.now;eq(i,1,AGED,"SILENT");
        i.microphonePeak=3000;eq(i,1,HEALTHY,"AUDIO");i.microphonePeak=32767;eq(i,1,DEGRADED,"HIGH LEVEL");
        i.microphoneAt=i.now-4000;eq(i,1,AGED,"STALE");i.microphoneError="Recorder failed";eq(i,1,OUTAGE,"ERROR");
        i=blank();eq(i,2,LOCAL,"PRIVATE");i.gpsOptIn=true;eq(i,2,DEGRADED,"PERMISSION");
        i.gpsPermission=true;eq(i,2,DEGRADED,"DISABLED");i.gpsProviderEnabled=true;eq(i,2,CONNECTING,"SEEKING");
        i.gpsAgeMs=120001;eq(i,2,AGED,"STALE");i.gpsAgeMs=1000;eq(i,2,DEGRADED,"LOW ACCURACY");
        i.gpsAccuracy=Float.POSITIVE_INFINITY;eq(i,2,DEGRADED,"LOW ACCURACY");
        i.gpsAccuracy=-1;eq(i,2,DEGRADED,"LOW ACCURACY");i.gpsAccuracy=120;eq(i,2,DEGRADED,"LOW ACCURACY");
        i.gpsAccuracy=8;eq(i,2,HEALTHY,"FIX");i.mockLocation=true;eq(i,2,DEGRADED,"TEST FIX");
        i.gpsOptIn=false;eq(i,2,LOCAL,"PRIVATE");
        i=blank();eq(i,3,UNKNOWN,"MISSING");i.compassPresent=true;eq(i,3,CONNECTING,"SEEKING");
        i.compassAt=i.now-30000;eq(i,3,AGED,"STALE");i.compassAt=i.now;eq(i,3,DEGRADED,"CALIBRATE");
        i.compassAccuracy=0;eq(i,3,DEGRADED,"CALIBRATE");i.compassAccuracy=2;eq(i,3,HEALTHY,"HEADING");
        i=blank();eq(i,4,UNKNOWN,"OFF");i.weatherRequested=true;eq(i,4,UNKNOWN,"NO RECEIPT");
        i.weatherLoading=true;eq(i,4,CONNECTING,"FETCHING");i.weatherLoading=false;i.weatherError="HTTP 503";eq(i,4,OUTAGE,"FAILED");
        i.weatherError="";i.weatherAt=i.now-2000;i.weatherPlaceMatches=false;eq(i,4,DEGRADED,"OTHER PLACE");
        i.weatherPlaceMatches=true;eq(i,4,HEALTHY,"MODEL");i.weatherAt=i.now;eq(i,4,RECEIVING,"RECEIVED");
        i.now+=1_800_001;eq(i,4,AGED,"STALE");i.weatherAt=i.now+1;eq(i,4,UNKNOWN,"NO RECEIPT");
        i.weatherRequested=false;eq(i,4,UNKNOWN,"OFF");
        i=blank();eq(i,5,UNKNOWN,"NO EXPORT");i.gallerySaving=true;eq(i,5,CONNECTING,"SAVING");
        i.gallerySaving=false;i.galleryResult=-1;eq(i,5,OUTAGE,"FAILED");i.galleryResult=1;eq(i,5,UNKNOWN,"UNCONFIRMED");
        i.galleryAt=i.now;eq(i,5,RECEIVING,"SAVED");i.now+=2000;eq(i,5,HEALTHY,"SAVED");
        i.galleryAt=i.now+1;eq(i,5,UNKNOWN,"UNCONFIRMED");
        // All 6 channels can have different real conditions at one time.
        i=blank();i.cameraPermission=true;i.cameraOpen=true;i.frameAt=i.now;i.adequateResolution=true;
        i.recording=true;i.microphoneEnabled=true;i.microphonePermission=true;i.microphoneError="I/O";
        i.compassPresent=true;i.compassAt=i.now-30000;i.weatherRequested=true;i.weatherLoading=true;
        eq(i,0,HEALTHY,"RECORDING");eq(i,1,OUTAGE,"ERROR");eq(i,2,LOCAL,"PRIVATE");
        eq(i,3,AGED,"STALE");eq(i,4,CONNECTING,"FETCHING");eq(i,5,UNKNOWN,"NO EXPORT");
        long time=i.now;Duwm1728CaptureHealth.read(i);ok(i.now==time&&i.galleryResult==0,"Policy does not mutate observations");
        Duwm1728CaptureHealth.Reading[] empty=Duwm1728CaptureHealth.read(null);
        ok(empty.length==6,"All six channels always present");
        for(Duwm1728CaptureHealth.Reading r:empty)ok(r.stage!=HEALTHY&&r.stage!=RECEIVING,"Missing measurements never become green/cyan");
        System.out.println("PASS "+checks+" executed capture-health assertions; hardware and Android rendering not tested");
    }
}
