#!/usr/bin/env bash
set -euo pipefail
audio_project="$(cd "$(dirname "$0")/.." && pwd)"
audio_proof="${1:-$audio_project/verification/recorded-audio-host-proof}"
audio_javac="${JAVAC:-${JAVA_HOME:+$JAVA_HOME/bin/}javac}"
audio_java="${JAVA:-${JAVA_HOME:+$JAVA_HOME/bin/}java}"
audio_build="$(mktemp -d "${TMPDIR:-/tmp}/duwm-audio-host.XXXXXX")"
trap 'rm -rf -- "$audio_build"' EXIT
audio_source="$audio_project/app/src/main/java/com/sentongoharuna/worldsituationroom"
"$audio_javac" --release 17 -encoding UTF-8 -d "$audio_build" \
  "$audio_source/Duwm1728BroadcastComposition.java" \
  "$audio_source/Duwm1728CaptionPages.java" \
  "$audio_source/Duwm1728BroadcastLayout.java" "$audio_source/Duwm1728ClearPictureLayout.java" \
  "$audio_source/Duwm1728HeadlineFit.java" \
  "$audio_source/Duwm1728TickerTimeline.java" \
  "$audio_source/Duwm1728CaptionEditPolicy.java" \
  "$audio_source/Duwm1728PcmTimeline.java" \
  "$audio_source/Duwm1728SpeechCues.java" \
  "$audio_source/Duwm1728SpeechSessionPolicy.java" \
  "$audio_project/verification/broadcast/RecordedAudioTimingTest.java" \
  "$audio_project/verification/broadcast/RecordedSpeechSessionTest.java"
"$audio_java" -cp "$audio_build" com.sentongoharuna.worldsituationroom.RecordedAudioTimingTest "$audio_proof"
"$audio_java" -cp "$audio_build" com.sentongoharuna.worldsituationroom.RecordedSpeechSessionTest "$audio_proof"
