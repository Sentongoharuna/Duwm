#!/usr/bin/env bash
# Declare the regression font explicitly; never change fontconfig to hide a fit defect.
set -euo pipefail
font_project="$(cd "$(dirname "$0")/.." && pwd)"
font_proof="$font_project/verification/results/1728_2_21_3"
mkdir -p "$font_proof"
cd "$font_project"
(
  set -euo pipefail
  if ! python3 verification/verify_host_fonts.py "$font_proof/HOST-CI-FONTS.json"; then
    # Provision only the official Ubuntu packages on the declared GitHub runner.
    # An ordinary local check cannot silently become a package installation.
    python3 - <<'PY_HOST'
import os,pathlib,re
release=pathlib.Path('/etc/os-release').read_text()
assert os.environ.get('RUNNER_OS')=='Linux' and re.search(r'^ID="?ubuntu"?$',release,re.M), 'Automatic font provisioning is restricted to the Ubuntu GitHub runner'
PY_HOST
    timeout 600 sudo apt-get update
    timeout 600 sudo apt-get install -y --no-install-recommends fontconfig fonts-dejavu-core
    python3 verification/verify_host_fonts.py "$font_proof/HOST-CI-FONTS.json"
  fi
) 2>&1 | tee "$font_proof/HOST-CI-FONTS.log"
