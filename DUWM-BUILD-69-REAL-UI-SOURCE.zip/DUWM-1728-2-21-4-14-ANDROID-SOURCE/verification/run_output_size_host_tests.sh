#!/usr/bin/env bash
set -euo pipefail
size_project="$(cd "$(dirname "$0")/.." && pwd)"
size_proof="${1:-$size_project/verification/results/1728_2_21/output-size}"
size_javac="${JAVAC:-${JAVA_HOME:+$JAVA_HOME/bin/}javac}"
size_java="${JAVA:-${JAVA_HOME:+$JAVA_HOME/bin/}java}"
size_build="$(mktemp -d "${TMPDIR:-/tmp}/duwm-output-size.XXXXXX")"
trap 'rm -rf -- "$size_build"' EXIT
size_source="$size_project/app/src/main/java/com/sentongoharuna/worldsituationroom"
"$size_javac" --release 17 -encoding UTF-8 -d "$size_build" \
  "$size_source/Duwm1728OutputSizePolicy.java" \
  "$size_project/verification/broadcast/OutputSizePolicyTest.java"
"$size_java" -Xmx256m -cp "$size_build" \
  com.sentongoharuna.worldsituationroom.OutputSizePolicyTest "$size_proof"
