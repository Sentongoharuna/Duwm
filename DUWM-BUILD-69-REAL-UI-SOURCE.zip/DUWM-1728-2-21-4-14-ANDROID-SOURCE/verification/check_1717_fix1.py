#!/usr/bin/env python3
"""1717 FIX1 regression guard for GitHub Action run 42211817796.

Source parser checks previously passed but javac reported an illegal static
forward reference in Duwm1715SignalLights.java:40. Keep this guard alongside
full Android :app:assembleDebug compilation in GitHub Actions.
"""
from pathlib import Path
p=(Path(__file__).resolve().parents[1] / 'app/src/main/java/com/sentongoharuna/worldsituationroom/Duwm1715SignalLights.java')
s=p.read_text(encoding='utf-8')
assert s.count('private static java.lang.ref.WeakReference<SignalRail> visible')==1
assert s.count('private static final Runnable COALESCED_REFRESH')==1
assert s.index('private static java.lang.ref.WeakReference<SignalRail> visible') < s.index('private static final Runnable COALESCED_REFRESH'), 'Regression: illegal static forward reference to visible'
assert 'SignalRail rail=visible.get();' in s
assert 'UI.postDelayed(COALESCED_REFRESH,180L);' in s
assert 'new java.lang.ref.WeakReference<>(null)' in s
assert 'new SatelliteMapView' not in s, 'No new globe permitted in signal rail'
print('PASS 1717 FIX1: visible declared before static runnable; signal rail, coalescing and original globe preserved')
