#!/usr/bin/env python3
"""Compile the five new /21/2 measurement classes against the actual Android SDK.

No API substitutes are used. This is a selected-source compilation, not an APK
build, model SDK resolution, sensor execution, or provider network check.
"""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
NAMES = ('Duwm1728Measurements', 'Duwm1728MeasurementMath', 'Duwm1728MeasurementStore',
         'Duwm1728MeasurementSources', 'Duwm1728PreviewRate')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--android-jar',required=True,type=Path)
    parser.add_argument('--javac',default='javac')
    parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args()
    assert args.android_jar.is_file()
    args.out.mkdir(parents=True,exist_ok=True)
    package=ROOT/'app/src/main/java/com/sentongoharuna/worldsituationroom'
    sources=[package/(name+'.java') for name in NAMES]
    hashes=lambda:{p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
    before=hashes()
    with tempfile.TemporaryDirectory(prefix='duwm-actual-android-measurements-') as temporary:
        command=[args.javac,'-encoding','UTF-8','-source','17','-target','17','-proc:none',
                 '-classpath',str(args.android_jar),'-d',temporary]+[str(p) for p in sources]
        run=subprocess.run(command,cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    stable=before==hashes()
    report={'build':'1728.2/21/2','status':'PASS' if run.returncode==0 and stable else 'FAIL',
            'scope':'Five new measurement runtime classes compiled against actual Android API 36; no API substitutes',
            'returncode':run.returncode,'source_hashes':before,'inputs_unchanged_during_check':stable,
            'android_jar_sha256':hashlib.sha256(args.android_jar.read_bytes()).hexdigest(),
            'api_substitutes_used':False,'complete_app_build_verified':False,'apk_built':False,
            'official_mlkit_dependency_resolved':False,'physical_sensors_executed':False,
            'provider_network_executed':False,'model_inference_executed':False,'command':command}
    (args.out/'JAVAC.txt').write_text(run.stdout)
    (args.out/'ANDROID-MEASUREMENT-SOURCE-CHECK.json').write_text(json.dumps(report,indent=2)+'\n')
    print(report['status']+': five measurement classes against actual Android API; no APK or runtime claim.')
    if run.returncode:print(run.stdout)
    raise SystemExit(0 if report['status']=='PASS' else 1)

if __name__=='__main__':main()
