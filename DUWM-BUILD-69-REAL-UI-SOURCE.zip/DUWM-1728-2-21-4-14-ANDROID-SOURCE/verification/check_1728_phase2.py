from pathlib import Path
p=Path(__file__).resolve().parents[1]
j=p/'app/src/main/java/com/sentongoharuna/worldsituationroom'
m=(p/'app/src/main/AndroidManifest.xml').read_text()
s=(j/'Duwm1728VideoEditorActivity.java').read_text()
r=(j/'Duwm1728OverlayRenderer.java').read_text()
l=(j/'Duwm1726GalleryLibraryActivity.java').read_text()
assert 'Duwm1728VideoEditorActivity' in m
assert 'new Intent(this,Duwm1728VideoEditorActivity.class)' in l
for word in ['VideoView','spec.fromMs','spec.toMs','Duwm1728OverlayRenderer.export','Duwm1724GalleryPublisher.publish','reporter-entered'.upper()]:
    assert word in s or word in r,word
for word in ['MediaCodec.createEncoderByType','MediaMuxer','MediaMetadataRetriever','paintOverlay','UNVERIFIED','audio.getSampleTime','firstVideoTime','if(!success)output.delete()']:
    assert word in r,word
assert (p/'app/src/main/AndroidManifest.xml').is_file() # root can be renamed; code contract unchanged
assert 'SatelliteMapView' in (j/'MainActivity.java').read_text()
print('PASS 1728 phase2 editor integration, burned-overlay renderer and original-globe anchor')
