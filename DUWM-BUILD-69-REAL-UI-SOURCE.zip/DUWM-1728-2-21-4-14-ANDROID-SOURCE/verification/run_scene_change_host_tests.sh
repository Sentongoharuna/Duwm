#!/usr/bin/env bash
set -euo pipefail
scene_project="$(cd "$(dirname "$0")/.." && pwd)"
scene_proof="${1:-$scene_project/verification/results/1728_2_21_1/scene-change}"
scene_javac="${JAVAC:-${JAVA_HOME:+$JAVA_HOME/bin/}javac}"
scene_java="${JAVA:-${JAVA_HOME:+$JAVA_HOME/bin/}java}"
scene_build="$(mktemp -d "${TMPDIR:-/tmp}/duwm-scene-change.XXXXXX")"
trap 'rm -rf -- "$scene_build"' EXIT
"$scene_javac" --release 17 -encoding UTF-8 -d "$scene_build" \
  "$scene_project/app/src/main/java/com/sentongoharuna/worldsituationroom/Duwm1728SceneChangePolicy.java" \
  "$scene_project/verification/SceneChangePolicyTest.java"
"$scene_java" -cp "$scene_build" com.sentongoharuna.worldsituationroom.SceneChangePolicyTest "$scene_proof"
