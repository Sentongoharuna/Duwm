#!/usr/bin/env bash
# Pure Java source-time editing plus actual production Painter. No Android emulator.
set -euo pipefail
caption_project="$(cd "$(dirname "$0")/.." && pwd)"
caption_proof="${1:-$caption_project/verification/caption-edit-host-proof}"
caption_javac="${JAVAC:-${JAVA_HOME:+$JAVA_HOME/bin/}javac}"
caption_java="${JAVA:-${JAVA_HOME:+$JAVA_HOME/bin/}java}"
caption_build="$(mktemp -d "${TMPDIR:-/tmp}/duwm-caption-host.XXXXXX")"
trap 'rm -rf -- "$caption_build"' EXIT
caption_source="$caption_project/app/src/main/java/com/sentongoharuna/worldsituationroom"
"$caption_javac" --release 17 -encoding UTF-8 -d "$caption_build" \
  "$caption_source/Duwm1728BroadcastComposition.java" \
  "$caption_source/Duwm1728BroadcastLayout.java" "$caption_source/Duwm1728ClearPictureLayout.java" \
  "$caption_source/Duwm1728HeadlineFit.java" \
  "$caption_source/Duwm1728CaptionPages.java" \
  "$caption_source/Duwm1728TickerTimeline.java" \
  "$caption_source/Duwm1728BroadcastTimeline.java" \
  "$caption_source/Duwm1728SubtitleImport.java" \
  "$caption_source/Duwm1728CaptionSrt.java" \
  "$caption_source/Duwm1728CaptionEditPolicy.java" \
  "$caption_project/verification/broadcast/BroadcastRenderTest.java" \
  "$caption_project/verification/broadcast/CaptionEditPolicyTest.java"
"$caption_java" -Djava.awt.headless=true -cp "$caption_build" \
  com.sentongoharuna.worldsituationroom.CaptionEditPolicyTest "$caption_proof"
