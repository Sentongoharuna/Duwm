#!/usr/bin/env bash
set -euo pipefail
scene_layout_project="$(cd "$(dirname "$0")/.." && pwd)"
scene_layout_proof="${1:-$scene_layout_project/verification/scene-layout-host-proof}"
scene_layout_javac="${JAVAC:-${JAVA_HOME:+$JAVA_HOME/bin/}javac}"
scene_layout_java="${JAVA:-${JAVA_HOME:+$JAVA_HOME/bin/}java}"
scene_layout_build="$(mktemp -d "${TMPDIR:-/tmp}/duwm-scene-layout.XXXXXX")"
trap 'rm -rf -- "$scene_layout_build"' EXIT
scene_layout_source="$scene_layout_project/app/src/main/java/com/sentongoharuna/worldsituationroom"
"$scene_layout_javac" --release 17 -encoding UTF-8 -d "$scene_layout_build" \
  "$scene_layout_source/Duwm1728BroadcastComposition.java" \
  "$scene_layout_source/Duwm1728BroadcastLayout.java" "$scene_layout_source/Duwm1728ClearPictureLayout.java" \
  "$scene_layout_source/Duwm1728HeadlineFit.java" \
  "$scene_layout_source/Duwm1728CaptionPages.java" \
  "$scene_layout_source/Duwm1728SceneTimeline.java" \
  "$scene_layout_project/verification/broadcast/BroadcastRenderTest.java" \
  "$scene_layout_project/verification/broadcast/SceneLayoutTest.java"
"$scene_layout_java" -Xmx512m -Djava.awt.headless=true -cp "$scene_layout_build" \
  com.sentongoharuna.worldsituationroom.SceneLayoutTest "$scene_layout_proof"
