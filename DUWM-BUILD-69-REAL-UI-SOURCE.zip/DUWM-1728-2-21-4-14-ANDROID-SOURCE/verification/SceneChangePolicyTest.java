package com.sentongoharuna.worldsituationroom;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

/** Image-difference policy fixtures, never semantic scene or model evidence. */
public final class SceneChangePolicyTest {
    private static int checks;
    private static void check(boolean condition,String message){
        checks++;if(!condition)throw new AssertionError(message);
    }
    public static void main(String[] args)throws Exception{
        int[] dark=new int[100];Arrays.fill(dark,0xff102030);
        int[] same=dark.clone();
        check(!Duwm1728SceneChangePolicy.changed(dark,same),"unchanged frame invalidated");
        int[] alpha=dark.clone();Arrays.fill(alpha,0x00102030);
        check(!Duwm1728SceneChangePolicy.changed(dark,alpha),"alpha-only change invalidated");
        int[] noise=dark.clone();
        for(int i=0;i<noise.length;i++)noise[i]=i%2==0?0xff142433:0xff0e1c2c;
        check(!Duwm1728SceneChangePolicy.changed(dark,noise),"small sensor noise invalidated");
        int[] light=new int[100];Arrays.fill(light,0xffe0e0e0);
        check(Duwm1728SceneChangePolicy.changed(dark,light),"large appearance change not detected");
        check(Duwm1728SceneChangePolicy.changed(light,dark),"appearance difference should be symmetric");
        int[] smallPatch=dark.clone();Arrays.fill(smallPatch,0,10,0xffffffff);
        check(!Duwm1728SceneChangePolicy.changed(dark,smallPatch),"small moving patch should not invalidate whole scene");
        int[] half=dark.clone();Arrays.fill(half,0,54,0xffffffff);
        check(!Duwm1728SceneChangePolicy.changed(dark,half),"below coverage threshold invalidated");
        int[] largePatch=dark.clone();Arrays.fill(largePatch,0,55,0xffffffff);
        check(Duwm1728SceneChangePolicy.changed(dark,largePatch),"large sufficiently strong change missed");
        check(!Duwm1728SceneChangePolicy.changed(null,dark),"null prior frame fabricated event");
        check(!Duwm1728SceneChangePolicy.changed(dark,null),"null current frame fabricated event");
        check(!Duwm1728SceneChangePolicy.changed(new int[0],new int[0]),"empty frames fabricated event");
        check(!Duwm1728SceneChangePolicy.changed(dark,new int[99]),"mismatched frame shape fabricated event");
        check(Arrays.equals(dark,same),"comparison mutated the reference frame");
        Path output=Path.of(args[0]);Files.createDirectories(output);
        String report="{\n  \"schema\":1,\n  \"status\":\"PASS\",\n  \"scope\":\"pure appearance-difference policy with synthetic pixels\",\n  \"checks\":"+checks+",\n  \"model_inference_verified\":false,\n  \"physical_camera_verified\":false\n}\n";
        Files.writeString(output.resolve("SCENE-CHANGE-HOST.json"),report);System.out.print(report);
    }
}
