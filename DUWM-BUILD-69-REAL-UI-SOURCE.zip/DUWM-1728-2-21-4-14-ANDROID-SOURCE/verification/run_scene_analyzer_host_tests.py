#!/usr/bin/env python3
"""Exercise the real production controller with isolated deterministic test doubles.

This does NOT compile against the official ML Kit artifact or run any vision model.
All replacement Android/ML Kit classes exist only in a temporary directory; none
are app sources, Gradle dependencies, APK inputs, or distributable runtime classes.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


DOUBLES = {
    "android/os/Looper.java": r"""
package android.os;
public final class Looper {
    private static final Looper MAIN = new Looper();
    private static final Thread OWNER = Thread.currentThread();
    public static Looper getMainLooper() { return MAIN; }
    public static Looper myLooper() { return Thread.currentThread() == OWNER ? MAIN : null; }
}
""",
    "android/os/SystemClock.java": r"""
package android.os;
public final class SystemClock {
    private static long elapsed = 100000L;
    public static long elapsedRealtime() { return elapsed; }
    public static void set(long value) { elapsed = value; }
}
""",
    "android/os/Handler.java": r"""
package android.os;
import java.util.PriorityQueue;
public final class Handler {
    private static long sequence;
    private static final class Scheduled implements Comparable<Scheduled> {
        final Runnable runnable; final long deadline, order;
        Scheduled(Runnable runnable, long deadline) {
            this.runnable = runnable; this.deadline = deadline; this.order = sequence++;
        }
        public int compareTo(Scheduled other) {
            int result = Long.compare(deadline, other.deadline);
            return result != 0 ? result : Long.compare(order, other.order);
        }
    }
    private static final PriorityQueue<Scheduled> QUEUE = new PriorityQueue<>();
    public Handler(Looper looper) {}
    public boolean post(Runnable runnable) { return postDelayed(runnable, 0); }
    public boolean postDelayed(Runnable runnable, long delay) {
        QUEUE.add(new Scheduled(runnable, SystemClock.elapsedRealtime() + Math.max(0, delay)));
        return true;
    }
    public void removeCallbacks(Runnable runnable) {
        QUEUE.removeIf(item -> item.runnable == runnable);
    }
    public static void reset() { QUEUE.clear(); sequence = 0; SystemClock.set(100000L); }
    public static void runCurrent() {
        int count = 0;
        while (!QUEUE.isEmpty() && QUEUE.peek().deadline <= SystemClock.elapsedRealtime()) {
            if (++count > 10000) throw new AssertionError("Unbounded controller callback loop");
            QUEUE.remove().runnable.run();
        }
    }
    public static void advance(long milliseconds) {
        SystemClock.set(SystemClock.elapsedRealtime() + milliseconds);
        runCurrent();
    }
}
""",
    "android/content/SharedPreferences.java": r"""
package android.content;
import java.util.HashMap;
import java.util.Map;
public final class SharedPreferences {
    private final Map<String,Long> values = new HashMap<>();
    public long getLong(String key, long fallback) { return values.getOrDefault(key, fallback); }
    public Editor edit() { return new Editor(); }
    public final class Editor {
        private final Map<String,Long> pending = new HashMap<>();
        public Editor putLong(String key, long value) { pending.put(key, value); return this; }
        public void apply() { values.putAll(pending); }
    }
}
""",
    "android/content/Context.java": r"""
package android.content;
import java.util.HashMap;
import java.util.Map;
public class Context {
    public static final int MODE_PRIVATE = 0;
    private static final Map<String,SharedPreferences> PREFERENCES = new HashMap<>();
    public Context getApplicationContext() { return this; }
    public SharedPreferences getSharedPreferences(String name, int mode) {
        return PREFERENCES.computeIfAbsent(name, ignored -> new SharedPreferences());
    }
    public static void resetPreferences() { PREFERENCES.clear(); }
}
""",
    "android/graphics/Bitmap.java": r"""
package android.graphics;
public final class Bitmap {
    private final int width, height;
    private boolean recycled;
    public int recycleCount;
    public Bitmap(int width, int height) { this.width = width; this.height = height; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public boolean isRecycled() { return recycled; }
    public void recycle() { recycled = true; recycleCount++; }
    public static Bitmap createScaledBitmap(Bitmap original, int width, int height, boolean filter) {
        return original.width == width && original.height == height ? original : new Bitmap(width, height);
    }
}
""",
    "android/util/Log.java": r"""
package android.util;
public final class Log {
    public static int w(String tag, String message, Throwable error) { return 0; }
}
""",
    "com/google/common/util/concurrent/ListenableFuture.java": r"""
package com.google.common.util.concurrent;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
public interface ListenableFuture<V> extends Future<V> {
    void addListener(Runnable listener, Executor executor);
}
""",
    "com/google/common/util/concurrent/ControlledFuture.java": r"""
package com.google.common.util.concurrent;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
public final class ControlledFuture<V> implements ListenableFuture<V> {
    private static final class Registration {
        final Runnable runnable; final Executor executor;
        Registration(Runnable runnable, Executor executor) { this.runnable = runnable; this.executor = executor; }
    }
    private final List<Registration> listeners = new ArrayList<>();
    private boolean done, cancelled;
    private V value;
    private Throwable error;
    public boolean honorCancellation = true;
    public int cancelCalls;
    public boolean throwWhenAddingListener;
    public void addListener(Runnable listener, Executor executor) {
        if (throwWhenAddingListener) throw new IllegalStateException("Controlled registration failure");
        if (done) executor.execute(listener); else listeners.add(new Registration(listener, executor));
    }
    private void dispatch() {
        List<Registration> snapshot = new ArrayList<>(listeners); listeners.clear();
        for (Registration registration : snapshot) registration.executor.execute(registration.runnable);
    }
    public void complete(V value) {
        if (done) throw new AssertionError("Future was already completed");
        this.value = value; done = true; dispatch();
    }
    public void fail(Throwable error) {
        if (done) throw new AssertionError("Future was already completed");
        this.error = error; done = true; dispatch();
    }
    public boolean cancel(boolean interrupt) {
        cancelCalls++;
        if (done || !honorCancellation) return false;
        done = true; cancelled = true; dispatch(); return true;
    }
    public boolean isDone() { return done; }
    public boolean isCancelled() { return cancelled; }
    public V get() throws ExecutionException {
        if (!done) throw new AssertionError("Production controller tried to block on an incomplete future");
        if (cancelled) throw new CancellationException();
        if (error != null) throw new ExecutionException(error);
        return value;
    }
    public V get(long timeout, TimeUnit unit) throws ExecutionException, TimeoutException {
        if (!done) throw new TimeoutException(); return get();
    }
}
""",
    "com/google/mlkit/genai/common/FeatureStatus.java": r"""
package com.google.mlkit.genai.common;
public @interface FeatureStatus {
    int UNAVAILABLE = 0, DOWNLOADABLE = 1, DOWNLOADING = 2, AVAILABLE = 3;
}
""",
    "com/google/mlkit/genai/common/GenAiException.java": r"""
package com.google.mlkit.genai.common;
public class GenAiException extends Exception {
    private final int code;
    public GenAiException(int code) { super("Controlled error " + code); this.code = code; }
    public int getErrorCode() { return code; }
    public @interface ErrorCode {
        // The pinned SDK compile proved that the newer quota/background
        // constant fields are absent. Do not invent them in this test double.
        int BUSY = 9;
    }
}
""",
    "com/google/mlkit/genai/imagedescription/ImageDescriberOptions.java": r"""
package com.google.mlkit.genai.imagedescription;
import android.content.Context;
public final class ImageDescriberOptions {
    public static Builder builder(Context context) { return new Builder(); }
    public static final class Builder {
        public ImageDescriberOptions build() { return new ImageDescriberOptions(); }
    }
}
""",
    "com/google/mlkit/genai/imagedescription/ImageDescriptionRequest.java": r"""
package com.google.mlkit.genai.imagedescription;
import android.graphics.Bitmap;
public final class ImageDescriptionRequest {
    public final Bitmap bitmap;
    private ImageDescriptionRequest(Bitmap bitmap) { this.bitmap = bitmap; }
    public static Builder builder(Bitmap bitmap) { return new Builder(bitmap); }
    public static final class Builder {
        private final Bitmap bitmap;
        Builder(Bitmap bitmap) { this.bitmap = bitmap; }
        public ImageDescriptionRequest build() { return new ImageDescriptionRequest(bitmap); }
    }
}
""",
    "com/google/mlkit/genai/imagedescription/ImageDescriptionResult.java": r"""
package com.google.mlkit.genai.imagedescription;
public final class ImageDescriptionResult {
    private final String description;
    public ImageDescriptionResult(String description) { this.description = description; }
    public String getDescription() { return description; }
}
""",
    "com/google/mlkit/genai/imagedescription/ImageDescriber.java": r"""
package com.google.mlkit.genai.imagedescription;
import com.google.common.util.concurrent.ListenableFuture;
public interface ImageDescriber {
    ListenableFuture<Integer> checkFeatureStatus();
    ListenableFuture<Void> prepareInferenceEngine();
    ListenableFuture<ImageDescriptionResult> runInference(ImageDescriptionRequest request);
    void close();
}
""",
    "com/google/mlkit/genai/imagedescription/ImageDescription.java": r"""
package com.google.mlkit.genai.imagedescription;
public final class ImageDescription {
    public static ImageDescriber controlledClient;
    public static int factoryCalls;
    public static ImageDescriber getClient(ImageDescriberOptions options) {
        factoryCalls++;
        if (controlledClient == null) throw new AssertionError("No controlled client installed");
        return controlledClient;
    }
}
""",
}

HARNESS = r"""
package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import com.google.common.util.concurrent.ControlledFuture;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.genai.common.FeatureStatus;
import com.google.mlkit.genai.common.GenAiException;
import com.google.mlkit.genai.imagedescription.*;
import java.util.ArrayList;
import java.util.List;

public final class SceneAnalyzerControllerTest {
    private static int checks;
    private static void check(boolean condition, String reason) {
        checks++;
        if (!condition) throw new AssertionError(reason);
    }
    private static final class Client implements ImageDescriber {
        final List<ControlledFuture<Integer>> statuses = new ArrayList<>();
        final List<ControlledFuture<Void>> preparations = new ArrayList<>();
        final List<ControlledFuture<ImageDescriptionResult>> inferences = new ArrayList<>();
        final List<ImageDescriptionRequest> images = new ArrayList<>();
        int closed;
        boolean throwDuringInference, throwOnListenerRegistration, throwOnClose;
        public ListenableFuture<Integer> checkFeatureStatus() {
            ControlledFuture<Integer> future = new ControlledFuture<>(); statuses.add(future); return future;
        }
        public ListenableFuture<Void> prepareInferenceEngine() {
            ControlledFuture<Void> future = new ControlledFuture<>(); preparations.add(future); return future;
        }
        public ListenableFuture<ImageDescriptionResult> runInference(ImageDescriptionRequest request) {
            if (throwDuringInference) throw new IllegalStateException("Controlled synchronous failure");
            images.add(request);
            ControlledFuture<ImageDescriptionResult> future = new ControlledFuture<>();
            future.throwWhenAddingListener = throwOnListenerRegistration;
            inferences.add(future); return future;
        }
        public void close() {
            closed++;
            if (throwOnClose) throw new IllegalStateException("Controlled close failure");
        }
        ControlledFuture<Integer> status() { return statuses.get(statuses.size() - 1); }
        ControlledFuture<Void> preparation() { return preparations.get(preparations.size() - 1); }
        ControlledFuture<ImageDescriptionResult> inference() { return inferences.get(inferences.size() - 1); }
    }
    private static final class Events implements Duwm1728SceneAnalyzer.Listener {
        final List<Duwm1728SceneAnalyzer.State> statuses = new ArrayList<>();
        final List<Duwm1728SceneTimeline.Entry> scenes = new ArrayList<>();
        public void onStatus(Duwm1728SceneAnalyzer.State state, String detail) {
            check(Looper.myLooper() == Looper.getMainLooper(), "Status was not on the main thread");
            statuses.add(state);
            check(detail != null && !detail.isEmpty(), "Empty state explanation");
        }
        public void onScene(Duwm1728SceneTimeline.Entry entry) {
            check(Looper.myLooper() == Looper.getMainLooper(), "Scene was not on the main thread");
            scenes.add(entry);
        }
        Duwm1728SceneAnalyzer.State status() { return statuses.get(statuses.size() - 1); }
    }
    private static final class Fixture {
        final Context context = new Context();
        final Client client = new Client();
        final Events events = new Events();
        final Duwm1728SceneAnalyzer analyzer;
        Fixture() {
            Handler.reset(); Context.resetPreferences();
            ImageDescription.controlledClient = client; ImageDescription.factoryCalls = 0;
            analyzer = new Duwm1728SceneAnalyzer(context, events);
        }
        void ready(int feature) {
            analyzer.start();
            finishPreparation(feature);
            check(analyzer.isReady() && analyzer.canRequest(), "Controller did not become ready");
        }
        void finishPreparation(int feature) {
            client.status().complete(feature); Handler.runCurrent();
            client.preparation().complete(null); Handler.runCurrent();
        }
    }
    private static Bitmap frame() { return new Bitmap(640, 360); }
    private static ImageDescriptionResult result(String text) { return new ImageDescriptionResult(text); }

    private static void preparationAndOwnership() {
        Fixture f = new Fixture();
        check(!f.analyzer.canRequest(), "Inactive controller accepted camera extraction");
        f.analyzer.resume();
        check(f.events.status() == Duwm1728SceneAnalyzer.State.CHECKING, "Missing readiness check state");
        f.client.status().complete(FeatureStatus.DOWNLOADABLE); Handler.runCurrent();
        check(f.events.status() == Duwm1728SceneAnalyzer.State.DOWNLOADING, "Missing automatic download state");
        check(f.client.preparations.size() == 1 && !f.analyzer.canRequest(), "Inference before model preparation");
        f.client.preparation().complete(null); Handler.runCurrent();
        check(f.analyzer.canRequest(), "Prepared model was not usable");
        Bitmap original = new Bitmap(1536, 864);
        check(f.analyzer.request(original, 123), "First frame rejected");
        Bitmap scaled = f.client.images.get(0).bitmap;
        check(original.isRecycled() && scaled != original, "Scaled source ownership leaked");
        check(scaled.getWidth() == 768 && scaled.getHeight() == 432, "Image resource bound/aspect changed");
        check(!scaled.isRecycled(), "SDK image recycled before its future completed");
        Bitmap concurrent = frame();
        check(!f.analyzer.request(concurrent, 124) && concurrent.isRecycled(), "Concurrent request not consumed");
        check(f.client.inferences.size() == 1, "More than one inference in flight");
        String text = "A red bicycle beside a stone wall. Someone stands behind it.";
        f.client.inference().complete(result(text));
        check(f.events.scenes.isEmpty(), "Model callback bypassed main-thread queue");
        Handler.runCurrent();
        check(scaled.isRecycled() && scaled.recycleCount == 1, "Completed model image not released exactly once");
        check(f.events.scenes.size() == 1 && f.events.scenes.get(0).description.equals(text),
                "Controller replaced actual returned model text");
        check(f.events.scenes.get(0).atMs == 123 && f.events.scenes.get(0).validUntilMs == 12123,
                "Source timestamp was replaced with completion time");
        check(f.events.scenes.get(0).source.equals(Duwm1728SceneTimeline.SOURCE), "Model provenance lost");
        check(!f.analyzer.canRequest(), "Cadence was reset by successful inference");
        f.analyzer.resetSession();
        check(!f.analyzer.canRequest(), "Session reset bypassed minimum request interval");
        Handler.advance(4000);
        check(f.analyzer.canRequest(), "Minimum interval did not end");
        f.analyzer.close();
    }

    private static void generationAndPause() {
        Fixture f = new Fixture(); f.ready(FeatureStatus.AVAILABLE);
        Bitmap first = frame(); f.analyzer.request(first, 900);
        ControlledFuture<ImageDescriptionResult> old = f.client.inference(); old.honorCancellation = false;
        f.analyzer.resetSession();
        check(old.cancelCalls == 1 && !first.isRecycled(), "Best-effort cancellation recycled SDK-owned image");
        check(!f.analyzer.canRequest(), "Reset avoided cadence");
        Handler.advance(4000);
        check(f.analyzer.request(frame(), 0), "New recording time origin was rejected");
        ControlledFuture<ImageDescriptionResult> current = f.client.inference();
        old.complete(result("An obsolete scene.")); Handler.runCurrent();
        check(f.events.scenes.isEmpty() && !f.analyzer.canRequest(), "Old callback contaminated current request");
        current.complete(result("The current scene.")); Handler.runCurrent();
        check(f.events.scenes.size() == 1 && f.events.scenes.get(0).description.equals("The current scene."),
                "Current generation result lost");
        Handler.advance(4000);
        f.analyzer.request(frame(), 8000);
        ControlledFuture<ImageDescriptionResult> beforePause = f.client.inference();
        beforePause.honorCancellation = false;
        f.analyzer.pause();
        Bitmap rejected = frame();
        check(!f.analyzer.request(rejected, 9000) && rejected.isRecycled(), "Paused request accepted/leaked");
        f.analyzer.resume();
        check(f.events.status() == Duwm1728SceneAnalyzer.State.WAITING, "Resume bypassed cadence");
        Handler.advance(4000); f.finishPreparation(FeatureStatus.AVAILABLE);
        beforePause.complete(result("An obsolete paused frame.")); Handler.runCurrent();
        check(f.events.scenes.size() == 1, "Paused generation emitted a scene");
        check(f.analyzer.canRequest(), "Resume left model readiness stranded");
        f.analyzer.close();
    }

    private static void preparationGenerations() {
        Fixture f = new Fixture();
        f.analyzer.resume();
        ControlledFuture<Integer> oldStatus = f.client.status(); oldStatus.honorCancellation = false;
        f.analyzer.pause(); f.analyzer.resume();
        oldStatus.complete(FeatureStatus.AVAILABLE); Handler.runCurrent();
        check(f.client.preparations.isEmpty(), "Obsolete feature status prepared a new session");
        f.client.status().complete(FeatureStatus.DOWNLOADING); Handler.runCurrent();
        ControlledFuture<Void> oldPreparation = f.client.preparation(); oldPreparation.honorCancellation = false;
        f.analyzer.resetSession();
        oldPreparation.complete(null); Handler.runCurrent();
        check(f.analyzer.canRequest(), "Scene reset invalidated independent model preparation");
        f.analyzer.pause(); f.analyzer.resume();
        f.client.status().complete(FeatureStatus.AVAILABLE); Handler.runCurrent();
        ControlledFuture<Void> pausedPreparation = f.client.preparation(); pausedPreparation.honorCancellation = false;
        f.analyzer.pause(); pausedPreparation.complete(null); Handler.runCurrent();
        check(!f.analyzer.isReady(), "Paused preparation reactivated the model");
        f.analyzer.resume(); f.finishPreparation(FeatureStatus.AVAILABLE);
        check(f.analyzer.canRequest(), "Warmup did not recover after pause");
        f.analyzer.close();
    }

    private static void freshnessAndTimeout() {
        Fixture f = new Fixture(); f.ready(FeatureStatus.AVAILABLE);
        Bitmap stale = frame(); f.analyzer.request(stale, 0);
        Handler.advance(8001); f.client.inference().complete(result("A stale caption.")); Handler.runCurrent();
        check(f.events.scenes.isEmpty() && stale.isRecycled(), "Aged inference was displayed or retained");
        check(f.analyzer.canRequest(), "Stale completed result stranded the controller");
        f.analyzer.request(frame(), 8001);
        Handler.advance(8000); f.client.inference().complete(result("Boundary-age caption.")); Handler.runCurrent();
        check(f.events.scenes.size() == 1, "Exact maximum age should remain usable");
        f.analyzer.request(frame(), 16001);
        ControlledFuture<ImageDescriptionResult> timedOut = f.client.inference();
        timedOut.honorCancellation = false;
        Handler.advance(15001);
        check(timedOut.cancelCalls == 1 && !f.analyzer.canRequest(), "Inference deadline did not cancel/back off");
        timedOut.complete(result("A result after timeout.")); Handler.runCurrent();
        check(f.events.scenes.size() == 1, "Timed-out inference emitted a caption");
        Handler.advance(5000); f.finishPreparation(FeatureStatus.AVAILABLE);
        check(f.analyzer.canRequest(), "Timeout recovery never rechecked readiness");
        f.analyzer.close();
    }

    private static void quotaAndPersistence() {
        Fixture f = new Fixture(); f.ready(FeatureStatus.AVAILABLE);
        f.analyzer.request(frame(), 0);
        f.client.inference().fail(new GenAiException(GenAiException.ErrorCode.BUSY)); Handler.runCurrent();
        f.analyzer.resetSession(); Handler.advance(9999);
        check(!f.analyzer.canRequest(), "BUSY cooldown escaped through reset");
        Handler.advance(1); check(f.analyzer.canRequest(), "BUSY cooldown failed to recover");
        f.analyzer.request(frame(), 10000);
        f.client.inference().fail(new GenAiException(27)); // Documented long-duration quota response.
        Handler.runCurrent();
        f.analyzer.resetSession();
        long until = f.context.getSharedPreferences("duwm_scene_model_policy", Context.MODE_PRIVATE)
                .getLong("quota_until_utc", 0);
        check(until > System.currentTimeMillis() + 3500000L, "Battery quota was not persisted");
        check(!f.analyzer.canRequest(), "Battery quota escaped through reset");
        f.analyzer.close();
        Client recreatedClient = new Client(); Events recreatedEvents = new Events();
        ImageDescription.controlledClient = recreatedClient;
        Duwm1728SceneAnalyzer recreated = new Duwm1728SceneAnalyzer(f.context, recreatedEvents);
        recreated.resume(); Handler.runCurrent();
        check(!recreated.canRequest() && recreatedClient.statuses.isEmpty(),
                "Activity/process recreation bypassed persisted battery cooldown");
        check(recreatedEvents.status() == Duwm1728SceneAnalyzer.State.WAITING, "Missing persisted quota state");
        recreated.close();
    }

    private static void unsupportedAndBackground() {
        Fixture f = new Fixture(); f.analyzer.start();
        f.client.status().complete(FeatureStatus.UNAVAILABLE); Handler.runCurrent();
        check(f.events.status() == Duwm1728SceneAnalyzer.State.UNAVAILABLE, "Unavailable model falsely marked ready");
        check(f.client.preparations.isEmpty() && f.events.scenes.isEmpty(), "Unavailable model fabricated a scene");
        Bitmap rejected = frame();
        check(!f.analyzer.request(rejected, 0) && rejected.isRecycled(), "Unavailable bitmap was retained");
        Handler.advance(300000);
        check(f.client.statuses.size() == 2, "Feature configuration was never rechecked");
        f.finishPreparation(FeatureStatus.AVAILABLE);
        f.analyzer.request(frame(), 0);
        f.client.inference().fail(new GenAiException(30)); // Documented background-use rejection.
        Handler.runCurrent();
        check(!f.analyzer.isReady(), "Background rejection left inference enabled");
        f.analyzer.pause(); f.analyzer.resume(); Handler.advance(29999);
        check(f.client.statuses.size() == 2, "Background cooldown escaped through pause/resume");
        Handler.advance(1); f.finishPreparation(FeatureStatus.AVAILABLE);
        check(f.analyzer.canRequest(), "Foreground preparation never recovered");
        f.analyzer.close();
    }

    private static void badInputsAndClose() {
        Fixture f = new Fixture(); f.ready(FeatureStatus.AVAILABLE);
        Bitmap negative = frame(), overflow = frame();
        check(!f.analyzer.request(negative, -1) && negative.isRecycled(), "Negative source offset accepted");
        check(!f.analyzer.request(overflow, Long.MAX_VALUE) && overflow.isRecycled(), "Overflow source offset accepted");
        f.analyzer.request(frame(), 10); f.client.inference().complete(result("  \n\t")); Handler.runCurrent();
        check(f.events.scenes.isEmpty(), "Empty model text became a description");
        Handler.advance(5000); f.finishPreparation(FeatureStatus.AVAILABLE);
        Bitmap repeated = frame();
        check(!f.analyzer.request(repeated, 10) && repeated.isRecycled(), "Nonmonotonic source time accepted");
        f.client.throwDuringInference = true;
        Bitmap thrown = frame();
        check(!f.analyzer.request(thrown, 11) && thrown.isRecycled(), "Synchronous SDK failure leaked its bitmap");
        f.client.throwDuringInference = false;
        Handler.advance(10000); f.finishPreparation(FeatureStatus.AVAILABLE);
        f.client.throwOnListenerRegistration = true;
        Bitmap registration = frame();
        check(!f.analyzer.request(registration, 12), "Controlled callback registration failure was ignored");
        check(!registration.isRecycled() && f.client.inference().cancelCalls == 1,
                "Future already accepted by SDK was recycled during a setup exception");
        f.client.throwOnListenerRegistration = false;
        f.client.throwOnClose = true;
        f.analyzer.close(); f.analyzer.close(); f.analyzer.resume();
        check(f.client.closed == 1 && f.events.status() == Duwm1728SceneAnalyzer.State.CLOSED,
                "Close was not idempotent or teardown exception escaped");
        Bitmap closed = frame();
        check(!f.analyzer.request(closed, 13) && closed.isRecycled(), "Closed controller accepted/retained image");
        Handler.advance(1000000);
        check(f.events.scenes.isEmpty(), "Closed controller emitted later data");
    }

    private static void closeWithRunningInference() {
        Fixture f = new Fixture(); f.ready(FeatureStatus.AVAILABLE);
        Bitmap input = frame(); f.analyzer.request(input, 0);
        ControlledFuture<ImageDescriptionResult> future = f.client.inference();
        future.honorCancellation = false;
        f.analyzer.close();
        check(future.cancelCalls == 1 && !input.isRecycled(), "Close released a still-owned SDK bitmap");
        future.complete(result("A result after owner destruction.")); Handler.runCurrent();
        check(f.events.scenes.isEmpty(), "Destroyed owner received a scene");
        check(f.events.status() == Duwm1728SceneAnalyzer.State.CLOSED, "Old completion changed closed state");
        Handler.advance(1000000);
        check(f.client.closed == 1 && f.client.statuses.size() == 1, "Closed owner restarted preparation");
    }

    public static void main(String[] args) {
        preparationAndOwnership();
        generationAndPause();
        preparationGenerations();
        freshnessAndTimeout();
        quotaAndPersistence();
        unsupportedAndBackground();
        badInputsAndClose();
        closeWithRunningInference();
        System.out.println("{\"status\":\"PASS\",\"checks\":" + checks + "}");
    }
}
"""


def java_tool(name: str, root: Path) -> str:
    configured = os.environ.get("JAVA_HOME")
    if configured and (Path(configured) / "bin" / name).is_file():
        return str(Path(configured) / "bin" / name)
    discovered = shutil.which(name)
    if discovered:
        return discovered
    # Reuse the supplied offline workspace JDK when this runner is used outside CI.
    for candidate in sorted((root.parent / "android-toolchain").glob("jdk-*/bin/" + name)):
        return str(candidate)
    raise SystemExit("Java 17 is required; set JAVA_HOME to the installed JDK.")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    output = (args.out or root / "artifacts" / "scene-analyzer-host").resolve()
    package = Path("com/sentongoharuna/worldsituationroom")
    production = [
        root / "app/src/main/java" / package / "Duwm1728SceneAnalyzer.java",
        root / "app/src/main/java" / package / "Duwm1728SceneTimeline.java",
    ]
    before = {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
              for path in production}
    compatibility = []
    rejected_logs = []
    with tempfile.TemporaryDirectory(prefix="duwm-scene-controller-doubles-") as temporary:
        temporary = Path(temporary)
        generated = []
        for relative, contents in DOUBLES.items():
            destination = temporary / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(contents, encoding="utf-8")
            generated.append(destination)
        harness = temporary / package / "SceneAnalyzerControllerTest.java"
        harness.parent.mkdir(parents=True, exist_ok=True)
        harness.write_text(HARNESS, encoding="utf-8")
        generated.append(harness)
        # Reintroducing either observed beta1 compiler error must fail against
        # this deliberately restricted test API. These are host regression
        # probes, not claims that the actual SDK artifact was downloaded.
        for missing, replacement in (
            ("PER_APP_BATTERY_USE_QUOTA_EXCEEDED", "SDK_BATTERY_QUOTA_ERROR"),
            ("BACKGROUND_USE_BLOCKED", "SDK_BACKGROUND_BLOCKED_ERROR"),
        ):
            mutated = temporary / ("reintroduced-" + missing) / package / production[0].name
            mutated.parent.mkdir(parents=True, exist_ok=True)
            text = production[0].read_text()
            old = "errorCode == " + replacement
            assert text.count(old) == 1
            mutated.write_text(text.replace(old, "errorCode == GenAiException.ErrorCode." + missing), encoding="utf-8")
            rejected = subprocess.run(
                [java_tool("javac", root), "-encoding", "UTF-8", "-d", str(temporary / ("classes-rejected-" + missing))]
                + [str(path) for path in [mutated, production[1]] + generated],
                capture_output=True, text=True,
            )
            assert rejected.returncode != 0 and "cannot find symbol" in rejected.stderr and missing in rejected.stderr, \
                "Missing-field regression no longer detected: " + missing
            compatibility.append({"missing_sdk_field": missing, "reintroduced_error_rejected": True})
            rejected_logs.append(rejected.stderr)
        classes = temporary / "classes"
        subprocess.run(
            [java_tool("javac", root), "-encoding", "UTF-8", "-d", str(classes)]
            + [str(path) for path in production + generated],
            check=True,
        )
        execution = subprocess.run(
            [java_tool("java", root), "-cp", str(classes),
             "com.sentongoharuna.worldsituationroom.SceneAnalyzerControllerTest"],
            check=False, capture_output=True, text=True,
        )
        if execution.returncode:
            sys.stderr.write(execution.stderr)
            sys.stderr.write(execution.stdout)
            raise SystemExit(execution.returncode)
        report = json.loads(execution.stdout)
    report.update({
        "schema": 1,
        "scope": "REAL_PRODUCTION_CONTROLLER_WITH_TEST_DOUBLES",
        "description": "Deterministic lifecycle, quota, time and ownership tests with the two absent SDK fields omitted; all API doubles were temporary.",
        "sdk_field_compatibility_cases": compatibility,
        "sdk_error_codes_source": "https://developers.google.com/android/reference/com/google/mlkit/genai/common/GenAiException.ErrorCode",
        "documented_error_values": {"battery_quota": 27, "background_blocked": 30},
        "official_sdk_compilation_verified": False,
        "model_inference_verified": False,
        "physical_camera_verified": False,
        "native_encoder_verified": False,
        "production_sources_sha256": {
            str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in production
        },
    })
    output.mkdir(parents=True, exist_ok=True)
    assert before == report["production_sources_sha256"], "Controller changed during regression checks"
    report["inputs_unchanged_during_check"] = True
    (output / "PINNED-SDK-FIELD-REGRESSIONS.txt").write_text("\n".join(rejected_logs), encoding="utf-8")
    serialized = json.dumps(report, indent=2, sort_keys=True) + "\n"
    (output / "SCENE-ANALYZER-HOST.json").write_text(serialized, encoding="utf-8")
    print(serialized, end="")


if __name__ == "__main__":
    main()
