#!/usr/bin/env python3
"""Executable host regressions plus preservation. Not an Android/API compilation claim."""
from pathlib import Path
import verify_native_stages as native_gate
import hashlib,json,subprocess,tempfile,xml.etree.ElementTree as ET,shutil,re,sys
root=Path(__file__).resolve().parents[1]
java=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
from release_contract import assert_release_at_least
assert assert_release_at_least(root,1728)==172821
ui=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1728.2.21' and ui['uiVersionCode']==172821
baseline_path=root/'1728_2_20_SOURCE_SHA256.json'
assert hashlib.sha256(baseline_path.read_bytes()).hexdigest()=='c7fca074cb2f7400272cc7355657bf6562243099744a17f391cca57734af95f5','Immutable delivered /20 source manifest changed'
protected=json.loads((root/'verification/preserved_sources_1728_2_21.json').read_text())
baseline=json.loads(baseline_path.read_text())
baseline_java={name:digest for name,digest in baseline.items() if name.startswith('app/src/main/java/') and name.endswith('.java')}
allowed_changed={'app/src/main/java/com/sentongoharuna/worldsituationroom/'+name for name in (
    'Duwm1728VideoEditorActivity.java','Duwm1728ExportPreflight.java',
    'Duwm1728BroadcastLayout.java','Duwm1728OverlayRenderer.java')}
new_components={'Duwm1728HeadlineFit.java','Duwm1728OutputSizePolicy.java'}
new_java={'app/src/main/java/com/sentongoharuna/worldsituationroom/'+name for name in new_components}
assert len(baseline_java)==302 and len(protected)==298
assert protected=={name:digest for name,digest in baseline_java.items() if name not in allowed_changed},'Preservation must cover every /20 production Java file except the four explicitly scoped automatic-fit integration files'
actual_java={path.relative_to(root).as_posix() for path in (root/'app/src/main/java').rglob('*.java')}
assert actual_java==set(baseline_java)|new_java and len(actual_java)==304,'Unexpected production Java addition/removal outside /21 automatic headline fitting and output-size fallback'
for component in ('Duwm1728CaptionEditPolicy.java','Duwm1728CaptionEditorDialog.java','Duwm1728BroadcastReviewActivity.java'):
    assert any(name.endswith('/'+component) for name in protected),component
for name,digest in protected.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
assert any(n.endswith('SatelliteMapView.java') for n in protected)
assert any(n.endswith('Duwm1718MonitorsCamActivity.java') for n in protected)
print('PASS',len(protected),'unchanged /20 Java components, including original globe and clean camera.')
for file in (root/'app/src').rglob('*.xml'):ET.parse(file)
editor=(java/'Duwm1728VideoEditorActivity.java').read_text();renderer=(java/'Duwm1728OverlayRenderer.java').read_text()
# The reported /16 defect clips two-line marks within their own row; an
# ancestor ScrollView cannot reveal pixels clipped by that immediate parent.
trim_row=editor.split('LinearLayout trimControls=new LinearLayout(this);',1)[1].split('controlColumn.addView(trimControls);',1)[0]
assert 'trimControls.setBaselineAligned(false)' in trim_row and 'trimControls.setGravity(Gravity.CENTER_VERTICAL)' in trim_row
assert 't.setMinHeight(dp(48))' in editor and 'BROADCAST STUDIO  /21' in editor
assert native_gate.STAGES==('signals','graphics','exports4','framing','inset1','review','editor_controls','review_controls','recovery','composition','caption_editing','caption_files','automatic_production','automatic_report','automatic_ready','automatic_fit'),'All sixteen native stages remain mandatory'
# Source-wiring guards for the three observed /16 failures. These do not stand
# in for the Android assertions or claim that a frame was actually displayed.
native_dir=root/'app/src/androidTest/java/com/sentongoharuna/worldsituationroom'
caption_harness=native_dir/'DuwmCaptionFilesChecks.java'
assert hashlib.sha256(caption_harness.read_bytes()).hexdigest()==baseline[caption_harness.relative_to(root).as_posix()],'Preserve the exact /19 repair for the observed /18 RadioButton harness failure'
native_checks=(native_dir/'DuwmBroadcastChecks.java').read_text()
saved_review=native_checks.split('void savedVideoReview(',1)[1].split('private File reviewFixture(',1)[0]
assert 'boolean publishedDeleted=false;' in saved_review
assert 'publishedDeleted=deleted==1;' in saved_review and 'check(publishedDeleted,' in saved_review
assert 'if(!publishedDeleted)target.getContentResolver().delete(published,null,null);' in saved_review
assert '"VIDEO UNAVAILABLE"' in saved_review and '!flag(runner,missing,"ready")' in saved_review and '!flag(runner,missing,"available")' in saved_review
assert '!missing.getWindow().getDecorView().findViewWithTag("broadcast-review-share").isEnabled()' in saved_review
assert 'phase("review.missing_file.verified")' in saved_review
landscape=native_checks.split('private void editorLandscape(',1)[1].split('private boolean reviewPlaying(',1)[0]
for token in ('visible.width()>=control.getWidth()-2','visible.height()>=control.getHeight()-2',
              '"local_bounds"','"visible_bounds"','"row_bounds"','"minimum_touch_height_px"',
              'texture==original.get()&&texture.getParent()==parent.get()',
              'getHeight()>=Math.round(48*editor.getResources().getDisplayMetrics().density)',
              'Math.abs(editorPosition(runner,editor)-before)<=80'):
    assert token in landscape,token
assert 'ANDROID-EDITOR-TRIM-LANDSCAPE-BOUNDS.json' in native_gate.REQUIRED['editor_controls']
fullscreen=native_checks.split('phase("review_controls.fullscreen")',1)[1].split('phase("review_controls.persist")',1)[0]
assert 'DuwmRenderedFrameCapture.captureReviewFullscreen(runner,first,originalVideo.get(),folder,"ANDROID-REVIEW-FULLSCREEN")' in fullscreen
assert 'origin=captured.origin,size=captured.size' in fullscreen
assert fullscreen.index('fullscreen.compress(')<fullscreen.index('proof.assertUnobstructed(')<fullscreen.index('check(captured.ready,')<fullscreen.index('screenColour(fullscreen,')<fullscreen.index('fullscreen.recycle()')
for token in ('video==originalVideo.get()','Arrays.equals(origin,currentOrigin)',
              'size[0]==video.getWidth()&&size[1]==video.getHeight()',
              '!Rect.intersects(picture,exitRect)', 'Math.abs(size[0]/(float)size[1]-16f/9f)<.03f',
              '.10f,.45f,0xFFC91010','.90f,.50f,0xFF1043D0'):
    assert token in fullscreen,token
capture_helper=(native_dir/'DuwmRenderedFrameCapture.java').read_text()
for token in ('TIMEOUT_MS = 5000','CHANNEL_TOLERANCE = 40','runner.getUiAutomation().takeScreenshot()',
              'before.matches(fence.geometry) && before.matches(after)','consecutive >= 2',
              'registerFrameCommitCallback','!layoutPending','name + "-CAPTURE.txt"'):
    assert token in capture_helper,token
assert 'Bitmap.createBitmap' not in capture_helper and 'new Canvas(' not in capture_helper
assert 'ANDROID-REVIEW-FULLSCREEN-CAPTURE.txt' in native_gate.REQUIRED['review_controls']
print('PASS /21 repair source wiring; actual layout, scoped cleanup and composed playback frames still require all sixteen Android stages.')
assert 'convertSrt(text)' not in editor,'Editor must not flatten timed SRT into raw subtitle text'
assert 'Duwm1728ExportPreflight.inspect' in editor and 'Duwm1728ExportPreflight.inspect' in renderer
assert 'outputPlan!=null' in editor and 'prepareTimelines(s)' in editor
assert 'sourceAtProgress' in editor and 'ticker_origin_ms' in editor
assert 'clipEnd-clipStart' in editor and 'caption_timebase' in editor
assert 'renderedCaptions' in renderer and 'renderedTickers' in renderer
assert '45000L' not in renderer and 'fps=24' not in renderer
assert 'planWorker.shutdownNow()' in editor and 'main.removeCallbacks(planKick)' in editor
assert 'startAi(spec())' not in editor
# Caption-file integration guards describe source wiring only; Android intent,
# provider, storage and lifecycle behavior is exercised by caption_files.
caption_srt=(java/'Duwm1728CaptionSrt.java').read_text()
subtitle_import=(java/'Duwm1728SubtitleImport.java').read_text()
caption_controller=(java/'Duwm1728CaptionFilesController.java').read_text()
caption_store=(java/'Duwm1728CaptionFileStore.java').read_text()
caption_provider=(java/'Duwm1728CaptionFileProvider.java').read_text()
assert 'Duwm1728CaptionSrt' in subtitle_import,'SubtitleImport must delegate the shared SRT codec'
assert 'Duwm1728CaptionSrt.importCues(' in caption_controller,'Caption-file import must use validated source-time cue conversion'
assert 'Duwm1728CaptionFilesController' in editor,'Editor must expose the real caption-file controller'
assert 'Duwm1728CaptionSrt' in caption_controller and 'Duwm1728CaptionFileStore' in caption_controller
manifest_root=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
android='{http://schemas.android.com/apk/res/android}'
providers=[p for p in manifest_root.findall('./application/provider') if p.get(android+'name','').rsplit('.',1)[-1]=='Duwm1728CaptionFileProvider']
assert len(providers)==1,'Caption files require exactly one registered provider'
assert providers[0].get(android+'exported')=='false' and providers[0].get(android+'grantUriPermissions')=='true','Caption provider must be private and grantable'
assert providers[0].get(android+'authorities')=='${applicationId}.caption-files','Caption provider must use the app-owned authority'
for token in ('initializeCaptionFiles(saved)','captionFiles.onActivityResult(request,result,data)',
              'captionFiles.saveState(saved)','captionFiles.close()','captionFiles.locksEditor()',
              'private boolean saveDraft(){if(title==null||draftRestoreBlocked)return false;',
              'if(!saveDraft())','draftRestoreBlocked=oldBlocked'):
    assert token in editor,token
for token in ('Intent.ACTION_CREATE_DOCUMENT','Intent.ACTION_OPEN_DOCUMENT',
              'Duwm1728CaptionFileStore.copyTo(','host.replaceCaptions(candidate,',
              '!importSource.equals(host.selection().sourceKey)','worker.shutdown()'):
    assert token in caption_controller,token
for token in ('Intent.EXTRA_STREAM','ClipData','FLAG_GRANT_READ_URI_PERMISSION',
              'openOutputStream(destination,"wt")','uri.getQuery()!=null','uri.getFragment()!=null'):
    assert token in caption_store,token
assert 'FLAG_GRANT_WRITE_URI_PERMISSION' not in caption_store
assert 'if(!"r".equals(mode))throw' in caption_provider and 'ParcelFileDescriptor.MODE_READ_ONLY' in caption_provider
assert native_gate.REQUIRED['caption_files']==('ANDROID-CAPTIONS-ORIGINAL.srt','ANDROID-CAPTIONS-CLIP.srt','ANDROID-CAPTION-FILES.png','ANDROID-CAPTION-FILES-CONFIRM.png','ANDROID-CAPTION-FILES-ERROR.png','ANDROID-CAPTION-FILES-RESTORED.png','CAPTION-FILES-NATIVE.json')
native_dispatcher=(native_dir/'DuwmSignalInstrumentation.java').read_text()
assert re.search(r'case\s+"caption_files"\s*:',native_dispatcher) and 'broadcast.captionFiles(' in native_dispatcher,'New native stage must be dispatched'
assert 'DuwmCaptionFilesChecks' in native_checks,'Broadcast checks must invoke the dedicated caption-files checks'
print('PASS /21 caption-file component, provider and mandatory-evidence wiring. Native behavior remains a separate gate.')
assert native_gate.REQUIRED['automatic_production']==('ANDROID-AUTOMATIC-BROADCAST.mp4','ANDROID-AUTOMATIC-PRODUCTION.png','ANDROID-AUTOMATIC-REVIEW.png','AUTOMATIC-PRODUCTION-NATIVE.json')
assert re.search(r'case\s+"automatic_production"\s*:',native_dispatcher) and 'broadcast.automaticProduction(' in native_dispatcher
assert 'DuwmAutomaticProductionChecks' in native_checks,'Automatic production must reach its real native stage'
assert native_gate.REQUIRED['automatic_report']==('ANDROID-AUTO-REPORT.mp4','ANDROID-AUTO-REPORT-EDITOR.png','ANDROID-AUTO-REPORT-PAGE-1.png','ANDROID-AUTO-REPORT-PAGE-LAST.png','AUTO-REPORT-NATIVE.json')
assert re.search(r'case\s+"automatic_report"\s*:',native_dispatcher) and 'broadcast.automaticReport(' in native_dispatcher
assert 'DuwmAutomaticReportChecks' in native_checks,'Automatic reports must reach their real native stage'
assert (native_dir/'DuwmAutomaticReportChecks.java').is_file()
assert native_gate.REQUIRED['automatic_ready']==('ANDROID-AUTO-READY.mp4','ANDROID-AUTO-READY-TICKER-FIRST.png','ANDROID-AUTO-READY-TICKER-LAST.png','AUTO-READY-NATIVE.json')
assert re.search(r'case\s+"automatic_ready"\s*:',native_dispatcher) and 'broadcast.automaticReady(' in native_dispatcher
assert 'DuwmAutomaticReadyChecks' in native_checks,'Automatic readiness must reach its real native stage'
assert (native_dir/'DuwmAutomaticReadyChecks.java').is_file()
assert native_gate.REQUIRED['automatic_fit']==('ANDROID-AUTO-FIT.mp4','ANDROID-AUTO-FIT-HEADLINE.png','AUTO-FIT-NATIVE.json')
assert re.search(r'case\s+"automatic_fit"\s*:',native_dispatcher) and 'broadcast.automaticFit(' in native_dispatcher
assert 'DuwmAutomaticFitChecks' in native_checks,'Automatic fitting must reach its real native stage'
assert (native_dir/'DuwmAutomaticFitChecks.java').is_file()
layout=(java/'Duwm1728BroadcastLayout.java').read_text()
assert 'Duwm1728CaptionPages.plan(' in layout and '.pageAt(' in layout,'Preview/export layout must use the shared measured caption pager'
assert re.search(r'Duwm1728BroadcastTimeline\.captions\(\s*spec\.automaticTickers\s*,\s*spec\.fromMs\s*,\s*spec\.toMs\s*\)',renderer),'Structured automatic tickers must retain source timing and use shared clip/rebase projection'
assert 's.automaticTickers=' in editor and 'automaticTickerCues' in editor,'Editor must pass structured source-time tickers to export'
assert 'r.automaticTickerPages=!s.automaticTickers.isEmpty();' in renderer,'Only structured automatic ticker cues must enable measured automatic pages'
for token in ('if(r.automaticTickerPages&&c!=null)',
              'Duwm1728CaptionPages.plan(p,tick,size,false,available,1)',
              'pages.pageAt(ms-c.startMs,c.endMs-c.startMs)',
              'r.tickerPixelsPerSecond'):
    assert token in layout,token
transcriber=(java/'Duwm1728RecordedAudioTranscriber.java').read_text()
readiness=(java/'Duwm1728SpeechReadiness.java').read_text()
assert 'Duwm1728SpeechSessionPolicy.completion(' in transcriber,'Real recorded speech recognition must use the tested session completion policy'
assert 'Duwm1728SpeechLanguagePolicy.SupportFlow' in transcriber and 'Duwm1728SpeechLanguagePolicy.SupportFlow' in readiness,'Live readiness and recorded transcription must share the tested bounded language-resolution flow'
assert 'static Intent recordedFileRequest(' in transcriber and 'Duwm1728RecordedAudioTranscriber.recordedFileRequest(' in readiness,'Readiness must use the real recorded-file request builder'
assert 'checkRecognitionSupport(request,' in transcriber and 'recognizer.startListening(request)' in transcriber,'The final exact request must be checked before actual recorded recognition'
assert 'checkRecognitionSupport(request,' in readiness and 'startListening(' not in readiness,'Readiness may query support but must never start recognition'
assert 'triggerModelDownload(' not in readiness and 'triggerModelDownload(' not in transcriber,'Model downloads must remain explicit phone settings actions'
assert 'current.check(result->' in editor and 'speechReadiness!=current' in editor,'The help UI must use live readiness and reject a superseded callback'
assert 'automaticHelpDialog==null||!automaticHelpDialog.isShowing()' in editor and 'closeSpeechReadiness();' in editor,'Readiness must be tied to the visible help dialog lifecycle'
assert 'recordedAudioTranscriber!=current' in editor and 'result.selectedLanguage' in editor,'Automatic production must show language status only from its current request'
print('PASS /21 mandatory automatic-report/readiness evidence, measured caption/ticker pages, retained manual marquee and structured source-time projection. Actual decoded video pages remain a separate Android gate.')
proof=root/'verification/results/1728_2_21';proof.mkdir(parents=True,exist_ok=True)
subprocess.run([sys.executable,str(root/'verification/check_ai_entrypoints.py'),str(proof)],check=True)
with tempfile.TemporaryDirectory() as temp:
    sources=['Duwm1728BroadcastComposition.java','Duwm1728CaptionPages.java','Duwm1728HeadlineFit.java','Duwm1728BroadcastLayout.java','Duwm1728BroadcastTimeline.java','Duwm1728TickerTimeline.java','Duwm1728SubtitleImport.java','Duwm1728CaptionEditPolicy.java','Duwm1728CaptionSrt.java','Duwm1728FramePlan.java','Duwm1728EditorTrimPolicy.java','Duwm1728BroadcastReviewState.java','Duwm1728RecoveryFilePolicy.java','Duwm1728AutomaticProduction.java','Duwm1728SpeechSessionPolicy.java','Duwm1728SpeechLanguagePolicy.java']
    subprocess.run(['javac','--release','17','-d',temp,*[str(java/n) for n in sources],str(root/'verification/broadcast/BroadcastRenderTest.java'),str(root/'verification/broadcast/BroadcastCompositionTest.java'),str(root/'verification/broadcast/baseline/Duwm1728BroadcastLayout14.java'),str(root/'verification/broadcast/BroadcastTimelineTest.java'),str(root/'verification/broadcast/BroadcastFramingTest.java'),str(root/'verification/broadcast/BroadcastFramingRender.java'),str(root/'verification/EditorTrimPolicyTest.java'),str(root/'verification/BroadcastReviewStateTest.java'),str(root/'verification/RecoveryFilePolicyTest.java'),str(root/'verification/AutomaticProductionPolicyTest.java')],check=True)
    for name,args in [('BroadcastRenderTest',[str(proof)]),('BroadcastCompositionTest',[str(proof)]),('BroadcastTimelineTest',[]),('EditorTrimPolicyTest',[]),('BroadcastReviewStateTest',[]),('RecoveryFilePolicyTest',[]),('AutomaticProductionPolicyTest',[str(proof)]),('BroadcastFramingTest',[]),('BroadcastFramingRender',[str(proof)])]:
        result=subprocess.run(['java','-Djava.awt.headless=true','-cp',temp,name if name=='EditorTrimPolicyTest' else 'com.sentongoharuna.worldsituationroom.'+name,*args],capture_output=True,text=True,check=True)
        print(result.stdout,end='');(proof/(name+'.txt')).write_text(result.stdout)
    pkg=Path(temp)/'src/com/sentongoharuna/worldsituationroom';pkg.mkdir(parents=True)
    for name in ('FeedStatus.java','Duwm1724SignalFlow.java','DuwmUnifiedTheme.java','Duwm1728SignalMotion.java','Duwm1728CaptureHealth.java'):
        shutil.copyfile(java/name,pkg/name)
    layer=re.search(r'public enum Layer\s*\{([^}]+)\}',(java/'Signal.java').read_text()).group(1)
    (pkg/'Signal.java').write_text('package com.sentongoharuna.worldsituationroom; public final class Signal {public enum Layer {'+layer+'}}')
    for name in ('SignalMotionTest.java','CaptureHealthTest.java'):shutil.copyfile(root/'verification'/name,pkg/name)
    subprocess.run(['javac','--release','17','-d',temp,*map(str,pkg.glob('*.java'))],check=True)
    for name in ('SignalMotionTest','CaptureHealthTest'):
        result=subprocess.run(['java','-cp',temp,'com.sentongoharuna.worldsituationroom.'+name],capture_output=True,text=True,check=True)
        print(result.stdout,end='');(proof/(name+'.txt')).write_text(result.stdout)
print('PASS /21 wiring, exact identity and XML. Host composition evidence is not native recording or encoding proof; Android runtime, physical phone and live AI remain separate gates.')

pipe=(java/'Duwm1728EglVideoPipe.java').read_text();preflight=(java/'Duwm1728ExportPreflight.java').read_text()
for token in ('s.frameMode=frameMode','Duwm1728FramePlan.create','Duwm1728FramePlan.dimensions','setOpaque(false)','frame_mode','showFraming'):
    assert token in editor,token
assert 'destination' in pipe and 'Duwm1728FramePlan.create' in pipe
assert 'spec.frameMode,spec.frameX,spec.frameY' in renderer
assert 'Duwm1728FramePlan.dimensions' in preflight
assert 'broadcast.framingExports(this,proof.directory())' in (root/'app/src/androidTest/java/com/sentongoharuna/worldsituationroom/DuwmSignalInstrumentation.java').read_text()
assert 'showCompositionGuides' not in renderer and 'showBroadcast' not in renderer
review=(java/'Duwm1728BroadcastReviewActivity.java').read_text()
gallery=(java/'Duwm1726GalleryLibraryActivity.java').read_text()
publisher=(java/'Duwm1724GalleryPublisher.java').read_text()
assert 'Duwm1728BroadcastReviewActivity' in (root/'app/src/main/AndroidManifest.xml').read_text()
assert 'Duwm1728BroadcastReviewActivity.open' in gallery
assert 'Uri.fromFile(dest)' not in publisher
assert 'ACTION_SEND' in review and 'FLAG_GRANT_READ_URI_PERMISSION' in review and 'ClipData' in review
print('PASS shared framing integration, Gallery content URI and native review wiring. Runtime playback/share assertions run in Android.')

subprocess.run([sys.executable,str(root/'verification/NativeStageGateTest.py')],check=True)

composition=(java/'Duwm1728BroadcastComposition.java').read_text()
assert 'Duwm1728BroadcastComposition' in editor and 's.composition=' in editor
assert 'r.composition=' in renderer and 'composition' in (java/'Duwm1728BroadcastLayout.java').read_text()
assert 'composition' in (root/'verification/verify_native_stages.py').read_text()
print('PASS composition wiring from editor to shared preview/export layout; native execution remains separate.')

subprocess.run(["bash",str(root/"verification/run_caption_edit_host_tests.sh"),str(proof)],check=True)
print("PASS /21 caption editing host policy. Actual native UI/encoder acceptance remains separate.")

subprocess.run(["bash",str(root/"verification/run_caption_srt_host_tests.sh"),str(proof/"caption-srt")],check=True)
print("PASS /21 caption SRT host codec. SAF, grants and Android file UI remain separate native checks.")

subprocess.run(["bash",str(root/"verification/run_recorded_audio_host_tests.sh"),str(proof/"recorded-audio")],check=True)
print("PASS /21 recorded-audio PCM and cue host policy. Recognition support and actual Android speech remain separate.")

subprocess.run(["bash",str(root/"verification/run_caption_pages_host_tests.sh"),str(proof/"caption-pages")],check=True)
print("PASS /21 measured caption-page host layout. Actual encoded pages remain a separate native gate.")

subprocess.run(["bash",str(root/"verification/run_automatic_ticker_pages_host_tests.sh"),str(proof/"automatic-ticker-pages")],check=True)
print("PASS /21 measured automatic ticker pages and retained manual marquee host behavior. Actual decoded ticker pages remain a separate native gate.")

subprocess.run(["bash",str(root/"verification/run_speech_language_host_tests.sh"),str(proof/"speech-language")],check=True)
print("PASS /21 deterministic installed speech-language policy and bounded support-check flow. Installed Android services and real recognition remain separate native/device checks.")

subprocess.run(["bash",str(root/"verification/run_output_size_host_tests.sh"),str(proof/"output-size")],check=True)
print("PASS /21 automatic-only advertised AVC output-size selection and strict manual policy. Real device encoder selection remains a native gate.")

subprocess.run(["bash",str(root/"verification/run_automatic_headline_fit_host_tests.sh"),str(proof/"automatic-headline-fit")],check=True)
print("PASS /21 measured automatic headline fitting and retained manual headline layout. Encoded headline pixels remain a separate native gate.")

subprocess.run([sys.executable,str(root/"verification/package_1728_2_21.py"),"--check-workflow-contexts"],check=True)
