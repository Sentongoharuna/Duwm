#!/usr/bin/env python3
"""Compile selected /21/3 wiring against Android and cached real app classes.

This checks the changed layout/editor/renderer/review and their native checks without
inventing any Google API declarations. It is not a full application build:
SceneAnalyzer and the official ML Kit dependency require the separate Gradle
gate. Cached dependencies must come from a previously compiled project.
"""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = "com/sentongoharuna/worldsituationroom/"
MAIN = (
    "Duwm1728BroadcastReviewActivity.java",
    "Duwm1728BroadcastLayout.java", "Duwm1728ClearPictureLayout.java",
    "Duwm1728OverlayRenderer.java", "Duwm1728OverlayCadence.java",
    "Duwm1728VideoEditorActivity.java", "Duwm1728LiveSceneView.java",
    "Duwm1728SceneTimeline.java", "Duwm1728SceneStore.java",
    "Duwm1728Measurements.java", "Duwm1728MeasurementMath.java",
    "Duwm1728MeasurementStore.java", "Duwm1728MeasurementSources.java",
)
NATIVE = (
    "DuwmAutomaticFitChecks.java", "DuwmAacPacketContract.java", "DuwmNativeAacChecks.java",
    "DuwmMeasuredTelemetryChecks.java", "DuwmSceneTimelineChecks.java",
    "DuwmClearPictureChecks.java", "DuwmNativeEvidence.java",
    "DuwmBroadcastChecks.java", "DuwmSignalInstrumentation.java",
)
CACHED = (
    "app/build/intermediates/javac/debug/compileDebugJavaWithJavac/classes",
    "app/build/intermediates/javac/debugAndroidTest/compileDebugAndroidTestJavaWithJavac/classes",
    "app/build/intermediates/compile_and_runtime_not_namespaced_r_class_jar/debug/processDebugResources/R.jar",
    "app/build/intermediates/compile_and_runtime_not_namespaced_r_class_jar/debugAndroidTest/processDebugAndroidTestResources/R.jar",
)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--android-jar", type=Path, required=True)
    parser.add_argument("--compiled-baseline", type=Path, required=True)
    parser.add_argument("--javac", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    android = args.android_jar.resolve()
    baseline = args.compiled_baseline.resolve()
    output = args.out.resolve()
    dependencies = [baseline / name for name in CACHED]
    if not android.is_file() or any(not path.exists() for path in dependencies):
        raise SystemExit("The real Android JAR and cached compiled dependencies are required")
    for path in dependencies:
        if path.is_dir() and list(path.glob("com/google/mlkit/**/*.class")):
            raise SystemExit("Google API classes are outside this selected-source check")
    sources = [ROOT / ("app/src/main/java/" + PACKAGE + name) for name in MAIN]
    sources += [ROOT / ("app/src/androidTest/java/" + PACKAGE + name) for name in NATIVE]
    cached_files = sorted({file for path in dependencies
                           for file in (path.rglob("*") if path.is_dir() else [path])
                           if file.is_file()})

    def input_hashes():
        return ({path.relative_to(ROOT).as_posix(): sha(path) for path in sources},
                {path.relative_to(baseline).as_posix(): sha(path) for path in cached_files},
                sha(android))

    before = input_hashes()
    output.mkdir(parents=True, exist_ok=True)
    classes = output / "classes"
    classes.mkdir(exist_ok=True)
    command = [args.javac, "--release", "17", "-encoding", "UTF-8",
               "-proc:none", "-implicit:none", "-sourcepath", "",
               "-cp", ":".join(map(str, [android] + dependencies)),
               "-d", str(classes)] + list(map(str, sources))
    run = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT)
    (output / "JAVAC.txt").write_text(run.stdout)
    unchanged = before == input_hashes()
    report = {
        "schema": 1, "build": "1728.2/21/3",
        "scope": "Selected clear-picture layout/editor/renderer/review/storage and all changed native-stage Java against cached Android API 36 and actual delivered /21 compiled dependencies; no Google API declarations",
        "status": "PASS" if run.returncode == 0 and unchanged else "FAIL",
        "returncode": run.returncode,
        "sources_unchanged_during_typecheck": unchanged,
        "source_count": len(sources), "source_sha256": before[0],
        "android_jar_sha256": before[2],
        "cached_dependency_files": len(cached_files),
        "cached_dependencies_sha256": hashlib.sha256(json.dumps(before[1], sort_keys=True).encode()).hexdigest(),
        "official_mlkit_dependency_resolved": False,
        "official_mlkit_compilation_verified": False,
        "google_api_declarations_used": False,
        "apk_built": False, "android_native_executed": False,
        "physical_camera_executed": False, "physical_sensors_executed": False,
        "model_inference_executed": False, "provider_network_executed": False,
        "command": command,
    }
    (output / "CACHED-DEPENDENCY-INPUTS.json").write_text(json.dumps(before[1], indent=2) + "\n")
    (output / "RESULT.json").write_text(json.dumps(report, indent=2) + "\n")
    print(f"{report['status']}: {len(sources)} selected actual Android sources; Google SDK build and native execution not verified.")
    if run.stdout:
        print(run.stdout[-12000:])
    if report["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
