from pathlib import Path
root=Path(__file__).resolve().parents[1]
pkg=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
a=(pkg/'Duwm1728RecordedAudioTranscriber.java').read_text()
e=(pkg/'Duwm1728VideoEditorActivity.java').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
required_a=['MediaExtractor','MediaCodec','ParcelFileDescriptor.createPipe()', 'createOnDeviceSpeechRecognizer', 'RecognizerIntent.EXTRA_AUDIO_SOURCE','RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE','RecognizerIntent.EXTRA_REQUEST_WORD_TIMING','RecognitionPart','getTimestampMillis()', 'hasVerifiedWordTimes','callbacks.error', '55000', 'toTimedCues(parts)','sourceTime<fromMs']
required_e=['TRANSCRIBE RECORDED VIDEO AUDIO','Duwm1728RecordedAudioTranscriber','Review recorded-audio transcript','Duwm1728TickerTimeline.parse(checked)','No camera microphone fallback']
for item in required_a:assert item in a,item
for item in required_e:assert item in e,item
assert '<queries>' in manifest and 'android.speech.RecognitionService' in manifest
assert 'recordedAudioTranscriber.close()' in e
assert 'subtitles.setText(checked)' in e
assert 'Duwm1728TickerTimeline.parse(checked)' in e
print('PASS 1728.2/5 guarded injected recorded-audio recognition, source timings, edit-before-import and cancellation checks')
