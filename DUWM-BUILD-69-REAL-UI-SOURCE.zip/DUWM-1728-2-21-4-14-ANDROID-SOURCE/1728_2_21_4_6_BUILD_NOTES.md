# DUWM 1728.2/21/4/6 — Semantic signal colours

- Red is reserved for explicit BREAKING / URGENT / ALERT / EMERGENCY states.
- Cyan/blue is used for live measured data and active telemetry. Weather uses blue; general live measurements use cyan.
- Yellow is used for WATCH / CAUTION / STALE / UNAVAILABLE / UNRELIABLE / UNCERTAIN / OFF states.
- Green is used only for explicitly VERIFIED / ACTIVE / CONFIRMED states and never for UNVERIFIED.
- The colour policy changes presentation only; it does not invent a verification, urgency or sensor state.
- The clear-picture geometry, AI headline/subtitle, measured HDG/ALT/WX, rotating GPS/SPEED/FPS/REC slot and automatic finishing/export are retained.
