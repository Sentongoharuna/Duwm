# DUWM 1728.2/21/4/9 — Source/time ticker attribution

- Every visible ticker item now carries an evidence-source label and original-recording timestamp.
- Example: `RECORDED SPEECH • 00:55 | ...`.
- Trimmed exports preserve original footage time: `fromMs + cue.startMs`.
- Automatic speech excerpts label `RECORDED SPEECH`; capture-note excerpts label `CAPTURE NOTES`; manual ticker entries label `REPORTER ENTRY`.
- No publisher/source identity is invented.
- Smooth `/21.4/8` motion and edge gutters remain unchanged.
