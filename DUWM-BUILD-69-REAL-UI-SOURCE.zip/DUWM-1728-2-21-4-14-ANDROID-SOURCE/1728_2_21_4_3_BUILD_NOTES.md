# DUWM 1728.2/21/4/3

Improvement 3: short AI-generated scene description subtitle.

- Keeps the automatic AI event headline from /21.4/2.
- Replaces long/raw subtitle copy with a concise sentence-case description derived only from the current on-device Image Description result.
- Removes image-description boilerplate such as “The image shows”.
- Keeps one observed sentence, maximum sixteen visible words and 112 code points.
- Does not invent people, places, causes, urgency or facts absent from the AI observation.
- The full model description remains stored in the scene timeline for provenance; only the visible broadcast subtitle is shortened.
- Existing expiry and source-time rules remain unchanged.
- Retains /21/4 automatic finishing/export and all earlier clear-picture/telemetry behavior.
