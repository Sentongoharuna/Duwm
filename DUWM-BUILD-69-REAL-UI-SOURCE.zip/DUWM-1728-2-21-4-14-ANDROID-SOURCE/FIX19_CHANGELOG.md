1728.2/21.4/19: Immersive full screen camera with focus/resume persistence; original single globe R11-style radar sweep refined. APK not verified.
