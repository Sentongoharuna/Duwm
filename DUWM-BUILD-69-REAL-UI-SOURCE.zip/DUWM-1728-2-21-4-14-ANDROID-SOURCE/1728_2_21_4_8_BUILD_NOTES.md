# DUWM 1728.2/21/4/8 — Smooth edge-safe ticker

- Replaces the legacy repeating marquee offset with deterministic source-time motion.
- Preserves Slow / Normal / Fast ticker speed controls.
- Uses protected left/right gutters inside the ticker strip so the outer broadcast edge never slices a glyph.
- Keeps the full ticker string; no ellipsis or truncation is introduced.
- Uses a larger inter-message gap so repeated headlines do not visually collide.
- Preview/export remain deterministic because ticker position is derived from the same source time.
- Keeps AI headline/subtitle, measured telemetry, semantic signal colours, automatic reporter status and automatic finishing.
