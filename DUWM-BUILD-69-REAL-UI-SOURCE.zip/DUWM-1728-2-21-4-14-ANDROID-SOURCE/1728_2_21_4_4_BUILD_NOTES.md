# DUWM 1728.2/21/4/4 — Real measured HDG / ALT / WX

- HDG now renders the actual camera optical-axis magnetic heading from Android rotation sensors, cardinal direction, and measurement age.
- ALT renders the actual Android Location altitude, identifies MSL or WGS84, includes vertical accuracy when reported, and measurement age.
- WX renders the actual Open-Meteo model/provider result already captured by the measurement pipeline, preserving provider, condition, temperature/wind, model time and stale/unavailable states.
- No synthetic values are introduced. Missing, stale, off and unreliable states remain explicit.
- Source-time playback/export continues to use the measurement sample that existed at that source time.
