package com.sentongoharuna.worldsituationroom;

/** Deterministic source-time ticker motion with protected edge gutters.
 * No text is shortened or ellipsized. The message travels through an inset
 * viewport, so the outer broadcast border never slices a glyph.
 */
public final class Duwm1728SmoothTicker {
    private Duwm1728SmoothTicker() {}
    public static float safeInset(float unit) { return Math.max(12f * unit, 1f); }
    public static float repeatGap(float unit, float textSize) { return Math.max(84f * unit, textSize * 3.5f); }
    public static float firstX(long relativeMs, float textWidth, float viewportWidth, float pixelsPerSecond, float unit, float textSize) {
        if (viewportWidth <= 0f) return 0f;
        float inset = safeInset(unit);
        float safeWidth = Math.max(1f, viewportWidth - inset * 2f);
        float width = Math.max(1f, textWidth);
        float speed = Math.max(20f * unit, Math.min(180f * unit, pixelsPerSecond * unit));
        float cycle = safeWidth + width + repeatGap(unit, textSize);
        double elapsed = Math.max(0L, relativeMs) / 1000d;
        return viewportWidth - inset - (float)((elapsed * speed) % cycle);
    }
    public static float period(float textWidth, float unit, float textSize) {
        return Math.max(1f, textWidth) + repeatGap(unit, textSize);
    }
}
