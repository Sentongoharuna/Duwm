package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/** A navigation-capable globe: coastlines are Natural Earth, markers are observations only. */
public final class OperationsGlobeView extends View {
    public static final int AIR=1, QUAKE=2, SPACE=3, SEA=4;
    public static final class Observation {
        public final int type;
        public final double lat,lon;
        public final String title,detail,source;
        public final long timeMillis;
        public Observation(int type,double lat,double lon,String title,String detail,String source,long timeMillis){
            this.type=type;this.lat=lat;this.lon=lon;this.title=title;this.detail=safeDetail(detail);this.source=source;this.timeMillis=timeMillis;
        }
    }
    public interface OnObservationSelected {void onSelected(Observation item);}
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    // FIX8: R11-inspired live sweep and observation pulse, rendered on the original globe.
    private static final double TAU=Math.PI*2d;
    private final List<List<double[]>> coastlines=new ArrayList<>();
    private final List<Observation> objects=new ArrayList<>();
    // Actual previous provider positions, retained only when the same track updates.
    private final java.util.Map<String,Observation> priorTracks=new java.util.HashMap<>();
    private long trackTransitionStart=0L;
    private static final long TRANSITION_MS=11000L;
    private static final long FRESH_AIR_MS=90000L;
    private static final long FRESH_SEA_MS=240000L;
    private boolean reduceMotion=false;
    private boolean showFreshness=true;
    private int visibleAir=0,visibleSea=0,staleMarkers=0;
    private int invalidObservationCount=0;
    private int duplicateObservationCount=0;
    private int rejectedTrackCount=0;
    private int validObservationCount=0;
    public void setReducedMotion(boolean value){
        reduceMotion=value;
        if(moving && !value)postInvalidateOnAnimation();else invalidate();
    }
    public void setShowFreshness(boolean value){showFreshness=value;invalidate();}
    public boolean isReducedMotion(){return reduceMotion;}
    public boolean isFreshnessVisible(){return showFreshness;}
    public void resetView(){zoom=1f;yaw=Math.toRadians(32);pitch=Math.toRadians(7);invalidate();}
    public int getInvalidObservationCount(){return invalidObservationCount;}
    public int getDuplicateObservationCount(){return duplicateObservationCount;}
    public int getRejectedTrackCount(){return rejectedTrackCount;}
    public int getValidObservationCount(){return validObservationCount;}
    // Stable provider identity: only received positions of the same tracked object are joined.
    private static String trackKey(Observation a){return a.type+"/"+a.source.trim()+"/"+a.title.trim();}
    private static double wrappedDelta(double from,double to){return ((to-from+540d)%360d)-180d;}
    private static String safeDetail(String value){return value==null?"":value.trim();}
    private static boolean validObservation(Observation a){
        return a!=null && (a.type==AIR || a.type==SEA || a.type==QUAKE || a.type==SPACE) && a.title!=null && !a.title.trim().isEmpty() && a.source!=null && !a.source.trim().isEmpty() &&
            Double.isFinite(a.lat) && Double.isFinite(a.lon) &&
            Math.abs(a.lat)<=90d && Math.abs(a.lon)<=180d && a.timeMillis>0L && a.timeMillis<=System.currentTimeMillis()+30000L;
    }
    private static boolean genuinelyMoved(Observation a,Observation b){
        return Math.abs(a.lat-b.lat)>0.00001d || Math.abs(wrappedDelta(a.lon,b.lon))>0.00001d;
    }
    private static boolean plausibleTrack(Observation old,Observation next){
        long delta=next.timeMillis-old.timeMillis;
        if(delta<=0 || delta>240000L || old.type!=next.type)return false;
        double dLat=Math.toRadians(next.lat-old.lat),dLon=Math.toRadians(wrappedDelta(old.lon,next.lon));
        double a=Math.pow(Math.sin(dLat/2),2)+Math.cos(Math.toRadians(old.lat))*Math.cos(Math.toRadians(next.lat))*Math.pow(Math.sin(dLon/2),2);
        double km=12742d*Math.asin(Math.min(1d,Math.sqrt(Math.max(0d,a))));
        double maxKmh=next.type==AIR?1100d:next.type==SEA?75d:0d;
        if(maxKmh<=0d)return false;
        return km/(delta/3600000d)<=maxKmh;
    }
    private static double interpolateLongitude(double from,double to,float fraction){
        double delta=((to-from+540d)%360d)-180d;
        return ((from+delta*fraction+540d)%360d)-180d;
    }

    private OnObservationSelected listener;
    private boolean moving=false, aircraft=true,quakes=true,space=true,sea=true,dragging=false,auroraPalette=true,compassRingEnabled=true;
    private float speedScale=1f;
    private long previousFrame=0;
    private long lastDataReceivedAt=0L;
    public boolean hasReceivedProviderData(){return lastDataReceivedAt>0L;}
    public long getLastDataReceivedAt(){return lastDataReceivedAt;}
    public long getDataAgeMillis(){return lastDataReceivedAt<=0L?-1L:Math.max(0L,System.currentTimeMillis()-lastDataReceivedAt);}
    public boolean isProviderRefreshStale(){long age=getDataAgeMillis();return age<0 || age>300000L;}
    // P3: ease rotation after touch and focus only on real reported positions.
    private long lastGestureEnd=0;
    private float rotationBlend=1f;
    private boolean focusPending=false;
    private double focusYaw=0,focusPitch=0;
    private Observation selectedObservation;

    private long frameCounter=0;
    private double totalDegrees=0;
    private double yaw=Math.toRadians(32), pitch=Math.toRadians(7);
    private float cx,cy,radius,zoom=1f,lastX,lastY,downX,downY;
    private int coastSegments=0;
    private boolean focusOn=false;
    private double focusedLat,focusedLon;
    private final ScaleGestureDetector scaler;
    private final int OCEAN_COLOR=Color.rgb(4,21,43), LAND=DuwmUnifiedTheme.MAP_COAST, GRID=Color.argb(62,57,181,195), EDGE=DuwmUnifiedTheme.MAP_RIM;

    public OperationsGlobeView(Context c){
        super(c);scaler=new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
            @Override public boolean onScale(ScaleGestureDetector d){zoom=Math.max(.8f,Math.min(2.2f,zoom*d.getScaleFactor()));invalidate();return true;}
        });loadCoasts();setContentDescription("Modern HD Earth with detailed real coastline geometry and source-observed markers. Drag to rotate, pinch to zoom, tap an actual marker for details.");
    }
    /** DUWM 1673 true visual upgrade: users can change both globe palettes live. */
    public void setGlobePalette(boolean aurora){auroraPalette=aurora;if(moving)postInvalidateOnAnimation();else invalidate();}
    public boolean isAuroraPalette(){return auroraPalette;}
    public void togglePalette(){setGlobePalette(!auroraPalette);}
    /** Visual speed is geographic rotation, not a measurement or object update. */
    public void setRotationSpeed(float speed){
        if(!Float.isFinite(speed) || speed<=0f)return;
        speedScale=Math.max(.25f,Math.min(2.2f,speed));
        if(moving)postInvalidateOnAnimation();
    }
    public void toggleCompassRing(){setCompassRingEnabled(!compassRingEnabled);}
    public void setCompassRingEnabled(boolean visible){compassRingEnabled=visible;if(moving)postInvalidateOnAnimation();else invalidate();}
    public int getObservationCount(){return objects.size();}
    public int getTrackedMovementCount(){return priorTracks.size();}
    public int getFreshAircraftCount(){return visibleAir;}
    public boolean hasFreshAircraft(){return visibleAir>0;}
    public boolean hasMovingTracks(){return !priorTracks.isEmpty();}
    public int getFreshVesselCount(){return visibleSea;}
    public boolean hasFreshVessels(){return visibleSea>0;}
    public boolean hasAnyFreshTransport(){return visibleAir+visibleSea>0;}
    public int getStaleObservationCount(){return staleMarkers;}
    public boolean hasStaleObservations(){return staleMarkers>0;}
    public int getCoastSegmentCount(){return coastSegments;}
    public void focusAt(double lat,double lon){
        if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)return;
        focusOn=true;focusedLat=lat;focusedLon=lon;
        moving=false;yaw=Math.toRadians(lon);
        pitch=Math.max(-1.1,Math.min(1.1,Math.toRadians(lat)));
        invalidate();
    }
    public void setOnObservationSelected(OnObservationSelected l){listener=l;}
    public void setObservations(List<Observation> items){
        Observation previous=selectedObservation;
        java.util.Map<String,Observation> old=new java.util.HashMap<>();
        for(Observation v:objects)if(v.type==AIR||v.type==SEA)old.put(trackKey(v),v);
        priorTracks.clear();
        objects.clear();
        invalidObservationCount=0;duplicateObservationCount=0;rejectedTrackCount=0;validObservationCount=0;
        java.util.Map<String,Observation> latest=new java.util.LinkedHashMap<>();
        if(items!=null)for(Observation v:items){
            if(!validObservation(v)){invalidObservationCount++;continue;}
            String key=trackKey(v)+(v.type==AIR||v.type==SEA?"":"/"+v.timeMillis+"/"+v.lat+"/"+v.lon);
            Observation existing=latest.get(key);
            if(existing!=null){duplicateObservationCount++;
                if(existing.timeMillis>=v.timeMillis)continue;
            }
            latest.put(key,v);
        }
        objects.addAll(latest.values());
        validObservationCount=objects.size();
        for(Observation v:objects){
            Observation o=old.get(trackKey(v));
            if(o!=null && genuinelyMoved(o,v)){
                if(plausibleTrack(o,v))priorTracks.put(trackKey(v),o);
                else rejectedTrackCount++;
            }
        }
        trackTransitionStart=SystemClock.uptimeMillis();
        if(items!=null && !items.isEmpty())lastDataReceivedAt=System.currentTimeMillis();
        selectedObservation=null;
        if(previous!=null)for(Observation v:objects){
            if(v.type==previous.type && v.source.equals(previous.source) && v.title.equals(previous.title)){
                selectedObservation=v;break;
            }
        }
        invalidate();
    }
    /** P3 CENTER SELECTED: only a real provider observation can control the viewpoint. */
    public boolean duwmP3FocusObservation(Observation observation){
        if(observation==null)return false;
        Observation current=null;
        for(Observation v:objects){
            if(v==observation || (v.type==observation.type && v.source.equals(observation.source) &&
               v.title.equals(observation.title) && (v.type!=QUAKE || v.timeMillis==observation.timeMillis))){
                current=v;break;
            }
        }
        // A stale selection that has disappeared from the last real feed is not invented on screen.
        if(current==null || !Double.isFinite(current.lat) || !Double.isFinite(current.lon) ||
           Math.abs(current.lat)>90d || Math.abs(current.lon)>180d)return false;
        selectedObservation=current;
        focusYaw=Math.toRadians(current.lon);
        focusPitch=Math.max(-1.32d,Math.min(1.32d,Math.toRadians(current.lat)));
        focusPending=true;
        rotationBlend=0f;
        lastGestureEnd=SystemClock.uptimeMillis();
        previousFrame=lastGestureEnd;
        postInvalidateOnAnimation();
        return true;
    }

    public void showLayer(int kind,boolean enabled){if(kind==AIR)aircraft=enabled;else if(kind==QUAKE)quakes=enabled;else if(kind==SPACE)space=enabled;else if(kind==SEA)sea=enabled;invalidate();}
    public void showTransportOnly(){aircraft=true;sea=true;quakes=false;space=false;invalidate();}
    public boolean isLayerVisible(int kind){return kind==AIR?aircraft:kind==SEA?sea:kind==QUAKE?quakes:kind==SPACE&&space;}
    public void resume(){moving=true;previousFrame=SystemClock.uptimeMillis();rotationBlend=0f;postInvalidateOnAnimation();}
    public boolean isGlobeAnimating(){return moving;}
    public void toggleRotation(){if(moving)pause();else resume();}
    public void pause(){moving=false;previousFrame=SystemClock.uptimeMillis();invalidate();}
    // 21.4/20: animated atmospheric beacon ring, purely visual; never a synthetic tracked object.
    private void drawAtmosphericBeacons(Canvas canvas,long now){
        if(radius<=0 || reduceMotion)return;
        final float phase=(now%9500L)/9500f;
        p.setStyle(Paint.Style.STROKE);
        for(int i=0;i<3;i++){
            float theta=(float)(phase*Math.PI*2+i*Math.PI*2/3);
            float x=cx+(float)Math.cos(theta)*radius*1.055f;
            float y=cy+(float)Math.sin(theta)*radius*.21f;
            p.setColor(i==0?0xCC48D9FF:(i==1?0xAA38E6B3:0x99F3BD54));
            p.setStrokeWidth(Math.max(1.5f,radius*.007f));
            canvas.drawCircle(x,y,Math.max(2f,radius*.022f)*(1f+.24f*(float)Math.sin(theta*3)),p);
        }
        p.setStyle(Paint.Style.FILL);
    }
    @Override protected void onDetachedFromWindow(){pause();super.onDetachedFromWindow();}
    private int dp(float value){return (int)(value*getResources().getDisplayMetrics().density+.5f);}
    private void loadCoasts(){
        // V1159.4: actual GSHHS shorelines; no invented object positions.
        // These points are rendered on the SAME modern globe every animated frame.
        try(BufferedReader br=new BufferedReader(new InputStreamReader(getContext().getAssets().open("naturalearth_coasts.txt"),"UTF-8"))){
            String line;while((line=br.readLine())!=null){List<double[]> coast=new ArrayList<>();for(String pair:line.split(" ")){
                String[] v=pair.split(",");if(v.length!=2)continue;double lat=Double.parseDouble(v[0]),lon=Double.parseDouble(v[1]);
                if(Math.abs(lat)<=90&&Math.abs(lon)<=180)coast.add(new double[]{lat,lon});
            }if(coast.size()>=3){coastlines.add(coast);coastSegments++;}}
        }catch(Exception ignored){/* Missing coastline data is not replaced with invented geography. */}
    }
    private float[] project(double lat,double lon){
        double a=Math.toRadians(lat),b=Math.toRadians(lon)-yaw;
        double x=Math.cos(a)*Math.sin(b),y=Math.sin(a),z=Math.cos(a)*Math.cos(b);
        double cp=Math.cos(pitch),sp=Math.sin(pitch),tiltedY=y*cp-z*sp,depth=y*sp+z*cp;
        if(depth<=0.004d)return null;
        return new float[]{cx+(float)(radius*x),cy-(float)(radius*tiltedY)};
    }
    private boolean enabled(int kind){return kind==AIR?aircraft:kind==QUAKE?quakes:kind==SEA?sea:space;}
    private void strokePath(Canvas c,List<double[]> lines){Path path=new Path();boolean active=false;
        for(double[] spot:lines){float[] v=project(spot[0],spot[1]);if(v==null){active=false;continue;}
            if(!active){path.moveTo(v[0],v[1]);active=true;}else path.lineTo(v[0],v[1]);}c.drawPath(path,p);
    }
    private void grid(Canvas c,boolean meridian,int coordinate){Path path=new Path();boolean begun=false;
        for(int i=0;i<=180;i++){double lat=meridian?-90+i:coordinate,lon=meridian?coordinate:-180+2*i;
            float[] v=project(lat,lon);if(v==null){begun=false;continue;}
            if(!begun){path.moveTo(v[0],v[1]);begun=true;}else path.lineTo(v[0],v[1]);}c.drawPath(path,p);
    }
    private int tint(int kind){return kind==AIR?DuwmUnifiedTheme.MAP_COAST:kind==QUAKE?DuwmUnifiedTheme.MAP_RIM:kind==SEA?DuwmUnifiedTheme.MAP_RIM:DuwmUnifiedTheme.MAP_COAST;}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        long now=SystemClock.uptimeMillis();
        long dt=Math.min(34,Math.max(0,now-previousFrame));previousFrame=now;
        boolean rotatedThisFrame=false;
        if(!dragging && focusPending){
            double dyaw=Math.atan2(Math.sin(focusYaw-yaw),Math.cos(focusYaw-yaw));
            double dpitch=focusPitch-pitch;
            double easing=1d-Math.exp(-Math.max(1,dt)/180d);
            yaw+=dyaw*easing;pitch+=dpitch*easing;
            rotatedThisFrame=true;
            if(Math.abs(dyaw)<.002d && Math.abs(dpitch)<.002d){yaw=focusYaw;pitch=focusPitch;focusPending=false;}
        }else if(moving && !dragging && now-lastGestureEnd>1700L){
            rotationBlend=Math.min(1f,rotationBlend+dt/1650f);
            double advance=dt*.000147d*rotationBlend*speedScale;
            yaw=(yaw+advance)%(2*Math.PI);
            totalDegrees+=Math.abs(advance)*180d/Math.PI;
            rotatedThisFrame=advance>0d;
        }
        if(rotatedThisFrame)frameCounter++;
        float w=getWidth(),h=getHeight();cx=w/2f;cy=h*.49f;radius=Math.max(dp(20),Math.min(w*.44f,h*.45f)*zoom);
        // DUWM 1673: distinct aurora/carbon command globe, not the frozen legacy presentation.
        int rim=auroraPalette?DuwmUnifiedTheme.MAP_RIM:DuwmUnifiedTheme.MAP_RIM;
        int haze=auroraPalette?DuwmUnifiedTheme.MAP_COAST:DuwmUnifiedTheme.MAP_COAST;
        canvas.drawColor(auroraPalette?0xFF020B1B:0xFF031326);
        p.setShader(null);p.setStyle(Paint.Style.STROKE);
        p.setColor(auroraPalette?0x170D2A45:0x160D2A45);p.setStrokeWidth(dp(25));canvas.drawCircle(cx,cy,radius+dp(8),p);
        p.setColor(auroraPalette?0x53184472:0x53184472);p.setStrokeWidth(dp(7));canvas.drawCircle(cx,cy,radius+dp(3),p);
        p.setColor(auroraPalette?0xC1184472:0xC1184472);p.setStrokeWidth(dp(1.4f));canvas.drawCircle(cx,cy,radius+dp(9),p);
        // Calibrated outer compass ticks track the REAL view orientation, not fake intelligence.
        for(int n=0;compassRingEnabled && n<96;n++){
            double theta=Math.PI*n/48d;
            float sx=cx+(float)Math.cos(theta)*(radius+dp(11));
            float sy=cy+(float)Math.sin(theta)*(radius+dp(11));
            float ex=cx+(float)Math.cos(theta)*(radius+dp(n%8==0?24:16));
            float ey=cy+(float)Math.sin(theta)*(radius+dp(n%8==0?24:16));
            p.setStrokeWidth(dp(n%8==0?1.5f:.65f));p.setColor(n%8==0?rim:0x6628547A);
            canvas.drawLine(sx,sy,ex,ey,p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(auroraPalette?DuwmUnifiedTheme.MAP_OCEAN:DuwmUnifiedTheme.MAP_OCEAN);canvas.drawCircle(cx,cy,radius,p);
        p.setShader(new LinearGradient(cx-radius,cy-radius,cx+radius,cy+radius,
                auroraPalette?DuwmUnifiedTheme.MAP_OCEAN:DuwmUnifiedTheme.MAP_OCEAN,
                auroraPalette?0xFF041424:0xFF041424,Shader.TileMode.CLAMP));
        canvas.drawCircle(cx,cy,radius,p);p.setShader(null);
        // Soft blue atmospheric rim restores the older live-motion colour depth.
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2.6f));p.setColor(0xB944BDF5);
        canvas.drawCircle(cx,cy,radius-dp(1),p);p.setStyle(Paint.Style.FILL);
        canvas.save();Path clipping=new Path();clipping.addCircle(cx,cy,radius,Path.Direction.CW);canvas.clipPath(clipping);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(.76f));
        p.setColor(auroraPalette?0x42173B5B:0x42173B5B);
        for(int i=-150;i<=180;i+=30)grid(canvas,true,i);
        for(int i=-60;i<=60;i+=30)grid(canvas,false,i);
        // V1159.4: preserved two-pass geographic coastlines; real asset provides the positions.
        p.setColor(auroraPalette?0x5432C7F4:0x30173B5B);p.setStrokeWidth(dp(4.6f));for(List<double[]> coastline:coastlines)strokePath(canvas,coastline);
        p.setColor(auroraPalette?0xFF5CEBFF:0xFF39C8F4);p.setStrokeWidth(dp(1.65f));for(List<double[]> coastline:coastlines)strokePath(canvas,coastline);
        int max=1800,shown=0;visibleAir=0;visibleSea=0;staleMarkers=0;
        long wallNow=System.currentTimeMillis();
        for(Observation a:objects){if(!enabled(a.type)||shown++>max)continue;
            long age=Math.max(0L,wallNow-a.timeMillis);
            boolean stale=a.timeMillis<=0L || age>(a.type==AIR?FRESH_AIR_MS:a.type==SEA?FRESH_SEA_MS:86400000L) || isProviderRefreshStale();
            if(stale)staleMarkers++;else if(a.type==AIR)visibleAir++;else if(a.type==SEA)visibleSea++;
            double renderLat=a.lat,renderLon=a.lon;
            Observation old=priorTracks.get(trackKey(a));
            if(old!=null){
                float fraction=reduceMotion?1f:Math.min(1f,(now-trackTransitionStart)/(float)TRANSITION_MS);
                float eased=fraction*fraction*(3f-2f*fraction);
                renderLat=old.lat+(a.lat-old.lat)*eased;
                renderLon=interpolateLongitude(old.lon,a.lon,eased);
            }
            float[] v=project(renderLat,renderLon);if(v==null)continue;
            int color=tint(a.type);
            if(stale)color=0xFF70849B;
            if(!reduceMotion && old!=null && now-trackTransitionStart<TRANSITION_MS){
                float[] previousPosition=project(old.lat,old.lon);
                if(previousPosition!=null){
                    p.setColor(Color.argb(185,Color.red(color),Color.green(color),Color.blue(color)));
                    p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.1f));
                    // Animate the trail only between two actual provider observations.
                    // No predicted aircraft or vessel position is generated.
                    float trailPhase=(now%1800L)/1800f;
                    android.graphics.Path trail=new android.graphics.Path();
                    trail.moveTo(previousPosition[0],previousPosition[1]);
                    trail.lineTo(v[0],v[1]);
                    p.setPathEffect(new android.graphics.DashPathEffect(new float[]{dp(7),dp(4)},trailPhase*dp(10)));
                    canvas.drawPath(trail,p);
                    p.setPathEffect(null);
                    p.setStyle(Paint.Style.FILL);
                }
            }p.setStyle(Paint.Style.FILL);p.setColor(Color.argb(65,Color.red(color),Color.green(color),Color.blue(color)));
            float pulse=reduceMotion?0.5f:(float)(0.5d+0.5d*Math.sin(now/430d+shown*0.63d));
            float ring=dp(a.type==AIR?3.6f:a.type==SEA?5.0f:6.0f)+dp(3.2f)*pulse;
            canvas.drawCircle(v[0],v[1],ring,p);
            p.setColor(color);canvas.drawCircle(v[0],v[1],dp(a.type==AIR?1.6f:a.type==SEA?2.3f:2.4f),p);
            if(a==selectedObservation){
                p.setColor(Color.rgb(228,244,248));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.4f));
                canvas.drawCircle(v[0],v[1],dp(9),p);p.setStyle(Paint.Style.FILL);
            }
        }
        // R11-style animated radar sweep is decorative, not a claimed real sensor track.
        if(moving && !reduceMotion){
            float angle=(float)((now%6500L)*TAU/7200d);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.1f));p.setColor(0xAA42C5F5);
            canvas.drawLine(cx,cy,cx+(float)Math.cos(angle)*radius,cy+(float)Math.sin(angle)*radius,p);
            p.setColor(0x5542C5F5);
            canvas.drawArc(cx-radius*.82f,cy-radius*.82f,cx+radius*.82f,cy+radius*.82f,
                    (float)Math.toDegrees(angle)-30f,28f,false,p);p.setStyle(Paint.Style.FILL);
        }
        if(focusOn){
            float[] target=project(focusedLat,focusedLon);
            if(target!=null){
                p.setShader(null);p.setStyle(Paint.Style.STROKE);p.setColor(DuwmUnifiedTheme.MAP_RIM);
                p.setStrokeWidth(dp(1.6f));canvas.drawCircle(target[0],target[1],dp(12),p);
                canvas.drawLine(target[0]-dp(18),target[1],target[0]-dp(7),target[1],p);
                canvas.drawLine(target[0]+dp(7),target[1],target[0]+dp(18),target[1],p);
                canvas.drawLine(target[0],target[1]-dp(18),target[0],target[1]-dp(7),p);
                canvas.drawLine(target[0],target[1]+dp(7),target[0],target[1]+dp(18),p);
            }
        }
        canvas.restore();p.setShader(null);p.setColor(rim);p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(1.2f));canvas.drawCircle(cx,cy,radius,p);
        // 1674 double-axis compass framing visualizes view direction, NOT telemetry tracks.
        p.setColor(0x884A7AB3);p.setStrokeWidth(dp(.9f));
        canvas.drawOval(cx-radius-dp(12),cy-radius*.52f,cx+radius+dp(12),cy+radius*.52f,p);
        // Transparent orbital framing is graphical orientation only; no false trajectory lines.
        p.setColor(0x77426CAF);p.setStrokeWidth(dp(.8f));
        canvas.drawOval(cx-radius-dp(21),cy-radius*.33f,cx+radius+dp(21),cy+radius*.33f,p);
        p.setStyle(Paint.Style.FILL);
        p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(117, 146, 188));p.setTextSize(dp(10));
        canvas.drawText("N",cx-dp(3),Math.max(dp(12),cy-radius-dp(8)),p);
        p.setTextSize(dp(9));p.setColor(DuwmUnifiedTheme.MAP_COAST);
        canvas.drawText("OBSERVED MARKERS "+objects.size(),dp(13),dp(19),p);
        if(showFreshness){
            p.setTextSize(dp(9));p.setColor(0xFF7ED9E9);
            canvas.drawText("FRESH AIR "+visibleAir+"  •  SEA "+visibleSea+"  •  STALE "+staleMarkers,dp(13),dp(32),p);
            if(isProviderRefreshStale()){
                p.setColor(0xFFFFB56B);
                canvas.drawText("FEED DELAYED / OFFLINE",dp(13),dp(44),p);
            }
        }
        // Motion readout counts actual completed animation frames, not fabricated network events.
        p.setTextSize(dp(10));p.setColor(DuwmUnifiedTheme.MAP_COAST);
        canvas.drawText(moving?"EARTH ROTATION • ACTIVE":"EARTH ROTATION • PAUSED",dp(13),h-dp(18),p);
        p.setColor(DuwmUnifiedTheme.MAP_RIM);
        canvas.drawText("RENDER FRAMES "+frameCounter+"  •  ROTATION "+String.format(java.util.Locale.US,"%.1f°",totalDegrees),dp(13),h-dp(5),p);
        // Geographic projection is orthographic; only received source positions produce markers.
        if((moving || focusPending) && !reduceMotion)drawAtmosphericBeacons(canvas,now);
        if(moving || focusPending)postInvalidateOnAnimation(); // avoid continuous rendering while paused
    }
    @Override public boolean onTouchEvent(MotionEvent e){scaler.onTouchEvent(e);if(scaler.isInProgress()){
            lastGestureEnd=SystemClock.uptimeMillis();rotationBlend=0f;focusPending=false;
            previousFrame=lastGestureEnd;return true;
        }
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(true);
                downX=lastX=e.getX();downY=lastY=e.getY();dragging=true;
                focusPending=false;rotationBlend=0f;previousFrame=SystemClock.uptimeMillis();return true;
            case MotionEvent.ACTION_MOVE:
                float dx=e.getX()-lastX,dy=e.getY()-lastY;
                yaw-=dx/Math.max(1f,radius)*.68d;pitch=Math.max(-1.32d,Math.min(1.32d,pitch+dy/Math.max(1f,radius)*.35d));
                lastX=e.getX();lastY=e.getY();invalidate();return true;
            case MotionEvent.ACTION_CANCEL:
                if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(false);
                dragging=false;lastGestureEnd=SystemClock.uptimeMillis();previousFrame=lastGestureEnd;
                if(moving)postInvalidateOnAnimation();return true;
            case MotionEvent.ACTION_UP:
                if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(false);
                dragging=false;lastGestureEnd=SystemClock.uptimeMillis();previousFrame=lastGestureEnd;
                if(moving)postInvalidateOnAnimation();
                if(Math.abs(e.getX()-downX)<dp(10)&&Math.abs(e.getY()-downY)<dp(10)){
                    Observation nearest=null;float best=dp(19)*dp(19);
                    for(Observation item:objects){if(!enabled(item.type))continue;float[] point=project(item.lat,item.lon);if(point==null)continue;
                        float a=point[0]-e.getX(),b=point[1]-e.getY(),dist=a*a+b*b;if(dist<best){best=dist;nearest=item;}}
                    if(nearest!=null){selectedObservation=nearest;
                        if(listener!=null)listener.onSelected(nearest);
                    }else performClick();}
                invalidate();return true;
            default:return true;
        }
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
