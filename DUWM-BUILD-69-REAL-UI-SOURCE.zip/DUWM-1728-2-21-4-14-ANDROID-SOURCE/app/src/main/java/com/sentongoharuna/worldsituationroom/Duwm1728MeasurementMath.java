package com.sentongoharuna.worldsituationroom;

/** Pure camera/sensor math. No target frame rate, inferred position or synthetic speed. */
public final class Duwm1728MeasurementMath {
    private Duwm1728MeasurementMath() {}

    /** Magnetic heading of the camera optical axis, not the top edge of the phone.
     * The input is Android's row-major 3x3 device-to-world rotation matrix.
     * Back camera looks along -device Z; front camera looks along +device Z.
     * A near-vertical optical axis has no reliable horizontal camera bearing.
     */
    public static double cameraHeading(float[] rotation, boolean front) {
        if (!rotationMatrix(rotation)) return Double.NaN;
        double sign = front ? 1.0 : -1.0;
        double east = sign * rotation[2], north = sign * rotation[5];
        if (Math.hypot(east, north) < 0.15) return Double.NaN;
        double degrees = Math.toDegrees(Math.atan2(east, north));
        return (degrees + 360.0) % 360.0;
    }

    private static boolean rotationMatrix(float[] matrix) {
        if (matrix == null || matrix.length != 9) return false;
        for (float value : matrix) if (!Float.isFinite(value)) return false;
        for (int row = 0; row < 3; row++) {
            double norm = 0;
            for (int column = 0; column < 3; column++)
                norm += (double) matrix[row * 3 + column] * matrix[row * 3 + column];
            if (Math.abs(norm - 1.0) > 0.05) return false;
            for (int other = row + 1; other < 3; other++) {
                double dot = 0;
                for (int column = 0; column < 3; column++)
                    dot += (double) matrix[row * 3 + column] * matrix[other * 3 + column];
                if (Math.abs(dot) > 0.05) return false;
            }
        }
        double determinant = matrix[0] * ((double) matrix[4] * matrix[8] - (double) matrix[5] * matrix[7])
                - matrix[1] * ((double) matrix[3] * matrix[8] - (double) matrix[5] * matrix[6])
                + matrix[2] * ((double) matrix[3] * matrix[7] - (double) matrix[4] * matrix[6]);
        return Math.abs(determinant - 1.0) <= 0.05;
    }

    public static boolean coordinates(double latitude, double longitude) {
        return Double.isFinite(latitude) && Double.isFinite(longitude)
                && latitude >= -90 && latitude <= 90 && longitude >= -180 && longitude <= 180;
    }

    /** Great-circle distance; query matching only, never used to invent movement speed. */
    public static double distanceMeters(double lat1, double lon1, double lat2, double lon2) {
        if (!coordinates(lat1, lon1) || !coordinates(lat2, lon2)) return Double.NaN;
        double latitude = Math.toRadians(lat2 - lat1), longitude = Math.toRadians(lon2 - lon1);
        double a = Math.sin(latitude / 2) * Math.sin(latitude / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(longitude / 2) * Math.sin(longitude / 2);
        return 6_371_008.8 * 2.0 * Math.atan2(Math.sqrt(Math.max(0, Math.min(1, a))),
                Math.sqrt(Math.max(0, 1 - Math.min(1, a))));
    }

    /** The count includes both endpoint frames; therefore there are frames-1 intervals. */
    public static double previewFps(int frames, long windowMs) {
        if (frames < 2 || windowMs < 500 || windowMs > 5_000) return Double.NaN;
        double fps = (frames - 1) * 1000.0 / windowMs;
        return fps > 0 && fps <= 1000 ? fps : Double.NaN;
    }
}
