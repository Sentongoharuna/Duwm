package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * DUWM 1717: on-device receipt evidence audit, not a second globe or an invented feed.
 * An audit is recorded ONLY at the user's explicit request. It compares stable
 * provider-receipt fields, excluding the changing "minutes ago" age display.
 * The 19-row heatmap shows only previously saved observations; blanks are not zeros.
 */
public final class Duwm1717ReceiptAuditActivity extends Activity {
    private static final String PREFS="duwm1717_receipt_audit_v1";
    private static final String HISTORY="explicit_captures_v1";
    private static final int MAX_CAPTURES=12;
    private static final String[] LABELS={"RECENT","REVIEW","LOCAL","NO RECEIPT","ERROR"};
    private final Duwm1683DeskCatalog.Desk[] sectors=Duwm1683DeskCatalog.ALL;
    private LinearLayout board,overview;
    private TextView explanation;
    private JSONArray history=new JSONArray();

    private int dp(float n){return Math.max(1,Math.round(getResources().getDisplayMetrics().density*n));}
    private GradientDrawable background(int color,int outline){
        GradientDrawable d=new GradientDrawable();d.setColor(color);
        d.setCornerRadius(dp(DuwmUnifiedTheme.FORMAL_CORNER_DP));
        d.setStroke(dp(1),outline);return d;
    }
    private TextView label(String value,int size,int color,boolean emphasis){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setTypeface(Typeface.create(emphasis?"sans-serif-medium":"sans-serif",Typeface.NORMAL));
        return t;
    }
    private LinearLayout.LayoutParams full(int height,int top){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,height<0?height:dp(height));
        p.topMargin=dp(top);return p;
    }
    private TextView button(String title,Runnable action){
        TextView t=label(title,11,DuwmUnifiedTheme.TEXT,true);
        t.setGravity(Gravity.CENTER);t.setSingleLine(true);
        t.setBackground(background(DuwmUnifiedTheme.APPROVED_NAVY,DuwmUnifiedTheme.BORDER));
        t.setContentDescription(title);t.setMinHeight(dp(44));
        t.setOnClickListener(v->action.run());return t;
    }
    private String utc(long time){
        if(time<=0)return "NOT CAPTURED";
        SimpleDateFormat format=new SimpleDateFormat("dd MMM yyyy HH:mm:ss 'UTC'",Locale.US);
        format.setTimeZone(TimeZone.getTimeZone("UTC"));return format.format(new Date(time));
    }
    private SharedPreferences prefs(){return getSharedPreferences(PREFS,MODE_PRIVATE);}
    private void load(){
        try{history=new JSONArray(prefs().getString(HISTORY,"[]"));}
        catch(Exception e){history=new JSONArray();}
    }
    private String stableReceived(String receipt){
        if(receipt==null)return "NOT RECEIVED";
        int split=receipt.indexOf(" · ");return split<0?receipt:receipt.substring(0,split);
    }
    /** Values are already provided by the native source-receipt diagnostics. */
    private JSONObject readSector(int index) throws Exception {
        Duwm1684DeskDiagnostics.Snapshot s=Duwm1684DeskDiagnostics.read(this,sectors[index]);
        JSONObject r=new JSONObject();
        r.put("sector",index);r.put("title",sectors[index].title);
        r.put("state",s.state);r.put("count",s.count);r.put("provider",s.provider);
        r.put("receivedUtc",stableReceived(s.received));r.put("sourceTime",s.sourceTime);
        r.put("coverage",s.coverage);r.put("error",s.error);
        return r;
    }
    private String signature(JSONObject o){
        if(o==null)return "";
        return o.optString("state")+"\u001f"+o.optString("count")+"\u001f"+
            o.optString("provider")+"\u001f"+o.optString("receivedUtc")+"\u001f"+
            o.optString("sourceTime")+"\u001f"+o.optString("coverage")+"\u001f"+
            o.optString("error");
    }
    private JSONObject capture() throws Exception {
        JSONObject entry=new JSONObject();entry.put("observedAt",System.currentTimeMillis());
        JSONArray rows=new JSONArray();for(int i=0;i<sectors.length;i++)rows.put(readSector(i));
        entry.put("rows",rows);
        JSONObject last=history.optJSONObject(history.length()-1);
        JSONArray before=last==null?null:last.optJSONArray("rows");
        int changes=0;
        for(int i=0;i<sectors.length;i++){
            JSONObject old=before==null?null:before.optJSONObject(i);
            if(old!=null&&!signature(old).equals(signature(rows.optJSONObject(i))))changes++;
        }
        entry.put("observedDifferences",changes);entry.put("baseline",before==null);
        return entry;
    }
    private void saveCapture(){
        try {
            JSONObject next=capture();
            boolean baseline=next.optBoolean("baseline");
            if(!baseline&&next.optInt("observedDifferences")==0){
                explanation.setText("RECHECK COMPLETE / NO CHANGES IN THE STABLE STORED SOURCE FIELDS. NO NEW EVENT WAS RECORDED.");
                return;
            }
            JSONArray updated=new JSONArray();
            for(int n=Math.max(0,history.length()-(MAX_CAPTURES-1));n<history.length();n++)updated.put(history.getJSONObject(n));
            updated.put(next);
            boolean ok=prefs().edit().putString(HISTORY,updated.toString()).commit();
            if(!ok){explanation.setText("SAVE FAILED / LOCAL STORAGE DID NOT CONFIRM THE NEW AUDIT.");return;}
            history=updated;render();
            explanation.setText(baseline?"BASELINE SAVED / NO NEW PROVIDER EVENT IS IMPLIED.":
                "CAPTURE SAVED / "+next.optInt("observedDifferences")+" OBSERVED SECTOR FIELD CHANGES; NOT CLAIMED AS NEW LIVE REPORTS.");
        }catch(Exception ex){explanation.setText("CAPTURE FAILED / "+ex.getClass().getSimpleName()+". NO DATA WAS FABRICATED.");}
    }
    private void clear(){
        new AlertDialog.Builder(this).setTitle("Clear local receipt audit history?")
            .setMessage("This deletes only the locally saved 1717 comparison snapshots. It does not modify actual provider receipts or the 19 desks.")
            .setNegativeButton("KEEP",(d,w)->d.dismiss())
            .setPositiveButton("CLEAR LOCAL HISTORY",(d,w)->{
                if(prefs().edit().remove(HISTORY).commit()){
                    history=new JSONArray();render();explanation.setText("LOCAL AUDIT HISTORY CLEARED / ORIGINAL SOURCE RECEIPTS UNCHANGED.");
                }else explanation.setText("COULD NOT CLEAR LOCAL HISTORY / STORAGE ERROR.");
            }).show();
    }
    private void share(){
        if(history.length()==0){explanation.setText("NO CAPTURE TO SHARE / SAVE A REAL OBSERVATION FIRST.");return;}
        JSONObject last=history.optJSONObject(history.length()-1);
        StringBuilder out=new StringBuilder("DUWM 1717 / ON-DEVICE RECEIPT AUDIT\n")
            .append("LOCAL OBSERVATION UTC: ").append(utc(last.optLong("observedAt"))).append('\n')
            .append("SAVED OBSERVATIONS: ").append(history.length()).append('\n')
            .append("DIFFERENCES SINCE PRIOR CAPTURE: ").append(last.optBoolean("baseline")?"BASELINE":last.optInt("observedDifferences")).append("\n\n");
        JSONArray rows=last.optJSONArray("rows");
        for(int i=0;i<sectors.length;i++){
            JSONObject r=rows==null?null:rows.optJSONObject(i);if(r==null)continue;
            out.append(String.format(Locale.US,"%02d %s / %s\n",i+1,r.optString("title"),r.optString("state")))
                .append("Provider: ").append(r.optString("provider"))
                .append(" | Count: ").append(r.optString("count"))
                .append(" | Receipt: ").append(r.optString("receivedUtc")).append("\n");
        }
        out.append("\nThese are user-captured local source-state readings, not independently verified current global events.");
        Intent share=new Intent(Intent.ACTION_SEND);share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT,out.toString());
        startActivity(Intent.createChooser(share,"Share receipt audit evidence"));
    }
    private void details(int index,int capture){
        JSONObject entry=history.optJSONObject(capture);
        JSONObject r=entry==null?null:entry.optJSONArray("rows").optJSONObject(index);
        if(r==null)return;
        String message="LOCAL AUDIT OBSERVED: "+utc(entry.optLong("observedAt"))+"\n\n"+
            "STATE   "+r.optString("state")+"\n"+
            "COUNT / SOURCE VALUE   "+r.optString("count")+"\n"+
            "PROVIDER   "+r.optString("provider")+"\n"+
            "LAST PROVIDER RECEIPT   "+r.optString("receivedUtc")+"\n"+
            "SOURCE OBSERVATION   "+r.optString("sourceTime")+"\n"+
            "COVERAGE   "+r.optString("coverage")+"\n"+
            "ERROR   "+r.optString("error")+"\n\n"+
            "A locally captured observation does not itself mean the provider issued a new report.";
        new AlertDialog.Builder(this).setTitle(String.format(Locale.US,"SECTOR %02d / %s",index+1,r.optString("title")))
            .setMessage(message)
            .setNeutralButton("OPEN DESK",(d,w)->startActivity(Duwm1683DeskCatalog.intent(this,sectors[index])))
            .setPositiveButton("CLOSE",(d,w)->d.dismiss()).show();
    }
    private void infoTile(String key,String value,int color){
        LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setBackground(background(DuwmUnifiedTheme.APPROVED_NAVY,DuwmUnifiedTheme.DIVIDER));
        wrap.setPadding(dp(9),dp(5),dp(4),dp(4));
        wrap.addView(label(value,20,color,true),new LinearLayout.LayoutParams(-1,dp(28)));
        wrap.addView(label(key,9,DuwmUnifiedTheme.MUTED,false),new LinearLayout.LayoutParams(-1,dp(17)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(59),1f);
        p.rightMargin=dp(5);overview.addView(wrap,p);
    }
    @Override public void onCreate(Bundle savedState){
        super.onCreate(savedState);
        DuwmPageMotion32.apply(this); DuwmPageMotion33.configure(this, "AUDIT · receipts"); // Build 32: consistent full-page navy chrome and transition

        getWindow().setStatusBarColor(DuwmUnifiedTheme.APPROVED_NAVY);
        getWindow().setNavigationBarColor(DuwmUnifiedTheme.APPROVED_NAVY);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12),dp(9),dp(12),dp(8));
        root.setBackgroundColor(DuwmUnifiedTheme.APPROVED_NAVY);
        TextView title=label("SOURCE RECEIPT AUDIT / 1717",19,DuwmUnifiedTheme.TEXT,true);
        root.addView(title,full(36,1));
        TextView sub=label("19 EXISTING DESKS  /  USER-CAPTURED OBSERVATIONS  /  NOT A LIVE FEED",10,DuwmUnifiedTheme.MUTED,false);
        sub.setMaxLines(2);root.addView(sub,full(42,0));
        explanation=label("CAPTURE A BASELINE TO COMPARE REAL, ON-DEVICE RECEIPT STATES. NO AUTOMATIC HISTORY IS INVENTED.",10,DuwmUnifiedTheme.MUTED,false);
        explanation.setMaxLines(3);root.addView(explanation,full(53,0));
        LinearLayout actions=new LinearLayout(this);
        String[] items={"CAPTURE","SHARE","CLEAR"};
        for(String item:items){
            Runnable action=item.equals("CAPTURE")?this::saveCapture:item.equals("SHARE")?this::share:this::clear;
            TextView b=button(item,action);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(46),1f);
            p.rightMargin=dp(6);actions.addView(b,p);
        }
        root.addView(actions,full(47,4));
        overview=new LinearLayout(this);overview.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(overview,full(60,8));
        ScrollView scroll=new ScrollView(this);
        board=new LinearLayout(this);board.setOrientation(LinearLayout.VERTICAL);
        board.setPadding(0,dp(7),0,dp(24));scroll.addView(board);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));
        LinearLayout navigation=new LinearLayout(this);
        TextView centre=button("SIGNAL CENTRE",()->startActivity(new Intent(this,Duwm1716SignalCenterActivity.class)));
        TextView globe=button("ORIGINAL GLOBE",()->{
            Intent i=new Intent(this,MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);finish();
        });
        LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,dp(47),1f);
        half.rightMargin=dp(5);navigation.addView(centre,half);
        navigation.addView(globe,new LinearLayout.LayoutParams(0,dp(47),1f));
        root.addView(navigation,full(49,5));
        setContentView(root);load();render();
    }
    @Override protected void onResume(){super.onResume();if(board!=null){load();render();}}
    private void render(){
        if(board==null||overview==null)return;
        board.removeAllViews();overview.removeAllViews();
        JSONObject latest=history.optJSONObject(history.length()-1);
        JSONArray rows=latest==null?null:latest.optJSONArray("rows");
        int review=0,available=0;
        for(int i=0;rows!=null&&i<rows.length();i++){
            JSONObject o=rows.optJSONObject(i);if(o==null)continue;
            int color=Duwm1715SignalLights.indicatorColor(o.optString("state"));
            if(color==DuwmUnifiedTheme.WARNING||color==DuwmUnifiedTheme.DANGER)review++;
            if(color==DuwmUnifiedTheme.LIVE)available++;
        }
        infoTile("SAVED CAPTURES",String.valueOf(history.length()),DuwmUnifiedTheme.TEXT);
        infoTile("LAST RECENT",latest==null?"--":String.valueOf(available),DuwmUnifiedTheme.LIVE);
        infoTile("NEEDS REVIEW",latest==null?"--":String.valueOf(review),DuwmUnifiedTheme.WARNING);
        if(history.length()==0){
            TextView empty=label("NO SAVED AUDITS YET\n\nTap CAPTURE to take a local baseline from the 19 existing source receipts. Unavailable sources remain unavailable; no sample activity will be added.",13,DuwmUnifiedTheme.MUTED,false);
            empty.setGravity(Gravity.TOP);empty.setPadding(dp(13),dp(30),dp(8),0);
            board.addView(empty,full(160,8));return;
        }
        TextView note=label("AUDIT HEATMAP  /  OLDEST → NEWEST  /  TAP A LIGHT FOR ITS SAVED EVIDENCE",10,DuwmUnifiedTheme.MUTED,true);
        board.addView(note,full(35,0));
        HorizontalScrollView horizontal=new HorizontalScrollView(this);horizontal.setHorizontalScrollBarEnabled(false);
        LinearLayout heat=new LinearLayout(this);heat.setOrientation(LinearLayout.VERTICAL);
        heat.setPadding(dp(4),dp(7),dp(6),dp(9));
        for(int sector=0;sector<sectors.length;sector++){
            LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);
            String name=sectors[sector].title;
            TextView nameView=label(String.format(Locale.US,"%02d %s",sector+1,name),10,DuwmUnifiedTheme.TEXT,false);
            nameView.setSingleLine(true);nameView.setEllipsize(TextUtils.TruncateAt.END);
            nameView.setContentDescription("Sector "+(sector+1)+", "+name);
            line.addView(nameView,new LinearLayout.LayoutParams(dp(151),dp(32)));
            for(int capture=0;capture<history.length();capture++){
                JSONObject c=history.optJSONObject(capture);
                JSONArray items=c==null?null:c.optJSONArray("rows");
                JSONObject item=items==null?null:items.optJSONObject(sector);
                int col=item==null?DuwmUnifiedTheme.UNAVAILABLE:
                    Duwm1715SignalLights.indicatorColor(item.optString("state"));
                final int captureIndex=capture,sectorIndex=sector;
                TextView lamp=label("●",20,col,true);lamp.setGravity(Gravity.CENTER);
                lamp.setBackground(background(DuwmUnifiedTheme.APPROVED_NAVY,DuwmUnifiedTheme.DIVIDER));
                lamp.setContentDescription("Open saved observation "+(capture+1)+" for "+name+
                    ", "+(item==null?"NO SAVED RECORD":item.optString("state")));
                lamp.setOnClickListener(v->details(sectorIndex,captureIndex));
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(35),dp(31));
                p.rightMargin=dp(5);line.addView(lamp,p);
            }
            heat.addView(line,full(34,2));
        }
        horizontal.addView(heat);
        board.addView(horizontal,full(-2,4));
        View divider=new View(this);divider.setBackgroundColor(DuwmUnifiedTheme.BORDER);
        board.addView(divider,full(1,12));
        TextView timeline=label("LOCAL OBSERVATION TIMELINE  /  NOT PROVIDER EVENT HISTORY",10,DuwmUnifiedTheme.MUTED,true);
        board.addView(timeline,full(30,4));
        for(int k=history.length()-1;k>=0;k--){
            JSONObject record=history.optJSONObject(k);if(record==null)continue;
            String value=utc(record.optLong("observedAt"))+"   /   "+
                (record.optBoolean("baseline")?"BASELINE":record.optInt("observedDifferences")+" OBSERVED CHANGES");
            TextView card=label(value,11,DuwmUnifiedTheme.TEXT,false);
            card.setPadding(dp(12),0,dp(8),0);
            card.setBackground(background(DuwmUnifiedTheme.APPROVED_NAVY,DuwmUnifiedTheme.DIVIDER));
            card.setContentDescription("Local observation "+value);
            board.addView(card,full(45,5));
        }
    }
}
