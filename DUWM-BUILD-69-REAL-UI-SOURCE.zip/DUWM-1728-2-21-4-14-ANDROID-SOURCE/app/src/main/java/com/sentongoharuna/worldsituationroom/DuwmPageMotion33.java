package com.sentongoharuna.worldsituationroom;
import android.app.Activity;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Build 34: unique page identity and semantic accent; never obscures globe or camera. */
public final class DuwmPageMotion33 {
    private DuwmPageMotion33(){}
    private static final class Profile {
        final String category,description; final int accent;
        Profile(String category,int accent,String description){this.category=category;this.accent=accent;this.description=description;}
    }
    private static Profile profile(String label){
        if(label.startsWith("AIRCRAFT"))return new Profile("FLIGHT TRACKING",0xFF56CFFF,"Aircraft information");
        if(label.startsWith("AIR RADAR"))return new Profile("AIRSPACE",0xFF4BC7E8,"Air radar observations");
        if(label.startsWith("VESSELS"))return new Profile("MARITIME",0xFF398CFA,"Marine vessel observations");
        if(label.startsWith("SATELLITES"))return new Profile("ORBITAL",0xFFE5C45C,"Satellite observations");
        if(label.startsWith("EARTHQUAKES"))return new Profile("SEISMIC",0xFFFF6C6C,"Seismic reports");
        if(label.startsWith("WEATHER"))return new Profile("ATMOSPHERE",0xFF61A9FF,"Weather reports");
        if(label.startsWith("NEWS"))return new Profile("EDITORIAL",0xFFC596EF,"News sources");
        if(label.startsWith("RADIO"))return new Profile("AUDIO",0xFF4FE0D0,"Radio stations");
        if(label.startsWith("MEDIA"))return new Profile("BROADCAST",0xFFBA8EF0,"Media broadcasts");
        if(label.startsWith("DISCOVER"))return new Profile("EXPLORATION",0xFF65D5CB,"World discovery");
        if(label.startsWith("MY WORLD"))return new Profile("PERSONAL",0xFF7FD9A7,"Saved world places");
        if(label.startsWith("GEO WATCH"))return new Profile("GEOSPATIAL",0xFFF4BC62,"Geospatial observations");
        if(label.startsWith("EVIDENCE"))return new Profile("RECORDS",0xFFE2B4F9,"Evidence records");
        if(label.startsWith("SIGNALS"))return new Profile("ALERTS",0xFFFF9A58,"Signal intelligence");
        if(label.startsWith("AUDIT"))return new Profile("COMPLIANCE",0xFF95C7E7,"Audit records");
        if(label.startsWith("DESK"))return new Profile("WORKSPACE",0xFF65C9EF,"Full-screen desk");
        if(label.startsWith("GALLERY"))return new Profile("IMAGES",0xFFCC91F2,"Media gallery");
        if(label.startsWith("VIDEO"))return new Profile("EDITOR",0xFFEF7EA8,"Video editing");
        if(label.startsWith("INTELLIGENCE"))return new Profile("ANALYSIS",0xFFAB8BF4,"World intelligence");
        if(label.startsWith("SETTINGS"))return new Profile("PREFERENCES",0xFF9CB2C5,"Application settings");
        if(label.startsWith("PLACE MAP"))return new Profile("LOCATION",0xFF58D9BD,"Place mapping");
        if(label.startsWith("EARTH"))return new Profile("GEOGRAPHY",0xFF58CDAE,"Earth exploration");
        if(label.startsWith("SOURCES"))return new Profile("PROVENANCE",0xFF8BB9F3,"Source providers");
        if(label.startsWith("COMMAND"))return new Profile("OPERATIONS",0xFF45D9F4,"Command deck");
        if(label.startsWith("MATRIX"))return new Profile("SYSTEMS",0xFFE9A65F,"Operations matrix");
        return new Profile("SYSTEM",0xFF5DB9D9,"World Situation Room page");
    }
    public static void configure(Activity activity,String label){
        if(activity==null || activity.isFinishing())return;
        final Profile style=profile(label);
        activity.getWindow().getDecorView().post(()->{
            if(activity.isFinishing() || activity.isDestroyed())return;
            View content=activity.findViewById(android.R.id.content);
            if(!(content instanceof ViewGroup))return;
            ViewGroup container=(ViewGroup)content;
            if(container.findViewWithTag("duwm-page-34")!=null)return;
            if(container.getChildCount()==0 || !(container.getChildAt(0) instanceof LinearLayout))return;
            LinearLayout root=(LinearLayout)container.getChildAt(0);
            if(root.getOrientation()!=LinearLayout.VERTICAL)return;
            TextView strip=new TextView(activity);
            strip.setTag("duwm-page-34");
            strip.setText(style.category+"  |  "+label);
            strip.setTextSize(10f);
            strip.setSingleLine(true);
            strip.setFocusable(true);
            strip.setSelected(false);
            strip.setEllipsize(android.text.TextUtils.TruncateAt.END);
            strip.setTextColor(0xFFD8F2FF);
            strip.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            strip.setGravity(android.view.Gravity.CENTER_VERTICAL);
            strip.setPadding(dp(activity,12),dp(activity,8),dp(activity,12),dp(activity,8));
            strip.setMinHeight(dp(activity,36));
            strip.setContentDescription(style.description+". "+label);
            strip.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_NONE);
            strip.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
            GradientDrawable background=new GradientDrawable();
            background.setColor(0xFF061A35);
            background.setStroke(dp(activity,1),style.accent);
            background.setCornerRadius(dp(activity,4));
            strip.setBackground(background);
            LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
            params.setMargins(dp(activity,6),dp(activity,2),dp(activity,6),dp(activity,2));
            root.addView(strip,0,params);
            // Never animate a synthetic LIVE indicator. Only the existing feed may report live data.
        });
    }
    private static int dp(Activity a,int value){return (int)(value*a.getResources().getDisplayMetrics().density+0.5f);}
}
