package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import java.io.IOException;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Plays the completed Gallery MP4 itself. No preview overlay is drawn over this video. */
public final class Duwm1728BroadcastReviewActivity extends Activity {
    private static final int NAVY=0xFF041424, PANEL=0xFF081B2B;
    private static final int WHITE=0xFFF5F7FA, SILVER=0xFFDEE5EF, GREEN=0xFF00C853, AMBER=0xFFFFB300;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService inspector=Executors.newSingleThreadExecutor();
    private Uri savedVideo;
    private VideoView video;
    private MediaPlayer mediaPlayer;
    private Duwm1728AspectFrame stage;
    private TextView status,metadata,time,playButton,shareButton,loopButton,muteButton;
    private TextView fullscreenButton,fullscreenPlayButton,fullscreenMuteButton;
    private LinearLayout page,header,controls,fullscreenBar;
    private ScrollView controlsScroll;
    private View hiddenSignalRail;
    private int signalRailVisibility=View.VISIBLE,previousSystemUi,previousVisibleBars,previousBarsBehavior;
    private boolean previousWindowFullscreen;
    private Object fullscreenBackCallback;
    private SharedPreferences reviewPrefs;
    private String preferenceKey="";
    private LinearLayout errorPanel;
    private TextView errorMessage;
    private SeekBar seek;
    private Facts facts;
    private int generation,savedPositionMs,pendingSeekPositionMs;
    private boolean ready,available,active,destroyed,dragging,ended,needsReload,seeking;
    private boolean fullscreen,loopEnabled,muted,playRequested,restoreFullscreen,recoveryVideo;
    private long lastPersistAt;
    private String failure="";

    public static Intent intent(Context context,Uri uri) {
        requireContentUri(uri);
        // This explicit, non-exported activity shares the app's existing URI access.
        // A temporary grant is only needed when sharing with another app. Requesting
        // one here makes Android reject a deleted/revoked URI before our inspector
        // can open it and present the normal unavailable/retry state.
        return new Intent(context,Duwm1728BroadcastReviewActivity.class)
                .setDataAndType(uri,"video/mp4");
    }

    public static void open(Context context,Uri uri) {
        Intent launch=intent(context,uri);
        if(!(context instanceof Activity))launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(launch);
    }

    /** The chooser receives a grantable content URI, never a file:// path or the clean master. */
    static Intent shareIntent(Uri uri) {
        requireContentUri(uri);
        Intent send=new Intent(Intent.ACTION_SEND).setType("video/mp4")
                .putExtra(Intent.EXTRA_STREAM,uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        send.setClipData(new ClipData("DUWM saved video",new String[]{"video/mp4"},new ClipData.Item(uri)));
        return send;
    }

    public static void share(Context context,Uri uri) {
        final Context app=context.getApplicationContext();
        final Handler ui=new Handler(Looper.getMainLooper());
        new Thread(()->{
            try {
                requireContentUri(uri);
                try(AssetFileDescriptor descriptor=app.getContentResolver().openAssetFileDescriptor(uri,"r")) {
                    if(descriptor==null||descriptor.getLength()==0)throw new IOException("Saved video is unavailable");
                }
                Intent send=shareIntent(uri);
                Intent chooser=Intent.createChooser(send,Duwm1728ExportRecovery.isRecoveryUri(app,uri)?"Share local recovery MP4":"Share saved MP4");
                chooser.setClipData(send.getClipData());
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                if(!(context instanceof Activity))chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ui.post(()->{
                    if(!canPresent(context))return;
                    try {context.startActivity(chooser);}
                    catch(Exception error){Toast.makeText(context,"No app can receive this video.",Toast.LENGTH_LONG).show();}
                });
            }catch(Exception error) {
                ui.post(()->{
                    if(!canPresent(context))return;
                    if(context instanceof Activity) {
                        new AlertDialog.Builder(context).setTitle("Saved video unavailable")
                                .setMessage(Duwm1728ExportRecovery.isRecoveryUri(app,uri)?
                                        "This private copy is unavailable. It may have been saved to Gallery or removed. Open Pending Broadcasts to check its save status.":
                                        "The MP4 could not be opened. It may have been moved or deleted. Reopen the saved video or export the draft again.")
                                .setPositiveButton("CLOSE",null).show();
                    }else Toast.makeText(context,"The saved MP4 is unavailable.",Toast.LENGTH_LONG).show();
                });
            }
        },"duwm-share-saved-video").start();
    }

    private static boolean canPresent(Context context) {
        return !(context instanceof Activity)||(!((Activity)context).isFinishing()&&!((Activity)context).isDestroyed());
    }

    private static void requireContentUri(Uri uri) {
        if(uri==null||!"content".equals(uri.getScheme())||uri.getAuthority()==null||uri.getAuthority().isEmpty())
            throw new IllegalArgumentException("A completed video content URI is required");
    }

    /** Keep playback history local and isolated for each saved content URI. */
    static String playbackKey(Uri uri) {
        requireContentUri(uri);
        return Duwm1728BroadcastReviewState.key(uri.toString());
    }

    /** A completed or replaced shorter video must reopen at its beginning. */
    static int clampResumePosition(long positionMs,long durationMs) {
        return Duwm1728BroadcastReviewState.resumePosition(positionMs,durationMs);
    }

    private void readPlaybackPreferences(Bundle state) {
        reviewPrefs=getSharedPreferences("duwm_saved_video_review",MODE_PRIVATE);
        try {preferenceKey=playbackKey(savedVideo);}catch(IllegalArgumentException ignored){return;}
        savedPositionMs=(int)Math.min(Integer.MAX_VALUE,Math.max(0,reviewPrefs.getLong(preferenceKey+".position_ms",0)));
        loopEnabled=reviewPrefs.getBoolean(preferenceKey+".loop",false);
        muted=reviewPrefs.getBoolean(preferenceKey+".muted",false);
        if(state!=null&&savedVideo.toString().equals(state.getString("saved_video_uri"))) {
            savedPositionMs=Math.max(0,state.getInt("position_ms",savedPositionMs));
            loopEnabled=state.getBoolean("loop_enabled",loopEnabled);
            muted=state.getBoolean("muted",muted);
            restoreFullscreen=state.getBoolean("fullscreen",false);
        }
    }

    private void persistPlayback() {
        if(reviewPrefs==null||preferenceKey.isEmpty())return;
        long resume=ended?0:position();
        savedPositionMs=facts==null?(int)Math.min(Integer.MAX_VALUE,Math.max(0,resume)):
                clampResumePosition(resume,facts.durationMs);
        reviewPrefs.edit().putLong(preferenceKey+".position_ms",savedPositionMs)
                .putBoolean(preferenceKey+".loop",loopEnabled).putBoolean(preferenceKey+".muted",muted).apply();
        lastPersistAt=android.os.SystemClock.uptimeMillis();
    }

    private static final class Facts {
        final int width,height;
        final long durationMs,bytes;
        final boolean audio;
        final String name;
        Facts(int width,int height,long durationMs,long bytes,boolean audio,String name) {
            this.width=width;this.height=height;this.durationMs=durationMs;this.bytes=bytes;this.audio=audio;this.name=name;
        }
        String summary() {
            return width+" × "+height+"  •  "+Duwm1728BroadcastTimeline.clock(durationMs)+"  •  "+(audio?"AUDIO":"SILENT");
        }
        String details() {
            return name+"\n\n"+width+" × "+height+" pixels\n"+
                    Duwm1728BroadcastTimeline.clock(durationMs)+" duration\n"+
                    (audio?"Audio track present":"No audio track")+
                    (bytes>=0?String.format(Locale.ROOT,"\n%.1f MiB",bytes/1048576d):"");
        }
    }

    private static Facts inspect(Context context,Uri uri)throws Exception {
        requireContentUri(uri);
        long bytes;
        try(AssetFileDescriptor descriptor=context.getContentResolver().openAssetFileDescriptor(uri,"r")) {
            if(descriptor==null)throw new IOException("Saved video is unavailable");
            bytes=descriptor.getLength();
            if(bytes<0)bytes=descriptor.getParcelFileDescriptor().getStatSize();
            if(bytes==0)throw new IOException("Saved video is empty");
        }
        String name="Saved MP4";
        try(Cursor cursor=context.getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)) {
            if(cursor!=null&&cursor.moveToFirst()&&!cursor.isNull(0))name=cursor.getString(0);
        }catch(Exception ignored){}
        MediaMetadataRetriever reader=new MediaMetadataRetriever();
        try {
            reader.setDataSource(context,uri);
            int width=Integer.parseInt(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
            int height=Integer.parseInt(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
            long duration=Long.parseLong(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
            String rawRotation=reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
            int rotation=rawRotation==null?0:Integer.parseInt(rawRotation);
            if(rotation%180!=0){int temporary=width;width=height;height=temporary;}
            if(width<1||height<1||duration<1)throw new IOException("No playable video track");
            boolean audio="yes".equalsIgnoreCase(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO));
            return new Facts(width,height,duration,bytes,audio,name);
        }finally{try{reader.release();}catch(Exception ignored){}}
    }

    private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
    private TextView label(String text,int size) {
        TextView view=new TextView(this);view.setText(text);view.setTextColor(WHITE);view.setTextSize(size);
        view.setPadding(dp(12),dp(6),dp(12),dp(6));return view;
    }
    private TextView button(String text,String tag,Runnable action) {
        TextView view=label(text,12);view.setTag(tag);view.setGravity(Gravity.CENTER);
        view.setMinHeight(dp(48));view.setTypeface(null,Typeface.BOLD);view.setMaxLines(2);
        view.setFocusable(true);view.setContentDescription(text);
        view.setAccessibilityDelegate(new View.AccessibilityDelegate(){
            @Override public void onInitializeAccessibilityNodeInfo(View host,AccessibilityNodeInfo info){
                super.onInitializeAccessibilityNodeInfo(host,info);info.setClassName("android.widget.Button");
            }
        });
        GradientDrawable background=new GradientDrawable();background.setColor(PANEL);
        background.setCornerRadius(dp(8));background.setStroke(Math.max(1,dp(1)),SILVER);view.setBackground(background);
        view.setOnClickListener(v->action.run());return view;
    }
    private LinearLayout.LayoutParams cell(float weight) {
        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(0,dp(48),weight);
        params.setMargins(dp(3),dp(3),dp(3),dp(3));return params;
    }

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(NAVY);
        savedVideo=getIntent().getData();recoveryVideo=Duwm1728ExportRecovery.isRecoveryUri(this,savedVideo);readPlaybackPreferences(saved);
        page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setBackgroundColor(NAVY);
        header=new LinearLayout(this);header.setTag("broadcast-review-header");header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=label(recoveryVideo?"RECOVERY COPY":"SAVED VIDEO",15);title.setTypeface(null,Typeface.BOLD);title.setMaxLines(2);
        header.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));
        fullscreenButton=button("FULL SCREEN","broadcast-review-fullscreen",()->setFullscreen(true));
        header.addView(fullscreenButton,new LinearLayout.LayoutParams(dp(104),dp(48)));
        header.addView(button("BACK","broadcast-review-back",this::finish),new LinearLayout.LayoutParams(dp(64),dp(48)));
        page.addView(header);

        // Controls occupy their own strip; no button covers a pixel of the finished video.
        fullscreenBar=new LinearLayout(this);fullscreenBar.setTag("broadcast-review-fullscreen-bar");
        fullscreenBar.addView(button("CONTROLS","broadcast-review-exit-fullscreen",()->setFullscreen(false)),cell(1.4f));
        fullscreenPlayButton=button("PLAY","broadcast-review-fullscreen-play",this::playPause);
        fullscreenBar.addView(fullscreenPlayButton,cell(1));
        fullscreenMuteButton=button("MUTE OFF","broadcast-review-fullscreen-mute",this::toggleMute);
        fullscreenBar.addView(fullscreenMuteButton,cell(1));
        fullscreenBar.setVisibility(View.GONE);page.addView(fullscreenBar);

        FrameLayout viewport=new FrameLayout(this);viewport.setBackgroundColor(NAVY);
        stage=new Duwm1728AspectFrame(this);stage.setTag("broadcast-review-stage");
        viewport.addView(stage,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));
        video=new VideoView(this);video.setTag("broadcast-review-video");
        video.setContentDescription(recoveryVideo?"Local recovery MP4 retained in DUWM, full picture":"Actual saved MP4, full picture");
        stage.addView(video,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));
        errorPanel=new LinearLayout(this);errorPanel.setOrientation(LinearLayout.VERTICAL);errorPanel.setGravity(Gravity.CENTER);
        errorPanel.setPadding(dp(24),dp(12),dp(24),dp(12));errorPanel.setBackgroundColor(NAVY);
        errorMessage=label("",14);errorMessage.setGravity(Gravity.CENTER);errorPanel.addView(errorMessage);
        errorPanel.addView(button("RETRY","broadcast-review-retry",this::load),new LinearLayout.LayoutParams(dp(140),dp(48)));
        viewport.addView(errorPanel,new FrameLayout.LayoutParams(-1,-1));errorPanel.setVisibility(View.GONE);
        page.addView(viewport,new LinearLayout.LayoutParams(-1,0,1));

        controlsScroll=new ScrollView(this);controlsScroll.setTag("broadcast-review-controls");
        controlsScroll.setFillViewport(false);controlsScroll.setBackgroundColor(NAVY);
        controls=new LinearLayout(this);controls.setOrientation(LinearLayout.VERTICAL);
        controls.setTag("broadcast-review-control-content");controlsScroll.addView(controls,new ScrollView.LayoutParams(-1,-2));
        page.addView(controlsScroll,new LinearLayout.LayoutParams(-1,-2));
        page.addOnLayoutChangeListener((v,left,top,right,bottom,oldLeft,oldTop,oldRight,oldBottom)->sizeControls());
        controls.addOnLayoutChangeListener((v,left,top,right,bottom,oldLeft,oldTop,oldRight,oldBottom)->sizeControls());

        status=label(recoveryVideo?"OPENING LOCAL RECOVERY COPY…":"OPENING SAVED VIDEO…",12);status.setTag("broadcast-review-status");status.setTextColor(SILVER);
        status.setMaxLines(2);controls.addView(status);
        metadata=label("Reading the finished MP4",11);metadata.setTag("broadcast-review-metadata");metadata.setTextColor(SILVER);
        metadata.setMaxLines(2);metadata.setOnClickListener(v->showDetails());controls.addView(metadata);
        seek=new SeekBar(this);seek.setTag("broadcast-review-seek");seek.setMax(1000);
        seek.setContentDescription("Saved video playback position");seek.setProgressTintList(android.content.res.ColorStateList.valueOf(GREEN));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(SILVER));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar bar,int progress,boolean user){if(user&&ready&&facts!=null)seekTo((long)progress*facts.durationMs/1000);}
            public void onStartTrackingTouch(SeekBar bar){dragging=true;}
            public void onStopTrackingTouch(SeekBar bar){dragging=false;updateClock();persistPlayback();}
        });controls.addView(seek,new LinearLayout.LayoutParams(-1,dp(48)));
        time=label("00:00 / 00:00",11);time.setTag("broadcast-review-time");time.setGravity(Gravity.CENTER);controls.addView(time);

        LinearLayout playback=new LinearLayout(this);
        playback.addView(button("−10s","broadcast-review-back10",()->skip(-10000)),cell(1));
        playButton=button("PLAY","broadcast-review-play",this::playPause);playback.addView(playButton,cell(1.4f));
        playback.addView(button("+10s","broadcast-review-forward10",()->skip(10000)),cell(1));
        playback.addView(button("REPLAY","broadcast-review-replay",this::replay),cell(1.2f));controls.addView(playback);
        LinearLayout preferences=new LinearLayout(this);
        loopButton=button("LOOP OFF","broadcast-review-loop",this::toggleLoop);preferences.addView(loopButton,cell(1));
        muteButton=button("MUTE OFF","broadcast-review-mute",this::toggleMute);preferences.addView(muteButton,cell(1));
        controls.addView(preferences);
        LinearLayout actions=new LinearLayout(this);
        shareButton=button("SHARE MP4","broadcast-review-share",()->{if(available)share(this,savedVideo);});shareButton.setTextColor(GREEN);
        actions.addView(shareButton,cell(2));actions.addView(button("DETAILS","broadcast-review-details",this::showDetails),cell(1));controls.addView(actions);
        // The application-owned signal shell applies all system-bar/cutout insets once.
        setContentView(page);updatePreferenceButtons();load();
    }

    /** Keep the picture visible in landscape; the controls themselves remain scrollable. */
    private void sizeControls() {
        if(fullscreen||page.getHeight()<1||controls.getHeight()<1)return;
        int availableHeight=Math.max(0,page.getHeight()-header.getMeasuredHeight());
        int pictureHeight=Math.min(dp(144),Math.max(dp(80),availableHeight/2));
        int height=Math.min(controls.getMeasuredHeight(),Math.max(dp(48),availableHeight-pictureHeight));
        LinearLayout.LayoutParams params=(LinearLayout.LayoutParams)controlsScroll.getLayoutParams();
        if(params.height!=height){params.height=height;controlsScroll.setLayoutParams(params);}
    }

    private void setFullscreen(boolean value) {
        if(value&&!ready)return;
        if(fullscreen==value){if(value)applyFullscreenWindow();return;}
        persistPlayback();fullscreen=value;
        if(value) {
            previousSystemUi=getWindow().getDecorView().getSystemUiVisibility();
            previousWindowFullscreen=(getWindow().getAttributes().flags&WindowManager.LayoutParams.FLAG_FULLSCREEN)!=0;
            if(Build.VERSION.SDK_INT>=30) {
                android.view.WindowInsets insets=getWindow().getDecorView().getRootWindowInsets();
                previousVisibleBars=android.view.WindowInsets.Type.systemBars();
                if(insets!=null){previousVisibleBars=0;
                    if(insets.isVisible(android.view.WindowInsets.Type.statusBars()))previousVisibleBars|=android.view.WindowInsets.Type.statusBars();
                    if(insets.isVisible(android.view.WindowInsets.Type.navigationBars()))previousVisibleBars|=android.view.WindowInsets.Type.navigationBars();}
                android.view.WindowInsetsController controller=getWindow().getInsetsController();
                if(controller!=null)previousBarsBehavior=controller.getSystemBarsBehavior();
            }
            header.setVisibility(View.GONE);controlsScroll.setVisibility(View.GONE);fullscreenBar.setVisibility(View.VISIBLE);
            applyFullscreenWindow();registerFullscreenBack();
            fullscreenBar.findViewWithTag("broadcast-review-exit-fullscreen").requestFocus();
        } else {
            unregisterFullscreenBack();restoreFullscreen=false;
            header.setVisibility(View.VISIBLE);controlsScroll.setVisibility(View.VISIBLE);fullscreenBar.setVisibility(View.GONE);
            if(hiddenSignalRail!=null){hiddenSignalRail.setVisibility(signalRailVisibility);hiddenSignalRail=null;}
            if(!previousWindowFullscreen)getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            getWindow().getDecorView().setSystemUiVisibility(previousSystemUi);
            if(Build.VERSION.SDK_INT>=30) {
                android.view.WindowInsetsController controller=getWindow().getInsetsController();
                if(controller!=null){controller.setSystemBarsBehavior(previousBarsBehavior);
                    if(previousVisibleBars!=0)controller.show(previousVisibleBars);
                    int hidden=android.view.WindowInsets.Type.systemBars()&~previousVisibleBars;
                    if(hidden!=0)controller.hide(hidden);}
            }
            getWindow().getDecorView().requestApplyInsets();page.post(this::sizeControls);fullscreenButton.requestFocus();
        }
    }

    private void applyFullscreenWindow() {
        if(!fullscreen||destroyed)return;
        if(hiddenSignalRail==null){View rail=getWindow().getDecorView().findViewWithTag("duwm1715-global-signal-rail");
            if(rail!=null){hiddenSignalRail=rail;signalRailVisibility=rail.getVisibility();rail.setVisibility(View.GONE);}}
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if(Build.VERSION.SDK_INT>=30) {
            android.view.WindowInsetsController controller=getWindow().getInsetsController();
            if(controller!=null){controller.setSystemBarsBehavior(android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                controller.hide(android.view.WindowInsets.Type.systemBars());}
        }else getWindow().getDecorView().setSystemUiVisibility(previousSystemUi|View.SYSTEM_UI_FLAG_FULLSCREEN|
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        // The existing signal shell remains the sole owner of display-cutout/system insets.
        getWindow().getDecorView().requestApplyInsets();
    }

    private void registerFullscreenBack() {
        if(Build.VERSION.SDK_INT>=33&&fullscreenBackCallback==null)
            fullscreenBackCallback=FullscreenBack.register(this,()->setFullscreen(false));
    }
    private void unregisterFullscreenBack() {
        if(Build.VERSION.SDK_INT>=33&&fullscreenBackCallback!=null){FullscreenBack.unregister(this,fullscreenBackCallback);fullscreenBackCallback=null;}
    }
    private static final class FullscreenBack {
        static Object register(Activity activity,Runnable exit) {
            android.window.OnBackInvokedCallback callback=exit::run;
            activity.getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,callback);
            return callback;
        }
        static void unregister(Activity activity,Object callback) {
            activity.getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback((android.window.OnBackInvokedCallback)callback);
        }
    }
    @Override public void onBackPressed(){if(fullscreen)setFullscreen(false);else super.onBackPressed();}
    @Override public void onWindowFocusChanged(boolean hasFocus){super.onWindowFocusChanged(hasFocus);if(hasFocus&&fullscreen)applyFullscreenWindow();}

    private void load() {
        if(destroyed||isFinishing())return;int request=++generation;
        ready=false;available=false;ended=false;needsReload=false;seeking=false;playRequested=false;failure="";facts=null;
        mediaPlayer=null;video.stopPlayback();errorPanel.setVisibility(View.GONE);
        setPlaying(false);
        status.setText(recoveryVideo?"OPENING LOCAL RECOVERY COPY…":"OPENING SAVED VIDEO…");status.setTextColor(SILVER);metadata.setText("Reading the finished MP4");updateActions();
        inspector.execute(()->{
            try {
                Facts inspected=inspect(getApplicationContext(),savedVideo);
                main.post(()->{
                    if(destroyed||request!=generation)return;
                    facts=inspected;available=true;metadata.setText(inspected.summary()+(recoveryVideo?"  •  LOCAL RECOVERY COPY":""));
                    stage.setRatio(inspected.width/(float)inspected.height);status.setText("PREPARING PLAYBACK…");
                    video.setOnPreparedListener(player->{
                        if(destroyed||request!=generation)return;
                        boolean continuePlaying=playRequested&&active;
                        mediaPlayer=player;ready=true;ended=false;applyPlaybackPreferences();
                        player.setOnSeekCompleteListener(done->{if(destroyed||request!=generation)return;
                            seeking=false;updateClock();if(!playRequested)persistPlayback();});
                        // Preparing a saved URI never requests playback. A live surface resize may continue existing playback.
                        video.pause();seekTo(clampResumePosition(savedPositionMs,inspected.durationMs));
                        if(!ready)return;
                        if(continuePlaying){video.start();setPlaying(true);}
                        else {setPlaying(false);status.setText(savedPositionMs>0?"RESUMED POSITION  •  PAUSED":"READY TO REVIEW  •  "+copyLabel());}
                        status.setTextColor(GREEN);
                        updateActions();updateClock();
                        if(restoreFullscreen){restoreFullscreen=false;setFullscreen(true);}
                    });
                    video.setOnCompletionListener(player->{
                        if(destroyed||request!=generation)return;
                        if(loopEnabled&&playRequested&&active){seekTo(0);if(ready){video.start();setPlaying(true);}return;}
                        ended=true;seeking=false;savedPositionMs=0;status.setText("PLAYBACK COMPLETE");status.setTextColor(GREEN);
                        setPlaying(false);persistPlayback();updateClock();
                    });
                    video.setOnErrorListener((player,what,extra)->{
                        if(destroyed||request!=generation)return true;
                        fail("This phone could not play the saved MP4. Retry, or share it with another player.",true);return true;
                    });
                    try {video.setVideoURI(savedVideo);updateActions();}
                    catch(Exception error){fail(recoveryVideo?
                            "The local recovery MP4 could not be opened. Check Pending Broadcasts, then retry.":
                            "The saved MP4 could not be opened. Retry after checking that it is still in Gallery.",false);}
                });
            }catch(Exception error) {
                main.post(()->{if(!destroyed&&request==generation)fail(recoveryVideo?
                        "This private MP4 is unavailable. It may have been saved to Gallery or removed. Open Pending Broadcasts from Details to check its save status.":
                        "This saved MP4 is unavailable. It may have been moved or deleted. You can return to the draft and export it again.",false);});
            }
        });
    }

    private void fail(String message,boolean mayShare) {
        persistPlayback();if(fullscreen)setFullscreen(false);restoreFullscreen=false;
        ready=false;available=mayShare;seeking=false;failure=message;mediaPlayer=null;video.stopPlayback();setPlaying(false);
        status.setText("VIDEO UNAVAILABLE");status.setTextColor(AMBER);metadata.setText(facts==null?"No saved-video details available":facts.summary());
        errorMessage.setText(message);errorPanel.setVisibility(View.VISIBLE);updateActions();
    }
    private void updateActions() {
        playButton.setEnabled(ready);playButton.setAlpha(ready?1f:.45f);seek.setEnabled(ready);
        fullscreenButton.setEnabled(ready);fullscreenButton.setAlpha(ready?1f:.45f);
        fullscreenPlayButton.setEnabled(ready);fullscreenPlayButton.setAlpha(ready?1f:.45f);
        loopButton.setEnabled(ready);loopButton.setAlpha(ready?1f:.45f);
        muteButton.setEnabled(ready);muteButton.setAlpha(ready?1f:.45f);
        fullscreenMuteButton.setEnabled(ready);fullscreenMuteButton.setAlpha(ready?1f:.45f);
        shareButton.setEnabled(available);shareButton.setAlpha(available?1f:.45f);
    }
    private void applyPlaybackPreferences() {
        if(mediaPlayer==null)return;
        try {mediaPlayer.setLooping(loopEnabled);float volume=muted?0f:1f;mediaPlayer.setVolume(volume,volume);}
        catch(IllegalStateException ignored){} // A stale surface will receive the same preferences on preparation.
    }
    private void toggleLoop(){loopEnabled=!loopEnabled;applyPlaybackPreferences();updatePreferenceButtons();persistPlayback();}
    private void toggleMute(){muted=!muted;applyPlaybackPreferences();updatePreferenceButtons();persistPlayback();}
    private void updatePreferenceButtons() {
        preferenceLabel(loopButton,"LOOP",loopEnabled);preferenceLabel(muteButton,"MUTE",muted);
        preferenceLabel(fullscreenMuteButton,"MUTE",muted);
    }
    private void preferenceLabel(TextView button,String name,boolean enabled) {
        button.setText(name+(enabled?" ON":" OFF"));button.setContentDescription(name.toLowerCase(Locale.ROOT)+(enabled?" on":" off"));
        button.setSelected(enabled);button.setActivated(enabled);button.setTextColor(enabled?GREEN:SILVER);
        if(Build.VERSION.SDK_INT>=30)button.setStateDescription(enabled?"On":"Off");
    }
    private long position() {
        if(ended&&facts!=null)return facts.durationMs;
        if(seeking)return pendingSeekPositionMs;
        try{return ready?Math.max(0,video.getCurrentPosition()):savedPositionMs;}catch(Exception ignored){return savedPositionMs;}
    }
    private void seekTo(long positionMs) {
        if(!ready||facts==null)return;
        long target=Math.max(0,Math.min(positionMs,Math.max(0,facts.durationMs-1)));ended=false;
        savedPositionMs=(int)Math.min(Integer.MAX_VALUE,target);pendingSeekPositionMs=savedPositionMs;seeking=true;
        try {
            if(Build.VERSION.SDK_INT>=26&&mediaPlayer!=null)mediaPlayer.seekTo(target,MediaPlayer.SEEK_CLOSEST);
            else video.seekTo(savedPositionMs);
        }catch(IllegalStateException error){seeking=false;fail("Playback stopped. Tap Retry to reopen the saved MP4.",available);return;}
        time.setText(Duwm1728BroadcastTimeline.clock(target)+" / "+Duwm1728BroadcastTimeline.clock(facts.durationMs));
    }
    private void skip(long delta){if(ready){seekTo(position()+delta);persistPlayback();}}
    private void replay(){if(!ready)return;seekTo(0);if(ready){video.start();setPlaying(true);persistPlayback();}}
    private void playPause() {
        if(!ready)return;
        try {
            if(video.isPlaying()||playRequested){video.pause();setPlaying(false);persistPlayback();}
            else {if(ended)seekTo(0);if(ready){video.start();setPlaying(true);}}
        }catch(Exception error){fail("Playback stopped. Tap Retry to reopen the saved MP4.",available);}
    }
    private void setPlaying(boolean playing) {
        playRequested=playing;String caption=playing?"PAUSE":ended?"REPLAY":"PLAY";
        playButton.setText(caption);playButton.setContentDescription(caption);
        fullscreenPlayButton.setText(caption);fullscreenPlayButton.setContentDescription(caption);
        if(playing){status.setText("PLAYING  •  "+copyLabel());status.setTextColor(GREEN);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);}
        else {getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            if(ready&&!ended){status.setText("PAUSED  •  "+copyLabel());status.setTextColor(GREEN);}}
    }
    private void updateClock() {
        if(facts==null)return;long current=Math.min(position(),facts.durationMs);
        if(!dragging)seek.setProgress((int)(current*1000/Math.max(1,facts.durationMs)));
        time.setText(Duwm1728BroadcastTimeline.clock(current)+" / "+Duwm1728BroadcastTimeline.clock(facts.durationMs));
    }
    private void showDetails() {
        String text=facts==null?(failure.isEmpty()?"The saved MP4 is still opening.":failure):facts.details();
        if(recoveryVideo)text+="\n\nLOCAL RECOVERY COPY\nThis completed MP4 is kept in DUWM. Open Pending Broadcasts to check its Gallery save status. Clearing app data or uninstalling removes private copies.";
        AlertDialog.Builder dialog=new AlertDialog.Builder(this).setTitle(recoveryVideo?"Local recovery MP4 details":"Saved MP4 details")
                .setMessage(text).setPositiveButton("CLOSE",null);
        if(recoveryVideo)dialog.setNeutralButton("PENDING BROADCASTS",(d,w)->Duwm1728ExportRecoveryActivity.open(this,Duwm1728ExportRecovery.entryId(savedVideo)));
        dialog.show();
    }
    private String copyLabel(){return recoveryVideo?"LOCAL RECOVERY COPY":"SAVED MP4";}
    private final Runnable clock=new Runnable(){public void run(){if(!active||destroyed)return;updateClock();
        if(playRequested&&android.os.SystemClock.uptimeMillis()-lastPersistAt>=3000)persistPlayback();main.postDelayed(this,200);}};
    @Override protected void onResume(){super.onResume();active=true;if(needsReload)load();main.removeCallbacks(clock);main.post(clock);
        if(fullscreen){registerFullscreenBack();main.post(this::applyFullscreenWindow);}}
    @Override protected void onPause(){
        persistPlayback();active=false;main.removeCallbacks(clock);
        if(ready)try{video.pause();}catch(Exception ignored){}setPlaying(false);super.onPause();
    }
    @Override protected void onStop(){super.onStop();generation++;unregisterFullscreenBack();mediaPlayer=null;video.stopPlayback();ready=false;seeking=false;needsReload=true;}
    @Override protected void onSaveInstanceState(Bundle state){persistPlayback();state.putInt("position_ms",savedPositionMs);
        state.putString("saved_video_uri",savedVideo==null?"":savedVideo.toString());state.putBoolean("loop_enabled",loopEnabled);
        state.putBoolean("muted",muted);state.putBoolean("fullscreen",fullscreen);super.onSaveInstanceState(state);}
    @Override protected void onDestroy(){if(fullscreen)setFullscreen(false);unregisterFullscreenBack();destroyed=true;generation++;
        main.removeCallbacksAndMessages(null);inspector.shutdownNow();video.stopPlayback();super.onDestroy();}
}
