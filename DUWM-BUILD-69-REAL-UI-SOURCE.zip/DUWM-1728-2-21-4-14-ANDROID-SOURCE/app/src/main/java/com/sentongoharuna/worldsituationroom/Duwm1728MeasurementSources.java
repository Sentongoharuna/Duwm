package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Automatic area lookup and explicitly labelled weather-model data for a real fix.
 * Network replies never become camera observations or physical weather-sensor readings. */
@SuppressWarnings("deprecation")
public final class Duwm1728MeasurementSources {
    public interface Listener { void onSourcesChanged(); }
    private final Context context;
    private Listener listener;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService weatherWorker=Executors.newSingleThreadExecutor();
    private final ExecutorService oldGeocoderWorker=Executors.newSingleThreadExecutor();
    private final AtomicBoolean oldGeocoderBusy=new AtomicBoolean();
    private volatile HttpURLConnection weatherConnection;
    private volatile boolean active,closed,enabled;
    private boolean placeLoading,weatherLoading,weatherRequested;
    private volatile int generation,placeRequest,weatherRequest;
    private long placeAttempt=-1,weatherAttempt=-1,placeReceived=-1,placeFix=-1,weatherReceived=-1;
    private long weatherRetryMs=60_000L;
    private double placeLatitude=Double.NaN,placeLongitude=Double.NaN;
    private double weatherLatitude=Double.NaN,weatherLongitude=Double.NaN;
    private String place="",weatherFailure="";
    private Weather weather;

    public Duwm1728MeasurementSources(Context context,Listener listener){
        this.context=context.getApplicationContext();this.listener=listener;
    }
    public void resume(){if(!closed)active=true;}
    public void pause(){
        active=false;generation++;placeLoading=false;weatherLoading=false;
        HttpURLConnection connection=weatherConnection;if(connection!=null)connection.disconnect();
    }
    public void close(){closed=true;pause();listener=null;main.removeCallbacksAndMessages(null);weatherWorker.shutdownNow();oldGeocoderWorker.shutdownNow();}
    public void disable(){
        enabled=false;generation++;placeLoading=false;weatherLoading=false;
        place="";placeReceived=-1;placeFix=-1;weather=null;weatherReceived=-1;
        placeLatitude=Double.NaN;placeLongitude=Double.NaN;weatherLatitude=Double.NaN;weatherLongitude=Double.NaN;
        weatherRequested=false;weatherFailure="";
        HttpURLConnection connection=weatherConnection;if(connection!=null)connection.disconnect();
    }
    private static boolean finite(double value){return !Double.isNaN(value)&&!Double.isInfinite(value);}
    private static boolean eligible(Location fix,long now){
        if(fix==null||fix.isFromMockProvider()||!fix.hasAccuracy()||!finite(fix.getAccuracy())
                ||fix.getAccuracy()<0f||fix.getAccuracy()>2000f)return false;
        long at=fix.getElapsedRealtimeNanos()/1_000_000L;
        return at>0&&now>=at&&now-at<=30_000L&&finite(fix.getLatitude())&&finite(fix.getLongitude())
                &&Math.abs(fix.getLatitude())<=90&&Math.abs(fix.getLongitude())<=180;
    }
    public void update(Location fix,boolean requested){
        if(!requested){if(enabled)disable();return;}
        enabled=true;if(closed||!active)return;
        long now=SystemClock.elapsedRealtime();if(!eligible(fix,now))return;
        final double lat=fix.getLatitude(),lon=fix.getLongitude();
        double placeMove=Duwm1728MeasurementMath.distanceMeters(lat,lon,placeLatitude,placeLongitude);
        boolean placeDue=placeReceived<0||now-placeReceived>=300_000L||(finite(placeMove)&&placeMove>=200d);
        if(!placeLoading&&placeDue&&(placeAttempt<0||now-placeAttempt>=15_000L))
            requestPlace(new Location(fix),now);
        double weatherMove=Duwm1728MeasurementMath.distanceMeters(lat,lon,weatherLatitude,weatherLongitude);
        boolean weatherDue=weatherReceived<0||now-weatherReceived>=300_000L||(finite(weatherMove)&&weatherMove>=2000d);
        if(!weatherLoading&&weatherDue&&(weatherAttempt<0||now-weatherAttempt>=weatherRetryMs))
            requestWeather(lat,lon,now);
    }
    private boolean current(int expected){return !closed&&active&&enabled&&generation==expected;}
    private void changed(){if(listener!=null&&!closed)listener.onSourcesChanged();}

    private void requestPlace(Location fix,long now){
        placeAttempt=now;
        if(!Geocoder.isPresent()||(Build.VERSION.SDK_INT<33&&oldGeocoderBusy.get()))return;
        placeLoading=true;final int gen=generation,id=++placeRequest;
        final Geocoder geocoder=new Geocoder(context,Locale.getDefault());
        main.postDelayed(()->{if(current(gen)&&id==placeRequest&&placeLoading){placeLoading=false;placeRequest++;changed();}},15_000L);
        if(Build.VERSION.SDK_INT>=33){
            try{geocoder.getFromLocation(fix.getLatitude(),fix.getLongitude(),1,new Geocoder.GeocodeListener(){
                @Override public void onGeocode(List<Address> addresses){main.post(()->finishPlace(gen,id,fix,addresses));}
                @Override public void onError(String errorMessage){main.post(()->finishPlace(gen,id,fix,null));}
            });}catch(Exception unavailable){finishPlace(gen,id,fix,null);}
        }else{
            if(!oldGeocoderBusy.compareAndSet(false,true)){placeLoading=false;return;}
            try{oldGeocoderWorker.execute(()->{
                if(!current(gen)||id!=placeRequest){oldGeocoderBusy.set(false);return;}
                List<Address> result=null;
                try{result=geocoder.getFromLocation(fix.getLatitude(),fix.getLongitude(),1);}catch(Exception unavailable){/* explicit empty result */}
                finally{oldGeocoderBusy.set(false);}
                final List<Address> accepted=result;main.post(()->finishPlace(gen,id,fix,accepted));
            });}catch(RuntimeException stopped){oldGeocoderBusy.set(false);finishPlace(gen,id,fix,null);}
        }
    }
    private void finishPlace(int gen,int id,Location fix,List<Address> addresses){
        if(!current(gen)||id!=placeRequest)return;
        placeLoading=false;
        if(addresses!=null&&!addresses.isEmpty()){
            Address address=addresses.get(0);StringBuilder text=new StringBuilder();
            String[] areas={address.getSubLocality(),address.getLocality(),address.getAdminArea(),address.getCountryName()};
            for(String area:areas){
                if(area==null)continue;String clean=area.replaceAll("[\\p{Cntrl}\\p{Cf}]"," ").replaceAll("\\s+"," ").trim();
                if(clean.isEmpty()||text.toString().toLowerCase(Locale.ROOT).contains(clean.toLowerCase(Locale.ROOT)))continue;
                if(text.length()>0)text.append(", ");text.append(clean);if(text.length()>140)break;
            }
            if(text.length()>0){String value=text.toString();place=value.substring(0,value.offsetByCodePoints(0,Math.min(160,value.codePointCount(0,value.length()))));placeReceived=SystemClock.elapsedRealtime();
                placeFix=fix.getElapsedRealtimeNanos()/1_000_000L;placeLatitude=fix.getLatitude();placeLongitude=fix.getLongitude();}
        }
        changed();
    }

    private void requestWeather(double latitude,double longitude,long now){
        weatherAttempt=now;weatherLoading=true;weatherRequested=true;weatherFailure="";
        final int gen=generation,id=++weatherRequest;
        // The weather grid does not require a full-precision coordinate query.
        final double lat=Math.rint(latitude*1000d)/1000d,lon=Math.rint(longitude*1000d)/1000d;
        try{weatherWorker.execute(()->{
            if(!current(gen)||id!=weatherRequest)return;
            Weather found=null;String failure="";long retry=60_000L;HttpURLConnection connection=null;
            try{
                String url=String.format(Locale.US,"https://api.open-meteo.com/v1/forecast?latitude=%.3f&longitude=%.3f&current=temperature_2m,wind_speed_10m,weather_code&temperature_unit=celsius&wind_speed_unit=ms&timeformat=unixtime&timezone=UTC",lat,lon);
                connection=(HttpURLConnection)new URL(url).openConnection();weatherConnection=connection;
                connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(7000);connection.setReadTimeout(7000);
                if(!current(gen)||id!=weatherRequest)return;
                int status=connection.getResponseCode();
                if(status!=200){
                    if(status==429){retry=300_000L;String after=connection.getHeaderField("Retry-After");
                        try{retry=Math.max(retry,Math.min(3_600_000L,Long.parseLong(after)*1000L));}catch(Exception ignored){}}
                    throw new IllegalStateException("Weather HTTP "+status);
                }
                try(InputStream in=connection.getInputStream();ByteArrayOutputStream bytes=new ByteArrayOutputStream()){
                    byte[] buffer=new byte[4096];int n;
                    while((n=in.read(buffer))>=0){if(bytes.size()+n>65536)throw new IllegalStateException("Weather response too large");bytes.write(buffer,0,n);}
                    found=parseWeather(bytes.toString("UTF-8"),System.currentTimeMillis());
                }
            }catch(Exception error){failure=error.getMessage()==null?"Weather unavailable":error.getMessage();}
            finally{if(connection!=null)connection.disconnect();if(weatherConnection==connection)weatherConnection=null;}
            final Weather accepted=found;final String error=failure;final long wait=retry;
            main.post(()->{
                if(!current(gen)||id!=weatherRequest)return;
                weatherLoading=false;weatherFailure=error;weatherRetryMs=wait;
                if(accepted!=null){weather=accepted;weatherReceived=SystemClock.elapsedRealtime();weatherLatitude=lat;weatherLongitude=lon;}
                changed();
            });
        });}catch(RuntimeException stopped){weatherLoading=false;weatherFailure="Weather worker unavailable";}
    }

    static final class Weather {
        final double temperatureC,windMps;final int code;final long utcMs;final String description;
        Weather(double temperature,double wind,int code,long utc,String description){
            temperatureC=temperature;windMps=wind;this.code=code;utcMs=utc;this.description=description;
        }
    }
    static Weather parseWeather(String body,long nowUtcMs)throws Exception{
        if(body==null||body.length()>65536)throw new IllegalArgumentException("Invalid weather response");
        JSONObject root=new JSONObject(body),units=root.getJSONObject("current_units"),current=root.getJSONObject("current");
        if(!"°C".equals(units.getString("temperature_2m"))||!"m/s".equals(units.getString("wind_speed_10m"))
                ||!"unixtime".equals(units.getString("time")))throw new IllegalArgumentException("Unexpected weather units");
        Object temperature=current.get("temperature_2m"),wind=current.get("wind_speed_10m"),time=current.get("time"),rawCode=current.get("weather_code");
        if(!(temperature instanceof Number)||!(wind instanceof Number)||!(time instanceof Number)||!(rawCode instanceof Number))
            throw new IllegalArgumentException("Missing numeric weather measurements");
        double t=((Number)temperature).doubleValue(),w=((Number)wind).doubleValue(),seconds=((Number)time).doubleValue(),codeValue=((Number)rawCode).doubleValue();
        if(!finite(t)||t< -100d||t>70d||!finite(w)||w<0d||w>150d||!finite(seconds)||seconds<=0d||seconds>Long.MAX_VALUE/1000d
                ||!finite(codeValue)||codeValue!=Math.rint(codeValue))throw new IllegalArgumentException("Invalid weather values");
        long utc=(long)(seconds*1000d);int code=(int)codeValue;String description=weatherDescription(code);
        if(nowUtcMs<=0||utc<nowUtcMs-3_600_000L||utc>nowUtcMs+300_000L||description.isEmpty())
            throw new IllegalArgumentException("Weather time or code unavailable");
        return new Weather(t,w,code,utc,description);
    }
    private static String weatherDescription(int code){
        switch(code){
            case 0:return "Clear";case 1:return "Mainly clear";case 2:return "Partly cloudy";case 3:return "Overcast";
            case 45:case 48:return "Fog";case 51:case 53:case 55:return "Drizzle";case 56:case 57:return "Freezing drizzle";
            case 61:return "Light rain";case 63:return "Rain";case 65:return "Heavy rain";case 66:case 67:return "Freezing rain";
            case 71:case 73:case 75:case 77:return "Snow";case 80:case 81:case 82:return "Rain showers";
            case 85:case 86:return "Snow showers";case 95:return "Thunderstorm";case 96:case 99:return "Thunderstorm with hail";
            default:return "";
        }
    }
    public void fill(Duwm1728Measurements.Input input){
        input.place=place;input.placeSource="Android Geocoder area";input.placeQueryLatitude=placeLatitude;input.placeQueryLongitude=placeLongitude;
        input.placeReceivedElapsedMs=placeReceived;input.placeFixElapsedMs=placeFix;
        input.weatherEnabled=enabled;input.weatherProvider="Open-Meteo";input.weatherSource="Open-Meteo weather model";
        input.weatherQueryLatitude=weatherLatitude;input.weatherQueryLongitude=weatherLongitude;input.weatherReceivedElapsedMs=weatherReceived;
        if(weather!=null){input.temperatureC=weather.temperatureC;input.windMps=weather.windMps;input.weatherCode=weather.code;input.weatherUtcMs=weather.utcMs;input.weatherDescription=weather.description;}
    }
    public boolean weatherRequested(){return weatherRequested;}
    public boolean weatherLoading(){return weatherLoading;}
    public String weatherFailure(){return weatherFailure;}
    public long weatherReceivedAt(){return weatherReceived;}
    public double weatherLatitude(){return weatherLatitude;}
    public double weatherLongitude(){return weatherLongitude;}
}
