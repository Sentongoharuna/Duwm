package com.sentongoharuna.worldsituationroom;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Real sampled measurements and source-time display policy. No Android or model dependency. */
public final class Duwm1728Measurements {
    public static final int MAX_SAMPLES = 2000;
    public static final long SAMPLE_VALIDITY_MS = 3_000L;
    public static final long GPS_MAX_AGE_MS = 30_000L;
    public static final long HEADING_MAX_AGE_MS = 3_000L;
    public static final long FPS_MAX_AGE_MS = 3_000L;
    public static final long PLACE_MAX_AGE_MS = 5 * 60_000L;
    public static final long WEATHER_MAX_AGE_MS = 10 * 60_000L;
    public static final long WEATHER_PROVIDER_MAX_AGE_MS = 60 * 60_000L;
    public static final double PLACE_MAX_DISTANCE_METERS = 1_000;
    public static final double WEATHER_MAX_DISTANCE_METERS = 5_000;
    private static final double POSITION_PRECISE_ACCURACY_METERS = 100;
    private static final DateTimeFormatter UTC =
            DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss 'UTC'", Locale.US).withZone(ZoneOffset.UTC);
    private static final DateTimeFormatter WEATHER_UTC =
            DateTimeFormatter.ofPattern("HH:mm 'UTC'", Locale.US).withZone(ZoneOffset.UTC);

    public enum Status { AVAILABLE, MISSING, STALE, OFF, UNRELIABLE }
    private Duwm1728Measurements() {}

    /** Adapters supply only actual reported values. NaN means absent; zero is a real value. */
    public static final class Input {
        public long nowElapsedMs = -1, sourceMs = -1, utcMs = -1;
        public boolean recording, coordinatesAllowed;
        public boolean locationEnabled, locationAvailable, locationMocked;
        public long fixElapsedMs = -1;
        public double latitude = Double.NaN, longitude = Double.NaN;
        public double horizontalAccuracyMeters = Double.NaN, altitudeMeters = Double.NaN;
        public double verticalAccuracyMeters = Double.NaN, speedMps = Double.NaN, speedAccuracyMps = Double.NaN;
        public String locationSource = "Android location", altitudeReference = "WGS84";
        public boolean headingEnabled = true;
        public double headingDegrees = Double.NaN;
        public long headingElapsedMs = -1;
        public int headingAccuracy = -1;
        public String headingSource = "Camera optical axis / magnetic";
        public boolean fpsEnabled = true;
        public double previewFps = Double.NaN;
        public long fpsElapsedMs = -1, fpsWindowMs;
        public int fpsFrames;
        public String fpsSource = "TextureView presented frames";
        public String place = "", placeSource = "";
        public double placeQueryLatitude = Double.NaN, placeQueryLongitude = Double.NaN;
        public long placeFixElapsedMs = -1, placeReceivedElapsedMs = -1;
        public boolean weatherEnabled;
        public String weatherProvider = "", weatherDescription = "", weatherSource = "";
        public double temperatureC = Double.NaN, windMps = Double.NaN;
        public double weatherQueryLatitude = Double.NaN, weatherQueryLongitude = Double.NaN;
        public int weatherCode = -1;
        public long weatherUtcMs = -1, weatherReceivedElapsedMs = -1;

        public Input() {}
        private Input(Input other) {
            nowElapsedMs=other.nowElapsedMs; sourceMs=other.sourceMs; utcMs=other.utcMs;
            recording=other.recording; coordinatesAllowed=other.coordinatesAllowed;
            locationEnabled=other.locationEnabled; locationAvailable=other.locationAvailable; locationMocked=other.locationMocked;
            fixElapsedMs=other.fixElapsedMs; latitude=other.latitude; longitude=other.longitude;
            horizontalAccuracyMeters=other.horizontalAccuracyMeters; altitudeMeters=other.altitudeMeters;
            verticalAccuracyMeters=other.verticalAccuracyMeters; speedMps=other.speedMps; speedAccuracyMps=other.speedAccuracyMps;
            locationSource=clean(other.locationSource,64); altitudeReference=clean(other.altitudeReference,16);
            headingEnabled=other.headingEnabled; headingDegrees=other.headingDegrees;
            headingElapsedMs=other.headingElapsedMs; headingAccuracy=other.headingAccuracy;
            headingSource=clean(other.headingSource,64);
            fpsEnabled=other.fpsEnabled; previewFps=other.previewFps; fpsElapsedMs=other.fpsElapsedMs;
            fpsWindowMs=other.fpsWindowMs; fpsFrames=other.fpsFrames; fpsSource=clean(other.fpsSource,64);
            place=clean(other.place,100); placeSource=clean(other.placeSource,64);
            placeQueryLatitude=other.placeQueryLatitude; placeQueryLongitude=other.placeQueryLongitude;
            placeFixElapsedMs=other.placeFixElapsedMs; placeReceivedElapsedMs=other.placeReceivedElapsedMs;
            weatherEnabled=other.weatherEnabled; weatherProvider=clean(other.weatherProvider,64);
            weatherDescription=clean(other.weatherDescription,80); weatherSource=clean(other.weatherSource,64);
            temperatureC=other.temperatureC; windMps=other.windMps;
            weatherQueryLatitude=other.weatherQueryLatitude; weatherQueryLongitude=other.weatherQueryLongitude;
            weatherCode=other.weatherCode; weatherUtcMs=other.weatherUtcMs;
            weatherReceivedElapsedMs=other.weatherReceivedElapsedMs;
        }
    }

    public static final class Metric {
        public final Status status;
        public final double value;
        public final String unit, source;
        /** -1 means the measurement's age could not be established. */
        public final long ageMs, freshForMs;
        private Metric(Status status, double value, String unit, String source, long age, long freshFor) {
            this.status=status; this.value=Double.isFinite(value)?value:Double.NaN;
            this.unit=unit; this.source=source; this.ageMs=age; this.freshForMs=Math.max(0,freshFor);
        }
    }

    public static final class TextReading {
        public final Status status;
        public final String value, source;
        public final long ageMs, freshForMs;
        private TextReading(Status status,String value,String source,long age,long freshFor) {
            this.status=status; this.value=value; this.source=source;
            this.ageMs=age; this.freshForMs=Math.max(0,freshFor);
        }
    }

    public static final class Sample {
        public final long atMs, validUntilMs, utcMs, weatherUtcMs, fpsWindowMs;
        public final boolean recording, coordinatesAllowed;
        public final int fpsFrames, weatherCode;
        public final String altitudeReference, weatherProvider, weatherSource;
        public final Metric latitude, longitude, horizontalAccuracy, altitude, verticalAccuracy;
        public final Metric speed, speedAccuracy, heading, fps, temperature, wind;
        public final TextReading place, weather, movement;
        private final Input input;

        private Sample(Input supplied) {
            input=new Input(supplied);
            Input in=input;
            atMs=in.sourceMs; validUntilMs=atMs+SAMPLE_VALIDITY_MS; utcMs=in.utcMs;
            recording=in.recording; coordinatesAllowed=in.coordinatesAllowed;
            altitudeReference=in.altitudeReference; weatherUtcMs=in.weatherUtcMs; weatherCode=in.weatherCode;
            weatherProvider=in.weatherProvider; weatherSource=in.weatherSource;
            fpsFrames=in.fpsFrames; fpsWindowMs=in.fpsWindowMs;
            long gpsAge=age(in.nowElapsedMs,in.fixElapsedMs);
            long gpsFresh=remaining(GPS_MAX_AGE_MS,gpsAge);
            Status base=locationStatus(in,gpsAge);
            Status position=base;
            if(position==Status.AVAILABLE && (!valid(in.horizontalAccuracyMeters,0,100_000)
                    || in.horizontalAccuracyMeters>POSITION_PRECISE_ACCURACY_METERS)) position=Status.UNRELIABLE;
            latitude=numeric(position,in.latitude,-90,90,"deg",in.locationSource,gpsAge,gpsFresh);
            longitude=numeric(position,in.longitude,-180,180,"deg",in.locationSource,gpsAge,gpsFresh);
            horizontalAccuracy=numeric(base,in.horizontalAccuracyMeters,0,100_000,"m",in.locationSource,gpsAge,gpsFresh);
            verticalAccuracy=numeric(base,in.verticalAccuracyMeters,0,100_000,"m",in.locationSource,gpsAge,gpsFresh);
            Status altitudeStatus=base;
            if(altitudeStatus==Status.AVAILABLE && (!("MSL".equals(in.altitudeReference)||"WGS84".equals(in.altitudeReference))
                    || (Double.isFinite(in.verticalAccuracyMeters)&&in.verticalAccuracyMeters>50)))
                altitudeStatus=Status.UNRELIABLE;
            altitude=numeric(altitudeStatus,in.altitudeMeters,-12_000,100_000,"m",in.locationSource,gpsAge,gpsFresh);
            speed=numeric(base,in.speedMps,0,1_000,"m/s",in.locationSource,gpsAge,gpsFresh);
            speedAccuracy=numeric(base,in.speedAccuracyMps,0,1_000,"m/s",in.locationSource,gpsAge,gpsFresh);
            Status motion=speed.status;
            String motionValue="";
            if(motion==Status.AVAILABLE) {
                if(speedAccuracy.status!=Status.AVAILABLE) motion=Status.UNRELIABLE;
                else if(in.speedMps-in.speedAccuracyMps>=0.5) motionValue="MOVING";
                else if(in.speedMps+in.speedAccuracyMps<=0.5) motionValue="STATIONARY";
                else motion=Status.UNRELIABLE;
            }
            movement=new TextReading(motion,motionValue,"Android location speed and accuracy",gpsAge,gpsFresh);

            long headingAge=age(in.nowElapsedMs,in.headingElapsedMs);
            Status headingStatus=timed(in.headingEnabled,Double.isFinite(in.headingDegrees),headingAge,HEADING_MAX_AGE_MS);
            if(headingStatus==Status.AVAILABLE && (in.headingAccuracy<2 || in.headingAccuracy>3
                    || in.headingDegrees<0 || in.headingDegrees>=360)) headingStatus=Status.UNRELIABLE;
            heading=metric(headingStatus,in.headingDegrees,"deg MAG",in.headingSource,headingAge,remaining(HEADING_MAX_AGE_MS,headingAge));

            long fpsAge=age(in.nowElapsedMs,in.fpsElapsedMs);
            Status fpsStatus=timed(in.fpsEnabled,Double.isFinite(in.previewFps),fpsAge,FPS_MAX_AGE_MS);
            double calculated=Duwm1728MeasurementMath.previewFps(in.fpsFrames,in.fpsWindowMs);
            if(fpsStatus==Status.AVAILABLE && (!Double.isFinite(calculated)
                    || Math.abs(calculated-in.previewFps)>Math.max(0.2,calculated*0.01)))
                fpsStatus=Status.UNRELIABLE;
            fps=metric(fpsStatus,in.previewFps,"presented fps",in.fpsSource,fpsAge,remaining(FPS_MAX_AGE_MS,fpsAge));

            long placeAge=age(in.nowElapsedMs,in.placeReceivedElapsedMs);
            long placeFixAge=age(in.nowElapsedMs,in.placeFixElapsedMs);
            Status placeStatus=dependentStatus(in,base,in.placeQueryLatitude,in.placeQueryLongitude,PLACE_MAX_DISTANCE_METERS);
            if(placeStatus!=Status.OFF&&(in.place.isEmpty()||in.placeSource.isEmpty()))placeStatus=Status.MISSING;
            if(placeStatus==Status.AVAILABLE) {
                placeStatus=timed(true,!in.place.isEmpty()&&!in.placeSource.isEmpty(),placeAge,PLACE_MAX_AGE_MS);
                if(placeStatus==Status.AVAILABLE && (placeFixAge<0||in.placeFixElapsedMs>in.placeReceivedElapsedMs))
                    placeStatus=Status.UNRELIABLE;
                if(placeStatus==Status.AVAILABLE && placeFixAge>PLACE_MAX_AGE_MS) placeStatus=Status.STALE;
            }
            long placeFresh=Math.min(gpsFresh,Math.min(remaining(PLACE_MAX_AGE_MS,placeAge),remaining(PLACE_MAX_AGE_MS,placeFixAge)));
            place=new TextReading(placeStatus,in.place,in.placeSource,placeAge,placeFresh);

            long weatherAge=age(in.nowElapsedMs,in.weatherReceivedElapsedMs);
            long providerAge=in.utcMs>0&&in.weatherUtcMs>0?in.utcMs-in.weatherUtcMs:-1;
            Status weatherStatus=!in.weatherEnabled?Status.OFF:
                    dependentStatus(in,base,in.weatherQueryLatitude,in.weatherQueryLongitude,WEATHER_MAX_DISTANCE_METERS);
            if(weatherStatus==Status.AVAILABLE) {
                weatherStatus=timed(true,!in.weatherProvider.isEmpty()&&!in.weatherSource.isEmpty(),weatherAge,WEATHER_MAX_AGE_MS);
                if(weatherStatus==Status.AVAILABLE && (in.utcMs<=0||in.weatherUtcMs<=0
                        || providerAge < -5*60_000L)) weatherStatus=Status.UNRELIABLE;
                if(weatherStatus==Status.AVAILABLE && providerAge>WEATHER_PROVIDER_MAX_AGE_MS)
                    weatherStatus=Status.STALE;
            }
            long weatherFresh=Math.min(gpsFresh,Math.min(remaining(WEATHER_MAX_AGE_MS,weatherAge),
                    remaining(WEATHER_PROVIDER_MAX_AGE_MS,Math.max(0,providerAge))));
            String weatherSource=in.weatherProvider+(in.weatherSource.isEmpty()?"":" / "+in.weatherSource);
            Status conditions=weatherStatus;
            if(conditions!=Status.OFF && (in.weatherDescription.isEmpty()||in.weatherCode<0||in.weatherCode>99))
                conditions=Status.MISSING;
            weather=new TextReading(conditions,in.weatherDescription,weatherSource,weatherAge,weatherFresh);
            temperature=numeric(weatherStatus,in.temperatureC,-100,70,"C",weatherSource,weatherAge,weatherFresh);
            wind=numeric(weatherStatus,in.windMps,0,200,"m/s",weatherSource,weatherAge,weatherFresh);
        }

        /** A detached copy is used by the atomic store; callers cannot mutate this sample. */
        Input inputCopy() { return new Input(input); }
    }

    public static Sample sample(Input input) {
        if(input==null || input.nowElapsedMs<0 || input.sourceMs<0
                || input.sourceMs>Long.MAX_VALUE-SAMPLE_VALIDITY_MS)
            throw new IllegalArgumentException("Measured source and monotonic clock required");
        return new Sample(input);
    }

    public static Sample at(List<Sample> samples,long sourceMs) {
        if(samples==null||sourceMs<0)return null;
        Sample latest=null;
        for(Sample sample:samples)
            if(sample!=null&&sample.atMs<=sourceMs&&(latest==null||sample.atMs>=latest.atMs))latest=sample;
        return latest!=null&&sourceMs<latest.validUntilMs?latest:null;
    }

    public static List<Sample> normalize(List<Sample> samples) {
        if(samples==null||samples.isEmpty())return Collections.emptyList();
        List<Sample> sorted=new ArrayList<>();
        for(Sample sample:samples)if(sample!=null)sorted.add(sample);
        sorted.sort(Comparator.comparingLong(sample->sample.atMs));
        List<Sample> result=new ArrayList<>();
        for(Sample sample:sorted) {
            if(!result.isEmpty()&&result.get(result.size()-1).atMs==sample.atMs)result.set(result.size()-1,sample);
            else result.add(sample);
        }
        if(result.size()>MAX_SAMPLES)result=new ArrayList<>(result.subList(0,MAX_SAMPLES));
        return Collections.unmodifiableList(result);
    }

    /** Stable concise labels, shared by live view, preview and encoded output. */
    public static final class Display {
        public final boolean hasSample, headingAvailable;
        public final double headingDegrees;
        public final String location,coordinates,accuracy,heading,movement,speed,altitude,fps,weather,time;
        /** Separate segments let layouts truncate conditions without hiding provider, units or time. */
        public final String weatherProviderLabel,weatherDescription,weatherNumbers,weatherTime;
        private Display(Sample sample,long sourceMs,boolean allowed) {
            hasSample=sample!=null&&sourceMs>=sample.atMs&&sourceMs<sample.validUntilMs;
            if(!hasSample) {
                location="PLACE UNAVAILABLE"; coordinates="LAT/LON UNAVAILABLE"; accuracy="ACC UNAVAILABLE";
                heading="CAM HDG UNAVAILABLE"; movement="MOVEMENT UNAVAILABLE"; speed="SPEED UNAVAILABLE";
                altitude="ALT UNAVAILABLE"; fps="PREVIEW FPS UNAVAILABLE"; weather="WX UNAVAILABLE";
                weatherProviderLabel="";weatherDescription="";weatherNumbers="";weatherTime="";
                time="UTC UNAVAILABLE"; headingDegrees=Double.NaN; headingAvailable=false; return;
            }
            long delta=sourceMs-sample.atMs;
            Status placeStatus=effective(sample.place,delta);
            location=placeStatus==Status.AVAILABLE?"PLACE "+sample.place.value:label("PLACE",placeStatus);
            Status position=effective(sample.latitude,delta);
            coordinates=position==Status.OFF?"LAT/LON OFF":
                    !(sample.coordinatesAllowed&&allowed)?"LAT/LON WITHHELD":
                    position==Status.AVAILABLE?String.format(Locale.US,"LAT/LON %.5f, %.5f",sample.latitude.value,sample.longitude.value):
                    label("LAT/LON",position);
            accuracy=effective(sample.horizontalAccuracy,delta)==Status.AVAILABLE
                    ?String.format(Locale.US,"ACC \u00b1%.0f m",sample.horizontalAccuracy.value):label("ACC",effective(sample.horizontalAccuracy,delta));
            Status headingStatus=effective(sample.heading,delta);
            headingAvailable=headingStatus==Status.AVAILABLE;
            headingDegrees=headingAvailable?sample.heading.value:Double.NaN;
            heading=headingAvailable?String.format(Locale.US,"HDG %03d\u00b0 %s MAG / AGE %s",
                    Math.round(sample.heading.value)%360,direction(sample.heading.value),ageLabel(sample.heading.ageMs,delta)):label("HDG",headingStatus);
            Status movementStatus=effective(sample.movement,delta);
            movement=movementStatus==Status.AVAILABLE?sample.movement.value:
                    movementStatus==Status.UNRELIABLE?"MOVEMENT UNCERTAIN":label("MOVEMENT",movementStatus);
            speed=effective(sample.speed,delta)==Status.AVAILABLE?
                    String.format(Locale.US,"SPEED %.1f km/h",sample.speed.value*3.6):label("SPEED",effective(sample.speed,delta));
            if(effective(sample.altitude,delta)==Status.AVAILABLE) {
                altitude=String.format(Locale.US,"ALT %.0f m %s",sample.altitude.value,sample.altitudeReference)
                        +(effective(sample.verticalAccuracy,delta)==Status.AVAILABLE?
                        String.format(Locale.US," \u00b1%.0f m",sample.verticalAccuracy.value):" / ACC UNAVAILABLE")
                        +" / AGE "+ageLabel(sample.altitude.ageMs,delta);
            } else altitude=label("ALT",effective(sample.altitude,delta));
            fps=effective(sample.fps,delta)==Status.AVAILABLE?
                    String.format(Locale.US,"PREVIEW %.1f fps",sample.fps.value):label("PREVIEW FPS",effective(sample.fps,delta));
            Status weatherStatus=effective(sample.weather,delta);
            if(weatherStatus==Status.AVAILABLE||effective(sample.temperature,delta)==Status.AVAILABLE
                    ||effective(sample.wind,delta)==Status.AVAILABLE) {
                weatherProviderLabel="WX "+(sample.weatherProvider.isEmpty()?"PROVIDER UNAVAILABLE":sample.weatherProvider);
                weatherDescription=weatherStatus==Status.AVAILABLE?sample.weather.value:"";
                StringBuilder numbers=new StringBuilder();
                if(effective(sample.temperature,delta)==Status.AVAILABLE)
                    numbers.append(String.format(Locale.US,"%.1f\u00b0C",sample.temperature.value));
                if(effective(sample.wind,delta)==Status.AVAILABLE) {
                    if(numbers.length()>0)numbers.append(" / ");
                    numbers.append(String.format(Locale.US,"WIND %.1f m/s",sample.wind.value));
                }
                weatherNumbers=numbers.toString();
                String stamp="";
                try{stamp=WEATHER_UTC.format(Instant.ofEpochMilli(sample.weatherUtcMs));}
                catch(RuntimeException ignored){}
                weatherTime=stamp;
                StringBuilder value=new StringBuilder(weatherProviderLabel);
                value.append(" / ").append(weatherDescription.isEmpty()?"CONDITIONS UNAVAILABLE":weatherDescription);
                if(!weatherNumbers.isEmpty())value.append(" / ").append(weatherNumbers);
                value.append(" / ").append(weatherTime.isEmpty()?"MODEL TIME UNAVAILABLE":weatherTime);
                value.append(" / AGE ").append(ageLabel(sample.weather.ageMs,delta));
                weather=value.toString();
            } else {
                weather=label("WX",weatherStatus);
                weatherProviderLabel="";weatherDescription="";weatherNumbers="";weatherTime="";
            }
            String stamp="UTC UNAVAILABLE";
            long utc=safeUtc(sample.utcMs,delta);
            if(utc>0)try{stamp=UTC.format(Instant.ofEpochMilli(utc));}catch(RuntimeException ignored){}
            time=stamp+" / "+(sample.recording?"REC ":"VIEW ")+duration(sourceMs);
        }
    }

    public static Display display(Sample sample,long sourceMs,boolean coordinatesAllowed) {
        return new Display(sample,sourceMs,coordinatesAllowed);
    }

    public static Status effective(Metric metric,long sourceDeltaMs) {
        if(metric==null)return Status.MISSING;
        return effective(metric.status,metric.freshForMs,sourceDeltaMs);
    }
    public static Status effective(TextReading reading,long sourceDeltaMs) {
        if(reading==null)return Status.MISSING;
        return effective(reading.status,reading.freshForMs,sourceDeltaMs);
    }
    private static Status effective(Status status,long freshFor,long delta) {
        if(delta<0)return Status.MISSING;
        return (status==Status.AVAILABLE||status==Status.UNRELIABLE)&&delta>freshFor?Status.STALE:status;
    }
    private static Status locationStatus(Input in,long age) {
        Status status=timed(in.locationEnabled,in.locationAvailable,age,GPS_MAX_AGE_MS);
        if(status==Status.AVAILABLE&&(!Duwm1728MeasurementMath.coordinates(in.latitude,in.longitude)||in.locationMocked))
            status=Status.UNRELIABLE;
        return status;
    }
    private static Status dependentStatus(Input in,Status base,double queryLat,double queryLon,double maxDistance) {
        if(base!=Status.AVAILABLE)return base;
        if(!valid(in.horizontalAccuracyMeters,0,maxDistance))return Status.UNRELIABLE;
        double distance=Duwm1728MeasurementMath.distanceMeters(in.latitude,in.longitude,queryLat,queryLon);
        if(!Double.isFinite(distance))return Status.MISSING;
        return distance>maxDistance?Status.STALE:Status.AVAILABLE;
    }
    private static Status timed(boolean enabled,boolean present,long age,long maximum) {
        if(!enabled)return Status.OFF;
        if(!present)return Status.MISSING;
        if(age<0)return Status.UNRELIABLE;
        return age>maximum?Status.STALE:Status.AVAILABLE;
    }
    private static Metric numeric(Status base,double value,double minimum,double maximum,String unit,String source,long age,long freshFor) {
        Status status=base;
        if(base!=Status.OFF) {
            if(!Double.isFinite(value))status=Status.MISSING;
            else if(value<minimum||value>maximum)status=Status.UNRELIABLE;
        }
        return metric(status,value,unit,source,age,freshFor);
    }
    private static Metric metric(Status status,double value,String unit,String source,long age,long freshFor) {
        return new Metric(status,value,unit,source,age,freshFor);
    }
    private static boolean valid(double value,double minimum,double maximum) {
        return Double.isFinite(value)&&value>=minimum&&value<=maximum;
    }
    private static long age(long now,long then) { return then>=0&&then<=now?now-then:-1; }
    private static long remaining(long maximum,long age) { return age<0?0:Math.max(0,maximum-age); }
    private static long safeUtc(long utc,long delta) {
        return utc>0&&delta>=0&&utc<=Long.MAX_VALUE-delta?utc+delta:-1;
    }
    private static String label(String name,Status status) {
        return name+" "+(status==Status.MISSING?"UNAVAILABLE":status.name());
    }
    private static String direction(double degrees) {
        return new String[]{"N","NE","E","SE","S","SW","W","NW"}[(int)Math.round(degrees/45.0)%8];
    }
    private static String ageLabel(long sampledAgeMs,long sourceDeltaMs) {
        if(sampledAgeMs<0||sourceDeltaMs<0)return "UNKNOWN";
        long total=sampledAgeMs+sourceDeltaMs;
        if(total<1000)return "<1s";
        if(total<60_000)return String.format(Locale.US,"%ds",total/1000);
        return String.format(Locale.US,"%dm",total/60_000);
    }
    private static String duration(long sourceMs) {
        long seconds=sourceMs/1000;return String.format(Locale.US,"%02d:%02d:%02d",seconds/3600,(seconds/60)%60,seconds%60);
    }
    private static String clean(String value,int maximumCodePoints) {
        if(value==null)return "";
        String normalized=value.replaceAll("[\\p{Cntrl}\\p{Cf}]+"," ").replaceAll("\\s+"," ").trim();
        int count=normalized.codePointCount(0,normalized.length());
        return count<=maximumCodePoints?normalized:normalized.substring(0,normalized.offsetByCodePoints(0,maximumCodePoints));
    }
}
