package com.sentongoharuna.worldsituationroom;

import java.util.Locale;

/** Semantic signal colours for broadcast graphics. Colours describe state,
 * never content category: red urgent, cyan/blue live data, yellow watch/caution,
 * green verified/active. Unknown/unverified states are never promoted to green. */
public final class Duwm1728SemanticSignalColors {
    public static final int RED = 0xFFD50000;
    public static final int CYAN = 0xFF00ACC1;
    public static final int BLUE = 0xFF0D47A1;
    public static final int YELLOW = 0xFFFBC02D;
    public static final int GREEN = 0xFF00C853;
    private Duwm1728SemanticSignalColors(){}

    private static String upper(String value){return value==null?"":value.trim().toUpperCase(Locale.ROOT);}
    public static boolean urgent(String value){String s=upper(value);return s.contains("BREAKING")||s.contains("URGENT")||s.contains("ALERT")||s.contains("EMERGENCY");}
    public static boolean watch(String value){String s=upper(value);return s.contains("WATCH")||s.contains("CAUTION")||s.contains("STALE")||s.contains("UNAVAILABLE")||s.contains("UNRELIABLE")||s.contains("UNCERTAIN")||s.contains("NO FIX")||s.endsWith(" OFF")||s.startsWith("OFF " )||s.equals("OFF");}
    public static boolean verified(String value){String s=upper(value);return !s.contains("UNVERIFIED")&&(s.contains("VERIFIED")||s.contains("ACTIVE")||s.contains("CONFIRMED"));}
    public static int state(String value,int liveColor){if(urgent(value))return RED;if(watch(value))return YELLOW;if(verified(value))return GREEN;return liveColor;}
    public static int provenance(String value){String s=upper(value);if(urgent(s))return RED;if(verified(s))return GREEN;return YELLOW;}
    public static int telemetry(String value){return state(value,CYAN);}
    public static int weather(String value){return state(value,BLUE);}
    public static int live(String value){return state(value,CYAN);}
}
