package com.sentongoharuna.worldsituationroom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Timestamped model output. Times are source-video offsets, never export-relative times. */
public final class Duwm1728SceneTimeline {
    public static final String SOURCE = "on-device-image-description";
    public static final long MAX_VALIDITY_MS = 12_000L;
    public static final int MAX_ENTRIES = 2048;
    public static final int MAX_TITLE_CODE_POINTS = 64;
    public static final int MAX_DESCRIPTION_CODE_POINTS = 384;

    private Duwm1728SceneTimeline() {}

    public static final class Entry {
        public final long atMs;
        public final long validUntilMs;
        public final String title;
        public final String description;
        public final String source;

        public Entry(long atMs, long validUntilMs, String title,
                     String description, String source) {
            if (atMs < 0 || validUntilMs <= atMs
                    || validUntilMs - atMs > MAX_VALIDITY_MS) {
                throw new IllegalArgumentException("Invalid scene observation interval");
            }
            this.title = clean(title, MAX_TITLE_CODE_POINTS);
            this.description = clean(description, MAX_DESCRIPTION_CODE_POINTS);
            this.source = clean(source, 64);
            if (this.title.isEmpty() || this.description.isEmpty()
                    || !SOURCE.equals(this.source)) {
                throw new IllegalArgumentException("Actual on-device description required");
            }
            this.atMs = atMs;
            this.validUntilMs = validUntilMs;
        }
    }

    /**
     * The newest observation owns its interval. Once it expires, an older overlapping
     * observation must not reappear. An unsorted input cannot expose a future caption.
     */
    public static Entry at(List<Entry> entries, long sourceMs) {
        if (entries == null || sourceMs < 0) return null;
        Entry latest = null;
        for (Entry entry : entries) {
            if (entry != null && entry.atMs <= sourceMs
                    && (latest == null || entry.atMs >= latest.atMs)) latest = entry;
        }
        return latest != null && sourceMs < latest.validUntilMs ? latest : null;
    }

    /** Shortens only the supplied model text; it never infers a scene from sensor labels. */
    public static Entry fromDescription(long atMs, String actualModelText) {
        String description = clean(actualModelText, MAX_DESCRIPTION_CODE_POINTS);
        if (description.isEmpty()) throw new IllegalArgumentException("Empty model description");
        if (atMs < 0 || atMs > Long.MAX_VALUE - MAX_VALIDITY_MS)
            throw new IllegalArgumentException("Invalid scene source time");
        String title = Duwm1728EventHeadline.fromDescription(description);
        if (title.isEmpty()) throw new IllegalArgumentException("No grounded event headline");
        return new Entry(atMs, atMs + MAX_VALIDITY_MS, title, description, SOURCE);
    }

    /** Immutable, stable ordering with duplicate times replaced by the last supplied entry. */
    public static List<Entry> normalize(List<Entry> entries) {
        if (entries == null || entries.isEmpty()) return Collections.emptyList();
        List<Entry> ordered = new ArrayList<>();
        for (Entry entry : entries) if (entry != null) ordered.add(entry);
        ordered.sort(Comparator.comparingLong(entry -> entry.atMs));
        List<Entry> unique = new ArrayList<>();
        for (Entry entry : ordered) {
            if (!unique.isEmpty() && unique.get(unique.size() - 1).atMs == entry.atMs)
                unique.set(unique.size() - 1, entry);
            else unique.add(entry);
        }
        // Preserve the start of a recording. A very long recording becomes uncaptioned
        // after this bound; old descriptions are never stretched to cover missing data.
        if (unique.size() > MAX_ENTRIES)
            unique = new ArrayList<>(unique.subList(0, MAX_ENTRIES));
        return Collections.unmodifiableList(unique);
    }

    /** Plain display text. Preserve joined emoji/marks while removing invisible bidi controls. */
    public static String clean(String text, int maxCodePoints) {
        if (text == null || maxCodePoints <= 0) return "";
        StringBuilder result = new StringBuilder();
        boolean pendingSpace = false;
        for (int index = 0; index < text.length();) {
            int cp = text.codePointAt(index);
            index += Character.charCount(cp);
            if (Character.isWhitespace(cp) || Character.isSpaceChar(cp)) {
                pendingSpace = result.length() > 0;
                continue;
            }
            int type = Character.getType(cp);
            boolean joinedFormat = cp == 0x200C || cp == 0x200D
                    || (cp >= 0xE0020 && cp <= 0xE007F);
            if (Character.isISOControl(cp) || (type == Character.FORMAT && !joinedFormat)
                    || type == Character.SURROGATE) continue;
            if (pendingSpace) { result.append(' '); pendingSpace = false; }
            result.appendCodePoint(cp);
        }
        String normalized = result.toString();
        if (normalized.codePointCount(0, normalized.length()) <= maxCodePoints) return normalized;
        // Reserve one code point for the ellipsis and cut only at a complete cluster.
        // These are the same cluster rules as CaptionPages, kept here to leave this
        // policy independent of Android and the broadcast painter for host testing.
        int cut = 0, at = 0, used = 0;
        List<Integer> ends = new ArrayList<>();
        while (at < normalized.length()) {
            int end = clusterEnd(normalized, at);
            int length = normalized.codePointCount(at, end);
            if (used + length > maxCodePoints - 1) break;
            used += length;
            cut = end;
            ends.add(end);
            at = end;
        }
        int space = normalized.lastIndexOf(' ', Math.max(0, cut - 1));
        while (space > 0 && (!ends.contains(space) || !ends.contains(space + 1)))
            space = normalized.lastIndexOf(' ', space - 1);
        if (space > 0 && cut - space <= 18) cut = space;
        while (cut > 0 && normalized.charAt(cut - 1) == ' '
                && (cut == 1 || ends.contains(cut - 1))) cut--;
        return cut == 0 ? "" : normalized.substring(0, cut) + '\u2026';
    }

    private static int clusterEnd(String text, int at) {
        int cp = text.codePointAt(at);
        at += Character.charCount(cp);
        if (regional(cp) && at < text.length() && regional(text.codePointAt(at)))
            at += Character.charCount(text.codePointAt(at));
        while (at < text.length()) {
            int next = text.codePointAt(at);
            int type = Character.getType(next);
            if (type == Character.NON_SPACING_MARK || type == Character.COMBINING_SPACING_MARK
                    || type == Character.ENCLOSING_MARK || next == 0x200C
                    || (next >= 0xFE00 && next <= 0xFE0F)
                    || (next >= 0xE0100 && next <= 0xE01EF)
                    || (next >= 0x1F3FB && next <= 0x1F3FF)
                    || (next >= 0xE0020 && next <= 0xE007F)) {
                at += Character.charCount(next);
            } else if (hangulJoin(cp, next)) {
                cp = next;
                at += Character.charCount(next);
            } else if (next == 0x200D) {
                at += Character.charCount(next);
                if (at < text.length()) {
                    cp = text.codePointAt(at);
                    at += Character.charCount(cp);
                }
            } else break;
        }
        return at;
    }

    private static boolean regional(int cp) { return cp >= 0x1F1E6 && cp <= 0x1F1FF; }

    private static int hangul(int cp) {
        if ((cp >= 0x1100 && cp <= 0x115F) || (cp >= 0xA960 && cp <= 0xA97C)) return 1;
        if ((cp >= 0x1160 && cp <= 0x11A7) || (cp >= 0xD7B0 && cp <= 0xD7C6)) return 2;
        if ((cp >= 0x11A8 && cp <= 0x11FF) || (cp >= 0xD7CB && cp <= 0xD7FB)) return 3;
        if (cp >= 0xAC00 && cp <= 0xD7A3) return (cp - 0xAC00) % 28 == 0 ? 4 : 5;
        return 0;
    }

    private static boolean hangulJoin(int before, int after) {
        int a = hangul(before), b = hangul(after);
        return a == 1 && (b == 1 || b == 2 || b == 4 || b == 5)
                || (a == 2 || a == 4) && (b == 2 || b == 3)
                || (a == 3 || a == 5) && b == 3;
    }
}
