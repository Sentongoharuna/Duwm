package com.sentongoharuna.worldsituationroom;

import android.app.Instrumentation;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.provider.MediaStore;
import java.io.File;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

/** /21/4 native gate for the hands-free finishing policy. */
final class DuwmAutomaticFinishChecks {
    private final DuwmNativeEvidence proof; private int checks;
    DuwmAutomaticFinishChecks(DuwmNativeEvidence proof){this.proof=proof;}
    int count(){return checks;}
    private void check(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
    void run(Instrumentation runner,File folder)throws Exception {
        proof.phase("automatic_finish.policy");
        check("SAVED_VERIFIED_WITH_CAPTIONS".equals(Duwm1728AutomaticFinish.savedState(true)),"Verified captioned state is explicit");
        check("SAVED_VERIFIED_WITHOUT_CAPTIONS".equals(Duwm1728AutomaticFinish.savedState(false)),"Verified no-caption state is explicit");
        check("LOCAL_COPY_READY".equals(Duwm1728AutomaticFinish.recoveryState(true,false)),"Local finished copy is a ready recovery state");
        check("GALLERY_UNCONFIRMED_LOCAL_COPY".equals(Duwm1728AutomaticFinish.recoveryState(true,true)),"Unconfirmed Gallery result preserves local finished copy state");
        check("FAILED".equals(Duwm1728AutomaticFinish.recoveryState(false,false)),"No durable output remains a failure");
        boolean invalid=false;try{Duwm1728AutomaticFinish.verifyReadable(runner.getTargetContext(),Uri.parse("file:///tmp/not-content.mp4"));}catch(java.io.IOException expected){invalid=true;}
        check(invalid,"File URI cannot be called a verified finished video");

        proof.phase("automatic_finish.actual_content_uri");
        ContentResolver resolver=runner.getTargetContext().getContentResolver();
        ContentValues values=new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME,"DUWM_AUTOFINISH_TEST_"+System.currentTimeMillis()+".mp4");
        values.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");
        if(android.os.Build.VERSION.SDK_INT>=29)values.put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/DUWM-Test");
        Uri uri=resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,values);
        check(uri!=null,"Owned MediaStore test URI created");
        try{
            try(OutputStream out=resolver.openOutputStream(uri,"w")){check(out!=null,"Owned MediaStore test URI writable");out.write("DUWM-21-4-FINISH-CHECK".getBytes(StandardCharsets.UTF_8));}
            long length=Duwm1728AutomaticFinish.verifyReadable(runner.getTargetContext(),uri);
            check(length==-1||length>0,"Actual content URI can be reopened after finalization");
        }finally{if(uri!=null)resolver.delete(uri,null,null);}

        JSONObject result=new JSONObject().put("schema",1).put("status","PASS")
            .put("hands_free_finish_policy_verified",true)
            .put("actual_content_uri_reopen_verified",true)
            .put("verified_success_states",true)
            .put("local_copy_fallback_state",true)
            .put("physical_camera_verified",false).put("model_inference_verified",false)
            .put("checks",checks);
        java.nio.file.Files.write(new File(folder,"AUTOMATIC-FINISH-NATIVE.json").toPath(),(result.toString(2)+"\n").getBytes(StandardCharsets.UTF_8));
    }
}
