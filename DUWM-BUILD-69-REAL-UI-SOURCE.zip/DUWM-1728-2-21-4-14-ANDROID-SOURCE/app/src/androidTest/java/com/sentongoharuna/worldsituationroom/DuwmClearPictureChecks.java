package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.SystemClock;
import android.util.AtomicFile;
import android.widget.CheckBox;
import android.widget.EditText;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import org.json.JSONArray;
import org.json.JSONObject;

/** Synthetic changing scenes and measurements through actual Android editor,
 * clear-picture painter and codec. No physical sensor/model/network claim. */
final class DuwmClearPictureChecks {
    private static final long UTC=1794052800000L;
    private final DuwmNativeEvidence proof;private int checks;
    DuwmClearPictureChecks(DuwmNativeEvidence proof){this.proof=proof;}
    int count(){return checks;}
    private void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    private interface Action{void run()throws Exception;}
    private interface Condition{boolean ready()throws Exception;}
    private static void rethrow(Throwable error)throws Exception{if(error instanceof InvocationTargetException){rethrow(((InvocationTargetException)error).getTargetException());return;}if(error instanceof Error)throw (Error)error;if(error instanceof Exception)throw (Exception)error;if(error!=null)throw new RuntimeException(error);}
    private void ui(Instrumentation runner,Action action)throws Exception{AtomicReference<Throwable> error=new AtomicReference<>();runner.runOnMainSync(()->{try{action.run();}catch(Throwable failure){error.set(failure);}});rethrow(error.get());}
    private static Object field(Object object,String name)throws Exception{java.lang.reflect.Field f=object.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(object);}
    private static void set(Object object,String name,Object value)throws Exception{java.lang.reflect.Field f=object.getClass().getDeclaredField(name);f.setAccessible(true);f.set(object,value);}
    private static Object call(Object object,String name)throws Exception{java.lang.reflect.Method m=object.getClass().getDeclaredMethod(name);m.setAccessible(true);try{return m.invoke(object);}catch(InvocationTargetException error){rethrow(error);return null;}}
    private void await(Instrumentation runner,Condition condition,String label)throws Exception{AtomicBoolean ready=new AtomicBoolean();long until=SystemClock.elapsedRealtime()+15000;do{ui(runner,()->ready.set(condition.ready()));if(ready.get())break;Thread.sleep(75);}while(SystemClock.elapsedRealtime()<until);check(ready.get(),label);}
    private static void copy(InputStream in,OutputStream out)throws Exception{byte[] bytes=new byte[65536];int n;while((n=in.read(bytes))!=-1)out.write(bytes,0,n);}
    private static Duwm1728Measurements.Input input(long at,boolean second){
        Duwm1728Measurements.Input in=new Duwm1728Measurements.Input();in.sourceMs=at;in.nowElapsedMs=100000+at;in.utcMs=UTC+at;in.recording=true;in.coordinatesAllowed=true;
        in.locationEnabled=true;in.locationAvailable=true;in.fixElapsedMs=in.nowElapsedMs-29500;in.latitude=second?.33667:.33567;in.longitude=second?32.56990:32.56890;in.horizontalAccuracyMeters=second?12:4;in.altitudeMeters=second?1430:1235;in.verticalAccuracyMeters=8;in.speedMps=second?.05:4;in.speedAccuracyMps=.1;in.locationSource="synthetic-native-fixture";
        in.headingDegrees=second?250:78;in.headingAccuracy=3;in.headingElapsedMs=in.nowElapsedMs-2500;in.previewFps=second?27:18;in.fpsFrames=second?28:19;in.fpsWindowMs=1000;in.fpsElapsedMs=in.nowElapsedMs-2500;
        in.place=second?"RIVER ACCESS FIXTURE":"NORTH CAMPUS FIXTURE";in.placeSource="synthetic-native-fixture";in.placeQueryLatitude=in.latitude;in.placeQueryLongitude=in.longitude;in.placeFixElapsedMs=in.fixElapsedMs;in.placeReceivedElapsedMs=in.nowElapsedMs-1000;
        in.weatherEnabled=true;in.weatherProvider="Open-Meteo";in.weatherSource="synthetic-native-fixture";in.weatherDescription=second?"Heavy rain":"Clear";in.weatherCode=second?65:0;in.temperatureC=second?17.5:26.5;in.windMps=second?12.3:3.2;in.weatherUtcMs=UTC-300000;in.weatherReceivedElapsedMs=in.nowElapsedMs-1000;in.weatherQueryLatitude=in.latitude;in.weatherQueryLongitude=in.longitude;return in;
    }
    private static List<Duwm1728Measurements.Sample> samples(){return Arrays.asList(Duwm1728Measurements.sample(input(400,false)),Duwm1728Measurements.sample(input(1100,true)));}
    private Duwm1728OverlayRenderer.Spec editor(Instrumentation runner,Uri source)throws Exception{
        Context target=runner.getTargetContext();String key=Duwm1728CaptureTelemetry.storageKey(source);
        check(Duwm1728MeasurementStore.save(target,source,samples(),true),"Persist synthetic measurements for clear-picture test");
        check(Duwm1728SceneStore.save(target,source,Arrays.asList(
            new Duwm1728SceneTimeline.Entry(400,950,"FIRST SYNTHETIC COURTYARD SCENE","A supplied synthetic scene observation for the first source interval.",Duwm1728SceneTimeline.SOURCE),
            new Duwm1728SceneTimeline.Entry(1100,1700,"SECOND SYNTHETIC RIVERSIDE SCENE","A different supplied observation for the second source interval.",Duwm1728SceneTimeline.SOURCE))),"Persist separate synthetic scene observations");
        Activity editor=runner.startActivitySync(new Intent(target,Duwm1728VideoEditorActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(Duwm1728VideoEditorActivity.EXTRA_VIDEO_URI,source.toString()));
        try{
            await(runner,()->(Boolean)field(editor,"prepared"),"Clear-picture editor player is ready");
            AtomicReference<Duwm1728OverlayRenderer.Spec> selected=new AtomicReference<>();
            ui(runner,()->{
                CheckBox clear=(CheckBox)field(editor,"clearPictureToggle");
                check(clear.isChecked()&&((Duwm1728OverlayRenderer.Spec)call(editor,"spec")).clearPicture,"Fresh recorded capture enables clear picture automatically");
                ((EditText)field(editor,"from")).setText("0.250");((EditText)field(editor,"to")).setText("1.900");
                set(editor,"selectedRatio","ORIGINAL");set(editor,"frameMode",Duwm1728FramePlan.FIT);
                set(editor,"aiCaptions",Arrays.asList(new Duwm1728BroadcastLayout.Cue(400,950,"First synthetic caption stays above the measured information."),new Duwm1728BroadcastLayout.Cue(1100,1700,"Second synthetic caption changes without moving the picture.")));
                call(editor,"showLayoutPicker");android.app.AlertDialog picker=(android.app.AlertDialog)field(editor,"layoutPicker");
                android.view.View legacy=picker.getWindow().getDecorView().findViewWithTag("broadcast-editor-layout-COMPACT");
                check(legacy!=null&&legacy.performClick()&&!clear.isChecked(),"Existing compact layout remains selectable and disables clear picture");
                check((Boolean)call(editor,"saveDraft"),"Save explicit legacy selection");call(editor,"loadDraft");call(editor,"refresh");check(!clear.isChecked(),"Explicit clear-picture-off choice survives draft restore");
                call(editor,"showLayoutPicker");picker=(android.app.AlertDialog)field(editor,"layoutPicker");
                android.view.View choice=picker.getWindow().getDecorView().findViewWithTag("broadcast-editor-layout-CLEAR_PICTURE");
                check(choice!=null&&choice.performClick()&&clear.isChecked(),"Real layout picker restores clear picture");
                call(editor,"refresh");check((Boolean)call(editor,"saveDraft"),"Save clear-picture selection and original-time captions");
            });
            SharedPreferences drafts=target.getSharedPreferences("duwm_production_drafts",Context.MODE_PRIVATE);String saved=drafts.getString(key,"");
            JSONObject older=new JSONObject(saved);older.remove("clear_picture");check(drafts.edit().putString(key,older.toString()).commit(),"Seed fixture-owned predecessor draft");
            ui(runner,()->{call(editor,"loadDraft");check(!((CheckBox)field(editor,"clearPictureToggle")).isChecked(),"Older authored draft retains its previous composition");});
            String malformed=new JSONObject(saved).put("clear_picture","true").toString();check(drafts.edit().putString(key,malformed).commit(),"Seed fixture-owned malformed clear flag");
            ui(runner,()->{call(editor,"loadDraft");check((Boolean)field(editor,"draftRestoreBlocked")&&!(Boolean)call(editor,"saveDraft"),"Malformed clear flag cannot partially restore or overwrite draft");});
            check(malformed.equals(drafts.getString(key,"")),"Malformed original draft bytes remain intact");check(drafts.edit().putString(key,saved).commit(),"Restore valid fixture draft");
            ui(runner,()->{call(editor,"loadDraft");call(editor,"refresh");selected.set((Duwm1728OverlayRenderer.Spec)call(editor,"spec"));});
            Duwm1728OverlayRenderer.Spec result=selected.get();
            check(result.clearPicture&&result.fromMs==250&&result.toMs==1900&&result.automaticSceneTitles&&result.includeSourceSummary,"Editor restores clear picture with exact clip and source choices");
            check(result.renderedCaptions.size()==2&&result.renderedCaptions.get(0).startMs==150&&result.renderedCaptions.get(1).startMs==850,"Caption source times are trimmed exactly once");
            return result;
        }finally{ui(runner,editor::finish);await(runner,editor::isDestroyed,"Clear-picture editor closes before encoding");}
    }
    private String geometry(Duwm1728BroadcastLayout.Geometry g){return g.headerTop+"|"+g.headerBottom+"|"+g.telemetryTop+"|"+g.tickerTop+"|"+g.captionTop+"|"+g.captionBottom+"|"+g.clearSafeLeft+"|"+g.clearSafeTop+"|"+g.clearSafeWidth+"|"+g.clearSafeHeight;}
    private int painted(Bitmap image){int total=0;for(int y=0;y<image.getHeight();y++)for(int x=0;x<image.getWidth();x++)if(Color.alpha(image.getPixel(x,y))>0)total++;return total;}
    private void timing(Duwm1728OverlayRenderer.Spec spec){
        proof.phase("clear_picture.stable_geometry_and_timing");String fixed=null;
        for(long elapsed:new long[]{0,100,149,150,350,699,700,750,849,850,1050,1449,1450,1550}){
            Duwm1728BroadcastLayout.Report report=Duwm1728OverlayRenderer.reportAt(spec,elapsed);check(report.clearPicture,"Clear mode reaches shared renderer");
            Bitmap image=Bitmap.createBitmap(960,540,Bitmap.Config.ARGB_8888);
            try{
                Duwm1728BroadcastLayout.Geometry g=Duwm1728BroadcastLayout.draw(new Duwm1728BroadcastCanvas(new Canvas(image)),960,540,report,elapsed);
                check(g.clearPicture&&!g.headlineVisible&&!g.tickerVisible,"Clear mode removes duplicate lower headline and ticker");
                if(fixed==null)fixed=geometry(g);else check(fixed.equals(geometry(g)),"Changing title, captions and stale fields never move reserved geometry");
                check(g.clearSafeAreaFraction>.60f&&g.clearSafeWidth>0&&g.clearSafeHeight>0,"Large central picture area is explicitly reserved");
                boolean transparent=true;for(int y=(int)Math.ceil(g.clearSafeTop);y<(int)(g.clearSafeTop+g.clearSafeHeight);y++)for(int x=(int)Math.ceil(g.clearSafeLeft);x<(int)(g.clearSafeLeft+g.clearSafeWidth);x++)if(Color.alpha(image.getPixel(x,y))!=0)transparent=false;
                check(transparent,"Every reserved central pixel remains transparent in actual Android painter");
                long source=spec.fromMs+elapsed;String expected=source>=400&&source<950?"FIRST":source>=1100&&source<1700?"SECOND":"";
                check(expected.isEmpty()?report.sceneTitle.isEmpty():report.sceneTitle.startsWith(expected),"Clear title selects actual original-time observation without future or expired content");
            }finally{image.recycle();}
        }
        Duwm1728BroadcastLayout.Report first=Duwm1728OverlayRenderer.reportAt(spec,350),second=Duwm1728OverlayRenderer.reportAt(spec,1050),stale=Duwm1728OverlayRenderer.reportAt(spec,750);
        check(first.measuredCoordinates.contains("0.33567")&&second.measuredCoordinates.contains("0.33667")&&stale.measuredCoordinates.contains("STALE"),"Clear layout retains changing and stale measurement states");
        Bitmap clear=expected(spec,350);boolean prior=spec.clearPicture;spec.clearPicture=false;Bitmap legacy=expected(spec,350);spec.clearPicture=prior;
        try{check(painted(clear)<painted(legacy)*.85,"Clear mode paints substantially less of the same source picture");}finally{clear.recycle();legacy.recycle();}
    }
    private static boolean ink(int pixel){int r=Color.red(pixel),g=Color.green(pixel),b=Color.blue(pixel);return r>150&&g>150&&b>150||g>100&&b>110&&r<g*.8;}
    private double dice(Bitmap actual,Bitmap expected,Rect box){int a=0,e=0,both=0;for(int y=box.top;y<box.bottom;y++)for(int x=box.left;x<box.right;x++){boolean aa=ink(actual.getPixel(x,y)),ee=ink(expected.getPixel(x,y));if(aa)a++;if(ee)e++;if(aa&&ee)both++;}check(a>20&&e>20,"Decoded and expected measured regions contain actual glyph pixels");return 2d*both/(a+e);}
    private Bitmap expected(Duwm1728OverlayRenderer.Spec spec,long at){Bitmap image=Bitmap.createBitmap(960,540,Bitmap.Config.ARGB_8888);Duwm1728OverlayRenderer.drawOverlay(new Canvas(image),spec,at,null);return image;}
    private JSONArray decoded(File output,File source,Duwm1728OverlayRenderer.Spec spec,File folder)throws Exception{
        MediaMetadataRetriever video=new MediaMetadataRetriever(),original=new MediaMetadataRetriever();try{
            video.setDataSource(output.getAbsolutePath());original.setDataSource(source.getAbsolutePath());
            check("960".equals(video.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH))&&"540".equals(video.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)),"Clear export retains complete original dimensions");
            check("yes".equalsIgnoreCase(video.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)),"Clear export includes original source audio");
            check(Math.abs(Long.parseLong(video.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION))-(spec.toMs-spec.fromMs))<180,"Clear export retains selected duration");
            JSONArray results=new JSONArray();for(long at:new long[]{100,350,750,1050,1550}){
                Bitmap actual=video.getFrameAtTime(at*1000,MediaMetadataRetriever.OPTION_CLOSEST),sourceFrame=original.getFrameAtTime((spec.fromMs+at)*1000,MediaMetadataRetriever.OPTION_CLOSEST),wanted=expected(spec,at),wrong=expected(spec,at==350?1050:350);
                check(actual!=null&&sourceFrame!=null,"Clear MP4 and original frames decode");
                try{
                    Duwm1728BroadcastLayout.Geometry g=Duwm1728BroadcastLayout.draw(new Duwm1728BroadcastCanvas(new Canvas(wanted)),960,540,Duwm1728OverlayRenderer.reportAt(spec,at),at);
                    Rect band=new Rect((int)(g.x+20*g.unit),(int)(g.telemetryTop+3*g.unit),(int)(g.x+g.width-20*g.unit),(int)(g.tickerTop-3*g.unit));
                    Rect title=new Rect((int)(g.x+18*g.unit),(int)(g.headerTop+2*g.unit),(int)(g.x+Math.min(g.width*.62f,680*g.unit)-20*g.unit),(int)(g.headerBottom-12*g.unit));
                    double correct=dice(actual,wanted,band),incorrect=dice(actual,wrong,band),titleScore=dice(actual,wanted,title),wrongTitle=dice(actual,wrong,title);
                    check(correct>.70&&correct>incorrect+.035,"Decoded measurements match the correct clear source moment: "+at);
                    check(titleScore>.70&&titleScore>wrongTitle+.035,"Decoded compact title follows scene changes and neutral gaps: "+at);
                    ArrayList<Integer> differences=new ArrayList<>();long total=0;for(int gy=1;gy<=9;gy++)for(int gx=1;gx<=17;gx++){
                        int x=Math.round(g.clearSafeLeft+g.clearSafeWidth*gx/18f),y=Math.round(g.clearSafeTop+g.clearSafeHeight*gy/10f);
                        int a=actual.getPixel(x,y),b=sourceFrame.getPixel(x,y),difference=(Math.abs(Color.red(a)-Color.red(b))+Math.abs(Color.green(a)-Color.green(b))+Math.abs(Color.blue(a)-Color.blue(b)))/3;
                        differences.add(difference);total+=difference;
                    }
                    Collections.sort(differences);double mean=total/(double)differences.size();int p95=differences.get((int)Math.floor((differences.size()-1)*.95));
                    check(mean<24&&p95<50,"Decoded clear center preserves source-picture grid within codec tolerance");
                    if(at==350||at==1050)try(OutputStream out=new FileOutputStream(new File(folder,at==350?"ANDROID-CLEAR-FIRST.png":"ANDROID-CLEAR-SECOND.png"))){check(actual.compress(Bitmap.CompressFormat.PNG,100,out),"Write actual decoded clear frame");}
                    results.put(new JSONObject().put("elapsed_ms",at).put("source_ms",spec.fromMs+at).put("measurement_glyph_dice",correct).put("wrong_measurement_glyph_dice",incorrect).put("title_glyph_dice",titleScore).put("wrong_title_glyph_dice",wrongTitle).put("center_grid_mean_rgb_error",mean).put("center_grid_p95_rgb_error",p95).put("center_grid_points",differences.size()).put("clear_safe_area_fraction",g.clearSafeAreaFraction));
                }finally{actual.recycle();sourceFrame.recycle();wanted.recycle();wrong.recycle();}
            }return results;
        }finally{video.release();original.release();}
    }
    void run(Instrumentation runner,File folder)throws Exception{
        Context target=runner.getTargetContext();File source=new File(target.getCacheDir(),"clear-picture-fixture-"+UUID.randomUUID()+".mp4");Uri uri=Uri.fromFile(source);String key=Duwm1728CaptureTelemetry.storageKey(uri);File temporary=null;JSONObject result=null;Throwable failure=null;
        try{
            proof.phase("clear_picture.fixture");try(InputStream in=runner.getContext().getAssets().open("framing_fixture.mp4");OutputStream out=new FileOutputStream(source)){copy(in,out);}String before=DuwmNativeEvidence.hash(source);
            Duwm1728OverlayRenderer.Spec spec=editor(runner,uri);timing(spec);Duwm1728OverlayRenderer.prepare(spec);
            proof.phase("clear_picture.encode");temporary=Duwm1728OverlayRenderer.export(target,uri,spec);File output=new File(folder,"ANDROID-CLEAR-PICTURE.mp4");try(InputStream in=new FileInputStream(temporary);OutputStream out=new FileOutputStream(output)){copy(in,out);}
            JSONObject audioProof=DuwmNativeAacChecks.verify(source,output,spec.fromMs*1000,spec.toMs*1000,this::check);
            proof.phase("clear_picture.decode");JSONArray frames=decoded(output,source,spec,folder);check(before.equals(DuwmNativeEvidence.hash(source)),"Original source remains byte-for-byte unchanged");
            result=new JSONObject().put("schema",1).put("status","PASS").put("fixture_source","synthetic-native-fixture").put("physical_sensor_verified",false).put("physical_camera_verified",false).put("model_inference_verified",false).put("provider_network_verified",false)
                .put("encoded_picture_verified",true).put("stable_geometry_verified",true).put("center_picture_preserved",true).put("source_time_trim_verified",true).put("source_audio_preserved",true).put("source_aac_packets",audioProof.getInt("packet_count")).put("audio_packet_proof",audioProof).put("source_file_unchanged",true).put("source_file_sha256",before)
                .put("clear_default_and_saved_choices_verified",true).put("older_draft_composition_preserved",true).put("malformed_draft_rejected",true).put("from_ms",spec.fromMs).put("to_ms",spec.toMs).put("decoded_samples",frames)
                .put("comparison","Synthetic source-timed scenes and measurements through actual Android editor/painter/codec; exact transparent center and codec-tolerant decoded source-grid comparisons. No physical sensor, network provider or model execution.");
        }catch(Throwable error){failure=error;rethrow(error);}
        finally{try{check(target.getSharedPreferences("duwm_production_drafts",Context.MODE_PRIVATE).edit().remove(key).commit(),"Remove only clear fixture draft");new AtomicFile(new File(new File(target.getFilesDir(),"measurement-timelines"),key.substring("capture_".length())+".json")).delete();new AtomicFile(new File(new File(target.getFilesDir(),"scene-timelines"),key+".json")).delete();check(!Duwm1728MeasurementStore.hasCapture(target,uri)&&!Duwm1728SceneStore.hasCapture(target,uri),"Remove only clear fixture sidecars");if(temporary!=null&&temporary.exists())check(temporary.delete(),"Remove clear fixture temporary output");if(source.exists())check(source.delete(),"Remove clear fixture source copy");}catch(Throwable cleanup){if(failure!=null)failure.addSuppressed(cleanup);else rethrow(cleanup);}}
        check(result!=null,"Clear-picture checks and fixture cleanup complete");result.put("checks",checks).put("fixture_cleanup_complete",true);try(OutputStream out=new FileOutputStream(new File(folder,"CLEAR-PICTURE-NATIVE.json"))){out.write((result.toString(2)+"\n").getBytes(StandardCharsets.UTF_8));}proof.phase("clear_picture.complete");
    }
}
