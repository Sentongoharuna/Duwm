package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.Instrumentation;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import java.io.File;
import java.io.FileOutputStream;
import java.util.HashSet;
import java.util.Set;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/** Native Android Canvas regression, no network, mocked news or test fixtures in the app UI.
 * This runner is compiled into a separate androidTest APK, not the user APK.
 */
public final class DuwmSignalInstrumentation extends Instrumentation {
    private int checks;
    private Bundle arguments;
    @Override public void onCreate(Bundle args){arguments=args==null?new Bundle():new Bundle(args);super.onCreate(args);start();}
    private void require(boolean ok,String text){checks++;if(!ok)throw new AssertionError(text);}
    private Bitmap frame(Duwm1728StatusLampView lamp,long time,boolean motion){
        Bitmap image=Bitmap.createBitmap(80,80,Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(image);c.drawColor(DuwmUnifiedTheme.APPROVED_NAVY);
        lamp.layout(0,0,80,80);lamp.drawLampFrame(c,time,motion);return image;
    }
    private void pixels(File folder) throws Exception {
        if(!folder.isDirectory()&&!folder.mkdirs())throw new IllegalStateException("Cannot save proof");
        for(Duwm1724SignalFlow.Stage state:Duwm1724SignalFlow.Stage.values()){
            Duwm1728StatusLampView lamp=new Duwm1728StatusLampView(getTargetContext());
            lamp.setStage(state,0,true);
            Bitmap fixed=frame(lamp,0L,false);
            int expected=state==Duwm1724SignalFlow.Stage.LOCAL?DuwmUnifiedTheme.APPROVED_NAVY:state.color;
            require(fixed.getPixel(40,40)==expected,"Exact solid colour / hollow local: "+state);
            require(fixed.getPixel(0,0)==DuwmUnifiedTheme.APPROVED_NAVY,"Exact navy background");
            try(FileOutputStream stream=new FileOutputStream(new File(folder,state.name()+"-STATIC.png"))){
                require(fixed.compress(Bitmap.CompressFormat.PNG,100,stream),"PNG proof write");
            }
            fixed.recycle();Set<Integer> distinct=new HashSet<>();
            for(int i=0;i<24;i++){
                Bitmap moving=frame(lamp,Duwm1728SignalMotion.periodMs(state)*i/24L,true);
                int pixel=moving.getPixel(40,40);distinct.add(pixel);
                require((pixel>>>24)==255,"Opaque animated core");moving.recycle();
            }
            require(state.rank>=0?distinct.size()>1:distinct.size()==1,"Real frame colour changes / neutral stays still: "+state);
            Duwm1728StatusLampView legend=new Duwm1728StatusLampView(getTargetContext());
            legend.showStaticColor(state.color,"STATIC HISTORY, NOT LIVE");
            Bitmap before=frame(legend,0,false),after=frame(legend,900,false);
            require(before.sameAs(after),"History does not pretend live activity");before.recycle();after.recycle();
        }
        // Same state, different sector keys -> an independent animation phase.
        Duwm1728StatusLampView one=new Duwm1728StatusLampView(getTargetContext());
        Duwm1728StatusLampView two=new Duwm1728StatusLampView(getTargetContext());
        one.setStage(Duwm1724SignalFlow.Stage.HEALTHY,0,true);
        two.setStage(Duwm1724SignalFlow.Stage.HEALTHY,1,true);
        Bitmap a=frame(one,700,true),b=frame(two,700,true);
        require(a.getPixel(40,40)!=b.getPixel(40,40),"No synchronized blinking across all providers");a.recycle();b.recycle();
    }
    private void cameraHealthDock(File folder) throws Exception {
        // Test-only fixtures: demonstrate native layout, never inserted into the production UI.
        android.view.ContextThemeWrapper context=new android.view.ContextThemeWrapper(
                getTargetContext(),R.style.Theme_WorldSituationRoom);
        android.util.TypedValue value=new android.util.TypedValue();
        require(context.getTheme().resolveAttribute(android.R.attr.alertDialogTheme,value,true),"Native dialog theme resolves");
        android.view.ContextThemeWrapper dialog=new android.view.ContextThemeWrapper(context,value.resourceId);
        require(dialog.getTheme().resolveAttribute(android.R.attr.colorBackground,value,true),"Dialog background resolves");
        require(value.data==DuwmUnifiedTheme.APPROVED_NAVY,"Dialog has exact approved navy background");
        Duwm1728CaptureHealth.Input input=new Duwm1728CaptureHealth.Input();
        input.now=1_000_000L;input.cameraPermission=true;input.cameraOpen=true;
        input.frameAt=input.now;input.adequateResolution=true;input.recording=true;
        input.microphoneEnabled=true;input.microphonePermission=true;input.microphoneError="TEST FIXTURE: input failed";
        input.compassPresent=true;input.compassAt=input.now-30_000L;
        input.weatherRequested=true;input.weatherLoading=true;
        Duwm1728CaptureHealthView dock=new Duwm1728CaptureHealthView(context);dock.update(input);
        int width=Math.round(360*context.getResources().getDisplayMetrics().density);
        int height=Math.round(58*context.getResources().getDisplayMetrics().density);
        dock.measure(android.view.View.MeasureSpec.makeMeasureSpec(width,android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(height,android.view.View.MeasureSpec.EXACTLY));
        dock.layout(0,0,width,height);
        require(dock.getChildCount()==6,"Six native camera-health cells");
        Duwm1724SignalFlow.Stage[] expected={Duwm1724SignalFlow.Stage.HEALTHY,
                Duwm1724SignalFlow.Stage.OUTAGE,Duwm1724SignalFlow.Stage.LOCAL,
                Duwm1724SignalFlow.Stage.AGED,Duwm1724SignalFlow.Stage.CONNECTING,
                Duwm1724SignalFlow.Stage.UNKNOWN};
        int end=0;
        for(int k=0;k<6;k++){
            android.view.View cell=dock.getChildAt(k);
            require(cell.getWidth()>0&&cell.getLeft()>=end&&cell.getRight()<=width,"Nonoverlapping native cell "+k);
            end=cell.getRight();
            require(cell.isClickable()&&cell.isFocusable(),"Tap/accessibility target "+k);
            android.view.ViewGroup top=(android.view.ViewGroup)((android.view.ViewGroup)cell).getChildAt(0);
            Duwm1728StatusLampView lamp=(Duwm1728StatusLampView)top.getChildAt(0);
            int left=lamp.getLeft(),topY=lamp.getTop(),right=lamp.getRight(),bottom=lamp.getBottom();
            Bitmap exact=frame(lamp,0L,false);
            require(exact.getPixel(40,40)==(expected[k]==Duwm1724SignalFlow.Stage.LOCAL?
                    DuwmUnifiedTheme.APPROVED_NAVY:expected[k].color),"Camera source maps to real pixel colour "+k);
            exact.recycle();lamp.layout(left,topY,right,bottom);
        }
        Bitmap image=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
        dock.draw(new Canvas(image));
        require(image.getPixel(0,0)==DuwmUnifiedTheme.APPROVED_NAVY,"Camera dock uses the exact navy surface");
        try(FileOutputStream out=new FileOutputStream(new File(folder,"CAMERA-HEALTH-TEST-FIXTURES.png"))){
            require(image.compress(Bitmap.CompressFormat.PNG,100,out),"Write fixture-only Android dock proof");
        }
        image.recycle();
    }
    private void landscapeSafeInsets(){
        if(android.os.Build.VERSION.SDK_INT<30)return;
        android.view.View content=new android.view.View(getTargetContext());
        android.view.WindowInsets occupied=new android.view.WindowInsets.Builder()
            .setInsets(android.view.WindowInsets.Type.systemBars(),android.graphics.Insets.of(14,24,32,48))
            .setInsets(android.view.WindowInsets.Type.displayCutout(),android.graphics.Insets.of(22,0,0,0))
            .setInsets(android.view.WindowInsets.Type.ime(),android.graphics.Insets.of(0,0,0,200)).build();
        Duwm1715SignalLights.applySafeInsets(content,occupied);
        require(content.getPaddingLeft()==22&&content.getPaddingTop()==24&&content.getPaddingRight()==32&&content.getPaddingBottom()==200,
            "Landscape side cutout, system bars and keyboard use the largest safe inset on each edge");
        Duwm1715SignalLights.applySafeInsets(content,occupied);
        require(content.getPaddingLeft()==22&&content.getPaddingTop()==24&&content.getPaddingRight()==32&&content.getPaddingBottom()==200,
            "Repeated insets do not accumulate padding");
        android.view.WindowInsets clear=new android.view.WindowInsets.Builder().setInsets(
            android.view.WindowInsets.Type.systemBars()|android.view.WindowInsets.Type.displayCutout()|android.view.WindowInsets.Type.ime(),
            android.graphics.Insets.NONE).build();
        Duwm1715SignalLights.applySafeInsets(content,clear);
        require(content.getPaddingLeft()==0&&content.getPaddingTop()==0&&content.getPaddingRight()==0&&content.getPaddingBottom()==0,
            "Cleared insets remove obsolete rotation margins");
    }
    private interface MainCheck {void run()throws Exception;}
    private void onMain(MainCheck check)throws Exception {
        AtomicReference<Throwable> failure=new AtomicReference<>();
        runOnMainSync(()->{try{check.run();}catch(Throwable error){failure.set(error);}});
        Throwable error=failure.get();if(error instanceof Error)throw (Error)error;if(error instanceof Exception)throw (Exception)error;
    }
    @Override public void onStart(){
        Bundle result=new Bundle();String selected=arguments.getString("stage","full");
        boolean full="full".equals(selected);List<String> failures=new ArrayList<>();StringBuilder details=new StringBuilder();int total=0;
        try {
            if(!full&&!Arrays.asList(DuwmNativeEvidence.STAGES).contains(selected))throw new IllegalArgumentException("Unknown stage "+selected+"; use full or "+Arrays.toString(DuwmNativeEvidence.STAGES));
            DuwmNativeEvidence proof=new DuwmNativeEvidence(this,arguments.getString("run_id"));
            for(String stage:full?DuwmNativeEvidence.STAGES:new String[]{selected}) {
                Throwable failure=null;int before=checks;DuwmBroadcastChecks broadcast=new DuwmBroadcastChecks(proof);
                proof.start(stage);
                try {
                    switch(stage){
                        case "signals":
                            proof.phase("signal.canvas");onMain(()->pixels(proof.directory()));
                            proof.phase("camera.health");onMain(()->cameraHealthDock(proof.directory()));
                            proof.phase("landscape.insets");onMain(this::landscapeSafeInsets);break;
                        case "graphics":onMain(()->broadcast.pixels(proof.directory()));break;
                        case "exports4":broadcast.exports4(this,proof.directory());break;
                        case "framing":broadcast.framingExports(this,proof.directory());break;
                        case "inset1":broadcast.portraitInsetExport(this,proof.directory());break;
                        case "review":broadcast.savedVideoReview(this,proof.directory());break;
                        case "editor_controls":broadcast.editorControls(this,proof.directory());break;
                        case "review_controls":broadcast.reviewControls(this,proof.directory());break;
                        case "recovery":broadcast.exportRecovery(this,proof.directory());break;
                        case "composition":broadcast.compositions(this,proof.directory());break;
                        case "caption_editing":broadcast.captionEditing(this,proof.directory());break;
                        case "caption_files":broadcast.captionFiles(this,proof.directory());break;
                        case "automatic_production":broadcast.automaticProduction(this,proof.directory());break;
                        case "automatic_report":broadcast.automaticReport(this,proof.directory());break;
                        case "automatic_ready":broadcast.automaticReady(this,proof.directory());break;
                        case "automatic_fit":broadcast.automaticFit(this,proof.directory());break;
                        case "scene_timeline":broadcast.sceneTimeline(this,proof.directory());break;
                        case "measured_telemetry":broadcast.measuredTelemetry(this,proof.directory());break;
                        case "clear_picture":broadcast.clearPicture(this,proof.directory());break;
                        case "automatic_finish":broadcast.automaticFinish(this,proof.directory());break;
                        default:throw new AssertionError("Stage not dispatched: "+stage);
                    }
                }catch(Throwable error){failure=error;failures.add(stage);details.append(stage).append(": ").append(android.util.Log.getStackTraceString(error)).append('\n');}
                int stageChecks=checks-before+broadcast.count();total+=stageChecks;proof.finish(stageChecks,failure);
            }
            if(failures.isEmpty()) {
                String marker=full?"DUWM_NATIVE_BROADCAST_PASS":"DUWM_NATIVE_STAGE_PASS stage="+selected;
                result.putString("stream",marker+" run_id="+proof.runId()+" checks="+total+"; all selected stages passed; not a physical-camera test\n");
                if(full){File folder=new File(getTargetContext().getFilesDir(),"broadcast-native-proof");if(!folder.isDirectory()&&!folder.mkdirs())throw new java.io.IOException("Cannot write complete result");
                    try(FileOutputStream out=new FileOutputStream(new File(folder,"RESULT.txt"))){out.write(("PASS all "+DuwmNativeEvidence.STAGES.length+" stages, "+total+" checks, run_id="+proof.runId()+". Require matching per-stage RESULT.json manifests; not physical camera verification.\n").getBytes("UTF-8"));}}
                finish(Activity.RESULT_OK,result);
            }else{
                result.putString("stream",(full?"DUWM_NATIVE_BROADCAST_FAIL":"DUWM_NATIVE_STAGE_FAIL stage="+selected)+" run_id="+proof.runId()+" failed_stages="+failures+"\n"+details);
                finish(Activity.RESULT_CANCELED,result);
            }
        }catch(Throwable error){result.putString("stream","DUWM_NATIVE_BROADCAST_FAIL stage="+selected+"\n"+android.util.Log.getStackTraceString(error));finish(Activity.RESULT_CANCELED,result);}
    }
}
