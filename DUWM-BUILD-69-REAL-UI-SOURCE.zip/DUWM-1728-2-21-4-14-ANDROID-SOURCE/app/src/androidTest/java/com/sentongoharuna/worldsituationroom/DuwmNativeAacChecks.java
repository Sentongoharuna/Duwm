package com.sentongoharuna.worldsituationroom;

import android.media.MediaExtractor;
import android.media.MediaFormat;
import java.io.File;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.json.JSONObject;

/** Reads real native output and verifies packet bytes, sample timing and A/V sync. */
final class DuwmNativeAacChecks {
    private static final class Audio {
        final List<DuwmAacPacketContract.Packet> packets=new ArrayList<>();
        int sampleRate,channels;byte[] config;
    }
    private static Audio audio(File file,long fromUs,long toUs,DuwmAacPacketContract.Check check)throws Exception {
        MediaExtractor reader=new MediaExtractor();try {
            reader.setDataSource(file.getAbsolutePath());Audio result=new Audio();int selected=-1;
            for(int index=0;index<reader.getTrackCount();index++) {
                MediaFormat format=reader.getTrackFormat(index);
                if(!"audio/mp4a-latm".equals(format.getString(MediaFormat.KEY_MIME)))continue;
                check.that(selected<0,"Fixture has exactly one AAC track");selected=index;
                result.sampleRate=format.getInteger(MediaFormat.KEY_SAMPLE_RATE);result.channels=format.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                check.that(result.sampleRate==48000&&result.channels==1,"Retained fixture AAC is 48 kHz mono");
                ByteBuffer config=format.getByteBuffer("csd-0");check.that(config!=null&&config.remaining()>0,"AAC decoder configuration exists");
                ByteBuffer copy=config.duplicate();result.config=new byte[copy.remaining()];copy.get(result.config);
                check.that(result.config.length>=2&&(result.config[0]&0xf8)==0x10&&(result.config[1]&4)==0,"Fixture AudioSpecificConfig declares AAC-LC with 1024-sample frames");
            }
            check.that(selected>=0,"Actual AAC track exists");reader.selectTrack(selected);reader.seekTo(fromUs,MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            ByteBuffer buffer=ByteBuffer.allocate(2*1024*1024);
            while(reader.getSampleTime()>=0&&reader.getSampleTime()<toUs) {
                long at=reader.getSampleTime();buffer.clear();int size=reader.readSampleData(buffer,0);if(size<0)break;
                if(at>=fromUs){byte[] bytes=new byte[size];buffer.position(0);buffer.get(bytes);result.packets.add(new DuwmAacPacketContract.Packet(at,bytes));}
                if(!reader.advance())break;
            }
            return result;
        }finally{reader.release();}
    }
    private static List<Long> video(File file,long fromUs,long toUs,DuwmAacPacketContract.Check check)throws Exception {
        MediaExtractor reader=new MediaExtractor();try {
            reader.setDataSource(file.getAbsolutePath());int selected=-1;
            for(int index=0;index<reader.getTrackCount();index++) {
                String mime=reader.getTrackFormat(index).getString(MediaFormat.KEY_MIME);
                if(mime!=null&&mime.startsWith("video/")){check.that(selected<0,"Fixture has exactly one video track");selected=index;}
            }
            check.that(selected>=0,"Actual video track exists for A/V sync");reader.selectTrack(selected);reader.seekTo(0,MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            List<Long> result=new ArrayList<>();
            // Source packets may arrive in decode order (B frames). Inspect every PTS
            // and compare sorted presentation times, rather than stopping at toUs.
            while(reader.getSampleTime()>=0){long at=reader.getSampleTime();if(at>=fromUs&&at<toUs)result.add(at);if(!reader.advance())break;}
            Collections.sort(result);return result;
        }finally{reader.release();}
    }
    static JSONObject verify(File source,File output,long fromUs,long toUs,DuwmAacPacketContract.Check check)throws Exception {
        Audio before=audio(source,fromUs,toUs,check),after=audio(output,0,Long.MAX_VALUE,check);
        check.that(before.sampleRate==after.sampleRate&&before.channels==after.channels&&Arrays.equals(before.config,after.config),"Original AAC sample rate, channels and decoder configuration are identical");
        List<Long> sourceVideo=video(source,fromUs,toUs,check),outputVideo=video(output,0,Long.MAX_VALUE,check);
        DuwmAacPacketContract.Clocks clocks=DuwmAacPacketContract.Clocks.read(output);
        DuwmAacPacketContract.Report result=DuwmAacPacketContract.verify(before.packets,after.packets,sourceVideo,outputVideo,before.sampleRate,clocks,check);
        return new JSONObject().put("packet_count",result.packetCount).put("payload_bytes",result.byteCount).put("aac_samples",result.sampleCount)
            .put("video_frames",result.videoFrames).put("source_common_origin_us",result.originUs).put("requested_trim_us",fromUs)
            .put("movie_timescale",clocks.movie).put("audio_timescale",clocks.audio).put("video_timescale",clocks.video)
            .put("audio_start_movie_ticks",result.audioStartMovieTicks).put("video_start_movie_ticks",result.videoStartMovieTicks)
            .put("all_payload_bytes_identical",true).put("all_sample_timestamps_exact",true).put("all_video_timestamps_exact",true)
            .put("shared_av_origin_verified",true).put("timestamp_contract","Earliest selected A/V sample; exact movie and track ticks");
    }
}
