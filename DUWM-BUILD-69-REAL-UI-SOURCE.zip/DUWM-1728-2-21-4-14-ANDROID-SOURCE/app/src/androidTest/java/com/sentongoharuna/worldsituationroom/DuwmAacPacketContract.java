package com.sentongoharuna.worldsituationroom;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.List;

/** Independent AAC-copy acceptance contract. No Android runtime or production exporter calls.
 *
 * Android's MP4 writer subtracts the earliest submitted track timestamp from every
 * track. It rounds each later track's initial empty edit in the movie timescale;
 * packet spacing is represented in the track timescale. Comparing output PTS to
 * source PTS minus the requested trim is therefore wrong when neither track has
 * a sample exactly at the trim. One common, source-derived origin is required.
 *
 * References: AOSP MediaMuxerTest.verifyTSWithSamplesDropAndStartOffset and
 * MPEG4Writer.Track.writeEdtsBox. Every comparison below is exact in the relevant
 * integer clock. No millisecond tolerance or independently rebased track is used.
 */
final class DuwmAacPacketContract {
    interface Check { void that(boolean condition, String message); }
    static final class Packet {
        final long timeUs;
        final byte[] bytes;
        Packet(long timeUs, byte[] bytes) { this.timeUs=timeUs; this.bytes=bytes.clone(); }
    }
    static final class Report {
        final int packetCount, videoFrames;
        final long byteCount, sampleCount, originUs, audioStartMovieTicks, videoStartMovieTicks;
        Report(int packets,int frames,long bytes,long samples,long origin,long audioStart,long videoStart) {
            packetCount=packets;videoFrames=frames;byteCount=bytes;sampleCount=samples;
            originUs=origin;audioStartMovieTicks=audioStart;videoStartMovieTicks=videoStart;
        }
    }
    /** Movie and media clocks read from the output file, not assumed constants. */
    static final class Clocks {
        final long movie, audio, video;
        Clocks(long movie,long audio,long video) {
            if(movie<=0||audio<=0||video<=0||movie>1_000_000||audio>1_000_000||video>1_000_000)
                throw new IllegalArgumentException("MP4 clocks must be positive and recoverable from microseconds");
            this.movie=movie;this.audio=audio;this.video=video;
        }
        static Clocks read(File file)throws IOException {
            try(RandomAccessFile in=new RandomAccessFile(file,"r")) {
                Box moov=find(in,0,in.length(),"moov");
                long movie=timescale(in,find(in,moov.payload,moov.end,"mvhd"));
                long audio=0,video=0;
                for(long at=moov.payload;at<moov.end;) {
                    Box track=box(in,at,moov.end);at=track.end;
                    if(!"trak".equals(track.type))continue;
                    Box mdia=find(in,track.payload,track.end,"mdia");
                    Box handler=find(in,mdia.payload,mdia.end,"hdlr");
                    if(handler.end-handler.payload<12)throw new IOException("Truncated MP4 handler");
                    in.seek(handler.payload+8);String kind=in.readInt()==0x736f756e?"audio":"";
                    if(kind.isEmpty()){in.seek(handler.payload+8);if(in.readInt()==0x76696465)kind="video";}
                    if(kind.isEmpty())continue;
                    long clock=timescale(in,find(in,mdia.payload,mdia.end,"mdhd"));
                    if("audio".equals(kind)){if(audio!=0)throw new IOException("Multiple audio tracks in fixture output");audio=clock;}
                    else {if(video!=0)throw new IOException("Multiple video tracks in fixture output");video=clock;}
                }
                try{return new Clocks(movie,audio,video);}catch(IllegalArgumentException error){throw new IOException(error);}
            }
        }
    }
    private static final class Box {
        final long payload,end;final String type;
        Box(long payload,long end,String type){this.payload=payload;this.end=end;this.type=type;}
    }
    private static Box box(RandomAccessFile in,long at,long limit)throws IOException {
        if(at<0||limit-at<8)throw new IOException("Truncated MP4 box");
        in.seek(at);long size=Integer.toUnsignedLong(in.readInt());byte[] type=new byte[4];in.readFully(type);
        long header=8;if(size==1){if(limit-at<16)throw new IOException("Truncated extended MP4 box");size=in.readLong();header=16;}
        if(size==0)size=limit-at;
        if(size<header||size>limit-at)throw new IOException("Invalid MP4 box extent");
        return new Box(at+header,at+size,new String(type,java.nio.charset.StandardCharsets.US_ASCII));
    }
    private static Box find(RandomAccessFile in,long from,long end,String type)throws IOException {
        for(long at=from;at<end;){Box next=box(in,at,end);if(type.equals(next.type))return next;at=next.end;}
        throw new IOException("Missing MP4 "+type+" box");
    }
    private static long timescale(RandomAccessFile in,Box box)throws IOException {
        if(box.end-box.payload<4)throw new IOException("Truncated MP4 clock");
        in.seek(box.payload);int version=in.readUnsignedByte();
        if(version!=0&&version!=1)throw new IOException("Unsupported MP4 clock version");
        long offset=version==0?12:20;
        if(box.end-box.payload<offset+4)throw new IOException("Truncated MP4 timescale");
        in.seek(box.payload+offset);return Integer.toUnsignedLong(in.readInt());
    }
    static long scale(long value,long numerator,long denominator) {
        if(value<0||numerator<=0||denominator<=0)throw new IllegalArgumentException("Invalid media time");
        return Math.addExact(Math.multiplyExact(value,numerator),denominator/2)/denominator;
    }
    private static long ticks(long timeUs,long clock){return scale(timeUs,clock,1_000_000);}
    static Report verify(List<Packet> source,List<Packet> output,List<Long> sourceVideo,
                         List<Long> outputVideo,int sampleRate,Clocks clocks,Check check) {
        check.that(source.size()>10&&source.size()==output.size(),"Every selected source AAC packet is retained");
        check.that(!sourceVideo.isEmpty()&&sourceVideo.size()==outputVideo.size(),"Every selected source video frame is retained for A/V sync");
        check.that(clocks.audio==sampleRate,"AAC media clock equals its retained sample rate");
        long firstAudio=source.get(0).timeUs,firstVideo=sourceVideo.get(0),origin=Math.min(firstAudio,firstVideo);
        check.that(origin>=0,"Selected source A/V timestamps have a nonnegative common origin");
        long audioStart=ticks(firstAudio-origin,clocks.movie),videoStart=ticks(firstVideo-origin,clocks.movie);
        long audioStartTicks=scale(audioStart,clocks.audio,clocks.movie),videoStartTicks=scale(videoStart,clocks.video,clocks.movie);
        long bytes=0,previousSource=-1,previousOutput=-1;
        for(int index=0;index<source.size();index++) {
            Packet before=source.get(index),after=output.get(index);
            check.that(before.timeUs>previousSource&&after.timeUs>previousOutput,"AAC timestamps are strictly increasing at packet "+index);
            check.that(before.bytes.length>0&&Arrays.equals(before.bytes,after.bytes),"Original AAC payload bytes are identical at packet "+index);
            long sourceTicks=ticks(before.timeUs-firstAudio,clocks.audio);
            check.that(sourceTicks==index*1024L,"Fixture AAC packet spacing retains every 1024-sample access unit at "+index);
            long expected=audioStartTicks+sourceTicks,actual=ticks(after.timeUs,clocks.audio);
            check.that(actual==expected,"AAC common-origin sample timestamp at packet "+index+": expected "+expected+" ticks, got "+actual);
            bytes+=before.bytes.length;previousSource=before.timeUs;previousOutput=after.timeUs;
        }
        previousSource=-1;previousOutput=-1;
        for(int index=0;index<sourceVideo.size();index++) {
            long before=sourceVideo.get(index),after=outputVideo.get(index);
            check.that(before>previousSource&&after>previousOutput,"Video timestamps are strictly increasing at frame "+index);
            long expected=videoStartTicks+ticks(before-firstVideo,clocks.video),actual=ticks(after,clocks.video);
            check.that(actual==expected,"Video shares the source A/V origin at frame "+index+": expected "+expected+" ticks, got "+actual);
            previousSource=before;previousOutput=after;
        }
        return new Report(source.size(),sourceVideo.size(),bytes,source.size()*1024L,origin,audioStart,videoStart);
    }
}
