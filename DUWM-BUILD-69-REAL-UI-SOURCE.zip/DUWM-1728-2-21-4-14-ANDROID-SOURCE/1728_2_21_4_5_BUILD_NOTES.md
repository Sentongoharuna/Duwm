# DUWM 1728.2/21/4/5 — Rotating GPS / SPEED / FPS / RECORDING TIME

- Adds one fixed-width rotating telemetry cell instead of adding another graphics row.
- Rotation order is GPS → SPEED → FPS → RECORDING TIME, changing every four seconds on the source timeline.
- GPS uses only the existing recorded coordinate permission/state and real typed measurement sample. Withheld coordinates remain withheld; missing values display an explicit dash/state.
- SPEED uses Android location speed plus the existing movement classification; no derived or simulated movement is inserted.
- FPS uses the measured TextureView presented-frame rate; it is not the requested camera target frame rate.
- RECORDING TIME is calculated from the original recording source time. Preview mode does not claim a recording timer.
- The rotating cell has fixed geometry sized for the bounded formats, so changing fields do not move the lower-third or cover more of the camera picture.
- Rotation boundaries are added to the live overlay cadence so the slot advances even when no sensor callback arrives at that moment.
- AI event headline, AI scene subtitle, measured HDG / ALT / WX, clear-picture mode and automatic finishing/export are retained.
