# DUWM 1728.2/21/3 — Clear picture and inherited SDK repair

## Exact upgrade

This release continues from the exact delivered `/21/2` source. It implements
step 3 of the automatic camera-to-video plan: keep the picture clear while
source-timed scene titles and real measurements change. It also repairs the two
inherited compiler errors supplied by the user during this upgrade.

- Baseline: `DUWM-1728.2-21-2-MEASURED-TELEMETRY-SOURCE.zip`.
- Baseline SHA-256: `d6ef7877a16121d9bee61480d80ed53f2f3f60aed26a7b2fcfbf8c84f611770c`.
- Baseline manifest SHA-256: `8f40a7b23dabe6d40453e58460c68c69cf1bb2eb079428c015130c29276eec99`.
- Version name: `1728.2.21.3`; version code: `172824`.
- Launcher: `DUWM 1728.2/21/3 • DEVELOP.UGANDA`.
- Application ID: `com.sentongoharuna.worldsituationroom.rb2live25`.
- The original globe, navy `#041424`, nineteen desks and unrelated components
  remain. Of the 314 predecessor production Java files, 309 remain unchanged;
  five integration/controller files change and two clear-picture classes are added.

The official dependency remains
`com.google.mlkit:genai-image-description:1.0.0-beta1`. No substitute SDK is added
to the application, no older APK is renamed, and no host result is presented as
physical-phone or native execution.

## Inherited compiler errors and repair

The user's screenshots identify `/21/1` run `42404405149` at commit
`b0c4394cc458f181daed06043f89c74b9c10850e`:

https://github.com/Sentongoharuna/Duwm/actions/runs/42404405149

The official dependency-resolution task passed. Java compilation then failed in
`Duwm1728SceneAnalyzer.java` because the resolved `GenAiException.ErrorCode` type
did not expose these two named fields:

1. `PER_APP_BATTERY_USE_QUOTA_EXCEEDED`.
2. `BACKGROUND_USE_BLOCKED`.

This was an application-source compatibility error. The dependent native job was
skipped because the compile job failed; the screenshots do not establish a native
test failure for this run.

The current official Google reference documents integer error values 27 and 30
for those responses. The controller now uses locally named constants for those
documented values with the existing `getErrorCode()` API, avoiding references to
the absent SDK fields. The one-hour persisted quota cooldown, thirty-second
foreground retry, lifecycle cancellation and bounded general backoff remain.

The previous documentation-only source diagnostic declared those newer fields
in its temporary API surface and therefore could not detect this incompatibility.
The current `/21/3` diagnostic omits them. The active controller test double also
omits them, and two negative compilation probes deliberately reintroduce each
old field reference and require the compiler to reject it. The real controller's
quota and background behavior is still exercised with the documented responses.

Official reference:
https://developers.google.com/android/reference/com/google/mlkit/genai/common/GenAiException.ErrorCode

## Clear-picture layout

New recorded captures with scene or measurement metadata default to **Clear
picture**. Live camera preview uses the same clear layout. The layout has:

- A bounded scene-title card and clock at the top.
- A compact three-row measurement band at the bottom when the measurement
  summary is enabled.
- A fixed two-row caption reservation immediately above that band.
- An explicit central rectangle that the automatic graphics leave unpainted.

The repeated lower scene-description panel, category block and moving ticker are
omitted in this mode. The full recorded scene observations and measurement
history remain in their source-associated metadata. Existing full, compact and
captions compositions remain selectable.

Title length, clock values, stale readings and caption appearance cannot change
the reserved geometry. Long labels fit within their own cells. Essential
coordinates, accuracy, heading, preview frame rate, movement, speed, altitude
reference and weather numbers retain their reserved space and units. Missing
values keep their explicit neutral state instead of collapsing the band.

The layout does not move or zoom the source picture to accommodate text. The
existing automatic original-shape/FIT output policy and original audio path are
retained. A deliberately selected second-video inset is an additional manual
picture element; the clear central-graphics guarantee excludes that chosen inset.
This release does not claim subject, face or saliency detection.

## Live freshness and stable updates

The live view previously depended on incoming callbacks to advance its source
time. If callbacks stopped, a reading could remain on screen beyond its intended
expiry. The new monotonic presentation clock advances between callbacks and
schedules bounded redraws at the next clock second or reading/scene deadline.

This changes presentation timing only. It does not smooth, invent, delay or
interpolate measurement values or model descriptions. Scene changes, stale states
and permission restrictions apply at their actual source times. Camera-session
resets clear the previous scene and measurements; hidden/detached views cancel
their scheduled redraw. The measurement band remains reserved while waiting for
the next sample.

Export remains a stateless selection at `trim start + elapsed output time`.
Seeking and trimming therefore use the same original recording timestamps as
the existing measurement and scene policy. The `/21/2` protection against
capture-end metadata leaking onto earlier frames remains.

## Editor choice and migration

The real layout picker now includes **Clear picture** with its own preview.
Choosing a legacy composition disables clear mode so the chosen composition is
actually shown. The details panel also has a **Keep the picture clear** control.

The `clear_picture` draft field is a strictly validated boolean. Explicit on/off
choices persist. Older authored drafts without the new field retain their
previous composition. Malformed values block partial draft restoration and
cannot overwrite the original draft. Automatic operation introduces no provider
address, server URL or API-key form.

## Verification and its limits

The acceptance file and verification archive contain the final executed results
and exact input hashes. The principal checks are:

- Existing host regressions and source preservation against the delivered baseline.
- Fixed clear-layout geometry, long/changing labels, captions, states and actual
  host-rendered transparent-center pixels across supported shapes.
- The live presentation clock's expiry, idle, reset and seek policy. View
  lifecycle callbacks are source-checked; host checks do not execute Android's
  actual attachment or visibility lifecycle.
- Controller lifecycle/quota behavior and the two inherited compiler-regression probes.
- Source compilation checks with their actual dependency scope explicitly stated.
- Matching source/workflow recovery, workflow syntax and exact evidence bindings.

Documentation-derived temporary Google declarations are diagnostic fixtures only;
they are never supplied to Gradle or packaged in an APK. Passing such a diagnostic
does not establish official SDK compilation. The actual Gradle attempt and any
remaining dependency restriction are recorded separately. Physical camera, model,
GPS/compass/weather and encoded timing checks are not inferred from host results.

## Nineteenth native stage

All eighteen prior native stages remain mandatory. The new `clear_picture`
stage exercises synthetic source-timed scenes and measurements through the real
Android editor, renderer, encoder, decoder and audio path. It verifies:

1. Automatic clear-picture defaults, the real four-choice layout picker, saved
   selections, predecessor-draft migration and malformed-boolean rejection.
2. Fixed geometry through different titles, captions and missing/stale samples.
3. Exact transparency of every reserved center pixel in the Android overlay.
4. Less painted area than the previous compact composition for the same input.
5. Actual decoded title/measurement changes at the correct source moments.
6. A 153-point source-picture comparison inside the clear center at each decoded
   sample, allowing the explicitly stated codec tolerance.
7. Original source-file integrity and exact selected AAC packet bytes/timestamps.

Its artifacts are `ANDROID-CLEAR-PICTURE.mp4`, `ANDROID-CLEAR-FIRST.png`,
`ANDROID-CLEAR-SECOND.png`, and `CLEAR-PICTURE-NATIVE.json`. A passing record is
written only after checks and fixture cleanup complete. It must retain false
physical-camera, physical-sensor, provider-network and model-inference flags.

Stages 17 and 18 explicitly select their prior composition to preserve their
existing description-panel and measured-layout coverage. Stage 19 separately
tests the new default. Their previous assertions and artifact contracts remain.

## Recorded final check results

The final complete host suite passed with all 556 application, instrumentation,
verification-code and fixture inputs unchanged. Focused results are 6,808
clear-layout checks, 73 cadence checks, 62 actual overlay-report adapter checks,
283 scene-controller checks and both missing-SDK-field compiler probes. Native
evidence gate unit tests (46), SDK/measurement/clear-picture class-definition
gates (8/3/4), and ten workflow expression-context cases also passed. These are
host results, not nineteen-stage native execution.

All original host Java files remain byte-identical. Eight host compiler lists add
the new pure layout class. The headline test's temporary compiled copy compares
every original /20 geometry field and retains every pixel assertion; six new
fields are checked separately for neutral legacy defaults. This schema extension
adds 168 assertions, for 2,970 headline checks. No historical layout behavior is
exempted from comparison.

Seven synthetic host images were visually reviewed and their hashes matched the
final suite's images. Across ten sizes, every tested protected central pixel
remained unpainted. The protected rectangle covers 75.84% of a 720×1280 frame and
66.54% of a 960×540 frame. With the same active synthetic subtitle and readings,
painted overlay area fell 26.37% and 36.22%, respectively, from the previous
compact layout. These measurements exclude a deliberately chosen second-video
inset and do not establish physical-camera or Android encoder performance.

Eighteen selected layout, editor, renderer, storage and native-check Java sources
compiled against cached real Android API 36 and recorded compiled dependencies,
without Google API declarations. The separate whole-source diagnostic passed
for 316 application and thirteen instrumentation Java files using the restricted,
temporary Google declarations described above. Original globe, navigation,
source links and component-preservation source checks passed.

One final offline Gradle attempt stopped at `:app:checkDebugAarMetadata` because
`com.google.mlkit:genai-image-description:1.0.0-beta1` is not cached. Neither the
application nor instrumentation Java compiler ran; all 444 build inputs stayed
unchanged. No official SDK download was retried and no new APK was produced.
The nineteen-stage native suite, attached View lifecycle, physical camera and
sensors, provider-network operation and model inference remain unexecuted for
this release. A new /21/3 GitHub Actions run has not been started in this session.

## Matching delivery

Place `DUWM-1728.2-21-3-CLEAR-PICTURE-SOURCE.zip` at the repository root and
`DUWM-1728.2-21-3-CLEAR-PICTURE-APK.yml` in `.github/workflows/`. The workflow
requires their exact matching hashes, genuine official dependency resolution,
actual APK class definitions and all nineteen native stages. Failure diagnostics
are retained. It can restore the exact source from the supported delivered
predecessor archives when the full new archive is absent.

A successful GitHub run is a separate observed event; workflow validation alone
is not a running or passed Actions check. Later releases must use a version code
greater than `172824`.
