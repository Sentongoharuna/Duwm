# DUWM 1728.2/21/4/7 — Automatic reporter verification status

- Reporter badge is now resolved automatically from evidence supplied with the report/capture.
- VERIFIED appears only when an explicit verified-profile assertion is present.
- Local DUWM camera capture with a named reporter is ACTIVE, not VERIFIED.
- Explicit pending verification is shown as VERIFICATION PENDING.
- Otherwise the badge remains UNVERIFIED.
- Reporter-profile verification remains separate from report credibility; a verified profile never confirms the report itself.
- Semantic colours from /21/4/6 remain: green verified/active, yellow pending/unverified.
