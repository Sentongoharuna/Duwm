# DUWM 1728.2/21/3 — Repair 2

## Start the repaired Actions workflow

Upload `DUWM-1728.2-21-3-REPAIR2-APK.yml` into the existing repository's
`.github/workflows/` directory and commit it to `main`. Its own filename is in
the push trigger. The displayed workflow name includes **Repair 2**.

The exact Repair 1 source ZIP already used by run `42417837324` is a supported
input. The workflow validates that ZIP's hash, applies its embedded checked
repair, and verifies every restored source file. This route needs only the new
YAML upload. The separately supplied `DUWM-1728.2-21-3-REPAIR2-SOURCE.zip` is the
complete matching source and may instead be uploaded to the repository root.

Use the new workflow, rather than rerunning the historical Repair 1 run, to
test these new bytes. A rerun of an old commit cannot include this repair.
Manual `workflow_dispatch` is also provided once the new workflow is committed.

## What this repairs

The observed Repair 1 run started successfully, resolved the official ML Kit
SDK, and compiled both Android APKs. Fourteen native stages passed; five failed.
The failures were `review`, `automatic_fit`, `scene_timeline`,
`measured_telemetry`, and `clear_picture`.

- **Saved-video review:** the same-app, non-exported review activity no longer
  requests a redundant URI grant while opening a deleted MediaStore entry.
  Android can reach the existing unavailable/retry state. External sharing
  retains its read grant, stream URI and ClipData. The native deleted-file test
  remains unchanged and mandatory.
- **Automatic headline fixture:** a measured wide title deliberately exercises
  two rows. The old test could select a valid complete one-row title under
  different font metrics. Exact two-row, complete-title, TAIL, byline and
  decoded-video checks remain. The native MP4 and row measurements are now
  retained before a potential assertion failure.
- **AAC verification in three stages:** every selected packet is still checked
  byte for byte. Timestamp checks use one source-derived audio/video origin and
  the output MP4's actual movie and media clocks. Android rebased all three
  archived outputs to the earliest selected packet; the old test incorrectly
  expected the requested trim boundary to remain zero. The production exporter
  is unchanged.
- **Actions diagnostics:** the summary lists all nineteen native stages and
  every failed, missing or invalid result, while preserving failure status and
  the existing strict APK/evidence validation.

## Verification and limits

The combined retained host suite passed with **583 unchanged inputs**.
New focused checks passed: **6,782 AAC assertions**, **36 rejected corruption
and clock cases**, **373 headline-fixture checks**, **28 actual review intent
factory checks**, and **6 native-summary tests**. Existing geometry, font, SDK
field, native-gate and server regressions remain required.

The changed production code and all changed native checks compile in a selected
22-source check against cached actual Android API 36 and recorded compiled app
dependencies, without Google API substitutes. A separate diagnostic checks all
316 application and 15 instrumentation Java sources with explicitly isolated
Google declarations; it is not an official SDK build.

The archived native MP4s prove all 78 selected AAC packets and 20,054 payload
bytes were retained in each of the three failed audio checks. Replaying those
files is not a new Android execution. **Repair 2 has not yet built a new APK or
passed its nineteen-stage Android workflow.** The workflow must establish that.
Physical camera, sensors, provider network requests and model inference are
separate unverified scopes.

The application stays version `1728.2.21.3`, code `172824`, with the original
globe, navy presentation, nineteen desks and clear-picture upgrade. Only one
production Java file changes from Repair 1; the other 315 remain identical.

Detailed source-bound results, observed Repair 1 evidence, package checks and
limitations are supplied in `DUWM-1728.2-21-3-REPAIR2-VERIFICATION.zip`.
