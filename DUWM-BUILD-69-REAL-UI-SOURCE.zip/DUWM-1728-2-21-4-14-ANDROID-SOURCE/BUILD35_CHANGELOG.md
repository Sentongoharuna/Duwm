# Build 35 - RDD accessibility and page rail refinement

Based directly on Build 34 source.
- Version code 172848 and version name 1728.2.21.4.35.
- Shared page identity rail gains 36dp minimum height and 8dp vertical padding for legibility.
- Identity rail is focusable for keyboard and accessibility navigation.
- Decorative identity rail does not announce fake live updates.
- Reduced vertical margin for dense pages.
- Existing globe, tracking and camera implementations retained without replacement.

No APK compilation or device testing is claimed.
