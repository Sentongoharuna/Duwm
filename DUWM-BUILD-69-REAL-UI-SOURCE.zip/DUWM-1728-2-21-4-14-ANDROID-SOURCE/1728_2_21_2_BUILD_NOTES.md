# DUWM 1728.2/21/2 — Changing information from real measurements

## Delivery and exact baseline

This implements step 2 of the automatic camera-to-finished-video plan on the exact
delivered `/21/1` source. It adds real Android measurement acquisition, automatic
place/weather lookup, source-time persistence and a shared live/export display.
The existing on-device scene-description integration is retained.

- Baseline: `DUWM-1728.2-21-1-SCENE-VISION-SOURCE.zip`.
- Baseline SHA-256: `6736e30d11961fa417eba9be9131f1ced5db84a5d058416102b3c490b466beb7`.
- Version name: `1728.2.21.2`; version code: `172823`.
- Launcher: `DUWM 1728.2/21/2 • DEVELOP.UGANDA`.
- Application ID: `com.sentongoharuna.worldsituationroom.rb2live25`.
- Android minimum API 26, compile API 36, Java 17, unchanged from `/21/1`.
- The original globe, nineteen desks and approved navy theme remain. Exactly
  304 existing production Java files are unchanged; five existing integration
  classes change and five measurement classes are added.

The official ML Kit dependency remains
`com.google.mlkit:genai-image-description:1.0.0-beta1`. It was unavailable in the
local cache for `/21/1`; this work does not substitute an SDK, bypass the existing
network restriction or rename an older APK. The included acceptance document and
verification bundle record the actual `/21/2` build outcome separately from
source checks. No physical sensor/model result is inferred from a host test.

## What supplies each value

| Displayed information | Actual source and meaning |
| --- | --- |
| Latitude, longitude and horizontal accuracy | Android LocationManager fix, its provider and reported accuracy; an unavailable or poor fix is not replaced with a default coordinate. |
| Area/place | Android Geocoder response for a real recent fix. No manual place name or AI inference is used as a measured place. |
| Camera heading | Rotation-vector device-to-world matrix projected along the selected camera's optical axis. Labelled magnetic heading. Near-vertical or unreliable readings stay unavailable. |
| Speed | Android location's reported speed, only when the provider actually supplies it. The code does not infer speed from noisy point-to-point differences. |
| Movement | Reported speed and speed accuracy; ambiguous movement is labelled uncertain. |
| Altitude | Actual altitude with the MSL reference when the platform supplies it, otherwise explicitly WGS84. Vertical accuracy is retained when available. |
| Preview frame rate | Distinct TextureView frame arrivals in a rolling window, with an actual frame count and time span. This is not the configured encoder target or a claim about encoded FPS. |
| Weather | Open-Meteo current weather-model data, including provider, model time, temperature and wind units. It is not presented as a phone weather-sensor measurement. |
| Recording time | Recording-start device UTC anchored to monotonic source elapsed time. Export does not substitute its own current wall clock. |

Raw values, units, source identifiers, time/age information and availability states
remain in private source-associated metadata. Zero coordinates, zero speed and
zero altitude are valid when genuinely supplied; missing values do not become zero.

## Automatic acquisition and lifecycle

The location/measurement preset defaults to enabled for this requested feature,
and subsequent user choices persist. Android location permission remains required.
The permission request includes both fine and coarse location and accepts the
platform's approximate-location choice. Denial does not trigger repeated prompts
on each refresh. Camera, compass and preview-rate functions remain usable without
location access.

A separate saved setting controls coordinate display in preview and automatic
video. Precise disclosure requires the camera preset and the platform's fine
permission. The editor retains its own saved choice. The redundant per-recording
location confirmation dialog is removed; the settings and ordinary Android
permission control the feature.

Location providers are handled independently so one unavailable provider does not
prevent the other from working. Nonpositive/future fix timestamps and invalid
coordinates are rejected before the latest-fix comparison, preventing a bad future
fix from blocking later real data. Mock-location data is not accepted as trustworthy
measurement evidence.

Area lookup and weather refresh run automatically from an eligible real location.
Area lookup is bounded by a minimum interval and changes in location; weather
normally refreshes after five minutes or significant movement, with a one-minute
minimum and longer backoff for provider rate limits. Weather queries round the
coordinates to three decimal places. Geocoder callbacks and network workers have
session checks; results from disabled, paused or replaced sessions are discarded.
Queued work checks the session before starting. Turning location off clears cached
query coordinates as well as values.

Weather parsing requires numeric data, explicit expected units and a plausible
provider time/code. HTTP errors, malformed data and provider unavailability remain
visible availability states. No address, server URL or API-key form is introduced.

## Timeline and stale-data rules

New samples are collected at approximately one-second intervals during recording.
The live display refreshes at approximately half-second intervals. These are
scheduled UI intervals, not guaranteed real-time deadlines.

- A saved sample has a maximum three-second interval and never appears before its
  source timestamp. A gap or expired tail cannot revive an older sample.
- Location freshness is bounded to thirty seconds. Compass and preview-rate
  freshness are bounded to three seconds; a stalled preview also withdraws its
  rolling rate.
- Place information has a five-minute/one-kilometre limit and must remain
  associated with a suitable current fix.
- Weather has a ten-minute/five-kilometre limit, a bounded provider timestamp,
  and a current-location requirement. Fetch time alone cannot make old model data
  current.
- Values retain per-field freshness budgets, so a sample can contain an available
  compass alongside unavailable location/weather data.
- UTC advances from the captured time anchor. It does not change when a later
  export is started or when the video is played on a different day.

The legacy renderer's capture-end fallback is repaired: end-of-recording metadata
is no longer burned over earlier moments as if it had been observed then. Legacy
actual sample tracks also receive a bounded hold interval.

Trimming selects using the original source time (`trim start + output elapsed`).
The source video is preserved. Sensor and scene timelines remain separate: neither
weather nor a location string can invent what the image-description model saw.

## Shared display and automatic finishing

Live preview, editor preview and exported video share the measured display adapter
and painter. The measured bar allocates space to coordinates/accuracy, magnetic
heading, preview rate, place, movement/speed, altitude and model weather. Long place
names or weather descriptions must not displace the numeric fields and units.
Unavailable/stale readings have compact states without retained old numbers.

Atomic sidecars are associated with the exact private/Gallery source URI. They
also preserve the measured-capture marker and coordinate preset for empty captures.
A storage failure passes an explicit marker into the editor, keeps the result
neutral and prevents a silent fallback to unrelated metadata. Draft booleans are
validated as booleans, not coerced from arbitrary strings.

The existing automatic finishing flow loads these recorded measurements by default
for new measured captures. No manual title, place entry or weather refresh is
required to apply them. Users can still hide measured output in editor settings.
Moving/reimporting a clean master without its private sidecar cannot reconstruct
its original readings; missing metadata remains unavailable.

## Verification boundaries

The host suite exercises actual pure measurement/timeline/math policies and shared
layout using explicitly synthetic inputs. The preview-rate test uses deterministic
arrival times. These do not execute physical sensors or a weather service.

A dedicated selected-source check compiles all five new measurement runtime
classes against the real Android API 36 jar without API substitutes. The separate
whole-application diagnostic uses real Android APIs plus temporary documented
Google declarations because the actual ML Kit dependency is unavailable locally.
That diagnostic checks source wiring; it is not official ML Kit compilation or an
APK build. Temporary declarations are never passed to Gradle or put in an APK.

The new eighteenth `measured_telemetry` native stage uses synthetic measurements
through actual Android persistence, preview/export and decode paths. It includes
real Android JSON parsing of synthetic provider responses, missing/future/gap
states, trimming and protection against capture-end leakage. Its evidence must
retain `physical_sensors_verified: false`, `provider_network_verified: false` and
`model_inference_verified: false`. All seventeen prior stages remain mandatory.

The workflow also resolves the official ML Kit artifact, compiles genuine APKs and
inspects actual SDK and measurement class definitions in DEX. Host checks, failed
dependency listings and strings merely appearing in a DEX file cannot satisfy
these gates. Failure diagnostics remain available.

## Recorded final check results

The complete host suite passed with all 515 application/native Java and
verification-code inputs unchanged during the run. The new measurement policy
passed 120 checks, preview-rate logic 13 checks, and measured layout 1,905 checks.
All retained behavior, scene, evidence-rejection and workflow-context tests also
passed. The verification archive includes each scoped log and input hash.

All five new measurement classes compiled against actual Android API 36 without
substitute APIs. The broader diagnostic passed for 314 application and twelve
instrumentation Java files using the explicitly documented temporary Google
declarations described above.

One final offline Gradle attempt on the frozen source failed before application
or instrumentation compilation: `com.google.mlkit:genai-image-description:1.0.0-beta1`
was not present in the local cache. All 441 build inputs stayed unchanged during
that attempt. No new APK was produced and no new GitHub Actions run was started.
The eighteen-stage Android/native suite, provider-network behavior and physical
phone measurements remain unexecuted for this release.

## Physical-phone acceptance still required

After a genuine dependency-backed APK is built, verify on the user's phone:

1. Android precise, approximate and denied location permission paths, including
   GPS being switched off/on and location availability indoors/outdoors.
2. Real coordinate accuracy, altitude reference, movement and speed readings.
3. Front/back camera compass direction, unreliable magnetic conditions and a
   near-vertical camera, where a horizontal heading must not be invented.
4. Preview frame-rate changes, stalled frames, recording start/stop and camera
   switches. Compare encoded frame timing independently if encoded FPS is needed.
5. Automatic place/model-weather updates after movement, network loss and provider
   failure; verify source labels, observation time and expiry.
6. Automatic finished videos and trimmed clips, ensuring measurements describe the
   corresponding source moments while original audio and image orientation remain.

The source clock is anchored to MediaRecorder start. Physical alignment with the
camera's encoded presentation timestamps has not yet been measured on the phone;
fixture timing tests do not establish this hardware latency.

## Matching build files

Put `DUWM-1728.2-21-2-MEASURED-TELEMETRY-SOURCE.zip` at the repository root and
`DUWM-1728.2-21-2-MEASURED-TELEMETRY-APK.yml` in `.github/workflows/`. Use the matching
pair; the workflow verifies their source hash. It can also restore an exact checked
patch from the supported delivered predecessor archives.

Later releases, including a version named `/22`, must use a version code greater
than `172823`.

## Official references

- https://developer.android.com/reference/android/location/Location
- https://developer.android.com/reference/android/hardware/SensorManager
- https://developer.android.com/develop/sensors-and-location/location/permissions/runtime
- https://developer.android.com/reference/android/location/Geocoder
- https://open-meteo.com/en/docs
