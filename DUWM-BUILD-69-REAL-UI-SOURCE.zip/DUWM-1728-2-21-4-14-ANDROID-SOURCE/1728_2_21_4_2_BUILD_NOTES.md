# DUWM 1728.2/21/4/2

Improvement 2: automatic AI-generated event headline.

- Uses the current on-device Image Description result as the only headline source.
- Removes image-description boilerplate such as “The image shows”.
- Produces a concise maximum-nine-word uppercase broadcast headline.
- Does not invent a person, place, cause, urgency or event absent from the AI description.
- Keeps the full AI scene description separately for the description layer.
- Existing scene expiry rules remain unchanged; stale AI text is not reused.
- Native graphics fixture now renders an automatic scene headline instead of “AUTOMATED GRAPHICS TEST”.
- Retains /21/4 automatic finishing and all earlier clear-picture/telemetry behavior.
