package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** GEV Port 05 / Maritime Intelligence.
 * Public bounded Open Waters AIS snapshots are supported without an API key;
 * a private, properly authorized HTTPS gateway remains optional.
 * No AIS provider reception means no fabricated ships. Not for navigation. */
public final class GevMarineActivity extends Activity {
    private static final String PREF="rb11_marine";
    private static final long MAX_BYTES=8L*1024L*1024L,STALE_MS=30L*60L*1000L;
    private static final int BG=Color.rgb(5,14,23), FG=Color.rgb(224,240,244), CYAN=Color.rgb(71,210,219), MUTED=Color.rgb(57,181,195), GREEN=Color.rgb(71,210,219), AMBER=Color.rgb(71,210,219);
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final ArrayList<Ship> ships=new ArrayList<>();
    private TextView banner,detail,summary,foot;private EditText endpoint,search;private LinearLayout list;private GevMarineRadarView radar;
    private Duwm1678VisualKit.PulsePanel marineBand;private Duwm1690EvidenceBars marineEvidence;
    private Duwm1670WorldMapView seaWorldMap;
    private String sourceStatus="not configured",sourceName="AISStream gateway";
    private boolean loading;private int selected=-1;private long lastSuccess;private String error="";
    static final String[] PUBLIC_REGIONS={
      "EAST AFRICA / INDIAN OCEAN", "GULF OF ADEN", "RED SEA", "MEDITERRANEAN",
      "NORTH SEA / EUROPE", "ARABIAN GULF", "BAY OF BENGAL", "SINGAPORE / MALACCA",
      "JAPAN", "EAST CHINA SEA", "US ATLANTIC", "GULF OF MEXICO",
      "PANAMA", "BRAZIL / SOUTH ATLANTIC", "SOUTH AFRICA", "AUSTRALIA / TASMAN",
      "OSLOFJORD / NORWAY", "ENGLISH CHANNEL"};
    // Each public area is <=100 square degrees; a region is a request window,
    // not a claim of comprehensive regional AIS receiver coverage.
    static final double[][] PUBLIC_BBOX={
      {-7,37,-1,43},{10,42,16,50},{18,34,26,42},{32,12,40,20},
      {49,0,57,8},{22,48,30,56},{10,80,18,88},{0,99,6,106},
      {31,133,39,141},{22,114,30,122},{35,-78,43,-70},{25,-94,31,-86},
      {6,-83,12,-77},{-28,-47,-20,-39},{-37,15,-29,23},{-37,146,-29,154},
      {58.5,9.5,60.5,11.5},{49,-1,51,3}};
    private int publicRegion=0;private long lastPublicRequest=0L;
    private final Runnable publicPoller=new Runnable(){
        @Override public void run(){
            if(!isFinishing()&&endpoint!=null&&endpoint.getText().toString().trim().isEmpty()&&
               System.currentTimeMillis()-lastPublicRequest>=60000L)fetchPublic();
            ui.postDelayed(this,60000L);
        }
    };
    private boolean showMovingOnly=false,showRecentOnly=false,largeSeaMap=false,listFirst=false,radarVisible=false,regionSpinnerReady=false;private int publicSelectionGeneration=0;private String vesselKind="ALL";
    private LinearLayout.LayoutParams seaMapLayout;
    private int speedBand=0;private int visibleShipRows=85;private int vesselOrder=0; // Lazy pagination, not a maximum number of available ships.

    private static final class Ship {
        String mmsi="",name="",imo="",type="",destination="";
        double lat,lon,sog=Double.NaN,cog=Double.NaN,heading=Double.NaN;
        long observed;
    }
    private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable background(boolean sel){GradientDrawable d=new GradientDrawable();d.setColor(Color.rgb(8,24,36));d.setCornerRadius(dp(23));d.setStroke(dp(1),sel?CYAN:Color.rgb(24,87,105));return d;}
    private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private TextView button(String text,Runnable run){TextView b=txt(text,11,CYAN,true);b.setGravity(Gravity.CENTER);b.setBackground(background(false));b.setOnClickListener(v->run.run());return b;}
    private SharedPreferences prefs(){return getSharedPreferences(PREF,MODE_PRIVATE);}
    @Override protected void onCreate(Bundle state){super.onCreate(state);RunningballV17Insets.install(this);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        // One scrollable document fixes fixed-height controls crowding out
        // the vessel list on phone screens with navigation or display scaling.
        ScrollView page=new ScrollView(this);page.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);root.setPadding(dp(12),dp(10),dp(12),dp(10));
        root.addView(txt("MARITIME  /  VERIFIED AIS",10,CYAN,true),new LinearLayout.LayoutParams(-1,dp(25)));
        root.addView(Duwm1693Chrome.title(txt("MARITIME INTELLIGENCE  /  1700",19,FG,true)),new LinearLayout.LayoutParams(-1,dp(59)));
        marineBand=new Duwm1678VisualKit.PulsePanel(this,"VESSEL RADAR");
        LinearLayout.LayoutParams bandLp=new LinearLayout.LayoutParams(-1,dp(48));bandLp.bottomMargin=dp(9);root.addView(marineBand,bandLp);
        banner=txt("NO AIS FEED CONNECTED",12,AMBER,true);root.addView(banner,new LinearLayout.LayoutParams(-1,dp(44)));
        marineEvidence=new Duwm1690EvidenceBars(this);
        endpoint=new EditText(this);endpoint.setSingleLine(true);endpoint.setTextColor(FG);endpoint.setHintTextColor(MUTED);endpoint.setTextSize(12);
        endpoint.setHint("https://your-ais-server.example/api/vessels");endpoint.setBackground(background(false));endpoint.setPadding(dp(12),0,dp(10),0);
        endpoint.setText(prefs().getString("endpoint",""));
        // Optional credentials stay out of the way when public AIS is being used.
        LinearLayout gatewayBox=new LinearLayout(this);gatewayBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(gatewayBox);
        gatewayBox.addView(endpoint,new LinearLayout.LayoutParams(-1,dp(45)));
        TextView guide=txt("OPTIONAL HTTPS AIS GATEWAY • PUBLIC REGIONAL AIS BELOW NEEDS NO KEY",10,MUTED,false);
        gatewayBox.addView(guide,new LinearLayout.LayoutParams(-1,dp(28)));
        boolean savedGateway=!endpoint.getText().toString().trim().isEmpty();
        gatewayBox.setVisibility(savedGateway?android.view.View.VISIBLE:android.view.View.GONE);
        TextView toggleGateway=button(savedGateway?"HIDE AIS GATEWAY SETTINGS":"OPTIONAL AIS GATEWAY SETTINGS  ▸",()->{});
        root.addView(toggleGateway,new LinearLayout.LayoutParams(-1,dp(43)));
        toggleGateway.setOnClickListener(v->{boolean open=gatewayBox.getVisibility()!=android.view.View.VISIBLE;
            gatewayBox.setVisibility(open?android.view.View.VISIBLE:android.view.View.GONE);
            toggleGateway.setText(open?"HIDE AIS GATEWAY SETTINGS":"OPTIONAL AIS GATEWAY SETTINGS  ▸");});
        LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.addView(button("CONNECT / REFRESH",()->fetch(true)),new LinearLayout.LayoutParams(0,dp(43),1.25f));
        LinearLayout.LayoutParams moving=new LinearLayout.LayoutParams(0,dp(43),1f);moving.leftMargin=dp(6);
        controls.addView(button("MOVING / ALL",()->{showMovingOnly=!showMovingOnly;render();}),moving);root.addView(controls);
        TextView publicTitle=txt("PUBLIC AIS / NO API KEY  •  SELECT AN OCEAN REGION",11,CYAN,true);
        LinearLayout.LayoutParams pl=new LinearLayout.LayoutParams(-1,dp(32));pl.topMargin=dp(6);root.addView(publicTitle,pl);
        Spinner publicAreas=new Spinner(this);
        ArrayAdapter<String> regions=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,PUBLIC_REGIONS);
        regions.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        publicAreas.setAdapter(regions);publicAreas.setBackground(background(false));root.addView(publicAreas,new LinearLayout.LayoutParams(-1,dp(48)));
        // An initial high-receiver sample avoids a misleading permanently empty screen.
        // It is visibly labelled NORWAY, never presented as global ship coverage.
        publicRegion=Math.min(PUBLIC_REGIONS.length-1,Math.max(0,prefs().getInt("public_region",16)));
        publicAreas.setSelection(publicRegion);
        publicAreas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(AdapterView<?> parent,android.view.View view,int index,long id){
                boolean changed=publicRegion!=index;publicRegion=index;prefs().edit().putInt("public_region",index).apply();
                if(radar!=null){double[] a=PUBLIC_BBOX[index];radar.setPort((a[0]+a[2])/2,(a[1]+a[3])/2,500);}
                if(seaWorldMap!=null){double[] a=PUBLIC_BBOX[index];seaWorldMap.focus((a[0]+a[2])/2,(a[1]+a[3])/2,4.2f);}
                if(!regionSpinnerReady){regionSpinnerReady=true;return;}
                if(changed&&endpoint!=null&&endpoint.getText().toString().trim().isEmpty()){
                    publicSelectionGeneration++;ships.clear();selected=-1;lastSuccess=0L;
                    sourceStatus="region selected / waiting for new receipt";error="";render();
                    long cooldown=Math.max(0L,8000L-(System.currentTimeMillis()-lastPublicRequest));
                    if(cooldown>0L)ui.postDelayed(GevMarineActivity.this::fetchPublic,cooldown+250L);else fetchPublic();
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent){}
        });
        TextView publicLoad=button("LOAD ACTUAL PUBLIC AIS POSITIONS  ↻",this::fetchPublic);
        LinearLayout.LayoutParams publicLp=new LinearLayout.LayoutParams(-1,dp(46));publicLp.topMargin=dp(6);root.addView(publicLoad,publicLp);
        LinearLayout vesselDeck=new LinearLayout(this);vesselDeck.setOrientation(LinearLayout.VERTICAL);
        TextView mapFocus=button("AIS MAP FIRST  /  HIDE ADVANCED FILTERS",()->{});
        root.addView(mapFocus,new LinearLayout.LayoutParams(-1,dp(47)));
        root.addView(vesselDeck,new LinearLayout.LayoutParams(-1,-2));
        mapFocus.setOnClickListener(v->{boolean show=vesselDeck.getVisibility()!=View.VISIBLE;
          vesselDeck.setVisibility(show?View.VISIBLE:View.GONE);
          if(seaWorldMap!=null&&seaMapLayout!=null){seaMapLayout.height=dp(show?(listFirst?235:largeSeaMap?730:440):760);
            seaWorldMap.setLayoutParams(seaMapLayout);}
          mapFocus.setText(show?"AIS MAP FIRST  /  HIDE ADVANCED FILTERS":"AIS MAP FOCUS  /  SHOW ADVANCED FILTERS");});
        search=new EditText(this);search.setSingleLine(true);search.setTextColor(FG);search.setHintTextColor(MUTED);search.setHint("Search name • MMSI • destination");
        search.setTextSize(13);search.setPadding(dp(12),0,dp(10),0);search.setBackground(background(false));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(43));sp.topMargin=dp(7);vesselDeck.addView(search,sp);
        LinearLayout typeFilters=new LinearLayout(this);typeFilters.setOrientation(LinearLayout.HORIZONTAL);
        android.widget.HorizontalScrollView classScroll=new android.widget.HorizontalScrollView(this);classScroll.setHorizontalScrollBarEnabled(false);
        classScroll.addView(typeFilters);vesselDeck.addView(classScroll,new LinearLayout.LayoutParams(-1,dp(45)));
        final java.util.ArrayList<TextView> vesselTypeButtons=new java.util.ArrayList<>();
        for(String kind:new String[]{"ALL","CARGO","TANKERS","PASSENGER","OTHER / UNKNOWN"}){
            TextView chip=button(kind,()->{vesselKind=kind;visibleShipRows=85;
                for(TextView choice:vesselTypeButtons){choice.setTextColor(choice.getText().toString().equals(vesselKind)?FG:CYAN);
                    choice.setBackground(background(choice.getText().toString().equals(vesselKind)));}
                render();});
            vesselTypeButtons.add(chip);chip.setBackground(background(kind.equals(vesselKind)));
            chip.setTextColor(kind.equals(vesselKind)?FG:CYAN);
            LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(dp(kind.length()>10?145:100),dp(41));clp.rightMargin=dp(5);
            typeFilters.addView(chip,clp);
        }
        summary=txt("0 VERIFIED VESSEL REPORTS",12,CYAN,true);root.addView(summary,new LinearLayout.LayoutParams(-1,dp(34)));
        TextView shipOrder=button("SORT VESSEL REGISTER: LATEST AIS FIX",()->{});
        vesselDeck.addView(shipOrder,new LinearLayout.LayoutParams(-1,dp(44)));
        shipOrder.setOnClickListener(v->{vesselOrder=(vesselOrder+1)%3;visibleShipRows=85;
            shipOrder.setText(vesselOrder==1?"SORT VESSEL REGISTER: FASTEST REPORTED SPEED":
                vesselOrder==2?"SORT VESSEL REGISTER: VESSEL NAME A-Z":"SORT VESSEL REGISTER: LATEST AIS FIX");renderList();});
        LinearLayout mapOps=new LinearLayout(this);mapOps.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams mop=new LinearLayout.LayoutParams(-1,dp(47));mop.bottomMargin=dp(6);vesselDeck.addView(mapOps,mop);
        TextView recentOnly=button("ALL AIS AGES",()->{});
        mapOps.addView(recentOnly,new LinearLayout.LayoutParams(0,-1,1));
        recentOnly.setOnClickListener(v->{showRecentOnly=!showRecentOnly;
            recentOnly.setText(showRecentOnly?"RECENT FIXES ONLY":"ALL AIS AGES");render();});
        TextView speedSelector=button("AIS SPEED / ALL REPORTED VESSELS",()->{});
        speedSelector.setContentDescription("Filter the AIS map and vessel register by real received speed: all, stopped, moving, ten knots or more");
        vesselDeck.addView(speedSelector,new LinearLayout.LayoutParams(-1,dp(46)));
        speedSelector.setOnClickListener(v->{speedBand=(speedBand+1)%4;visibleShipRows=85;
            speedSelector.setText(speedBand==1?"AIS SPEED / STOPPED OR NEAR ZERO":
                speedBand==2?"AIS SPEED / UNDERWAY 0.5–10 KNOTS":
                speedBand==3?"AIS SPEED / 10+ KNOTS":"AIS SPEED / ALL REPORTED VESSELS");render();});
        TextView bigMap=button("EXPAND SEA MAP",()->{});
        LinearLayout.LayoutParams amp=new LinearLayout.LayoutParams(0,-1,1);amp.leftMargin=dp(6);mapOps.addView(bigMap,amp);
        bigMap.setOnClickListener(v->{largeSeaMap=!largeSeaMap;if(seaWorldMap!=null&&seaMapLayout!=null){
            seaMapLayout.height=dp(vesselDeck.getVisibility()==View.GONE?760:listFirst?235:largeSeaMap?730:440);seaWorldMap.setLayoutParams(seaMapLayout);}
            bigMap.setText(largeSeaMap?"COMPACT SEA MAP":"EXPAND SEA MAP");});
        LinearLayout ports=new LinearLayout(this);ports.setOrientation(LinearLayout.HORIZONTAL);
        ports.addView(button("MOMBASA",()->radar.setPort(-4.04,39.67,140)),new LinearLayout.LayoutParams(0,dp(31),1));
        ports.addView(button("DAR ES SALAAM",()->radar.setPort(-6.82,39.28,140)),new LinearLayout.LayoutParams(0,dp(31),1));
        ports.addView(button("DURBAN",()->radar.setPort(-29.88,31.05,140)),new LinearLayout.LayoutParams(0,dp(31),1));
        vesselDeck.addView(ports);
        seaWorldMap=new Duwm1670WorldMapView(this);seaWorldMap.setLayer("VESSELS");
        seaMapLayout=new LinearLayout.LayoutParams(-1,dp(440));seaMapLayout.topMargin=dp(9);root.addView(seaWorldMap,4,seaMapLayout);
        seaWorldMap.setOnPinSelected(pin->{for(int i=0;i<ships.size();i++)if(ships.get(i).mmsi.equals(pin.id)){
          selected=i;showSelected();renderList();break;}});
        TextView focusLatest=button("◎ FOCUS LATEST MATCHING AIS VESSEL",this::focusLatestReceivedVessel);
        focusLatest.setContentDescription("Focus on a real AIS vessel from the selected region and current filters");
        root.addView(focusLatest,5,new LinearLayout.LayoutParams(-1,dp(45)));
        radar=new GevMarineRadarView(this);
        TextView radarToggle=button("OPTIONAL PORT RADAR ▸  (MAP IS PRIMARY)",()->{});
        LinearLayout.LayoutParams radarLp=new LinearLayout.LayoutParams(-1,dp(42));radarLp.topMargin=dp(5);root.addView(radarToggle,radarLp);
        radar.setVisibility(android.view.View.GONE);
        root.addView(radar,new LinearLayout.LayoutParams(-1,dp(180)));
        radarToggle.setOnClickListener(v->{radarVisible=!radarVisible;radar.setVisibility(radarVisible?android.view.View.VISIBLE:android.view.View.GONE);
            radarToggle.setText(radarVisible?"HIDE OPTIONAL PORT RADAR":"OPTIONAL PORT RADAR ▸  (MAP IS PRIMARY)");});
        TextView layoutMode=button("MAP FIRST  /  TAP TO ENLARGE VESSEL REGISTER",()->{});
        LinearLayout.LayoutParams layoutModeLp=new LinearLayout.LayoutParams(-1,dp(43));layoutModeLp.bottomMargin=dp(7);root.addView(layoutMode,layoutModeLp);
        layoutMode.setOnClickListener(v->{listFirst=!listFirst;seaMapLayout.height=dp(vesselDeck.getVisibility()==View.GONE?760:listFirst?235:largeSeaMap?730:440);
            seaWorldMap.setLayoutParams(seaMapLayout);layoutMode.setText(listFirst?"VESSEL REGISTER FIRST  /  TAP FOR MAP":"MAP FIRST  /  TAP FOR VESSEL REGISTER");});
        TextView receiptGraph=button("VIEW RECEIVED AIS CLASSIFICATION  ▸",()->{});
        root.addView(receiptGraph,new LinearLayout.LayoutParams(-1,dp(45)));
        marineEvidence.setVisibility(android.view.View.GONE);
        LinearLayout.LayoutParams mlp=new LinearLayout.LayoutParams(-1,dp(225));mlp.bottomMargin=dp(10);root.addView(marineEvidence,mlp);
        receiptGraph.setOnClickListener(v->{boolean open=marineEvidence.getVisibility()!=android.view.View.VISIBLE;
            marineEvidence.setVisibility(open?android.view.View.VISIBLE:android.view.View.GONE);
            receiptGraph.setText(open?"HIDE AIS CLASSIFICATION  ▴":"VIEW RECEIVED AIS CLASSIFICATION  ▸");});
        radar.setOnShipSelected(index->{selected=index;showSelected();renderList();});
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list,new LinearLayout.LayoutParams(-1,-2));
        detail=txt("SELECT A VESSEL TO VIEW ITS LAST REPORTED POSITION",13,FG,true);
        detail.setPadding(dp(9),dp(13),dp(9),dp(13));detail.setBackground(background(false));
        // One selected-vessel panel immediately after the original map; do not duplicate the report below.
        root.addView(detail,5,new LinearLayout.LayoutParams(-1,-2));
        TextView focus=button("CENTRE SEA MAP ON SELECTED AIS FIX",()->{
            Ship s=chosen();if(s==null){banner.setText("SELECT A SOURCE-REPORTED VESSEL FIRST");return;}
            seaWorldMap.setSelected(s.mmsi);seaWorldMap.focus(s.lat,s.lon,4.0f);
        });
        LinearLayout.LayoutParams focusLp=new LinearLayout.LayoutParams(-1,dp(46));focusLp.topMargin=dp(5);root.addView(focus,6,focusLp);
        LinearLayout bottom=new LinearLayout(this);bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.addView(button("EARTH POSITION",this::openEarth),new LinearLayout.LayoutParams(0,dp(44),1));
        LinearLayout.LayoutParams share=new LinearLayout.LayoutParams(0,dp(44),1);share.leftMargin=dp(7);bottom.addView(button("SHARE CARD",this::share),share);
        root.addView(bottom);
        foot=txt("OPEN WATERS PUBLIC AIS OR OPTIONAL HTTPS GATEWAY • NOT FOR NAVIGATION",10,MUTED,false);
        root.addView(foot,new LinearLayout.LayoutParams(-1,dp(33)));
        page.addView(root,new ScrollView.LayoutParams(-1,-2));setContentView(page);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){render();}
            public void afterTextChanged(Editable e){} });
        restore();render();if(!endpoint.getText().toString().trim().isEmpty())fetch(false);else fetchPublic();
    }
    static long timestamp(JSONObject row){
        double raw=row.optDouble("last_position_epoch",Double.NaN);
        if(GevMarineMath.finite(raw)&&raw>0d){long n=(long)raw;return n<100000000000L?n*1000L:n;}
        String iso=row.optString("last_position_UTC","");if(iso.isEmpty())return 0L;
        try{String trimmed=iso.trim();if(trimmed.endsWith("Z"))trimmed=trimmed.substring(0,trimmed.length()-1);
            if(trimmed.length()>19)trimmed=trimmed.substring(0,19);
            SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date d=f.parse(trimmed);return d==null?0L:d.getTime();}catch(Exception ignored){return 0L;}
    }
    private void decode(String json,boolean freshNetwork){
        ArrayList<Ship> found=new ArrayList<>();
        JSONObject data;try{data=new JSONObject(json);}catch(Exception e){error="INVALID AIS GATEWAY JSON";return;}
        JSONArray arr=data.optJSONArray("rows");if(arr==null){error="AIS GATEWAY RESPONSE LACKS rows ARRAY";return;}
        sourceName=data.optString("source","AISStream gateway");sourceStatus=data.optString("status","unknown");
        for(int i=0;i<arr.length()&&found.size()<18000;i++){
            JSONObject row=arr.optJSONObject(i);if(row==null)continue;
            Ship ship=new Ship();ship.lat=row.optDouble("lat",Double.NaN);ship.lon=row.optDouble("lon",Double.NaN);
            ship.mmsi=row.optString("mmsi","").trim();if(!GevMarineMath.valid(ship.lat,ship.lon)||!GevMarineMath.validMmsi(ship.mmsi))continue;
            ship.name=row.optString("name","").trim();if(ship.name.isEmpty())ship.name="MMSI "+ship.mmsi;
            ship.imo=row.optString("imo","");ship.type=row.optString("type","");ship.destination=row.optString("destination","");
            ship.sog=row.optDouble("speed",Double.NaN);ship.cog=row.optDouble("course",Double.NaN);ship.heading=row.optDouble("heading",Double.NaN);
            ship.observed=timestamp(row);found.add(ship);
        }
        if(freshNetwork)lastSuccess=System.currentTimeMillis();
        ships.clear();ships.addAll(found);selected=-1;
        Collections.sort(ships,(a,b)->Long.compare(b.observed,a.observed));
    }
    private void restore(){lastSuccess=prefs().getLong("last_fetch",0L);sourceStatus=prefs().getString("status","cached");
        String raw=prefs().getString("rows","");if(!raw.isEmpty())decode(raw,false);}
    private void fetch(boolean manual){if(loading)return;
        String rawUrl=endpoint.getText().toString().trim();
        try{URL u=new URL(rawUrl);if(!"https".equalsIgnoreCase(u.getProtocol())||u.getUserInfo()!=null||u.getQuery()!=null)
            throw new IllegalArgumentException("HTTPS URL WITHOUT CREDENTIALS OR QUERY REQUIRED");
            if(u.getHost()==null||u.getHost().isEmpty())throw new IllegalArgumentException("INVALID HOST");
        }catch(Exception e){banner.setText("CONFIGURE HTTPS AIS GATEWAY • NOT CONNECTED");return;}
        prefs().edit().putString("endpoint",rawUrl).apply();loading=true;banner.setText("CONNECTING TO AIS SNAPSHOT …");
        io.execute(()->{String content=null;String failure=null;HttpURLConnection c=null;
            try{c=(HttpURLConnection)new URL(rawUrl+(rawUrl.endsWith("?")?"":"?maxRows=5000")).openConnection();c.setConnectTimeout(8500);c.setReadTimeout(9500);
                c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","RUNNINGBALL2-Maritime/11");
                if(c.getResponseCode()!=200)throw new IllegalStateException("AIS GATEWAY HTTP "+c.getResponseCode());
                try(InputStream s=c.getInputStream();ByteArrayOutputStream b=new ByteArrayOutputStream()){
                    byte[] buf=new byte[8192];int n;while((n=s.read(buf))!=-1){if(b.size()+n>MAX_BYTES)throw new IllegalStateException("AIS SNAPSHOT EXCEEDS MEMORY SAFETY BOUND");b.write(buf,0,n);}content=b.toString("UTF-8");}
                JSONObject verify=new JSONObject(content);if(!verify.has("rows")||verify.optJSONArray("rows")==null)throw new IllegalStateException("AIS JSON MISSING rows");
            }catch(Exception e){failure=e.getMessage()==null?"AIS CONNECTION ERROR":e.getMessage();}finally{if(c!=null)c.disconnect();}
            final String data=content,fail=failure;
            ui.post(()->{loading=false;if(isFinishing())return;
                if(fail==null&&data!=null){error="";decode(data,true);
                    prefs().edit().putString("rows",data).putString("status",sourceStatus).putLong("last_fetch",lastSuccess).remove("last_error").apply();
                }else{error=fail==null?"NO DATA":fail;sourceStatus="offline";
                    prefs().edit().putString("last_error",error).apply();}
                render();GevMaritimeWidget.updateAll(this);RunningballV14SignalWidget.updateAll(this);
            });
        });
    }
    /** Open Waters anonymous GeoJSON endpoint, 2026 public API. It accepts only
     * geographically bounded requests for unauthenticated clients; never send a
     * global anonymous request, bypass authentication or invent ship markers. */
    private void fetchPublic(){
        if(loading)return;
        long now=System.currentTimeMillis();if(now-lastPublicRequest<8000L){banner.setText("PUBLIC AIS REQUEST ALREADY SENT • WAIT FOR RECEIPT");return;}
        lastPublicRequest=now;loading=true;error="";
        prefs().edit().putLong("home_public_attempt",now).apply();
        final int region=Math.max(0,Math.min(PUBLIC_REGIONS.length-1,publicRegion));
        final int regionGeneration=publicSelectionGeneration;
        final double[] b=PUBLIC_BBOX[region];
        final String address=String.format(Locale.US,
            "https://ais.openwaters.io/v1/vessels?bbox=%.5f,%.5f,%.5f,%.5f",
            b[0],b[1],b[2],b[3]);
        banner.setText("REQUESTING PUBLIC AIS • "+PUBLIC_REGIONS[region]);
        io.execute(()->{
            String data=null,failure=null;HttpURLConnection c=null;
            try{
                c=(HttpURLConnection)new URL(address).openConnection();
                c.setConnectTimeout(10000);c.setReadTimeout(16000);
                c.setRequestProperty("Accept","application/geo+json, application/json");
                c.setRequestProperty("User-Agent","develop.uganda-DUWM-1674/1.0");
                int http=c.getResponseCode();if(http!=200)throw new IllegalStateException("OPEN WATERS HTTP "+http+(http==429?" / RATE LIMITED":""));
                ByteArrayOutputStream out=new ByteArrayOutputStream();
                try(InputStream in=c.getInputStream()){
                    byte[] buffer=new byte[8192];int n;
                    while((n=in.read(buffer))!=-1){if(out.size()+n>MAX_BYTES)throw new IllegalStateException("AIS RESPONSE EXCEEDS MEMORY SAFETY BOUND");out.write(buffer,0,n);}
                }
                JSONObject featureCollection=new JSONObject(out.toString("UTF-8"));
                JSONArray features=featureCollection.optJSONArray("features");
                if(features==null)throw new IllegalStateException("AIS DID NOT RETURN A GEOJSON FEATURE LIST");
                JSONArray rows=new JSONArray();
                for(int i=0;i<features.length();i++){
                    JSONObject feature=features.optJSONObject(i);if(feature==null)continue;
                    JSONObject geo=feature.optJSONObject("geometry");JSONObject properties=feature.optJSONObject("properties");
                    if(geo==null||properties==null)continue;
                    JSONArray coordinates=geo.optJSONArray("coordinates");
                    if(coordinates==null||coordinates.length()<2)continue;
                    double lon=coordinates.optDouble(0,Double.NaN),lat=coordinates.optDouble(1,Double.NaN);
                    if(!GevMarineMath.valid(lat,lon))continue;
                    JSONObject v=new JSONObject();v.put("lat",lat);v.put("lon",lon);
                    v.put("mmsi",properties.optString("mmsi",feature.optString("id","")));
                    v.put("name",properties.optString("name",""));v.put("type",properties.optString("type",""));
                    v.put("speed",properties.has("sog")?properties.optDouble("sog"):JSONObject.NULL);
                    v.put("course",properties.has("cog")?properties.optDouble("cog"):JSONObject.NULL);
                    v.put("heading",properties.has("heading")?properties.optDouble("heading"):JSONObject.NULL);
                    v.put("last_position_UTC",properties.optString("seen",""));
                    rows.put(v);
                }
                JSONObject packet=new JSONObject();packet.put("rows",rows);
                packet.put("source","Open Waters AIS / anonymous area GeoJSON");
                packet.put("status","live");packet.put("region",PUBLIC_REGIONS[region]);
                packet.put("sourceUrl",address);data=packet.toString();
            }catch(Exception e){failure=e.getMessage()==null?"PUBLIC AIS UNAVAILABLE":e.getMessage();}
            finally{if(c!=null)c.disconnect();}
            final String json=data,err=failure;
            ui.post(()->{
                loading=false;if(isFinishing())return;
                if(regionGeneration!=publicSelectionGeneration){lastPublicRequest=0L;render();fetchPublic();return;}
                if(json!=null&&err==null){error="";decode(json,true);
                    prefs().edit().putString("rows",json).putString("status",sourceStatus)
                        .putLong("last_fetch",lastSuccess).remove("last_error").apply();
                    double[] r=PUBLIC_BBOX[region];radar.setPort((r[0]+r[2])/2,(r[1]+r[3])/2,500);
                }else{error=err==null?"NO AIS RESPONSE":err;sourceStatus="offline";prefs().edit().putString("last_error",error).apply();}
                render();GevMaritimeWidget.updateAll(this);RunningballV14SignalWidget.updateAll(this);
            });
        });
    }
    private String utc(long t){if(t<=0L)return "NO TIMESTAMP";SimpleDateFormat f=new SimpleDateFormat("dd MMM yyyy HH:mm 'UTC'",Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(t));}
    private void focusLatestReceivedVessel(){
        long now=System.currentTimeMillis();int candidate=-1;
        for(int i=0;i<ships.size();i++){
            Ship v=ships.get(i);
            if(!visibleShip(v,now)||v.observed<=0||!Double.isFinite(v.lat)||!Double.isFinite(v.lon)||
                Math.abs(v.lat)>90||Math.abs(v.lon)>180)continue;
            if(candidate<0||v.observed>ships.get(candidate).observed)candidate=i;
        }
        if(candidate<0){banner.setText("NO RECEIVED AIS FIX MATCHES THE CURRENT REGION AND FILTERS");return;}
        selected=candidate;Ship found=ships.get(candidate);
        showSelected();renderList();
        if(seaWorldMap!=null){seaWorldMap.setSelected(found.mmsi);seaWorldMap.focus(found.lat,found.lon,4.4f);}
        banner.setText("FOCUSED RECEIVED AIS FIX  /  "+found.name+"  •  "+utc(found.observed));
    }
    private Ship chosen(){return selected>=0&&selected<ships.size()?ships.get(selected):null;}
    private static String kindOf(Ship ship){String type=ship.type==null?"":ship.type.trim().toUpperCase(Locale.US);
        int code=-1;try{code=Integer.parseInt(type);}catch(NumberFormatException ignored){}
        if(type.contains("CARGO")||(code>=70&&code<=79))return "CARGO";
        if(type.contains("TANK")||(code>=80&&code<=89))return "TANKERS";
        if(type.contains("PASSENGER")||(code>=60&&code<=69))return "PASSENGER";
        return "OTHER / UNKNOWN";
    }
    private boolean visibleShip(Ship ship,long now){
        if(!"ALL".equals(vesselKind)&&!vesselKind.equals(kindOf(ship)))return false;
        if(speedBand!=0 && (!GevMarineMath.reported(ship.sog) ||
            (speedBand==1 && ship.sog>0.5d) ||
            (speedBand==2 && (ship.sog<=0.5d || ship.sog>=10d)) ||
            (speedBand==3 && ship.sog<10d)))return false;
        if(showRecentOnly&&!"RECENT".equals(GevMarineMath.freshness(ship.observed,now)))return false;
        if(showMovingOnly&&(!GevMarineMath.reported(ship.sog)||ship.sog<0.5d))return false;
        String q=search==null?"":search.getText().toString().trim().toLowerCase(Locale.US);
        return q.isEmpty()||(ship.name+" "+ship.mmsi+" "+ship.destination+" "+ship.type).toLowerCase(Locale.US).contains(q);
    }
    private void render(){long now=System.currentTimeMillis();
        if(chosen()!=null&&!visibleShip(chosen(),now))selected=-1;
        int recent=0,moving=0,cargo=0,tankers=0,passengers=0,other=0;
        for(Ship ship:ships){if("RECENT".equals(GevMarineMath.freshness(ship.observed,now)))recent++;
            if(GevMarineMath.reported(ship.sog)&&ship.sog>0.5d)moving++;
            String k=kindOf(ship);if("CARGO".equals(k))cargo++;else if("TANKERS".equals(k))tankers++;
            else if("PASSENGER".equals(k))passengers++;else other++;}
        if(marineEvidence!=null)marineEvidence.setValues("MARITIME / RECEIVED AIS TYPES",
            new String[]{"CARGO","TANKERS","PASSENGER","OTHER / UNKNOWN"},
            new long[]{cargo,tankers,passengers,other});
        boolean live="live".equalsIgnoreCase(sourceStatus)&&recent>0&&error.isEmpty()&&lastSuccess>0&&now-lastSuccess<180000L;
        if(ships.isEmpty()){banner.setText(error.isEmpty()?"NO AIS POSITIONS RECEIVED FOR THIS REGION • TRY OSLOFJORD / CHANNEL / RETRY":"AIS UNAVAILABLE • "+error);}
        else banner.setText((live?"LIVE AIS REPORTS":"AIS CACHED / UNVERIFIED")+" • "+sourceStatus.toUpperCase(Locale.US)+(error.isEmpty()?"":" • "+error));
        boolean connected=!prefs().getString("endpoint","").trim().isEmpty() ||
            sourceName.startsWith("Open Waters") || lastPublicRequest>0L;
        marineBand.setReceipt(ships.isEmpty()?"NO AIS POSITIONS RETURNED":"AIS POSITIONS / "+sourceName,ships.size(),live);
        summary.setTextColor(live?GREEN:(ships.isEmpty()?AMBER:CYAN));
        summary.setText(!connected?"AIS NOT REQUESTED  •  SELECT PUBLIC REGION OR CONNECT GATEWAY":
          lastSuccess<=0?"AIS DATA NOT RECEIVED  •  REPORTED VESSELS --":
          ships.size()+" REPORTED VESSELS  •  "+recent+" RECENT  •  "+moving+" MOVING  •  TYPE "+vesselKind+"  •  SPEED "+(speedBand==0?"ALL":speedBand==1?"STOPPED":speedBand==2?"0.5–10 KN":"10+ KN")+
          (sourceName.startsWith("Open Waters")?"  •  REGION "+PUBLIC_REGIONS[publicRegion]:"  •  PRIVATE AIS GATEWAY"));
        foot.setText(sourceName+" • RECEIVED "+utc(lastSuccess)+" • AIS COVERAGE IS PARTIAL / POSITIONS MAY BE STALE");
        ArrayList<GevMarineRadarView.Point> plots=new ArrayList<>();
        for(int i=0;i<ships.size();i++){Ship ship=ships.get(i);
            if(visibleShip(ship,now)&&plots.size()<1200)plots.add(new GevMarineRadarView.Point(i,ship.lat,ship.lon,ship.observed,ship.name,ship.mmsi));}
        radar.setRecords(plots);
        ArrayList<Duwm1670WorldMapView.Pin> worldPins=new ArrayList<>();
        for(Ship ship:ships)if(visibleShip(ship,now)&&worldPins.size()<1200)worldPins.add(new Duwm1670WorldMapView.Pin(ship.mmsi,ship.name,"VESSEL",
            ship.lat,ship.lon,ship.observed,"AIS position / "+sourceName));
        if(seaWorldMap!=null)seaWorldMap.setPins(worldPins,false);
        foot.setText(sourceName+" • RECEIVED "+utc(lastSuccess)+" • CHART SHOWS "+worldPins.size()+" MOST RECENT MATCHING REPORTS (MAX 1,200) • NOT FOR NAVIGATION");
        renderList();showSelected();
    }
    private void renderList(){if(list==null)return;list.removeAllViews();String q=search.getText().toString().trim().toLowerCase(Locale.US);long now=System.currentTimeMillis();int shown=0,eligible=0;
        ArrayList<Integer> order=new ArrayList<>();for(int i=0;i<ships.size();i++)order.add(i);
        java.util.Collections.sort(order,(a,b)->{
            Ship x=ships.get(a),y=ships.get(b);
            if(vesselOrder==1){double xs=GevMarineMath.reported(x.sog)?x.sog:-1,ys=GevMarineMath.reported(y.sog)?y.sog:-1;
                int bySpeed=Double.compare(ys,xs);if(bySpeed!=0)return bySpeed;}
            if(vesselOrder==2){int byName=String.valueOf(x.name).compareToIgnoreCase(String.valueOf(y.name));if(byName!=0)return byName;}
            return Long.compare(y.observed,x.observed);
        });
        for(int i:order){
            Ship v=ships.get(i);if(!visibleShip(v,now))continue;
            eligible++;if(shown>=visibleShipRows)continue;
            String speed=GevMarineMath.reported(v.sog)?String.format(Locale.US,"%.1f kn",v.sog):"SPEED --";
            final int index=i;
            String line=v.name+"\n"+v.mmsi+"  •  "+speed+"  •  "+GevMarineMath.freshness(v.observed,now)+
                (v.type.isEmpty()?"":"  •  "+v.type.toUpperCase(Locale.US));
            LinearLayout vesselRow=new LinearLayout(this);vesselRow.setOrientation(LinearLayout.HORIZONTAL);
            vesselRow.setGravity(Gravity.CENTER_VERTICAL);vesselRow.setBackground(Duwm1678VisualKit.panel(this,"VESSELS",i==selected));
            TextView vesselDot=txt("●",18,(v.type.toUpperCase(Locale.US).contains("TANK")?AMBER:
              v.type.toUpperCase(Locale.US).contains("RESCUE")?GREEN:CYAN),true);
            vesselDot.setPadding(dp(7),0,0,0);vesselRow.addView(vesselDot);
            TextView item=txt(line,12,i==selected?CYAN:FG,i==selected);
            item.setPadding(dp(12),dp(6),dp(6),dp(6));
            vesselRow.addView(item,new LinearLayout.LayoutParams(0,dp(72),1));
            TextView send=button("▣ CARD",()->share(v));
            send.setContentDescription("Share recorded AIS vessel information for "+v.name);
            LinearLayout.LayoutParams sendLp=new LinearLayout.LayoutParams(dp(82),dp(45));sendLp.rightMargin=dp(6);
            vesselRow.addView(send,sendLp);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(76));lp.bottomMargin=dp(6);list.addView(vesselRow,lp);
            item.setOnClickListener(view->{selected=index;showSelected();renderList();
              if(seaWorldMap!=null){seaWorldMap.setSelected(v.mmsi);seaWorldMap.focus(v.lat,v.lon,3.2f);}});shown++;
        }
        if(shown==0)list.addView(txt(ships.isEmpty()?"NO VESSELS RECEIVED. CHECK REGION, COVERAGE AND PROVIDER STATUS.":"NO VESSELS MATCH THIS FILTER",12,MUTED,false));
        if(eligible>shown){
            final int remaining=eligible-shown;
            TextView load=button("LOAD MORE VERIFIED SHIPS  •  "+remaining+" REMAINING",()->{visibleShipRows+=85;renderList();});
            list.addView(load,new LinearLayout.LayoutParams(-1,dp(52)));
        }
    }
    private void showSelected(){Ship s=chosen();if(s==null){detail.setText("SELECT A VESSEL TO INSPECT REPORTED POSITION");return;}
        String speed=GevMarineMath.reported(s.sog)?String.format(Locale.US,"%.1f KNOTS",s.sog):"SPEED UNKNOWN";
        String cog=GevMarineMath.finite(s.cog)?String.format(Locale.US,"%.0f°",s.cog):"--";
        detail.setText("SELECTED AIS FIX  /  "+s.name+"\nMMSI "+s.mmsi+"  •  "+speed+"  •  COURSE "+cog+
          "\nPOSITION "+String.format(Locale.US,"%.4f, %.4f",s.lat,s.lon)+"\nOBSERVED "+utc(s.observed)+
          "  •  "+GevMarineMath.freshness(s.observed,System.currentTimeMillis())+"\nTYPE  "+kindOf(s)+"  •  DESTINATION (VESSEL-REPORTED): "+(s.destination.isEmpty()?"NOT REPORTED":s.destination));
    }
    private void openEarth(){Ship s=chosen();if(s==null){banner.setText("SELECT A VESSEL FIRST");return;}
        Intent i=new Intent(this,GevEarthExploreActivity.class);i.putExtra("geo_lat",s.lat);i.putExtra("geo_lon",s.lon);
        i.putExtra("marine_observed",true);i.putExtra("marine_name",s.name);startActivity(i);
    }
    private void share(){Ship s=chosen();if(s==null){banner.setText("SELECT A VESSEL FIRST");return;}share(s);}
    private void share(Ship s){if(s==null)return;
        LinkedHashMap<String,String> facts=new LinkedHashMap<>();facts.put("MMSI",s.mmsi);facts.put("POSITION",String.format(Locale.US,"%.4f, %.4f",s.lat,s.lon));
        facts.put("SPEED",GevMarineMath.reported(s.sog)?String.format(Locale.US,"%.1f kn",s.sog):"Unavailable");
        facts.put("COURSE",GevMarineMath.finite(s.cog)?String.format(Locale.US,"%.0f°",s.cog):"Unavailable");
        facts.put("HEADING",GevMarineMath.finite(s.heading)?String.format(Locale.US,"%.0f°",s.heading):"Unavailable");
        facts.put("DESTINATION",s.destination.isEmpty()?"Not reported":s.destination);
        facts.put("LAST AIS POSITION",utc(s.observed));facts.put("FEED STATUS",sourceStatus);
        ShareCardRenderer.share(this,new ShareCardData(s.name,"Last reported AIS vessel location; not a live-video observation.",
            "MARITIME AIS",GevMarineMath.freshness(s.observed,System.currentTimeMillis()),"MARITIME","GLOBAL",1,
            sourceName,"",s.observed>0?s.observed:lastSuccess,s.lat,s.lon,facts,CYAN,
            "AIS reception and timestamps may be delayed or incomplete. Not for navigation or safety decisions."));
    }
    @Override protected void onResume(){super.onResume();if(marineBand!=null)marineBand.start();if(seaWorldMap!=null)seaWorldMap.resume();if(radar!=null)radar.resume();ui.removeCallbacks(publicPoller);ui.postDelayed(publicPoller,60000L);}
    @Override protected void onPause(){if(marineBand!=null)marineBand.stop();if(seaWorldMap!=null)seaWorldMap.pause();if(radar!=null)radar.pause();ui.removeCallbacks(publicPoller);super.onPause();}
    @Override protected void onDestroy(){super.onDestroy();io.shutdownNow();ui.removeCallbacksAndMessages(null);}
}
