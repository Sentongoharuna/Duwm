package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** Shared compositions for Android preview, encoded frames and executable desktop render tests.
 * This renderer does not infer events, fake telemetry or label content independently verified. */
public final class Duwm1728BroadcastLayout {
    public static final int NAVY=0xFF041424,PANEL=0xFF041424,SILVER=0xFFDEE5EF,WHITE=0xFFF5F7FA,
        MUTED=0xFFA0A5AE,RED=0xFFD50000,GREEN=0xFF00C853,AMBER=0xFFFBC02D,CYAN=0xFF00ACC1,
        ORANGE=0xFFFFA000,PURPLE=0xFFB39DDB;
    public interface Painter {
        void rect(float x,float y,float w,float h,int color,float radius);
        void line(float x,float y,float x2,float y2,int color,float thickness);
        void text(String text,float x,float baseline,float size,int color,boolean bold);
        float measure(String text,float size,boolean bold);
        /** Immutable font/locale identity; null safely disables caption caching
         * for adapters whose measurement settings are not explicitly known. */
        default Object captionMeasurementKey(){return null;}
        void clip(float x,float y,float w,float h);void unclip();
    }
    public static final class Cue {
        public final long startMs,endMs;public final String text;
        public Cue(long start,long end,String words){if(start<0||end<=start)throw new IllegalArgumentException("Invalid cue");startMs=start;endMs=end;text=clean(words,500);}
    }
    public static final class Report {
        public String title="",location="",description="",category="FIELD REPORT",reporter="",clock="";
        public String heading="",altitude="",weather="",gps="",provenance="REPORTER ACCOUNT • UNVERIFIED";
        public String composition=Duwm1728BroadcastComposition.FULL;
        /** Edge-bound presentation is opt-in. Existing manual compositions keep
         * their original geometry unless this selection is explicitly enabled. */
        public boolean clearPicture;
        public boolean breakingApproved,coordinatesAllowed;
        /** Structured automatic excerpts use measured display pages inside the
         * source cue. Legacy/manual ticker text keeps its selected marquee. */
        public boolean automaticTickerPages;public int tickerPixelsPerSecond=75;
        /** Automatic selected titles may use two measured static rows. Manual
         * titles retain their existing geometry and presentation. */
        public boolean automaticHeadlineFit;
        /** Real frame observations only. These intervals use the same clock as
         * draw(): original capture time for live preview, clip time for export.
         * Missing, future or expired observations display a neutral state. */
        public boolean automaticSceneTitles;
        public long sceneAtMs=-1,sceneUntilMs=-1;
        public String sceneTitle="",sceneDescription="",sceneSource="",sceneNeutralTitle="RECORDED SCENE";
        /** Already freshness-filtered source measurements. The shared Android
         * adapter supplies these for both live view and original-time export. */
        public boolean measuredSummary;
        public String measuredLocation="",measuredCoordinates="",measuredAccuracy="",measuredHeading="",measuredSpeed="",measuredMovement="",measuredAltitude="",measuredFps="",measuredWeather="";
        public String measuredCoordinateState="",measuredWeatherProvider="",measuredWeatherDescription="",measuredWeatherNumbers="",measuredWeatherTime="";
        public String measuredClockPrefix="RECORDED";
        public double measuredHeadingDegrees=Double.NaN;
        public List<Cue> tickers=new ArrayList<>(),captions=new ArrayList<>();
    }
    public static final class Geometry {
        public final float unit,x,width,headerTop,tagTop,headlineTop,telemetryTop,tickerTop,bottom;
        public final String composition;
        public final boolean headlineVisible,tickerVisible,telemetryVisible,captionVisible;
        public final float tagHeight,headlineHeight,telemetryHeight,tickerHeight,headerBottom;
        public final float captionLeft,captionTop,captionWidth,captionHeight,captionBottom;
        /** The clear presentation never paints this central rectangle. Its
         * bounds reserve subtitle space even between active source cues. */
        public final boolean clearPicture;
        public final float clearSafeLeft,clearSafeTop,clearSafeWidth,clearSafeHeight,clearSafeAreaFraction;
        Geometry(int w,int h,boolean telemetry){this(w,h,telemetry,Duwm1728BroadcastComposition.FULL,0);}
        Geometry(int w,int h,boolean telemetry,String selected,int captionLines){this(w,h,telemetry,selected,captionLines,0);}
        Geometry(int w,int h,boolean telemetry,String selected,int captionLines,int measuredRows){
            clearPicture=false;clearSafeLeft=clearSafeTop=clearSafeWidth=clearSafeHeight=clearSafeAreaFraction=0;
            composition=Duwm1728BroadcastComposition.normalize(selected);
            boolean compact=Duwm1728BroadcastComposition.COMPACT.equals(composition);
            boolean captionsOnly=Duwm1728BroadcastComposition.CAPTIONS.equals(composition);
            unit=Math.min(w,h)/1080f;x=34*unit;width=w-2*x;
            headerTop=Math.max(h*.035f,24*unit);headerBottom=headerTop+66*unit;
            bottom=h-Math.max(h*.045f,26*unit);
            headlineVisible=!captionsOnly;tickerVisible=!captionsOnly;telemetryVisible=!captionsOnly&&telemetry;
            tagHeight=(captionsOnly?36:compact?32:40)*unit;
            headlineHeight=(captionsOnly?0:compact?78:132)*unit;
            telemetryHeight=(telemetryVisible?(measuredRows>0?6+29*measuredRows:compact?32:48):0)*unit;
            tickerHeight=(captionsOnly?0:compact?40:56)*unit;
            tickerTop=bottom-tickerHeight;telemetryTop=tickerTop-telemetryHeight;
            headlineTop=telemetryTop-headlineHeight;tagTop=headlineTop-tagHeight;
            captionWidth=captionWidth(w,h,unit,captionsOnly);captionLeft=(w-captionWidth)/2;
            captionVisible=captionLines>0;
            captionHeight=captionVisible?(captionLines*(captionsOnly?40:36)+(captionsOnly?22:20))*unit:0;
            captionBottom=tagTop-(captionsOnly?20:18)*unit;captionTop=captionBottom-captionHeight;
        }
        Geometry(Duwm1728ClearPictureLayout.Frame frame,String selected,boolean captionActive){
            composition=Duwm1728BroadcastComposition.normalize(selected);clearPicture=true;
            unit=frame.unit;x=frame.x;width=frame.width;headerTop=frame.headerTop;headerBottom=frame.headerBottom;
            bottom=frame.bottom;telemetryTop=frame.measurementTop;tickerTop=frame.bottom;
            headlineTop=tagTop=telemetryTop;tagHeight=headlineHeight=tickerHeight=0;
            headlineVisible=tickerVisible=false;telemetryVisible=frame.measurements;telemetryHeight=frame.measurementHeight;
            captionVisible=captionActive;captionLeft=frame.captionLeft;captionTop=frame.captionTop;
            captionWidth=frame.captionWidth;captionHeight=frame.captionHeight;captionBottom=frame.captionBottom;
            clearSafeLeft=frame.safeLeft;clearSafeTop=frame.safeTop;clearSafeWidth=frame.safeWidth;
            clearSafeHeight=frame.safeHeight;clearSafeAreaFraction=frame.safeAreaFraction;
        }
    }
    /** Colours express report category; only an explicit breaking approval enables red. */
    public static int accent(String category,boolean breakingApproved){
        if(breakingApproved)return RED;
        String tag=clean(category,32).toUpperCase(Locale.ROOT);
        if("WEATHER".equals(tag))return CYAN;
        if("TRAFFIC".equals(tag))return ORANGE;
        if("ENVIRONMENT".equals(tag))return GREEN;
        if("INTERVIEW".equals(tag))return PURPLE;
        return SILVER;
    }
    private static float captionWidth(int w,int h,float unit,boolean captionsOnly){
        return Math.min(w-68*unit,w*(w>h?(captionsOnly?.80f:.73f):.88f));
    }
    public static String clean(String v,int maximum){if(v==null)return "";v=v.replaceAll("[\\p{Cntrl}]+"," ").trim();if(v.length()<=maximum)return v;int end=maximum;if(end>0&&Character.isHighSurrogate(v.charAt(end-1)))end--;return v.substring(0,end);}
    public static Cue active(List<Cue> list,long ms){Cue best=null;if(list!=null)for(Cue c:list)if(c.startMs<=ms&&ms<c.endMs&&(best==null||best.startMs<=c.startMs))best=c;return best;}
    /** Even encoded dimensions; exact requested ratio; never upscales the source. */
    public static int[] dimensions(int sourceW,int sourceH,String ratio){
        if(sourceW<2||sourceH<2)throw new IllegalArgumentException("Invalid source size");
        if("ORIGINAL".equals(ratio))return new int[]{sourceW&~1,sourceH&~1};
        int p,q;if("9:10".equals(ratio)){p=9;q=10;}else if("9:16".equals(ratio)){p=9;q=16;}
        else if("16:9".equals(ratio)){p=16;q=9;}else throw new IllegalArgumentException("Unknown aspect ratio");
        int k=Math.min(sourceW/p,sourceH/q)&~1;if(k<2)throw new IllegalArgumentException("Source too small");return new int[]{p*k,q*k};
    }
    /** Normalised centre crop in upright source space: x,y,width,height. */
    public static float[] crop(int sourceW,int sourceH,int outW,int outH){
        if(sourceW<=0||sourceH<=0||outW<=0||outH<=0)throw new IllegalArgumentException("Invalid frame size");
        float s=sourceW/(float)sourceH,t=outW/(float)outH,cw=s>t?t/s:1f,ch=s>t?1f:s/t;
        return new float[]{(1-cw)/2,(1-ch)/2,cw,ch};
    }
    private static String fit(Painter p,String text,float size,boolean bold,float width){
        if(width<=0)return "";
        String t=clean(text,700);if(p.measure(t,size,bold)<=width)return t;
        if(p.measure("…",size,bold)>width)return "";
        while(!t.isEmpty()&&p.measure(t+"…",size,bold)>width)t=t.substring(0,t.offsetByCodePoints(t.length(),-1));return t+"…";
    }
    private static List<String> wrap(Painter p,String value,float size,boolean bold,float width,int maximum){
        ArrayList<String> result=new ArrayList<>();String remaining=clean(value,700);
        while(!remaining.isEmpty()&&result.size()<maximum){
            if(result.size()==maximum-1){result.add(fit(p,remaining,size,bold,width));break;}
            int end=remaining.length();while(end>0&&p.measure(remaining.substring(0,end),size,bold)>width)end=remaining.offsetByCodePoints(end,-1);
            if(end==0)end=remaining.offsetByCodePoints(0,1);
            if(end<remaining.length()){int space=remaining.lastIndexOf(' ',end);if(space>0)end=space;}
            result.add(remaining.substring(0,end).trim());remaining=remaining.substring(end).trim();
        }return result;
    }
    public static boolean currentScene(Report r,long ms){
        return r.automaticSceneTitles&&r.sceneAtMs>=0&&r.sceneAtMs<=ms&&ms<r.sceneUntilMs
            &&"on-device-image-description".equals(r.sceneSource)
            &&!clean(r.sceneTitle,500).isEmpty()&&!clean(r.sceneDescription,500).isEmpty();
    }
    /** A scene description can be longer than a speech headline. Keep a fixed
     * readable size and visibly abbreviate overflow, without splitting a joined
     * Unicode cluster or shrinking a long model response into unreadable text. */
    static String sceneText(String value){
        String text=clean(value,1000);if(text.length()<=500)return text;
        int end=0;for(int boundary:Duwm1728CaptionPages.clusterEnds(text))if(boundary<=499)end=boundary;else break;
        return text.substring(0,end).trim()+"…";
    }
    static String sceneFit(Painter p,String value,float size,boolean bold,float width,boolean continued){
        String text=sceneText(value);if(width<=0)return "";
        if(!continued&&p.measure(text,size,bold)<=width)return text;
        if(p.measure("…",size,bold)>width)return "";
        String best="";for(int end:Duwm1728CaptionPages.clusterEnds(text)){
            String prefix=text.substring(0,end).trim();if(p.measure(prefix+"…",size,bold)<=width)best=prefix;
        }return best+"…";
    }
    static List<String> sceneRows(Painter p,String value,float size,float width,int maximum){
        if(width<=0)return Collections.emptyList();
        Duwm1728CaptionPages.Plan plan=Duwm1728CaptionPages.plan(p,sceneText(value),size,true,width,maximum);
        if(plan.pages.isEmpty())return Collections.emptyList();
        ArrayList<String> rows=new ArrayList<>(plan.pages.get(0).lines);
        for(int i=0;i<rows.size();i++)rows.set(i,sceneFit(p,rows.get(i),size,true,width,plan.pageCount()>1&&i==rows.size()-1));
        return rows;
    }
    static String joinMeasured(String... values){
        StringBuilder result=new StringBuilder();for(String value:values){String text=clean(value,500);if(text.isEmpty())continue;if(result.length()>0)result.append("  •  ");result.append(text);}return result.toString();
    }
    static void measuredLine(Painter p,String words,float x,float y,float width,float unit,int color){
        if(words.isEmpty())return;float size=20*unit;if(p.measure(words,size,false)>width)size=18*unit;
        p.text(sceneFit(p,words,size,false,width,false),x,y,size,color,false);
    }
    /** Stable second-row columns measured with the actual painter's font. A
     * fixed percentage was too narrow for a complete speed/movement reading
     * with wider system fonts. Reserve the bounded numeric/status formats first;
     * only the descriptive place name yields. These examples size columns only
     * and are never presented as observations. No current value affects bounds. */
    static final class MeasuredSecondRow {
        final float locationWidth,speedLeft,speedWidth,altitudeLeft,altitudeWidth;
        MeasuredSecondRow(float available,float gap,float speed,float altitude){
            speedWidth=Math.min(speed,Math.max(0,available-2*gap));
            altitudeWidth=Math.min(altitude,Math.max(0,available-speedWidth-2*gap));
            locationWidth=Math.max(0,available-speedWidth-altitudeWidth-2*gap);
            speedLeft=locationWidth+gap;altitudeLeft=speedLeft+speedWidth+gap;
        }
    }
    static MeasuredSecondRow measuredSecondRow(Painter p,float available,float unit){
        float size=18*unit,gap=16*unit;
        float speed=measuredReserve(p,size,
                "SPEED 3600.0 km/h  •  STATIONARY",
                "SPEED 3600.0 km/h  •  UNCERTAIN",
                "SPEED UNRELIABLE  •  UNCERTAIN",
                "SPEED UNAVAILABLE  •  UNAVAILABLE");
        float altitude=measuredReserve(p,size,
                "ALT 100000 m WGS84 ±50 m",
                "ALT -12000 m WGS84 ±50 m",
                "ALT 100000 m WGS84 / ACC UNAVAILABLE",
                "ALT -12000 m WGS84 / ACC UNAVAILABLE");
        return new MeasuredSecondRow(available,gap,
                Math.max(available*.34f-gap,speed+2*unit),
                Math.max(available*.32f,altitude+2*unit));
    }
    /** Preview-rate states can be wider than numeric rates. A dedicated fixed
     * cell beside weather leaves the complete compass/heading row readable.
     * The weather formatter already gives descriptive words lower priority
     * than its actual provider, numbers, units and observation time. */
    static final class MeasuredWeatherRow {
        final float weatherWidth,fpsLeft,fpsWidth;
        MeasuredWeatherRow(float available,float gap,float fps){
            fpsWidth=Math.min(fps,Math.max(0,available-gap));fpsLeft=available-fpsWidth;
            weatherWidth=Math.max(0,fpsLeft-gap);
        }
    }
    static MeasuredWeatherRow measuredWeatherRow(Painter p,float available,float unit){
        float fps=measuredReserve(p,18*unit,
                "PREVIEW 1000.0 fps","PREVIEW FPS UNRELIABLE","PREVIEW FPS UNAVAILABLE");
        return new MeasuredWeatherRow(available,16*unit,Math.max(available*.20f,fps+2*unit));
    }
    private static float measuredReserve(Painter p,float size,String... formats){
        float width=0;for(String format:formats)width=Math.max(width,p.measure(format,size,false));return width;
    }
    static String measuredWeather(Painter p,Report report,float width,float unit){
        String provider=clean(report.measuredWeatherProvider,160),description=clean(report.measuredWeatherDescription,300);
        String essentials=joinMeasured(report.measuredWeatherNumbers,report.measuredWeatherTime);
        if(provider.isEmpty()&&essentials.isEmpty())return clean(report.measuredWeather,500);
        String all=joinMeasured(provider,description,essentials);
        if(p.measure(all,18*unit,false)<=width)return all;
        float reserved=p.measure(essentials,18*unit,false)+(essentials.isEmpty()?0:p.measure("  •  ",18*unit,false));
        provider=sceneFit(p,provider,18*unit,false,width-reserved,false);
        String fixed=joinMeasured(provider,essentials);
        float remaining=width-p.measure(fixed,18*unit,false)-p.measure("  •  ",18*unit,false);
        description=sceneFit(p,description,18*unit,false,remaining,false);return joinMeasured(provider,description,essentials);
    }
    static void measuredCompass(Painter p,double heading,float cx,float cy,float unit){
        if(!Double.isFinite(heading))return;double angle=Math.toRadians(heading);float length=10*unit;
        float ex=cx+(float)Math.sin(angle)*length,ey=cy-(float)Math.cos(angle)*length;
        p.line(cx,cy-12*unit,cx,cy-9*unit,MUTED,unit);
        p.line(cx-(float)Math.sin(angle)*6*unit,cy+(float)Math.cos(angle)*6*unit,ex,ey,CYAN,2*unit);
        double a=angle+Math.toRadians(145),b=angle-Math.toRadians(145);
        p.line(ex,ey,ex+(float)Math.sin(a)*6*unit,ey-(float)Math.cos(a)*6*unit,CYAN,2*unit);
        p.line(ex,ey,ex+(float)Math.sin(b)*6*unit,ey-(float)Math.cos(b)*6*unit,CYAN,2*unit);
    }
    public static Geometry draw(Painter p,int width,int height,Report r,long ms){
        if(width<64||height<64)throw new IllegalArgumentException("Canvas too small");
        if(r.clearPicture)return Duwm1728ClearPictureLayout.draw(p,width,height,r,ms);
        String composition=Duwm1728BroadcastComposition.normalize(r.composition);
        boolean compact=Duwm1728BroadcastComposition.COMPACT.equals(composition);
        boolean captionsOnly=Duwm1728BroadcastComposition.CAPTIONS.equals(composition);
        boolean sceneMode=r.automaticSceneTitles,sceneCurrent=currentScene(r,ms);
        String neutral=clean(r.sceneNeutralTitle,80);if(neutral.isEmpty())neutral="RECORDED SCENE";
        String sceneHeading=sceneCurrent?sceneText(r.sceneTitle):neutral;
        String description=sceneMode?(sceneCurrent?sceneText(r.sceneDescription):"Scene description unavailable for this moment."):r.description;
        boolean telemetry=r.measuredSummary||!clean(r.heading,200).isEmpty()||!clean(r.altitude,200).isEmpty()||!clean(r.weather,200).isEmpty()
            ||(r.coordinatesAllowed&&!clean(r.gps,200).isEmpty());
        float unit=Math.min(width,height)/1080f,captionSize=(captionsOnly?32:29)*unit;
        Cue sub=active(r.captions,ms);
        Duwm1728CaptionPages.Plan captionPlan=sub==null?null:Duwm1728CaptionPages.plan(p,sub.text,captionSize,true,captionWidth(width,height,unit,captionsOnly)-32*unit,2);
        Duwm1728CaptionPages.Page captionPage=captionPlan==null?null:captionPlan.pageAt(ms-sub.startMs,sub.endMs-sub.startMs);
        List<String> captionLines=captionPage==null?Collections.emptyList():captionPage.lines;
        if(captionPlan!=null)captionSize=captionPlan.textSize;
        Geometry g=new Geometry(width,height,telemetry,composition,captionPlan==null?0:captionPlan.rows,r.measuredSummary?3:0);float u=g.unit,x=g.x,w=g.width,pad=22*u;
        int accent=accent(r.category,r.breakingApproved);
        String clock=clean(r.clock,120);if(clock.isEmpty())clock="RECORDED";
        float cw=Math.min(w*.47f,Math.max(155*u,p.measure(clock,16*u,false)+28*u)),cx=width-x-cw;
        if(sceneMode){
            float headerWidth=Math.max(1,Math.min(w*.62f,cx-x-16*u));
            p.rect(x,g.headerTop,headerWidth,66*u,PANEL,5*u);p.rect(x,g.headerTop,6*u,66*u,accent,0);
            p.clip(x+16*u,g.headerTop,Math.max(1,headerWidth-30*u),52*u);
            float baseline=g.headerTop+23*u;for(String row:sceneRows(p,sceneHeading,22*u,headerWidth-38*u,2)){
                p.text(row,x+20*u,baseline,22*u,WHITE,true);baseline+=22*u;
            }p.unclip();
            p.clip(x+16*u,g.headerTop+53*u,Math.max(1,headerWidth-30*u),13*u);
            p.text(sceneFit(p,sceneCurrent?"AI SCENE":"SCENE UNAVAILABLE",11*u,true,headerWidth-38*u,false),
                x+20*u,g.headerTop+62*u,11*u,sceneCurrent?SILVER:AMBER,true);p.unclip();
        }else{
            p.rect(x,g.headerTop,282*u,66*u,PANEL,5*u);p.rect(x,g.headerTop,6*u,66*u,accent,0);
            p.clip(x+12*u,g.headerTop,262*u,66*u);
            p.text("DUWM",x+20*u,g.headerTop+35*u,32*u,WHITE,true);
            p.text("WORLD MONITOR",x+20*u,g.headerTop+55*u,14*u,SILVER,true);p.unclip();
        }
        p.rect(cx,g.headerTop,cw,40*u,PANEL,4*u);p.clip(cx+10*u,g.headerTop,cw-20*u,40*u);
        p.text(fit(p,clock,16*u,false,cw-26*u),cx+13*u,g.headerTop+26*u,16*u,SILVER,false);p.unclip();
        String tag=r.breakingApproved?"BREAKING NEWS":clean(r.category,32).toUpperCase(Locale.ROOT);
        if(tag.isEmpty()||(!r.breakingApproved&&tag.contains("BREAKING")))tag="FIELD REPORT";
        float tagSize=(compact||captionsOnly?18:20)*u;
        float tagW=Math.max(195*u,Math.min(w*.53f,p.measure(tag,tagSize,true)+40*u));
        p.rect(x,g.tagTop,tagW,g.tagHeight,r.breakingApproved?RED:NAVY,0);
        if(!r.breakingApproved)p.rect(x,g.tagTop,4*u,g.tagHeight,accent,0);
        p.clip(x+12*u,g.tagTop,tagW-24*u,g.tagHeight);
        p.text(fit(p,tag,tagSize,true,tagW-40*u),x+20*u,g.tagTop+g.tagHeight*.675f,tagSize,r.breakingApproved?WHITE:accent,true);p.unclip();
        if(!sceneMode){
            p.rect(x+tagW,g.tagTop,w-tagW,g.tagHeight,PANEL,0);
            String provenance=clean(r.provenance,180);if(provenance.isEmpty())provenance="REPORTER ACCOUNT • UNVERIFIED";
            p.clip(x+tagW+8*u,g.tagTop,w-tagW-16*u,g.tagHeight);
            p.text(fit(p,provenance,13*u,false,w-tagW-24*u),x+tagW+12*u,g.tagTop+g.tagHeight*.65f,13*u,AMBER,false);p.unclip();
        }
        if(g.headlineVisible){
            p.rect(x,g.headlineTop,w,g.headlineHeight,PANEL,0);p.clip(x+pad,g.headlineTop,w-2*pad,g.headlineHeight);
            float titleSize=(compact?(width>height?30:28):(width>height?40:34))*u,ty=g.headlineTop+(compact?33:44)*u;
            float titleStep=43*u,bylineSize=(compact?17:18)*u,bylineBaseline=g.headlineTop+(compact?62:115)*u;
            boolean separateByline=false;
            List<String> titleRows;
            if(sceneMode){
                titleSize=(compact?22:34)*u;ty=g.headlineTop+(compact?25:40)*u;titleStep=(compact?26:40)*u;
                bylineSize=(compact?14:18)*u;bylineBaseline=g.headlineTop+(compact?72:115)*u;separateByline=compact;
                p.clip(x+pad,g.headlineTop+2*u,w-2*pad,(compact?55:96)*u);
                titleRows=sceneRows(p,description,titleSize,w-2*pad,2);
                for(String row:titleRows){p.text(row,x+pad,ty,titleSize,WHITE,true);ty+=titleStep;}p.unclip();
            }else if(r.automaticHeadlineFit){
                Duwm1728HeadlineFit.Plan title=Duwm1728HeadlineFit.plan(p,r.title,titleSize,compact?22*u:titleSize,w-2*pad,compact?1:2);
                titleRows=title.lines;titleSize=title.textSize;
                if(title.compactWrapped){
                    // Two rows remain inside the same78u panel. The byline has
                    // its own lower band and cannot overlap the headline.
                    ty=g.headlineTop+25*u;titleStep=26*u;bylineSize=14*u;bylineBaseline=g.headlineTop+72*u;
                    separateByline=true;
                    p.clip(x+pad,g.headlineTop+2*u,w-2*pad,55*u);
                }
                for(String row:titleRows){p.text(row,x+pad,ty,titleSize,WHITE,true);ty+=titleStep;}
                if(title.compactWrapped)p.unclip();
            }else{
                titleRows=wrap(p,r.title,titleSize,true,w-2*pad,compact?1:2);
                for(String row:titleRows){p.text(row,x+pad,ty,titleSize,WHITE,true);ty+=titleStep;}
            }
            String byline=clean(r.location,100),reporter=clean(r.reporter,70);
            if(!reporter.isEmpty())byline+=(byline.isEmpty()?"":"  •  ")+reporter;
            if(byline.isEmpty()&&!sceneMode)byline=clean(r.description,140);
            if(separateByline)p.clip(x+pad,g.headlineTop+59*u,w-2*pad,19*u);
            p.text(fit(p,byline,bylineSize,false,w-2*pad),x+pad,bylineBaseline,bylineSize,SILVER,false);
            if(separateByline)p.unclip();p.unclip();
        }
        if(g.telemetryVisible){
            p.rect(x,g.telemetryTop,w,g.telemetryHeight,NAVY,0);p.line(x,g.telemetryTop,x+w,g.telemetryTop,SILVER,u);
            if(r.measuredSummary){
                float available=w-2*pad,left=x+pad;
                String position=joinMeasured(r.coordinatesAllowed?r.measuredCoordinates:r.measuredCoordinateState,r.measuredAccuracy);
                String movement=clean(r.measuredMovement,120);if(movement.startsWith("MOVEMENT "))movement=movement.substring(9);
                String speed=joinMeasured(r.measuredSpeed,movement);
                boolean missing=joinMeasured(r.measuredLocation,position,r.measuredHeading,speed,r.measuredAltitude,r.measuredFps,r.measuredWeather).isEmpty();
                p.clip(x+pad,g.telemetryTop+2*u,w-2*pad,g.telemetryHeight-4*u);
                if(missing)measuredLine(p,"MEASUREMENTS UNAVAILABLE",left,g.telemetryTop+24*u,available,u,CYAN);
                else{
                    measuredLine(p,position,left,g.telemetryTop+24*u,available*.52f-16*u,u,CYAN);
                    measuredCompass(p,r.measuredHeadingDegrees,left+available*.52f+12*u,g.telemetryTop+16*u,u);
                    measuredLine(p,r.measuredHeading,left+available*.52f+30*u,g.telemetryTop+24*u,available*.48f-30*u,u,CYAN);
                    MeasuredSecondRow row=measuredSecondRow(p,available,u);
                    measuredLine(p,r.measuredLocation,left,g.telemetryTop+53*u,row.locationWidth,u,CYAN);
                    measuredLine(p,speed,left+row.speedLeft,g.telemetryTop+53*u,row.speedWidth,u,CYAN);
                    measuredLine(p,r.measuredAltitude,left+row.altitudeLeft,g.telemetryTop+53*u,row.altitudeWidth,u,CYAN);
                    MeasuredWeatherRow footer=measuredWeatherRow(p,available,u);
                    measuredLine(p,measuredWeather(p,r,footer.weatherWidth,u),left,g.telemetryTop+82*u,footer.weatherWidth,u,SILVER);
                    measuredLine(p,r.measuredFps,left+footer.fpsLeft,g.telemetryTop+82*u,footer.fpsWidth,u,CYAN);
                }p.unclip();
            }else{
            ArrayList<String[]> fields=new ArrayList<>();
            if(!clean(r.heading,200).isEmpty())fields.add(new String[]{"HDG",r.heading});
            if(!clean(r.altitude,200).isEmpty())fields.add(new String[]{"ALT",r.altitude});
            if(!clean(r.weather,200).isEmpty())fields.add(new String[]{"WX",r.weather});
            if(r.coordinatesAllowed&&!clean(r.gps,200).isEmpty())fields.add(new String[]{"GPS",r.gps});
            float column=w/Math.max(1,fields.size());int i=0;
            for(String[] f:fields){float fx=x+pad+i++*column,available=column-pad*1.5f;
                p.clip(fx,g.telemetryTop,available,g.telemetryHeight);
                if(compact){
                    float labelWidth=p.measure(f[0]+"  ",11*u,true);
                    p.text(f[0],fx,g.telemetryTop+21*u,11*u,MUTED,true);
                    p.text(fit(p,f[1],16*u,false,available-labelWidth),fx+labelWidth,g.telemetryTop+22*u,16*u,CYAN,false);
                }else{
                    p.text(f[0],fx,g.telemetryTop+14*u,11*u,MUTED,true);
                    p.text(fit(p,f[1],22*u,false,available),fx,g.telemetryTop+41*u,22*u,CYAN,false);
                }p.unclip();
            }
            }
        }
        if(g.tickerVisible){
            p.rect(x,g.tickerTop,w,g.tickerHeight,NAVY,0);p.line(x,g.tickerTop,x+w,g.tickerTop,SILVER,u);
            Cue c=active(r.tickers,ms);
            float label=(compact?95:115)*u,baseline=g.tickerTop+(compact?27:36)*u;
            p.rect(x,g.tickerTop,label,g.tickerHeight,accent,0);
            p.clip(x+10*u,g.tickerTop,label-20*u,g.tickerHeight);
            p.text(sceneMode&&c==null?"SCENE":"UPDATE",x+(compact?12:15)*u,baseline,(compact?17:20)*u,r.breakingApproved?WHITE:NAVY,true);p.unclip();
            String tick=c==null?(sceneMode?neutral:clean(description,500)):c.text;if(tick.isEmpty()&&!sceneMode)tick=clean(r.title,500);
            if(!tick.isEmpty()){
                float start=x+label+16*u,available=w-label-30*u,size=(compact?20:23)*u;
                p.clip(start,g.tickerTop,available,g.tickerHeight);
                if(sceneMode&&c==null){
                    p.text(sceneFit(p,tick,size,false,available,false),start,baseline,size,WHITE,false);
                }else if(r.automaticTickerPages&&c!=null){
                    // A fixed-speed marquee can change cues before its tail
                    // enters the frame. Each measured page fits completely;
                    // its time is display policy, never a new speech timestamp.
                    Duwm1728CaptionPages.Plan pages=Duwm1728CaptionPages.plan(p,tick,size,false,available,1);
                    Duwm1728CaptionPages.Page page=pages.pageAt(ms-c.startMs,c.endMs-c.startMs);
                    if(page!=null)for(String row:page.lines)p.text(row,start,baseline,pages.textSize,WHITE,false);
                }else{
                    float period=p.measure(tick,size,false)+96*u;
                    float speed=Math.max(20,Math.min(180,r.tickerPixelsPerSecond))*u;
                    float shift=(Math.max(0,ms-(c==null?0:c.startMs))/1000f*speed)%period;
                    for(float tx=start-shift;tx<start+available;tx+=period)p.text(tick,tx,baseline,size,WHITE,false);
                }
                p.unclip();
            }
        }
        float outlineTop=captionsOnly?g.tagTop:g.headlineTop;
        p.line(x,outlineTop,x+w,outlineTop,SILVER,1.2f*u);p.line(x,outlineTop,x,g.bottom,SILVER,1.4f*u);
        p.line(x+w,outlineTop,x+w,g.bottom,SILVER,1.4f*u);p.line(x,g.bottom,x+w,g.bottom,SILVER,u);
        if(g.captionVisible){
            p.rect(g.captionLeft,g.captionTop,g.captionWidth,g.captionHeight,0xE4041424,6*u);
            p.clip(g.captionLeft+16*u,g.captionTop,g.captionWidth-32*u,g.captionHeight);
            float baseline=g.captionTop+(captionsOnly?38:35)*u;
            for(String row:captionLines){p.text(row,(width-p.measure(row,captionSize,true))/2,baseline,captionSize,WHITE,true);baseline+=(captionsOnly?40:36)*u;}p.unclip();
        }
        return g;
    }
}
