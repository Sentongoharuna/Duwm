package com.sentongoharuna.worldsituationroom;

import java.util.Collections;
import java.util.ArrayList;
import java.util.List;
import static com.sentongoharuna.worldsituationroom.Duwm1728BroadcastLayout.*;

/** Fixed edge graphics for a clear camera picture. This class only presents
 * supplied observations: it neither detects subjects nor crops source pixels.
 * Geometry depends on frame dimensions and the explicit measurement selection,
 * never on title length, field availability, caption pages or clock contents. */
public final class Duwm1728ClearPictureLayout {
    private Duwm1728ClearPictureLayout(){}

    /** Bounds are expressed in output pixels. The central safe rectangle is a
     * promise of this painter; a separately requested picture inset is outside
     * this class's responsibilities. Two subtitle rows are always reserved. */
    public static final class Frame {
        public final float unit,x,width,headerTop,headerBottom,titleWidth,clockLeft,clockWidth,clockHeight;
        public final float bottom,measurementTop,measurementHeight;
        public final float captionLeft,captionTop,captionWidth,captionHeight,captionBottom;
        public final float safeLeft,safeTop,safeWidth,safeHeight,safeAreaFraction;
        public final boolean measurements;
        Frame(int w,int h,boolean showMeasurements){
            if(w<64||h<64)throw new IllegalArgumentException("Canvas too small");
            unit=Math.min(w,h)/1080f;x=34*unit;width=w-2*x;
            headerTop=Math.max(h*.018f,20*unit);headerBottom=headerTop+66*unit;
            clockWidth=320*unit;clockHeight=44*unit;clockLeft=w-x-clockWidth;
            titleWidth=Math.min(680*unit,clockLeft-x-20*unit);
            bottom=h-Math.max(h*.02f,22*unit);measurements=showMeasurements;
            measurementHeight=showMeasurements?93*unit:0;measurementTop=bottom-measurementHeight;
            captionWidth=Math.min(width,w*(w>h?.73f:.88f));captionLeft=(w-captionWidth)/2;
            captionHeight=92*unit;captionBottom=measurementTop-14*unit;captionTop=captionBottom-captionHeight;
            safeLeft=x;safeTop=headerBottom+14*unit;safeWidth=width;
            safeHeight=Math.max(0,captionTop-14*unit-safeTop);
            safeAreaFraction=safeWidth*safeHeight/(w*(float)h);
        }
    }
    public static Frame geometry(int width,int height,boolean measurements){return new Frame(width,height,measurements);}

    public static Duwm1728BroadcastLayout.Geometry draw(Painter painter,int width,int height,Report report,long ms){
        Frame frame=new Frame(width,height,report.measuredSummary);float u=frame.unit;
        Cue caption=active(report.captions,ms);
        Duwm1728CaptionPages.Plan captions=caption==null?null:Duwm1728CaptionPages.plan(painter,caption.text,29*u,true,frame.captionWidth-32*u,2);
        Duwm1728CaptionPages.Page page=captions==null?null:captions.pageAt(ms-caption.startMs,caption.endMs-caption.startMs);
        List<String> captionRows=page==null?Collections.emptyList():page.lines;
        Duwm1728BroadcastLayout.Geometry result=new Duwm1728BroadcastLayout.Geometry(frame,report.composition,!captionRows.isEmpty());

        boolean observed=currentScene(report,ms);
        String neutral=clean(report.sceneNeutralTitle,80);if(neutral.isEmpty())neutral="RECORDED SCENE";
        String title=report.automaticSceneTitles?(observed?sceneText(report.sceneTitle):neutral):sceneText(report.title);
        if(title.isEmpty())title=neutral;
        painter.rect(frame.x,frame.headerTop,frame.titleWidth,66*u,PANEL,5*u);
        painter.rect(frame.x,frame.headerTop,4*u,66*u,SILVER,0);
        painter.clip(frame.x+16*u,frame.headerTop,frame.titleWidth-32*u,52*u);
        float baseline=frame.headerTop+23*u;
        for(String row:sceneRows(painter,title,22*u,frame.titleWidth-38*u,2)){
            painter.text(row,frame.x+20*u,baseline,22*u,WHITE,true);baseline+=22*u;
        }
        painter.unclip();
        String source=report.automaticSceneTitles?(observed?"AI SCENE":"SCENE UNAVAILABLE"):"TITLE";
        painter.clip(frame.x+16*u,frame.headerTop+53*u,frame.titleWidth-32*u,13*u);
        painter.text(sceneFit(painter,source,11*u,true,frame.titleWidth-38*u,false),frame.x+20*u,frame.headerTop+62*u,11*u,observed?SILVER:MUTED,true);
        painter.unclip();

        String clock=clean(report.clock,120);if(clock.isEmpty())clock=report.measuredSummary?"UTC UNAVAILABLE":"RECORDED";
        painter.rect(frame.clockLeft,frame.headerTop,frame.clockWidth,frame.clockHeight,PANEL,4*u);
        painter.clip(frame.clockLeft+10*u,frame.headerTop,frame.clockWidth-20*u,frame.clockHeight);
        Duwm1728CaptionPages.Plan clockPlan=Duwm1728CaptionPages.plan(painter,clock,16*u,false,frame.clockWidth-26*u,2);
        List<String> clockRows=clockPlan.pages.isEmpty()?Collections.emptyList():new ArrayList<>(clockPlan.pages.get(0).lines);
        // Keep a source clock's timezone with the time it qualifies. A wider
        // system font can otherwise place just "UTC" on the second row even
        // when the complete time/timezone and elapsed recording value fit there.
        // This only chooses a line break; clock text, size and card stay fixed.
        if(clockRows.size()==2){
            String first=clockRows.get(0),second=clockRows.get(1);
            int split=first.lastIndexOf(' ');
            if(split>0){
                String token=first.substring(split+1),joined=token+" "+second;
                boolean utc=token.matches("[0-9]{2}:[0-9]{2}:[0-9]{2}")
                        &&(second.equals("UTC")||second.startsWith("UTC "));
                boolean elapsed=(token.equals("REC")||token.equals("VIEW"))
                        &&second.matches("[0-9]+:[0-9]{2}:[0-9]{2}(?: .*)?");
                if((utc||elapsed)&&painter.measure(joined,16*u,false)<=frame.clockWidth-26*u){
                    clockRows.set(0,first.substring(0,split).trim());clockRows.set(1,joined);
                }
            }
        }
        baseline=frame.headerTop+(clockRows.size()>1?17:27)*u;
        for(int index=0;index<clockRows.size();index++){
            String row=sceneFit(painter,clockRows.get(index),16*u,false,frame.clockWidth-26*u,clockPlan.pageCount()>1&&index==clockRows.size()-1);
            painter.text(row,frame.clockLeft+13*u,baseline,16*u,SILVER,false);baseline+=18*u;
        }
        painter.unclip();

        if(frame.measurements)drawMeasurements(painter,frame,report);
        if(!captionRows.isEmpty()){
            painter.rect(frame.captionLeft,frame.captionTop,frame.captionWidth,frame.captionHeight,0xE4041424,6*u);
            painter.clip(frame.captionLeft+16*u,frame.captionTop,frame.captionWidth-32*u,frame.captionHeight);
            baseline=frame.captionTop+35*u;
            for(String row:captionRows){
                painter.text(row,(width-painter.measure(row,captions.textSize,true))/2,baseline,captions.textSize,WHITE,true);baseline+=36*u;
            }
            painter.unclip();
        }
        return result;
    }

    /** Same independent cells and readable minimum size as the measured /21/2
     * presentation. Long place/condition strings yield before numeric readings,
     * units, provider and model observation time. No numeric fallback is added. */
    private static void drawMeasurements(Painter painter,Frame frame,Report report){
        float u=frame.unit,pad=22*u,left=frame.x+pad,available=frame.width-2*pad,top=frame.measurementTop;
        painter.rect(frame.x,top,frame.width,frame.measurementHeight,NAVY,0);
        painter.line(frame.x,top,frame.x+frame.width,top,SILVER,u);
        String position=joinMeasured(report.coordinatesAllowed?report.measuredCoordinates:report.measuredCoordinateState,report.measuredAccuracy);
        String movement=clean(report.measuredMovement,120);if(movement.startsWith("MOVEMENT "))movement=movement.substring(9);
        String speed=joinMeasured(report.measuredSpeed,movement);
        boolean missing=joinMeasured(report.measuredLocation,position,report.measuredHeading,speed,report.measuredAltitude,report.measuredFps,report.measuredWeather).isEmpty();
        painter.clip(left,top+2*u,available,frame.measurementHeight-4*u);
        if(missing)measurementLine(painter,"MEASUREMENTS UNAVAILABLE",left,top+24*u,available,u,CYAN);
        else{
            measurementLine(painter,position,left,top+24*u,available*.52f-16*u,u,CYAN);
            measuredCompass(painter,report.measuredHeadingDegrees,left+available*.52f+12*u,top+16*u,u);
            measurementLine(painter,report.measuredHeading,left+available*.52f+30*u,top+24*u,available*.48f-30*u,u,CYAN);
            MeasuredSecondRow second=measuredSecondRow(painter,available,u);
            measurementLine(painter,report.measuredLocation,left,top+53*u,second.locationWidth,u,CYAN);
            measurementLine(painter,speed,left+second.speedLeft,top+53*u,second.speedWidth,u,CYAN);
            measurementLine(painter,report.measuredAltitude,left+second.altitudeLeft,top+53*u,second.altitudeWidth,u,CYAN);
            MeasuredWeatherRow footer=measuredWeatherRow(painter,available,u);
            measurementLine(painter,measuredWeather(painter,report,footer.weatherWidth,u),left,top+82*u,footer.weatherWidth,u,SILVER);
            measurementLine(painter,report.measuredFps,left+footer.fpsLeft,top+82*u,footer.fpsWidth,u,CYAN);
        }
        painter.unclip();
    }
    private static void measurementLine(Painter painter,String value,float x,float y,float width,float unit,int color){
        if(value.isEmpty())return;
        // A reading changing digit count must not make the whole field pulse.
        float size=18*unit;painter.text(sceneFit(painter,value,size,false,width,false),x,y,size,color,false);
    }
}
