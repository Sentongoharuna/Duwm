package com.sentongoharuna.worldsituationroom;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.graphics.YuvImage;
import android.graphics.ImageFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaRecorder;
import android.media.AudioManager;
import android.media.AudioDeviceInfo;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaFormat;
import android.os.Build;
import android.util.Range;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.security.MessageDigest;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/** MONITORS CAM: direct camera-to-recorder clean master, with separately stored telemetry.
 * Recording opens the shared broadcast review/export path. Clean TextureView frames also
 * feed the real on-device ML Kit image describer. Scene observations are stored alongside
 * the master; no JPEG intermediates or pre-burned panels enter the camera recording.
 * Model preparation is automatic on supported devices and has no server-address form.
 */
@SuppressWarnings("deprecation")
public final class Duwm1718MonitorsCamActivity extends Activity implements TextureView.SurfaceTextureListener, SensorEventListener {
    private static final int NAVY=DuwmUnifiedTheme.APPROVED_NAVY;
    private static final int TEXT=DuwmUnifiedTheme.TEXT, MUTED=DuwmUnifiedTheme.MUTED;
    // Camera hardware and Canvas input support vary by device. Both ratios are EXACT
    // encoded pixel ratios, not merely letterboxing the preview widget.
    private int outputW=1080,outputH=1920,outputFps=30,outputBitrate=16_000_000;
    private int nativeVideoW=1920,nativeVideoH=1080,mediaRotation;
    private Duwm1728AspectFrame viewfinder;
    private boolean recorderOwnsCamera;
    private static final String VIDEO_SETTINGS="duwm1724_video_settings";
    private static final String KEY_RATIO="ratio",KEY_QUALITY="quality";
    private static final String KEY_MEASURE_LOCATION="measured_location_enabled",KEY_MEASURE_COORDINATES="measured_coordinates_export";
    private int ratioIndex=0,qualityIndex=0; // 0 = 9:10 portrait; 1 = 16:9 landscape
    private int actualSourceWidth=0,actualSourceHeight=0;
    private TextView aspectButton,qualityButton,recordingProfile;
    private static final int REQ_LEGACY_GALLERY=1824;
    private static final int REQ_CAMERA=1818,REQ_LOCATION=1819;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService frames=Executors.newSingleThreadExecutor();
    private final AtomicBoolean processing=new AtomicBoolean();
    private final AtomicReference<Bitmap> latest=new AtomicReference<>();
    private final Object surfaceLock=new Object();
    private Camera camera; private MediaRecorder recorder; private Surface recorderSurface;
    private ScheduledExecutorService videoClock;
    private TextureView preview; private TextView indicator,telemetry,recordButton;
    private TextView sceneStatus;
    private Duwm1728LiveSceneView sceneOverlay;
    private Duwm1728SceneAnalyzer sceneAnalyzer;
    private Duwm1728SceneAnalyzer.State sceneState=Duwm1728SceneAnalyzer.State.PAUSED;
    private String sceneDetail="Preparing on-device scene descriptions";
    private Duwm1728SceneTimeline.Entry liveScene;
    private final java.util.List<Duwm1728SceneTimeline.Entry> sceneSamples=new java.util.ArrayList<>();
    private long sceneClockStart,sceneFrameAt=-1L;
    private int[] sceneReferencePixels;
    private static final int SCENE_MAX_SAMPLES=500;
    private final Runnable sceneRefresh=new Runnable(){@Override public void run(){
        if(closed||!cameraUiActive)return;
        updateScenePreview();sampleSceneFrame();main.postDelayed(this,750L);
    }};
    // 1728.2/7: UI-only measured health, independent from the encoder and newsroom text.
    private Duwm1728CaptureHealthView captureHealthDock;
    private boolean cameraUiActive;
    private volatile long decodedFrameAt=-1L;
    private volatile int cameraSessionGeneration;
    private final java.util.concurrent.atomic.AtomicInteger decodedFrameCount=new java.util.concurrent.atomic.AtomicInteger();
    private String captureFailure="", microphoneFailure="", galleryMessage="";
    private long microphoneSampleAt=-1L, galleryCompletedAt=-1L;
    private int microphonePeak=-1, galleryResult=0, compassAccuracy=-1;
    private boolean weatherRequested, weatherLoading;
    private String weatherFailure="";
    private View previewGrid; private boolean showGrid=false;
    private ScaleGestureDetector scaleGesture;
    private float tapDownX,tapDownY;
    private boolean gestureScaled;
    private LinearLayout reportDetails; private TextView detailsToggle;
    private EditText placeInput,situationInput,reporterInput;
    private CheckBox preciseLocation,measurementCoordinates,audioEnabled;
    private Duwm1728MeasurementSources measurementSources;
    private final Duwm1728PreviewRate previewRate=new Duwm1728PreviewRate();
    private final java.util.List<Duwm1728Measurements.Sample> measurementSamples=new java.util.ArrayList<>();
    private Duwm1728Measurements.Sample liveMeasurements;
    private long lastMeasurementSample=-1000L,recordingStartUtc;
    private boolean bakedCoordinates,locationRequestPending,cameraRequestPending;
    private SensorManager sensorManager; private LocationManager locationManager;
    private volatile Location lastLocation;
    private boolean recording,closed,finished,locationActive;
    private volatile float heading=-1f;
    private volatile long lastHeadingAt=0L;
    private volatile long weatherReceivedAt=0L;
    private volatile double weatherLat=999d,weatherLon=999d;
    private String lastFile="";
    private static final String CLIP_RECEIPTS="duwm1721_camera_receipts";
    private static final String RECEIPT_LATEST="latest";
    private static final String[] CATEGORIES={"GENERAL","WEATHER","TRANSPORT","PUBLIC SAFETY","ENVIRONMENT","EYEWITNESS"};
    private int categoryIndex=0;private String bakedCategory="GENERAL";
    private static final String[] REPORT_OVERLAYS={"STANDARD","BREAKING NEWS","WEATHER REPORT","FIELD REPORT"};
    private int reportOverlayIndex=0;
    private String bakedOverlay="STANDARD";
    private boolean torchEnabled=false,nightModeEnabled=false;
    private String selectedWhiteBalance="AUTO";
    private boolean videoStabilizationEnabled=false;
    private int selectedMicrophoneId=-1;
    private int audioProcessingMode=0; // 0 standard mic, 1 voice-recognition, 2 voice-communication
    private int cameraEngineMode=0; // 0 currently verified HD/Pro engine, 1 optional UHD, 2 60 fps
    private static final String[] ADVANCED_CAPTURE_MODES={"STANDARD", "4K CAPABILITY-CHECKED", "60 FPS CAPABILITY-CHECKED"};
    private TextView categoryControl;
    private volatile boolean pendingGallerySave;
    private final java.util.List<Duwm1728TelemetryTimeline.Point> telemetrySamples=new java.util.ArrayList<>();
    private long lastSampleElapsed=-2000L;
    private TextView prompterDisplay;
    private String prompterScript="";
    private boolean showPrompter=false;
    private int prompterOffset=0;
    private final Runnable prompterScroll=new Runnable(){@Override public void run(){
        if(!closed && showPrompter && recording && prompterDisplay!=null){
            prompterOffset=Math.min(prompterScript.length(),prompterOffset+2);
            prompterDisplay.setText(prompterScript.substring(prompterOffset));
            main.postDelayed(this,600);
        }
    }};
    private volatile String bakedReporter="",bakedPlace="",bakedSituation="";
    private volatile boolean bakedPrecise;
    private long startedAt,lastFrameAt;
    private final java.util.concurrent.atomic.AtomicInteger sourceFrames=new java.util.concurrent.atomic.AtomicInteger();
    private int cameraId=0,cameraFacing=Camera.CameraInfo.CAMERA_FACING_BACK,rotate=90,previewWidth=640,previewHeight=480,limitSeconds=60,recordedFrames;
    private final Runnable telemetryRefresh=new Runnable(){@Override public void run(){if(closed||!cameraUiActive)return;displayTelemetry();refreshCaptureHealth();main.postDelayed(this,500);}};
    private final LocationListener gpsListener=new LocationListener(){
        @Override public void onLocationChanged(Location value){acceptLocation(value);}
        @Override public void onProviderEnabled(String provider){if(cameraUiActive)requestLocation();}
        @Override public void onProviderDisabled(String provider){
            if(lastLocation!=null&&provider.equals(lastLocation.getProvider()))lastLocation=null;
            if(cameraUiActive)displayTelemetry();
        }
        @Override public void onStatusChanged(String provider,int status,Bundle extras){}
    };
    private int dp(float x){return Math.round(getResources().getDisplayMetrics().density*x);}
    private GradientDrawable outline(){GradientDrawable d=new GradientDrawable();d.setColor(NAVY);d.setCornerRadius(dp(14));d.setStroke(dp(1),DuwmUnifiedTheme.BORDER);return d;}
    private TextView txt(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextColor(TEXT);t.setTextSize(sp);t.setGravity(Gravity.CENTER_VERTICAL);t.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));return t;}
    private TextView action(String label,Runnable a){TextView t=txt(label,12);t.setGravity(Gravity.CENTER);t.setBackground(outline());t.setMinHeight(dp(48));t.setOnClickListener(v->a.run());return t;}
    private LinearLayout.LayoutParams mp(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(7);return p;}
    @Override public void onCreate(Bundle b){super.onCreate(b);
        ratioIndex=getSharedPreferences(VIDEO_SETTINGS,MODE_PRIVATE).getInt(KEY_RATIO,2);if(ratioIndex<0||ratioIndex>2)ratioIndex=2;
        qualityIndex=getSharedPreferences(VIDEO_SETTINGS,MODE_PRIVATE).getInt(KEY_QUALITY,1);updateProfile();
        setRequestedOrientation(ratioIndex==1?ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE:ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
        getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(NAVY);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        cameraId=findCamera(Camera.CameraInfo.CAMERA_FACING_BACK);if(cameraId<0)cameraId=0;
        sensorManager=(SensorManager)getSystemService(SENSOR_SERVICE);locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
        measurementSources=new Duwm1728MeasurementSources(getApplicationContext(),()->{if(cameraUiActive&&!closed)displayTelemetry();});
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setBackgroundColor(NAVY);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(10),0,dp(10),0);
        sceneStatus=txt("SCENE AI • PREPARING",13);sceneStatus.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));sceneStatus.setTag("scene-ai-status");sceneStatus.setOnClickListener(v->showSceneStatus());header.addView(sceneStatus,new LinearLayout.LayoutParams(0,dp(42),1));
        header.addView(action("WORLD",this::finish),new LinearLayout.LayoutParams(dp(70),dp(40)));page.addView(header);
        LinearLayout tools=new LinearLayout(this);tools.setPadding(dp(8),0,dp(8),dp(4));
        aspectButton=action(ratioName(),this::switchRatio);qualityButton=action(qualityIndex==0?"HD":"PRO",this::chooseRecordingMode);detailsToggle=action("SETTINGS",this::showCameraSettings);
        for(TextView t:new TextView[]{aspectButton,qualityButton,detailsToggle}){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(42),1);lp.setMargins(dp(3),0,dp(3),0);tools.addView(t,lp);}page.addView(tools);
        FrameLayout outer=new FrameLayout(this);outer.setBackgroundColor(NAVY);viewfinder=new Duwm1728AspectFrame(this);viewfinder.setRatio(outputW/(float)outputH);
        outer.addView(viewfinder,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));preview=new TextureView(this);preview.setSurfaceTextureListener(this);
        preview.setContentDescription("Camera viewfinder. Tap to focus, pinch to zoom. The selected crop is used for broadcast export.");viewfinder.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        scaleGesture=new ScaleGestureDetector(this,new ScaleGestureDetector.SimpleOnScaleGestureListener(){@Override public boolean onScale(ScaleGestureDetector g){gestureScaled=true;return scaleCamera(g.getScaleFactor());}});
        preview.setOnTouchListener((v,e)->{if(e.getActionMasked()==MotionEvent.ACTION_DOWN){tapDownX=e.getX();tapDownY=e.getY();gestureScaled=false;}scaleGesture.onTouchEvent(e);
            if(e.getActionMasked()==MotionEvent.ACTION_UP&&!gestureScaled&&Math.abs(e.getX()-tapDownX)<dp(22)&&Math.abs(e.getY()-tapDownY)<dp(22)){focusOnce();v.performClick();}return true;});
        previewGrid=new View(this){final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);@Override protected void onDraw(Canvas c){if(!showGrid)return;paint.setColor(0x80DEE5EF);paint.setStrokeWidth(dp(1));for(int i=1;i<3;i++){c.drawLine(getWidth()*i/3f,0,getWidth()*i/3f,getHeight(),paint);c.drawLine(0,getHeight()*i/3f,getWidth(),getHeight()*i/3f,paint);}}};
        viewfinder.addView(previewGrid,new FrameLayout.LayoutParams(-1,-1));
        sceneOverlay=new Duwm1728LiveSceneView(this);sceneOverlay.setTag("scene-ai-overlay");viewfinder.addView(sceneOverlay,new FrameLayout.LayoutParams(-1,-1));
        indicator=txt("CAMERA INITIALISING",10);indicator.setSingleLine(true);indicator.setPadding(dp(9),0,dp(9),0);indicator.setBackgroundColor(NAVY);
        telemetry=txt("",10);telemetry.setVisibility(View.GONE); // detailed telemetry lives in settings, not over the picture
        prompterDisplay=txt("",17);prompterDisplay.setGravity(Gravity.CENTER);prompterDisplay.setBackgroundColor(0xC0041424);prompterDisplay.setVisibility(View.GONE);viewfinder.addView(prompterDisplay,new FrameLayout.LayoutParams(-1,dp(90),Gravity.CENTER));
        page.addView(outer,new LinearLayout.LayoutParams(-1,0,1));
        page.addView(indicator,new LinearLayout.LayoutParams(-1,dp(25)));
        recordingProfile=txt(profileLabel(),10);recordingProfile.setGravity(Gravity.CENTER);page.addView(recordingProfile,new LinearLayout.LayoutParams(-1,dp(23)));
        captureHealthDock=new Duwm1728CaptureHealthView(this);page.addView(captureHealthDock,new LinearLayout.LayoutParams(-1,dp(46)));
        LinearLayout dock=new LinearLayout(this);dock.setGravity(Gravity.CENTER);dock.setPadding(dp(12),dp(6),dp(12),dp(10));
        TextView gallery=action("GALLERY",()->{if(!recording)startActivity(new Intent(this,Duwm1726GalleryLibraryActivity.class));});
        TextView flip=action("FLIP",this::flipCamera);recordButton=action("● REC",this::toggleRecording);recordButton.setTextSize(19);recordButton.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        GradientDrawable rec=new GradientDrawable();rec.setColor(0xFFD50000);rec.setCornerRadius(dp(34));rec.setStroke(dp(2),0xFFDEE5EF);recordButton.setBackground(rec);recordButton.setContentDescription("Start recording; press again to stop and produce a broadcast");
        dock.addView(gallery,new LinearLayout.LayoutParams(0,dp(50),1));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(dp(96),dp(62));rp.setMargins(dp(18),0,dp(18),0);dock.addView(recordButton,rp);dock.addView(flip,new LinearLayout.LayoutParams(0,dp(50),1));page.addView(dock);
        reportDetails=new LinearLayout(this);reportDetails.setOrientation(LinearLayout.VERTICAL);reportDetails.setPadding(dp(14),dp(12),dp(14),dp(16));
        reporterInput=input("Reporter / ID (self-reported)","WORLD MONITOR REPORTER");reportDetails.addView(reporterInput,mp());
        placeInput=input("City / place (self-reported)","");reportDetails.addView(placeInput,mp());
        situationInput=input("Situation / eyewitness description","");
        situationInput.setSingleLine(false);situationInput.setMinLines(2);situationInput.setMaxLines(4);
        situationInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE |
                android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        reportDetails.addView(situationInput,mp());
        preciseLocation=new CheckBox(this);
        preciseLocation.setText("Automatic location, movement, altitude and weather");
        preciseLocation.setTextColor(TEXT);preciseLocation.setButtonTintList(
                android.content.res.ColorStateList.valueOf(DuwmUnifiedTheme.BORDER));
        preciseLocation.setChecked(getSharedPreferences(VIDEO_SETTINGS,MODE_PRIVATE).getBoolean(KEY_MEASURE_LOCATION,true));
        preciseLocation.setOnCheckedChangeListener((button,checked)->{
            getSharedPreferences(VIDEO_SETTINGS,MODE_PRIVATE).edit().putBoolean(KEY_MEASURE_LOCATION,checked)
                .putBoolean("measurement_location_permission_requested",!checked).apply();
            if(checked)requestLocation();else stopLocation();
            displayTelemetry();
        });reportDetails.addView(preciseLocation,mp());
        measurementCoordinates=new CheckBox(this);measurementCoordinates.setText("Show coordinates in preview and automatic video");
        measurementCoordinates.setTextColor(TEXT);measurementCoordinates.setButtonTintList(android.content.res.ColorStateList.valueOf(DuwmUnifiedTheme.BORDER));
        measurementCoordinates.setChecked(getSharedPreferences(VIDEO_SETTINGS,MODE_PRIVATE).getBoolean(KEY_MEASURE_COORDINATES,true));
        measurementCoordinates.setOnCheckedChangeListener((button,checked)->{
            getSharedPreferences(VIDEO_SETTINGS,MODE_PRIVATE).edit().putBoolean(KEY_MEASURE_COORDINATES,checked).apply();displayTelemetry();
        });reportDetails.addView(measurementCoordinates,mp());
        audioEnabled=new CheckBox(this);audioEnabled.setText("Microphone audio (permission required)");
        audioEnabled.setTextColor(TEXT);audioEnabled.setChecked(true);
        audioEnabled.setButtonTintList(android.content.res.ColorStateList.valueOf(DuwmUnifiedTheme.BORDER));
        reportDetails.addView(audioEnabled,mp());
        categoryControl=action("REPORT CATEGORY  /  GENERAL  ▸",this::nextCategory);
        reportDetails.addView(categoryControl,mp());
        reportDetails.addView(txt("Location names and Open-Meteo model weather refresh automatically from an available location. Weather shows its provider and observation time. GPS precision follows Android permission.",10),mp());
        reportDetails.addView(action("CAMERA / SENSOR / PRIVACY READINESS",this::showReadiness),mp());
        LinearLayout proTools=new LinearLayout(this);proTools.setOrientation(LinearLayout.HORIZONTAL);
        TextView evDown=action("EXPOSURE −",()->adjustExposure(-1));
        TextView evUp=action("EXPOSURE +",()->adjustExposure(1));
        for(TextView t:new TextView[]{evDown,evUp}){
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(46),1);lp.rightMargin=dp(5);
            proTools.addView(t,lp);
        }
        reportDetails.addView(proTools,mp());
        reportDetails.addView(action("WHITE BALANCE  /  DEVICE CONTROL",this::cycleWhiteBalance),mp());
        reportDetails.addView(action("LOW LIGHT  /  DEVICE MODE",this::toggleNightMode),mp());
        reportDetails.addView(action("TORCH  /  DEVICE FLASH",this::toggleTorch),mp());
        reportDetails.addView(action("BROADCAST STYLE / APPLIED AFTER REVIEW",this::cycleOverlayTemplate),mp());
        reportDetails.addView(action("CAMERA CAPABILITIES / HDR / HIGH-SPEED / LENSES",this::showAdvancedCameraCapabilities),mp());
        reportDetails.addView(action("RECORDING MODE / HD, PRO, 4K, 60 FPS",this::chooseRecordingMode),mp());
        reportDetails.addView(action("STABILIZATION / DEVICE VIDEO MODE",this::toggleVideoStabilization),mp());
        reportDetails.addView(action("CAMERA LENS / SWITCH AVAILABLE CAMERA IDS",this::switchPhysicalCamera),mp());
        reportDetails.addView(action("AUDIO INPUT / SELECT MICROPHONE",this::chooseMicrophone),mp());
        reportDetails.addView(action("AUDIO PROCESSING / STANDARD OR SPEECH",this::chooseAudioProcessing),mp());
        reportDetails.addView(action("SLOW MOTION / TIMELAPSE / HDR SUPPORT",this::showSpecialCaptureModes),mp());
        reportDetails.addView(action("TELEPROMPTER / SCRIPT & DISPLAY",this::editTeleprompter),mp());
        reportDetails.addView(txt("The teleprompter guides the reporter in preview; it is NOT burned into recorded footage.",10),mp());
        reportDetails.addView(action("PREVIEW GRID ON / OFF",()->{
            showGrid=!showGrid;if(previewGrid!=null)previewGrid.invalidate();
        }),mp());
        reportDetails.addView(action("RECORDING LENGTH",this::setDuration),mp());
        reportDetails.addView(action("LATEST VIDEO SHA-256 RECEIPT",this::showCaptureReceipt),mp());
        reportDetails.addView(action("MY SAVED GALLERY VIDEOS",()->startActivity(new Intent(this,Duwm1726GalleryLibraryActivity.class))),mp());
        reportDetails.addView(txt("Sensor data is measured only when available. Reporter descriptions are unverified. Overlay encoding depends on phone hardware.",10),mp());

        reportDetails.addView(telemetry,mp());telemetry.setVisibility(View.VISIBLE);
        reportDetails.addView(action("HD / PRO QUALITY",this::switchQuality),mp());
        setContentView(page);
        if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){cameraRequestPending=true;requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAMERA);}
    }
    private String ratioName(){return ratioIndex==0?"9:10":ratioIndex==1?"16:9":"9:16";}
    private void showCameraSettings(){if(recording){note("Stop recording before changing the camera setup");return;}
        if(reportDetails.getParent() instanceof android.view.ViewGroup)((android.view.ViewGroup)reportDetails.getParent()).removeView(reportDetails);
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(NAVY);scroll.addView(reportDetails);
        new AlertDialog.Builder(this).setTitle("Camera & reporting settings").setView(scroll).setPositiveButton("DONE",null).show();
    }

    private EditText input(String hint,String value){EditText x=new EditText(this);x.setSingleLine(true);x.setTextSize(14);x.setTextColor(TEXT);x.setHintTextColor(MUTED);x.setHint(hint);x.setText(value);x.setPadding(dp(13),0,dp(13),0);x.setBackground(outline());x.setMinHeight(dp(49));return x;}
    private int findCamera(int facing){for(int i=0;i<Camera.getNumberOfCameras();i++){Camera.CameraInfo info=new Camera.CameraInfo();Camera.getCameraInfo(i,info);if(info.facing==facing)return i;}return Camera.getNumberOfCameras()>0?0:-1;}
    @Override protected void onResume(){super.onResume();cameraUiActive=true;
        if(measurementSources!=null)measurementSources.resume();
        ensureSceneAnalyzer();sceneAnalyzer.resume();main.removeCallbacks(sceneRefresh);main.post(sceneRefresh);
        main.removeCallbacks(telemetryRefresh);main.post(telemetryRefresh);
        if(preciseLocation!=null&&preciseLocation.isChecked())requestLocation();
        Sensor rv=sensorManager==null?null:sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        if(rv!=null)sensorManager.registerListener(this,rv,SensorManager.SENSOR_DELAY_UI);
        if(preview!=null&&preview.isAvailable())openCamera();}
    private void openCamera(){if(camera!=null||recording||closed||checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED||preview==null||!preview.isAvailable())return;
        captureFailure="";decodedFrameAt=-1;cameraSessionGeneration++;
        resetSceneSession();sceneClockStart=SystemClock.elapsedRealtime();sceneFrameAt=-1L;previewRate.reset();liveMeasurements=null;
        if(sceneOverlay!=null)sceneOverlay.clearMeasurements();
        try{camera=Camera.open(cameraId);Camera.CameraInfo info=new Camera.CameraInfo();Camera.getCameraInfo(cameraId,info);cameraFacing=info.facing;
            Camera.Parameters p=camera.getParameters();java.util.List<Camera.Size> videoSizes=p.getSupportedVideoSizes();if(videoSizes==null)videoSizes=p.getSupportedPreviewSizes();
            int targetW=cameraEngineMode==1?3840:qualityIndex==0?1280:1920,targetH=cameraEngineMode==1?2160:qualityIndex==0?720:1080;
            nativeVideoW=0;nativeVideoH=0;for(Camera.Size size:videoSizes)if(size.width==targetW&&size.height==targetH){nativeVideoW=size.width;nativeVideoH=size.height;break;}
            if(nativeVideoW==0){for(Camera.Size size:videoSizes)if(Math.abs(size.width/(double)size.height-16.0/9.0)<.02&&size.width>nativeVideoW){nativeVideoW=size.width;nativeVideoH=size.height;}}
            if(nativeVideoW==0)throw new IllegalStateException("No supported 16:9 clean-master profile");
            Camera.Size best=null;long bestScore=Long.MAX_VALUE;for(Camera.Size size:p.getSupportedPreviewSizes()){
                long score=Math.abs((long)size.width*size.height-Math.min((long)nativeVideoW*nativeVideoH,1920L*1080));score+=(long)(Math.abs(size.width/(double)size.height-16.0/9.0)*10000000);if(score<bestScore){best=size;bestScore=score;}}
            if(best!=null){previewWidth=best.width;previewHeight=best.height;p.setPreviewSize(best.width,best.height);}
            actualSourceWidth=nativeVideoW;actualSourceHeight=nativeVideoH;p.setPreviewFormat(ImageFormat.NV21);p.setRecordingHint(true);
            if(p.getSupportedFocusModes()!=null&&p.getSupportedFocusModes().contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO))p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
            if(videoStabilizationEnabled&&p.isVideoStabilizationSupported())p.setVideoStabilization(true);
            java.util.List<int[]> ranges=p.getSupportedPreviewFpsRange();int[] selected=null;if(ranges!=null)for(int[] range:ranges)if(range[0]<=outputFps*1000&&range[1]>=outputFps*1000&&(selected==null||(range[1]-range[0])<(selected[1]-selected[0])))selected=range;
            if(selected!=null)p.setPreviewFpsRange(selected[0],selected[1]);camera.setParameters(p);
            int display=getWindowManager().getDefaultDisplay().getRotation(),degrees=display==Surface.ROTATION_90?90:display==Surface.ROTATION_180?180:display==Surface.ROTATION_270?270:0;
            mediaRotation=info.facing==Camera.CameraInfo.CAMERA_FACING_FRONT?(info.orientation+degrees)%360:(info.orientation-degrees+360)%360;
            rotate=mediaRotation;int displayRotation=info.facing==Camera.CameraInfo.CAMERA_FACING_FRONT?(360-mediaRotation)%360:mediaRotation;
            camera.setDisplayOrientation(displayRotation);camera.setPreviewTexture(preview.getSurfaceTexture());camera.setPreviewCallbackWithBuffer(this::acceptFrame);
            camera.addCallbackBuffer(new byte[previewWidth*previewHeight*3/2]);camera.addCallbackBuffer(new byte[previewWidth*previewHeight*3/2]);camera.startPreview();applyViewfinderAspect();indicator.setText("READY  •  CLEAN MASTER "+nativeVideoW+"×"+nativeVideoH);
        }catch(Exception e){releaseCamera();captureFailure=safe(e);indicator.setText("CAMERA UNAVAILABLE • "+safe(e));refreshCaptureHealth();}
    }
    private void ensureSceneAnalyzer(){
        if(sceneAnalyzer!=null)return;
        sceneAnalyzer=new Duwm1728SceneAnalyzer(getApplicationContext(),new Duwm1728SceneAnalyzer.Listener(){
            @Override public void onStatus(Duwm1728SceneAnalyzer.State state,String detail){
                if(closed)return;sceneState=state;sceneDetail=detail;
                if(sceneStatus!=null){
                    String label=state==Duwm1728SceneAnalyzer.State.ANALYZING?"DESCRIBING":
                        state==Duwm1728SceneAnalyzer.State.CHECKING?"CHECKING":
                        state==Duwm1728SceneAnalyzer.State.DOWNLOADING?"PREPARING MODEL":
                        state==Duwm1728SceneAnalyzer.State.WAITING?"WAITING":
                        state==Duwm1728SceneAnalyzer.State.READY?"READY":
                        state==Duwm1728SceneAnalyzer.State.UNAVAILABLE?"UNAVAILABLE":"PAUSED";
                    sceneStatus.setText("SCENE AI • "+label);
                    sceneStatus.setContentDescription("Camera scene AI: "+detail+". Tap for status.");
                }
            }
            @Override public void onScene(Duwm1728SceneTimeline.Entry entry){
                if(closed||!cameraUiActive||camera==null)return;
                long now=sceneSourceTime();
                if(entry==null||entry.atMs>now||entry.validUntilMs<=now)return;
                liveScene=entry;
                if(recording&&sceneSamples.size()<SCENE_MAX_SAMPLES){
                    expireRecordedSceneAt(entry.atMs);
                    if(sceneSamples.isEmpty()||sceneSamples.get(sceneSamples.size()-1).atMs<entry.atMs)
                        sceneSamples.add(entry);
                }
                updateScenePreview();
            }
        });
    }
    private long sceneSourceTime(){return Math.max(0L,SystemClock.elapsedRealtime()-(recording?startedAt:sceneClockStart));}
    private void resetSceneSession(){
        liveScene=null;sceneReferencePixels=null;
        if(sceneAnalyzer!=null)sceneAnalyzer.resetSession();
        updateScenePreview();
    }
    private void updateScenePreview(){
        if(sceneOverlay==null)return;
        long at=sceneSourceTime();
        if(liveScene!=null&&(at<liveScene.atMs||at>=liveScene.validUntilMs))liveScene=null;
        sceneOverlay.update(liveScene,at,recording);
    }
    private void expireRecordedSceneAt(long boundary){
        if(sceneSamples.isEmpty())return;
        int last=sceneSamples.size()-1;Duwm1728SceneTimeline.Entry previous=sceneSamples.get(last);
        if(boundary>previous.atMs&&boundary<previous.validUntilMs)
            sceneSamples.set(last,new Duwm1728SceneTimeline.Entry(previous.atMs,boundary,
                previous.title,previous.description,previous.source));
    }
    private void sampleSceneFrame(){
        if(sceneAnalyzer==null||camera==null||preview==null||!preview.isAvailable()||pendingGallerySave)return;
        long now=SystemClock.elapsedRealtime();
        // Only a freshly presented camera frame may enter vision. UI screenshots,
        // placeholders and the overlaid scene text never enter this TextureView.
        if(sceneFrameAt<0||now-sceneFrameAt>1500L||(recording&&sceneFrameAt<startedAt)
                ||preview.getWidth()<2||preview.getHeight()<2)return;
        if(!sceneAnalyzer.canRequest()&&liveScene==null&&sceneState!=Duwm1728SceneAnalyzer.State.ANALYZING)return;
        Bitmap fingerprint=null,frame=null;
        try{
            fingerprint=preview.getBitmap(24,24);
            if(fingerprint==null)return;
            int[] pixels=new int[24*24];fingerprint.getPixels(pixels,0,24,0,0,24,24);
            long sourceAt=sceneSourceTime();
            if(Duwm1728SceneChangePolicy.changed(sceneReferencePixels,pixels)){
                // This metric only withdraws an obsolete observation. All words
                // still originate from a successful ML Kit model response.
                if(recording)expireRecordedSceneAt(sourceAt);
                resetSceneSession();
            }
            if(!sceneAnalyzer.canRequest())return;
            float scale=Math.min(1f,640f/Math.max(preview.getWidth(),preview.getHeight()));
            int w=Math.max(2,Math.round(preview.getWidth()*scale)),h=Math.max(2,Math.round(preview.getHeight()*scale));
            frame=preview.getBitmap(w,h);if(frame==null)return;
            // Legacy front-camera preview is mirrored; the recorder's clean
            // master is not. Undo that mirror before asking for a description.
            if(cameraFacing==Camera.CameraInfo.CAMERA_FACING_FRONT){
                Matrix unmirror=new Matrix();unmirror.setScale(-1f,1f);
                Bitmap upright=Bitmap.createBitmap(frame,0,0,frame.getWidth(),frame.getHeight(),unmirror,true);
                if(upright!=frame){frame.recycle();frame=upright;}
            }
            Bitmap owned=frame;frame=null;
            if(sceneAnalyzer.request(owned,sourceAt))sceneReferencePixels=pixels;
        }catch(RuntimeException error){
            android.util.Log.w("DUWM-SCENE","Camera frame not available for scene analysis",error);
        }finally{
            if(fingerprint!=null&&!fingerprint.isRecycled())fingerprint.recycle();
            if(frame!=null&&!frame.isRecycled())frame.recycle();
        }
    }
    private void showSceneStatus(){
        new AlertDialog.Builder(this).setTitle("Camera scene understanding")
            .setMessage(sceneDetail+"\n\nDUWM automatically prepares the on-device image model on supported phones. "
                +"Clean camera images supply the descriptions; speech and location do not invent scene text. "
                +"Descriptions update from sampled frames and expire when old. Keep DUWM open while it works. "
                +"No server address or AI key is required.")
            .setPositiveButton("CLOSE",null).show();
    }
    /** Keep the preview picture at the selected recorded aspect (no stretched faces). */
    private void applyViewfinderAspect(){if(preview==null)return;preview.post(()->{int w=preview.getWidth(),h=preview.getHeight();if(w<1||h<1)return;
        int sw=rotate%180==0?previewWidth:previewHeight,sh=rotate%180==0?previewHeight:previewWidth;float scale=Math.max(w/(float)sw,h/(float)sh);
        Matrix transform=new Matrix();transform.setScale(sw*scale/w,sh*scale/h,w/2f,h/2f);preview.setTransform(transform);});}
    private void acceptFrame(byte[] data,Camera src){
        if(src!=camera||closed||data==null)return;decodedFrameAt=SystemClock.elapsedRealtime();decodedFrameCount.incrementAndGet();sourceFrames.incrementAndGet();
        try{src.addCallbackBuffer(data);}catch(RuntimeException ignored){}
    }
    private void flipCamera(){if(recording)return;int f=cameraFacing==Camera.CameraInfo.CAMERA_FACING_FRONT?Camera.CameraInfo.CAMERA_FACING_BACK:Camera.CameraInfo.CAMERA_FACING_FRONT;int id=findCamera(f);if(id<0)return;releaseCamera();cameraId=id;openCamera();}
    private void zoomCamera(){if(recording||camera==null)return;try{Camera.Parameters p=camera.getParameters();if(!p.isZoomSupported()){note("Zoom not supported");return;}p.setZoom((p.getZoom()+Math.max(1,p.getMaxZoom()/8))%(p.getMaxZoom()+1));camera.setParameters(p);}catch(Exception e){note("Zoom unavailable");}}
    private boolean scaleCamera(float factor){
        if(recording||camera==null)return false;
        try{
            Camera.Parameters settings=camera.getParameters();
            if(!settings.isZoomSupported())return false;
            int maximum=settings.getMaxZoom();if(maximum<=0)return false;
            int previous=settings.getZoom();
            // Avoid jumping across the whole device zoom range in one gesture.
            int jump=Math.max(1,Math.min(3,Math.round(Math.abs(factor-1f)*maximum*0.6f)));
            int target=Math.max(0,Math.min(maximum,previous+(factor>=1f?jump:-jump)));
            if(target!=previous){settings.setZoom(target);camera.setParameters(settings);
                indicator.setText("● CAMERA READY / PINCH ZOOM "+target+" / "+maximum);
            }
            return true;
        }catch(RuntimeException unsupported){note("Pinch zoom unavailable on this camera");return false;}
    }
    private void focusOnce(){
        if(recording){note("Focus is locked while recording");return;}
        if(camera==null){note("Camera is not available");return;}
        try{
            Camera.Parameters p=camera.getParameters();
            if(p.getSupportedFocusModes()==null||!p.getSupportedFocusModes().contains(Camera.Parameters.FOCUS_MODE_AUTO)){
                note("Manual focus not supported on this camera");return;
            }
            p.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);camera.setParameters(p);
            camera.autoFocus((success,c)->main.post(()->indicator.setText(success?
                    "● FOCUS CONFIRMED  /  DEVICE CAMERA":"● AUTOFOCUS NOT CONFIRMED")));
        }catch(RuntimeException e){note("Device autofocus unavailable");}
    }
    private void adjustExposure(int direction){
        if(recording){note("Exposure locked while recording");return;}
        if(camera==null){note("Camera unavailable");return;}
        try{
            Camera.Parameters p=camera.getParameters();
            int min=p.getMinExposureCompensation(),max=p.getMaxExposureCompensation();
            if(min==0&&max==0){note("Exposure adjustment unsupported");return;}
            int target=Math.max(min,Math.min(max,p.getExposureCompensation()+direction));
            p.setExposureCompensation(target);camera.setParameters(p);
            indicator.setText("● CAMERA READY  /  EXPOSURE "+target+" / "+min+".."+max);
        }catch(RuntimeException e){note("Exposure adjustment unavailable on this camera");}
    }
    /** Only enable a feature when the opened camera reports it as supported. */
    private void cycleWhiteBalance(){
        if(recording||camera==null){note("Stop recording and open the camera first");return;}
        try{
            Camera.Parameters p=camera.getParameters();java.util.List<String> modes=p.getSupportedWhiteBalance();
            if(modes==null||modes.size()<2){note("This camera has no alternate white-balance modes");return;}
            int index=modes.indexOf(p.getWhiteBalance());
            String next=modes.get((index+1+modes.size())%modes.size());
            p.setWhiteBalance(next);camera.setParameters(p);selectedWhiteBalance=next;
            indicator.setText("● WHITE BALANCE / "+next.toUpperCase(Locale.US));
        }catch(RuntimeException ex){note("White balance not supported on this device");}
    }
    private void toggleNightMode(){
        if(recording||camera==null){note("Change low-light mode before recording");return;}
        try{
            Camera.Parameters p=camera.getParameters();java.util.List<String> modes=p.getSupportedSceneModes();
            if(modes==null||!modes.contains(Camera.Parameters.SCENE_MODE_NIGHT)){
                note("This camera does not advertise a native night scene mode");return;
            }
            nightModeEnabled=!nightModeEnabled;
            p.setSceneMode(nightModeEnabled?Camera.Parameters.SCENE_MODE_NIGHT:Camera.Parameters.SCENE_MODE_AUTO);
            camera.setParameters(p);indicator.setText(nightModeEnabled?"● DEVICE NIGHT MODE ON":"● DEVICE NIGHT MODE OFF");
        }catch(RuntimeException ex){nightModeEnabled=false;note("Native low-light mode unavailable");}
    }
    private void toggleTorch(){
        if(recording||camera==null){note("Torch cannot change while recording on this camera engine");return;}
        try{
            Camera.Parameters p=camera.getParameters();java.util.List<String> modes=p.getSupportedFlashModes();
            if(modes==null||!modes.contains(Camera.Parameters.FLASH_MODE_TORCH)){
                note("No camera torch available");return;
            }
            torchEnabled=!torchEnabled;
            p.setFlashMode(torchEnabled?Camera.Parameters.FLASH_MODE_TORCH:Camera.Parameters.FLASH_MODE_OFF);
            camera.setParameters(p);indicator.setText(torchEnabled?"● TORCH ON":"● TORCH OFF");
        }catch(RuntimeException ex){torchEnabled=false;note("Torch unsupported by current camera");}
    }
    private void cycleOverlayTemplate(){
        if(recording){note("Cannot change permanent video graphics during recording");return;}
        reportOverlayIndex=(reportOverlayIndex+1)%REPORT_OVERLAYS.length;
        note("Permanent MP4 graphic / "+REPORT_OVERLAYS[reportOverlayIndex]);
    }
    private void showAdvancedCameraCapabilities(){
        String report=Duwm1728CameraCapabilities.inspect(this);
        new AlertDialog.Builder(this).setTitle("Camera2 hardware & encoder capability report")
          .setMessage(report+"\n\nThis is hardware discovery only: not proof that the legacy Canvas recording engine can achieve 4K, 60 FPS or HDR.")
          .setPositiveButton("CLOSE",null).show();
    }
    /** A mode is selectable only when camera frames AND the H.264 encoder declare enough capacity.
     * This does NOT claim successful capture until an actual file is inspected on a device. */
    private boolean codecSupports(int width,int height,int fps){
        try{
            MediaCodecList list=new MediaCodecList(MediaCodecList.REGULAR_CODECS);
            for(MediaCodecInfo info:list.getCodecInfos()){
                if(!info.isEncoder())continue;
                for(String type:info.getSupportedTypes()){
                    if(!"video/avc".equalsIgnoreCase(type))continue;
                    MediaCodecInfo.VideoCapabilities v=info.getCapabilitiesForType(type).getVideoCapabilities();
                    if(v!=null&&v.areSizeAndRateSupported(width,height,(double)fps))return true;
                }
            }
        }catch(Exception ex){android.util.Log.w("DUWM-CAM","Encoder capability query failed",ex);}
        return false;
    }
    private boolean cameraPreviewSupports(int width,int height,int fps){
        if(camera==null)return false;
        try{
            Camera.Parameters p=camera.getParameters();boolean pixels=false,rates=false;
            for(Camera.Size size:p.getSupportedPreviewSizes()){
                if((long)size.width*size.height>=(long)width*height){pixels=true;break;}
            }
            java.util.List<int[]> ranges=p.getSupportedPreviewFpsRange();
            if(ranges!=null)for(int[] r:ranges)if(r!=null&&r.length>=2&&r[0]<=fps*1000&&r[1]>=fps*1000){rates=true;break;}
            return pixels&&rates;
        }catch(RuntimeException ex){return false;}
    }
    private void chooseRecordingMode(){
        if(recording||pendingGallerySave){note("Stop the current recording first");return;}
        if(camera==null){note("Open the camera before selecting an advanced recording mode");return;}
        final String[] modes={"STANDARD / current aspect and quality", "UHD 4K / 3840×2160 30 FPS (landscape)",
                "60 FPS / current aspect and quality"};
        new AlertDialog.Builder(this).setTitle("Recording profile (device-dependent)")
          .setItems(modes,(dialog,index)->{
              if(index==1&&(ratioIndex!=1||!cameraPreviewSupports(3840,2160,30)||!codecSupports(3840,2160,30))){
                  note("4K mode unavailable: landscape, camera preview and H.264 encoder support required");return;
              }
              if(index==2&&(!cameraPreviewSupports(outputW,outputH,60)||!codecSupports(outputW,outputH,60))){
                  note("60 FPS unavailable for the current camera and recording resolution");return;
              }
              cameraEngineMode=index;
              applyRequestedCaptureMode();
              if(camera!=null){releaseCamera();openCamera();}
              if(recordingProfile!=null)recordingProfile.setText(profileLabel());
              note(index==0?"Standard mode selected": "Advanced mode requested; recording and actual MP4 FPS must still be verified");
          }).show();
    }
    private void applyRequestedCaptureMode(){
        if(cameraEngineMode==1){outputW=3840;outputH=2160;outputFps=30;outputBitrate=45_000_000;}
        else if(cameraEngineMode==2){outputFps=60;outputBitrate=Math.max(outputBitrate,18_000_000);}
    }
    private void toggleVideoStabilization(){
        if(camera==null||recording){note("Open camera and stop recording before changing stabilisation");return;}
        try{
            Camera.Parameters p=camera.getParameters();
            if(!p.isVideoStabilizationSupported()){note("Device does not provide legacy-camera video stabilization");return;}
            boolean enable=!p.getVideoStabilization();p.setVideoStabilization(enable);
            camera.setParameters(p);videoStabilizationEnabled=camera.getParameters().getVideoStabilization();
            note(videoStabilizationEnabled?"Device video stabilization ON":"Device video stabilization OFF");
        }catch(RuntimeException ex){videoStabilizationEnabled=false;note("Stabilization request rejected by the camera");}
    }
    private void switchPhysicalCamera(){
        if(recording){note("Stop recording before switching lenses");return;}
        int n=Camera.getNumberOfCameras();if(n<2){note("Only one independently addressable camera is available");return;}
        String[] choices=new String[n];
        for(int i=0;i<n;i++){Camera.CameraInfo info=new Camera.CameraInfo();Camera.getCameraInfo(i,info);
            choices[i]="Camera "+i+" / "+(info.facing==Camera.CameraInfo.CAMERA_FACING_FRONT?"FRONT":"BACK")+
                (i==cameraId?" / SELECTED":"");}
        new AlertDialog.Builder(this).setTitle("Cameras independently exposed by Android")
           .setItems(choices,(d,which)->{if(which!=cameraId){releaseCamera();cameraId=which;openCamera();}}).show();
    }
    private AudioDeviceInfo[] audioInputs(){
        AudioManager manager=(AudioManager)getSystemService(AUDIO_SERVICE);
        return manager==null?new AudioDeviceInfo[0]:manager.getDevices(AudioManager.GET_DEVICES_INPUTS);
    }
    private void chooseMicrophone(){
        if(recording){note("Stop recording before selecting a microphone");return;}
        AudioDeviceInfo[] inputs=audioInputs();String[] labels=new String[inputs.length+1];labels[0]="SYSTEM DEFAULT";
        for(int i=0;i<inputs.length;i++)labels[i+1]=
            "INPUT "+inputs[i].getId()+" / "+inputs[i].getProductName()+" / type "+inputs[i].getType();
        new AlertDialog.Builder(this).setTitle("Choose recording audio input")
          .setItems(labels,(d,i)->{selectedMicrophoneId=i==0?-1:inputs[i-1].getId();
              note(i==0?"System-default microphone selected":"Requested microphone: "+labels[i]);}).show();
    }
    private void chooseAudioProcessing(){
        if(recording){note("Stop recording to change audio input processing");return;}
        String[] modes={"STANDARD MICROPHONE / no special processing request",
            "VOICE RECOGNITION / voice-oriented input", "VOICE COMMUNICATION / platform may apply noise processing"};
        new AlertDialog.Builder(this).setTitle("Device audio capture profile")
          .setItems(modes,(d,i)->{audioProcessingMode=i;note(modes[i]+"; actual noise reduction is device-controlled");}).show();
    }
    private void showSpecialCaptureModes(){
        String desc="Slow motion needs genuinely high-frame-rate samples and adjusted media timestamps. " +
          "Time lapse needs time-controlled sample timestamps. " +
          "10-bit HDR requires a compatible Camera2 dynamic-range capture pipeline and HDR encoder. " +
          "This recording path does not supply those complete recording paths; they remain DISABLED, " +
          "even when the camera advertises related hardware capabilities.";
        new AlertDialog.Builder(this).setTitle("Advanced capture: not yet recordable")
          .setMessage(desc).setPositiveButton("CLOSE",null).show();
    }
    private void applyRecorderAudio(){
        if(!audioEnabled.isChecked()||recorder==null)return;
        int src=audioProcessingMode==1?MediaRecorder.AudioSource.VOICE_RECOGNITION:
            audioProcessingMode==2?MediaRecorder.AudioSource.VOICE_COMMUNICATION:MediaRecorder.AudioSource.MIC;
        recorder.setAudioSource(src);
        if(Build.VERSION.SDK_INT>=28&&selectedMicrophoneId>=0){
            boolean routed=false;
            for(AudioDeviceInfo device:audioInputs()){
                if(device.getId()==selectedMicrophoneId){routed=recorder.setPreferredDevice(device);break;}
            }
            if(!routed)throw new IllegalStateException("Selected microphone is no longer available");
        }
    }
    private void nextCategory(){if(recording){note("Stop recording to change report category");return;}categoryIndex=(categoryIndex+1)%CATEGORIES.length;categoryControl.setText("REPORT CATEGORY  /  "+CATEGORIES[categoryIndex]+"  ▸");}
    private void showCaptureReceipt(){String entry=getSharedPreferences(CLIP_RECEIPTS,MODE_PRIVATE).getString(RECEIPT_LATEST,"");
        if(entry.isEmpty()){note("No completed video receipt stored on this phone");return;}
        new AlertDialog.Builder(this).setTitle("Local capture receipt / not independently verified")
            .setMessage(entry+"\n\nSHA-256 identifies the locally recorded bytes at the time of capture. It does not prove the scene or report is authentic.")
            .setNegativeButton("CLOSE",null).setPositiveButton("SHARE TEXT",(d,w)->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,"DUWM local capture receipt\n"+entry+"\nNot independently verified");startActivity(Intent.createChooser(i,"Share capture receipt"));}).show();
    }
    private void saveCaptureReceipt(File completed,String captureName,long elapsedMillis,int framesMade,String reportCategory,boolean includedPrecise){
        final android.content.Context application=getApplicationContext();
        final int sceneCount=sceneSamples.size();
        new Thread(()->{try(FileInputStream input=new FileInputStream(completed)){
            MessageDigest digest=MessageDigest.getInstance("SHA-256");byte[] buffer=new byte[32768];int len;
            while((len=input.read(buffer))!=-1)digest.update(buffer,0,len);
            StringBuilder hex=new StringBuilder();for(byte b:digest.digest())hex.append(String.format(Locale.US,"%02x",b&0xff));
            String receipt="FILE  "+captureName+"\nUTC RECEIPT  "+utc()+"\nDURATION  "+(elapsedMillis/1000)+" sec\nFRAMES  "+framesMade+
                    "\nSIZE  "+completed.length()+" bytes\nREPORT TYPE  "+reportCategory+
                    " (SELF-REPORTED)\nPRECISE GPS SIDECAR  "+(includedPrecise?"USER OPTED IN":"NO")+
                    "\nAI SCENE OBSERVATIONS  "+sceneCount+"\nAI SOURCE  "+
                    (sceneCount>0?"ML Kit on-device image descriptions":"No model description returned")+
                    "\nSHA-256  "+hex.toString();
            application.getSharedPreferences(CLIP_RECEIPTS,MODE_PRIVATE).edit().putString(RECEIPT_LATEST,receipt).apply();
        }catch(Exception ex){android.util.Log.w("DUWM-CAM","Capture fingerprint unavailable",ex);}},"duwm1721-private-mp4-sha256").start();
    }
    private void updateProfile(){
        int shortEdge=qualityIndex==0?720:1080;outputW=ratioIndex==1?(qualityIndex==0?1280:1920):shortEdge;
        outputH=ratioIndex==0?(qualityIndex==0?800:1200):ratioIndex==1?shortEdge:(qualityIndex==0?1280:1920);
        outputFps=30;outputBitrate=qualityIndex==0?8_000_000:16_000_000;applyRequestedCaptureMode();
    }
    private String profileLabel(){return ratioName()+"  •  "+outputW+"×"+outputH+" BROADCAST  •  "+outputFps+" FPS REQUEST";}
    private void switchRatio(){if(recording||pendingGallerySave){note("Stop recording first");return;}
        final String[] choices={"9:10","16:9","9:16"};new AlertDialog.Builder(this).setTitle("Broadcast aspect ratio").setSingleChoiceItems(choices,ratioIndex,(dialog,index)->{
            ratioIndex=index;cameraEngineMode=0;getSharedPreferences(VIDEO_SETTINGS,MODE_PRIVATE).edit().putInt(KEY_RATIO,index).apply();updateProfile();viewfinder.setRatio(outputW/(float)outputH);
            aspectButton.setText(ratioName());recordingProfile.setText(profileLabel());setRequestedOrientation(index==1?ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE:ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
            if(camera!=null){releaseCamera();openCamera();}applyViewfinderAspect();dialog.dismiss();}).show();}
    private void switchQuality(){
        if(recording||pendingGallerySave){note("Stop recording before changing quality");return;}
        cameraEngineMode=0;
        qualityIndex=1-qualityIndex;
        getSharedPreferences(VIDEO_SETTINGS,MODE_PRIVATE).edit().putInt(KEY_QUALITY,qualityIndex).apply();
        updateProfile();if(qualityButton!=null)qualityButton.setText("QUALITY / "+(qualityIndex==0?"HD":"PRO"));
        if(recordingProfile!=null)recordingProfile.setText(profileLabel());
        if(camera!=null){releaseCamera();openCamera();}
        note(qualityIndex==1?"PRO requests higher resolution and needs a capable device":"HD uses a lighter encoding profile");
    }
    private boolean hasAdequateCameraSource(){
        int wantedWidth=cameraEngineMode==1?3840:qualityIndex==0?1280:1920;
        int wantedHeight=cameraEngineMode==1?2160:qualityIndex==0?720:1080;
        return nativeVideoW>=wantedWidth&&nativeVideoH>=wantedHeight;
    }
    private void setDuration(){if(recording)return;final String[] options={"15 seconds","30 seconds","60 seconds","3 minutes","5 minutes"};final int[] seconds={15,30,60,180,300};new AlertDialog.Builder(this).setTitle("Maximum video length").setItems(options,(d,w)->{limitSeconds=seconds[w];recordButton.setText("● REC");}).show();}
    private void toggleRecording(){if(recording){stopRecording(true);return;}if(pendingGallerySave){note("Previous recording is saving");return;}if(camera==null){note("Camera not ready");return;}
        if(Duwm1724GalleryPublisher.needsLegacyPermission(this)){requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},REQ_LEGACY_GALLERY);return;}
        if(!hasAdequateCameraSource()||!codecSupports(nativeVideoW,nativeVideoH,outputFps)){note("Selected profile is not supported. Choose HD or another exposed camera; no quality is faked.");return;}
        if(audioEnabled.isChecked()&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_CAMERA);note("Allow microphone, then press Record. Silent recording can be selected in settings.");return;}
        startRecording();
    }
    private String compass(){return heading>=0f&&compassAccuracy>=SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM&&lastHeadingAt>0L&&SystemClock.elapsedRealtime()-lastHeadingAt<3000L?String.format(Locale.US,"%.0f° MAG",heading):"UNAVAILABLE";}
    private String gpsAccuracy(){Location l=lastLocation;return locationFresh(l)&&l.hasAccuracy()?String.format(Locale.US,"±%.0f m",l.getAccuracy()):"UNAVAILABLE";}
    private String sourceWeather(){
        if(liveMeasurements==null)return "MODEL WX UNAVAILABLE";
        return Duwm1728Measurements.display(liveMeasurements,sceneSourceTime(),coordinatesAllowed()).weather;
    }
    private String readiness(){
        String cameraState=camera!=null&&decodedFrameAt>0&&SystemClock.elapsedRealtime()-decodedFrameAt<3000?"READY":"UNAVAILABLE";
        String mic=audioEnabled.isChecked()?(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED?"ON / PERMITTED":"PERMISSION REQUIRED"):"OFF";
        String gps=preciseLocation.isChecked()?(locationFresh(lastLocation)?"ON / SENSOR "+gpsAccuracy():"ON / WAITING FOR FRESH SENSOR"):"WITHHELD";
        return "CAMERA  "+cameraState+"\nVIDEO  "+profileLabel()+"\nINPUT  "+actualSourceWidth+"×"+actualSourceHeight+" (native video size)\nGALLERY  Movies / "+Duwm1724GalleryPublisher.ALBUM+"\nMICROPHONE  "+mic+"\nPRECISE GPS  "+gps+"\nDEVICE COMPASS  "+compass()+"\nWEATHER  "+sourceWeather()+"\nREPORTER / PLACE / SITUATION  SELF-REPORTED";
    }
    private void showReadiness(){new AlertDialog.Builder(this).setTitle("MONITORS CAM / Measured source status")
      .setMessage(readiness()+"\n\nLocation and coordinate display follow your saved camera settings and Android permission. VIEW FPS measures preview frames. Weather is provider model data.")
      .setPositiveButton("CLOSE",null).show();}
    private void editTeleprompter(){
        if(recording){note("Stop recording before changing the teleprompter script");return;}
        EditText input=new EditText(this);input.setText(prompterScript);input.setTextColor(TEXT);
        input.setHint("Paste reporter script");input.setHintTextColor(MUTED);
        input.setMinLines(4);input.setMaxLines(10);input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|
            android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        new AlertDialog.Builder(this).setTitle("Private reporter teleprompter")
            .setMessage("Script appears on the camera preview, not inside the exported MP4.")
            .setView(input).setNeutralButton("HIDE",(d,w)->{
                showPrompter=false;if(prompterDisplay!=null)prompterDisplay.setVisibility(View.GONE);
            }).setNegativeButton("CANCEL",null).setPositiveButton("SHOW",(d,w)->{
                prompterScript=input.getText().toString().trim();
                if(prompterScript.length()>4000)prompterScript=prompterScript.substring(0,4000);
                showPrompter=!prompterScript.isEmpty();prompterOffset=0;
                if(prompterDisplay!=null){prompterDisplay.setText(prompterScript);
                    prompterDisplay.setVisibility(showPrompter?View.VISIBLE:View.GONE);}
            }).show();
    }
    private boolean fineLocationGranted(){return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;}
    private boolean locationGranted(){return fineLocationGranted()||checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;}
    private boolean coordinatesAllowed(){return (recording?bakedCoordinates:measurementCoordinates!=null&&measurementCoordinates.isChecked()
        &&preciseLocation!=null&&preciseLocation.isChecked())&&fineLocationGranted();}
    private void acceptLocation(Location value){
        if(value==null||!cameraUiActive||preciseLocation==null||!preciseLocation.isChecked()||!locationGranted())return;
        long fixTime=value.getElapsedRealtimeNanos(),now=SystemClock.elapsedRealtimeNanos();
        if(fixTime<=0L||fixTime>now||!Duwm1728MeasurementMath.coordinates(value.getLatitude(),value.getLongitude()))return;
        Location previous=lastLocation;
        if(previous==null||value.getElapsedRealtimeNanos()>previous.getElapsedRealtimeNanos())lastLocation=new Location(value);
    }
    private void updateMeasurements(){
        long now=SystemClock.elapsedRealtime(),sourceMs=sceneSourceTime();
        boolean locationOn=recording?bakedPrecise:preciseLocation!=null&&preciseLocation.isChecked();
        Location fix=locationGranted()?lastLocation:null;
        if(cameraUiActive&&locationOn&&locationGranted()&&!locationActive)requestLocation();
        if(measurementSources!=null&&cameraUiActive)measurementSources.update(fix,locationOn&&locationGranted());
        Duwm1728Measurements.Input in=new Duwm1728Measurements.Input();
        in.nowElapsedMs=now;in.sourceMs=sourceMs;in.utcMs=recording?recordingStartUtc+sourceMs:System.currentTimeMillis();
        in.recording=recording;in.coordinatesAllowed=coordinatesAllowed();in.locationEnabled=locationOn;
        in.locationAvailable=locationOn&&fix!=null;
        if(in.locationAvailable){
            in.fixElapsedMs=fix.getElapsedRealtimeNanos()/1_000_000L;in.locationMocked=fix.isFromMockProvider();
            in.latitude=fix.getLatitude();in.longitude=fix.getLongitude();in.locationSource=fix.getProvider()==null?"Android location":fix.getProvider();
            if(fix.hasAccuracy())in.horizontalAccuracyMeters=fix.getAccuracy();
            if(Build.VERSION.SDK_INT>=34&&fix.hasMslAltitude()){
                in.altitudeMeters=fix.getMslAltitudeMeters();in.altitudeReference="MSL";
                if(fix.hasMslAltitudeAccuracy())in.verticalAccuracyMeters=fix.getMslAltitudeAccuracyMeters();
            }else if(fix.hasAltitude()){
                in.altitudeMeters=fix.getAltitude();in.altitudeReference="WGS84";
                if(fix.hasVerticalAccuracy())in.verticalAccuracyMeters=fix.getVerticalAccuracyMeters();
            }
            if(fix.hasSpeed())in.speedMps=fix.getSpeed();
            if(fix.hasSpeedAccuracy())in.speedAccuracyMps=fix.getSpeedAccuracyMetersPerSecond();
        }
        in.headingDegrees=Float.isFinite(heading)&&heading>=0f?heading:Double.NaN;in.headingElapsedMs=lastHeadingAt;in.headingAccuracy=compassAccuracy;
        in.headingSource="Camera optical axis / magnetic north";
        Duwm1728PreviewRate.Reading fps=previewRate.at(now);
        in.previewFps=fps.framesPerSecond;in.fpsElapsedMs=fps.observedAtMs;in.fpsWindowMs=fps.windowMs;in.fpsFrames=fps.frames;
        in.fpsSource="TextureView presented frames";
        if(measurementSources!=null){
            measurementSources.fill(in);in.weatherEnabled=locationOn;
            weatherRequested=measurementSources.weatherRequested();weatherLoading=measurementSources.weatherLoading();
            weatherFailure=measurementSources.weatherFailure();weatherReceivedAt=measurementSources.weatherReceivedAt();
            weatherLat=measurementSources.weatherLatitude();weatherLon=measurementSources.weatherLongitude();
        }
        liveMeasurements=Duwm1728Measurements.sample(in);
        if(recording&&sourceMs-lastMeasurementSample>=1000L&&measurementSamples.size()<1000){
            measurementSamples.add(liveMeasurements);lastMeasurementSample=sourceMs;
        }
        if(sceneOverlay!=null)sceneOverlay.updateMeasurements(liveMeasurements,sourceMs,coordinatesAllowed());
    }
    private void recordTelemetrySample(){
        updateMeasurements();
        if(!recording)return;
        long ms=SystemClock.elapsedRealtime()-startedAt;
        if(ms<0||ms-lastSampleElapsed<2000L||telemetrySamples.size()>=200)return;
        lastSampleElapsed=ms;
        // Label the sensor/provider data as measured at this time; unavailable stays unavailable.
        telemetrySamples.add(new Duwm1728TelemetryTimeline.Point(ms,
            new Duwm1728CaptureTelemetry.Snapshot(System.currentTimeMillis(),compass(),altitude(),
                gpsAccuracy(),sourceWeather(),coordinates(),bakedPrecise)));
    }
    private void startRecording(){
        microphonePeak=-1;microphoneSampleAt=-1;microphoneFailure="";captureFailure="";decodedFrameCount.set(0);
        if(camera==null||decodedFrameAt<0){note("Wait for a camera preview");return;}
        bakedReporter=reporterInput.getText().toString();bakedPlace=placeInput.getText().toString();bakedSituation=situationInput.getText().toString();bakedCategory=CATEGORIES[categoryIndex];bakedOverlay=REPORT_OVERLAYS[reportOverlayIndex];bakedPrecise=preciseLocation.isChecked();
        bakedCoordinates=measurementCoordinates.isChecked()&&bakedPrecise&&fineLocationGranted();
        reporterInput.setEnabled(false);placeInput.setEnabled(false);situationInput.setEnabled(false);preciseLocation.setEnabled(false);measurementCoordinates.setEnabled(false);audioEnabled.setEnabled(false);categoryControl.setEnabled(false);
        try{MonitorStore store=new MonitorStore(this);lastFile=store.createCaptureTarget();File output=store.mediaFile(lastFile);if(output==null)throw new IllegalStateException("Private recording target unavailable");
            camera.setPreviewCallbackWithBuffer(null);camera.unlock();recorderOwnsCamera=true;recorder=new MediaRecorder();recorder.setCamera(camera);applyRecorderAudio();
            recorder.setVideoSource(MediaRecorder.VideoSource.CAMERA);recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
            recorder.setVideoSize(nativeVideoW,nativeVideoH);recorder.setVideoFrameRate(outputFps);recorder.setVideoEncodingBitRate(outputBitrate);recorder.setOrientationHint(mediaRotation);
            if(audioEnabled.isChecked()){recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);recorder.setAudioEncodingBitRate(192000);recorder.setAudioSamplingRate(48000);}
            recorder.setOutputFile(output.getAbsolutePath());recorder.setMaxDuration(limitSeconds*1000);recorder.setOnInfoListener((r,what,extra)->{if(what==MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED)main.post(()->stopRecording(true));});
            recorder.setOnErrorListener((r,what,extra)->main.post(()->{captureFailure="Recorder error "+what;stopRecording(true);}));
            recorder.prepare();recorder.start();startedAt=SystemClock.elapsedRealtime();recordingStartUtc=System.currentTimeMillis();recordedFrames=0;sourceFrames.set(0);telemetrySamples.clear();lastSampleElapsed=-2000;recording=true;
            measurementSamples.clear();lastMeasurementSample=-1000L;liveMeasurements=null;previewRate.reset();if(sceneOverlay!=null)sceneOverlay.clearMeasurements();
            sceneSamples.clear();sceneFrameAt=-1L;resetSceneSession();
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);recordTelemetrySample();main.removeCallbacks(prompterScroll);if(showPrompter)main.post(prompterScroll);recordButton.setText("■ STOP");indicator.setText("REC • CLEAN MASTER / AUDIO "+(audioEnabled.isChecked()?"ON":"OFF"));
        }catch(Exception e){captureFailure=safe(e);recording=false;sceneSamples.clear();measurementSamples.clear();liveMeasurements=null;resetSceneSession();cleanupRecorder();new MonitorStore(this).discardMedia(lastFile);lastFile="";unlockInputs();releaseCamera();openCamera();note("Recording could not start: "+safe(e));}
    }
    private void unlockInputs(){reporterInput.setEnabled(true);placeInput.setEnabled(true);situationInput.setEnabled(true);preciseLocation.setEnabled(true);measurementCoordinates.setEnabled(true);audioEnabled.setEnabled(true);if(categoryControl!=null)categoryControl.setEnabled(true);}
    private String safe(Exception ex){String s=ex.getMessage();return TextUtils.isEmpty(s)?ex.getClass().getSimpleName():s;}
    
    
    private String shortText(String value,int max){if(value==null||value.trim().isEmpty())return "NOT PROVIDED";String s=value.replace('\n',' ').trim();return s.length()>max?s.substring(0,Math.max(1,max-1))+"…":s;}
    private String utc(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date());}
    private boolean locationFresh(Location l){return l!=null&&!l.isFromMockProvider()&&l.getElapsedRealtimeNanos()>0L
        &&(SystemClock.elapsedRealtimeNanos()-l.getElapsedRealtimeNanos())>=0L
        &&(SystemClock.elapsedRealtimeNanos()-l.getElapsedRealtimeNanos())<=30_000_000_000L;}
    private String coordinates(){if(!(recording?bakedPrecise:preciseLocation.isChecked()))return "WITHHELD";Location l=lastLocation;return !locationFresh(l)?"SENSOR MISSING / STALE":String.format(Locale.US,"%.5f, %.5f",l.getLatitude(),l.getLongitude());}
    private String altitude(){Location l=lastLocation;return (recording?bakedPrecise:preciseLocation.isChecked())&&locationFresh(l)&&l.hasAltitude()?String.format(Locale.US,"%.0f m",l.getAltitude()):"UNAVAILABLE";}
    private void displayTelemetry(){if(telemetry==null)return;recordTelemetrySample();
        Duwm1728Measurements.Display measured=Duwm1728Measurements.display(liveMeasurements,sceneSourceTime(),coordinatesAllowed());
        telemetry.setText(measured.time+"\n"+measured.location+"\n"+measured.coordinates+"  "+measured.accuracy
            +"\n"+measured.heading+"  "+measured.speed+"  "+measured.movement+"\n"+measured.altitude+"  "+measured.fps+"\n"+measured.weather);
        if(recording){long secs=(SystemClock.elapsedRealtime()-startedAt)/1000;
            String level="MIC OFF";
            if(audioEnabled.isChecked()&&recorder!=null){try{
                int amplitude=recorder.getMaxAmplitude();
                microphonePeak=amplitude;microphoneSampleAt=SystemClock.elapsedRealtime();microphoneFailure="";
                float db=amplitude<=0?-90f:(float)(20.0*Math.log10(amplitude/32767.0));
                level=String.format(Locale.US,"MIC %.0f dBFS",Math.max(-90f,db));
            }catch(RuntimeException ex){microphoneFailure=safe(ex);level="MIC LEVEL UNAVAILABLE";}}
            double measuredFps=previewRate.at(SystemClock.elapsedRealtime()).framesPerSecond;
            String quality=secs>=3&&Double.isFinite(measuredFps)&&measuredFps<outputFps*.70?" / PREVIEW FPS LOW":"";
            String rate=Double.isFinite(measuredFps)?String.format(Locale.US,"%.1f",measuredFps):"—";
            indicator.setText(String.format(Locale.US,"● REC %d/%ds • %s • VIEW FPS %s / %d target%s",secs,limitSeconds,level,rate,outputFps,quality));
            if(secs>=limitSeconds)stopRecording(true);}}
    private void stopRecording(boolean keep){if(!recording)return;recordTelemetrySample();
        final Duwm1728CaptureTelemetry.Snapshot captureEnd=new Duwm1728CaptureTelemetry.Snapshot(
            recordingStartUtc+sceneSourceTime(),compass(),altitude(),gpsAccuracy(),sourceWeather(),coordinates(),bakedPrecise);
        expireRecordedSceneAt(sceneSourceTime());recording=false;resetSceneSession();sceneClockStart=SystemClock.elapsedRealtime();liveMeasurements=null;if(sceneOverlay!=null)sceneOverlay.clearMeasurements();main.removeCallbacks(prompterScroll);ScheduledExecutorService clock=videoClock;videoClock=null;if(clock!=null)clock.shutdownNow();boolean valid=false;
        synchronized(surfaceLock){try{if(recorder!=null){recorder.stop();valid=true;}}catch(RuntimeException ex){android.util.Log.e("DUWM-CAM","Recorder output incomplete",ex);}cleanupRecorder();}
        unlockInputs();recordButton.setText("● REC");indicator.setText(valid?"● VIDEO SAVED / PRIVATE DRAFT":"● VIDEO ERROR / RETRY");File f=new MonitorStore(this).mediaFile(lastFile);if(!keep||!valid||f==null||f.length()<1024){new MonitorStore(this).discardMedia(lastFile);lastFile="";if(keep){galleryResult=-1;galleryMessage="No complete MP4 was produced; no Gallery success is claimed.";note("Video not completed; please retry");}refreshCaptureHealth();return;}
        // Keep the original private capture and the World Monitor draft route.
        // Copy a SECOND completed MP4 into the user-visible phone Gallery.
        saveCaptureReceipt(f,lastFile,Math.max(0L,SystemClock.elapsedRealtime()-startedAt),recordedFrames,bakedCategory,bakedPrecise);
        // Legacy end metadata is retained separately; the new measured track is authoritative in export.
        pendingGallerySave=true;galleryResult=0;galleryMessage="";refreshCaptureHealth();indicator.setText("● COMPLETED MP4 / SAVING TO PHONE GALLERY");
        final String savedFile=lastFile;
        final java.util.List<Duwm1728TelemetryTimeline.Point> capturedTrack=new java.util.ArrayList<>(telemetrySamples);
        final java.util.List<Duwm1728SceneTimeline.Entry> capturedScenes=new java.util.ArrayList<>(sceneSamples);
        final java.util.List<Duwm1728Measurements.Sample> capturedMeasurements=Duwm1728Measurements.normalize(new java.util.ArrayList<>(measurementSamples));
        final boolean capturedCoordinatesAllowed=bakedCoordinates;
        // Persist the capture marker even when no model result was available.
        // An empty track must remain honestly unavailable, not speech-derived AI.
        Duwm1728SceneStore.save(getApplicationContext(),Uri.fromFile(f),capturedScenes);
        Duwm1728MeasurementStore.save(getApplicationContext(),Uri.fromFile(f),capturedMeasurements,capturedCoordinatesAllowed);
        final String galleryName="DUWM_MASTER_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".mp4";
        new Thread(()->{
            Uri gallery=null;String message;
            try{
                MediaMetadataRetriever verify=new MediaMetadataRetriever();
                try{verify.setDataSource(f.getAbsolutePath());
                    String duration=verify.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                    if(duration==null || Long.parseLong(duration)<500L)throw new IllegalStateException("Unplayable MP4 duration");
                } finally {verify.release();}
                gallery=Duwm1724GalleryPublisher.publish(getApplicationContext(),f,galleryName);
                message="MP4 saved to your phone Gallery / Movies / "+Duwm1724GalleryPublisher.ALBUM;
            }catch(Exception e){
                android.util.Log.e("DUWM-CAM","Gallery copy failed; private recording retained",e);
                message="Video saved as private draft. Gallery copy failed: "+safe(e);
            }
            final Uri savedUri=gallery;final String result=message;
            main.post(()->{
                pendingGallerySave=false;
                galleryResult=savedUri!=null?1:-1;galleryCompletedAt=SystemClock.elapsedRealtime();galleryMessage=result;
                refreshCaptureHealth();
                if(savedUri!=null){
                    getSharedPreferences(VIDEO_SETTINGS,MODE_PRIVATE).edit()
                       .putString("last_gallery_uri",savedUri.toString()).apply();
                    Duwm1726GalleryIndex.add(getApplicationContext(),savedUri,galleryName);
                    Duwm1728CaptureTelemetry.save(getApplicationContext(),savedUri,captureEnd);
                    Duwm1728TelemetryTimeline.save(getApplicationContext(),savedUri,capturedTrack);
                    Duwm1728SceneStore.save(getApplicationContext(),savedUri,capturedScenes);
                    Duwm1728MeasurementStore.save(getApplicationContext(),savedUri,capturedMeasurements,capturedCoordinatesAllowed);
                }
                Toast.makeText(getApplicationContext(),result,Toast.LENGTH_LONG).show();
                if(closed||isFinishing()||!cameraUiActive)return;
                Intent next=new Intent(this,Duwm1728VideoEditorActivity.class);
                next.putExtra("duwm1718_camera_file",savedFile);
                Uri reviewUri=savedUri!=null?savedUri:Uri.fromFile(f);
                Duwm1728CaptureTelemetry.save(getApplicationContext(),reviewUri,captureEnd);
                Duwm1728TelemetryTimeline.save(getApplicationContext(),reviewUri,capturedTrack);
                boolean scenesSaved=Duwm1728SceneStore.save(getApplicationContext(),reviewUri,capturedScenes);
                next.putExtra("scene_capture_enabled",true);
                next.putExtra("scene_capture_storage_error",!scenesSaved);
                boolean measurementsSaved=Duwm1728MeasurementStore.save(getApplicationContext(),reviewUri,capturedMeasurements,capturedCoordinatesAllowed);
                next.putExtra("measurement_capture_enabled",true);
                next.putExtra("measurement_capture_storage_error",!measurementsSaved);
                next.putExtra("measurement_coordinates_allowed",capturedCoordinatesAllowed);
                next.putExtra(Duwm1728VideoEditorActivity.EXTRA_VIDEO_URI,reviewUri.toString());
                next.putExtra("clean_master",true);next.putExtra("broadcast_ratio",ratioName());
                next.putExtra("reporter",bakedReporter);next.putExtra("place",bakedPlace);next.putExtra("notes",bakedSituation);
                next.putExtra("report_category",bakedCategory);
                if(savedUri!=null)next.putExtra("duwm1724_gallery_uri",savedUri.toString());
                next.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(next);finish();
            });
        },"duwm1724-gallery-export").start();
    }
    private void cleanupRecorder(){if(recorder!=null){try{recorder.reset();}catch(Exception ignored){}try{recorder.release();}catch(Exception ignored){}}recorder=null;recorderSurface=null;if(recorderOwnsCamera&&camera!=null)try{camera.lock();}catch(Exception ignored){}recorderOwnsCamera=false;}
    private void releaseCamera(){cameraSessionGeneration++;decodedFrameAt=-1L;sceneFrameAt=-1L;resetSceneSession();
        previewRate.reset();liveMeasurements=null;heading=-1f;lastHeadingAt=0L;compassAccuracy=-1;if(sceneOverlay!=null)sceneOverlay.clearMeasurements();
        synchronized(surfaceLock){Bitmap old=latest.getAndSet(null);if(old!=null&&!old.isRecycled())old.recycle();}
        if(camera!=null){try{camera.setPreviewCallbackWithBuffer(null);camera.stopPreview();}catch(Exception ignored){}try{camera.release();}catch(Exception ignored){}camera=null;}}
    private void requestLocation(){
        if(closed||!cameraUiActive||preciseLocation==null||!preciseLocation.isChecked()||locationManager==null)return;
        if(!locationGranted()){
            if(cameraRequestPending||locationRequestPending||checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED
                    ||getSharedPreferences(VIDEO_SETTINGS,MODE_PRIVATE).getBoolean("measurement_location_permission_requested",false))return;
            locationRequestPending=true;
            getSharedPreferences(VIDEO_SETTINGS,MODE_PRIVATE).edit().putBoolean("measurement_location_permission_requested",true).apply();
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ_LOCATION);
            return;
        }
        if(locationActive)return;
        boolean registered=false;
        String[] providers={LocationManager.GPS_PROVIDER,LocationManager.NETWORK_PROVIDER};
        for(String provider:providers){
            if(LocationManager.GPS_PROVIDER.equals(provider)&&!fineLocationGranted())continue;
            try{
                if(!locationManager.isProviderEnabled(provider))continue;
                locationManager.requestLocationUpdates(provider,1000L,0f,gpsListener);registered=true;
                acceptLocation(locationManager.getLastKnownLocation(provider));
            }catch(SecurityException|IllegalArgumentException unavailable){/* Other providers remain usable. */}
        }
        locationActive=registered;
    }
    private void stopLocation(){
        if(locationManager!=null)try{locationManager.removeUpdates(gpsListener);}catch(RuntimeException ignored){}
        locationActive=false;lastLocation=null;weatherRequested=false;weatherLoading=false;weatherFailure="";weatherReceivedAt=-1L;
        weatherLat=Double.NaN;weatherLon=Double.NaN;
        if(measurementSources!=null)measurementSources.disable();
    }
    private void refreshCaptureHealth(){
        if(closed||!cameraUiActive||captureHealthDock==null)return;
        Duwm1728CaptureHealth.Input in=new Duwm1728CaptureHealth.Input();
        in.now=SystemClock.elapsedRealtime();
        in.cameraPermission=checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED;
        in.cameraOpen=camera!=null;in.frameAt=decodedFrameAt;in.cameraError=captureFailure;
        in.recording=recording;in.adequateResolution=hasAdequateCameraSource();in.targetFps=outputFps;
        if(recording){in.recordingMs=Math.max(0L,in.now-startedAt);double measured=previewRate.at(in.now).framesPerSecond;in.sourceFps=Double.isFinite(measured)?measured:0d;}
        in.microphoneEnabled=audioEnabled!=null&&audioEnabled.isChecked();
        in.microphonePermission=checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED;
        in.microphonePeak=microphonePeak;in.microphoneAt=microphoneSampleAt;in.microphoneError=microphoneFailure;
        in.gpsOptIn=preciseLocation!=null&&preciseLocation.isChecked();
        in.gpsPermission=locationGranted();
        if(in.gpsOptIn&&in.gpsPermission&&locationManager!=null){try{
            in.gpsProviderEnabled=locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)||locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        }catch(RuntimeException ignored){in.gpsProviderEnabled=false;}}
        Location location=lastLocation;
        if(in.gpsOptIn&&location!=null){
            long age=SystemClock.elapsedRealtimeNanos()-location.getElapsedRealtimeNanos();
            if(location.getElapsedRealtimeNanos()>0L && age>=0L)in.gpsAgeMs=age/1_000_000L;
            if(location.hasAccuracy())in.gpsAccuracy=location.getAccuracy();
            in.mockLocation=location.isFromMockProvider();
        }
        in.compassPresent=sensorManager!=null&&sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)!=null;
        in.compassAt=heading>=0f&&lastHeadingAt>0L?lastHeadingAt:-1L;in.compassAccuracy=compassAccuracy;
        in.weatherRequested=weatherRequested;in.weatherLoading=weatherLoading;in.weatherError=weatherFailure;
        boolean currentWeather=liveMeasurements!=null&&Duwm1728Measurements.effective(liveMeasurements.weather,
            Math.max(0L,sceneSourceTime()-liveMeasurements.atMs))==Duwm1728Measurements.Status.AVAILABLE;
        in.weatherAt=currentWeather&&weatherReceivedAt>0L?weatherReceivedAt:-1L;
        if(weatherRequested&&!weatherLoading&&!currentWeather&&in.weatherError.isEmpty())in.weatherError="Weather model unavailable or stale";
        if(locationFresh(location)){double distance=Duwm1728MeasurementMath.distanceMeters(location.getLatitude(),location.getLongitude(),weatherLat,weatherLon);in.weatherPlaceMatches=Double.isFinite(distance)&&distance<=5000d;}
        in.gallerySaving=pendingGallerySave;in.galleryResult=galleryResult;
        in.galleryAt=galleryCompletedAt;in.galleryMessage=galleryMessage;
        captureHealthDock.update(in);
    }
    private void note(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    @Override public void onRequestPermissionsResult(int r,String[] perms,int[] grants){super.onRequestPermissionsResult(r,perms,grants);if(r==REQ_CAMERA){
            cameraRequestPending=false;
            for(int i=0;i<perms.length;i++)if(Manifest.permission.RECORD_AUDIO.equals(perms[i]) && (i>=grants.length||grants[i]!=PackageManager.PERMISSION_GRANTED)){
                audioEnabled.setChecked(false);note("Microphone denied: next recording will be silent unless you enable it in Settings.");}
            if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED){openCamera();requestLocation();}}
        if(r==REQ_LOCATION){locationRequestPending=false;if(locationGranted())requestLocation();else{stopLocation();note("Location is unavailable without Android permission. Camera, compass and preview frame rate remain available.");}displayTelemetry();}}
    @Override public void onSurfaceTextureAvailable(SurfaceTexture surface,int width,int height){openCamera();}
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture surface,int w,int h){applyViewfinderAspect();}
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture surface){if(recording)stopRecording(true);releaseCamera();return true;}
    @Override public void onSurfaceTextureUpdated(SurfaceTexture surface){
        if(camera==null||!cameraUiActive)return;
        decodedFrameAt=SystemClock.elapsedRealtime();sceneFrameAt=decodedFrameAt;long producer=0L;
        try{producer=surface.getTimestamp();}catch(RuntimeException ignored){}
        previewRate.onFrame(decodedFrameAt,producer);
        if(recording){decodedFrameCount.incrementAndGet();sourceFrames.incrementAndGet();recordedFrames++;}
    }
    @Override public void onSensorChanged(SensorEvent event){
        if(!cameraUiActive||event.sensor.getType()!=Sensor.TYPE_ROTATION_VECTOR)return;
        float[] matrix=new float[9];SensorManager.getRotationMatrixFromVector(matrix,event.values);
        double measured=Duwm1728MeasurementMath.cameraHeading(matrix,cameraFacing==Camera.CameraInfo.CAMERA_FACING_FRONT);
        heading=Double.isFinite(measured)?(float)measured:-1f;
        lastHeadingAt=event.timestamp>0L?event.timestamp/1_000_000L:0L;compassAccuracy=event.accuracy;
    }
    @Override public void onAccuracyChanged(Sensor sensor,int accuracy){if(sensor!=null&&sensor.getType()==Sensor.TYPE_ROTATION_VECTOR)compassAccuracy=accuracy;}
    @Override protected void onPause(){cameraUiActive=false;main.removeCallbacks(sceneRefresh);if(sceneAnalyzer!=null)sceneAnalyzer.pause();main.removeCallbacks(telemetryRefresh);main.removeCallbacks(prompterScroll);if(recording)stopRecording(true);releaseCamera();if(sensorManager!=null)sensorManager.unregisterListener(this);stopLocation();if(measurementSources!=null)measurementSources.pause();super.onPause();}
    @Override protected void onDestroy(){closed=true;main.removeCallbacks(sceneRefresh);if(sceneAnalyzer!=null)sceneAnalyzer.close();if(measurementSources!=null)measurementSources.close();main.removeCallbacks(telemetryRefresh);main.removeCallbacks(prompterScroll);if(videoClock!=null)videoClock.shutdownNow();frames.shutdownNow();cleanupRecorder();releaseCamera();super.onDestroy();}
}
