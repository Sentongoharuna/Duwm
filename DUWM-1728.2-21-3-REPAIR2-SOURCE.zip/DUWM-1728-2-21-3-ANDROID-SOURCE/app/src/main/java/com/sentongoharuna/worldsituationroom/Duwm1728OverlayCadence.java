package com.sentongoharuna.worldsituationroom;

/** Advances a live source clock and schedules its next visible time boundary.
 * Never caches, interpolates, delays or smooths a scene or sensor value.
 */
public final class Duwm1728OverlayCadence {
    private long sourceAnchorMs=-1,elapsedAnchorMs=-1;

    /** Returns true when an invalid or backwards time axis requires clearing retained data. */
    public boolean update(long sourceMs,long elapsedMs) {
        if(sourceMs<0||elapsedMs<0){reset();return true;}
        boolean reset=sourceAnchorMs>=0&&(sourceMs<sourceAnchorMs||elapsedMs<elapsedAnchorMs);
        // Repeated notifications for the same source instant must not extend a
        // measurement or scene's lifetime by repeatedly restarting its clock.
        if(!reset&&sourceMs==sourceAnchorMs)return false;
        sourceAnchorMs=sourceMs;elapsedAnchorMs=elapsedMs;
        return reset;
    }

    public long sourceAt(long elapsedMs) {
        if(sourceAnchorMs<0||elapsedAnchorMs<0||elapsedMs<elapsedAnchorMs)return -1;
        long delta=elapsedMs-elapsedAnchorMs;
        return sourceAnchorMs<=Long.MAX_VALUE-delta?sourceAnchorMs+delta:-1;
    }

    public void reset(){sourceAnchorMs=-1;elapsedAnchorMs=-1;}

    /** Checked original-source time for a trimmed output frame. */
    public static long sourceTime(long fromMs,long elapsedMs) {
        if(fromMs<0||elapsedMs<0||elapsedMs>Long.MAX_VALUE-fromMs)return -1;
        return fromMs+elapsedMs;
    }

    /** -1 means no timed data remains to redraw. Otherwise one deadline is enough:
     * a clock second, a scene/sample boundary, or an individual reading's expiry.
     */
    public static long nextDelayMs(long sourceMs,Duwm1728SceneTimeline.Entry scene,
                                    Duwm1728Measurements.Sample sample) {
        if(sourceMs<0)return -1;
        long delay=Long.MAX_VALUE;
        if(scene!=null) {
            delay=sooner(delay,sourceMs,scene.atMs);
            delay=sooner(delay,sourceMs,scene.validUntilMs);
        }
        if(sample!=null) {
            delay=sooner(delay,sourceMs,sample.atMs);
            delay=sooner(delay,sourceMs,sample.validUntilMs);
            if(sourceMs>=sample.atMs&&sourceMs<sample.validUntilMs) {
                delay=Math.min(delay,1000L-sourceMs%1000L);
                // UTC and recorded elapsed time need not share a subsecond
                // anchor. Redraw at either displayed clock's next change.
                long sourceDelta=sourceMs-sample.atMs;
                if(sample.utcMs>0&&sample.utcMs<=Long.MAX_VALUE-sourceDelta){
                    long utc=sample.utcMs+sourceDelta;
                    long utcDelay=1000L-utc%1000L;
                    long validFor=Long.MAX_VALUE-utc;
                    if(validFor<utcDelay)utcDelay=validFor+1;
                    delay=Math.min(delay,utcDelay);
                }
                Duwm1728Measurements.Metric[] numbers={sample.latitude,sample.longitude,sample.horizontalAccuracy,
                        sample.altitude,sample.verticalAccuracy,sample.speed,sample.speedAccuracy,
                        sample.heading,sample.fps,sample.temperature,sample.wind};
                for(Duwm1728Measurements.Metric metric:numbers)
                    delay=reading(delay,sourceMs,sample.atMs,metric.status,metric.freshForMs);
                Duwm1728Measurements.TextReading[] words={sample.place,sample.weather,sample.movement};
                for(Duwm1728Measurements.TextReading text:words)
                    delay=reading(delay,sourceMs,sample.atMs,text.status,text.freshForMs);
            }
        }
        return delay==Long.MAX_VALUE?-1:Math.max(1,delay);
    }

    /** Drawing can itself cross an expiry. Base the next refresh on the time
     * actually painted, then account for render duration, so the final stale
     * frame cannot remain on screen after all later deadlines have elapsed. */
    public static long nextDelayAfterRenderMs(long renderedSourceMs,long currentSourceMs,
            Duwm1728SceneTimeline.Entry scene,Duwm1728Measurements.Sample sample){
        if(currentSourceMs<0)return -1;
        if(renderedSourceMs<0||currentSourceMs<renderedSourceMs)return 1;
        long planned=nextDelayMs(renderedSourceMs,scene,sample);
        if(planned<0)return -1;
        long renderDuration=currentSourceMs-renderedSourceMs;
        return renderDuration>=planned?1:planned-renderDuration;
    }

    private static long reading(long delay,long now,long at,Duwm1728Measurements.Status status,long remaining) {
        if((status!=Duwm1728Measurements.Status.AVAILABLE&&status!=Duwm1728Measurements.Status.UNRELIABLE)
                ||remaining<0||remaining>=Long.MAX_VALUE-at)return delay;
        // effective() permits the exact freshness limit and expires one ms later.
        return sooner(delay,now,at+remaining+1);
    }
    private static long sooner(long delay,long now,long boundary) {
        return boundary>now?Math.min(delay,boundary-now):delay;
    }
}
