package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.os.SystemClock;
import android.view.View;

/** UI-only scene overlay. The underlying TextureView supplies clean pixels to
 * ML Kit; this sibling is never captured by that TextureView or MediaRecorder. */
public final class Duwm1728LiveSceneView extends View {
    private final Duwm1728BroadcastLayout.Report report = new Duwm1728BroadcastLayout.Report();
    private final Duwm1728OverlayCadence cadence=new Duwm1728OverlayCadence();
    private Duwm1728SceneTimeline.Entry observation;
    private Duwm1728Measurements.Sample measurements;
    private boolean measurementCoordinatesAllowed,attached;
    private final Runnable timeRefresh=()->{if(canSchedule())invalidate();};

    public Duwm1728LiveSceneView(Context context) {
        super(context);
        setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        setClickable(false);
        setFocusable(false);
        report.composition = Duwm1728BroadcastComposition.COMPACT;
        report.clearPicture = true;
        report.automaticSceneTitles = true;
        report.automaticHeadlineFit = true;
        report.sceneNeutralTitle = "CAMERA VIEW";
        report.clock = "CAMERA PREVIEW";
        report.measuredClockPrefix = "PREVIEW";
        report.category = "SCENE";
        report.provenance = "AI SCENE DESCRIPTION";
        // Reserve the same edge band before the first fix and during missing data.
        Duwm1728OverlayRenderer.applyMeasurements(report,null,0,false);
    }

    public void update(Duwm1728SceneTimeline.Entry observation, long atMs, boolean recording) {
        if(cadence.update(atMs,SystemClock.elapsedRealtime()))clearReadings();
        this.observation=observation;
        report.clock = recording ? "RECORDING" : "CAMERA PREVIEW";
        report.measuredClockPrefix=recording?"RECORDING":"PREVIEW";
        report.sceneAtMs = observation == null ? -1 : observation.atMs;
        report.sceneUntilMs = observation == null ? -1 : observation.validUntilMs;
        report.sceneTitle = observation == null ? "" : observation.title;
        report.sceneDescription = observation == null ? "" : observation.description;
        report.sceneSource = observation == null ? "" : observation.source;
        invalidate();
    }

    public void setMeasurements(Duwm1728Measurements.Sample sample,long sourceMs,boolean coordinatesAllowed){
        if(cadence.update(sourceMs,SystemClock.elapsedRealtime()))clearReadings();
        measurements=sample;measurementCoordinatesAllowed=coordinatesAllowed;invalidate();
    }
    public void updateMeasurements(Duwm1728Measurements.Sample sample,long sourceMs,boolean coordinatesAllowed){setMeasurements(sample,sourceMs,coordinatesAllowed);}
    /** A camera/recording reset clears the scene as well as its sensor data and clock. */
    public void clearMeasurements(){
        removeCallbacks(timeRefresh);cadence.reset();clearReadings();invalidate();
    }
    private void clearReadings(){
        observation=null;measurements=null;measurementCoordinatesAllowed=false;
        report.sceneAtMs=-1;report.sceneUntilMs=-1;
        report.sceneTitle="";report.sceneDescription="";report.sceneSource="";
        Duwm1728OverlayRenderer.applyMeasurements(report,null,0,false);
    }

    private boolean canSchedule(){return attached&&getVisibility()==VISIBLE&&getWindowVisibility()==VISIBLE&&isShown();}
    private void scheduleNext(){
        scheduleNext(cadence.sourceAt(SystemClock.elapsedRealtime()));
    }
    private void scheduleNext(long renderedSourceMs){
        removeCallbacks(timeRefresh);
        if(!canSchedule())return;
        long sourceMs=cadence.sourceAt(SystemClock.elapsedRealtime());
        long delay=Duwm1728OverlayCadence.nextDelayAfterRenderMs(renderedSourceMs,sourceMs,observation,measurements);
        if(delay>=0)postDelayed(timeRefresh,delay);
    }
    @Override protected void onAttachedToWindow(){
        super.onAttachedToWindow();attached=true;invalidate();scheduleNext();
    }
    @Override protected void onDetachedFromWindow(){
        attached=false;removeCallbacks(timeRefresh);cadence.reset();clearReadings();super.onDetachedFromWindow();
    }
    @Override protected void onWindowVisibilityChanged(int visibility){
        super.onWindowVisibilityChanged(visibility);
        if(cadence!=null){scheduleNext();if(visibility==VISIBLE&&attached)invalidate();}
    }
    @Override protected void onVisibilityChanged(View changedView,int visibility){
        super.onVisibilityChanged(changedView,visibility);
        if(cadence!=null){scheduleNext();if(visibility==VISIBLE&&attached)invalidate();}
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (getWidth() < 64 || getHeight() < 64){removeCallbacks(timeRefresh);return;}
        long sourceTimeMs=cadence.sourceAt(SystemClock.elapsedRealtime());
        if(sourceTimeMs<0)clearReadings();
        Duwm1728OverlayRenderer.applyMeasurements(report,measurements,sourceTimeMs,measurementCoordinatesAllowed);
        Duwm1728BroadcastLayout.draw(new Duwm1728BroadcastCanvas(canvas),
                getWidth(), getHeight(), report,Math.max(0,sourceTimeMs));
        scheduleNext(sourceTimeMs);
    }
}
