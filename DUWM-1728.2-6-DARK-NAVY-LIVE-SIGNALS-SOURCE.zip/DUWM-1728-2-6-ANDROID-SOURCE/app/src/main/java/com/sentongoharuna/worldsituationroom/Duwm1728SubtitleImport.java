package com.sentongoharuna.worldsituationroom;

import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Strict timecoded SRT import. The source file must already contain transcript text and times. */
public final class Duwm1728SubtitleImport {
    private Duwm1728SubtitleImport(){}
    private static final Pattern TIMING=Pattern.compile("(\\d{2}):(\\d{2}):(\\d{2})[,\\.](\\d{3})\\s*-->\\s*(\\d{2}):(\\d{2}):(\\d{2})[,\\.](\\d{3})");
    private static long ms(Matcher m,int start){
        long h=Long.parseLong(m.group(start)),min=Long.parseLong(m.group(start+1));
        long s=Long.parseLong(m.group(start+2)),frac=Long.parseLong(m.group(start+3));
        if(min>59||s>59)throw new IllegalArgumentException("Invalid subtitle timestamp");
        return ((h*60+min)*60+s)*1000+frac;
    }
    public static String convertSrt(String text){
        if(text==null||text.length()>65536)throw new IllegalArgumentException("Invalid or oversized SRT file");
        text=text.replace("\r\n","\n").replace('\r','\n').replace("\uFEFF","");
        String[] blocks=text.trim().split("\n\\s*\n");
        ArrayList<String> cues=new ArrayList<>();long prev=-1;
        for(String block:blocks){
            String[] lines=block.split("\n");int index=0;
            if(lines.length>0&&lines[0].trim().matches("[0-9]+"))index++;
            if(index>=lines.length)continue;
            Matcher m=TIMING.matcher(lines[index].trim());if(!m.matches())throw new IllegalArgumentException("Unrecognised SRT time code");
            long start=ms(m,1),end=ms(m,5);
            if(start<prev||end<=start||start>=45000)throw new IllegalArgumentException("Subtitle times out of order or beyond 45-second editor limit");
            prev=start;StringBuilder words=new StringBuilder();
            for(int i=index+1;i<lines.length;i++){
                String clean=lines[i].replaceAll("<[^>]*>","").replaceAll("[;=\\r\\n]+"," ").trim();
                if(!clean.isEmpty()){if(words.length()>0)words.append(' ');words.append(clean);}
            }
            if(words.length()==0)continue;
            if(words.length()>180)throw new IllegalArgumentException("Subtitle over 180 characters");
            cues.add(String.format(Locale.US,"%02d:%02d=%s",start/60000,(start/1000)%60,words));
            if(cues.size()>12)throw new IllegalArgumentException("Maximum 12 timed cues in current editor");
        }
        if(cues.isEmpty())throw new IllegalArgumentException("No subtitle cues found");
        return String.join(";",cues);
    }
}
