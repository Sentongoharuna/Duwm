package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.Instrumentation;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import java.io.File;
import java.io.FileOutputStream;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

/** Native Android Canvas regression, no network, mocked news or test fixtures in the app UI.
 * This runner is compiled into a separate androidTest APK, not the user APK.
 */
public final class DuwmSignalInstrumentation extends Instrumentation {
    private int checks;
    @Override public void onCreate(Bundle args){super.onCreate(args);start();}
    private void require(boolean ok,String text){checks++;if(!ok)throw new AssertionError(text);}
    private Bitmap frame(Duwm1728StatusLampView lamp,long time,boolean motion){
        Bitmap image=Bitmap.createBitmap(80,80,Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(image);c.drawColor(DuwmUnifiedTheme.APPROVED_NAVY);
        lamp.layout(0,0,80,80);lamp.drawLampFrame(c,time,motion);return image;
    }
    private void pixels() throws Exception {
        File folder=new File(getTargetContext().getFilesDir(),"signal-visual-proof");
        if(!folder.isDirectory()&&!folder.mkdirs())throw new IllegalStateException("Cannot save proof");
        for(Duwm1724SignalFlow.Stage state:Duwm1724SignalFlow.Stage.values()){
            Duwm1728StatusLampView lamp=new Duwm1728StatusLampView(getTargetContext());
            lamp.setStage(state,0,true);
            Bitmap fixed=frame(lamp,0L,false);
            int expected=state==Duwm1724SignalFlow.Stage.LOCAL?DuwmUnifiedTheme.APPROVED_NAVY:state.color;
            require(fixed.getPixel(40,40)==expected,"Exact solid colour / hollow local: "+state);
            require(fixed.getPixel(0,0)==DuwmUnifiedTheme.APPROVED_NAVY,"Exact navy background");
            try(FileOutputStream stream=new FileOutputStream(new File(folder,state.name()+"-STATIC.png"))){
                require(fixed.compress(Bitmap.CompressFormat.PNG,100,stream),"PNG proof write");
            }
            fixed.recycle();Set<Integer> distinct=new HashSet<>();
            for(int i=0;i<24;i++){
                Bitmap moving=frame(lamp,Duwm1728SignalMotion.periodMs(state)*i/24L,true);
                int pixel=moving.getPixel(40,40);distinct.add(pixel);
                require((pixel>>>24)==255,"Opaque animated core");moving.recycle();
            }
            require(state.rank>=0?distinct.size()>1:distinct.size()==1,"Real frame colour changes / neutral stays still: "+state);
            Duwm1728StatusLampView legend=new Duwm1728StatusLampView(getTargetContext());
            legend.showStaticColor(state.color,"STATIC HISTORY, NOT LIVE");
            Bitmap before=frame(legend,0,false),after=frame(legend,900,false);
            require(before.sameAs(after),"History does not pretend live activity");before.recycle();after.recycle();
        }
        // Same state, different sector keys -> an independent animation phase.
        Duwm1728StatusLampView one=new Duwm1728StatusLampView(getTargetContext());
        Duwm1728StatusLampView two=new Duwm1728StatusLampView(getTargetContext());
        one.setStage(Duwm1724SignalFlow.Stage.HEALTHY,0,true);
        two.setStage(Duwm1724SignalFlow.Stage.HEALTHY,1,true);
        Bitmap a=frame(one,700,true),b=frame(two,700,true);
        require(a.getPixel(40,40)!=b.getPixel(40,40),"No synchronized blinking across all providers");a.recycle();b.recycle();
    }
    @Override public void onStart(){
        Bundle result=new Bundle();AtomicReference<Throwable> failure=new AtomicReference<>();
        runOnMainSync(()->{try{pixels();}catch(Throwable error){failure.set(error);}});
        if(failure.get()!=null){
            result.putString("stream","DUWM_SIGNAL_VISUAL_FAIL\n"+android.util.Log.getStackTraceString(failure.get()));
            finish(Activity.RESULT_CANCELED,result);
        }else{
            result.putString("stream","DUWM_SIGNAL_VISUAL_PASS: "+checks+" native Android pixel checks; not a physical-camera test\n");
            finish(Activity.RESULT_OK,result);
        }
    }
}
