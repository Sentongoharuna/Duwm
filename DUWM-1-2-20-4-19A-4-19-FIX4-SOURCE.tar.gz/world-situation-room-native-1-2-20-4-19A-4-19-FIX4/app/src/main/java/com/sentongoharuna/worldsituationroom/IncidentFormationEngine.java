package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4.19A/4.4 evidence-ledger incident candidates with lifecycle; never automatic confirmation. */
public final class IncidentFormationEngine {
 public enum State { SINGLE_SOURCE, MULTI_SOURCE_RELATED, FORMING, ACTIVE_RELATED, COOLING, NO_LONGER_CURRENT }
 public enum Basis { RELATIONSHIP_ID, SAME_CANONICAL_GROUP }
 public static final class Evidence {
  public final String canonicalId,providerId; public final Signal.Layer layer; public final long providerTimeMs; public final Basis basis;
  Evidence(Signal s,Basis b){canonicalId=s.canonicalId;providerId=s.providerId;layer=s.layer;providerTimeMs=s.timestampChain==null?s.timestampMs:s.timestampChain.providerTimeMs;basis=b;}
 }
 public static final class Incident {
  public final String incidentId; public final State state; public final double latitude,longitude,radiusKm;
  public final List<Signal> records; public final List<Evidence> evidence; public final int providerCount,layerCount;
  public final long firstSeenMs,lastSeenMs; public final int consecutiveRefreshes;
  Incident(String id,State s,double a,double o,double r,List<Signal>x,List<Evidence>ev,int pc,int lc,long f,long l,int cr){
   incidentId=id;state=s;latitude=a;longitude=o;radiusKm=r;records=Collections.unmodifiableList(x);evidence=Collections.unmodifiableList(ev);
   providerCount=pc;layerCount=lc;firstSeenMs=f;lastSeenMs=l;consecutiveRefreshes=cr;
  }
 }
 private static final class Memory {long first,last;int refreshes;State lastState;Memory(long n){first=n;last=n;refreshes=1;lastState=State.FORMING;}}
 private final LinkedHashMap<String,Memory> memory=new LinkedHashMap<>(64,0.75f,true);

 public synchronized List<Incident> form(Collection<List<Signal>> layers,long now){
  ArrayList<Signal> all=new ArrayList<>();if(layers!=null)for(List<Signal>list:layers)if(list!=null)for(Signal s:list)if(s!=null&&s.hasLocation())all.add(s);
  LinkedHashMap<String,ArrayList<Signal>>groups=new LinkedHashMap<>();
  for(Signal s:all){String key=s.relationshipId==null||s.relationshipId.isEmpty()?s.canonicalId:s.relationshipId;List<Signal> bucket=groups.get(key);if(bucket==null){bucket=new ArrayList<>();groups.put(key,bucket);}bucket.add(s);}
  ArrayList<Incident>out=new ArrayList<>();HashSet<String>seen=new HashSet<>();
  for(Map.Entry<String,ArrayList<Signal>>e:groups.entrySet()){
   ArrayList<Signal>x=e.getValue();if(x.isEmpty())continue;String id="incident:"+e.getKey();seen.add(id);
   LinkedHashSet<String>providers=new LinkedHashSet<>();EnumSet<Signal.Layer>ls=EnumSet.noneOf(Signal.Layer.class);ArrayList<Evidence>ledger=new ArrayList<>();
   double lat=0,lon=0;for(Signal s:x){providers.add(s.providerId);ls.add(s.layer);lat+=s.latitude;lon+=s.longitude;ledger.add(new Evidence(s,(s.relationshipId!=null&&!s.relationshipId.isEmpty())?Basis.RELATIONSHIP_ID:Basis.SAME_CANONICAL_GROUP));}
   lat/=x.size();lon/=x.size();double radius=0;for(Signal s:x)radius=Math.max(radius,km(lat,lon,s.latitude,s.longitude));
   boolean multi=providers.size()>=2||ls.size()>=2;Memory mem=memory.get(id);State state;
   if(mem==null){mem=new Memory(now);memory.put(id,mem);state=multi?State.FORMING:State.SINGLE_SOURCE;}
   else{mem.last=now;mem.refreshes++;state=multi&&mem.refreshes>=2?State.ACTIVE_RELATED:multi?State.MULTI_SOURCE_RELATED:State.SINGLE_SOURCE;mem.lastState=state;}
   out.add(new Incident(id,state,lat,lon,radius,new ArrayList<>(x),ledger,providers.size(),ls.size(),mem.first,mem.last,mem.refreshes));
  }
  // Retain recently absent candidates as lifecycle-only records, never as fabricated current Signal records.
  for(Map.Entry<String,Memory>e:new ArrayList<>(memory.entrySet())){
   if(seen.contains(e.getKey()))continue;Memory mem=e.getValue();long age=now-mem.last;
   if(age<=60L*60L*1000L)out.add(new Incident(e.getKey(),State.COOLING,Double.NaN,Double.NaN,0,Collections.emptyList(),Collections.emptyList(),0,0,mem.first,mem.last,mem.refreshes));
   else if(age<=6L*60L*60L*1000L)out.add(new Incident(e.getKey(),State.NO_LONGER_CURRENT,Double.NaN,Double.NaN,0,Collections.emptyList(),Collections.emptyList(),0,0,mem.first,mem.last,mem.refreshes));
  }
  trim(now);Collections.sort(out,(a,b)->Integer.compare(b.records.size(),a.records.size()));return Collections.unmodifiableList(out);
 }
 public synchronized List<Incident> form(Collection<List<Signal>> layers){return form(layers,System.currentTimeMillis());}
 public static Incident forObject(List<Incident> incidents,String canonicalId){if(incidents==null||canonicalId==null)return null;for(Incident i:incidents)for(Signal s:i.records)if(canonicalId.equals(s.canonicalId))return i;return null;}
 private void trim(long now){Iterator<Map.Entry<String,Memory>>it=memory.entrySet().iterator();while(it.hasNext())if(now-it.next().getValue().last>6L*60L*60L*1000L)it.remove();while(memory.size()>256){Iterator<String>i=memory.keySet().iterator();if(!i.hasNext())break;i.next();i.remove();}}
 private static double km(double a,double b,double c,double d){double r=6371.0088,p1=Math.toRadians(a),p2=Math.toRadians(c),dp=Math.toRadians(c-a),dl=Math.toRadians(d-b);double h=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);return 2*r*Math.asin(Math.min(1d,Math.sqrt(h)));}
}