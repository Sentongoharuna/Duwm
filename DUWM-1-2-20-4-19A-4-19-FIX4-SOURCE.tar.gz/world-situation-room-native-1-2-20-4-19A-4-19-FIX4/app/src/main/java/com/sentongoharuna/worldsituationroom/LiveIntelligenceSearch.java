package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** 1.2/20/4.19A/4.16 ranked multi-result current canonical intelligence search. */
public final class LiveIntelligenceSearch {
 public static final class Hit {
  public final Signal signal; public final int rank; public final String matchedBy,region,freshness,operationalState;
  Hit(Signal s,int r,String m,String rg,String f,String op){signal=s;rank=r;matchedBy=m;region=rg;freshness=f;operationalState=op;}
 }
 public static List<Hit> search(String raw,Collection<List<Signal>>layers,CanonicalWatchStore watch,LiveChangeRegistry changes,int limit){
  String q=norm(raw);if(q.isEmpty())return Collections.emptyList();ArrayList<Hit>out=new ArrayList<>();HashSet<String>seen=new HashSet<>();
  for(List<Signal>list:layers)if(list!=null)for(Signal s:list){
   if(s==null||s.canonicalId==null||!seen.add(s.canonicalId))continue;int rank=0;String by="";
   String canonical=norm(s.canonicalId),nativeId=norm(s.id),title=norm(s.title),provider=norm(s.providerName+" "+s.providerId),region=norm(s.region),layer=norm(s.layer.name()),callsign=norm(s.facts.get("CALLSIGN")),norad=norm(s.facts.get("NORAD CATALOG"));
   if(q.equals(canonical)){rank=100;by="CANONICAL ID";}else if(q.equals(nativeId)||q.equals(callsign)||q.equals(norad)){rank=95;by="EXACT ID / CALLSIGN / NORAD";}
   else if(title.contains(q)){rank=85;by="TITLE";}else if(provider.contains(q)){rank=70;by="PROVIDER";}else if(region.contains(q)){rank=65;by="REGION";}else if(layer.contains(q)){rank=60;by="LAYER";}
   else if("watched".equals(q)&&watch.watched(s.canonicalId)){rank=80;by="WATCH";}else if("changed".equals(q)&&!changes.changesFor(s.canonicalId).isEmpty()){rank=80;by="CHANGE HISTORY";}
   else if("uganda".equals(q)&&RegionalPriorityEngine.evaluate(s).band==RegionalPriorityEngine.Band.UGANDA){rank=75;by="UGANDA RELEVANCE";}
   else if("east africa".equals(q)){RegionalPriorityEngine.Band b=RegionalPriorityEngine.evaluate(s).band;if(b==RegionalPriorityEngine.Band.UGANDA||b==RegionalPriorityEngine.Band.UGANDA_BORDER||b==RegionalPriorityEngine.Band.EAST_AFRICA){rank=72;by="EAST AFRICA RELEVANCE";}}
   if(rank>0){RegionalPriorityEngine.Result rr=RegionalPriorityEngine.evaluate(s);String fs=s.freshness==null?"UNKNOWN":s.freshness.state.name();String op=(watch.watched(s.canonicalId)?"WATCHED ":"")+(!changes.changesFor(s.canonicalId).isEmpty()?"CHANGED":"");out.add(new Hit(s,rank,by,rr.band.name(),fs,op.trim().isEmpty()?"CURRENT":op.trim()));}
  }
  Collections.sort(out,(a,b)->{int x=Integer.compare(b.rank,a.rank);return x!=0?x:Long.compare(b.signal.timestampMs,a.signal.timestampMs);});if(out.size()>limit)out=new ArrayList<>(out.subList(0,limit));return Collections.unmodifiableList(out);
 }
 private static String norm(String s){return s==null?"":s.trim().toLowerCase(Locale.ROOT);}
}