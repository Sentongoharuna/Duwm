package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4.19A/4.6 concentric-band proximity intelligence from current located canonical records only. */
public final class ProximityIntelligence {
 public enum Band { KM_0_10, KM_10_25, KM_25_50, KM_50_100, KM_100_150 }
 public static final class Nearby {
  public final Signal signal; public final double distanceKm,bearingDeg; public final String direction; public final Band band;
  Nearby(Signal s,double d,double b,String dir,Band x){signal=s;distanceKm=d;bearingDeg=b;direction=dir;band=x;}
 }
 public static final class Snapshot {
  public final List<Nearby> nearest; public final Map<Band,Integer> bandCounts; public final Map<Signal.Layer,Nearby> nearestByLayer;
  public final int uniqueObjects,providerCount;
  Snapshot(List<Nearby>n,Map<Band,Integer>b,Map<Signal.Layer,Nearby>l,int u,int p){
   nearest=Collections.unmodifiableList(n);bandCounts=Collections.unmodifiableMap(b);nearestByLayer=Collections.unmodifiableMap(l);uniqueObjects=u;providerCount=p;
  }
 }
 public static Snapshot snapshot(Signal focus,Collection<List<Signal>> layers,int limit){
  if(focus==null||!focus.hasLocation())return new Snapshot(Collections.emptyList(),new EnumMap<>(Band.class),new EnumMap<>(Signal.Layer.class),0,0);
  ArrayList<Nearby> all=new ArrayList<>();HashSet<String>seen=new HashSet<>(),providers=new HashSet<>();
  EnumMap<Band,Integer>counts=new EnumMap<>(Band.class);EnumMap<Signal.Layer,Nearby>byLayer=new EnumMap<>(Signal.Layer.class);
  if(layers!=null)for(List<Signal>list:layers)if(list!=null)for(Signal s:list){
   if(s==null||!s.hasLocation()||s.canonicalId==null||s.canonicalId.equals(focus.canonicalId)||!seen.add(s.canonicalId))continue;
   double d=km(focus.latitude,focus.longitude,s.latitude,s.longitude);Band band=band(d);if(band==null)continue;
   double b=bearing(focus.latitude,focus.longitude,s.latitude,s.longitude);Nearby n=new Nearby(s,d,b,compass(b),band);
   all.add(n);providers.add(s.providerId);counts.put(band,(counts.containsKey(band)?counts.get(band):0)+1);
   Nearby prior=byLayer.get(s.layer);if(prior==null||d<prior.distanceKm)byLayer.put(s.layer,n);
  }
  Collections.sort(all,(a,b)->Double.compare(a.distanceKm,b.distanceKm));int total=all.size();
  if(all.size()>limit)all=new ArrayList<>(all.subList(0,limit));
  return new Snapshot(all,new EnumMap<>(counts),new EnumMap<>(byLayer),total,providers.size());
 }
 public static List<Nearby> around(Signal focus,Collection<List<Signal>> layers,double radiusKm,int limit){
  Snapshot s=snapshot(focus,layers,limit);ArrayList<Nearby>x=new ArrayList<>();for(Nearby n:s.nearest)if(n.distanceKm<=radiusKm)x.add(n);return Collections.unmodifiableList(x);
 }
 private static Band band(double d){return d<=10?Band.KM_0_10:d<=25?Band.KM_10_25:d<=50?Band.KM_25_50:d<=100?Band.KM_50_100:d<=150?Band.KM_100_150:null;}
 private static double km(double a,double b,double c,double d){double r=6371.0088,p1=Math.toRadians(a),p2=Math.toRadians(c),dp=Math.toRadians(c-a),dl=Math.toRadians(d-b);double h=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);return 2*r*Math.asin(Math.min(1d,Math.sqrt(h)));}
 private static double bearing(double a,double b,double c,double d){double p1=Math.toRadians(a),p2=Math.toRadians(c),dl=Math.toRadians(d-b);double y=Math.sin(dl)*Math.cos(p2),x=Math.cos(p1)*Math.sin(p2)-Math.sin(p1)*Math.cos(p2)*Math.cos(dl);return (Math.toDegrees(Math.atan2(y,x))+360d)%360d;}
 private static String compass(double b){String[]p={"N","NE","E","SE","S","SW","W","NW"};return p[((int)Math.floor((b+22.5)/45d))%8];}
}