package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4.19A/4.12 deep East Africa operations lens over worldwide canonical records. */
public final class EastAfricaOperationsView {
 public static final class ChangeItem {
  public final Signal signal; public final LiveChangeRegistry.Change change;
  ChangeItem(Signal s,LiveChangeRegistry.Change c){signal=s;change=c;}
 }
 public static final class Snapshot {
  public final List<Signal> records; public final List<ChangeItem> latestChanges;
  public final Map<Signal.Layer,Integer> layers; public final Map<String,Integer> places,freshness;
  public final int providerCount,liveFreshCount,watchedCount,changeCount,ugandaCount,borderCount;
  Snapshot(List<Signal>r,List<ChangeItem>c,Map<Signal.Layer,Integer>l,Map<String,Integer>p,Map<String,Integer>f,
           int pc,int lf,int w,int cc,int ug,int bc){
   records=Collections.unmodifiableList(r);latestChanges=Collections.unmodifiableList(c);layers=Collections.unmodifiableMap(l);
   places=Collections.unmodifiableMap(p);freshness=Collections.unmodifiableMap(f);providerCount=pc;liveFreshCount=lf;
   watchedCount=w;changeCount=cc;ugandaCount=ug;borderCount=bc;
  }
 }
 public static Snapshot build(Collection<List<Signal>>all,CanonicalWatchStore watch,LiveChangeRegistry changes,int limit){
  ArrayList<Signal>records=new ArrayList<>();ArrayList<ChangeItem>latest=new ArrayList<>();
  HashSet<String>seen=new HashSet<>(),providers=new HashSet<>();EnumMap<Signal.Layer,Integer>counts=new EnumMap<>(Signal.Layer.class);
  LinkedHashMap<String,Integer>places=new LinkedHashMap<>(),freshness=new LinkedHashMap<>();int fresh=0,watched=0,changed=0,uganda=0,border=0;
  if(all!=null)for(List<Signal>list:all)if(list!=null)for(Signal s:list){
   if(s==null||s.canonicalId==null||!seen.add(s.canonicalId))continue;
   RegionalPriorityEngine.Result rr=RegionalPriorityEngine.evaluate(s);
   if(rr.band!=RegionalPriorityEngine.Band.UGANDA&&rr.band!=RegionalPriorityEngine.Band.UGANDA_BORDER&&rr.band!=RegionalPriorityEngine.Band.EAST_AFRICA)continue;
   if(rr.band==RegionalPriorityEngine.Band.UGANDA)uganda++;if(rr.band==RegionalPriorityEngine.Band.UGANDA_BORDER)border++;
   records.add(s);providers.add(s.providerId);counts.put(s.layer,(counts.containsKey(s.layer)?counts.get(s.layer):0)+1);
   String place=countryBand(s,rr);places.put(place,(places.containsKey(place)?places.get(place):0)+1);
   String fs=s.freshness==null?"UNKNOWN":s.freshness.state.name();freshness.put(fs,(freshness.containsKey(fs)?freshness.get(fs):0)+1);
   if(s.freshness!=null&&(s.freshness.state==ObjectFreshness.State.LIVE||s.freshness.state==ObjectFreshness.State.FRESH))fresh++;
   if(watch!=null&&watch.watched(s.canonicalId))watched++;
   if(changes!=null){List<LiveChangeRegistry.Change>cs=changes.changesFor(s.canonicalId);if(!cs.isEmpty()){changed++;latest.add(new ChangeItem(s,cs.get(0)));}}
  }
  Collections.sort(records,(a,b)->Long.compare(b.timestampMs,a.timestampMs));Collections.sort(latest,(a,b)->Long.compare(b.change.detectedAtMs,a.change.detectedAtMs));
  if(records.size()>limit)records=new ArrayList<>(records.subList(0,limit));if(latest.size()>12)latest=new ArrayList<>(latest.subList(0,12));
  return new Snapshot(records,latest,new EnumMap<>(counts),places,freshness,providers.size(),fresh,watched,changed,uganda,border);
 }
 private static String countryBand(Signal s,RegionalPriorityEngine.Result rr){
  if(rr.band==RegionalPriorityEngine.Band.UGANDA_BORDER)return "UGANDA BORDER CONTEXT";
  if(rr.band==RegionalPriorityEngine.Band.UGANDA)return "UGANDA";
  if(s.hasLocation()){
   double a=s.latitude,o=s.longitude;
   if(a>=-5.0&&a<=5.5&&o>=33.5&&o<=42.5)return "KENYA";
   if(a>=-12.0&&a<=-0.8&&o>=29.0&&o<=40.8)return "TANZANIA";
   if(a>=-2.9&&a<=-1.0&&o>=28.8&&o<=30.9)return "RWANDA";
   if(a>=-4.6&&a<=-2.2&&o>=28.9&&o<=30.9)return "BURUNDI";
   if(a>=3.4&&a<=12.3&&o>=23.4&&o<=35.9)return "SOUTH SUDAN";
  }
  return "EAST AFRICA / UNRESOLVED COUNTRY";
 }
}