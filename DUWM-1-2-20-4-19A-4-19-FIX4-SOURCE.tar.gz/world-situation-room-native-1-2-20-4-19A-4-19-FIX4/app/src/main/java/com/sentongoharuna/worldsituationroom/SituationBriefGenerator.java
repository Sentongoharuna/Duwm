package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** 1.2/20/4.19A/4.17 structured factual situation brief from current canonical provider records only. */
public final class SituationBriefGenerator {
 public static final class Brief {
  public final String scope;public final int records,providers,liveFresh,changed,watched,missingWatched;
  public final Map<Signal.Layer,Integer>layers;public final Map<String,Integer>freshness;public final List<Signal>newest;public final List<LiveChangeRegistry.Change>latestChanges;
  Brief(String s,int r,int p,int f,int c,int w,int mw,Map<Signal.Layer,Integer>l,Map<String,Integer>fs,List<Signal>n,List<LiveChangeRegistry.Change>ch){scope=s;records=r;providers=p;liveFresh=f;changed=c;watched=w;missingWatched=mw;layers=Collections.unmodifiableMap(l);freshness=Collections.unmodifiableMap(fs);newest=Collections.unmodifiableList(n);latestChanges=Collections.unmodifiableList(ch);}
 }
 public static Brief build(String scope,Collection<List<Signal>>all,CanonicalWatchStore watch,LiveChangeRegistry changes,int limit){
  ArrayList<Signal>x=new ArrayList<>();ArrayList<LiveChangeRegistry.Change>latest=new ArrayList<>();HashSet<String>seen=new HashSet<>(),providers=new HashSet<>();EnumMap<Signal.Layer,Integer>counts=new EnumMap<>(Signal.Layer.class);LinkedHashMap<String,Integer>freshness=new LinkedHashMap<>();int fresh=0,changed=0,watched=0;
  if(all!=null)for(List<Signal>list:all)if(list!=null)for(Signal s:list){if(s==null||s.canonicalId==null||!seen.add(s.canonicalId)||!inScope(scope,s))continue;x.add(s);providers.add(s.providerId);counts.put(s.layer,(counts.containsKey(s.layer)?counts.get(s.layer):0)+1);String fs=s.freshness==null?"UNKNOWN":s.freshness.state.name();freshness.put(fs,(freshness.containsKey(fs)?freshness.get(fs):0)+1);if("LIVE".equals(fs)||"FRESH".equals(fs))fresh++;if(watch.watched(s.canonicalId))watched++;List<LiveChangeRegistry.Change>cs=changes.changesFor(s.canonicalId);if(!cs.isEmpty()){changed++;latest.add(cs.get(0));}}
  int missingWatched=0;for(CanonicalWatchStore.Watch ww:watch.all())if(!seen.contains(ww.canonicalId)){LiveChangeRegistry.Lifecycle life=changes.lifecycleFor(ww.canonicalId);if(life!=null&&life.consecutiveMissing>0)missingWatched++;}
  Collections.sort(x,(a,b)->Long.compare(b.timestampMs,a.timestampMs));Collections.sort(latest,(a,b)->Long.compare(b.detectedAtMs,a.detectedAtMs));int total=x.size();if(x.size()>limit)x=new ArrayList<>(x.subList(0,limit));if(latest.size()>8)latest=new ArrayList<>(latest.subList(0,8));
  return new Brief(scope,total,providers.size(),fresh,changed,watched,missingWatched,new EnumMap<>(counts),freshness,x,latest);
 }
 private static boolean inScope(String scope,Signal s){RegionalPriorityEngine.Band b=RegionalPriorityEngine.evaluate(s).band;if("UGANDA".equals(scope))return b==RegionalPriorityEngine.Band.UGANDA;if("EAST_AFRICA".equals(scope))return b==RegionalPriorityEngine.Band.UGANDA||b==RegionalPriorityEngine.Band.UGANDA_BORDER||b==RegionalPriorityEngine.Band.EAST_AFRICA;return true;}
}