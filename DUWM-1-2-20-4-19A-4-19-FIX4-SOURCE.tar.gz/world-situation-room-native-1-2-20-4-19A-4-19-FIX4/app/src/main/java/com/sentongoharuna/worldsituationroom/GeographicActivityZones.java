package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4.19A/4.3 persistent observed activity zones with stability/trend and bounded state. */
public final class GeographicActivityZones {
 public enum Trend { NEW, INCREASING, STABLE, DECREASING }
 public static final class Zone {
  public final String zoneId; public final double latitude,longitude,radiusKm;
  public final int objectCount,layerCount,providerCount; public final String dominantLayer;
  public final long firstSeenMs,lastSeenMs; public final int consecutiveRefreshes; public final Trend trend;
  Zone(String id,double a,double o,double r,int c,int lc,int pc,String d,long f,long l,int cr,Trend t){
   zoneId=id;latitude=a;longitude=o;radiusKm=r;objectCount=c;layerCount=lc;providerCount=pc;dominantLayer=d;
   firstSeenMs=f;lastSeenMs=l;consecutiveRefreshes=cr;trend=t;
  }
 }
 private static final class Memory {
  long first,last; int count,refreshes;
  Memory(long n,int c){first=n;last=n;count=c;refreshes=1;}
 }
 private final LinkedHashMap<String,Memory> memory=new LinkedHashMap<>(64,0.75f,true);

 public synchronized List<Zone> detect(Collection<List<Signal>> layers,long now){
  ArrayList<Signal> all=new ArrayList<>();
  if(layers!=null)for(List<Signal> list:layers)if(list!=null)for(Signal s:list)if(valid(s))all.add(s);
  ArrayList<Zone> out=new ArrayList<>();HashSet<String> used=new HashSet<>(),seenZones=new HashSet<>();
  for(Signal seed:all){
   if(used.contains(seed.canonicalId))continue;
   ArrayList<Signal> members=new ArrayList<>();
   for(Signal s:all)if(distanceKm(seed.latitude,seed.longitude,s.latitude,s.longitude)<=75d)members.add(s);
   if(members.size()<4)continue;
   double lat=0,lon=0;EnumMap<Signal.Layer,Integer> counts=new EnumMap<>(Signal.Layer.class);HashSet<String>providers=new HashSet<>();
   for(Signal s:members){lat+=s.latitude;lon+=s.longitude;counts.put(s.layer,(counts.containsKey(s.layer)?counts.get(s.layer):0)+1);providers.add(s.providerId);}
   lat/=members.size();lon/=members.size();
   double radius=0;for(Signal s:members)radius=Math.max(radius,distanceKm(lat,lon,s.latitude,s.longitude));
   Signal.Layer dom=null;int max=0;for(Map.Entry<Signal.Layer,Integer>e:counts.entrySet())if(e.getValue()>max){dom=e.getKey();max=e.getValue();}
   String id=zoneId(lat,lon);seenZones.add(id);Memory mem=memory.get(id);Trend trend=Trend.NEW;
   if(mem==null){mem=new Memory(now,members.size());memory.put(id,mem);}
   else {trend=members.size()>mem.count?Trend.INCREASING:members.size()<mem.count?Trend.DECREASING:Trend.STABLE;mem.last=now;mem.refreshes++;mem.count=members.size();}
   out.add(new Zone(id,lat,lon,Math.min(75d,radius),members.size(),counts.size(),providers.size(),dom==null?"UNKNOWN":dom.name(),mem.first,mem.last,mem.refreshes,trend));
   for(Signal s:members)used.add(s.canonicalId);
  }
  Collections.sort(out,(a,b)->Integer.compare(b.objectCount,a.objectCount));
  trim(now,seenZones);return Collections.unmodifiableList(out);
 }
 /** Compatibility entry point retained for older callers; state timestamp uses wall clock only here. */
 public synchronized List<Zone> detect(Collection<List<Signal>> layers){return detect(layers,System.currentTimeMillis());}
 private void trim(long now,Set<String>seen){
  Iterator<Map.Entry<String,Memory>>it=memory.entrySet().iterator();
  while(it.hasNext()){Map.Entry<String,Memory>e=it.next();if(!seen.contains(e.getKey())&&now-e.getValue().last>6L*60L*60L*1000L)it.remove();}
  while(memory.size()>256){Iterator<String>i=memory.keySet().iterator();if(!i.hasNext())break;i.next();i.remove();}
 }
 private static String zoneId(double lat,double lon){return String.format(Locale.US,"zone:%.1f:%.1f",Math.rint(lat*10d)/10d,Math.rint(lon*10d)/10d);}
 private static boolean valid(Signal s){return s!=null&&s.canonicalId!=null&&!s.canonicalId.isEmpty()&&s.hasLocation();}
 private static double distanceKm(double a,double b,double c,double d){double r=6371.0088,p1=Math.toRadians(a),p2=Math.toRadians(c),dp=Math.toRadians(c-a),dl=Math.toRadians(d-b);double h=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);return 2*r*Math.asin(Math.min(1d,Math.sqrt(h)));}
}