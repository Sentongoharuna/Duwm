package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4.19A/4.10 deep factual location snapshot: bands, freshness, providers, watch and changes. */
public final class LocationIntelligence {
 public enum Band { KM_0_10, KM_10_25, KM_25_50, KM_50_100 }
 public static final class Snapshot {
  public final double latitude,longitude,radiusKm; public final List<Signal> records;
  public final Map<Signal.Layer,Integer> layerCounts; public final Map<Band,Integer> bandCounts;
  public final Map<String,Integer> freshnessCounts; public final Map<Signal.Layer,Signal> nearestByLayer;
  public final int providerCount,watchedCount,changedCount,uniqueCount;
  Snapshot(double a,double o,double r,List<Signal>x,Map<Signal.Layer,Integer>lc,Map<Band,Integer>bc,Map<String,Integer>fc,
           Map<Signal.Layer,Signal>nl,int pc,int wc,int cc,int uc){
   latitude=a;longitude=o;radiusKm=r;records=Collections.unmodifiableList(x);layerCounts=Collections.unmodifiableMap(lc);
   bandCounts=Collections.unmodifiableMap(bc);freshnessCounts=Collections.unmodifiableMap(fc);nearestByLayer=Collections.unmodifiableMap(nl);
   providerCount=pc;watchedCount=wc;changedCount=cc;uniqueCount=uc;
  }
 }
 public static Snapshot around(double lat,double lon,double radiusKm,Collection<List<Signal>>layers,
                               CanonicalWatchStore watch,LiveChangeRegistry changes,int limit){
  ArrayList<Signal>all=new ArrayList<>();HashSet<String>seen=new HashSet<>(),providers=new HashSet<>();
  EnumMap<Signal.Layer,Integer>layersCount=new EnumMap<>(Signal.Layer.class);EnumMap<Band,Integer>bands=new EnumMap<>(Band.class);
  LinkedHashMap<String,Integer>fresh=new LinkedHashMap<>();EnumMap<Signal.Layer,Signal>nearest=new EnumMap<>(Signal.Layer.class);
  EnumMap<Signal.Layer,Double>nearestD=new EnumMap<>(Signal.Layer.class);int watched=0,changed=0;
  if(layers!=null)for(List<Signal>list:layers)if(list!=null)for(Signal s:list){
   if(s==null||!s.hasLocation()||s.canonicalId==null||!seen.add(s.canonicalId))continue;
   double d=km(lat,lon,s.latitude,s.longitude);if(d>radiusKm)continue;Band b=band(d);if(b==null)continue;
   all.add(s);providers.add(s.providerId);layersCount.put(s.layer,(layersCount.containsKey(s.layer)?layersCount.get(s.layer):0)+1);bands.put(b,(bands.containsKey(b)?bands.get(b):0)+1);
   String fs=s.freshness==null?"UNKNOWN":s.freshness.state.name();fresh.put(fs,(fresh.containsKey(fs)?fresh.get(fs):0)+1);
   if(watch!=null&&watch.watched(s.canonicalId))watched++;if(changes!=null&&!changes.changesFor(s.canonicalId).isEmpty())changed++;
   if(!nearestD.containsKey(s.layer)||d<nearestD.get(s.layer)){nearestD.put(s.layer,d);nearest.put(s.layer,s);}
  }
  Collections.sort(all,(a,b)->Double.compare(km(lat,lon,a.latitude,a.longitude),km(lat,lon,b.latitude,b.longitude)));int unique=all.size();
  if(all.size()>limit)all=new ArrayList<>(all.subList(0,limit));
  return new Snapshot(lat,lon,radiusKm,all,new EnumMap<>(layersCount),new EnumMap<>(bands),fresh,new EnumMap<>(nearest),providers.size(),watched,changed,unique);
 }
 public static Snapshot around(double lat,double lon,double radiusKm,Collection<List<Signal>>layers,CanonicalWatchStore watch,int limit){
  return around(lat,lon,radiusKm,layers,watch,null,limit);
 }
 private static Band band(double d){return d<=10?Band.KM_0_10:d<=25?Band.KM_10_25:d<=50?Band.KM_25_50:d<=100?Band.KM_50_100:null;}
 private static double km(double a,double b,double c,double d){double r=6371.0088,p1=Math.toRadians(a),p2=Math.toRadians(c),dp=Math.toRadians(c-a),dl=Math.toRadians(d-b);double h=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);return 2*r*Math.asin(Math.min(1d,Math.sqrt(h)));}
}