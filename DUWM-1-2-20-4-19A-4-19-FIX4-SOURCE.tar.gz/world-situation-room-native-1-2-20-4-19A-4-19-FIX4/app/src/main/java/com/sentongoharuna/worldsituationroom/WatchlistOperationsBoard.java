package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4-13 operational board for persistent canonical WATCH identities. */
public final class WatchlistOperationsBoard {
 public static final class Row {
  public final CanonicalWatchStore.Watch watch; public final Signal current;
  public final boolean currentlyPresent; public final int changeCount;
  Row(CanonicalWatchStore.Watch w,Signal s,int c){watch=w;current=s;currentlyPresent=s!=null;changeCount=c;}
 }
 public static final class Snapshot {
  public final List<Row> rows; public final int total,present,missing,changed,liveFresh;
  Snapshot(List<Row>r,int t,int p,int m,int c,int f){rows=Collections.unmodifiableList(r);total=t;present=p;missing=m;changed=c;liveFresh=f;}
 }
 public static Snapshot build(CanonicalWatchStore store,Collection<List<Signal>> layers,LiveChangeRegistry changes,int limit){
  if(store==null)return new Snapshot(Collections.emptyList(),0,0,0,0,0);
  LinkedHashMap<String,Signal> current=new LinkedHashMap<>();
  if(layers!=null)for(List<Signal>list:layers)if(list!=null)for(Signal s:list)
   if(s!=null&&s.canonicalId!=null)current.put(s.canonicalId,s);
  ArrayList<Row>rows=new ArrayList<>();int present=0,missing=0,changed=0,fresh=0;
  for(CanonicalWatchStore.Watch w:store.all()){
   Signal s=current.get(w.canonicalId);int cc=changes==null?0:changes.changesFor(w.canonicalId).size();
   if(s==null)missing++;else{present++;if(s.freshness!=null&&(s.freshness.state==ObjectFreshness.State.LIVE||s.freshness.state==ObjectFreshness.State.FRESH))fresh++;}
   if(cc>0)changed++;rows.add(new Row(w,s,cc));
  }
  Collections.sort(rows,(a,b)->Long.compare(b.watch.watchedAtMs,a.watch.watchedAtMs));
  int total=rows.size();if(rows.size()>limit)rows=new ArrayList<>(rows.subList(0,limit));
  return new Snapshot(rows,total,present,missing,changed,fresh);
 }
}
