#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"; J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"; M="$J/MainActivity.java"
# FIX4 verifies the exact syntax damage introduced by FIX3's API23 rewrite is gone.
! grep -R -nE '\.\(' "$J"/*.java
grep -F '(snap.bandCounts.containsKey(b)?snap.bandCounts.get(b):0)' "$M" >/dev/null
! grep -R -n 'getOrDefault(' "$J"
! grep -R -n 'computeIfAbsent(' "$J"
echo "1.2/20/4.19A/4.19 FIX4 SYNTAX REPAIR PASS"
