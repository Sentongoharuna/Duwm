#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
"$P/scripts/verify-1-2-20-4-19A-4-19-fix1-deep-regression.sh" "$P"
grep -F 'double d=SatelliteMapView.distanceKm(signal.latitude,signal.longitude,z.latitude,z.longitude);' "$M" >/dev/null
! grep -F 'double d=distanceKm(signal.latitude,signal.longitude,z.latitude,z.longitude);' "$M"
echo "1.2/20/4.19A/4.19 FIX2 DISTANCE COMPILE REPAIR PASS"
