#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
"$P/scripts/verify-1-2-20-4-19A-4-19-fix2-compile-repair.sh" "$P"
if grep -R -n -E '\b[a-zA-Z_][a-zA-Z0-9_]*\.sort\(' "$J" | grep -v -E 'Collections\.sort|Arrays\.sort'; then
  echo "API24 List.sort remains"; exit 1
fi
! grep -R -n 'getOrDefault(' "$J"
! grep -R -n 'computeIfAbsent(' "$J"
grep -F 'Collections.sort(out,' "$J/CanonicalWatchStore.java" >/dev/null
grep -F 'Collections.sort(all,' "$J/ProximityIntelligence.java" >/dev/null
grep -F 'Collections.sort(records,' "$J/UgandaOperationsView.java" >/dev/null
grep -F 'Collections.sort(records,' "$J/EastAfricaOperationsView.java" >/dev/null
echo "1.2/20/4.19A/4.19 FIX3 API23 LINT REPAIR PASS"
