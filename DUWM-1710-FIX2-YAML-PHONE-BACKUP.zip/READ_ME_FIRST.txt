DUWM 1710 FIX2 — ONE YAML UPLOAD ONLY
=====================================
1. In GitHub repository Sentongoharuna/Duwm open .github/workflows/
2. Upload DUWM-1710-FIX2-ONE-FILE-GREEN-REPAIR.yml directly into that folder.
3. Commit to main. The workflow is triggered by that YAML path.
4. Do not upload the backup ZIP itself as an Actions workflow.
5. The workflow reconstructs the exact existing 1710 FIX1 app source from the already-present verified 1709 source ZIP + embedded changed files. You do not need a separate source ZIP upload.
6. Green status only when Android compilation, APK verification and emulator install/launch succeed.
