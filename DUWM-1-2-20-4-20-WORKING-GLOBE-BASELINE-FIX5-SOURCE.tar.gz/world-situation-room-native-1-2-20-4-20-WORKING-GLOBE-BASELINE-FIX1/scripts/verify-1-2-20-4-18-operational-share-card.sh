#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
"$P/scripts/verify-1-2-20-4-17-situation-brief-generator.sh" "$P"

# Provenance-preserving share-card foundation actually present in current source.
for x in 'CANONICAL OBJECT ID' 'PROVIDER ID' 'PROVIDER NAME' 'PROVIDER RECORD ID'          'COORDINATE ORIGIN' 'FRESHNESS' 'PROVIDER TIME' 'FIRST SEEN' 'FETCHED AT'          'RELATIONSHIP ID' 'OBJECT TYPE' 'OBJECT STATE' 'OBSERVED / PUBLISHED'          'LOCATION' 'CREDIBILITY' 'FEED STATE' 'SOURCE UPDATE AGE' 'PROVIDER-RETURNED COUNT'; do
  grep -F "cardFacts.put(\"$x\"" "$M" >/dev/null
done

# Operational intelligence engines must exist in the current application.
grep -F 'OperationalPriorityEngine.evaluate(' "$M" >/dev/null
grep -F 'SituationBriefGenerator.build(' "$M" >/dev/null

# Current operational/situation wording and safety disclosures.
grep -F 'WITH DETECTED CHANGES' "$M" >/dev/null
grep -F 'INCIDENT CANDIDATE' "$M" >/dev/null
grep -F 'INCIDENT CANDIDATE ≠ CONFIRMED INCIDENT' "$M" >/dev/null
grep -F 'CALCULATED FROM PUBLIC ELEMENTS — NOT LIVE TELEMETRY' "$M" >/dev/null
grep -F 'RADAR HISTORY / OBSERVATION — NOT A FORECAST' "$M" >/dev/null

echo "1.2/20/4-18 OPERATIONAL SHARE CARD PASS"
