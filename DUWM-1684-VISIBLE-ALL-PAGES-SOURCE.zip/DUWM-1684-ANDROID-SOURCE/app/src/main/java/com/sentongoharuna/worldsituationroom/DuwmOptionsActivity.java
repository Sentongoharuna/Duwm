package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.Locale;

/** 1683: a searchable, data-aware front door to EVERY original DUWM intelligence desk.
 * Opens individual existing activities, never places a second globe over MainActivity.
 */
public final class DuwmOptionsActivity extends Activity {
    private static final int BG=DuwmUnifiedTheme.BACKGROUND;
    private static final int WHITE=DuwmUnifiedTheme.TEXT;
    private static final int MUTED=DuwmUnifiedTheme.MUTED;
    private static final int CYAN=DuwmUnifiedTheme.ACCENT;
    private static final int TEAL=DuwmUnifiedTheme.PANEL;
    private final ArrayList<LinearLayout> tiles=new ArrayList<>();
    private final ArrayList<TextView> headers=new ArrayList<>();
    private final ArrayList<TextView> receiptLines=new ArrayList<>();
    private TextView resultCount,recentDesk;
    private final Set<String> favorites=new HashSet<>();
    private boolean onlyFavorites=false;
    private SharedPreferences prefs;
    private EditText searchBox;
    private String sectionFilter="ALL";
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);
        if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return t;
    }
    private GradientDrawable background(boolean selected){
        GradientDrawable d=new GradientDrawable();d.setColor(selected?DuwmUnifiedTheme.PANEL_SELECTED:TEAL);
        d.setStroke(dp(1),selected?CYAN:DuwmUnifiedTheme.BORDER);
        d.setCornerRadius(dp(11));return d;
    }
    private TextView pill(String value){
        TextView v=text(value,11,CYAN,true);v.setGravity(Gravity.CENTER);v.setBackground(background(false));
        v.setPadding(dp(9),dp(9),dp(9),dp(9));return v;
    }
    private void header(LinearLayout root,String category){
        TextView h=text(category.toUpperCase(Locale.ROOT),15,CYAN,true);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.topMargin=dp(23);p.bottomMargin=dp(12);root.addView(h,p);headers.add(h);
    }
    private String id(Duwm1683DeskCatalog.Desk d){return d.title;}
    private void openDesk(Duwm1683DeskCatalog.Desk d){
        prefs.edit().putString("recentDesk",d.title).apply();
        startActivity(Duwm1683DeskCatalog.intent(this,d));
    }
    private void item(LinearLayout root,Duwm1683DeskCatalog.Desk d){
        LinearLayout block=new LinearLayout(this);block.setOrientation(LinearLayout.VERTICAL);
        block.setPadding(dp(13),dp(12),dp(13),dp(13));block.setBackground(background(false));
        Duwm1684SectorVisual thumbnail=new Duwm1684SectorVisual(this,d.title,false);
        LinearLayout.LayoutParams thumbnailLp=new LinearLayout.LayoutParams(-1,dp(83));
        thumbnailLp.bottomMargin=dp(10);block.addView(thumbnail,thumbnailLp);
        LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.HORIZONTAL);
        TextView name=text(d.title.toUpperCase(Locale.ROOT),17,WHITE,true);top.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow=text("↗",23,CYAN,true);top.addView(arrow);
        block.addView(top);
        TextView subtitle=text(d.subtitle,12,MUTED,false);subtitle.setPadding(0,dp(3),0,dp(4));block.addView(subtitle);
        TextView receipt=text(Duwm1683DeskCatalog.status(this,d),11,
                              d.source>=0?CYAN:MUTED,false);
        receipt.setSingleLine(false);receipt.setMaxLines(3);block.addView(receipt);receiptLines.add(receipt);
        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams actionParams=new LinearLayout.LayoutParams(-1,-2);
        actionParams.topMargin=dp(6);block.addView(actions,actionParams);
        TextView open=pill("OPEN FULL SCREEN  ↗");open.setOnClickListener(v->openDesk(d));
        actions.addView(open,new LinearLayout.LayoutParams(0,dp(39),2));
        TextView detail=pill("SOURCE DETAIL");
        LinearLayout.LayoutParams detailParams=new LinearLayout.LayoutParams(0,dp(39),1);
        detailParams.leftMargin=dp(8);actions.addView(detail,detailParams);
        detail.setOnClickListener(v->Duwm1683DeskDetailKit.show(this,d));
        TextView favorite=pill(favorites.contains(id(d))?"★":"☆");
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(dp(42),dp(39));fp.leftMargin=dp(6);
        actions.addView(favorite,fp);
        favorite.setOnClickListener(v->{
            if(favorites.contains(id(d)))favorites.remove(id(d));else favorites.add(id(d));
            favorite.setText(favorites.contains(id(d))?"★":"☆");
            prefs.edit().putString("favorites",android.text.TextUtils.join("\u001f",favorites)).apply();
            filter(searchBox.getText().toString());
        });
        block.setOnClickListener(v->openDesk(d));
        block.setContentDescription(d.title+". "+d.subtitle+". "+Duwm1683DeskCatalog.status(this,d));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(9);
        root.addView(block,p);tiles.add(block);
    }
    private void filter(String query){
        String q=query==null?"":query.trim().toLowerCase(Locale.ROOT);
        String group="";int visible=0;int matching=0;int groupIndex=-1;
        for(int i=0;i<Duwm1683DeskCatalog.ALL.length;i++){
            Duwm1683DeskCatalog.Desk d=Duwm1683DeskCatalog.ALL[i];
            boolean sectionOk=(sectionFilter.equals("ALL")||d.category.equals(sectionFilter))&&
                    (!onlyFavorites||favorites.contains(id(d)));
            boolean show=sectionOk && (q.isEmpty()||(d.title+" "+d.subtitle+" "+d.category+" "+d.description)
                                  .toLowerCase(Locale.ROOT).contains(q));
            if(show){visible++;matching++;}tiles.get(i).setVisibility(show?View.VISIBLE:View.GONE);
        }
        for(int k=0;k<headers.size();k++){
            String section=headers.get(k).getText().toString();boolean has=false;
            for(int i=0;i<Duwm1683DeskCatalog.ALL.length;i++){
                if(Duwm1683DeskCatalog.ALL[i].category.equals(section)&&tiles.get(i).getVisibility()==View.VISIBLE){has=true;break;}
            }
            headers.get(k).setVisibility(has?View.VISIBLE:View.GONE);
        }
        if(resultCount!=null)resultCount.setText("FULL SCREEN DESKS  "+visible+" / "+Duwm1683DeskCatalog.ALL.length+
                                "   •   SAVED "+favorites.size());
    }
    private void refreshReceipts(){
        for(int i=0;i<Duwm1683DeskCatalog.ALL.length&&i<receiptLines.size();i++){
            receiptLines.get(i).setText(Duwm1683DeskCatalog.status(this,Duwm1683DeskCatalog.ALL[i]));
        }
    }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        prefs=getSharedPreferences("duwm1684_desk_nav",Context.MODE_PRIVATE);
        String saved=prefs.getString("favorites","");
        if(!saved.isEmpty())for(String name:saved.split("\u001f"))if(!name.isEmpty())favorites.add(name);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(BG);setContentView(shell);Duwm1167SafeArea.install(this,shell);
        TextView home=pill("← ORIGINAL COMMAND / ONE GLOBE");home.setGravity(Gravity.CENTER);
        home.setOnClickListener(v->finish());
        LinearLayout.LayoutParams back=new LinearLayout.LayoutParams(-1,dp(38));
        back.setMargins(dp(13),dp(9),dp(13),dp(7));shell.addView(home,back);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);
        shell.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14),dp(8),dp(14),dp(26));scroll.addView(root);
        TextView banner=text("WORLD SITUATION ROOM  /  1684",21,WHITE,true);
        banner.setPadding(0,dp(8),0,dp(11));root.addView(banner);
        Duwm1684SectorVisual commandVisual=new Duwm1684SectorVisual(this,"WORLD OPERATIONS",true);
        LinearLayout.LayoutParams commandLp=new LinearLayout.LayoutParams(-1,dp(182));
        commandLp.bottomMargin=dp(10);root.addView(commandVisual,commandLp);
        TextView lead=text("19 dedicated full-screen intelligence desks. Each opens its original functional page with an upgraded sector view, source receipts and detailed navigation.",13,WHITE,false);
        lead.setPadding(0,dp(3),0,dp(14));root.addView(lead);
        recentDesk=pill("RECENT DESK  /  NONE");
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(39));rp.bottomMargin=dp(7);
        root.addView(recentDesk,rp);recentDesk.setOnClickListener(v->{
            String last=prefs.getString("recentDesk","");
            for(Duwm1683DeskCatalog.Desk desk:Duwm1683DeskCatalog.ALL)
                if(desk.title.equals(last)){openDesk(desk);break;}
        });
        TextView caption=text("ONE ORIGINAL GLOBE  •  UNIFIED NAVY/TEAL DESIGN  •  PROVIDER-BACKED DATA",12,MUTED,false);
        caption.setPadding(0,dp(6),0,dp(12));root.addView(caption);
        searchBox=new EditText(this);searchBox.setSingleLine(true);searchBox.setTextSize(14);
        searchBox.setTextColor(WHITE);searchBox.setHintTextColor(MUTED);
        searchBox.setHint("SEARCH DESKS, SOURCES OR INFORMATION");
        searchBox.setBackground(background(false));searchBox.setPadding(dp(12),0,dp(12),0);
        root.addView(searchBox,new LinearLayout.LayoutParams(-1,dp(52)));
        android.widget.HorizontalScrollView sectionsScroll=new android.widget.HorizontalScrollView(this);
        sectionsScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout sectionsRow=new LinearLayout(this);sectionsRow.setOrientation(LinearLayout.HORIZONTAL);
        sectionsScroll.addView(sectionsRow);
        for(String label:new String[]{"ALL","AIR, SEA & EARTH","NEWS & MEDIA","DATA, RECORDS & SOURCES"}){
            TextView choice=pill(label);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,dp(39));
            cp.rightMargin=dp(7);sectionsRow.addView(choice,cp);
            choice.setOnClickListener(v->{sectionFilter=label;
                for(int j=0;j<sectionsRow.getChildCount();j++){
                    TextView b=(TextView)sectionsRow.getChildAt(j);
                    b.setBackground(background(b.getText().toString().equals(sectionFilter)));
                }
                filter(searchBox.getText().toString());});
            if(label.equals("ALL"))choice.setBackground(background(true));
        }
        TextView fav=pill("☆ SAVED DESKS");
        LinearLayout.LayoutParams favLp=new LinearLayout.LayoutParams(-2,dp(39));
        sectionsRow.addView(fav,favLp);
        fav.setOnClickListener(v->{onlyFavorites=!onlyFavorites;fav.setBackground(background(onlyFavorites));
            filter(searchBox.getText().toString());});
        LinearLayout.LayoutParams sectionsLp=new LinearLayout.LayoutParams(-1,dp(40));
        sectionsLp.topMargin=dp(9);root.addView(sectionsScroll,sectionsLp);
        resultCount=text("19 DESKS",12,CYAN,true);resultCount.setPadding(0,dp(10),0,dp(4));root.addView(resultCount);
        String group="";
        for(Duwm1683DeskCatalog.Desk d:Duwm1683DeskCatalog.ALL){
            if(!d.category.equals(group)){group=d.category;header(root,group);}
            item(root,d);
        }
        searchBox.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){filter(s.toString());}
            @Override public void afterTextChanged(Editable e){}
        });
        TextView foot=text("Each DETAILS panel describes the actual provider, record freshness, missing coverage and how to read the information. No synthetic live records are created.",12,MUTED,false);
        foot.setPadding(0,dp(8),0,dp(18));root.addView(foot);filter("");
    }
    @Override protected void onResume(){super.onResume();refreshReceipts();
        String last=prefs.getString("recentDesk","");
        if(recentDesk!=null)recentDesk.setText(last.isEmpty()?"RECENT DESK  /  NONE":"↗ RETURN TO  /  "+last);
    }
}
