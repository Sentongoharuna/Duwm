package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.View;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Locale;

/** TikTok-friendly 1080×1350 desk-specific visual card, generated using locally received data.
 * No downloaded image, invented source datum, location, trend or live badge is manufactured.
 */
public final class Duwm1684ShareCard {
    private Duwm1684ShareCard(){}
    private static final int W=1080,H=1350;
    private static final int INK=0xFFE4F4F7,ACCENT=0xFF83E7EC,MUTED=0xFF99BBC5;
    private static final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private static void text(Canvas c,String t,float x,float y,float size,int color,boolean bold){
        p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        p.setTextSize(size);p.setColor(color);c.drawText(t==null?"":t,x,y,p);
    }
    private static float wrap(Canvas c,String content,float x,float y,int maxWidth,int fontSize,int color,int maxLines){
        if(content==null || content.isEmpty())content="NOT PROVIDED";
        p.setTextSize(fontSize);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
        ArrayList<String> lines=new ArrayList<>();StringBuilder row=new StringBuilder();
        for(String word:content.replace('\n',' ').split("\\s+")){
            String proposal=row.length()==0?word:row+" "+word;
            if(p.measureText(proposal)>maxWidth && row.length()>0){lines.add(row.toString());row=new StringBuilder(word);}
            else row=new StringBuilder(proposal);
        }
        if(row.length()>0)lines.add(row.toString());
        for(int i=0;i<Math.min(maxLines,lines.size());i++){
            String line=lines.get(i);
            if(i==maxLines-1 && i<lines.size()-1)line=line+" …";
            text(c,line,x,y+(i*fontSize*1.47f),fontSize,color,false);
        }
        return y+Math.min(maxLines,Math.max(1,lines.size()))*fontSize*1.47f;
    }
    private static void field(Canvas c,String title,String value,float y,int maxLines){
        text(c,title,72,y,24,ACCENT,true);
        wrap(c,value,72,y+39,935,26,INK,maxLines);
    }
    public static void share(Activity a,Duwm1683DeskCatalog.Desk d){
        try{
            Duwm1684DeskDiagnostics.Snapshot s=Duwm1684DeskDiagnostics.read(a,d);
            Bitmap bmp=Bitmap.createBitmap(W,H,Bitmap.Config.ARGB_8888);
            Canvas c=new Canvas(bmp);c.drawColor(DuwmUnifiedTheme.BACKGROUND);
            p.setColor(0xFF0D3043);p.setStyle(Paint.Style.FILL);
            c.drawRoundRect(new RectF(37,42,1043,1298),37,37,p);
            p.setColor(DuwmUnifiedTheme.BORDER);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);
            c.drawRoundRect(new RectF(37,42,1043,1298),37,37,p);p.setStyle(Paint.Style.FILL);
            try{
                Drawable logo=a.getDrawable(R.drawable.develop_uganda_logo);
                if(logo!=null){logo.setBounds(74,83,177,186);logo.draw(c);}
            }catch(Exception ignored){}
            text(c,"DEVELOP.UGANDA  /  DUWM",200,126,29,ACCENT,true);
            text(c,"WORLD SITUATION ROOM  •  SOURCE CARD",200,164,19,MUTED,false);
            String title=d.title.toUpperCase(Locale.US);
            text(c,title.length()>28?title.substring(0,28):title,73,252,44,INK,true);
            Duwm1684SectorVisual sector=new Duwm1684SectorVisual(a,d.title,false);
            sector.measure(View.MeasureSpec.makeMeasureSpec(930,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(255,View.MeasureSpec.EXACTLY));
            sector.layout(0,0,930,255);c.save();c.translate(72,285);sector.draw(c);c.restore();
            text(c,"RECEIVED SOURCE INTELLIGENCE",72,599,25,ACCENT,true);
            field(c,"SOURCE STATE",s.state,647,1);
            field(c,"RECEIVED VALUE",s.count,739,1);
            field(c,"PROVIDER",s.provider,830,2);
            field(c,"LAST RECEIPT",s.received,961,2);
            field(c,"COVERAGE",s.coverage,1095,2);
            text(c,"DATA FROM THIS DEVICE'S PROVIDER RECEIPTS",72,1225,20,MUTED,false);
            text(c,"Visual illustration is not a plotted observation  •  DUWM 1684",72,1254,18,MUTED,false);
            File dir=new File(a.getCacheDir(),"share-cards");if(!dir.isDirectory()&&!dir.mkdirs())throw new Exception("Unable to create card cache");
            String safe=d.title.replaceAll("[^A-Za-z0-9]","-").toLowerCase(Locale.US);
            if(safe.length()>35)safe=safe.substring(0,35);
            File out=new File(dir,"duwm-1684-"+safe+"-"+System.currentTimeMillis()+".png");
            try(FileOutputStream os=new FileOutputStream(out)){
                if(!bmp.compress(Bitmap.CompressFormat.PNG,100,os))throw new Exception("PNG encode failed");
            }finally{bmp.recycle();}
            Uri uri=Uri.parse("content://"+a.getPackageName()+".sharecards/"+out.getName());
            Intent share=new Intent(Intent.ACTION_SEND);share.setType("image/png");
            share.putExtra(Intent.EXTRA_STREAM,uri);
            share.putExtra(Intent.EXTRA_TEXT,"DUWM / "+d.title+"\n"+s.report());
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            share.setClipData(android.content.ClipData.newUri(a.getContentResolver(),"DUWM source card",uri));
            a.startActivity(Intent.createChooser(share,"Share DUWM source image"));
        }catch(Exception e){
            android.widget.Toast.makeText(a,"Image card unavailable: "+e.getClass().getSimpleName(),android.widget.Toast.LENGTH_LONG).show();
        }
    }
}
