package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;
import java.util.Locale;

/** A visibly different schematic for each desk. All strokes, glyphs and scans are UI decoration,
 * never invented sensor positions, routes, market movements or provider observations. */
public final class Duwm1684SectorVisual extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final String title,mode;
    private final boolean motion;
    private float density;
    public Duwm1684SectorVisual(Context c,String title,boolean motion){
        super(c);this.title=title==null?"WORLD SOURCE":title;this.mode=mode(this.title);
        this.motion=motion;density=getResources().getDisplayMetrics().density;
        setContentDescription("Decorative "+mode+" sector illustration. Not a map of received signals or synthetic live data.");
    }
    public static String mode(String name){
        String n=name==null?"":name.toUpperCase(Locale.ROOT);
        if(n.contains("AIRCRAFT")||n.contains("FLIGHT")||n.contains("AIR RADAR"))return "AVIATION";
        if(n.contains("SHIP")||n.contains("MARITIME")||n.contains("MARINE")||n.contains("VESSEL"))return "MARITIME";
        if(n.contains("QUAKE")||n.contains("SEISMIC"))return "SEISMIC";
        if(n.contains("WEATHER"))return "WEATHER";
        if(n.contains("SATELLITE")||n.contains("NASA")||n.contains("ISS")||n.contains("ORBIT"))return "SPACE";
        if(n.contains("RADIO"))return "RADIO";
        if(n.contains("TV")||n.contains("TELEVISION")||n.contains("MEDIA"))return "TELEVISION";
        if(n.contains("CAMERA"))return "CAMERAS";
        if(n.contains("NEWS")||n.contains("ARTICLE"))return "NEWSROOM";
        if(n.contains("MARKET")||n.contains("FX")||n.contains("CURRENCY"))return "MARKETS";
        if(n.contains("MAP")||n.contains("GEO")||n.contains("PLACE"))return "GEOGRAPHY";
        if(n.contains("SOURCE")||n.contains("HEALTH"))return "SOURCE HEALTH";
        if(n.contains("EVIDENCE")||n.contains("RECORD"))return "EVIDENCE";
        return "OPERATIONS";
    }
    private void line(Canvas c,float x1,float y1,float x2,float y2){c.drawLine(x1,y1,x2,y2,p);}
    private void icon(Canvas c,float x,float y,float s){
        c.save();c.translate(x,y);c.scale(s,s);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.3f);p.setColor(0xFF89EEF1);
        RectF r = new RectF(-42,-32,42,32);
        switch(mode){
            case "AVIATION": {
                Path a=new Path();a.moveTo(0,-40);a.lineTo(8,-6);a.lineTo(37,7);a.lineTo(37,14);
                a.lineTo(8,8);a.lineTo(7,25);a.lineTo(18,32);a.lineTo(18,37);a.lineTo(0,31);
                a.lineTo(-18,37);a.lineTo(-18,32);a.lineTo(-7,25);a.lineTo(-8,8);
                a.lineTo(-37,14);a.lineTo(-37,7);a.lineTo(-8,-6);a.close();c.drawPath(a,p);break;}
            case "MARITIME": {
                Path a=new Path();a.moveTo(-41,4);a.lineTo(42,4);a.lineTo(26,26);a.lineTo(-27,26);a.close();c.drawPath(a,p);
                c.drawRect(-13,-13,18,4,p);line(c,-2,-26,-2,-13);
                for(int i=0;i<3;i++){float xx=-35+i*29;line(c,xx,34,xx+14,34);}break;}
            case "SEISMIC": {
                Path q=new Path();q.moveTo(-45,0);q.lineTo(-34,0);q.lineTo(-25,-8);q.lineTo(-16,19);
                q.lineTo(-5,-27);q.lineTo(8,28);q.lineTo(20,-14);q.lineTo(31,0);q.lineTo(44,0);c.drawPath(q,p);break;}
            case "WEATHER": {
                c.drawArc(-38,-27,-1,16,180,180,false,p);c.drawArc(-14,-38,28,15,180,180,false,p);
                line(c,-38,10,35,10);for(int i=-1;i<=1;i++){line(c,i*22-5,20,i*22-13,34);}break;}
            case "SPACE": {c.drawCircle(0,0,17,p);c.drawOval(-48,-21,48,21,p);
                c.drawOval(-20,-42,20,42,p);c.drawCircle(34,-14,4,p);break;}
            case "RADIO": {c.drawCircle(-3,2,6,p);line(c,-3,9,-3,39);c.drawArc(-24,-20,18,23,-65,130,false,p);
                c.drawArc(-40,-39,35,40,-65,130,false,p);break;}
            case "TELEVISION": {c.drawRoundRect(r,5,5,p);c.drawRect(-34,-24,34,20,p);
                line(c,-12,32,-12,40);line(c,12,32,12,40);line(c,-19,40,19,40);break;}
            case "CAMERAS": {c.drawCircle(0,0,35,p);c.drawCircle(0,0,17,p);
                for(int k=0;k<6;k++){double t=k*Math.PI/3;float xx=(float)(30*Math.cos(t));float yy=(float)(30*Math.sin(t));
                    c.drawCircle(xx,yy,3,p);}break;}
            case "NEWSROOM": {c.drawRect(-41,-35,41,36,p);c.drawRect(-32,-25,-6,-1,p);
                for(int k=0;k<5;k++){float yy=-21+k*12;line(c,k<2?2:-32,yy,k<2?32:32,yy);}break;}
            case "MARKETS": {c.drawRect(-41,-34,41,35,p);
                for(int k=0;k<4;k++){float xx=-29+k*20;line(c,xx,-13,xx,18);}break;}
            case "GEOGRAPHY": {c.drawCircle(0,0,37,p);c.drawOval(-19,-37,19,37,p);
                line(c,-37,0,37,0);c.drawOval(-37,-19,37,19,p);break;}
            case "EVIDENCE": {c.drawRoundRect(-32,-37,32,37,5,5,p);line(c,-18,-17,18,-17);
                line(c,-18,-1,18,-1);line(c,-18,15,13,15);break;}
            default: {c.drawCircle(0,0,36,p);c.drawCircle(0,0,23,p);line(c,-48,0,48,0);
                line(c,0,-47,0,47);break;}
        }
        c.restore();
    }
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);float w=getWidth(),h=getHeight();if(w<1||h<1)return;
        p.setStyle(Paint.Style.FILL);p.setShader(new LinearGradient(0,0,w,h,
            new int[]{0xFF144457,0xFF0B2B3C,0xFF071A29},null,Shader.TileMode.CLAMP));
        canvas.drawRoundRect(0,0,w,h,16*density,16*density,p);p.setShader(null);
        p.setStrokeWidth(0.7f*density);p.setColor(0x3347D2DB);
        for(int i=1;i<12;i++)line(canvas,i*w/12f,0,i*w/12f,h);
        for(int i=1;i<6;i++)line(canvas,0,i*h/6f,w,i*h/6f);
        float phase=motion?(SystemClock.uptimeMillis()%7200L)/7200f:0.37f;
        float beam=phase*w;
        p.setColor(0x1947D2DB);p.setStrokeWidth(13*density);line(canvas,beam,8*density,beam,h-8*density);
        float cx=w*.76f,cy=h*.50f;float s=Math.min(w/360f,h/130f)*.88f;
        p.setStyle(Paint.Style.STROKE);p.setColor(0x5547D2DB);p.setStrokeWidth(1.3f*density);
        canvas.drawCircle(cx,cy,52*s,p);canvas.drawCircle(cx,cy,72*s,p);
        icon(canvas,cx,cy,s);
        p.setStyle(Paint.Style.FILL);p.setTypeface(android.graphics.Typeface.create("sans-serif-medium",1));
        p.setTextSize(Math.min(16*density,h*.18f));p.setColor(0xFFE4F4F7);
        String heading=mode; if(p.measureText(heading)>w*.53f)heading=heading.substring(0,Math.min(12,heading.length()));
        canvas.drawText(heading,14*density,Math.max(29*density,h*.33f),p);
        p.setTypeface(android.graphics.Typeface.DEFAULT);p.setTextSize(Math.min(10*density,h*.095f));p.setColor(0xFF8FCAD1);
        canvas.drawText("DUWM  /  INTELLIGENCE DESK",14*density,h*.51f,p);
        canvas.drawText("VISUAL GUIDE • VERIFIED DATA BELOW",14*density,h*.70f,p);
        p.setColor(0xFF83E7EC);canvas.drawCircle(w-13*density,13*density,3*density,p);
        if(motion && isAttachedToWindow())postInvalidateDelayed(130L);
    }
}
