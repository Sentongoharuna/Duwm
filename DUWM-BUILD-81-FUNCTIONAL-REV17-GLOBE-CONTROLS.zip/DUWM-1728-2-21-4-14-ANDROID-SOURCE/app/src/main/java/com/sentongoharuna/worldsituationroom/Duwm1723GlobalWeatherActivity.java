package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Worldwide coordinate-based forecast desk. This is a MODEL forecast, not measured device weather.
 *  It makes no network request until the user taps FETCH and does not infer the user's location.
 *  Cached responses are explicitly labelled, dated and restricted to the same coordinates.
 */
public final class Duwm1723GlobalWeatherActivity extends Activity {
    private static final int NAVY=DuwmUnifiedTheme.APPROVED_NAVY;
    private static final int TEXT=DuwmUnifiedTheme.TEXT, MUTED=DuwmUnifiedTheme.MUTED;
    private static final String PREFS="duwm1723_world_weather_source", CACHE="body", CACHE_LAT="lat", CACHE_LON="lon", CACHE_AT="retrieved_utc";
    private static final int MAX_BYTES=210000;
    private static final String ATTRIBUTION="Open-Meteo forecast model • https://open-meteo.com/ • check commercial licensing";
    private final Handler handler=new Handler(Looper.getMainLooper());
    private LinearLayout results; private TextView status,title;
    private EditText latitude,longitude,place;
    private volatile boolean closed,fetching;
    private int requestSerial=0;
    private TextView fetchButton, daysButton, autoRefreshButton;
    private boolean autoRefreshEnabled=false, foreground=false;
    private static final long REFRESH_INTERVAL_MS=15*60*1000L;
    private long lastRequestStarted=0;
    private final Runnable periodicRefresh=new Runnable(){@Override public void run(){
        if(closed||!foreground||!autoRefreshEnabled)return;
        if(!fetching && coords()!=null && System.currentTimeMillis()-lastRequestStarted>=REFRESH_INTERVAL_MS)fetchForecast();
        handler.postDelayed(this,60*1000L);
    }};
    private int visibleDays=7;
    private String lastForecastRaw=null;
    private boolean lastForecastCached=false;
    private long lastForecastAt=0;
    private double shownRequestedLat=Double.NaN,shownRequestedLon=Double.NaN;
    private String shownPlace="";
    private int dp(float px){return Math.round(getResources().getDisplayMetrics().density*px);}
    private GradientDrawable frame(int border){GradientDrawable d=new GradientDrawable();d.setColor(NAVY);d.setCornerRadius(dp(15));d.setStroke(dp(1),border);return d;}
    private TextView text(String value,int size,int color){TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(color);v.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));return v;}
    private TextView button(String value,Runnable action){TextView v=text(value,12,TEXT);v.setGravity(Gravity.CENTER);v.setPadding(dp(10),dp(9),dp(10),dp(9));v.setMinHeight(dp(48));v.setBackground(frame(DuwmUnifiedTheme.BORDER));v.setOnClickListener(w->action.run());return v;}
    private LinearLayout.LayoutParams gap(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(10);return p;}
    private EditText input(String hint,String val){EditText e=new EditText(this);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setTextSize(14);e.setSingleLine(true);e.setHint(hint);e.setText(val);e.setPadding(dp(12),0,dp(12),0);e.setBackground(frame(DuwmUnifiedTheme.BORDER));e.setMinHeight(dp(48));return e;}
    @Override public void onCreate(Bundle b){super.onCreate(b);
        DuwmPageMotion32.apply(this); DuwmPageMotion33.configure(this, "WEATHER · global conditions"); // Build 32: consistent full-page navy chrome and transition

        getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(NAVY);
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(NAVY);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(14),dp(10),dp(14),dp(20));root.setBackgroundColor(NAVY);
        root.addView(text("DUWM 1723  /  WORLD WEATHER",21,TEXT),gap());
        root.addView(text("GLOBAL FORECAST DESK  •  SELECT ANY LOCATION  •  NO DEFAULT COUNTRY",11,MUTED),gap());
        root.addView(text("Weather here is opt-in numerical-model data. It is not a device sensor measurement or an official emergency warning.",12,MUTED),gap());
        String initName=getIntent().getStringExtra("duwm_place_name");
        String initLat=getIntent().getStringExtra("focus_lat"),initLon=getIntent().getStringExtra("focus_lon");
        place=input("Place / country (label only)",initName==null?"":initName);root.addView(place,gap());
        latitude=input("Latitude  −90 to 90",initLat==null?"":initLat);root.addView(latitude,gap());
        longitude=input("Longitude  −180 to 180",initLon==null?"":initLon);root.addView(longitude,gap());
        // Build 81 functional revision: real coordinate presets, not simulated forecasts.
        root.addView(text("WORLDWIDE QUICK LOCATIONS · TAP TO FETCH LIVE MODEL DATA",11,MUTED),gap());
        LinearLayout presets=new LinearLayout(this);presets.setOrientation(LinearLayout.VERTICAL);
        String[] presetNames={"KAMPALA","NAIROBI","LONDON","TOKYO","NEW YORK","DUBAI","MUMBAI","SYDNEY","JOHANNESBURG","LAGOS","CAIRO","SINGAPORE","SAO PAULO","PARIS","TORONTO","JAKARTA"};
        double[] presetLat={0.3476,-1.2921,51.5074,35.6762,40.7128,25.2048,19.0760,-33.8688,-26.2041,6.5244,30.0444,1.3521,-23.5505,48.8566,43.6532,-6.2088};
        double[] presetLon={32.5825,36.8219,-0.1278,139.6503,-74.0060,55.2708,72.8777,151.2093,28.0473,3.3792,31.2357,103.8198,-46.6333,2.3522,-79.3832,106.8456};
        LinearLayout presetRow=null;
        for(int i=0;i<presetNames.length;i++){
            if(i%2==0){presetRow=new LinearLayout(this);presetRow.setOrientation(LinearLayout.HORIZONTAL);presets.addView(presetRow,gap());}
            final int index=i;
            TextView preset=button(presetNames[i],()->{
                place.setText(presetNames[index]);
                latitude.setText(String.format(Locale.US,"%.4f",presetLat[index]));
                longitude.setText(String.format(Locale.US,"%.4f",presetLon[index]));
                status.setText("Requesting current model forecast for "+presetNames[index]+"…");
                fetchForecast();
            });
            LinearLayout.LayoutParams presetParams=new LinearLayout.LayoutParams(0,dp(52),1);
            if(i%2>0)presetParams.leftMargin=dp(6);
            presetRow.addView(preset,presetParams);
        }
        root.addView(presets,gap());
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
        TextView fetch=button("FETCH MODEL FORECAST",this::fetchForecast);fetchButton=fetch;
        TextView view=button("OPEN PLACE MAP",this::openMap);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(50),1);p.rightMargin=dp(5);actions.addView(fetch,p);actions.addView(view,new LinearLayout.LayoutParams(0,dp(50),1));root.addView(actions,gap());
        daysButton=button("FORECAST: 7 DAYS · TAP FOR 14",this::cycleForecastDays);
        daysButton.setContentDescription("Switch forecast between three, seven and fourteen days without downloading again");
        root.addView(daysButton,gap());
        autoRefreshButton=button("AUTO REFRESH: OFF · 15 MIN",()->{
            autoRefreshEnabled=!autoRefreshEnabled;
            getSharedPreferences(PREFS,MODE_PRIVATE).edit().putBoolean("auto_refresh",autoRefreshEnabled).apply();
            updateAutoRefreshControl();
            handler.removeCallbacks(periodicRefresh);
            if(autoRefreshEnabled&&foreground)handler.post(periodicRefresh);
        });
        autoRefreshButton.setContentDescription("Enable or disable periodic weather model refresh every fifteen minutes while this screen is visible");
        root.addView(autoRefreshButton,gap());
        autoRefreshEnabled=getSharedPreferences(PREFS,MODE_PRIVATE).getBoolean("auto_refresh",false);
        updateAutoRefreshControl();
        title=text("SOURCE STATUS",14,TEXT);root.addView(title,gap());
        status=text("Choose a place in Global Discovery or enter valid coordinates. No network request has been made.",12,MUTED);root.addView(status,gap());
        results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);root.addView(results,gap());
        root.addView(button("CHOOSE A PLACE WORLDWIDE",()->startActivity(new Intent(this,Duwm1718GlobalDiscoverActivity.class))),gap());
        root.addView(button("SHARE VISIBLE FORECAST DETAILS",this::shareCurrent),gap());
        root.addView(text(ATTRIBUTION+". Do not use a forecast alone for emergency decisions; follow local official warnings.",11,MUTED),gap());
        sc.addView(root);setContentView(sc);
        if(initLat!=null&&initLon!=null){showCacheIfMatching();}
    }
    private double[] coords(){try{
        double lat=Double.parseDouble(latitude.getText().toString().trim()),lon=Double.parseDouble(longitude.getText().toString().trim());
        if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)throw new IllegalArgumentException("Coordinates outside Earth range");
        return new double[]{lat,lon};
    }catch(Exception e){status.setText("INVALID COORDINATES: Enter latitude between −90 and 90 and longitude between −180 and 180.");return null;}}
    private static String utc(long millis){SimpleDateFormat d=new SimpleDateFormat("yyyy-MM-dd HH:mm 'UTC'",Locale.US);d.setTimeZone(TimeZone.getTimeZone("UTC"));return d.format(new Date(millis));}
    private static String code(int v){
        if(v==0)return "Clear";if(v==1||v==2)return "Partly cloudy";if(v==3)return "Overcast";
        if(v==45||v==48)return "Fog";if(v>=51&&v<=57)return "Drizzle";if(v>=61&&v<=67)return "Rain";
        if(v>=71&&v<=77)return "Snow";if(v>=80&&v<=82)return "Rain showers";if(v>=85&&v<=86)return "Snow showers";
        if(v>=95&&v<=99)return "Thunderstorm";return "Model code "+v;
    }
    private String placeLabel(){String s=place.getText().toString().trim();return s.isEmpty()?"SELECTED COORDINATES":s;}
    private void showCacheIfMatching(){double[] c=coords();if(c==null)return;
        android.content.SharedPreferences prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        if(Math.abs(prefs.getFloat(CACHE_LAT,999f)-c[0])>0.005||Math.abs(prefs.getFloat(CACHE_LON,999f)-c[1])>0.005)return;
        String cached=prefs.getString(CACHE,"");if(cached.isEmpty())return;
        try{render(cached,true,prefs.getLong(CACHE_AT,0L),c[0],c[1],placeLabel());}catch(Exception ignored){status.setText("Cached model response could not be read. Fetch again.");}
    }
    private void fetchForecast(){double[] c=coords();if(c==null)return;
        if(fetching){status.setText("A forecast request is already in progress. Please wait.");return;}
        fetching=true;lastRequestStarted=System.currentTimeMillis();final int serial=++requestSerial;
        fetchButton.setEnabled(false);fetchButton.setAlpha(0.55f);
        final double lat=c[0],lon=c[1];status.setText("REQUESTING FORECAST MODEL for "+placeLabel()+"… No device location permission required.");
        final String name=placeLabel();
        new Thread(()->{
            HttpURLConnection connection=null;
            try{
                String u=String.format(Locale.US,"https://api.open-meteo.com/v1/forecast?latitude=%.5f&longitude=%.5f&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,wind_speed_10m,wind_direction_10m,cloud_cover,weather_code&hourly=temperature_2m,precipitation_probability,weather_code&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,wind_speed_10m_max,weather_code&forecast_days=14&timezone=auto",lat,lon);
                connection=(HttpURLConnection)new URL(u).openConnection();connection.setConnectTimeout(8000);connection.setReadTimeout(9000);
                if(connection.getResponseCode()!=200)throw new IllegalStateException("Forecast HTTP "+connection.getResponseCode());
                try(InputStream in=connection.getInputStream();ByteArrayOutputStream buf=new ByteArrayOutputStream()){
                    byte[] data=new byte[8192];int n;while((n=in.read(data))!=-1){if(buf.size()+n>MAX_BYTES)throw new IllegalStateException("Forecast response too large");buf.write(data,0,n);}
                    String raw=buf.toString("UTF-8");JSONObject parsed=new JSONObject(raw);
                    if(parsed.optJSONObject("current")==null||parsed.optJSONObject("daily")==null)throw new IllegalStateException("Provider returned no forecast data");
                    long downloaded=System.currentTimeMillis();
                    getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(CACHE,raw).putFloat(CACHE_LAT,(float)lat).putFloat(CACHE_LON,(float)lon).putLong(CACHE_AT,downloaded).apply();
                    handler.post(()->{
                        if(closed||serial!=requestSerial)return;
                        double[] present=coords();
                        if(present==null||Math.abs(present[0]-lat)>0.005||Math.abs(present[1]-lon)>0.005){
                            status.setText("Forecast for "+name+" downloaded but your selected coordinates changed. Re-select that place to use the new cached result.");
                            return;
                        }
                        render(raw,false,downloaded,lat,lon,name);
                    });
                }
            }catch(Exception error){handler.post(()->{if(closed||serial!=requestSerial)return;status.setText("FORECAST UNAVAILABLE: "+error.getMessage()+". Retaining the last labelled result, if any.");});}
            finally{if(connection!=null)connection.disconnect();fetching=false;handler.post(()->{if(!closed&&serial==requestSerial){fetchButton.setEnabled(true);fetchButton.setAlpha(1f);}});}
        },"duwm1723-weather-opt-in").start();
    }
    private void cycleForecastDays(){
        visibleDays=visibleDays==7?14:visibleDays==14?3:7;
        daysButton.setText("FORECAST: "+visibleDays+" DAYS · TAP TO CHANGE");
        if(lastForecastRaw!=null)render(lastForecastRaw,lastForecastCached,lastForecastAt,shownRequestedLat,shownRequestedLon,shownPlace);
        else status.setText("Forecast range set to "+visibleDays+" days. Fetch a location to see model data.");
    }
    private TextView reportCard(String heading,String detail){TextView v=text(heading+"\n"+detail,13,TEXT);v.setPadding(dp(12),dp(12),dp(12),dp(12));v.setLineSpacing(dp(3),1f);v.setBackground(frame(DuwmUnifiedTheme.DIVIDER));return v;}
    private static String number(JSONObject o,String key,String unit){return o!=null&&o.has(key)&&!o.isNull(key)?String.format(Locale.US,"%.1f%s",o.optDouble(key),unit):"UNAVAILABLE";}
    private static String valueAt(JSONArray a,int i,String suffix){if(a==null||i>=a.length()||a.isNull(i))return "—";Object o=a.opt(i);return String.valueOf(o)+suffix;}
    private void render(String raw,boolean cached,long downloaded,double requestedLat,double requestedLon,String requestedPlace){try{
        JSONObject all=new JSONObject(raw);JSONObject cur=all.getJSONObject("current"),daily=all.getJSONObject("daily");
        JSONArray dates=daily.getJSONArray("time");if(dates.length()==0)throw new IllegalArgumentException("Empty forecast");
        results.removeAllViews();lastForecastRaw=raw;lastForecastCached=cached;lastForecastAt=downloaded;shownRequestedLat=requestedLat;shownRequestedLon=requestedLon;shownPlace=requestedPlace;
        String localZone=all.optString("timezone","PROVIDER TIMEZONE UNAVAILABLE");
        status.setText((cached?"CACHED FORECAST / NOT LIVE":"MODEL FORECAST RECEIVED")+" • downloaded "+utc(downloaded)+"\nPROVIDER LOCAL TIME ZONE: "+localZone+"\nSOURCE: Open-Meteo model forecast; not official warning information.");
        String current="Provider observation time "+cur.optString("time","TIME UNAVAILABLE")+"\nTemperature "+number(cur,"temperature_2m","°C")+
             "  •  Feels like "+number(cur,"apparent_temperature","°C")+"\nHumidity "+number(cur,"relative_humidity_2m","%")+
             "  •  Wind "+number(cur,"wind_speed_10m"," km/h")+"\nWind heading "+number(cur,"wind_direction_10m","°")+"  •  Cloud cover "+number(cur,"cloud_cover","%")+"\nPrecipitation "+number(cur,"precipitation"," mm")+
             "  •  "+code(cur.optInt("weather_code",-1));
        results.addView(reportCard("CURRENT MODEL CONDITIONS / "+shownPlace,current),gap());
        JSONArray hi=daily.optJSONArray("temperature_2m_max"),lo=daily.optJSONArray("temperature_2m_min"),rain=daily.optJSONArray("precipitation_probability_max"),wx=daily.optJSONArray("weather_code");
        JSONArray precipitation=daily.optJSONArray("precipitation_sum"),maxWind=daily.optJSONArray("wind_speed_10m_max");
        // At-a-glance forecast risk summary based solely on provider daily fields.
        int wetDays=0,windyDays=0;double warmest=Double.NEGATIVE_INFINITY,coldest=Double.POSITIVE_INFINITY;
        for(int i=0;i<Math.min(visibleDays,dates.length());i++){
            if(rain!=null&&!rain.isNull(i)&&rain.optDouble(i,0)>=60)wetDays++;
            if(maxWind!=null&&!maxWind.isNull(i)&&maxWind.optDouble(i,0)>=40)windyDays++;
            if(hi!=null&&!hi.isNull(i))warmest=Math.max(warmest,hi.optDouble(i));
            if(lo!=null&&!lo.isNull(i))coldest=Math.min(coldest,lo.optDouble(i));
        }
        String range=(Double.isFinite(coldest)?String.format(Locale.US,"%.1f°C to %.1f°C",coldest,warmest):"Not available");
        String overview="Temperature range: "+range+"\nDays with rain chance ≥60%: "+wetDays+" / "+Math.min(visibleDays,dates.length())+
            "\nDays with model maximum wind ≥40 km/h: "+windyDays+
            "\nForecast indicators only; not official weather alerts.";
        results.addView(reportCard("FORECAST OUTLOOK / NEXT "+visibleDays+" DAYS",overview),gap());
        for(int i=0;i<Math.min(visibleDays,dates.length());i++){
            String d=dates.optString(i,"DATE UNAVAILABLE");String detail="High "+valueAt(hi,i,"°C")+"   •   Low "+valueAt(lo,i,"°C")+
                "\nRain probability (model max) "+valueAt(rain,i,"%")+"   •   "+code(wx==null?-1:wx.optInt(i,-1))+
                "\nPrecipitation "+valueAt(precipitation,i," mm")+"   •   Maximum wind "+valueAt(maxWind,i," km/h");
            results.addView(reportCard(d+"  /  DAILY MODEL FORECAST",detail),gap());
        }
        // Actual first-seven-day temperature chart from the provider response; fourteen daily cards above.
        results.addView(new TemperatureChart(hi,lo,dates),gap());
        JSONObject hourly=all.optJSONObject("hourly");if(hourly!=null){
            JSONArray times=hourly.optJSONArray("time"),temps=hourly.optJSONArray("temperature_2m"),chance=hourly.optJSONArray("precipitation_probability");
            StringBuilder next=new StringBuilder();if(times!=null){
                String now=cur.optString("time","");int first=0;
                while(first<times.length()&&times.optString(first).compareTo(now)<0)first++;
                for(int i=first;i<Math.min(times.length(),first+12);i++){
                next.append(times.optString(i)).append("  •  ").append(valueAt(temps,i,"°C")).append("  •  rain ").append(valueAt(chance,i,"%")).append("\n");
            }}results.addView(reportCard("NEXT 12 MODEL HOURS / PROVIDER LOCAL TIME",next.toString()),gap());
        }
    }catch(Exception e){status.setText("MODEL RESPONSE UNREADABLE: "+e.getMessage());}}

    /** Draws a seven-day high/low chart from real model values, never placeholder numbers. */
    private final class TemperatureChart extends View {
        private final float[] high,low;private final String[] labels;
        private final Paint paint=new Paint(3);
        TemperatureChart(JSONArray highs,JSONArray lows,JSONArray dates){super(Duwm1723GlobalWeatherActivity.this);
            int n=Math.min(7,dates.length());high=new float[n];low=new float[n];labels=new String[n];
            for(int i=0;i<n;i++){high[i]=(float)(highs==null?Double.NaN:highs.optDouble(i,Double.NaN));low[i]=(float)(lows==null?Double.NaN:lows.optDouble(i,Double.NaN));labels[i]=dates.optString(i,"");}
            setContentDescription("Seven day forecast temperature chart. Highs in orange and lows in cyan.");
        }
        @Override protected void onMeasure(int w,int h){setMeasuredDimension(MeasureSpec.getSize(w),dp(205));}
        @Override protected void onDraw(Canvas c){super.onDraw(c);
            c.drawColor(NAVY);if(high.length<2)return;
            float min=Float.POSITIVE_INFINITY,max=Float.NEGATIVE_INFINITY;
            for(int i=0;i<high.length;i++){if(Float.isFinite(high[i])){min=Math.min(min,high[i]);max=Math.max(max,high[i]);}if(Float.isFinite(low[i])){min=Math.min(min,low[i]);max=Math.max(max,low[i]);}}
            if(!Float.isFinite(min)||!Float.isFinite(max))return;
            min-=2;max+=2;float left=dp(35),right=getWidth()-dp(20),top=dp(25),bottom=getHeight()-dp(35);
            paint.setStrokeWidth(dp(1));paint.setColor(0xff33465f);
            for(int j=0;j<4;j++){float y=top+(bottom-top)*j/3f;c.drawLine(left,y,right,y,paint);}
            paint.setTextSize(dp(10));paint.setColor(TEXT);
            for(int i=0;i<high.length;i++){float x=left+(right-left)*i/(high.length-1f);String d=labels[i];c.drawText(d.length()>5?d.substring(5):d,x-dp(12),getHeight()-dp(12),paint);}
            for(int series=0;series<2;series++){float[] values=series==0?high:low;paint.setColor(series==0?0xffffae52:0xff44d4e9);paint.setStrokeWidth(dp(2.5f));
                for(int i=1;i<values.length;i++){if(!Float.isFinite(values[i])||!Float.isFinite(values[i-1]))continue;float x0=left+(right-left)*(i-1)/(values.length-1f),x1=left+(right-left)*i/(values.length-1f);float y0=bottom-(values[i-1]-min)/(max-min)*(bottom-top),y1=bottom-(values[i]-min)/(max-min)*(bottom-top);c.drawLine(x0,y0,x1,y1,paint);}
                for(int i=0;i<values.length;i++){if(!Float.isFinite(values[i]))continue;float x=left+(right-left)*i/(values.length-1f),y=bottom-(values[i]-min)/(max-min)*(bottom-top);c.drawCircle(x,y,dp(3),paint);}
            }
            paint.setTextSize(dp(11));paint.setColor(0xffffae52);c.drawText("HIGH",left,dp(15),paint);paint.setColor(0xff44d4e9);c.drawText("LOW",left+dp(52),dp(15),paint);
        }
    }

    private void openMap(){double[] c=coords();if(c==null)return;Intent i=new Intent(this,DuwmPlaceMapActivity.class);i.putExtra("focus_lat",String.format(Locale.US,"%.6f",c[0]));i.putExtra("focus_lon",String.format(Locale.US,"%.6f",c[1]));startActivity(i);}
    private void shareCurrent(){if(results==null||results.getChildCount()==0){status.setText("No received forecast to share. Fetch one first.");return;}
        double[] c=coords();if(c==null||Math.abs(c[0]-shownRequestedLat)>0.005||Math.abs(c[1]-shownRequestedLon)>0.005){
            status.setText("The place coordinates changed after the forecast was loaded. Fetch the selected place before sharing.");return;
        }
        StringBuilder s=new StringBuilder("DUWM MODEL WORLD WEATHER / ").append(shownPlace).append("\n").append(status.getText());
        for(int i=0;i<results.getChildCount();i++)if(results.getChildAt(i) instanceof TextView)s.append("\n\n").append(((TextView)results.getChildAt(i)).getText());
        s.append("\n\n").append(ATTRIBUTION).append("\nNot official emergency advice.");
        Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,s.toString());startActivity(Intent.createChooser(send,"Share cited DUWM model weather"));
    }
    private void updateAutoRefreshControl(){
        if(autoRefreshButton!=null)autoRefreshButton.setText(autoRefreshEnabled?"AUTO REFRESH: ON · 15 MIN":"AUTO REFRESH: OFF · 15 MIN");
    }
    @Override protected void onResume(){super.onResume();foreground=true;handler.removeCallbacks(periodicRefresh);if(autoRefreshEnabled)handler.post(periodicRefresh);}
    @Override protected void onPause(){foreground=false;handler.removeCallbacks(periodicRefresh);super.onPause();}
    @Override protected void onDestroy(){closed=true;handler.removeCallbacks(periodicRefresh);super.onDestroy();}
}
