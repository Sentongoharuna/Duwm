# DUWM 1691 — source-backed native visual overhaul

**Base:** Exact DUWM 1690 source archive SHA-256 `d6b527de76cb775eeb2d8ec5ed1fa1c6079c1b854ade4ef3b37bdc024dacaad3`.

## Visible change summary

- Six existing Android intelligence screens now receive a consistent native title/header treatment, with their existing real-data and in-app playback preserved.
- The source metric visual used by Aircraft, Ships, News, Radio, Media and Source Health (also the all-desk Overview tab) was rebuilt in place as four large high-contrast source-backed instrument tiles. No invented totals, trends or source positions.
- All 19 workspace desk analysis visuals have been changed from a decorative radar to a professional provider state and timestamped receipt trend. Actual numeric history with at least two distinct timestamps is required before drawing any trend.
- Mission board sector filters scroll horizontally, correcting compressed filter chip widths on narrow phones. Each existing desk card distinguishes its provider state; saved desk and native routes remain unchanged.
- Source Health existing rows now distinguish current and review-required status using backgrounds, retaining timestamps/errors/links.
- Old 1690 launcher, specialist, sharing, Options and navigation labels are replaced with 1691.

## Not changed

- One and only one original globe (`SatelliteMapView`) and original launcher `MainActivity` geometry and navigation.
- Current aircraft, AIS, news and other source network endpoints; no fabricated data.
- Existing `MediaPlayer`, `VideoView` and underlying media decoding and error behavior.
- App ID `com.sentongoharuna.worldsituationroom.rb2live25` to preserve upgrade compatibility.

## Release checks

Run `python3 verification/check_1691_lineage.py` plus the inherited checks. Java parser validates source grammar but does not compile against Android. The paired GitHub workflow is responsible for Gradle, APK signature, embedded native classes and exact manifest identity. An APK should not be described as green until the workflow succeeds.
