# DUWM 1717 — SOURCE RECEIPT AUDIT / evidence history

This is a functional upgrade to the **original DUWM 1716** Android source. It does not create another globe or app shell. The original rotating globe remains in `MainActivity` and all nineteen sectors, signal indicators, full-screen desks, and provider integrations are preserved.

## User-visible new functionality
- A new full-screen `Duwm1717ReceiptAuditActivity` opened from the existing Signal Centre.
- An on-device ledger of **up to twelve** user-triggered observations across all **19** original desks; nothing is captured, uploaded or polled automatically by this feature.
- A scrollable 19-sector status heatmap with source-state lights representing actual saved diagnostic readings, never animated mock values.
- Each heatmap cell opens the saved provider, count, stored receipt time, scope and error text, with direct navigation into the corresponding desk.
- Stable-field change comparison that strips the changing *minutes ago* display so passing time alone does not create a false new event. An unchanged capture reports **NO CHANGES** without writing a duplicate.
- Explicit baseline, confirmed local clear, and plaintext share labelled as user-captured local evidence, not verified global events.
- The exact screenshot design remains **navy `#041424`**, thin silver `#DEE5EF` outlines, white text, grey headings and limited factual status colours.

## Release constraints
- Existing source ZIP upgraded in place; no replacement globe, no fake source-data generator.
- Android versionCode `171700`, versionName `1717`, `DUWM 1717 • DEVELOP.UGANDA`.
- A source syntax test does not prove Android build or emulator success. Only a GitHub run with a signed APK artifact establishes a compiled APK.
- Repeated / legacy GitHub workflows can start on every push; use only the explicitly named 1717 workflow for release provenance.
