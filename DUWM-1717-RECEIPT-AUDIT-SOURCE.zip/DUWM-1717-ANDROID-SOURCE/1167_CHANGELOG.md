# DUWM 1167 — Native Android source upgrade (3 November 2026)

## Verified changes in this source archive

- Based on the actual 1166 archive matching SHA-256 `1c6bfd884fc077c1d67e3cd910c2891a8f7dd1b78ef9f35c1768e884d9f992bd`.
- Native `Duwm1167SafeArea` uses Android system-bar insets to prevent content from overlapping the phone clock and navigation region on the observed intelligence, radio, news, media, NASA and article screens. Original globe/map-specific insets handling is preserved.
- User-triggered `REFRESH VERIFIED SOURCES` now bypasses the scheduled request cooldown. Periodic polling remains throttled; live provider rate limits still apply.
- The source board distinguishes **pending**, **received** and **unavailable** source requests instead of conflating pending with unavailable.
- Individual aircraft, earthquake, satellite, weather and vessel record pages now explicitly label the capped saved position sample, separate from full provider counts. Graphs draw only actual saved coordinates, with improved readability and zero-record handling. Screens refresh saved records on return.
- Radio Atlas adds Kenya, Nigeria, UK, USA and South Africa regional selectors, an explicit STOP AUDIO control and a count of stations with provided coordinates. Stations without coordinates remain unmapped.
- 9:16 news portrait cards fit the original source URL within the 1080px canvas; source photo availability and publisher attribution remain honest.
- App version updated to 1167/116700; the Android application ID is unchanged to support in-place upgrades.

## Protected systems

Detailed rotating Earth renderer, original satellite globe, live wallpaper, source-driven news, NASA viewer, widgets, and in-app media/player remain in the native source. No fabricated positions, events, station coordinates or image assets are introduced.

## Build and device validation

Static checks and regression scripts can run locally. A GitHub-hosted Android build with Java 17 / Gradle 8.13 must still pass, publish APK, and be tested on a physical phone. This archive **does not prove** external streams, worldwide AIS, full satellite coverage, publisher embedding, or on-device playback. The 1167 upgrade does not claim to introduce new worldwide AIS suppliers or working TV stations beyond provider responses.
