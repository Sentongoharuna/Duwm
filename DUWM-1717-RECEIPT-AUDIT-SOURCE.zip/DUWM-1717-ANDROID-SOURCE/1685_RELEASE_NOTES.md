# DUWM 1685 — substantial, visible, all-desk Android upgrade

**Version:** 1685 / versionCode 168500. **Base:** the full DUWM 1684 Android source and workflow, not a new shell or an alternative globe.

## What actually changes in source

1. **All 19 registered native desk destinations** receive the new 1685 command-console header: much larger desk title, sector-specific visual, real provider receipt state/number/time, direct source-detail and image-sharing buttons, and expandable receipt history with the desk-specific interpretation and limitation. All modifications are attached to the original Activity content rather than replacing the native map, list or stream player. Full canvas and video screens receive a collapsible 1685 bar with restore control instead of a large covering header.
2. **Options hub** includes a new three-zone 19-desk status board with source-recency counts derived from actual on-device receipts, 7 received-provider chart previews, prominent native launch and direct share-card actions for each of the 19 desks. Existing saved favorites, recent desk, search and categories remain.
3. **Individual full-screen source dossiers** now expose locally observed provider receipt histories, cross-sector shortcuts, the same actual source diagnostics, fresh timestamps, and tall image sharing. The existing previous/next navigation and native data route remain.
4. **Home Command Center** retains the existing single original rotating `SatelliteMapView`; its mission dock adds source receipt access, 1685 desk navigation and a source-aware SHARE SOURCE action that requires an actual category selection (otherwise it opens the desk chooser).
5. **Social share cards** are now portrait 1080 × 1920 PNG files rather than 1080 × 1350. Each includes the app mark, sector visual, provider state/count, coverage, source timestamp and a receipt-history panel. Images are encoded from the device state and shared using the existing read-only Android ContentProvider.
6. **Real receipt history:** a point can be added only when the actual stored provider receipt timestamp changes; cached rereads cannot increment the timeline. Numeric charts are shown **only** when at least two source receipts contain numeric values. Otherwise timestamps are presented as time markers, not invented trends. Local-only tools carry no fake telemetry.

## Nonclaims and limitations

- Not a new flight radar provider, AIS coverage expansion, new TV licence, unlimited publisher scrape or fabricated map tracks. All connected providers and genuine native data views remain those present in the inherited source.
- The 1685 artwork is a clearly labeled schematic, not a photograph from the publisher or a plot of real geographical positions.
- Java AST parsing and the source checks are not Android compilation. Phone playback, live connectivity, screen appearance and APK installability require a green Android build and actual device testing.

## Source integrity

`app/build.gradle.kts`, `app/src/main/assets/duwm_release_ui.json`, `DuWorldApplication`, `MainActivity`, `DuwmOptionsActivity`, `Duwm1683DeskFullScreenActivity` and the five new Java classes are updated. The original `SatelliteMapView` is retained, as are 1684 components for traceability. One 1685 console lifecycle hook is installed; 1684's panel hook is **not** installed, preventing duplicate headers.
