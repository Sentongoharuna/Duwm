# DUWM 1683 — Full-screen intelligence desks repair

- The one original MainActivity + SatelliteMapView globe remains the launcher and is unchanged.
- All nineteen Options destinations now use fullscreen native Android activity space (status bar hidden; navigation remains available).
- SOURCE / DETAILS opens a dedicated full-screen source-information activity rather than an AlertDialog overlay.
- The details screen includes real provider status, available record age, coverage, errors, share action and a button opening the existing full desk.
- News, TV, radio, public cameras, AIS ships, aircraft, satellite, earthquake, weather, markets, and other registered destinations retain their real data code.
- The media desk now uses compact navigation and gives more vertical space to the stream and source list.
- Aircraft, maritime and specialist event maps have more useful vertical map space; source text and other controls remain scrollable.
- The SDK/third-party media/API restrictions still apply; fullscreen does not guarantee an external feed will connect.
- Version code 168301 allows an upgrade over version 168300 without changing the application ID.

## Validation

Run `python3 verification/check_1683_fullscreen.py` and `python3 verification/check_1683_all_detail_desks.py` then the Gradle compile step. Do not consider phone playback verified just because javac and Gradle succeed.
