# DUWM 1677 – Global Situation Room (Native Android)

## What is actually new
- A new launcher Activity (`Duwm1677MissionControlActivity`) is used by the Android manifest. It is not a subclass of the old fixed command deck.
- A mobile-first dark/cyan Mission Control visual hierarchy, source receipt strip with 8 channels, accessible nav rail, animated Earth view, regional WDBII country-border map, news wire and distinct operational tiles.
- Globe dots, regional markers and counts are derived from device-cached source responses, and visible source-status colours reflect freshness/absence. Real date labels include years.
- Clicking an actual marker opens its source details and a 9:16 share-card action; the TV, radio, camera, aircraft, maritime, news, weather, markets, earthquakes, satellite, Evidence Vault, Geographic Watchlist and source directory screens remain reachable.
- Source refresh delegates to the existing OpenSky, native RSS/GDELT, public AIS and multi-feed collectors with their required access limits. No made-up flights, geopolitical scores, radiation levels or road damage readings.
- The new launcher does not require historic layout hashes or a frozen `*CommandDeckActivity` naming convention.

## Scope and what is NOT yet verified
- The provided generated design picture was only a visual reference. The Android screen is native layout code, not a still image with simulated figures.
- Regional and global position dots depend on real available cache rows. When a source is missing or stale, the UI shows an unavailable/cached state.
- Geopolitical/news article counts are source-reported publications, not proof that any incident occurred.
- Infrastructure/road-scanning and radiation meters require actual measurement feeds and are **not** claimed operational.
- 1677 Gradle compilation, actual TV playback, network coverage and phone layout remain unverified until Actions produces an APK and phone testing confirms behaviour.

## Acceptance test after APK install
1. Android launcher shows `DUWM / v1677` and a vertically scrollable redesigned mission control, with the status bar unobscured.
2. All eight top status cells are visible by horizontal swiping. No data receipt must not be labelled live.
3. Globe rotates and supports drag, pinch, tap on a real observation, palette toggle and layer filters.
4. The second, separate map shows country boundaries; tap on a sourced pin opens details.
5. AIR/SEA/NEWS numbers reflect source caches, and manual SYNC requests eligible feeds without faking new telemetry.
6. The share-card action uses a genuinely selected observation.
7. Camera, television, radio, Evidence Vault and Geographic Watchlist actions open their corresponding screens.
