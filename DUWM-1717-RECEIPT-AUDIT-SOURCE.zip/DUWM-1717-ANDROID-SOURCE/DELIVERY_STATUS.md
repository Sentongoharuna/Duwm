# DUWM 1696 — candidate source, not an APK release

The source ZIP and workflow must be uploaded to GitHub. The current environment cannot compile Android APKs. A green GitHub Actions run, signed APK and on-phone testing are required before calling 1696 released.
