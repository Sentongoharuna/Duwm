# DUWM 1715 — Signal lights FIX2

- The approved single rotating globe is retained. No duplicate globe or overlay.
- Every native Activity is given one slim 34dp status-light rail **in layout** above its content.
- Nineteen lights correspond to the existing nineteen desks, not new or simulated feeds.
- Lights use real stored source receipts from Duwm1684DeskDiagnostics and the existing FeedStatus runtime callbacks.
- Green = recent/live source, amber = stale/loading/cached, red = failed/offline, grey = no receipt/not configured, blue = local tool. This legend is semantic, not decorative.
- A short pulse is allowed only after actual new source records or a different weather frame is accepted, never from a timer inventing events.
- Status indicators appear alongside every sector card and comparison card in the Operations Matrix, plus each native desk dock.
- Original app-wide formal midnight navy (#050D22), consistent 0.85dp thin sector outlines, original ticker and signal rails remain.
- No new notification, GPS, network, broadcast, permissions, or synthetic data sources.
- GitHub's Android 35 system-image download failure in build 1714 is isolated in an optional smoke-test job; the signed APK is uploaded independently.
- Version name deliberately remains 1715 until a genuinely compiled APK passes build verification.
