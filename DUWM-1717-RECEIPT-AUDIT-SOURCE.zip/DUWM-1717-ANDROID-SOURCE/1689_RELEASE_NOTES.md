# DUWM 1689 | Native evidence workflows — inherited from 1688

**Exact build parent:** `DUWM-1688-NATIVE-PAGE-UPGRADE-SOURCE.zip` (SHA-256 `244da3e1d32762ee6b6f66018693a8ea10d7e4923a8530907c0f9ec28e374809`), not version 1678. The original launcher `MainActivity` and `SatelliteMapView` globe remain the single command centre; built-in map and Android media engines remain intact.

## Existing screens materially upgraded

1. **Aircraft:** WORLD/AFRICA/EUROPE/MIDDLE EAST/INDIA-ASIA/AMERICAS/PACIFIC selections filter the actual received points rather than merely moving the map camera. Latest-20-minute source-fix toggle, true recency ordering, two-fix evidence remains preserved. Region boundaries are broad approximations; OpenSky data does not imply complete worldwide coverage.
2. **Maritime:** Real reported AIS ship-type filters (cargo, tankers, passenger, other/unknown) work simultaneously on the existing map, radar and ship list. Only the 1,200 newest matching vessel reports draw per frame, avoiding thousands of simultaneous marker objects; full source results remain in lazy list pages. Selected reported ship now shows AIS type and vessel-reported destination, if any.
3. **News:** Save a received publisher's HTTPS story link, filter to saved stories within the current cached responses, and see actual matching results / total pages. No fake articles or synthesized publisher images.
4. **Radio:** Save received HTTPS radio stream URLs, filter those actually returned in the selected country, and show actual matching and source-geotagged totals on the existing map. Native player remains unchanged.
5. **Media (TV, radio, news, cameras):** Source-order / alphabetical sorting, fully browsable received records in increments of 45, real matching/shown figures. Replaces previous hard cap of 90 visible entries; native video, camera and audio playback unaffected.
6. **Source Health:** Filter to missing/delayed/error sources, keeping verified live source statuses distinct. No directory link is labelled a real observation.
7. **Release identification:** Existing mission board, detail workspace, Options screen, aircraft/news/media pages, portrait share text and launcher all use build 1689. Version code is 168900.

## Verified versus unverified

`verification/check_source.py`, inherited geometry and compiler guards, `verification/check_1689_lineage.py`, and the 236-file Java syntax parser are included. Source checks cannot establish successful Android APK compilation, live provider accessibility or on-phone appearance. The accompanying GitHub workflow compiles an installable debug APK and verifies its manifest, classes, signature and checksum before publishing an artifact.

**Upgrade policy:** Do not add fake observations or a second command centre. Do not rename without functionality changes. The source control file lists hashes of original 1688 classes and confirms every native activity changed by 1689.
