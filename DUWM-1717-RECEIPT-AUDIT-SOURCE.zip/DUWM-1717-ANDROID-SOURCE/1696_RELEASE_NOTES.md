# DUWM 1696 — Native map and media focus

Derived from exact 1695 source SHA-256 8c0d0fa1fbeb71b65a361b0132c231d9c8565e089035b96f04d7456c13caebae

- Aircraft map-first focus collapses existing filters, expands the original map and clears all actual source filters in one action.
- Maritime map-first focus collapses AIS register controls without introducing another sea map.
- News publisher time filters rotate cleanly through all, 24-hour and 6-hour windows; Clear resets every source filter.
- Radio atlas visibly highlights selected source region instead of making region changes appear static.
- TV/Camera player focus and expanded size now use a single consistent layout calculation.
- Source Health shares only the diagnostic records currently visible under issue/search filtering.
- All 19 intelligence desks allow direct movement from a peer provider comparison to that desk’s real receipt overview.

Release gate: a real signed APK with correct label and functioning controls must compile and pass runtime tests on Android.
