
'use strict';
const modes={
 CITY:{accent:'#f1c275', water:'#3683b9',pitch:48, label:'CITY NETWORK'},
 AIR:{accent:'#39deed', water:'#2b7391',pitch:35,label:'AIR CORRIDORS'},
 SEA:{accent:'#4caaf2',water:'#1f89ca',pitch:42,label:'COAST / SEA'},
 QUAKE:{accent:'#f26465',water:'#286d91',pitch:30,label:'EVENT ALERTS'},
 SAT:{accent:'#f6d05a',water:'#2b798f',pitch:30,label:'SATELLITE WATCH'},
 WEATHER:{accent:'#52cde4',water:'#278cb4',pitch:38,label:'WEATHER MONITOR'},
 NEWS:{accent:'#b79df2',water:'#3371a2',pitch:36,label:'INTELLIGENCE LAYER'}
};
let mode='CITY',place='KAMPALA',map=null,roadsReady=false,points=[],traces=[],styleSource=null,screenEnabled=true;
const empty={type:'FeatureCollection',features:[]};
function geojsonPoint(p){return {type:'Feature',id:p.id,geometry:{type:'Point',coordinates:[p.lon,p.lat]},properties:{id:p.id,kind:p.kind,title:p.title,source:p.source,time:p.time}};}
function typeColor(kind){return ({AIRCRAFT:'#39dbe6',EARTHQUAKE:'#f66c69',ISS:'#f7d45e',WEATHER:'#54bce6',NEWS:'#bb9aec'}[kind]||'#8fd5df');}
function safeNum(value){return typeof value==='number'&&Number.isFinite(value);}
function setMessage(message){let e=document.getElementById('fallback');e.innerHTML=message;e.style.display='block';}
function withSource(id,type,data){if(!map.getSource(id))map.addSource(id,{type:type,data:data});else map.getSource(id).setData(data);}
function roadLayers(){
 if(!map||!map.isStyleLoaded())return;
 const style=map.getStyle();
 const transportation=style.layers.find(l=>l['source-layer']==='transportation'&&l.source);
 const water=style.layers.find(l=>l['source-layer']==='water'&&l.source);
 const building=style.layers.find(l=>l['source-layer']==='building'&&l.source);
 styleSource=transportation?transportation.source:null;
 if(transportation){
  const match=['match',['get','class'],['motorway','trunk','primary','secondary','tertiary'],true,false];
  const common={type:'line',source:transportation.source,'source-layer':'transportation',filter:match,layout:{'line-cap':'round','line-join':'round'}};
  map.addLayer({...common,id:'duwm-road-halo',paint:{'line-color':modes[mode].accent,'line-opacity':.40,'line-width':['interpolate',['linear'],['zoom'],8,1,12,8,15,13], 'line-blur':5}});
  map.addLayer({...common,id:'duwm-road-core',paint:{'line-color':modes[mode].accent,'line-opacity':.77,'line-width':['interpolate',['linear'],['zoom'],8,.3,12,1.8,15,3]}});
  const minor={type:'line',id:'duwm-road-minor',source:transportation.source,'source-layer':'transportation',
   filter:['match',['get','class'],['residential','service','minor','street'],true,false],layout:{'line-cap':'round'},
   paint:{'line-color':modes[mode].accent,'line-width':.7,'line-opacity':.24}};
  map.addLayer(minor);
 }
 if(water){map.addLayer({id:'duwm-water-sheen',type:'line',source:water.source,'source-layer':'water',
  paint:{'line-color':modes[mode].water,'line-width':2.3,'line-blur':2.5,'line-opacity':.55}});}
 // 2.5D uses actual building height attributes; unknown heights are not synthesized.
 if(building){map.addLayer({id:'duwm-real-buildings',type:'fill-extrusion',source:building.source,'source-layer':'building',minzoom:14,
  paint:{'fill-extrusion-color':'#39535d','fill-extrusion-height':['coalesce',['to-number',['get','render_height']],['to-number',['get','height']],0],
   'fill-extrusion-base':0,'fill-extrusion-opacity':.48}});}
 roadsReady=!!transportation;
 updateLayerPalette();
}
function addObservationLayers(){
 if(!map||!map.isStyleLoaded())return;
 map.addSource('duwm-source-points',{type:'geojson',data:empty});
 map.addSource('duwm-source-tracks',{type:'geojson',data:empty,lineMetrics:true});
 map.addLayer({id:'duwm-route-glow',type:'line',source:'duwm-source-tracks',paint:{'line-color':'#42dcea','line-width':9,'line-blur':6,'line-opacity':.5}});
 map.addLayer({id:'duwm-route-core',type:'line',source:'duwm-source-tracks',paint:{'line-color':'#7ce6ef','line-width':2.8,'line-opacity':.95}});
 map.addLayer({id:'duwm-signal-halo',type:'circle',source:'duwm-source-points',paint:{'circle-radius':13,'circle-blur':.85,'circle-opacity':.36,'circle-color':['match',['get','kind'],'AIRCRAFT','#40d8e9','EARTHQUAKE','#f36b69','ISS','#ebd05a','WEATHER','#3aa7e6','NEWS','#b695f1','#5ac6da']}});
 map.addLayer({id:'duwm-signal-dot',type:'circle',source:'duwm-source-points',paint:{'circle-color':['match',['get','kind'],'AIRCRAFT','#40d8e9','EARTHQUAKE','#f36b69','ISS','#ebd05a','WEATHER','#3aa7e6','NEWS','#b695f1','#5ac6da'],'circle-radius':5,'circle-stroke-width':1.5,'circle-stroke-color':'#d1f9ff'}});
 map.on('click','duwm-signal-dot',event=>{const f=event.features?.[0];if(!f)return;selectItem(String(f.properties.id));});
 map.on('mouseenter','duwm-signal-dot',()=>{map.getCanvas().style.cursor='pointer';});
 map.on('mouseleave','duwm-signal-dot',()=>{map.getCanvas().style.cursor='';});
}
function updateLayerPalette(){if(!map)return;
 for(const layer of ['duwm-road-halo','duwm-road-core','duwm-road-minor'])if(map.getLayer(layer))map.setPaintProperty(layer,'line-color',modes[mode].accent);
 if(map.getLayer('duwm-water-sheen'))map.setPaintProperty('duwm-water-sheen','line-color',modes[mode].water);
 document.documentElement.style.setProperty('--accent',modes[mode].accent);
}
function modeAccepts(record){
 if(mode==='CITY')return true;
 const wanted={AIR:'AIRCRAFT',SEA:'VESSEL',QUAKE:'EARTHQUAKE',SAT:'ISS',WEATHER:'WEATHER',NEWS:'NEWS'};
 return record.kind===wanted[mode];
}
function usableRecord(p){
 if(!p || typeof p.id!=='string' || !safeNum(p.lon) || !safeNum(p.lat) || !safeNum(p.time))return false;
 if(Math.abs(p.lat)>85 || Math.abs(p.lon)>180 || p.time<=0)return false;
 const now=Date.now(), age=now-p.time;
 if(age < -300000)return false; // bad source clock, not an observation from the future
 // Weather is a point forecast, quake events are historical; moving positions expire rapidly.
 const limit=p.kind==='EARTHQUAKE'?604800000:p.kind==='WEATHER'?10800000:900000;
 return age<=limit;
}
function updateFeatures(){
 const filtered=points.filter(p=>usableRecord(p)&&modeAccepts(p));
 const validFixes=traces.filter(t=>t && safeNum(t.lat1) && safeNum(t.lon1) && safeNum(t.lat2) && safeNum(t.lon2)
   && Math.abs(t.lat1)<=85 && Math.abs(t.lat2)<=85 && Math.abs(t.lon1)<=180 && Math.abs(t.lon2)<=180
   && safeNum(t.from) && safeNum(t.to) && t.to>t.from && t.to<=Date.now()+300000
   && Date.now()-t.to<=900000 && ['AIRCRAFT','ISS'].includes(t.kind) && modeAccepts(t));
 if(map && map.isStyleLoaded() && map.getSource('duwm-source-points')){
  map.getSource('duwm-source-points').setData({type:'FeatureCollection',features:filtered.map(geojsonPoint)});
  map.getSource('duwm-source-tracks').setData({type:'FeatureCollection',features:validFixes.map(t=>({
    type:'Feature',properties:{kind:t.kind,from:t.from,to:t.to,description:'STRAIGHT SEGMENT BETWEEN TWO REPORTED FIXES — NOT THE ACTUAL ROUTE'},
    geometry:{type:'LineString',coordinates:[[t.lon1,t.lat1],[t.lon2,t.lat2]]}}))});
 }
 const banner=mode==='SEA'?'AIS DATA FEED NOT CONFIGURED':mode==='NEWS'?'NEWS WITHOUT VERIFIED GEOGRAPHIC COORDINATES IS NOT MAPPED':
   filtered.length===0?'NO FRESH, SOURCE-GEOLOCATED RECORDS FOR '+mode:'TAP A POINT FOR RECORD / SOURCE / OBSERVATION TIME';
 document.getElementById('observed').textContent=mode+' '+filtered.length+' FIXES';
 document.getElementById('p2State').textContent=banner+' • '+validFixes.length+' OBSERVED FIX PAIRS';
 return filtered;
}
function fitObserved(){
 const displayed=points.filter(p=>usableRecord(p)&&modeAccepts(p));
 if(!map || !map.isStyleLoaded() || !displayed.length){
  document.getElementById('p2State').textContent='NO FRESH GEOLOCATED '+mode+' RECORDS TO FRAME';return;
 }
 const first=displayed[0];let west=first.lon,east=first.lon,south=first.lat,north=first.lat;
 for(const p of displayed){west=Math.min(west,p.lon);east=Math.max(east,p.lon);south=Math.min(south,p.lat);north=Math.max(north,p.lat);}
 if(displayed.length===1){map.easeTo({center:[first.lon,first.lat],zoom:8,pitch:0,duration:650});return;}
 map.fitBounds([[west,south],[east,north]],{padding:{top:75,bottom:85,left:35,right:100},maxZoom:12,duration:900});
}
function selectItem(id){if(!id)return;window.location.href='duwm://select?id='+encodeURIComponent(id);}
window.duwmMode=function(next){if(!modes[next])return;mode=next;updateLayerPalette();updateFeatures();
 document.getElementById('focus').textContent=place.toUpperCase()+' / '+modes[mode].label;
 if(map)map.easeTo({pitch:modes[mode].pitch,duration:650});};
window.duwmFocus=function(lat,lon,zoom,name){if(!safeNum(lat)||!safeNum(lon)||Math.abs(lat)>85||Math.abs(lon)>180)return;
 place=String(name||'SELECTED LOCATION');document.getElementById('focus').textContent=place.toUpperCase()+' / '+modes[mode].label;
 if(map)map.easeTo({center:[lon,lat],zoom:Math.min(17,Math.max(3,zoom||11)),pitch:modes[mode].pitch,duration:850});};
window.duwmReceive=function(payload){if(!payload)return;
 points=Array.isArray(payload.points)?payload.points.filter(p=>p&&typeof p.id==='string'):[];
 traces=Array.isArray(payload.traces)?payload.traces:[];
 updateFeatures();};

// DUWM 1162: animation applies only to features from real provider receipts / vector OSM tiles.
// Road lighting is cartographic styling, not evidence of observed road traffic.
function duwm1162Paint(t){
 if(!map||!map.isStyleLoaded())return;
 const palette=modes[mode]||modes.CITY;
 const glow=.40+.10*Math.sin(t/870);
 if(map.getLayer('duwm-road-core')){
   map.setPaintProperty('duwm-road-core','line-color',palette.accent);
   map.setPaintProperty('duwm-road-core','line-opacity',.82);
 }
 if(map.getLayer('duwm-road-minor')){
   map.setPaintProperty('duwm-road-minor','line-color',palette.accent);
   map.setPaintProperty('duwm-road-minor','line-opacity',mode==='CITY'?.32:.17);
 }
 if(map.getLayer('duwm-water-sheen'))map.setPaintProperty('duwm-water-sheen','line-opacity',mode==='SEA'?.77:.35);
 if(map.getLayer('duwm-road-halo'))map.setPaintProperty('duwm-road-halo','line-opacity',glow);
 if(map.getLayer('duwm-route-core') && traces.some(p=>p&&p.to>p.from && ['AIRCRAFT','ISS'].includes(p.kind))){
   // The feature geometry itself originates from two observed source fixes, not invented paths.
   const phase=(Math.sin(t/390)+1)/2;
   map.setPaintProperty('duwm-route-core','line-opacity',.75+.23*phase);
 }
 if(map.getLayer('duwm-signal-dot') && points.length){
   map.setPaintProperty('duwm-signal-dot','circle-stroke-width',1.1+.65*((Math.sin(t/620)+1)/2));
 }
 if(map.getLayer('duwm-real-buildings')){
   map.setPaintProperty('duwm-real-buildings','fill-extrusion-opacity',mode==='CITY'?.67:.39);
 }
}

function animate(t){if(!screenEnabled)return;
 try{duwm1162Paint(t);}catch(error){console.warn("1162 map styling unavailable",error);}
 if(map&&map.isStyleLoaded()){
  let intensity=(Math.sin(t/580)+1)/2;
  if(map.getLayer('duwm-signal-halo'))map.setPaintProperty('duwm-signal-halo','circle-radius',10+8*intensity);
  if(map.getLayer('duwm-road-halo'))map.setPaintProperty('duwm-road-halo','line-opacity',.23+.16*intensity);
 }
 setTimeout(()=>requestAnimationFrame(animate),125);
}

// Navigation controls operate on the actual vector map, not a decorative picture.
document.getElementById('p2Home').addEventListener('click',()=>{
 window.duwmFocus(.3476,32.5825,11.1,'Kampala');
});
document.getElementById('p2Fit').addEventListener('click',fitObserved);
document.getElementById('p2Plus').addEventListener('click',()=>{if(map)map.zoomIn({duration:350});});
document.getElementById('p2Minus').addEventListener('click',()=>{if(map)map.zoomOut({duration:350});});
document.getElementById('p2Tilt').addEventListener('click',()=>{if(map)map.easeTo({pitch:map.getPitch()>5?0:48,duration:450});});

try{
 if(typeof maplibregl==='undefined')throw new Error('Map renderer could not load');
 map=new maplibregl.Map({container:'map',style:'https://tiles.openfreemap.org/styles/dark',center:[32.5825,.3476],zoom:11.1,pitch:48,bearing:0,
  attributionControl:true,maxPitch:65,antialias:true,renderWorldCopies:false});
 map.on('load',()=>{
   document.getElementById('p2State').textContent='MAP TILES READY • WAITING FOR SOURCE-OBSERVED POINTS';
   document.getElementById('fallback').style.display='none';
   try{roadLayers();}catch(e){console.warn('Road overlay unavailable',e);}
   try{addObservationLayers();updateFeatures();}catch(e){setMessage('SOURCE POINT LAYER UNAVAILABLE / '+String(e.message||e));}
 });
 map.on('error',error=>{if(!roadsReady&&error?.error)setMessage('MAP TILE SOURCE UNAVAILABLE / '+String(error.error.message||'Connection error').slice(0,110));});
 document.addEventListener('visibilitychange',()=>{screenEnabled=!document.hidden;if(screenEnabled)requestAnimationFrame(animate)});
 requestAnimationFrame(animate);
}catch(error){setMessage('GEOGRAPHIC MAP ENGINE UNAVAILABLE<br/>No artificial streets or map markers will be created.');}
