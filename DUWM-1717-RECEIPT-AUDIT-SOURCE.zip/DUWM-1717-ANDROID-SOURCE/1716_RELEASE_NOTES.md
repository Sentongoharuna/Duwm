# DUWM 1716 — Source-Backed Signal Centre / Exact Navy

Base: DUWM 1715 FIX3 EXACT COLOURS complete Android source. This release continues the **one original globe** and all 19 registered desks.

## New visible functionality
- A dedicated full-screen **World Signal Centre** with nineteen individual live-source-state indicators, original sector names, provider, source value and last local receipt (read from the on-device receipt adapters, not invented).
- Four counted source-state summary tiles: recent, review, local tools and no receipt; recalculate on open and REREAD.
- Real category/search filters, sector-targeted opening by tapping any lamp in the existing 19-light rail, native desk launch, source evidence detail dialog, and shareable local status text.
- The global rail's label updates from real source diagnostics and remains fully tappable; the native desk footer has a contextual SIGNALS action.
- All new panels are full-screen midnight navy #041424 with #DEE5EF one-pixel silver outlines, #F5F7FA typography and muted #A0A5AE labels. Status-only lights retain semantic colors.

No second globe, no extra network request, no false live claim, no telemetry synthesis. The original SatelliteMapView class and renderer remain unchanged.

## Build policy
The source ZIP and GitHub workflow are provided separately. Compiling, signing, APK identity checks and publication must complete before describing 1716 as a successful APK build. Emulator image downloads may fail independently.
