# DUWM 1711 — Unified desk navigation; no floating overlays

Built from the successful 1710 FIX2 project, preserving the original single globe, source-backed signal animation, two running tickers, World Watch, and the approved #050D22 navy panels.

## Actual source changes

- On all 19 native desk activities, the old floating `SOURCE / DETAILS` action has been removed. A fixed bottom dock is placed **outside** the native content viewport (when the activity has a single content root), with 48dp actions for Source Details, 19 Desks and Globe.
- Native desk dock has a live on-device source-state caption and a 1dp sector identifier. No artificial counts are generated.
- The 19-sector full-screen detail activity now has an independent horizontal chip switcher above its scrollable content. It automatically scrolls to the active sector and opens the corresponding existing desk.
- The original globe adds a `19 DESKS` action into its existing horizontal quick-action rail outside the globe map.
- No new globe, maps, media player, data source or synthetic track was introduced.

## Verification gates

- Source lineage and preserved protected Java component hashes.
- 19-sector navigational actions and removal of the old floating action.
- Android identity 1711 / versionCode 171100 and Java syntax.
- GitHub Actions builds APK, verifies identity and signature, installs the APK in an emulator and launches original globe.
