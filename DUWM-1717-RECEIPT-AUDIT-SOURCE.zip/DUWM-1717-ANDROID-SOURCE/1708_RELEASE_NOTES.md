# DUWM 1708 — APPROVED #050D22 FULL-APP NIGHT PRINT

Base: actual DUWM 1707 native source, in turn based on green 1706.

- Whole app uses the user-approved **#050D22** for its dominant background: native desks, command center, widgets, globe canvas, ocean, HTML place-map, share images, menu and rail backgrounds.
- Raised cards are subtle **#08162E**, focus items **#122545**, borders dark slate-blue. Bright blue is limited to live/selection/navigation signals; other warning statuses keep distinct meanings.
- The one original `SatelliteMapView` remains the same renderer with real source arcs, beacons, observed-position trails, rotation and controls. No duplicate globe or artificial telemetry.
- Both `SignalTickerRailView` instances still move continuously and use actual received source messages; their dark rails now match the main screen.
- All 19 desks, local widgets and legal source citations are retained. No feeds, data providers or list functionality are deleted.
- Version code 170800 and name 1708 distinguish the resulting APK. A green GitHub action is required before calling it device-verified.
