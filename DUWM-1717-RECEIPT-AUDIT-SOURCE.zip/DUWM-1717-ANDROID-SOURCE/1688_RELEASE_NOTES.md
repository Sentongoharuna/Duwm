# DUWM 1688 — Native Pages and Real Source Operations

This package is a direct revision of the **DUWM-1687-FIX1-CORRECTED-SOURCE.zip**, SHA-256 `08c812f50fda13734bed7a3896a981387542c4db66fc468ba693d50fdd7ffa58`.
It does not replace the one original rotating globe, launcher activity, app ID or existing sources.

## Substantive existing-page changes

- **Aircraft** — expand/compact original map, switch between received positions and genuine two-fix trails; source ages and scenario limitations remain visible.
- **Maritime** — collapse unused gateway, enlarge original sea map, select and focus an observed MMSI vessel; filter ship list to recent source fixes and keep provider status visible.
- **News** — live text search over source-received stories, time-order sorting, larger legitimate source images and the existing article reader / 9:16 share function.
- **Radio** — source-backed station search, mapped-location filter and selected-station location ring; pause/resume/stop in-app player and avoid out-of-order provider responses.
- **TV / Cameras** — expand/compact the in-app media area; hide irrelevant TV-only full-screen action on other media tabs; show received and filtered records.
- **Source health** — direct routing to the native Aircraft, Maritime and News desks; return to original MainActivity globe instead of legacy OperationsMainActivity.
- **Shared native desk chrome** — shorten the inherited source bar and stop forcing fullscreen Android flags over player/map content. All 19 native entries remain in the single searchable board.
- **Version identity** — 1688 launcher label, versionName `1688`, versionCode `168800`, matching share-card labels and source metadata.

## Checks and limitations

`python3 verification/check_1688_native_upgrade.py` confirms changed native Java file hashes relative to 1687 FIX1, inherited globe hashes, app identity, and source behaviour markers. `JavaSyntaxCheck` parses 236 Java sources. These checks are not a compiled APK and cannot demonstrate actual user-interface performance. Build the signed debug APK in GitHub Actions using the workflow bundled alongside this ZIP, then inspect it on your phone before calling it visually verified.
