# DUWM 1702 — SOURCE LENS + PRIORITY INCIDENT CLARITY

Base: exact DUWM 1701 original Android app (not a recreated globe).

## Verifiable functional upgrades
- New permanent **LENS** control on the phone's compact left edge, next to AIR/SEA/SRC. One tap opens seven source-backed options: ALL, AIR, SEA, EVENTS, WEATHER, SATELLITES, CAMERAS.
- On selecting a lens, the actual existing `SatelliteMapView` filters drawn markers and provider activity arcs to those signal layers; unrelated city decoration and background pulses are suppressed during focus. The canonical provider snapshot, feed counts, all 19 desks, map camera and globe geometry stay unchanged.
- Lens choices display actual currently received geolocated counts from enabled source layers rather than fabricated marker numbers; empty sources show zero.
- Lens survives app restarts using Android preferences and can be changed from the older MORE action sheet.
- 1701's *first marker wins* overlap logic is upgraded: incident severity and confirmed high-priority observations are sorted once per source update and take precedence in crowded 16dp cells. Full ALL mode still draws records in original order.
- Hit-testing continues to work only for visible markers; hidden markers are never interactive until a user clears the filter.
- Native build identity: versionName 1702, versionCode 170200, original applicationId unchanged, original globe class retained.

## Integrity and limitations
- No replacement globe, no fake positions, no claimed new external feeds or server-side uploads. Source lens is a rendering/navigation feature for received source signals.
- Java syntax and lineage tests are separate from Android APK compilation/launch. A verified APK requires GitHub Actions to compile, check APK identity and signature, launch the original MainActivity in an emulator and upload a real artifact.
