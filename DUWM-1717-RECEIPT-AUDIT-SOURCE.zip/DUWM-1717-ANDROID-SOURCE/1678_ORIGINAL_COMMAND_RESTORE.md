# DUWM 1678 - Original Command Center Restoration

- Launch activity: MainActivity (the original native Command Center).
- Exactly one home globe: the existing SatelliteMapView. Renderer and motion source are unchanged.
- No OperationsGlobeView or additional globe is placed onto the main screen.
- New DESKS header button and OPTIONS mission-dock item open DuwmOptionsActivity.
- Optional pages include aircraft, maritime AIS, weather, earthquakes, space, geographic watchlist, maps, news, radio, TV, cameras, NASA, markets, source health, evidence vault and source directory.
- Previous functionality is retained inside its own activity rather than replacing the home screen.
- Android versionName 1678 remains; versionCode 167801 supports an over-the-top update from 167800.

Source checks are not proof of Android compilation or live-provider availability. Run the matching GitHub workflow and verify the APK on a phone.
