# DUWM 1669 — Worldwide Source Discovery

- 200 embedded candidate source websites: 50 public camera, 50 TV broadcasters, 50 news, and 50 maritime sources.
- Dedicated searchable native source directory linked from the globe home screen.
- Each source shows region, information kind, access note, status and original website.
- Not 200 verified provider connections: no source is falsely marked streaming/live/connected.
- Existing live feed parsers, source cache, original detailed moving globe, news, media, radio and wallpaper remain in place.
- The maritime list includes live AIS, licensed AIS, port arrivals, historical AIS and ship registries, labelled accurately.
- Source availability and licensing should be checked individually before app connects, embeds or republishes any content.
