# DUWM 1706 — LIVE SOURCE CHANNELS

Based on the 1705 live globe restoration. Not a new globe or shell.

- Retains the one original orthographic SatelliteMapView, rotation, radius, zoom, and both native continuous tickers.
- Adds long-press to both running tickers and a new MORE → 1706 SIGNAL CHANNELS action.
- Filter the lower ticker by actual received source layer; upper ticker remains all received sources.
- Slow / normal / fast ticker speeds persist across app restarts; both rails continue scrolling.
- New source-activity halo on original globe links colour, count, light intensity and motion to actual received feed status and recent callback timestamps; it does not simulate routes, events or positions.
- World Watch, newsroom receipts/search, provider source links, share cards and all 19 desks unchanged.
- Mandatory APK compile, signature, app identity, Android emulator start and screenshot checks remain part of GitHub Actions.
