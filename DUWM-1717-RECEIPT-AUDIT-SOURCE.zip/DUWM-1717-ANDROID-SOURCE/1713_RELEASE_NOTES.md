# DUWM 1713 — 19-sector receipt comparison and coverage strip

- Extends the 1712 full-screen operations matrix; preserves the original single globe, 19 native desks, no-overlap layout, two running tickers and approved #050D22 navy.
- Adds COMPARE TWO in the matrix's horizontally scrollable filter controls; choose any two of the 19 sectors and compare stored provider states, observed counts, receipt timestamps, source observation times, coverage and error details.
- Every comparison card retains direct OPEN DESK and FULL RECEIPT actions.
- Adds a 19-segment native receipt-coverage strip using the matrix's actual stored provider diagnostics. Green = recent receipt, amber = attention, blue = local tool, muted = other. Segments do not infer zero activity.
- Refresh View re-reads stored receipts; any old or missing data is explicitly labeled, and the comparison does not claim two sources corroborate each other.
- No simulated reports, no new globe, no added controls over the existing globe.
- Android compilation and emulator launch must still pass on GitHub before the build is green.
