# DUWM 1683 – Source-driven original globe navigation

Build 1683 upgrades the actual `MainActivity` controls and the single existing `SatelliteMapView`.

- **WATCH NEW** reacts only to new received observations with valid source timestamps, ignoring already displayed cached fixes. No predicted positions.
- **SAVED TOUR** visits actual cached positions at seven-second intervals with explicit “NOT LIVE” labelling.
- Two modes are mutually exclusive and pause when the activity leaves the foreground.
- Selected observations show the source category, record title and source UTC timestamp.
- The existing navy/cyan theme, full source rail and all desk navigation remain in place.
- No additional globe or replacement home screen was created.

Verification: Java syntax and standalone data-deduplication tests run before APK compilation. On-phone stream/data access is not guaranteed by a successful compilation.
