# DUWM 1714 — Persisted 19-sector Source Watchlist

- Base is the actual 1713 Android project. No new globe and no second command shell.
- Adds WATCHED filter to the existing full-screen Operations Matrix. Sector cards have PIN/UNPIN actions; selections persist in app-private preferences across restart.
- 19 independent sector shortcuts, clear-all confirmation, accurate empty state, count of pinned sectors.
- This is a *navigation watchlist* not a notification or proof of live activity. Actual source receipt state is read again from Duwm1684DeskDiagnostics, never fabricated.
- Preserves 1713 two-sector receipt comparison, 1712 source matrix, 1711 docked controls, original single animated globe, signal lights, tickers, all 19 desks, #050D22 background and thin sector outlines.
- Android compilation, emulator launch and final APK must pass GitHub to call the release green.
