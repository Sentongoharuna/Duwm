# DUWM 1697 — native-screen improvement candidate

Parent: `DUWM-1696-FIX2-FULL-GLOBE-SOURCE.zip` (exact SHA256 recorded in 1697_SOURCE_LINEAGE.json).

- Unmodified original SatelliteMapView globe geometry, scale, rotation and fixed MainActivity globe positioning.
- Fix incorrect row placement in ranked source-backed counts (shared across six native desks and 19 workspaces).
- Maritime: position original AIS map above advanced controls without a second map.
- News: collapsible publisher/image/time controls and an optional real source-summary chart to prioritize reading.
- Radio: collapsible station filters and actual station chart while keeping main atlas and in-app player.
- Media: horizontally scrollable playback controls so actions are not clipped on narrow Android phones.
- Source Health: allow live receipt diagnostic rows to display without a large permanent chart; chart remains user-accessible.
- Aircraft: receiver-coverage warning can be expanded or folded without losing its contents.
- Release identity: label DUWM 1697, versionName 1697, versionCode 169700.

This is **not** a released APK until GitHub Actions successfully compiles, verifies Android identity/signature, installs to emulator, validates globe clearance and uploads the APK artifact. Genuine source caches and feeds need on-device testing.
