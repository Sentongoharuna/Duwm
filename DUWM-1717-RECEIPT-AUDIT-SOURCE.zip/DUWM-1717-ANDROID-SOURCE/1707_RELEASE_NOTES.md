# DUWM 1707 — MIDNIGHT NAVY COMMAND CENTER

Built directly from the successful 1706 source. This is a real global re-skin
across native Android Java Canvas painting, UI controls, app theme, source
workspaces, widget XML, share-card drawing, and the **same** globe renderer.

- Core palette: midnight #050D22, panel #0D2345, selected #183B6B,
  border #31558D, active cobalt #558BDF, highlight #97BBF7.
- The original SatelliteMapView remains single, rotatable and resizable.
  Geography, oceans, grid and land outlines are now navy, not green/teal.
- All 19 desks, World Watch, media, news, AIS, aircraft, radio, share
  cards, settings and widgets share the same dark-navy print.
- The two uninterrupted source-backed scrolling tickers, real-data ring
  arcs and signal beacons remain; signals never invent traffic/events.
- Small danger, warning and source-live indicators retain meaning and
  written labels rather than using undifferentiated blue for alerts.
- New version 1707 identity, but the installed app package is unchanged.
- The CI workflow compiles an actual Android APK, validates identity,
  installs it in emulator, launches original globe, captures screenshot
  and publishes verified APK only upon successful launch.
