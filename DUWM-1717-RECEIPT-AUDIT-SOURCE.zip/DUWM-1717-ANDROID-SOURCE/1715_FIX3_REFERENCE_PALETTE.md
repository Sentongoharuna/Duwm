# DUWM 1715 FIX3 — user-provided screenshot palette

Reference screenshot sampled at 1536 × 897: navy area most common sampled pixel **#041424**.

- Exact screen/background and ordinary chip fill: `#041424`.
- Approximate visible chip outline: `#DEE5EF` (JPEG compression makes boundary vary).
- Headline / action text: `#F5F7FA` (near-white).
- Muted section labels: `#A0A5AE`.
- Only selected surface: `#0D2638`; never for default panels.
- Thin separation rules: `#7D8E9F`.

Signal lights remain strictly state-based, not decorative: recent green, delayed amber,
offline red, missing receipt muted, local tool blue. The original globe, map data,
routes, and video sources are preserved. No new shell/globe added. Native windows,
resources, web chrome and widgets now share `#041424` navy. Pill-style corners follow
20dp formal control radius where theme-driven.
