# DUWM 1705 LIVE GLOBE RESTORE

This is a source-code update to the existing 1705 build, not an additional globe or version bump.

- Full marker presentation re-enabled once after update; future display choice remains user-controlled.
- Two independently moving native ticker rails, only real received source reports with timestamps, tap for World Watch.
- Brighter moving source-health arcs and category lamps on the original orthographic globe.
- Actual flight/ship historical received fixes traced with illuminated lines (when 2+ genuine points exist), no fabricated routes.
- 1703-1705 World Watch, search, categorisation, evidence, geography and share cards retained.
- Real APK build plus Android emulator launch required before declaring green.
