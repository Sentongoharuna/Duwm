# DUWM 1684 — visible, whole-app major upgrade (original command source)

**Release rule:** The number 1684 identifies meaningful changes that can be seen and used. The
original Command Center remains the only globe; this source does not introduce a second globe,
an overlay globe, a substitute command center, fabricated positions, synthetic news, or fake tracks.

## What visibly changes

1. **Home command dock now opens full-screen native destinations.** News, aircraft, ships, weather,
   earthquakes, satellites, radio, television, cameras, markets, geography, source health and other
   categories go directly to their real existing Activity. Source-pulse cards preserve first-tap
   focus on the original globe and open the corresponding full-screen desk on the second tap.
2. **All 19 original Options destinations receive an app-wide sector header.** A distinctive
   schematic for the desk type, large desk heading, current local receipt and SOURCE DETAIL action
   appear above existing content in scroll screens. Full-screen media players retain their playback
   space, receiving a small non-blocking source badge instead of a large inserted header.
3. **Options hub visibly rebuilt.** A large animated operations illustration, 19 sector previews,
   larger cards, explicit native launch and source detail controls, text search and saved desks.
4. **Source detail pages rebuilt.** Large animated sector illustration, actual-provider/source
   status, sector-specific inspection checklist, open-native-data button, coverage, receipt age,
   errors, refresh where the provider supports it, and previous/next desk navigation.
5. **Image sharing.** Every desk's share action now produces a branded 1080x1350 PNG card bearing
   the existing app logo, visual illustration, actual on-device provider source status, count,
   source name, last receipt and coverage. Share via the already registered read-only provider.
   These sector diagrams are explicitly illustrative, not geographical or numeric observations.
6. **Unified colour.** Existing single-colour navy/teal design remains; no rainbow pages or
   incompatible alternate themes are created.

## Source-by-source covered pages

Aircraft tracker; Maritime intelligence; Earthquakes; Weather; Satellites and ISS;
Geographic watchlist; Place maps; World news; News atlas; Radio stations; TV stations;
Public cameras; NASA Earth images; World markets; Source health; Evidence vault;
World source directory; Geopolitical lens; Local reports.

## Verification limits

- Source-level verification parses all Java files and checks the single original globe,
  provider connections, media routing, full-screen desk activity coverage and these new classes.
- A green Android compile and a signed artifact must be confirmed by the GitHub workflow.
- In-app media streams, network feeds, camera sources, third-party restrictions, device playback,
  real-time accuracy and actual screenshot appearance cannot be proved by source checks alone.
