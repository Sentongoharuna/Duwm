# DUWM 1675 — Evidence Vault

This release adds a genuinely new offline, user-triggered **Source Evidence Vault** to the 1674.1 compiled base.

- Tap **1675 Evidence Vault** on the existing Mission Control home screen.
- **CAPTURE RECEIPTS** records nine source statuses, provider names, counts, fetch timestamps and any available source timestamps actually present on the device at capture time. The app does not invent records or fetch data when creating a snapshot.
- Compare the most recent two captures, showing changed values, receipts reused between snapshots, and changed source status. It does not claim providers were sampled simultaneously.
- Filter captured snapshots by source category, inspect their details offline, and preserve up to 60 snapshots locally.
- **SAVE CSV FILE** opens Android's system file picker and exports a proper table; the exporter escapes CSV content and discourages formula injection.
- **SHARE LATEST 9:16 CARD** uses the existing source-labelled PNG card exporter.
- The app remains the same package ID and has a higher versionCode so it installs over the previous build.
- Existing aircraft, globe, vessel, news, and media screens remain reachable.

## Verification boundaries

Pure-Java formatter/delta/CSV tests and source-manifest checks run in GitHub before compilation. Android compilation and package signing must pass before the APK artifact uploads. This release does not claim to repair every external API, prove stream playback, or establish location accuracy.
