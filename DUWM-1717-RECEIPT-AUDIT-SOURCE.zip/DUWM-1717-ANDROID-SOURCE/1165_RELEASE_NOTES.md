# DUWM 1165 — Detailed Earth restore (revision build 116501)

## What changed in actual Android source

- `OperationsMainActivity.java`: **stops invoking `switchOriginalRenderer()` on launch**. The startup renderer now remains `OperationsGlobeView` with the dense `naturalearth_coasts.txt` geometry. The prior native `SatelliteMapView` has large flat `LAND_MASSES` polygons and white triangular flight markers, matching the degraded screenshot.
- The previous `SatelliteMapView` is still available via an explicitly labeled **LEGACY** button, which becomes **DETAILED** to return to the preferred globe.
- The heading describes the actually displayed detailed globe; source receipt string is shorter and an accessible full description is retained.
- `app/build.gradle.kts`: `versionCode 116501` / `versionName 1165-detail-restore` (same 1165 series, incremented installable build).
- `verification/check_source.py` and `verification/check_detailed_globe.py`: assert the default renderer and alternate path rather than falsely treating the coarse renderer as the best globe.

## Still not proved

Local static source tests and geographic map script checks are not Android runtime testing. The GitHub build, signature, source receipts, real map tiles and on-phone appearance must be verified. No invented positions or provider success are added.
