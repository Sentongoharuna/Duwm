# DUWM 1701 — ORIGINAL GLOBE CLARITY / REAL SOURCE NAVIGATION

Source: exact existing 1700 Android source, **not** recreated globe or a new shell.

## Functional differences from 1700
- Three switchable visual modes directly on the original orthographic globe: ALL MARKERS, CLARITY (default), and INCIDENTS. Switch with the right-edge VIEW control; preference persists across app restarts.
- CLARITY suppresses overlapping map pins in 16dp on-screen cells and reduces source arc opacity. Source records, feed counts, all desks, and underlying map observations remain intact; the skipped markers cannot be accidentally selected as if visible.
- INCIDENTS hides aircraft, ships, satellites and static infrastructure marks on the globe while retaining real event source markers; no signal data is deleted.
- Smartphone header now shows the full DU WORLD MONITOR wordmark; optional desk/settings actions live inside the accessible MENU rather than clipping the logo.
- Narrower, vertically centered side controls cut clutter: AIR, SEA, SOURCE and FIX, VIEW, ZOOM IN, MORE. The MORE menu retains zoom out, globe camera controls, source status, latest observed details, receipt counts, cross-source brief and all 19 desks.
- App identifier upgraded to versionCode 170100 and versionName 1701; package and single original globe unchanged. Key detail desks display 1701 headers.

## Verification
This ZIP contains actual edited Java sources. The GitHub workflow must compile Android, validate the APK package and signatures, install on an accelerated emulator, and launch `MainActivity` successfully before release is called green.
