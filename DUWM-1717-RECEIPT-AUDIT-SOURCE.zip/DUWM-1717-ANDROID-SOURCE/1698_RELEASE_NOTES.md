# DUWM 1698 | Original full-size globe + actual native workflows

Based on exact 1697 source ZIP. APK not yet compiled; do not confuse source verification with APK testing.

- 1698: full-size single original globe, original camera projection, 36dp edge rail actions and touch gestures inherited unchanged from 1697.
- 1698: Aircraft adds a direct native air map control, collapses optional flight-state filters and resets all filters by one tap.
- 1698: Maritime moves its single existing selected-vessel detail panel to the original map and offers expandable source-backed classification chart; category chips highlight the active real-data filter.
- 1698: News cards open articles by touching titles; image cards are shorter to reveal more genuine publisher stories, and reading-density control is visible without opening advanced source filters.
- 1698: Radio clears old region map bounds when changing provider region, annotates the selected source-coordinate marker with the real received station name, and preserves in-app audio.
- 1698: Media removes redundant decorative header, moves provider-data chart behind an optional control to prioritize playable entries, and makes source items directly actionable.
- 1698: All 19 source workspaces put actionable verified provider data before change graphics; scrolling resets on tab switch, aged/errors get a distinct source-status color.
- 1698: Provider diagnostics retains device-only counts and real receipt ages; displayed version labels match compiled APK.
