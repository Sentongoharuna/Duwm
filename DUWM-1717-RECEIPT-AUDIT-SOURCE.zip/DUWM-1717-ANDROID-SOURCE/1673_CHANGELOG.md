# DUWM 1673 — UNFROZEN VISUAL COMMAND DECK

This is a source upgrade, not a renamed workflow.

- Different default home screen (`Duwm1673CommandDeckActivity`), responsive with source-based figures and sector cards.
- Original OperationsGlobeView renderer genuinely modified: new Aurora/Carbon color systems, illuminated tick ring, orthographic shading, faster but touch-pausable rotation, larger pinch zoom and a graphical orbit frame.
- Interactive globe palette toggle, rotation toggle, provider refresh, observation inspector, actual-record sharing and aircraft follow-map link.
- Dedicated navigation to aircraft, public regional AIS, news atlas, markets, weather, seismic, satellites, in-app TV, webcams and radio.
- 200 worldwide source directory and 200 regional news discovery entries retained.
- New version-aware release gate replaces frozen visual/source hash restrictions. Older SHA-gated tests are archived and no longer mandatory in the 1673 workflow.
- Provider access limits, real-data integrity checks and Android signature verification remain necessary.

## In-app playback and cards upgrade

- Every received Radio Browser station in the Radio Atlas now offers both `PLAY IN APP` and `CARD` without leaving DUWM.
- The media desk retains native TV and radio playback, adds native full-screen video and a SHARE CURRENT CARD action; items remain individually shareable.
- Every visible AIS vessel has a dedicated source-attributed card action; AIS movement appears on the native radar rather than being falsely described as live video.
- Media availability remains dependent on actual publisher streams and phone-supported codecs; no promise that all indexed source websites have working direct media URLs.

## What is NOT verified

This source package is not a successful GitHub APK build or proof of on-device rendering; it needs workflow compilation and device testing.
