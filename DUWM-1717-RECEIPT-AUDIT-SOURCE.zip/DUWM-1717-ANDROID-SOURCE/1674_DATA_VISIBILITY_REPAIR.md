# DUWM 1674 data visibility repair (after 1673 user feedback)

- Home globe redraw only uses contemporary OpenSky position timestamps, never a 1990/historical observation as LIVE.
- Full UTC year is shown for flight map dates; invalid timestamps are explicitly labelled rather than silently updated.
- Home NEWS counter reads actual RSS/GDELT receipts in addition to older NewsStore content, and refreshes both on resume.
- News atlas now requests legitimate RSS/GDELT sources and shows received article titles under Africa/conflict rather than only publisher directory entries.
- Marine source has two additional named bounded public AIS scan regions, default Oslofjord on fresh install, retains regional selection and shows honest receiver coverage/failures.
- Enlarged eight-channel signal board; status indicators stay visible whether data exists or not, and lights never indicate fabricated events.
- Source directories are not treated as active live news/ships. Lack of upstream receiver data still results in an honest empty state.
- Compilation and on-device playback still require GitHub build and phone verification.
