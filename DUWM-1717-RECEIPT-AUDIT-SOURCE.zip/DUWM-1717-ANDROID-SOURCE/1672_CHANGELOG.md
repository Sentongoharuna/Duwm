# DUWM 1672 - Real-source movement and provider availability

This source upgrade is built on the full DUWM 1671 Android project.

1. Aircraft receive cache increases from 5,000 to 22,000 validated positions, with spatially even cache downsizing if the local safety budget is exceeded. All received aircraft are considered by the map rather than silently clipping after 2,500.
2. Global aircraft automatic requests remain provider-conscious. Explicit manual refresh requests are not blocked for 15 minutes; they are guarded against accidental duplicate taps, and OpenSky 429 retry periods still apply. This is not a claim of unlimited API access.
3. Animated two-fix transitions stay active through UI redraws, and the flight screen requests display updates approximately every 1.2 seconds. Animation does not predict a future aircraft position.
4. World map and marine radar use pixel-density decluttering instead of arbitrary first-N drawing, preserving selected pins. The underlying number of received pins remains visible. Maritime radar smoothly interpolates between TWO newly observed positions of the same MMSI and does not extrapolate into unobserved futures.
5. Maritime desk gains an Open Waters GeoJSON bounded-area feed, with 16 selectable maritime regions and key-free access on the anonymous tier. When visible, the app checks for fresh regional positions about once a minute. This does not imply unlimited coverage; access tier and commercial rights still apply. It preserves the optional HTTPS AIS gateway.
6. The vessel page is scrollable at all phone display sizes, and shows public AIS status even without a private gateway. Vessel lists gain progressive Load More paging. The receiver accepts larger bounded regional snapshots and the radar no longer silently discards everything after 160 matches.
7. Mission-control home page exposes a direct aircraft source request and the new public AIS desk; all ten specialist desks, protected globe and wallpaper remain.
8. Provider-health board now identifies cached public AIS sources instead of mislabelling them as disconnected.

Not verified by static testing: APK compilation, mobile GPU performance, actual provider receipts, stream playback, external API availability.

17. 1672 integrity tests protect the original globe and source boundaries. Android compilation and mobile operation remain unverified until GitHub succeeds.
