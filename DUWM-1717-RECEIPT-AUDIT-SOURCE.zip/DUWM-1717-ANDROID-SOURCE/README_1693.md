# DUWM 1693 — in-place native workflow release

Parent: the exact `DUWM-1692-EXISTING-APP-UPGRADE-SOURCE.zip` from `/builds/1692`.

Visible changes that alter existing pages (no second globe or duplicate shell):
- Aircraft: real selectable, paginated aircraft register synchronised with the original map, selected telemetry, and native search filters.
- Maritime: switch between native sea-map emphasis and the AIS vessel register; applies to existing region/type/movement filtering.
- News: full-image article view or a compact source-wire view, retaining original source article links/bookmark/share controls.
- Radio: full radio atlas or station-list-first view, preserving real Radio Browser map pins and in-app playback.
- TV, radio, public cameras and other media: persistent saved source listings, saved-only filter and real playback in the existing player.
- Source health: readable compact incident triage or complete provider error/receipt details with full text share unaffected.
- All 19 existing desk workspaces: 24-hour genuine history filtering and same-category/all-desk source-state comparisons.
- Mission board: persistent attention-first ordering using actual provider states.
- Unified native title bar: replaces missing `Duwm1692Chrome` symbol (a real inherited compilation blocker) and updates visible labels to 1693.
- Evidence charts: persist actual-count/ranked-bar preference across native desk pages, never fabricate telemetry.

Compiling an APK and inspecting on-device visuals are distinct from static/source tests. The GitHub workflow publishes an APK only after Java/Android compilation, label, package, class and signature checks succeed.
