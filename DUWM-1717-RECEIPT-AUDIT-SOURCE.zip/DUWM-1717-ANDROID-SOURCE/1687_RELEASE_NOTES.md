# DUWM 1687 — improvement of the same original Command Center

## Principle: no duplicated pages, globes, or dashboard panels

The existing `MainActivity` and `SatelliteMapView` remain the launch/home globe. The 19 native desks retain their existing maps, news feeds, audio/video players and source endpoints. A native page gets only one compact status/Details strip rather than a second map, another big visual, or a repeated detail navigation bar. The strip can be hidden completely over a map or player; the restore chip appears only when hidden.

The existing DuwmOptionsActivity now shows one searchable 19-desk mission board with working sector, text-search and saved-desk filters. Existing favorites continue using the same `duwm1684_desk_nav` preferences storage; the duplicated legacy advanced directory and oversized decorative hero have been removed.

Dedicated full-screen desk workspaces provide six views (LIVE, DETAILS, HISTORY, COMPARE, SOURCES, TOOLS), only using on-device provider receipts. The existing native desk can still be opened from each workspace. Navigation retains all nineteen desk routes. Share cards are 1080×1920 PNG images with source details, UTC receipt timestamps and locally observed history; decorative sector art is explicitly labelled illustration rather than live positions or original source photography.

## Verification
- `verification/check_1687_major_upgrade.py` checks 19 desk routes, original one-globe launcher, new navigation, source facts and non-duplication constraints.
- `verification/JavaSyntaxCheck.java` parses all Java source files, not Android type-checking.
- `verification/check_source.py`, legacy compiler fixes, geometry tests, JVM geographic- and real-fix tests are run in workflow.
- Full Android debug compilation, APK-signature verification and packaging run in GitHub Actions; success is only established if that workflow completes and publishes an artifact.

**Limitations:** Static checks cannot verify visual quality on the user's phone, streaming/playback, or whether external data providers are available. The design does not generate synthetic aviation, maritime, camera or other live position data.
