# DUWM 1674.1 – data-flow repair, not a feature-completion claim

1. AIR counts and the AIR signal use `Duwm1674UnifiedReceipts.aircraft()`, based on the same worldwide OpenSky cache.
2. SEA counts, lights, and the status screen use one regional AIS cache. A regional public AIS HTTP request is attempted on home resume, Refresh All, and a provider-aware schedule; failures show the error and retain the previous successful cache.
3. NEWS counts, lights, and status use the same native RSS/GDELT and older persisted article caches. Counts are cache entries, **not distinct verified events**.
4. Up to 1,200 sampled real OpenSky observations and up to 300 real cached AIS positions are eligible for the home globe. These are displayed observations, not simulated flight or ship trajectories.
5. Source Health can now request AIR, NEWS and regional AIS data. The home ticker no longer labels the obsolete local aircraft cache as the worldwide aircraft feed.
6. The home globe has a separate SEA layer filter; the UI has a shorter globe panel and compact title.
7. Source-integrity checks are updated to the actual 1674.1 code and no longer require an obsolete exact source hash.

**Limitations:** Network access, provider authentication/quotas, real AIS coverage, genuine flight destinations/ETA, working TV/radio playback, Android compilation and on-phone behavior are not established by source checks. All network positions originate from parsed provider replies.
