# DUWM 1678 — Native Screen Redesign

This is a full Android source project carried forward from the compiled DUWM 1677 source.

## Visual changes implemented in Android Java

- Native `Duwm1678VisualKit.PulsePanel`: different colors for Radio, TV, Cameras, Aircraft, AIS, Earthquakes, Weather, Markets, News, Satellites. Decorative scanning lines are never represented as real observations.
- MediaDesk: compact horizontal category tabs; updated record cards; source-state labels; live-in-player indication only after Android reports a prepared stream; retry empty-state controls; previously-received source-directory cache labelled **cached** and not live.
- Maritime: actual AIS positions drawn on a second geographic country-border map beside the existing regional vessel radar; colored vessel rows; prominent information band and animated decorative radar scan.
- Aircraft: illuminated map borders, radar scan guide, heading symbols, two-real-fix track legend, source status and the existing selectable telemetry.
- Earthquakes/markets/weather/satellites: native category banner and colored status; map and charts never manufacture source records.
- Markets historical chart: upgraded background/line glow; displays an honest no-history message unless two real receipts exist.
- Version 1678 (code 167800) and existing application ID retained.

## What this release does NOT claim

A successful source check is not proof of successful Android compilation or live provider access. Radio, TV and cameras require usable legal streams; regional AIS remains coverage-limited; the market data shown are source references rather than synthetic trading ticks. A scan animation is purely UI decoration. No fake geographic markers or source counts are generated.

## Build

Upload `DUWM-1678-REAL-ANDROID-SOURCE.zip` to the GitHub repository root and `DUWM-1678-VISUAL-DESKS-APK.yml` to `.github/workflows/`. The workflow verifies the exact ZIP checksum, source contracts, Android compilation, APK signature, version and compiled features before publishing an artifact.
