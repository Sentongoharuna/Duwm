# DUWM 1166 — Implemented source changes (3 November 2026)

The following are code changes, **not proof of successful Android installation or of source availability**.

- Preserved native original detailed globe and wallpaper source files. Home now has an ALL DESKS navigation entry and uses source-status indicators on aircraft/earthquake/ISS; vessels show a coverage-limited entry.
- Added `Duwm1166SignalView` with independently updated, source-conditioned LEDs. Colors/rhythms represent fresh, stale, error, updating, reference, and unavailable data. No marker or data count is fabricated.
- Added `Duwm1166NewsDeskActivity` for local, worldwide, wars, economics, western, Middle East, Africa, and India. Displays source images if obtained and separates unavailable images from reports.
- Added `Duwm1166PortraitCard` generating original **1080×1920 portrait PNG** cards for TikTok-style sharing through Android's read-only content provider. Includes verified source, publisher time, and real image only where the source supplies one.
- Added `Duwm1166ArticleActivity` — in-app HTTPS article viewer and supported in-app media playback through WebView.
- Added `Duwm1166CustomFeedActivity` for user-supplied HTTPS RSS/Atom/JSON feeds. Avoids inventing items when a feed fails.
- Added `Duwm1166RadioAtlasActivity` with Radio Browser HTTPS station lookup, source-provided map coordinates, Natural Earth coastline geometry and native audio player. Coverage/streams depend on the public service.
- Added `Duwm1166RecordsActivity` and `Duwm1166RecordChart` with dedicated region-filtered aircraft/vessel/ISS/quake/weather pages and histograms of actual stored observations. Two actual observations are required for movement history; no invented tracks.
- Expanded `NewsSourceCatalog` with regional Google News RSS editions and topic searches, including India, Africa, Middle East, economics, maritime, aviation and science. Publication and access are provider-dependent; catalog entries are not evidence of live reception.
- Connected Fintraffic/Digitraffic Finnish-water AIS GeoJSON to the vessel source board. **This is not global AIS coverage**.
- Changed `DuwmPlaceMapActivity` to focus on full-screen geography and moved redundant strips out of view while retaining selected record sharing.
- Incremented versionCode to 116600 and versionName to 1166. Preserved package ID for installation upgrades.

## Known limitations

This ZIP has not passed Android compilation or on-phone acceptance testing within ChatGPT. GitHub must compile it and publish the APK. Map tiles, public news feeds, TV channels, radio streams, AIS, webcams, and APIs may be blocked/unavailable; the app should show unavailable status. Video playback may be restricted by the publisher. The current globe has not been visually re-tested on the user device.
