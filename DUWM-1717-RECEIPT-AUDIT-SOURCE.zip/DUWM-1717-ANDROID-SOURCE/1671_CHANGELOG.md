# DUWM 1671 — 10-area source release (2026-11-03)

All work derives from the full DUWM 1670 Android ZIP. No placeholder Android project, no simulated telemetry, no fake destinations.

## Included (source-level implementation)

1. **Command-home**: new full-screen source-backed mission control reachable as the first tab from the original launcher. Preserves the original Natural Earth coastlines and detailed globe; 6-sector changing-data rail.
2. **Aircraft**: reported OpenSky positions, globally selectable map, constrained two-fix displacement transitions, callsign/ICAO search, follow selected aircraft, real speed/altitude/heading and 9:16 share export. The optional airport/direct-line ETA is explicitly a scenario, NOT a true airline ETA.
3. **Vessels**: real AIS-sourced cached geo-fixes, two-source-time movement when available, per-fix inspection and sharable cards; access to existing marine/AIS setup. An AISStream key and working provider are still required for worldwide live coverage; zero genuine reports remain zero markers.
4. **News geography**: preserved actual 200 regional publisher candidate list (50 Africa, 50 conflict, 50 Western and 50 ISS/space), native country-reference atlas, existing real news headlines and 9:16 news-image cards. Haruna Enterprises remains a *candidate company website*, not a fabricated live article feed.
5. **Markets**: separate reference FX display and source receipt-history chart. Chart is empty until TWO genuine distinct phone-cached provider responses exist; no invented finance tickers.
6. **TV & public cameras**: existing in-app MediaDeskActivity preserved and accessible directly from the 1671 specialist picker. It tests streams at playback and labels still-image cameras as snapshots.
7. **Satellites**: satellite specialist picker, sourced ISS fixes and launch of pre-existing CelesTrak Kepler calculation desk. The orbital position is an estimate, not an observed live satellite location.
8. **Weather & earthquake**: regional weather values with real receipt-history temperature chart; earthquake map with timed event bins from actual cached timestamps.
9. **Shareable data**: new source-attributed, branded 1080×1920 PNG exporter for selected genuine aircraft, maritime, ISS, quake, weather and market records; never invents missing publisher photos.
10. **Source health**: new explicit diagnostic board showing source freshness, receipt/source timestamps, errors, required credentials and OpenSky rate-limit status. Existing cooldown rules preserved.

## Verification and limits

- Inherited 1167–1670 static gates and full old regression suite must pass, plus `verification/check_1671_source.py`.
- GitHub Gradle/Android API 36 compilation, DEX check, APK signing and artifact upload must succeed before distributing an APK.
- No device playback, network live coverage, background stream availability, live worldwide AIS access, verified flight schedule/true ETA or exact satellite orbit is claimed from local tests.
- A website list is not the same as a live integration; the 200-source registries remain discovery candidates.
