# DUWM 1686 — Major all-desk native intelligence workspaces

Version 1686 / versionCode 168600. This is a functional and visible revision of the COMPLETE 1685 Android source, not an unrelated shell or a second globe.

## Concrete changes in Android code

- **19 existing native desk screens**: the 1685 injected command card is replaced by an on-screen 1686 intelligence console with 127dp animated sector canvas, prominent 22sp title, source state, actual received value, provider time and three direct actions. Map-first and media-player screens instead show a compact, hideable 1686 strip, so video and map remain accessible. Dynamic Earthquake/Weather/Markets selector preserves its selected desk.
- **19 new full-screen, five-tab workspaces**: Overview, Observations, History, Sources and Actions. These screens show real provider receipts, received value, provider identity, scope, last error and source timestamps. History reads actual distinct timestamps saved on the device; it does not manufacture trends. All pages link to the exact original native data map/feed/player and share-card route. Back, previous and next navigate between desk screens.
- **New command board**: 19 interactive, individually named desks divided across the three original categories; their status lines derive from stored provider receipts. The first six priority desks are prominent, with an expand control for the full registry. Each has independently clickable DETAIL and LIVE VIEW. Original searchable favorites and app options remain present.
- **New shareable portrait poster**: a redesigned 1080 x 1920 branded PNG for each desk with large artwork, typography, provider status, real source receipt time, scope and time chart, plus verified Android read-only ContentProvider sharing. Sector artwork is explicitly labelled schematic and is not passed off as observed positions, live publisher media or real vessel tracks.
- **Original Command Center preserved**: the one original `SatelliteMapView` remains the launcher globe. Main dock now prominently links to 1686 all-desk workspaces and image sharing. No extra globe is created.
- **Native source capabilities untouched**: aircraft and AIS pages, weather and seismic feeds, radio, TV, news, cameras, NASA, markets, records and monitors still use their original native implementations. The upgrade does not invent provider access or claim that a missing stream is playable.

## Verification boundaries

`verification/check_1686_major_upgrade.py`, original source integrity test, Java syntax parser, 1674 compiler-repair check and offline geodata check are green in source validation. Android compilation, APK signature and actual device UI / feed availability require a successful GitHub Actions run and phone check. New workflow uses exact ZIP SHA-256 and verifies that installed APK has all 1686 components and the versionCode/versionName. Do not claim a green APK until the GitHub build publishes it.

## Preservation

Preserve one existing globe, all original native Activity destinations, live widgets, source connectors, provider receipts, saved watchlists, safe share ContentProvider, and one installed page-upgrade lifecycle hook. No unverified coordinates or fabricated telemetry.
