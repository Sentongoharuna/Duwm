# DUWM 1704 — World Watch investigative newsroom (source code)

Base: complete DUWM 1703 source ZIP. No second globe or alternative activity shell.

- Full-screen World Watch source-search input: headline, summary, provider, event type, region and canonical ID.
- Category selector with genuine incidents, aviation, shipping, weather, news, satellites, cameras and local-monitor receipts.
- Newest / severity-priority / provider sorting and paginated 40-record windows; underlying source caches are untouched.
- Source provenance sheet with provider native ID, provider identity, UTC timestamp, coordinate origin, actual latitude/longitude and full summary.
- Share genuine source-attributed image news cards using the existing ShareCardRenderer; HTTPS publisher source link where supplied.
- Report Cam shortcut routes into the pre-existing LocalMonitorActivity citizen report, recording and uploading experience.
- Existing one original globe, map controls, 1702 lenses, 1703 source index and 19 desks preserved.

IMPORTANT: This is an implementation in Java sources, not a verified compiled APK. Do not claim production upload service guarantees or burnt-in telemetry without end-to-end proof.
