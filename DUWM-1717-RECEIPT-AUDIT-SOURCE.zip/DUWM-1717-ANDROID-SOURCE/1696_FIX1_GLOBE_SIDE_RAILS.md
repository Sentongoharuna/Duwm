# DUWM 1696 FIX1 — Original globe information placement

This is a layout repair of the 1696 source, not a new version or a replacement globe.
The original `SatelliteMapView` and 19 native intelligence desks remain intact.

## Actual existing activity changes
- Replaced permanent full-width top HUD and bottom provider matrix overlays with fixed-width left and right rails, reserving the middle of the globe for touch, rotating Earth and signals.
- Left: world-air shortcut, live layer counts, independently scrolling source selections and genuine observed receipt totals.
- Right: selected source observation, latest acquired signal, provider status lights, original zoom and the cross-source brief.
- Kept search in a small fixed top strip and source/feed ticker plus navigation below the map footprint.
- Original globe rotation/fix/region controls now appear only after tapping **GLOBE TOOLS**.
- New **CLEAR / RAILS** toggle in the top search strip hides and restores both rails without changing the globe renderer or source data.
- Existing map source selection, observation detail and panel navigation actions remain connected.

## Release boundary
1696 versionName, code and package remain unchanged. This does not certify a working APK: GitHub must compile, validate manifest/signature and capture emulator screenshots before release.
