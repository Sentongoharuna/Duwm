# DUWM 1703 — WORLD WATCH / FULL-SCREEN SOURCE RECEIPT INBOX

- Base: original 1702 source archive; unchanged single SatelliteMapView globe and 19 desks.
- 1703 creates a full-screen WORLD WATCH observation inbox on MainActivity. Every listed card is a real geolocated Signal from received source snapshots; never synthetic data.
- Cards display source, event timestamp, elapsed age, severity, credibility, actual latitude/longitude; chronological ordering with canonical-ID de-duplication.
- Native interactive time-window selection (all/1h/6h/24h/72h) and priority severity >=4 filter; persisted on device. Respects 1702 source lens and enabled sources.
- Tap any card: returns to the original globe, centers on its real received coordinates, highlights its observed marker, and opens existing source detail or local monitor report; no second globe.
- Visible WATCH count at globe edge, with access via MORE and header menu; full-screen inbox does not cover the globe while closed.
- Invalid/future provider times excluded; empty states clearly say no matching records, not fabricated LIVE positions.
- APK compiled in GitHub CI; no fabricated APK, no substitute for emulator verification.
