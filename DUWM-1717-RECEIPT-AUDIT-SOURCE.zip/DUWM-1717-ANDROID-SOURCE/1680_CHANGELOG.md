# DUWM 1680 - original command source pulse

The original MainActivity and single SatelliteMapView remain the home screen.
This upgrade adds a visible, horizontally scrolling SOURCE PULSE rail to the existing globe overlay.
Nine native source cards report provider counts separately from retained records, with the actual source state and age.
Each card opens the already-existing native desk; long press opens Source Health.
Updates are driven by provider results and freshness changes, not invented live observations.
The existing one-colour navy/cyan palette remains in use.

This source change is not evidence of APK compilation or live provider availability.
