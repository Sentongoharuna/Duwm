# DUWM 1690 — existing original Command Centre upgraded

**Base:** Exact 1689 full source ZIP (SHA-256: `0844211028159f64b79a8752886e1de61377f3c1253efb6c8a3fe8259f1f0721`). This release does not recreate the app or add an alternative globe.

## Noticeable native changes

- Aircraft map: 9,000 m+ altitude filter; bar displays actual observed fix, movement, altitude and two-fix counts. Original map expanded to 570dp.
- Maritime map: category distribution from actual decoded AIS records; original sea map, AIS radar, vessel focus and in-app controls retained.
- News: source-published last-24-hour filter, counts for publishers' image URLs, saved stories, and actual received articles.
- Radio: source-backed directory totals, mapped station positions, saved stream counts; same Android audio player.
- TV / camera / media: functional HTTPS-listed-source filter and source record metrics inside the scrollable results; native media player remains visible.
- Source Health: real provider-state matrix with received/current/aged/not-received counts.
- Earthquakes / markets / weather shared native sector: expandable existing geographic map. Existing real source trend and event bars preserved.
- All 19 workspaces: LIVE tab now uses receipt history charts instead of schematic artwork; no invented times or signals.
- Original mission board: "Needs" filter for provider problems plus selected tab states.

## Non-regression contract

The original MainActivity launcher and single `SatelliteMapView` globe remain, no duplicate globe or replacement native media engine, same Android applicationId, original aircraft/vessel data receiver connections retained. Older release notes and checks are archival and not run as current-release gates.

## Verification boundary

Verified offline: **actual changed files vs 1689**, protected renderer/media SHA hashes, 19 desk registrations, Java source syntax, existing source/static regression scripts, ZIP integrity, release label/version code. **Not verified offline:** Android full compile, APK signing, phone layout, external feeds and streaming playback.

## GitHub build

Put `DUWM-1690-NATIVE-OPERATIONS-SOURCE.zip` in repository root and `DUWM-1690-NATIVE-OPERATIONS-APK.yml` in `.github/workflows/`. Run the workflow and download its APK artifact only if it compiles, passes app identity checks and is signed. The workflow checks the source ZIP's exact SHA-256.
