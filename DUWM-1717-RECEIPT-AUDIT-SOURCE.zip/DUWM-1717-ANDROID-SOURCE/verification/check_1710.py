#!/usr/bin/env python3
"""DUWM 1710 based on 1709: all 19 thin sector keylines, single original globe and navy."""
from pathlib import Path
import json,re,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
gradle=(root/'app/build.gradle.kts').read_text()
assert 'versionCode = 171001' in gradle and 'versionName = "1710"' in gradle
assert 'com.sentongoharuna.worldsituationroom.rb2live25' in gradle
assert 'DUWM 1710' in (root/'app/src/main/res/values/strings.xml').read_text()
ui=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1710' and ui['uiVersionCode']==171001
assert ui['singleOriginalGlobe'] and ui['launchActivity']=='MainActivity'
assert ui['sectorOutlines1709']['sectionCount']==19
assert ui['sectorOutlines1709']['background']=='#050D22'
assert ui['sectorOutlines1709']['strokeDp']==0.85
assert len(list(j.glob('*.java')))==242
catalog=(j/'Duwm1683DeskCatalog.java').read_text()
assert catalog.count('        d("')==19
outlines=(j/'Duwm1709SectorOutline.java').read_text()
colors=re.findall(r'0xFF[0-9A-F]{6},?\s*// \d{2}',outlines)
assert len(colors)==19,('Expected one distinct accent per desk',len(colors))
assert len(set(re.findall(r'0xFF[0-9A-F]{6}', '\n'.join(colors))))==19
for phrase in ('density * 0.85f','Color.TRANSPARENT','frameNativePage(Activity activity)',
               'Duwm1683DeskCatalog.find(activity)','FrameLayout'):
    assert phrase in outlines,phrase
board=(j/'Duwm1687MissionBoard.java').read_text()
assert 'Duwm1709SectorOutline.card(a,i' in board
assert 'Duwm1709SectorOutline.color(i)' in board
for name in ('Duwm1687WorkspaceActivity.java','Duwm1686WorkspaceActivity.java'):
    s=(j/name).read_text()
    assert 'Duwm1709SectorOutline.card(this,deskIndex' in s,name
native=(j/'Duwm1683DeskFullScreenActivity.java').read_text()
assert 'Duwm1709SectorOutline.card(this,deskIndex' in native
assert 'Duwm1709SectorOutline.color(deskIndex)' in native
opts=(j/'DuwmOptionsActivity.java').read_text()
assert 'Duwm1709SectorOutline.card(this,Duwm1709SectorOutline.index(d)' in opts
app=(j/'DuWorldApplication.java').read_text()
assert 'registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks()' in app
assert 'Duwm1709SectorOutline.frameNativePage(a);' in app
main=(j/'MainActivity.java').read_text()
assert main.count('new SatelliteMapView(this)')==1
assert 'show1703WorldWatch()' in main and 'render1705Pulse' in main
sphere=(j/'SatelliteMapView.java').read_text()
for phrase in ('draw1705ReceivedFixLines(canvas)','draw1705SourceLightBeacons(canvas)',
               'draw1706SourceActivityHalo(canvas)'):
    assert phrase in sphere,phrase
assert 'DuwmUnifiedTheme.APPROVED_NAVY' in sphere
rail=(j/'SignalTickerRailView.java').read_text()
assert 'render1706ReceivedTicker' in rail
colors_theme=(j/'DuwmUnifiedTheme.java').read_text()
assert 'BACKGROUND = 0xFF050D22' in colors_theme
assert 'APPROVED_NAVY = 0xFF050D22' in colors_theme
for p in (root/'app/src/main/res').rglob('*.xml'):ET.parse(p)
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
android='{http://schemas.android.com/apk/res/android}'
launch=[]
for a in manifest.findall('application/activity'):
    for f in a.findall('intent-filter'):
        actions={n.get(android+'name') for n in f.findall('action')}
        categories={n.get(android+'name') for n in f.findall('category')}
        if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in categories:
            launch.append(a.get(android+'name','').lstrip('.'))
assert launch==['MainActivity'],launch
print('PASS DUWM 1710: 19 section-specific thin outlines, global native page frames, approved midnight navy, original single globe and newsroom')

# 1710 source-derived wave chart and high-priority geolocated event halos.
chart=(j/'Duwm1710SourceWaveView.java').read_text()
for snippet in ('BUCKETS = 12','windowHours == 24 ? 6 : 24',
                'signal.timestampMs > now + 300_000L','set1710Observations',
                'NO OBSERVATIONS IN WINDOW','signal.layer == Signal.Layer.SHIPS'):
    assert snippet in chart,snippet
assert 'set1710Observations(rows)' in main
assert 'new Duwm1710SourceWaveView(this)' in main
assert 'sourceUnderline1710.setBackgroundColor' in main
assert 'draw1710EvidenceSignalGlow(canvas);' in sphere
assert 'signal.severity < 4' in sphere
assert 'if (age > 6L * 60L * 60_000L)' in sphere
assert 'projectInto(signal.latitude, signal.longitude, xy)' in sphere
assert 'Synthetic' not in chart
assert ui['visualDynamics1710']['background']=='#050D22'
assert ui['visualDynamics1710']['singleOriginalGlobe'] is True
assert ui['visualDynamics1710']['syntheticReports'] is False
assert ui['visualDynamics1710']['retainedSectorOutlines']==19
print('PASS 1710: 12 time bins, 6H/24H real received reports, severity 4+ source-coordinate accents, 19 outlines preserved')
