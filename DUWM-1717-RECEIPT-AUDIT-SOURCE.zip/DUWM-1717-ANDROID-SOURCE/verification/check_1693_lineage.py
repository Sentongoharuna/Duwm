"""Assert real 1693 source-lineage and functional native-page edits, not just a version bump.
The SHA of the external 1692 base is pinned in SOURCE_LINEAGE_1693.json.
This test independently checks immutable source anchors and in-place 1693 code features.
"""
from pathlib import Path
import hashlib,json,re
P=Path(__file__).resolve().parent.parent
manifest=json.loads((P/'SOURCE_LINEAGE_1693.json').read_text())
assert manifest['release']==1693 and manifest['parent_release']==1692
assert manifest['parent_zip_sha256']=='0bad4438cb391b6ef089aad46fff479b5fb9c69c87523150c587c580d6e2d7e3'
for file,sha in manifest['protected_unchanged_sha256'].items():
    assert hashlib.sha256((P/file).read_bytes()).hexdigest()==sha,('protected source changed',file)
base=P/'app/src/main/java/com/sentongoharuna/worldsituationroom'
features={'Duwm1670FlightMapActivity': ['renderAircraftRegister', 'LOAD NEXT ', 'map.focus(pin.lat,pin.lon'], 'GevMarineActivity': ['VESSEL REGISTER FIRST', 'listFirst', 'seaMapLayout.height=dp(listFirst?'], 'Duwm1166NewsDeskActivity': ['compactNews', 'COMPACT SOURCE WIRE', 'dp(compactNews?106:240)'], 'Duwm1166RadioAtlasActivity': ['STATION LIST FIRST', 'atlasLayout.height=dp(fullAtlas?490:210)'], 'MediaDeskActivity': ['duwm1693_saved_media', 'savedMediaOnly', 'SAVE VERIFIED SOURCE LISTING'], 'Duwm1671SourceStatusActivity': ['compactRows', 'INCIDENT DETAIL'], 'Duwm1687WorkspaceActivity': ['recentHistory', 'compareAll', 'LAST 24 HOURS'], 'Duwm1687MissionBoard': ['sort_attention_first', 'attentionOrder', 'list.removeAllViews();for(int ix:order)'], 'Duwm1670WorldMapView': ['remove game-like simulated radar sweep', 'TWO genuine dated position records'], 'Duwm1690EvidenceBars': ['duwm1693_presentation', 'RECEIVED DATA CARDS']}
for name,tokens in features.items():
    data=(base/(name+'.java')).read_text()
    for token in tokens:assert token in data,('missing native function',name,token)
assert (base/'Duwm1693Chrome.java').is_file()
assert not any('Duwm1692Chrome' in file.read_text() for file in base.glob('*.java')),'Unresolved 1692 Chrome class reference'
assert len(list(base.glob('*.java')))>=239
assert 'versionName = "1693"' in (P/'app/build.gradle.kts').read_text()
assert 'versionCode = 169300' in (P/'app/build.gradle.kts').read_text()
assert 'DUWM 1693 • DEVELOP.UGANDA' in (P/'app/src/main/res/values/strings.xml').read_text()
ui=json.loads((P/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1693' and ui['uiVersionCode']==169300 and ui['singleOriginalGlobe'] is True
catalog=(base/'Duwm1683DeskCatalog.java').read_text()
assert catalog.count('        d("')>=19, 'Missing 19-desk native catalog'
print('PASS: 1693 parent SHA, preserved original globe, 10 changed native components, 19 desks and installed app identity')
