from pathlib import Path
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
s=(j/'MainActivity.java').read_text()
t=(j/'DuwmUnifiedTheme.java').read_text()
assert 'globeSpace.setMargins(0, 0, 0, 0)' in s
assert 'root.addView(search, searchParams);' in s
assert 'root.addView(upperTicker1705' in s
assert 'root.addView(quickActions, quickParams)' in s
assert 'root.addView(missionDock, missionParams)' in s
assert 'root.addView(crawlText' in s and 'root.addView(feedPulse' in s
for forbidden in ('commandDeck.addView(leftTabs','commandDeck.addView(rightTabs',
                  'commandDeck.addView(search, searchParams)',
                  'commandDeck.addView(crawlText, crawlParams)',
                  'commandDeck.addView(missionDock, dockParams)'):
    assert forbidden not in s,forbidden
assert 'DUWM 1710 FIX1' in (root/'app/src/main/res/values/strings.xml').read_text()
assert 'versionCode = 171001' in (root/'app/build.gradle.kts').read_text()
assert 'DuwmUnifiedTheme.PANEL' in s and 'DuwmUnifiedTheme.BORDER' in s
assert 'BACKGROUND = 0xFF050D22' in t
assert 'drawable.setColor(DuwmUnifiedTheme.PANEL)' in (j/'MainActivity.java').read_text()
assert 'd.setColor(DuwmUnifiedTheme.PANEL)' in (j/'Duwm1709SectorOutline.java').read_text()
assert 'Duwm1709SectorOutline.card(this,deskIndex' in (j/'Duwm1683DeskFullScreenActivity.java').read_text()
assert 'Duwm1710SourceWaveView' in s and 'SignalTickerRailView' in s
assert s.count('new SatelliteMapView(this)')==1
print('PASS: 1710 FIX1 dedicated chrome rows, no permanent map overlays, uniform 19 desks, original globe preserved')
