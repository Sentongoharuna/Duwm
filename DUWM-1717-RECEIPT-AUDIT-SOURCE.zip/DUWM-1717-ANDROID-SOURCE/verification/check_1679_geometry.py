from pathlib import Path
r=Path(__file__).resolve().parents[1]
for filename, minimum_lines in [('naturalearth_coasts.txt',500),('duwm_country_borders_wdbii.txt',450)]:
    lines=(r/'app/src/main/assets'/filename).read_text().splitlines()
    assert len(lines)>=minimum_lines,(filename,len(lines))
    assert all(',' in line for line in lines)
print('PASS 1679 offline detailed country and coast files are packaged')
