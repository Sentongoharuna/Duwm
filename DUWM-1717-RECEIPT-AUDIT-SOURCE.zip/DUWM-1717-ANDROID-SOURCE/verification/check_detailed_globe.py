#!/usr/bin/env python3
"""1167 device-visible globe preference regression (static source test)."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]
pkg=p/'app/src/main/java/com/sentongoharuna/worldsituationroom'
a=(pkg/'OperationsMainActivity.java').read_text()
d=(pkg/'OperationsGlobeView.java').read_text()
legacy=(pkg/'SatelliteMapView.java').read_text()
assert a.count('earth=new OperationsGlobeView(this)')==1
assert 'globeLabel=text("DETAILED EARTH  /  VERIFIED WORLD POSITIONS"' in a
assert 'originalMode=false;\n        earth.setVisibility(View.VISIBLE);' in a
assert '        switchOriginalRenderer();\n        earth.postInvalidateOnAnimation();' not in a
assert 'originalToggle.setOnClickListener(v->switchOriginalRenderer());' in a
assert 'originalToggle.setText("LEGACY")' in a and 'originalToggle.setText("DETAILED")' in a
assert 'loadCoasts()' in d and 'naturalearth_coasts.txt' in d
assert 'postInvalidateOnAnimation()' in d
assert 'private void drawGlobeLand(Canvas canvas)' in legacy and 'LAND_MASSES' in legacy
assert 'sourceHeartbeat.setContentDescription(ok>0?' in a
from release_contract import assert_release_at_least
assert_release_at_least(p,1167)
print('PASS 1167 preserved detail restore: Natural Earth globe default, legacy optional, source status compact, version upgrade')
