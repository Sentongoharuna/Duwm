from pathlib import Path
import xml.etree.ElementTree as ET
import json,re
root=Path(__file__).resolve().parents[1]
main=root/'app/src/main'
java=main/'java/com/sentongoharuna/worldsituationroom'
config=(root/'app/build.gradle.kts').read_text()
assert 'versionCode = 167600' in config and 'versionName = "1676"' in config
ui=json.loads((main/'assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1676' and ui['launchActivity']=='Duwm1676CommandDeckActivity'
assert (main/'assets/duwm_1676_release_notes.json').is_file()
manifest=ET.parse(main/'AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
launchers=[]
for a in manifest.iter('activity'):
    name=a.get(ns+'name','')
    for f in a.findall('intent-filter'):
        if 'android.intent.action.MAIN' in {x.get(ns+'name') for x in f.findall('action')} and 'android.intent.category.LAUNCHER' in {x.get(ns+'name') for x in f.findall('category')}:
            launchers.append(name)
assert launchers==['.Duwm1676CommandDeckActivity'],launchers
names={a.get(ns+'name','') for a in manifest.iter('activity')}
assert '.Duwm1676GeoWatchActivity' in names
assert '.Duwm1675EvidenceVaultActivity' in names
assert (java/'Duwm1676CommandDeckActivity.java').is_file()
for fname in ('Duwm1676GeoWatchActivity.java','Duwm1676GeoMath.java','Duwm1676WatchRegions.java'):
    assert (java/fname).is_file(),fname
activity=(java/'Duwm1676GeoWatchActivity.java').read_text()
store=(java/'Duwm1676WatchRegions.java').read_text()
deck=(java/'Duwm1674CommandDeckActivity.java').read_text()
for token in ('RunningballV25GlobalAircraftData.read','DuwmGeoObservationStore.read',
              'GevMarineActivity.timestamp','Duwm1676GeoMath.inside','Duwm1676GeoMath.acceptableTime',
              'Duwm1676WatchRegions.read','Duwm1676WatchRegions.add','Duwm1676WatchRegions.remove',
              'V115941ShareCards.share','SOURCE EVIDENCE VAULT','SCAN DEVICE CACHE',
              'REQUEST SOURCE UPDATES','RECENT SOURCE'):
    if token=='RECENT SOURCE':continue
    assert token in activity,token
assert 'MAX_CUSTOM=20' in store and 'WORLD / ALL OBSERVED' in store and 'STRAIT OF HORMUZ' in store
assert 'Duwm1676GeoWatchActivity.class' in deck and '1676 GEOGRAPHIC WATCHLIST' in deck
assert 'Duwm1675EvidenceVaultActivity.class' in deck
assert 'OCEAN_COLOR=Color.rgb' in (java/'OperationsGlobeView.java').read_text()
assert 'Math.random(' not in activity and 'fake' not in activity.lower()
print('PASS 1676 watchlist: new launcher, nav, actual cached locations, source timestamps, region persistence, filters, map and cards')
