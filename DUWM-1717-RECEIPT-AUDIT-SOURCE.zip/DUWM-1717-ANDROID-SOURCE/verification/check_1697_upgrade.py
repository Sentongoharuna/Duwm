#!/usr/bin/env python3
"""1697 source and lineage gate. Android compilation/emulator is a distinct required step."""
from pathlib import Path
from hashlib import sha256
import json,xml.etree.ElementTree as ET
p=Path(__file__).resolve().parent.parent
j=p/'app/src/main/java/com/sentongoharuna/worldsituationroom'
lineage=json.loads((p/'1697_SOURCE_LINEAGE.json').read_text())
assert lineage['release']==1697
assert lineage['base_sha256']=='52df6727532580e043823c29dec8f2660b149bf422785e76a70b165120261837'
assert lineage['parent_original_globe_sha256']=='cf069e2f0aabfcb17f3b151382f5ceea72413ff93f8486084ecdba0dc3113279'
assert lineage['parent_main_activity_sha256']=='55ada5c7ce8b5bc399116d75af0738662b344bbb71ecaef7f8c31a5919309075'
main=(j/'MainActivity.java').read_text()
assert sha256(main.replace('1697','1696').encode()).hexdigest()==lineage['parent_main_activity_sha256'], 'Main globe structure modified beyond release labels'
assert main.count('new SatelliteMapView(this)')==1
assert 'globeSpace.setMargins(0, dp(52), 0, dp(102))' in main
assert main.count('dp(36), ViewGroup.LayoutParams.WRAP_CONTENT')==2
assert 'mapView.setScaleX(' not in main and 'mapView.setScaleY(' not in main
assert sha256((j/'SatelliteMapView.java').read_bytes()).hexdigest()==lineage['parent_original_globe_sha256']
assert 'Math.min(getWidth() * 0.455f, getHeight() * 0.40f) * globeScale' in (j/'SatelliteMapView.java').read_text()
assert 'root.addView(seaWorldMap,4,seaMapLayout)' in (j/'GevMarineActivity.java').read_text()
assert 'float y=head+row*rowHeight' in (j/'Duwm1690EvidenceBars.java').read_text()
news=(j/'Duwm1166NewsDeskActivity.java').read_text()
assert 'advancedNews.setVisibility(android.view.View.GONE)' in news
assert 'newsEvidence.setVisibility(android.view.View.GONE)' in news
radio=(j/'Duwm1166RadioAtlasActivity.java').read_text()
assert 'advancedRadio.setVisibility(android.view.View.GONE)' in radio
assert 'radioEvidence.setVisibility(android.view.View.GONE)' in radio
media=(j/'MediaDeskActivity.java').read_text()
assert 'playerControlsScroll.addView(controls)' in media
assert 'playerBox.addView(info' in media
health=(j/'Duwm1671SourceStatusActivity.java').read_text()
assert 'healthEvidence.setVisibility(android.view.View.GONE)' in health
assert 'OPENSKY RECEIVER COVERAGE' in (j/'AircraftOperationsActivity.java').read_text()
assert 'versionCode = 169700' in (p/'app/build.gradle.kts').read_text()
assert 'versionName = "1697"' in (p/'app/build.gradle.kts').read_text()
assert '<string name="app_name">DUWM 1697 • DEVELOP.UGANDA</string>' in (p/'app/src/main/res/values/strings.xml').read_text()
assert len(list(j.glob('*.java')))>=239
assert len(list(j.glob('SatelliteMapView.java')))==1
assert 'Duwm1683DeskCatalog.ALL' in main and 'open1684Desk(18)' in main
ui=json.loads((p/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1697' and ui['uiVersionCode']==169700 and ui['singleOriginalGlobe']
ns='{http://schemas.android.com/apk/res/android}'
manifest=ET.parse(p/'app/src/main/AndroidManifest.xml').getroot()
launch=[]
for a in manifest.findall('application/activity'):
 for f in a.findall('intent-filter'):
  if {x.get(ns+'name') for x in f.findall('action')} >= {'android.intent.action.MAIN'} and {x.get(ns+'name') for x in f.findall('category')} >= {'android.intent.category.LAUNCHER'}:
   launch.append(a.get(ns+'name','').lstrip('.'))
assert launch==['MainActivity'],launch
print('PASS: 1697 parent, correct app identity, original full globe, 19 desks, six enhanced native surfaces and charts')
print('WARNING: This does not prove APK compilation, network feeds, player compatibility or phone visuals.')
