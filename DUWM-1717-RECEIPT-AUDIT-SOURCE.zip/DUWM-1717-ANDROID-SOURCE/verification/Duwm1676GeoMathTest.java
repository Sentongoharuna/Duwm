package com.sentongoharuna.worldsituationroom;

/** Real geography tests: known distances, anti-meridian and invalid or stale sources. */
public final class Duwm1676GeoMathTest {
    private static void check(boolean condition,String msg){if(!condition)throw new AssertionError(msg);}
    public static void main(String[] args){
        check(Math.abs(Duwm1676GeoMath.distanceKm(0,0,0,0))<1e-8,"same position");
        double kampalaMombasa=Duwm1676GeoMath.distanceKm(0.3476,32.5825,-4.0435,39.6682);
        check(kampalaMombasa>800&&kampalaMombasa<1000,"Kampala-Mombasa distance");
        check(Duwm1676GeoMath.inside(0.3476,32.5825,100,0.5,32.6),"Uganda near");
        check(!Duwm1676GeoMath.inside(0.3476,32.5825,100,-4.0435,39.6682),"Mombasa not Kampala");
        check(Duwm1676GeoMath.distanceKm(0,179.8,0,-179.8)<50,"anti-meridian wrap");
        check(!Duwm1676GeoMath.inside(0,0,100,91,0),"invalid coordinate");
        check(!Duwm1676GeoMath.inside(0,0,-1,0,0),"negative radius");
        check(!Duwm1676GeoMath.inside(0,0,30000,0,0),"unbounded radius");
        long now=1793736000000L;
        check(!Duwm1676GeoMath.acceptableTime(631152000000L,now,86400000L),"historical 1990 cannot be live");
        check(Duwm1676GeoMath.acceptableTime(now-10000L,now,3600000L),"recent real position");
        check(!Duwm1676GeoMath.acceptableTime(now-7200000L,now,3600000L),"stale position");
        check(!Duwm1676GeoMath.acceptableTime(now+7200000L,now,3600000L),"future position");
        System.out.println("PASS 1676 geo watch: distances, radius, antimeridian, valid timestamps and staleness");
    }
}
