#!/usr/bin/env python3
"""1708 release gates: real Android source and approved midnight-blue identity.

This does not claim a successful APK compilation until CI assembles the artifact.
"""
from pathlib import Path
import json
import xml.etree.ElementTree as ET
root = Path(__file__).resolve().parents[1]
java = root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
values = root/'app/src/main/res/values'
gradle=(root/'app/build.gradle.kts').read_text()
assert 'versionCode = 170800' in gradle and 'versionName = "1708"' in gradle
assert 'applicationId = "com.sentongoharuna.worldsituationroom.rb2live25"' in gradle
assert 'DUWM 1708' in (values/'strings.xml').read_text()
ui=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1708' and ui['uiVersionCode']==170800
assert ui['singleOriginalGlobe'] and ui['launchActivity']=='MainActivity'
main=(java/'MainActivity.java').read_text()
globe=(java/'SatelliteMapView.java').read_text()
rail=(java/'SignalTickerRailView.java').read_text()
assert main.count('new SatelliteMapView(this)')==1, 'a duplicate globe was added'
assert 'Math.min(getWidth() * 0.455f, getHeight() * 0.40f) * globeScale' in globe
for needle in ('updateAutoRotation()', 'drawGlobe(canvas)',
               'draw1705ReceivedFixLines(canvas)', 'draw1705SourceLightBeacons(canvas)',
               'draw1706SourceActivityHalo(canvas)', 'set1702SourceLens(int lens)'):
    assert needle in globe, needle
for needle in ('show1703WorldWatch()', 'filter1704WorldWatch(List<Signal> source)',
               'show1704Receipt(Signal signal)', 'render1705Pulse(List<Signal> allReceived)',
               'show1706SignalConsole()', 'show1706TickerSpeed()',
               'shareSignal(signal)', 'openLocalMonitors()'):
    assert needle in main,needle
for needle in ('render1706ReceivedTicker(List<Signal> observations)',
               'set1706Channel(Signal.Layer channel)', 'set1706Speed(int dpPerSecond)',
               'postInvalidateOnAnimation()'):
    assert needle in rail,needle
assert 'DuwmUnifiedTheme.APPROVED_NAVY' in globe
assert 'DuwmUnifiedTheme.BACKGROUND' in rail
assert 'DuwmUnifiedTheme.RAISED_CARD' in rail
assert (java/'ShareCardRenderer.java').is_file()
assert 'Color.rgb(5, 13, 34)' in (java/'ShareCardRenderer.java').read_text()
assert 'Color.rgb(8, 22, 46)' in (java/'ShareCardRenderer.java').read_text()
assert len(list(java.glob('*.java')))==240
assert len((java/'Duwm1683DeskCatalog.java').read_text().split('        d("'))==20
for file in (root/'app/src/main/res').rglob('*.xml'): ET.parse(file)
assert len(list((root/'app/src/main/res').rglob('*.xml')))==75
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
launch=[]
for activity in manifest.findall('application/activity'):
    for intent in activity.findall('intent-filter'):
        acts={a.get(ns+'name') for a in intent.findall('action')}
        cats={c.get(ns+'name') for c in intent.findall('category')}
        if 'android.intent.action.MAIN' in acts and 'android.intent.category.LAUNCHER' in cats:
            launch.append(activity.get(ns+'name','').lstrip('.'))
assert launch==['MainActivity'],launch
print('PASS DUWM 1708: release identity, one original moving globe, original tickers, 19 desks, news sharing and native resources')
