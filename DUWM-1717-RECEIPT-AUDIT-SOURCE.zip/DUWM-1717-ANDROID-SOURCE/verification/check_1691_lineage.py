"""DUWM 1691 audit: source lineage, actual existing-page edits and truth-in-data safeguards.
This is not a substitute for Gradle compilation or real phone verification.
"""
from pathlib import Path
import hashlib,json,re,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
java=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
lineage=json.loads((root/'SOURCE_LINEAGE_1691.json').read_text())
assert lineage['release']=='1691' and lineage['basedOn']=='1690'
assert lineage['parentZipSHA256']=='d6b527de76cb775eeb2d8ec5ed1fa1c6079c1b854ade4ef3b37bdc024dacaad3'
assert len(lineage['changedExistingJava'])>=14
for name,old in lineage['oldJavaSHA256'].items():
    p=java/name
    assert p.is_file(), f'Removed existing Android page: {name}'
    assert hashlib.sha256(p.read_bytes()).hexdigest()!=old, f'No native improvement vs 1690: {name}'
for name,old in lineage['protectedSHA256'].items():
    assert hashlib.sha256((java/name).read_bytes()).hexdigest()==old, f'Original globe/map/radar replaced: {name}'
main=(java/'MainActivity.java').read_text()
assert main.count('mapView = new SatelliteMapView(this);')==1
assert hashlib.sha256(main.replace('1691','1690').encode()).hexdigest()==lineage['oldJavaSHA256']['MainActivity.java'], 'Core globe launcher changed beyond source label'
assert sum(s.lstrip().startswith('d("') for s in (java/'Duwm1683DeskCatalog.java').read_text().splitlines())==19
chart=(java/'Duwm1690EvidenceBars.java').read_text()
assert 'LOCAL DATASET' in chart and 'counts[k]/(float)max' in chart and 'maxWidth' in chart
for name in ['Duwm1670FlightMapActivity.java','GevMarineActivity.java','Duwm1166NewsDeskActivity.java',
             'Duwm1166RadioAtlasActivity.java','MediaDeskActivity.java','Duwm1671SourceStatusActivity.java']:
    t=(java/name).read_text()
    assert 'Duwm1690EvidenceBars' in t and 'Duwm1691Chrome.title' in t, f'{name} missing 1691 native visual changes'
visual=(java/'Duwm1687OpsVisual.java').read_text()
assert 'Duwm1685ReceiptHistory.read' in visual
assert 'n>=2 && lastTime>firstTime' in visual
assert 'point.sourceAt-firstTime' in visual
assert 'drawCircle(' not in visual and 'SCHEMATIC UI' not in visual, 'Previous radar schematic not removed'
board=(java/'Duwm1687MissionBoard.java').read_text()
assert 'HorizontalScrollView tabsScroller' in board and 'SOURCE' in board and 'statusSurface' in board
workspace=(java/'Duwm1687WorkspaceActivity.java').read_text()
assert '1691 / '+ '"+desk.title' in workspace
assert 'Duwm1687OpsVisual' in workspace and 'Duwm1690EvidenceBars' in workspace
for name in ['Duwm1687ShareCard.java','Duwm1671SectorActivity.java','Duwm1683DeskFullScreenActivity.java',
             'DuwmOptionsActivity.java','Duwm1687WorkspaceActivity.java']:
    s=(java/name).read_text()
    assert not re.search(r'(?<![A-Za-z])1690\s*/|DUWM 1690|SHARE 1690',s),f'Outdated visible 1690 in {name}'
for name in ['MediaDeskActivity.java','Duwm1166RadioAtlasActivity.java']:
    txt=(java/name).read_text()
    assert 'MediaPlayer' in txt or 'play(' in txt, 'Original playback removed'
gradle=(root/'app/build.gradle.kts').read_text()
assert 'versionCode = 169100' in gradle and 'versionName = "1691"' in gradle
assert 'applicationId = "com.sentongoharuna.worldsituationroom.rb2live25"' in gradle
strings=(root/'app/src/main/res/values/strings.xml').read_text()
assert '<string name="app_name">DUWM 1691 • DEVELOP.UGANDA</string>' in strings
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
a='{http://schemas.android.com/apk/res/android}'
assert any(el.attrib.get(a+'name')=='.MainActivity' for el in manifest.iter('activity'))
ui=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1691' and ui['uiVersionCode']==169100 and ui['singleOriginalGlobe'] is True
print('PASS: 1691 derives from exact 1690 archive, 15 modified original Java files and one new style helper')
print('PASS: six native desks have in-place professional UI, all 19 detail desks share actual receipt timeline and polished source visuals')
print('PASS: original single globe, existing media engines, appId and links preserved; app label and version 1691')
print('NOT VERIFIED: Android compilation, installed APK, provider responsiveness, on-phone appearance')
