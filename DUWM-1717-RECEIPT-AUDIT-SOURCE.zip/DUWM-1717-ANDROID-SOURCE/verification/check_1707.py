#!/usr/bin/env python3
"""1707 full navy print; protect original globe and the 1706 green features."""
import json, re, xml.etree.ElementTree as ET
from pathlib import Path
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
main=(src/'MainActivity.java').read_text()
globe=(src/'SatelliteMapView.java').read_text()
ticker=(src/'SignalTickerRailView.java').read_text()
body=(root/'app/build.gradle.kts').read_text()
ui=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert 'versionCode = 170700' in body and 'versionName = "1707"' in body
assert 'applicationId = "com.sentongoharuna.worldsituationroom.rb2live25"' in body
assert 'DUWM 1707' in (root/'app/src/main/res/values/strings.xml').read_text()
assert ui['uiRevision']=='1707' and ui['uiVersionCode']==170700
assert ui['singleOriginalGlobe'] and ui['launchActivity']=='MainActivity'
assert main.count('new SatelliteMapView(this)')==1
assert 'Math.min(getWidth() * 0.455f, getHeight() * 0.40f) * globeScale' in globe
for token in ['updateAutoRotation()', 'drawGlobe(canvas)', 'drawOriginalGeographicDetail(canvas)',
              'draw1705ReceivedFixLines(canvas)', 'draw1705SourceLightBeacons(canvas)',
              'draw1706SourceActivityHalo(canvas)', 'set1702SourceLens(int lens)']:
 assert token in globe,token
for token in ['show1703WorldWatch()', 'filter1704WorldWatch(List<Signal> source)',
              'show1704Receipt(Signal signal)', 'shareSignal(signal)',
              'matches1705Evidence(Signal signal)', 'render1705Pulse(List<Signal> allReceived)',
              'show1706SignalConsole()', 'show1706TickerSpeed()', 'set1706Channel(tickerChannel1706)']:
 assert token in main,token
for token in ['render1706ReceivedTicker(List<Signal> observations)',
              'postInvalidateOnAnimation()', 'set1706Speed(int dpPerSecond)']:
 assert token in ticker,token
assert 'Color.argb(245, 14, 34, 72)' in globe, 'must be midnight-blue land'
assert 'Color.argb(195, 67, 111, 184)' in globe, 'must be cobalt land outline'
assert 'Color.argb(78, 35, 73, 69)' not in globe, 'green flat land regression'
assert 'Color.argb(238, 14, 65, 79)' not in globe, 'green/teal land regression'
theme=(src/'DuwmUnifiedTheme.java').read_text()
for v in ('0xFF050D22','0xFF0D2345','0xFF183B6B','0xFF558BDF'):
 assert v in theme,v
assert 'android:windowLightStatusBar' in (root/'app/src/main/res/values/styles.xml').read_text()
assert '#558BDF' in (root/'app/src/main/assets/duwm_place_map.html').read_text()
assert '#47D2DB' not in (root/'app/src/main/assets/duwm_place_map.html').read_text()
assert '1707' in (root/'1707_RELEASE_NOTES.md').read_text()
ns='{http://schemas.android.com/apk/res/android}'
man=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
launch=[]
for activity in man.findall('application/activity'):
 for filt in activity.findall('intent-filter'):
  acts={a.get(ns+'name') for a in filt.findall('action')}
  cats={c.get(ns+'name') for c in filt.findall('category')}
  if 'android.intent.action.MAIN' in acts and 'android.intent.category.LAUNCHER' in cats:
   launch.append(activity.get(ns+'name','').lstrip('.'))
assert launch==['MainActivity'],launch
assert len(list(src.glob('*.java'))) == 240
assert len((src/'Duwm1683DeskCatalog.java').read_text().split('        d("')) == 20
assert (src/'ShareCardRenderer.java').exists()
print('PASS 1707: midnight-blue UI, same original globe, all 19 desks, source-backed tickers, World Watch + news share cards')
