#!/usr/bin/env python3
"""Apply meaningful native DUWM fixes to regenerated Android project.

Fails if the known source layout drifts. Does not invent observations or media feeds.
"""
from pathlib import Path
import sys,re,hashlib,json
root=Path(sys.argv[1]);base=root/'app/src/main';pkg=base/'java/com/sentongoharuna/worldsituationroom'
assert (pkg/'OperationsMainActivity.java').is_file(), 'Actual Android source missing'
protected=['DuwmLiveWallpaperService.java','DuWidgetProviders.java','DuWidgetUpdater.java','WidgetSnapshot.java','V115941ShareCards.java','MediaDeskActivity.java','DuwmWorldIntelligenceActivity.java','AircraftOperationsActivity.java']
old_sha={p:hashlib.sha256((pkg/p).read_bytes()).hexdigest() for p in protected if (pkg/p).is_file()}

def once(text,old,new,reason):
    count=text.count(old)
    if count!=1:raise AssertionError(f'{reason}: expected one anchor, found {count}')
    return text.replace(old,new,1)

# 1) Replace the unreliable external-JS map dependency with self-contained slippy map.
html=(Path(__file__).parent/'duwm_native_map.html').read_text(encoding='utf-8')
assert '<script>' in html and 'window.duwmReceive=' in html and 'tile.openstreetmap.org/' in html
asset=base/'assets/duwm_place_map.html';asset.write_text(html,encoding='utf-8')

# 2) Native source receipt panel: no floating rail over navigation or map controls.
railfile=pkg/'DuwmSignalRail.java';r=railfile.read_text()
r=once(r,'    View root = activity.getWindow() == null ? null : activity.getWindow().getDecorView();',
  '''    // These screens contain an embedded signal rail in a dedicated layout row.
    // Do not add another floating rail over their controls or real map records.
    if (activity instanceof OperationsMainActivity || activity instanceof DuwmPlaceMapActivity) return;
    View root = activity.getWindow() == null ? null : activity.getWindow().getDecorView();''',
  'avoid overlay on map and main screen')
r=once(r,'  public static void attach(Activity activity) {',
  '''  /** Render the same verified source lights inside a reserved status-row slot. */
  public static DuwmSignalRail embedded(Activity activity) {return new DuwmSignalRail(activity);}

  public static void attach(Activity activity) {''','embed actual signal rail')
railfile.write_text(r)

# 3) Preserve original detailed SatelliteMapView as default, reduce chrome, fix insets.
mainfile=pkg/'OperationsMainActivity.java';m=mainfile.read_text()
m=once(m,'setContentView(root);','''setContentView(root);
        root.setFitsSystemWindows(true);
        if(android.os.Build.VERSION.SDK_INT >= 30){
            root.setOnApplyWindowInsetsListener((v,insets)->{
                android.graphics.Insets bars=insets.getInsets(android.view.WindowInsets.Type.statusBars()|android.view.WindowInsets.Type.navigationBars());
                root.setPadding(0,bars.top,0,bars.bottom);
                return insets;
            });
        }''','respect Android status bar')
m=once(m,'rowAdd(root,heading,-1,57);','rowAdd(root,heading,-1,50);','compact first header')
m=once(m,'dp(43),dp(43)','dp(36),dp(36)','logo not oversized')
m=once(m,'brand.addView(text("DEVELOP.UGANDA",18,TEXT,true));','brand.addView(text("DEVELOP.UGANDA",15,TEXT,true));','responsive title')
m=once(m,'brand.addView(text("WORLD SITUATION ROOM  /  FUSED COMMAND",11,MUTED,true));','brand.addView(text("WORLD SITUATION ROOM  /  INTELLIGENCE",10,MUTED,true));','responsive subtitle')
m=once(m,'rowAdd(heading,headerStatus,92,40);','rowAdd(heading,headerStatus,70,34);','compact source status')
m=once(m,'rowAdd(root,metadata,-1,29);','rowAdd(root,metadata,-1,27);','compact UTC metadata')
m=once(m,'rowAdd(root,scroller,-1,51);','rowAdd(root,scroller,-1,44);','compact nav bar')
m=once(m,'dp(46));lp.rightMargin=dp(7);','dp(39));lp.rightMargin=dp(6);','smaller nav tabs')
m=once(m,'rowAdd(globeFrame,globeHeading,-1,37);','rowAdd(globeFrame,globeHeading,-1,34);','compact globe heading')
m=once(m,'new LinearLayout.LayoutParams(-1,dp(56))','new LinearLayout.LayoutParams(-1,dp(45))','compact photo row')
m=once(m,'new LinearLayout.LayoutParams(0,dp(48),1);nlp.rightMargin','new LinearLayout.LayoutParams(0,dp(39),1);nlp.rightMargin','news action height')
m=once(m,'new LinearLayout.LayoutParams(0,dp(48),1);elp.leftMargin','new LinearLayout.LayoutParams(0,dp(39),1);elp.leftMargin','NASA action height')
m=once(m,'sourceHeartbeat.setPadding(dp(16),dp(4),dp(8),dp(3));','''sourceHeartbeat.setPadding(dp(12),dp(4),dp(4),dp(3));
        sourceHeartbeat.setSingleLine(true);
        sourceHeartbeat.setEllipsize(android.text.TextUtils.TruncateAt.END);''','compact source receipt text')
m=once(m,'globeFrame.addView(sourceHeartbeat,new LinearLayout.LayoutParams(-1,dp(27)));',
  '''LinearLayout verifiedRailRow=new LinearLayout(this);verifiedRailRow.setGravity(Gravity.CENTER_VERTICAL);
        verifiedRailRow.addView(sourceHeartbeat,new LinearLayout.LayoutParams(0,dp(25),1));
        DuwmSignalRail verifiedLeds=DuwmSignalRail.embedded(this);
        LinearLayout.LayoutParams signalParams=new LinearLayout.LayoutParams(dp(106),dp(24));signalParams.rightMargin=dp(8);
        verifiedRailRow.addView(verifiedLeds,signalParams);
        globeFrame.addView(verifiedRailRow,new LinearLayout.LayoutParams(-1,dp(27)));''','working source lights in a reserved row')
m=once(m,'rowAdd(globeHeading,rotationControl,112,35);','rowAdd(globeHeading,rotationControl,77,32);','smaller rotation control')
m=once(m,'''FrameLayout.LayoutParams originalParams=new FrameLayout.LayoutParams(dp(130),dp(43),Gravity.BOTTOM|Gravity.RIGHT);
        originalParams.rightMargin=dp(14);originalParams.bottomMargin=dp(12);
        earthViewport.addView(originalToggle,originalParams);''',
 '''// Mode control belongs beside the globe title, never over the coastline or markers.
        originalToggle.setText("NATIVE");rowAdd(globeHeading,originalToggle,65,32);''','remove obstructive globe toggle overlay')
m=once(m,'rowAdd(globeHeading,focusControl,68,35);','rowAdd(globeHeading,focusControl,59,32);','compact focus control')
m=once(m,'globeFrame.addView(shareObserved,new LinearLayout.LayoutParams(-1,dp(45)));','globeFrame.addView(shareObserved,new LinearLayout.LayoutParams(-1,dp(39)));','compact share')
m=once(m,'globeFrame.addView(pulseEntry,new LinearLayout.LayoutParams(-1,dp(50)));','globeFrame.addView(pulseEntry,new LinearLayout.LayoutParams(-1,dp(43)));','compact maps entry')
m=once(m,'globeFrame.addView(p3GlobeControls,new LinearLayout.LayoutParams(-1,dp(46)));','globeFrame.addView(p3GlobeControls,new LinearLayout.LayoutParams(-1,dp(39)));','compact observation controls')
m=once(m,'rowAdd(globeFrame,layers,-1,47);','rowAdd(globeFrame,layers,-1,35);','compact layers')
m=once(m,'rowAdd(globeFrame,detail,-1,48);','rowAdd(globeFrame,detail,-1,32);','compact detail text')
m=once(m,'originalToggle.setText("ORIGINAL GLOBE");','originalToggle.setText("NATIVE");','mode toggle available')
m=once(m,'originalToggle.setText("MODERN GLOBE");','originalToggle.setText("MODERN");','mode button compact active')
m=once(m,'''earth.postInvalidateOnAnimation(); // leave modern globe animated''',
 '''// Original detailed native Earth is the starting renderer; modern source globe
        // remains a selectable option and is still updated with observed records.
        switchOriginalRenderer();
        earth.postInvalidateOnAnimation();''','restore original detailed globe as startup default')
m=once(m,'            nativeGlobe.setGlobeMode(true);\n            originalEarth=nativeGlobe;','            nativeGlobe.setGlobeMode(true);\n            // Restore exact-record tapping on the original detailed globe.\n            // Only a source observation already present in this app may be shared.\n            nativeGlobe.setListener(new SatelliteMapView.Listener(){\n                @Override public void onSignalTap(Signal signal){\n                    if(signal==null)return;\n                    for(OperationsGlobeView.Observation observed:earthObservations){\n                        if(observed==null || observed.title==null)continue;\n                        if(observed.title.equals(signal.title) &&\n                           Math.abs(observed.lat-signal.latitude)<0.0001d &&\n                           Math.abs(observed.lon-signal.longitude)<0.0001d){\n                            selectedShareObservation=observed;\n                            inspectObservation(observed,false);\n                            return;\n                        }\n                    }\n                    detail.setText("SOURCE SIGNAL / "+signal.title+" / no matching current observation to share");\n                }\n                @Override public void onViewportChanged(SatelliteMapView.Bounds bounds){}\n            });\n            originalEarth=nativeGlobe;','original native globe real record selection')
mainfile.write_text(m)

# 4) Truthful moving globe telemetry: frame counter and degrees change only after a rendered rotation step.
operationfile=pkg/'OperationsGlobeView.java';g=operationfile.read_text()
g=once(g,'''        if(!dragging && focusPending){''','''        boolean rotatedThisFrame=false;
        if(!dragging && focusPending){''','motion frame gate')
g=once(g,'''            yaw+=dyaw*easing;pitch+=dpitch*easing;''','''            yaw+=dyaw*easing;pitch+=dpitch*easing;
            rotatedThisFrame=true;''','focus frame counter')
g=once(g,'''            yaw=(yaw+dt*.000105d*rotationBlend)%(2*Math.PI);''','''            double advance=dt*.000105d*rotationBlend;
            yaw=(yaw+advance)%(2*Math.PI);
            totalDegrees+=Math.abs(advance)*180d/Math.PI;
            rotatedThisFrame=advance>0d;''','real turn measurement')
g=once(g,'''        float w=getWidth(),h=getHeight();cx=w/2f;''','''        if(rotatedThisFrame)frameCounter++;
        float w=getWidth(),h=getHeight();cx=w/2f;''','count rendered frames')
g=once(g,'if(moving || focusPending)postInvalidateDelayed(33);','if(moving || focusPending)postInvalidateOnAnimation();','smooth scheduling')
operationfile.write_text(g)

# 5) Correct original native globe auto rotation math to the documented speed and keep native rendering.
originalfile=pkg/'SatelliteMapView.java';o=originalfile.read_text()
o=once(o,'centerLon = wrapLongitude(centerLon + elapsed * 0.018d);',
       'centerLon = wrapLongitude(centerLon + elapsed * (360d / (5.5d * 60d * 1000d)));',
       'native globe 5.5-minute revolution matches actual code')
originalfile.write_text(o)

# 6) Map view gets actual source observations but no fabricated data; real tile rendering inside packaged HTML.
mapfile=pkg/'DuwmPlaceMapActivity.java';java=mapfile.read_text()
java=once(java,'root.setPadding(dp(8),dp(3),dp(8),dp(30));setContentView(root);',
 '''root.setPadding(dp(8),dp(3),dp(8),dp(4));setContentView(root);
    root.setFitsSystemWindows(true);
    if(android.os.Build.VERSION.SDK_INT >= 30){
      root.setOnApplyWindowInsetsListener((v,insets)->{
        android.graphics.Insets bars=insets.getInsets(android.view.WindowInsets.Type.statusBars()|android.view.WindowInsets.Type.navigationBars());
        root.setPadding(dp(8),bars.top+dp(3),dp(8),bars.bottom+dp(4));
        return insets;
      });
    }''','map status/navigation bar insets')
java=once(java,'LinearLayout.LayoutParams intelParams=new LinearLayout.LayoutParams(-1,dp(39));',
               'LinearLayout.LayoutParams intelParams=new LinearLayout.LayoutParams(-1,dp(32));','map intelligence button compact')
java=once(java,'root.addView(scroller,new LinearLayout.LayoutParams(-1,dp(45)));',
               'root.addView(scroller,new LinearLayout.LayoutParams(-1,dp(39)));','map mode bar compact')
java=once(java,'modes=strip();scroller.addView(modes,new HorizontalScrollView.LayoutParams(-2,dp(44)));',
               'modes=strip();scroller.addView(modes,new HorizontalScrollView.LayoutParams(-2,dp(37)));','map modes compact')
java=once(java,'root.addView(cityStatus);','''cityStatus.setSingleLine(true);cityStatus.setEllipsize(android.text.TextUtils.TruncateAt.END);
    LinearLayout mapStatusRow=strip();mapStatusRow.addView(cityStatus,new LinearLayout.LayoutParams(0,dp(30),1));
    DuwmSignalRail embeddedSignals=DuwmSignalRail.embedded(this);
    LinearLayout.LayoutParams sigp=new LinearLayout.LayoutParams(dp(106),dp(24));sigp.rightMargin=dp(3);
    mapStatusRow.addView(embeddedSignals,sigp);root.addView(mapStatusRow);''','map signal chips reserved layout row')
java=once(java,'@Override public void onPageFinished(WebView view,String url){webReady=true;applyMode();sendPoints();}',
 '''@Override public void onPageFinished(WebView view,String url){webReady=true;
        js("window.duwmFocus("+centerLat+","+centerLon+",11,"+jsonString(place)+");");
        applyMode();sendPoints();}''','map focus from observation intents')
java=once(java,'web.getSettings().setAllowFileAccess(false);',
 '''web.getSettings().setAllowFileAccess(false);
    web.getSettings().setLoadsImagesAutomatically(true);
    web.getSettings().setBlockNetworkImage(false);''','enable source basemap tiles')
java=once(java,'web.loadDataWithBaseURL("https://tiles.openfreemap.org/",',
               'web.loadDataWithBaseURL("https://tile.openstreetmap.org/",','self-contained tile origin')
java=once(java,'receipt=label("Waiting for real source reports. Streets and place names require an online map provider.",10,MUTED);',
               'receipt=label("Real OpenStreetMap geometry • provider observations only • tiles require internet.",10,MUTED);','truthful map status')
java=once(java,'root.addView(share,new LinearLayout.LayoutParams(-1,dp(35)));',
               'root.addView(share,new LinearLayout.LayoutParams(-1,dp(32)));','compact map share')
mapfile.write_text(java)

# 7) Native package versions and build identity: only change version after real source edits.
gradle=root/'app/build.gradle.kts';grad=gradle.read_text()
assert 'versionCode = 116200' in grad and 'versionName = "1162"' in grad
# We deliberately retain 1165 to avoid a new number without a tested APK.
grad=once(grad,'versionCode = 116200','versionCode = 116500','version identifier for consolidated build')
grad=once(grad,'versionName = "1162"','versionName = "1165-real-source"','explicit source recovery label')
gradle.write_text(grad)
strings=base/'res/values/strings.xml';s=strings.read_text()
assert 'DEVELOP.UGANDA 1162' in s
strings.write_text(s.replace('DEVELOP.UGANDA 1162','DEVELOP.UGANDA 1164',1))
for name,d in old_sha.items():
    assert hashlib.sha256((pkg/name).read_bytes()).hexdigest()==d,('Unintended modification of source component',name)

proof={'modified':['OperationsMainActivity.java','OperationsGlobeView.java','SatelliteMapView.java',
                   'DuwmPlaceMapActivity.java','DuwmSignalRail.java','duwm_place_map.html',
                   'app/build.gradle.kts','strings.xml'],
       'unmodified_source_components':old_sha,
       'map_engine':'self-contained viewport-based OpenStreetMap tile renderer',
       'original_globe':'SatelliteMapView default, 5.5-minute native revolution',
       'facts':'No fake observations, no AIS without provider',
       'source_count':len(list(pkg.glob('*.java')))}
(root/'DUWM_REAL_SOURCE_CHANGE_REPORT.json').write_text(json.dumps(proof,indent=2)+'\n')
print('PASS meaningful modifications:',', '.join(proof['modified']))
