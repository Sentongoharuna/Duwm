#!/usr/bin/env python3
"""Retained source-backed activity and 1707 midnight navy native surfaces."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
main=(j/'MainActivity.java').read_text()
globe=(j/'SatelliteMapView.java').read_text()
rail=(j/'SignalTickerRailView.java').read_text()
xml=(root/'app/src/main/res/values/colors.xml').read_text()
html=(root/'app/src/main/assets/duwm_place_map.html').read_text()
assert '#050D22' in xml and '0D2345' in xml and '#558BDF' in xml
assert 'Color.rgb(5, 13, 34)' in main
assert 'Color.argb(245, 14, 34, 72)' in globe
assert 'Color.argb(195, 67, 111, 184)' in globe
assert 'Color.argb(158, 83, 127, 205)' in globe
assert 'Color.argb(213, 139, 168, 228)' in globe
assert 'Color.argb(245, 6, 18, 42)' in rail
assert '#47D2DB' not in html and '#558BDF' in html
assert 'draw1706SourceActivityHalo(canvas)' in globe
assert 'draw1705SourceLightBeacons(canvas)' in globe
assert 'draw1705ReceivedFixLines(canvas)' in globe
assert 'render1706ReceivedTicker(List<Signal> observations)' in rail
assert 'framePulse' in globe and 'updateAutoRotation()' in globe
assert main.count('new SatelliteMapView(this)')==1
# The native theme must cover actual desks, not just the home header.
native=(j/'DuwmUnifiedTheme.java').read_text()
assert '0xFF050D22' in native and '0xFF558BDF' in native
pages=['AirRadarActivity.java','OperationsMainActivity.java',
 'DuwmPlaceMapActivity.java','Duwm1687WorkspaceActivity.java',
 'ShareCardRenderer.java','MediaDeskActivity.java','Duwm1166NewsDeskActivity.java']
for page in pages:
 assert (j/page).is_file(),page
updated=sum(('0xFF558BDF' in x.read_text() or 'Color.rgb(85, 139, 223)' in x.read_text() or
              'Color.rgb(76, 120, 196)' in x.read_text() or '0xFF0A1C3B' in x.read_text())
            for x in j.glob('*.java'))
assert updated >= 70, 'Midnight blue not applied across app Java pages: '+str(updated)
assert len(list(j.glob('*.java'))) == 240
print('PASS 1707: navy palette across native pages, place-map and widgets; globe, ticker, desks, share cards all retained')
