from pathlib import Path
import json,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
j=(r/'app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java').read_text()
helper=(r/'app/src/main/java/com/sentongoharuna/worldsituationroom/Duwm1683FixTracker.java').read_text()
assert j.count('mapView = new SatelliteMapView(this);')==1, 'original globe duplicated or removed'
assert 'new OperationsGlobeView(' not in j, 'second globe present in launcher'
for token in ('toggleLiveFixWatch()', 'toggleSavedFixTour()', 'savedFixTourTick',
              'liveFixTracker.acceptNew(signal.canonicalId, signal.timestampMs, now)',
              'liveFixTracker.seed(signal.canonicalId, signal.timestampMs)',
              'mapView.highlightSignal(newestReceived)',
              'SAVED FIX TOUR / NOT LIVE', 'WATCH NEW RECEIPTS',
              'onPause()', 'stopSavedFixTour()', 'activityHandler.postDelayed(savedFixTourTick, 7000L)'):
    assert token in j, token
assert 'timestampMs > nowMs + MAX_FUTURE_MS' in helper
assert 'timestampMs < nowMs - MAX_AGE_MS' in helper
assert 'versionCode = 168500' in (r/'app/build.gradle.kts').read_text()
assert 'versionName = "1685"' in (r/'app/build.gradle.kts').read_text()
meta=json.loads((r/'app/src/main/assets/duwm_1683_real_fix_modes.json').read_text())
assert meta['singleOriginalGlobe'] and not meta['syntheticPositions']
manifest=ET.parse(r/'app/src/main/AndroidManifest.xml').getroot()
a='{http://schemas.android.com/apk/res/android}'
launch=[]
for activity in manifest.iter('activity'):
    for intent in activity.findall('intent-filter'):
        action=any(tag.get(a+'name')=='android.intent.action.MAIN' for tag in intent.findall('action'))
        cat=any(tag.get(a+'name')=='android.intent.category.LAUNCHER' for tag in intent.findall('category'))
        if action and cat:launch.append(activity.get(a+'name'))
assert launch==['.MainActivity'],launch
print('PASS 1683: one original globe, real-fix watch, labelled saved tour and actual Android launcher')
