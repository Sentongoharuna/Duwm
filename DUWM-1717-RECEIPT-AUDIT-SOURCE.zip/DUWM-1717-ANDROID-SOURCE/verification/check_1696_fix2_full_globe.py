#!/usr/bin/env python3
"""Protect actual full-size original globe and real side-rail data in 1696 FIX2."""
from pathlib import Path
import hashlib, zipfile
P=Path(__file__).resolve().parent.parent
J=P/'app/src/main/java/com/sentongoharuna/worldsituationroom'
s=(J/'MainActivity.java').read_text()
original=Path('/not-used-in-ci')
checks={
 'only one original globe instance':s.count('new SatelliteMapView(this)')==1,
 'map retains full horizontal viewport':'FrameLayout.LayoutParams globeSpace = fullFrame()' in s and 'globeSpace.setMargins(0, dp(52), 0, dp(102))' in s,
 'no globe shrinking via source panels':'commandDeck.addView(mapView, globeSpace)' in s and 'mapView.setScaleX(' not in s and 'mapView.setScaleY(' not in s,
 'phone rails only 36dp':s.count('dp(36), ViewGroup.LayoutParams.WRAP_CONTENT')==2,
 'tablet adaptation': 'screenWidthDp < 1150' in s,
 'full old cards hidden on phone': 'leftRail.setVisibility(View.GONE)' in s and 'rightRail.setVisibility(View.GONE)' in s,
 'compact air counts are real': 'compactAirCount.setText("AIR\\n" + count(Signal.Layer.FLIGHTS))' in s,
 'compact ship counts are real': 'compactSeaCount.setText("SEA\\n" + count(Signal.Layer.SHIPS))' in s,
 'actual observed fixes in tab': 'compactFixCount.setText("FIX\\n" + globeObservationIndex.size())' in s,
 'source picker reflects genuine records': 'card.getText().toString().replace' in s and 'selectPulseSource(layers.get(selected - 1))' in s,
 'clear mode hides active panels': 'compactGlobeRails ? compactLeftRail : leftRail' in s and 'compactGlobeRails ? compactRightRail : rightRail' in s,
 'source health and globe tools reachable': 'Duwm1671SourceStatusActivity.class' in s and 'globeToolsButton.performClick()' in s,
 '19 existing desks': 'Duwm1683DeskCatalog.ALL' in s and 'open1684Desk(18)' in s,
 'globe formula unchanged': 'Math.min(getWidth() * 0.455f, getHeight() * 0.40f) * globeScale' in (J/'SatelliteMapView.java').read_text(),
 'app identity stays 1696': 'versionCode = 169600' in (P/'app/build.gradle.kts').read_text(),
}
for title,passed in checks.items():
    assert passed,f'FAIL: {title}'
print(f'PASS FIX2: {len(checks)} actual globe-size and side-tab invariants')
print('APK compilation and emulator are separate required release checks')
