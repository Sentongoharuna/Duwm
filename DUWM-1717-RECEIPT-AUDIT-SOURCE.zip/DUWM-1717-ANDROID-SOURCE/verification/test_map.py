"""Browser-level tests of packaged DUWM map HTML. All fixture data is TEST ONLY.
No remote tiles or invented observations are bundled into the Android app.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import time
ROOT = Path(__file__).resolve().parents[1]
MAP = ROOT / 'app/src/main/assets/duwm_place_map.html'
OUT = ROOT / 'verification'

def main():
    assert MAP.is_file()
    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
        page = browser.new_page(viewport={'width':412,'height':820},device_scale_factor=1,is_mobile=True,has_touch=True)
        page.route('https://tile.openstreetmap.org/**',lambda route: route.abort())
        exceptions=[]
        page.on('pageerror',lambda err: exceptions.append(str(err)))
        page.set_content(MAP.read_text(encoding='utf-8'),wait_until='domcontentloaded')
        initial=page.evaluate('window.duwmRenderStatus()')
        assert initial['engine']=='NATIVE_OSM_CANVAS',initial
        assert page.locator('#map').is_visible()
        assert page.locator('#home').is_visible()
        assert page.locator('#retry').is_visible()
        now=int(time.time()*1000)
        records=[
            {'id':'air:1','kind':'AIRCRAFT','title':'TEST ONLY aircraft','detail':'Test altitude','source':'LOCAL TEST ONLY','lat':.34,'lon':32.58,'time':now-30000},
            {'id':'q:1','kind':'EARTHQUAKE','title':'TEST ONLY earthquake','source':'LOCAL TEST ONLY','lat':-.1,'lon':33,'time':now-360000},
            {'id':'stale','kind':'AIRCRAFT','source':'LOCAL TEST ONLY','lat':.2,'lon':32.6,'time':now-3600000},
            {'id':'missing-time','kind':'ISS','source':'LOCAL TEST ONLY','lat':1,'lon':30,'time':0},
            {'id':'invalid-lat','kind':'AIRCRAFT','source':'LOCAL TEST ONLY','lat':95,'lon':30,'time':now},
            {'id':'null-lat','kind':'AIRCRAFT','source':'LOCAL TEST ONLY','lat':None,'lon':30,'time':now},
            {'id':'null-lon','kind':'AIRCRAFT','source':'LOCAL TEST ONLY','lat':.3,'lon':None,'time':now},
            {'id':'null-time','kind':'AIRCRAFT','source':'LOCAL TEST ONLY','lat':.3,'lon':30,'time':None},
        ]
        page.evaluate('(records)=>window.duwmReceive({points:records,traces:[],received:Date.now()})',records)
        assert page.evaluate('window.duwmRenderStatus().recordCount')==2,'Only valid, timely source records may appear'
        page.evaluate('window.duwmMode("AIR")')
        assert page.evaluate('window.duwmRenderStatus().recordCount')==1
        page.evaluate('window.duwmMode("SEA")')
        assert page.evaluate('window.duwmRenderStatus().recordCount')==0
        assert 'AIS feed not configured' in page.locator('#observationSummary').inner_text()
        page.evaluate('window.duwmMode("QUAKE")')
        assert page.evaluate('window.duwmRenderStatus().recordCount')==1
        page.evaluate('window.duwmFocus(1.2,38.8,13,"Nairobi")')
        assert abs(page.evaluate('window.duwmRenderStatus().latitude')-1.2)<1e-6
        page.locator('#zoomIn').click();assert page.evaluate('window.duwmRenderStatus().zoom')==14
        page.locator('#home').click();assert abs(page.evaluate('window.duwmRenderStatus().longitude')-32.5825)<.0001
        page.locator('#style').click();assert page.locator('#style').inner_text()=='LIGHT'
        page.locator('#retry').click();assert page.evaluate('window.duwmRenderStatus().engine')=='NATIVE_OSM_CANVAS'
        page.screenshot(path=str(OUT/'map_offline_browser_test.png'),full_page=True)
        assert not exceptions,exceptions
        print('PASS Map renderer initializes, interactions work, null/stale positions rejected, no false vessel activity.')
        print('Note: external street tiles intentionally blocked in this test; online tile delivery not verified.')
        browser.close()

if __name__=='__main__':main()
