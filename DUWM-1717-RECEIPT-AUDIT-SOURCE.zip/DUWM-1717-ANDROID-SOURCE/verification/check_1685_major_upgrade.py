"""R1685 release gate: evidence of substantial visible upgrades on original native pages.
No assertions claim real device rendering, actual network connectivity, playable TV or a green GitHub build.
"""
from pathlib import Path
import json, re, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
pkg=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
read=lambda name:(pkg/name).read_text()
cat=read('Duwm1683DeskCatalog.java')
main=read('MainActivity.java')
app=read('DuWorldApplication.java')
page=read('Duwm1685PageUpgrade.java')
options=read('DuwmOptionsActivity.java')
fullscreen=read('Duwm1683DeskFullScreenActivity.java')
board=read('Duwm1685MissionBoard.java')
share=read('Duwm1685ShareCard.java')
history=read('Duwm1685ReceiptHistory.java')
chart=read('Duwm1685ReceiptChart.java')
release=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert release['uiRevision']=='1685' and release['uiVersionCode']==168500
assert 'versionCode = 168500' in (root/'app/build.gradle.kts').read_text()
assert 'versionName = "1685"' in (root/'app/build.gradle.kts').read_text()
assert len([line for line in cat.splitlines() if line.lstrip().startswith('d("')])==19
assert 'Duwm1685PageUpgrade.install(this);' in app
assert 'Duwm1684PageUpgrade.install(this);' not in app, 'No stacked/duplicate command headers'
assert 'Duwm1683DeskCatalog.find(a)' in page
assert 'list.addView(panel,0,lp)' in page
assert 'Duwm1684SectorVisual(a,d.title,true)' in page
assert 'overlay.setVisibility(View.GONE)' in page and 'overlay.setVisibility(View.VISIBLE)' in page
assert 'Duwm1685ShareCard.share(a,d)' in page
assert 'Duwm1685ReceiptHistory.capture(a,d)' in page
for mode in ['AVIATION','MARITIME','SEISMIC','WEATHER','SPACE','NEWSROOM','RADIO','TELEVISION',
             'CAMERAS','MARKETS','GEOGRAPHY','SOURCE HEALTH','EVIDENCE']:
    assert '"'+mode+'"' in page
assert 'Duwm1685MissionBoard.create(this)' in options
assert 'Duwm1685ReceiptChart(this,d)' in options
assert 'Duwm1685ShareCard.share(this,d)' in options
assert 'Duwm1685ReceiptChart(this,desk)' in fullscreen
assert 'Duwm1685ShareCard.share(this,desk)' in fullscreen
assert 'createShortcuts(this,desk)' in fullscreen
assert 'int[][] bounds={{0,7},{7,13},{13,19}}' in board
assert 'Duwm1684DeskDiagnostics.read(a,desk)' in board
assert 'recent++' in board and '"RECENT".equals(s.state)' in board
assert 'if(d==null||d.source<0)return' in history
assert 'timestamp=receipt.receivedAt' in history and 'timestamp=r.fetchedAt' in history
assert 'if(p.sourceAt==timestamp)return' in history
assert 'List<Point> entries=read(c,d)' in history
assert 'if(numerical&&pts.size()>1)' in chart
assert 'NO SOURCE SNAPSHOTS RECEIVED' in chart
assert 'W=1080,H=1920' in share
assert 'Duwm1685ReceiptChart history' in share
assert 'R.drawable.develop_uganda_logo' in share
assert 'FLAG_GRANT_READ_URI_PERMISSION' in share
assert 'content://' in share and '.sharecards/' in share
assert 'SHARE SOURCE' in main and 'PROVIDER RECEIPTS' in main
assert main.count('new SatelliteMapView(this)')==1
assert 'setGlobeMode' in main and 'open1684Desk(7)' in main
assert 'new SatelliteMapView(this)' not in page + board + share + options
m=(root/'app/src/main/AndroidManifest.xml').read_text()
assert '<provider android:name=".ShareCardProvider"' in m
assert 'android:name=".MainActivity"' in m
assert 'Duwm1683DeskFullScreenActivity' in m
print('PASS DUWM 1685: 19 native pages, live diagnostic command headers, unique receipt-only charts, mission board, portrait share cards and one original globe')
print('NOT VERIFIED: Android compile/signature, phone layout/playback, live provider reachability')
