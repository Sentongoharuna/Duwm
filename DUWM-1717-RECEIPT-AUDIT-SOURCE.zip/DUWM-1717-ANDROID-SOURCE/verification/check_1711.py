#!/usr/bin/env python3
"""1711 release check: no floating native overlays, 19 sectors, 1710 feature continuity."""
from pathlib import Path
import re, json, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
g=(root/'app/build.gradle.kts').read_text()
assert 'versionCode = 171100' in g and 'versionName = "1711"' in g
assert 'com.sentongoharuna.worldsituationroom.rb2live25' in g
assert 'DUWM 1711' in (root/'app/src/main/res/values/strings.xml').read_text()
ui=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1711' and ui['uiVersionCode']==171100
nav=ui['navigation1711']
assert nav['sectorCount']==19 and nav['nativeDockBelowContent']
assert nav['floatingSourceDetailsRemoved'] and nav['singleOriginalGlobe']
assert nav['background']=='#050D22' and nav['syntheticSignals'] is False
assert (j/'DuwmUnifiedTheme.java').read_text().count('0xFF050D22')>=2
assert len(list(j.glob('*.java')))==243
catalog=(j/'Duwm1683DeskCatalog.java').read_text()
assert catalog.count('        d("')==19
sector=(j/'Duwm1709SectorOutline.java').read_text()
assert len(re.findall(r'0xFF[0-9A-F]{6},?\s*// \d{2}',sector))==19
main=(j/'MainActivity.java').read_text()
assert main.count('new SatelliteMapView(this)')==1
assert 'globeEdgeTab("19 DESKS"' in main
assert 'root.addView(quickActions, quickParams)' in main
for bad in ('commandDeck.addView(leftTabs','commandDeck.addView(rightTabs',
            'commandDeck.addView(missionDock, dockParams)',
            'commandDeck.addView(crawlText, crawlParams)'):
    assert bad not in main, bad
assert 'SignalTickerRailView' in main and 'Duwm1710SourceWaveView' in main
sphere=(j/'SatelliteMapView.java').read_text()
for symbol in ('draw1705ReceivedFixLines(canvas)','draw1705SourceLightBeacons(canvas)',
               'draw1706SourceActivityHalo(canvas)','draw1710EvidenceSignalGlow(canvas)'):
    assert symbol in sphere,symbol
kit=(j/'Duwm1683DeskDetailKit.java').read_text()
assert 'Duwm1711NativeDeskDock.attach(a,desk);' in kit
assert 'root.addView(chip,params)' not in kit, 'Old floating chip would overlap native content'
dock=(j/'Duwm1711NativeDeskDock.java').read_text()
for symbol in ('content.getChildCount()!=1','content.removeView(original)',
               'shell.addView(original,new LinearLayout.LayoutParams',
               'SOURCE DETAILS','19 DESKS','GLOBE','Duwm1683DeskCatalog.status(a,desk)'):
    assert symbol in dock,symbol
full=(j/'Duwm1683DeskFullScreenActivity.java').read_text()
assert 'build1711SectorSwitcher()' in full and 'HorizontalScrollView' in full
assert 'Duwm1709SectorOutline.card(this,i' in full
assert 'getExtra' not in full or 'EXTRA_DESK_INDEX' in full
for p in (root/'app/src/main/res').rglob('*.xml'):
    ET.parse(p)
assert len(list((root/'app/src/main/res').rglob('*.xml')))>=75
print('PASS DUWM 1711: real 19-sector native dock and switcher, uniform navy, no floating source overlay, source-backed globe and 1710 lineage intact')
