#!/usr/bin/env python3
"""1714 release check: real persisted watchlist, protected 1713 compare and original globe."""
import json, re, xml.etree.ElementTree as ET
from pathlib import Path
r=Path(__file__).resolve().parents[1]
j=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
source=(j/'Duwm1712OperationsMatrixActivity.java').read_text()
main=(j/'MainActivity.java').read_text()
ui=json.loads((r/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiVersionCode']==171400 and ui['uiRevision']=='1714'
assert 'versionCode = 171400' in (r/'app/build.gradle.kts').read_text()
assert 'versionName = "1714"' in (r/'app/build.gradle.kts').read_text()
assert 'DUWM 1714' in (r/'app/src/main/res/values/strings.xml').read_text()
f=ui['watchlist1714']
assert f['sectorCount']==19 and f['background']=='#050D22'
assert all(f[k] for k in ('savedLocalPreferences','pinAndUnpinFromSourceCard','confirmClear','preserveRealProviderReceipts','noFloatingGlobeOverlays','retain1713Comparison','retainSingleOriginalGlobe','meaningfulEmptyWatchlist'))
assert f['noSyntheticCounts']
for snippet in ('WATCH_PREFS', 'WATCH_MASK','getSharedPreferences(WATCH_PREFS, MODE_PRIVATE)', 'getInt(WATCH_MASK,0)', 'putInt(WATCH_MASK,pinnedMask)', 'putInt(WATCH_MASK,0)', 'WATCHED','PIN TO WATCHLIST','UNPIN SECTOR','CLEAR PINS','confirmClearWatchlist','watchedCount()','isWatched(index)','filter==4', 'NO WATCHED SECTORS', 'snapshot.report()', 'render1713Comparison', 'Duwm1713ReceiptCoverageView', 'Duwm1684DeskDiagnostics.read(this,desks[i])'):
    assert snippet in source,snippet
assert 'Math.random(' not in source
assert 'new SatelliteMapView(this)' not in source
assert main.count('new SatelliteMapView(this)')==1
assert 'Duwm1712OperationsMatrixActivity' in (r/'app/src/main/AndroidManifest.xml').read_text()
assert (j/'SatelliteMapView.java').read_text().count('draw1706SourceActivityHalo(canvas)')>=1
assert 'SignalTickerRailView' in main
assert len(list(j.glob('*.java'))) >=245
for xml in (r/'app/src/main/res').rglob('*.xml'): ET.parse(xml)
assert (j/'Duwm1709SectorOutline.java').read_text().count('0xFF')>=19
assert '0xFF050D22' in (j/'DuwmUnifiedTheme.java').read_text()
print('PASS DUWM 1714 persisted source-watchlist, real receipts, protected 1713 matrix, original single globe, 19 outlined sectors and navy theme')
