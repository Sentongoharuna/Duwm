#!/usr/bin/env python3
"""1703 source contract: actual source updates and no replacement globe."""
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
m=(j/'MainActivity.java').read_text()
g=(j/'SatelliteMapView.java').read_text()
b=(root/'app/build.gradle.kts').read_text()
ui=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert 'versionCode = 170300' in b and 'versionName = "1703"' in b
assert 'applicationId = "com.sentongoharuna.worldsituationroom.rb2live25"' in b
assert 'DUWM 1703' in (root/'app/src/main/res/values/strings.xml').read_text()
assert ui['uiRevision']=='1703' and ui['uiVersionCode']==170300
assert ui['singleOriginalGlobe'] and ui['launchActivity']=='MainActivity'
assert m.count('new SatelliteMapView(this)')==1
assert 'globeSpace.setMargins(0, dp(52), 0, dp(102))' in m
assert 'Math.min(getWidth() * 0.455f, getHeight() * 0.40f) * globeScale' in g
for token in ['set1702SourceLens(int lens)', 'prioritySignals', 'setGlobePresentationMode(int mode)']:
 assert token in g, token
for token in ['build1703WorldWatchPanel()', 'show1703WorldWatch()', 'collect1703WorldWatch(long now)',
              'open1703WatchSignal(Signal signal)', 'watchAge1703(long stamp, long now)',
              'watchHours1703', 'watchPriorityOnly1703', 'watchPanel1703.setVisibility(View.GONE)',
              'watchTab1703 = globeEdgeTab', 'mapView.highlightSignal(signal)',
              'signal.canonicalId', 'signal.timestampMs', 'signal.source', 'signal.latitude']:
 assert token in m, token
assert 'DUWM 1702' in (root/'1702_RELEASE_NOTES.md').read_text()
assert len(list(j.glob('*.java')))>=239
ns='{http://schemas.android.com/apk/res/android}'
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
la=[]
for a in manifest.findall('application/activity'):
 for i in a.findall('intent-filter'):
  actions={x.get(ns+'name') for x in i.findall('action')}
  cats={x.get(ns+'name') for x in i.findall('category')}
  if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in cats:
   la.append(a.get(ns+'name','').lstrip('.'))
assert la==['MainActivity'],la
assert len((j/'Duwm1683DeskCatalog.java').read_text().split('        d("'))==20
print('PASS 1703: native WORLD WATCH source inbox, original single globe, provider provenance, original 19 desks, release identity')
