#!/usr/bin/env python3
from pathlib import Path
r=Path(__file__).resolve().parents[1]
j=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
s=(j/'GevMarineActivity.java').read_text()
assert s.count('import android.view.View;')==1, 'Missing android.view.View import'
assert all(x in s for x in ['vesselDeck.getVisibility()!=View.VISIBLE','View.VISIBLE:View.GONE','View.GONE?760']), 'Maritime map controls damaged'
assert 'versionCode = 170000' in (r/'app/build.gradle.kts').read_text()
print('PASS 1700 FIX1: Maritime Android View import, original controls and 1700 identity')
