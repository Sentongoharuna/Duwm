#!/usr/bin/env python3
"""DUWM 1702 source verification: real source, original renderer, visible layer lens."""
import json
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
main=(j/'MainActivity.java').read_text()
globe=(j/'SatelliteMapView.java').read_text()
cfg=(root/'app/build.gradle.kts').read_text()
ui=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert 'versionCode = 170200' in cfg and 'versionName = "1702"' in cfg
assert 'applicationId = "com.sentongoharuna.worldsituationroom.rb2live25"' in cfg
assert ui['uiRevision']=='1702' and ui['uiVersionCode']==170200
assert ui['singleOriginalGlobe'] and ui['launchActivity']=='MainActivity'
assert 'DUWM 1702 • DEVELOP.UGANDA' in (root/'app/src/main/res/values/strings.xml').read_text()
assert main.count('new SatelliteMapView(this)')==1
assert 'globeSpace.setMargins(0, dp(52), 0, dp(102))' in main
assert 'Math.min(getWidth() * 0.455f, getHeight() * 0.40f) * globeScale' in globe
assert 'setGlobePresentationMode(int mode)' in globe
assert 'lastDrawnSignalIds.contains(signal.id)' in globe
assert 'filledCells.add(bucket)' in globe and 'lastDrawnSignalIds.add(signal.id)' in globe
for term in ('set1702SourceLens(int lens)', 'visibleIn1702Lens(Signal.Layer layer)',
             'markerPriority1702(Signal value)', 'prioritySignals',
             'List<Signal> displayOrder', 'SOURCE LENS / '):
    assert term in globe, term
for term in ('show1702SourceLensPicker()', 'receivedGeoCount1702(int lens)',
             'update1702LensLabel()', '1702_map_source_lens',
             'sourceLensTab1702 = globeEdgeTab', 'mapView.set1702SourceLens(chosen)'):
    assert term in main, term
assert 'DUWM 1701' in (root/'1701_RELEASE_NOTES.md').read_text()
assert len(list(j.glob('*.java')))==239
ns='{http://schemas.android.com/apk/res/android}'
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
launches=[]
for activity in manifest.findall('application/activity'):
    for filt in activity.findall('intent-filter'):
        actions={x.get(ns+'name') for x in filt.findall('action')}
        cats={x.get(ns+'name') for x in filt.findall('category')}
        if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in cats:
            launches.append(activity.get(ns+'name','').lstrip('.'))
assert launches==['MainActivity'], launches
assert len((j/'Duwm1683DeskCatalog.java').read_text().split('        d("'))==20
print('PASS 1702: actual Android Java lens features, priority rendering, original one globe, all 19 desks, release identity.')
