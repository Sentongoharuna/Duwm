from pathlib import Path
import json,xml.etree.ElementTree as ET,re
root=Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java').read_text()
assert s.count('mapView = new SatelliteMapView(this);')==1
assert 'new OperationsGlobeView(' not in s
for k in ('private void updateGlobeObservationIndex(List<Signal> visibleSignals)',
          'private void navigateGlobeObservation(int direction)',
          'private void openSelectedGlobeObservation()',
          'private void updateGlobeObservationReadout()',
          'mapView.highlightSignal(signal)',
          'mapView.setCenter(signal.latitude, signal.longitude, 4.0d)',
          'globeObservationIndex.sort',
          'signal.timestampMs > 0L', 'signal.timestampMs <= now + 300_000L',
          'updateGlobeObservationIndex(mapSignals);',
          'Button nextFix = compactButton("NEXT FIX ▶")',
          'Button previousFix = compactButton("◀ FIX")',
          'Button showFix = compactButton("FIX DETAIL")',
          'if (!globeObservationIndex.isEmpty()) navigateGlobeObservation(1);'):
    assert k in s,k
assert 'versionCode = 168200' in (root/'app/build.gradle.kts').read_text()
assert 'versionName = "1682"' in (root/'app/build.gradle.kts').read_text()
metadata=json.loads((root/'app/src/main/assets/duwm_1682_observation_navigator.json').read_text())
assert metadata['singleOriginalGlobe'] and not metadata['interpolation']
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot();android='{http://schemas.android.com/apk/res/android}'
launch=[a.get(android+'name') for a in manifest.iter('activity') for f in a.findall('intent-filter') if any(e.get(android+'name')=='android.intent.action.MAIN' for e in f.findall('action')) and any(e.get(android+'name')=='android.intent.category.LAUNCHER' for e in f.findall('category'))]
assert launch==['.MainActivity'],launch
print('PASS DUWM 1682 original globe source record inspection / 1 launcher / valid observed timestamp')
