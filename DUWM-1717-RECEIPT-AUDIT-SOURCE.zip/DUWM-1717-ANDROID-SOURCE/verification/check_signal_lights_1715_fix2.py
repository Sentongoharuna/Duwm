#!/usr/bin/env python3
"""Verify fixed 1715 signal-light implementation, real receipt semantics and original globe."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]
j=p/'app/src/main/java/com/sentongoharuna/worldsituationroom'
get=lambda s:(j/s).read_text()
light=get('Duwm1715SignalLights.java')
main=get('MainActivity.java')
app=get('DuWorldApplication.java')
assert 'class Duwm1715SignalLights' in light
assert 'Duwm1684DeskDiagnostics.read(context,desk)' in light
assert 'Duwm1683DeskCatalog.ALL.length' in light
assert 'new LinearLayout.LayoutParams(-1,dp(activity,34))' in light
assert 'shell.addView(original,new LinearLayout.LayoutParams(-1,0,1f))' in light
assert 'fromFeed(FeedStatus s)' in light
assert 'if(genuinelyNew>0' in light
assert 'RECEIPT_PULSE_MS' in light
assert 'REFRESH_MS' in light
assert 'sourceUpdate(' in light
assert 'new SatelliteMapView(this)' in main and main.count('new SatelliteMapView(this)')==1
assert 'Duwm1715SignalLights.attach(this)' in main
assert 'Duwm1715SignalLights.attach(a)' in app
assert 'operational.newAcquisitions.size()' in main
assert 'Duwm1715SignalLights.sectorLamp' in get('Duwm1711NativeDeskDock.java')
assert get('Duwm1712OperationsMatrixActivity.java').count('Duwm1715SignalLights.sectorLamp')>=2
assert 'DUWM 1715' in (p/'app/src/main/res/values/strings.xml').read_text()
assert 'versionCode = 171500' in (p/'app/build.gradle.kts').read_text()
assert '0xFF041424' in get('DuwmUnifiedTheme.java')
assert len(list(j.glob('*.java')))>=247
assert len(__import__('re').findall(r'Duwm1709SectorOutline.color\(i\)',light))==1
print('PASS: 1715 FIX2 19 source-aware signal lights, original unobstructed globe, app-wide formal navy, actual receipt pulses only')
