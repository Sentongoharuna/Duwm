#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
m=(j/'MainActivity.java').read_text()
g=(j/'SatelliteMapView.java').read_text()
t=(j/'SignalTickerRailView.java').read_text()
assert m.count('new SatelliteMapView(this)')==1
assert 'globeSpace.setMargins(0, dp(52), 0, dp(102))' in m
assert '1705_full_command_look_initialised' in m
assert 'putInt("1701_globe_presentation", 0)' in m
assert 'putInt("1702_map_source_lens", 0)' in m
assert 'upperTicker1705 = new SignalTickerRailView' in m
assert 'crawlText = new SignalTickerRailView' in m
assert 'crawlText.setSignals(signals)' in m
for code in ['draw1705ReceivedFixLines(canvas)','draw1705SourceLightBeacons(canvas)',
             'observedTracks.get(signal.id)', 'activityStatuses.get(layer)',
             'latest.timestampMs', 'if (!globeMode || replayMode']:
 assert code in g,code
for code in ['onDraw(Canvas canvas)', 'setSignals(List<Signal> observations)',
             'postInvalidateOnAnimation()', 's.timestampMs', 's.source', 's.title']:
 assert code in t,code
for code in ['show1703WorldWatch()', 'filter1704WorldWatch(List<Signal> source)',
             'show1704Receipt(Signal signal)', 'render1705Pulse(List<Signal> allReceived)']:
 assert code in m,code
assert (root/'app/build.gradle.kts').read_text().count('versionCode = 170500')==1
print('PASS 1705 RESTORE: real-data animated tickers, genuine observed tracks, source status lights, single original globe, 1704 newsroom and 1705 filters')
