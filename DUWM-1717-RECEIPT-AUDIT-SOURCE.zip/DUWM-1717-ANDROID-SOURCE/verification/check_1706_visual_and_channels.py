#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
m=(j/'MainActivity.java').read_text()
g=(j/'SatelliteMapView.java').read_text()
t=(j/'SignalTickerRailView.java').read_text()
assert m.count('new SatelliteMapView(this)')==1
assert 'globeSpace.setMargins(0, dp(52), 0, dp(102))' in m
assert '1705_full_command_look_initialised' in m
assert 'putInt("1701_globe_presentation", 0)' in m
assert 'putInt("1702_map_source_lens", 0)' in m
assert 'upperTicker1705 = new SignalTickerRailView' in m
assert 'crawlText = new SignalTickerRailView' in m
assert 'crawlText.setSignals(signals)' in m
for code in ['draw1705ReceivedFixLines(canvas)','draw1705SourceLightBeacons(canvas)',
             'observedTracks.get(signal.id)', 'activityStatuses.get(layer)',
             'latest.timestampMs', 'if (!globeMode || replayMode']:
 assert code in g,code
for code in ['onDraw(Canvas canvas)', 'setSignals(List<Signal> observations)',
             'postInvalidateOnAnimation()', 's.timestampMs', 's.source', 's.title']:
 assert code in t,code
for code in ['show1703WorldWatch()', 'filter1704WorldWatch(List<Signal> source)',
             'show1704Receipt(Signal signal)', 'render1705Pulse(List<Signal> allReceived)']:
 assert code in m,code
assert (root/'app/build.gradle.kts').read_text().count('versionCode = 170600')==1
print('PASS 1705 RESTORE: real-data animated tickers, genuine observed tracks, source status lights, single original globe, 1704 newsroom and 1705 filters')

# 1706: genuine interactive channels on restored rails, no new globe or source cache.
assert 'show1706SignalConsole()' in m
assert 'show1706TickerSpeed()' in m
assert 'tickerChannel1706' in m and 'tickerSpeed1706' in m
assert 'crawlText.set1706Channel(tickerChannel1706)' in m
assert 'upperTicker1705.set1706Speed(tickerSpeed1706)' in m
assert 'draw1706SourceActivityHalo(canvas)' in g
assert 'activityStatuses.get(layer)' in g
assert 'activityReceivedAt.get(layer)' in g
assert 'status.count <= 0' in g
assert 'set1706Channel(Signal.Layer channel)' in t
assert 'set1706Speed(int dpPerSecond)' in t
assert 'render1706ReceivedTicker(List<Signal> observations)' in t
assert 'channel1706 != null && channel1706 != s.layer' in t
assert 'versionCode = 170600' in (root/'app/build.gradle.kts').read_text()
assert 'DUWM 1706' in (root/'app/src/main/res/values/strings.xml').read_text()
print('PASS 1706: real-data selectable ticker channels, persistent speeds and source-activity globe halo')
