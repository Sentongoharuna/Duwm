from pathlib import Path
import xml.etree.ElementTree as ET, re, json
ROOT=Path(__file__).resolve().parents[1]
java=ROOT/'app/src/main/java/com/sentongoharuna/worldsituationroom'
m=ET.parse(ROOT/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
launchers=[]
for a in m.iter('activity'):
    actions={n.get(ns+'name') for f in a.findall('intent-filter') for n in f.findall('action')}
    categories={n.get(ns+'name') for f in a.findall('intent-filter') for n in f.findall('category')}
    if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in categories:
        launchers.append(a.get(ns+'name'))
assert launchers==['.MainActivity'],launchers
main=(java/'MainActivity.java').read_text()
assert main.count('mapView = new SatelliteMapView(this);')==1
assert 'new OperationsGlobeView(' not in main
assert 'new Duwm1677MissionControlActivity(' not in main
assert 'headerButton("DESKS")' in main
assert 'addMissionAction(row, "OPTIONS"' in main
options=(java/'DuwmOptionsActivity.java').read_text()
assert 'class DuwmOptionsActivity extends Activity' in options
assert not re.search(r'new\s+(?:OperationsGlobeView|SatelliteMapView|LiveEarthGlobeView)\s*\(',options)
for token in ('Duwm1670FlightMapActivity.class','GevMarineActivity.class','Duwm1166NewsDeskActivity.class',
              'MediaDeskActivity.class','Duwm1671SectorActivity.class','Duwm1676GeoWatchActivity.class',
              'Duwm1675EvidenceVaultActivity.class','Duwm1671SourceStatusActivity.class','Duwm1669SourceDirectoryActivity.class'):
    assert token in options,token
ui=json.loads((ROOT/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['launchActivity']=='MainActivity' and ui['singleOriginalGlobe'] is True
config=(ROOT/'app/build.gradle.kts').read_text()
assert 'versionCode = 167802' in config and 'versionName = "1678"' in config
print('PASS: one original SatelliteMapView home globe, later desks are separate options; build code 167801')
