from pathlib import Path
from zipfile import ZipFile
import re, xml.etree.ElementTree as ET
root=Path('app/src/main')
java=root/'java/com/sentongoharuna/worldsituationroom'
assert 'versionCode = 167500' in Path('app/build.gradle.kts').read_text()
assert 'versionName = "1675"' in Path('app/build.gradle.kts').read_text()
manifest=ET.parse(root/'AndroidManifest.xml')
ns={'a':'http://schemas.android.com/apk/res/android'}
assert any(x.get('{http://schemas.android.com/apk/res/android}name')=='.Duwm1675EvidenceVaultActivity' for x in manifest.findall('.//activity'))
assert any(x.get('{http://schemas.android.com/apk/res/android}name')=='.Duwm1675CommandDeckActivity' for x in manifest.findall('.//activity'))
for name in ('Duwm1675EvidenceStore.java','Duwm1675EvidenceMath.java','Duwm1675EvidenceVaultActivity.java'):
    assert (java/name).exists(),name
store=(java/'Duwm1675EvidenceStore.java').read_text()
activity=(java/'Duwm1675EvidenceVaultActivity.java').read_text()
deck=(java/'Duwm1674CommandDeckActivity.java').read_text()
assert 'Duwm1674UnifiedReceipts.aircraft' in store and 'Duwm1674UnifiedReceipts.maritime' in store and 'Duwm1674UnifiedReceipts.news' in store
assert 'MAX_CAPTURES=60' in store
assert 'Duwm1675EvidenceStore.capture' in activity
assert 'Intent.ACTION_CREATE_DOCUMENT' in activity and 'Duwm1671Share.share' in activity
assert 'Duwm1675EvidenceVaultActivity.class' in deck and '1675 EVIDENCE VAULT' in deck
assert 'extends Duwm1674CommandDeckActivity' in (java/'Duwm1675CommandDeckActivity.java').read_text()
assert 'EVIDENCE VAULT  •' in deck
assert 'OCEAN_COLOR=Color.rgb' in (java/'OperationsGlobeView.java').read_text()
print('PASS 1675 evidence vault manifests, navigation, real receipt inputs, CSV export and prior compiler repair')
