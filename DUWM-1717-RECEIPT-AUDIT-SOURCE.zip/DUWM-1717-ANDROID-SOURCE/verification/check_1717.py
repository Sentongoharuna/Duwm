#!/usr/bin/env python3
"""1717 source-only release gate. Android build/sign/runtime needs actual CI APK."""
from pathlib import Path
import xml.etree.ElementTree as ET
import json,hashlib
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
audit=(j/'Duwm1717ReceiptAuditActivity.java').read_text()
centre=(j/'Duwm1716SignalCenterActivity.java').read_text()
main=(j/'MainActivity.java').read_text()
rail=(j/'Duwm1715SignalLights.java').read_text()
theme=(j/'DuwmUnifiedTheme.java').read_text()
config=(root/'app/build.gradle.kts').read_text()
assets=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert 'versionCode = 171700' in config and 'versionName = "1717"' in config
assert 'DUWM 1717 • DEVELOP.UGANDA' in (root/'app/src/main/res/values/strings.xml').read_text()
assert assets['uiRevision']=='1717' and assets['uiVersionCode']==171700
flags=assets['receiptAudit1717']
for key in ('storedLocally','onDemandComparisonOnly','heatmapFromSavedCaptures',
            'ignoresRelativeAgeStringWhenComparing','noSyntheticFeeds','noAdditionalGlobe',
            'oneOriginalGlobePreserved','shareLocalAudit','clearHistoryConfirmation'):
    assert flags[key],key
assert flags['exactNavy']=='#041424' and flags['silverControlOutlines']=='#DEE5EF'
assert flags['sectors']==19 and flags['maxExplicitCaptures']==12
assert '0xFF041424' in theme and '0xFFDEE5EF' in theme
assert main.count('new SatelliteMapView(this)')==1 and 'SignalTickerRailView' in main
assert 'class Duwm1717ReceiptAuditActivity extends Activity' in audit
assert 'Duwm1684DeskDiagnostics.read(this,sectors[index])' in audit
assert 'MAX_CAPTURES=12' in audit
assert 'stableReceived' in audit and 'receipt.indexOf(" · ")' in audit
assert 'if(!baseline&&next.optInt("observedDifferences")==0)' in audit
assert 'getSharedPreferences(PREFS,MODE_PRIVATE)' in audit
assert '.setPositiveButton("CLEAR LOCAL HISTORY"' in audit and 'ACTION_SEND' in audit
assert 'Duwm1715SignalLights.indicatorColor' in audit
assert 'lamp.setOnClickListener(v->details(sectorIndex,captureIndex))' in audit
assert 'startActivity(Duwm1683DeskCatalog.intent(this,sectors[index]))' in audit
assert 'Duwm1717ReceiptAuditActivity.class' in centre and 'AUDIT HISTORY / 1717' in centre
assert 'REREAD' in centre and 'OPEN DESK' in centre and 'SOURCE DETAILS' in centre
assert 'Duwm1715SignalLights.attach(a)' in (j/'DuWorldApplication.java').read_text()
assert 'slot.setOnClickListener(v->openSignalCentre(context,selectedSector))' in rail
assert 'Math.random' not in audit and 'new SatelliteMapView' not in audit
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
a='{http://schemas.android.com/apk/res/android}'
entries=[e.attrib.get(a+'name') for e in manifest.iter('activity')]
assert '.Duwm1717ReceiptAuditActivity' in entries
assert '.Duwm1716SignalCenterActivity' in entries
assert len(list(j.glob('*.java'))) >=249
for f in (root/'app/src/main/res').rglob('*.xml'):ET.parse(f)
assert '#041424' in (root/'1717_RELEASE_NOTES.md').read_text()
print('PASS: 1717 real 19-sector receipt audit, stable-change comparison, saved on-device timeline, one original globe and exact approved colour scheme')
print('NOT VERIFIED HERE: Android APK compilation, signing, installation, actual streaming, emulator launch')
