"""DUWM 1692: exact 1691 source lineage and evidence-only functional regression guards.
Not a substitute for Android APK compilation or on-phone verification.
"""
from pathlib import Path
import hashlib, json, re, xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
j=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
a=json.loads((r/'SOURCE_LINEAGE_1692.json').read_text())
assert a['release']=='1692' and a['basedOn']=='1691'
assert a['parentZipSHA256']=='1b97e4e2b62b52bd4fc63304428bc09dc33273e6ed8d545167193dd49e2b5285', 'Incorrect 1691 parent archive'
assert len(a['changedExistingJava'])>=12, 'Insufficient changes for a new version'
for f,sha in a['oldJavaSHA256'].items():
 assert hashlib.sha256((j/f).read_bytes()).hexdigest()!=sha,'Unchanged native 1691 file '+f
for f,sha in a['protectedSHA256'].items():
 assert hashlib.sha256((j/f).read_bytes()).hexdigest()==sha,'Protected original engine changed '+f
must={
 'MainActivity.java':['1692 / ALL 19 DESKS','1692 SHARE CARD'],
 'AircraftOperationsActivity.java':['AIRBORNE ONLY','CONTACT ≤ 5 MIN','MATCHING '],
 'GevMarineActivity.java':['OPTIONAL PORT RADAR','regionSpinnerReady','publicSelectionGeneration'],
 'Duwm1166NewsDeskActivity.java':['PUBLISHER:','publisherFilter'],
 'Duwm1166RadioAtlasActivity.java':['MAP: FIT MATCHING STATIONS','updateBounds','stationLimit+=36'],
 'MediaDeskActivity.java':['FOCUS PLAYER','SHOW SOURCE LIST','recordsScroll.setVisibility'],
 'Duwm1671SourceStatusActivity.java':['SHARE CURRENT SOURCE DIAGNOSTICS','sourceQuery','lastReport'],
 'Duwm1671SectorActivity.java':['MAP DATA WINDOW','extendedGeoWindow'],
 'Duwm1687WorkspaceActivity.java':['LATEST VERIFIED RECEIPT CHANGE','SHARE TEXT RECEIPT','Duwm1685ReceiptHistory.read'],
 'Duwm1687MissionBoard.java':['CLEAR FILTERS','last_category']}
for f,need in must.items():
 content=(j/f).read_text()
 for snippet in need:assert snippet in content, f'{f} lacks operational feature: {snippet}'
main=(j/'MainActivity.java').read_text()
assert main.count('mapView = new SatelliteMapView(this);')==1,'Multiple globe instances found'
assert sum(x.lstrip().startswith('d("') for x in (j/'Duwm1683DeskCatalog.java').read_text().splitlines())==19,'Not 19 original desks'
for marker in ('"AIRWX"','"WIRE"','"BRIEF"','"RISK"','"AIRPORTS"','"PORTS"','"CALLS"'):
 assert 'addMissionAction(row, '+marker not in main,'Duplicate home dock shortcut '+marker
for f in ['Duwm1670FlightMapActivity.java','GevMarineActivity.java','Duwm1166NewsDeskActivity.java','Duwm1166RadioAtlasActivity.java','MediaDeskActivity.java','Duwm1671SourceStatusActivity.java']:
 assert 'Duwm1690EvidenceBars' in (j/f).read_text(), 'Inherited real source chart missing '+f
w=(j/'Duwm1687WorkspaceActivity.java').read_text()
assert 'Duwm1685ReceiptHistory.Point' in w and 'last.numerical&&previous.numerical' in w
assert '1692 / '+ '"+desk.title' in w,'Wrong desk version'
gradle=(r/'app/build.gradle.kts').read_text()
assert 'versionCode = 169200' in gradle and 'versionName = "1692"' in gradle
assert 'applicationId = "com.sentongoharuna.worldsituationroom.rb2live25"' in gradle
assert '<string name="app_name">DUWM 1692 • DEVELOP.UGANDA</string>' in (r/'app/src/main/res/values/strings.xml').read_text()
ui=json.loads((r/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1692' and ui['uiVersionCode']==169200 and ui['singleOriginalGlobe'] is True
root=ET.parse(r/'app/src/main/AndroidManifest.xml').getroot();tag='{http://schemas.android.com/apk/res/android}'
assert any(x.attrib.get(tag+'name')=='.MainActivity' for x in root.iter('activity'))
print('PASS: 1692 exact prior archive lineage; %d modified original Java files'%len(a['changedExistingJava']))
print('PASS: source-backed operational features on six native desks, specialist map and all 19 workspaces')
print('PASS: original globe preserved, duplicated home shortcuts removed, app label/version 1692')
print('NOT VERIFIED HERE: Android bytecode compilation, installed APK, live streams or physical-device UI')
