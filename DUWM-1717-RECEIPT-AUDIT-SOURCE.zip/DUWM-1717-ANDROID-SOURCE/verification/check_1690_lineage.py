"""DUWM 1690 actual-source upgrade gates, no synthetic APK-success claims."""
from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
r=json.loads((root/'SOURCE_LINEAGE_1690.json').read_text())
assert r['release']=='1690' and r['baseRelease']=='1689'
assert r['baseSourceZipSHA256']=='0844211028159f64b79a8752886e1de61377f3c1253efb6c8a3fe8259f1f0721'
assert len(r['changedExistingNativePages'])>=9
for name in r['changedExistingNativePages']:
    assert hashlib.sha256((j/name).read_bytes()).hexdigest()!=r['priorJavaSHA256'][name],f'Unchanged native page: {name}'
for name,old in r['protectedOriginalRendererAndPlayerSHAs'].items():
    assert hashlib.sha256((j/name).read_bytes()).hexdigest()==old, f'Original globe/media engine altered: {name}'
main=(j/'MainActivity.java').read_text()
assert main.count('mapView = new SatelliteMapView(this);')==1
assert 'new SatelliteMapView(this);' in main
assert hashlib.sha256(main.replace('1690','1689').encode()).hexdigest()==r['priorJavaSHA256']['MainActivity.java'], 'Original main launcher altered beyond identity'
assert (j/'Duwm1690EvidenceBars.java').is_file()
catalog=(j/'Duwm1683DeskCatalog.java').read_text()
assert sum(line.lstrip().startswith('d("') for line in catalog.splitlines())==19
code=(root/'app/build.gradle.kts').read_text();labels=(root/'app/src/main/res/values/strings.xml').read_text()
assert 'versionCode = 169000' in code and 'versionName = "1690"' in code
assert 'applicationId = "com.sentongoharuna.worldsituationroom.rb2live25"' in code
assert '<string name="app_name">DUWM 1690 • DEVELOP.UGANDA</string>' in labels
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
a='{http://schemas.android.com/apk/res/android}'
assert any(el.attrib.get(a+'name')=='.MainActivity' for el in manifest.iter('activity'))
assert 'DUWM 1690 Operations' in (root/'app/src/main/AndroidManifest.xml').read_text()
m=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert m['uiRevision']=='1690' and m['uiVersionCode']==169000 and m['singleOriginalGlobe'] is True
checks={
'Duwm1670FlightMapActivity.java':('highAltitudeOnly','flightEvidence.setValues','altitude','inRegion(activeRegion,lat,lon)'),
'GevMarineActivity.java':('marineEvidence.setValues','cargo','tankers','passengers','visibleShip(ship,now)'),
'Duwm1166NewsDeskActivity.java':('dayOnly','now-n.publishedAt<=86400000L','newsEvidence.setValues','toggleSaved'),
'Duwm1166RadioAtlasActivity.java':('radioEvidence.setValues','stationVisible(station)','saveStation'),
'MediaDeskActivity.java':('secureSourcesOnly','mediaEvidence.setValues','records.addView(mediaEvidence','stopPlayback'),
'Duwm1671SourceStatusActivity.java':('healthEvidence.setValues','RunningballV25Sources.read','issuesOnly'),
'Duwm1671SectorActivity.java':('mapSizeControl','mapLayout.height=dp(expandedMap?780:530)','map.setPins(points,newlyArrived)'),
'Duwm1687WorkspaceActivity.java':('receiptOverview();','Duwm1690EvidenceBars','Duwm1685ReceiptHistory.read(this,desk)'),
'Duwm1687MissionBoard.java':('needsAttention','"NEEDS"','groups[n].equals(category[0])'),
}
for name,markers in checks.items():
    t=(j/name).read_text()
    for marker in markers:assert marker in t, f'{name} lacks {marker}'
assert not any('1689' in (j/name).read_text() for name in checks), 'Stale 1689 on active changed pages'
print('PASS 1690: nine existing native/shared page files have substantial changes vs SHA-pinned 1689')
print('PASS 1690: one original globe, native media engine and unchanged applicationId')
print('PASS 1690: 19 registered desks, six source-dependent metric panels, meaningful filters, 1690 launcher identity')
print('APK compile, installation, visual testing, live data and codec support NOT verified by this script.')
