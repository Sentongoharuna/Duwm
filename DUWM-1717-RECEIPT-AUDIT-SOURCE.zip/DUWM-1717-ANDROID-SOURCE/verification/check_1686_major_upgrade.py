"""Release-specific SOURCE checks for substantial 1686 UI changes. Build and device verification remain separate."""
from pathlib import Path
import json, xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
pkg=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
read=lambda name:(pkg/name).read_text()
config=(r/'app/build.gradle.kts').read_text()
release=json.loads((r/'app/src/main/assets/duwm_release_ui.json').read_text())
assert 'versionCode = 168600' in config and 'versionName = "1686"' in config
assert release['uiRevision']=='1686' and release['uiVersionCode']==168600
cat=read('Duwm1683DeskCatalog.java')
assert sum(x.lstrip().startswith('d("') for x in cat.splitlines())==19
app=read('DuWorldApplication.java')
assert 'Duwm1685PageUpgrade.install(this);' in app and 'Duwm1684PageUpgrade.install(this);' not in app
page=read('Duwm1685PageUpgrade.java')
assert 'Duwm1686Console.page(a,d)' in page and 'Duwm1686Console.compact(a,d)' in page
assert 'list.addView(panel,0,lp)' in page and 'overlay.setVisibility(View.GONE)' in page
assert 'Duwm1686WorkspaceActivity.open(a,d)' in page
workspace=read('Duwm1686WorkspaceActivity.java')
assert all('"'+x+'"' in workspace for x in ('OVERVIEW','OBSERVATIONS','HISTORY','SOURCES','ACTIONS'))
assert 'Duwm1685ReceiptHistory.read(this,desk)' in workspace
assert 'Duwm1684DeskDiagnostics.read(this,desk)' in workspace
assert 'startActivity(Duwm1683DeskCatalog.intent(this,desk))' in workspace
assert 'handler.removeCallbacks(tick)' in workspace and 'onPause()' in workspace
assert 'Duwm1686ShareCard.share(this,desk)' in workspace
assert 'move(-1)' in workspace and 'move(1)' in workspace
console=read('Duwm1686Console.java')
assert 'Duwm1684SectorVisual' in console and 'Duwm1686WorkspaceActivity.open' in console
assert 'Duwm1686ShareCard.share' in console
board=read('Duwm1686CommandBoard.java')
assert 'for(Duwm1683DeskCatalog.Desk desk:Duwm1683DeskCatalog.ALL)' in board
assert 'SHOW ALL 19 WORKSPACES' in board and 'LIVE VIEW' in board and 'DETAILS' in board
assert 'Duwm1684DeskDiagnostics.read(a,desk)' in board
options=read('DuwmOptionsActivity.java')
assert 'Duwm1686CommandBoard.create(this)' in options and '1686' in options
assert 'Duwm1686ShareCard.share(this,d)' in options
main=read('MainActivity.java')
assert main.count('mapView = new SatelliteMapView(this);')==1
assert '1686 / ALL 19 DESKS' in main and '1686 SHARE CARD' in main
assert 'Duwm1686ShareCard.share(this,Duwm1683DeskCatalog.ALL[index])' in main
assert 'new SatelliteMapView(this)' not in workspace + console + board
share=read('Duwm1686ShareCard.java')
assert 'W=1080,H=1920' in share and 'Duwm1685ReceiptChart' in share
assert 'R.drawable.develop_uganda_logo' in share
assert 'FLAG_GRANT_READ_URI_PERMISSION' in share and '.sharecards/' in share
assert 'SCHEMATIC SECTOR ART' in share
assert 'Duwm1686ShareCard.share(this,desk)' in read('Duwm1683DeskFullScreenActivity.java')
manifest=ET.parse(r/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
activities={a.get(ns+'name','') for a in manifest.iter('activity')}
assert '.Duwm1686WorkspaceActivity' in activities
assert '.MainActivity' in activities
assert '.Duwm1683DeskFullScreenActivity' in activities
assert 'ShareCardProvider' in (r/'app/src/main/AndroidManifest.xml').read_text()
assert 'NO SYNTHETIC' in console
print('PASS 1686 SOURCE: 19 upgraded native pages, 5-tab detailed workspaces, 19 desk directory, state-aware panels, redesigned portrait share cards, one globe')
print('LIMITATION: Source checks do not prove Android compile, installability, physical screen appearance, playable streams or live provider data.')
