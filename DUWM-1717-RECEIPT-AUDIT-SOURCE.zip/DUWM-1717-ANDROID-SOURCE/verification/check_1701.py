#!/usr/bin/env python3
"""DUWM 1701 real-source correctness gate; not a substitute for APK boot testing."""
import json
from pathlib import Path
import xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
j=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
main=(j/'MainActivity.java').read_text()
mapv=(j/'SatelliteMapView.java').read_text()
gradle=(r/'app/build.gradle.kts').read_text()
ui=json.loads((r/'app/src/main/assets/duwm_release_ui.json').read_text())
assert 'versionCode = 170100' in gradle
assert 'versionName = "1701"' in gradle
assert ui['uiRevision']=='1701' and ui['uiVersionCode']==170100
assert ui['singleOriginalGlobe'] and ui['launchActivity']=='MainActivity'
assert 'DUWM 1701 • DEVELOP.UGANDA' in (r/'app/src/main/res/values/strings.xml').read_text()
assert main.count('new SatelliteMapView(this)')==1
assert 'globeSpace.setMargins(0, dp(52), 0, dp(102))' in main
assert 'Math.min(getWidth() * 0.455f, getHeight() * 0.40f) * globeScale' in mapv
assert 'setGlobePresentationMode(int mode)' in mapv
assert 'lastDrawnSignalIds.contains(signal.id)' in mapv
assert 'filledCells.add(bucket)' in mapv and 'lastDrawnSignalIds.add(signal.id)' in mapv
assert 'private void show1701GlobeViewPicker()' in main
assert 'private void show1701GlobeActions(View globeToolsButton)' in main
assert all(v in main for v in ['CLARITY','INCIDENTS','ALL MARKERS','1701_globe_presentation'])
assert 'mapView.setSignals(mapSignals);' in main
assert len(list(j.glob('*.java')))==239
root=ET.parse(r/'app/src/main/AndroidManifest.xml').getroot(); ns='{http://schemas.android.com/apk/res/android}'
launch=[]
for activity in root.findall('application/activity'):
 for filt in activity.findall('intent-filter'):
  acts={x.get(ns+'name') for x in filt.findall('action')}
  cats={x.get(ns+'name') for x in filt.findall('category')}
  if 'android.intent.action.MAIN' in acts and 'android.intent.category.LAUNCHER' in cats:
   launch.append(activity.get(ns+'name','').lstrip('.'))
assert launch==['MainActivity'],launch
assert len((j/'Duwm1683DeskCatalog.java').read_text().split('        d("'))==20
print('PASS 1701: source and identity, all 19 desks, user-selectable real map decluttering, single ORIGINAL globe.')
