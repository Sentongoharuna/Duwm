from pathlib import Path
import re, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
pkg=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
catalog=(pkg/'Duwm1683DeskCatalog.java').read_text()
kit=(pkg/'Duwm1683DeskDetailKit.java').read_text()
opts=(pkg/'DuwmOptionsActivity.java').read_text()
app=(pkg/'DuWorldApplication.java').read_text()
flight=(pkg/'Duwm1670FlightMapActivity.java').read_text()
worldmap=(pkg/'Duwm1670WorldMapView.java').read_text()
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
registered={a.get(ns+'name','') for a in manifest.iter('activity')}
assert catalog.count('        d("')==19,(catalog.count('        d("'), 'Expected 19 real desks')
assert 'Duwm1683DeskDetailKit.install(this)' in app
for c in ('Duwm1670FlightMapActivity', 'GevMarineActivity','Duwm1671SectorActivity',
  'GevSatelliteActivity','Duwm1676GeoWatchActivity','DuwmPlaceMapActivity',
  'Duwm1166NewsDeskActivity','Duwm1670NewsAtlasActivity','Duwm1166RadioAtlasActivity',
  'MediaDeskActivity','RunningballV107EpicActivity','Duwm1671SourceStatusActivity',
  'Duwm1675EvidenceVaultActivity','Duwm1669SourceDirectoryActivity','Duwm1668GeopoliticalLensActivity',
  'LocalMonitorActivity'):
    assert c+'.class' in catalog,c
    assert '.'+c in registered or 'com.sentongoharuna.worldsituationroom.'+c in registered,c
for token in ('onActivityResumed','attach(a)','Duwm1683DeskFullScreenActivity.class','Duwm1683DeskFullScreenActivity.class',
              'EXTRA_DESK_INDEX','a.startActivity(intent)'):
    assert token in kit,token
for token in ('SEARCH DESKS, SOURCES OR INFORMATION','sectionFilter','DETAILS',
              'Duwm1683DeskDetailKit.show(this,d)','Duwm1683DeskCatalog.status(this,d)'):
    assert token in opts,token
for token in ('NEXT AIRCRAFT','FIT WORLD','SOURCE FIX','ICAO24 /','GROUNDSPEED',
              'ALTITUDE','TWO REAL FIXES','compass(double heading)','MainActivity.class'):
    assert token in flight,token
assert 'OperationsMainActivity.class' not in flight
assert 'aircraftIcon' in worldmap and 'pin.heading' in worldmap
assert 'versionCode = 168500' in (root/'app/build.gradle.kts').read_text()
assert 'versionName = "1685"' in (root/'app/build.gradle.kts').read_text()
main=(pkg/'MainActivity.java').read_text()
assert main.count('mapView = new SatelliteMapView(this);')==1
print('PASS 1683: 19 real option destinations, actual source drawer on each, searchable hub, enhanced aircraft telemetry and one original home globe')

assert '.Duwm1683DeskFullScreenActivity' in registered
assert 'Duwm1683FullScreen.install(this)' in app
full=(pkg/'Duwm1683FullScreen.java').read_text()
assert 'FLAG_FULLSCREEN' in full and 'MainActivity' in full
assert 'Duwm1683DeskCatalog.find(a)!=null' in full
assert 'dialog.show()' not in kit
assert 'Duwm1683DeskFullScreenActivity.class' in kit
assert 'FLAG_FULLSCREEN' in (pkg/'Duwm1683DeskFullScreenActivity.java').read_text()
