#!/usr/bin/env python3
"""1715: the new release is a verified UI/code change, not a build number only."""
import json, xml.etree.ElementTree as ET
from pathlib import Path
r=Path(__file__).resolve().parents[1]
j=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
get=lambda f:(j/f).read_text()
ui=json.loads((r/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1715' and ui['uiVersionCode']==171500
assert 'versionCode = 171500' in (r/'app/build.gradle.kts').read_text()
assert 'versionName = "1715"' in (r/'app/build.gradle.kts').read_text()
assert 'DUWM 1715' in (r/'app/src/main/res/values/strings.xml').read_text()
assert '<item name="android:fontFamily">sans</item>' in (r/'app/src/main/res/values/styles.xml').read_text()
assert len(list(j.glob('*.java')))>=245
assert 'new SatelliteMapView(this)' in get('MainActivity.java')
assert get('MainActivity.java').count('new SatelliteMapView(this)')==1
assert 'SignalTickerRailView' in get('MainActivity.java')
assert 'Duwm1715FormalUi.apply(a)' in get('DuWorldApplication.java')
formal=get('Duwm1715FormalUi.java')
for token in ('normalizeText(', 'window.setStatusBarColor(', 'window.setNavigationBarColor(', 'sans-serif-medium','ViewGroup'):
    assert token in formal,token
sector=get('Duwm1709SectorOutline.java')
assert 'int surface = fill == DuwmUnifiedTheme.PANEL_SELECTED' in sector
assert 'FORMAL_CORNER_DP' in sector
assert len(ui['formalUi1715'])>=12
assert all(ui['formalUi1715'].values())
assert 'dp(a,84)' in get('Duwm1711NativeDeskDock.java')
assert 'DUWM 1715  /  SECTOR' in get('Duwm1711NativeDeskDock.java')
assert 'Duwm1684SectorVisual thumbnail=' not in get('DuwmOptionsActivity.java')
assert 'Duwm1685ReceiptChart' in get('DuwmOptionsActivity.java')
assert 'WATCH_PREFS' in get('Duwm1712OperationsMatrixActivity.java')
assert 'Duwm1713ReceiptCoverageView' in get('Duwm1712OperationsMatrixActivity.java')
assert 'Duwm1684DeskDiagnostics.read(' in get('Duwm1712OperationsMatrixActivity.java')
assert len(__import__('re').findall('0xFF',get('Duwm1709SectorOutline.java')))>=19
for xml in (r/'app/src/main/res').rglob('*.xml'): ET.parse(xml)
assert len(ui.get('watchlist1714',{}))>5
print('PASS 1715: formal UI on every native Activity, original globe, 19 real desks, receipts, watchlist, no fake telemetry')
