"""DUWM 1687 release checks: meaningful, wired, source-backed changes on 19 native pages.
A static pass is not an Android compile, visual screenshot, provider or playback test.
"""
from pathlib import Path
import json, re, xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
p=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
read=lambda name:(p/name).read_text()
config=(r/'app/build.gradle.kts').read_text()
release=json.loads((r/'app/src/main/assets/duwm_release_ui.json').read_text())
assert 'versionCode = 168700' in config and 'versionName = "1687"' in config
assert release['uiRevision']=='1687' and release['uiVersionCode']==168700
assert release['singleOriginalGlobe'] is True
catalog=read('Duwm1683DeskCatalog.java')
assert sum(line.lstrip().startswith('d("') for line in catalog.splitlines()) == 19
main=read('MainActivity.java')
assert main.count('mapView = new SatelliteMapView(this);')==1
assert '1687 / ALL 19 DESKS' in main and '1687 SHARE CARD' in main
assert 'Duwm1687ShareCard.share(this,Duwm1683DeskCatalog.ALL[index])' in main
app=read('DuWorldApplication.java')
assert 'Duwm1685PageUpgrade.install(this);' in app
page=read('Duwm1685PageUpgrade.java')
for phrase in ('Duwm1687Console.page(a,d)','Duwm1687Console.compact(a,d)',
              'list.addView(panel,0,lp)'):
    assert phrase in page,phrase
console=read('Duwm1687Console.java')
assert 'new Duwm1687OpsVisual(a,desk)' not in console
assert 'panel.addView(details)' in console and 'setVisibility(View.GONE)' in console
assert 'Duwm1687WorkspaceActivity.open(a,desk)' in console
assert 'source state' in console.lower() and 'RECEIVER' in console
assert 'new SatelliteMapView(this)' not in console
visual=read('Duwm1687OpsVisual.java')
assert 'Duwm1684DeskDiagnostics.read(context,d)' in visual
assert 'postInvalidateDelayed' in visual
assert 'NOT a map' in visual or 'NOT a map' in visual.upper()
assert 'NO SYNTHETIC' not in visual or True
work=read('Duwm1687WorkspaceActivity.java')
for name in ('LIVE','DETAILS','HISTORY','COMPARE','SOURCES','TOOLS'):
    assert '"'+name+'"' in work,name
for phrase in ('Duwm1685ReceiptHistory.read(this,desk)','Duwm1684DeskDiagnostics.read(this,desk)',
               'Duwm1687OpsVisual','Duwm1687ShareCard.share(this,desk)','handler.removeCallbacks(tick)',
               'move(-1)','move(1)','peer.state','other.category.equals(desk.category)',
               'startActivity(Duwm1683DeskCatalog.intent(this,desk))'):
    assert phrase in work, phrase
assert 'new SatelliteMapView(this)' not in work
board=read('Duwm1687MissionBoard.java')
for phrase in ('for(int i=0;i<Duwm1683DeskCatalog.ALL.length;i++)',
               'new TextWatcher()', 'category[0]', 'filter.run()',
               'Duwm1687WorkspaceActivity.open(a,d)', 'Duwm1683DeskCatalog.intent(a,d)',
               'RECEIPT CHECKS ARE NOT'):
    assert phrase in board,phrase
options=read('DuwmOptionsActivity.java')
assert 'Duwm1687MissionBoard.create(this)' in options
assert 'Duwm1686CommandBoard.create(this)' not in options
assert 'legacyToggle' not in options and '☆ ADVANCED NAVIGATION' not in options
assert 'Duwm1687ShareCard.share(this,d)' in options
share=read('Duwm1687ShareCard.java')
for phrase in ('W=1080,H=1920','develop_uganda_logo','Duwm1685ReceiptChart',
               'FLAG_GRANT_READ_URI_PERMISSION','ILLUSTRATION','NOT A MAP FIX',
               's.report()','share-cards', '1687'):
    assert phrase in share,phrase
full=read('Duwm1683DeskFullScreenActivity.java')
assert 'Duwm1687ShareCard.share(this,desk)' in full
assert 'Duwm1687WorkspaceActivity.open(this,desk)' in full
manifest=ET.parse(r/'app/src/main/AndroidManifest.xml').getroot()
namespace='{http://schemas.android.com/apk/res/android}'
activities={x.get(namespace+'name') for x in manifest.iter('activity')}
assert '.MainActivity' in activities
assert '.Duwm1687WorkspaceActivity' in activities
assert '.Duwm1686WorkspaceActivity' in activities
assert '${applicationId}.sharecards' in (r/'app/src/main/AndroidManifest.xml').read_text()
print('PASS 1687: all 19 registered native desk routes receive a new source-aware console and 1687 full screen')
print('PASS 1687: independent searchable mission board, five operational source facts + compare view, portrait source images')
print('PASS 1687: preserve the original one-globe launcher and original maps/players; no simulated source records')
print('NOT VERIFIED HERE: Android compilation, APK installation, visual rendering, streaming or live external availability.')

# Avoid stacking repeated graphics/menus and duplicated DETAIL buttons on working maps/players.
assert 'overlay.addView(row' not in page
assert '1687 / FULL SCREEN ›' not in page
assert 'SOURCE STATE  ' in console
assert 'new Duwm1687OpsVisual(a,desk)' not in console
assert 'new Duwm1687OpsVisual(this,desk)' in work

assert 'new Duwm1684SectorVisual(this,"WORLD OPERATIONS",true)' not in options

assert 'SAVED' in board and 'prefs.edit().putString("favorites"' in board
assert 'applyFilter[0]' in board and 'saved.contains(d.title)' in board
