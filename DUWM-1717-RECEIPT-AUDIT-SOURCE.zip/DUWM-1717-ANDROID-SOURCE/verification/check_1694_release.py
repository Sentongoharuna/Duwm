from pathlib import Path
import json,re
P=Path(__file__).resolve().parent.parent
J=P/'app/src/main/java/com/sentongoharuna/worldsituationroom'
assert 'versionCode = 169400' in (P/'app/build.gradle.kts').read_text()
assert 'versionName = "1694"' in (P/'app/build.gradle.kts').read_text()
assert 'DUWM 1694 • DEVELOP.UGANDA' in (P/'app/src/main/res/values/strings.xml').read_text()
u=json.loads((P/'app/src/main/assets/duwm_release_ui.json').read_text())
assert u['uiRevision']=='1694' and u['uiVersionCode']==169400 and u['singleOriginalGlobe'] is True
for f,s in {
  'GevMarineActivity.java':'GevMarineActivity.this::fetchPublic',
  'Duwm1670FlightMapActivity.java':'fastOnly',
  'Duwm1166NewsDeskActivity.java':'sixHourOnly',
  'Duwm1166RadioAtlasActivity.java':'alphabeticalStations',
  'Duwm1690EvidenceBars.java':'setOnLongClickListener',
  'Duwm1687WorkspaceActivity.java':'sourceStatus.setOnClickListener',
  'Duwm1693Chrome.java':'DUWM 1694 / SOURCE NAVIGATION'
}.items():assert s in (J/f).read_text(),(f,s)
assert 'fastShipsOnly' in (J/'GevMarineActivity.java').read_text()
assert (J/'MainActivity.java').exists() and (J/'SatelliteMapView.java').exists()
assert sum(1 for _ in J.glob('*.java'))>=230
print('PASS: actual 1694 source, unchanged single-globe implementation, native page upgrades and identity')
