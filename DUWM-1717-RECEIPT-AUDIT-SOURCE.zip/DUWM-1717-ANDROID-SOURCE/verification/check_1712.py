#!/usr/bin/env python3
"""1712 real source check: 19-sector operations matrix, uniform native controls and original globe."""
from pathlib import Path
import json, re, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
manifest=root/'app/src/main/AndroidManifest.xml'
code=(root/'app/build.gradle.kts').read_text()
assert ('versionCode = 171200' in code and 'versionName = "1712"' in code) or ('versionCode = 171300' in code and 'versionName = "1713"' in code)
assert any(('DUWM '+v) in (root/'app/src/main/res/values/strings.xml').read_text() for v in ('1712','1713'))
settings=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert (settings['uiRevision'],settings['uiVersionCode']) in (('1712',171200),('1713',171300))
m=settings['operations1712']
assert m['background']=='#050D22' and m['sectors']==19
assert not m['falseZeroCount'] and m['nativeDockEntry'] and m['worldWatchEntry']
assert m['noFloatingGlobePanels']
assert 'Duwm1712OperationsMatrixActivity' in manifest.read_text()
ET.parse(manifest)
assert len(list((root/'app/src/main/res').rglob('*.xml'))) >= 75
for xml in (root/'app/src/main/res').rglob('*.xml'): ET.parse(xml)
main=(j/'MainActivity.java').read_text()
assert main.count('new SatelliteMapView(this)')==1
assert 'globeEdgeTab("OPS\\n19"' in main
assert 'compactButton("OPS 19")' in main
assert 'root.addView(quickActions, quickParams)' in main
for floating in ('commandDeck.addView(leftTabs','commandDeck.addView(rightTabs','commandDeck.addView(crawlText, crawlParams)'):
    assert floating not in main
for retained in ('show1703WorldWatch','Duwm1710SourceWaveView','SignalTickerRailView','sync1710ClearGlobeStage'):
    assert retained in main
native=(j/'Duwm1711NativeDeskDock.java').read_text()
assert 'controls.addView(matrix,opsParams);' in native
assert 'SOURCE' in native and '19 DESKS' in native and 'GLOBE' in native
assert 'Duwm1712OperationsMatrixActivity' in native
assert 'content.removeView(original)' in native
matrix=(j/'Duwm1712OperationsMatrixActivity.java').read_text()
for feature in ('FILTERS={"ALL 19","NEEDS REVIEW","RECENT RECEIPTS","LOCAL TOOLS"}',
                'Duwm1684DeskDiagnostics.read(this,desks[i])','Duwm1683DeskCatalog.ALL',
                'Duwm1709SectorOutline.card(this,index','new Intent(this,MainActivity.class)',
                'SOURCE RECEIPT','source', '19 SECTORS', 'OPEN DESK'):
    assert feature in matrix,feature
assert 'Math.random(' not in matrix and 'demo' not in matrix.lower()
assert 'setContentView(root);' in matrix
assert 'render();' in matrix
assert 'DuwmUnifiedTheme.APPROVED_NAVY' in matrix
assert len(list(j.glob('*.java'))) >= 244
assert (j/'SatelliteMapView.java').read_text().count('draw1706SourceActivityHalo(canvas)')>=1
assert (j/'Duwm1709SectorOutline.java').read_text().count('0xFF')>=19
print('PASS DUWM 1712: 19 real-receipt operations sectors, navy full-screen matrix, fixed non-overlapping controls, original single animated globe and intact 1710/1711 functions')
