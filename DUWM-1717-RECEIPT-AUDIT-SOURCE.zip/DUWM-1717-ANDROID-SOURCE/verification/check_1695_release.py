#!/usr/bin/env python3
from pathlib import Path
import json, hashlib
P=Path(__file__).resolve().parent.parent
J=P/'app/src/main/java/com/sentongoharuna/worldsituationroom'
identity=(P/'app/build.gradle.kts').read_text()
assert 'versionCode = 169500' in identity and 'versionName = "1695"' in identity
assert 'DUWM 1695 • DEVELOP.UGANDA' in (P/'app/src/main/res/values/strings.xml').read_text()
ui=json.loads((P/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1695' and ui['uiVersionCode']==169500 and ui['singleOriginalGlobe'] is True
lineage=json.loads((P/'1695_SOURCE_LINEAGE.json').read_text())
assert lineage['parent_sha256']=='f12045364daf8d8aad3ce24701303cff5cafe79f38a80866b2382fe18e04e669'
assert hashlib.sha256((J/'SatelliteMapView.java').read_bytes()).hexdigest()==lineage['unchanged_globe_sha256']
assert len(lineage['actual_changed_java_files'])>=10
for f,token in {
'Duwm1670FlightMapActivity.java':'ORDER AIRCRAFT: HIGHEST REPORTED SPEED',
'GevMarineActivity.java':'SORT VESSEL REGISTER: FASTEST REPORTED SPEED',
'Duwm1166NewsDeskActivity.java':'FILTER RECEIVED NEWS PUBLISHER',
'Duwm1166RadioAtlasActivity.java':'playNextReceivedStation()',
'MediaDeskActivity.java':'playNextMediaSource()',
'Duwm1671SourceStatusActivity.java':'PROVIDER AUDIT',
'Duwm1687WorkspaceActivity.java':'RECEIPT / SOURCE TIME',
'Duwm1690EvidenceBars.java':'int[] rank={0,1,2,3}',
'Duwm1693Chrome.java':'DUWM 1695 / SOURCE NAVIGATION',
'GevMarineActivity.java':'vesselOrder=(vesselOrder+1)%3'
}.items():
    assert token in (J/f).read_text(),(f,token)
assert (J/'MainActivity.java').is_file() and (J/'Duwm1683DeskCatalog.java').is_file()
assert len(list(J.glob('*.java')))>=239
print('PASS: 1695 source identity, changed native code, one protected original globe and known 1694 lineage')
