#!/usr/bin/env python3
"""Release 1674: enforce visible upgrade and source-linked controls, not earlier UI hashes."""
from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET,re
from release_contract import assert_release_at_least
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
assets=root/'app/src/main/assets'
assert_release_at_least(root,1674)
assert 'versionCode = 167401' in (root/'app/build.gradle.kts').read_text()
xml=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
activities=list(xml.iter('activity'))
launch=[]
for a in activities:
    for f in a.findall('intent-filter'):
        actions={x.get(ns+'name') for x in f.findall('action')}
        cats={x.get(ns+'name') for x in f.findall('category')}
        if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in cats:launch.append(a.get(ns+'name'))
assert launch==['.Duwm1674CommandDeckActivity'],launch
command=(j/'Duwm1674CommandDeckActivity.java').read_text()
assert 'public final class Duwm1674CommandDeckActivity' in command
for needle in ['Duwm1674UnifiedReceipts.aircraft(this)','Duwm1674UnifiedReceipts.maritime(this)',
 'Duwm1674MaritimeRefresh.refresh(this','new OperationsGlobeView(this)','new Duwm1674SignalBoardView(this)',
 'LIVE WORLD INTELLIGENCE','CHANGE GLOBE','AFRICA','EUROPE','ASIA','AMERICAS',
 'showLayer(OperationsGlobeView.AIR','showLayer(OperationsGlobeView.SEA','showLayer(OperationsGlobeView.QUAKE','showLayer(OperationsGlobeView.SPACE',
 'Duwm1670FlightMapActivity.class','GevMarineActivity.class','Duwm1670NewsAtlasActivity.class',
 'MediaDeskActivity.class','"PUBLIC CAMERAS"','"TV STATIONS"','"RADIO"',
 'RunningballV25GlobalAircraftData.refresh','Duwm1671Share.share(this','V115941ShareCards.share(this',
 'RunningballV25Sources.read(this','DuwmGeoObservationStore.read(this)']:
 assert needle in command,needle
assert 'Math.random(' not in command and 'Thread.sleep(' not in command
signal=(j/'Duwm1674SignalBoardView.java').read_text()
for needle in ['RunningballV25Sources.read(getContext(),i)','r.fetchedAt',
 'r.status==RunningballV25Sources.Status.LIVE','setContentDescription','LIVE SOURCE SIGNALS  /  8 CHANNELS']:
 assert needle in signal,needle
assert 'Math.random(' not in signal
assert (j/'Duwm1674TimeGuard.java').is_file()
assert 'Duwm1674UnifiedReceipts.news(this)' in command
assert 'Duwm1674MaritimeRefresh.refresh' in command
assert 'REFRESH REAL NEWS SOURCES' in (j/'Duwm1670NewsAtlasActivity.java').read_text()
assert 'OSLOFJORD / NORWAY' in (j/'GevMarineActivity.java').read_text()
sphere=(j/'OperationsGlobeView.java').read_text()
for needle in ['naturalearth_coasts.txt','setRotationSpeed(float speed)','setCompassRingEnabled(boolean visible)',
 'getObservationCount()','n<96','strokePath(canvas,coastline)','postInvalidateOnAnimation()']:
 assert needle in sphere,needle
ui=json.loads((assets/'duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1674'
assert ui['launchActivity']=='Duwm1674CommandDeckActivity'
assert ui['newGlobeSHA256']==hashlib.sha256(sphere.encode()).hexdigest()
assert ui['newGlobeSHA256']!=ui['previousGlobeSHA256'],'Globe unchanged from 1673'
for name in ('naturalearth_coasts.txt','duwm_country_borders_wdbii.txt','duwm_news_200_region_sources.json','duwm_global_200_sources.json'):
 assert (assets/name).stat().st_size>10000,name
assert len(json.loads((assets/'duwm_news_200_region_sources.json').read_text())['sources'])==200
assert len(json.loads((assets/'duwm_global_200_sources.json').read_text())['sources'])==200
for f in ('Duwm1670FlightMapActivity','Duwm1670NewsAtlasActivity','Duwm1671SectorActivity','GevMarineActivity',
 'MediaDeskActivity','NativeMediaActivity','Duwm1671SourceStatusActivity','Duwm1671Share'):
 assert (j/(f+'.java')).is_file(),f
media=(j/'MediaDeskActivity.java').read_text()
marine=(j/'GevMarineActivity.java').read_text()
for t in ('VideoView(this)','MediaPlayer','NativeMediaActivity.class','shareSourceCard(it,img)','PUBLIC CAMERAS'):
 assert t in media,t
for t in ('radar.setRecords(plots)','private void share(Ship s)','fetchPublic()'):
 assert t in marine,t
assert 'DUWM 1674' in (root/'app/src/main/res/values/strings.xml').read_text()
print('PASS 1674.1 source: new launcher, visibly altered globe, real-source signal board, media routes, app version and source preservation')
print('WARNING source verification is not an APK compilation or live device test')
