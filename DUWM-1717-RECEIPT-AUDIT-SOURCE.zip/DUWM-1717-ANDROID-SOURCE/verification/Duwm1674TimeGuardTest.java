package com.sentongoharuna.worldsituationroom;

public final class Duwm1674TimeGuardTest {
    public static void main(String[] args) {
        long now = System.currentTimeMillis();
        if(Duwm1674TimeGuard.normalize(631152000L)!=0L) throw new AssertionError("1990 UNIX seconds must not look live");
        if(Duwm1674TimeGuard.normalize(631152000000L)!=0L) throw new AssertionError("1990 UNIX milliseconds must not look live");
        if(Duwm1674TimeGuard.normalize(now/1000L)<=0L) throw new AssertionError("Contemporary UNIX seconds rejected");
        if(!Duwm1674TimeGuard.recent(now,60000L)) throw new AssertionError("Fresh observation rejected");
        if(Duwm1674TimeGuard.recent(631152000L,21600000L)) throw new AssertionError("Historical observation accepted");
        if(!Duwm1674TimeGuard.utc(now).contains(String.valueOf(java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC")).get(java.util.Calendar.YEAR))))
            throw new AssertionError("Actual UTC year not displayed");
        System.out.println("PASS 1674 time guard: 1990 never live, real source year retained");
    }
}
