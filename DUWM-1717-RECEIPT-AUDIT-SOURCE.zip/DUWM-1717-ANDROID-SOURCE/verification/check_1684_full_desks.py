from pathlib import Path
root=Path(__file__).resolve().parents[1]
pkg=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
opt=(pkg/'DuwmOptionsActivity.java').read_text()
full=(pkg/'Duwm1683DeskFullScreenActivity.java').read_text()
cat=(pkg/'Duwm1683DeskCatalog.java').read_text()
real=(pkg/'Duwm1684DeskDiagnostics.java').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
app=(root/'app/build.gradle.kts').read_text()
assert 'versionCode = 168500' in app and 'versionName = "1685"' in app
assert 'Duwm1684DeskDiagnostics.shortStatus' in cat
assert 'Duwm1684DeskDiagnostics.fullStatus' in cat
assert 'Duwm1674UnifiedReceipts.aircraft' in real and 'Duwm1674UnifiedReceipts.maritime' in real and 'Duwm1674UnifiedReceipts.news' in real
assert 'RunningballV25Sources.read' in real and 'NO RECEIPT' in real
assert 'last_error' not in real or 'error' in real
assert 'private void refreshSource()' in full
assert 'Duwm1674MaritimeRefresh.refresh' in full and 'RunningballV25NewsRepository.refresh' in full
assert 'PREVIOUS DESK' in full and 'NEXT DESK' in full
assert 'getSharedPreferences("duwm1684_desk_nav"' in opt and 'SAVED DESKS' in opt
assert 'OPEN NATIVE DESK' in opt and 'Duwm1683DeskDetailKit.show(this,d)' in opt
assert 'new Intent(this,DuwmOptionsActivity.class)' in full
assert '.Duwm1683DeskFullScreenActivity' in manifest
assert 'android:name=".MainActivity"' in manifest
assert 'SatelliteMapView' in (pkg/'MainActivity.java').read_text()
assert len([l for l in cat.splitlines() if l.lstrip().startswith('d("')])==19
print('PASS DUWM 1684: provider details, active requests, full-screen navigation and 19 saved desk choices; one original globe')
