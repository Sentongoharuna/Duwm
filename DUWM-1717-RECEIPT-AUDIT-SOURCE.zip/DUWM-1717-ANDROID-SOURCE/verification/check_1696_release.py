#!/usr/bin/env python3
from pathlib import Path
from hashlib import sha256
import json,re,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent.parent
J=P/'app/src/main/java/com/sentongoharuna/worldsituationroom'
lineage=json.loads((P/'1696_SOURCE_LINEAGE.json').read_text())
assert lineage['release']==1696 and lineage['parent_archive']=='DUWM-1695-NATIVE-VERIFIED-SOURCE.zip'
assert lineage['parent_sha256']=='8c0d0fa1fbeb71b65a361b0132c231d9c8565e089035b96f04d7456c13caebae'
assert sha256((J/'SatelliteMapView.java').read_bytes()).hexdigest()==lineage['protected_original_globe_sha256']
for name,original in lineage['parent_java_sha256'].items():
    assert sha256((J/name).read_bytes()).hexdigest()!=original,('Unchanged previous source',name)
required={
 'Duwm1670FlightMapActivity.java':['filterDeck.setVisibility','CLEAR ALL FILTERS','liveMapParams.height'],
 'GevMarineActivity.java':['vesselDeck.setVisibility','AIS MAP FOCUS','seaWorldMap.setLayoutParams'],
 'Duwm1166NewsDeskActivity.java':['sixHourOnly=false;imageOnly=false','SOURCE TIME: LAST 6 HOURS'],
 'Duwm1166RadioAtlasActivity.java':['regionButtons.get(i)','selected radio region'],
 'MediaDeskActivity.java':['applyPlayerSize()','focusPlayer?540'],
 'Duwm1671SourceStatusActivity.java':['if((!issuesOnly||!ok)&&queryMatch){','lastReport.append'],
 'Duwm1687WorkspaceActivity.java':['peerLink.setOnClickListener','TextView item('],
}
for file,words in required.items():
    text=(J/file).read_text()
    for value in words: assert value in text,(file,value)
assert len(list(J.glob('*.java')))>=239
assert len(list(J.glob('SatelliteMapView.java')))==1
build=(P/'app/build.gradle.kts').read_text()
assert 'versionCode = 169600' in build and 'versionName = "1696"' in build
assert '<string name="app_name">DUWM 1696 • DEVELOP.UGANDA</string>' in (P/'app/src/main/res/values/strings.xml').read_text()
ui=json.loads((P/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1696' and ui['uiVersionCode']==169600 and ui['singleOriginalGlobe']
assert len(ui['improvements'])>=7
assert all('1695' not in file.read_text() for file in J.glob('*.java'))
root=ET.parse(P/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
launch=[]
for activity in root.findall('application/activity'):
    for tag in activity.findall('intent-filter'):
        actions={x.get(ns+'name') for x in tag.findall('action')}
        cats={x.get(ns+'name') for x in tag.findall('category')}
        if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in cats:
            launch.append(activity.get(ns+'name','').lstrip('.'))
assert launch==['MainActivity'],launch
print('PASS DUWM 1696: correct label/version, 7 native functional page changes, protected single globe, 19-desk workspace')
