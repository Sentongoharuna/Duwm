#!/usr/bin/env python3
"""Check approved #050D22 dominates source-rendered screens, not a mock-up."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
java=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
main=(java/'MainActivity.java').read_text()
colors=(root/'app/src/main/res/values/colors.xml').read_text()
styles=(root/'app/src/main/res/values/styles.xml').read_text()
html=(root/'app/src/main/assets/duwm_place_map.html').read_text()
theme=(java/'DuwmUnifiedTheme.java').read_text()
assert '#050D22' in colors and '#050D22' in html
assert '0xFF050D22' in theme and 'APPROVED_NAVY = 0xFF050D22' in theme
assert 'android:windowBackground">@color/command_background' in styles
assert 'android:statusBarColor">@color/command_background' in styles
assert '--bg:#050D22' in html and 'tile.openstreetmap.org' in html
assert 'Color.rgb(5, 13, 34)' in main and 'Color.rgb(8, 22, 46)' in main
assert 'new SatelliteMapView(this)' in main
assert 'DuwmUnifiedTheme.APPROVED_NAVY' in (java/'SatelliteMapView.java').read_text()
assert 'DuwmUnifiedTheme.BACKGROUND' in (java/'SignalTickerRailView.java').read_text()
assert '#0A1C3B' not in html and '0xFF0A1C3B' not in ''.join(p.read_text() for p in java.glob('*.java'))
assert '#0A1C3B' not in ''.join(p.read_text() for p in (root/'app/src/main/res').rglob('*.xml'))
assert (root/'1707_RELEASE_NOTES.md').is_file() and (root/'1708_RELEASE_NOTES.md').is_file()
changed=__import__('json').loads((root/'1708_CHANGED_FILES.json').read_text())
assert len([x for x in changed if x.endswith('.java')])>=55
assert len([x for x in changed if x.endswith('.xml')])>=5
# Accents remain for source-backed active status, and warning/danger are distinct.
for n in ('ACCENT = 0xFF558BDF','LIVE = 0xFF67CBA6','WARNING = 0xFFDBAC64','DANGER = 0xFFDF777B'):
    assert n in theme,n
for p in ('Duwm1166NewsDeskActivity.java', 'MediaDeskActivity.java', 'AirRadarActivity.java',
          'Duwm1687WorkspaceActivity.java','ShareCardRenderer.java'):
    assert (java/p).is_file(),p
print('PASS DUWM 1708 approved midnight-navy UI: all major native surfaces, share cards, tickers, widgets and map, protected lights remain')
