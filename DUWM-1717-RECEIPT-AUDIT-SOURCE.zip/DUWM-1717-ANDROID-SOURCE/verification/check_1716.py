#!/usr/bin/env python3
"""1716 release gate: source based factual signals, original command globe, full-screen centre.
This is not an Android binary runtime test or live-provider network assertion.
"""
from pathlib import Path
import json, re, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
read=lambda f:(j/f).read_text()
main=read('MainActivity.java')
new=read('Duwm1716SignalCenterActivity.java')
rail=read('Duwm1715SignalLights.java')
dock=read('Duwm1711NativeDeskDock.java')
config=(root/'app/build.gradle.kts').read_text()
ui=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ('versionCode = 171600' in config and 'versionName = "1716"' in config) or ('versionCode = 171700' in config and 'versionName = "1717"' in config)
assert ('DUWM 1716' in (root/'app/src/main/res/values/strings.xml').read_text() or 'DUWM 1717' in (root/'app/src/main/res/values/strings.xml').read_text())
assert (ui['uiRevision']=='1716' and ui['uiVersionCode']==171600) or (ui['uiRevision']=='1717' and ui['uiVersionCode']==171700)
flags=ui['signalCenter1716']
assert flags['nineteenRealSectorCards'] and flags['noDuplicateGlobe'] and flags['noSyntheticLiveUpdates']
assert flags['exactNavy']=='#041424' and flags['silverOutlines']=='#DEE5EF'
assert main.count('new SatelliteMapView(this)')==1
assert 'SignalTickerRailView' in main
assert 'class Duwm1716SignalCenterActivity extends Activity' in new
assert 'Duwm1684DeskDiagnostics.read(this,desks[i])' in new
assert 's.report()' in new and 's.received' in new and 's.provider' in new
assert 'share' in new.lower() and 'startActivity(Duwm1683DeskCatalog.intent(this,d))' in new
assert 'filter==1' in new and 'filter==2' in new and 'filter==3' in new and 'filter==4' in new
assert 'REREAD' in new and 'SOURCE DETAILS' in new and 'WORLD SIGNAL CENTRE' in new
assert 'Math.random(' not in new and 'new SatelliteMapView(' not in new
assert 'getIntent().getIntExtra(EXTRA_SECTOR,-1)' in new
assert 'slot.setOnClickListener(v->openSignalCentre(context,selectedSector))' in rail
assert 'title.setOnClickListener(v->openSignalCentre(context,-1))' in rail
assert 'new LinearLayout.LayoutParams(-1,dp(activity,34))' in rail
assert 'shell.addView(original,new LinearLayout.LayoutParams(-1,0,1f))' in rail
assert 'if(genuinelyNew>0' in rail and 'Duwm1684DeskDiagnostics.read(context,desk)' in rail
assert 'DUWM 1716' in dock and 'Duwm1716SignalCenterActivity.class' in dock
assert '#041424' in (root/'1716_RELEASE_NOTES.md').read_text()
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
a='{http://schemas.android.com/apk/res/android}'
entries=[x.attrib.get(a+'name','') for x in manifest.iter('activity')]
assert '.Duwm1716SignalCenterActivity' in entries
assert len(list(j.glob('*.java'))) >= 248
for x in (root/'app/src/main/res').rglob('*.xml'):ET.parse(x)
print('PASS: 1716 full-screen live-receipt Signal Centre, all clickable 19 sector lamps, exact navy, original single globe, release identity')
print('NOT VERIFIED BY THIS CHECK: APK compile/sign, Android installation, actual network or external streams')
