#!/usr/bin/env python3
"""Checks release SOURCE facts only. An Android APK and emulator remain mandatory."""
from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
j=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
lineage=json.loads((r/'1700_SOURCE_LINEAGE.json').read_text())
assert (lineage['parent'],lineage['candidate'])==(1699,1700)
assert lineage['parent_zip_sha256']=="9d662cdeef7cd793759f0cefc5815b6bdce4193e16199a6d20190b90eb737863"
assert len(lineage['changed_files'])>=12
assert len(list(j.glob('*.java')))==239
for name,digest in lineage['protected_byte_identical_files'].items():
    assert hashlib.sha256((r/name).read_bytes()).hexdigest()==digest,('Original globe/media changed',name)
main=(j/'MainActivity.java').read_text()
assert main.count('new SatelliteMapView(this)')==1
assert main.count('dp(36), ViewGroup.LayoutParams.WRAP_CONTENT')==2
assert 'globeSpace.setMargins(0, dp(52), 0, dp(102))' in main
assert 'Math.min(getWidth() * 0.455f, getHeight() * 0.40f) * globeScale' in (j/'SatelliteMapView.java').read_text()
checks={
 'AircraftOperationsActivity.java':['focusLatestObservedAircraft','LOCATE NEWEST MATCH ON ORIGINAL GLOBE','lastContactSec<=0'],
 'GevMarineActivity.java':['focusLatestReceivedVessel','FOCUS LATEST MATCHING AIS VESSEL','seaWorldMap.setSelected(found.mmsi)'],
 'Duwm1166NewsDeskActivity.java':['newestMatch','READ LATEST MATCH','Duwm1166ArticleActivity.class'],
 'Duwm1166RadioAtlasActivity.java':['playAdjacentStation(-1)','playAdjacentStation(int direction)','playNextReceivedStation'],
 'MediaDeskActivity.java':['playAdjacentMediaSource(-1)','playAdjacentMediaSource(int direction)','mediaSort==2'],
 'Duwm1690EvidenceBars.java':['maxCount()==0','NO RECORDS IN THIS VIEW','Math.max(max,n)'],
 'Duwm1687WorkspaceActivity.java':['PROVIDER  /  "+s.provider','RECEIVED "+s.received'],
 'Duwm1687MissionBoard.java':['LAST LOCAL RECEIPT: "+s.received','receipt.setMaxLines(3)']
}
for name,strings in checks.items():
    txt=(j/name).read_text()
    for token in strings:assert token in txt,(name,token)
assert len((j/'Duwm1683DeskCatalog.java').read_text().split('        d("'))==20
assert 'versionCode = 170000' in (r/'app/build.gradle.kts').read_text()
assert 'versionName = "1700"' in (r/'app/build.gradle.kts').read_text()
assert 'DUWM 1700 • DEVELOP.UGANDA' in (r/'app/src/main/res/values/strings.xml').read_text()
ui=json.loads((r/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1700' and ui['uiVersionCode']==170000 and ui['singleOriginalGlobe']
root=ET.parse(r/'app/src/main/AndroidManifest.xml').getroot();ns='{http://schemas.android.com/apk/res/android}'
launch=[]
for activity in root.findall('application/activity'):
    for filt in activity.findall('intent-filter'):
        actions={x.get(ns+'name') for x in filt.findall('action')}
        categories={x.get(ns+'name') for x in filt.findall('category')}
        if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in categories:
            launch.append(activity.get(ns+'name','').lstrip('.'))
assert launch==['MainActivity']
print('PASS: exact 1699 lineage, 19 desks, native controls, original full-size globe and 1700 identity.')
print('APK compilation, real playback, external connectivity, and visual emulator checks still mandatory.')
