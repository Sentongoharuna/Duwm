"""DUWM 1677 source-level release gate; not an Android build or network test."""
from pathlib import Path
import json,re,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
java=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
main=root/'app/src/main'
config=(root/'app/build.gradle.kts').read_text()
assert 'versionCode = 167700' in config
assert 'versionName = "1677"' in config
manifest=ET.parse(main/'AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
launchers=[]
for a in manifest.iter('activity'):
    names={i.get(ns+'name') for f in a.findall('intent-filter') for i in f.findall('action')}
    categories={i.get(ns+'name') for f in a.findall('intent-filter') for i in f.findall('category')}
    if 'android.intent.action.MAIN' in names and 'android.intent.category.LAUNCHER' in categories:
        launchers.append(a.get(ns+'name'))
assert launchers==['.Duwm1677MissionControlActivity'],launchers
u=(java/'Duwm1677MissionControlActivity.java').read_text()
assert 'extends Activity' in u and 'extends Duwm1674CommandDeckActivity' not in u
for token in ('OperationsGlobeView','Duwm1670WorldMapView','Duwm1674UnifiedReceipts.aircraft',
  'Duwm1674UnifiedReceipts.maritime','Duwm1674UnifiedReceipts.news','RunningballV25Sources.read',
  'DuwmGeoObservationStore.read','RunningballV25GlobalAircraftData.read',
  'GevMarineActivity.timestamp','RunningballV25NewsRepository.articles',
  'Duwm1674MaritimeRefresh.refresh','Duwm1670FlightMapActivity.class',
  'GevMarineActivity.class','Duwm1670NewsAtlasActivity.class','MediaDeskActivity.class',
  'Duwm1675EvidenceVaultActivity.class','Duwm1676GeoWatchActivity.class',
  'Duwm1671SourceStatusActivity.class','V115941ShareCards.share',
  'setOnObservationSelected','setOnPinSelected','panel','SOURCE RECEIPTS',
  'NO RADIATION METER SOURCE','NOT VERIFIED INCIDENT COUNTS',
  'DRAG / PINCH / TAP REAL SOURCE POINTS','GLOBAL OPERATIONS'):
    if token=='panel': continue
    assert token in u,token
assert 'Math.random(' not in u and 'fake' not in u.lower()
assert u.count('protected void onResume()')==1
assert u.count('protected void onPause()')==1
assert (main/'assets/naturalearth_coasts.txt').is_file()
assert (main/'assets/duwm_country_borders_wdbii.txt').is_file()
config=json.loads((main/'assets/duwm_release_ui.json').read_text())
assert config['launchActivity']=='Duwm1677MissionControlActivity'
assert config['uiRevision']=='1677'
assert (main/'assets/duwm_1677_release_notes.json').is_file()
assert 'DUWM 1677' in (main/'res/values/strings.xml').read_text()
print('PASS 1677 real launcher, dynamic 8-channel receipts, two genuine maps, actionable desks, source status, share cards and release identity')
