from pathlib import Path
import json, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
pkg=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
kit=(pkg/'Duwm1678VisualKit.java').read_text()
for name in ('RADIO','TV','CAMERA','MARINE','AIR','QUAKE','MARKET','WEATHER','NEWS','SPACE'):
    assert name+'=DuwmUnifiedTheme.ACCENT' in kit, name
assert 'DuwmUnifiedTheme.UNAVAILABLE' in kit
assert 'DuwmUnifiedTheme.PANEL' in (pkg/'DuwmOptionsActivity.java').read_text()
assert (pkg/'DuwmUnifiedTheme.java').is_file()
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
found=[]
for a in manifest.iter('activity'):
    actions={x.get(ns+'name') for f in a.findall('intent-filter') for x in f.findall('action')}
    cats={x.get(ns+'name') for f in a.findall('intent-filter') for x in f.findall('category')}
    if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in cats:
        found.append(a.get(ns+'name'))
assert found==['.MainActivity'],found
main=(pkg/'MainActivity.java').read_text()
assert main.count('mapView = new SatelliteMapView(this);')==1
assert 'new OperationsGlobeView(' not in main
assert 'addMissionAction(row, "OPTIONS"' in main
cfg=(root/'app/build.gradle.kts').read_text()
assert 'versionCode = 167802' in cfg
assert 'versionName = "1678"' in cfg
pal=(root/'app/src/main/res/values/colors.xml').read_text()
for name in ('widget_red','widget_amber','widget_green','widget_violet'):
    assert '<color name="'+name+'">#47D2DB</color>' in pal
ui=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['launchActivity']=='MainActivity' and ui['singleOriginalGlobe'] is True
assert (root/'app/src/main/assets/duwm_place_map.html').is_file()
print('PASS: one original globe, single cyan-teal native theme, option desks, version 167802')
