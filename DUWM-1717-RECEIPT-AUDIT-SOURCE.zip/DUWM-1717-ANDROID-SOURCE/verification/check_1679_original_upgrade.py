from pathlib import Path
import re, json, hashlib, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
m=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
launch=[]
for a in m.iter('activity'):
    actions={x.get(ns+'name') for f in a.findall('intent-filter') for x in f.findall('action')}
    cats={x.get(ns+'name') for f in a.findall('intent-filter') for x in f.findall('category')}
    if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in cats:
        launch.append(a.get(ns+'name'))
assert launch==['.MainActivity'],launch
home=(j/'MainActivity.java').read_text()
globe=(j/'SatelliteMapView.java').read_text()
assert home.count('mapView = new SatelliteMapView(this);') == 1
assert hashlib.sha256(home.encode()).hexdigest() != '03867f82af488281ba43881cfcfe851c256fa5b28df62a092b38643cbfcde777', 'Launcher unchanged from 1678'
assert hashlib.sha256(globe.encode()).hexdigest() != 'e159783c20b545cb4bef28f35905fb6f9b2b436b8cc8710278cca6e8d8dc4717', 'Globe renderer unchanged from 1678'
assert 'new OperationsGlobeView(' not in home
assert 'new Duwm1677MissionControlActivity(' not in home
for token in ('buildOriginalGlobeControls()', 'addOriginalFocus(row, "UGANDA"', 'ROTATE ON', 'setAutoRotationEnabled(rotate)', 'mapView.setGlobeMode(false)', 'sourceMatrixView = new SourceMatrixView(this)', 'signalBeaconView = new SignalBeaconView(this)'):
    assert token in home,token
for token in ('loadOriginalGlobeGeography(context.getApplicationContext())', 'naturalearth_coasts.txt', 'duwm_country_borders_wdbii.txt', 'drawOriginalGeographicDetail(canvas)', 'drawGlobeLand(canvas)', 'updateAutoRotation();', 'drawSignals(canvas)'):
    assert token in globe,token
assert not re.search(r'new\s+(?:SatelliteMapView|OperationsGlobeView)\(', (j/'DuwmOptionsActivity.java').read_text())
config=(root/'app/build.gradle.kts').read_text()
assert 'versionCode = 167900' in config and 'versionName = "1679"' in config
release=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert release['launchActivity']=='MainActivity' and release['singleOriginalGlobe'] is True
for asset in ('duwm_country_borders_wdbii.txt', 'naturalearth_coasts.txt'):
    assert (root/'app/src/main/assets'/asset).stat().st_size>100000
print('PASS: upgraded original SatelliteMapView and home layout, one launcher and one globe, offline geography')
