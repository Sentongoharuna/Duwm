#!/usr/bin/env python3
"""DUWM 1673 release gate: proves a new working UI has been authored; not an APK emulator test."""
from pathlib import Path
import json,re,hashlib,xml.etree.ElementTree as ET
from release_contract import assert_release_at_least
P=Path(__file__).resolve().parents[1]
J=P/'app/src/main/java/com/sentongoharuna/worldsituationroom'
A=P/'app/src/main/assets'
assert_release_at_least(P,1673)
assert 'versionCode = 167300' in (P/'app/build.gradle.kts').read_text()
manifest=ET.parse(P/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
launchers=[]
activities=[]
for activity in manifest.iter('activity'):
    name=activity.get(ns+'name','');activities.append(name)
    for f in activity.findall('intent-filter'):
        actions={n.get(ns+'name') for n in f.findall('action')}
        categories={n.get(ns+'name') for n in f.findall('category')}
        if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in categories:launchers.append(name)
assert launchers==['.Duwm1673CommandDeckActivity'],launchers
for cls in ['OperationsMainActivity','Duwm1673CommandDeckActivity','Duwm1670FlightMapActivity',
            'Duwm1670NewsAtlasActivity','Duwm1671SectorActivity','GevMarineActivity',
            'Duwm1671SourceStatusActivity','MediaDeskActivity']:
    assert any(x.endswith(cls) for x in activities),cls
s=(J/'Duwm1673CommandDeckActivity.java').read_text()
for needle in ['new OperationsGlobeView(this)','setGlobePalette(true)','CHANGE GLOBE','ROTATION ON',
               'SOURCE NETWORK  /  ACTUAL RECEIPTS','Duwm1670HomeTelemetryView','Duwm1671SectorActivity',
               'Duwm1670FlightMapActivity','GevMarineActivity','Duwm1670NewsAtlasActivity','MediaDeskActivity',
               'RunningballV25GlobalAircraftData.read','DuwmGeoObservationStore.read','RunningballV25Sources.read',
               'OPEN DESK','V115941ShareCards.share','RunningballV25GlobalAircraftData.refreshNow']:
    assert needle in s,needle
assert 'Math.random(' not in s and 'Thread.sleep(' not in s
sphere=(J/'OperationsGlobeView.java').read_text()
for needle in ['setGlobePalette(boolean aurora)','auroraPalette?','canvas.drawOval','naturalearth_coasts.txt',
               'postInvalidateOnAnimation()','requestDisallowInterceptTouchEvent(true)',
               'focusAt(double lat,double lon)','setObservations(List<Observation> items)']:
    assert needle in sphere,needle
m=json.loads((A/'duwm_release_ui.json').read_text())
assert m['uiRevision']=='1673' and m['launchActivity']=='Duwm1673CommandDeckActivity'
assert m['previousGlobeSHA256']!=m['newGlobeSHA256']
assert hashlib.sha256((J/'OperationsGlobeView.java').read_bytes()).hexdigest()==m['newGlobeSHA256']
assert len(json.loads((A/'duwm_global_200_sources.json').read_text())['sources'])==200
assert len(json.loads((A/'duwm_news_200_region_sources.json').read_text())['sources'])==200
assert (A/'naturalearth_coasts.txt').stat().st_size>100000
assert (A/'duwm_country_borders_wdbii.txt').stat().st_size>100000
assert 'DUWM 1673' in (P/'app/src/main/res/values/strings.xml').read_text()
# Playback/share actions must exist in the actual Android classes, not only in a document.
media=(J/'MediaDeskActivity.java').read_text()
radio=(J/'Duwm1166RadioAtlasActivity.java').read_text()
marine=(J/'GevMarineActivity.java').read_text()
for token in ['openFullScreenMedia()', 'NativeMediaActivity.class', 'shareCurrent.setOnClickListener', 'MediaController(this)', 'shareSourceCard(lastSelectedMedia']:
    assert token in media,token
for token in ['shareStation(Station s)', 'share.setOnClickListener(v->shareStation(s))', 'MediaPlayer mp=new MediaPlayer()', 'Duwm1671Share.share(this,"RADIO"']:
    assert token in radio,token
for token in ['button("▣ CARD",()->share(v))', 'private void share(Ship s)', 'radar.setRecords(plots)', 'ShareCardRenderer.share(this,new ShareCardData']:
    assert token in marine,token
assert '.NativeMediaActivity' in activities
print('PASS DUWM 1673: genuinely changed launcher, two new globe styles, live source-backed controls, specialist navigation, dynamic release versioning and user interactions.')
print('LIMITS: static checks do not prove Gradle compilation, phone compatibility or provider availability.')
