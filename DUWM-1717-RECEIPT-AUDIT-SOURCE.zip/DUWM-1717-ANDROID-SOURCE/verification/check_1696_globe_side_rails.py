#!/usr/bin/env python3
"""Static release gate for the original globe side-rail correction; APK/emulator CI required."""
from pathlib import Path
import hashlib
import json
P=Path(__file__).resolve().parent.parent
J=P/'app/src/main/java/com/sentongoharuna/worldsituationroom'
main=(J/'MainActivity.java').read_text()
checks={
 'one original globe':main.count('new SatelliteMapView(this)')==1,
 'actual globe left exposed': 'globeSpace.setMargins(0, dp(52), 0, dp(102))' in main,
 'one left source rail': 'leftRail.addView(sourcePulseRail' in main and main.count('sourcePulseRail = buildSourcePulseRail()')==1,
 'air status on left': 'leftRail.addView(rb25WorldAirChip' in main,
 'left status on left': 'leftRail.addView(leftReadout' in main,
 'observations on right': 'rightItems.addView(globeObservationReadout' in main,
 'live health on right': 'rightItems.addView(buildLiveHud()' in main,
 'source comparison on right': 'rightItems.addView(correlationText' in main,
 'zoom on right': 'rightItems.addView(zoomRail' in main,
 'phone height scroll safety': 'rightRail.addView(rightItems)' in main and 'ScrollView rightRail = new ScrollView(this)' in main,
 'source layers independently scroll': 'ScrollView scroller = new ScrollView(this)' in main,
 'clear globe interaction': 'clearGlobeButton.setOnClickListener' in main and 'clearGlobeButton.setText(clear ? "RAILS" : "CLEAR")' in main,
 'globe controls opt in': 'globeControls.setVisibility(View.GONE)' in main and 'globeToolsButton.setOnClickListener' in main,
 'no fixed status card across centre': 'commandDeck.addView(liveHud' not in main,
 'no bottom-wide layers rail': 'commandDeck.addView(sourcePulseRail' not in main,
 'no bottom-wide correlation card': 'commandDeck.addView(correlationText' not in main,
 'real source navigation preserved':'selectPulseSource(layer)' in main and 'openSelectedGlobeObservation()' in main,
 'all 19 desks preserved': 'open1684Desk(18)' in main and 'Duwm1683DeskCatalog.ALL' in main,
 'version still 1696': 'versionCode = 169600' in (P/'app/build.gradle.kts').read_text(),
}
for k,v in checks.items():
    assert v,'FAIL: '+k
print('PASS 1696 FIX1 original-globe side rails:',len(checks),'source/layout invariants')
print('LIMIT: visual verification and Android compilation must pass in GitHub Actions')
