"""DUWM 1689 native source lineage + functionality gate.
Must be executed after extracting the exact 1689 source archive.
Cannot prove Android compilation or app UI/performance on a physical phone.
"""
from pathlib import Path
import hashlib,json,re,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
record=json.loads((root/'SOURCE_LINEAGE_1689.json').read_text())
assert record['baseSourceZipSHA256']=='244da3e1d32762ee6b6f66018693a8ea10d7e4923a8530907c0f9ec28e374809'
base=record['inheritedJavaSHAs']
changed=record['changedExistingNativePages']
for name in changed:
    actual=hashlib.sha256((j/name).read_bytes()).hexdigest()
    assert actual!=base[name],f'1689 falsely relabelled but native page unchanged: {name}'
for name in ('SatelliteMapView.java','DuWorldApplication.java','LiveEarthGlobeView.java','Duwm1670WorldMapView.java','GevMarineRadarView.java','NativeMediaActivity.java'):
    assert hashlib.sha256((j/name).read_bytes()).hexdigest()==base[name],f'Protected original renderer/media core changed: {name}'
main=(j/'MainActivity.java').read_text()
assert 'new SatelliteMapView(this);' in main and main.count('mapView = new SatelliteMapView(this);')==1
assert hashlib.sha256(main.replace('1689','1688').encode()).hexdigest()==base['MainActivity.java'], 'MainActivity changed beyond version text or original globe replaced'
gradle=(root/'app/build.gradle.kts').read_text()
strings=(root/'app/src/main/res/values/strings.xml').read_text()
assert 'versionCode = 168900' in gradle and 'versionName = "1689"' in gradle
assert 'applicationId = "com.sentongoharuna.worldsituationroom.rb2live25"' in gradle
assert '<string name="app_name">DUWM 1689 • DEVELOP.UGANDA</string>' in strings
meta=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert meta['uiRevision']=='1689' and meta['uiVersionCode']==168900 and meta['singleOriginalGlobe'] is True
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
a='{http://schemas.android.com/apk/res/android}'
assert any(v.attrib.get(a+'name')=='.MainActivity' for v in manifest.iter('activity'))
assert 'DUWM 1689 Operations' in (root/'app/src/main/AndroidManifest.xml').read_text()
catalog=(j/'Duwm1683DeskCatalog.java').read_text()
assert sum(line.lstrip().startswith('d("') for line in catalog.splitlines())==19
assert '1689  /  WORLD OPERATIONS' in (j/'Duwm1687MissionBoard.java').read_text()
assert '1689 / '+'' in (j/'Duwm1687WorkspaceActivity.java').read_text()
news=(j/'Duwm1166NewsDeskActivity.java').read_text()
for marker in ('duwm_news_bookmarks','savedOnly','toggleSaved','SAVE THIS REPORT','PAGE '): assert marker in news,marker
radio=(j/'Duwm1166RadioAtlasActivity.java').read_text()
for marker in ('duwm_radio_stations','savedOnly','saveStation(s)','stationVisible(s)','prepareAsync'): assert marker in radio,marker
flight=(j/'Duwm1670FlightMapActivity.java').read_text()
for marker in ('inRegion(activeRegion,lat,lon)','freshOnly','recent(at,1200000L)','Collections.sort(fresh','pairsOnly'): assert marker in flight,marker
marine=(j/'GevMarineActivity.java').read_text()
for marker in ('vesselKind','kindOf(ship)','worldPins.size()<1200','plots.size()<1200','visibleShip(ship,now)'): assert marker in marine,marker
media=(j/'MediaDeskActivity.java').read_text()
for marker in ('shownLimit=45','shownLimit+=45','SORT: SOURCE','SORT: A–Z','visible.sort','lastSelectedMedia'): assert marker in media,marker
health=(j/'Duwm1671SourceStatusActivity.java').read_text()
for marker in ('issuesOnly','SHOW ONLY UNAVAILABLE','Status.LIVE','MainActivity.class'): assert marker in health,marker
assert 'Status.DELAYED' not in health, 'Delayed must not be labelled live'
assert not any('new SatelliteMapView' in (j/name).read_text() for name in changed), 'Do not add a duplicate globe'
assert not any('1688' in f.read_text() for f in j.glob('*.java')), 'Stale live page version caption remains'
print('PASS 1689: real native page modifications relative to SHA-pinned 1688, original map and player engines protected')
print('PASS 1689: persistent source bookmarks, actual geographic and vessel classification filters, incremental media listing and provider state filtering')
print('PASS 1689: 19 native desk entries, launcher label 1689, version code 168900 and stable original application ID')
print('NOTE: Android SDK compile, data feed availability and phone UI must be verified independently.')
