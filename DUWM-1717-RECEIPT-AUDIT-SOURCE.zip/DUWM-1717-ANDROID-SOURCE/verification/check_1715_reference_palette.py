#!/usr/bin/env python3
from pathlib import Path
import re,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
j=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
ui=(j/'DuwmUnifiedTheme.java').read_text()
colors=(r/'app/src/main/res/values/colors.xml').read_text()
assert 'BACKGROUND = 0xFF041424' in ui
assert 'PANEL = 0xFF041424' in ui
assert 'APPROVED_NAVY = 0xFF041424' in ui
assert 'BORDER = 0xFFDEE5EF' in ui
assert 'TEXT = 0xFFF5F7FA' in ui
assert 'MUTED = 0xFFA0A5AE' in ui
assert 'FORMAL_CORNER_DP = 20' in ui
assert '<color name="command_background">#041424</color>' in colors
assert '<color name="widget_text">#F5F7FA</color>' in colors
assert 'DuwmUnifiedTheme.LOCAL_SIGNAL' in (j/'Duwm1715SignalLights.java').read_text()
main=(j/'MainActivity.java').read_text()
assert main.count('new SatelliteMapView(this)')==1
assert 'SignalTickerRailView' in main
for file in (r/'app/src/main/res').rglob('*.xml'):ET.parse(file)
print('PASS image reference navy and silver UI, semantic signal lights, one protected original globe')
