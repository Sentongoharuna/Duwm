import com.sun.source.util.JavacTask;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

/** Parse Java sources without requiring Android SDK; CI still performs real Android compilation. */
public final class JavaSyntaxCheck {
    public static void main(String[] args) throws Exception {
        Path dir = Path.of("app/src/main/java");
        List<Path> files = new ArrayList<>();
        try (Stream<Path> all = Files.walk(dir)) {
            all.filter(p -> p.toString().endsWith(".java")).sorted(Comparator.comparing(Path::toString)).forEach(files::add);
        }
        if (files.size() < 200) throw new AssertionError("Expected complete Android source, found " + files.size());
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) throw new IllegalStateException("JDK compiler required");
        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        try (StandardJavaFileManager manager = compiler.getStandardFileManager(diagnostics, null, null)) {
            Iterable<? extends JavaFileObject> source = manager.getJavaFileObjectsFromPaths(files);
            JavacTask task = (JavacTask)compiler.getTask(null, manager, diagnostics,
                    List.of("-proc:none"), null, source);
            task.parse();
        }
        long errors = diagnostics.getDiagnostics().stream().filter(d -> d.getKind() == Diagnostic.Kind.ERROR).count();
        if (errors > 0) {
            for (Diagnostic<? extends JavaFileObject> d : diagnostics.getDiagnostics())
                if (d.getKind() == Diagnostic.Kind.ERROR) System.err.println(d);
            throw new AssertionError(errors + " Java syntax errors");
        }
        System.out.println("PASS parsed " + files.size() + " Java source files without syntax errors");
    }
}
