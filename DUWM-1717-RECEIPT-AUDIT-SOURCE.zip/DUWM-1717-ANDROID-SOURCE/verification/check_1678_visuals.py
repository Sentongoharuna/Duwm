"""DUWM 1678 source contract. Checks implementation, not Android runtime nor network success."""
from pathlib import Path
import re, json, xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
JAVA=ROOT/'app/src/main/java/com/sentongoharuna/worldsituationroom'
read=lambda n:(JAVA/n).read_text()
config=(ROOT/'app/build.gradle.kts').read_text()
assert 'versionCode = 167802' in config and 'versionName = "1678"' in config
manifest=ET.parse(ROOT/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
launchers=[]
for act in manifest.iter('activity'):
    aa={x.get(ns+'name') for f in act.findall('intent-filter') for x in f.findall('action')}
    cc={x.get(ns+'name') for f in act.findall('intent-filter') for x in f.findall('category')}
    if 'android.intent.action.MAIN' in aa and 'android.intent.category.LAUNCHER' in cc:launchers.append(act.get(ns+'name'))
assert launchers == ['.MainActivity'],launchers
kit=read('Duwm1678VisualKit.java')
for token in ('PulsePanel extends View','RADIO=','CAMERA=','MARINE=','QUAKE=','MARKET=',
              'setReceipt(', 'setMode(', 'postInvalidateDelayed','SOURCE DISPLAY'):
    assert token in kit,token
media=read('MediaDeskActivity.java')
for token in ('HorizontalScrollView','mediaBand.setMode(name)', 'Duwm1678VisualKit.chip',
              'restoreDirectory(requested)','saveDirectory(requested,fresh)',
              'CACHED SOURCE DIRECTORY','TEST ON PLAY','RETRY SOURCE CONNECTION'):
    assert token in media,token
marine=read('GevMarineActivity.java')
for token in ('marineBand.setReceipt','seaWorldMap=new Duwm1670WorldMapView',
              'seaWorldMap.setPins(worldPins,false)', 'Vessel', 'radar.resume()', '▣ CARD'):
    if token=='Vessel': continue
    assert token in marine,token
assert 'Duwm1678VisualKit.PulsePanel' in read('Duwm1671SectorActivity.java')
assert 'DUWM • LIVE INTELLIGENCE DESKS' in read('Duwm1671SectorActivity.java')
assert 'Duwm1678VisualKit.PulsePanel' in read('Duwm1670FlightMapActivity.java')
assert 'TRAIL: TWO REAL FIXES' in read('Duwm1670FlightMapActivity.java')
assert 'Two distinct real receipts are required' in read('Duwm1671TrendView.java')
assert 'No graph or synthetic trend' in read('Duwm1671TrendView.java')
assert 'Radar scan is a purely visual cue' in read('Duwm1670WorldMapView.java')
assert 'Rotating visual scan is not a simulated AIS observation' in read('GevMarineRadarView.java')
assert '1678' in read('Duwm1677MissionControlActivity.java')
assert 'duwm_1678_release_notes.json' in '\n'.join(p.name for p in (ROOT/'app/src/main/assets').iterdir())
ui=json.loads((ROOT/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1678'
assert ui['launchActivity']=='MainActivity'
assert (ROOT/'app/src/main/assets/duwm_country_borders_wdbii.txt').is_file()
assert 'SEA' in read('OperationsGlobeView.java')
print('PASS 1678 changed native media, maritime, aircraft, sector, chart, radar, release and launcher visuals')
