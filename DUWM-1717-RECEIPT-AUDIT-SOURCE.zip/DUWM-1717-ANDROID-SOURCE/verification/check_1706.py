#!/usr/bin/env python3
"""1705 source contract: actual source updates and no replacement globe."""
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
m=(j/'MainActivity.java').read_text()
g=(j/'SatelliteMapView.java').read_text()
b=(root/'app/build.gradle.kts').read_text()
ui=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert 'versionCode = 170600' in b and 'versionName = "1706"' in b
assert 'applicationId = "com.sentongoharuna.worldsituationroom.rb2live25"' in b
assert 'DUWM 1706' in (root/'app/src/main/res/values/strings.xml').read_text()
assert ui['uiRevision']=='1706' and ui['uiVersionCode']==170600
assert ui['singleOriginalGlobe'] and ui['launchActivity']=='MainActivity'
assert m.count('new SatelliteMapView(this)')==1
assert 'globeSpace.setMargins(0, dp(52), 0, dp(102))' in m
assert 'Math.min(getWidth() * 0.455f, getHeight() * 0.40f) * globeScale' in g
for token in ['set1702SourceLens(int lens)', 'prioritySignals', 'setGlobePresentationMode(int mode)']:
 assert token in g, token
for token in ['build1703WorldWatchPanel()', 'show1703WorldWatch()', 'collect1703WorldWatch(long now)',
              'open1703WatchSignal(Signal signal)', 'watchAge1703(long stamp, long now)',
              'watchHours1703', 'watchPriorityOnly1703', 'watchPanel1703.setVisibility(View.GONE)',
              'watchTab1703 = globeEdgeTab', 'mapView.highlightSignal(signal)',
              'signal.canonicalId', 'signal.timestampMs', 'signal.source', 'signal.latitude']:
 assert token in m, token
assert 'DUWM 1702' in (root/'1702_RELEASE_NOTES.md').read_text()
assert 'DUWM 1705' in (root/'1705_RELEASE_NOTES.md').read_text()
assert len(list(j.glob('*.java')))>=239
ns='{http://schemas.android.com/apk/res/android}'
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
la=[]
for a in manifest.findall('application/activity'):
 for i in a.findall('intent-filter'):
  actions={x.get(ns+'name') for x in i.findall('action')}
  cats={x.get(ns+'name') for x in i.findall('category')}
  if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in cats:
   la.append(a.get(ns+'name','').lstrip('.'))
assert la==['MainActivity'],la
assert len((j/'Duwm1683DeskCatalog.java').read_text().split('        d("'))==20
for token in ['watchSearch1704', 'matches1704Group(Signal s)', 'matches1704Query(Signal s)',
              'filter1704WorldWatch(List<Signal> source)', 'show1704GroupPicker()',
              'show1704SortPicker()', 'show1704Receipt(Signal signal)', 'watchPage1704',
              'shareSignal(signal)', 'signal.coordinateProvenance.origin.name()',
              'signal.sourceUrl.startsWith("https://")', 'watchGroup1704', 'watchSort1704',
              'REPORT CAM', 'openLocalMonitors()']:
 assert token in m, token
assert 'WORLD WATCH / 1705' in m
assert 'watchGroupButton1704' in m
assert 'versionCode = 170600' in b
for token in ['WATCH_EVIDENCE_1705', 'watchEvidence1705', 'watchRegion1705',
              'show1705RegionPicker()', 'show1705EvidencePicker()',
              'matches1705Evidence(Signal signal)', 'matches1705SourceRegion(Signal signal)',
              'count1705Category(List<Signal> signals, String category)',
              'render1705Pulse(List<Signal> allReceived)',
              'SOURCE-REPORTED REGION', 'SOURCE HTTPS LINK',
              'signal.sourceUrl.startsWith("https://")',
              'Signal.Credibility.CONFIRMED', 'signal.id.startsWith("local-monitor:")',
              'watchPulse1705', 'watchCoverage1705']:
 assert token in m, token
assert 'DUWM 1704' in (root/'1704_RELEASE_NOTES.md').read_text()
assert ui['singleOriginalGlobe'] is True
assert 'new SatelliteMapView(this)' in m and m.count('new SatelliteMapView(this)')==1
print('PASS 1706: retained 1705 source pulse, newsroom, provenance, original single globe, all 19 desks')
