#!/usr/bin/env python3
from pathlib import Path
import json,re,hashlib,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent.parent
j=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
lineage=json.loads((r/'1699_SOURCE_LINEAGE.json').read_text())
assert lineage['parent']==1698 and lineage['candidate']==1699
assert lineage['parent_zip_sha256']=='637c23b81c7dd1c63f2bb5c88eb1a2c589474d05f8bf76274d97796c5472bc87'
assert len(lineage['changed_files'])>=10
assert len(list(j.glob('*.java')))==239
for name,h in lineage['protected_byte_identical_files'].items():
    assert hashlib.sha256((r/name).read_bytes()).hexdigest()==h,('Original globe/media source changed',name)
main=(j/'MainActivity.java').read_text()
assert main.count('new SatelliteMapView(this)')==1,'No new globe'
assert main.count('dp(36), ViewGroup.LayoutParams.WRAP_CONTENT')==2,'Keep narrow globe edge controls'
assert 'globeSpace.setMargins(0, dp(52), 0, dp(102))' in main
assert 'Math.min(getWidth() * 0.455f, getHeight() * 0.40f) * globeScale' in (j/'SatelliteMapView.java').read_text()
checks={
 'AircraftOperationsActivity.java':['altitudeBand==1','f.altMeters>=3048.0d','f.altMeters<9144.0d','ALTITUDE / ALL RECEIVED'],
 'GevMarineActivity.java':['speedBand==1','speedBand==2','speedBand==3','if(visibleShip(ship,now)&&worldPins.size()<1200)','AIS SPEED / STOPPED OR NEAR ZERO'],
 'Duwm1166NewsDeskActivity.java':['receivedLinks.add(n.link.trim())','suppressedRepeats','REPEATED SOURCE LINKS'],
 'Duwm1166RadioAtlasActivity.java':['selectedMapFocus','selected.lon-6d','selected.lat-4d','MAP: SELECTED STATION'],
 'MediaDeskActivity.java':['mediaSort=(mediaSort+1)%3','mediaSort==2','Boolean.compare(ib,ia)'],
}
for n,fields in checks.items():
    content=(j/n).read_text()
    assert all(f in content for f in fields),n
assert len((j/'Duwm1683DeskCatalog.java').read_text().split('        d("'))==20
build=(r/'app/build.gradle.kts').read_text()
assert 'versionCode = 169900' in build and 'versionName = "1699"' in build
assert '<string name="app_name">DUWM 1699 • DEVELOP.UGANDA</string>' in (r/'app/src/main/res/values/strings.xml').read_text()
ui=json.loads((r/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['uiRevision']=='1699' and ui['uiVersionCode']==169900 and ui['singleOriginalGlobe']
manifest=ET.parse(r/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
launch=[]
for a in manifest.findall('application/activity'):
    for f in a.findall('intent-filter'):
        actions={x.get(ns+'name') for x in f.findall('action')}
        cats={x.get(ns+'name') for x in f.findall('category')}
        if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in cats:
            launch.append(a.get(ns+'name','').lstrip('.'))
assert launch==['MainActivity'],launch
print('PASS: exact source lineage, original globe unchanged, 19 desk routes, actual native page features, app release 1699')
print('APK compilation and runtime remain mandatory before release')
