#!/usr/bin/env python3
"""Hard checks for the 1674.1 data-flow repairs, without pretending to test live Internet."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
def src(n): return (j/(n+'.java')).read_text()
truth=src('Duwm1674UnifiedReceipts')
assert 'RunningballV25GlobalAircraftData.read(c)' in truth
assert 'getSharedPreferences("rb11_marine"' in truth
assert 'RunningballV25NewsRepository.articles(c,key)' in truth
assert 'RunningballV17Feeds.cached(c,RunningballV17Feeds.NEWS)' in truth
for klass in ('Duwm1674SignalBoardView','Duwm1670HomeTelemetryView','Duwm1674CommandDeckActivity'):
 assert 'Duwm1674UnifiedReceipts.' in src(klass),klass
control=src('Duwm1674CommandDeckActivity')
assert 'Duwm1674MaritimeRefresh.refresh(this' in control
assert 'Duwm1674MaritimeRefresh.refresh(Duwm1674CommandDeckActivity.this' in control
assert 'OperationsGlobeView.SEA' in control
assert 'GevMarineActivity.timestamp(ship)' in control
assert 'Duwm1674TimeGuard.recent' in control
assert '1200' in control and 'report.size()<1200' in control
sphere=src('OperationsGlobeView')
assert 'SEA=4' in sphere and 'kind==SEA?sea' in sphere
assert 'int max=1800' in sphere
marine=src('Duwm1674MaritimeRefresh')
assert 'https://ais.openwaters.io/v1/vessels?bbox=' in marine
assert 'if(http!=200)' in marine
assert 'validMmsi(mmsi)' in marine and 'last_error' in marine
assert 'new JSONArray()' in marine
assert 'Math.random(' not in marine and 'fake' not in control.lower()
assert 'versionCode = 167401' in (root/'app/build.gradle.kts').read_text()
print('PASS 1674.1 unified AIR/SEA/NEWS receipt checks, AIS refresh, vessel globe pins, source date checks')
