"""Release 1681: focus existing original globe, no extra renderer or fake positions."""
from pathlib import Path
import json, xml.etree.ElementTree as ET, re
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java'
java=src.read_text()
sphere=(root/'app/src/main/java/com/sentongoharuna/worldsituationroom/SatelliteMapView.java').read_text()
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
android='{http://schemas.android.com/apk/res/android}'
launch=[]
for a in manifest.iter('activity'):
    for f in a.findall('intent-filter'):
        if any(e.get(android+'name')=='android.intent.action.MAIN' for e in f.findall('action')) and any(e.get(android+'name')=='android.intent.category.LAUNCHER' for e in f.findall('category')):
            launch.append(a.get(android+'name'))
assert launch==['.MainActivity'],launch
assert java.count('mapView = new SatelliteMapView(this);')==1
assert 'new OperationsGlobeView(' not in java
assert 'setAutoRotationEnabled' in java and 'setAutoRotationEnabled(boolean enabled)' in sphere
for token in ('pulseMapFocus', 'pulseRailHeading', 'selectPulseSource(layer)',
              'private void selectPulseSource(Signal.Layer layer)',
              'private void clearPulseMapFocus()', 'private boolean pulseHasMapLayer(',
              'mapView.setGlobeMode(true)',
              'mapView.setCenter(newest.latitude, newest.longitude, 3d)',
              'signal.hasLocation()',
              'if (it.next().layer != pulseMapFocus) it.remove();',
              'updateSourcePulseRail(); // age changes when a source becomes stale',
              'openCatalog(pulseCatalog(layer))',
              'case SHIPS: return "SEA";',
              'case NEWS: return "NEWS";',
              'case NATURAL: return "QUAKE";',
              'Color.argb(246, 11, 50, 63)'):
    assert token in java, f'missing behavior: {token}'
config=(root/'app/build.gradle.kts').read_text()
assert 'versionCode = 168100' in config and 'versionName = "1681"' in config
ui=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['launchActivity']=='MainActivity' and ui['singleOriginalGlobe'] is True
assert ui['uiRevision']=='1681' and ui['uiVersionCode']==168100
focus=json.loads((root/'app/src/main/assets/duwm_1681_source_focus.json').read_text())
assert focus['singleGlobe'] and focus['globe']=='SatelliteMapView'
assert {'FLIGHTS','SHIPS','NEWS','NATURAL','WEBCAMS'} == set(focus['focusLayers'])
assert 'duwm_country_borders_wdbii.txt' in '\n'.join(p.name for p in (root/'app/src/main/assets').iterdir())
print('PASS: 1681 source rail focuses one category on ORIGINAL globe, with clear/reset and data-only map markers')
