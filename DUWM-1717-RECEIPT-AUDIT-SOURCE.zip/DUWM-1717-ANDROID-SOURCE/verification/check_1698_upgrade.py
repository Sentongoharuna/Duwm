#!/usr/bin/env python3
"""1698 source evidence gate. APK compilation and runtime checks remain mandatory."""
from pathlib import Path
from hashlib import sha256
import json, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent.parent
java=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
meta=json.loads((root/'1698_RELEASE_SOURCE_LINEAGE.json').read_text())
assert meta['release']==1698 and meta['parent']==1697
assert meta['base_sha256']=='87db5c32e99dc77de0d34a4070cb977c0c33612e7f53ceb9c198e7fef1bad452'
assert len(set(meta['changed_java_files']))>=10
assert len(list(java.glob('*.java')))==239
# Original globe size, renderer and NativeMapView are byte-identical except for release labels.
for name,expected in meta['protected_source_sha256_1697'].items():
    contents=(java/name).read_text()
    if name != 'SatelliteMapView.java':
        contents=contents.replace('1698','1697')
    assert sha256(contents.encode('utf-8')).hexdigest()==expected,(name,'Original renderer/layout changed')
main=(java/'MainActivity.java').read_text()
assert main.count('new SatelliteMapView(this)')==1
assert 'globeSpace.setMargins(0, dp(52), 0, dp(102))' in main
assert main.count('dp(36), ViewGroup.LayoutParams.WRAP_CONTENT')==2
assert 'mapView.setScaleX(' not in main and 'mapView.setScaleY(' not in main
assert 'Math.min(getWidth() * 0.455f, getHeight() * 0.40f) * globeScale' in (java/'SatelliteMapView.java').read_text()
checks={
 'AircraftOperationsActivity.java':['TextView map=click("MAP")','Duwm1670FlightMapActivity.class','FILTERS  ▸','RESET SEARCH / FILTERS','recentContactOnly'],
 'GevMarineActivity.java':['VIEW RECEIVED AIS CLASSIFICATION','marineEvidence.setVisibility(android.view.View.GONE)','root.addView(detail,5','vesselTypeButtons','root.addView(seaWorldMap,4,seaMapLayout)'],
 'Duwm1166NewsDeskActivity.java':['title.setOnClickListener','dp(compactNews?100:186)','root.addView(layoutMode,layoutLp)','Duwm1166PortraitCard.share'],
 'Duwm1166RadioAtlasActivity.java':['atlas.updateBounds();atlas.invalidate()','if(s==selected){ // Selected station label','playNextReceivedStation','Selected station label is derived'],
 'MediaDeskActivity.java':['mediaBand.setVisibility(View.GONE)','showMediaSourceChart','showReport.setOnClickListener','content.setOnClickListener','playerControlsScroll.addView(controls)'],
 'Duwm1687WorkspaceActivity.java':['private ScrollView contentScroller','contentScroller.scrollTo(0,0)','PROVIDER RECEIPT','LATEST VERIFIED RECEIPT CHANGE','Duwm1690EvidenceBars','19 desks'],
 'Duwm1690EvidenceBars.java':['float y=head+row*rowHeight','max=Math.max(max,n)'],
 'Duwm1671SourceStatusActivity.java':['SHOW PROVIDER RECEIPT CHART','RunningballV25Sources.read','SOURCE DETAILS  /  EXPANDED'],
}
for n,tokens in checks.items():
    s=(java/n).read_text()
    for token in tokens:assert token in s,(n,token)
ws=(java/'Duwm1687WorkspaceActivity.java').read_text()
assert ws.index('LinearLayout p=panel("01   LIVE OPERATIONAL SOURCE")')<ws.index('LinearLayout change=panel("LATEST VERIFIED RECEIPT CHANGE")'), 'Live source should lead'
assert len((java/'Duwm1683DeskCatalog.java').read_text().split('        d("'))==20
b=(root/'app/build.gradle.kts').read_text()
assert 'versionCode = 169800' in b and 'versionName = "1698"' in b
assert '<string name="app_name">DUWM 1698 • DEVELOP.UGANDA</string>' in (root/'app/src/main/res/values/strings.xml').read_text()
ui=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text());assert ui['uiRevision']=='1698' and ui['uiVersionCode']==169800 and ui['singleOriginalGlobe']
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot();ns='{http://schemas.android.com/apk/res/android}'
launch=[]
for a in manifest.findall('application/activity'):
 for f in a.findall('intent-filter'):
  actions={x.get(ns+'name') for x in f.findall('action')};categories={x.get(ns+'name') for x in f.findall('category')}
  if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in categories:launch.append(a.get(ns+'name','').lstrip('.'))
assert launch==['MainActivity']
print('PASS: 1698 native page changes, 19 desks, protected globe geometry and Android identity')
print('WARNING: Java syntax is not Android compilation; screenshots and playback require actual APK tests')
