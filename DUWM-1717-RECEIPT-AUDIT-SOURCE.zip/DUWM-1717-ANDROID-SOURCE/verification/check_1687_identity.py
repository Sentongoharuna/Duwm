"""1687 FIX1: Verify phone-visible identity matches actual source and release metadata.
Not a substitute for Android compilation or physical-device runtime checks.
"""
from pathlib import Path
import xml.etree.ElementTree as ET
import json
r=Path(__file__).resolve().parents[1]
strings=ET.parse(r/'app/src/main/res/values/strings.xml').getroot()
label=next(v.text for v in strings.findall('string') if v.get('name')=='app_name')
assert label=='DUWM 1687 • DEVELOP.UGANDA',f'Stale Android launcher label: {label}'
build=(r/'app/build.gradle.kts').read_text()
assert 'versionCode = 168700' in build and 'versionName = "1687"' in build
release=json.loads((r/'app/src/main/assets/duwm_release_ui.json').read_text())
assert release['uiRevision']=='1687' and release['uiVersionCode']==168700
manifest=(r/'app/src/main/AndroidManifest.xml').read_text()
assert 'android:label="@string/app_name"' in manifest
assert 'DUWM 1678 Optional Intelligence Desk' not in manifest
java=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
for file in ('Duwm1685PageUpgrade.java','Duwm1686WorkspaceActivity.java','Duwm1687Console.java','Duwm1687MissionBoard.java','Duwm1687WorkspaceActivity.java','Duwm1687ShareCard.java'):
    assert (java/file).is_file(),f'Cumulative latest version class missing: {file}'
options=(java/'DuwmOptionsActivity.java').read_text()
assert 'getPackageManager().getPackageInfo(getPackageName(),0).versionName' in options
assert 'getString(R.string.app_name)' in options
for filename in ('Duwm1671SectorActivity.java','Duwm1677MissionControlActivity.java'):
    assert '1678 •' not in (java/filename).read_text(),f'Stale old visible version in {filename}'
print('PASS 1687 FIX1: launcher label, real installed version, versionCode, release metadata, cumulative classes')
