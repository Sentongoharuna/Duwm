#!/usr/bin/env python3
"""1713 real-code checks: 19-sector receipt comparison, unified navy + protected globe."""
import json, subprocess, sys, xml.etree.ElementTree as ET
from pathlib import Path
r=Path(__file__).resolve().parents[1]
j=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
code=(r/'app/build.gradle.kts').read_text()
assert 'versionCode = 171300' in code and 'versionName = "1713"' in code
assert 'DUWM 1713' in (r/'app/src/main/res/values/strings.xml').read_text()
a=json.loads((r/'app/src/main/assets/duwm_release_ui.json').read_text())
assert a['uiRevision']=='1713' and a['uiVersionCode']==171300
assert a['receiptCompare1713']['sectors']==19
assert a['receiptCompare1713']['background']=='#050D22'
assert a['receiptCompare1713']['dualSectorCompare']
assert a['receiptCompare1713']['noOverlayOverGlobe']
assert a['receiptCompare1713']['originalSingleGlobe']
assert not a['receiptCompare1713']['crossSourceCorrelationClaims']
s=(j/'Duwm1712OperationsMatrixActivity.java').read_text()
for token in ('COMPARE TWO','pick1713Sector','render1713Comparison','add1713ComparisonCard',
              'SOURCE OBSERVATION','LAST LOCAL RECEIPT','snapshot.report()',
              'setStatuses(statuses)','new Duwm1713ReceiptCoverageView(this)',
              'BACK TO ALL 19 SECTORS','no extra globe','Duwm1684DeskDiagnostics.read'):
    assert token in s,token
assert 'new SatelliteMapView(this)' not in s
assert 'Math.random(' not in s
strip=(j/'Duwm1713ReceiptCoverageView.java').read_text()
for token in ('states=new int[19]', 'states.length', 'setStatuses', 'DuwmUnifiedTheme.LIVE',
              'DuwmUnifiedTheme.WARNING','DuwmUnifiedTheme.ACCENT', 'DuwmUnifiedTheme.UNAVAILABLE'):
    assert token in strip,token
assert 'Math.random(' not in strip
assert len(list(j.glob('*.java')))>=245
assert 'new SatelliteMapView(this)' in (j/'MainActivity.java').read_text()
assert 'Duwm1712OperationsMatrixActivity' in (r/'app/src/main/AndroidManifest.xml').read_text()
for x in (r/'app/src/main/res').rglob('*.xml'): ET.parse(x)
subprocess.run([sys.executable,str(r/'verification/check_1712.py')],cwd=r,check=True)
print('PASS DUWM 1713 source comparison: receipts only, 19-segment status coverage, 19-sector navigation, original globe preserved, approved navy')
