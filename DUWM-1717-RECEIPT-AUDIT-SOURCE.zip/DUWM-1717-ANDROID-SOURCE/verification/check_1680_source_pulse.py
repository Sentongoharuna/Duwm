from pathlib import Path
import re,xml.etree.ElementTree as ET,json
r=Path(__file__).resolve().parents[1]
j=r/'app/src/main/java/com/sentongoharuna/worldsituationroom'
s=(j/'MainActivity.java').read_text()
g=(j/'SatelliteMapView.java').read_text()
assert s.count('mapView = new SatelliteMapView(this);')==1
assert 'new OperationsGlobeView(' not in s
for token in ('sourcePulseRail = buildSourcePulseRail()', 'private View buildSourcePulseRail()',
              'private void updateSourcePulseRail()', 'updateSourcePulseRail();',
              'case SHIPS: return "SHIPS";', 'case NEWS: return "NEWS";',
              'case TV: return "TV";', 'case RADIO: return "RADIO";',
              'status.state == FeedStatus.State.LIVE', 'provider reported',
              'saved records', 'new Intent(this, Duwm1671SourceStatusActivity.class)'):
    assert token in s,token
assert s.count('private View buildSourcePulseRail()')==1
assert s.count('private void updateSourcePulseRail()')==1
assert 'naturalearth_coasts.txt' in g and 'drawOriginalGeographicDetail(canvas)' in g
m=ET.parse(r/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
launch=[]
for a in m.iter('activity'):
    actions={x.get(ns+'name') for f in a.findall('intent-filter') for x in f.findall('action')}
    cats={x.get(ns+'name') for f in a.findall('intent-filter') for x in f.findall('category')}
    if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in cats:
        launch.append(a.get(ns+'name'))
assert launch==['.MainActivity'],launch
config=(r/'app/build.gradle.kts').read_text()
assert 'versionCode = 168000' in config and 'versionName = "1680"' in config
ui=json.loads((r/'app/src/main/assets/duwm_release_ui.json').read_text())
assert ui['launchActivity']=='MainActivity' and ui['singleOriginalGlobe'] is True
assert ui['uiRevision']=='1680'
print('PASS 1680: one original Command Center and real-status source rail linked to existing desks')
