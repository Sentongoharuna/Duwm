#!/usr/bin/env python3
"""Verify real source modifications for DUWM 1672; not a substitute for compilation or on-phone testing."""
from pathlib import Path
import hashlib,json,re
P=Path(__file__).resolve().parents[1]
J=P/'app/src/main/java/com/sentongoharuna/worldsituationroom'
B=(P/'app/build.gradle.kts').read_text()
from release_contract import assert_release_at_least
assert_release_at_least(P,1672)
assert 'com.sentongoharuna.worldsituationroom.rb2live25' in B

def source(name):
    f=J/name
    assert f.is_file(),name
    return f.read_text()

air=source('RunningballV25GlobalAircraftData.java')
assert 'MAX_POINTS=22000' in air and 'MAX_BYTES=32*1024*1024' in air
assert 'refreshNow(Context context, Runnable callback)' in air and 'MANUAL_GAP_MS=30L*1000L' in air
assert 'nextAllowedAt' in air and 'http==429' in air
assert 'priorSourceAt' in air and 'previous' in air
assert 'MAX_POINTS=5000' not in air
flight=source('Duwm1670FlightMapActivity.java')
assert 'ui.postDelayed(this,1200)' in flight and 'RunningballV25GlobalAircraftData.refreshNow' in flight
assert '&&fresh.size()<2500' not in flight
world=source('Duwm1670WorldMapView.java')
assert 'occupied=new boolean' in world and 'No fixed 2500-item clipping' in world
assert 'if(shown++>2500)' not in world
marine=source('GevMarineActivity.java')
assert 'https://ais.openwaters.io/v1/vessels?bbox=' in marine
assert '&limit=1000' not in marine
assert 'PUBLIC_REGIONS' in marine and 'PUBLIC_BBOX' in marine
assert 'lastPublicRequest' in marine and 'publicPoller' in marine
assert 'setFillViewport(true)' in marine and 'setContentView(page)' in marine
assert 'LOAD MORE VERIFIED SHIPS' in marine and 'sourceName.startsWith("Open Waters")' in marine
assert 'private final ExecutorService io' in marine
bbox=re.search(r'private static final double\[\]\[\] PUBLIC_BBOX=\{(.*?)\};',marine,re.S)
assert bbox
areas=re.findall(r'\{\s*([-\d.]+),\s*([-\d.]+),\s*([-\d.]+),\s*([-\d.]+)\s*\}',bbox.group(1))
assert len(areas)>=16,len(areas)  # Later versions may add bounded regional boxes
for region in areas:
    a,b,c,d=map(float,region)
    assert -90<=a<c<=90 and -180<=b<d<=180
    assert (c-a)*(d-b)<=100,(region,'exceeds anonymous area budget')
radar=source('GevMarineRadarView.java')
assert 'animatedXY' in radar and 'lastByMmsi' in radar
assert 'p.lastObserved>from.lastObserved' in radar and 'postInvalidateDelayed(50L)' in radar
assert 'AIS FIXES / SMOOTHED TWO-REPORT MOTION' in radar
assert 'if(drawn++>=160)' not in radar
assert 'GevMarineRadarView.Point(i,ship.lat,ship.lon,ship.observed,ship.name,ship.mmsi)' in marine
news=source('Duwm1670NewsAtlasActivity.java')
assert 'LOAD MORE RECEIVED NEWS' in news
catalog=json.loads((P/'app/src/main/assets/duwm_news_200_region_sources.json').read_text())['sources']
assert len(catalog)==200
main=source('OperationsMainActivity.java')
assert '"1672 GLOBAL MISSION"' in main and 'earth=new OperationsGlobeView(this)' in main
status=source('RunningballV25Sources.java')
assert 'Open Waters public AIS / configured gateway' in status
protected=json.loads((P/'DUWM_REAL_SOURCE_CHANGE_REPORT.json').read_text())['unmodified_source_components']
for name,sha in protected.items():
    assert hashlib.sha256((J/name).read_bytes()).hexdigest()==sha,name+' changed unexpectedly'
print('PASS DUWM 1672: uncapped map sampling, user refresh, 16 legal public AIS areas, vessel interpolation based on TWO received fixes, scrolling, news pagination, preserved globe and source integrity.')
print('NOT VERIFIED: GitHub APK compilation, provider availability, licensed deployment, on-device performance.')
