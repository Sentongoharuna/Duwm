package com.sentongoharuna.worldsituationroom;

/** Source-only unit test for auto-follow deduplication and age guards. */
public final class Duwm1683FixTrackerTest {
    public static void main(String[] args) {
        Duwm1683FixTracker t = new Duwm1683FixTracker();
        long now = 1780500000000L;
        t.seed("air:abc", now - 50_000L);
        if (t.acceptNew("air:abc",now - 50_000L,now)) throw new AssertionError("seed replayed");
        if (!t.acceptNew("air:abc",now - 10_000L,now)) throw new AssertionError("fresh update rejected");
        if (t.acceptNew("air:abc",now - 10_000L,now)) throw new AssertionError("duplicate accepted");
        if (t.acceptNew("ship:xy",now - 900_001L,now)) throw new AssertionError("stale position accepted");
        if (t.acceptNew("ship:xy",now + 60_001L,now)) throw new AssertionError("future position accepted");
        if (!t.acceptNew("ship:xy",now - 2000L,now)) throw new AssertionError("fresh vessel rejected");
        t.clear();
        if (!t.acceptNew("air:abc",now - 10_000L,now)) throw new AssertionError("clear failed");
        System.out.println("PASS 1683 real-fix tracker: accepted fresh updates and rejected cached, stale or future fixes");
    }
}
