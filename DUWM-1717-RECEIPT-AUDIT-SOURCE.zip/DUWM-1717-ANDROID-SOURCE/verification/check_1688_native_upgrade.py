"""1688 source lineage gate: proves native files changed from FIX1 and original globe preserved.
This checks source-level structure and content, not actual device UI or provider availability.
"""
from pathlib import Path
import hashlib, json, re, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
base_sha='08c812f50fda13734bed7a3896a981387542c4db66fc468ba693d50fdd7ffa58'
must_change=['Duwm1166NewsDeskActivity.java', 'Duwm1166RadioAtlasActivity.java', 'Duwm1670FlightMapActivity.java', 'GevMarineActivity.java', 'MediaDeskActivity.java', 'Duwm1671SourceStatusActivity.java', 'Duwm1687MissionBoard.java', 'Duwm1687Console.java', 'Duwm1687WorkspaceActivity.java', 'MainActivity.java', 'Duwm1687ShareCard.java']
must_preserve=['SatelliteMapView.java','DuWorldApplication.java']
shas={'Duwm1166NewsDeskActivity.java': '777dbeb129ee67df84b63a11a7e677f20e51027530d06b1014f2f3dea5b586fe', 'Duwm1166RadioAtlasActivity.java': '1079e555ad8521b63caa71560b4976776c1eb00a4b17425dfea59db89bf447b8', 'Duwm1670FlightMapActivity.java': '7f23dc266c1364f2cbeadbb6322cf1f4b8610f81308f77d91e747df878950c26', 'GevMarineActivity.java': 'de6f5835029b55c7af0901acf1005ffdf9fa01419ab04868e0d9d3097d8dc9a0', 'MediaDeskActivity.java': '6cfa8ae8bc1c3dcc8bc28c879e902a1623eeb47e198107345014fb728cb42d3d', 'Duwm1671SourceStatusActivity.java': 'f7302b91263024758a439452df87d09b9aeb47ddf35ad8b7cd50423e2f9592cb', 'Duwm1687MissionBoard.java': 'bacbd4f9de9cb8e3b9a3a762bb130752db700d7e28fc064dd0e34d425b371362', 'Duwm1687Console.java': '3357d1ea541dd51af1155d939283debf2b4925985d876ac183e1fcd80eaab8b0', 'Duwm1687WorkspaceActivity.java': '6c98033c9c0d878d95666464b03a4bce6c091c00a275a5236a46ae7f415b9dc3', 'MainActivity.java': '37bc51ab46e937599b58b1b0c02f74a2782332b6144b26e6bf1b6683ebfa5294', 'Duwm1687ShareCard.java': '17b922e23fa9b2d089b3a6473ad3932a16a781560ee307094ae2c22a79ef1780', 'SatelliteMapView.java': 'cf069e2f0aabfcb17f3b151382f5ceea72413ff93f8486084ecdba0dc3113279', 'DuWorldApplication.java': '7869315928d42ab3e16466cbae95646f768647441e03fb2da22abcfea6e6539c'}
checks={'sourceChecks':{},'identity':{},'summary':{}}
for name in must_change+must_preserve:
    data=(j/name).read_bytes()
    digest=hashlib.sha256(data).hexdigest()
    if name in must_change:
        assert digest!=shas[name],name+' unchanged from 1687 FIX1; refused cosmetic version bump'
    else:
        assert digest==shas[name],name+' original globe or app bootstrap has been replaced'
    checks['sourceChecks'][name]={'modifiedFrom1687':digest!=shas[name],'sha256':digest}
gradle=(root/'app/build.gradle.kts').read_text()
strings=(root/'app/src/main/res/values/strings.xml').read_text()
assert 'versionName = "1688"' in gradle
assert 'versionCode = 168800' in gradle
assert 'applicationId = "com.sentongoharuna.worldsituationroom.rb2live25"' in gradle
assert '<string name="app_name">DUWM 1688 • DEVELOP.UGANDA</string>' in strings
assert 'DUWM 1678 • DEVELOP.UGANDA' not in strings
meta=json.loads((root/'app/src/main/assets/duwm_release_ui.json').read_text())
assert meta['uiRevision']=='1688' and meta['uiVersionCode']==168800
assert meta['singleOriginalGlobe'] is True
catalog=(j/'Duwm1683DeskCatalog.java').read_text()
assert sum(l.lstrip().startswith('d("') for l in catalog.splitlines())==19
main=(j/'MainActivity.java').read_text()
assert main.count('mapView = new SatelliteMapView(this);')==1
assert '1688 / ALL 19 DESKS' in main and '1688 SHARE CARD' in main
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
assert '<activity android:name=".Duwm1687WorkspaceActivity"' in manifest
assert 'DUWM 1688 Operations' in manifest
assert 'DUWM 1687 Operations' not in manifest
page=(j/'Duwm1685PageUpgrade.java').read_text()
assert 'Duwm1687Console.page(a,d)' in page
assert 'a.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)' not in page
console=(j/'Duwm1687Console.java').read_text()
assert 'single-line proof rail' in console and 'RECEIPT  ' in console
news=(j/'Duwm1166NewsDeskActivity.java').read_text()
assert 'searchText' in news and 'oldestFirst' in news and 'Search real headlines' in news
assert 'n.imageUrl.startsWith("https://")' in news
radio=(j/'Duwm1166RadioAtlasActivity.java').read_text()
for phrase in ['stationVisible(s)','requestGeneration','playingStation','PAUSE / RESUME','MAP FILTER:','atlas.invalidate()']:
    assert phrase in radio,'radio: '+phrase
flight=(j/'Duwm1670FlightMapActivity.java').read_text()
for phrase in ['pairsOnly','pin.genuinePair()','EXPAND MAP','liveMapParams.height','OpenSky']:
    assert phrase.lower() in flight.lower(),'aircraft: '+phrase
marine=(j/'GevMarineActivity.java').read_text()
for phrase in ['showRecentOnly','OPTIONAL AIS GATEWAY SETTINGS','EXPAND SEA MAP','CENTRE SEA MAP ON SELECTED','GevMarineMath.freshness']:
    assert phrase in marine,'marine: '+phrase
media=(j/'MediaDeskActivity.java').read_text()
for phrase in ['largePlayer','EXPAND PLAYER','visibleSourceCount','mediaFullScreenButton','cameraView.setLayoutParams']:
    assert phrase in media,'media: '+phrase
health=(j/'Duwm1671SourceStatusActivity.java').read_text()
for phrase in ['OPEN AIRCRAFT MAP','OPEN MARITIME AIS MAP','OPEN NEWSROOM','MainActivity.class']:
    assert phrase in health,'source health: '+phrase
assert 'OperationsMainActivity.class' not in health,'Source Health must not return to legacy second globe'
assert not any('new SatelliteMapView' in (j/n).read_text() for n in must_change if n!='MainActivity.java'),'A new globe was added in a native page'
checks['identity']={'appLabel':'DUWM 1688 • DEVELOP.UGANDA','versionCode':168800,'versionName':'1688','package':'com.sentongoharuna.worldsituationroom.rb2live25'}
checks['summary']={'baseZipSha256':base_sha,'changedJavaFiles':len(must_change),'preservedGlobe':True,'deskRoutes':19,'apksBuiltHere':False}
print('PASS 1688 NATIVE: 6 modified original native activities, not a relabelled 1678/1687 screen')
print('PASS 1688 SHARED: original globe preserved; native source rail, search board, workspace and share identity advanced')
print('PASS 1688 SOURCE LINEAGE: original 1687 FIX1 file digests pinned; app label/version/package validated')
print('NOT VERIFIED: Android Gradle compile, APK on device, live third-party data or streaming.')
