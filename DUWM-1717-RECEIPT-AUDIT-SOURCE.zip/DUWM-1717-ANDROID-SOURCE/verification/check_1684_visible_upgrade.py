"""Regression gate: 1684 must visibly change every sector, route native fullscreen and share images."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
main=(src/'MainActivity.java').read_text()
opt=(src/'DuwmOptionsActivity.java').read_text()
full=(src/'Duwm1683DeskFullScreenActivity.java').read_text()
visual=(src/'Duwm1684SectorVisual.java').read_text()
upgrade=(src/'Duwm1684PageUpgrade.java').read_text()
share=(src/'Duwm1684ShareCard.java').read_text()
app=(src/'DuWorldApplication.java').read_text()
cat=(src/'Duwm1683DeskCatalog.java').read_text()
assert len([x for x in cat.splitlines() if x.lstrip().startswith('d("')])==19
assert 'Duwm1684PageUpgrade.install(this);' in app
assert 'private static void enhance(Activity a)' in upgrade and 'makeHero(a,d)' in upgrade
assert 'a instanceof MainActivity' in upgrade and 'Duwm1683DeskCatalog.find(a)' in upgrade
assert 'new Duwm1684SectorVisual(this,d.title,false)' in opt
assert 'new Duwm1684SectorVisual(this,desk.title,true)' in full
assert 'Duwm1684ShareCard.share(this,desk)' in full
assert 'Bitmap.createBitmap(W,H,Bitmap.Config.ARGB_8888)' in share
assert 'W=1080,H=1350' in share
assert 'FLAG_GRANT_READ_URI_PERMISSION' in share and '.sharecards/' in share
assert 'R.drawable.develop_uganda_logo' in share
assert 'not a plotted track' in full
for mode in ['AVIATION','MARITIME','SEISMIC','WEATHER','SPACE','RADIO','TELEVISION','CAMERAS','NEWSROOM','MARKETS','GEOGRAPHY','SOURCE HEALTH','EVIDENCE']:
    assert f'"{mode}"' in visual,mode
# Original MainActivity still has ONE SatelliteMapView creation and one home launcher.
assert main.count('new SatelliteMapView(this)')==1
assert 'open1684Desk(7)' in main and 'open1684Desk(9)' in main and 'open1684Desk(10)' in main
assert 'open1684Desk(11)' in main and 'open1684Desk(1)' in main
assert 'private void open1684PulseDesk(Signal.Layer layer)' in main
assert 'startActivity(Duwm1683DeskCatalog.intent(this,Duwm1683DeskCatalog.ALL[index]))' in main
assert '"DESKS 19"' in main
assert 'versionCode = 168400' in (root/'app/build.gradle.kts').read_text()
print('PASS DUWM 1684 MAJOR: 19 original native desks, distinct sector previews, full-screen home navigation, images shared from actual receipts, original single globe preserved')
