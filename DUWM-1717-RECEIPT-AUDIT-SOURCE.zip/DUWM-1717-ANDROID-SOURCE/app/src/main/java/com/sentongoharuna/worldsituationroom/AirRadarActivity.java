package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Interactive RADAR from the same ADS-B snapshot as RUNNINGBALL2 AIR COMMAND V4.
 *  This screen never invents positions or interpolated tracks. Wallpaper is not modified.
 */
public final class AirRadarActivity extends Activity {
    private static final int BG = Color.rgb(5, 13, 34);
    private static final int PANEL = Color.rgb(13, 31, 61);
    private static final int CYAN = Color.rgb(85, 139, 223);
    private static final int LIGHT = Color.rgb(225, 235, 255);
    private static final int MUTED = Color.rgb(76, 120, 196);
    private static final int GREEN = Color.rgb(85, 139, 223);
    private static final int AMBER = Color.rgb(85, 139, 223);
    private double KLAT=0.0d, KLON=0.0d;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refreshCache = new Runnable() {
        @Override public void run() {
            if (!foreground) return;
            reload();
            handler.postDelayed(this, 3_000L);
        }
    };
    private boolean foreground;
    private Radar radar;
    private TextView summary, age, detail, detailButton;
    private JSONArray records = new JSONArray();
    private long observationMs;
    private String chosenHex = "";
    private int limitNm = 250;
    private int reportedCount;
    private String providerError = "";

    private int dp(float d) {return Math.round(getResources().getDisplayMetrics().density*d);}
    private TextView text(String s, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);v.setTextSize(sp);v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }
    private GradientDrawable panel(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);d.setCornerRadius(dp(11));
        d.setStroke(dp(1),Color.rgb(40, 76, 135));
        return d;
    }
    private static boolean finite(double d) {return !Double.isNaN(d)&&!Double.isInfinite(d);}
    private static String number(double n,String unit) {
        return finite(n)?String.format(Locale.US,"%.0f%s",n,unit):"—";
    }
    private static String timeUtc(long ms) {
        return Duwm1674TimeGuard.utc(ms);
    }
    private TextView action(String label, Runnable fn) {
        TextView b = text(label, 12, CYAN, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(panel(PANEL));
        b.setPadding(dp(9),dp(10),dp(9),dp(10));
        b.setOnClickListener(v -> fn.run());
        return b;
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);RunningballV17Insets.install(this);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(13),dp(12),dp(13),dp(12));
        TextView heading = text("✈  AIRCRAFT RADAR  /  RUNNINGBALL2 V5",15,CYAN,true);
        root.addView(heading,new LinearLayout.LayoutParams(-1,dp(38)));
        root.addView(action("WORLD LOCATION  /  CHANGE REGION",()->startActivity(new Intent(this,RunningballWorldExplorerActivity.class))),new LinearLayout.LayoutParams(-1,dp(39)));
        summary = text("AWAITING AIRCRAFT REPORT",13,LIGHT,true);
        root.addView(summary,new LinearLayout.LayoutParams(-1,dp(29)));
        age = text("SOURCE ADSB.LOL  •  OBSERVED POSITIONS",10,MUTED,false);
        root.addView(age,new LinearLayout.LayoutParams(-1,dp(35)));
        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        for (int range:new int[]{250,125,60}) {
            TextView control = action(range+" NM",()->setRange(range));
            LinearLayout.LayoutParams c = new LinearLayout.LayoutParams(0,dp(40),1f);
            c.setMargins(0,0,dp(5),0);
            controls.addView(control,c);
        }
        root.addView(controls,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView contactsButton = action("CONTACTS  /  NEAREST 250 KM", () ->
                startActivity(new Intent(this, GevContactsActivity.class)));
        LinearLayout.LayoutParams contactsLayout = new LinearLayout.LayoutParams(-1, dp(42));
        contactsLayout.topMargin=dp(8);
        root.addView(contactsButton, contactsLayout);
        radar = new Radar();
        LinearLayout.LayoutParams map = new LinearLayout.LayoutParams(-1,0,1f);
        map.topMargin=dp(8);
        root.addView(radar,map);
        detail = text("SELECT AN AIRCRAFT MARKER TO VIEW REPORT DETAILS",12,LIGHT,false);
        detail.setPadding(dp(12),dp(10),dp(12),dp(7));
        detail.setBackground(panel(PANEL));
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1,dp(95));
        dl.topMargin=dp(9);root.addView(detail,dl);
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        detailButton = action("FLIGHT DETAILS",this::showDetail);
        actions.addView(detailButton,new LinearLayout.LayoutParams(0,dp(44),1f));
        TextView cockpitButton=action("COCKPIT",this::openCockpit);
        LinearLayout.LayoutParams cr=new LinearLayout.LayoutParams(0,dp(44),1f);
        cr.leftMargin=dp(7);actions.addView(cockpitButton,cr);
        TextView refresh = action("↻ REFRESH",this::requestRefresh);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0,dp(44),1f);
        rp.leftMargin=dp(7);
        actions.addView(refresh,rp);
        TextView share = action("SHARE", this::shareSnapshot);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        sp.leftMargin = dp(7);
        actions.addView(share,sp);
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(44));
        ap.topMargin=dp(9);
        root.addView(actions,ap);
        TextView earth=action("EARTH EXPLORER",this::openEarth);
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(37));ep.topMargin=dp(6);root.addView(earth,ep);
        TextView foot = text("OBSERVED DATA ONLY  ·  NO PREDICTED TRACKS",10,MUTED,false);
        foot.setGravity(Gravity.CENTER);
        root.addView(foot,new LinearLayout.LayoutParams(-1,dp(32)));
        setContentView(root);
        radar.setContentDescription("Aircraft radar with selectable reported flight markers. Range 250 nautical miles.");
        reload();
    }
    private void setRange(int value){limitNm=value;chosenHex="";reload();}
    private void requestRefresh(){
        Intent i=new Intent(this,AirOperationsWidgets.Command.class);
        i.setAction("com.sentongoharuna.worldsituationroom.AIR_WIDGET_REFRESH");
        sendBroadcast(i);
        age.setText("REFRESH REQUESTED · DATA MAY UPDATE AFTER PROVIDER RESPONSE");
    }
    private void reload(){
        KLAT=RunningballWorldTarget.lat(this);KLON=RunningballWorldTarget.lon(this);
        JSONObject data=AirOperationsWidgets.lastData(this);
        records=data.optJSONArray("items");
        if(records==null)records=new JSONArray();
        reportedCount=data.optInt("count",0);
        observationMs=data.optLong("time",0);
        providerError=getSharedPreferences("air_widget_v2",MODE_PRIVATE).getString("last_error","");
        long delay=observationMs<=0?Long.MAX_VALUE:Math.max(0,System.currentTimeMillis()-observationMs);
        int shown=radar==null?0:radar.countWithinRange();
        summary.setText(RunningballWorldTarget.label(this)+"  ·  "+shown+" PLOTTED / "+reportedCount+" REPORTED");
        boolean fresh=observationMs>0&&delay<=180_000L&&providerError.isEmpty();
        String state=observationMs<=0?"NO REPORT":fresh?"RECENT REPORT":"CACHED / STALE";
        age.setText(state+"  ·  "+timeUtc(observationMs)+"  ·  ADSB.LOL"+
                (providerError.isEmpty()?"":"  ·  "+providerError));
        age.setTextColor(fresh?GREEN:AMBER);
        if(radar!=null)radar.invalidate();
        updateDetails();
    }
    private void select(String hex){chosenHex=hex;updateDetails();radar.invalidate();}
    private void updateDetails(){
        JSONObject x=findSelected();
        if(x==null){detail.setText("TOUCH A REPORTED AIRCRAFT MARKER TO INSPECT\nDISPLAYED POSITIONS ARE NOT PREDICTED.");return;}
        detail.setText(x.optString("flight",x.optString("hex","AIRCRAFT"))+"  /  "+x.optString("hex","")+"\n"+
            "DIST "+number(x.optDouble("nm",Double.NaN)," NM")+"   ALT "+
            (x.optBoolean("ground",false)?"GROUND":number(x.optDouble("alt",Double.NaN)," FT"))+"\n"+
            "SPEED "+number(x.optDouble("speed",Double.NaN)," KT")+"   HDG "+
            number(x.optDouble("heading",Double.NaN),"°")+"   ·  SNAPSHOT");
    }
    private JSONObject findSelected(){
        for(int i=0;i<records.length();i++){
            JSONObject x=records.optJSONObject(i);
            if(x!=null&&!chosenHex.isEmpty()&&chosenHex.equals(x.optString("hex","")))return x;
        }
        return null;
    }
    private void shareSnapshot() {
        if (observationMs <= 0L) {
            detail.setText("NO OBSERVED AIRCRAFT DATA TO SHARE. REFRESH FIRST.");
            return;
        }
        long elapsed = Math.max(0L, System.currentTimeMillis() - observationMs);
        boolean fresh = elapsed <= 180_000L && providerError.isEmpty();
        JSONObject selected = findSelected();
        java.util.LinkedHashMap<String,String> facts = new java.util.LinkedHashMap<>();
        facts.put("RADAR COVERAGE", limitNm + " nautical miles around " + RunningballWorldTarget.label(this));
        facts.put("AIRCRAFT REPORTED", Integer.toString(reportedCount));
        facts.put("AIRCRAFT IN SELECTED RANGE", Integer.toString(radar.countWithinRange()));
        if (selected != null) {
            facts.put("ICAO HEX", selected.optString("hex", "UNAVAILABLE"));
            facts.put("DISTANCE", number(selected.optDouble("nm", Double.NaN), " NM"));
            facts.put("ALTITUDE", selected.optBoolean("ground", false) ? "GROUND" :
                      number(selected.optDouble("alt", Double.NaN), " FT"));
            facts.put("GROUND SPEED", number(selected.optDouble("speed", Double.NaN), " KT"));
            facts.put("HEADING", number(selected.optDouble("heading", Double.NaN), "°"));
        }
        String status = fresh ? "RECENT REPORT" : "CACHED / STALE";
        String title = selected == null ? RunningballWorldTarget.label(this) + " AIRCRAFT SNAPSHOT" :
                selected.optString("flight", selected.optString("hex", "AIRCRAFT"));
        String summary = selected == null ?
                "Aircraft observed within the selected radar coverage; positions are not predicted." :
                "One reported aircraft position with source timestamp and telemetry.";
        double latitude = selected == null ? Double.NaN : selected.optDouble("lat", Double.NaN);
        double longitude = selected == null ? Double.NaN : selected.optDouble("lon", Double.NaN);
        ShareCardRenderer.share(this, new ShareCardData(
                title, summary, status, fresh ? "RECENT OBSERVATION" : "DELAYED OR CACHED",
                "AVIATION", RunningballWorldTarget.label(this), 1, "ADSB.LOL", "https://adsb.lol/",
                observationMs, latitude, longitude, facts,
                fresh ? Color.rgb(85, 139, 223) : Color.rgb(85, 139, 223),
                "Position report only. Not an air-traffic control or navigation service."));
    }
    private void openCockpit(){
        if(findSelected()==null){detail.setText("SELECT AN AIRCRAFT MARKER FIRST");return;}
        Intent i=new Intent(this,GevCockpitActivity.class);
        i.putExtra("air_hex",chosenHex);startActivity(i);
    }
    private void openEarth(){
        Intent i=new Intent(this,GevEarthExploreActivity.class);
        JSONObject selected=findSelected();
        if(selected!=null){double a=selected.optDouble("lat",Double.NaN),b=selected.optDouble("lon",Double.NaN);
            if(GevEarthCoordinates.valid(a,b)){i.putExtra("geo_lat",a);i.putExtra("geo_lon",b);}}
        startActivity(i);
    }
    private void showDetail(){
        if(findSelected()==null){detail.setText("SELECT AN AIRCRAFT MARKER FIRST");return;}
        Intent i=new Intent(this,AirFlightDetailsActivity.class);
        i.putExtra("air_hex",chosenHex);
        startActivity(i);
    }
    @Override protected void onResume(){super.onResume();foreground=true;handler.removeCallbacks(refreshCache);handler.post(refreshCache);}
    @Override protected void onPause(){foreground=false;handler.removeCallbacks(refreshCache);super.onPause();}
    @Override protected void onDestroy(){handler.removeCallbacks(refreshCache);super.onDestroy();}

    private final class Radar extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path arrow=new Path();
        private final float[] positions=new float[2*8];
        private final String[] identities=new String[8];
        private int drawn;
        Radar(){super(AirRadarActivity.this);setBackground(panel(PANEL));setClickable(true);}
        private double bearing(double lat,double lon){
            double dlon=Math.toRadians(lon-KLON);
            double y=Math.sin(dlon)*Math.cos(Math.toRadians(lat));
            double x=Math.cos(Math.toRadians(KLAT))*Math.sin(Math.toRadians(lat))-
                    Math.sin(Math.toRadians(KLAT))*Math.cos(Math.toRadians(lat))*Math.cos(dlon);
            return Math.atan2(y,x);
        }
        private int countWithinRange(){
            int n=0;
            for(int i=0;i<records.length() && i<8;i++){
                JSONObject item=records.optJSONObject(i);
                if(item!=null && item.optDouble("nm",Double.NaN)<=limitNm &&
                        finite(item.optDouble("lat",Double.NaN))&&finite(item.optDouble("lon",Double.NaN)))n++;
            }
            return n;
        }
        @Override protected void onDraw(Canvas canvas){
            super.onDraw(canvas);
            float cx=getWidth()/2f,cy=getHeight()/2f;
            float radius=Math.min(getWidth(),getHeight())*.43f;
            p.setStyle(Paint.Style.FILL);p.setColor(PANEL);canvas.drawColor(PANEL);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));p.setColor(Color.rgb(40, 76, 135));
            for(int ring=1;ring<=4;ring++)canvas.drawCircle(cx,cy,radius*ring/4f,p);
            canvas.drawLine(cx-radius,cy,cx+radius,cy,p);
            canvas.drawLine(cx,cy-radius,cx,cy+radius,p);
            p.setStyle(Paint.Style.FILL);p.setTextSize(dp(11));p.setColor(CYAN);
            canvas.drawText("N",cx-dp(4),cy-radius-dp(8),p);
            canvas.drawText("E",cx+radius+dp(4),cy+dp(4),p);
            p.setColor(GREEN);canvas.drawCircle(cx,cy,dp(4),p);
            p.setColor(MUTED);p.setTextSize(dp(10));
            canvas.drawText(limitNm+" NM",dp(12),dp(24),p);
            canvas.drawText(RunningballWorldTarget.label(AirRadarActivity.this),dp(12),getHeight()-dp(15),p);
            drawn=0;
            for(int i=0;i<records.length()&&i<8;i++){
                JSONObject x=records.optJSONObject(i);if(x==null)continue;
                double dist=x.optDouble("nm",Double.NaN),lat=x.optDouble("lat",Double.NaN),lon=x.optDouble("lon",Double.NaN);
                if(!finite(dist)||!finite(lat)||!finite(lon)||dist>limitNm)continue;
                double az=bearing(lat,lon);
                float px=cx+(float)(Math.sin(az)*dist/limitNm*radius);
                float py=cy-(float)(Math.cos(az)*dist/limitNm*radius);
                if(drawn>=identities.length)break;
                positions[drawn*2]=px;positions[drawn*2+1]=py;
                identities[drawn]=x.optString("hex","");drawn++;
                boolean focused=identities[drawn-1].equals(chosenHex);
                int color=focused?Color.WHITE:x.optBoolean("ground",false)?MUTED:GREEN;
                p.setColor(color);p.setStyle(Paint.Style.FILL);
                canvas.drawCircle(px,py,focused?dp(7):dp(4),p);
                double track=x.optDouble("heading",Double.NaN);
                if(finite(track) && !x.optBoolean("ground",false)){
                    // Heading arrow is an orientation cue, not a projected future location.
                    double angle=Math.toRadians(track);float len=dp(13);
                    float tx=px+(float)Math.sin(angle)*len,ty=py-(float)Math.cos(angle)*len;
                    p.setStrokeWidth(dp(2));p.setStyle(Paint.Style.STROKE);canvas.drawLine(px,py,tx,ty,p);
                    p.setStyle(Paint.Style.FILL);
                }
                p.setTextSize(dp(10));p.setColor(focused?Color.WHITE:LIGHT);
                String name=x.optString("flight",x.optString("hex","AIR"));
                if(name.length()>10)name=name.substring(0,10);
                canvas.drawText(name,px+dp(9),py-dp(6),p);
            }
            if(drawn==0){p.setTextSize(dp(13));p.setColor(MUTED);p.setTextAlign(Paint.Align.CENTER);
                canvas.drawText(observationMs<=0?"AWAITING AIRCRAFT REPORT":"NO REPORTED AIRCRAFT IN VIEW",cx,cy+dp(35),p);
                p.setTextAlign(Paint.Align.LEFT);}
        }
        @Override public boolean onTouchEvent(MotionEvent event){
            if(event.getActionMasked()==MotionEvent.ACTION_UP){
                int best=-1;float closest=dp(28);
                for(int i=0;i<drawn;i++){
                    float dx=event.getX()-positions[i*2],dy=event.getY()-positions[i*2+1];
                    float d=(float)Math.hypot(dx,dy);
                    if(d<closest){closest=d;best=i;}
                }
                if(best>=0)select(identities[best]);
                performClick();return true;
            }
            return true;
        }
        @Override public boolean performClick(){super.performClick();return true;}
    }
}
