package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

/** Visibly upgraded 1686 command surface for all nineteen existing Android Activity screens.
 * Inherited maps and media players remain functional and are not replaced with mock display data. */
public final class Duwm1686Console {
    private Duwm1686Console(){}
    private static int dp(Activity a,float n){return (int)(a.getResources().getDisplayMetrics().density*n+.5f);}
    private static TextView text(Activity a,String s,int size,int color,boolean bold){
        TextView t=new TextView(a);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        t.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",Typeface.NORMAL));
        t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(dp(a,7),dp(a,6),dp(a,7),dp(a,6));return t;
    }
    private static GradientDrawable surface(Activity a,boolean high){
        GradientDrawable d=new GradientDrawable();d.setColor(high?DuwmUnifiedTheme.PANEL_SELECTED:DuwmUnifiedTheme.PANEL);
        d.setCornerRadius(dp(a,11));d.setStroke(dp(a,1),high?DuwmUnifiedTheme.ACCENT:DuwmUnifiedTheme.BORDER);return d;
    }
    private static void button(Activity a,LinearLayout parent,String text,Runnable onClick,int weight){
        TextView b=text(a,text,12,DuwmUnifiedTheme.ACCENT_BRIGHT,true);b.setGravity(Gravity.CENTER);
        b.setBackground(surface(a,true));b.setOnClickListener(v->onClick.run());b.setContentDescription(text);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(a,48),weight);lp.rightMargin=dp(a,6);parent.addView(b,lp);
    }
    public static View page(Activity a,Duwm1683DeskCatalog.Desk desk){
        Duwm1685ReceiptHistory.capture(a,desk);
        Duwm1684DeskDiagnostics.Snapshot s=Duwm1684DeskDiagnostics.read(a,desk);
        LinearLayout root=new LinearLayout(a);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(a,9),dp(a,9),dp(a,9),dp(a,9));root.setBackground(surface(a,false));
        LinearLayout mast=new LinearLayout(a);mast.setOrientation(LinearLayout.HORIZONTAL);mast.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(mast,new LinearLayout.LayoutParams(-1,dp(a,37)));
        TextView headline=text(a,"1686 / "+Duwm1684SectorVisual.mode(desk.title)+" INTELLIGENCE",12,DuwmUnifiedTheme.ACCENT_BRIGHT,true);
        mast.addView(headline,new LinearLayout.LayoutParams(0,-1,1));
        TextView full=text(a,"FULL SCREEN  ›",11,DuwmUnifiedTheme.ACCENT_BRIGHT,true);
        full.setGravity(Gravity.CENTER);full.setBackground(surface(a,true));
        mast.addView(full,new LinearLayout.LayoutParams(dp(a,114),-1));
        full.setOnClickListener(v->Duwm1686WorkspaceActivity.open(a,desk));
        TextView title=text(a,desk.title.toUpperCase(Locale.US),22,DuwmUnifiedTheme.TEXT,true);
        title.setSingleLine(true);title.setEllipsize(android.text.TextUtils.TruncateAt.END);root.addView(title);
        Duwm1684SectorVisual visual=new Duwm1684SectorVisual(a,desk.title,true);
        LinearLayout.LayoutParams illustration=new LinearLayout.LayoutParams(-1,dp(a,127));illustration.bottomMargin=dp(a,7);root.addView(visual,illustration);
        LinearLayout stats=new LinearLayout(a);stats.setGravity(Gravity.CENTER_VERTICAL);stats.setBackground(surface(a,true));
        LinearLayout.LayoutParams statsLp=new LinearLayout.LayoutParams(-1,dp(a,68));root.addView(stats,statsLp);
        TextView one=text(a,"ACTUAL SOURCE\n"+s.state,12,DuwmUnifiedTheme.TEXT,true);
        one.setTag("duwm1685-receipt-live");one.setMaxLines(3);stats.addView(one,new LinearLayout.LayoutParams(0,-1,1));
        TextView two=text(a,"RECEIVED VALUE\n"+s.count,12,DuwmUnifiedTheme.ACCENT_BRIGHT,true);
        stats.addView(two,new LinearLayout.LayoutParams(0,-1,1));
        TextView three=text(a,"RECEIPT TIME\n"+s.received,10,DuwmUnifiedTheme.MUTED,true);
        three.setMaxLines(3);three.setTag("duwm1685-receipt-live-time");stats.addView(three,new LinearLayout.LayoutParams(0,-1,1));
        TextView status=text(a,"PROVIDER / "+s.provider+"  •  "+Duwm1685ReceiptHistory.label(a,desk),11,DuwmUnifiedTheme.MUTED,false);
        status.setMaxLines(3);root.addView(status);
        LinearLayout buttons=new LinearLayout(a);root.addView(buttons,new LinearLayout.LayoutParams(-1,dp(a,50)));
        button(a,buttons,"DETAIL WORKSPACE",()->Duwm1686WorkspaceActivity.open(a,desk),2);
        button(a,buttons,"SHARE 9:16",()->Duwm1686ShareCard.share(a,desk),1);
        button(a,buttons,"SOURCE",()->Duwm1683DeskDetailKit.show(a,desk),1);
        TextView note=text(a,"ORIGINAL NATIVE MAP / PLAYER BELOW  •  NO SYNTHETIC FIXES",10,DuwmUnifiedTheme.MUTED,false);
        root.addView(note);return root;
    }
    public static View compact(Activity a,Duwm1683DeskCatalog.Desk desk){
        Duwm1684DeskDiagnostics.Snapshot s=Duwm1684DeskDiagnostics.read(a,desk);
        LinearLayout root=new LinearLayout(a);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(a,8),dp(a,7),dp(a,8),dp(a,6));
        root.setBackground(surface(a,true));
        LinearLayout row=new LinearLayout(a);row.setGravity(Gravity.CENTER_VERTICAL);root.addView(row,new LinearLayout.LayoutParams(-1,dp(a,37)));
        TextView name=text(a,"1686 / "+desk.title.toUpperCase(Locale.US),13,DuwmUnifiedTheme.TEXT,true);
        name.setSingleLine(true);name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        row.addView(name,new LinearLayout.LayoutParams(0,-1,1));
        button(a,row,"OPEN WORKSPACE",()->Duwm1686WorkspaceActivity.open(a,desk),1);
        TextView state=text(a,"SOURCE "+s.state+"  /  "+s.count+"  /  "+s.received,11,DuwmUnifiedTheme.ACCENT_BRIGHT,false);
        root.addView(state);return root;
    }
}
