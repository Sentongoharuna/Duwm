package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.os.SystemClock;
import android.view.View;
import java.util.Locale;

/** Independent, source-truth LED. Animation conveys a fresh *received* record, never fake traffic. */
public final class Duwm1166SignalView extends View {
  public static final int UNKNOWN=0, FRESH=1, STALE=2, ERROR=3, FETCHING=4, REFERENCE=5;
  private int status=UNKNOWN;private String kind="SOURCE";
  private long sourceTime=0L,receiptTime=0L;
  private final Paint p=new Paint(3);
  public Duwm1166SignalView(Context c){super(c);setMinimumWidth(dp(22));setMinimumHeight(dp(22));setContentDescription("No verified source signal");}
  private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
  public void source(String type,long observedAt,long receivedAt,boolean isFetching,boolean hasError){
    kind=type==null?"SOURCE":type.toUpperCase(Locale.US);sourceTime=observedAt;receiptTime=receivedAt;
    long now=System.currentTimeMillis();
    if(hasError)status=ERROR;
    else if(isFetching)status=FETCHING;
    else if(observedAt<=0 || receivedAt<=0 || observedAt>now+10*60*1000L)status=UNKNOWN;
    else if(now-receivedAt<=10*60*1000L && now-observedAt<=30*60*1000L)status=FRESH;
    else status=STALE;
    updateDescription();invalidate();
  }
  public void reference(){status=REFERENCE;updateDescription();invalidate();}
  private void updateDescription(){
    final String[] terms={"No verified data","Fresh source observation","Stale last observation","Source error","Refreshing source","Reference data"};
    setContentDescription(kind+": "+terms[status]+(sourceTime>0?" at "+sourceTime:""));
  }
  private long interval(){if(status==ERROR)return 2100L;if(status==STALE)return 2750L;
    if(kind.contains("AIR"))return 420L;if(kind.contains("SAT")||kind.contains("ISS"))return 1500L;
    if(kind.contains("VESSEL")||kind.contains("MARINE"))return 1800L;
    if(kind.contains("QUAKE")||kind.contains("ALERT"))return 520L;
    if(kind.contains("NEWS"))return 1100L;return 1250L;}
  @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);int color;
    switch(status){case FRESH:color=0xFF558BDF;break;case STALE:color=0xFF558BDF;break;
      case ERROR:color=0xFF558BDF;break;case FETCHING:color=0xFF558BDF;break;
      case REFERENCE:color=0xFFCFDEE2;break;default:color=0xFF284C87;}
    long now=SystemClock.uptimeMillis();float alpha=1f;
    boolean animate=isShown()&&(status==FRESH||status==STALE||status==ERROR||status==FETCHING);
    if(animate){double phase=(now%interval())*Math.PI*2.0/interval();alpha=.54f+.46f*(float)((1+Math.cos(phase))/2.0);}
    float r=Math.min(getWidth(),getHeight())*.22f,cx=getWidth()/2f,cy=getHeight()/2f;
    p.setColor(color);p.setStyle(Paint.Style.FILL);p.setAlpha((int)(75*alpha));canvas.drawCircle(cx,cy,r*1.9f,p);
    p.setAlpha((int)(255*alpha));canvas.drawCircle(cx,cy,r,p);p.setAlpha(255);
    if(animate)postInvalidateDelayed(95L);
  }
}
