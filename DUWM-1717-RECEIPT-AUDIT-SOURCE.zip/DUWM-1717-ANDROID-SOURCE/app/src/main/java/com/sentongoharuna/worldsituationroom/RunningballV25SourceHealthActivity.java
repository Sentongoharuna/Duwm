package com.sentongoharuna.worldsituationroom;
import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
/** Stage 1 truthful provider cache health: reading actual V24 stores, no mock figures. */
public final class RunningballV25SourceHealthActivity extends Activity {
  private final Handler ui=new Handler(Looper.getMainLooper());private boolean showing=false;
  private LinearLayout content;
  private final Runnable tick=new Runnable(){@Override public void run(){if(!showing)return;render();ui.postDelayed(this,10000L);}};
  private int dp(int a){return Math.round(a*getResources().getDisplayMetrics().density);}
  private TextView label(String s,int size,int color){TextView v=new TextView(this);v.setText(s);v.setTextColor(color);v.setTextSize(size);v.setPadding(dp(6),dp(5),dp(6),dp(5));return v;}
  @Override public void onCreate(Bundle b){super.onCreate(b);RunningballV17Insets.install(this);
    ScrollView outer=new ScrollView(this);outer.setBackgroundColor(0xFF041424);
    content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(13),dp(13),dp(13),dp(20));outer.addView(content);setContentView(outer);
  }
  @Override protected void onResume(){super.onResume();showing=true;ui.post(tick);}
  @Override protected void onPause(){showing=false;ui.removeCallbacks(tick);super.onPause();}
  private void render(){content.removeAllViews();TextView back=label("‹ BACK",14,0xFF558BDF);back.setMinHeight(dp(48));back.setOnClickListener(v->finish());content.addView(back);
    content.addView(label("V25 / SOURCE HEALTH",22,0xFFE0EAFE));
      TextView legacyRoute=label("OPEN LEGACY AIR DIAGNOSTICS  ›",13,0xFF558BDF);
      legacyRoute.setMinimumHeight(dp(48));
      legacyRoute.setContentDescription("Open original V15 source diagnostics and aircraft refresh");
      legacyRoute.setOnClickListener(v->startActivity(new Intent(this,RunningballV15SourceHealthActivity.class)));
      content.addView(legacyRoute);
    content.addView(label("Source times represent received cache, not necessarily observation time. Keys/paid providers require separate configuration.",12,0xFF558BDF));
    for(int i=0;i<RunningballV25Sources.IDS.length;i++){
      RunningballV25Sources.Result r=RunningballV25Sources.read(this,i);
      LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(7),dp(7),dp(7),dp(9));
      GradientDrawable bg=new GradientDrawable();bg.setColor(0xFF0C1B39);bg.setCornerRadius(dp(10));
      bg.setStroke(dp(1),r.status==RunningballV25Sources.Status.LIVE?0xFF558BDF:0xFF558BDF);card.setBackground(bg);
      card.addView(label(RunningballV25Sources.NAMES[i]+"  ·  "+r.status,14,0xFF558BDF));
      card.addView(label(r.value+"  /  "+r.display(),16,0xFFE0EAFE));
      card.addView(label("PROVIDER TIME: "+r.sourceAge()+" · LAST GOOD FETCH: "+r.age(),10,0xFFE0EAFE));
      card.addView(label("SOURCE: "+r.provider+"\nENDPOINT: "+r.endpoint+"\nCOVERAGE: "+r.coverage,11,0xFFE0EAFE));
      card.addView(label("LICENCE: "+RunningballV25Sources.RIGHTS[i],10,0xFF558BDF));
      if(!r.errorReason.isEmpty())card.addView(label("LAST ERROR: "+r.errorReason,11,0xFF558BDF));
      if(i==0){
        TextView world=label("OPEN WORLDWIDE AIRCRAFT / OPENSKY REPORTS  ›",12,0xFF558BDF);
        world.setMinHeight(dp(48));world.setContentDescription("Open global OpenSky aircraft reports, separate from regional ADS-B");
        world.setOnClickListener(v->startActivity(new android.content.Intent(this,RunningballV25WorldwideAirActivity.class)));
        card.addView(world);
      }
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(9);content.addView(card,lp);
    }
    content.addView(label("NO ARTIFICIAL COUNTS · SOURCE ACCESS/COMMERCIAL RIGHTS NOT CERTIFIED",11,0xFF558BDF));
  }
}
