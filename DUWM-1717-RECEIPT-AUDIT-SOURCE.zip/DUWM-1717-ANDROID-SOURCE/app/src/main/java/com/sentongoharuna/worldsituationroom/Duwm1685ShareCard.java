package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.View;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Locale;

/** Full 1080x1920 social-ready source cards for every native intelligence sector.
 * Chart and facts derive from receipts, never fictional weather tracks or fabricated values.
 */
public final class Duwm1685ShareCard {
    private static final int W=1080,H=1920;
    private static final int INK=0xFFE3EEFF,ACCENT=0xFF97BBF7,MUTED=0xFF94AAD2;
    private Duwm1685ShareCard(){}
    private static void say(Canvas c,String s,float x,float y,float size,int color,boolean bold){
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(color);p.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        p.setTextSize(size);c.drawText(s==null?"":s,x,y,p);
    }
    private static float para(Canvas c,String str,float x,float y,float maxWidth,int px,int color,int limit){
        if(str==null||str.trim().isEmpty())str="NOT REPORTED";
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setTextSize(px);
        ArrayList<String> lines=new ArrayList<>();StringBuilder cur=new StringBuilder();
        for(String word:str.replace('\n',' ').trim().split("\\s+")){
            String trial=cur.length()==0?word:cur+" "+word;
            if(p.measureText(trial)>maxWidth&&cur.length()>0){lines.add(cur.toString());cur=new StringBuilder(word);}
            else cur=new StringBuilder(trial);
        }
        if(cur.length()>0)lines.add(cur.toString());
        int count=Math.min(limit,lines.size());
        for(int i=0;i<count;i++)say(c,lines.get(i)+(i==count-1&&lines.size()>count?" …":""),x,y+px*1.35f*i,px,color,false);
        return y+count*px*1.35f;
    }
    private static void key(Canvas c,String title,String value,float y,int maxLines){
        say(c,title,85,y,25,ACCENT,true);para(c,value,85,y+45,900,34,INK,maxLines);
    }
    public static void share(Activity a,Duwm1683DeskCatalog.Desk desk){
        Bitmap bmp=null;
        try{
            Duwm1685ReceiptHistory.capture(a,desk);
            Duwm1684DeskDiagnostics.Snapshot data=Duwm1684DeskDiagnostics.read(a,desk);
            bmp=Bitmap.createBitmap(W,H,Bitmap.Config.ARGB_8888);
            Canvas canvas=new Canvas(bmp);canvas.drawColor(DuwmUnifiedTheme.BACKGROUND);
            Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(DuwmUnifiedTheme.PANEL);p.setStyle(Paint.Style.FILL);
            canvas.drawRoundRect(new RectF(37,39,1043,1873),39,39,p);
            p.setColor(DuwmUnifiedTheme.BORDER);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);
            canvas.drawRoundRect(new RectF(37,39,1043,1873),39,39,p);p.setStyle(Paint.Style.FILL);
            try{
                Drawable logo=a.getDrawable(R.drawable.develop_uganda_logo);
                if(logo!=null){logo.setBounds(73,69,178,174);logo.draw(canvas);}
            }catch(Exception ignored){}
            say(canvas,"DEVELOP.UGANDA",204,108,35,ACCENT,true);
            say(canvas,"WORLD SITUATION ROOM   /   1685",204,153,25,MUTED,false);
            say(canvas,"SOURCE STATUS / INTELLIGENCE CARD",82,223,26,ACCENT,true);
            para(canvas,desk.title.toUpperCase(Locale.US),82,290,900,50,INK,2);
            Duwm1684SectorVisual artwork=new Duwm1684SectorVisual(a,desk.title,false);
            artwork.measure(View.MeasureSpec.makeMeasureSpec(920,View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(292,View.MeasureSpec.EXACTLY));
            artwork.layout(0,0,920,292);
            canvas.save();canvas.translate(80,392);artwork.draw(canvas);canvas.restore();
            say(canvas,"01   RECEIVED DATA STATE",84,740,30,ACCENT,true);
            key(canvas,"PROVIDER STATE",data.state,799,1);
            key(canvas,"RECEIVED VALUE",data.count,896,1);
            key(canvas,"SOURCE",data.provider,995,2);
            key(canvas,"SOURCE RECEIPT (UTC)",data.received,1125,2);
            key(canvas,"PROVIDER COVERAGE",data.coverage,1262,2);
            say(canvas,"02   VERIFIED RECEIPT HISTORY",84,1420,30,ACCENT,true);
            Duwm1685ReceiptChart history=new Duwm1685ReceiptChart(a,desk);
            history.measure(View.MeasureSpec.makeMeasureSpec(918,View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(245,View.MeasureSpec.EXACTLY));
            history.layout(0,0,918,245);canvas.save();canvas.translate(81,1452);history.draw(canvas);canvas.restore();
            say(canvas,"SOURCE NOTE",84,1750,24,ACCENT,true);
            para(canvas,data.explanation,84,1784,903,22,MUTED,2);
            say(canvas,"Illustrations are UI art, not observed routes  •  DUWM 1685",84,1840,18,MUTED,false);
            File outputDir=new File(a.getCacheDir(),"share-cards");
            if(!outputDir.isDirectory()&&!outputDir.mkdirs())throw new Exception("Share-card cache unavailable");
            String safe=desk.title.toLowerCase(Locale.US).replaceAll("[^a-z0-9]+","-");
            File output=new File(outputDir,"duwm-1685-"+safe+"-"+System.currentTimeMillis()+".png");
            try(FileOutputStream stream=new FileOutputStream(output)){
                if(!bmp.compress(Bitmap.CompressFormat.PNG,100,stream))throw new Exception("PNG encode failed");
            }
            Uri uri=Uri.parse("content://"+a.getPackageName()+".sharecards/"+output.getName());
            Intent intent=new Intent(Intent.ACTION_SEND);intent.setType("image/png");
            intent.putExtra(Intent.EXTRA_STREAM,uri);
            intent.putExtra(Intent.EXTRA_TEXT,"DUWM 1685 / "+desk.title+"\n"+data.report());
            intent.setClipData(android.content.ClipData.newUri(a.getContentResolver(),"DUWM verified card",uri));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            a.startActivity(Intent.createChooser(intent,"Share DUWM 1685 image"));
        }catch(Exception e){
            android.widget.Toast.makeText(a,"Unable to share verified image: "+e.getClass().getSimpleName(),android.widget.Toast.LENGTH_LONG).show();
        }finally{if(bmp!=null&&!bmp.isRecycled())bmp.recycle();}
    }
}
