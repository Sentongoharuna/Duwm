package com.sentongoharuna.worldsituationroom;

/** Great-circle geometry for local, source-observed watch regions. No simulated positions. */
public final class Duwm1676GeoMath {
    private static final double EARTH_KM=6371.0088d;
    private Duwm1676GeoMath(){}
    public static boolean valid(double lat,double lon){
        return Double.isFinite(lat)&&Double.isFinite(lon)&&Math.abs(lat)<=90d&&Math.abs(lon)<=180d;
    }
    public static double distanceKm(double lat1,double lon1,double lat2,double lon2){
        if(!valid(lat1,lon1)||!valid(lat2,lon2))return Double.NaN;
        double dLat=Math.toRadians(lat2-lat1),dLon=Math.toRadians(lon2-lon1);
        double a=Math.pow(Math.sin(dLat/2d),2d)+Math.cos(Math.toRadians(lat1))*
                 Math.cos(Math.toRadians(lat2))*Math.pow(Math.sin(dLon/2d),2d);
        return 2d*EARTH_KM*Math.asin(Math.sqrt(Math.min(1d,Math.max(0d,a))));
    }
    public static boolean inside(double centerLat,double centerLon,double radiusKm,double lat,double lon){
        return Double.isFinite(radiusKm)&&radiusKm>0d&&radiusKm<=20050d&&
             distanceKm(centerLat,centerLon,lat,lon)<=radiusKm;
    }
    public static boolean acceptableTime(long timeMillis,long now,long maxAgeMillis){
        return timeMillis>=1577836800000L && timeMillis<=now+300000L &&
               now-timeMillis<=maxAgeMillis;
    }
}
