package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.atomic.AtomicBoolean;

/** Actual NOAA planetary K-index observations; no sample/dummy figures. */
public final class RunningballV19Noaa {
  private static final String URL_TEXT="https://services.swpc.noaa.gov/products/noaa-planetary-k-index.json";
  private static final String STORE="rb19_space_weather";
  private static final long MIN_REQUEST_MS=20L*60_000L;
  private static final AtomicBoolean BUSY=new AtomicBoolean(false);
  private RunningballV19Noaa(){}
  public static SharedPreferences preferences(Context c){return c.getApplicationContext().getSharedPreferences(STORE,Context.MODE_PRIVATE);}
  public static long received(Context c){return preferences(c).getLong("received",0);}
  public static String error(Context c){return preferences(c).getString("error","");}
  public static String observedTime(Context c){return preferences(c).getString("observation_time","");}
  public static double kp(Context c){return Double.longBitsToDouble(preferences(c).getLong("kp",Double.doubleToLongBits(Double.NaN)));}
  public static void request(Context context,Runnable onFinished){
    final Context app=context.getApplicationContext();
    if(!BUSY.compareAndSet(false,true))return;
    long now=System.currentTimeMillis();SharedPreferences prefs=preferences(app);
    if(now-prefs.getLong("attempt",0)<MIN_REQUEST_MS){BUSY.set(false);if(onFinished!=null)new Handler(Looper.getMainLooper()).post(onFinished);return;}
    prefs.edit().putLong("attempt",now).apply();
    new Thread(()->{
      HttpURLConnection con=null;
      try {
        con=(HttpURLConnection)new URL(URL_TEXT).openConnection();
        con.setRequestMethod("GET");con.setConnectTimeout(8000);con.setReadTimeout(9000);
        con.setRequestProperty("Accept","application/json");
        con.setRequestProperty("User-Agent","RUNNINGBALL2/19 (NOAA-source-credited)");
        int http=con.getResponseCode();if(http!=200)throw new IllegalStateException("NOAA HTTP "+http);
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        try(InputStream in=con.getInputStream()){
          byte[] buf=new byte[8192];int count;
          while((count=in.read(buf))!=-1){if(bytes.size()+count>200000)throw new IllegalStateException("NOAA RESPONSE EXCEEDS LIMIT");bytes.write(buf,0,count);}
        }
        JSONArray reports=new JSONArray(bytes.toString("UTF-8"));
        double value=Double.NaN;String observation="";
        for(int i=0;i<reports.length();i++){
          JSONObject row=reports.optJSONObject(i);if(row==null)continue;
          double candidate=row.optDouble("Kp",Double.NaN);
          String time=row.optString("time_tag","");
          if(Double.isFinite(candidate)&&candidate>=0&&candidate<=9&&time.matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}")){
            if(time.compareTo(observation)>0){value=candidate;observation=time;}
          }
        }
        if(!Double.isFinite(value)||observation.isEmpty())throw new IllegalStateException("NO VALID NOAA KP OBSERVATION");
        prefs.edit().putLong("kp",Double.doubleToLongBits(value)).putString("observation_time",observation)
          .putLong("received",System.currentTimeMillis()).remove("error").apply();
      }catch(Exception e){
        String why=e.getMessage()==null?"PROVIDER UNAVAILABLE":e.getMessage();
        if(why.length()>100)why=why.substring(0,100);
        prefs.edit().putString("error",why).apply(); // keep genuine previous observation with unchanged time
      }finally{if(con!=null)con.disconnect();BUSY.set(false);if(onFinished!=null)new Handler(Looper.getMainLooper()).post(onFinished);}
    },"RUNNINGBALL2-NOAA-IO").start();
  }
}
