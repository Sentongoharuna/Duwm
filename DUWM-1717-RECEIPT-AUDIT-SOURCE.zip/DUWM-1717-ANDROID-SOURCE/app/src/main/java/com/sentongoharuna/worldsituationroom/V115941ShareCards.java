package com.sentongoharuna.worldsituationroom;
import android.app.Activity;
import android.content.Intent;
import android.content.ClipData;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.net.Uri;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;

/** V1159.4/1 genuine-source card renderer. Never supplies invented photos, positions or timestamps. */
public final class V115941ShareCards {
  private V115941ShareCards(){}
  private static final int W=1080,H=1470;
  private static int rgb(int r,int g,int b){return Color.rgb(r,g,b);}
  private static int typeColor(String type){
    String s=type==null?"":type.toUpperCase(Locale.US);
    if(s.contains("EARTHQUAKE")||s.contains("ALERT")||s.contains("CONFLICT"))return rgb(251,101,90);
    if(s.contains("AIR"))return rgb(83,209,225);
    if(s.contains("VESSEL")||s.contains("MARITIME"))return rgb(75,164,241);
    if(s.contains("SATELLITE")||s.contains("ISS"))return rgb(243,192,92);
    if(s.contains("WEATHER"))return rgb(115,204,246);
    if(s.contains("NEWS")||s.contains("INTELLIGENCE"))return rgb(179,154,244);
    if(s.contains("RADIO")||s.contains("TV")||s.contains("CAMERA"))return rgb(112,233,165);
    return rgb(153,191,217);
  }
  private static String safe(String s){if(s==null||s.trim().length()==0)return "Not supplied by provider";
    return s.replaceAll("[\\p{Cntrl}]+"," ").trim();}
  private static String utc(long millis){if(millis<=0)return "Not supplied by provider";
    SimpleDateFormat f=new SimpleDateFormat("dd MMM yyyy  HH:mm:ss 'UTC'",Locale.US);
    f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(millis));}
  private static void txt(Canvas c,Paint p,String s,float x,float y,int size,int color,boolean bold){
    p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);
    p.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
    c.drawText(s,x,y,p);
  }
  private static float lines(Canvas c,Paint p,String input,float x,float y,float max,int size,int lh,int maximum,int color,boolean bold){
    p.setShader(null);p.setStyle(Paint.Style.FILL);p.setTextSize(size);p.setColor(color);
    p.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
    String[] words=safe(input).split("\\s+");String row="";int printed=0;
    for(String word:words){String next=row.isEmpty()?word:row+" "+word;
      if(p.measureText(next)<=max){row=next;continue;}
      if(!row.isEmpty()){c.drawText(row,x,y,p);y+=lh;printed++;row="";if(printed>=maximum)return y;}
      while(word.length()>1&&p.measureText(word)>max){int n=word.length()-1;while(n>1&&p.measureText(word.substring(0,n))>max)n--;
        c.drawText(word.substring(0,n),x,y,p);y+=lh;printed++;
        if(printed>=maximum)return y;word=word.substring(n);
      }row=word;
    }
    if(!row.isEmpty()&&printed<maximum){c.drawText(row,x,y,p);y+=lh;}
    return y;
  }
  private static void box(Canvas c,Paint p,int left,int top,int right,int bottom,int color){
    p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(left,top,right,bottom,18,18,p);
  }
  private static Bitmap create(Activity context,String type,String title,String details,String source,
                               long observationTime,long receivedTime,Double lat,Double lon,
                               String sourceUrl,Bitmap providerImage){
    Bitmap bmp=Bitmap.createBitmap(W,H,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(bmp);
    Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);c.drawColor(rgb(7,17,28));
    int accent=typeColor(type);
    p.setColor(accent);c.drawRect(0,0,W,12,p);
    box(c,p,38,38,1042,163,rgb(14,35,49));
    try{Bitmap logo=BitmapFactory.decodeResource(context.getResources(),R.drawable.develop_uganda_logo);
      if(logo!=null){c.drawBitmap(logo,null,new Rect(57,59,138,139),p);logo.recycle();}}
    catch(Exception ignored){/* Provider logo not substituted. */}
    txt(c,p,"DEVELOP.UGANDA",155,91,39,rgb(240,249,250),true);
    txt(c,p,"WORLD SITUATION ROOM  /  SOURCE EVIDENCE",155,126,18,rgb(153,187,198),false);
    box(c,p,38,184,1042,266,rgb(16,37,50));
    txt(c,p,"DATA TYPE",61,217,19,rgb(172,194,207),true);
    String kind=safe(type).toUpperCase(Locale.US);if(kind.length()>27)kind=kind.substring(0,27);
    txt(c,p,kind,61,250,33,accent,true);
    String state=observationTime<=0?"SOURCE TIME UNKNOWN":
      Math.abs(System.currentTimeMillis()-observationTime)<300000L?"RECENT SOURCE REPORT":"SOURCE-DATED RECORD";
    txt(c,p,state,720,215,18,rgb(190,221,227),true);
    p.setColor(accent);c.drawCircle(987,221,23,p);
    String key=kind.contains("AIR")?"A":kind.contains("VESSEL")?"V":kind.contains("EARTHQUAKE")?"Q":
      kind.contains("SATELLITE")||kind.contains("ISS")?"S":kind.contains("WEATHER")?"W":
      kind.contains("NEWS")?"N":kind.contains("CAMERA")?"C":kind.contains("RADIO")?"R":"D";
    txt(c,p,key,979,230,24,rgb(7,20,31),true);
    final int photoTop=284,photoBottom=760;
    if(providerImage!=null&&!providerImage.isRecycled()&&providerImage.getWidth()>0&&providerImage.getHeight()>0){
      float ratio=964f/(photoBottom-photoTop);
      int iw=providerImage.getWidth(),ih=providerImage.getHeight();Rect crop;
      if(iw/(float)ih>ratio){int cut=Math.max(1,(int)(ih*ratio));crop=new Rect((iw-cut)/2,0,(iw+cut)/2,ih);}
      else {int cut=Math.max(1,(int)(iw/ratio));crop=new Rect(0,(ih-cut)/2,iw,(ih+cut)/2);}
      c.drawBitmap(providerImage,crop,new Rect(58,photoTop,1022,photoBottom),p);
      box(c,p,65,691,521,752,rgb(9,29,42));txt(c,p,"PROVIDER PHOTO RECEIVED",91,731,23,accent,true);
    } else {
      box(c,p,58,photoTop,1022,photoBottom,rgb(15,36,52));
      p.setColor(rgb(35,69,83));p.setStrokeWidth(2);p.setStyle(Paint.Style.STROKE);
      for(int x=118;x<1020;x+=95)c.drawLine(x,photoTop+40,x,photoBottom-40,p);
      for(int yy=338;yy<photoBottom;yy+=81)c.drawLine(85,yy,995,yy,p);
      p.setStyle(Paint.Style.FILL);p.setColor(accent);c.drawCircle(540,481,15,p);
      p.setColor(rgb(143,205,220));p.setStrokeWidth(2);p.setStyle(Paint.Style.STROKE);
      c.drawCircle(540,481,67,p);c.drawLine(445,481,635,481,p);c.drawLine(540,386,540,576,p);p.setStyle(Paint.Style.FILL);
      txt(c,p,"DATA-ONLY SOURCE CARD",95,648,38,rgb(222,240,244),true);
      txt(c,p,"No original picture was supplied",95,693,26,rgb(161,195,205),false);
      if(lat!=null&&lon!=null&&Double.isFinite(lat)&&Double.isFinite(lon)){
        txt(c,p,String.format(Locale.US,"RECORDED POSITION  %.5f, %.5f",lat,lon),95,736,23,accent,true);
      }else txt(c,p,"LOCATION NOT PROVIDED",95,736,23,accent,true);
    }
    box(c,p,38,780,1042,1433,rgb(16,34,48));
    float y=834;
    y=lines(c,p,title,70,y,937,36,44,2,rgb(239,248,250),true)+12;
    txt(c,p,"DETAILS / OBSERVATION",70,y,19,accent,true);y+=43;
    y=lines(c,p,details,70,y,930,25,32,4,rgb(210,229,236),false)+15;
    if(y>1160)y=1160;
    txt(c,p,"PROVIDER / SOURCE",70,y,19,accent,true);y+=34;
    y=lines(c,p,source,70,y,930,25,28,1,rgb(236,245,246),true)+8;
    txt(c,p,"SOURCE TIME",70,y,18,accent,true);y+=31;
    txt(c,p,utc(observationTime),70,y,23,rgb(221,236,240),false);y+=27;
    txt(c,p,"CARD GENERATED / UTC",70,y,18,accent,true);y+=29;
    txt(c,p,utc(receivedTime),70,y,21,rgb(202,219,229),false);
    txt(c,p,"LOCATION / COORDINATES",70,1311,17,accent,true);
    String coordinates=lat!=null&&lon!=null&&Double.isFinite(lat)&&Double.isFinite(lon)?
      String.format(Locale.US,"%.5f, %.5f  (provider reported)",lat,lon):"Not supplied by provider";
    txt(c,p,coordinates,70,1338,20,rgb(211,232,238),false);
    p.setColor(rgb(63,103,119));c.drawRect(58,1356,1020,1359,p);
    String url=(sourceUrl!=null&&sourceUrl.startsWith("https://"))?sourceUrl:"Source record URL not supplied";
    lines(c,p,url,70,1392,930,18,25,2,rgb(174,202,213),false);
    txt(c,p,"SOURCE ATTRIBUTED  /  NO FABRICATED IMAGES OR POSITIONS",60,1457,17,rgb(126,162,180),true);
    return bmp;
  }
  public static Bitmap render(Activity context,String type,String title,String details,String source,
                              long observationTime,Double lat,Double lon,String url,Bitmap image){
    return create(context,type,title,details,source,observationTime,System.currentTimeMillis(),lat,lon,url,image);
  }
  public static void share(Activity a,String type,String title,String detail,String source,long sourceTime,
                           Double lat,Double lon,String sourceUrl,Bitmap image){
    Toast.makeText(a,"Preparing source card",Toast.LENGTH_SHORT).show();
    new Thread(()->{
      try{
        Bitmap card=render(a,type,title,detail,source,sourceTime,lat,lon,sourceUrl,image);
        File folder=new File(a.getCacheDir(),"sharecards");if(!folder.isDirectory()&&!folder.mkdirs())throw new java.io.IOException("Cache unavailable");
        String file="card-"+UUID.randomUUID().toString().replace("-","").substring(0,24)+".png";
        File out=new File(folder,file);
        try(FileOutputStream stream=new FileOutputStream(out)){
          if(!card.compress(Bitmap.CompressFormat.PNG,100,stream))throw new java.io.IOException("PNG encoding failed");
        }card.recycle();
        Uri uri=new Uri.Builder().scheme("content").authority(a.getPackageName()+".v11593sourcecards")
            .appendPath("cards").appendPath(file).build();
        String copy="DEVELOP.UGANDA / "+type+"\n"+safe(title)+"\n"+safe(detail)+"\nSource: "+safe(source)
            +"\nSource time: "+utc(sourceTime)+"\n"+(sourceUrl==null?"":sourceUrl);
        a.runOnUiThread(()->{
          if(a.isFinishing()||a.isDestroyed())return;
          Intent send=new Intent(Intent.ACTION_SEND);send.setType("image/png");
          send.putExtra(Intent.EXTRA_STREAM,uri);send.putExtra(Intent.EXTRA_TEXT,copy);
          send.setClipData(ClipData.newUri(a.getContentResolver(),"DEVELOP.UGANDA source card",uri));
          send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
          try{a.startActivity(Intent.createChooser(send,"Share verified source record"));}
          catch(Exception ex){Toast.makeText(a,"No sharing app available",Toast.LENGTH_LONG).show();}
        });
      }catch(Exception ex){a.runOnUiThread(()->Toast.makeText(a,"Card unavailable: "+ex.getClass().getSimpleName(),Toast.LENGTH_LONG).show());}
    },"share-card-export").start();
  }
}
