package com.sentongoharuna.worldsituationroom;

import android.app.Application;

/** Installs local crash-loop protection before any activity or live source starts. */
public final class DuWorldApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        CrashLedger.install(this);
        AppContextHolder.set(this);
        NewsNotifier.channels(this);
        Duwm1683FullScreen.install(this);
        Duwm1683DeskDetailKit.install(this);
        Duwm1685PageUpgrade.install(this);
        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override public void onActivityCreated(android.app.Activity a,android.os.Bundle b) {}
            @Override public void onActivityStarted(android.app.Activity a) {}
            @Override public void onActivityResumed(android.app.Activity a) {
                Duwm1715FormalUi.apply(a);
                Duwm1715SignalLights.attach(a);
                Duwm1709SectorOutline.frameNativePage(a);
            }
            @Override public void onActivityPaused(android.app.Activity a) {}
            @Override public void onActivityStopped(android.app.Activity a) {}
            @Override public void onActivitySaveInstanceState(android.app.Activity a,android.os.Bundle b) {}
            @Override public void onActivityDestroyed(android.app.Activity a) {}
        });
    }
}
