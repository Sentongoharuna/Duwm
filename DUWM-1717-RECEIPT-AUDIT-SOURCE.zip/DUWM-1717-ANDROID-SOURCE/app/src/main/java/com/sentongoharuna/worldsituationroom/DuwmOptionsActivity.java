package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.Locale;

/** 1683: a searchable, data-aware front door to EVERY original DUWM intelligence desk.
 * Opens individual existing activities, never places a second globe over MainActivity.
 */
public final class DuwmOptionsActivity extends Activity {
    private static final int BG=DuwmUnifiedTheme.BACKGROUND;
    private static final int WHITE=DuwmUnifiedTheme.TEXT;
    private static final int MUTED=DuwmUnifiedTheme.MUTED;
    private static final int CYAN=DuwmUnifiedTheme.ACCENT;
    private static final int TEAL=DuwmUnifiedTheme.PANEL;
    private final ArrayList<LinearLayout> tiles=new ArrayList<>();
    private final ArrayList<TextView> headers=new ArrayList<>();
    private final ArrayList<TextView> receiptLines=new ArrayList<>();
    private TextView resultCount,recentDesk;
    private View missionBoard;
    private final Set<String> favorites=new HashSet<>();
    private boolean onlyFavorites=false;
    private SharedPreferences prefs;
    private EditText searchBox;
    private String sectionFilter="ALL";
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);
        if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return t;
    }
    private GradientDrawable background(boolean selected){
        GradientDrawable d=new GradientDrawable();d.setColor(selected?DuwmUnifiedTheme.PANEL_SELECTED:TEAL);
        d.setStroke(dp(1),selected?CYAN:DuwmUnifiedTheme.BORDER);
        d.setCornerRadius(dp(DuwmUnifiedTheme.FORMAL_CORNER_DP));return d;
    }
    private TextView pill(String value){
        TextView v=text(value,11,CYAN,true);v.setGravity(Gravity.CENTER);v.setBackground(background(false));
        v.setPadding(dp(9),dp(9),dp(9),dp(9));return v;
    }
    private void header(LinearLayout root,String category){
        TextView h=text(category.toUpperCase(Locale.ROOT),15,CYAN,true);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.topMargin=dp(23);p.bottomMargin=dp(12);root.addView(h,p);headers.add(h);
    }
    private String id(Duwm1683DeskCatalog.Desk d){return d.title;}
    private void openDesk(Duwm1683DeskCatalog.Desk d){
        prefs.edit().putString("recentDesk",d.title).apply();
        startActivity(Duwm1683DeskCatalog.intent(this,d));
    }
    private void item(LinearLayout root,Duwm1683DeskCatalog.Desk d){
        LinearLayout block=new LinearLayout(this);block.setOrientation(LinearLayout.VERTICAL);
        block.setPadding(dp(13),dp(12),dp(13),dp(13));
        block.setBackground(Duwm1709SectorOutline.card(this,Duwm1709SectorOutline.index(d),DuwmUnifiedTheme.PANEL,false));
        // Formal source index: use real receipts below, not 19 decorative mock maps.
        LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.HORIZONTAL);
        TextView name=text(d.title.toUpperCase(Locale.ROOT),17,WHITE,true);top.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow=text("↗",23,CYAN,true);top.addView(arrow);
        block.addView(top);
        TextView subtitle=text(d.subtitle,12,MUTED,false);subtitle.setPadding(0,dp(3),0,dp(4));block.addView(subtitle);
        TextView share=pill("SHARE 1699 IMAGE");
        share.setOnClickListener(v->Duwm1687ShareCard.share(this,d));
        LinearLayout.LayoutParams shareParams=new LinearLayout.LayoutParams(-1,dp(39));shareParams.topMargin=dp(7);
        block.addView(share,shareParams);
        if(d.source>=0){
            Duwm1685ReceiptHistory.capture(this,d);
            Duwm1685ReceiptChart chart=new Duwm1685ReceiptChart(this,d);
            LinearLayout.LayoutParams trendParams=new LinearLayout.LayoutParams(-1,dp(104));
            trendParams.topMargin=dp(7);block.addView(chart,trendParams);
        }
        TextView receipt=text(Duwm1683DeskCatalog.status(this,d),11,
                              d.source>=0?CYAN:MUTED,false);
        receipt.setSingleLine(false);receipt.setMaxLines(3);block.addView(receipt);receiptLines.add(receipt);
        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams actionParams=new LinearLayout.LayoutParams(-1,-2);
        actionParams.topMargin=dp(6);block.addView(actions,actionParams);
        TextView open=pill("OPEN NATIVE DESK  ↗");open.setOnClickListener(v->openDesk(d));
        actions.addView(open,new LinearLayout.LayoutParams(0,dp(39),2));
        TextView detail=pill("SOURCE DETAIL");
        LinearLayout.LayoutParams detailParams=new LinearLayout.LayoutParams(0,dp(39),1);
        detailParams.leftMargin=dp(8);actions.addView(detail,detailParams);
        detail.setOnClickListener(v->Duwm1683DeskDetailKit.show(this,d));
        TextView favorite=pill(favorites.contains(id(d))?"★":"☆");
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(dp(42),dp(39));fp.leftMargin=dp(6);
        actions.addView(favorite,fp);
        favorite.setOnClickListener(v->{
            if(favorites.contains(id(d)))favorites.remove(id(d));else favorites.add(id(d));
            favorite.setText(favorites.contains(id(d))?"★":"☆");
            prefs.edit().putString("favorites",android.text.TextUtils.join("\u001f",favorites)).apply();
            filter(searchBox.getText().toString());
        });
        block.setOnClickListener(v->openDesk(d));
        block.setContentDescription(d.title+". "+d.subtitle+". "+Duwm1683DeskCatalog.status(this,d));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(9);
        root.addView(block,p);tiles.add(block);
    }
    private void filter(String query){
        String q=query==null?"":query.trim().toLowerCase(Locale.ROOT);
        String group="";int visible=0;int matching=0;int groupIndex=-1;
        for(int i=0;i<Duwm1683DeskCatalog.ALL.length;i++){
            Duwm1683DeskCatalog.Desk d=Duwm1683DeskCatalog.ALL[i];
            boolean sectionOk=(sectionFilter.equals("ALL")||d.category.equals(sectionFilter))&&
                    (!onlyFavorites||favorites.contains(id(d)));
            boolean show=sectionOk && (q.isEmpty()||(d.title+" "+d.subtitle+" "+d.category+" "+d.description)
                                  .toLowerCase(Locale.ROOT).contains(q));
            if(show){visible++;matching++;}tiles.get(i).setVisibility(show?View.VISIBLE:View.GONE);
        }
        for(int k=0;k<headers.size();k++){
            String section=headers.get(k).getText().toString();boolean has=false;
            for(int i=0;i<Duwm1683DeskCatalog.ALL.length;i++){
                if(Duwm1683DeskCatalog.ALL[i].category.equals(section)&&tiles.get(i).getVisibility()==View.VISIBLE){has=true;break;}
            }
            headers.get(k).setVisibility(has?View.VISIBLE:View.GONE);
        }
        if(resultCount!=null)resultCount.setText("FULL SCREEN DESKS  "+visible+" / "+Duwm1683DeskCatalog.ALL.length+
                                "   •   SAVED "+favorites.size());
    }
    private void refreshReceipts(){
        for(int i=0;i<Duwm1683DeskCatalog.ALL.length&&i<receiptLines.size();i++){
            receiptLines.get(i).setText(Duwm1683DeskCatalog.status(this,Duwm1683DeskCatalog.ALL[i]));
        }
    }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        prefs=getSharedPreferences("duwm1684_desk_nav",Context.MODE_PRIVATE);
        String saved=prefs.getString("favorites","");
        if(!saved.isEmpty())for(String name:saved.split("\u001f"))if(!name.isEmpty())favorites.add(name);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(BG);setContentView(shell);Duwm1167SafeArea.install(this,shell);
        TextView home=pill("← ORIGINAL COMMAND / ONE GLOBE");home.setGravity(Gravity.CENTER);
        home.setOnClickListener(v->finish());
        LinearLayout.LayoutParams back=new LinearLayout.LayoutParams(-1,dp(38));
        back.setMargins(dp(13),dp(9),dp(13),dp(7));shell.addView(home,back);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);
        shell.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14),dp(8),dp(14),dp(26));scroll.addView(root);
        // 1687 FIX1: read the version from the INSTALLED APK, not a painted hard-coded badge.
        String installedVersion="UNKNOWN";
        try { installedVersion=getPackageManager().getPackageInfo(getPackageName(),0).versionName; }
        catch (android.content.pm.PackageManager.NameNotFoundException ignored) { }
        TextView banner=text("WORLD SITUATION ROOM  /  "+installedVersion,21,WHITE,true);
        banner.setPadding(0,dp(8),0,dp(5));root.addView(banner);
        TextView installedIdentity=text("INSTALLED APK  •  "+getString(R.string.app_name)+"  •  v"+installedVersion,11,MUTED,false);
        installedIdentity.setPadding(0,0,0,dp(11));root.addView(installedIdentity);
        // The 1687 mission board replaces the old duplicate decorative hero panel.
        missionBoard=Duwm1687MissionBoard.create(this);root.addView(missionBoard);
        // Saved desks are now integrated directly into the single searchable 1698 mission board.
        // The previous advanced-navigation list/search/filter duplicated the same 19 desk tiles.
        TextView foot=text("Each DETAILS panel describes the actual provider, record freshness, missing coverage and how to read the information. No synthetic live records are created.",12,MUTED,false);
        foot.setPadding(0,dp(8),0,dp(18));root.addView(foot);
    }
    @Override protected void onResume(){super.onResume();refreshReceipts();
        if(missionBoard!=null)missionBoard.post(()->Duwm1687MissionBoard.refresh(this,missionBoard));
        String last=prefs.getString("recentDesk","");
        if(recentDesk!=null)recentDesk.setText(last.isEmpty()?"RECENT DESK  /  NONE":"↗ RETURN TO  /  "+last);
    }
}
