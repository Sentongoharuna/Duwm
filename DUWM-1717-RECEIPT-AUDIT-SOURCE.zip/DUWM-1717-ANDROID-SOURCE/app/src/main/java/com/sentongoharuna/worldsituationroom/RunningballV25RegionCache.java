package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
/** Two real previous regional ADS-B snapshots, 256 KiB maximum combined payload; 6h TTL.
  Snapshots are cached only after their original observer coordinates and receipt time are validated. */
public final class RunningballV25RegionCache {
  public static final int MAX_CACHE_BYTES=262144;public static final long TTL=21600000L;
  private RunningballV25RegionCache(){}
  private static SharedPreferences db(Context c){return c.getApplicationContext().getSharedPreferences("rb25_region_cache",Context.MODE_PRIVATE);}
  public static synchronized void save(Context c,double lat,double lon){
    String data=c.getApplicationContext().getSharedPreferences("air_widget_v2",Context.MODE_PRIVATE).getString("last_snapshot","");
    if(data.isEmpty()||data.length()*2>MAX_CACHE_BYTES/2)return;
    try{JSONObject record=new JSONObject(data);long stamp=record.optLong("time",0L);
      if(stamp<=0||System.currentTimeMillis()-stamp>TTL||
         Math.abs(record.optDouble("observerLat",999)-lat)>.001 ||
         Math.abs(record.optDouble("observerLon",999)-lon)>.001)return;
      SharedPreferences p=db(c);String key=RunningballV25RegionQuery.key(lat,lon);
      String a=p.getString("slot0_key","");String b=p.getString("slot1_key","");
      int slot=key.equals(a)?0:key.equals(b)?1:a.isEmpty()?0:b.isEmpty()?1:
        p.getLong("slot0_saved",0L)<=p.getLong("slot1_saved",0L)?0:1;
      String k="slot"+slot+"_";
      p.edit().putString(k+"key",key).putString(k+"data",data).putLong(k+"saved",System.currentTimeMillis()).apply();
    }catch(Exception ignored){} // bad data are never rescued into cache
  }
  public static synchronized boolean restore(Context c,double lat,double lon){
    SharedPreferences p=db(c);String wanted=RunningballV25RegionQuery.key(lat,lon);
    for(int slot=0;slot<2;slot++){
      String key="slot"+slot+"_";if(!wanted.equals(p.getString(key+"key","")))continue;
      String raw=p.getString(key+"data","");
      try{JSONObject o=new JSONObject(raw);long age=System.currentTimeMillis()-o.optLong("time",0);
        if(age<0||age>TTL||raw.length()*2>MAX_CACHE_BYTES/2)return false;
        c.getApplicationContext().getSharedPreferences("air_widget_v2",Context.MODE_PRIVATE).edit()
         .putString("last_snapshot",raw).putString("last_error","OFFLINE CACHE / WAITING FOR NEW REGION REPORT").apply();
        return true;
      }catch(Exception ignored){return false;}
    }
    return false;
  }
}
