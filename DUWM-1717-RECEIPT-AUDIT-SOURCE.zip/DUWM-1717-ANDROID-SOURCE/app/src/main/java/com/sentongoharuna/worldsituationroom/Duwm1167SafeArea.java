package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
/**
 * Applies status- and navigation-bar-safe insets to screens that previously drew
 * underneath the Android clock. Keep the base padding; do not modify the original
 * interactive globe, wallpaper, or its own insets handler.
 */
public final class Duwm1167SafeArea {
  private Duwm1167SafeArea() {}
  public static void install(Activity activity, View content) {
    if (activity==null || content==null) return;
    final int left=content.getPaddingLeft(), top=content.getPaddingTop();
    final int right=content.getPaddingRight(), bottom=content.getPaddingBottom();
    if(Build.VERSION.SDK_INT>=30) {
      activity.getWindow().setDecorFitsSystemWindows(false);
    } else {
      content.setFitsSystemWindows(true);
    }
    content.setOnApplyWindowInsetsListener((v, insets)->{
      int t,b;
      if(Build.VERSION.SDK_INT>=30) {
        android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());
        t=bars.top;b=bars.bottom;
      } else {
        t=insets.getSystemWindowInsetTop();b=insets.getSystemWindowInsetBottom();
      }
      v.setPadding(left,top+t,right,bottom+b);
      return insets;
    });
    content.requestApplyInsets();
  }
}
