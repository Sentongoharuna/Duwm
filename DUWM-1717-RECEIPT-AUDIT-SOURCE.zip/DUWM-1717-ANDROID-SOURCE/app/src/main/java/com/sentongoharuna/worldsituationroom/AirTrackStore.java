package com.sentongoharuna.worldsituationroom;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Process-local immutable snapshots of actual OpenSky records. No generated positions. */
public final class AirTrackStore {
    private AirTrackStore() {}
    public static final class Flight {
        public final String icao24,callsign,origin,squawk;
        public final double lat,lon,altMeters,velocityMs,headingDeg,verticalRateMs;
        public final long lastContactSec,positionTimeSec;
        public final boolean ground;
        Flight(String i,String c,String o,String sq,double latitude,double longitude,double alt,double vel,
               double heading,double vertical,long contact,long position,boolean onGround){
            icao24=i;callsign=c;origin=o;squawk=sq;lat=latitude;lon=longitude;altMeters=alt;
            velocityMs=vel;headingDeg=heading;verticalRateMs=vertical;lastContactSec=contact;
            positionTimeSec=position;ground=onGround;
        }
        public String display(){return callsign.length()>0?callsign:icao24.toUpperCase(Locale.US);}
    }
    public static final class Snapshot {
        public final List<Flight> records;
        public final long sourceTimeSec,receivedAtMillis;
        public final int reportedCount,rejectedUnlocated;
        Snapshot(List<Flight> flights,long utc,long now,int reported,int rejected){
            records=Collections.unmodifiableList(new ArrayList<>(flights));sourceTimeSec=utc;
            receivedAtMillis=now;reportedCount=reported;rejectedUnlocated=rejected;
        }
    }
    private static volatile Snapshot last;
    public static Snapshot current(){return last;}
    private static double numeric(JSONArray a,int index){
        if(a.isNull(index))return Double.NaN;
        double v=a.optDouble(index,Double.NaN);
        return Double.isFinite(v)?v:Double.NaN;
    }
    public static Snapshot publish(JSONObject data){
        JSONArray rows=data.optJSONArray("states");
        if(rows==null)throw new IllegalArgumentException("OpenSky states missing");
        int rejected=0,limit=Math.min(rows.length(),10000);
        List<Flight> entries=new ArrayList<>(Math.min(limit,6000));
        for(int k=0;k<limit;k++){
            JSONArray a=rows.optJSONArray(k);
            if(a==null||a.length()<11){rejected++;continue;}
            double lon=numeric(a,5),lat=numeric(a,6);
            if(!Double.isFinite(lat)||!Double.isFinite(lon)||lat>90||lat < -90||lon>180||lon < -180){rejected++;continue;}
            String icao=a.optString(0,"").trim(),cs=a.optString(1,"").trim(),origin=a.optString(2,"").trim();
            if(icao.isEmpty()){rejected++;continue;}
            entries.add(new Flight(icao,cs,origin,a.optString(14,"").trim(),lat,lon,
                    numeric(a,7),numeric(a,9),numeric(a,10),numeric(a,11),
                    a.optLong(4,0),a.optLong(3,0),a.optBoolean(8,false)));
        }
        Snapshot snapshot=new Snapshot(entries,data.optLong("time",0),System.currentTimeMillis(),rows.length(),rejected);
        last=snapshot;
        return snapshot;
    }
}
