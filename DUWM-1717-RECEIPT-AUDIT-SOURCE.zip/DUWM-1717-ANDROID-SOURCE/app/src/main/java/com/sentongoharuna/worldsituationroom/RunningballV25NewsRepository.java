package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Xml;
import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Independent V8 native implementation. Publisher RSS/GDELT article metadata only, never incident verification. */
public final class RunningballV25NewsRepository {
  private RunningballV25NewsRepository(){}
  public static final String STORE="rb25_news_conflicts_v8";
  public static final String[] RSS_NAMES={"The Independent Uganda","The Observer Uganda","SoftPower News","Watchdog Uganda"};
  public static final String[] RSS_URLS={"https://www.independent.co.ug/feed/","https://observer.ug/feed/","https://softpower.ug/feed/","https://www.watchdoguganda.com/feed"};
  public static final String[] KEYS={"ug_independent","ug_observer","ug_softpower","ug_watchdog","conflict_middle_east","conflict_world"};
  private static final long TTL=20*60*1000L, MIN_RETRY=3*60*1000L;
  private static final int MAX_BYTES=450000;
  private static final ExecutorService WORK=Executors.newFixedThreadPool(2);
  private static final Handler MAIN=new Handler(Looper.getMainLooper());
  private static final Set<String> IN_FLIGHT=new HashSet<>();
  public static SharedPreferences pref(Context c){return c.getApplicationContext().getSharedPreferences(STORE,Context.MODE_PRIVATE);}
  public static long last(Context c,String key){return pref(c).getLong(key+"_at",0);}
  public static long requested(Context c,String key){return pref(c).getLong(key+"_attempt",0);}
  public static String error(Context c,String key){return pref(c).getString(key+"_error","");}
  public static JSONArray articles(Context c,String key){try{return new JSONArray(pref(c).getString(key+"_items","[]"));}catch(Exception e){return new JSONArray();}}
  public static String age(long time){if(time<=0)return "NEVER RECEIVED";long m=Math.max(0,System.currentTimeMillis()-time)/60000L;return m<1?"<1m":m<60?m+"m":m<1440?(m/60)+"h":(m/1440)+"d";}
  public static boolean validArticle(String url){try{URL u=new URL(url);return "https".equals(u.getProtocol())&&u.getHost()!=null&&u.getHost().contains(".");}catch(Exception e){return false;}}
  private static byte[] download(String url) throws Exception {
    if(!url.startsWith("https://"))throw new IllegalArgumentException("HTTPS required");
    HttpURLConnection conn=null;
    try{
      conn=(HttpURLConnection)new URL(url).openConnection();conn.setRequestMethod("GET");
      conn.setConnectTimeout(9000);conn.setReadTimeout(12000);
      conn.setRequestProperty("User-Agent","RUNNINGBALL2-V25-NewsReader/8 (headlines only)");
      conn.setRequestProperty("Accept","application/rss+xml,application/atom+xml,application/xml,text/xml,application/json");
      if(conn.getResponseCode()!=200)throw new IllegalStateException("HTTP "+conn.getResponseCode());
      ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[8192];
      try(InputStream input=conn.getInputStream()){
        int n;while((n=input.read(buffer))!=-1){if(out.size()+n>MAX_BYTES)throw new IllegalStateException("RESPONSE TOO LARGE");out.write(buffer,0,n);}
      }
      if(out.size()==0)throw new IllegalStateException("EMPTY RESPONSE");return out.toByteArray();
    }finally{if(conn!=null)conn.disconnect();}
  }
  public static JSONArray parseRss(byte[] bytes,String publisher) throws Exception {
    XmlPullParser parser=Xml.newPullParser();
    parser.setInput(new ByteArrayInputStream(bytes),"UTF-8");JSONArray results=new JSONArray();
    boolean item=false;String title="",link="",date="";
    for(int ev=parser.getEventType();ev!=XmlPullParser.END_DOCUMENT;ev=parser.next()){
      if(ev==XmlPullParser.START_TAG){String tag=parser.getName();
        if("item".equalsIgnoreCase(tag)||"entry".equalsIgnoreCase(tag)){item=true;title="";link="";date="";}
        else if(item&&"title".equalsIgnoreCase(tag))title=parser.nextText().trim();
        else if(item&&"link".equalsIgnoreCase(tag)){
          String href=parser.getAttributeValue(null,"href");link=href!=null?href.trim():parser.nextText().trim();
        }else if(item&&(tag.equalsIgnoreCase("pubDate")||tag.equalsIgnoreCase("published")||tag.equalsIgnoreCase("updated")))date=parser.nextText().trim();
      }else if(ev==XmlPullParser.END_TAG&&(parser.getName().equalsIgnoreCase("item")||parser.getName().equalsIgnoreCase("entry"))){
        if(title.length()>7&&validArticle(link)){
          JSONObject o=new JSONObject();o.put("title",title.substring(0,Math.min(240,title.length())));
          o.put("url",link);o.put("publisher",publisher);o.put("published",date);o.put("type","PUBLISHER HEADLINE");results.put(o);
        }item=false;if(results.length()>=12)break;
      }
    }
    if(results.length()==0)throw new IllegalStateException("NO VALID RSS ITEMS");
    return results;
  }
  public static JSONArray parseGdelt(byte[] bytes,String desk) throws Exception {
    JSONObject json=new JSONObject(new String(bytes,StandardCharsets.UTF_8));JSONArray feed=json.optJSONArray("articles");
    if(feed==null)throw new IllegalStateException("MISSING GDELT ARTICLES");JSONArray results=new JSONArray();
    for(int i=0;i<feed.length()&&results.length()<35;i++){
      JSONObject a=feed.optJSONObject(i);if(a==null)continue;
      String title=a.optString("title","").trim(),url=a.optString("url","").trim();
      if(title.length()<8||!validArticle(url))continue;
      JSONObject o=new JSONObject();o.put("title",title.substring(0,Math.min(240,title.length())));
      o.put("url",url);o.put("publisher",a.optString("domain","Publisher not supplied"));
      o.put("published",a.optString("seendate",""));o.put("type","NEWS REPORT · UNVERIFIED INCIDENT");
      o.put("desk",desk);results.put(o);
    }
    return results;
  }
  private static String gdelt(boolean regional) throws Exception {
    String query=regional?"(Gaza OR Israel OR Palestine OR Lebanon OR Syria OR Iran OR Yemen OR Iraq OR \"Red Sea\") (conflict OR ceasefire OR strike OR humanitarian OR casualties OR evacuation)":
      "(war OR conflict OR ceasefire OR humanitarian OR displacement OR armed clashes)";
    return "https://api.gdeltproject.org/api/v2/doc/doc?mode=artlist&format=json&maxrecords=40&sort=datedesc&timespan=24h&query="+
        URLEncoder.encode(query,"UTF-8");
  }
  private static void runOne(Context app,int which,Runnable notify){
    String key=KEYS[which];synchronized(IN_FLIGHT){if(IN_FLIGHT.contains(key))return;IN_FLIGHT.add(key);}
    WORK.execute(()->{
      try{
        String url=which<4?RSS_URLS[which]:gdelt(which==4);
        JSONArray items=which<4?parseRss(download(url),RSS_NAMES[which]):parseGdelt(download(url),which==4?"MIDDLE EAST":"WORLD CONFLICT");
        // A legitimately empty GDELT result is an empty result set, not a casualty count.
        pref(app).edit().putString(key+"_items",items.toString()).putLong(key+"_at",System.currentTimeMillis()).remove(key+"_error").apply();
      }catch(Exception ex){String message=ex.getClass().getSimpleName()+": "+String.valueOf(ex.getMessage());
        pref(app).edit().putString(key+"_error",message.substring(0,Math.min(140,message.length()))).apply();
      }finally{synchronized(IN_FLIGHT){IN_FLIGHT.remove(key);}if(notify!=null)MAIN.post(notify);}
    });
  }
  public static void refresh(Context c,boolean manual,Runnable notify){
    Context app=c.getApplicationContext();long now=System.currentTimeMillis();
    for(int i=0;i<KEYS.length;i++){
      String key=KEYS[i];long previous=requested(app,key),received=last(app,key);
      if(now-previous<(manual?MIN_RETRY:TTL) && previous>0)continue;
      if(!manual&&received>0&&now-received<TTL)continue;
      pref(app).edit().putLong(key+"_attempt",now).apply();runOne(app,i,notify);
    }
  }
}
