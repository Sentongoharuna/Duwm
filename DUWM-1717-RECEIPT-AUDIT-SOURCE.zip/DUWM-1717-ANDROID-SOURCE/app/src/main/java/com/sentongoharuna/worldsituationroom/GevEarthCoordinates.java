package com.sentongoharuna.worldsituationroom;

import java.util.Locale;

/** Port 03: validate WGS84 coordinates and keyless geo: navigation.
 * Inspired by God's Eye View's keyless coordinate navigation; no external imagery copied.
 */
public final class GevEarthCoordinates {
    private GevEarthCoordinates() { }
    public static final class Point {
        public final double lat, lon;
        public Point(double lat, double lon) { this.lat=lat; this.lon=lon; }
    }
    public static boolean valid(double lat, double lon) {
        return !Double.isNaN(lat) && !Double.isInfinite(lat) &&
          !Double.isNaN(lon) && !Double.isInfinite(lon) &&
          lat >= -90d && lat <= 90d && lon >= -180d && lon <= 180d;
    }
    public static Point parse(String query) {
        if (query == null) return null;
        String s=query.trim();
        if (s.regionMatches(true,0,"geo:",0,4)) s=s.substring(4);
        int q=s.indexOf('?'); if(q>=0)s=s.substring(0,q);
        String[] bits=s.split(",",-1);
        if(bits.length!=2) return null;
        try {
            double lat=Double.parseDouble(bits[0].trim());
            double lon=Double.parseDouble(bits[1].trim());
            return valid(lat,lon)?new Point(lat,lon):null;
        } catch(NumberFormatException e) { return null; }
    }
    public static String formatted(Point p) {
        if(p==null||!valid(p.lat,p.lon))return "INVALID LOCATION";
        return String.format(Locale.US,"%.5f, %.5f",p.lat,p.lon);
    }
}
