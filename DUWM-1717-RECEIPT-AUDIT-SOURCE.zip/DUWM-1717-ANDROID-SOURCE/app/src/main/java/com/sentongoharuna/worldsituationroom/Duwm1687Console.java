package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

/** Original 19 native Activities receive a recognizable 1687 operational command header.
 * Data originates solely from Duwm1684DeskDiagnostics and the actual local receipt history.
 * Maps, live audio/video and globe are not replaced with decorative fake data. */
public final class Duwm1687Console {
    private Duwm1687Console(){}
    private static int dp(Activity a,float v){return Math.round(a.getResources().getDisplayMetrics().density*v);}
    private static GradientDrawable bg(Activity a,boolean selected){
        GradientDrawable d=new GradientDrawable();d.setColor(selected?DuwmUnifiedTheme.PANEL_SELECTED:DuwmUnifiedTheme.PANEL);
        d.setCornerRadius(dp(a,13));d.setStroke(dp(a,1),selected?DuwmUnifiedTheme.ACCENT:DuwmUnifiedTheme.BORDER);return d;
    }
    private static TextView text(Activity a,String value,int size,int color,boolean bold){
        TextView t=new TextView(a);t.setText(value);t.setTextSize(size);t.setTextColor(color);
        t.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",0));t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(a,6),dp(a,4),dp(a,6),dp(a,4));return t;
    }
    private static TextView action(Activity a,String label,Runnable r){
        TextView t=text(a,label,12,DuwmUnifiedTheme.ACCENT_BRIGHT,true);t.setGravity(Gravity.CENTER);
        t.setContentDescription(label);t.setBackground(bg(a,true));t.setOnClickListener(v->r.run());return t;
    }
    private static void addButton(Activity a,LinearLayout row,String label,Runnable r,int weight){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(a,49),weight);p.rightMargin=dp(a,6);
        row.addView(action(a,label,r),p);
    }
    /** One compact, collapsible toolbar INSTEAD of a duplicate dashboard above the native page. */
    public static View page(Activity a,Duwm1683DeskCatalog.Desk desk){
        Duwm1685ReceiptHistory.capture(a,desk);
        Duwm1684DeskDiagnostics.Snapshot snap=Duwm1684DeskDiagnostics.read(a,desk);
        LinearLayout panel=new LinearLayout(a);panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(a,8),dp(a,3),dp(a,8),dp(a,3));panel.setBackground(bg(a,false));
        LinearLayout top=new LinearLayout(a);top.setGravity(Gravity.CENTER_VERTICAL);
        panel.addView(top,new LinearLayout.LayoutParams(-1,dp(a,43)));
        TextView heading=text(a,desk.title.toUpperCase(Locale.US),13,DuwmUnifiedTheme.TEXT,true);
        heading.setSingleLine(true);heading.setEllipsize(android.text.TextUtils.TruncateAt.END);
        top.addView(heading,new LinearLayout.LayoutParams(0,-1,1));
        TextView detailsButton=action(a,"FULL DATA ↗",()->Duwm1687WorkspaceActivity.open(a,desk));
        top.addView(detailsButton,new LinearLayout.LayoutParams(dp(a,112),-1));
        // The single-line proof rail replaces the earlier double header; native map and player stay above the fold.
        TextView state=text(a,"RECEIPT  "+snap.state+"  /  "+snap.count+"  /  "+snap.provider,10,DuwmUnifiedTheme.ACCENT_BRIGHT,true);
        state.setTag("duwm-1687-live-state");state.setSingleLine(true);
        state.setEllipsize(android.text.TextUtils.TruncateAt.END);panel.addView(state);
        TextView receiver=text(a,snap.received,10,DuwmUnifiedTheme.MUTED,false);
        receiver.setTag("duwm-1687-live-time");receiver.setSingleLine(true);
        receiver.setEllipsize(android.text.TextUtils.TruncateAt.END);
        // Receipt time belongs in the full DATA view; no second row is added here.
        receiver.setVisibility(View.GONE);panel.addView(receiver);
        // The full-screen workspace owns the detailed graphs, sources, history and share controls.
        // Never stack a second map, dashboard, share bar or decorative globe in this native view.
        return panel;
    }
    /** A single narrow source/navigation strip over an original map or live player. */
    public static View compact(Activity a,Duwm1683DeskCatalog.Desk desk){
        Duwm1684DeskDiagnostics.Snapshot snap=Duwm1684DeskDiagnostics.read(a,desk);
        LinearLayout panel=new LinearLayout(a);panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setGravity(Gravity.CENTER_VERTICAL);
        panel.setPadding(dp(a,7),dp(a,4),dp(a,7),dp(a,4));panel.setBackground(bg(a,true));
        TextView summary=text(a,desk.title.toUpperCase(Locale.US)+" / "+snap.state,12,DuwmUnifiedTheme.TEXT,true);
        summary.setTag("duwm-1687-overlay-state");summary.setSingleLine(true);
        summary.setEllipsize(android.text.TextUtils.TruncateAt.END);
        panel.addView(summary,new LinearLayout.LayoutParams(0,dp(a,43),1));
        panel.addView(action(a,"DETAILS",()->Duwm1687WorkspaceActivity.open(a,desk)),new LinearLayout.LayoutParams(dp(a,78),dp(a,43)));
        TextView hide=action(a,"×",()->panel.setVisibility(View.GONE));
        hide.setContentDescription("Hide source panel and reveal native map or media player");
        panel.addView(hide,new LinearLayout.LayoutParams(dp(a,42),dp(a,43)));
        return panel;
    }

}
