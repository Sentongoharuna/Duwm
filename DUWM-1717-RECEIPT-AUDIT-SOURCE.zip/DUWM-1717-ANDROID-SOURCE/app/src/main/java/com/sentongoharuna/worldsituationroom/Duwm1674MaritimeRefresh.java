package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Shared, bounded public AIS refresh for the HOME button and marine desk.
 * Only real returned GeoJSON features enter the cache. Empty/failed responses
 * never create simulated vessels. Existing good cache survives network failure.
 */
public final class Duwm1674MaritimeRefresh {
  private static final String PREF="rb11_marine";
  private static final ExecutorService IO=Executors.newSingleThreadExecutor();
  private static final Handler MAIN=new Handler(Looper.getMainLooper());
  private static final Object LOCK=new Object();
  private static boolean working=false;
  private static final long MIN_GAP_MS=90L*1000L;
  private static final int MAX_BYTES=6*1024*1024;
  private Duwm1674MaritimeRefresh(){}
  public static void refresh(Context context,Runnable onComplete){
    final Context app=context.getApplicationContext();
    SharedPreferences prefs=app.getSharedPreferences(PREF,Context.MODE_PRIVATE);
    if(!prefs.getString("endpoint","").trim().isEmpty()){
      prefs.edit().putString("last_error","CONFIGURED AIS GATEWAY: REFRESH INSIDE MARITIME DESK").apply();
      if(onComplete!=null)MAIN.post(onComplete);return;
    }
    synchronized(LOCK){
      long now=System.currentTimeMillis();
      if(working||now-prefs.getLong("home_public_attempt",0L)<MIN_GAP_MS){
        if(onComplete!=null)MAIN.post(onComplete);return;
      }
      working=true;prefs.edit().putLong("home_public_attempt",now).apply();
    }
    int region=Math.max(0,Math.min(GevMarineActivity.PUBLIC_REGIONS.length-1,prefs.getInt("public_region",16)));
    IO.execute(()->{
      HttpURLConnection conn=null;String failure="";
      try{
        double[] b=GevMarineActivity.PUBLIC_BBOX[region];
        String url=String.format(Locale.US,"https://ais.openwaters.io/v1/vessels?bbox=%.5f,%.5f,%.5f,%.5f",
            b[0],b[1],b[2],b[3]);
        conn=(HttpURLConnection)new URL(url).openConnection();
        conn.setConnectTimeout(9500);conn.setReadTimeout(14500);
        conn.setRequestProperty("Accept","application/geo+json, application/json");
        conn.setRequestProperty("User-Agent","develop.uganda-DUWM/1674.1");
        int http=conn.getResponseCode();
        if(http!=200)throw new IllegalStateException("PUBLIC AIS HTTP "+http);
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        try(InputStream in=conn.getInputStream()){
          byte[] buffer=new byte[8192];int n;
          while((n=in.read(buffer))!=-1){
            if(bytes.size()+n>MAX_BYTES)throw new IllegalStateException("AIS RESPONSE TOO LARGE");
            bytes.write(buffer,0,n);
          }
        }
        JSONObject data=new JSONObject(bytes.toString("UTF-8"));
        JSONArray features=data.optJSONArray("features");
        if(features==null)throw new IllegalStateException("NO GEOJSON FEATURES ARRAY");
        JSONArray rows=new JSONArray();
        for(int i=0;i<features.length()&&rows.length()<15000;i++){
          JSONObject feature=features.optJSONObject(i);if(feature==null)continue;
          JSONObject geom=feature.optJSONObject("geometry"),props=feature.optJSONObject("properties");
          if(geom==null||props==null)continue;
          JSONArray co=geom.optJSONArray("coordinates");if(co==null||co.length()<2)continue;
          double lon=co.optDouble(0,Double.NaN),lat=co.optDouble(1,Double.NaN);
          String mmsi=props.optString("mmsi",feature.optString("id","")).trim();
          if(!GevMarineMath.valid(lat,lon)||!GevMarineMath.validMmsi(mmsi))continue;
          JSONObject row=new JSONObject();row.put("lat",lat);row.put("lon",lon);
          row.put("mmsi",mmsi);row.put("name",props.optString("name",""));
          row.put("type",props.optString("type",""));
          row.put("speed",props.has("sog")?props.opt("sog"):JSONObject.NULL);
          row.put("course",props.has("cog")?props.opt("cog"):JSONObject.NULL);
          row.put("heading",props.has("heading")?props.opt("heading"):JSONObject.NULL);
          row.put("last_position_UTC",props.optString("seen",""));
          rows.put(row);
        }
        JSONObject result=new JSONObject();result.put("rows",rows);
        result.put("region",GevMarineActivity.PUBLIC_REGIONS[region]);
        result.put("source","Open Waters AIS / bounded public GeoJSON");
        result.put("status","live");result.put("sourceUrl",url);
        prefs.edit().putString("rows",result.toString()).putLong("last_fetch",System.currentTimeMillis())
            .putString("status","live").remove("last_error").apply();
      }catch(Exception ex){failure=ex.getClass().getSimpleName()+": "+String.valueOf(ex.getMessage());
        prefs.edit().putString("last_error",failure.substring(0,Math.min(150,failure.length()))).apply();
      }finally{
        if(conn!=null)conn.disconnect();
        synchronized(LOCK){working=false;}
        if(onComplete!=null)MAIN.post(onComplete);
      }
    });
  }
}
