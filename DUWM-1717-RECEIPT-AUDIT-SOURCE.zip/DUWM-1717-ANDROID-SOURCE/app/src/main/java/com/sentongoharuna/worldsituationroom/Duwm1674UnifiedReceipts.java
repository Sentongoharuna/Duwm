package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** One consistent source of truth for counts, dashboard LEDs and the home receipt ticker.
 * A successful fetch and a current observation are deliberately different states.
 */
public final class Duwm1674UnifiedReceipts {
  private Duwm1674UnifiedReceipts() {}
  public static final class Receipt {
    public final int entries;
    public final long receivedAt;
    public final boolean current;
    public final String detail;
    Receipt(int count, long at, boolean live, String explanation) {
      entries=count;receivedAt=at;current=live;detail=explanation;
    }
    public boolean hasReceipt(){return receivedAt>0L;}
    public String count(){return entries<0?"--":String.valueOf(entries);}
  }
  public static Receipt aircraft(Context c) {
    RunningballV25GlobalAircraftData.Snapshot a=RunningballV25GlobalAircraftData.read(c);
    boolean good=a.hasGood();
    boolean fresh=good&&a.ageMs()<60L*60L*1000L&&a.error.isEmpty()
      &&Duwm1674TimeGuard.recent(a.sourceAt,60L*60L*1000L);
    return new Receipt(good?a.providerRows:-1,good?a.receivedAt:0L,fresh,
        (good?a.status():"NO VERIFIED AIRCRAFT RECEIPT")+" / "+a.ageLabel());
  }
  public static Receipt maritime(Context c) {
    SharedPreferences p=c.getSharedPreferences("rb11_marine",Context.MODE_PRIVATE);
    long at=p.getLong("last_fetch",0L);
    int count=-1;
    String region="SELECT MARITIME REGION";
    try {
      JSONObject cache=new JSONObject(p.getString("rows","{}"));
      JSONArray rows=cache.optJSONArray("rows");
      if(rows!=null&&at>0)count=rows.length();
      region=cache.optString("region","REGIONAL AIS COVERAGE");
    }catch(Exception ignored){}
    String error=p.getString("last_error","");
    long age=Math.max(0L,System.currentTimeMillis()-at);
    boolean fresh=at>0L&&age<30L*60L*1000L&&error.isEmpty();
    String state=at<=0?(error.isEmpty()?"NO AIS RESPONSE • SELECT REGION":"AIS FETCH ERROR: "+error):
      (count==0?"0 VESSELS RETURNED IN "+region:"AIS POSITIONS / "+region)+
      (fresh?" • RECENT":" • SAVED CACHE")+(error.isEmpty()?"":" • LATEST ERROR: "+error);
    return new Receipt(count,at,fresh,state);
  }
  public static Receipt news(Context c) {
    int count=new NewsStore(c).load().size();
    long at=0L;String error="";
    for(String key:RunningballV25NewsRepository.KEYS) {
      count+=RunningballV25NewsRepository.articles(c,key).length();
      at=Math.max(at,RunningballV25NewsRepository.last(c,key));
      if(error.isEmpty())error=RunningballV25NewsRepository.error(c,key);
    }
    JSONObject external=RunningballV17Feeds.cached(c,RunningballV17Feeds.NEWS);
    JSONArray articles=external.optJSONArray("articles");
    if(articles!=null)count+=articles.length();
    at=Math.max(at,RunningballV17Feeds.received(c,RunningballV17Feeds.NEWS));
    boolean fresh=at>0&&System.currentTimeMillis()-at<60L*60L*1000L;
    String state=count>0?"CACHED SOURCE ENTRIES"+(fresh?" • RECENT":" • OLDER RECORDS"):
      (error.isEmpty()?"NO NEWS IN CACHE • REQUEST FEEDS":"NEWS SOURCE ERROR • "+error);
    return new Receipt(count,at,fresh,state);
  }
}
