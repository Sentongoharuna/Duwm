package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.view.WindowManager;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Full-height, native destinations for every registered intelligence desk.
 * Excludes the home Command Center and the wallpaper, which keep their original globe.
 * The system navigation bar remains available so users can always go back.
 */
public final class Duwm1683FullScreen {
  private Duwm1683FullScreen() {}
  public static void install(Application app) {
    app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks(){
      @Override public void onActivityCreated(Activity activity, Bundle state){prepare(activity);}
      @Override public void onActivityStarted(Activity a) {}
      @Override public void onActivityResumed(Activity a) {compact(a);}
      @Override public void onActivityPaused(Activity a) {}
      @Override public void onActivityStopped(Activity a) {}
      @Override public void onActivitySaveInstanceState(Activity a, Bundle out) {}
      @Override public void onActivityDestroyed(Activity a) {}
    });
  }
  public static void prepare(Activity a) {
    if (a instanceof MainActivity) return;
    if (a instanceof DuwmOptionsActivity || a instanceof Duwm1683DeskFullScreenActivity ||
        a instanceof NativeMediaActivity || Duwm1683DeskCatalog.find(a)!=null) {
      a.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
      a.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
      a.getWindow().setNavigationBarColor(DuwmUnifiedTheme.BACKGROUND);
    }
  }
  private static void compact(Activity a) {
    if (a instanceof MainActivity) return;
    if (Duwm1683DeskCatalog.find(a)==null) return;
    FrameLayout content=a.findViewById(android.R.id.content);
    if(content!=null && content.findViewWithTag("duwm1683-header-compacted")==null){
      // The content remains a full-height native Activity. Never replace the data View.
      content.setTag("duwm1683-header-compacted");
    }
  }
}
