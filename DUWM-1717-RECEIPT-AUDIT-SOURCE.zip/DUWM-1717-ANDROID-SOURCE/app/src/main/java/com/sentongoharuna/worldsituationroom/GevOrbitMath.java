package com.sentongoharuna.worldsituationroom;

/** Native orbital estimate based on publicly distributed mean orbital elements.
 * NOT SGP4: short-horizon illustrative Keplerian predictions, no perturbations.
 * Positions are NEVER live telemetry, and must not be used for navigation.
 * Inspiration: the public-orbit/ground-track features of God's Eye View;
 * this Java calculation is independently written for RUNNINGBALL2. */
public final class GevOrbitMath {
    private GevOrbitMath() {}
    public static final double EARTH_KM=6378.137d;
    private static final double MU=398600.4418d;
    public static final class Position {
        public final double lat,lon,altKm,radiusKm;
        public final boolean valid;
        Position(double lat,double lon,double altKm,double r,boolean valid){
            this.lat=lat;this.lon=lon;this.altKm=altKm;this.radiusKm=r;this.valid=valid;
        }
    }
    public static Position invalid(){return new Position(Double.NaN,Double.NaN,Double.NaN,Double.NaN,false);}
    private static boolean finite(double v){return !Double.isNaN(v)&&!Double.isInfinite(v);}
    public static boolean validElements(double mm,double eccentricity,double inc,double raan,double arg,double mean){
        return finite(mm)&&mm>0.1&&mm<20&&finite(eccentricity)&&eccentricity>=0&&eccentricity<0.6&&
            finite(inc)&&inc>=0&&inc<=180&&finite(raan)&&finite(arg)&&finite(mean);
    }
    public static Position propagate(double meanMotionRevsDay,double eccentricity,double inclinationDeg,
                                     double raanDeg,double argPerigeeDeg,double meanAnomalyDeg,
                                     long epochMs,long whenMs){
        if(!validElements(meanMotionRevsDay,eccentricity,inclinationDeg,raanDeg,argPerigeeDeg,meanAnomalyDeg)
                ||epochMs<=0)return invalid();
        double rate=meanMotionRevsDay*2d*Math.PI/86400d;
        double semi=Math.cbrt(MU/(rate*rate));
        double m=Math.toRadians(meanAnomalyDeg)+rate*((whenMs-epochMs)/1000d);
        m=Math.IEEEremainder(m,2d*Math.PI);
        double E=m;
        for(int k=0;k<15;k++){
            double d=(E-eccentricity*Math.sin(E)-m)/(1d-eccentricity*Math.cos(E));
            E-=d;
            if(Math.abs(d)<1e-12)break;
        }
        double nu=Math.atan2(Math.sqrt(1d-eccentricity*eccentricity)*Math.sin(E), Math.cos(E)-eccentricity);
        double radius=semi*(1d-eccentricity*Math.cos(E));
        double i=Math.toRadians(inclinationDeg), omega=Math.toRadians(argPerigeeDeg),raan=Math.toRadians(raanDeg);
        double u=omega+nu;
        double x=radius*(Math.cos(raan)*Math.cos(u)-Math.sin(raan)*Math.sin(u)*Math.cos(i));
        double y=radius*(Math.sin(raan)*Math.cos(u)+Math.cos(raan)*Math.sin(u)*Math.cos(i));
        double z=radius*Math.sin(u)*Math.sin(i);
        double jd=2440587.5d+whenMs/86400000d;
        double centuries=(jd-2451545d)/36525d;
        double gmstDeg=280.46061837d+360.98564736629d*(jd-2451545d)+0.000387933d*centuries*centuries-
          centuries*centuries*centuries/38710000d;
        double earthRotation=Math.toRadians(gmstDeg%360d);
        double lat=Math.toDegrees(Math.atan2(z,Math.hypot(x,y)));
        double lon=Math.toDegrees(Math.atan2(y,x)-earthRotation);
        lon=((lon+540d)%360d)-180d;
        if(!finite(lat)||!finite(lon)||radius<=EARTH_KM)return invalid();
        return new Position(lat,lon,radius-EARTH_KM,radius,true);
    }
    /** Geometric look angle from an observer at sea level; ignores refraction and terrain. */
    public static double elevationDeg(Position p,double observerLat,double observerLon){
        if(p==null||!p.valid||!GevGeo.valid(observerLat,observerLon))return Double.NaN;
        double a=Math.toRadians(observerLat),b=Math.toRadians(p.lat),d=Math.toRadians(p.lon-observerLon);
        double cosCentral=Math.sin(a)*Math.sin(b)+Math.cos(a)*Math.cos(b)*Math.cos(d);
        cosCentral=Math.max(-1d,Math.min(1d,cosCentral));
        double up=p.radiusKm*cosCentral-EARTH_KM;
        double horizontal=p.radiusKm*Math.sqrt(Math.max(0d,1d-cosCentral*cosCentral));
        return Math.toDegrees(Math.atan2(up,horizontal));
    }
    public static long periodSeconds(double meanMotionRevsDay){
        return finite(meanMotionRevsDay)&&meanMotionRevsDay>0d?Math.round(86400d/meanMotionRevsDay):0;
    }
}
