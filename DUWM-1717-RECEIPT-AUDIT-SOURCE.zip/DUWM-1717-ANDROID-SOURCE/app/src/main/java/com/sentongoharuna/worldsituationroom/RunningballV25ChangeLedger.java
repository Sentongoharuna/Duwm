package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
/** Verified receipt/figure changes only; never generates synthetic traffic or headlines. */
public final class RunningballV25ChangeLedger {
  private static final String PREF="rb25_change_ledger";private RunningballV25ChangeLedger(){}
  public static synchronized String update(Context c){
    SharedPreferences store=c.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);
    JSONArray history;try{history=new JSONArray(store.getString("events","[]"));}catch(Exception e){history=new JSONArray();}
    SharedPreferences.Editor e=store.edit();String last="";
    for(int i=0;i<RunningballV25Sources.IDS.length;i++){
      RunningballV25Sources.Result r=RunningballV25Sources.read(c,i);
      if(r.fetchedAt<=0||"--".equals(r.value))continue;
      String id="last_"+r.key;long previousStamp=store.getLong(id+"_when",0L);
      String previousValue=store.getString(id+"_value","");
      if(previousStamp==r.fetchedAt)continue;
      e.putLong(id+"_when",r.fetchedAt).putString(id+"_value",r.value);
      if(previousStamp<=0)continue; // first observation establishes baseline, never a new event
      if(previousValue.equals(r.value))continue; // a refreshed count is not a new incident
      String type="REPORTED VALUE CHANGED";
      JSONObject event=new JSONObject();try{
        event.put("received",r.fetchedAt);event.put("source",r.provider);event.put("type",type);
        event.put("detail",RunningballV25Sources.NAMES[i]+": "+previousValue+" → "+r.value);
        event.put("coverage",r.coverage);history.put(event);
        last=type+" / "+RunningballV25Sources.NAMES[i];
      }catch(Exception ignored){}
    }
    JSONArray next=new JSONArray();for(int i=Math.max(0,history.length()-30);i<history.length();i++)next.put(history.opt(i));
    e.putString("events",next.toString());e.apply();return last;
  }
  public static String summary(Context c){
    JSONArray a;try{a=new JSONArray(c.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("events","[]"));}
    catch(Exception ignored){return "NO VERIFIED CHANGES RECORDED";}
    if(a.length()==0)return "NO VERIFIED CHANGES RECORDED";
    StringBuilder out=new StringBuilder();for(int i=a.length()-1;i>=Math.max(0,a.length()-5);i--){
      JSONObject item=a.optJSONObject(i);if(item==null)continue;
      out.append(item.optString("type")).append(" · ").append(item.optString("detail"));
      if(i>Math.max(0,a.length()-5))out.append("\n");
    }return out.toString();
  }
}
