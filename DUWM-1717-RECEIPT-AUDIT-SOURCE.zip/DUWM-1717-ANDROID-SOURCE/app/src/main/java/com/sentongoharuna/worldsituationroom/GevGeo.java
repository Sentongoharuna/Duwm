package com.sentongoharuna.worldsituationroom;

/** MIT-adapted from Bilawal Sidhu's God's Eye View src/geoDistance.js.
 * Copyright (c) 2026 Bilawal Sidhu; see assets/gev-mit-license.txt.
 * Great-circle WGS84-style point utility; rejects invalid coordinates. */
public final class GevGeo {
    private static final double EARTH_RADIUS_KM=6371.0088d;
    private GevGeo() {}
    public static boolean valid(double lat,double lon) {
        return !Double.isNaN(lat) && !Double.isInfinite(lat) && lat>=-90d && lat<=90d &&
                !Double.isNaN(lon) && !Double.isInfinite(lon) && lon>=-180d && lon<=180d;
    }
    public static double km(double la1,double lo1,double la2,double lo2) {
        if(!valid(la1,lo1) || !valid(la2,lo2)) return Double.POSITIVE_INFINITY;
        double r1=Math.toRadians(la1),r2=Math.toRadians(la2);
        double dlat=Math.toRadians(la2-la1),dlon=Math.toRadians(lo2-lo1);
        double h=Math.pow(Math.sin(dlat/2d),2d)+Math.cos(r1)*Math.cos(r2)*Math.pow(Math.sin(dlon/2d),2d);
        double bound=Math.min(1d,Math.max(0d,h));
        return 2d*EARTH_RADIUS_KM*Math.atan2(Math.sqrt(bound),Math.sqrt(1d-bound));
    }
}
