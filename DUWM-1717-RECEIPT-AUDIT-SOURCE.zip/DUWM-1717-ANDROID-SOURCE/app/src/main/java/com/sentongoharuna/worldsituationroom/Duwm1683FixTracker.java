package com.sentongoharuna.worldsituationroom;

import java.util.LinkedHashSet;
import java.util.Iterator;

/** Source timestamp and identity gate; no synthetic location or extrapolation. */
public final class Duwm1683FixTracker {
    private static final long MAX_AGE_MS = 15L * 60L * 1000L;
    private static final long MAX_FUTURE_MS = 60L * 1000L;
    private static final int MAX_KEYS = 25000;
    private final LinkedHashSet<String> seen = new LinkedHashSet<>();

    public void clear() { seen.clear(); }

    public void seed(String canonicalId, long timestampMs) {
        if (canonicalId != null && !canonicalId.trim().isEmpty() && timestampMs > 0L) {
            add(canonicalId + "@" + timestampMs);
        }
    }

    public boolean acceptNew(String canonicalId, long timestampMs, long nowMs) {
        if (canonicalId == null || canonicalId.trim().isEmpty() || timestampMs <= 0L
                || nowMs <= 0L || timestampMs > nowMs + MAX_FUTURE_MS
                || timestampMs < nowMs - MAX_AGE_MS) return false;
        return add(canonicalId + "@" + timestampMs);
    }

    private boolean add(String key) {
        if (!seen.add(key)) return false;
        if (seen.size() > MAX_KEYS) {
            Iterator<String> iter = seen.iterator();
            while (iter.hasNext() && seen.size() > MAX_KEYS) {
                iter.next();
                iter.remove();
            }
        }
        return true;
    }
}
