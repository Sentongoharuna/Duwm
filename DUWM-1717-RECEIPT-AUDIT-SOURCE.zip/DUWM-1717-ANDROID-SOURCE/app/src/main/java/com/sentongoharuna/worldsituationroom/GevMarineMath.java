package com.sentongoharuna.worldsituationroom;

/** God's Eye View Port 05 / maritime coordinate and freshness contracts.
 * Independently adapted great-circle computations, not copied provider data. */
public final class GevMarineMath {
    private GevMarineMath() {}
    public static boolean finite(double a) { return !Double.isNaN(a) && !Double.isInfinite(a); }
    public static boolean valid(double lat,double lon){return finite(lat)&&finite(lon)&&lat>=-90&&lat<=90&&lon>=-180&&lon<=180;}
    public static double distanceNm(double lat1,double lon1,double lat2,double lon2){
        if(!valid(lat1,lon1)||!valid(lat2,lon2))return Double.POSITIVE_INFINITY;
        double a1=Math.toRadians(lat1),a2=Math.toRadians(lat2);
        double dLat=(a2-a1)/2d,dLon=Math.toRadians(lon2-lon1)/2d;
        double a=Math.sin(dLat)*Math.sin(dLat)+Math.cos(a1)*Math.cos(a2)*Math.sin(dLon)*Math.sin(dLon);
        return 6371.0088d*2d*Math.atan2(Math.sqrt(Math.min(1d,Math.max(0d,a))),Math.sqrt(Math.max(0d,1d-a)))/1.852d;
    }
    public static String freshness(long eventTime,long now){
        if(eventTime<=0L||eventTime>now+60000L)return "TIME UNKNOWN";
        long ms=now-eventTime;
        if(ms<30L*60L*1000L)return "RECENT";
        if(ms<2L*60L*60L*1000L)return "CACHED";
        return "STALE";
    }
    public static boolean validMmsi(String id){return id!=null&&id.matches("[0-9]{9}");}
    public static boolean reported(double speedKnots){return finite(speedKnots)&&speedKnots>=0d&&speedKnots<103d;}
}
