package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Mission status board: ALL 19 registered desks, original native destinations, receipt-only values. */
public final class Duwm1685MissionBoard {
    private Duwm1685MissionBoard(){}
    private static int dp(Activity a,float v){return Math.round(a.getResources().getDisplayMetrics().density*v);}
    private static TextView text(Activity a,String value,int size,int color,boolean bold){
        TextView t=new TextView(a);t.setText(value);t.setTextSize(size);t.setTextColor(color);
        t.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",Typeface.NORMAL));return t;
    }
    private static GradientDrawable surface(Activity a){
        GradientDrawable d=new GradientDrawable();d.setColor(DuwmUnifiedTheme.PANEL_SELECTED);
        d.setCornerRadius(dp(a,10));d.setStroke(dp(a,1),DuwmUnifiedTheme.BORDER);return d;
    }
    private static int[] sample(Activity a,int first,int last){
        int recent=0,held=0;
        for(int i=first;i<last;i++){
            Duwm1683DeskCatalog.Desk desk=Duwm1683DeskCatalog.ALL[i];
            Duwm1685ReceiptHistory.capture(a,desk);
            Duwm1684DeskDiagnostics.Snapshot s=Duwm1684DeskDiagnostics.read(a,desk);
            if("RECENT".equals(s.state))recent++;
            if(desk.source>=0)held++;
        }
        return new int[]{recent,held};
    }
    public static View createShortcuts(Activity a,Duwm1683DeskCatalog.Desk current){
        LinearLayout box=new LinearLayout(a);box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(a,10),dp(a,10),dp(a,10),dp(a,10));box.setBackground(surface(a));
        box.addView(text(a,"1685  /  SWITCH NATIVE INTELLIGENCE DESK",13,DuwmUnifiedTheme.ACCENT_BRIGHT,true));
        int here=0;
        for(int k=0;k<Duwm1683DeskCatalog.ALL.length;k++)if(Duwm1683DeskCatalog.ALL[k]==current)here=k;
        final int previous=(here+Duwm1683DeskCatalog.ALL.length-1)%Duwm1683DeskCatalog.ALL.length;
        final int next=(here+1)%Duwm1683DeskCatalog.ALL.length;
        LinearLayout actions=new LinearLayout(a);actions.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(a,54));ap.topMargin=dp(a,8);box.addView(actions,ap);
        int[] selections={previous,next};
        String[] names={"‹ "+Duwm1683DeskCatalog.ALL[previous].title,Duwm1683DeskCatalog.ALL[next].title+" ›"};
        for(int i=0;i<selections.length;i++){
            final int target=selections[i];
            TextView link=text(a,names[i],11,DuwmUnifiedTheme.TEXT,true);
            link.setGravity(Gravity.CENTER);link.setMaxLines(2);link.setPadding(dp(a,5),dp(a,4),dp(a,5),dp(a,4));
            link.setOnClickListener(v->a.startActivity(Duwm1683DeskCatalog.intent(a,Duwm1683DeskCatalog.ALL[target])));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.rightMargin=dp(a,6);
            actions.addView(link,lp);link.setBackground(surface(a));
        }
        return box;
    }
    public static View create(Activity a){
        LinearLayout root=new LinearLayout(a);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(a,12),dp(a,12),dp(a,12),dp(a,12));root.setBackground(surface(a));
        TextView title=text(a,"1685  /  INTELLIGENCE MISSION BOARD",17,DuwmUnifiedTheme.TEXT,true);
        root.addView(title);
        TextView desc=text(a,"19 native desks • real receipt health • one original globe",12,DuwmUnifiedTheme.ACCENT_BRIGHT,false);
        desc.setPadding(0,dp(a,5),0,dp(a,10));root.addView(desc);
        String[] names={"AIR / SEA / EARTH","NEWS / MEDIA","SOURCES / RECORDS"};
        int[][] bounds={{0,7},{7,13},{13,19}};
        for(int k=0;k<3;k++){
            int[] stats=sample(a,bounds[k][0],bounds[k][1]);
            final int selected=bounds[k][0];
            LinearLayout row=new LinearLayout(a);row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(a,10),dp(a,6),dp(a,6),dp(a,6));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(a,60));rp.bottomMargin=dp(a,6);
            root.addView(row,rp);
            GradientDrawable back=surface(a);row.setBackground(back);
            LinearLayout copy=new LinearLayout(a);copy.setOrientation(LinearLayout.VERTICAL);
            row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
            copy.addView(text(a,names[k],13,DuwmUnifiedTheme.TEXT,true));
            copy.addView(text(a,"REGISTERED "+(bounds[k][1]-bounds[k][0])+"  /  CONNECTED "+stats[1]+
                 "  /  RECENT "+stats[0],10,DuwmUnifiedTheme.MUTED,false));
            TextView open=text(a,"OPEN  ↗",12,DuwmUnifiedTheme.ACCENT_BRIGHT,true);
            open.setGravity(Gravity.CENTER);open.setPadding(dp(a,10),dp(a,8),dp(a,10),dp(a,8));
            row.addView(open);row.setOnClickListener(v->a.startActivity(Duwm1683DeskCatalog.intent(a,Duwm1683DeskCatalog.ALL[selected])));
        }
        TextView note=text(a,"'RECENT' only means recent *provider receipt*, not live position. Open any desk for observed data, source date and limitations.",11,DuwmUnifiedTheme.MUTED,false);
        note.setPadding(0,dp(a,6),0,0);root.addView(note);
        return root;
    }
}
