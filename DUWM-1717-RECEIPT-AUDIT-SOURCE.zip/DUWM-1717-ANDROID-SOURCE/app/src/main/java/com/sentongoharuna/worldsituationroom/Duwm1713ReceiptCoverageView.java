package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import java.util.Arrays;

/** 1713: 19 thin receipt-status segments, never an inferred global activity counter.
 * Values only classify Duwm1684DeskDiagnostics snapshots already read on-device.
 * No synthetic data, no network calls and no second globe.
 */
public final class Duwm1713ReceiptCoverageView extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private int[] states=new int[19];
    public Duwm1713ReceiptCoverageView(Context context){super(context);}
    public void setStatuses(int[] received){
        if(received==null || received.length!=19)
            throw new IllegalArgumentException("19 observed source states required");
        states=Arrays.copyOf(received,received.length);
        invalidate();
    }
    private int colorFor(int code){
        if(code==1)return DuwmUnifiedTheme.LIVE;
        if(code==2)return DuwmUnifiedTheme.WARNING;
        if(code==3)return DuwmUnifiedTheme.ACCENT;
        return DuwmUnifiedTheme.UNAVAILABLE;
    }
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        float density=getResources().getDisplayMetrics().density;
        float gap=2f*density;
        float width=getWidth(),height=getHeight();
        float usable=Math.max(0,width-gap*18);
        float item=usable/19f;
        float h=Math.min(height-2*density,9f*density);
        float y=(height-h)/2f;
        for(int i=0;i<states.length;i++){
            float x=i*(item+gap);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(colorFor(states[i]));
            canvas.drawRoundRect(new RectF(x,y,x+item,y+h),2f*density,2f*density,paint);
        }
    }
}
