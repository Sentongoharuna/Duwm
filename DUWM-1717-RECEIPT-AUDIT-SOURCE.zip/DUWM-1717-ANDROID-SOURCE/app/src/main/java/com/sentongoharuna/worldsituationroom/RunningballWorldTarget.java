package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Locale;

/** Shared worldwide observer: never pretend regional observations cover the planet. */
public final class RunningballWorldTarget {
  private static final String PREF="rb_global_observer_v1";
  private RunningballWorldTarget() {}
  public static boolean valid(double lat,double lon) {
    return !Double.isNaN(lat)&&!Double.isNaN(lon)&&!Double.isInfinite(lat)&&!Double.isInfinite(lon)
      &&lat>=-90.0d&&lat<=90.0d&&lon>=-180.0d&&lon<=180.0d;
  }
  private static SharedPreferences prefs(Context context) {
    return context.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);
  }
  public static boolean ready(Context context) {return prefs(context).getBoolean("chosen",false);}
  public static double lat(Context context) {return Double.longBitsToDouble(prefs(context).getLong("lat",Double.doubleToLongBits(0.0d)));}
  public static double lon(Context context) {return Double.longBitsToDouble(prefs(context).getLong("lon",Double.doubleToLongBits(0.0d)));}
  public static String label(Context context) {
    return ready(context)?prefs(context).getString("label","SELECTED WORLD REGION"):"NO REGION SELECTED";
  }
  public static String url(Context context) {
    if(!ready(context)||!valid(lat(context),lon(context)))throw new IllegalStateException("SELECT WORLD REGION FIRST");
    return RunningballV25RegionQuery.url(lat(context),lon(context));
  }
  public static String source(Context context){return prefs(context).getString("source","MAP");}
  public static long revision(Context context){return prefs(context).getLong("revision",0L);}
  public static String coverage(Context context){return ready(context)?RunningballV25RegionQuery.coverage(label(context)):"GLOBAL VIEW / NO REGIONAL AIRCRAFT QUERY";}
  /** Global reset leaves the historic provider snapshots intact, but invalidates the current regional aircraft display. */
  public static void resetGlobal(Context context){
    SharedPreferences state=prefs(context);
    if(!state.getBoolean("chosen",false))return;
    RunningballV25RegionCache.save(context,lat(context),lon(context));
    long rev=state.getLong("revision",0L)+1L;
    state.edit().putBoolean("chosen",false).putString("label","GLOBAL VIEW")
      .putString("source","GLOBAL_RESET").putLong("revision",rev).apply();
    context.getApplicationContext().getSharedPreferences("air_widget_v2",Context.MODE_PRIVATE)
      .edit().remove("last_snapshot").putString("last_error","NO REGION SELECTED").apply();
  }
  public static void choose(Context context,double lat,double lon,String label) {
    choose(context,lat,lon,label,"MAP");
  }
  public static void choose(Context context,double lat,double lon,String label,String source) {
    if(!valid(lat,lon))throw new IllegalArgumentException("World coordinates out of range");
    String clean=label==null?"WORLD REGION":label.trim();
    if(clean.isEmpty())clean="COORDINATE TARGET";
    if(clean.length()>48)clean=clean.substring(0,48);
    if(ready(context)&&Math.abs(lat(context)-lat)<0.00001d&&Math.abs(lon(context)-lon)<0.00001d)return;
    if(ready(context))RunningballV25RegionCache.save(context,lat(context),lon(context));
    prefs(context).edit().putBoolean("chosen",true).putLong("lat",Double.doubleToLongBits(lat))
       .putLong("lon",Double.doubleToLongBits(lon)).putString("label",clean)
       .putString("source",source==null?"MAP":source).putLong("revision",revision(context)+1L).apply();
    // Region switch must discard old regional observations; never show them under a new location.
    context.getApplicationContext().getSharedPreferences("air_widget_v2",Context.MODE_PRIVATE).edit()
       .remove("last_snapshot").putString("last_error","PREVIOUS REGION - AWAITING NEW DATA").apply();
    RunningballV25RegionCache.restore(context,lat,lon);
  }
}
