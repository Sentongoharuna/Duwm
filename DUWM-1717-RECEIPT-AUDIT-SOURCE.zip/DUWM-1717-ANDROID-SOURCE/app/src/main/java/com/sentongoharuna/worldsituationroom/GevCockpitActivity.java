package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.TimeZone;

/** GEV Cockpit Port 02. Native observed-data flight tracking / cockpit instrument presentation.
 * It is NOT an actual cockpit camera or a photorealistic 3D terrain camera.
 * Coordinates, altitude, heading and speed are read from ADS-B observations without prediction.
 * Previous RUNNINGBALL2 globe, wallpaper, radar, widgets, and share cards are left unchanged.
 */
public final class GevCockpitActivity extends Activity {
    private static final int BG=Color.rgb(5, 13, 34), PANEL=Color.rgb(13, 31, 61);
    private static final int CYAN=Color.rgb(85, 139, 223), LIGHT=Color.rgb(225,241,245);
    private static final int MUTED=Color.rgb(76, 120, 196), AMBER=Color.rgb(85, 139, 223);
    private static final int GREEN=Color.rgb(76, 120, 196);
    private static final String ACTION_REFRESH="com.sentongoharuna.worldsituationroom.AIR_WIDGET_REFRESH";
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable poll=new Runnable(){@Override public void run(){if(active){load();handler.postDelayed(this,3000L);}}};
    private boolean active, chase=false;
    private int chaseNm=30;
    private String hex="";
    private JSONArray items=new JSONArray();
    private JSONObject target;
    private long snapshotTime;
    private String error="";
    private TextView name, status, telemetry, source, toggle, range;
    private CockpitScene scene;
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private static String val(double n,String suffix){return GevCockpitMath.finite(n)?String.format(Locale.US,"%.0f%s",n,suffix):"NOT REPORTED";}
    private static String utc(long t){if(t<=0L)return "NO SNAPSHOT";
        SimpleDateFormat f=new SimpleDateFormat("HH:mm:ss 'UTC'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(t));}
    private boolean recent(){return snapshotTime>0 && error.isEmpty() &&
            System.currentTimeMillis()>=snapshotTime && System.currentTimeMillis()-snapshotTime<=180000L;}
    private TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);
        t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private GradientDrawable card(){GradientDrawable d=new GradientDrawable();d.setColor(PANEL);
        d.setCornerRadius(dp(22));d.setStroke(dp(1),Color.rgb(66, 104, 180));return d;}
    private TextView action(String title,Runnable r){TextView t=label(title,12,CYAN,true);
        t.setGravity(Gravity.CENTER);t.setBackground(card());t.setOnClickListener(v->r.run());return t;}
    @Override protected void onCreate(Bundle b){super.onCreate(b);RunningballV17Insets.install(this);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        hex=getIntent().getStringExtra("air_hex");if(hex==null)hex="";
        hex=hex.trim().toLowerCase(Locale.US);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);root.setPadding(dp(13),dp(12),dp(13),dp(10));
        root.addView(label("RUNNINGBALL2  /  GEV COCKPIT 02",12,CYAN,true),new LinearLayout.LayoutParams(-1,dp(28)));
        name=label("SELECTED AIRCRAFT",22,LIGHT,true);root.addView(name,new LinearLayout.LayoutParams(-1,dp(38)));
        status=label("AWAITING OBSERVED AIRCRAFT DATA",11,AMBER,true);root.addView(status,new LinearLayout.LayoutParams(-1,dp(36)));
        LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.HORIZONTAL);
        toggle=action("COCKPIT  /  CHASE",()->{chase=!chase;render();});
        top.addView(toggle,new LinearLayout.LayoutParams(0,dp(44),2f));
        range=action("30 NM",()->{chaseNm=chaseNm==10?30:chaseNm==30?60:10;render();});
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,dp(44),1f);rp.leftMargin=dp(7);top.addView(range,rp);
        root.addView(top,new LinearLayout.LayoutParams(-1,dp(44)));
        scene=new CockpitScene();LinearLayout.LayoutParams canvas=new LinearLayout.LayoutParams(-1,0,1f);canvas.topMargin=dp(10);
        root.addView(scene,canvas);
        telemetry=label("NO REPORT",13,LIGHT,false);telemetry.setPadding(dp(12),dp(7),dp(12),dp(7));telemetry.setBackground(card());
        LinearLayout.LayoutParams facts=new LinearLayout.LayoutParams(-1,dp(96));facts.topMargin=dp(8);root.addView(telemetry,facts);
        LinearLayout nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);
        TextView details=action("DETAILS",()->{if(target!=null){Intent i=new Intent(this,AirFlightDetailsActivity.class);
            i.putExtra("air_hex",hex);startActivity(i);}});
        TextView share=action("SHARE CARD",this::share);
        TextView refresh=action("REFRESH",this::requestRefresh);
        nav.addView(details,new LinearLayout.LayoutParams(0,dp(45),1f));
        LinearLayout.LayoutParams sh=new LinearLayout.LayoutParams(0,dp(45),1f);sh.leftMargin=dp(6);nav.addView(share,sh);
        LinearLayout.LayoutParams re=new LinearLayout.LayoutParams(0,dp(45),1f);re.leftMargin=dp(6);nav.addView(refresh,re);
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,dp(45));np.topMargin=dp(8);root.addView(nav,np);
        TextView earth=action("EARTH VIEW / REPORTED POSITION",this::openEarth);
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(40));ep.topMargin=dp(6);root.addView(earth,ep);
        source=label("PUBLIC ADS-B OBSERVATIONS • NO FUTURE POSITION PREDICTIONS",10,MUTED,false);
        source.setGravity(Gravity.CENTER);root.addView(source,new LinearLayout.LayoutParams(-1,dp(34)));
        setContentView(root);load();
    }
    private void openEarth(){
        Intent i=new Intent(this,GevEarthExploreActivity.class);
        if(target!=null){double a=target.optDouble("lat",Double.NaN),b=target.optDouble("lon",Double.NaN);
            if(GevEarthCoordinates.valid(a,b)){i.putExtra("geo_lat",a);i.putExtra("geo_lon",b);}}
        startActivity(i);
    }
    private void requestRefresh(){Intent i=new Intent(this,AirOperationsWidgets.Command.class);
        i.setAction(ACTION_REFRESH);sendBroadcast(i);
        status.setText("REFRESH REQUESTED • AWAITING NEW PROVIDER RESPONSE");}
    private void load(){JSONObject data=AirOperationsWidgets.lastData(this);
        items=data.optJSONArray("items");if(items==null)items=new JSONArray();
        snapshotTime=data.optLong("time",0L);
        error=getSharedPreferences("air_widget_v2",MODE_PRIVATE).getString("last_error","");
        target=null;
        for(int i=0;i<items.length();i++){JSONObject x=items.optJSONObject(i);
            if(x!=null&&!hex.isEmpty()&&hex.equalsIgnoreCase(x.optString("hex",""))){target=x;break;}}
        render();
    }
    private void render(){range.setText(chaseNm+" NM");
        toggle.setText(chase?"CHASE VIEW   ●":"COCKPIT HUD   ●");
        String quality=snapshotTime<=0?"NO OBSERVATION":recent()?"RECENT OBSERVATION":"CACHED / STALE OBSERVATION";
        status.setText(quality+"  •  "+utc(snapshotTime));status.setTextColor(recent()?GREEN:AMBER);
        if(target==null){name.setText(hex.isEmpty()?"NO AIRCRAFT SELECTED":"AIRCRAFT "+hex.toUpperCase(Locale.US));
            telemetry.setText("CONTACT NOT PRESENT IN LAST REPORT.\nGo back to Contacts or Radar and select an aircraft.");
        }else{
            String flight=target.optString("flight","").trim();name.setText((flight.isEmpty()?"AIRCRAFT":flight)+" / "+hex.toUpperCase(Locale.US));
            double lat=target.optDouble("lat",Double.NaN),lon=target.optDouble("lon",Double.NaN);
            telemetry.setText("ALT "+(target.optBoolean("ground",false)?"ON GROUND":val(target.optDouble("alt",Double.NaN)," FT"))+
              "   •   SPEED "+val(target.optDouble("speed",Double.NaN)," KT")+
              "\nCOURSE "+GevCockpitMath.headingText(target.optDouble("heading",Double.NaN))+"°"+
              "   •   LAT "+(GevCockpitMath.finite(lat)?String.format(Locale.US,"%.4f",lat):"—")+
              "\nLON "+(GevCockpitMath.finite(lon)?String.format(Locale.US,"%.4f",lon):"—")+
              "   •   "+(chase?"TARGET-CENTERED OBSERVATION":"OBSERVED FLIGHT TELEMETRY"));
        }
        source.setText("ADSB.LOL  •  "+(recent()?"RECENT":"NOT LIVE")+
           "  •  OBSERVED POSITION ONLY"+(error.isEmpty()?"":" • SOURCE ERROR"));
        if(scene!=null)scene.invalidate();
    }
    private void share(){if(target==null||snapshotTime<=0)return;
        double lat=target.optDouble("lat",Double.NaN),lon=target.optDouble("lon",Double.NaN);
        LinkedHashMap<String,String> info=new LinkedHashMap<>();
        info.put("ICAO HEX",hex.toUpperCase(Locale.US));
        info.put("ALTITUDE",target.optBoolean("ground",false)?"GROUND":val(target.optDouble("alt",Double.NaN)," FT"));
        info.put("SPEED",val(target.optDouble("speed",Double.NaN)," KT"));
        info.put("COURSE",GevCockpitMath.headingText(target.optDouble("heading",Double.NaN))+"°");
        info.put("POSITION",GevGeo.valid(lat,lon)?String.format(Locale.US,"%.4f, %.4f",lat,lon):"NOT REPORTED");
        info.put("DISPLAY",chase?"OBSERVED CHASE":"COCKPIT TELEMETRY HUD");
        ShareCardRenderer.share(this,new ShareCardData(
            target.optString("flight",hex),"Cockpit-style instrument display based on a reported aircraft position.",
            recent()?"RECENT OBSERVATION":"CACHED / STALE",recent()?"RECENT POSITION":"NOT LIVE",
            "AVIATION",RunningballWorldTarget.label(this),1,"ADSB.LOL","https://adsb.lol/",snapshotTime,
            lat,lon,info,recent()?CYAN:AMBER,
            "Not a live video feed, simulated flight, or aircraft navigation system."));
    }
    @Override protected void onResume(){super.onResume();active=true;handler.removeCallbacks(poll);handler.post(poll);
        if(snapshotTime<=0 || System.currentTimeMillis()-snapshotTime>180000L)requestRefresh();}
    @Override protected void onPause(){active=false;handler.removeCallbacks(poll);super.onPause();}
    @Override protected void onDestroy(){handler.removeCallbacks(poll);super.onDestroy();}

    private final class CockpitScene extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private final Path arrow=new Path();
        CockpitScene(){super(GevCockpitActivity.this);setBackground(card());}
        private void line(Canvas c,float x1,float y1,float x2,float y2,int color,float thick){p.setStyle(Paint.Style.STROKE);p.setColor(color);p.setStrokeWidth(dp(thick));c.drawLine(x1,y1,x2,y2,p);p.setStyle(Paint.Style.FILL);}
        private void txt(Canvas c,String s,float x,float y,int size,int color,boolean center){p.setStyle(Paint.Style.FILL);
            p.setTextSize(dp(size));p.setTypeface(Typeface.create(Typeface.MONOSPACE,Typeface.BOLD));p.setColor(color);
            p.setTextAlign(center?Paint.Align.CENTER:Paint.Align.LEFT);c.drawText(s,x,y,p);p.setTextAlign(Paint.Align.LEFT);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f;
            c.drawColor(PANEL);if(target==null){txt(c,"NO SELECTED CONTACT",cx,cy,13,AMBER,true);return;}
            double lat=target.optDouble("lat",Double.NaN),lon=target.optDouble("lon",Double.NaN);
            double heading=target.optDouble("heading",Double.NaN);
            boolean positionOk=GevGeo.valid(lat,lon);
            float r=Math.min(w,h)*.40f;
            if(chase){
                p.setColor(Color.rgb(27, 56, 104));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));
                for(int i=1;i<=4;i++)c.drawCircle(cx,cy,r*i/4f,p);
                line(c,cx-r,cy,cx+r,cy,Color.rgb(40, 76, 135),1);
                line(c,cx,cy-r,cx,cy+r,Color.rgb(40, 76, 135),1);
                p.setStyle(Paint.Style.FILL);txt(c,"TARGET-CENTERED  /  "+chaseNm+" NM",dp(13),dp(24),11,CYAN,false);
                txt(c,GevCockpitMath.finite(heading)?"UP = TRACK "+GevCockpitMath.headingText(heading)+" DEG":"UP = NORTH",dp(13),dp(42),10,MUTED,false);
                if(positionOk){
                    for(int i=0;i<items.length();i++){
                        JSONObject x=items.optJSONObject(i);if(x==null||hex.equalsIgnoreCase(x.optString("hex","")))continue;
                        double a=x.optDouble("lat",Double.NaN),b=x.optDouble("lon",Double.NaN);
                        if(!GevGeo.valid(a,b))continue;
                        double nm=GevGeo.km(lat,lon,a,b)/1.852d;
                        if(!GevCockpitMath.finite(nm)||nm>chaseNm)continue;
                        double bearing=GevCockpitMath.bearing(lat,lon,a,b);
                        double relative=GevCockpitMath.relativeBearing(bearing,GevCockpitMath.finite(heading)?heading:0);
                        float xPos=cx+(float)(Math.sin(Math.toRadians(relative))*nm/chaseNm*r);
                        float yPos=cy-(float)(Math.cos(Math.toRadians(relative))*nm/chaseNm*r);
                        p.setColor(GREEN);c.drawCircle(xPos,yPos,dp(3),p);
                    }
                }
                p.setStyle(Paint.Style.FILL);p.setColor(CYAN);c.drawCircle(cx,cy,dp(6),p);
                line(c,cx,cy-dp(18),cx,cy-dp(7),LIGHT,2);
                txt(c,"SELECTED AIRCRAFT",cx,cy+dp(28),11,LIGHT,true);
                if(!positionOk)txt(c,"POSITION NOT REPORTED",cx,cy+dp(49),11,AMBER,true);
            }else{
                // Neutral instrument reference only: ADS-B does not provide an attitude/pitch feed.
                p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(30, 61, 107));c.drawRect(0,0,w,cy,p);
                p.setColor(Color.rgb(13, 31, 61));c.drawRect(0,cy,w,h,p);
                line(c,0,cy,w,cy,Color.rgb(76, 120, 196),2);
                line(c,cx-dp(40),cy,cx-dp(12),cy,CYAN,2);
                line(c,cx+dp(12),cy,cx+dp(40),cy,CYAN,2);
                line(c,cx,cy-dp(9),cx,cy+dp(9),CYAN,2);
                txt(c,"COCKPIT TELEMETRY",cx,dp(30),13,CYAN,true);
                txt(c,"ATTITUDE NOT REPORTED",cx,cy+dp(42),11,AMBER,true);
                txt(c,"COURSE "+GevCockpitMath.headingText(heading)+" DEG",cx,cy-dp(45),18,LIGHT,true);
                txt(c,"ALT "+(target.optBoolean("ground",false)?"GROUND":val(target.optDouble("alt",Double.NaN)," FT")),dp(12),cy-dp(9),11,GREEN,false);
                txt(c,"SPD "+val(target.optDouble("speed",Double.NaN)," KT"),dp(12),cy+dp(25),11,GREEN,false);
            }
            txt(c,recent()?"RECENT ADS-B REPORT":"STALE / CACHED • NOT LIVE",cx,h-dp(22),11,recent()?GREEN:AMBER,true);
        }
    }
}
