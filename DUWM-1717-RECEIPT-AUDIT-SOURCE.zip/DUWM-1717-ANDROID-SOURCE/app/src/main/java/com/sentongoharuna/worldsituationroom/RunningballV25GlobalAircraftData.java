package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Independent V25 worldwide OpenSky adapter, not an adaptation of GEV.
 * Original WorldDataRepository and SatelliteMapView remain untouched.
 * GLOBAL means positions returned by OpenSky coverage, NOT all aircraft in existence.
 */
public final class RunningballV25GlobalAircraftData {
  private static final String PREF="rb25_opensky_global_v2";
  private static final long AUTO_POLL_MS=15L*60L*1000L, MANUAL_GAP_MS=30L*1000L,
      CACHE_TTL_MS=6L*60L*60L*1000L;
  private static final int MAX_POINTS=22000, MAX_BYTES=32*1024*1024, MAX_COMPACT_CHARS=2600000;
  private static final Object LOCK=new Object();
  private static final ExecutorService WORK=Executors.newSingleThreadExecutor();
  private static final Handler UI=new Handler(Looper.getMainLooper());
  private static boolean fetching=false;
  private RunningballV25GlobalAircraftData(){}
  private static SharedPreferences pref(Context c){return c.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);}
  public static final class Snapshot {
    public final long receivedAt,sourceAt,attemptAt,nextAllowedAt;
    public final int lastHttp;
    public final int providerRows,positionRows,displayRows;
    public final String error;
    public final JSONArray points;
    public final JSONArray priorPoints;
    public final long priorSourceAt;
    Snapshot(SharedPreferences p,boolean forWallpaper){
      receivedAt=p.getLong("receivedAt",0L);sourceAt=p.getLong("sourceAt",0L);attemptAt=p.getLong("attemptAt",0L);nextAllowedAt=p.getLong("nextAllowedAt",0L);lastHttp=p.getInt("lastHttp",0);
      providerRows=p.getInt("providerRows",-1);positionRows=p.getInt("positionRows",-1);
      error=p.getString("error","");
      JSONArray parsed;
      try {String raw=p.getString(forWallpaper?"wallpaperPoints":"points", "[]");parsed=raw.length()<=MAX_COMPACT_CHARS?new JSONArray(raw):new JSONArray();}
      catch(Exception ignored){parsed=new JSONArray();}
      points=parsed;displayRows=parsed.length();
      priorSourceAt=p.getLong("priorSourceAt",0L);
      JSONArray history;
      try {String old=p.getString("priorPoints","[]");history=old.length()<=MAX_COMPACT_CHARS?new JSONArray(old):new JSONArray();}
      catch(Exception invalid){history=new JSONArray();}
      priorPoints=history;
    }
    public boolean hasGood(){return receivedAt>0&&providerRows>=0&&positionRows>=0;}
    public long ageMs(){return receivedAt<=0?Long.MAX_VALUE:Math.max(0L,System.currentTimeMillis()-receivedAt);}
    public String status(){
      if(!hasGood())return error.isEmpty()?"NO VERIFIED GLOBAL AIRCRAFT DATA": (lastHttp==429?"RATE LIMITED / NO DATA":"SOURCE FAILED / NO DATA");
      if(ageMs()>CACHE_TTL_MS)return "STALE / CACHE EXPIRED";
      if(sourceAt>0&&System.currentTimeMillis()-sourceAt>CACHE_TTL_MS)return "STALE / PROVIDER TIME";
      if(!error.isEmpty())return "OFFLINE / LAST GOOD CACHE";
      return ageMs()<=AUTO_POLL_MS?"RECEIVED / SOURCE-AGED":"DELAYED / CACHED";
    }
    public String countLabel(){return hasGood()&&ageMs()<=CACHE_TTL_MS?String.valueOf(providerRows):"--";}
    /** Provider observation timestamp is distinct from when the phone fetched the data. */
    public String providerAgeLabel(){
      if(sourceAt<=0)return "PROVIDER TIMESTAMP MISSING";
      long minutes=Math.max(0L,(System.currentTimeMillis()-sourceAt)/60000L);
      return minutes<60?minutes+" MIN OLD":(minutes/60)+" H "+(minutes%60)+" MIN OLD";
    }
    public String nextCheckLabel(){
      long left=Math.max(0L,nextAllowedAt-System.currentTimeMillis());
      return left<=0?"READY":(left/60000L+1L)+" MIN";
    }
    public String ageLabel(){
      if(!hasGood())return "NO SUCCESSFUL FETCH";
      long m=ageMs()/60000L;return m<60?m+" MIN AGO":(m/60)+" H "+(m%60)+" MIN AGO";
    }
  }
  public static Snapshot read(Context c){return new Snapshot(pref(c),false);}
  /** Small cache-only wallpaper sample: do not parse the complete worldwide map in its draw cycle. */
  public static Snapshot readWallpaper(Context c){return new Snapshot(pref(c),true);}
  /** Ordinary background/UI refresh. Anonymous worldwide requests use a conservative
   * cadence because OpenSky credits are shared across IP addresses. */
  public static void refresh(Context context, Runnable callback){request(context, callback, false);}
  /** Explicit user action: no fixed 15-minute app-side lock. The network's 429
   * Retry-After remains authoritative. A 30s duplicate-request guard prevents
   * accidental repeated taps and wasting the anonymous credit pool. */
  public static void refreshNow(Context context, Runnable callback){request(context, callback, true);}
  private static void request(Context context,Runnable callback,boolean manual){
    Context app=context.getApplicationContext();long now=System.currentTimeMillis();
    synchronized(LOCK){
      SharedPreferences p=pref(app);
      long attempted=p.getLong("attemptAt",0L);
      long gap=manual?MANUAL_GAP_MS:AUTO_POLL_MS;
      if(fetching||now<p.getLong("nextAllowedAt",0L)||now<attempted+gap){
        if(callback!=null)UI.post(callback);return;
      }
      fetching=true;p.edit().putLong("attemptAt",now).apply();
    }
    WORK.execute(()->{
      try{fetch(app);}catch(Exception ex){
        String message=ex.getClass().getSimpleName()+": "+(ex.getMessage()==null?"REQUEST FAILED":ex.getMessage());
        pref(app).edit().putString("error",message.substring(0,Math.min(180,message.length()))).apply();
      }finally{
        synchronized(LOCK){fetching=false;}
        if(callback!=null)UI.post(callback);
      }
    });
  }
  private static void fetch(Context app) throws Exception {
    HttpURLConnection connection=null;
    try{
      // Single worldwide call; no unapproved scraping or insecure API credentials.
      connection=(HttpURLConnection)new URL(AppConfig.OPENSKY_STATES).openConnection();
      connection.setRequestMethod("GET");connection.setConnectTimeout(12000);connection.setReadTimeout(15000);
      connection.setRequestProperty("Accept","application/json");
      connection.setRequestProperty("User-Agent",AppConfig.USER_AGENT);
      int http=connection.getResponseCode();
      if(http!=200){
        String retry=connection.getHeaderField("X-Rate-Limit-Retry-After-Seconds");
        long pause=(http==429?AUTO_POLL_MS:MANUAL_GAP_MS);
        if(http==429){
          try{pause=Math.max(pause,Math.min(604800L,Long.parseLong(retry))*1000L);}catch(Exception ignored){}
        }
        if(http==429)pref(app).edit().putInt("lastHttp",http)
          .putLong("nextAllowedAt",System.currentTimeMillis()+pause).apply();
        else pref(app).edit().putInt("lastHttp",http)
          .putLong("nextAllowedAt",System.currentTimeMillis()+MANUAL_GAP_MS).apply();
        throw new IllegalStateException("OPEN SKY HTTP "+http+
          (http==401?" / OAUTH2 TOKEN REQUIRED":"")+
          (http==429?" / PROVIDER QUOTA EXCEEDED":"")+
          (retry==null?"":" / RETRY AFTER "+retry+" SECONDS"));
      }
      ByteArrayOutputStream output=new ByteArrayOutputStream();
      try(InputStream in=connection.getInputStream()){
        byte[] buffer=new byte[8192];int n;
        while((n=in.read(buffer))!=-1){
          if(output.size()+n>MAX_BYTES)throw new IllegalStateException("OpenSky response exceeds device memory safety bound");
          output.write(buffer,0,n);
        }
      }
      JSONObject response=new JSONObject(output.toString("UTF-8"));
      JSONArray states=response.optJSONArray("states");
      if(states==null)throw new IllegalStateException("No OpenSky states array");
      long sourceSeconds=response.optLong("time",0L);
      if(sourceSeconds<=0)throw new IllegalStateException("Missing provider source time");
      if(!Duwm1674TimeGuard.recent(sourceSeconds,21600000L))
        throw new IllegalStateException("PROVIDER SOURCE DATE IS NOT CURRENT / HISTORICAL TRACK REJECTED");
      int valid=0;
      for(int i=0;i<states.length();i++){
        JSONArray p=states.optJSONArray(i);
        if(validPosition(p))valid++;
      }
      int stride=Math.max(1,(valid+MAX_POINTS-1)/MAX_POINTS);
      int accepted=0;
      JSONArray compact=new JSONArray();
      for(int i=0;i<states.length();i++){
        JSONArray p=states.optJSONArray(i);if(!validPosition(p))continue;
        if((accepted++%stride)!=0)continue;
        JSONArray row=new JSONArray();
        row.put(p.optDouble(6));row.put(p.optDouble(5));
        row.put(p.optString(0,"").trim().toUpperCase(Locale.US));
        row.put(p.isNull(1)?"":p.optString(1,"").trim());
        row.put(p.isNull(7)?JSONObject.NULL:p.optDouble(7));
        row.put(p.isNull(9)?JSONObject.NULL:p.optDouble(9));
        row.put(p.isNull(10)?JSONObject.NULL:p.optDouble(10));
        row.put(p.isNull(3)?JSONObject.NULL:p.optLong(3));
        row.put(p.isNull(8)?JSONObject.NULL:p.optBoolean(8));
        row.put(p.isNull(2)?"":p.optString(2,"").trim());
        compact.put(row);
        if(compact.length()>=MAX_POINTS)break;
      }
      // Preserve the full verified position count, but cap the disk-backed cache
      // conservatively to protect lower-memory phones. If needed, spatially stride
      // the whole sample rather than dropping all records from the array's tail.
      if(compact.toString().length()>MAX_COMPACT_CHARS){
        JSONArray reduced=new JSONArray();int factor=2;
        while(true){
          reduced=new JSONArray();for(int i=0;i<compact.length();i+=factor)reduced.put(compact.optJSONArray(i));
          if(reduced.toString().length()<=MAX_COMPACT_CHARS||factor>=compact.length())break;
          factor*=2;
        }
        compact=reduced;
      }
      JSONArray small=new JSONArray();
      int miniStride=Math.max(1,(compact.length()+54)/55);
      for(int i=0;i<compact.length();i+=miniStride){small.put(compact.optJSONArray(i));}
      // A legitimate empty response is valid; show 0 only if the provider said 0.
      // Keep at most ONE preceding provider sample for same-aircraft two-fix comparison.
      // Never synthesize a track from heading/speed or update a prior record when time is unchanged.
      SharedPreferences oldCache=pref(app);
      long olderSourceAt=oldCache.getLong("sourceAt",0L);
      long newSourceAt=sourceSeconds*1000L;
      SharedPreferences.Editor twoFix=oldCache.edit();
      if(newSourceAt>olderSourceAt && olderSourceAt>0L && newSourceAt-olderSourceAt<=5400000L){
        String previous=oldCache.getString("points","[]");
        if(previous.length()<=MAX_COMPACT_CHARS){twoFix.putLong("priorSourceAt",olderSourceAt).putString("priorPoints",previous);}
        else{twoFix.remove("priorSourceAt").remove("priorPoints");}
      } else if(newSourceAt>olderSourceAt){twoFix.remove("priorSourceAt").remove("priorPoints");}
      twoFix.putLong("receivedAt",System.currentTimeMillis())
        .putLong("sourceAt",sourceSeconds*1000L)
        .putInt("providerRows",states.length())
        .putInt("positionRows",valid)
        .putString("points",compact.toString())
        .putString("wallpaperPoints",small.toString())
        .putInt("lastHttp",200)
        .putLong("nextAllowedAt",System.currentTimeMillis()+MANUAL_GAP_MS)
        .remove("error").apply();
    }finally{if(connection!=null)connection.disconnect();}
  }
  private static boolean validPosition(JSONArray a){
    if(a==null||a.length()<11||a.isNull(5)||a.isNull(6))return false;
    double lon=a.optDouble(5,Double.NaN),lat=a.optDouble(6,Double.NaN);
    return Double.isFinite(lat)&&Double.isFinite(lon)&&Math.abs(lat)<=90&&Math.abs(lon)<=180;
  }
}
