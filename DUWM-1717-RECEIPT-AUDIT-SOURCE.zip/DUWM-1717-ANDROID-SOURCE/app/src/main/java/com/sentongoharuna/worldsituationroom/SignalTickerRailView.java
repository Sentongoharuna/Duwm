package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/**
 * 1705 restoration: perpetual 60px/s native horizontal news/source ticker.
 * Only source-attributed provider observations are rendered. Unlike a TextView
 * MARQUEE this scroll is not dependent on text focus or selection state.
 */
public final class SignalTickerRailView extends View {
    private final Paint base = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glyph = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF bounds = new RectF();
    private final SimpleDateFormat clock = new SimpleDateFormat("HH:mm 'UTC'", Locale.US);
    private final String lane;
    private final boolean reverse;
    private String content = "AWAITING RECEIVED SOURCE REPORTS  /  NO EVENTS GENERATED";
    private float contentWidth;
    private long frameStart;
    private int receivedCount;
    private Signal.Layer channel1706;
    private int speed1706 = 52;
    private List<Signal> lastReceived1706 = java.util.Collections.emptyList();

    /** A local presentation-only filter. No signals or provider records are deleted. */
    public void set1706Channel(Signal.Layer channel) {
        if (channel1706 == channel) return;
        channel1706 = channel;
        render1706ReceivedTicker(lastReceived1706);
    }

    /** True speed control in density-independent pixels per second. */
    public void set1706Speed(int dpPerSecond) {
        speed1706 = Math.max(18, Math.min(100, dpPerSecond));
        postInvalidateOnAnimation();
    }

    public Signal.Layer get1706Channel() { return channel1706; }


    public SignalTickerRailView(Context context, String lane, boolean reverse) {
        super(context);
        this.lane = lane;
        this.reverse = reverse;
        clock.setTimeZone(TimeZone.getTimeZone("UTC"));
        glyph.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setContentDescription(lane + ": waiting for actual source reports");
    }

    public void setSignals(List<Signal> observations) {
        lastReceived1706 = observations == null ? java.util.Collections.emptyList()
                : new java.util.ArrayList<>(observations);
        render1706ReceivedTicker(lastReceived1706);
    }

    /** Two source-backed lanes remain independent; category only affects this rail. */
    private void render1706ReceivedTicker(List<Signal> observations) {
        StringBuilder line = new StringBuilder();
        int count = 0;
        if (observations != null) {
            for (Signal s : observations) {
                if (s == null || s.title == null || s.title.trim().isEmpty()) continue;
                if (channel1706 != null && channel1706 != s.layer) continue;
                if (count >= 22) break;
                if (count > 0) line.append("     ◆     ");
                line.append('[').append(s.layer == null ? "REPORT" : s.layer.name())
                        .append("] ").append(shorten(s.title, 78));
                if (s.source != null && !s.source.trim().isEmpty()) {
                    line.append("  •  ").append(shorten(s.source, 36));
                }
                line.append("  /  ").append(s.timestampMs > 0L
                        ? clock.format(new Date(s.timestampMs)) : "TIME NOT SUPPLIED");
                count++;
            }
        }
        if (count == 0) line.append(channel1706 == null
                ? "AWAITING RECEIVED SOURCE REPORTS  /  NO EVENTS GENERATED"
                : "NO RECEIVED " + channel1706.name() + " REPORTS IN THE CURRENT SNAPSHOT");
        line.append("       ◆       ");
        String next = line.toString();
        if (!next.equals(content)) {
            content = next;
            contentWidth = 0f;
            frameStart = SystemClock.uptimeMillis();
        }
        receivedCount = count;
        setContentDescription(lane + ": " + count + " received reports"
                + (channel1706 == null ? "" : " for " + channel1706.name())
                + ", tap for World Watch; hold for signal channels");
        postInvalidateOnAnimation();
    }

    private static String shorten(String text, int max) {
        String cleaned = text.replace('\n', ' ').replace('\r', ' ').trim();
        return cleaned.length() > max ? cleaned.substring(0, max - 1) + "…" : cleaned;
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float d = getResources().getDisplayMetrics().density;
        float textScale = getResources().getDisplayMetrics().scaledDensity;
        if (getWidth() <= 0 || getHeight() <= 0) return;
        float h = getHeight();
        base.setColor(DuwmUnifiedTheme.BACKGROUND);
        base.setStyle(Paint.Style.FILL);
        bounds.set(0, 0, getWidth(), h);
        canvas.drawRoundRect(bounds, 6f * d, 6f * d, base);
        base.setColor(Color.argb(125, 44, 72, 116));
        canvas.drawRect(0, 0, getWidth(), Math.max(1f, 0.6f * d), base);
        float chipWidth = Math.min(getWidth() * .38f, Math.max(70f * d, 94f * d));
        base.setColor(DuwmUnifiedTheme.RAISED_CARD);
        canvas.drawRoundRect(0, 0, chipWidth, h, 6f * d, 6f * d, base);
        float activity = receivedCount > 0
                ? (0.6f + 0.4f * (float) Math.sin(SystemClock.uptimeMillis() / 290d)) : 0.25f;
        base.setColor(Color.argb((int) (90 + activity * 165), 87, 143, 223));
        canvas.drawCircle(7.5f * d, h / 2f, 2.2f * d, base);
        glyph.setTextSize(7.3f * textScale);
        glyph.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        glyph.setColor(Color.rgb(175, 198, 245));
        glyph.setTextAlign(Paint.Align.LEFT);
        canvas.drawText(channel1706 == null ? lane : "WIRE/" + channel1706.name(),
                15f * d, h / 2f + 2.6f * textScale, glyph);
        glyph.setTextSize(9.2f * textScale);
        glyph.setColor(Color.rgb(225, 235, 255));
        glyph.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL));
        if (contentWidth <= 0f) contentWidth = Math.max(1f, glyph.measureText(content));
        float left = chipWidth + 8f * d;
        float available = getWidth() - left - 3f * d;
        if (available > 1f) {
            canvas.save();
            canvas.clipRect(left, 1f, getWidth() - 3f * d, h);
            long elapsed = SystemClock.uptimeMillis() - frameStart;
            float step = (elapsed % 2_000_000L) * speed1706 * (reverse ? 0.72f : 1f) * d / 1_000f;
            float period = contentWidth + 42f * d;
            float phase = step % period;
            float start = reverse ? left - period + phase : left + available - phase;
            for (float x = start; x < getWidth(); x += period) {
                if (x + contentWidth >= left) {
                    canvas.drawText(content, x, h / 2f + 3.2f * textScale, glyph);
                }
            }
            canvas.restore();
        }
        // Continuous animation is deliberately independent of the status age.
        if (isAttachedToWindow() && isShown()) postInvalidateOnAnimation();
    }
}
