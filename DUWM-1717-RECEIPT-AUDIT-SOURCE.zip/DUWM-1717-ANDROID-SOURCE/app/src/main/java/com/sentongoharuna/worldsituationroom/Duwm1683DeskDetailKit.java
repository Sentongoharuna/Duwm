package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.Application;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Context-sensitive detail drawer on EVERY listed intelligence desk, without a replacement globe.
 * Only user tapping DETAIL opens the drawer; source data is never synthesized by this component.
 */
public final class Duwm1683DeskDetailKit {
    private Duwm1683DeskDetailKit() {}
    private static int dp(Activity a,float n){return Math.round(a.getResources().getDisplayMetrics().density*n);}
    private static GradientDrawable surface(Activity a){
        GradientDrawable d=new GradientDrawable();d.setColor(DuwmUnifiedTheme.PANEL);
        d.setCornerRadius(dp(a,12));d.setStroke(dp(a,1),DuwmUnifiedTheme.BORDER);return d;
    }
    private static TextView line(Activity a,String value,int size,int color,boolean bold){
        TextView t=new TextView(a);t.setText(value);t.setTextColor(color);t.setTextSize(size);
        t.setPadding(dp(a,4),dp(a,6),dp(a,4),dp(a,6));
        if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return t;
    }
    public static void install(Application app){
        app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks(){
            @Override public void onActivityCreated(Activity a,Bundle state){}
            @Override public void onActivityStarted(Activity a){}
            @Override public void onActivityResumed(Activity a){attach(a);}
            @Override public void onActivityPaused(Activity a){}
            @Override public void onActivityStopped(Activity a){}
            @Override public void onActivitySaveInstanceState(Activity a,Bundle b){}
            @Override public void onActivityDestroyed(Activity a){}
        });
    }
    private static void attach(Activity a){
        Duwm1683DeskCatalog.Desk desk=Duwm1683DeskCatalog.find(a);
        if(desk==null)return;
        // Fixed bottom dock, NEVER a button over the globe, a map or a media player.
        Duwm1711NativeDeskDock.attach(a,desk);
    }
    public static void show(Activity a,Duwm1683DeskCatalog.Desk desk){
        int index=-1;
        for(int i=0;i<Duwm1683DeskCatalog.ALL.length;i++)
            if(Duwm1683DeskCatalog.ALL[i]==desk){index=i;break;}
        if(index<0)return;
        Intent intent=new Intent(a,Duwm1683DeskFullScreenActivity.class);
        intent.putExtra(Duwm1683DeskFullScreenActivity.EXTRA_DESK_INDEX,index);
        a.startActivity(intent);
    }
}
