package com.sentongoharuna.worldsituationroom;
import java.util.Locale;
/** Independent Stage 1 pure Java region functions, no third-party material. */
public final class RunningballV25RegionQuery {
  private RunningballV25RegionQuery(){}
  public static final int RADIUS_NM=250;
  public static String url(double lat,double lon){
    if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90d||Math.abs(lon)>180d)
      throw new IllegalArgumentException("invalid global coordinates");
    return String.format(Locale.US,"https://api.adsb.lol/v2/point/%.5f/%.5f/%d",lat,lon,RADIUS_NM);
  }
  public static String coverage(String name){return (name==null||name.trim().isEmpty()?"UNNAMED REGION":name.trim())+" / 250 NM REGIONAL AIRCRAFT";}
  public static String key(double lat,double lon){return String.format(Locale.US,"%.4f,%.4f",lat,lon);}
}
