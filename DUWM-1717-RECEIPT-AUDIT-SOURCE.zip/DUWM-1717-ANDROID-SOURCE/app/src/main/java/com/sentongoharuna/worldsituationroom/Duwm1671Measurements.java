package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Local source-receipt ledger: never adds a chart point without a genuine successful provider receipt. */
public final class Duwm1671Measurements {
  public static final class Point {
    public final long received,source;
    public final double value;
    public Point(long t,long s,double v){received=t;source=s;value=v;}
  }
  private Duwm1671Measurements(){}
  private static final String PREF="duwm_1671_real_measurements";
  private static final Pattern FIRST_NUMBER=Pattern.compile("[-+]?(?:\\d+\\.?\\d*|\\.\\d+)");
  private static String key(int provider){return "points_"+provider;}
  public static Double parse(String value){
    if(value==null||value.equals("--")||value.contains("NO DATA"))return null;
    Matcher m=FIRST_NUMBER.matcher(value);if(!m.find())return null;
    try{double v=Double.parseDouble(m.group());return Double.isFinite(v)?v:null;}catch(Exception invalid){return null;}
  }
  public static synchronized void capture(Context ctx,int provider){
    if(provider!=6&&provider!=7&&provider!=8)return;
    RunningballV25Sources.Result r=RunningballV25Sources.read(ctx,provider);
    Double numeric=parse(r.value);
    if(numeric==null||r.fetchedAt<=0||r.status==RunningballV25Sources.Status.FAILED||r.status==RunningballV25Sources.Status.NOT_CONFIGURED||r.status==RunningballV25Sources.Status.NO_DATA_FOR_REGION)return;
    SharedPreferences preferences=ctx.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);
    JSONArray entries;try{entries=new JSONArray(preferences.getString(key(provider),"[]"));}catch(Exception invalid){entries=new JSONArray();}
    for(int i=0;i<entries.length();i++){
      JSONObject o=entries.optJSONObject(i);
      if(o!=null&&o.optLong("received")==r.fetchedAt)return;
    }
    JSONObject item=new JSONObject();try{item.put("received",r.fetchedAt);item.put("source",r.sourceTime);item.put("value",numeric);}catch(Exception ignored){return;}
    entries.put(item);
    JSONArray bounded=new JSONArray();for(int i=Math.max(0,entries.length()-120);i<entries.length();i++)bounded.put(entries.optJSONObject(i));
    preferences.edit().putString(key(provider),bounded.toString()).apply();
  }
  public static synchronized List<Point> history(Context c,int provider){
    ArrayList<Point> points=new ArrayList<>();
    try{String json=c.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(key(provider),"[]");JSONArray arr=new JSONArray(json);
      for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i);if(o==null)continue;long r=o.optLong("received",0),s=o.optLong("source",0);double v=o.optDouble("value",Double.NaN);
        if(r>0&&Double.isFinite(v))points.add(new Point(r,s,v));}
    }catch(Exception ignored){}return points;
  }
}
