package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.Uri;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Creates a local 4:5 newsroom PNG and opens Android's native share sheet. */
public final class ShareCardRenderer {
    private static final int WIDTH = 1080;
    private static final int HEIGHT = 1350;
    private static final int BG = Color.rgb(5, 13, 34);
    private static final int PANEL = Color.rgb(8, 22, 46);
    private static final int TEXT = Color.rgb(221, 234, 254);
    private static final int MUTED = Color.rgb(96,132,139);
    private static final int LINE = Color.rgb(35, 62, 104);
    private static final ExecutorService RENDERER = Executors.newSingleThreadExecutor();

    private ShareCardRenderer() { }

    public static void share(Activity activity, ShareCardData data) {
        if (activity == null || data == null || activity.isFinishing()) return;
        Toast.makeText(activity, "Creating share card…", Toast.LENGTH_SHORT).show();
        RENDERER.execute(() -> {
            try {
                File png = render(activity, data);
                Uri uri = new Uri.Builder()
                        .scheme("content")
                        .authority(activity.getPackageName() + ".sharecards")
                        .appendPath("card")
                        .appendPath(png.getName())
                        .build();
                String shareText = fullText(data);
                activity.runOnUiThread(() -> {
                    if (activity.isFinishing() || activity.isDestroyed()) return;
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("image/png");
                    send.putExtra(Intent.EXTRA_SUBJECT, data.title + " — " + ShareCardData.BRAND);
                    send.putExtra(Intent.EXTRA_TEXT, shareText);
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.setClipData(ClipData.newRawUri("DU World Monitor share card", uri));
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        activity.startActivity(Intent.createChooser(send, "Share information card"));
                    } catch (RuntimeException error) {
                        Toast.makeText(activity, "No compatible sharing app is available",
                                Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception error) {
                activity.runOnUiThread(() -> Toast.makeText(activity,
                        "Could not create share card", Toast.LENGTH_LONG).show());
            }
        });
    }


    /** Source photo only if the exact share record carries a verified reuse grant.
     * Never scrape an article or invent a photo from a story title. */
    private static Bitmap approvedSourcePhoto(ShareCardData card) {
        String url=card.facts.get("IMAGE");
        String credit=card.facts.get("IMAGE_CREDIT");
        String licence=card.facts.get("IMAGE_LICENSE");
        String record=card.facts.get("IMAGE_RECORD_URL");
        if(url==null||credit==null||licence==null||record==null || credit.trim().isEmpty())return null;
        if(card.sourceUrl.isEmpty() || !card.sourceUrl.equals(record))return null;
        if(!(licence.equals("CC0")||licence.equals("PUBLIC_DOMAIN")||
              licence.equals("CC_BY_4_0")||licence.equals("NASA_EDITORIAL")||licence.equals("USGS_PUBLIC_DOMAIN")))return null;
        HttpURLConnection connection=null;
        try{
            URL link=new URL(url);String host=link.getHost().toLowerCase(java.util.Locale.ROOT);
            boolean nasa=host.equals("images-assets.nasa.gov")||host.equals("images.nasa.gov")||host.equals("science.nasa.gov");
            boolean commons=host.equals("upload.wikimedia.org");
            // USGS authored ShakeMap product only. Reject other imagery, query strings and third-party hosts.
            boolean usgs=host.equals("earthquake.usgs.gov") &&
                link.getPath().matches("/product/shakemap/[A-Za-z0-9_-]+/[A-Za-z0-9_-]+/[0-9]{1,14}/download/intensity\\.jpg") &&
                link.getQuery()==null && link.getUserInfo()==null && link.getPort()==-1;
            // V107: NASA DSCOVR/EPIC natural-color archive, only its exact NASA image.
            boolean epic=host.equals("epic.gsfc.nasa.gov") &&
                link.getPath().matches("/archive/natural/[0-9]{4}/[0-9]{2}/[0-9]{2}/jpg/[A-Za-z0-9_-]+\\.jpg") &&
                link.getQuery()==null && link.getUserInfo()==null && link.getPort()==-1;
            if(!"https".equals(link.getProtocol())||url.length()>1800||!(nasa||commons||epic||usgs))return null;
            if(licence.equals("NASA_EDITORIAL")&&!(nasa||epic))return null;
            if(!licence.equals("NASA_EDITORIAL")&&!commons&&!nasa&&!(usgs&&licence.equals("USGS_PUBLIC_DOMAIN")))return null;
            if(epic&&!licence.equals("NASA_EDITORIAL"))return null;
            if(usgs&&!licence.equals("USGS_PUBLIC_DOMAIN"))return null;
            connection=(HttpURLConnection)link.openConnection();
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(5500);connection.setReadTimeout(6500);
            if(connection.getResponseCode()!=200)return null;
            String type=connection.getContentType();
            if(type==null||!(type.startsWith("image/jpeg")||type.startsWith("image/png")||type.startsWith("image/webp")))return null;
            if(connection.getContentLengthLong()>2000000L)return null;
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            try(java.io.InputStream in=connection.getInputStream()){
                byte[] chunk=new byte[8192];int n;
                while((n=in.read(chunk))!=-1){
                    if(bytes.size()+n>2000000)return null;
                    bytes.write(chunk,0,n);
                }
            }
            byte[] raw=bytes.toByteArray();
            BitmapFactory.Options opts=new BitmapFactory.Options();opts.inJustDecodeBounds=true;
            BitmapFactory.decodeByteArray(raw,0,raw.length,opts);
            if(opts.outWidth<100||opts.outHeight<100||opts.outWidth>10000||opts.outHeight>10000)return null;
            opts.inJustDecodeBounds=false;
            opts.inSampleSize=Math.max(1,Math.max(opts.outWidth,opts.outHeight)/1700);
            return BitmapFactory.decodeByteArray(raw,0,raw.length,opts);
        }catch(Exception ignored){return null;}
        finally{if(connection!=null)connection.disconnect();}
    }

    /** Native factual illustration when the provider supplies coordinates, not photography. */
    private static float drawObservedCoordinateGraphic(Canvas c,Paint p,ShareCardData d,
                                                        int left,int right,float top){
        float bottom=top+225f;
        p.setColor(Color.rgb(20, 47, 91));
        c.drawRoundRect(new RectF(left,top,right,bottom),16,16,p);
        p.setColor(Color.argb(95,57,181,195));p.setStrokeWidth(1.5f);
        for(int col=1;col<6;col++){
            float xx=left+(right-left)*col/6f;c.drawLine(xx,top+12,xx,bottom-31,p);
        }
        for(int row=1;row<4;row++){
            float yy=top+(bottom-top-36f)*row/4f;c.drawLine(left+10,yy,right-10,yy,p);
        }
        float xx=left+(right-left)*(float)((d.longitude+180d)/360d);
        float yy=top+(bottom-top-36f)*(float)((90d-d.latitude)/180d);
        p.setColor(d.accentColor);c.drawCircle(xx,yy,10,p);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2f);c.drawCircle(xx,yy,19,p);
        p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        p.setTextSize(18f);p.setColor(TEXT);
        c.drawText(String.format(Locale.US,"OBSERVED COORDINATE   %.3f, %.3f",d.latitude,d.longitude),
                   left+14,bottom-11,p);
        return bottom+22f;
    }

    private static float drawCreditedPhoto(Canvas c,Paint p,Bitmap photo,ShareCardData d,
                                           int left,int right,float top){
        float h=Math.min(295f,1010f-top);
        if(h<160f)return top;
        float w=right-left, ratio=Math.max(w/photo.getWidth(),h/photo.getHeight());
        int srcW=Math.min(photo.getWidth(),(int)(w/ratio));
        int srcH=Math.min(photo.getHeight(),(int)(h/ratio));
        Rect src=new Rect((photo.getWidth()-srcW)/2,(photo.getHeight()-srcH)/2,
                          (photo.getWidth()+srcW)/2,(photo.getHeight()+srcH)/2);
        p.setColor(android.graphics.Color.WHITE);p.setAlpha(255);
        c.drawBitmap(photo,src,new android.graphics.RectF(left,top,right,top+h),p);
        p.setColor(android.graphics.Color.argb(218,5,14,23));
        c.drawRect(left,top+h-43,right,top+h,p);
        p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(17f);
        p.setColor(TEXT);
        c.drawText(clip("SOURCE IMAGE · "+d.facts.get("IMAGE_CREDIT")+" · "+d.facts.get("IMAGE_LICENSE"),76),
                   left+12,top+h-15,p);
        return top+h+24f;
    }

    private static File render(Activity activity, ShareCardData data) throws IOException {
        Bitmap bitmap = Bitmap.createBitmap(WIDTH, HEIGHT, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(BG);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStrokeWidth(1f);
        paint.setColor(Color.argb(34,57,181,195));
        for (int x = 0; x <= WIDTH; x += 90) canvas.drawLine(x, 0, x, HEIGHT, paint);
        for (int y = 0; y <= HEIGHT; y += 90) canvas.drawLine(0, y, WIDTH, y, paint);

        // V6 consistent glass-panel family: rounded frame, slim colored border,
        // restrained corner status dot, spacious headline and genuine facts.
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(247,8,24,36));
        canvas.drawRoundRect(new RectF(44, 42, WIDTH - 44, HEIGHT - 42), 52, 52, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3.5f);
        paint.setColor(data.accentColor);
        canvas.drawRoundRect(new RectF(44, 42, WIDTH - 44, HEIGHT - 42), 52, 52, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(data.accentColor);
        canvas.drawCircle(WIDTH - 96f, 99f, 10f, paint);

        int left = 94;
        int right = WIDTH - 90;
        float y = 108f;
        drawBrandMark(canvas, paint, left + 30f, y - 12f, 29f);
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        paint.setTextSize(39f);
        paint.setColor(TEXT);
        canvas.drawText(ShareCardData.BRAND, left + 76f, y, paint);
        paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        paint.setTextSize(18f);
        paint.setColor(Color.rgb(85, 139, 223));
        canvas.drawText("GLOBAL SIGNALS • LOCAL WITNESSES • SOURCE AWARE",
                left + 76f, y + 34f, paint);

        y += 88f;
        paint.setColor(PANEL);
        canvas.drawRoundRect(new RectF(left, y, right, y + 68f), 18, 18, paint);
        paint.setColor(data.accentColor);
        paint.setTextSize(22f);
        canvas.drawText("● " + clip(data.status, 24) + "  •  SEVERITY " + data.severity
                + "  •  " + clip(data.credibility, 40), left + 22, y + 43f, paint);

        y += 108f;
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        paint.setTextSize(59f);
        paint.setColor(TEXT);
        y = drawWrapped(canvas, paint, data.title, left, y, right - left, 66f, 4);

        y += 18f;
        paint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        paint.setTextSize(32f);
        paint.setColor(Color.rgb(194, 211, 241));
        y = drawWrapped(canvas, paint, data.summary, left, y, right - left, 43f, 5);

        // One strictly attributed source image where the record grants share reuse.
        // No photo is invented for a source which supplies only measurements.
        Bitmap sourcePhoto=approvedSourcePhoto(data);
        boolean visual=false;
        if(sourcePhoto!=null){
            try{if(y<825f){
                y=drawCreditedPhoto(canvas,paint,sourcePhoto,data,left,right,y+10f);
                visual=true;
            }}finally{sourcePhoto.recycle();}
        }else{
            String origin=data.facts.get("COORDINATE ORIGIN");
            boolean providerCoord=origin!=null &&
               (origin.equalsIgnoreCase("PROVIDER")||origin.equalsIgnoreCase("OBSERVED")||
                origin.equalsIgnoreCase("SOURCE_REPORTED"));
            if(data.hasLocation() && providerCoord && y<830f){
                y=drawObservedCoordinateGraphic(canvas,paint,data,left,right,y+8f);
                visual=true;
            }
        }
        if(visual){
            paint.setTypeface(Typeface.create(Typeface.MONOSPACE,Typeface.BOLD));
            paint.setTextSize(19f);paint.setColor(MUTED);
            canvas.drawText("FULL SOURCE FACTS ACCOMPANY THE SHARED PNG",left,1050f,paint);
            y=1055f; // no source facts over photo or coordinate illustration
        }
        y += 28f;
        paint.setColor(LINE);
        canvas.drawRect(left, y, right, y + 2f, paint);
        y += 32f;

        paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        int shown = 0;
        boolean more = false;
        for (Map.Entry<String, String> fact : data.facts.entrySet()) {
            if (shown >= 8 || y > 1010f) {
                more = true;
                break;
            }
            paint.setTextSize(20f);
            paint.setColor(data.accentColor);
            canvas.drawText(clip(fact.getKey().toUpperCase(Locale.ROOT), 32), left, y, paint);
            y += 30f;
            paint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            paint.setTextSize(28f);
            paint.setColor(TEXT);
            y = drawWrapped(canvas, paint, fact.getValue(), left, y,
                    right - left, 36f, 2);
            y += 13f;
            paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            shown++;
        }
        if (more) {
            paint.setTextSize(20f);
            paint.setColor(MUTED);
            canvas.drawText("FULL DETAILS INCLUDED IN THE SHARED TEXT", left, 1050f, paint);
        }

        float footerTop = 1090f;
        paint.setColor(LINE);
        canvas.drawRect(left, footerTop, right, footerTop + 2f, paint);
        paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        paint.setTextSize(21f);
        paint.setColor(MUTED);
        canvas.drawText("SOURCE", left, footerTop + 38f, paint);
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        paint.setTextSize(25f);
        paint.setColor(TEXT);
        canvas.drawText(clip(data.source, 62), left + 112f, footerTop + 38f, paint);

        paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        paint.setTextSize(21f);
        paint.setColor(MUTED);
        canvas.drawText("UTC", left, footerTop + 76f, paint);
        canvas.drawText(utc(data.timestampMs), left + 112f, footerTop + 76f, paint);
        canvas.drawText("REGION", left, footerTop + 114f, paint);
        canvas.drawText(clip(data.region, 42), left + 112f, footerTop + 114f, paint);
        if (data.hasLocation()) {
            canvas.drawText(String.format(Locale.US, "COORD  %.4f, %.4f",
                    data.latitude, data.longitude), left, footerTop + 152f, paint);
        }

        paint.setColor(data.accentColor);
        paint.setTextSize(19f);
        paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        canvas.drawText(clip(data.disclaimer.toUpperCase(Locale.ROOT), 82),
                left, HEIGHT - 86f, paint);
        paint.setColor(MUTED);
        paint.setTextSize(17f);
        canvas.drawText("#DUWORLDMONITOR  •  " + ShareCardData.TAGLINE,
                left, HEIGHT - 55f, paint);

        File directory = new File(activity.getCacheDir(), "share-cards");
        if (!directory.exists() && !directory.mkdirs()) {
            bitmap.recycle();
            throw new IOException("Could not create share-card cache");
        }
        prune(directory);
        File file = new File(directory, "du-world-moniter-"
                + System.currentTimeMillis() + ".png");
        try (FileOutputStream output = new FileOutputStream(file)) {
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) {
                throw new IOException("PNG encoder failed");
            }
        } finally {
            bitmap.recycle();
        }
        return file;
    }

    private static void drawBrandMark(
            Canvas canvas,
            Paint paint,
            float centerX,
            float centerY,
            float radius) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(24, 53, 98));
        canvas.drawCircle(centerX, centerY, radius, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.2f);
        paint.setColor(Color.rgb(85, 139, 223));
        canvas.drawCircle(centerX, centerY, radius - 2f, paint);
        canvas.drawOval(new RectF(centerX - radius * 0.45f, centerY - radius + 2f,
                centerX + radius * 0.45f, centerY + radius - 2f), paint);
        canvas.drawLine(centerX - radius + 2f, centerY,
                centerX + radius - 2f, centerY, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(radius * 0.72f);
        paint.setColor(Color.rgb(85, 139, 223));
        canvas.drawText("DU", centerX, centerY + radius * 0.26f, paint);
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setColor(Color.rgb(85, 139, 223));
        canvas.drawCircle(centerX + radius * 0.72f,
                centerY - radius * 0.72f, radius * 0.16f, paint);
    }

    private static float drawWrapped(Canvas canvas, Paint paint, String value, float x,
                                     float y, float width, float lineHeight, int maxLines) {
        List<String> lines = wrap(paint, value, width, maxLines);
        for (String line : lines) {
            canvas.drawText(line, x, y, paint);
            y += lineHeight;
        }
        return y;
    }

    private static List<String> wrap(Paint paint, String value, float width, int maxLines) {
        String clean = value == null ? "" : value.trim().replaceAll("\\s+", " ");
        List<String> result = new ArrayList<>();
        String remaining = clean;
        while (!remaining.isEmpty() && result.size() < maxLines) {
            int count = paint.breakText(remaining, true, width, null);
            if (count <= 0) break;
            if (count < remaining.length()) {
                int space = remaining.lastIndexOf(' ', count);
                if (space > 0) count = space;
            }
            String line = remaining.substring(0, count).trim();
            remaining = remaining.substring(count).trim();
            if (result.size() == maxLines - 1 && !remaining.isEmpty()) {
                while (paint.measureText(line + "…") > width && line.length() > 1) {
                    line = line.substring(0, line.length() - 1);
                }
                line += "…";
                remaining = "";
            }
            result.add(line);
        }
        if (result.isEmpty()) result.add("—");
        return result;
    }

    private static String fullText(ShareCardData data) {
        StringBuilder text = new StringBuilder();
        text.append(ShareCardData.BRAND).append('\n')
                .append(data.status).append(" • SEVERITY ").append(data.severity)
                .append(" • ").append(data.credibility).append("\n\n")
                .append(data.title).append("\n\n")
                .append(data.summary).append("\n\n");
        for (Map.Entry<String, String> fact : data.facts.entrySet()) {
            text.append(fact.getKey()).append(": ").append(fact.getValue()).append('\n');
        }
        text.append("\nCATEGORY: ").append(data.category)
                .append("\nREGION: ").append(data.region)
                .append("\nSOURCE: ").append(data.source)
                .append("\nUTC: ").append(utc(data.timestampMs));
        if (data.hasLocation()) {
            text.append(String.format(Locale.US, "\nCOORDINATES: %.5f, %.5f",
                    data.latitude, data.longitude));
        }
        if (!data.sourceUrl.isEmpty()) text.append("\nORIGINAL SOURCE: ").append(data.sourceUrl);
        text.append("\n\n").append(data.disclaimer);
        return text.toString();
    }

    private static String utc(long timestampMs) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US);
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        return format.format(new Date(timestampMs));
    }

    private static String clip(String value, int maximum) {
        String clean = value == null ? "" : value.trim().replaceAll("\\s+", " ");
        return clean.length() <= maximum ? clean
                : clean.substring(0, Math.max(1, maximum - 1)) + "…";
    }

    private static void prune(File directory) {
        File[] files = directory.listFiles();
        if (files == null || files.length <= 20) return;
        java.util.Arrays.sort(files, (first, second) ->
                Long.compare(first.lastModified(), second.lastModified()));
        for (int index = 0; index < files.length - 20; index++) {
            // Cache cleanup is best effort. A receiver with an open descriptor is unaffected.
            files[index].delete();
        }
    }
}
