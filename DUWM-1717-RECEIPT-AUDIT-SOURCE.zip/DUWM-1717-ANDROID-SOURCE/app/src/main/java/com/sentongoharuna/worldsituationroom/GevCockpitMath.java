package com.sentongoharuna.worldsituationroom;

/** Heading/position math adapted from the MIT-licensed God's Eye View cockpitMath.js.
 * Copyright (c) 2026 Bilawal Sidhu. Original license in assets/gev-mit-license.txt.
 * All rendered positions are observed ADS-B positions, never projections of future flight. */
public final class GevCockpitMath {
    private GevCockpitMath() { }
    public static boolean finite(double v) { return !Double.isNaN(v) && !Double.isInfinite(v); }
    public static double heading(double v) { return finite(v) ? ((v % 360d) + 360d) % 360d : Double.NaN; }
    public static String headingText(double v) {
        return finite(v) ? String.format(java.util.Locale.US, "%03d", (int)Math.round(heading(v)) % 360) : "---";
    }
    public static double bearing(double latA, double lonA, double latB, double lonB) {
        if (!GevGeo.valid(latA,lonA) || !GevGeo.valid(latB,lonB)) return Double.NaN;
        double a=Math.toRadians(latA), b=Math.toRadians(latB), dLon=Math.toRadians(lonB-lonA);
        double y=Math.sin(dLon)*Math.cos(b);
        double x=Math.cos(a)*Math.sin(b)-Math.sin(a)*Math.cos(b)*Math.cos(dLon);
        return heading(Math.toDegrees(Math.atan2(y,x)));
    }
    public static double relativeBearing(double target, double reference) {
        if(!finite(target)||!finite(reference)) return Double.NaN;
        return heading(target - reference);
    }
}
