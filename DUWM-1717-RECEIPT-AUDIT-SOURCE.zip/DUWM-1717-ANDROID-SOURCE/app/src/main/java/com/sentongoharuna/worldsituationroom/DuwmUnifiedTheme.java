package com.sentongoharuna.worldsituationroom;

/** 1715 FIX3: exactly sampled #041424 reference navy, #DEE5EF silver controls: one original command center and one visual language across
 * every native page. Cosmetic values never modify source records or freshness.
 */
public final class DuwmUnifiedTheme {
    private DuwmUnifiedTheme() {}
    public static final int BACKGROUND = 0xFF041424;
    public static final int PANEL = 0xFF041424;
    public static final int PANEL_SELECTED = 0xFF0D2638;
    public static final int BORDER = 0xFFDEE5EF;
    public static final int DIVIDER = 0xFF7D8E9F;
    public static final int SECTOR_LINE = 0xFFBDC7D2;
    public static final int FORMAL_CORNER_DP = 20;
    public static final int ACCENT = 0xFFDEE5EF;
    public static final int ACCENT_BRIGHT = 0xFFF5F7FA;
    // Whole-screen backgrounds must be the approved navy, not cobalt panels.
    public static final int APPROVED_NAVY = 0xFF041424;
    public static final int RAISED_CARD = PANEL;
    public static final int OVERLAY = 0xF2041424;
    public static final int TEXT = 0xFFF5F7FA;
    public static final int MUTED = 0xFFA0A5AE;
    public static final int UNAVAILABLE = 0xFF687786;
    public static final int LOCAL_SIGNAL = 0xFF558BDF; // Status-only blue, not a surface colour
    // Limited status accents: always label the status; never portray synthetic data.
    public static final int LIVE = 0xFF67CBA6;
    public static final int WARNING = 0xFFDBAC64;
    public static final int DANGER = 0xFFDF777B;
}
