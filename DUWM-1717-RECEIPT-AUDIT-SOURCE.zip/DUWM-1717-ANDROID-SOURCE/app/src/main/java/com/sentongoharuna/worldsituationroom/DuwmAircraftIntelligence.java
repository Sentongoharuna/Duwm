package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Optional aircraft-only overlay for the protected RUNNINGBALL2 WallpaperService.
 * Never performs networking or parsing in the original 33ms SurfaceHolder draw loop.
 * Aircraft reports are queried in 250 NM sectors worldwide; no claim of all global traffic.
 */
final class DuwmAircraftIntelligence {
    // Region coordinates are dynamically selected from worldwide Earth view.
    private final Context app;
    private static final double RADIUS_NM = 250d;
    // Network location comes from RunningballWorldTarget.url(app).
    private static final long POLL_MS = 60_000L;
    private static final long STALE_MS = 180_000L;
    private static final long MAX_CACHED_MS = 300_000L;
    private static final long TRAIL_RETENTION_MS = 900_000L;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Map<String, ArrayDeque<Fix>> history = new HashMap<>();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float dp;
    private final float sp;
    private volatile Snapshot snapshot = Snapshot.startup();
    private boolean visible;
    private volatile String currentRegion="";
    private boolean closed;

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (!visible || closed) return;
            io.execute(new Runnable() {
                @Override public void run() { refresh(); }
            });
            ui.postDelayed(this, POLL_MS);
        }
    };

    DuwmAircraftIntelligence(Context context) {
        app=context.getApplicationContext();
        dp = context.getResources().getDisplayMetrics().density;
        sp = context.getResources().getDisplayMetrics().scaledDensity;
        text.setTypeface(android.graphics.Typeface.MONOSPACE);
    }

    void setVisible(boolean value) {
        ui.removeCallbacks(poll);
        visible = value && !closed;
        if (visible) ui.post(poll);
    }

    void close() {
        closed = true;
        visible = false;
        ui.removeCallbacks(poll);
        io.shutdownNow();
    }

    private void refresh() {
        if(!RunningballWorldTarget.ready(app)){snapshot=Snapshot.startup();history.clear();return;}
        String target=RunningballWorldTarget.url(app);
        if(!target.equals(currentRegion)){currentRegion=target;history.clear();snapshot=Snapshot.startup();}
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(RunningballWorldTarget.url(app)).openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("User-Agent", "DUWM-RUNNINGBALL2-Aircraft/1.0");
            conn.setConnectTimeout(8_000);
            conn.setReadTimeout(8_000);
            final int response = conn.getResponseCode();
            if (response != 200) {
                throw new IllegalStateException(response == 429 ? "RATE LIMITED" : "HTTP " + response);
            }
            final ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (InputStream in = conn.getInputStream()) {
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) {
                    if (bytes.size() + n > 2_000_000) throw new IllegalStateException("OVERSIZED FEED");
                    bytes.write(buffer, 0, n);
                }
            }
            JSONObject root = new JSONObject(new String(bytes.toByteArray(), StandardCharsets.UTF_8));
            JSONArray data = root.optJSONArray("ac");
            if (data == null) throw new IllegalStateException("NO AIRCRAFT ARRAY");
            final long now = System.currentTimeMillis();
            List<Aircraft> aircraft = new ArrayList<>();
            for (int i = 0; i < data.length() && i < 1_000; i++) {
                JSONObject row = data.optJSONObject(i);
                if (row == null) continue;
                String id = row.optString("hex", "").trim();
                if (!id.matches("(?i)[0-9a-f]{6}")) continue;
                double lat = row.optDouble("lat", Double.NaN);
                double lon = row.optDouble("lon", Double.NaN);
                double seen = row.optDouble("seen_pos", Double.NaN);
                if (!valid(lat) || !valid(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180
                        || !valid(seen) || seen < 0 || seen > 120) continue;
                double distance = distanceNm(RunningballWorldTarget.lat(app), RunningballWorldTarget.lon(app), lat, lon);
                if (distance > RADIUS_NM) continue;
                String callsign = row.optString("flight", "").trim();
                if (callsign.isEmpty()) callsign = id.toUpperCase(Locale.US);
                double altitude = row.optDouble("alt_baro", Double.NaN);
                double speed = row.optDouble("gs", Double.NaN); // ADS-B ground speed in knots
                double heading = row.optDouble("track", Double.NaN);
                Fix current = new Fix(lat, lon, now - (long) (seen * 1000d),RunningballWorldTarget.lat(app),RunningballWorldTarget.lon(app));
                ArrayDeque<Fix> track = history.get(id);
                if (track == null) { track = new ArrayDeque<>(); history.put(id, track); }
                Fix previous = track.peekLast();
                if (previous == null || (previous.timeMs < current.timeMs
                        && distanceNm(previous.lat, previous.lon, current.lat, current.lon) >= 0.05d)) {
                    track.addLast(current);
                }
                while (track.size() > 6) track.removeFirst();
                while (!track.isEmpty() && now - track.peekFirst().timeMs > TRAIL_RETENTION_MS) {
                    track.removeFirst();
                }
                aircraft.add(new Aircraft(id, callsign, lat, lon, altitude, speed, heading,
                        seen, distance, current, Collections.unmodifiableList(new ArrayList<>(track))));
            }
            Iterator<Map.Entry<String, ArrayDeque<Fix>>> iter = history.entrySet().iterator();
            while (iter.hasNext()) {
                ArrayDeque<Fix> tracks = iter.next().getValue();
                if (tracks.isEmpty() || now - tracks.peekLast().timeMs > TRAIL_RETENTION_MS) iter.remove();
            }
            Collections.sort(aircraft, new Comparator<Aircraft>() {
                @Override public int compare(Aircraft a, Aircraft b) {
                    return Double.compare(a.distanceNm, b.distanceNm);
                }
            });
            if (aircraft.size() > 50) aircraft = new ArrayList<>(aircraft.subList(0, 50));
            snapshot = new Snapshot(Collections.unmodifiableList(aircraft), now, "LIVE");
        } catch (Exception e) {
            Snapshot old = snapshot;
            String reason = e.getMessage() == null ? "UNAVAILABLE" : e.getMessage();
            // Last known observations are retained but will never be labeled LIVE.
            snapshot = new Snapshot(old.aircraft, old.retrievedAtMs,
                    "RATE LIMITED".equals(reason) ? "RATE LIMITED" : "UNAVAILABLE");
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static boolean valid(double v) { return !Double.isNaN(v) && !Double.isInfinite(v); }
    private static double distanceNm(double la1, double lo1, double la2, double lo2) {
        double dLat = Math.toRadians(la2 - la1);
        double dLon = Math.toRadians(lo2 - lo1);
        double a = Math.pow(Math.sin(dLat / 2d), 2)
                + Math.cos(Math.toRadians(la1)) * Math.cos(Math.toRadians(la2))
                * Math.pow(Math.sin(dLon / 2d), 2);
        return 3440.065d * 2d * Math.atan2(Math.sqrt(a), Math.sqrt(Math.max(0d, 1d - a)));
    }

    /** The radar is north-up, separate from the decorative rotating wallpaper globe. */
    void draw(Canvas c) {
        if (c.getWidth() <= 0 || c.getHeight() <= 0) return;
        Snapshot snap = snapshot;
        // Never render another region’s cached aircraft beneath the current label.
        if(!RunningballWorldTarget.ready(app) || !RunningballWorldTarget.url(app).equals(currentRegion))snap=Snapshot.startup();
        long age = snap.retrievedAtMs == 0 ? Long.MAX_VALUE :
                Math.max(0, System.currentTimeMillis() - snap.retrievedAtMs);
        boolean live = "LIVE".equals(snap.status) && age <= STALE_MS;
        boolean cached = !live && age <= MAX_CACHED_MS;
        List<Aircraft> show = (live || cached) ? snap.aircraft : Collections.<Aircraft>emptyList();
        String state = live ? "LIVE" : cached ? "CACHED" : snap.status;

        float w = c.getWidth();
        float left = 12f * dp;
        float right = Math.min(w - left, left + 355f * dp);
        float top = 12f * dp;
        float bottom = top + 182f * dp;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(214,5,14,23));
        c.drawRoundRect(left, top, right, bottom, 12f * dp, 12f * dp, paint);
        paint.setColor(Color.argb(240,71,210,219));
        c.drawRoundRect(left, top, left + 3f * dp, bottom, 2f * dp, 2f * dp, paint);
        float x = left + 13f * dp;
        label(c, "AIRCRAFT INTELLIGENCE", x, top + 19f * dp, 12f, Color.rgb(85, 139, 223));
        label(c, (RunningballWorldTarget.label(app)+"  /  250 NM"), x, top + 36f * dp, 9f, Color.rgb(76, 120, 196));
        label(c, state + "  /  " + (live ? show.size() + " DISPLAYED" : "NOT LIVE"),
                x, top + 54f * dp, 9f,
                live ? Color.rgb(85, 139, 223) : Color.rgb(85, 139, 223));

        float rx = right - 67f * dp;
        float ry = top + 100f * dp;
        float radius = 48f * dp;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp);
        paint.setColor(Color.argb(145,57,181,195));
        c.drawCircle(rx, ry, radius, paint);
        c.drawCircle(rx, ry, radius / 2f, paint);
        c.drawLine(rx - radius, ry, rx + radius, ry, paint);
        c.drawLine(rx, ry - radius, rx, ry + radius, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(85, 139, 223));
        c.drawCircle(rx, ry, 2.5f * dp, paint); // selected observer centre

        int visibleDots = 0;
        for (Aircraft a : show) {
            if (visibleDots++ >= 65) break;
            for (int j = 1; j < a.trail.size(); j++) {
                Fix p = a.trail.get(j - 1);
                Fix q = a.trail.get(j);
                float fromX = rx + p.nx * radius, fromY = ry - p.ny * radius;
                float toX = rx + q.nx * radius, toY = ry - q.ny * radius;
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(1.2f * dp);
                paint.setColor(Color.argb(145,71,210,219));
                c.drawLine(fromX, fromY, toX, toY, paint);
            }
            float pointX = rx + a.position.nx * radius;
            float pointY = ry - a.position.ny * radius;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(live ? Color.rgb(85, 139, 223) : Color.rgb(76, 120, 196));
            c.drawCircle(pointX, pointY, 2.2f * dp, paint);
            if (valid(a.headingDeg)) {
                double hdg = Math.toRadians(a.headingDeg);
                c.drawLine(pointX, pointY, pointX + (float) Math.sin(hdg) * 5f * dp,
                        pointY - (float) Math.cos(hdg) * 5f * dp, paint);
            }
        }
        int maxRows = Math.min(3, show.size());
        for (int i = 0; i < maxRows; i++) {
            Aircraft a = show.get(i);
            String line1 = truncate(a.callsign, 10) + String.format(Locale.US,
                    "  %.0fS AGO", a.seenSeconds + Math.max(0, age) / 1000d);
            label(c, line1, x, top + (83 + i * 29) * dp, 8.2f, Color.rgb(218, 231, 254));
            label(c, String.format(Locale.US, "%s  %s  HDG %s",
                            altitudeText(a.altitudeFt), speedText(a.speedKt), headingText(a.headingDeg)),
                    x, top + (96 + i * 29) * dp, 7f, Color.rgb(76, 120, 196));
        }
        if (maxRows == 0) {
            label(c, live ? "NO REPORTS IN RANGE" : "WAITING FOR FEED", x,
                    top + 96f * dp, 8f, Color.rgb(183,196,199));
        }
        label(c, "SOURCE: ADSB.LOL  /  POSITIONS SUBJECT TO COVERAGE",
                x, bottom - 8f * dp, 6.6f, Color.rgb(91,125,132));
    }

    private void label(Canvas canvas, String value, float x, float y, float size, int color) {
        text.setTextSize(size * sp);
        text.setColor(color);
        canvas.drawText(value, x, y, text);
    }
    private static String truncate(String x, int n) { return x.length() <= n ? x : x.substring(0, n); }
    private static String altitudeText(double ft) {
        return valid(ft) ? String.format(Locale.US, "%.0fFT", ft) : "ALT --";
    }
    private static String speedText(double kt) {
        return valid(kt) ? String.format(Locale.US, "%.0fKT", kt) : "GS --";
    }
    private static String headingText(double deg) {
        return valid(deg) ? String.format(Locale.US, "%03.0f", (deg + 360d) % 360d) : "---";
    }

    private static final class Fix {
        final double lat, lon;
        final float nx, ny; // Precomputed normalized radar position, zero allocations in draw loop
        final long timeMs;
        Fix(double lat, double lon, long timeMs,double centerLat,double centerLon) {
            this.lat = lat; this.lon = lon; this.timeMs = timeMs;
            double east = (lon - centerLon) * 60d * Math.cos(Math.toRadians(centerLat)) / RADIUS_NM;
            double north = (lat - centerLat) * 60d / RADIUS_NM;
            double mag = Math.sqrt(east * east + north * north);
            if (mag > 1d) { east /= mag; north /= mag; }
            this.nx = (float) east;
            this.ny = (float) north;
        }
    }
    private static final class Aircraft {
        final String id, callsign;
        final double lat, lon, altitudeFt, speedKt, headingDeg, seenSeconds, distanceNm;
        final Fix position;
        final List<Fix> trail;
        Aircraft(String id, String callsign, double lat, double lon, double altitudeFt,
                 double speedKt, double headingDeg, double seenSeconds, double distanceNm,
                 Fix position, List<Fix> trail) {
            this.id = id; this.callsign = callsign; this.lat = lat; this.lon = lon;
            this.altitudeFt = altitudeFt; this.speedKt = speedKt;
            this.headingDeg = headingDeg; this.seenSeconds = seenSeconds;
            this.distanceNm = distanceNm; this.position = position; this.trail = trail;
        }
    }
    private static final class Snapshot {
        final List<Aircraft> aircraft;
        final long retrievedAtMs;
        final String status;
        Snapshot(List<Aircraft> aircraft, long retrievedAtMs, String status) {
            this.aircraft = aircraft; this.retrievedAtMs = retrievedAtMs; this.status = status;
        }
        static Snapshot startup() {
            return new Snapshot(Collections.<Aircraft>emptyList(), 0L, "WAITING");
        }
    }
}
