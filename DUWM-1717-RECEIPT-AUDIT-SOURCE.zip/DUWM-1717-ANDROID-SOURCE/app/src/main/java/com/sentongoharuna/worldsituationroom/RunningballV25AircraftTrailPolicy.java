package com.sentongoharuna.worldsituationroom;
/** Independent two-OBSERVED-fix displacement rule; a connector is NOT a real flight route. */
public final class RunningballV25AircraftTrailPolicy {
  private RunningballV25AircraftTrailPolicy(){}
  public static boolean qualifies(String oldHex,String newHex,
      double oldLat,double oldLon,double newLat,double newLon,
      long oldSeenSeconds,long newSeenSeconds,long oldSourceMs,long newSourceMs){
    if(oldHex==null||newHex==null||oldHex.length()<3||!oldHex.equalsIgnoreCase(newHex))return false;
    if(!Double.isFinite(oldLat)||!Double.isFinite(oldLon)||!Double.isFinite(newLat)||!Double.isFinite(newLon))return false;
    if(Math.abs(oldLat)>90||Math.abs(newLat)>90||Math.abs(oldLon)>180||Math.abs(newLon)>180)return false;
    if(Math.abs(newLon-oldLon)>180)return false; // do not draw across the date line
    if(Math.abs(newLat-oldLat)+Math.abs(newLon-oldLon)<0.00001d)return false;
    if(oldSourceMs<=0||newSourceMs<=oldSourceMs||newSourceMs-oldSourceMs>5400000L)return false;
    if(oldSeenSeconds<=0||newSeenSeconds<=oldSeenSeconds||newSeenSeconds-oldSeenSeconds>5400L)return false;
    if(oldSeenSeconds*1000L>oldSourceMs+60000L || newSeenSeconds*1000L>newSourceMs+60000L)return false;
    return true;
  }
}
