package com.sentongoharuna.worldsituationroom;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

/** V9 independent implementation using V8 received RSS/GDELT caches; never a verified incident feed. */
public final class RunningballV25NewsroomActivity extends Activity {
  private static final int BG=0xFF041424,CYAN=0xFF558BDF,GREEN=0xFF558BDF,
      AMBER=0xFF558BDF,INK=0xFFE0EAFE,MUTED=0xFFBECBE0,RED=0xFF558BDF;
  private static final String[] NAMES={"THE INDEPENDENT","THE OBSERVER","SOFTPOWER NEWS","WATCHDOG UGANDA","MIDDLE EAST / GDELT","WORLD CONFLICT / GDELT"};
  private static final String[] LABELS={"ALL NEWS","UGANDA","MIDDLE EAST","WORLD CONFLICT","SOURCE HEALTH"};
  private final Handler ui=new Handler(Looper.getMainLooper());
  private final Runnable tick=new Runnable(){public void run(){if(!visible)return;render();RunningballV25NewsRepository.refresh(RunningballV25NewsroomActivity.this,false,RunningballV25NewsroomActivity.this::render);ui.postDelayed(this,60000L);}};
  private boolean visible=false;private int filter=0;private String query="";
  private TextView summary, updated;private LinearLayout headlines;private ScrollView scroller;
  private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
  private GradientDrawable panel(int line){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFF0D1E3B,BG});d.setStroke(dp(1),line);d.setCornerRadius(dp(12));return d;}
  private TextView label(String s,int size,int colour,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(colour);if(bold)v.setTypeface(null,1);return v;}
  private TextView button(String s,Runnable action){TextView t=label(s,11,CYAN,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(8),dp(12),dp(8),dp(12));t.setMinimumHeight(dp(48));t.setBackground(panel(0xFF284C87));t.setContentDescription(s);t.setOnClickListener(v->action.run());return t;}
  private static long timestamp(String text){if(text==null||text.trim().isEmpty())return 0L;
    String[] formats={"yyyyMMdd'T'HHmmss'Z'","yyyyMMddHHmmss","EEE, dd MMM yyyy HH:mm:ss Z","EEE, dd MMM yyyy HH:mm:ss z","yyyy-MM-dd'T'HH:mm:ssX","yyyy-MM-dd'T'HH:mm:ss'Z'"};
    for(String pattern:formats){try{SimpleDateFormat f=new SimpleDateFormat(pattern,Locale.US);f.setLenient(false);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.parse(text.trim()).getTime();}catch(Exception ignored){}}
    return 0L;
  }
  private static final class Story {String title,url,publisher,published,desk,type;long stamp;
    Story(JSONObject x,String key){title=x.optString("title","").trim();url=x.optString("url","").trim();publisher=x.optString("publisher","Unknown publisher");published=x.optString("published","");type=x.optString("type","PUBLISHER HEADLINE");desk=key;stamp=timestamp(published);}
  }
  private boolean isVisibleDesk(int source){return filter==0||filter==1&&source<4||filter==2&&source==4||filter==3&&source==5;}
  private int newsCount(){int total=0;for(String key:RunningballV25NewsRepository.KEYS)total+=RunningballV25NewsRepository.articles(this,key).length();return total;}
  private void article(Story s){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(11),dp(12),dp(12));card.setBackground(panel(0xFF284C87));
    TextView meta=label(s.publisher+"  ·  "+(s.desk.startsWith("ug_")?"UGANDA":s.desk.equals("conflict_middle_east")?"MIDDLE EAST":"WORLD CONFLICT"),10,CYAN,true);card.addView(meta);
    TextView heading=label(s.title,14,INK,true);heading.setMaxLines(4);card.addView(heading);
    String when=s.published.isEmpty()?"PUBLISHED TIME NOT PROVIDED":"PUBLISHER DATE: "+s.published;
    String age=RunningballV25NewsRepository.age(RunningballV25NewsRepository.last(this,s.desk));
    card.addView(label(when+"  ·  LAST FETCH "+age+" AGO\n"+s.type+"  ·  TAP ORIGINAL REPORT",10,MUTED,false));
    card.setMinimumHeight(dp(70));card.setContentDescription("Open publisher article "+s.title);
    card.setOnClickListener(v->{try{if(RunningballV25NewsRepository.validArticle(s.url))startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(s.url)));}
      catch(Exception e){summary.setText("BROWSER UNAVAILABLE: "+e.getClass().getSimpleName());}});
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(8);headlines.addView(card,lp);
  }
  private void notice(String title,String value,int tone){TextView t=label(title+"\n"+value,11,tone,false);t.setPadding(dp(10),dp(13),dp(9),dp(13));t.setBackground(panel(tone));
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(7);headlines.addView(t,lp);}
  private void renderHealth(){notice("SIX SOURCE FEEDS / REAL RECEIPT TIMES","Errors and cached stories are separate; a successfully fetched article is still only a publisher report.",CYAN);
    for(int i=0;i<RunningballV25NewsRepository.KEYS.length;i++){
      String key=RunningballV25NewsRepository.KEYS[i];long at=RunningballV25NewsRepository.last(this,key),attempt=RunningballV25NewsRepository.requested(this,key);
      String err=RunningballV25NewsRepository.error(this,key);boolean cached=at>0;boolean stale=cached&&System.currentTimeMillis()-at>30*60*1000L;
      String status=(!err.isEmpty()?(cached?"FETCH FAILED · OFFLINE CACHE":"FETCH FAILED"):(cached?(stale?"STALE CACHE":"RECENTLY FETCHED"):"NOT RECEIVED"));
      int colour=!err.isEmpty()?RED:stale?AMBER:cached?GREEN:AMBER;
      notice(NAMES[i]+" / "+status,
        "LAST GOOD: "+RunningballV25NewsRepository.age(at)+"  ·  LAST REQUEST: "+RunningballV25NewsRepository.age(attempt)+
        "\nARTICLES CACHED: "+RunningballV25NewsRepository.articles(this,key).length()+
        (err.isEmpty()?"":"\nLAST ERROR: "+err)+"\nSOURCE: "+(i<4?RunningballV25NewsRepository.RSS_URLS[i]:"GDELT DOC 2.0"),colour);
    }
    notice("DATA INTEGRITY","No invented news counts, casualty figures, troop locations or validated combat incidents. RSS syndication and redistribution rights must be respected.",AMBER);
  }
  private void render(){if(headlines==null)return;
    int position=scroller==null?0:scroller.getScrollY();headlines.removeAllViews();int healthy=0,broken=0;
    for(String key:RunningballV25NewsRepository.KEYS){if(RunningballV25NewsRepository.last(this,key)>0)healthy++;if(!RunningballV25NewsRepository.error(this,key).isEmpty())broken++;}
    summary.setText("NEWSROOM · "+healthy+"/6 FEEDS HAVE A RECEIVED SNAPSHOT · "+broken+" LATEST FETCH ERRORS");
    updated.setText("SOURCE CACHES REFRESH WHILE VIEWING · 20 MIN TTL · 3 MIN MANUAL COOLDOWN");
    if(filter==4){renderHealth();return;}
    ArrayList<Story> items=new ArrayList<>();Set<String> distinct=new HashSet<>();
    for(int source=0;source<RunningballV25NewsRepository.KEYS.length;source++){
      if(!isVisibleDesk(source))continue;String key=RunningballV25NewsRepository.KEYS[source];JSONArray a=RunningballV25NewsRepository.articles(this,key);
      for(int i=0;i<a.length();i++){JSONObject obj=a.optJSONObject(i);if(obj==null)continue;Story s=new Story(obj,key);
        if(s.title.length()<8||!RunningballV25NewsRepository.validArticle(s.url))continue;
        if(!query.isEmpty()&&!(s.title+" "+s.publisher).toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT)))continue;
        if(!distinct.add(s.url))continue;items.add(s);
      }
    }
    Collections.sort(items,(a,b)->Long.compare(b.stamp,a.stamp));
    String heading=filter==0?"LATEST GLOBAL NEWSROOM":filter==1?"UGANDA / PUBLISHER HEADLINES":filter==2?"MIDDLE EAST / REPORTED HEADLINES":"WORLD CONFLICT / REPORTED HEADLINES";
    notice(heading,items.size()+" CACHED ARTICLE LINKS · DATE SORTED WHERE PUBLISHER TIME EXISTS · UNKNOWN DATES LAST",CYAN);
    int limit=Math.min(45,items.size());for(int i=0;i<limit;i++)article(items.get(i));
    if(limit==0)notice("NO MATCHING RECEIVED REPORTS","Try another filter, open SOURCE HEALTH or refresh. Empty results do not establish that no event occurred.",AMBER);
    if(items.size()>limit)notice("BOUNDED DISPLAY",(items.size()-limit)+" additional cached headlines omitted from this display. Narrow your search.",MUTED);
    if(scroller!=null&&position>0)scroller.post(()->scroller.scrollTo(0,position));
  }
  @Override public void onCreate(Bundle saved){super.onCreate(saved);
    getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    scroller=new ScrollView(this);scroller.setFillViewport(true);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
    root.setPadding(dp(12),dp(12),dp(12),dp(32));root.setBackgroundColor(BG);scroller.addView(root);
    root.addView(label("RUNNINGBALL2 / V9 GLOBAL NEWSROOM",12,GREEN,true));root.addView(label("LIVE NEWS INTELLIGENCE",23,INK,true));
    root.addView(label("RECEIVED PUBLISHER HEADLINES · NOT CONFIRMED MILITARY INCIDENTS",11,AMBER,true));
    root.addView(button("BACK TO GLOBAL SIGNALS",this::finish));
    summary=label("WAITING FOR RECEIVED NEWS",12,GREEN,true);summary.setPadding(0,dp(9),0,dp(8));root.addView(summary);
    LinearLayout filterList=new LinearLayout(this);filterList.setOrientation(LinearLayout.VERTICAL);
    for(int i=0;i<LABELS.length;i+=2){LinearLayout line=new LinearLayout(this);for(int j=i;j<Math.min(LABELS.length,i+2);j++){
      int index=j;LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(3),dp(3),dp(3),dp(3));
      line.addView(button(LABELS[j],()->{filter=index;render();}),lp);
    }filterList.addView(line);}root.addView(filterList);
    root.addView(label("SEARCH RECEIVED HEADLINES OR PUBLISHERS",11,CYAN,true));
    EditText search=new EditText(this);search.setTextColor(INK);search.setHintTextColor(MUTED);search.setHint("Type topic, location or news outlet");
    search.setSingleLine(true);search.setTextSize(14);search.setMinimumHeight(dp(48));search.setBackground(panel(0xFF284C87));
    search.setPadding(dp(12),dp(8),dp(10),dp(8));root.addView(search);
    search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}
      public void onTextChanged(CharSequence s,int start,int before,int count){query=s.toString().trim();render();}
      public void afterTextChanged(Editable e){} });
    LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.HORIZONTAL);
    LinearLayout.LayoutParams left=new LinearLayout.LayoutParams(0,-2,1);left.rightMargin=dp(4);
    LinearLayout.LayoutParams right=new LinearLayout.LayoutParams(0,-2,1);right.leftMargin=dp(4);
    controls.addView(button("REFRESH NEWS",()->{updated.setText("REQUESTING FEEDS · RESULTS NOT YET CONFIRMED");RunningballV25NewsRepository.refresh(this,true,this::render);}),left);
    controls.addView(button("UGANDA + CONFLICT DESKS",()->startActivity(new Intent(this,RunningballV25NewsMonitorActivity.class))),right);root.addView(controls);
    updated=label("LOADING SOURCE HEALTH",10,MUTED,false);updated.setPadding(0,dp(9),0,dp(8));root.addView(updated);
    headlines=new LinearLayout(this);headlines.setOrientation(LinearLayout.VERTICAL);root.addView(headlines);
    String desk=getIntent().getStringExtra("desk");if("UGANDA".equals(desk))filter=1;else if("MIDDLE EAST".equals(desk))filter=2;else if("SOURCE HEALTH".equals(desk))filter=4;
    setContentView(scroller);render();RunningballV25NewsRepository.refresh(this,false,this::render);
  }
  @Override protected void onResume(){super.onResume();visible=true;ui.removeCallbacks(tick);ui.post(tick);}
  @Override protected void onPause(){visible=false;ui.removeCallbacks(tick);super.onPause();}
}
