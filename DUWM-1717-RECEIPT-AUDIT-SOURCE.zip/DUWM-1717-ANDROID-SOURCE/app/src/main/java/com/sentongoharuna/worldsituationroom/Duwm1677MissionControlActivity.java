package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** DUWM 1677 redesigned, directly functional mission-control launcher.
 * The aesthetic radar halo is decoration. All counters, marks and source statuses
 * are drawn from actual received device records. No invented flights, ships,
 * countries affected by news, forecasts or risk-index scores are displayed.
 */
public final class Duwm1677MissionControlActivity extends Activity {
  private static final int BG=0xFF041424, PANEL=0xFF0D3845, PANEL2=0xFF114A5B;
  private static final int BORDER=0xFF284C87, WHITE=0xFFDCE9FD, CYAN=0xFF558BDF;
  private static final int AQUA=0xFF558BDF, MUTED=0xFF4C78C4, AMBER=0xFF558BDF, RED=0xFF558BDF;
  private static final String[] LABELS={"AIR","SEA","NEWS","WX","FX","QUAKE","SAT","MEDIA"};
  private final Handler ui=new Handler(Looper.getMainLooper());
  private final TextView[] metric=new TextView[8], metricState=new TextView[8], signal=new TextView[8];
  private boolean active=false,rotating=true,aurora=true,airEnabled=true,seaEnabled=true,quakeEnabled=true,spaceEnabled=true;
  private long lastAirRequest=0L,lastSeaRequest=0L;
  private TextView utcLine,feedLine, mapDetails,heroLabel,healthLine,summaryAir,summarySea,summaryNews,summaryEvents,summaryWeather,summaryFx,summaryInfra,summaryGeo,summaryRadiation,summaryTrend;
  private TextView rotationButton, paletteButton;
  private OperationsGlobeView globe;
  private Duwm1670WorldMapView regional;
  private OperationsGlobeView.Observation selected;
  private final ArrayList<OperationsGlobeView.Observation> observations=new ArrayList<>();
  private final Runnable clock=new Runnable(){@Override public void run(){
    if(!active)return;
    updateSources();
    long now=System.currentTimeMillis();
    if(now-lastAirRequest>95000L){lastAirRequest=now;
      RunningballV25GlobalAircraftData.refresh(Duwm1677MissionControlActivity.this,()->{if(active)updateSources();});}
    if(now-lastSeaRequest>240000L){lastSeaRequest=now;
      Duwm1674MaritimeRefresh.refresh(Duwm1677MissionControlActivity.this,()->{if(active)updateSources();});}
    ui.postDelayed(this,15000L);
  }};

  private int dp(float a){return Math.round(a*getResources().getDisplayMetrics().density);}
  private TextView text(String content,int sp,int color,boolean bold){
    TextView t=new TextView(this);t.setText(content);t.setTextSize(sp);t.setTextColor(color);
    t.setFontFeatureSettings("tnum");if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return t;
  }
  private GradientDrawable surface(int fill,int stroke,int radius){
    GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
      new int[]{fill, fill==PANEL?0xFF041424:fill==PANEL2?0xFF0C1A35:fill});
    d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;
  }
  private TextView action(String name,Runnable fn){
    TextView t=text(name,11,CYAN,true);t.setGravity(Gravity.CENTER);
    t.setPadding(dp(10),dp(12),dp(10),dp(12));t.setBackground(surface(PANEL,BORDER,10));
    t.setOnClickListener(v->fn.run());t.setMinimumHeight(dp(44));return t;
  }
  private LinearLayout column(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
  private LinearLayout row(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
  private void gap(LinearLayout p,int h){View v=new View(this);p.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
  private void addWeighted(LinearLayout r,View v,int margin){
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f);
    lp.leftMargin=dp(margin);r.addView(v,lp);
  }
  private void pageButton(LinearLayout parent,String name,Runnable fn){
    TextView b=action(name,fn);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(8);parent.addView(b,p);
  }
  private void section(LinearLayout p,String title,String sub){
    TextView t=text(title,14,WHITE,true);p.addView(t);
    if(sub!=null&&!sub.isEmpty()){TextView s=text(sub,10,MUTED,false);p.addView(s);}
  }
  private String utc(long ts){if(ts<=0)return "NO SOURCE TIME";SimpleDateFormat f=new SimpleDateFormat("dd MMM yyyy • HH:mm 'UTC'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(ts));}
  private String clockUtc(){SimpleDateFormat f=new SimpleDateFormat("HH:mm:ss 'UTC'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date());}
  private void start(Class<?> klass){startActivity(new Intent(this,klass));}
  private void media(String name){Intent intent=new Intent(this,MediaDeskActivity.class);intent.putExtra("mode",name);startActivity(intent);}
  private void desk(String name){Intent i=new Intent(this,Duwm1671SectorActivity.class);i.putExtra(Duwm1671SectorActivity.EXTRA_KIND,name);startActivity(i);}
  private void openCategory(int i){switch(i){
    case 0:start(Duwm1670FlightMapActivity.class);break;
    case 1:start(GevMarineActivity.class);break;
    case 2:start(Duwm1670NewsAtlasActivity.class);break;
    case 3:desk("WEATHER");break;
    case 4:desk("MARKETS");break;
    case 5:desk("EARTHQUAKES");break;
    case 6:start(GevSatelliteActivity.class);break;
    default:media("TV STATIONS");break;
  }}
  @Override public void onCreate(Bundle bundle){super.onCreate(bundle);
    getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    LinearLayout frame=column();frame.setBackgroundColor(BG);setContentView(frame);Duwm1167SafeArea.install(this,frame);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setVerticalScrollBarEnabled(false);
    frame.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout content=column();content.setPadding(dp(12),dp(9),dp(12),dp(18));scroll.addView(content);

    LinearLayout brand=row();content.addView(brand);
    TextView logo=text("◢  DUWM",23,WHITE,true);brand.addView(logo,new LinearLayout.LayoutParams(0,-2,1));
    TextView build=text("v1678",12,CYAN,true);brand.addView(build);
    TextView title=text("GLOBAL SITUATION ROOM   /   WORLD INTELLIGENCE",10,MUTED,true);
    content.addView(title);
    gap(content,9);
    LinearLayout state=row();state.setBackground(surface(PANEL,BORDER,9));state.setPadding(dp(10),dp(9),dp(10),dp(9));content.addView(state);
    utcLine=text("UTC --:--:--",11,CYAN,true);state.addView(utcLine,new LinearLayout.LayoutParams(0,-2,1));
    healthLine=text("SOURCE CHECK",11,AQUA,true);state.addView(healthLine);
    state.setOnClickListener(v->start(Duwm1671SourceStatusActivity.class));
    gap(content,11);

    HorizontalScrollView strip=new HorizontalScrollView(this);strip.setHorizontalScrollBarEnabled(false);content.addView(strip);
    LinearLayout tabs=row();strip.addView(tabs);
    for(int i=0;i<LABELS.length;i++){
      final int index=i;LinearLayout tile=column();tile.setGravity(Gravity.CENTER);
      tile.setPadding(dp(13),dp(8),dp(13),dp(9));tile.setBackground(surface(PANEL,BORDER,8));
      LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(98),dp(79));if(i>0)p.leftMargin=dp(5);tabs.addView(tile,p);
      LinearLayout name=row();tile.addView(name);
      signal[i]=text("●",15,0xFF426CAF,true);name.addView(signal[i]);
      TextView n=text(" "+LABELS[i],11,WHITE,true);name.addView(n);
      metric[i]=text("--",18,WHITE,true);metric[i].setSingleLine(true);metric[i].setGravity(Gravity.CENTER);tile.addView(metric[i]);
      metricState[i]=text("NO RECEIPT",9,MUTED,false);metricState[i].setSingleLine(true);metricState[i].setGravity(Gravity.CENTER);tile.addView(metricState[i]);
      tile.setOnClickListener(v->openCategory(index));
    }
    gap(content,13);
    section(content,"EARTH  /  GLOBAL OPERATIONS","OBSERVED POSITIONS • REAL SOURCE TIME • NO SYNTHETIC MOVEMENT");
    FrameLayout mapContainer=new FrameLayout(this);mapContainer.setBackground(surface(PANEL,BORDER,16));
    LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(352));mp.topMargin=dp(8);content.addView(mapContainer,mp);
    globe=new OperationsGlobeView(this);globe.setGlobePalette(true);globe.setRotationSpeed(1.45f);globe.setCompassRingEnabled(true);
    mapContainer.addView(globe,new FrameLayout.LayoutParams(-1,-1));
    heroLabel=text("●  EARTH 1678   •   OBSERVATION LAYER",10,CYAN,true);heroLabel.setPadding(dp(9),dp(7),dp(9),dp(7));heroLabel.setBackground(surface(0xD8172F52,0,7));
    FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT);hp.topMargin=dp(10);hp.leftMargin=dp(9);mapContainer.addView(heroLabel,hp);
    TextView tip=text("DRAG / PINCH / TAP REAL SOURCE POINTS",9,MUTED,false);tip.setGravity(Gravity.CENTER);tip.setPadding(dp(8),dp(6),dp(8),dp(6));tip.setBackground(surface(0xDE0A1C3B,0,6));
    FrameLayout.LayoutParams tipLp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);tipLp.leftMargin=dp(7);tipLp.rightMargin=dp(7);tipLp.bottomMargin=dp(9);mapContainer.addView(tip,tipLp);
    globe.setOnObservationSelected(o->{selected=o;
      mapDetails.setText(o.title+"  •  "+o.source+"\n"+utc(o.timeMillis)+"  •  "+o.detail);
      mapDetails.setTextColor(WHITE);
    });
    gap(content,8);
    LinearLayout geos=row();content.addView(geos);
    addWeighted(geos,action("AFRICA",()->focus(-1.8,23.5)),0);
    addWeighted(geos,action("EUROPE",()->focus(50,13)),5);
    addWeighted(geos,action("ASIA",()->focus(27,90)),5);
    addWeighted(geos,action("AMERICAS",()->focus(18,-77)),5);
    gap(content,7);
    LinearLayout controls=row();content.addView(controls);
    rotationButton=action("ROTATE  ●",()->{rotating=!rotating;if(rotating)globe.resume();else globe.pause();rotationButton.setText(rotating?"ROTATE  ●":"ROTATE  OFF");});
    addWeighted(controls,rotationButton,0);
    paletteButton=action("MAP STYLE",()->{aurora=!aurora;globe.setGlobePalette(aurora);paletteButton.setText(aurora?"MAP STYLE":"DARK EARTH");});
    addWeighted(controls,paletteButton,5);
    addWeighted(controls,action("SYNC DATA",this::requestFeeds),5);
    gap(content,8);
    LinearLayout layers=row();content.addView(layers);
    addWeighted(layers,action("AIR",()->{airEnabled=!airEnabled;globe.showLayer(OperationsGlobeView.AIR,airEnabled);}),0);
    addWeighted(layers,action("SEA",()->{seaEnabled=!seaEnabled;globe.showLayer(OperationsGlobeView.SEA,seaEnabled);}),5);
    addWeighted(layers,action("QUAKE",()->{quakeEnabled=!quakeEnabled;globe.showLayer(OperationsGlobeView.QUAKE,quakeEnabled);}),5);
    addWeighted(layers,action("ISS",()->{spaceEnabled=!spaceEnabled;globe.showLayer(OperationsGlobeView.SPACE,spaceEnabled);}),5);
    mapDetails=text("TAP AN ACTUAL POSITION ON THE GLOBE TO INSPECT OR SHARE IT",11,MUTED,false);
    mapDetails.setPadding(dp(10),dp(12),dp(10),dp(12));mapDetails.setBackground(surface(PANEL,BORDER,9));
    LinearLayout.LayoutParams selp=new LinearLayout.LayoutParams(-1,-2);selp.topMargin=dp(8);content.addView(mapDetails,selp);
    pageButton(content,"SHARE SELECTED OBSERVATION",this::shareSelected);
    gap(content,18);

    section(content,"REGIONAL OPERATIONS","COUNTRY BORDERS FROM MAP DATA • DOTS ARE RECEIVED COORDINATES");
    regional=new Duwm1670WorldMapView(this);regional.setLayer("AIRCRAFT");
    regional.setOnPinSelected(pin->new AlertDialog.Builder(this).setTitle(pin.title)
      .setMessage(pin.detail+"\nOBSERVED: "+utc(pin.observed)+"\nCOORDINATES: "+pin.lat+", "+pin.lon)
      .setPositiveButton("SHARE CARD",(d,w)->V115941ShareCards.share(this,pin.type,pin.title,pin.detail,
        "DUWM / saved observation",pin.observed,pin.lat,pin.lon,"",null))
      .setNegativeButton("CLOSE",null).show());
    LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(221));rp.topMargin=dp(8);content.addView(regional,rp);
    gap(content,10);
    section(content,"SOURCE INTELLIGENCE  /  LIVE DESKS","COUNTERS DISPLAY RECEIVED RECORDS • CACHED DATA IS LABELLED");
    LinearLayout operational=row();content.addView(operational);
    summaryAir=card(operational,"✈  AIRCRAFT",()->start(Duwm1670FlightMapActivity.class),0);
    summarySea=card(operational,"▰  VESSELS",()->start(GevMarineActivity.class),6);
    gap(content,7);
    LinearLayout intelligence=row();content.addView(intelligence);
    summaryNews=card(intelligence,"▤  WORLD NEWS",()->start(Duwm1670NewsAtlasActivity.class),0);
    summaryWeather=card(intelligence,"☁  WEATHER",()->desk("WEATHER"),6);
    gap(content,7);
    LinearLayout next=row();content.addView(next);
    summaryFx=card(next,"↗  FINANCIAL MARKETS",()->desk("MARKETS"),0);
    summaryEvents=card(next,"◎  QUAKES / SAT",()->desk("EARTHQUAKES"),6);
    gap(content,14);

    section(content,"NEWS / EVENTS WIRE","PUBLISHER REPORTS ARE NOT INDEPENDENTLY VERIFIED INCIDENTS");
    feedLine=text("AWAITING RECEIVED PUBLISHER RECORDS",12,WHITE,false);feedLine.setPadding(dp(12),dp(13),dp(12),dp(13));
    feedLine.setBackground(surface(PANEL2,BORDER,9));feedLine.setMaxLines(3);
    LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,-2);fp.topMargin=dp(8);content.addView(feedLine,fp);
    feedLine.setOnClickListener(v->start(Duwm1670NewsAtlasActivity.class));
    gap(content,12);
    section(content,"SPECIALIST INTELLIGENCE","DEDICATED GEOGRAPHIC, MEDIA AND SOURCE EVIDENCE DESKS");
    LinearLayout special1=row();content.addView(special1);
    summaryGeo=card(special1,"◈  GEOPOLITICAL BRIEF",()->start(Duwm1670NewsAtlasActivity.class),0);
    summaryInfra=card(special1,"▧  INFRASTRUCTURE / CAMS",()->media("PUBLIC CAMERAS"),6);
    gap(content,7);
    LinearLayout special2=row();content.addView(special2);
    summaryRadiation=card(special2,"◎  RADIATION WATCH",()->start(Duwm1671SourceStatusActivity.class),0);
    summaryTrend=card(special2,"↗  RECEIPT CHANGES",()->start(Duwm1675EvidenceVaultActivity.class),6);
    gap(content,11);
    LinearLayout util=row();content.addView(util);
    addWeighted(util,action("GEO WATCHLIST",()->start(Duwm1676GeoWatchActivity.class)),0);
    addWeighted(util,action("EVIDENCE VAULT",()->start(Duwm1675EvidenceVaultActivity.class)),6);
    gap(content,8);
    LinearLayout util2=row();content.addView(util2);
    addWeighted(util2,action("PUBLIC CAMERAS",()->media("PUBLIC CAMERAS")),0);
    addWeighted(util2,action("LIVE TELEVISION",()->media("TV STATIONS")),6);
    gap(content,8);
    LinearLayout util3=row();content.addView(util3);
    addWeighted(util3,action("WORLD RADIO",()->media("RADIO")),0);
    addWeighted(util3,action("SOURCE HEALTH",()->start(Duwm1671SourceStatusActivity.class)),6);
    gap(content,8);
    pageButton(content,"ALL 200 WORLDWIDE SOURCE DIRECTORIES",()->start(Duwm1669SourceDirectoryActivity.class));
    gap(content,8);
    content.addView(text("VISUALIZATION • ROTATION AND PULSE ARE UI EFFECTS, NOT NEW PROVIDER REPORTS.\nAVAILABLE DATA MAY BE REGION-LIMITED, DELAYED OR SUBJECT TO PROVIDER ACCESS RULES.",10,MUTED,false));

    LinearLayout bottom=row();bottom.setPadding(dp(4),dp(4),dp(4),dp(4));bottom.setBackground(surface(0xFF041424,BORDER,10));frame.addView(bottom,new LinearLayout.LayoutParams(-1,dp(58)));
    nav(bottom,"HOME",()->scroll.smoothScrollTo(0,0));
    nav(bottom,"MAP",()->start(Duwm1670FlightMapActivity.class));
    nav(bottom,"INTEL",()->start(Duwm1671SourceStatusActivity.class));
    nav(bottom,"MEDIA",()->media("TV STATIONS"));
    nav(bottom,"MORE",()->start(Duwm1676GeoWatchActivity.class));
    updateSources();
  }
  private TextView card(LinearLayout row,String title,Runnable action,int leftMargin){
    LinearLayout p=column();p.setPadding(dp(12),dp(12),dp(12),dp(12));p.setBackground(surface(PANEL,BORDER,11));
    LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(0,dp(116),1);params.leftMargin=dp(leftMargin);row.addView(p,params);
    TextView head=text(title,12,CYAN,true);p.addView(head);
    TextView value=text("AWAITING SOURCE",13,WHITE,true);value.setMaxLines(3);
    LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-1,0,1);vp.topMargin=dp(11);p.addView(value,vp);
    p.setOnClickListener(v->action.run());return value;
  }
  private void nav(LinearLayout row,String title,Runnable action){
    TextView item=text(title,11,CYAN,true);item.setGravity(Gravity.CENTER);item.setOnClickListener(v->action.run());
    row.addView(item,new LinearLayout.LayoutParams(0,-1,1));
  }
  private void focus(double lat,double lon){globe.focusAt(lat,lon);rotating=false;rotationButton.setText("ROTATE  OFF");
    regional.focus(lat,lon,2.1f);
  }
  private void shareSelected(){
    if(selected==null){Toast.makeText(this,"Select a real observation first",Toast.LENGTH_SHORT).show();return;}
    OperationsGlobeView.Observation o=selected;
    String type=o.type==OperationsGlobeView.AIR?"AIRCRAFT":o.type==OperationsGlobeView.SEA?"VESSEL":o.type==OperationsGlobeView.QUAKE?"EARTHQUAKE":"ISS";
    V115941ShareCards.share(this,type,o.title,o.detail,o.source,o.timeMillis,o.lat,o.lon,"",null);
  }
  private void requestFeeds(){healthLine.setText("REQUESTED");
    RunningballV25GlobalAircraftData.refreshNow(this,()->{if(active)updateSources();});
    RunningballV25NewsRepository.refresh(this,true,()->{if(active)updateSources();});
    RunningballV17Feeds.request(this,true,()->{if(active)updateSources();});
    Duwm1674MaritimeRefresh.refresh(this,()->{if(active)updateSources();});
  }
  private void putMetric(int i,String value,long received,boolean current,String kind){
    metric[i].setText(value==null||value.isEmpty()?"--":value);
    boolean old=received>0&&!current;int light=current?AQUA:old?AMBER:0xFF426CAF;
    signal[i].setTextColor(light);metric[i].setTextColor(current?WHITE:old?AMBER:MUTED);
    metricState[i].setText(current?"RECEIVED":old?"CACHED":"NO RECEIPT");
  }
  private void updateSources(){if(metric[0]==null||globe==null)return;
    utcLine.setText("●  "+clockUtc());
    Duwm1674UnifiedReceipts.Receipt air=Duwm1674UnifiedReceipts.aircraft(this);
    Duwm1674UnifiedReceipts.Receipt sea=Duwm1674UnifiedReceipts.maritime(this);
    Duwm1674UnifiedReceipts.Receipt news=Duwm1674UnifiedReceipts.news(this);
    putMetric(0,air.count(),air.receivedAt,air.current,"AIR");
    putMetric(1,sea.count(),sea.receivedAt,sea.current,"SEA");
    putMetric(2,news.count(),news.receivedAt,news.current,"NEWS");
    int[] ids={6,7,3,1};int n=3;int received=(air.hasReceipt()?1:0)+(sea.hasReceipt()?1:0)+(news.hasReceipt()?1:0);
    for(int id:ids){RunningballV25Sources.Result r=RunningballV25Sources.read(this,id);
      boolean valid=r.fetchedAt>0&&(r.status==RunningballV25Sources.Status.LIVE||r.status==RunningballV25Sources.Status.DELAYED);
      putMetric(n++,r.value,r.fetchedAt,valid,r.key);if(r.fetchedAt>0)received++;}
    putMetric(7,"OPEN",0L,false,"MEDIA");metricState[7].setText("SELECT");
    healthLine.setText(received+" SOURCE RECEIPTS");
    summaryAir.setText(air.count()+" RECEIVED\n"+shorten(air.detail,67));
    summarySea.setText(sea.count()+" AIS / REGION\n"+shorten(sea.detail,67));
    summaryNews.setText(news.count()+" HEADLINES\n"+shorten(news.detail,67));
    RunningballV25Sources.Result weather=RunningballV25Sources.read(this,6);
    RunningballV25Sources.Result fx=RunningballV25Sources.read(this,7);
    RunningballV25Sources.Result quake=RunningballV25Sources.read(this,3);
    RunningballV25Sources.Result sat=RunningballV25Sources.read(this,1);
    summaryWeather.setText("WX "+weather.value+"\n"+weather.display());
    summaryFx.setText("FX "+fx.value+"\n"+fx.display());
    summaryEvents.setText("QUAKE "+quake.value+" / SAT "+sat.value+"\nSOURCE STATUS AVAILABLE");
    int conflict=RunningballV25NewsRepository.articles(this,"conflict_world").length()
      +RunningballV25NewsRepository.articles(this,"conflict_middle_east").length();
    summaryGeo.setText(conflict+" PUBLISHER REPORTS\nNOT VERIFIED INCIDENT COUNTS");
    summaryInfra.setText("PUBLIC CAMERA DIRECTORY\nLIVE VIDEO / SNAPSHOTS IF AVAILABLE");
    summaryRadiation.setText("NO RADIATION METER SOURCE\nNO MEASUREMENTS INVENTED");
    int captures=Duwm1675EvidenceStore.read(this).length();
    summaryTrend.setText(captures+" SAVED RECEIPT CAPTURES\nCOMPARE ACTUAL SNAPSHOTS");
    updateNewsWire();
    updateMap();
  }
  private String shorten(String s,int len){if(s==null)return "NO SOURCE";return s.length()>len?s.substring(0,len-1)+"…":s;}
  private void updateNewsWire(){
    String latest="";String provider="";long published=0L;
    for(String key:RunningballV25NewsRepository.KEYS){
      JSONArray entries=RunningballV25NewsRepository.articles(this,key);
      for(int i=0;i<Math.min(2,entries.length());i++){
        JSONObject a=entries.optJSONObject(i);if(a==null)continue;
        String title=a.optString("title","").trim();
        if(title.length()<8)continue;
        long receivedAt=RunningballV25NewsRepository.last(this,key);
        if(receivedAt>published){published=receivedAt;latest=title;provider=a.optString("publisher","SOURCE NOT STATED");}
        break;
      }
    }
    if(latest.isEmpty()){
      Duwm1674UnifiedReceipts.Receipt r=Duwm1674UnifiedReceipts.news(this);
      feedLine.setText(r.entries>0?r.count()+" STORED ARTICLE ENTRIES • OPEN NEWS ATLAS TO READ":"NO PUBLISHER HEADLINES RECEIVED • TAP TO OPEN NEWS ATLAS");
    }else feedLine.setText(provider+" / PUBLISHER HEADLINE\n"+latest+"\nRECEIVED "+utc(published));
  }
  private void updateMap(){
    ArrayList<OperationsGlobeView.Observation> newOnes=new ArrayList<>();
    ArrayList<Duwm1670WorldMapView.Pin> flat=new ArrayList<>();
    RunningballV25GlobalAircraftData.Snapshot s=RunningballV25GlobalAircraftData.read(this);
    if(s.hasGood()&&s.ageMs()<21600000L){
      JSONArray pts=s.points;int step=Math.max(1,(pts.length()+799)/800);
      for(int i=0;i<pts.length()&&newOnes.size()<800;i+=step){
        JSONArray a=pts.optJSONArray(i);if(a==null)continue;
        double lat=a.optDouble(0,Double.NaN),lon=a.optDouble(1,Double.NaN);
        long at=Duwm1674TimeGuard.normalize(a.isNull(7)?s.sourceAt:a.optLong(7));
        if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180||!Duwm1674TimeGuard.recent(at,21600000L))continue;
        String id=a.optString(3,a.optString(2,"AIRCRAFT"));
        newOnes.add(new OperationsGlobeView.Observation(OperationsGlobeView.AIR,lat,lon,id,"OpenSky received position", "OpenSky",at));
        flat.add(new Duwm1670WorldMapView.Pin(id,id,"AIRCRAFT",lat,lon,at,"OpenSky received position"));
      }
    }
    for(DuwmGeoObservationStore.Fix f:DuwmGeoObservationStore.read(this)){
      int kind="EARTHQUAKE".equals(f.type)?OperationsGlobeView.QUAKE:"ISS".equals(f.type)?OperationsGlobeView.SPACE:-1;
      if(kind<0)continue;
      newOnes.add(new OperationsGlobeView.Observation(kind,f.lat,f.lon,f.title,f.detail,f.provider,f.sourceTime));
      Duwm1670WorldMapView.Pin pin=new Duwm1670WorldMapView.Pin(f.id,f.title,f.type,f.lat,f.lon,f.sourceTime,f.detail);
      if(f.hasActualTrack()){pin.prevLat=f.oldLat;pin.prevLon=f.oldLon;pin.prevObserved=f.oldTime;}
      flat.add(pin);
    }
    SharedPreferences storage=getSharedPreferences("rb11_marine",MODE_PRIVATE);
    long fetch=storage.getLong("last_fetch",0L);
    if(fetch>0&&System.currentTimeMillis()-fetch<86400000L){
      try{
        JSONObject payload=new JSONObject(storage.getString("rows","{}"));
        JSONArray ships=payload.optJSONArray("rows");
        if(ships!=null){int step=Math.max(1,(ships.length()+199)/200);
          for(int i=0;i<ships.length()&&newOnes.size()<1250;i+=step){
            JSONObject vessel=ships.optJSONObject(i);if(vessel==null)continue;
            double lat=vessel.optDouble("lat",Double.NaN),lon=vessel.optDouble("lon",Double.NaN);
            String mmsi=vessel.optString("mmsi","");
            if(!GevMarineMath.valid(lat,lon)||!GevMarineMath.validMmsi(mmsi))continue;
            String name=vessel.optString("name","");if(name.isEmpty())name="MMSI "+mmsi;
            long at=GevMarineActivity.timestamp(vessel);
            String info="Received AIS position • MMSI "+mmsi+(at>0?" • "+utc(at):" • SOURCE TIME UNKNOWN");
            newOnes.add(new OperationsGlobeView.Observation(OperationsGlobeView.SEA,lat,lon,name,info,
              payload.optString("source","Regional AIS"),at));
            flat.add(new Duwm1670WorldMapView.Pin(mmsi,name,"VESSEL",lat,lon,at,info));
          }
        }
      }catch(Exception ignored){}
    }
    observations.clear();observations.addAll(newOnes);
    globe.setObservations(newOnes);
    // New provider snapshots change the data; idle UI repainting never invents a position.
    regional.setPins(flat,false);
    heroLabel.setText("●  EARTH 1678  /  "+newOnes.size()+" OBSERVED MARKERS");
  }
  @Override protected void onResume(){super.onResume();active=true;globe.resume();regional.resume();updateSources();
    ui.removeCallbacks(clock);ui.postDelayed(clock,15000L);
    lastAirRequest=System.currentTimeMillis();RunningballV25GlobalAircraftData.refresh(this,()->{if(active)updateSources();});
    RunningballV25NewsRepository.refresh(this,false,()->{if(active)updateSources();});
    RunningballV17Feeds.request(this,false,()->{if(active)updateSources();});
    lastSeaRequest=System.currentTimeMillis();Duwm1674MaritimeRefresh.refresh(this,()->{if(active)updateSources();});
  }
  @Override protected void onPause(){active=false;ui.removeCallbacks(clock);globe.pause();regional.pause();super.onPause();}
}
