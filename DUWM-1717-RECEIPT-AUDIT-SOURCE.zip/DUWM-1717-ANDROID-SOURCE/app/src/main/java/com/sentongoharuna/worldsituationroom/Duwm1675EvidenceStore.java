package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

/**
 * Offline, user-triggered snapshots of ACTUAL receipt metadata found on this device.
 * This is not an automatic live feed or an independent verification of publisher claims.
 */
public final class Duwm1675EvidenceStore {
    private static final String PREFS="duwm1675_evidence_v1", KEY="captures";
    public static final int MAX_CAPTURES=60;
    public static final String[] CHANNELS={"AIR","SAT","SEA","QUAKE","EVENT","NEWS","WEATHER","FX","KP"};
    private Duwm1675EvidenceStore() {}
    private static SharedPreferences prefs(Context c){return c.getApplicationContext().getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    public static JSONArray read(Context c){
        try {return new JSONArray(prefs(c).getString(KEY,"[]"));}catch(Exception ignored){return new JSONArray();}
    }
    private static JSONObject put(JSONObject obj,String key,Object value){try{obj.put(key,value);}catch(Exception ignored){}return obj;}
    private static JSONObject channel(String id,String name,String provider,String value,String status,
                                      long fetchedAt,long sourceTime,String detail){
        JSONObject entry=new JSONObject();
        put(entry,"id",id);put(entry,"name",name);put(entry,"provider",provider);
        put(entry,"value",value);put(entry,"status",status);
        put(entry,"fetchedAt",fetchedAt);put(entry,"sourceTime",sourceTime);
        put(entry,"detail",detail==null?"":detail);
        return entry;
    }
    public static JSONObject capture(Context c,String userNote){
        long capturedAt=System.currentTimeMillis();
        JSONArray observations=new JSONArray();
        int receipts=0;
        for(int i=0;i<CHANNELS.length;i++){
            String id=CHANNELS[i];
            if(i==0 || i==2 || i==5){
                Duwm1674UnifiedReceipts.Receipt r=i==0?Duwm1674UnifiedReceipts.aircraft(c):
                    (i==2?Duwm1674UnifiedReceipts.maritime(c):Duwm1674UnifiedReceipts.news(c));
                String provider=i==0?"OpenSky":i==2?"Public regional AIS / configured provider":"Stored publisher feeds";
                String state=!r.hasReceipt()?"NO RECEIPT":r.current?"RECENT RECEIPT":"CACHED / STALE";
                long sourceTime=i==0?Duwm1674TimeGuard.normalize(RunningballV25GlobalAircraftData.read(c).sourceAt):0L;
                observations.put(channel(id,RunningballV25Sources.NAMES[i],provider,r.count(),state,r.receivedAt,sourceTime,r.detail));
                if(r.hasReceipt())receipts++;
            }else{
                RunningballV25Sources.Result r=RunningballV25Sources.read(c,i);
                observations.put(channel(id,r.key.toUpperCase(Locale.US),r.provider,
                    r.value==null?"--":r.value,r.status.toString().replace('_',' '),
                    r.fetchedAt,r.sourceTime,(r.errorReason==null||r.errorReason.isEmpty())?r.coverage:r.coverage+" • "+r.errorReason));
                if(r.fetchedAt>0)receipts++;
            }
        }
        JSONObject snapshot=new JSONObject();
        put(snapshot,"schema",1);put(snapshot,"capturedAt",capturedAt);
        String note=userNote==null?"":userNote.trim();
        put(snapshot,"note",note.length()>200?note.substring(0,200):note);
        put(snapshot,"receiptCount",receipts);put(snapshot,"channels",observations);
        JSONArray existing=read(c), updated=new JSONArray();updated.put(snapshot);
        for(int i=0;i<existing.length()&&updated.length()<MAX_CAPTURES;i++){
            JSONObject previous=existing.optJSONObject(i);if(previous!=null)updated.put(previous);
        }
        if(!prefs(c).edit().putString(KEY,updated.toString()).commit())
            throw new IllegalStateException("Local snapshot could not be saved");
        return snapshot;
    }
    public static String details(JSONObject snapshot,String onlyChannel){
        if(snapshot==null)return "NO SAVED SNAPSHOT";
        StringBuilder b=new StringBuilder("RECORDED ON DEVICE  ")
            .append(Duwm1675EvidenceMath.utc(snapshot.optLong("capturedAt")))
            .append("\nProvider receipts at capture: ").append(snapshot.optInt("receiptCount"))
            .append(" / 9\nDevice snapshot; not proof of live provider availability.\n");
        String note=snapshot.optString("note","");if(!note.isEmpty())b.append("NOTE: ").append(note).append("\n");
        JSONArray records=snapshot.optJSONArray("channels");if(records==null)return b.toString();
        for(int i=0;i<records.length();i++){
            JSONObject o=records.optJSONObject(i);if(o==null)continue;
            String id=o.optString("id");if(onlyChannel!=null&&!onlyChannel.isEmpty()&&!onlyChannel.equals(id))continue;
            b.append("\n").append(id).append(" / ").append(o.optString("value","--"))
             .append(" / ").append(o.optString("status","UNKNOWN"))
             .append("\nProvider: ").append(o.optString("provider","UNKNOWN"))
             .append("\nReceived: ").append(Duwm1675EvidenceMath.utc(o.optLong("fetchedAt")))
             .append("\nSource timestamp: ").append(Duwm1675EvidenceMath.utc(o.optLong("sourceTime")))
             .append("\n").append(o.optString("detail","")).append("\n");
        }
        return b.toString();
    }
    public static String compare(JSONObject earlier,JSONObject later){
        if(earlier==null||later==null)return "Capture at least two snapshots first.";
        StringBuilder b=new StringBuilder("CHANGE BETWEEN TWO USER CAPTURES\n")
            .append(Duwm1675EvidenceMath.utc(earlier.optLong("capturedAt"))).append("  →  ")
            .append(Duwm1675EvidenceMath.utc(later.optLong("capturedAt")))
            .append("\nEach provider was fetched independently; this is a cache comparison, not a synchronized observation.\n");
        JSONArray x=earlier.optJSONArray("channels"),y=later.optJSONArray("channels");
        if(x==null||y==null)return b.toString();
        for(int i=0;i<Math.min(x.length(),y.length());i++){
            JSONObject prev=x.optJSONObject(i),curr=y.optJSONObject(i);if(prev==null||curr==null)continue;
            String oldVal=prev.optString("value","--"),newVal=curr.optString("value","--");
            String oldStatus=prev.optString("status",""),newStatus=curr.optString("status","");
            String delta=Duwm1675EvidenceMath.delta(oldVal,newVal);
            b.append("\n").append(curr.optString("id","?"))
                .append(": ").append(oldVal).append(" → ").append(newVal);
            if(!delta.isEmpty())b.append(" (Δ ").append(delta).append(")");
            if(!oldStatus.equals(newStatus))b.append(" [").append(oldStatus).append(" → ").append(newStatus).append("]");
            else b.append(" [").append(newStatus).append("]");
            long t1=prev.optLong("fetchedAt"),t2=curr.optLong("fetchedAt");
            if(t1==t2&&t1>0)b.append(" • SAME PROVIDER RECEIPT");
        }
        return b.toString();
    }
    public static String exportCsv(JSONArray history){
        StringBuilder b=new StringBuilder("capture_utc,channel,provider,value,status,receipt_utc,source_utc,note,detail\r\n");
        if(history==null)return b.toString();
        for(int j=0;j<history.length();j++){
            JSONObject snapshot=history.optJSONObject(j);if(snapshot==null)continue;
            JSONArray channels=snapshot.optJSONArray("channels");if(channels==null)continue;
            for(int i=0;i<channels.length();i++){
                JSONObject o=channels.optJSONObject(i);if(o==null)continue;
                String[] fields={Duwm1675EvidenceMath.utc(snapshot.optLong("capturedAt")),
                    o.optString("id"),o.optString("provider"),o.optString("value"),o.optString("status"),
                    Duwm1675EvidenceMath.utc(o.optLong("fetchedAt")),
                    Duwm1675EvidenceMath.utc(o.optLong("sourceTime")),
                    snapshot.optString("note"),o.optString("detail")};
                for(int k=0;k<fields.length;k++){if(k>0)b.append(',');b.append(Duwm1675EvidenceMath.csv(fields[k]));}
                b.append("\r\n");
            }
        }
        return b.toString();
    }
}
