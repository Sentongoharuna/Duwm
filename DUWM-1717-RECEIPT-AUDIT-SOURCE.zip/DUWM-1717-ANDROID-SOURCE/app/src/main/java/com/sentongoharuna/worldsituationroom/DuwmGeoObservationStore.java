package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

/** Only actual source-reported fixes are stored. A trace needs two distinct observed positions. */
public final class DuwmGeoObservationStore {
  private static final String PREF = "duwm_1160_geo_observations";
  private static final String JSON_KEY = "fixes";
  private static final int MAX_RECORDS=260;
  private DuwmGeoObservationStore() {}
  public static final class Fix {
    public final String id, type, title, detail, provider, url;
    public final double lat, lon;
    public final long sourceTime, receivedAt;
    public final Double oldLat, oldLon;
    public final long oldTime;
    public Fix(String id,String type,String title,String detail,String provider,String url,
               long sourceTime,long receivedAt,double lat,double lon,Double oldLat,Double oldLon,long oldTime){
      this.id=id;this.type=type;this.title=title;this.detail=detail;this.provider=provider;this.url=url;
      this.lat=lat;this.lon=lon;this.sourceTime=sourceTime;this.receivedAt=receivedAt;
      this.oldLat=oldLat;this.oldLon=oldLon;this.oldTime=oldTime;
    }
    public boolean hasActualTrack(){
      return oldLat!=null&&oldLon!=null&&oldTime>0&&sourceTime>oldTime&&
          sourceTime-oldTime<=3600000L&&valid(oldLat,oldLon)&&valid(lat,lon)&&
          (Math.abs(oldLat-lat)>0.00001||Math.abs(oldLon-lon)>0.00001) &&
          (type.equals("AIRCRAFT")||type.equals("ISS")||type.equals("VESSEL"));
    }
  }
  private static boolean valid(double lat,double lon){
    return Double.isFinite(lat)&&Double.isFinite(lon)&&Math.abs(lat)<=90&&Math.abs(lon)<=180;
  }
  private static JSONObject serialize(Fix f){
    JSONObject j=new JSONObject();try{
      j.put("id",f.id);j.put("type",f.type);j.put("title",f.title);j.put("detail",f.detail);
      j.put("provider",f.provider);j.put("url",f.url);j.put("time",f.sourceTime);
      j.put("received",f.receivedAt);j.put("lat",f.lat);j.put("lon",f.lon);
      if(f.oldLat!=null&&f.oldLon!=null){j.put("oldLat",f.oldLat);j.put("oldLon",f.oldLon);j.put("oldTime",f.oldTime);}
    }catch(Exception ignored){}return j;
  }
  private static Fix parse(JSONObject j){
    if(j==null)return null;double lat=j.optDouble("lat",Double.NaN),lon=j.optDouble("lon",Double.NaN);
    if(!valid(lat,lon))return null;
    Double a=j.has("oldLat")?j.optDouble("oldLat",Double.NaN):null;
    Double b=j.has("oldLon")?j.optDouble("oldLon",Double.NaN):null;
    if(a!=null&&b!=null&&!valid(a,b)){a=null;b=null;}
    return new Fix(j.optString("id",""),j.optString("type",""),j.optString("title",""),
        j.optString("detail",""),j.optString("provider",""),j.optString("url",""),
        j.optLong("time",0L),j.optLong("received",0L),lat,lon,a,b,j.optLong("oldTime",0L));
  }
  public static synchronized List<Fix> read(Context ctx){
    ArrayList<Fix> out=new ArrayList<>();
    try{String raw=ctx.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(JSON_KEY,"[]");
      JSONArray j=new JSONArray(raw);for(int i=0;i<j.length();i++){Fix f=parse(j.optJSONObject(i));if(f!=null&&!f.id.isEmpty())out.add(f);}
    }catch(Exception ignored){}return out;
  }
  /** Merge one received source type. Failed/unavailable sources must not publish invented points. */
  public static synchronized void publishType(Context ctx,String kind,List<Fix> fresh){
    if(ctx==null||kind==null||fresh==null)return;
    Map<String,Fix> before=new HashMap<>();for(Fix f:read(ctx))before.put(f.id,f);
    ArrayList<Fix> result=new ArrayList<>();long now=System.currentTimeMillis();
    for(Fix f:before.values()){
      if(!kind.equals(f.type)&&now-f.receivedAt<86400000L)result.add(f);
    }
    HashSet<String> added=new HashSet<>();
    for(Fix f:fresh){
      if(f==null||!kind.equals(f.type)||!valid(f.lat,f.lon)||f.id.isEmpty()||!added.add(f.id))continue;
      Fix prior=before.get(f.id);
      Double oldLat=null,oldLon=null;long oldTime=0;
      if(prior!=null&&prior.sourceTime>0&&f.sourceTime>prior.sourceTime&&
          f.sourceTime-prior.sourceTime<=3600000L&&
          (Math.abs(f.lat-prior.lat)>0.00001||Math.abs(f.lon-prior.lon)>0.00001)){
        oldLat=prior.lat;oldLon=prior.lon;oldTime=prior.sourceTime;
      }else if(prior!=null&&prior.sourceTime==f.sourceTime&&prior.hasActualTrack()){
        oldLat=prior.oldLat;oldLon=prior.oldLon;oldTime=prior.oldTime;
      }
      result.add(new Fix(f.id,f.type,f.title,f.detail,f.provider,f.url,f.sourceTime,now,f.lat,f.lon,oldLat,oldLon,oldTime));
      if(result.size()>=MAX_RECORDS)break;
    }
    JSONArray arr=new JSONArray();for(int i=0;i<result.size()&&i<MAX_RECORDS;i++)arr.put(serialize(result.get(i)));
    ctx.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
        .putString(JSON_KEY,arr.toString()).putLong("last_"+kind,now).apply();
  }
  /** Preserve source timestamps and identities from the existing live observation board. */
  public static void publishPulse(Context ctx,List<PulseDataActivity.Signal> observations){
    if(ctx==null||observations==null)return;
    for(String type:new String[]{"AIRCRAFT","EARTHQUAKE","ISS"}){
      ArrayList<Fix> list=new ArrayList<>();
      for(PulseDataActivity.Signal s:observations){
        if(!type.equals(s.kind)||!s.positioned())continue;
        list.add(new Fix(s.id,s.kind,s.title,s.detail,s.source,s.url,s.time,
            System.currentTimeMillis(),s.latitude,s.longitude,null,null,0));
      }
      if(!list.isEmpty())publishType(ctx,type,list);
    }
  }
}
