package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;
import java.util.List;
import java.util.Locale;

/**
 * 1710 source-attributed observation histogram. No synthetic reports, values or
 * forecasts: plotted dots represent RECEIVED records in equal time buckets.
 * Clicking changes the time window, never the provider snapshots or the globe.
 */
public final class Duwm1710SourceWaveView extends View {
    private static final int BUCKETS = 12;
    private static final int NAVY = DuwmUnifiedTheme.APPROVED_NAVY;
    private static final int BLUE = 0xFF6C9FE3;
    private static final int AMBER = 0xFFE3A35A;
    private final Paint ink = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path line = new Path();
    private final int[] reports = new int[BUCKETS];
    private final int[] movement = new int[BUCKETS];
    private List<Signal> lastRecords = java.util.Collections.emptyList();
    private long lastReceivedTime;
    private int windowHours = 24;
    private int accepted;
    private int skipped;

    public Duwm1710SourceWaveView(Context context) {
        super(context);
        setBackgroundColor(NAVY);
        setClickable(true);
        setContentDescription("Received source timeline. Tap to switch between 24 and 6 hours.");
    }

    /** Snapshot is supplied by World Watch's actual filtered receipts. */
    public void set1710Observations(List<Signal> records) {
        lastRecords = records == null ? java.util.Collections.emptyList() : new java.util.ArrayList<>(records);
        lastReceivedTime = System.currentTimeMillis();
        rebucket();
    }

    private void rebucket() {
        java.util.Arrays.fill(reports, 0);
        java.util.Arrays.fill(movement, 0);
        accepted = 0;
        skipped = 0;
        long now = lastReceivedTime;
        long windowMs = windowHours * 3_600_000L;
        for (Signal signal : lastRecords) {
            if (signal == null || signal.layer == null || signal.timestampMs <= 0L
                    || signal.timestampMs > now + 300_000L) { skipped++; continue; }
            long ageMs = Math.max(0L, now - signal.timestampMs);
            if (ageMs > windowMs) continue;
            int bucket = BUCKETS - 1 - (int) Math.min(BUCKETS - 1,
                    (ageMs * BUCKETS) / Math.max(1L, windowMs));
            boolean isTrack = signal.layer == Signal.Layer.FLIGHTS
                    || signal.layer == Signal.Layer.SHIPS
                    || signal.layer == Signal.Layer.SATELLITES;
            if (isTrack) movement[bucket]++;
            else reports[bucket]++;
            accepted++;
        }
        setContentDescription(String.format(Locale.US,
                "Received source timeline, %d records in last %d hours, %d records with invalid timestamps excluded. Tap to change time window.",
                accepted, windowHours, skipped));
        invalidate();
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_UP) {
            windowHours = windowHours == 24 ? 6 : 24;
            rebucket();
            performClick();
            return true;
        }
        return true;
    }
    @Override public boolean performClick() { super.performClick(); return true; }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float d = getResources().getDisplayMetrics().density;
        float w = getWidth(), h = getHeight();
        if (w < 80f || h < 45f) return;
        ink.setShader(null);
        ink.setStyle(Paint.Style.FILL);
        ink.setColor(0xFF08162E);
        canvas.drawRoundRect(0.5f*d, 0.5f*d, w-0.5f*d, h-0.5f*d, 8f*d, 8f*d, ink);
        ink.setStyle(Paint.Style.STROKE);
        ink.setStrokeWidth(Math.max(1f, 0.85f*d));
        ink.setColor(0xAA365783);
        canvas.drawRoundRect(0.5f*d, 0.5f*d, w-0.5f*d, h-0.5f*d, 8f*d, 8f*d, ink);
        ink.setStyle(Paint.Style.FILL);
        ink.setTypeface(android.graphics.Typeface.MONOSPACE);
        ink.setTextSize(9f*d);
        ink.setColor(0xFFE1ECFE);
        canvas.drawText("RECEIVED DATA / " + windowHours + "H", 10*d, 16*d, ink);
        ink.setTextSize(8f*d);
        ink.setColor(0xFF95A9C9);
        String countLabel = accepted == 0 ? "NO OBSERVATIONS IN WINDOW"
                : String.format(Locale.US,"%d RECORDS",accepted);
        canvas.drawText(countLabel, 10*d, 28*d, ink);
        float left = 11*d, right = w-12*d, top=34*d, bottom=h-17*d;
        ink.setStyle(Paint.Style.STROKE);
        ink.setStrokeWidth(0.7f*d);
        ink.setColor(0x66325483);
        for (int i=0; i<3; i++) {
            float y=top+(bottom-top)*i/2f;
            canvas.drawLine(left,y,right,y,ink);
        }
        int max=1;
        for(int i=0;i<BUCKETS;i++) max=Math.max(max,Math.max(reports[i],movement[i]));
        drawSeries(canvas,reports,AMBER,left,right,top,bottom,max,d);
        drawSeries(canvas,movement,BLUE,left,right,top,bottom,max,d);
        ink.setStyle(Paint.Style.FILL);
        ink.setTextSize(7.3f*d);
        ink.setColor(0xFF93A5C4);
        canvas.drawText(windowHours + "H AGO",left,h-5*d,ink);
        String label="NOW · REPORTS "+sum(reports)+" · TRACKS "+sum(movement);
        float width=ink.measureText(label);
        canvas.drawText(label,Math.max(left,w-width-10*d),h-5*d,ink);
    }

    private int sum(int[] values) { int total=0; for(int n:values)total+=n; return total; }

    private void drawSeries(Canvas c,int[] bins,int color,float l,float r,float t,float b,int max,float d) {
        line.reset();
        for(int i=0;i<BUCKETS;i++) {
            float x=l+(r-l)*i/(BUCKETS-1f);
            float y=b-(b-t)*(bins[i]/(float)max);
            if (i==0) line.moveTo(x,y); else line.lineTo(x,y);
        }
        ink.setStyle(Paint.Style.STROKE);
        ink.setStrokeCap(Paint.Cap.ROUND);
        ink.setStrokeJoin(Paint.Join.ROUND);
        ink.setStrokeWidth(3.5f*d);
        ink.setColor(Color.argb(35,Color.red(color),Color.green(color),Color.blue(color)));
        c.drawPath(line,ink);
        ink.setStrokeWidth(1.35f*d);
        ink.setColor(color);
        c.drawPath(line,ink);
        ink.setStyle(Paint.Style.FILL);
        for(int i=0;i<BUCKETS;i++) {
            if(bins[i]==0) continue;
            float x=l+(r-l)*i/(BUCKETS-1f);
            float y=b-(b-t)*(bins[i]/(float)max);
            ink.setColor(color);
            c.drawCircle(x,y,2f*d,ink);
        }
    }
}
