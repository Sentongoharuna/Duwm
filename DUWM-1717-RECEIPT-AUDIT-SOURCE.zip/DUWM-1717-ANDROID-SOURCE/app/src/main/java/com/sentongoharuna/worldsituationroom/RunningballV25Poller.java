package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
/** Visible-screen orchestrator for the EXISTING independent V24 async fetchers.
    Never polls in a Canvas frame; the legacy clients retain their own cooldowns. */
public final class RunningballV25Poller {
  private final Context app;private final Handler main=new Handler(Looper.getMainLooper());
  private boolean active=false;private long lastAny=0;
  private final Runnable poll=new Runnable(){@Override public void run(){
    if(!active)return;
    long now=System.currentTimeMillis();
    if(now-lastAny>=60000L){lastAny=now;dispatch();}
    main.postDelayed(this,30000L);
  }};
  public RunningballV25Poller(Context c){app=c.getApplicationContext();}
  public void start(){if(active)return;active=true;main.post(poll);}
  public void stop(){active=false;main.removeCallbacks(poll);}
  private void dispatch(){
    // Each provider is isolated; the V24 clients do their network I/O on worker threads.
    try{RunningballV16SourceRefresh.request(app,false,null);}catch(RuntimeException ignored){}
    try{RunningballV17Feeds.request(app,false,null);}catch(RuntimeException ignored){}
    try{RunningballV19SatelliteBootstrap.request(app,null);}catch(RuntimeException ignored){}
    try{RunningballV19Noaa.request(app,null);}catch(RuntimeException ignored){}
    if(RunningballWorldTarget.ready(app))try{
      Intent intent=new Intent(app,AirOperationsWidgets.Pulse.class);
      intent.setAction("com.sentongoharuna.worldsituationroom.AIR_WIDGET_REFRESH");
      intent.setPackage(app.getPackageName());app.sendBroadcast(intent);
    }catch(RuntimeException ignored){}
  }
}
