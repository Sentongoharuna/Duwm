package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** 1684: a real on-screen upgrade applied to existing native destination activities.
 * The original native content, map, stream player and data source remain the page body.
 * No additional globe, simulated feed, synthetic geolocation or alternate launcher. */
public final class Duwm1684PageUpgrade {
    private static final String TAG="duwm1684-visual-sector-header";
    private Duwm1684PageUpgrade(){}
    private static int dp(Activity a,float n){return Math.round(a.getResources().getDisplayMetrics().density*n);}
    public static void install(Application app){
        app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks(){
            @Override public void onActivityCreated(Activity a,Bundle b){}
            @Override public void onActivityStarted(Activity a){}
            @Override public void onActivityResumed(Activity a){a.getWindow().getDecorView().post(()->enhance(a));}
            @Override public void onActivityPaused(Activity a){}
            @Override public void onActivityStopped(Activity a){}
            @Override public void onActivitySaveInstanceState(Activity a,Bundle b){}
            @Override public void onActivityDestroyed(Activity a){}
        });
    }
    private static TextView label(Activity a,String s,int size,int color){
        TextView t=new TextView(a);t.setText(s);t.setTextColor(color);t.setTextSize(size);
        t.setTypeface(Typeface.create("sans-serif-medium",0));t.setGravity(Gravity.CENTER_VERTICAL);return t;
    }
    private static GradientDrawable surface(Activity a){
        GradientDrawable d=new GradientDrawable();d.setColor(DuwmUnifiedTheme.PANEL);
        d.setCornerRadius(dp(a,13));d.setStroke(dp(a,1),DuwmUnifiedTheme.BORDER);return d;
    }
    private static String shortStatus(Activity a,Duwm1683DeskCatalog.Desk d){
        Duwm1684DeskDiagnostics.Snapshot s=Duwm1684DeskDiagnostics.read(a,d);
        return s.state+"   /   SOURCE "+s.count;
    }
    private static LinearLayout makeHero(Activity a,Duwm1683DeskCatalog.Desk d){
        LinearLayout hero=new LinearLayout(a);hero.setOrientation(LinearLayout.VERTICAL);
        hero.setTag(TAG);hero.setPadding(dp(a,10),dp(a,10),dp(a,10),dp(a,10));hero.setBackground(surface(a));
        String title=d.title.toUpperCase(java.util.Locale.US);
        TextView header=label(a,"DUWM 1684   /   "+title,14,DuwmUnifiedTheme.TEXT);
        hero.addView(header,new LinearLayout.LayoutParams(-1,dp(a,26)));
        Duwm1684SectorVisual visual=new Duwm1684SectorVisual(a,d.title,false);
        hero.addView(visual,new LinearLayout.LayoutParams(-1,dp(a,112)));
        LinearLayout bottom=new LinearLayout(a);bottom.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(a,43));bp.topMargin=dp(a,8);
        hero.addView(bottom,bp);
        TextView status=label(a,shortStatus(a,d),11,DuwmUnifiedTheme.ACCENT_BRIGHT);
        status.setMaxLines(2);bottom.addView(status,new LinearLayout.LayoutParams(0,-1,1));
        TextView source=label(a,"SOURCE DETAIL  ›",11,DuwmUnifiedTheme.ACCENT_BRIGHT);
        source.setGravity(Gravity.CENTER);source.setPadding(dp(a,8),0,dp(a,8),0);
        source.setBackground(surface(a));
        source.setOnClickListener(v->Duwm1683DeskDetailKit.show(a,d));
        bottom.addView(source,new LinearLayout.LayoutParams(dp(a,121),dp(a,40)));
        return hero;
    }
    private static void enhance(Activity a){
        if(a.isFinishing() || a instanceof MainActivity || a instanceof DuwmOptionsActivity ||
           a instanceof Duwm1683DeskFullScreenActivity)return;
        Duwm1683DeskCatalog.Desk d=Duwm1683DeskCatalog.find(a);
        if(d==null)return;
        a.getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        FrameLayout content=a.findViewById(android.R.id.content);
        if(content==null || content.findViewWithTag(TAG)!=null || content.getChildCount()==0)return;
        View root=content.getChildAt(0);
        LinearLayout list=null;
        if(root instanceof ScrollView){
            ScrollView sv=(ScrollView)root;
            if(sv.getChildCount()>0 && sv.getChildAt(0) instanceof LinearLayout)list=(LinearLayout)sv.getChildAt(0);
        }else if(root instanceof LinearLayout && !(a instanceof MediaDeskActivity)){
            list=(LinearLayout)root;
        }
        if(list!=null && list.getOrientation()==LinearLayout.VERTICAL){
            LinearLayout hero=makeHero(a,d);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
            lp.bottomMargin=dp(a,14);
            list.addView(hero,0,lp);
            View redundant=content.findViewWithTag("duwm1683-detail-chip");
            if(redundant!=null)redundant.setVisibility(View.GONE);
        }else{
            // Map-only and video-first screens keep the full canvas/playback area.
            // Add a compact, dismissible source badge instead of shrinking the existing view.
            TextView badge=label(a,"1684 / "+Duwm1684SectorVisual.mode(d.title)+"   ›",11,DuwmUnifiedTheme.ACCENT_BRIGHT);
            badge.setTag(TAG);badge.setPadding(dp(a,12),0,dp(a,12),0);
            badge.setBackground(surface(a));badge.setOnClickListener(v->Duwm1683DeskDetailKit.show(a,d));
            FrameLayout.LayoutParams params=new FrameLayout.LayoutParams(-2,dp(a,41),Gravity.RIGHT|Gravity.TOP);
            params.topMargin=dp(a,10);params.rightMargin=dp(a,12);content.addView(badge,params);
        }
    }
}
