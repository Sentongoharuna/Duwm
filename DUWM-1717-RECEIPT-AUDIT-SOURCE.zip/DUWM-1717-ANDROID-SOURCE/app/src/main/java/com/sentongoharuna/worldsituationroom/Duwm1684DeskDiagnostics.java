package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** R1684: one truthful, read-only receipt interpretation shared by Options and all 19 full-screen desks.
 * Never combines unrelated provider counters or marks downloaded historical data as current.
 */
public final class Duwm1684DeskDiagnostics {
    private Duwm1684DeskDiagnostics() {}
    public static final class Snapshot {
        public final String state,count,provider,received,sourceTime,coverage,error,explanation;
        public final boolean refreshAvailable;
        Snapshot(String state,String count,String provider,String received,String sourceTime,
                 String coverage,String error,String explanation,boolean refreshAvailable) {
            this.state=state;this.count=count;this.provider=provider;this.received=received;
            this.sourceTime=sourceTime;this.coverage=coverage;this.error=error;
            this.explanation=explanation;this.refreshAvailable=refreshAvailable;
        }
        public String shortLabel(){return state+"  •  "+count+"  •  "+received;}
        public String report(){return "STATE  "+state+"\nSOURCE VALUE  "+count+"\nPROVIDER  "+provider+
          "\nLAST LOCAL RECEIPT  "+received+"\nSOURCE OBSERVATION  "+sourceTime+
          "\nCOVERAGE  "+coverage+"\nLAST ERROR  "+error+"\nINTERPRETATION  "+explanation;}
    }
    private static String utc(long ms){
        if(ms<=0)return "NOT RECEIVED";
        SimpleDateFormat f=new SimpleDateFormat("dd MMM yyyy HH:mm:ss 'UTC'",Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date(ms));
    }
    private static String age(long ms){
        if(ms<=0)return "NO RECEIPT";
        long delta=System.currentTimeMillis()-ms;
        if(delta < -60000L)return "FUTURE TIMESTAMP / CHECK CLOCK";
        long m=Math.max(0L,delta)/60000L;
        return m<1?"<1 MIN AGO":m<60?m+" MIN AGO":m<1440?m/60+" H AGO":m/1440+" D AGO";
    }
    public static Snapshot read(Context context,Duwm1683DeskCatalog.Desk d){
        if(d.source<0){
            return new Snapshot("LOCAL TOOL","NOT A LIVE FEED","DEVICE / DIRECTORY",
                "NOT APPLICABLE","NOT APPLICABLE","OPEN THE DESK TO INSPECT ITS OWN RECORDS","NONE",
                "A tool or registered website is not proof of a received source report.",false);
        }
        if(d.source==0 || d.source==2 || d.source==5){
            Duwm1674UnifiedReceipts.Receipt r=d.source==0?
              Duwm1674UnifiedReceipts.aircraft(context):d.source==2?
              Duwm1674UnifiedReceipts.maritime(context):Duwm1674UnifiedReceipts.news(context);
            String provider=d.source==0?"OpenSky":d.source==2?"Regional AIS / Open Waters":"Received publisher feeds / GDELT";
            String coverage=d.source==0?"PROVIDER-LIMITED WORLDWIDE POSITIONS":d.source==2?
                "ONLY THE SELECTED MARITIME REGION":"PUBLISHER / REGIONAL AVAILABILITY VARIES";
            String state=!r.hasReceipt()?"NO RECEIPT":r.current?"RECENT":"SAVED / AGED";
            String stamp=r.hasReceipt()?utc(r.receivedAt)+" · "+age(r.receivedAt):"NOT RECEIVED";
            return new Snapshot(state,r.count(),provider,stamp,"SEE DETAILED SOURCE RECORD",
                coverage,r.detail,"Count reflects actual returned/cached records; receipt age is not a new movement report.",true);
        }
        try{
            RunningballV25Sources.Result r=RunningballV25Sources.read(context,d.source);
            String error=r.errorReason==null||r.errorReason.isEmpty()?"NONE REPORTED":r.errorReason;
            return new Snapshot(r.status.toString().replace('_',' '),r.value==null||r.value.isEmpty()?"--":r.value,
                r.provider,utc(r.fetchedAt)+" · "+age(r.fetchedAt),utc(r.sourceTime),r.coverage,error,
                "Figures and times come from the stored provider response; older values are not labelled live.",false);
        }catch(Exception e){
            return new Snapshot("SOURCE READ FAILED","--","UNKNOWN","NOT AVAILABLE","NOT AVAILABLE",
                "CHECK SOURCE HEALTH",e.getClass().getSimpleName(),"Do not infer a zero from an unreadable response.",false);
        }
    }
    public static String shortStatus(Context c,Duwm1683DeskCatalog.Desk d){return read(c,d).shortLabel();}
    public static String fullStatus(Context c,Duwm1683DeskCatalog.Desk d){return read(c,d).report();}
}
