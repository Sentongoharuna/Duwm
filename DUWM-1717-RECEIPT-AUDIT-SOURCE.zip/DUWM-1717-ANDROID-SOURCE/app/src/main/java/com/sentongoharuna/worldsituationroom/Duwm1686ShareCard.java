package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.View;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Locale;

/** 1686 premium portrait status poster, assembled only from real device source receipts.
 * Sector image is explicitly schematic, not live media from the publisher or a real position plot. */
public final class Duwm1686ShareCard {
    private static final int W=1080,H=1920;
    private static final int BG=0xFF061824,PANEL=0xFF142A4D,WHITE=0xFFEBFAFC,ACCENT=0xFF68E4E6,MUTED=0xFFA8C8D0,LINE=0xFF285968;
    private Duwm1686ShareCard(){}
    private static final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private static void panel(Canvas c,float x,float y,float w,float h,int color){
        p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(new RectF(x,y,x+w,y+h),25,25,p);
        p.setColor(LINE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);c.drawRoundRect(new RectF(x,y,x+w,y+h),25,25,p);p.setStyle(Paint.Style.FILL);
    }
    private static void line(Canvas c,String value,float x,float y,int size,int color,boolean bold){
        p.setColor(color);p.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));p.setTextSize(size);
        c.drawText(value==null?"":value,x,y,p);
    }
    private static int paragraph(Canvas c,String text,int x,int y,int max,int size,int color,int maxLines){
        String v=text==null||text.trim().isEmpty()?"NOT REPORTED":text.trim().replace('\n',' ');
        p.setTextSize(size);p.setTypeface(Typeface.DEFAULT);
        ArrayList<String> lines=new ArrayList<>();StringBuilder curr=new StringBuilder();
        for(String part:v.split("\\s+")){
            String next=curr.length()==0?part:curr+" "+part;
            if(p.measureText(next)>max && curr.length()>0){lines.add(curr.toString());curr=new StringBuilder(part);}else curr=new StringBuilder(next);
        }
        if(curr.length()>0)lines.add(curr.toString());
        int shown=Math.min(maxLines,lines.size());
        for(int i=0;i<shown;i++){
            String txt=lines.get(i)+(i==shown-1&&lines.size()>shown?"…":"");
            line(c,txt,x,y+i*(size+12),size,color,false);
        }
        return y+shown*(size+12);
    }
    private static void field(Canvas c,String title,String content,int y,int lines){
        line(c,title,95,y,23,ACCENT,true);paragraph(c,content,95,y+43,880,30,WHITE,lines);
    }
    public static void share(Activity a,Duwm1683DeskCatalog.Desk desk){
        Bitmap bm=null;
        try{
            Duwm1685ReceiptHistory.capture(a,desk);
            Duwm1684DeskDiagnostics.Snapshot info=Duwm1684DeskDiagnostics.read(a,desk);
            bm=Bitmap.createBitmap(W,H,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(bm);c.drawColor(BG);
            p.setColor(ACCENT);c.drawRect(0,0,1080,18,p);
            panel(c,48,44,984,182,PANEL);
            try{Drawable logo=a.getDrawable(R.drawable.develop_uganda_logo);
                if(logo!=null){logo.setBounds(77,74,209,207);logo.draw(c);}}catch(Exception ignored){}
            line(c,"DEVELOP.UGANDA",233,104,37,ACCENT,true);
            line(c,"WORLD SITUATION ROOM",233,153,28,WHITE,true);
            line(c,"DUWM 1686  •  VERIFIED INTELLIGENCE",233,196,22,MUTED,false);
            line(c,"INTELLIGENCE SECTOR",74,288,26,ACCENT,true);
            paragraph(c,desk.title.toUpperCase(Locale.US),74,352,920,54,WHITE,2);
            panel(c,52,423,976,385,PANEL);
            Duwm1684SectorVisual art=new Duwm1684SectorVisual(a,desk.title,false);
            art.measure(View.MeasureSpec.makeMeasureSpec(944,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(350,View.MeasureSpec.EXACTLY));
            art.layout(0,0,944,350);c.save();c.translate(68,440);art.draw(c);c.restore();
            p.setColor(BG);c.drawRoundRect(new RectF(68,760,1010,796),6,6,p);
            line(c,"SCHEMATIC SECTOR ART  /  NOT RECEIVED POSITION DATA",82,784,19,MUTED,false);
            panel(c,53,831,975,170,PANEL);
            line(c,"01  RECEIPT STATUS",82,875,24,ACCENT,true);
            paragraph(c,info.state,82,939,420,37,WHITE,1);
            line(c,"REPORTED VALUE",578,875,24,ACCENT,true);
            paragraph(c,info.count,578,939,415,36,WHITE,1);
            panel(c,53,1023,975,380,PANEL);
            field(c,"02  RECEIVING PROVIDER",info.provider,1072,2);
            field(c,"LAST DEVICE RECEIPT (UTC)",info.received,1191,2);
            field(c,"SOURCE COVERAGE",info.coverage,1311,2);
            panel(c,53,1424,975,358,PANEL);
            line(c,"03  RECEIPT HISTORY  /  OBSERVED ONLY",81,1470,24,ACCENT,true);
            Duwm1685ReceiptChart chart=new Duwm1685ReceiptChart(a,desk);
            chart.measure(View.MeasureSpec.makeMeasureSpec(912,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(235,View.MeasureSpec.EXACTLY));
            chart.layout(0,0,912,235);c.save();c.translate(84,1493);chart.draw(c);c.restore();
            line(c,"ON-DEVICE PROVIDER RECORDS  •  NO SYNTHETIC TRENDS",81,1761,18,MUTED,false);
            line(c,"1686  /  SOURCE REFERENCE  /  "+Duwm1684SectorVisual.mode(desk.title),68,1841,22,ACCENT,true);
            line(c,"Availability and observation time vary by source.",68,1881,20,MUTED,false);
            File dir=new File(a.getCacheDir(),"share-cards");if(!dir.isDirectory()&&!dir.mkdirs())throw new Exception("Cache unavailable");
            String slug=desk.title.toLowerCase(Locale.US).replaceAll("[^a-z0-9]+","-");
            File output=new File(dir,"duwm-1686-"+slug+"-"+System.currentTimeMillis()+".png");
            try(FileOutputStream stream=new FileOutputStream(output)){if(!bm.compress(Bitmap.CompressFormat.PNG,100,stream))throw new Exception("PNG write failed");}
            Uri uri=Uri.parse("content://"+a.getPackageName()+".sharecards/"+output.getName());
            Intent intent=new Intent(Intent.ACTION_SEND);intent.setType("image/png");intent.putExtra(Intent.EXTRA_STREAM,uri);
            intent.putExtra(Intent.EXTRA_TEXT,"DUWM 1686 / "+desk.title+"\n"+info.report());
            intent.setClipData(ClipData.newUri(a.getContentResolver(),"DUWM 1686 image",uri));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            a.startActivity(Intent.createChooser(intent,"Share 1686 source image"));
        }catch(Exception e){android.widget.Toast.makeText(a,"Share unavailable: "+e.getClass().getSimpleName(),android.widget.Toast.LENGTH_LONG).show();}
        finally{if(bm!=null&&!bm.isRecycled())bm.recycle();}
    }
}
