package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** Local user-managed geographic watch areas, not a third-party tracking service. */
public final class Duwm1676WatchRegions {
    private static final String PREF="duwm1676_watch_regions",KEY="regions";
    public static final int MAX_CUSTOM=20;
    public static final class Region {
        public final String name; public final double lat,lon,radiusKm;public final boolean preset;
        Region(String name,double lat,double lon,double radius,boolean preset){
            this.name=name;this.lat=lat;this.lon=lon;this.radiusKm=radius;this.preset=preset;
        }
        @Override public String toString(){return name+"  /  "+Math.round(radiusKm)+" km";}
    }
    private Duwm1676WatchRegions(){}
    private static SharedPreferences p(Context c){return c.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    private static Region[] defaults(){return new Region[]{
        new Region("WORLD / ALL OBSERVED",0,0,20020,true),
        new Region("KAMPALA / UGANDA",0.3476,32.5825,350,true),
        new Region("STRAIT OF HORMUZ",26.55,56.45,260,true),
        new Region("SUEZ CANAL",30.00,32.55,250,true),
        new Region("SINGAPORE STRAIT",1.27,103.91,320,true),
        new Region("LONDON",51.5074,-0.1278,300,true),
        new Region("NEW YORK",40.7128,-74.0060,300,true),
        new Region("MOMBASA",-4.0435,39.6682,300,true)
    };}
    public static List<Region> read(Context c){
        ArrayList<Region> list=new ArrayList<>();for(Region r:defaults())list.add(r);
        try{JSONArray a=new JSONArray(p(c).getString(KEY,"[]"));
            for(int i=0;i<a.length()&&list.size()<MAX_CUSTOM+defaults().length;i++){
                JSONObject item=a.optJSONObject(i);if(item==null)continue;
                String name=item.optString("name","").trim();double lat=item.optDouble("lat",Double.NaN),lon=item.optDouble("lon",Double.NaN);
                double radius=item.optDouble("radius",Double.NaN);
                if(!name.isEmpty()&&name.length()<=60&&Duwm1676GeoMath.valid(lat,lon)&&
                   Double.isFinite(radius)&&radius>=10&&radius<=12000)list.add(new Region(name,lat,lon,radius,false));
            }
        }catch(Exception ignored){}
        return list;
    }
    public static boolean add(Context c,String name,double lat,double lon,double radius){
        if(name==null||name.trim().isEmpty()||name.trim().length()>60||
           !Duwm1676GeoMath.valid(lat,lon)||!Double.isFinite(radius)||radius<10||radius>12000)return false;
        JSONArray a;
        try{a=new JSONArray(p(c).getString(KEY,"[]"));}catch(Exception e){a=new JSONArray();}
        if(a.length()>=MAX_CUSTOM)return false;
        try{JSONObject item=new JSONObject();item.put("name",name.trim());item.put("lat",lat);item.put("lon",lon);item.put("radius",radius);
            a.put(item);return p(c).edit().putString(KEY,a.toString()).commit();
        }catch(Exception e){return false;}
    }
    public static boolean remove(Context c,Region region){
        if(region==null||region.preset)return false;
        JSONArray a;
        try{a=new JSONArray(p(c).getString(KEY,"[]"));}catch(Exception e){return false;}
        JSONArray updated=new JSONArray();boolean removed=false;
        for(int i=0;i<a.length();i++){
            JSONObject item=a.optJSONObject(i);if(item==null)continue;
            if(!removed&&item.optString("name").equals(region.name)&&
               Math.abs(item.optDouble("lat")-region.lat)<0.000001&&
               Math.abs(item.optDouble("lon")-region.lon)<0.000001){removed=true;continue;}
            updated.put(item);
        }
        return removed&&p(c).edit().putString(KEY,updated.toString()).commit();
    }
}
