package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.util.concurrent.atomic.AtomicBoolean;

/** Lazy 2-hour, checksum-independent bootstrap of CelesTrak's real STATIONS OMM catalogue. */
public final class RunningballV19SatelliteBootstrap {
  private static final String URL_TEXT="https://celestrak.org/NORAD/elements/gp.php?GROUP=STATIONS&FORMAT=JSON";
  private static final AtomicBoolean BUSY=new AtomicBoolean(false);
  private static final long MIN_MS=2L*3600000L;
  private RunningballV19SatelliteBootstrap(){}
  public static void request(Context context,Runnable finished){
    Context app=context.getApplicationContext();SharedPreferences p=app.getSharedPreferences("rb10_satellite",Context.MODE_PRIVATE);
    long now=System.currentTimeMillis();long last=p.getLong("data_STATIONS_time",0L);
    if(last>0&&now-last<MIN_MS){if(finished!=null)new Handler(Looper.getMainLooper()).post(finished);return;}
    if(!BUSY.compareAndSet(false,true))return;
    SharedPreferences diagnostics=app.getSharedPreferences("rb19_bootstrap",Context.MODE_PRIVATE);
    long attempted=diagnostics.getLong("sat_attempt",0L);
    if(attempted>0&&now-attempted<5L*60_000L){BUSY.set(false);return;}
    diagnostics.edit().putLong("sat_attempt",now).apply();
    new Thread(()->{
      HttpURLConnection con=null;
      try{
        con=(HttpURLConnection)new URL(URL_TEXT).openConnection();con.setConnectTimeout(8000);con.setReadTimeout(9000);
        con.setRequestProperty("Accept","application/json");con.setRequestProperty("User-Agent","RUNNINGBALL2/19 (OMM-catalogue-reader)");
        if(con.getResponseCode()!=200)throw new IllegalStateException("CELESTRAK HTTP "+con.getResponseCode());
        ByteArrayOutputStream data=new ByteArrayOutputStream();
        try(InputStream in=con.getInputStream()){
          byte[] buffer=new byte[8192];int n;
          while((n=in.read(buffer))!=-1){if(data.size()+n>500000)throw new IllegalStateException("CELESTRAK SIZE LIMIT");data.write(buffer,0,n);}
        }
        String raw=data.toString("UTF-8");JSONArray array=new JSONArray(raw);
        if(array.length()<1)throw new IllegalStateException("EMPTY OMM CATALOGUE");
        int valid=0;
        for(int i=0;i<array.length();i++){
          JSONObject j=array.optJSONObject(i);if(j==null)continue;
          if(j.optInt("NORAD_CAT_ID",0)>0&&!j.optString("OBJECT_NAME","").isEmpty()&&!j.optString("EPOCH","").isEmpty())valid++;
        }
        if(valid==0)throw new IllegalStateException("NO VALID ORBITAL RECORDS");
        p.edit().putString("data_STATIONS",raw).putLong("data_STATIONS_time",System.currentTimeMillis()).apply();
        diagnostics.edit().remove("sat_error").apply();
      }catch(Exception e){String msg=e.getMessage()==null?"ORBITAL SOURCE UNAVAILABLE":e.getMessage();
        if(msg.length()>100)msg=msg.substring(0,100);diagnostics.edit().putString("sat_error",msg).apply();
      }finally{if(con!=null)con.disconnect();BUSY.set(false);
        if(finished!=null)new Handler(Looper.getMainLooper()).post(finished);}
    },"RUNNINGBALL2-CelesTrak-Bootstrap").start();
  }
}
