package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
/** Independent native adapter: bounded genuine readings only (16 points/source; no synthetic samples). */
public final class RunningballV25Stage2History {
  private static final String STORE="rb25_stage2_history";
  private RunningballV25Stage2History(){}
  public static synchronized boolean update(Context context,int index){
    RunningballV25Sources.Result r=RunningballV25Sources.read(context,index);
    if(r.fetchedAt<=0||"--".equals(r.value))return false;
    SharedPreferences prefs=context.getApplicationContext().getSharedPreferences(STORE,Context.MODE_PRIVATE);
    String key=RunningballV25Sources.IDS[index];String lastKey=key+"_stamp";
    if(prefs.getLong(lastKey,0L)==r.fetchedAt)return false;
    // Start new history when the source's selected-region scope changes.
    String scope=key+"_scope";
    JSONArray entries=new JSONArray();
    if(r.coverage.equals(prefs.getString(scope,"")))try{entries=new JSONArray(prefs.getString(key+"_points","[]"));}catch(Exception ignored){}
    JSONArray bounded=new JSONArray();for(int i=Math.max(0,entries.length()-15);i<entries.length();i++)bounded.put(entries.opt(i));
    JSONObject sample=new JSONObject();try{
      sample.put("time",r.fetchedAt);sample.put("value",r.value);sample.put("scope",r.coverage);bounded.put(sample);
    }catch(Exception ignored){return false;}
    prefs.edit().putLong(lastKey,r.fetchedAt).putString(scope,r.coverage).putString(key+"_points",bounded.toString()).apply();
    return true;
  }
  public static JSONArray points(Context context,int index){
    String key=RunningballV25Sources.IDS[index];
    SharedPreferences prefs=context.getApplicationContext().getSharedPreferences(STORE,Context.MODE_PRIVATE);
    if(!RunningballV25Sources.read(context,index).coverage.equals(prefs.getString(key+"_scope","")))return new JSONArray();
    String raw=prefs.getString(key+"_points","[]");
    try{return new JSONArray(raw);}catch(Exception ignored){return new JSONArray();}
  }
}
