package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

/** 1686 prominent 19-desk command registry with direct full-screen dossier and live native actions. */
public final class Duwm1686CommandBoard {
    private Duwm1686CommandBoard(){}
    private static int dp(Activity a,int n){return Math.round(a.getResources().getDisplayMetrics().density*n);}
    private static TextView text(Activity a,String s,int sp,int color,boolean bold){
        TextView v=new TextView(a);v.setText(s);v.setTextColor(color);v.setTextSize(sp);
        v.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",Typeface.NORMAL));v.setGravity(Gravity.CENTER_VERTICAL);return v;
    }
    private static GradientDrawable bg(Activity a){
        GradientDrawable b=new GradientDrawable();b.setColor(DuwmUnifiedTheme.PANEL);b.setCornerRadius(dp(a,10));
        b.setStroke(dp(a,1),DuwmUnifiedTheme.BORDER);return b;
    }
    public static View create(Activity a){
        LinearLayout panel=new LinearLayout(a);panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(a,9),dp(a,10),dp(a,9),dp(a,11));panel.setBackground(bg(a));
        panel.addView(text(a,"1686  /  WORLD INTELLIGENCE COMMAND",20,DuwmUnifiedTheme.TEXT,true));
        TextView sub=text(a,"19 FULL-SCREEN WORKSPACES  •  ONE ORIGINAL GLOBE  •  HONEST SOURCE STATES",12,DuwmUnifiedTheme.ACCENT_BRIGHT,true);
        sub.setPadding(0,dp(a,5),0,dp(a,12));panel.addView(sub);
        String category="";int number=0;
        LinearLayout remaining=new LinearLayout(a);remaining.setOrientation(LinearLayout.VERTICAL);
        remaining.setVisibility(View.GONE);
        TextView expand=text(a,"SHOW ALL 19 WORKSPACES  ▾",13,DuwmUnifiedTheme.ACCENT_BRIGHT,true);
        expand.setGravity(Gravity.CENTER);expand.setPadding(dp(a,9),dp(a,11),dp(a,9),dp(a,11));
        expand.setBackground(bg(a));expand.setOnClickListener(v->{
            boolean show=remaining.getVisibility()!=View.VISIBLE;
            remaining.setVisibility(show?View.VISIBLE:View.GONE);
            expand.setText(show?"COLLAPSE DESK DIRECTORY  ▴":"SHOW ALL 19 WORKSPACES  ▾");
        });
        for(Duwm1683DeskCatalog.Desk desk:Duwm1683DeskCatalog.ALL){
            if(!desk.category.equals(category)){
                category=desk.category;
                TextView header=text(a,category.toUpperCase(Locale.US),13,DuwmUnifiedTheme.ACCENT_BRIGHT,true);
                header.setPadding(dp(a,3),dp(a,13),0,dp(a,7));(number<6?panel:remaining).addView(header);
            }
            number++;
            Duwm1684DeskDiagnostics.Snapshot s=Duwm1684DeskDiagnostics.read(a,desk);
            LinearLayout tile=new LinearLayout(a);tile.setOrientation(LinearLayout.HORIZONTAL);tile.setGravity(Gravity.CENTER_VERTICAL);
            tile.setPadding(dp(a,8),dp(a,7),dp(a,7),dp(a,7));tile.setBackground(bg(a));
            LinearLayout.LayoutParams tileLp=new LinearLayout.LayoutParams(-1,dp(a,91));tileLp.bottomMargin=dp(a,6);(number<=6?panel:remaining).addView(tile,tileLp);
            LinearLayout copy=new LinearLayout(a);copy.setOrientation(LinearLayout.VERTICAL);
            tile.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
            copy.addView(text(a,String.format(Locale.US,"%02d  %s",number,desk.title.toUpperCase(Locale.US)),13,DuwmUnifiedTheme.TEXT,true));
            TextView state=text(a,"STATE  "+s.state+"  /  "+s.count,11,DuwmUnifiedTheme.ACCENT_BRIGHT,false);
            state.setMaxLines(2);state.setPadding(0,dp(a,4),0,0);copy.addView(state);
            TextView source=text(a,s.provider,10,DuwmUnifiedTheme.MUTED,false);source.setSingleLine(true);copy.addView(source);
            LinearLayout controls=new LinearLayout(a);controls.setOrientation(LinearLayout.VERTICAL);tile.addView(controls,new LinearLayout.LayoutParams(dp(a,104),-1));
            TextView dossier=text(a,"DETAILS ›",11,DuwmUnifiedTheme.ACCENT_BRIGHT,true);
            dossier.setGravity(Gravity.CENTER);dossier.setBackground(bg(a));
            controls.addView(dossier,new LinearLayout.LayoutParams(-1,0,1));
            TextView live=text(a,"LIVE VIEW ›",11,DuwmUnifiedTheme.TEXT,true);
            live.setGravity(Gravity.CENTER);live.setBackground(bg(a));
            controls.addView(live,new LinearLayout.LayoutParams(-1,0,1));
            dossier.setOnClickListener(v->Duwm1686WorkspaceActivity.open(a,desk));
            live.setOnClickListener(v->a.startActivity(Duwm1683DeskCatalog.intent(a,desk)));
            tile.setOnClickListener(v->Duwm1686WorkspaceActivity.open(a,desk));
        }
        panel.addView(expand);panel.addView(remaining);
        TextView foot=text(a,"MAPS, STREAMS AND CURRENT TRACKS ARE SHOWN BY THE EXISTING NATIVE SOURCE PAGES. SOURCE STATES ABOVE REFLECT ONLY STORED RECEIPTS, NOT PROMISES OF LIVE COVERAGE.",11,DuwmUnifiedTheme.MUTED,false);
        foot.setPadding(dp(a,4),dp(a,10),dp(a,4),dp(a,4));panel.addView(foot);return panel;
    }
}
