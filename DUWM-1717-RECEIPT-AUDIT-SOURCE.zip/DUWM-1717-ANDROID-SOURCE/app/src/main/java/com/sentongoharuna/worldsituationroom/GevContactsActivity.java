package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.TimeZone;

/** Contacts V7: native Android implementation of God's Eye View's nearby-contact roster concept.
 * Source for aircraft observations stays ADSB.LOL via existing AirOperationsWidgets.
 * Nothing here interpolates aircraft positions or modifies RUNNINGBALL2 WallpaperService.
 */
public final class GevContactsActivity extends Activity {
    private double KLAT=0.0d,KLON=0.0d;
    private static final int BG=Color.rgb(5, 13, 34),PANEL=Color.rgb(13, 31, 61);
    private static final int INK=Color.rgb(225, 237, 255),MUTED=Color.rgb(76, 120, 196);
    private static final int CYAN=Color.rgb(85, 139, 223),GREEN=Color.rgb(85, 139, 223);
    private static final int AMBER=Color.rgb(85, 139, 223);
    private int rangeKm=250, selectedIndex=0;
    private final ArrayList<JSONObject> visible=new ArrayList<>();
    private JSONArray cached=new JSONArray();
    private TextView status,selector,detail,footer;
    private LinearLayout results;
    private EditText filter;
    private long snapshotMs;
    private String sourceError="", selectedHex="";
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean active;
    private final Runnable refreshUi=new Runnable(){@Override public void run(){
        if(!active)return;
        updateData(false);
        handler.postDelayed(this,5000L);
    }};

    private int dp(float d){return Math.round(getResources().getDisplayMetrics().density*d);}
    private static String metric(double x,String unit){return Double.isNaN(x)||Double.isInfinite(x)?"NOT REPORTED":String.format(Locale.US,"%.0f",x)+unit;}
    private TextView t(String s,int sp,int color,boolean bold){
        TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);
        if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        v.setGravity(Gravity.CENTER_VERTICAL);return v;
    }
    private GradientDrawable card(boolean selected){
        GradientDrawable d=new GradientDrawable();d.setColor(PANEL);d.setCornerRadius(dp(21));
        d.setStroke(dp(1),selected?CYAN:Color.rgb(40, 76, 135));return d;
    }
    private TextView action(String s,Runnable fn){
        TextView v=t(s,12,CYAN,true);v.setBackground(card(false));v.setGravity(Gravity.CENTER);
        v.setPadding(dp(9),dp(11),dp(9),dp(11));v.setOnClickListener(w->fn.run());return v;
    }
    private String utc(long ms){
        if(ms<=0)return "NO POSITION REPORT";
        SimpleDateFormat f=new SimpleDateFormat("HH:mm:ss 'UTC'",Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(ms));
    }
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);RunningballV17Insets.install(this);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(BG);
        LinearLayout base=new LinearLayout(this);base.setPadding(dp(15),dp(15),dp(15),dp(24));
        base.setOrientation(LinearLayout.VERTICAL);sc.addView(base);
        base.addView(t("GOD'S EYE VIEW  /  CONTACTS PORT 01",12,CYAN,true));
        TextView title=t("AIRCRAFT CONTACTS",24,INK,true);base.addView(title);
        base.addView(action("WORLD LOCATION  /  CHANGE REGION",()->startActivity(new Intent(this,RunningballWorldExplorerActivity.class))));
        status=t("LOADING OBSERVED REPORTS",12,MUTED,false);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(9);base.addView(status,sp);
        LinearLayout ranges=new LinearLayout(this);ranges.setOrientation(LinearLayout.HORIZONTAL);
        for(int k:new int[]{50,100,250}){
            TextView a=action(k+" KM",()->{rangeKm=k;selectedHex="";selectedIndex=0;updateData(true);});
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(42),1f);lp.setMargins(0,dp(12),dp(5),0);ranges.addView(a,lp);
        }
        base.addView(ranges);
        filter=new EditText(this);filter.setSingleLine(true);filter.setTextColor(INK);
        filter.setHintTextColor(MUTED);filter.setTextSize(14);filter.setHint("Search callsign or ICAO hex");
        filter.setPadding(dp(13),0,dp(13),0);filter.setBackground(card(false));
        LinearLayout.LayoutParams fl=new LinearLayout.LayoutParams(-1,dp(44));fl.topMargin=dp(12);base.addView(filter,fl);
        filter.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){rebuildList();}
            @Override public void afterTextChanged(Editable e){}
        });
        selector=t("SELECT A REPORTED CONTACT",11,CYAN,true);
        LinearLayout.LayoutParams sl=new LinearLayout.LayoutParams(-1,-2);sl.topMargin=dp(15);base.addView(selector,sl);
        results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams rl=new LinearLayout.LayoutParams(-1,-2);rl.topMargin=dp(8);base.addView(results,rl);
        detail=t("No aircraft selected",12,INK,false);detail.setPadding(dp(13),dp(13),dp(13),dp(13));detail.setBackground(card(false));
        LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(-1,-2);dl.topMargin=dp(13);base.addView(detail,dl);
        LinearLayout nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);
        String[] names={"◀ PREV","NEXT ▶","DETAILS","SHARE"};
        Runnable[] acts={()->step(-1),()->step(1),this::details,this::share};
        for(int i=0;i<names.length;i++){
            TextView v=action(names[i],acts[i]);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(45),1f);lp.setMargins(0,dp(10),dp(5),0);nav.addView(v,lp);
        }
        base.addView(nav);
        TextView cockpit=action("COCKPIT  /  TRACK SELECTED AIRCRAFT",this::openCockpit);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(46));cp.topMargin=dp(10);
        base.addView(cockpit,cp);
        TextView earth=action("EARTH EXPLORER  /  GLOBAL MAP",()->startActivity(new Intent(this,GevEarthExploreActivity.class)));
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(46));ep.topMargin=dp(8);
        base.addView(earth,ep);
        LinearLayout bottom=new LinearLayout(this);bottom.setOrientation(LinearLayout.HORIZONTAL);
        TextView refresh=action("↻ REFRESH SOURCE",this::requestRefresh);
        bottom.addView(refresh,new LinearLayout.LayoutParams(-1,dp(46)));
        LinearLayout.LayoutParams bl=new LinearLayout.LayoutParams(-1,dp(46));bl.topMargin=dp(10);base.addView(bottom,bl);
        footer=t("GEV Contacts concept • ADSB.LOL aircraft reports • No predicted movement",10,MUTED,false);
        LinearLayout.LayoutParams ftl=new LinearLayout.LayoutParams(-1,-2);ftl.topMargin=dp(14);base.addView(footer,ftl);
        setContentView(sc);updateData(true);
    }
    private void requestRefresh(){
        Intent i=new Intent(this,AirOperationsWidgets.Command.class);
        i.setAction("com.sentongoharuna.worldsituationroom.AIR_WIDGET_REFRESH");sendBroadcast(i);
        status.setText("REFRESH REQUESTED • CHECKING REPORTED DATA");
    }
    private boolean fresh(){return snapshotMs>0 && sourceError.isEmpty() && System.currentTimeMillis()-snapshotMs<=180000L;}
    private void updateData(boolean force){
        KLAT=RunningballWorldTarget.lat(this);KLON=RunningballWorldTarget.lon(this);
        JSONObject d=AirOperationsWidgets.lastData(this);
        long time=d.optLong("time",0L);
        String error=getSharedPreferences("air_widget_v2",MODE_PRIVATE).getString("last_error","");
        if(!force && time==snapshotMs && error.equals(sourceError))return;
        snapshotMs=time;sourceError=error;cached=d.optJSONArray("items");if(cached==null)cached=new JSONArray();
        String state=snapshotMs==0?"AWAITING FIRST REPORT":fresh()?"RECENT REPORT":"CACHED / STALE REPORT";
        status.setText(state+"  •  "+utc(snapshotMs)+"  •  "+d.optInt("count",0)+" REPORTED"+
                (sourceError.isEmpty()?"":"  •  "+sourceError));
        status.setTextColor(fresh()?GREEN:AMBER);rebuildList();
    }
    private void rebuildList(){
        if(results==null)return;
        String query=filter==null?"":filter.getText().toString().trim().toUpperCase(Locale.US);
        visible.clear();
        for(int i=0;i<cached.length();i++){
            JSONObject a=cached.optJSONObject(i);if(a==null)continue;
            double latitude=a.optDouble("lat",Double.NaN),longitude=a.optDouble("lon",Double.NaN);
            double km=GevGeo.km(KLAT,KLON,latitude,longitude);
            if(Double.isNaN(km)||Double.isInfinite(km)||km>rangeKm)continue;
            String key=a.optString("flight","").toUpperCase(Locale.US)+" "+a.optString("hex","").toUpperCase(Locale.US);
            if(!key.contains(query))continue;
            visible.add(a);
        }
        Collections.sort(visible,new Comparator<JSONObject>(){@Override public int compare(JSONObject a,JSONObject b){
            double x=GevGeo.km(KLAT,KLON,a.optDouble("lat",Double.NaN),a.optDouble("lon",Double.NaN));
            double y=GevGeo.km(KLAT,KLON,b.optDouble("lat",Double.NaN),b.optDouble("lon",Double.NaN));
            return Double.compare(x,y);
        }});
        selectedIndex=0;
        if(!selectedHex.isEmpty())for(int i=0;i<visible.size();i++)if(selectedHex.equals(visible.get(i).optString("hex",""))){selectedIndex=i;break;}
        if(visible.size()>0)selectedHex=visible.get(selectedIndex).optString("hex","");
        else selectedHex="";
        results.removeAllViews();
        selector.setText(""+visible.size()+" CONTACTS  •  "+rangeKm+" KM  •  "+(snapshotMs<=0?"NO SNAPSHOT":fresh()?"RECENT ROSTER":"CACHED ROSTER"));
        if(visible.isEmpty()){
            TextView none=t("NO REPORTED AIRCRAFT MATCH THIS RANGE OR SEARCH.\nCoverage varies by receiver and provider.",12,MUTED,false);
            none.setPadding(dp(10),dp(12),dp(10),dp(12));results.addView(none);
        }
        for(int i=0;i<visible.size();i++){
            final int index=i;JSONObject row=visible.get(i);
            double km=GevGeo.km(KLAT,KLON,row.optDouble("lat",Double.NaN),row.optDouble("lon",Double.NaN));
            String label=row.optString("flight",row.optString("hex","UNKNOWN"));
            if(label.isEmpty())label=row.optString("hex","UNKNOWN");
            TextView item=t(label+"  •  "+metric(km," KM")+"\n"+
                (row.optBoolean("ground",false)?"GROUND":metric(row.optDouble("alt",Double.NaN)," FT"))+
                "  •  "+metric(row.optDouble("speed",Double.NaN)," KT")+"  •  "+row.optString("hex",""),12,INK,true);
            item.setPadding(dp(12),dp(8),dp(12),dp(8));item.setBackground(card(i==selectedIndex));
            item.setOnClickListener(v->select(index));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(62));lp.bottomMargin=dp(6);results.addView(item,lp);
        }
        updateSelected();
    }
    private void select(int i){if(i<0||i>=visible.size())return;selectedIndex=i;selectedHex=visible.get(i).optString("hex","");rebuildList();}
    private void step(int d){if(visible.isEmpty())return;select((selectedIndex+d+visible.size())%visible.size());}
    private JSONObject current(){return selectedIndex>=0&&selectedIndex<visible.size()?visible.get(selectedIndex):null;}
    private void updateSelected(){
        JSONObject o=current();
        if(o==null){detail.setText("NO CONTACT SELECTED");return;}
        double km=GevGeo.km(KLAT,KLON,o.optDouble("lat",Double.NaN),o.optDouble("lon",Double.NaN));
        detail.setText(o.optString("flight",o.optString("hex","CONTACT"))+"  /  "+o.optString("hex","")+"\n"+
                metric(km," KM")+" FROM "+RunningballWorldTarget.label(this)+"  •  "+(o.optBoolean("ground",false)?"GROUND":metric(o.optDouble("alt",Double.NaN)," FT"))+"\n"+
                "SPEED "+metric(o.optDouble("speed",Double.NaN)," KT")+"  •  HEADING "+metric(o.optDouble("heading",Double.NaN),"°")+"\n"+
                (fresh()?"RECENT REPORTED POSITION":"CACHED / STALE — NOT A LIVE POSITION"));
    }
    private void openCockpit(){JSONObject o=current();if(o==null)return;
        Intent intent=new Intent(this,GevCockpitActivity.class);
        intent.putExtra("air_hex",o.optString("hex",""));startActivity(intent);
    }
    private void details(){JSONObject o=current();if(o==null)return;
        Intent i=new Intent(this,AirFlightDetailsActivity.class);i.putExtra("air_hex",o.optString("hex",""));startActivity(i);
    }
    private void share(){JSONObject o=current();if(o==null || snapshotMs<=0)return;
        double km=GevGeo.km(KLAT,KLON,o.optDouble("lat",Double.NaN),o.optDouble("lon",Double.NaN));
        LinkedHashMap<String,String> facts=new LinkedHashMap<>();
        facts.put("ICAO HEX",o.optString("hex","UNAVAILABLE"));
        facts.put("DISTANCE",metric(km," KM"));
        facts.put("BAROMETRIC ALTITUDE",o.optBoolean("ground",false)?"GROUND":metric(o.optDouble("alt",Double.NaN)," FT"));
        facts.put("GROUND SPEED",metric(o.optDouble("speed",Double.NaN)," KT"));
        facts.put("HEADING",metric(o.optDouble("heading",Double.NaN),"°"));
        facts.put("CONTACTS RANGE",rangeKm+" KM FROM "+RunningballWorldTarget.label(this));
        ShareCardRenderer.share(this,new ShareCardData(
                o.optString("flight",o.optString("hex","AIRCRAFT")),
                "Reported aircraft near selected worldwide observer; observation, not prediction.",
                fresh()?"RECENT REPORT":"CACHED / STALE",fresh()?"RECENT POSITION":"DELAYED OR CACHED",
                "AVIATION",RunningballWorldTarget.label(this),1,"ADSB.LOL","https://adsb.lol/",snapshotMs,
                o.optDouble("lat",Double.NaN),o.optDouble("lon",Double.NaN),facts,
                fresh()?CYAN:AMBER,"Public ADS-B data; not for air-traffic-control or navigation."));
    }
    @Override protected void onResume(){super.onResume();active=true;handler.removeCallbacks(refreshUi);handler.post(refreshUi);
        if(snapshotMs<=0 || System.currentTimeMillis()-snapshotMs>180000L)requestRefresh();}
    @Override protected void onPause(){active=false;handler.removeCallbacks(refreshUi);super.onPause();}
    @Override protected void onDestroy(){handler.removeCallbacks(refreshUi);super.onDestroy();}
}
