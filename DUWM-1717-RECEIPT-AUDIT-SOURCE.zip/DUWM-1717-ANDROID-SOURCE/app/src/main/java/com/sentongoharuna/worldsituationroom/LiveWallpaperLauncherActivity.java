package com.sentongoharuna.worldsituationroom;
import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
public final class LiveWallpaperLauncherActivity extends Activity {
  @Override protected void onCreate(Bundle b){
    super.onCreate(b);
    Intent i=new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
    i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,new ComponentName(this,DuwmLiveWallpaperService.class));
    try{startActivity(i);}catch(Throwable t){startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));}
    finish();
  }
}
