package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import org.json.JSONArray;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.util.Locale;
import android.util.Xml;
import org.xmlpull.v1.XmlPullParser;
import java.io.StringReader;
import java.util.concurrent.atomic.AtomicBoolean;

/** V17 public sources. No seeded numbers or demo articles; all fetches happen off UI thread. */
public final class RunningballV17Feeds {
  private static final String PREF="rb17_verified_feeds";
  private static final AtomicBoolean BUSY=new AtomicBoolean(false);
  public static final String NEWS="news", WEATHER="weather", FX="fx";
  private RunningballV17Feeds() {}
  public static SharedPreferences data(Context c){return c.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);}
  public static long received(Context c,String key){return data(c).getLong(key+"_received",0L);}
  public static long attempted(Context c,String key){return data(c).getLong(key+"_attempted",0L);}
  public static String error(Context c,String key){return data(c).getString(key+"_error","");}
  public static JSONObject cached(Context c,String key){try{return new JSONObject(data(c).getString(key+"_json","{}"));}catch(Exception e){return new JSONObject();}}
  private static boolean due(Context c,String k,long ttl){long t=attempted(c,k);return t==0||System.currentTimeMillis()-t>=ttl;}
  public static String age(long time){if(time<=0)return "NOT LOADED";long sec=Math.max(0,(System.currentTimeMillis()-time)/1000);return sec<60?sec+"s AGO":sec<3600?(sec/60)+"m AGO":(sec/3600)+"h AGO";}
  private static String read(String url,int max) throws Exception {
    if(!url.startsWith("https://"))throw new IllegalArgumentException("HTTPS REQUIRED");
    HttpURLConnection conn=null;
    try{
      conn=(HttpURLConnection)new URL(url).openConnection();
      conn.setRequestMethod("GET");conn.setConnectTimeout(6500);conn.setReadTimeout(7500);
      conn.setRequestProperty("Accept","application/json");conn.setRequestProperty("User-Agent","RUNNINGBALL2/17 (source-credited Android reader)");
      int code=conn.getResponseCode();if(code!=200)throw new IllegalStateException("PROVIDER HTTP "+code);
      ByteArrayOutputStream out=new ByteArrayOutputStream();
      try(InputStream in=conn.getInputStream()){
        byte[] buffer=new byte[8192];int n;
        while((n=in.read(buffer))!=-1){if(out.size()+n>max)throw new IllegalStateException("RESPONSE SIZE LIMIT");out.write(buffer,0,n);}
      }
      return out.toString("UTF-8");
    }finally{if(conn!=null)conn.disconnect();}
  }
  /** Public linked headlines only: no article bodies, no fabricated story counts. */
  private static JSONObject dwRss() throws Exception {
    final String url="https://rss.dw.com/xml/rss-en-all";
    HttpURLConnection conn=null;String xml;
    try {
      conn=(HttpURLConnection)new URL(url).openConnection();
      conn.setRequestMethod("GET");conn.setConnectTimeout(7000);conn.setReadTimeout(9000);
      conn.setRequestProperty("User-Agent","RUNNINGBALL2/24 (DW RSS reader; publisher links only)");
      conn.setRequestProperty("Accept","application/rss+xml,application/xml,text/xml");
      int status=conn.getResponseCode();if(status!=200)throw new IllegalStateException("DW RSS HTTP "+status);
      ByteArrayOutputStream bytes=new ByteArrayOutputStream();
      try(InputStream input=conn.getInputStream()){
        byte[] buf=new byte[8192];int n;
        while((n=input.read(buf))!=-1){if(bytes.size()+n>380000)throw new IllegalStateException("DW RSS TOO LARGE");bytes.write(buf,0,n);}
      }
      xml=bytes.toString("UTF-8");
    }finally{if(conn!=null)conn.disconnect();}
    XmlPullParser parser=Xml.newPullParser();parser.setInput(new StringReader(xml));
    JSONArray headlines=new JSONArray();boolean inItem=false;String title="",link="",date="";
    for(int event=parser.getEventType();event!=XmlPullParser.END_DOCUMENT;event=parser.next()){
      if(event==XmlPullParser.START_TAG){String tag=parser.getName();
        if("item".equalsIgnoreCase(tag)){inItem=true;title="";link="";date="";}
        else if(inItem&&"title".equalsIgnoreCase(tag))title=parser.nextText().trim();
        else if(inItem&&"link".equalsIgnoreCase(tag))link=parser.nextText().trim();
        else if(inItem&&"pubDate".equalsIgnoreCase(tag))date=parser.nextText().trim();
      }else if(event==XmlPullParser.END_TAG&&"item".equalsIgnoreCase(parser.getName())){
        if(inItem&&title.length()>=8&&link.startsWith("https://")){
          JSONObject row=new JSONObject();row.put("title",title.substring(0,Math.min(240,title.length())));
          row.put("url",link);row.put("domain","dw.com");row.put("seen",date);headlines.put(row);
        }
        inItem=false;if(headlines.length()>=12)break;
      }
    }
    if(headlines.length()==0)throw new IllegalStateException("DW RSS EMPTY OR INVALID");
    JSONObject result=new JSONObject();result.put("articles",headlines);
    result.put("provider","DEUTSCHE WELLE RSS / PUBLIC LINKED HEADLINES");return result;
  }
  private static void commit(Context c,String key,JSONObject response) {
    // Retain up to eight genuine successful provider snapshots for miniature history traces.
    try {
      String sampleId="";double value=Double.NaN;
      if(NEWS.equals(key)) {
        JSONArray a=response.optJSONArray("articles");value=a==null?Double.NaN:a.length();
        sampleId=a!=null&&a.length()>0?a.optJSONObject(0).optString("url",""):"";
      } else if(WEATHER.equals(key)) {
        value=response.optDouble("temperature",Double.NaN);
        sampleId=response.optString("region","")+":"+response.optString("time","");
      } else if(FX.equals(key)) {
        JSONObject rates=response.optJSONObject("rates");value=rates==null?Double.NaN:rates.optDouble("EUR",Double.NaN);
        sampleId=response.optString("date","");
      }
      if(Double.isFinite(value)&&!sampleId.isEmpty()) {
        JSONArray previous=new JSONArray(data(c).getString(key+"_history","[]"));
        boolean duplicate=false;
        if(previous.length()>0)duplicate=sampleId.equals(previous.optJSONObject(previous.length()-1).optString("id",""));
        if(!duplicate) {
          JSONArray next=new JSONArray();for(int i=Math.max(0,previous.length()-7);i<previous.length();i++)next.put(previous.getJSONObject(i));
          JSONObject point=new JSONObject();point.put("id",sampleId);point.put("value",value);
          point.put("received",System.currentTimeMillis());next.put(point);
          data(c).edit().putString(key+"_history",next.toString()).apply();
        }
      }
    }catch(Exception ignored){} // History decoration must never block primary verified data.
    data(c).edit().putString(key+"_json",response.toString())
      .putLong(key+"_received",System.currentTimeMillis()).putString(key+"_error","").apply();
  }
  private static void failure(Context c,String key,Exception e){
    String msg=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
    if(msg.length()>100)msg=msg.substring(0,100);
    data(c).edit().putString(key+"_error",msg).apply(); // Keep old verified snapshot, with original timestamp.
  }
  private static void fetch(Context c,String key) {
    long now=System.currentTimeMillis();data(c).edit().putLong(key+"_attempted",now).apply();
    try {
      if(NEWS.equals(key)) {
        try {
        // GDELT DOC provides sourced article metadata, not verified truth of article claims.
        String raw=read("https://api.gdeltproject.org/api/v2/doc/doc?query=world%20OR%20technology%20OR%20aviation%20OR%20economy%20OR%20business%20OR%20energy%20OR%20weather&mode=artlist&format=json&maxrecords=30&timespan=24h",480000);
        JSONObject source=new JSONObject(raw);JSONArray items=source.optJSONArray("articles");
        if(items==null)throw new IllegalStateException("NO ARTICLE LIST");
        JSONArray clean=new JSONArray();
        for(int i=0;i<items.length()&&clean.length()<30;i++) {
          JSONObject a=items.optJSONObject(i);if(a==null)continue;
          String title=a.optString("title","").trim(),link=a.optString("url","").trim();
          if(title.length()<8||!link.startsWith("https://"))continue;
          JSONObject entry=new JSONObject();entry.put("title",title.length()>240?title.substring(0,240):title);
          entry.put("url",link);entry.put("domain",a.optString("domain",""));
          entry.put("seen",a.optString("seendate",""));clean.put(entry);
        }
        if(clean.length()==0)throw new IllegalStateException("NO VALID ARTICLES");
        JSONObject result=new JSONObject();result.put("articles",clean);result.put("provider","GDELT DOC 2.0");commit(c,key,result);
        data(c).edit().remove("news_primary_error").apply();
        }catch(Exception primary){
          String warning=primary.getMessage()==null?"GDELT UNAVAILABLE":primary.getMessage();
          data(c).edit().putString("news_primary_error",warning.substring(0,Math.min(90,warning.length()))).apply();
          // A valid public publisher RSS feed is a backup, not a claim that GDELT worked.
          JSONObject rss=dwRss();commit(c,key,rss);
        }
      } else if(WEATHER.equals(key)) {
        if(!RunningballWorldTarget.ready(c))return;
        double lat=RunningballWorldTarget.lat(c),lon=RunningballWorldTarget.lon(c);
        String region=String.format(Locale.US,"%.4f,%.4f",lat,lon);
        String api=String.format(Locale.US,"https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f&current=temperature_2m,wind_speed_10m,precipitation,weather_code&timezone=UTC",lat,lon);
        JSONObject response=new JSONObject(read(api,150000));
        JSONObject current=response.optJSONObject("current");
        if(current==null||!current.has("temperature_2m")||!current.has("time"))throw new IllegalStateException("WEATHER FIELDS MISSING");
        JSONObject result=new JSONObject();result.put("provider","Open-Meteo model-derived");result.put("region",region);
        result.put("time",current.optString("time",""));result.put("temperature",current.optDouble("temperature_2m",Double.NaN));
        result.put("wind",current.optDouble("wind_speed_10m",Double.NaN));result.put("precipitation",current.optDouble("precipitation",Double.NaN));
        result.put("code",current.optInt("weather_code",-1));commit(c,key,result);
      } else if(FX.equals(key)) {
        JSONObject response=new JSONObject(read("https://api.frankfurter.dev/v1/latest?base=USD&symbols=EUR,GBP,JPY",100000));
        JSONObject rates=response.optJSONObject("rates");
        if(rates==null||!rates.has("EUR")||!rates.has("GBP")||!rates.has("JPY"))throw new IllegalStateException("FX QUOTES MISSING");
        JSONObject result=new JSONObject();result.put("provider","Frankfurter / official reference rates");
        result.put("date",response.optString("date",""));result.put("base","USD");result.put("rates",rates);commit(c,key,result);
      }
    }catch(Exception e){failure(c,key,e);}
  }
  public static void request(Context c,boolean manual,Runnable onFinished){
    Context app=c.getApplicationContext();if(!BUSY.compareAndSet(false,true))return;
    new Thread(()->{
      try {
        if(manual||due(app,NEWS,30L*60000L))fetch(app,NEWS);
        // Do not keep sending one location's weather after the user changes region.
        if(RunningballWorldTarget.ready(app)){
          String region=String.format(Locale.US,"%.4f,%.4f",RunningballWorldTarget.lat(app),RunningballWorldTarget.lon(app));
          if(!region.equals(cached(app,WEATHER).optString("region",""))||manual||due(app,WEATHER,15L*60000L))fetch(app,WEATHER);
        }
        if(manual||due(app,FX,6L*3600000L))fetch(app,FX);
      }finally{BUSY.set(false);if(onFinished!=null)new Handler(Looper.getMainLooper()).post(onFinished);}
    },"RB17-sourced-feeds").start();
  }
}
