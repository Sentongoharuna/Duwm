package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** 1691 data-first rework of the pre-existing desk visual. Does NOT create a globe,
 * synthetic radar dots, simulated traffic or invented time-series. A trend is drawn
 * only when at least TWO separate numeric provider receipt timestamps exist. */
public final class Duwm1687OpsVisual extends View {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Duwm1683DeskCatalog.Desk desk;
    private final float den;
    private Duwm1684DeskDiagnostics.Snapshot snap;
    private List<Duwm1685ReceiptHistory.Point> history=new ArrayList<>();
    private long lastRead=0L;
    public Duwm1687OpsVisual(Context c,Duwm1683DeskCatalog.Desk d){super(c);desk=d;den=getResources().getDisplayMetrics().density;refresh();}
    private float dp(float x){return x*den;}
    private void ink(int color){p.setStyle(Paint.Style.FILL);p.setColor(color);}
    private void word(Canvas c,String t,float x,float y,int pt,int color,boolean bold,float allowed){
        ink(color);p.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",0));p.setTextSize(dp(pt));
        String s=t==null?"":t;while(s.length()>3&&p.measureText(s)>allowed)s=s.substring(0,s.length()-2)+"…";
        c.drawText(s,x,y,p);
    }
    private void refresh(){snap=Duwm1684DeskDiagnostics.read(getContext(),desk);history=Duwm1685ReceiptHistory.read(getContext(),desk);
        lastRead=SystemClock.uptimeMillis();setContentDescription("Provider "+snap.provider+". State "+snap.state+". Received "+snap.count+". "+history.size()+" distinct local receipts.");}
    @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();if(w<dp(190)||h<dp(135))return;
        if(SystemClock.uptimeMillis()-lastRead>15000)refresh();
        ink(0xFF0A2533);c.drawRoundRect(new RectF(0,0,w,h),dp(14),dp(14),p);
        ink(0xFF55D0D2);c.drawRoundRect(new RectF(dp(12),dp(14),dp(16),h-dp(14)),dp(2),dp(2),p);
        float x=dp(29),right=w-dp(16),space=right-x;
        word(c,desk.title.toUpperCase(Locale.US),x,dp(28),13,0xFFE5F8F8,true,space);
        word(c,"REAL SOURCE STATUS  /  "+snap.provider,x,dp(48),10,0xFF98C0CB,false,space);
        word(c,snap.state.toUpperCase(Locale.US),x,dp(84),22,0xFF6CE1DD,true,space);
        word(c,"REPORTED VALUE  "+snap.count,x,dp(108),11,0xFFE2F2F5,true,space);
        float gy=dp(126),bottom=h-dp(30),left=x,gw=space;
        int n=0;double lo=Double.POSITIVE_INFINITY,hi=Double.NEGATIVE_INFINITY;
        long firstTime=Long.MAX_VALUE,lastTime=Long.MIN_VALUE;
        for(Duwm1685ReceiptHistory.Point point:history){if(point.numerical){n++;lo=Math.min(lo,point.value);hi=Math.max(hi,point.value);
                firstTime=Math.min(firstTime,point.sourceAt);lastTime=Math.max(lastTime,point.sourceAt);}}
        if(n>=2 && lastTime>firstTime && bottom>gy+dp(10)){
            Path path=new Path();int seen=0;
            for(Duwm1685ReceiptHistory.Point point:history){if(!point.numerical)continue;
                float px=left+gw*((point.sourceAt-firstTime)/(float)(lastTime-firstTime));
                float py=hi>lo?bottom-(float)((point.value-lo)/(hi-lo))*(bottom-gy):(gy+bottom)*0.5f;if(seen==0)path.moveTo(px,py);else path.lineTo(px,py);seen++;}
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2.3f));p.setColor(0xFF65E4CE);c.drawPath(path,p);p.setStyle(Paint.Style.FILL);
        }else{word(c,n==0?"NO NUMERIC RECEIPTS TO GRAPH":"AWAITING 2 DISTINCT NUMERIC RECEIPTS",x,Math.max(gy+dp(14),h-dp(33)),10,0xFF99BFC7,false,space);}
        word(c,history.size()+" LOCAL RECEIPTS   /   SOURCE TIME ONLY",x,h-dp(13),9,0xFF91B8C3,false,space);
        if(isShown()&&isAttachedToWindow())postInvalidateDelayed(15000L);
    }
}
