package com.sentongoharuna.worldsituationroom;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.regex.Pattern;
/** Read-only cache provider: supports Android sharing with temporary URI permissions. */
public final class V11593SourceCardProvider extends ContentProvider {
 private static final Pattern SAFE=Pattern.compile("card-[a-f0-9]{24}\\.png");
 @Override public boolean onCreate(){return true;}
 @Override public String getType(Uri uri){return "image/png";}
 @Override public Cursor query(Uri uri,String[] columns,String filter,String[] args,String sort){return null;}
 @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException();}
 @Override public int update(Uri uri,ContentValues values,String filter,String[] args){throw new UnsupportedOperationException();}
 @Override public int delete(Uri uri,String filter,String[] args){throw new UnsupportedOperationException();}
 @Override public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException{
  if(!"r".equals(mode)||uri==null||getContext()==null)throw new FileNotFoundException("Read only");
  if(!("content".equals(uri.getScheme()))||!(getContext().getPackageName()+".v11593sourcecards").equals(uri.getAuthority()))throw new FileNotFoundException("Wrong authority");
  if(uri.getPathSegments().size()!=2||!"cards".equals(uri.getPathSegments().get(0)))throw new FileNotFoundException("Invalid path");
  String name=uri.getPathSegments().get(1);
  if(!SAFE.matcher(name).matches())throw new FileNotFoundException("Invalid name");
  File file=new File(new File(getContext().getCacheDir(),"sharecards"),name);
  if(!file.isFile())throw new FileNotFoundException("Not found");
  return ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY);
 }
}
