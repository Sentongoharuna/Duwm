package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;
import java.util.List;

/** Event bars reflect genuine cached timestamps grouped into 6-hour UTC-relative bins. */
public final class Duwm1671EventBars extends View {
  private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
  private int[] bins=new int[4];private int count=0;
  public Duwm1671EventBars(Context c){super(c);setContentDescription("Actual received event count grouped into previous 24 hours");}
  public void setEvents(List<DuwmGeoObservationStore.Fix> fixes,long now){bins=new int[4];count=0;
    if(fixes!=null)for(DuwmGeoObservationStore.Fix f:fixes){long age=now-f.sourceTime;
      if(age<0||age>=86400000L)continue;int group=(int)(age/21600000L);bins[3-group]++;count++;}invalidate();}
  private float dp(float v){return v*getResources().getDisplayMetrics().density;}
  @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();c.drawColor(0xFF1B3763);
    p.setColor(0xFF558BDF);p.setTextSize(dp(12));c.drawText("SOURCE-OBSERVED EVENTS / PREVIOUS 24 HOURS",dp(12),dp(22),p);
    if(count==0){p.setColor(0xFFBAC7CA);c.drawText("NO TIMESTAMPED EVENTS IN LOCAL CACHE",dp(12),h*.6f,p);return;}
    int max=1;for(int n:bins)max=Math.max(max,n);
    float left=dp(14),bottom=h-dp(32),top=dp(48),slot=(w-dp(28))/4f;
    for(int i=0;i<4;i++){float bar=(bottom-top)*bins[i]/max,x=left+i*slot+dp(10);
      p.setColor(0xFF558BDF);c.drawRoundRect(x,bottom-bar,x+slot-dp(20),bottom,dp(5),dp(5),p);
      p.setColor(0xFFD7E6E9);p.setTextSize(dp(10));c.drawText(String.valueOf(bins[i]),x,bottom-bar-dp(6),p);
      String label=(18-i*6)+"–"+(24-i*6)+"h";c.drawText(label,x,bottom+dp(17),p);
    }
  }
}
