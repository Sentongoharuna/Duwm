package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Real on-device receipt history. A NEW provider timestamp is required to add a point.
 * This is not a historical external API, synthetic trend or live location feed. */
public final class Duwm1685ReceiptHistory {
    private Duwm1685ReceiptHistory(){}
    private static final String PREFS="duwm_1685_verified_receipts";
    private static final int LIMIT=16;
    public static final class Point {
        public final long sourceAt;
        public final double value;
        public final boolean numerical;
        Point(long sourceAt,double value,boolean numerical){
            this.sourceAt=sourceAt;this.value=value;this.numerical=numerical;
        }
    }
    private static String key(Duwm1683DeskCatalog.Desk d){
        return d.title.toLowerCase(Locale.US).replaceAll("[^a-z0-9]+","_");
    }
    public static synchronized void capture(Context c,Duwm1683DeskCatalog.Desk d){
        if(d==null||d.source<0)return; // local tool != provider history
        long timestamp=0L;
        String value=null;
        try{
            if(d.source==0||d.source==2||d.source==5){
                Duwm1674UnifiedReceipts.Receipt receipt=d.source==0?
                        Duwm1674UnifiedReceipts.aircraft(c):d.source==2?
                        Duwm1674UnifiedReceipts.maritime(c):Duwm1674UnifiedReceipts.news(c);
                timestamp=receipt.receivedAt;value=receipt.count();
            }else{
                RunningballV25Sources.Result r=RunningballV25Sources.read(c,d.source);
                timestamp=r.fetchedAt;value=r.value;
            }
        }catch(Exception ignored){return;}
        long now=System.currentTimeMillis();
        if(timestamp<946684800000L||timestamp>now+60000L)return;
        List<Point> entries=read(c,d);
        for(Point p:entries)if(p.sourceAt==timestamp)return;
        if(!entries.isEmpty() && timestamp<entries.get(entries.size()-1).sourceAt)return;
        double num=Double.NaN;
        if(value!=null){
            String clean=value.trim().replace(",","");
            if(clean.matches("[+-]?[0-9]+(?:\\.[0-9]+)?")){
                try{num=Double.parseDouble(clean);}catch(Exception ignored){}
            }
        }
        if(Double.isInfinite(num))num=Double.NaN;
        entries.add(new Point(timestamp,Double.isNaN(num)?0.0:num,!Double.isNaN(num)));
        while(entries.size()>LIMIT)entries.remove(0);
        StringBuilder sb=new StringBuilder();
        for(Point p:entries){
            if(sb.length()>0)sb.append(';');
            sb.append(p.sourceAt).append(',').append(p.numerical?Double.toString(p.value):"-");
        }
        c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString(key(d),sb.toString()).apply();
    }
    public static synchronized List<Point> read(Context c,Duwm1683DeskCatalog.Desk d){
        ArrayList<Point> out=new ArrayList<>();
        if(d==null||d.source<0)return out;
        SharedPreferences prefs=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
        for(String token:prefs.getString(key(d),"").split(";")){
            if(token.isEmpty())continue;
            String[] fields=token.split(",",-1);
            if(fields.length!=2)continue;
            try{
                long at=Long.parseLong(fields[0]);
                if(at<946684800000L)continue;
                boolean numeric=!"-".equals(fields[1]);
                double n=numeric?Double.parseDouble(fields[1]):0;
                if(Double.isNaN(n)||Double.isInfinite(n))continue;
                out.add(new Point(at,n,numeric));
            }catch(Exception ignored){}
        }
        return out;
    }
    public static String label(Context c,Duwm1683DeskCatalog.Desk d){
        if(d.source<0)return "LOCAL TOOL / NO PROVIDER TIME SERIES";
        int count=read(c,d).size();
        if(count==0)return "NO DISTINCT SOURCE RECEIPTS YET";
        return count+" DISTINCT RECEIVED SNAPSHOT"+(count==1?"":"S")+" SAVED ON THIS PHONE";
    }
}
