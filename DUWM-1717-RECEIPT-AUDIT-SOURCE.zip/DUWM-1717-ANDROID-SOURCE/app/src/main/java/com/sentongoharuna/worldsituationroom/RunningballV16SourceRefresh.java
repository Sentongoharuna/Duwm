package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.atomic.AtomicBoolean;

/** Public global data; fetch cadence and truth state live independently of animation. */
public final class RunningballV16SourceRefresh {
  private static final String PREF="rb_global_public_events";
  private static final long MIN_FETCH_MS=600000L; // ten minutes; no rapid polling
  private static final int MAX_BYTES=1600000;
  private static final AtomicBoolean BUSY=new AtomicBoolean(false);
  private static final String[][] FEEDS={
    {"quakes","https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson"},
    {"nasa","https://eonet.gsfc.nasa.gov/api/v3/events?status=open&limit=65"}
  };
  private RunningballV16SourceRefresh(){}
  public static void request(Context context, boolean force, Runnable whenDone){
    final Context app=context.getApplicationContext();
    final SharedPreferences pref=app.getSharedPreferences(PREF,Context.MODE_PRIVATE);
    final long now=System.currentTimeMillis();
    boolean due=false;
    for(String[] feed:FEEDS){
      long attempted=pref.getLong(feed[0]+"_v16_attempt",0L);
      if((force || attempted<=0L || now-attempted>MIN_FETCH_MS) && !BUSY.get())due=true;
    }
    if(!due)return;
    if(!BUSY.compareAndSet(false,true))return;
    new Thread(()->{
      try{
        for(String[] entry:FEEDS){
          String kind=entry[0];
          long attempted=pref.getLong(kind+"_v16_attempt",0L);
          if(!force && attempted>0L && System.currentTimeMillis()-attempted<MIN_FETCH_MS)continue;
          pref.edit().putLong(kind+"_v16_attempt",System.currentTimeMillis()).apply();
          HttpURLConnection conn=null;
          try{
            conn=(HttpURLConnection)new URL(entry[1]).openConnection();
            conn.setConnectTimeout(8000);conn.setReadTimeout(9000);
            conn.setRequestProperty("User-Agent","RUNNINGBALL2-World-Command/1.0 (public-event-feed)");
            if(conn.getResponseCode()!=200)throw new IllegalStateException("HTTP "+conn.getResponseCode());
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            InputStream input=conn.getInputStream();
            try{
              byte[] b=new byte[8192];int count;
              while((count=input.read(b))!=-1){
                if(bytes.size()+count>MAX_BYTES)throw new IllegalStateException("response limit reached");
                bytes.write(b,0,count);
              }
            }finally{input.close();}
            String json=bytes.toString("UTF-8");
            JSONObject doc=new JSONObject(json);
            String expected="quakes".equals(kind)?"features":"events";
            if(doc.optJSONArray(expected)==null)throw new IllegalArgumentException("Missing "+expected+" array");
            SharedPreferences.Editor saved=pref.edit().putString(kind+"_raw",json)
              .putLong(kind+"_time",System.currentTimeMillis()).remove(kind+"_v16_error");
            if("nasa".equals(kind))saved.putString("nasa_coverage","UP TO 65 EVENTS / PROVIDER-LIMITED");
            saved.apply();
          }catch(Exception e){
            // If NASA's full open-event response fails, retry a bounded smaller set.
            // Never turn a failure into a fake zero. The successful response is cached
            // with its actual receipt time and the reduced coverage is labelled.
            if("nasa".equals(kind)){
              HttpURLConnection retry=null;
              try{
                retry=(HttpURLConnection)new URL("https://eonet.gsfc.nasa.gov/api/v3/events?status=open&limit=20").openConnection();
                retry.setConnectTimeout(7000);retry.setReadTimeout(9000);
                retry.setRequestProperty("User-Agent","RUNNINGBALL2-World-Command/24 (EONET bounded retry)");
                if(retry.getResponseCode()!=200)throw new IllegalStateException("EONET RETRY HTTP "+retry.getResponseCode());
                ByteArrayOutputStream bytes=new ByteArrayOutputStream();
                try(InputStream input=retry.getInputStream()){
                  byte[] buf=new byte[8192];int n;
                  while((n=input.read(buf))!=-1){if(bytes.size()+n>MAX_BYTES)throw new IllegalStateException("EONET RETRY SIZE LIMIT");bytes.write(buf,0,n);}
                }
                String json=bytes.toString("UTF-8");
                JSONObject document=new JSONObject(json);
                if(document.optJSONArray("events")==null)throw new IllegalStateException("EONET RETRY INVALID EVENTS");
                pref.edit().putString("nasa_raw",json).putLong("nasa_time",System.currentTimeMillis())
                  .putString("nasa_coverage","UP TO 20 EVENTS / REDUCED RESULT LIMIT")
                  .remove("nasa_v16_error").apply();
                continue;
              }catch(Exception retryFailure){
                // Preserve prior true snapshot and both actual provider failures.
                e=new IllegalStateException("PRIMARY: "+e.getClass().getSimpleName()+" / RETRY: "+retryFailure.getClass().getSimpleName());
              }finally{if(retry!=null)retry.disconnect();}
            }
            String message=e.getMessage()==null?"SOURCE ERROR":e.getMessage();
            if(message.length()>95)message=message.substring(0,95);
            pref.edit().putString(kind+"_v16_error",message).apply();
            // Retain old cache, never falsify its original timestamp.
          }finally{if(conn!=null)conn.disconnect();}
        }
      }finally{
        BUSY.set(false);
        if(whenDone!=null)new Handler(Looper.getMainLooper()).post(whenDone);
      }
    },"RB16-global-source-refresh").start();
  }
}
