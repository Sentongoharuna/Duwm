package com.sentongoharuna.worldsituationroom;
import android.app.Activity;
import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
/** Safe Android status/navigation bars for V17 and selected protected modules. */
public final class RunningballV17Insets {
  private RunningballV17Insets(){}
  public static void install(Activity a){
    View content=a.findViewById(android.R.id.content);
    if(content==null)return;
    content.setOnApplyWindowInsetsListener((v,insets)->{
      int top,bottom;
      if(Build.VERSION.SDK_INT>=30){android.graphics.Insets b=insets.getInsets(WindowInsets.Type.systemBars());top=b.top;bottom=b.bottom;}
      else {top=insets.getSystemWindowInsetTop();bottom=insets.getSystemWindowInsetBottom();}
      if(v.getPaddingTop()!=top||v.getPaddingBottom()!=bottom){
        v.setPadding(v.getPaddingLeft(),top,v.getPaddingRight(),bottom);
      }
      return insets;
    });
    content.requestApplyInsets();
  }
}
