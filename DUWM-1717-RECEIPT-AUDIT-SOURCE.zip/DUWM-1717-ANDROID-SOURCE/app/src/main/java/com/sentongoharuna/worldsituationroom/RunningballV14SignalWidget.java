package com.sentongoharuna.worldsituationroom;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Native home-screen widget. Data comes from already stored source reports. */
public final class RunningballV14SignalWidget extends AppWidgetProvider {
  public static final String ACTION_REFRESH="com.sentongoharuna.worldsituationroom.RB14_REFRESH_WIDGET";
  private static PendingIntent open(Context c,Class<?> cls,int widgetId,int offset){
    Intent intent=new Intent(c,cls);
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
    return PendingIntent.getActivity(c,widgetId*10+offset,intent,
        PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  }
  private static PendingIntent refresh(Context c,int widgetId){
    Intent i=new Intent(c,RunningballV14SignalWidget.class);
    i.setAction(ACTION_REFRESH);
    i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,widgetId);
    return PendingIntent.getBroadcast(c,widgetId*10+9,i,
        PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  }
  private static String line(String[] data,int i,String missing){
    return data.length>i?data[i]:missing;
  }
  private static void update(Context c,AppWidgetManager manager,int id){
    RemoteViews r=new RemoteViews(c.getPackageName(),R.layout.rb14_global_signals_widget);
    // The same cache snapshot is shown inside the V13/V14 Global Signals page.
    String[] lines=RunningballV13SignalsActivity.summary(c).split("\\n",-1);
    r.setTextViewText(R.id.rb14_title,"GLOBAL SIGNALS  /  V15");
    r.setTextViewText(R.id.rb14_air_line,line(lines,0,"AIR -- · NO DATA"));
    r.setTextViewText(R.id.rb14_sat_line,line(lines,1,"SAT -- · NOT LOADED"));
    r.setTextViewText(R.id.rb14_sea_line,line(lines,2,"SEA -- · NO AIS FEED"));
    SimpleDateFormat fmt=new SimpleDateFormat("dd MMM HH:mm 'UTC'",Locale.US);
    fmt.setTimeZone(TimeZone.getTimeZone("UTC"));
    r.setTextViewText(R.id.rb14_footer,"CACHED DISPLAY · RECHECKED "+fmt.format(new Date()));
    r.setOnClickPendingIntent(R.id.rb14_air_line,open(c,AirRadarActivity.class,id,1));
    r.setOnClickPendingIntent(R.id.rb14_sat_line,open(c,GevSatelliteActivity.class,id,2));
    r.setOnClickPendingIntent(R.id.rb14_sea_line,open(c,GevMarineActivity.class,id,3));
    r.setOnClickPendingIntent(R.id.rb14_title,open(c,RunningballV13SignalsActivity.class,id,4));
    r.setOnClickPendingIntent(R.id.rb14_footer,open(c,RunningballV13SignalsActivity.class,id,5));
    r.setOnClickPendingIntent(R.id.rb14_refresh,refresh(c,id));
    manager.updateAppWidget(id,r);
  }
  public static void updateAll(Context c){
    AppWidgetManager manager=AppWidgetManager.getInstance(c);
    int[] ids=manager.getAppWidgetIds(new ComponentName(c,RunningballV14SignalWidget.class));
    for(int id:ids)update(c,manager,id);
  }
  @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){
    for(int id:ids)update(c,m,id);
  }
  @Override public void onReceive(Context c,Intent i){
    super.onReceive(c,i);
    if(ACTION_REFRESH.equals(i.getAction()))updateAll(c);
  }
}
