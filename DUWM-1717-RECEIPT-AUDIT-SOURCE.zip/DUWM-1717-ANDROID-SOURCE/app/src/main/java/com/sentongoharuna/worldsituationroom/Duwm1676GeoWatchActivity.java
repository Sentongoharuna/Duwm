package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * DUWM 1676: user-defined geographic watch regions over device-cached REAL source fixes.
 * A scan does not assert a new provider receipt. No background location or geofence permissions.
 */
public final class Duwm1676GeoWatchActivity extends Activity {
    private static final int BG=0xFF041424, CARD=0xFF0E2240, BORDER=0xFF284C87;
    private static final int TEXT=0xFFDCE9FD, MUTED=0xFFBECBE0, AQUA=0xFF558BDF, GOLD=0xFF558BDF;
    private static final String[] KINDS={"ALL OBSERVATIONS","AIRCRAFT","VESSEL","EARTHQUAKE","ISS"};
    private static final int MAP_MAX=350, LIST_MAX=45;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private boolean visible=false;
    private int scanSerial=0;
    private Spinner regionsSpinner,kindSpinner;
    private List<Duwm1676WatchRegions.Region> regions=new ArrayList<>();
    private TextView status,counts,selection;
    private LinearLayout results;
    private OperationsGlobeView globe;
    private List<Match> lastMatches=new ArrayList<>();
    private String lastRegion="";
    private final Runnable autoScan=new Runnable(){@Override public void run(){
        if(!visible)return;
        scan(); // local cache inspection only: never requests third-party API each minute.
        handler.postDelayed(this,60000L);
    }};
    private static final class Match {
        final String type,title,detail,provider;final double lat,lon;final long sourceTime;
        Match(String type,String title,String detail,String provider,double lat,double lon,long sourceTime){
            this.type=type;this.title=title;this.detail=detail;this.provider=provider;
            this.lat=lat;this.lon=lon;this.sourceTime=sourceTime;
        }
        int markerType(){return "AIRCRAFT".equals(type)?OperationsGlobeView.AIR:
                "VESSEL".equals(type)?OperationsGlobeView.SEA:
                "EARTHQUAKE".equals(type)?OperationsGlobeView.QUAKE:OperationsGlobeView.SPACE;}
    }
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private GradientDrawable panel(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);
        d.setStroke(dp(1),BORDER);d.setCornerRadius(dp(11));return d;}
    private TextView text(String str,int sp,int color,boolean bold){TextView v=new TextView(this);v.setText(str);
        v.setTextColor(color);v.setTextSize(sp);v.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));return v;}
    private TextView button(String label,Runnable onClick){TextView v=text(label,12,AQUA,true);
        v.setGravity(Gravity.CENTER);v.setPadding(dp(8),dp(11),dp(8),dp(11));v.setBackground(panel(CARD));
        v.setOnClickListener(w->onClick.run());return v;}
    private void pair(LinearLayout parent,TextView first,TextView second){
        LinearLayout row=new LinearLayout(this);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(8);parent.addView(row,p);
        row.addView(first,new LinearLayout.LayoutParams(0,dp(49),1));
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(0,dp(49),1);pp.leftMargin=dp(8);row.addView(second,pp);
    }
    @Override public void onCreate(Bundle state){super.onCreate(state);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);setContentView(scroll);
        Duwm1167SafeArea.install(this,scroll);
        LinearLayout root=new LinearLayout(this);root.setPadding(dp(15),dp(14),dp(15),dp(32));root.setOrientation(LinearLayout.VERTICAL);scroll.addView(root);
        root.addView(text("DUWM  /  LOCATION-BASED OBSERVATIONS",12,AQUA,true));
        root.addView(text("GEOGRAPHIC WATCHLIST  /  1676",22,TEXT,true));
        TextView note=text("Watch any saved region using aircraft, AIS vessel, earthquake and ISS fixes actually received by this phone. Offline scans never invent positions or contact a provider.",12,MUTED,false);
        note.setPadding(0,dp(10),0,dp(11));root.addView(note);
        pair(root,button("‹  MISSION CONTROL",this::finish),button("SOURCE EVIDENCE VAULT",()->startActivity(new Intent(this,Duwm1675EvidenceVaultActivity.class))));
        root.addView(text("SELECT A REGION",12,GOLD,true));
        regionsSpinner=new Spinner(this);regionsSpinner.setBackground(panel(CARD));root.addView(regionsSpinner,new LinearLayout.LayoutParams(-1,dp(52)));
        kindSpinner=new Spinner(this);ArrayAdapter<String> ka=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,KINDS);
        ka.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);kindSpinner.setAdapter(ka);
        kindSpinner.setBackground(panel(CARD));LinearLayout.LayoutParams kp=new LinearLayout.LayoutParams(-1,dp(50));kp.topMargin=dp(8);root.addView(kindSpinner,kp);
        pair(root,button("+ SAVE CUSTOM REGION",this::addCustomRegion),button("REMOVE CUSTOM REGION",this::removeRegion));
        status=text("READING SAVED PROVIDER OBSERVATIONS",13,GOLD,true);status.setPadding(0,dp(12),0,dp(7));root.addView(status);
        counts=text("NO SCAN YET",14,TEXT,true);counts.setPadding(dp(12),dp(12),dp(12),dp(12));counts.setBackground(panel(CARD));root.addView(counts);
        globe=new OperationsGlobeView(this);globe.setCompassRingEnabled(true);globe.setGlobePalette(true);
        FrameLayout map=new FrameLayout(this);map.setBackground(panel(CARD));
        LinearLayout.LayoutParams mapParams=new LinearLayout.LayoutParams(-1,dp(290));mapParams.topMargin=dp(10);root.addView(map,mapParams);
        map.addView(globe,new FrameLayout.LayoutParams(-1,-1));
        globe.setOnObservationSelected(o->{if(o!=null)showObservation(o);});
        selection=text("TAP A RECEIVED MAP MARKER TO VIEW AND SHARE SOURCE DETAILS",11,MUTED,false);
        selection.setPadding(dp(12),dp(11),dp(12),dp(11));root.addView(selection);
        pair(root,button("SCAN DEVICE CACHE",this::scan),button("REQUEST SOURCE UPDATES",this::refreshSources));
        pair(root,button("SHARE REGION SUMMARY",this::shareSummary),button("OPEN LIVE AIRCRAFT MAP",()->startActivity(new Intent(this,Duwm1670FlightMapActivity.class))));
        TextView caveat=text("OBSERVATION AGE LIMITS  /  AIR 6 H • VESSEL 48 H • ISS 6 H • QUAKE 30 DAYS. Older data and records lacking trustworthy coordinates or timestamps are excluded.",11,MUTED,false);
        caveat.setPadding(0,dp(16),0,dp(12));root.addView(caveat);
        root.addView(text("MATCHING REAL OBSERVATIONS",15,TEXT,true));
        results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);root.addView(results);
        AdapterView.OnItemSelectedListener change=new AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(AdapterView<?> parent,View v,int pos,long id){scan();}
            @Override public void onNothingSelected(AdapterView<?> parent){}
        };
        kindSpinner.setOnItemSelectedListener(change);
        regionsSpinner.setOnItemSelectedListener(change);
        reloadRegions(1);
    }
    private void reloadRegions(int desired){
        regions=Duwm1676WatchRegions.read(this);
        ArrayAdapter<Duwm1676WatchRegions.Region> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,regions);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);regionsSpinner.setAdapter(a);
        regionsSpinner.setSelection(Math.max(0,Math.min(desired,regions.size()-1)));
    }
    private Duwm1676WatchRegions.Region currentRegion(){
        int at=regionsSpinner==null?0:regionsSpinner.getSelectedItemPosition();
        if(at<0||at>=regions.size())return null;return regions.get(at);
    }
    private String selectedKind(){int at=kindSpinner==null?0:kindSpinner.getSelectedItemPosition();return at<=0?"":KINDS[at];}
    private void scan(){
        final Duwm1676WatchRegions.Region region=currentRegion();if(region==null||results==null)return;
        final String kind=selectedKind();final int serial=++scanSerial;
        status.setText("SCANNING RECEIVED POSITION CACHES  /  NO SIMULATED DATA");
        executor.execute(()->{
            final List<Match> found=collect(region,kind);
            handler.post(()->{if(serial!=scanSerial||isFinishing())return;showScan(region,kind,found);});
        });
    }
    private void addIfInside(List<Match> out,Duwm1676WatchRegions.Region r,String kindFilter,
                             String type,String title,String detail,String provider,double lat,double lon,long when,long maxAge,long now){
        if(!kindFilter.isEmpty()&&!kindFilter.equals(type))return;
        if(!Duwm1676GeoMath.inside(r.lat,r.lon,r.radiusKm,lat,lon))return;
        if(!Duwm1676GeoMath.acceptableTime(when,now,maxAge))return;
        out.add(new Match(type,title,detail,provider,lat,lon,when));
    }
    private List<Match> collect(Duwm1676WatchRegions.Region region,String kindFilter){
        ArrayList<Match> out=new ArrayList<>();long now=System.currentTimeMillis();
        if(kindFilter.isEmpty()||"AIRCRAFT".equals(kindFilter)){
            RunningballV25GlobalAircraftData.Snapshot s=RunningballV25GlobalAircraftData.read(this);
            if(s.hasGood()&&s.ageMs()<6L*3600000L){
                for(int i=0;i<s.points.length();i++){
                    JSONArray row=s.points.optJSONArray(i);if(row==null)continue;
                    double lat=row.optDouble(0,Double.NaN),lon=row.optDouble(1,Double.NaN);
                    long time=Duwm1674TimeGuard.normalize(row.isNull(7)?s.sourceAt:row.optLong(7));
                    String ident=row.optString(3,row.optString(2,"UNKNOWN AIRCRAFT"));
                    addIfInside(out,region,kindFilter,"AIRCRAFT",ident,"OpenSky received state vector", "OpenSky",lat,lon,time,6L*3600000L,now);
                }
            }
        }
        if(kindFilter.isEmpty()||"VESSEL".equals(kindFilter)){
            SharedPreferences pref=getSharedPreferences("rb11_marine",MODE_PRIVATE);
            try{JSONObject payload=new JSONObject(pref.getString("rows","{}"));JSONArray rows=payload.optJSONArray("rows");
                if(rows!=null)for(int i=0;i<rows.length();i++){
                    JSONObject row=rows.optJSONObject(i);if(row==null)continue;
                    double lat=row.optDouble("lat",Double.NaN),lon=row.optDouble("lon",Double.NaN);
                    String mmsi=row.optString("mmsi","");if(!GevMarineMath.validMmsi(mmsi))continue;
                    long time=Duwm1674TimeGuard.normalize(GevMarineActivity.timestamp(row));
                    String title=row.optString("name","");if(title.isEmpty())title="MMSI "+mmsi;
                    addIfInside(out,region,kindFilter,"VESSEL",title,"Reported AIS / MMSI "+mmsi,
                        payload.optString("source","REGIONAL AIS"),lat,lon,time,48L*3600000L,now);
                }
            }catch(Exception ignored){}
        }
        if(kindFilter.isEmpty()||"EARTHQUAKE".equals(kindFilter)||"ISS".equals(kindFilter)){
            for(DuwmGeoObservationStore.Fix f:DuwmGeoObservationStore.read(this)){
                if(!"EARTHQUAKE".equals(f.type)&&!"ISS".equals(f.type))continue;
                long limit="ISS".equals(f.type)?6L*3600000L:30L*86400000L;
                long time=Duwm1674TimeGuard.normalize(f.sourceTime);
                addIfInside(out,region,kindFilter,f.type,f.title,f.detail,f.provider,f.lat,f.lon,time,limit,now);
            }
        }
        Collections.sort(out,Comparator.comparingLong((Match m)->m.sourceTime).reversed());
        return out;
    }
    private void showScan(Duwm1676WatchRegions.Region region,String kind,List<Match> found){
        lastMatches=found;lastRegion=region.name;
        int air=0,sea=0,quake=0,iss=0;
        for(Match m:found){switch(m.type){case "AIRCRAFT":air++;break;case "VESSEL":sea++;break;case "EARTHQUAKE":quake++;break;case "ISS":iss++;break;default:break;}}
        counts.setText(region.name+"  •  "+Math.round(region.radiusKm)+" KM RADIUS\n"+
            found.size()+" ACTUAL OBSERVATIONS IN REGION\nAIR "+air+"  /  AIS "+sea+"  /  QUAKE "+quake+"  /  ISS "+iss);
        status.setText("SCAN COMPLETE  •  CACHE ONLY  •  "+new java.text.SimpleDateFormat("HH:mm:ss",Locale.US).format(new java.util.Date()));
        ArrayList<OperationsGlobeView.Observation> markers=new ArrayList<>();
        int step=Math.max(1,(found.size()+MAP_MAX-1)/MAP_MAX);
        for(int i=0;i<found.size()&&markers.size()<MAP_MAX;i+=step){Match m=found.get(i);
            markers.add(new OperationsGlobeView.Observation(m.markerType(),m.lat,m.lon,m.title,m.detail,m.provider,m.sourceTime));}
        globe.setObservations(markers);globe.focusAt(region.lat,region.lon);globe.pause();
        results.removeAllViews();
        if(found.isEmpty()){
            TextView none=text("No qualifying cached positions were found in this radius. This does not mean the region is empty in reality. Tap REQUEST SOURCE UPDATES, choose a wider region or inspect the provider source-health screen.",13,MUTED,false);
            none.setPadding(dp(11),dp(15),dp(11),dp(15));results.addView(none);return;
        }
        TextView visibleCount=text("SHOWING "+Math.min(found.size(),LIST_MAX)+" OF "+found.size()+" MATCHES / MAP MARKERS "+markers.size(),11,GOLD,false);
        visibleCount.setPadding(0,dp(12),0,dp(5));results.addView(visibleCount);
        for(int i=0;i<found.size()&&i<LIST_MAX;i++){
            Match match=found.get(i);
            String title=match.type+"  /  "+match.title;
            TextView card=text(title+"\n"+match.provider+"  •  "+Duwm1674TimeGuard.utc(match.sourceTime)+
                "\n"+String.format(Locale.US,"%.4f, %.4f",match.lat,match.lon)+"  •  TAP FOR DETAILS / SHARE",12,TEXT,false);
            card.setPadding(dp(11),dp(12),dp(11),dp(12));card.setBackground(panel(CARD));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(7);results.addView(card,cp);
            card.setOnClickListener(v->{globe.focusAt(match.lat,match.lon);new AlertDialog.Builder(this)
                .setTitle(title).setMessage(match.detail+"\nSOURCE: "+match.provider+"\nOBSERVED: "+
                    Duwm1674TimeGuard.utc(match.sourceTime)+"\nLOCATION: "+String.format(Locale.US,"%.5f, %.5f",match.lat,match.lon))
                .setPositiveButton("SHARE CARD",(d,w)->shareMatch(match))
                .setNegativeButton("CLOSE",null).show();});
        }
    }
    private void showObservation(OperationsGlobeView.Observation o){
        selection.setText(o.title+"  /  "+o.source+"  /  "+Duwm1674TimeGuard.utc(o.timeMillis));
        new AlertDialog.Builder(this).setTitle(o.title).setMessage(o.detail+"\n"+o.source+"\n"+Duwm1674TimeGuard.utc(o.timeMillis))
            .setPositiveButton("SHARE CARD",(d,w)->V115941ShareCards.share(this,
                o.type==OperationsGlobeView.AIR?"AIRCRAFT":o.type==OperationsGlobeView.SEA?"VESSEL":
                o.type==OperationsGlobeView.QUAKE?"EARTHQUAKE":"ISS",o.title,o.detail,o.source,
                o.timeMillis,o.lat,o.lon,"",null)).setNegativeButton("CLOSE",null).show();
    }
    private void shareMatch(Match m){V115941ShareCards.share(this,m.type,m.title,m.detail,m.provider,
        m.sourceTime,m.lat,m.lon,"",null);}
    private void shareSummary(){
        Duwm1676WatchRegions.Region region=currentRegion();if(region==null)return;
        StringBuilder report=new StringBuilder(region.name+"  /  "+Math.round(region.radiusKm)+" km radius\n"+lastMatches.size()+
            " device-cached observed positions matching the selected source and time filters.\n");
        for(int i=0;i<Math.min(lastMatches.size(),10);i++){
            Match m=lastMatches.get(i);report.append(m.type).append(" ").append(m.title).append(" • ")
                .append(Duwm1674TimeGuard.utc(m.sourceTime)).append(" • ").append(m.provider).append('\n');
        }
        Duwm1671Share.share(this,"REGION WATCH","DUWM 1676 / "+region.name,report.toString(),
            "Device-cached observations; local scan, not an independent real-time provider update","",System.currentTimeMillis());
    }
    private void refreshSources(){
        status.setText("REQUESTING ELIGIBLE AIRCRAFT AND REGIONAL AIS SOURCES • PROVIDER QUOTAS APPLY");
        RunningballV25GlobalAircraftData.refreshNow(this,()->{if(visible)scan();});
        Duwm1674MaritimeRefresh.refresh(this,()->{if(visible)scan();});
    }
    private EditText field(String label,int type,LinearLayout parent){
        EditText input=new EditText(this);input.setHint(label);input.setTextColor(TEXT);input.setHintTextColor(MUTED);
        input.setInputType(type);input.setTextSize(14);parent.addView(input,new LinearLayout.LayoutParams(-1,dp(49)));return input;
    }
    private void addCustomRegion(){
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(14),dp(7),dp(14),dp(6));
        EditText name=field("Region name",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS,form);
        int number=InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED;
        EditText lat=field("Latitude (−90 to 90)",number,form);
        EditText lon=field("Longitude (−180 to 180)",number,form);
        EditText radius=field("Radius in km (10 to 12000)",number,form);
        new AlertDialog.Builder(this).setTitle("SAVE NEW WATCH REGION")
            .setMessage("Only the named location and radius are saved. No background tracking is enabled.")
            .setView(form).setPositiveButton("SAVE",(d,w)->{
                try{double a=Double.parseDouble(lat.getText().toString()),b=Double.parseDouble(lon.getText().toString()),
                    r=Double.parseDouble(radius.getText().toString());
                    if(!Duwm1676WatchRegions.add(this,name.getText().toString(),a,b,r)){
                        Toast.makeText(this,"Invalid region or limit of 20 custom regions reached",Toast.LENGTH_LONG).show();return;}
                    reloadRegions(Duwm1676WatchRegions.read(this).size()-1);
                    Toast.makeText(this,"Region saved on device",Toast.LENGTH_SHORT).show();
                }catch(Exception e){Toast.makeText(this,"Enter a valid name, coordinates and radius",Toast.LENGTH_LONG).show();}
            }).setNegativeButton("CANCEL",null).show();
    }
    private void removeRegion(){Duwm1676WatchRegions.Region r=currentRegion();
        if(r==null||r.preset){Toast.makeText(this,"Select a saved custom region to remove",Toast.LENGTH_SHORT).show();return;}
        new AlertDialog.Builder(this).setTitle("REMOVE "+r.name).setMessage("Remove this locally saved region?")
            .setPositiveButton("REMOVE",(d,w)->{if(Duwm1676WatchRegions.remove(this,r))reloadRegions(1);})
            .setNegativeButton("CANCEL",null).show();
    }
    @Override protected void onResume(){super.onResume();visible=true;handler.removeCallbacks(autoScan);handler.post(autoScan);}
    @Override protected void onPause(){visible=false;handler.removeCallbacks(autoScan);if(globe!=null)globe.pause();super.onPause();}
    @Override protected void onDestroy(){scanSerial++;executor.shutdownNow();handler.removeCallbacks(autoScan);super.onDestroy();}
}
