package com.sentongoharuna.worldsituationroom;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Validates that a provider observation can be presented as a contemporary report.
 * Never rewrites a historical timestamp as today or manufactures a position. */
public final class Duwm1674TimeGuard {
    private static final long FIRST_CONTEMPORARY_MS = 1577836800000L; // Jan 1, 2020 UTC
    private static final long FUTURE_TOLERANCE_MS = 300000L;
    private Duwm1674TimeGuard() {}
    public static long normalize(long raw) {
        if (raw <= 0L) return 0L;
        long milliseconds = raw < 100000000000L ? raw * 1000L : raw;
        long now = System.currentTimeMillis();
        return milliseconds >= FIRST_CONTEMPORARY_MS && milliseconds <= now + FUTURE_TOLERANCE_MS
                ? milliseconds : 0L;
    }
    public static boolean recent(long raw,long maximumAgeMs) {
        long time = normalize(raw);
        return time > 0L && System.currentTimeMillis() - time <= maximumAgeMs;
    }
    public static String utc(long raw) {
        long time = normalize(raw);
        if (time == 0L) return "INVALID / HISTORICAL SOURCE DATE — NOT LIVE";
        SimpleDateFormat fmt=new SimpleDateFormat("dd MMM yyyy HH:mm:ss 'UTC'", Locale.US);
        fmt.setTimeZone(TimeZone.getTimeZone("UTC"));
        return fmt.format(new Date(time));
    }
}
