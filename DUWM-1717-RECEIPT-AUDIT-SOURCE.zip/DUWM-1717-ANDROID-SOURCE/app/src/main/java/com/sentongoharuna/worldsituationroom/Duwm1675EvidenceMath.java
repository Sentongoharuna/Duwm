package com.sentongoharuna.worldsituationroom;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Pure-Java formatting helpers for verified receipt audit; no Android or network state. */
public final class Duwm1675EvidenceMath {
    private Duwm1675EvidenceMath() {}
    public static String utc(long timestamp) {
        if (timestamp <= 0L) return "NOT PROVIDED";
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date(timestamp));
    }
    public static String csv(String input) {
        String s = input == null ? "" : input.replace("\r", " ").replace("\n", " ");
        if (!s.isEmpty() && "=+-@".indexOf(s.charAt(0)) >= 0) s = "'" + s;
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }
    public static String delta(String prior, String current) {
        if (prior == null || current == null) return "";
        if (!prior.matches("[0-9]{1,15}") || !current.matches("[0-9]{1,15}")) return "";
        try {
            long a = Long.parseLong(prior), b = Long.parseLong(current);
            long difference = b - a;
            return difference > 0 ? "+" + difference : String.valueOf(difference);
        } catch (NumberFormatException ignored) { return ""; }
    }
}
