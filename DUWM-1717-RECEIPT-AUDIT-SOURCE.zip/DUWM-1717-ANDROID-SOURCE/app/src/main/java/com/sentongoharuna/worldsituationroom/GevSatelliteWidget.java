package com.sentongoharuna.worldsituationroom;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONArray;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** A premium dark vertical widget. Counts catalogue records, NOT live detections. */
public final class GevSatelliteWidget extends AppWidgetProvider {
    @Override public void onUpdate(Context context,AppWidgetManager manager,int[] ids){for(int id:ids)paint(context,manager,id);}
    public static void updateAll(Context context){AppWidgetManager manager=AppWidgetManager.getInstance(context);
        int[] ids=manager.getAppWidgetIds(new ComponentName(context,GevSatelliteWidget.class));
        for(int id:ids)paint(context,manager,id);
    }
    private static void paint(Context c,AppWidgetManager m,int id){
        RemoteViews r=new RemoteViews(c.getPackageName(),R.layout.rb10_satellite_widget);
        String raw=c.getSharedPreferences("rb10_satellite",Context.MODE_PRIVATE).getString("data_STATIONS","[]");
        int count=0;try{count=new JSONArray(raw).length();}catch(Exception ignored){}
        long timestamp=c.getSharedPreferences("rb10_satellite",Context.MODE_PRIVATE).getLong("data_STATIONS_time",0L);
        r.setTextViewText(R.id.rb10_sat_count,count>0?String.valueOf(count):"--");
        r.setTextViewText(R.id.rb10_sat_status,count>0?"ORBITAL RECORDS":"NO CATALOGUE");
        if(timestamp>0L){SimpleDateFormat fmt=new SimpleDateFormat("dd MMM HH:mm 'UTC'",Locale.US);
            fmt.setTimeZone(TimeZone.getTimeZone("UTC"));r.setTextViewText(R.id.rb10_sat_footer,"SOURCE "+fmt.format(new Date(timestamp)));
        }else r.setTextViewText(R.id.rb10_sat_footer,"OPEN TO LOAD ORBITS");
        Intent i=new Intent(c,GevSatelliteActivity.class);
        PendingIntent p=PendingIntent.getActivity(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        r.setOnClickPendingIntent(R.id.rb10_sat_root,p);
        m.updateAppWidget(id,r);
    }
}
