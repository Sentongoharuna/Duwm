# DUWM 1694 — source package (APK build required)

Parent: **DUWM-1693-REAL-NATIVE-PAGES-SOURCE.zip**
SHA-256: `4adade73a43e0df4e704626595a23a8cba5361fc3da4e25f1c4990ca7e25e317`

This archive contains the complete 1694 native Android project rather than a patch to an older ZIP.

Changes applied to the 1693 source:
- Fix the confirmed `GevMarineActivity.java:142` Android compiler error by referencing the outer activity method.
- Add aircraft reported-speed 400+ km/h filter, maritime AIS 10+ knots filter, news publication six-hour filter and radio station A–Z sorting.
- Add source-health navigation in existing native activity headers, copy actual receipt-chart counts on long-press and direct diagnostics from the existing 19-desk workspace.
- Correct Android launcher label, version name and version code to 1694 / 169400.
- Preserve the original globe engine and existing 19 desk destinations.

Source integrity and Java syntax parsing passed locally. **No APK compilation, live-provider validation or device playback was confirmed during packaging.** The companion workflow compiles and verifies an installable APK when run in GitHub Actions.
