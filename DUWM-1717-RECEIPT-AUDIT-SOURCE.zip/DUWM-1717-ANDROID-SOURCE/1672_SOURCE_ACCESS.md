# DUWM 1672: Access and Verification Boundaries

- Public AIS: optional key-free Open Waters regional GeoJSON snapshots. Anonymous requests have geographical and rate limits and access is not necessarily authorized for a commercial product. Review https://openwaters.io/api/ais/ before distributing the APK. A configured HTTPS AIS gateway remains optional.
- Vessel movement: map sprites interpolate only between two timestamped AIS positions from the same MMSI. The interpolated sprite is NOT a fresh provider observation, forecast, or navigation position. The source observation timestamp remains visible.
- Aviation: OpenSky `/states/all` cannot supply commercial route destinations or scheduled ETA. Explicit refresh removes a fixed local 15-minute button gate but respects HTTP 429 and a 30-second duplicate-tap interval. Global request frequency must fit the provider's quota.
- Worldwide 200-source listings are discovery candidates, not working connections. Third-party TV streams, camera streams, news photos and AIS data must be checked for service conditions and playback rights before commercial use.
- Hard limits protecting mobile memory, UI responsiveness, network security, and honest data reporting remain in place; the app cannot override laws, third-party service quotas, missing provider coverage or device capabilities.
- Local Python/Node source checks cannot verify APK compilation, internet connectivity, installability or actual phone performance. The supplied GitHub workflow validates a compiled APK and signature when it completes successfully.
