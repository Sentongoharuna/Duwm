# DUWM 1699 — Native operational improvements (unreleased candidate)

Parent source: DUWM-1698-NATIVE-OPERATIONAL-SOURCE.zip
SHA-256: `637c23b81c7dd1c63f2bb5c88eb1a2c589474d05f8bf76274d97796c5472bc87`

Changes made in original native Android pages:

- Aircraft: three actual altitude filters below 10,000 feet, above 30,000 feet, or all; filter output/count reflects true received barometric altitude, with no synthetic positions.
- Maritime: stopped, underway, fast, or all AIS speed bands; same predicate filters the real sea map markers and vessel register, so no discrepancy.
- News: optional deduplication by actual publisher link; a suppressed-link count is displayed, and users may turn it off.
- Radio: full-world, matching received stations, and selected source-coordinate map focus; changing region stops an old broadcast.
- Radio/TV/Cameras media directory: source order, A–Z, or publisher-image-first order from actual listed images; in-app playback retained.
- Fixed remaining visible 1698 captions in main app, mission board, specialist map, source health, native media and full-screen desks.
- Original globe, globe size, 36 dp edge tabs and unchanged rendering/view engines.

Source audit: 16 original Java files modified, 239 Java files total.

Not verified: Android APK compilation, emulator pages, actual streaming or on-device touch behaviour. Do not release until GitHub builds and tests an APK.
