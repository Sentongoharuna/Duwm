# DUWM 1692 — Verified native operations

Base: exact 1691 source archive. The original single globe and live media engines are retained.

Changes in existing pages:
- Flight register: on-device airborne and five-minute contact filters, actual matching totals.
- Maritime: only one map visible by default, optional port radar, geographic region changes invalidate previous data and request new AIS observations.
- News: publisher selection restricted to actually received source names, in addition to text, region, date, bookmark and sort filters.
- Radio: focused map extent derived from actual geotagged received stations and working 36-row list pagination.
- Media: focus player toggle hides the directory while showing the in-app player at a larger size.
- Source Health: search and share actual device diagnostics, with NO synthetic source states.
- All 19 desks: real numeric last-two-receipt differences and shareable text receipt, preserving existing tabs and native open functions.
- Mission board: remembers selected category and has a functional filter reset.

Verifications are static/syntax only until Android compilation, signature, and on-device behavior are confirmed.
- Original main globe dock: removed seven duplicate shortcuts to already-present destinations.
- Specialist map: optional 24h/72h source receipt window using actual locally cached observations.
- Original source-data metrics: tap once to switch between 2×2 actual counts and four horizontal relative bars; no new data is generated.
