# DUWM 1705 — World Watch situation pulse and evidence triage

Actual Java source upgrade from 1704; **not a version-only rename**.

- Full-width, clickable native pulse counts for real incident, air, sea and weather receipts in World Watch; no synthetic data. Counts reflect received geolocated signals under currently active source lens/time/priority options; a category may be counted in more than one facet if applicable.
- Actual provider-reported region selector, built from current signal.region values. No geocoder or inferred geography.
- Evidence triage: ALL, exact HTTPS publisher link, provider-labelled CONFIRMED, RAW/UNVERIFIED, and local-monitor records. Provider credibility is shown as supplied, not independently established.
- Every report card and provenance receipt exposes source-link status, UTC, coordinates, declared region and provider credibility.
- Search, category and sort filters, 1702 globe lenses, 1703 World Watch, 1704 source cards and Report Cam navigation retained; one original globe; 19 desk routes unchanged.

Validation: source contract and Java syntax parser only. Actual Gradle APK/emulator runtime verification must occur on GitHub Actions before describing the APK as verified.

## 1705 Live Original Globe Restoration (same version; no cosmetic bump)
- Restores original ALL markers on first run after upgrade, retains user choice thereafter.
- Native dual constantly moving lower/upper source tickers rendered from received provider signals and UTC timestamps (never synthetic headlines).
- Original single orthographic globe has brighter category-coloured provider-status arcs, animated rim lights activated only by actual source callbacks/counts, and illuminated lines joining successive received flight/vessel fixes (only where history exists, freshness bounded).
- No second globe, fictitious position, fabricated link, altered main globe viewport or changes to the 1704-1705 World Watch feature set.
- GitHub build must still pass real APK compilation, signing and emulator launch to be considered green.
