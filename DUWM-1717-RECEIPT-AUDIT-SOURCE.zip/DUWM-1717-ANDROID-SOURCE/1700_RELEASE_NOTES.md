# DUWM 1700 — actual source upgrade candidate

Parent: exact DUWM-1699-ORIGINAL-GLOBE-SOURCE.zip. Never older 1678.

- Aircraft: locate latest filtered genuine OpenSky position on original globe.
- Maritime: focus latest matching AIS report on existing map, avoiding false tracking.
- News: open most recently published matching HTTPS source article inside app.
- Radio: previous/next filtered received station in the SAME native player.
- TV/Radio/Cameras Media: previous/next source in precisely the displayed ordering and filters.
- Evidence bars across desks: explicit zero-receipt state; tappable cards/rank view; no simulated detection.
- Mission board and all 19 desk workspaces: show source provider and actual receipt time clearly.
- Full-sized original globe and 36dp side tabs remain byte-for-byte unchanged.

Not a released APK until GitHub Android compile, signed APK, identity checks and emulator tests pass.
