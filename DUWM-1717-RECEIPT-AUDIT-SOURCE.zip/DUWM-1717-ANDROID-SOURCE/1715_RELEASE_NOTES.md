# DUWM 1715 — Unified Formal Navy + Build Pipeline Repair

## Direct changes in the Android APK source
- Keeps exactly one original command-center `SatelliteMapView`. No new globes, wallpapers, simulated source records or alternative dashboard shells.
- All Activity text widgets use the same professional sans-serif family on resume; app theme uses sans for new native views. System bars use approved midnight navy (#050D22) app-wide. Graphics, maps, video streams and the ticker renderer are not replaced.
- Approved common surfaces: background #050D22, cards #07162C, focused panels #122545; thin muted 19-sector identifying keylines. Card background function now honors selection instead of ignoring the requested fill.
- Removes non-data decorative thumbnail illustrations from the 19-desk directory; genuine source receipt charts continue to appear for applicable desks.
- Adjusts the shared bottom dock height from 76dp to 84dp to prevent clipping a 20dp status line plus a 48dp control rail and padding. The rail remains below native desk content, never on top of the globe.
- 19-sector matrix, source receipt comparison, persisted watchlist, news, aircraft, ships, radio, TV, cameras and original signal ticker remain part of the project.
- Version code 171500 / version 1715.

## Corrected build diagnostics
- The 1714 APK compiled, passed signed APK verification, and was uploaded to GitHub Actions.
- The 1714 workflow was marked failed only during Android emulator setup: downloading `system-images;android-35;google_apis;x86_64` returned `Error on ZipFile unknown archive` before launching the app. It was a runner SDK archive problem, not a demonstrated Java compilation failure.
- 1715 publishes its compiled, signed APK from the required build job independently from optional emulator setup. Emulator verification is explicitly labelled separately. A successful compile is **not** called a successful emulator launch.
- APK verification checks label/version/signature/compiled classes and source integrity; 19 desk catalog test and UI theme assertions prevent false version-only builds.
