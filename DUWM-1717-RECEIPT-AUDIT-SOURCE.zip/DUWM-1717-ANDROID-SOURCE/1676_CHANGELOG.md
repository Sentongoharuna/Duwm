# DUWM 1676 — Geographic Watchlist

This is a new functional feature, not a rename of the prior globe/dashboard proposals.

- New main-dashboard shortcut and new Geographic Watchlist page.
- User can select worldwide preset regions or save up to 20 custom areas with name, latitude, longitude and radius.
- The page scans the actual OpenSky aircraft-position cache, received AIS rows and stored USGS/ISS position fixes.
- The page filters by observed geographical location and source, shows a localized globe, source-provided timestamps, count, record details and share cards.
- Local cache scan every 60 seconds, with a separate manual provider-refresh control (provider quotas still apply).
- The code explicitly rejects missing/historical/future times and invalid coordinates, and does not create fake positions.
- Previous 1675 Source Evidence Vault and media/source desks remain available.

Tested locally: Java syntax parsing; pure Java distance/antimeridian/staleness tests; release source checks.
Not yet independently verified: on-phone visual behavior and GitHub APK build status.
