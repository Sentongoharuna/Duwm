# DUWM 1696 FIX2 — KEEP ORIGINAL GLOBE SIZE

This is a layout-only correction of the existing 1696 FIX1 project. The native SatelliteMapView.java is unmodified, including original globe radius, centre, motion, input handling, and zoom semantics. MainActivity keeps the same full-frame globe viewport and the same top/bottom map margins.

On screens below 1150 dp wide, two 36 dp translucent edge tabs replace the previously visible 90 dp/103 dp live panels. These taps open the existing source/counter/observation information on demand. AIR, SEA and FIX counts are computed from the same received signals and observations as before; missing observations are not invented. CLEAR/RAILS toggles only the compact tabs, never globe zoom or radius. On exceptionally wide devices the existing full information rails remain available in the outside space.

The single globe and all 19 destinations stay in the original app. A GitHub Android build plus emulator evidence must succeed before calling this a released APK. YouTube URL supplied by user is a design reference, not a dependency.
