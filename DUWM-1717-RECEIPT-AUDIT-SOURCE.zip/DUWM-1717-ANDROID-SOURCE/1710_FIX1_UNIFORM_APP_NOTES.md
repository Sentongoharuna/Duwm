# DUWM 1710 FIX1 — uniform midnight navy, unobstructed original globe

This is a corrective update to the existing complete 1710 Android project, NOT a 1700-code rollback or a replacement globe.

* Main screen: original `SatelliteMapView` gets an exclusive full-height central stage. Search, top/bottom moving tickers, source health, controls, and mission desk navigation occupy separate vertical rows outside the globe. No side cards or edge controls are added over Earth by default.
* Native data dialogs hide the globe while displayed; they restore the same original map View on close. They are not second maps.
* One uniform style: `#050D22` base background, `#07162C` rounded raised cards, subtle light grey keylines, and only thin muted colour accents to identify the 19 existing desks or actual signal state.
* Keep every existing provider, globe interaction, camera, World Watch report, source evidence, share-card and aircraft/ship function in the source. Do not invent source data.
* Version identity: `versionCode 171001`, `versionName 1710`, installed label `DUWM 1710 FIX1 • DEVELOP.UGANDA`. This makes this a verifiable FIX1 to 1710, not a retrograde build.

## What passing locally proves
`verification/check_source.py`, `check_1710.py`, `check_1710_ui_fix1.py`, `JavaSyntaxCheck`, Android XML parse, archive checksum. **This is not a Gradle compilation or installed APK verification.** The GitHub workflow compiles a real APK, verifies identity, installs and launches the original globe under KVM, and only then publishes a verified artifact. It deliberately fails if any stage fails.
