# DUWM 1682 — In-place real observation navigator

- Upgrades original `MainActivity` and `SatelliteMapView` only. No extra globe.
- NEXT FIX and PREVIOUS FIX traverse genuine on-map geolocated `Signal` records; the globe camera centres on the record.
- FIX DETAIL opens the exact provider-backed source detail screen.
- A floating readout shows record number, title, category, timestamp (UTC); no fabricated live points.
- Rejects missing/invalid/future-dated observation timestamps from this navigator.
- Existing one-colour navy/cyan interface, media, source-health rail, news, AIS and evidence features preserved.
- Android 168200 / versionName 1682.
- Source checks do not guarantee a successful Android APK compile or remote provider responses.
