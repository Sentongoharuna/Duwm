# DUWM 1710 — Real data light & source chart

Source baseline: DUWM 1709 (confirmed GitHub green).

- Original single orthographic globe and 1709 nineteen thin desk outlines unchanged.
- New amber/red severity rings are drawn **only at actual recent geolocated source coordinates** for weather, news, airspace and natural reports (severity 4+, within 6 hours, maximum 22). These are highlights, not object movement.
- World Watch has an interactive 12-bin 24-hour / 6-hour source-activity chart: separately displays received reports and tracked observations based only on real timestamps. Empty or invalid data is labelled, not simulated.
- Source receipt cards have understated severity/data-category hairlines under their provenance metadata.
- Background remains #050D22; the ticker, full globe animation, signal lights, other native pages, 19 sector frames and all previously working modules remain.
- APK compilation and emulator test are required in GitHub Actions; syntax parser alone is not a green build.
