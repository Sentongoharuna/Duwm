package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** Canonical in-memory port registry with source provenance and deterministic updates. */
public final class PortRegistry {
 public enum Decision { ADDED, UPDATED, DUPLICATE, REJECTED }
 public static final class Result {public final Decision decision;public final PortRecord record;public final String reason;Result(Decision d,PortRecord r,String x){decision=d;record=r;reason=x;}}
 private final LinkedHashMap<String,PortRecord> byId=new LinkedHashMap<>();
 private final LinkedHashMap<String,String> sourceRecordToPort=new LinkedHashMap<>();
 private final PortLocodeIndex locodes=new PortLocodeIndex();
 private final PortCoordinateRegistry coordinates=new PortCoordinateRegistry();
 private final PortGeographyRegistry geography=new PortGeographyRegistry();
 private final HarbourBoundaryRegistry harbourBoundaries=new HarbourBoundaryRegistry();
 private final PortTerminalRegistry terminals=new PortTerminalRegistry();
 private final PortAnchorageRegistry anchorages=new PortAnchorageRegistry();
 private final PortBerthRegistry berths=new PortBerthRegistry();
 private final PortApproachRegistry approaches=new PortApproachRegistry();
 private final PortEntranceRegistry entrances=new PortEntranceRegistry();
 private final PortNavigationChannelRegistry navigationChannels=new PortNavigationChannelRegistry();
 private final PortRestrictionRegistry restrictions=new PortRestrictionRegistry();
 private final PortDraughtContextRegistry draughtContext=new PortDraughtContextRegistry();
 private final PortWeatherContextRegistry weatherContext=new PortWeatherContextRegistry();
 private final PortTideContextRegistry tideContext=new PortTideContextRegistry();
 private final PortTrafficHistory trafficHistory=new PortTrafficHistory();
 private final PortFollowRegistry portFollows=new PortFollowRegistry();
 public synchronized Result upsert(PortRecord r){
  if(r==null||!r.validIdentity())return new Result(Decision.REJECTED,r,"INVALID PORT IDENTITY");
  if(!r.hasLocation())return new Result(Decision.REJECTED,r,"INVALID/MISSING PORT LOCATION");
  String sourceKey=r.sourceId+"|"+r.sourceRecordId;
  String priorId=sourceRecordToPort.get(sourceKey);
  if(priorId!=null&&!priorId.equals(r.portId))return new Result(Decision.REJECTED,r,"SOURCE RECORD ALREADY BOUND TO "+priorId);
  PortRecord old=byId.get(r.portId);
  if(old!=null&&same(old,r)){sourceRecordToPort.put(sourceKey,r.portId);return new Result(Decision.DUPLICATE,old,"UNCHANGED");}
  byId.put(r.portId,r);sourceRecordToPort.put(sourceKey,r.portId);
  return new Result(old==null?Decision.ADDED:Decision.UPDATED,r,old==null?"NEW PORT":"PORT UPDATED");
 }
 public synchronized PortRecord get(String id){return byId.get(id==null?"":id.trim());}
 public synchronized List<PortRecord> all(){return Collections.unmodifiableList(new ArrayList<>(byId.values()));}
 public synchronized List<PortRecord> search(String q){
  String x=q==null?"":q.trim().toLowerCase(Locale.US);ArrayList<PortRecord> out=new ArrayList<>();
  for(PortRecord r:byId.values())if(x.isEmpty()||r.name.toLowerCase(Locale.US).contains(x)||r.portId.toLowerCase(Locale.US).contains(x)||r.countryCode.toLowerCase(Locale.US).contains(x))out.add(r);
  return Collections.unmodifiableList(out);
 }
 public synchronized PortLocodeIndex.Result bindUnLocode(String portId,String rawLocode){
  PortRecord port=get(portId);return locodes.bind(port,rawLocode);
 }
 public synchronized PortRecord byUnLocode(String rawLocode){String id=locodes.portId(rawLocode);return id.isEmpty()?null:byId.get(id);}
 public synchronized String unLocodeFor(String portId){return locodes.locode(portId);}
 public synchronized int unLocodeCount(){return locodes.size();}
 public synchronized PortCoordinateRegistry.Result addCoordinateEvidence(PortCoordinateEvidence e){if(e==null||!byId.containsKey(e.portId))return new PortCoordinateRegistry.Result(PortCoordinateRegistry.Decision.REJECTED,"UNKNOWN PORT");return coordinates.add(e);}
 public synchronized List<PortCoordinateEvidence> coordinateEvidence(String portId){return coordinates.evidence(portId);}
 public synchronized PortCoordinateRegistry.Conflict coordinateConflict(String portId){return coordinates.conflict(portId);}
 public synchronized int coordinateEvidenceCount(){return coordinates.evidenceCount();}
 public synchronized PortGeographyRegistry.Result addGeographyEvidence(PortGeographyEvidence e){
  return geography.add(e==null?null:byId.get(e.portId),e);
 }
 public synchronized List<PortGeographyEvidence> geographyEvidence(String portId){return geography.evidence(portId);}
 public synchronized PortGeographyRegistry.Conflict geographyConflict(String portId){return geography.conflict(portId);}
 public synchronized int geographyEvidenceCount(){return geography.evidenceCount();}
 public synchronized HarbourBoundaryRegistry.Result addHarbourBoundary(HarbourBoundaryEvidence e){return harbourBoundaries.add(e==null?null:byId.get(e.portId),e);}
 public synchronized List<HarbourBoundaryEvidence> harbourBoundaries(String portId){return harbourBoundaries.boundaries(portId);}
 public synchronized boolean pointInsideHarbour(String portId,double lat,double lon){return harbourBoundaries.contains(portId,lat,lon);}
 public synchronized HarbourBoundaryRegistry.Conflict harbourBoundaryConflict(String portId){return harbourBoundaries.conflict(portId);}
 public synchronized int harbourBoundaryCount(){return harbourBoundaries.count();}
 public synchronized PortTerminalRegistry.Result upsertTerminal(PortTerminalRecord terminal){return terminals.upsert(terminal==null?null:byId.get(terminal.portId),terminal);}
 public synchronized PortTerminalRecord terminal(String terminalId){return terminals.get(terminalId);}
 public synchronized List<PortTerminalRecord> terminalsForPort(String portId){return terminals.forPort(portId);}
 public synchronized List<PortTerminalRecord> searchTerminals(String query){return terminals.search(query);}
 public synchronized int terminalCount(){return terminals.size();}
 public synchronized PortAnchorageRegistry.Result upsertAnchorage(PortAnchorageRecord a){return anchorages.upsert(a==null?null:byId.get(a.portId),a);}
 public synchronized PortAnchorageRecord anchorage(String id){return anchorages.get(id);}
 public synchronized List<PortAnchorageRecord> anchoragesForPort(String portId){return anchorages.forPort(portId);}
 public synchronized List<PortAnchorageRecord> anchoragesContaining(String portId,double lat,double lon){return anchorages.containing(portId,lat,lon);}
 public synchronized int anchorageCount(){return anchorages.size();}
 public synchronized PortBerthRegistry.Result upsertBerth(PortBerthRecord b){
  PortRecord port=b==null?null:byId.get(b.portId);PortTerminalRecord terminal=b==null||b.terminalId.isEmpty()?null:terminals.get(b.terminalId);return berths.upsert(port,terminal,b);
 }
 public synchronized PortBerthRecord berth(String id){return berths.get(id);}
 public synchronized List<PortBerthRecord> berthsForPort(String portId){return berths.forPort(portId);}
 public synchronized List<PortBerthRecord> berthsForTerminal(String terminalId){return berths.forTerminal(terminalId);}
 public synchronized List<PortBerthRecord> searchBerths(String q){return berths.search(q);}
 public synchronized int berthCount(){return berths.size();}
 public synchronized PortApproachRegistry.Result upsertApproach(PortApproachRecord a){return approaches.upsert(a==null?null:byId.get(a.portId),a);}
 public synchronized PortApproachRecord approach(String id){return approaches.get(id);}
 public synchronized List<PortApproachRecord> approachesForPort(String portId){return approaches.forPort(portId);}
 public synchronized List<PortApproachRecord> searchApproaches(String q){return approaches.search(q);}
 public synchronized int approachCount(){return approaches.size();}
 public synchronized PortEntranceRegistry.Result upsertEntrance(PortEntranceRecord e){return entrances.upsert(e==null?null:byId.get(e.portId),e);}
 public synchronized PortEntranceRecord entrance(String id){return entrances.get(id);}
 public synchronized List<PortEntranceRecord> entrancesForPort(String portId){return entrances.forPort(portId);}
 public synchronized List<PortEntranceRecord> searchEntrances(String q){return entrances.search(q);}
 public synchronized int entranceCount(){return entrances.size();}
 public synchronized PortNavigationChannelRegistry.Result upsertNavigationChannel(PortNavigationChannelRecord c){return navigationChannels.upsert(c==null?null:byId.get(c.portId),c);}
 public synchronized PortNavigationChannelRecord navigationChannel(String id){return navigationChannels.get(id);}
 public synchronized List<PortNavigationChannelRecord> navigationChannelsForPort(String portId){return navigationChannels.forPort(portId);}
 public synchronized List<PortNavigationChannelRecord> searchNavigationChannels(String q){return navigationChannels.search(q);}
 public synchronized int navigationChannelCount(){return navigationChannels.size();}
 public synchronized PortRestrictionRegistry.Result upsertRestriction(PortRestrictionRecord r){return restrictions.upsert(r==null?null:byId.get(r.portId),r);}
 public synchronized PortRestrictionRecord restriction(String id){return restrictions.get(id);}
 public synchronized List<PortRestrictionRecord> restrictionsForPort(String portId){return restrictions.forPort(portId);}
 public synchronized List<PortRestrictionRecord> effectiveRestrictions(String portId,long atMs){return restrictions.effective(portId,atMs);}
 public synchronized List<PortRestrictionRecord> restrictionsAtPoint(String portId,double lat,double lon,long atMs){return restrictions.affectingPoint(portId,lat,lon,atMs);}
 public synchronized int restrictionCount(){return restrictions.size();}
 public synchronized PortDraughtContextRegistry.Result upsertDraughtContext(PortDraughtContextRecord x){return draughtContext.upsert(x==null?null:byId.get(x.portId),x);}
 public synchronized PortDraughtContextRecord draughtContext(String id){return draughtContext.get(id);}
 public synchronized java.util.List<PortDraughtContextRecord> draughtContextForPort(String portId){return draughtContext.forPort(portId);}
 public synchronized java.util.List<PortDraughtContextRecord> effectiveDraughtContext(String portId,long atMs){return draughtContext.effective(portId,atMs);}
 public synchronized int draughtContextCount(){return draughtContext.size();}
 public synchronized PortWeatherContextRegistry.Result upsertWeatherContext(PortWeatherContextRecord w){return weatherContext.upsert(w==null?null:byId.get(w.portId),w);}
 public synchronized PortWeatherContextRecord weatherContext(String id){return weatherContext.get(id);}
 public synchronized List<PortWeatherContextRecord> weatherForPort(String portId,PortWeatherContextRecord.Kind kind){return weatherContext.forPort(portId,kind);}
 public synchronized PortWeatherContextRecord latestWeather(String portId,PortWeatherContextRecord.Kind kind){return weatherContext.latest(portId,kind);}
 public synchronized int weatherContextCount(){return weatherContext.size();}
 public synchronized PortTideContextRegistry.Result upsertTideContext(PortTideContextRecord t){return tideContext.upsert(t==null?null:byId.get(t.portId),t);}
 public synchronized PortTideContextRecord tideContext(String id){return tideContext.get(id);}
 public synchronized List<PortTideContextRecord> tideForPort(String portId,PortTideContextRecord.Kind kind){return tideContext.forPort(portId,kind);}
 public synchronized PortTideContextRecord nearestTide(String portId,PortTideContextRecord.Kind kind,long atMs){return tideContext.nearest(portId,kind,atMs);}
 public synchronized int tideContextCount(){return tideContext.size();}
 public synchronized List<PortNearbyVessel> nearbyVessels(String portId,List<AisFusedVesselRecord> vessels,double radiusKm){return PortNearbyVesselEngine.find(this,portId,vessels,radiusKm);}
 public synchronized PortApproachTrend vesselApproachTrend(String portId,String vesselKey,NormalizedAisRecord previous,NormalizedAisRecord current){return PortApproachingVesselEngine.trend(byId.get(portId),vesselKey,previous,current);}
 public synchronized List<PortApproachTrend> approachingVessels(String portId,Map<String,List<NormalizedAisRecord>> histories){return PortApproachingVesselEngine.approaching(byId.get(portId),histories);}
 public synchronized PortDepartureEvidence vesselDepartureEvidence(String portId,String vesselKey,NormalizedAisRecord previous,NormalizedAisRecord current){return PortDepartingVesselEngine.assess(this,portId,vesselKey,previous,current);}
 public synchronized PortAnchoredVesselState anchoredVesselState(String portId,String vesselKey,NormalizedAisRecord previous,NormalizedAisRecord current){return PortAnchoredVesselEngine.assess(this,portId,vesselKey,previous,current);}
 public synchronized PortTrafficCounters trafficCounters(String portId,List<PortNearbyVessel> presence,Map<String,PortApproachTrend> approach,Map<String,PortDepartureEvidence> departure,Map<String,PortAnchoredVesselState> anchored,long nowMs){return PortTrafficCounterEngine.count(portId,presence,approach,departure,anchored,nowMs);}
 public synchronized boolean recordTrafficSnapshot(PortTrafficCounters snapshot){return snapshot!=null&&byId.containsKey(snapshot.portId)&&trafficHistory.record(snapshot);}
 public synchronized List<PortTrafficCounters> trafficHistory(String portId){return trafficHistory.snapshots(portId);}
 public synchronized List<PortTrafficCounters> trafficHistoryBetween(String portId,long fromMs,long toMs){return trafficHistory.between(portId,fromMs,toMs);}
 public synchronized PortTrafficCounters nearestTrafficSnapshot(String portId,long atMs){return trafficHistory.nearest(portId,atMs);}
 public synchronized int trafficHistoryCount(String portId){return trafficHistory.size(portId);}
 public synchronized PortDestinationMatch matchReportedDestination(String reportedDestination){return PortDestinationMatcher.match(this,reportedDestination);}
 public synchronized List<PortSearchResult> globalSearch(String query){return GlobalPortSearch.search(this,query);}
 public synchronized boolean followPort(String portId,long atMs){return portFollows.follow(byId.get(portId),atMs);}
 public synchronized boolean unfollowPort(String portId,long atMs){return portFollows.unfollow(byId.get(portId),atMs);}
 public synchronized boolean isPortFollowed(String portId){return portFollows.isFollowed(portId);}
 public synchronized List<String> followedPortIds(){return portFollows.followedPortIds();}
 public synchronized int followedPortCount(){return portFollows.count();}
 public synchronized PortOverviewCameraTarget overviewCameraTarget(String portId,long atMs){return PortOverviewCameraEngine.target(byId.get(portId),atMs);}
 public synchronized PortIntelligenceSheet intelligenceSheet(String portId,long atMs){return PortIntelligenceSheetBuilder.build(this,portId,atMs);}
 public synchronized PortShareCard shareCard(String portId,long atMs){return PortShareCardBuilder.build(intelligenceSheet(portId,atMs));}
 public synchronized int size(){return byId.size();}
 private static boolean same(PortRecord a,PortRecord b){return a.name.equals(b.name)&&a.countryCode.equals(b.countryCode)&&a.region.equals(b.region)&&Double.compare(a.latitude,b.latitude)==0&&Double.compare(a.longitude,b.longitude)==0&&a.sourceId.equals(b.sourceId)&&a.sourceRecordId.equals(b.sourceRecordId);}
}
