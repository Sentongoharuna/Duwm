package com.sentongoharuna.worldsituationroom;
import java.util.Locale;

/** FIX11.30/30.6: altitude facts and vertical state without inventing missing altitude. */
public final class AircraftAltitudeIntelligence {
 public enum VerticalState { CLIMBING, LEVEL, DESCENDING, ON_GROUND, UNKNOWN }
 public final double barometricM, geometricM, preferredM, verticalRateMps;
 public final VerticalState state;
 public final String preferredBasis;

 private AircraftAltitudeIntelligence(double b,double g,double p,double vr,VerticalState s,String basis){
  barometricM=b;geometricM=g;preferredM=p;verticalRateMps=vr;state=s;preferredBasis=basis;
 }
 public static AircraftAltitudeIntelligence from(Signal signal){
  AircraftTelemetry t=AircraftTelemetry.from(signal);
  if(t==null)return new AircraftAltitudeIntelligence(Double.NaN,Double.NaN,Double.NaN,Double.NaN,VerticalState.UNKNOWN,"UNKNOWN");
  double preferred=!Double.isNaN(t.barometricAltitudeM)?t.barometricAltitudeM:t.geometricAltitudeM;
  String basis=!Double.isNaN(t.barometricAltitudeM)?"BAROMETRIC":!Double.isNaN(t.geometricAltitudeM)?"GEOMETRIC":"UNKNOWN";
  VerticalState state;
  if(Boolean.TRUE.equals(t.onGround))state=VerticalState.ON_GROUND;
  else if(Double.isNaN(t.verticalRateMps))state=VerticalState.UNKNOWN;
  else if(t.verticalRateMps>1.0d)state=VerticalState.CLIMBING;
  else if(t.verticalRateMps<-1.0d)state=VerticalState.DESCENDING;
  else state=VerticalState.LEVEL;
  return new AircraftAltitudeIntelligence(t.barometricAltitudeM,t.geometricAltitudeM,preferred,t.verticalRateMps,state,basis);
 }
 public String compact(){
  String alt=Double.isNaN(preferredM)?"ALT UNKNOWN":String.format(Locale.US,"%s %.0fm",preferredBasis,preferredM);
  String vr=Double.isNaN(verticalRateMps)?"VR UNKNOWN":String.format(Locale.US,"VR %+.1fm/s",verticalRateMps);
  return alt+" • "+state.name()+" • "+vr;
 }
 public String dualAltitude(){
  if(!Double.isNaN(barometricM)&&!Double.isNaN(geometricM))
   return String.format(Locale.US,"BARO %.0fm • GEO %.0fm • Δ %+.0fm",barometricM,geometricM,geometricM-barometricM);
  if(!Double.isNaN(barometricM))return String.format(Locale.US,"BARO %.0fm • GEO UNKNOWN",barometricM);
  if(!Double.isNaN(geometricM))return String.format(Locale.US,"BARO UNKNOWN • GEO %.0fm",geometricM);
  return "BARO UNKNOWN • GEO UNKNOWN";
 }
}
