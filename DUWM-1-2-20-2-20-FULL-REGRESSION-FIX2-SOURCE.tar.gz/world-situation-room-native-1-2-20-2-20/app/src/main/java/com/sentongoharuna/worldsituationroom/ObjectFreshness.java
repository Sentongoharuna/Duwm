package com.sentongoharuna.worldsituationroom;

/**
 * 1.2/20/2-5 canonical freshness derived from provider age + provider feed state.
 * Retained objects never become LIVE merely because the UI rendered again.
 */
public final class ObjectFreshness {
    public enum State { LIVE, FRESH, DELAYED, STALE, OFFLINE, UNKNOWN }

    public final State state;
    public final long ageMs;

    private ObjectFreshness(State state, long ageMs) {
        this.state = state;
        this.ageMs = ageMs;
    }

    public static ObjectFreshness evaluate(
            RecordTimestampChain chain, FeedStatus status, long now) {
        long age = chain == null ? -1L : chain.providerAgeMs(now);
        if (status != null && status.state == FeedStatus.State.OFFLINE)
            return new ObjectFreshness(State.OFFLINE, age);
        if (status != null && (status.state == FeedStatus.State.DELAYED
                || status.state == FeedStatus.State.KEY_REQUIRED))
            return new ObjectFreshness(State.DELAYED, age);
        if (age < 0L) return new ObjectFreshness(State.UNKNOWN, age);
        if (age <= 2L * 60L * 1000L) return new ObjectFreshness(State.LIVE, age);
        if (age <= 15L * 60L * 1000L) return new ObjectFreshness(State.FRESH, age);
        if (age <= 60L * 60L * 1000L) return new ObjectFreshness(State.DELAYED, age);
        return new ObjectFreshness(State.STALE, age);
    }

    public String ageText() {
        if (ageMs < 0L) return "TIME UNKNOWN";
        long min = ageMs / 60000L;
        if (min < 1L) return "NOW";
        if (min < 60L) return min + "m";
        long h = min / 60L;
        return h < 48L ? h + "h" : (h / 24L) + "d";
    }
}
