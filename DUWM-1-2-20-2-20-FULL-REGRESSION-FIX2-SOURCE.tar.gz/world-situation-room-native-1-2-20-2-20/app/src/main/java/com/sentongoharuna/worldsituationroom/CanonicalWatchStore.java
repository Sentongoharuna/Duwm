package com.sentongoharuna.worldsituationroom;
import android.content.*;
/** Persists watch identity by canonical object ID, never title/coordinates. */
public final class CanonicalWatchStore{
 private final SharedPreferences p;
 public CanonicalWatchStore(Context c){p=c.getApplicationContext().getSharedPreferences("du_canonical_watch_v1",Context.MODE_PRIVATE);}
 public boolean watched(String id){return id!=null&&!id.isEmpty()&&p.getBoolean("w_"+id,false);}
 public void setWatched(Signal s,boolean v){if(s==null||s.canonicalId==null||s.canonicalId.isEmpty())return;p.edit().putBoolean("w_"+s.canonicalId,v).putString("provider_"+s.canonicalId,s.providerId).putString("record_"+s.canonicalId,s.id).putString("layer_"+s.canonicalId,s.layer.name()).apply();}
}
