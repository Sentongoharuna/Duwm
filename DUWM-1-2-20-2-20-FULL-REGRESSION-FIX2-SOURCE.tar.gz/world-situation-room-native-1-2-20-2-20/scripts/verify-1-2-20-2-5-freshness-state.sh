#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
F="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/ObjectFreshness.java"
S="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/Signal.java"
M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
test -s "$F"
grep -F 'enum State { LIVE, FRESH, DELAYED, STALE, OFFLINE, UNKNOWN }' "$F" >/dev/null
grep -F 'chain.providerAgeMs(now)' "$F" >/dev/null
grep -F 'FeedStatus.State.OFFLINE' "$F" >/dev/null
grep -F 'FeedStatus.State.DELAYED' "$F" >/dev/null
grep -F 'FeedStatus.State.KEY_REQUIRED' "$F" >/dev/null
grep -F 'public ObjectFreshness freshness;' "$S" >/dev/null
grep -F 'ObjectFreshness.evaluate(' "$S" >/dev/null
grep -F 'ObjectFreshness.evaluate(signal.timestampChain, status, freshnessNow)' "$M" >/dev/null
grep -F 'operationsEngine.accept(' "$M" >/dev/null
"$P/scripts/verify-1-2-20-2-4-timestamp-chain.sh" "$P"
echo "1.2/20/2-5 FRESHNESS STATE PASS"
