#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"

# Frozen prior generation.
"$P/scripts/verify-1-2-20-2-20-full-regression.sh" "$P"

# Every Globe Object Intelligence gate, in order.
for s in \
 verify-1-2-20-3-1-universal-globe-object-tap.sh \
 verify-1-2-20-3-2-object-intelligence-sheet.sh \
 verify-1-2-20-3-3-aircraft-intelligence.sh \
 verify-1-2-20-3-4-aircraft-live-track.sh \
 verify-1-2-20-3-5-aircraft-trail.sh \
 verify-1-2-20-3-6-event-intelligence.sh \
 verify-1-2-20-3-7-orbit-intelligence.sh \
 verify-1-2-20-3-8-weather-object-intelligence.sh \
 verify-1-2-20-3-9-news-globe-intelligence.sh \
 verify-1-2-20-3-10-east-africa-resolver.sh \
 verify-1-2-20-3-11-related-intelligence.sh \
 verify-1-2-20-3-12-object-timeline.sh \
 verify-1-2-20-3-13-object-freshness-engine.sh \
 verify-1-2-20-3-14-provider-health-from-object.sh \
 verify-1-2-20-3-15-watch-intelligence.sh \
 verify-1-2-20-3-16-globe-search-exact-object.sh \
 verify-1-2-20-3-17-overlap-cluster-selection.sh \
 verify-1-2-20-3-18-object-share-card-2.sh \
 verify-1-2-20-3-19-object-functional-gate.sh; do
  chmod +x "$P/scripts/$s"
  "$P/scripts/$s" "$P"
done

# Final architecture invariants.
grep -F 'mapView = new SatelliteMapView(this)' "$J/MainActivity.java" >/dev/null
grep -F 'routeUniversalGlobeTap' "$J/MainActivity.java" >/dev/null
grep -F 'resolveExactSignal' "$J/MainActivity.java" >/dev/null
grep -F 'RELATIONSHIP ≠ CONFIRMATION' "$J/MainActivity.java" >/dev/null
grep -F 'CALCULATED FROM PUBLIC ELEMENTS — NOT LIVE TELEMETRY' "$J/MainActivity.java" >/dev/null
grep -F 'UNRESOLVED — NO MARKER INVENTED' "$J/MainActivity.java" >/dev/null
grep -F 'LAST_GOOD' "$J/ObjectFreshness.java" >/dev/null

# No dependency/UI architecture drift.
! grep -R -E 'android\.webkit\.WebView|okhttp3|okio\.' "$J"
test "$(grep -c 'new NewsSource(' "$J/NewsSourceCatalog.java")" -ge 43

echo "1.2/20/3-20 GLOBE INTELLIGENCE FULL GREEN PASS"
