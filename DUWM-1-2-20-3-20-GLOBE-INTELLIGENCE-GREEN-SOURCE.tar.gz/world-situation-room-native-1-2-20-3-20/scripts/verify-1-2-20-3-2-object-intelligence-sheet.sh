#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
grep -F 'compact Object Intelligence Sheet over the frozen Globe' "$M" >/dev/null
grep -F 'objectIntelligenceHeader(Signal signal)' "$M" >/dev/null
grep -F 'signal.layer.name() + "  •  " + signalStateText(signal) + "  •  " + freshness' "$M" >/dev/null
grep -F '"PROVIDER  " + provider + "  •  RECORD  " + recordId' "$M" >/dev/null
grep -F 'body.append("CANONICAL  ")' "$M" >/dev/null
grep -F 'detailWatchButton.setText(canonicalWatchStore.watched(signal.canonicalId) ? "WATCHING" : "WATCH")' "$M" >/dev/null
grep -F 'detailPanel.setContentDescription("Object Intelligence: " + signal.title)' "$M" >/dev/null
grep -F 'sourceButton' "$M" >/dev/null
grep -F 'detailShareButton' "$M" >/dev/null
"$P/scripts/verify-1-2-20-3-1-universal-globe-object-tap.sh" "$P"
echo "1.2/20/3-2 OBJECT INTELLIGENCE SHEET PASS"
