#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"; V="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/SatelliteMapView.java"
"$P/scripts/verify-1-2-20-4-19-live-intelligence-functional-regression.sh" "$P"
echo "3309dfc06fe8608653c77e54d19391428f686e42d243f0031c5da21e9b33adcb  $V" | sha256sum -c -
# Freeze proven pre-4.19A globe engine.
grep -F 'private final Runnable framePulse = new Runnable()' "$V" >/dev/null
grep -F 'updateAutoRotation();' "$V" >/dev/null
grep -F 'postOnAnimationDelayed(framePulse, frameDelayMs);' "$V" >/dev/null
! grep -F 'liveRotationPhaseDeg' "$V"
! grep -F 'motionLoopRunning' "$V"
! grep -F 'advanceLiveMotion' "$V"
echo "1.2/20/4.20 WORKING GLOBE BASELINE CONTINUATION PASS"
