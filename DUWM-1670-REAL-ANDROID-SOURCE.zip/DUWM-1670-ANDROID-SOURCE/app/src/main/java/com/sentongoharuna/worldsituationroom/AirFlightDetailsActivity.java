package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.content.Intent;
import java.util.TimeZone;

/** Accessible, scrollable report, opened from any aircraft widget row. */
public final class AirFlightDetailsActivity extends Activity {
    private final int background = Color.rgb(7, 15, 26);
    private final int ink = Color.rgb(228, 240, 248);
    private final int muted = Color.rgb(139, 168, 185);
    private final int cyan = Color.rgb(76, 213, 234);
    private int dp(float x) { return (int)(x*getResources().getDisplayMetrics().density+.5f); }
    private TextView label(String text, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(5), 0, dp(5));
        return t;
    }
    private GradientDrawable panel() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.rgb(14, 28, 42)); d.setCornerRadius(dp(14));
        d.setStroke(dp(1), Color.rgb(34, 72, 88)); return d;
    }
    private void field(LinearLayout parent, String key, String value) {
        LinearLayout row=new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(10),dp(5),dp(8),dp(6));
        row.addView(label(key, 11, muted, false));
        row.addView(label(value, 18, ink, true));
        parent.addView(row);
    }
    private static String fmt(double value, String pattern, String unit) {
        return AirOperationsWidgets.finite(value)?String.format(Locale.US,pattern,value)+unit:"NOT REPORTED";
    }
    /** ITEM 02 independent OpenSky detail mode. It never relabels regional ADS-B data. */
    private void showOpenSkyDetails(ScrollView sc,LinearLayout root,String aircraftId){
        String hex=aircraftId==null?"":aircraftId.trim().toUpperCase(Locale.US);
        RunningballV25GlobalAircraftData.Snapshot snap=RunningballV25GlobalAircraftData.read(this);
        org.json.JSONArray record=null;
        if(snap.hasGood())for(int i=0;i<snap.points.length();i++){
            org.json.JSONArray p=snap.points.optJSONArray(i);
            if(p!=null&&hex.equalsIgnoreCase(p.optString(2, ""))){record=p;break;}
        }
        root.addView(label("OPEN SKY / WORLDWIDE REPORTED POSITIONS",13,cyan,true));
        root.addView(label("SOURCE: opensky-network.org / states/all · Receiver coverage, not every aircraft",12,muted,false));
        root.addView(label("NETWORK STATUS: "+snap.status()+" · LAST GOOD: "+snap.ageLabel(),12,muted,false));
        root.addView(label("PROVIDER REPORT AGE: "+snap.providerAgeLabel(),12,muted,false));
        if(record==null){
            root.addView(label("Aircraft "+(hex.isEmpty()?"NOT SELECTED":hex)+" is not in the retained OpenSky position sample. No regional ADS-B result has been substituted.",16,muted,false));
            setContentView(sc);return;
        }
        double lat=record.optDouble(0,Double.NaN),lon=record.optDouble(1,Double.NaN);
        if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180){
            root.addView(label("INVALID PROVIDER COORDINATES · NO POSITION SHOWN",15,muted,false));setContentView(sc);return;
        }
        String call=record.optString(3,"").trim();
        root.addView(label((call.isEmpty()?"AIRCRAFT":call)+" / "+hex,24,ink,true));
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(panel());card.setPadding(dp(8),dp(8),dp(8),dp(8));root.addView(card);
        field(card,"ICAO24",hex);
        field(card,"REPORTED ORIGIN",record.optString(9,"UNKNOWN"));
        field(card,"OBSERVED LATITUDE",String.format(Locale.US,"%.5f°",lat));
        field(card,"OBSERVED LONGITUDE",String.format(Locale.US,"%.5f°",lon));
        field(card,"BAROMETRIC ALTITUDE",record.isNull(4)?"NOT REPORTED":String.format(Locale.US,"%.0f ft (%.0f m)",record.optDouble(4)*3.280839895d,record.optDouble(4)));
        field(card,"GROUND SPEED",record.isNull(5)?"NOT REPORTED":String.format(Locale.US,"%.0f knots (%.0f km/h)",record.optDouble(5)*1.943844492d,record.optDouble(5)*3.6d));
        field(card,"TRACK",record.isNull(6)?"NOT REPORTED":String.format(Locale.US,"%.0f°",record.optDouble(6)));
        field(card,"ON GROUND",record.isNull(8)?"NOT REPORTED":(record.optBoolean(8)?"YES":"NO"));
        long lastPosition=record.isNull(7)?0L:record.optLong(7,0L)*1000L;
        SimpleDateFormat df=new SimpleDateFormat("dd MMM yyyy HH:mm:ss 'UTC'",Locale.US);
        df.setTimeZone(TimeZone.getTimeZone("UTC"));
        field(card,"LAST REPORTED POSITION",lastPosition<=0?"NOT REPORTED":df.format(new Date(lastPosition)));
        field(card,"PROVIDER SNAPSHOT",snap.sourceAt<=0?"NOT REPORTED":df.format(new Date(snap.sourceAt)));
        root.addView(label("REPORTED COORDINATES ONLY · NOT A LIVE VIDEO OR PREDICTED POSITION",12,muted,false));
        TextView earth=label("VIEW EXACT REPORTED POSITION / EARTH EXPLORER  ›",14,cyan,true);
        earth.setBackground(panel());earth.setMinimumHeight(dp(48));earth.setOnClickListener(v->{
            Intent i=new Intent(this,GevEarthExploreActivity.class);
            i.putExtra("geo_lat",lat);i.putExtra("geo_lon",lon);startActivity(i);
        });root.addView(earth);
        TextView globe=label("OPEN ORIGINAL WORLD GLOBE  ›",14,cyan,true);
        globe.setBackground(panel());globe.setMinimumHeight(dp(48));
        globe.setOnClickListener(v->startActivity(new Intent(this,MainActivity.class)));root.addView(globe);
        TextView back=label("← BACK TO WORLDWIDE AIRCRAFT",14,cyan,true);back.setMinimumHeight(dp(48));
        back.setOnClickListener(v->finish());root.addView(back);
        setContentView(sc);
    }
    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(background); getWindow().setNavigationBarColor(background);
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true); sc.setBackgroundColor(background);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(30));
        sc.addView(root);
        root.addView(label("RUNNINGBALL2  /  AIRCRAFT INTELLIGENCE", 11, cyan, true));
        if("OPENSKY".equalsIgnoreCase(getIntent().getStringExtra("air_provider"))){
            showOpenSkyDetails(sc,root,getIntent().getStringExtra("air_hex"));return;
        }
        String hex=getIntent().getStringExtra("air_hex");
        if(hex==null)hex="";
        JSONObject cached=AirOperationsWidgets.lastData(this);
        long stamp=cached.optLong("time",0L);
        JSONArray entries=cached.optJSONArray("items");
        JSONObject aircraft=null;
        if(entries!=null){for(int i=0;i<entries.length();i++){
            JSONObject row=entries.optJSONObject(i);
            if(row!=null&&(hex.isEmpty()||hex.equals(row.optString("hex", "")))){aircraft=row;break;}
        }}
        String title=aircraft!=null?aircraft.optString("flight", "AIRCRAFT"):"AIRCRAFT OPERATIONS";
        root.addView(label(title, 29, ink, true));
        root.addView(label("SELECTED WORLD REGION  •  250 NM RADIUS", 12, muted, false));
        if(aircraft==null){
            root.addView(label("No cached aircraft report is available. Refresh either aircraft widget while connected.",16,muted,false));
            setContentView(sc);return;
        }
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(panel());
        card.setPadding(dp(8),dp(7),dp(8),dp(10));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);
        cp.topMargin=dp(14); root.addView(card,cp);
        field(card,"ICAO / HEX IDENTIFIER",aircraft.optString("hex", "—"));
        field(card,"DISTANCE FROM SELECTED REGION",fmt(aircraft.optDouble("nm",Double.NaN),"%.1f"," nautical miles"));
        field(card,"BAROMETRIC ALTITUDE",aircraft.optBoolean("ground",false)?"ON GROUND":fmt(aircraft.optDouble("alt",Double.NaN),"%.0f"," feet"));
        field(card,"GROUND SPEED",fmt(aircraft.optDouble("speed",Double.NaN),"%.0f"," knots"));
        field(card,"HEADING (TRUE)",fmt(aircraft.optDouble("heading",Double.NaN),"%.0f"," degrees"));
        field(card,"LATITUDE",fmt(aircraft.optDouble("lat",Double.NaN),"%.5f","°"));
        field(card,"LONGITUDE",fmt(aircraft.optDouble("lon",Double.NaN),"%.5f","°"));
        field(card,"POSITION AGE WHEN RECEIVED",fmt(aircraft.optDouble("seen",Double.NaN),"%.0f"," seconds"));
        SimpleDateFormat df=new SimpleDateFormat("dd MMM yyyy  •  HH:mm:ss 'UTC'",Locale.US);
        df.setTimeZone(TimeZone.getTimeZone("UTC"));
        root.addView(label("SNAPSHOT: "+(stamp>0?df.format(new Date(stamp)):"NOT AVAILABLE"),12,cyan,true));
        long age=stamp<=0?Long.MAX_VALUE:Math.max(0,System.currentTimeMillis()-stamp);
        root.addView(label(age>180_000L?"CACHED REPORT — DO NOT TREAT AS A LIVE POSITION":"RECENT REPORT — POSITION MAY HAVE CHANGED",12,age>180_000L?Color.rgb(250,192,91):cyan,true));
        root.addView(label("SOURCE: ADSB.LOL. Positions are received reports; coverage, altitude and speed may be unavailable or delayed. No predicted movement is shown.",12,muted,false));
        TextView back=label("←  CLOSE DETAILS",14,cyan,true);
        back.setGravity(Gravity.CENTER);
        back.setBackground(panel());
        back.setPadding(dp(12),dp(13),dp(12),dp(13));
        back.setOnClickListener(new View.OnClickListener(){@Override public void onClick(View v){finish();}});
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(20);root.addView(back,bp);
        setContentView(sc);
    }
}
