package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.FrameLayout;
import android.util.AttributeSet;
import java.lang.reflect.Constructor;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Operational home screen. Presentation never substitutes for observed source records. */
public final class OperationsMainActivity extends Activity {
    private static final int BG=Color.rgb(7,15,25), PANEL=Color.rgb(16,29,42), BORDER=Color.rgb(41,61,75);
    private static final int TEXT=Color.rgb(225,236,240), MUTED=Color.rgb(146,166,177), ACCENT=Color.rgb(110,188,203), WARN=Color.rgb(228,173,111);
    private static final long REFRESH_MS=180000L;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService network=Executors.newSingleThreadExecutor();
    private final AtomicBoolean fetching=new AtomicBoolean(false);
    private Duwm1670HomeTelemetryView newRail;
    private OperationsGlobeView earth;
    private OperationsGlobeView.Observation selectedShareObservation;
    private FrameLayout earthViewport;
    private View originalEarth;
    private TextView originalToggle, liveReadout;
    private LinearLayout originalHud;
    private OperationsTelemetryPanel telemetryPanel;
    private LinearLayout selectedObservation;
    private TextView selectedTitle,selectedDetail,selectedAction;
    private OperationsGlobeView.Observation selectedItem;
    private boolean originalMode=false;
    private boolean fullEarth=false;
    private TextView headerStatus,clock,updatedText,summaryText,airCount,quakeCount,issCount,airSource,quakeSource,issSource,detail;
    private TextView airLayer,quakeLayer,issLayer,rotationControl;
    private Duwm1166SignalView duwm1166AirLed,duwm1166QuakeLed,duwm1166IssLed;
    // V1159.4: the front-screen data receipt strip never displays synthetic observations.
    private TextView sourceHeartbeat;
    private boolean viewAir=true,viewQuakes=true,viewIss=true,rotate=true,foreground=false;
    private long lastAttempt=Long.MIN_VALUE/2;
    private final Runnable second=new Runnable(){@Override public void run(){
        if(!foreground)return;clock.setText(utc(System.currentTimeMillis())+" UTC");
        if(!fetching.get() && SystemClock.elapsedRealtime()-lastAttempt>=REFRESH_MS)refresh();
        main.postDelayed(this,1000);
    }};
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private String utc(long ms){SimpleDateFormat f=new SimpleDateFormat("dd MMM yyyy   HH:mm:ss",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(ms));}
    private TextView text(String s,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(sp);if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return t;}
    private GradientDrawable bg(int color,float corner,int line){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(corner));if(line!=0)d.setStroke(dp(1),line);return d;}
    private void rowAdd(LinearLayout row,View child,int width,int height){row.addView(child,new LinearLayout.LayoutParams(width<0?width:dp(width),height<0?height:dp(height)));}
    private TextView action(String label, String description){TextView t=text(label,11,ACCENT,true);t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12),dp(8),dp(12),dp(8));t.setBackground(bg(PANEL,5,BORDER));t.setContentDescription(description);return t;}
    private LinearLayout metric(LinearLayout parent,String title){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(10),dp(10),dp(9));card.setBackground(bg(PANEL,7,BORDER));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(168),dp(96));cp.rightMargin=dp(8);parent.addView(card,cp);
        TextView header=text(title,10,MUTED,true);card.addView(header);return card;
    }
    private void navigate(String mode){
        if("1670 COMMAND".equals(mode)){startActivity(new Intent(this,Duwm1670CommandActivity.class));return;}
        if("1670 FLIGHT MAP".equals(mode)){startActivity(new Intent(this,Duwm1670FlightMapActivity.class));return;}
        if("1670 NEWS ATLAS".equals(mode)){startActivity(new Intent(this,Duwm1670NewsAtlasActivity.class));return;}
        if("200 SOURCES".equals(mode)){startActivity(new Intent(this,Duwm1669SourceDirectoryActivity.class));return;}
        if("GEO LENS".equals(mode)){startActivity(new Intent(this,Duwm1668GeopoliticalLensActivity.class));return;}
        if("ALL INTELLIGENCE".equals(mode)){startActivity(new Intent(this,Duwm1166DirectoryActivity.class));return;}
        if("WORLD NEWS".equals(mode)){startActivity(new Intent(this,Duwm1166NewsDeskActivity.class));return;}
        if("RADIO".equals(mode)){startActivity(new Intent(this,Duwm1166RadioAtlasActivity.class));return;}

        if("ORIGINAL COMMAND".equals(mode)){startActivity(new Intent(this,MainActivity.class));return;}
        if("AIRCRAFT".equals(mode)){startActivity(new Intent(this,AircraftOperationsActivity.class));return;}
        if("RADIO".equals(mode)||"TV STATIONS".equals(mode)||"WORLD NEWS".equals(mode)||"EARTH IMAGES".equals(mode)){
            Intent i=new Intent(this,MediaDeskActivity.class);i.putExtra("mode",mode);startActivity(i);return;
        }
        Intent intent=new Intent(this,WorldSourceHubActivity.class);intent.putExtra("mode",mode);startActivity(intent);
    }
    @Override public void onCreate(Bundle state){super.onCreate(state);setTheme(android.R.style.Theme_Material_NoActionBar);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        LinearLayout root=new LinearLayout(this);root.setBackgroundColor(BG);root.setOrientation(LinearLayout.VERTICAL);setContentView(root);
        root.setFitsSystemWindows(true);
        if(android.os.Build.VERSION.SDK_INT >= 30){
            root.setOnApplyWindowInsetsListener((v,insets)->{
                android.graphics.Insets bars=insets.getInsets(android.view.WindowInsets.Type.statusBars()|android.view.WindowInsets.Type.navigationBars());
                root.setPadding(0,bars.top,0,bars.bottom);
                return insets;
            });
        }
        LinearLayout heading=new LinearLayout(this);heading.setGravity(Gravity.CENTER_VERTICAL);heading.setPadding(dp(16),dp(10),dp(16),dp(6));rowAdd(root,heading,-1,50);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.develop_uganda_logo);heading.addView(logo,new LinearLayout.LayoutParams(dp(36),dp(36)));
        LinearLayout brand=new LinearLayout(this);brand.setOrientation(LinearLayout.VERTICAL);brand.setPadding(dp(11),0,0,0);heading.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        brand.addView(text("DEVELOP.UGANDA",15,TEXT,true));brand.addView(text("WORLD SITUATION ROOM  /  INTELLIGENCE",10,MUTED,true));
        headerStatus=text("CONNECTING",10,ACCENT,true);headerStatus.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);rowAdd(heading,headerStatus,70,34);
        LinearLayout metadata=new LinearLayout(this);metadata.setPadding(dp(16),dp(2),dp(16),dp(8));metadata.setGravity(Gravity.CENTER_VERTICAL);rowAdd(root,metadata,-1,27);
        clock=text("UTC --",11,MUTED,false);metadata.addView(clock,new LinearLayout.LayoutParams(0,-2,1));
        updatedText=text("NO SOURCE SYNC",10,MUTED,true);metadata.addView(updatedText,new LinearLayout.LayoutParams(-2,-2));
        HorizontalScrollView scroller=new HorizontalScrollView(this);scroller.setHorizontalScrollBarEnabled(false);rowAdd(root,scroller,-1,44);
        LinearLayout tabs=new LinearLayout(this);tabs.setGravity(Gravity.CENTER_VERTICAL);tabs.setPadding(dp(14),0,dp(8),0);scroller.addView(tabs);
        String[][] categories={{"1670 LIVE COMMAND","1670 COMMAND"},{"LIVE AIRCRAFT MAP","1670 FLIGHT MAP"},{"200 REGIONAL NEWS","1670 NEWS ATLAS"},{"200 WORLD SOURCES","200 SOURCES"},{"GEO LENS 1668","GEO LENS"},{"ALL DESKS","ALL INTELLIGENCE"},{"AIRCRAFT REGISTER","AIRCRAFT"},{"VESSELS","VESSELS"},{"SATELLITES","SATELLITES"},{"CITY CAMERAS","CITY CAMERAS"},
                {"NEWS","WORLD NEWS"},{"RADIO","RADIO"},{"TELEVISION","TV STATIONS"},{"INTERNET","INTERNET"},{"NASA IMAGES","EARTH IMAGES"},{"ORIGINAL COMMAND","ORIGINAL COMMAND"}};
        for(String[] c:categories){TextView tab=action(c[0],"Open " + c[1] + " monitoring sources");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(39));lp.rightMargin=dp(6);tabs.addView(tab,lp);tab.setOnClickListener(v->navigate(c[1]));}
        // 1670: compact source-backed changing figures, no decorative fake counts.
        newRail=new Duwm1670HomeTelemetryView(this);
        newRail.setOnClickListener(v->navigate("1670 COMMAND"));
        newRail.setContentDescription("Open DUWM 1670 command page; figures come from last verified provider receipts");
        root.addView(newRail,new LinearLayout.LayoutParams(-1,dp(49)));
        LinearLayout globeFrame=new LinearLayout(this);globeFrame.setOrientation(LinearLayout.VERTICAL);globeFrame.setBackground(bg(Color.rgb(9,19,31),0,0));
        root.addView(globeFrame,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout globeHeading=new LinearLayout(this);globeHeading.setGravity(Gravity.CENTER_VERTICAL);
        globeHeading.setPadding(dp(16),dp(4),dp(16),0);rowAdd(globeFrame,globeHeading,-1,29);
        // Two distinct rows prevent long geographic labels from being compressed by controls.
        LinearLayout globeControls=new LinearLayout(this);globeControls.setGravity(Gravity.CENTER_VERTICAL);
        globeControls.setPadding(dp(12),0,dp(12),dp(2));
        globeFrame.addView(globeControls,new LinearLayout.LayoutParams(-1,dp(39)));
        // V1159.4 VISIBLE MAIN SCREEN: photo-backed share cards are one tap from the globe.
        LinearLayout photoRail=new LinearLayout(this);photoRail.setGravity(Gravity.CENTER_VERTICAL);
        photoRail.setPadding(dp(12),dp(3),dp(12),dp(3));
        globeFrame.addView(photoRail,new LinearLayout.LayoutParams(-1,dp(40)));
        TextView newsPhoto=action("NEWS PHOTO CARDS","Open WORLD NEWS source pictures and shareable details");
        newsPhoto.setTextColor(Color.rgb(228,242,245));
        newsPhoto.setBackground(bg(Color.rgb(24,61,77),8,Color.rgb(73,164,188)));
        LinearLayout.LayoutParams nlp=new LinearLayout.LayoutParams(0,dp(39),1);nlp.rightMargin=dp(5);photoRail.addView(newsPhoto,nlp);
        newsPhoto.setOnClickListener(v->startActivity(new Intent(this,Duwm1166NewsDeskActivity.class)));
        TextView earthPhotos=action("NASA EARTH PHOTOS","Open NASA source Earth pictures and image share cards");
        earthPhotos.setTextColor(Color.rgb(228,242,245));
        earthPhotos.setBackground(bg(Color.rgb(21,47,63),8,Color.rgb(70,116,143)));
        LinearLayout.LayoutParams elp=new LinearLayout.LayoutParams(0,dp(39),1);elp.leftMargin=dp(5);photoRail.addView(earthPhotos,elp);
        earthPhotos.setOnClickListener(v->{Intent i=new Intent(this,MediaDeskActivity.class);i.putExtra("mode","EARTH IMAGES");startActivity(i);});
        sourceHeartbeat=text("SOURCE RECEIPTS   /   NOT YET CHECKED",11,ACCENT,true);
        sourceHeartbeat.setPadding(dp(12),dp(4),dp(4),dp(3));
        sourceHeartbeat.setSingleLine(true);
        sourceHeartbeat.setEllipsize(android.text.TextUtils.TruncateAt.END);
        sourceHeartbeat.setContentDescription("Real provider synchronization status; no simulated live counts");
        LinearLayout verifiedRailRow=new LinearLayout(this);verifiedRailRow.setGravity(Gravity.CENTER_VERTICAL);
        verifiedRailRow.addView(sourceHeartbeat,new LinearLayout.LayoutParams(0,dp(25),1));
        DuwmSignalRail verifiedLeds=DuwmSignalRail.embedded(this);
        LinearLayout.LayoutParams signalParams=new LinearLayout.LayoutParams(dp(106),dp(24));signalParams.rightMargin=dp(8);
        verifiedRailRow.addView(verifiedLeds,signalParams);
        globeFrame.addView(verifiedRailRow,new LinearLayout.LayoutParams(-1,dp(27)));
        TextView globeLabel=text("DETAILED EARTH  /  VERIFIED WORLD POSITIONS",12,TEXT,true);
        globeLabel.setSingleLine(true);globeLabel.setEllipsize(android.text.TextUtils.TruncateAt.END);
        globeLabel.setContentDescription("Detailed rotating geographic Earth with Natural Earth coastlines and real source observations");
        globeHeading.addView(globeLabel,new LinearLayout.LayoutParams(-1,-2));
        rotationControl=action("ROTATION ON","Toggle visible globe auto-rotation");
        LinearLayout.LayoutParams rotateP=new LinearLayout.LayoutParams(0,dp(35),1);rotateP.rightMargin=dp(5);
        globeControls.addView(rotationControl,rotateP);
        rotationControl.setOnClickListener(v->{
            if(originalMode && originalEarth instanceof SatelliteMapView){
                rotate=!rotate;
                ((SatelliteMapView)originalEarth).setAutoRotationEnabled(rotate);
                rotationControl.setText(rotate?"ROTATION ON":"ROTATION OFF");
                detail.setText(rotate?"Original globe rotating; dragging pauses rotation temporarily":
                               "Original globe rotation paused; touch to inspect geographic features");
                return;
            }
            rotate=!rotate;rotationControl.setText(rotate?"ROTATION  ON":"ROTATION  OFF");
            if(rotate&&foreground)earth.resume();else earth.pause();
        });
        // One shared live Earth viewport: modern source globe and the actual preserved original renderer.
        // The two renderers belong to the SAME Android app and can be switched without launching a second dashboard.
        earthViewport=new FrameLayout(this);
        globeFrame.addView(earthViewport,new LinearLayout.LayoutParams(-1,0,1));
        earth=new OperationsGlobeView(this);
        earthViewport.addView(earth,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout earthHud=new LinearLayout(this);originalHud=earthHud;earthHud.setOrientation(LinearLayout.VERTICAL);
        earthHud.setPadding(dp(12),dp(8),dp(12),dp(8));earthHud.setBackground(bg(Color.argb(205,10,26,39),7,BORDER));
        FrameLayout.LayoutParams earthHudParams=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT);
        earthHudParams.leftMargin=dp(13);earthHudParams.topMargin=dp(8);
        earthViewport.addView(earthHud,earthHudParams);
        earthHud.addView(text("ORIGINAL GLOBE / OBSERVED SIGNALS",11,TEXT,true));
        liveReadout=text("AWAITING SOURCE OBSERVATIONS",11,ACCENT,true);earthHud.addView(liveReadout);
        originalToggle=action("LEGACY", "Optionally show the alternative legacy Canvas globe");
        // Mode control belongs beside the globe title, never over the coastline or markers.
        originalToggle.setText("LEGACY");
        LinearLayout.LayoutParams nativeP=new LinearLayout.LayoutParams(0,dp(35),1);nativeP.rightMargin=dp(5);
        globeControls.addView(originalToggle,nativeP);
        // Human-readable inspector belongs to the very same geo-viewport as live globe pins.
        selectedObservation=new LinearLayout(this);
        selectedObservation.setOrientation(LinearLayout.VERTICAL);
        selectedObservation.setPadding(dp(12),dp(9),dp(12),dp(10));
        selectedObservation.setBackground(bg(Color.argb(243,13,29,43),8,ACCENT));
        FrameLayout.LayoutParams inspectorParams=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM|Gravity.LEFT);
        inspectorParams.leftMargin=dp(12);inspectorParams.rightMargin=dp(12);inspectorParams.bottomMargin=dp(57);
        earthViewport.addView(selectedObservation,inspectorParams);
        selectedTitle=text("OBSERVATION",15,TEXT,true);selectedObservation.addView(selectedTitle);
        selectedDetail=text("Source is connecting",12,MUTED,false);selectedDetail.setMaxLines(3);selectedObservation.addView(selectedDetail);
        selectedAction=action("VIEW AIRCRAFT REGISTER","Open original observed aircraft record");
        selectedObservation.addView(selectedAction,new LinearLayout.LayoutParams(-1,dp(36)));
        selectedAction.setOnClickListener(v->{if(selectedItem!=null&&selectedItem.type==OperationsGlobeView.AIR){
            Intent i=new Intent(this,AircraftOperationsActivity.class);i.putExtra("query",selectedItem.title.trim());startActivity(i);
        }});
        selectedObservation.setVisibility(View.GONE);
        originalToggle.setOnClickListener(v->switchOriginalRenderer());
        // This control actually reflows the native globe viewport.
        TextView focusControl=action("FOCUS","Expand modern HD Earth globe full-screen");
        globeControls.addView(focusControl,new LinearLayout.LayoutParams(0,dp(35),1));
        earth.setOnObservationSelected(item->{selectedShareObservation=item;
            inspectObservation(item,false);
            detail.setText(item.title+"  •  "+item.detail+"  |  "+item.source+"  |  "+(item.timeMillis>0?utc(item.timeMillis)+" UTC":"TIME NOT SUPPLIED")
                +(item.type==OperationsGlobeView.AIR?"  •  TAP FOR AIRCRAFT INSPECTOR":""));
            detail.setOnClickListener(v->{
                if(item.type!=OperationsGlobeView.AIR)return;
                Intent i=new Intent(this,AircraftOperationsActivity.class);
                i.putExtra("query",item.title.trim());startActivity(i);
            });
        });
        TextView shareObserved=action("SHARE SELECTED OBSERVATION  /  SOURCE DATA","Export selected genuine aircraft, quake or satellite point");
        shareObserved.setTextColor(Color.rgb(216,244,248));
        shareObserved.setBackground(bg(Color.rgb(23,60,76),7,Color.rgb(91,194,211)));
        shareObserved.setGravity(Gravity.CENTER);
        globeFrame.addView(shareObserved,new LinearLayout.LayoutParams(-1,dp(39)));
        shareObserved.setOnClickListener(v->{OperationsGlobeView.Observation o=selectedShareObservation;
          if(o==null){android.widget.Toast.makeText(this,"Tap an observed marker first",android.widget.Toast.LENGTH_SHORT).show();return;}
          String type=o.type==OperationsGlobeView.AIR?"AIRCRAFT":o.type==OperationsGlobeView.QUAKE?"EARTHQUAKE":"SATELLITE / ISS";
          String url=o.type==OperationsGlobeView.AIR?"https://opensky-network.org/":o.type==OperationsGlobeView.QUAKE?"https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson":"https://api.wheretheiss.at/v1/satellites/25544";
          V115941ShareCards.share(this,type,o.title,o.detail,o.source,o.timeMillis,o.lat,o.lon,url,null);
        });
        TextView pulseEntry=action("MAPS  /  LIVE GEOSPATIAL DATA",
                "Source-observed aircraft, earthquakes, ISS and news; visual radar and point sharing");
        pulseEntry.setTextColor(Color.rgb(99,229,227));
        pulseEntry.setOnClickListener(v->startActivity(new Intent(this,DuwmPlaceMapActivity.class)));
        globeFrame.addView(pulseEntry,new LinearLayout.LayoutParams(-1,dp(43)));
        // P3 observed-position actions. No new or synthetic world markers.
        LinearLayout p3GlobeControls=new LinearLayout(this);
        p3GlobeControls.setPadding(dp(10),dp(2),dp(10),dp(3));
        p3GlobeControls.setGravity(Gravity.CENTER_VERTICAL);
        TextView p3Center=action("CENTER SELECTED","Smoothly focus globe on the selected real observation");
        TextView p3Map=action("VIEW ON MAP","Open selected observation coordinates in the real geographic map");
        LinearLayout.LayoutParams p3a=new LinearLayout.LayoutParams(0,dp(39),1);p3a.rightMargin=dp(4);
        p3GlobeControls.addView(p3Center,p3a);
        LinearLayout.LayoutParams p3b=new LinearLayout.LayoutParams(0,dp(39),1);p3b.leftMargin=dp(4);
        p3GlobeControls.addView(p3Map,p3b);
        globeFrame.addView(p3GlobeControls,new LinearLayout.LayoutParams(-1,dp(39)));
        p3Center.setOnClickListener(v->{
            OperationsGlobeView.Observation item=selectedShareObservation;
            if(item==null){
                android.widget.Toast.makeText(this,"Select an observed point first",android.widget.Toast.LENGTH_SHORT).show();return;
            }
            // Center the renderer actually visible on screen; the modern globe may be hidden.
            if(originalMode && originalEarth instanceof SatelliteMapView){inspectObservation(item,true);}
            else if(!earth.duwmP3FocusObservation(item)){
                android.widget.Toast.makeText(this,"Observation is no longer current",android.widget.Toast.LENGTH_SHORT).show();
            }
        });
        p3Map.setOnClickListener(v->{
            OperationsGlobeView.Observation item=selectedShareObservation;
            if(item==null || !Double.isFinite(item.lat) || !Double.isFinite(item.lon)){
                android.widget.Toast.makeText(this,"Select an observed point first",android.widget.Toast.LENGTH_SHORT).show();return;
            }
            Intent i=new Intent(this,DuwmPlaceMapActivity.class);
            i.putExtra("focus_lat",String.valueOf(item.lat));
            i.putExtra("focus_lon",String.valueOf(item.lon));
            startActivity(i);
        });
        LinearLayout layers=new LinearLayout(this);layers.setGravity(Gravity.CENTER_VERTICAL);layers.setPadding(dp(15),0,dp(12),0);rowAdd(globeFrame,layers,-1,35);
        airLayer=layer(layers,"AIRCRAFT",OperationsGlobeView.AIR);
        quakeLayer=layer(layers,"EARTHQUAKES",OperationsGlobeView.QUAKE);
        issLayer=layer(layers,"ISS",OperationsGlobeView.SPACE);
        detail=text("Drag to turn • pinch to zoom • tap an observed marker for details",11,MUTED,false);detail.setPadding(dp(16),dp(5),dp(16),dp(7));
        detail.setMaxLines(2);rowAdd(globeFrame,detail,-1,32);
        ScrollView infoScroll=new ScrollView(this);infoScroll.setFillViewport(false);root.addView(infoScroll,new LinearLayout.LayoutParams(-1,dp(0)));
        // Visible native observation board replaces the formerly truncated scroll of decorative metrics.
        // Older source cards stay in the view hierarchy for compatibility; all readings are sourced from the same payload.
        telemetryPanel=new OperationsTelemetryPanel(this);
        root.addView(telemetryPanel,new LinearLayout.LayoutParams(-1,dp(117)));
        focusControl.setOnClickListener(v->{
            fullEarth=!fullEarth;
            // The preserved native SatelliteMapView grows when the weighted frame remeasures.
            metadata.setVisibility(fullEarth?View.GONE:View.VISIBLE);
            scroller.setVisibility(fullEarth?View.GONE:View.VISIBLE);
            telemetryPanel.setVisibility(fullEarth?View.GONE:View.VISIBLE);
            layers.setVisibility(fullEarth?View.GONE:View.VISIBLE);
            detail.setVisibility(fullEarth?View.GONE:View.VISIBLE);
            focusControl.setText(fullEarth?"RESTORE":"FOCUS");
            focusControl.setContentDescription(fullEarth?"Restore source panels and tabs":"Expand modern HD Earth globe full-screen");
            globeLabel.setText(fullEarth?"MODERN HD EARTH  /  FULL-SCREEN LIVE GLOBE":
                originalMode?"ORIGINAL GLOBE  /  OBSERVED WORLD POSITIONS":"MODERN HD EARTH  /  OBSERVED WORLD POSITIONS");
            if(originalMode && originalEarth!=null){
                originalEarth.requestLayout();originalEarth.postInvalidateOnAnimation();
            }else{earth.requestLayout();earth.postInvalidateOnAnimation();}
        });
        telemetryPanel.setOnSelect(item->inspectObservation(item,true));
        LinearLayout information=new LinearLayout(this);information.setOrientation(LinearLayout.VERTICAL);information.setPadding(dp(13),dp(11),dp(13),dp(14));infoScroll.addView(information);
        LinearLayout titleRow=new LinearLayout(this);titleRow.setGravity(Gravity.CENTER_VERTICAL);information.addView(titleRow,new LinearLayout.LayoutParams(-1,dp(32)));
        TextView section=text("OBSERVATION STATUS / LIVE RECEIPTS",12,TEXT,true);titleRow.addView(section,new LinearLayout.LayoutParams(0,-2,1));
        TextView refresh=action("REFRESH","Request updated observed records");rowAdd(titleRow,refresh,94,36);refresh.setOnClickListener(v->refresh());
        summaryText=text("No remote source has responded",11,MUTED,false);summaryText.setPadding(dp(2),dp(7),0,dp(9));information.addView(summaryText);
        android.widget.HorizontalScrollView metricScroll=new android.widget.HorizontalScrollView(this);metricScroll.setHorizontalScrollBarEnabled(false);
        information.addView(metricScroll,new LinearLayout.LayoutParams(-1,dp(104)));
        LinearLayout cards=new LinearLayout(this);metricScroll.addView(cards);
        LinearLayout airCard=metric(cards,"AIRCRAFT / OPENSKY");duwm1166AirLed=new Duwm1166SignalView(this);airCard.addView(duwm1166AirLed,new LinearLayout.LayoutParams(dp(27),dp(22)));airCount=text("—",19,TEXT,true);airCard.addView(airCount);airSource=text("NOT CHECKED",10,MUTED,false);airSource.setMaxLines(2);airCard.addView(airSource);
        LinearLayout quakeCard=metric(cards,"QUAKES / USGS");duwm1166QuakeLed=new Duwm1166SignalView(this);quakeCard.addView(duwm1166QuakeLed,new LinearLayout.LayoutParams(dp(27),dp(22)));quakeCount=text("—",19,TEXT,true);quakeCard.addView(quakeCount);quakeSource=text("NOT CHECKED",10,MUTED,false);quakeSource.setMaxLines(2);quakeCard.addView(quakeSource);
        LinearLayout issCard=metric(cards,"ISS / OBSERVED");duwm1166IssLed=new Duwm1166SignalView(this);issCard.addView(duwm1166IssLed,new LinearLayout.LayoutParams(dp(27),dp(22)));issCount=text("—",19,TEXT,true);issCard.addView(issCount);issSource=text("NOT CHECKED",10,MUTED,false);issSource.setMaxLines(2);issCard.addView(issSource);
        LinearLayout seaCard=metric(cards,"VESSELS / AIS");Duwm1166SignalView vesselLed=new Duwm1166SignalView(this);
        vesselLed.source("VESSEL",0,0,false,false);seaCard.addView(vesselLed,new LinearLayout.LayoutParams(dp(27),dp(22)));
        TextView vesselCount=text("—",19,TEXT,true);seaCard.addView(vesselCount);
        seaCard.addView(text("FINNISH AIS  •  SEE SOURCE BOARD",10,MUTED,false));
        seaCard.setOnClickListener(v->{Intent i=new Intent(this,Duwm1166RecordsActivity.class);i.putExtra("kind","VESSELS");startActivity(i);});
        TextView foot=text("Source counts and markers are based on received records. An unavailable feed is not evidence of no activity. AIS vessels and embedded cameras require approved providers.",11,MUTED,false);
        foot.setPadding(dp(3),dp(12),dp(3),dp(8));information.addView(foot);
        TextView original=action("ORIGINAL COMMAND  /  ALL LEGACY TOOLS","Open the preserved command centre in this same app");
        information.addView(original,new LinearLayout.LayoutParams(-1,dp(48)));original.setOnClickListener(v->{Intent i=new Intent(this,MainActivity.class);startActivity(i);});
        // V1159.4: MODERN HD globe remains the first screen. Protected original is optional.
        earth.setVisibility(View.VISIBLE);
        originalHud.setVisibility(View.GONE);
        // 1165 DETAIL RESTORE: show the actual high-resolution Natural Earth coastline
        // renderer on first launch. The alternate legacy Canvas globe remains available
        // via the LEGACY button, but must not replace the preferred detailed Earth.
        // Do not call switchOriginalRenderer() on startup: it installs simplified
        // LAND_MASSES polygons and white triangle flight icons over the detailed coast.
        originalMode=false;
        earth.setVisibility(View.VISIBLE);
        originalHud.setVisibility(View.GONE);
        earth.postInvalidateOnAnimation();
    }
    /** Reuse the actual original native SatelliteMapView in the same screen, without copying or replacing it.
     * Original legacy globe and wallpaper code are kept intact. This fails visibly when the old renderer
     * requires application-specific setup; it never substitutes invented positions.
     */
    private void inspectObservation(OperationsGlobeView.Observation item,boolean focus){
        if(item==null)return;
        // The original view remains available, but geolocating always uses the real observation-aware globe.
        // Keep the actual original globe on-screen even when locating a source observation.
        selectedItem=item;
        String sector=item.type==OperationsGlobeView.AIR?"AIRCRAFT":item.type==OperationsGlobeView.QUAKE?"EARTHQUAKE":"ISS SATELLITE";
        selectedTitle.setText(sector+"  /  "+item.title);
        selectedDetail.setText(item.detail+"  •  "+item.source+"  •  "+(item.timeMillis>0?utc(item.timeMillis)+" UTC":"SOURCE TIME UNKNOWN"));
        selectedAction.setVisibility(item.type==OperationsGlobeView.AIR?View.VISIBLE:View.GONE);
        selectedObservation.setVisibility(View.VISIBLE);
        detail.setText("LOCATED "+item.title+"  •  "+String.format(Locale.US,"%.4f°, %.4f°",item.lat,item.lon));
        if(focus){
            if(originalMode && originalEarth instanceof SatelliteMapView){
                SatelliteMapView nativeGlobe=(SatelliteMapView)originalEarth;
                // The coordinates are supplied by OpenSky, USGS or the observed ISS source.
                nativeGlobe.setCenter(item.lat,item.lon,nativeGlobe.getZoom());
                nativeGlobe.setGlobeMode(true);
                nativeGlobe.invalidate();
            }else{
                rotate=false;rotationControl.setText("ROTATION  OFF");earth.pause();earth.focusAt(item.lat,item.lon);
            }
        }
    }
    private final List<OperationsGlobeView.Observation> earthObservations=new ArrayList<>();
    /** Adapt only received geolocated source records for the protected original globe renderer.
     * Never create random aircraft, approximate positions or invented timestamps. */
    private List<Signal> toNativeSignals(List<OperationsGlobeView.Observation> received){
        List<Signal> plotted=new ArrayList<>();
        for(OperationsGlobeView.Observation a:received){
            if(a==null||a.timeMillis<=0||!valid(a.lat,a.lon))continue;
            if(a.type==OperationsGlobeView.AIR&&!viewAir)continue;
            if(a.type==OperationsGlobeView.QUAKE&&!viewQuakes)continue;
            if(a.type==OperationsGlobeView.SPACE&&!viewIss)continue;
            Signal.Layer layer=a.type==OperationsGlobeView.AIR?Signal.Layer.FLIGHTS:
                a.type==OperationsGlobeView.QUAKE?Signal.Layer.NATURAL:Signal.Layer.SATELLITES;
            String url=a.type==OperationsGlobeView.AIR?"https://opensky-network.org/":
                a.type==OperationsGlobeView.QUAKE?"https://earthquake.usgs.gov/":"https://wheretheiss.at/";
            // Unknown speed and heading remain unknown; 0 would incorrectly imply observed stationarity.
            String id="observed-"+a.type+"-"+a.title+"-"+(a.type==OperationsGlobeView.AIR?a.source:a.timeMillis);
            plotted.add(new Signal(id,layer,a.title,a.detail,a.lat,a.lon,
                Double.NaN,Double.NaN,a.timeMillis,a.source,url,Signal.Credibility.PUBLIC_SOURCE,
                "","OBSERVED_SOURCE_RECORD",0,java.util.Collections.emptyMap()));
        }
        return plotted;
    }
    private void switchOriginalRenderer(){
        if(originalMode){
            if(originalEarth!=null){earthViewport.removeView(originalEarth);originalEarth=null;}
            earth.setVisibility(View.VISIBLE);originalMode=false;
            originalHud.setVisibility(View.GONE);
            rotationControl.setText(rotate?"ROTATION  ON":"ROTATION  OFF");
            originalToggle.setText("LEGACY");
            originalToggle.setContentDescription("Switch to alternate legacy globe for comparison");
            if(foreground&&rotate)earth.resume();
            return;
        }
        try{
            Class<?> type=Class.forName("com.sentongoharuna.worldsituationroom.SatelliteMapView");
            Object instance=null;
            try {Constructor<?> ctor=type.getDeclaredConstructor(android.content.Context.class);ctor.setAccessible(true);instance=ctor.newInstance(this);}
            catch(NoSuchMethodException missing){
                Constructor<?> ctor=type.getDeclaredConstructor(android.content.Context.class,AttributeSet.class);
                ctor.setAccessible(true);instance=ctor.newInstance(this,null);
            }
            if(!(instance instanceof SatelliteMapView))throw new IllegalStateException("Original globe renderer not found");
            SatelliteMapView nativeGlobe=(SatelliteMapView)instance;
            // Verified original V24 class has a dedicated full-sphere globe mode and its own rotation engine.
            nativeGlobe.setGlobeMode(true);
            nativeGlobe.setAutoRotationEnabled(rotate);
            // Restore exact-record tapping on the original detailed globe.
            // Only a source observation already present in this app may be shared.
            nativeGlobe.setListener(new SatelliteMapView.Listener(){
                @Override public void onSignalTap(Signal signal){
                    if(signal==null)return;
                    for(OperationsGlobeView.Observation observed:earthObservations){
                        if(observed==null || observed.title==null)continue;
                        if(observed.title.equals(signal.title) &&
                           Math.abs(observed.lat-signal.latitude)<0.0001d &&
                           Math.abs(observed.lon-signal.longitude)<0.0001d){
                            selectedShareObservation=observed;
                            inspectObservation(observed,false);
                            return;
                        }
                    }
                    detail.setText("SOURCE SIGNAL / "+signal.title+" / no matching current observation to share");
                }
                @Override public void onViewportChanged(SatelliteMapView.Bounds bounds){}
            });
            originalEarth=nativeGlobe;
            earth.pause();earth.setVisibility(View.GONE);
            earthViewport.addView(originalEarth,0,new FrameLayout.LayoutParams(-1,-1));
            originalHud.setVisibility(View.GONE);
            originalMode=true;originalToggle.setText("DETAILED");
            originalToggle.setContentDescription("Return to preferred detailed Earth globe");
            rotationControl.setText(rotate?"ROTATION ON":"ROTATION OFF");
            nativeGlobe.setSignals(toNativeSignals(earthObservations));
            nativeGlobe.invalidate();
            liveReadout.setText("ORIGINAL GLOBE  /  OBSERVED DATA  /  NATIVE MOTION");
        }catch(Exception ex){
            if(originalEarth!=null)earthViewport.removeView(originalEarth);
            originalMode=false;originalEarth=null;earth.setVisibility(View.VISIBLE);originalHud.setVisibility(View.VISIBLE);
            originalToggle.setText("ORIGINAL VIEW FAILED");rotationControl.setText("OFFLINE");
            if(foreground&&rotate)earth.resume();
            String msg=ex.getCause()!=null?ex.getCause().getClass().getSimpleName():ex.getClass().getSimpleName();
            liveReadout.setText("ORIGINAL VIEW UNAVAILABLE: "+msg);
        }
    }
    private TextView layer(LinearLayout parent,String label,int type){TextView v=text("● "+label,11,type==OperationsGlobeView.AIR?ACCENT:type==OperationsGlobeView.QUAKE?WARN:Color.rgb(162,203,170),true);
        v.setGravity(Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(44),type==OperationsGlobeView.QUAKE?1.25f:1);parent.addView(v,p);
        v.setContentDescription("Toggle " + label + " map layer");v.setOnClickListener(w->{boolean next;if(type==OperationsGlobeView.AIR){viewAir=!viewAir;next=viewAir;}
            else if(type==OperationsGlobeView.QUAKE){viewQuakes=!viewQuakes;next=viewQuakes;}else {viewIss=!viewIss;next=viewIss;}
            earth.showLayer(type,next);v.setAlpha(next?1f:.35f);
            if(telemetryPanel!=null)telemetryPanel.setVisibilityLayers(viewAir,viewQuakes,viewIss);
            if(originalMode&&originalEarth instanceof SatelliteMapView){
                ((SatelliteMapView)originalEarth).setSignals(toNativeSignals(earthObservations));
            }});return v;}
    private void applyFocus(Intent intent){
        if(earth==null||intent==null||!intent.hasExtra("focus_lat")||!intent.hasExtra("focus_lon"))return;
        double lat=intent.getDoubleExtra("focus_lat",Double.NaN),lon=intent.getDoubleExtra("focus_lon",Double.NaN);
        if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)return;
        rotate=false;rotationControl.setText("ROTATION  OFF");earth.pause();earth.focusAt(lat,lon);
        detail.setText(intent.getStringExtra("focus_label")+"  |  "+String.format(Locale.US,"%.4f°, %.4f°",lat,lon));
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);applyFocus(intent);}
    @Override protected void onResume(){super.onResume();foreground=true;applyFocus(getIntent());
        if(newRail!=null)newRail.resume();
        if(rotate&&!originalMode)earth.resume();
        if(originalMode&&originalEarth!=null)originalEarth.postInvalidateOnAnimation();
        main.post(second);
    }
    @Override protected void onPause(){foreground=false;if(newRail!=null)newRail.pause();earth.pause();main.removeCallbacks(second);super.onPause();}
    @Override protected void onDestroy(){network.shutdownNow();super.onDestroy();}

    private String get(String address,int limit) throws Exception {
        if(!address.startsWith("https://"))throw new java.io.IOException("HTTPS required");
        HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);
        c.setRequestProperty("User-Agent","DevelopUgandaOperations/1155");c.setRequestProperty("Accept","application/json");
        try{int code=c.getResponseCode();if(code!=200)throw new java.io.IOException("HTTP "+code);
            StringBuilder s=new StringBuilder();try(InputStream in=c.getInputStream();BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"))){
                char[] buf=new char[4096];int n;while((n=r.read(buf))!=-1){s.append(buf,0,n);if(s.length()>limit)throw new java.io.IOException("Response exceeds source limit");}}
            return s.toString();
        }finally{c.disconnect();}
    }
    private boolean valid(double lat,double lon){return Double.isFinite(lat)&&Double.isFinite(lon)&&lat>=-90&&lat<=90&&lon>=-180&&lon<=180;}
    private String error(Exception ex){String e=ex.getMessage();if(e==null)e=ex.getClass().getSimpleName();return e.length()>65?e.substring(0,65):e;}
    private void refresh(){if(!fetching.compareAndSet(false,true))return;lastAttempt=SystemClock.elapsedRealtime();
        headerStatus.setText("SYNCING");summaryText.setText("Requesting observed records from source providers…");
        if(telemetryPanel!=null)telemetryPanel.setSyncing();
        network.execute(()->{
            List<OperationsGlobeView.Observation> observations=new ArrayList<>();
            int sourceOk=0,sourceCount=3, aircraftReported=0,located=0,quakesReported=0;
            String air="NO RESPONSE",quake="NO RESPONSE",iss="NO RESPONSE",issValue="—";
            String aircraftValue="—",quakeValue="—";
            try{
                JSONObject payload=new JSONObject(get("https://opensky-network.org/api/states/all",6500000));
                AirTrackStore.publish(payload); // Same real OpenSky snapshot powers globe and searchable register.
                JSONArray a=payload.optJSONArray("states");if(a==null)throw new java.io.IOException("States array absent");
                aircraftReported=a.length();int skip=Math.max(1,a.length()/900);long observedTime=payload.optLong("time",0)*1000L;
                for(int i=0;i<a.length();i++){JSONArray x=a.optJSONArray(i);if(x==null||x.isNull(5)||x.isNull(6))continue;
                    double lon=x.optDouble(5,Double.NaN),lat=x.optDouble(6,Double.NaN);if(!valid(lat,lon))continue;located++;
                    if(i%skip!=0)continue;String callsign=x.optString(1,"").trim();String ident=x.optString(0,"");if(callsign.isEmpty())callsign=ident;
                    double altitude=x.optDouble(7,Double.NaN),speed=x.optDouble(9,Double.NaN);
                    String info=String.format(Locale.US,"%.3f°, %.3f° • alt %s • speed %s",lat,lon,Double.isFinite(altitude)?String.format(Locale.US,"%.0f m",altitude):"unknown",Double.isFinite(speed)?String.format(Locale.US,"%.0f m/s",speed):"unknown");
                    observations.add(new OperationsGlobeView.Observation(OperationsGlobeView.AIR,lat,lon,callsign,info,"OpenSky",observedTime));
                }
                sourceOk++;aircraftValue=String.format(Locale.US,"%,d",aircraftReported);
                air="Observed "+(observedTime>0?utc(observedTime)+" UTC":"UTC not supplied");
            }catch(Exception ex){air="Unavailable: "+error(ex);}
            try{
                JSONObject payload=new JSONObject(get("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson",1500000));
                JSONArray arr=payload.getJSONArray("features");quakesReported=arr.length();
                for(int i=0;i<Math.min(arr.length(),350);i++){JSONObject event=arr.optJSONObject(i);if(event==null)continue;
                    JSONObject g=event.optJSONObject("geometry"),prop=event.optJSONObject("properties");if(g==null||prop==null)continue;
                    JSONArray coords=g.optJSONArray("coordinates");if(coords==null||coords.length()<2)continue;
                    double lon=coords.optDouble(0,Double.NaN),lat=coords.optDouble(1,Double.NaN);if(!valid(lat,lon))continue;
                    String title="M"+String.format(Locale.US,"%.1f",prop.optDouble("mag",0)) + "  "+prop.optString("place","location not reported");
                    observations.add(new OperationsGlobeView.Observation(OperationsGlobeView.QUAKE,lat,lon,title,String.format(Locale.US,"%.3f°, %.3f°",lat,lon),"USGS",prop.optLong("time",0)));
                }
                sourceOk++;quakeValue=Integer.toString(quakesReported);quake="M4.5+ / last 24 h";
            }catch(Exception ex){quake="Unavailable: "+error(ex);}
            try{
                JSONObject data=new JSONObject(get("https://api.wheretheiss.at/v1/satellites/25544",85000));
                double lat=data.optDouble("latitude",Double.NaN),lon=data.optDouble("longitude",Double.NaN);
                long seen=data.optLong("timestamp",0)*1000L;
                if(!valid(lat,lon)||seen<=0||Math.abs(System.currentTimeMillis()-seen)>900000L)throw new java.io.IOException("Stale or missing reported position");
                observations.add(new OperationsGlobeView.Observation(OperationsGlobeView.SPACE,lat,lon,"ISS — International Space Station",String.format(Locale.US,"%.3f°, %.3f° • altitude %.1f km",lat,lon,data.optDouble("altitude",0)),"Where The ISS At",seen));
                issValue="POSITION";iss="Observed "+utc(seen)+" UTC";sourceOk++;
            }catch(Exception ex){iss="Unavailable: "+error(ex);}
            final String fa=air,fq=quake,fi=iss,fav=aircraftValue,fqv=quakeValue,fiv=issValue;
            final int ok=sourceOk, plotted=observations.size(),validPositions=located,totalAir=aircraftReported,totalQuakes=quakesReported;
            main.post(()->{fetching.set(false);if(isFinishing()||isDestroyed())return;
                airCount.setText(fav);quakeCount.setText(fqv);issCount.setText(fiv);
                airSource.setText(fa);quakeSource.setText(fq);issSource.setText(fi);
                long lastAir=0,lastQuake=0,lastISS=0;
                for(OperationsGlobeView.Observation report:observations){
                  if(report.type==OperationsGlobeView.AIR)lastAir=Math.max(lastAir,report.timeMillis);
                  else if(report.type==OperationsGlobeView.QUAKE)lastQuake=Math.max(lastQuake,report.timeMillis);
                  else if(report.type==OperationsGlobeView.SPACE)lastISS=Math.max(lastISS,report.timeMillis);
                }
                long reportedAt=System.currentTimeMillis();
                duwm1166AirLed.source("AIRCRAFT",lastAir,fa.startsWith("Unavailable")?0:reportedAt,false,fa.startsWith("Unavailable"));
                duwm1166QuakeLed.source("EARTHQUAKE",lastQuake,fq.startsWith("Unavailable")?0:reportedAt,false,fq.startsWith("Unavailable"));
                duwm1166IssLed.source("ISS",lastISS,fi.startsWith("Unavailable")?0:reportedAt,false,fi.startsWith("Unavailable"));
                // 1668: make the same real provider fixes available to the optional geo lens.
                // Never publish an empty or failed provider response as a synthetic record.
                for(String kind:new String[]{"AIRCRAFT","EARTHQUAKE","ISS"}){
                    ArrayList<DuwmGeoObservationStore.Fix> fresh=new ArrayList<>();
                    for(OperationsGlobeView.Observation o:observations){
                        String observedKind=o.type==OperationsGlobeView.AIR?"AIRCRAFT":
                            o.type==OperationsGlobeView.QUAKE?"EARTHQUAKE":"ISS";
                        if(!kind.equals(observedKind)||o.timeMillis<=0)continue;
                        String providerUrl=kind.equals("AIRCRAFT")?"https://opensky-network.org/":
                            kind.equals("EARTHQUAKE")?"https://earthquake.usgs.gov/":"https://wheretheiss.at/";
                        String stableId=kind+":"+o.source+":"+o.title+
                            (kind.equals("EARTHQUAKE")?":"+o.timeMillis:"");
                        if(fresh.size()>=155)break; // reserve space for other actual source types
                        fresh.add(new DuwmGeoObservationStore.Fix(stableId,kind,o.title,o.detail,
                            o.source,providerUrl,o.timeMillis,reportedAt,o.lat,o.lon,null,null,0));
                    }
                    if(!fresh.isEmpty())DuwmGeoObservationStore.publishType(this,kind,fresh);
                }
                earth.setObservations(observations);
                earthObservations.clear();earthObservations.addAll(observations);
                if(originalMode && originalEarth instanceof SatelliteMapView){
                    ((SatelliteMapView)originalEarth).setSignals(toNativeSignals(earthObservations));
                }
                if(telemetryPanel!=null)telemetryPanel.update(observations,ok,totalAir,totalQuakes,fa,fq,fi,System.currentTimeMillis());
                liveReadout.setText((originalMode?"ORIGINAL NATIVE GLOBE  /  ":"LIVE EARTH  /  ")+ok+"/3 SOURCES  •  "+plotted+" VERIFIED PINS");
                headerStatus.setText(ok>0?ok+"/3 READY":"OFFLINE");
                sourceHeartbeat.setText(ok>0?(ok+"/3 SOURCES  ·  "+plotted+" VERIFIED LOCATIONS"):
                   "NO SOURCE RESPONSE");
                sourceHeartbeat.setContentDescription(ok>0?("Source receipts: "+ok+" of 3 providers connected, "+plotted+" observed locations"):
                   "No source responded. Counts are not zero observations.");
                updatedText.setText(ok>0?"SYNC " + utc(System.currentTimeMillis()).substring(12)+" UTC":"SOURCE UNAVAILABLE");
                summaryText.setText(ok+" of "+sourceCount+" providers responded • "+plotted+" mapped observations • "+validPositions+" located aircraft of "+totalAir+" reported");
            });
        });
    }
}
