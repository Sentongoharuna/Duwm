package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;

/** Selectable live-source aircraft map. Movement is interpolation ONLY between reported fixes.
 * Source can be 15+ minutes old; redraw does not suggest current position. ETA uses optional
 * manually selected airport, not undisclosed actual origin/destination or a published timetable.
 */
public final class Duwm1670FlightMapActivity extends Activity {
  private static final int BG=0xFF07121E,WHITE=0xFFEAF7FB,MUTED=0xFF9BB9C7,CYAN=0xFF56D5E2,AMBER=0xFFE8BC73;
  private static final String[] REGION={"WORLD","AFRICA","EUROPE","MIDDLE EAST","INDIA / ASIA","AMERICAS","PACIFIC"};
  private static final double[][] TARGETS={{0,0},{2.0,22.0},{51,12},{25,46},{24,82},{40,-92},{-15,150}};
  private static final String[] AIRPORTS={"NO DESTINATION PROVIDED","EBB • Entebbe","NBO • Nairobi","DXB • Dubai","DOH • Doha","LHR • London Heathrow","DEL • Delhi","JNB • Johannesburg","JFK • New York","ADD • Addis Ababa","AMS • Amsterdam","SIN • Singapore"};
  private static final double[][] AIRPORT_GEO={{0,0},{0.042,32.443},{-1.319,36.927},{25.253,55.364},{25.273,51.608},{51.470,-0.454},{28.556,77.100},{-26.139,28.246},{40.641,-73.778},{8.978,38.799},{52.31,4.764},{1.364,103.99}};
  private final Handler ui=new Handler(Looper.getMainLooper());private boolean active;
  private Duwm1670WorldMapView map;private TextView source,details,summary;
  private Duwm1670WorldMapView.Pin chosen;
  private long sourceAt;
  private String activeRegion="WORLD",displayedKey="";
  private int destIndex=0;
  private final Runnable tick=new Runnable(){@Override public void run(){if(!active)return;render();ui.postDelayed(this,14000);}};
  private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}
  private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
  private GradientDrawable frame(){GradientDrawable d=new GradientDrawable();d.setColor(0xFF10283A);d.setCornerRadius(dp(10));d.setStroke(dp(1),0xFF356178);return d;}
  private TextView button(String s,Runnable fn){TextView v=text(s,12,CYAN);v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setGravity(Gravity.CENTER);v.setPadding(dp(8),dp(11),dp(8),dp(11));v.setBackground(frame());v.setOnClickListener(w->fn.run());return v;}
  private Spinner spinner(String[] opts){Spinner spin=new Spinner(this);ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,opts);a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);spin.setAdapter(a);spin.setBackground(frame());return spin;}
  private String utc(long ms){if(ms<=0)return "NO PROVIDER TIMESTAMP";SimpleDateFormat d=new SimpleDateFormat("dd MMM HH:mm:ss 'UTC'",Locale.US);d.setTimeZone(TimeZone.getTimeZone("UTC"));return d.format(new Date(ms));}
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);setContentView(scroll);Duwm1167SafeArea.install(this,scroll);
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(12),dp(12),dp(12),dp(25));scroll.addView(root);
    TextView head=text("DEVELOP.UGANDA   /   AIR TRAFFIC INTELLIGENCE",13,CYAN);head.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(head);
    TextView title=text("WORLD AIRCRAFT TRACKER",24,WHITE);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(title);
    root.addView(text("Real reported positions • moving two-fix transitions • borders from geographic data",11,MUTED));
    summary=text("REQUESTING AIRCRAFT SOURCE STATUS",12,WHITE);summary.setPadding(0,dp(12),0,dp(9));root.addView(summary);
    source=text("NO RECEIPT",11,AMBER);root.addView(source);
    LinearLayout actions=new LinearLayout(this);root.addView(actions);
    actions.addView(button("REFRESH SOURCE",()->{RunningballV25GlobalAircraftData.refresh(this,this::render);source.setText("Refresh requested; rate limits and cached data are respected.");}),new LinearLayout.LayoutParams(0,dp(45),1));
    TextView back=button("ORIGINAL GLOBE",()->startActivity(new Intent(this,OperationsMainActivity.class)));
    LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(45),1);bp.leftMargin=dp(7);actions.addView(back,bp);
    TextView lbl=text("SELECT WORLD REGION",12,AMBER);lbl.setPadding(0,dp(12),0,0);root.addView(lbl);
    Spinner region=spinner(REGION);root.addView(region,new LinearLayout.LayoutParams(-1,dp(48)));
    region.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
      @Override public void onItemSelected(AdapterView<?> p,View v,int position,long id){activeRegion=REGION[position];
        if(map!=null){if(position==0)map.reset();else map.focus(TARGETS[position][0],TARGETS[position][1],2.15f);}}
      @Override public void onNothingSelected(AdapterView<?> p){} });
    map=new Duwm1670WorldMapView(this);map.setLayer("AIRCRAFT");
    map.setOnPinSelected(pin->{chosen=pin;map.setSelected(pin.id);showSelected();});
    LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(340));mp.topMargin=dp(9);root.addView(map,mp);
    TextView note=text("DRAG / PINCH MAP   •   TAP AIRCRAFT MARKER   •   LINES JOIN TWO RECEIVED OBSERVATIONS, NOT A SCHEDULED ROUTE",10,MUTED);
    note.setPadding(0,dp(8),0,dp(10));root.addView(note);
    details=text("Select one aircraft marker for real altitude, ground speed, heading and coordinates.",12,WHITE);details.setPadding(dp(12),dp(11),dp(12),dp(11));details.setBackground(frame());root.addView(details);
    TextView dest=text("DESTINATION SCENARIO  /  USER SELECTED (NOT ACTUAL FLIGHT ROUTE)",11,AMBER);dest.setPadding(0,dp(12),0,dp(4));root.addView(dest);
    Spinner airports=spinner(AIRPORTS);root.addView(airports,new LinearLayout.LayoutParams(-1,dp(49)));
    airports.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
      @Override public void onItemSelected(AdapterView<?> p,View v,int pos,long id){destIndex=pos;
        if(map!=null){if(destIndex>0)map.setScenarioDestination(AIRPORT_GEO[destIndex][0],AIRPORT_GEO[destIndex][1],AIRPORTS[destIndex]);
          else map.clearScenario();}showSelected();}
      @Override public void onNothingSelected(AdapterView<?> p){} });
    LinearLayout foot=new LinearLayout(this);foot.setOrientation(LinearLayout.HORIZONTAL);root.addView(foot);
    foot.addView(button("FLIGHT REGISTER",()->startActivity(new Intent(this,RunningballV25FlightRegisterActivity.class))),new LinearLayout.LayoutParams(0,dp(48),1));
    TextView local=button("LOCAL RADAR 250 NM",()->startActivity(new Intent(this,AirRadarActivity.class)));
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1);lp.leftMargin=dp(7);foot.addView(local,lp);
    root.addView(text("DATA: OpenSky /states/all. Does not provide commercial flight origins, actual destinations, schedules or verified ETAs. No simulated aircraft are generated.",11,MUTED));
    render();
  }
  private static double distanceKm(double la1,double lo1,double la2,double lo2){double rla=Math.toRadians(la2-la1),rlo=Math.toRadians(lo2-lo1);
    double a=Math.pow(Math.sin(rla/2),2)+Math.cos(Math.toRadians(la1))*Math.cos(Math.toRadians(la2))*Math.pow(Math.sin(rlo/2),2);
    return 6371.0088*2*Math.asin(Math.min(1,Math.sqrt(a)));
  }
  private void showSelected(){if(details==null)return;
    if(chosen==null){details.setText("TAP AN AIRCRAFT TO SEE REAL TELEMETRY. Destination ETA is unavailable until an airport is chosen as a hypothetical scenario.");return;}
    Duwm1670WorldMapView.Pin p=chosen;String speed=Double.isFinite(p.speed)?String.format(Locale.US,"%.0f km/h",p.speed*3.6d):"NOT REPORTED";
    String alt=Double.isFinite(p.altitude)?String.format(Locale.US,"%.0f m",p.altitude):"NOT REPORTED";
    String heading=Double.isFinite(p.heading)?String.format(Locale.US,"%.0f°",p.heading):"NOT REPORTED";
    String eta="ACTUAL DESTINATION AND ETA: UNAVAILABLE FROM THIS PROVIDER";
    if(destIndex>0){double d=distanceKm(p.lat,p.lon,AIRPORT_GEO[destIndex][0],AIRPORT_GEO[destIndex][1]);
      if(Double.isFinite(p.speed)&&p.speed>35d){long mins=Math.round(d/(p.speed*3.6d)*60d);
        eta=String.format(Locale.US,"ASSUMED DESTINATION %s  /  %.0f KM GREAT-CIRCLE  /  ~%d H %02d MIN AT REPORTED SPEED\nSCENARIO ONLY · NOT ACTUAL ROUTE, NOT SCHEDULED ETA",AIRPORTS[destIndex],d,mins/60,mins%60);
      }else eta="ASSUMED DESTINATION "+AIRPORTS[destIndex]+" / SPEED UNAVAILABLE FOR ETA SCENARIO";
    }
    details.setText(p.title+"   /   "+p.id+"\n"+String.format(Locale.US,"POSITION %.4f°, %.4f°",p.lat,p.lon)+"\nGROUND SPEED "+speed+"   •   ALT "+alt+"   •   HEADING "+heading+"\nOBSERVED "+utc(p.observed)+"\n"+eta);
  }
  private void render(){if(map==null)return;
    RunningballV25GlobalAircraftData.Snapshot snap=RunningballV25GlobalAircraftData.read(this);
    ArrayList<Duwm1670WorldMapView.Pin> fresh=new ArrayList<>();HashMap<String,JSONArray> previous=new HashMap<>();
    if(snap.priorSourceAt>0&&snap.sourceAt>snap.priorSourceAt&&snap.sourceAt-snap.priorSourceAt<=5400000L)
      for(int i=0;i<snap.priorPoints.length();i++){JSONArray r=snap.priorPoints.optJSONArray(i);if(r!=null)previous.put(r.optString(2,""),r);}
    boolean visible=snap.hasGood()&&snap.ageMs()<=21600000L;
    JSONArray rows=visible?snap.points:new JSONArray();
    for(int i=0;i<rows.length()&&fresh.size()<2500;i++){
      JSONArray row=rows.optJSONArray(i);if(row==null)continue;
      double lat=row.optDouble(0,Double.NaN),lon=row.optDouble(1,Double.NaN);String hex=row.optString(2,"").trim();
      if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180||hex.isEmpty())continue;
      String callsign=row.optString(3,"").trim();long at=row.isNull(7)?snap.sourceAt:row.optLong(7,0L)*1000L;
      Duwm1670WorldMapView.Pin pin=new Duwm1670WorldMapView.Pin(hex,callsign.isEmpty()?hex:callsign,"AIRCRAFT",lat,lon,at,"OPENSKY RECEIVED POSITION");
      if(!row.isNull(4))pin.altitude=row.optDouble(4,Double.NaN);
      if(!row.isNull(5))pin.speed=row.optDouble(5,Double.NaN);
      if(!row.isNull(6))pin.heading=row.optDouble(6,Double.NaN);
      JSONArray before=previous.get(hex);
      if(before!=null){double a=before.optDouble(0,Double.NaN),b=before.optDouble(1,Double.NaN);
        long old=before.isNull(7)?snap.priorSourceAt:before.optLong(7,0)*1000L;
        if(Double.isFinite(a)&&Double.isFinite(b)&&old>0&&at>old&&at-old<=5400000L&&
          RunningballV25AircraftTrailPolicy.qualifies(hex,hex,a,b,lat,lon,old/1000L,at/1000L,snap.priorSourceAt,snap.sourceAt)){
          pin.prevLat=a;pin.prevLon=b;pin.prevObserved=old;
        }
      }
      fresh.add(pin);
    }
    String key=snap.sourceAt+":"+snap.priorSourceAt+":"+fresh.size();boolean changed=!key.equals(displayedKey);displayedKey=key;
    map.setPins(fresh,changed);
    sourceAt=snap.sourceAt;
    summary.setText((snap.hasGood()?snap.countLabel():"--")+" PROVIDER RECORDS  /  "+fresh.size()+" MAP POSITIONS  /  "+map.observedPairCount()+" TWO-FIX DISPLACEMENTS");
    source.setText("OPENSKY  •  "+snap.status()+"  •  "+snap.ageLabel()+"  •  SOURCE "+utc(sourceAt)+"  •  NEXT FETCH "+snap.nextCheckLabel());
    source.setTextColor(snap.ageMs()<1200000L&&snap.error.isEmpty()?CYAN:AMBER);
    if(chosen!=null){Duwm1670WorldMapView.Pin replacement=null;for(Duwm1670WorldMapView.Pin pin:fresh)if(pin.id.equals(chosen.id)){replacement=pin;break;}
      chosen=replacement;if(chosen!=null)map.setSelected(chosen.id);}
    showSelected();
  }
  @Override protected void onResume(){super.onResume();active=true;if(map!=null)map.resume();ui.removeCallbacks(tick);ui.post(tick);
    RunningballV25GlobalAircraftData.refresh(this,()->{if(active)render();});}
  @Override protected void onPause(){active=false;ui.removeCallbacks(tick);if(map!=null)map.pause();super.onPause();}
}
