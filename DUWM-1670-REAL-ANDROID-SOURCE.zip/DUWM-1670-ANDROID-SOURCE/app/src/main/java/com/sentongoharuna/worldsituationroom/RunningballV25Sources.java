package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.Locale;
/** Independent Stage 1 read-only adapters to the unchanged V24 provider caches.
    A reported count is not a claim of global, complete or simultaneous observations. */
public final class RunningballV25Sources {
  private RunningballV25Sources(){}
  public enum Status {LIVE, DELAYED, STALE, OFFLINE_CACHE, NOT_CONFIGURED, FAILED, NO_DATA_FOR_REGION}
  public static final String[] IDS={"air","sat","sea","quake","event","news","weather","fx","kp"};
  public static final String[] NAMES={"AIRCRAFT","SATELLITES","MARITIME","EARTHQUAKES","NASA EVENTS","WORLD NEWS","WEATHER","USD TO EUR","SPACE WEATHER"};
  public static final String[] PROVIDERS={"adsb.lol","CelesTrak","Private AIS HTTPS gateway","USGS","NASA EONET","GDELT / DW RSS","Open-Meteo","Frankfurter / ECB","NOAA SWPC"};
  public static final String[] ENDPOINTS={
    "https://api.adsb.lol/v2/point/{lat}/{lon}/250",
    "https://celestrak.org/NORAD/elements/gp.php?GROUP=stations&FORMAT=json",
    "USER CONFIGURED HTTPS AIS GATEWAY",
    "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson",
    "https://eonet.gsfc.nasa.gov/api/v3/events?status=open&limit=65",
    "https://api.gdeltproject.org/api/v2/doc/doc?query=... ; https://rss.dw.com/xml/rss-en-all",
    "https://api.open-meteo.com/v1/forecast (REGIONAL)",
    "https://api.frankfurter.dev/v1/latest?base=USD&symbols=EUR,GBP,JPY",
    "https://services.swpc.noaa.gov/products/noaa-planetary-k-index.json"};
  public static final String[] RIGHTS={"ODbL/fair-use check; commercial terms unconfirmed","CelesTrak redistribution terms verify","PAID/PRIVATE gateway required","USGS public data","NASA EONET attribution/third parties","Publisher/GDELT terms must be verified","Free tier is non-commercial","Frankfurter + ECB source terms verify","NOAA public observations"};
  public static final long[] FRESH={180000L,7200000L,180000L,1200000L,1200000L,3600000L,2700000L,172800000L,14400000L};
  public static final long[] POLL={60000L,7200000L,120000L,600000L,600000L,900000L,1800000L,43200000L,14400000L};
  public static final int MAX_METADATA_BYTES=16000;
  public static final class Result {
    public final String key, provider, endpoint, coverage, value, errorReason;
    public final long fetchedAt,sourceTime;public final Status status;
    public Result(String k,String pr,String ep,String c,String v,long when,long source,Status s,String err){
      key=k;provider=pr;endpoint=ep;coverage=c;value=v;fetchedAt=when;sourceTime=source;status=s;errorReason=err;
    }
    public String age(){if(fetchedAt<=0)return "NEVER RECEIVED";
      long m=Math.max(0,(System.currentTimeMillis()-fetchedAt)/60000L);
      return m==0?"<1m":m<60?m+"m":m<1440?(m/60)+"h "+(m%60)+"m":(m/1440)+"d";}
    public String display(){
      String freshness=status==Status.DELAYED&&sourceTime==0L?"RECENT CACHE / SOURCE TIME UNKNOWN":status.toString().replace('_',' ');
      return freshness+" · FETCH "+age();
    }
    public String sourceAge(){
      if(sourceTime<=0L)return "NOT PROVIDED";
      long min=Math.max(0L,(System.currentTimeMillis()-sourceTime)/60000L);
      return min<60L?min+"m":min<1440L?(min/60L)+"h "+(min%60L)+"m":(min/1440L)+"d";
    }
  }
  private static SharedPreferences p(Context c,String s){return c.getApplicationContext().getSharedPreferences(s,Context.MODE_PRIVATE);}
  private static JSONObject obj(String s){try{return new JSONObject(s);}catch(Exception e){return new JSONObject();}}
  private static int count(JSONObject o,String name){JSONArray a=o.optJSONArray(name);return a==null?-1:a.length();}
  private static int array(String raw){try{return new JSONArray(raw).length();}catch(Exception e){return -1;}}
  private static String figure(long stamp,int value){return stamp>0&&value>=0?Integer.toString(value):"--";}
  private static Status classify(long when,long ttl,String err,boolean configured,boolean regionReady){
    if(!configured)return Status.NOT_CONFIGURED;
    if(!regionReady)return Status.NO_DATA_FOR_REGION;
    if(when<=0)return err==null||err.isEmpty()?Status.NO_DATA_FOR_REGION:Status.FAILED;
    long age=Math.max(0,System.currentTimeMillis()-when);
    if(err!=null&&!err.isEmpty())return Status.OFFLINE_CACHE;
    if(age<=ttl)return Status.LIVE;
    if(age<=ttl*3)return Status.DELAYED;
    return Status.STALE;
  }
  public static Result read(Context ctx,int index){
    if(index<0||index>=IDS.length)throw new IllegalArgumentException("source index");
    boolean region=RunningballWorldTarget.ready(ctx);String key=IDS[index],err="",value="--";long stamp=0,sourceTime=0;
    String coverage="WORLDWIDE / PROVIDER-LIMITED";boolean configured=true,regionReady=true;
    switch(index){
      case 0:{SharedPreferences s=p(ctx,"air_widget_v2");JSONObject o=obj(s.getString("last_snapshot","{}"));
        coverage=RunningballWorldTarget.coverage(ctx);configured=true;regionReady=region;
        stamp=o.optLong("time",0);err=s.getString("last_error","");
        if(!region || Math.abs(o.optDouble("observerLat",999d)-RunningballWorldTarget.lat(ctx))>.001d ||
          Math.abs(o.optDouble("observerLon",999d)-RunningballWorldTarget.lon(ctx))>.001d){stamp=0;err="PREVIOUS REGION / NEW OBSERVATION REQUIRED";}
        value=figure(stamp,o.optInt("count",-1));break;}
      case 1:{SharedPreferences s=p(ctx,"rb10_satellite");stamp=s.getLong("data_STATIONS_time",0);
        value=figure(stamp,array(s.getString("data_STATIONS","")));err=p(ctx,"rb19_bootstrap").getString("sat_error","");
        coverage="CELESTRAK STATIONS / ORBIT ESTIMATE · TWO-BODY KEPLER";break;}
      case 2:{SharedPreferences s=p(ctx,"rb11_marine");configured=!s.getString("endpoint","").trim().isEmpty();
        coverage=configured?"USER-CONFIGURED AIS GATEWAY":"AIS SOURCE NOT CONNECTED";stamp=s.getLong("last_fetch",0);
        value=figure(stamp,count(obj(s.getString("rows","{}")),"rows"));break;}
      case 3:case 4:{SharedPreferences s=p(ctx,"rb_global_public_events");String stem=index==3?"quakes":"nasa";
        coverage=index==3?"WORLD / 24 HOURS / M2.5+":"WORLD / OPEN EVENTS / RESULT LIMIT 65";
        stamp=s.getLong(stem+"_time",0);err=s.getString(stem+"_v16_error","");
        value=figure(stamp,count(obj(s.getString(stem+"_raw","{}")),index==3?"features":"events"));break;}
      case 5:case 6:case 7:{SharedPreferences s=p(ctx,"rb17_verified_feeds");String stem=index==5?"news":index==6?"weather":"fx";
        JSONObject o=obj(s.getString(stem+"_json","{}"));stamp=s.getLong(stem+"_received",0);err=s.getString(stem+"_error","");
        if(index==5){value=figure(stamp,count(o,"articles"));coverage=o.optString("provider","PUBLISHER-LINKED RESULTS / NOT GLOBAL TOTAL");}
        if(index==6){coverage=region?RunningballWorldTarget.label(ctx):"SELECT REGION";
          configured=true;regionReady=region && RunningballV25RegionQuery.key(RunningballWorldTarget.lat(ctx),RunningballWorldTarget.lon(ctx)).equals(o.optString("region",""));
          if(!regionReady){stamp=0;err="PREVIOUS REGION / WEATHER REQUERY REQUIRED";}
          double v=o.optDouble("temperature",Double.NaN);if(stamp>0&&Double.isFinite(v))value=String.format(Locale.US,"%.1f °C",v);}
        if(index==7){JSONObject rates=o.optJSONObject("rates");double v=rates==null?Double.NaN:rates.optDouble("EUR",Double.NaN);
          if(stamp>0&&Double.isFinite(v))value=String.format(Locale.US,"%.4f USD/EUR",v);coverage="REFERENCE DATE "+o.optString("date","UNKNOWN");}
        break;}
      case 8:{stamp=RunningballV19Noaa.received(ctx);err=RunningballV19Noaa.error(ctx);
        double kp=RunningballV19Noaa.kp(ctx);if(stamp>0&&Double.isFinite(kp))value=String.format(Locale.US,"%.2f KP",kp);
        coverage="NOAA PLANETARY K-INDEX / OBSERVATION";break;}
    }
    // Timestamp integrity: a cache receipt alone is not a live observation.
    if(index==3){
      JSONObject feed=obj(p(ctx,"rb_global_public_events").getString("quakes_raw","{}"));
      JSONObject metadata=feed.optJSONObject("metadata");
      long generated=metadata==null?0L:metadata.optLong("generated",0L);
      if(generated>0L&&generated<=System.currentTimeMillis()+300000L)sourceTime=generated;
    }
    Status status=classify(stamp,FRESH[index],err,configured,regionReady);
    if(status==Status.LIVE){
      if(sourceTime<=0L)status=Status.DELAYED; // received recently; source observation time unverified
      else if(System.currentTimeMillis()-sourceTime>FRESH[index])status=Status.STALE;
    }
    if(stamp==0)value="--";
    return new Result(key,PROVIDERS[index],ENDPOINTS[index],coverage,value,stamp,sourceTime,status,err);
  }
}
