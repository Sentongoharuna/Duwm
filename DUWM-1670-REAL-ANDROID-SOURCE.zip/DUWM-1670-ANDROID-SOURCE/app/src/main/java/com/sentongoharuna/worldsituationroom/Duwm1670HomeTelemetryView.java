package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.SystemClock;
import android.view.View;
/** Compact moving status strip; counts and timestamps are cached provider receipts, never fabricated. */
public final class Duwm1670HomeTelemetryView extends View {
  private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private boolean running;
  private String[] names={"AIR","SEA","NEWS","WEATHER"},values={"--","--","--","--"};
  private boolean[] available=new boolean[4];
  public Duwm1670HomeTelemetryView(Context c){super(c);setContentDescription("Received air, vessel, news and weather data indicators. A flashing icon is display activity, not an incoming event.");}
  public void update(){RunningballV25GlobalAircraftData.Snapshot air=RunningballV25GlobalAircraftData.read(getContext());
    values[0]=air.hasGood()?air.countLabel():"--";available[0]=air.hasGood()&&air.ageMs()<3600000L;
    int[] ids={2,5,6};for(int k=1;k<=3;k++){RunningballV25Sources.Result r=RunningballV25Sources.read(getContext(),ids[k-1]);
      values[k]=r.value;available[k]=r.fetchedAt>0&&(r.status==RunningballV25Sources.Status.LIVE||r.status==RunningballV25Sources.Status.DELAYED);}
    invalidate();
  }
  public void resume(){running=true;update();postInvalidateDelayed(750);}
  public void pause(){running=false;}
  @Override protected void onDetachedFromWindow(){pause();super.onDetachedFromWindow();}
  @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();c.drawColor(0xFF0C2435);
    float pulse=(float)Math.sin(SystemClock.uptimeMillis()/300d);
    for(int i=0;i<4;i++){
      float x=i*w/4f+getResources().getDisplayMetrics().density*10f;
      p.setStyle(Paint.Style.FILL);p.setColor(available[i]?0xFF56CABB:0xFFB98C64);
      c.drawCircle(x+4f,h*.27f,2.7f+(available[i]?1.0f+.6f*pulse:0),p);
      p.setColor(0xFF99B7C5);p.setTextSize(h*.20f);c.drawText(names[i],x+12f,h*.34f,p);
      p.setColor(0xFFEBF6FB);p.setTextSize(h*.27f);String display=values[i];if(display.length()>12)display=display.substring(0,12);
      c.drawText(display,x,h*.74f,p);
    }
    if(running)postInvalidateDelayed(700);
  }
}
