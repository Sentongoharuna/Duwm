package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** GEV Port 05 / Maritime Intelligence.
 * Uses the HTTPS AISStream snapshot gateway provided by God's Eye View
 * or a compatible self-hosted endpoint. An AISSTREAM_API_KEY is held on the
 * backend, never embedded in Android. No AIS provider, no fabricated ships. */
public final class GevMarineActivity extends Activity {
    private static final String PREF="rb11_marine";
    private static final long MAX_BYTES=1024L*1024L,STALE_MS=30L*60L*1000L;
    private static final int BG=Color.rgb(7,13,21), FG=Color.rgb(231,245,251), CYAN=Color.rgb(119,226,244), MUTED=Color.rgb(141,166,183), GREEN=Color.rgb(96,236,178), AMBER=Color.rgb(251,187,114);
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final ArrayList<Ship> ships=new ArrayList<>();
    private TextView banner,detail,summary,foot;private EditText endpoint,search;private LinearLayout list;private GevMarineRadarView radar;
    private String sourceStatus="not configured",sourceName="AISStream gateway";
    private boolean loading;private int selected=-1;private long lastSuccess;private String error="";
    private boolean showMovingOnly=false;
    private static final class Ship {
        String mmsi="",name="",imo="",type="",destination="";
        double lat,lon,sog=Double.NaN,cog=Double.NaN,heading=Double.NaN;
        long observed;
    }
    private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable background(boolean sel){GradientDrawable d=new GradientDrawable();d.setColor(Color.rgb(17,26,36));d.setCornerRadius(dp(23));d.setStroke(dp(1),sel?CYAN:Color.rgb(55,108,126));return d;}
    private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private TextView button(String text,Runnable run){TextView b=txt(text,11,CYAN,true);b.setGravity(Gravity.CENTER);b.setBackground(background(false));b.setOnClickListener(v->run.run());return b;}
    private SharedPreferences prefs(){return getSharedPreferences(PREF,MODE_PRIVATE);}
    @Override protected void onCreate(Bundle state){super.onCreate(state);RunningballV17Insets.install(this);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);root.setPadding(dp(12),dp(10),dp(12),dp(10));
        root.addView(txt("RUNNINGBALL2 / GOD'S EYE VIEW PORT 05",11,CYAN,true),new LinearLayout.LayoutParams(-1,dp(25)));
        root.addView(txt("MARITIME INTELLIGENCE",22,FG,true),new LinearLayout.LayoutParams(-1,dp(42)));
        banner=txt("NO AIS FEED CONNECTED",12,AMBER,true);root.addView(banner,new LinearLayout.LayoutParams(-1,dp(44)));
        endpoint=new EditText(this);endpoint.setSingleLine(true);endpoint.setTextColor(FG);endpoint.setHintTextColor(MUTED);endpoint.setTextSize(12);
        endpoint.setHint("https://your-ais-server.example/api/vessels");endpoint.setBackground(background(false));endpoint.setPadding(dp(12),0,dp(10),0);
        endpoint.setText(prefs().getString("endpoint",""));
        root.addView(endpoint,new LinearLayout.LayoutParams(-1,dp(45)));
        TextView guide=txt("ENTER YOUR HTTPS AISStream GATEWAY • NO API KEY STORED ON PHONE",10,MUTED,false);
        root.addView(guide,new LinearLayout.LayoutParams(-1,dp(28)));
        LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.addView(button("CONNECT / REFRESH",()->fetch(true)),new LinearLayout.LayoutParams(0,dp(43),1.25f));
        LinearLayout.LayoutParams moving=new LinearLayout.LayoutParams(0,dp(43),1f);moving.leftMargin=dp(6);
        controls.addView(button("MOVING / ALL",()->{showMovingOnly=!showMovingOnly;render();}),moving);root.addView(controls);
        search=new EditText(this);search.setSingleLine(true);search.setTextColor(FG);search.setHintTextColor(MUTED);search.setHint("Search name • MMSI • destination");
        search.setTextSize(13);search.setPadding(dp(12),0,dp(10),0);search.setBackground(background(false));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(43));sp.topMargin=dp(7);root.addView(search,sp);
        summary=txt("0 VERIFIED VESSEL REPORTS",12,CYAN,true);root.addView(summary,new LinearLayout.LayoutParams(-1,dp(34)));
        LinearLayout ports=new LinearLayout(this);ports.setOrientation(LinearLayout.HORIZONTAL);
        ports.addView(button("MOMBASA",()->radar.setPort(-4.04,39.67,140)),new LinearLayout.LayoutParams(0,dp(31),1));
        ports.addView(button("DAR ES SALAAM",()->radar.setPort(-6.82,39.28,140)),new LinearLayout.LayoutParams(0,dp(31),1));
        ports.addView(button("DURBAN",()->radar.setPort(-29.88,31.05,140)),new LinearLayout.LayoutParams(0,dp(31),1));
        root.addView(ports);
        radar=new GevMarineRadarView(this);root.addView(radar,new LinearLayout.LayoutParams(-1,dp(170)));
        radar.setOnShipSelected(index->{selected=index;showSelected();renderList();});
        ScrollView sc=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);sc.addView(list);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        detail=txt("SELECT A VESSEL TO VIEW ITS LAST REPORTED POSITION",12,FG,true);root.addView(detail,new LinearLayout.LayoutParams(-1,dp(71)));
        LinearLayout bottom=new LinearLayout(this);bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.addView(button("EARTH POSITION",this::openEarth),new LinearLayout.LayoutParams(0,dp(44),1));
        LinearLayout.LayoutParams share=new LinearLayout.LayoutParams(0,dp(44),1);share.leftMargin=dp(7);bottom.addView(button("SHARE CARD",this::share),share);
        root.addView(bottom);
        foot=txt("AISSTREAM • REQUIRES PRIVATE HTTPS GATEWAY • NOT FOR NAVIGATION",10,MUTED,false);
        root.addView(foot,new LinearLayout.LayoutParams(-1,dp(33)));
        setContentView(root);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){renderList();}
            public void afterTextChanged(Editable e){} });
        restore();render();if(!endpoint.getText().toString().trim().isEmpty())fetch(false);
    }
    private static long timestamp(JSONObject row){
        double raw=row.optDouble("last_position_epoch",Double.NaN);
        if(GevMarineMath.finite(raw)&&raw>0d){long n=(long)raw;return n<100000000000L?n*1000L:n;}
        String iso=row.optString("last_position_UTC","");if(iso.isEmpty())return 0L;
        try{String trimmed=iso.trim();if(trimmed.endsWith("Z"))trimmed=trimmed.substring(0,trimmed.length()-1);
            if(trimmed.length()>19)trimmed=trimmed.substring(0,19);
            SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date d=f.parse(trimmed);return d==null?0L:d.getTime();}catch(Exception ignored){return 0L;}
    }
    private void decode(String json,boolean freshNetwork){
        ArrayList<Ship> found=new ArrayList<>();
        JSONObject data;try{data=new JSONObject(json);}catch(Exception e){error="INVALID AIS GATEWAY JSON";return;}
        JSONArray arr=data.optJSONArray("rows");if(arr==null){error="AIS GATEWAY RESPONSE LACKS rows ARRAY";return;}
        sourceName=data.optString("source","AISStream gateway");sourceStatus=data.optString("status","unknown");
        for(int i=0;i<arr.length()&&found.size()<800;i++){
            JSONObject row=arr.optJSONObject(i);if(row==null)continue;
            Ship ship=new Ship();ship.lat=row.optDouble("lat",Double.NaN);ship.lon=row.optDouble("lon",Double.NaN);
            ship.mmsi=row.optString("mmsi","").trim();if(!GevMarineMath.valid(ship.lat,ship.lon)||!GevMarineMath.validMmsi(ship.mmsi))continue;
            ship.name=row.optString("name","").trim();if(ship.name.isEmpty())ship.name="MMSI "+ship.mmsi;
            ship.imo=row.optString("imo","");ship.type=row.optString("type","");ship.destination=row.optString("destination","");
            ship.sog=row.optDouble("speed",Double.NaN);ship.cog=row.optDouble("course",Double.NaN);ship.heading=row.optDouble("heading",Double.NaN);
            ship.observed=timestamp(row);found.add(ship);
        }
        if(freshNetwork)lastSuccess=System.currentTimeMillis();
        ships.clear();ships.addAll(found);selected=-1;
        Collections.sort(ships,(a,b)->Long.compare(b.observed,a.observed));
    }
    private void restore(){lastSuccess=prefs().getLong("last_fetch",0L);sourceStatus=prefs().getString("status","cached");
        String raw=prefs().getString("rows","");if(!raw.isEmpty())decode(raw,false);}
    private void fetch(boolean manual){if(loading)return;
        String rawUrl=endpoint.getText().toString().trim();
        try{URL u=new URL(rawUrl);if(!"https".equalsIgnoreCase(u.getProtocol())||u.getUserInfo()!=null||u.getQuery()!=null)
            throw new IllegalArgumentException("HTTPS URL WITHOUT CREDENTIALS OR QUERY REQUIRED");
            if(u.getHost()==null||u.getHost().isEmpty())throw new IllegalArgumentException("INVALID HOST");
        }catch(Exception e){banner.setText("CONFIGURE HTTPS AIS GATEWAY • NOT CONNECTED");return;}
        prefs().edit().putString("endpoint",rawUrl).apply();loading=true;banner.setText("CONNECTING TO AIS SNAPSHOT …");
        io.execute(()->{String content=null;String failure=null;HttpURLConnection c=null;
            try{c=(HttpURLConnection)new URL(rawUrl+(rawUrl.endsWith("?")?"":"?maxRows=300")).openConnection();c.setConnectTimeout(8500);c.setReadTimeout(9500);
                c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","RUNNINGBALL2-Maritime/11");
                if(c.getResponseCode()!=200)throw new IllegalStateException("AIS GATEWAY HTTP "+c.getResponseCode());
                try(InputStream s=c.getInputStream();ByteArrayOutputStream b=new ByteArrayOutputStream()){
                    byte[] buf=new byte[8192];int n;while((n=s.read(buf))!=-1){if(b.size()+n>MAX_BYTES)throw new IllegalStateException("AIS SNAPSHOT EXCEEDS 1 MB");b.write(buf,0,n);}content=b.toString("UTF-8");}
                JSONObject verify=new JSONObject(content);if(!verify.has("rows")||verify.optJSONArray("rows")==null)throw new IllegalStateException("AIS JSON MISSING rows");
            }catch(Exception e){failure=e.getMessage()==null?"AIS CONNECTION ERROR":e.getMessage();}finally{if(c!=null)c.disconnect();}
            final String data=content,fail=failure;
            ui.post(()->{loading=false;if(isFinishing())return;
                if(fail==null&&data!=null){error="";decode(data,true);
                    prefs().edit().putString("rows",data).putString("status",sourceStatus).putLong("last_fetch",lastSuccess).apply();
                }else{error=fail==null?"NO DATA":fail;sourceStatus="offline";}
                render();GevMaritimeWidget.updateAll(this);RunningballV14SignalWidget.updateAll(this);
            });
        });
    }
    private String utc(long t){if(t<=0L)return "NO TIMESTAMP";SimpleDateFormat f=new SimpleDateFormat("dd MMM HH:mm 'UTC'",Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(t));}
    private Ship chosen(){return selected>=0&&selected<ships.size()?ships.get(selected):null;}
    private void render(){long now=System.currentTimeMillis();int recent=0,moving=0;
        for(Ship ship:ships){if("RECENT".equals(GevMarineMath.freshness(ship.observed,now)))recent++;
            if(GevMarineMath.reported(ship.sog)&&ship.sog>0.5d)moving++;}
        boolean live="live".equalsIgnoreCase(sourceStatus)&&recent>0&&error.isEmpty()&&lastSuccess>0&&now-lastSuccess<180000L;
        if(ships.isEmpty()){banner.setText(error.isEmpty()?"NO AIS SHIPS • CONNECT A LIVE GATEWAY":"AIS UNAVAILABLE • "+error);}
        else banner.setText((live?"LIVE AIS REPORTS":"AIS CACHED / UNVERIFIED")+" • "+sourceStatus.toUpperCase(Locale.US)+(error.isEmpty()?"":" • "+error));
        boolean connected=!prefs().getString("endpoint","").trim().isEmpty();
        summary.setText(!connected?"AIS SOURCE NOT CONNECTED  •  REPORTED VESSELS --":
          lastSuccess<=0?"AIS DATA NOT RECEIVED  •  REPORTED VESSELS --":
          ships.size()+" REPORTED VESSELS  •  "+recent+" RECENT  •  "+moving+" MOVING");
        foot.setText("AISSTREAM GATEWAY • LAST SNAPSHOT "+utc(lastSuccess)+" • POSITIONS MAY BE DELAYED");
        ArrayList<GevMarineRadarView.Point> plots=new ArrayList<>();
        for(int i=0;i<ships.size();i++){Ship ship=ships.get(i);
            plots.add(new GevMarineRadarView.Point(i,ship.lat,ship.lon,ship.observed,ship.name));}
        radar.setRecords(plots);
        renderList();showSelected();
    }
    private void renderList(){if(list==null)return;list.removeAllViews();String q=search.getText().toString().trim().toLowerCase(Locale.US);long now=System.currentTimeMillis();int shown=0;
        for(int i=0;i<ships.size()&&shown<85;i++){
            Ship v=ships.get(i);if(showMovingOnly&&(!GevMarineMath.reported(v.sog)||v.sog<0.5d))continue;
            String label=(v.name+" "+v.mmsi+" "+v.destination+" "+v.type).toLowerCase(Locale.US);if(!label.contains(q))continue;
            String speed=GevMarineMath.reported(v.sog)?String.format(Locale.US,"%.1f kn",v.sog):"SPEED --";
            final int index=i;
            String line=v.name+"\n"+v.mmsi+"  •  "+speed+"  •  "+GevMarineMath.freshness(v.observed,now);
            TextView item=txt(line,12,i==selected?CYAN:FG,i==selected);item.setPadding(dp(12),dp(6),dp(9),dp(6));item.setBackground(background(i==selected));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(64));lp.bottomMargin=dp(6);list.addView(item,lp);
            item.setOnClickListener(view->{selected=index;showSelected();renderList();});shown++;
        }
        if(shown==0)list.addView(txt(ships.isEmpty()?"NO VESSELS RECEIVED. CHECK GATEWAY STATUS.":"NO VESSELS MATCH THIS FILTER",12,MUTED,false));
    }
    private void showSelected(){Ship s=chosen();if(s==null){detail.setText("SELECT A VESSEL TO INSPECT REPORTED POSITION");return;}
        String speed=GevMarineMath.reported(s.sog)?String.format(Locale.US,"%.1f KNOTS",s.sog):"SPEED UNKNOWN";
        String cog=GevMarineMath.finite(s.cog)?String.format(Locale.US,"%.0f°",s.cog):"--";
        detail.setText(s.name+" • "+speed+" • COG "+cog+"\n"+String.format(Locale.US,"%.4f, %.4f",s.lat,s.lon)+" • "+utc(s.observed));
    }
    private void openEarth(){Ship s=chosen();if(s==null){banner.setText("SELECT A VESSEL FIRST");return;}
        Intent i=new Intent(this,GevEarthExploreActivity.class);i.putExtra("geo_lat",s.lat);i.putExtra("geo_lon",s.lon);
        i.putExtra("marine_observed",true);i.putExtra("marine_name",s.name);startActivity(i);
    }
    private void share(){Ship s=chosen();if(s==null){banner.setText("SELECT A VESSEL FIRST");return;}
        LinkedHashMap<String,String> facts=new LinkedHashMap<>();facts.put("MMSI",s.mmsi);facts.put("POSITION",String.format(Locale.US,"%.4f, %.4f",s.lat,s.lon));
        facts.put("SPEED",GevMarineMath.reported(s.sog)?String.format(Locale.US,"%.1f kn",s.sog):"Unavailable");
        facts.put("COURSE",GevMarineMath.finite(s.cog)?String.format(Locale.US,"%.0f°",s.cog):"Unavailable");
        facts.put("HEADING",GevMarineMath.finite(s.heading)?String.format(Locale.US,"%.0f°",s.heading):"Unavailable");
        facts.put("DESTINATION",s.destination.isEmpty()?"Not reported":s.destination);
        facts.put("LAST AIS POSITION",utc(s.observed));facts.put("FEED STATUS",sourceStatus);
        ShareCardRenderer.share(this,new ShareCardData(s.name,"Last reported AIS vessel location; not a live-video observation.",
            "MARITIME AIS",GevMarineMath.freshness(s.observed,System.currentTimeMillis()),"MARITIME","GLOBAL",1,
            sourceName,"",s.observed>0?s.observed:lastSuccess,s.lat,s.lon,facts,CYAN,
            "AIS reception and timestamps may be delayed or incomplete. Not for navigation or safety decisions."));
    }
    @Override protected void onDestroy(){super.onDestroy();io.shutdownNow();ui.removeCallbacksAndMessages(null);}
}
