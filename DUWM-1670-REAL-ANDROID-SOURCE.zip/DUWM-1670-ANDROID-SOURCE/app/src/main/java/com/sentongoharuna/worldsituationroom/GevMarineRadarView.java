package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;

/** Port 05: read-only vessel radar. Coordinates are actual AIS snapshot points.
 * No interpolation, simulation or extrapolation of vessel movements. */
public final class GevMarineRadarView extends View {
    public interface OnShipSelected { void selected(int sourceIndex); }
    public static final class Point {
        public final int originalIndex;public final double lat,lon;
        public final long lastObserved;
        public final String label;
        public Point(int index,double lat,double lon,long observed,String label){
            this.originalIndex=index;this.lat=lat;this.lon=lon;this.lastObserved=observed;this.label=label;
        }
    }
    private final Paint pen=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ArrayList<Point> points=new ArrayList<>();
    private double centerLat=-4.04d,centerLon=39.67d,rangeNm=140d;
    private OnShipSelected listener;
    public GevMarineRadarView(Context c){super(c);setBackgroundColor(Color.rgb(12,22,31));}
    public void setPort(double lat,double lon,double rangeNm){if(GevMarineMath.valid(lat,lon)&&rangeNm>0d){centerLat=lat;centerLon=lon;this.rangeNm=rangeNm;invalidate();}}
    public void setRecords(ArrayList<Point> records){points.clear();if(records!=null)points.addAll(records);invalidate();}
    public void setOnShipSelected(OnShipSelected selected){listener=selected;}
    private void stroke(Canvas c,int color,float width,float cx,float cy,float radius){pen.setColor(color);pen.setStyle(Paint.Style.STROKE);pen.setStrokeWidth(width);c.drawCircle(cx,cy,radius,pen);pen.setStyle(Paint.Style.FILL);}
    private float[] xy(double lat,double lon,float cx,float cy,float radius){
        double north=GevMarineMath.distanceNm(centerLat,centerLon,lat,centerLon)*(lat>=centerLat?1d:-1d);
        double east=GevMarineMath.distanceNm(centerLat,centerLon,centerLat,lon)*(lon>=centerLon?1d:-1d);
        return new float[]{(float)(cx+east/rangeNm*radius),(float)(cy-north/rangeNm*radius)};
    }
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);float w=getWidth(),h=getHeight();
        float cx=w/2f,cy=h/2f,radius=Math.max(12f,Math.min(w,h)*.43f);
        int cyan=Color.rgb(81,165,186),muted=Color.rgb(42,84,98);
        pen.setStyle(Paint.Style.FILL);pen.setColor(Color.rgb(11,22,31));canvas.drawColor(Color.rgb(11,22,31));
        stroke(canvas,muted,1f,cx,cy,radius);
        stroke(canvas,muted,1f,cx,cy,radius*.65f);
        stroke(canvas,muted,1f,cx,cy,radius*.32f);
        pen.setColor(muted);pen.setStrokeWidth(1f);canvas.drawLine(cx-radius,cy,cx+radius,cy,pen);canvas.drawLine(cx,cy-radius,cx,cy+radius,pen);
        pen.setStyle(Paint.Style.FILL);pen.setTextSize(19f);pen.setColor(cyan);
        canvas.drawText("N",cx-5f,cy-radius+14f,pen);
        canvas.drawText(""+(int)rangeNm+" NM",12f,h-10f,pen);
        long now=System.currentTimeMillis();int drawn=0,within=0;
        for(Point p:points){if(!GevMarineMath.valid(p.lat,p.lon))continue;
            double distance=GevMarineMath.distanceNm(centerLat,centerLon,p.lat,p.lon);
            if(distance>rangeNm)continue;within++;
            if(drawn++>=160)continue;
            float[] v=xy(p.lat,p.lon,cx,cy,radius);
            String freshness=GevMarineMath.freshness(p.lastObserved,now);
            int color="RECENT".equals(freshness)?Color.rgb(71,225,167):"CACHED".equals(freshness)?Color.rgb(249,181,98):Color.rgb(115,130,145);
            pen.setColor(color);canvas.drawCircle(v[0],v[1],4.2f,pen);
        }
        pen.setColor(Color.rgb(169,206,220));pen.setTextSize(20f);
        canvas.drawText("PLOTTED "+within+" REPORTS",12f,24f,pen);
        pen.setTextSize(16f);canvas.drawText("OBSERVED AIS ONLY",12f,44f,pen);
    }
    @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;
        if(listener==null)return true;
        float cx=getWidth()/2f,cy=getHeight()/2f,radius=Math.max(12f,Math.min(getWidth(),getHeight())*.43f);
        double best=18d*18d;int index=-1;
        for(Point p:points){if(GevMarineMath.distanceNm(centerLat,centerLon,p.lat,p.lon)>rangeNm)continue;
            float[] pt=xy(p.lat,p.lon,cx,cy,radius);double delta=Math.pow(e.getX()-pt[0],2)+Math.pow(e.getY()-pt[1],2);
            if(delta<best){best=delta;index=p.originalIndex;}}
        if(index>=0)listener.selected(index);return true;
    }
}
