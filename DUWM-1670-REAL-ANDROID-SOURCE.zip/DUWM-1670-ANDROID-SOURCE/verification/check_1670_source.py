from pathlib import Path
import json,re,hashlib
from xml.etree import ElementTree as ET
P=Path(__file__).resolve().parents[1]
J=P/'app/src/main/java/com/sentongoharuna/worldsituationroom'
A=P/'app/src/main/assets'
geo=A/'duwm_country_borders_wdbii.txt'; assert geo.stat().st_size>150000
lines=geo.read_text().splitlines();assert len(lines)>=300,len(lines)
for line in lines:
 assert all(len(x.split(','))==2 for x in line.split(' '))
news=json.loads((A/'duwm_news_200_region_sources.json').read_text())['sources'];assert len(news)==200
assert len({x['id'] for x in news})==200
for group in ('AFRICA','CONFLICT','WEST','ISS_SPACE'):
 records=[x for x in news if x['group']==group]
 assert len(records)==50,(group,len(records))
 assert all(x['url'].startswith('https://') and x['status']=='DISCOVERY_CANDIDATE' and x['feedStatus']=='NOT_VERIFIED' for x in records)
assert any(x['name']=='Haruna Enterprises' and x['url']=='https://harunaenterprisesltd.com/' for x in news)
required={
'Duwm1670WorldMapView.java':['duwm_country_borders_wdbii.txt','genuinePair()','postInvalidateDelayed','SCENARIO:','setScenarioDestination'],
'Duwm1670FlightMapActivity.java':['RunningballV25GlobalAircraftData','RunningballV25AircraftTrailPolicy.qualifies','SCENARIO ONLY','NO DESTINATION PROVIDED','setScenarioDestination'],
'Duwm1670NewsAtlasActivity.java':['duwm_news_200_region_sources.json','NOT CONFIRMED LIVE','NewsStore(this).load','Duwm1166ArticleActivity'],
'Duwm1670CommandActivity.java':['Duwm1670WorldMapView','Duwm1670DataPulseView','RunningballV25Sources','Duwm1670FlightMapActivity','Duwm1670NewsAtlasActivity'],
'Duwm1670DataPulseView.java':['fetched>0','not synthetic telemetry'],
'Duwm1670HomeTelemetryView.java':['RunningballV25Sources','RunningballV25GlobalAircraftData'],
}
for filename,patterns in required.items():
 s=(J/filename).read_text()
 for text in patterns:assert text.lower() in s.lower(),(filename,text)
source=(J/'OperationsMainActivity.java').read_text()
for t in ('1670 LIVE COMMAND','1670 NEWS ATLAS','LIVE AIRCRAFT MAP','newRail.resume()','newRail.pause()'):
 assert t in source,t
manifest=ET.parse(P/'app/src/main/AndroidManifest.xml').getroot(); ns='{http://schemas.android.com/apk/res/android}'
registered=[x.get(ns+'name') for x in manifest.iter('activity')]
for name in ('Duwm1670CommandActivity','Duwm1670NewsAtlasActivity','Duwm1670FlightMapActivity'):
 assert '.'+name in registered,name
build=(P/'app/build.gradle.kts').read_text()
assert 'versionCode = 167000' in build and 'versionName = "1670"' in build
assert 'com.sentongoharuna.worldsituationroom.rb2live25' in build
report=json.loads((P/'DUWM_REAL_SOURCE_CHANGE_REPORT.json').read_text())['unmodified_source_components']
for name,sha in report.items():assert hashlib.sha256((J/name).read_bytes()).hexdigest()==sha,name
print('PASS DUWM 1670: 200 category-distributed source candidates, 458+ political boundaries, source-tied aircraft transitions, scenario ETA labels, real source status on home, original globe protected.')
print('APK COMPILATION, ON-PHONE ANIMATIONS, THIRD-PARTY SOURCE UPTIME AND ROUTE ACCURACY NOT VERIFIED BY THIS TEST.')
