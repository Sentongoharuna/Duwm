package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

/**
 * DUWM 1719: a private, country-neutral personal home for worldwide users.
 * Reads the SAME on-device followed-place database created by Global Discovery.
 * Local clocks use explicit IANA zones only; unknown zones never silently fall back
 * to an incorrect GMT time. No geocoded location, live alert or synthetic feed is
 * presented as a sourced event. No network access or registration is needed.
 */
public final class Duwm1719MyWorldActivity extends Activity {
    private static final String PLACES_PREFS="duwm1718_follow_places", FOLLOWED="followed";
    private static final String USER_PREFS="duwm1719_my_world", INTERESTS="interests";
    private static final String[] TOPICS={"Weather","News","Aircraft","Vessels","Hazards","Markets","Radio & TV","World Monitor"};
    private static final int NAVY=DuwmUnifiedTheme.APPROVED_NAVY, TEXT=DuwmUnifiedTheme.TEXT;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private LinearLayout placesHolder, interestsHolder;
    private TextView summary;
    private boolean closed;
    private final Runnable minuteRefresh=new Runnable(){@Override public void run(){if(closed)return;renderPlaces();handler.postDelayed(this,60000);}};
    private int dp(float v){return Math.round(getResources().getDisplayMetrics().density*v);}
    private GradientDrawable shape(int stroke){GradientDrawable g=new GradientDrawable();g.setColor(NAVY);g.setCornerRadius(dp(16));g.setStroke(dp(1),stroke);return g;}
    private TextView label(String value,int size,int color){TextView t=new TextView(this);t.setText(value);t.setTextColor(color);t.setTextSize(size);t.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));return t;}
    private TextView button(String value,Runnable callback){TextView t=label(value,12,TEXT);t.setGravity(Gravity.CENTER);t.setMinHeight(dp(48));t.setPadding(dp(5),dp(8),dp(5),dp(8));t.setBackground(shape(DuwmUnifiedTheme.BORDER));t.setOnClickListener(v->callback.run());return t;}
    private LinearLayout.LayoutParams spaced(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(8);return p;}
    private void launch(Class<?> destination){startActivity(new Intent(this,destination));}
    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(NAVY);
        ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(15),dp(14),dp(15),dp(22));root.setBackgroundColor(NAVY);
        root.addView(label("DUWM 1719  /  MY WORLD",21,TEXT),spaced());
        root.addView(label("Your places, your local clocks and the original worldwide command centre. No default country.",12,DuwmUnifiedTheme.MUTED),spaced());
        summary=label("Saved places are stored privately on this phone.",12,DuwmUnifiedTheme.MUTED);root.addView(summary,spaced());
        root.addView(label("MY FOLLOWED PLACES  /  WORLD CLOCKS",14,TEXT),spaced());
        placesHolder=new LinearLayout(this);placesHolder.setOrientation(LinearLayout.VERTICAL);root.addView(placesHolder,spaced());
        root.addView(button("ADD OR SEARCH PLACES WORLDWIDE",()->launch(Duwm1718GlobalDiscoverActivity.class)),spaced());
        root.addView(label("MY INTERESTS  /  STORED ON THIS PHONE",14,TEXT),spaced());
        root.addView(label("Choose what matters to you. These selections are saved locally; they do not create live notifications or change source data.",11,DuwmUnifiedTheme.MUTED),spaced());
        interestsHolder=new LinearLayout(this);interestsHolder.setOrientation(LinearLayout.VERTICAL);root.addView(interestsHolder,spaced());
        root.addView(label("OPEN GLOBAL TOOLS",14,TEXT),spaced());
        root.addView(button("ORIGINAL WORLD GLOBE",()->{Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);finish();}),spaced());
        root.addView(button("ALL 19 SOURCE DESKS",()->launch(DuwmOptionsActivity.class)),spaced());
        root.addView(button("SOURCE STATUS & SIGNAL LIGHTS",()->launch(Duwm1716SignalCenterActivity.class)),spaced());
        root.addView(button("MONITORS CAM  /  REPORT FROM ANY COUNTRY",()->launch(Duwm1718MonitorsCamActivity.class)),spaced());
        root.addView(button("WORLD MONITOR  /  REVIEW REPORTS",()->launch(LocalMonitorActivity.class)),spaced());
        root.addView(label("Data reliability: saved places and clocks are local tools; news, weather, aircraft and other observations only come from their own cited sources.",11,DuwmUnifiedTheme.MUTED),spaced());
        sc.addView(root);setContentView(sc);renderInterests();renderPlaces();
    }
    private List<JSONObject> places(){List<JSONObject> list=new ArrayList<>();try{JSONArray arr=new JSONArray(getSharedPreferences(PLACES_PREFS,MODE_PRIVATE).getString(FOLLOWED,"[]"));for(int n=0;n<arr.length()&&n<40;n++){JSONObject item=arr.optJSONObject(n);if(item!=null)list.add(item);}}catch(Exception ignored){}return list;}
    private String zoneFor(JSONObject place){String id=place.optString("timezone","");if(id.isEmpty())return "";for(String candidate:TimeZone.getAvailableIDs()){if(candidate.equals(id))return id;}return "";}
    private String localTime(String zone){if(zone.isEmpty())return "TIME ZONE NOT SET";SimpleDateFormat f=new SimpleDateFormat("EEE, d MMM yyyy  HH:mm z",Locale.getDefault());f.setTimeZone(TimeZone.getTimeZone(zone));return f.format(new Date());}
    private void renderPlaces(){if(placesHolder==null)return;placesHolder.removeAllViews();List<JSONObject> list=places();summary.setText(list.size()+" followed place"+(list.size()==1?"":"s")+"  /  local private watchlist  /  not a live feed");
        if(list.isEmpty())placesHolder.addView(label("No places saved. Search any city in Global Discovery to follow it here.",12,DuwmUnifiedTheme.MUTED),spaced());
        for(JSONObject item:list){final String name=item.optString("name","Unnamed place"),country=item.optString("country","Country not provided"),zone=zoneFor(item);
            final double lat=item.optDouble("lat",999),lon=item.optDouble("lon",999);if(!valid(lat,lon))continue;
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(11),dp(11),dp(11),dp(11));card.setBackground(shape(DuwmUnifiedTheme.DIVIDER));
            card.addView(label(name+"  •  "+country,16,TEXT));
            card.addView(label(localTime(zone),13,zone.isEmpty()?DuwmUnifiedTheme.WARNING:DuwmUnifiedTheme.TEXT),spaced());
            card.addView(label(String.format(Locale.US,"MAP LOCATION  %.5f, %.5f  /  USER FOLLOW",lat,lon),11,DuwmUnifiedTheme.MUTED),spaced());
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
            TextView open=button("OPEN MAP",()->{Intent i=new Intent(this,DuwmPlaceMapActivity.class);i.putExtra("focus_lat",String.format(Locale.US,"%.6f",lat));i.putExtra("focus_lon",String.format(Locale.US,"%.6f",lon));startActivity(i);});
            TextView clock=button(zone.isEmpty()?"SET LOCAL CLOCK":"EDIT CLOCK",()->setTimeZone(name,lat,lon,zone));
            LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,dp(48),1);half.rightMargin=dp(6);row.addView(open,half);row.addView(clock,new LinearLayout.LayoutParams(0,dp(48),1));card.addView(row,spaced());placesHolder.addView(card,spaced());
        }
    }
    private boolean valid(double lat,double lon){return !Double.isNaN(lat)&&!Double.isNaN(lon)&&Math.abs(lat)<=85&&Math.abs(lon)<=180;}
    private void setTimeZone(String name,double lat,double lon,String current){EditText entry=new EditText(this);entry.setSingleLine(true);entry.setTextColor(TEXT);entry.setHintTextColor(DuwmUnifiedTheme.MUTED);entry.setHint("e.g. America/New_York");entry.setText(current);entry.setPadding(dp(12),dp(8),dp(12),dp(8));entry.setBackground(shape(DuwmUnifiedTheme.BORDER));
        new AlertDialog.Builder(this).setTitle("Set local clock — "+name).setMessage("Enter an IANA time zone, e.g. Asia/Tokyo, Europe/London, Africa/Nairobi. The app will never guess a location's time zone.")
                .setView(entry).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",(d,which)->{
                    String id=entry.getText().toString().trim();if(!id.isEmpty()&&!Arrays.asList(TimeZone.getAvailableIDs()).contains(id)){Toast.makeText(this,"Unknown timezone. Use an IANA name such as Europe/Paris.",Toast.LENGTH_LONG).show();return;}
                    SharedPreferences pref=getSharedPreferences(PLACES_PREFS,MODE_PRIVATE);try{JSONArray list=new JSONArray(pref.getString(FOLLOWED,"[]"));for(int k=0;k<list.length();k++){JSONObject item=list.optJSONObject(k);if(item!=null&&Math.abs(item.optDouble("lat",999)-lat)<0.001&&Math.abs(item.optDouble("lon",999)-lon)<0.001){item.put("timezone",id);break;}}pref.edit().putString(FOLLOWED,list.toString()).apply();renderPlaces();}catch(Exception e){Toast.makeText(this,"Clock could not be saved",Toast.LENGTH_SHORT).show();}
                }).show();
    }
    private Set<String> selections(){return new HashSet<>(getSharedPreferences(USER_PREFS,MODE_PRIVATE).getStringSet(INTERESTS,new HashSet<>()));}
    private void renderInterests(){if(interestsHolder==null)return;interestsHolder.removeAllViews();Set<String> selected=selections();for(String topic:TOPICS){final boolean active=selected.contains(topic);TextView control=button((active?"●  FOLLOWING  ":"○  FOLLOW  ")+topic,()->{
                Set<String> updated=selections();if(updated.contains(topic))updated.remove(topic);else updated.add(topic);
                getSharedPreferences(USER_PREFS,MODE_PRIVATE).edit().putStringSet(INTERESTS,updated).apply();renderInterests();
            });control.setTextColor(active?DuwmUnifiedTheme.LIVE:TEXT);interestsHolder.addView(control,spaced());}}
    @Override protected void onResume(){super.onResume();renderPlaces();handler.removeCallbacks(minuteRefresh);handler.postDelayed(minuteRefresh,60000);}
    @Override protected void onPause(){handler.removeCallbacks(minuteRefresh);super.onPause();}
    @Override protected void onDestroy(){closed=true;handler.removeCallbacks(minuteRefresh);super.onDestroy();}
}
