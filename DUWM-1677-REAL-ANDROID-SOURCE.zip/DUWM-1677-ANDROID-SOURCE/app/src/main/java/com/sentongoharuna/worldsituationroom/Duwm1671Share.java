package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.net.Uri;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;

/** Share any real observation as a branded, text-and-data 9:16 PNG. No stock/source image is invented. */
public final class Duwm1671Share {
  private Duwm1671Share(){}
  private static final int W=1080,H=1920;
  private static String utc(long t){if(t<=0)return "NO VERIFIED SOURCE TIME";SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm 'UTC'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(t));}
  private static int color(String kind){switch(kind.toUpperCase(Locale.ROOT)){case "AIRCRAFT":return 0xFF59D9EA;case "VESSEL":case "VESSELS":return 0xFF59DFB7;case "EARTHQUAKE":case "EARTHQUAKES":return 0xFFFA987E;case "MARKETS":return 0xFFF1C579;case "NEWS":return 0xFFCCA3EE;default:return 0xFF8DC7E6;}}
  private static void text(Canvas c,Paint p,String text,float size,int color,float x,float y,boolean bold){p.setColor(color);p.setTextSize(size);p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(text,x,y,p);}
  private static float wrap(Canvas c,Paint p,String input,float size,int color,float x,float y,int maxLines){
    if(input==null)input="";p.setTextSize(size);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
    String[] parts=input.replaceAll("[\\r\\n]+"," ").trim().split("\\s+");String line="";int n=0;
    for(String word:parts){String next=line.isEmpty()?word:line+" "+word;
      if(p.measureText(next)>940&&!line.isEmpty()){text(c,p,line,size,color,x,y,true);y+=size*1.32f;if(++n>=maxLines)return y;line=word;}
      else line=next;
      while(p.measureText(line)>940&&line.length()>2){int cut=line.length()-1;while(cut>2&&p.measureText(line.substring(0,cut))>940)cut--;
        text(c,p,line.substring(0,cut),size,color,x,y,true);y+=size*1.32f;n++;line=line.substring(cut);if(n>=maxLines)return y;}
    }if(!line.isEmpty()&&n<maxLines){text(c,p,line,size,color,x,y,true);y+=size*1.32f;}return y;
  }
  private static Bitmap draw(Activity a,String kind,String name,String details,String provider,String url,long received){
    Bitmap out=Bitmap.createBitmap(W,H,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(out);Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);c.drawColor(0xFF061522);
    int accent=color(kind);p.setColor(0xFF0E283A);for(int y=0;y<H;y+=110)c.drawRect(0,y,W,y+1,p);
    p.setColor(accent);c.drawRect(0,0,W,16,p);p.setColor(0xFF102A3E);c.drawRoundRect(46,55,1034,260,24,24,p);
    try{Bitmap logo=BitmapFactory.decodeResource(a.getResources(),R.drawable.develop_uganda_logo);
      if(logo!=null){c.drawBitmap(logo,null,new Rect(75,87,200,212),p);logo.recycle();}}catch(Exception ignored){}
    text(c,p,"DEVELOP.UGANDA",40,0xFFF2F9FC,230,127,true);
    text(c,p,"WORLD SITUATION ROOM / 1675",27,0xFFA7C5D7,230,183,false);
    text(c,p,kind.toUpperCase(Locale.ROOT)+"  /  INTELLIGENCE CARD",38,accent,68,335,true);
    p.setColor(accent);c.drawRect(68,357,1012,363,p);
    // A decorative measurement grid is explicitly NOT a geographic plot or data chart.
    p.setColor(0xFF102C3F);c.drawRoundRect(68,400,1012,1010,24,24,p);
    p.setColor(0xFF1D4758);p.setStrokeWidth(2);
    for(int x=115;x<990;x+=94)c.drawLine(x,430,x,973,p);
    for(int y=453;y<978;y+=94)c.drawLine(95,y,987,y,p);
    p.setColor(accent);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(6);c.drawCircle(540,707,186,p);c.drawCircle(540,707,110,p);c.drawLine(340,707,740,707,p);c.drawLine(540,507,540,907,p);p.setStyle(Paint.Style.FILL);
    text(c,p,"NO PUBLISHER PHOTO ATTACHED",25,0xFFD3E5EC,290,946,true);
    p.setColor(0xFF10283A);c.drawRoundRect(45,1060,1035,1780,24,24,p);
    float y=1150;y=wrap(c,p,name,54,0xFFF1F8FB,85,y,5)+42;
    text(c,p,"REPORTED INFORMATION",25,accent,85,y,true);y+=58;
    y=wrap(c,p,details,32,0xFFD1E1EA,85,y,10)+43;
    if(y>1630)y=1630;
    text(c,p,"SOURCE",24,accent,85,y,true);y+=47;
    y=wrap(c,p,provider==null?"UNKNOWN":provider,29,0xFFF2F7FB,85,y,2)+28;
    text(c,p,"RECEIVED: "+utc(received),23,0xFFE5F1F7,85,Math.min(1745,y+32),false);
    p.setColor(accent);c.drawRect(70,1817,1010,1822,p);
    String u=url==null?"NO SOURCE LINK":url;while(u.length()>22&&u.length()>90)u=u.substring(0,u.length()-1);
    text(c,p,u,20,0xFFA6C5D3,74,1860,false);
    text(c,p,"SOURCE DATA / NOT INDEPENDENTLY VERIFIED",23,0xFFE9F3F8,74,1900,true);
    return out;
  }
  public static void share(Activity a,String kind,String title,String details,String provider,String url,long when){
    if(a==null||a.isFinishing())return;
    if(title==null||title.trim().isEmpty()){Toast.makeText(a,"No record selected",Toast.LENGTH_SHORT).show();return;}
    new Thread(()->{try{
      Bitmap image=draw(a,kind,title,details,provider,url,when);
      File dir=new File(a.getCacheDir(),"share-cards");if(!dir.exists()&&!dir.mkdirs())throw new java.io.IOException("Cannot create card folder");
      String name="duwm1671-"+UUID.randomUUID().toString().substring(0,18)+".png";File file=new File(dir,name);
      try(FileOutputStream out=new FileOutputStream(file)){if(!image.compress(Bitmap.CompressFormat.PNG,100,out))throw new java.io.IOException("PNG export failed");}image.recycle();
      Uri uri=new Uri.Builder().scheme("content").authority(a.getPackageName()+".sharecards").appendPath(name).build();
      a.runOnUiThread(()->{if(a.isFinishing()||a.isDestroyed())return;
        Intent send=new Intent(Intent.ACTION_SEND);send.setType("image/png");send.putExtra(Intent.EXTRA_STREAM,uri);
        send.putExtra(Intent.EXTRA_TEXT,title+"\nSource: "+provider+"\n"+(url==null?"":url));
        send.setClipData(ClipData.newUri(a.getContentResolver(),"DUWM source card",uri));send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try{a.startActivity(Intent.createChooser(send,"Share verified-source card"));}catch(Exception e){Toast.makeText(a,"No compatible sharing app",Toast.LENGTH_LONG).show();}
      });
    }catch(Exception e){a.runOnUiThread(()->Toast.makeText(a,"Share card could not be created: "+e.getClass().getSimpleName(),Toast.LENGTH_LONG).show());}},"duwm1671-share").start();
  }
}
