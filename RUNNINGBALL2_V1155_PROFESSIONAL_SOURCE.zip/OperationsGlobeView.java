package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/** A navigation-capable globe: coastlines are Natural Earth, markers are observations only. */
public final class OperationsGlobeView extends View {
    public static final int AIR=1, QUAKE=2, SPACE=3;
    public static final class Observation {
        public final int type;
        public final double lat,lon;
        public final String title,detail,source;
        public final long timeMillis;
        public Observation(int type,double lat,double lon,String title,String detail,String source,long timeMillis){
            this.type=type;this.lat=lat;this.lon=lon;this.title=title;this.detail=detail;this.source=source;this.timeMillis=timeMillis;
        }
    }
    public interface OnObservationSelected {void onSelected(Observation item);}
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<List<double[]>> coastlines=new ArrayList<>();
    private final List<Observation> objects=new ArrayList<>();
    private OnObservationSelected listener;
    private boolean moving=false, aircraft=true,quakes=true,space=true,dragging=false;
    private long previousFrame=0;
    private double yaw=Math.toRadians(32), pitch=Math.toRadians(7);
    private float cx,cy,radius,zoom=1f,lastX,lastY,downX,downY;
    private int coastSegments=0;
    private final ScaleGestureDetector scaler;
    private final int SEA=Color.rgb(12,32,50), LAND=Color.rgb(115,167,158), GRID=Color.argb(75,112,158,171), EDGE=Color.rgb(63,123,142);

    public OperationsGlobeView(Context c){
        super(c);scaler=new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
            @Override public boolean onScale(ScaleGestureDetector d){zoom=Math.max(.85f,Math.min(1.55f,zoom*d.getScaleFactor()));invalidate();return true;}
        });loadCoasts();setContentDescription("Rotating Earth with observed aircraft, earthquakes and ISS positions. Drag to turn, pinch to zoom, tap a marker for details.");
    }
    public int getCoastSegmentCount(){return coastSegments;}
    public void setOnObservationSelected(OnObservationSelected l){listener=l;}
    public void setObservations(List<Observation> items){objects.clear();objects.addAll(items);invalidate();}
    public void showLayer(int kind,boolean enabled){if(kind==AIR)aircraft=enabled;else if(kind==QUAKE)quakes=enabled;else if(kind==SPACE)space=enabled;invalidate();}
    public void resume(){moving=true;previousFrame=SystemClock.uptimeMillis();postInvalidateOnAnimation();}
    public void pause(){moving=false;}
    @Override protected void onDetachedFromWindow(){pause();super.onDetachedFromWindow();}
    private int dp(float value){return (int)(value*getResources().getDisplayMetrics().density+.5f);}
    private void loadCoasts(){
        try(BufferedReader br=new BufferedReader(new InputStreamReader(getContext().getAssets().open("naturalearth_coasts.txt"),"UTF-8"))){
            String line;while((line=br.readLine())!=null){List<double[]> coast=new ArrayList<>();for(String pair:line.split(" ")){
                String[] v=pair.split(",");if(v.length!=2)continue;double lat=Double.parseDouble(v[0]),lon=Double.parseDouble(v[1]);
                if(Math.abs(lat)<=90&&Math.abs(lon)<=180)coast.add(new double[]{lat,lon});
            }if(coast.size()>=3){coastlines.add(coast);coastSegments++;}}
        }catch(Exception ignored){/* Missing coastline data is not replaced with invented geography. */}
    }
    private float[] project(double lat,double lon){
        double a=Math.toRadians(lat),b=Math.toRadians(lon)-yaw;
        double x=Math.cos(a)*Math.sin(b),y=Math.sin(a),z=Math.cos(a)*Math.cos(b);
        double cp=Math.cos(pitch),sp=Math.sin(pitch),tiltedY=y*cp-z*sp,depth=y*sp+z*cp;
        if(depth<=0.004d)return null;
        return new float[]{cx+(float)(radius*x),cy-(float)(radius*tiltedY)};
    }
    private boolean enabled(int kind){return kind==AIR?aircraft:kind==QUAKE?quakes:space;}
    private void strokePath(Canvas c,List<double[]> lines){Path path=new Path();boolean active=false;
        for(double[] spot:lines){float[] v=project(spot[0],spot[1]);if(v==null){active=false;continue;}
            if(!active){path.moveTo(v[0],v[1]);active=true;}else path.lineTo(v[0],v[1]);}c.drawPath(path,p);
    }
    private void grid(Canvas c,boolean meridian,int coordinate){Path path=new Path();boolean begun=false;
        for(int i=0;i<=180;i++){double lat=meridian?-90+i:coordinate,lon=meridian?coordinate:-180+2*i;
            float[] v=project(lat,lon);if(v==null){begun=false;continue;}
            if(!begun){path.moveTo(v[0],v[1]);begun=true;}else path.lineTo(v[0],v[1]);}c.drawPath(path,p);
    }
    private int tint(int kind){return kind==AIR?Color.rgb(99,184,207):kind==QUAKE?Color.rgb(238,166,105):Color.rgb(157,202,165);}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        if(moving&&!dragging){long now=SystemClock.uptimeMillis();long dt=Math.min(60,Math.max(0,now-previousFrame));yaw=(yaw+dt*.000105d)%(2*Math.PI);previousFrame=now;}
        float w=getWidth(),h=getHeight();cx=w/2f;cy=h*.49f;radius=Math.max(dp(20),Math.min(w*.445f,h*.458f)*zoom);
        canvas.drawColor(Color.rgb(7,15,25));
        p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(13,27,40));canvas.drawCircle(cx,cy,radius+dp(10),p);
        p.setShader(new LinearGradient(cx-radius,cy-radius,cx+radius,cy+radius,
                Color.rgb(23,57,72),SEA,Shader.TileMode.CLAMP));canvas.drawCircle(cx,cy,radius,p);p.setShader(null);
        canvas.save();Path clipping=new Path();clipping.addCircle(cx,cy,radius,Path.Direction.CW);canvas.clipPath(clipping);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(.65f));p.setColor(GRID);
        for(int i=-150;i<=180;i+=30)grid(canvas,true,i);
        for(int i=-60;i<=60;i+=30)grid(canvas,false,i);
        p.setColor(LAND);p.setStrokeWidth(dp(1.25f));for(List<double[]> coastline:coastlines)strokePath(canvas,coastline);
        int max=1300,shown=0;for(Observation a:objects){if(!enabled(a.type)||shown++>max)continue;
            float[] v=project(a.lat,a.lon);if(v==null)continue;
            int color=tint(a.type);p.setStyle(Paint.Style.FILL);p.setColor(Color.argb(65,Color.red(color),Color.green(color),Color.blue(color)));
            float ring=dp(a.type==AIR?3.6f:6.0f);canvas.drawCircle(v[0],v[1],ring,p);
            p.setColor(color);canvas.drawCircle(v[0],v[1],dp(a.type==AIR?1.6f:2.4f),p);
        }
        canvas.restore();p.setShader(null);p.setColor(EDGE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));canvas.drawCircle(cx,cy,radius,p);
        p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(132,153,165));p.setTextSize(dp(10));
        canvas.drawText("N",cx-dp(3),Math.max(dp(12),cy-radius-dp(8)),p);
        if(moving)postInvalidateDelayed(33);
    }
    @Override public boolean onTouchEvent(MotionEvent e){scaler.onTouchEvent(e);if(scaler.isInProgress())return true;
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN: downX=lastX=e.getX();downY=lastY=e.getY();dragging=true;return true;
            case MotionEvent.ACTION_MOVE:
                float dx=e.getX()-lastX,dy=e.getY()-lastY;
                yaw-=dx/Math.max(1f,radius)*.68d;pitch=Math.max(-.55d,Math.min(.55d,pitch+dy/Math.max(1f,radius)*.35d));
                lastX=e.getX();lastY=e.getY();invalidate();return true;
            case MotionEvent.ACTION_CANCEL: dragging=false;previousFrame=SystemClock.uptimeMillis();return true;
            case MotionEvent.ACTION_UP:
                dragging=false;previousFrame=SystemClock.uptimeMillis();
                if(Math.abs(e.getX()-downX)<dp(10)&&Math.abs(e.getY()-downY)<dp(10)){
                    Observation nearest=null;float best=dp(19)*dp(19);
                    for(Observation item:objects){if(!enabled(item.type))continue;float[] point=project(item.lat,item.lon);if(point==null)continue;
                        float a=point[0]-e.getX(),b=point[1]-e.getY(),dist=a*a+b*b;if(dist<best){best=dist;nearest=item;}}
                    if(nearest!=null&&listener!=null)listener.onSelected(nearest);else performClick();}
                invalidate();return true;
            default:return true;
        }
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
