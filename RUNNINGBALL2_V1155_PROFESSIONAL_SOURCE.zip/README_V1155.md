# DEVELOP.UGANDA — V1155 Professional Operations UI

This version is an actual native Android source change, not a change to the app's version name alone.

## New or revised components

- `OperationsMainActivity.java` — professional globe-first home screen, eight monitoring destinations, source-health status, received counts, timestamps, selectable reported geolocations, and manual refresh.
- `OperationsGlobeView.java` — real Natural Earth coastline display (using the existing V1154 asset), three observed-data marker classes, rotation, touch drag, pinch zoom, and selection callbacks.
- `upgrade_v1155.py` — adds the new classes, changes exactly one Android launcher, preserves the existing V1154 sources and wallpaper, and gives the installed app version code 1155. It also visually restyles the existing `WorldSourceHubActivity` without replacing its data provider logic.

## Data integrity

The globe plots only provider-returned aircraft, earthquakes and ISS coordinates. It does not simulate ship tracks, camera feeds, or network traffic. AIS and embedded cameras continue to require legitimate provider access. Source response errors are displayed rather than hidden. CI HTTP probes do not prove device reception.

## Release acceptance gates

The workflow must successfully compile the new Java classes and verify their presence in APK DEX. It then runs an Android emulator with Bash (fixing the V1154 `/bin/sh` failure), captures two Earth frames, and asserts observable globe-region motion. It opens the Aircraft category through a real UI tap and verifies the source view. Only after emulator testing does it publish a direct `.apk` through GitHub Releases.

## Limitations

V1155 must compile and pass emulator gates before its features are described as working. Full commercial-grade integration of AIS, licenced camera streams, broadcast playback, and international network telemetry is not part of this UI-focused version.
