package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Operational home screen. Presentation never substitutes for observed source records. */
public final class OperationsMainActivity extends Activity {
    private static final int BG=Color.rgb(7,15,25), PANEL=Color.rgb(16,29,42), BORDER=Color.rgb(41,61,75);
    private static final int TEXT=Color.rgb(225,236,240), MUTED=Color.rgb(146,166,177), ACCENT=Color.rgb(110,188,203), WARN=Color.rgb(228,173,111);
    private static final long REFRESH_MS=180000L;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService network=Executors.newSingleThreadExecutor();
    private final AtomicBoolean fetching=new AtomicBoolean(false);
    private OperationsGlobeView earth;
    private TextView headerStatus,clock,updatedText,summaryText,airCount,quakeCount,issCount,airSource,quakeSource,issSource,detail;
    private TextView airLayer,quakeLayer,issLayer,rotationControl;
    private boolean viewAir=true,viewQuakes=true,viewIss=true,rotate=true,foreground=false;
    private long lastAttempt=Long.MIN_VALUE/2;
    private final Runnable second=new Runnable(){@Override public void run(){
        if(!foreground)return;clock.setText(utc(System.currentTimeMillis())+" UTC");
        if(!fetching.get() && SystemClock.elapsedRealtime()-lastAttempt>=REFRESH_MS)refresh();
        main.postDelayed(this,1000);
    }};
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private String utc(long ms){SimpleDateFormat f=new SimpleDateFormat("dd MMM yyyy   HH:mm:ss",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(ms));}
    private TextView text(String s,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(sp);if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return t;}
    private GradientDrawable bg(int color,float corner,int line){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(corner));if(line!=0)d.setStroke(dp(1),line);return d;}
    private void rowAdd(LinearLayout row,View child,int width,int height){row.addView(child,new LinearLayout.LayoutParams(width<0?width:dp(width),height<0?height:dp(height)));}
    private TextView action(String label, String description){TextView t=text(label,11,ACCENT,true);t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12),dp(8),dp(12),dp(8));t.setBackground(bg(PANEL,5,BORDER));t.setContentDescription(description);return t;}
    private LinearLayout metric(LinearLayout parent,String title){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(10),dp(10),dp(9));card.setBackground(bg(PANEL,7,BORDER));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(95),1);cp.rightMargin=dp(6);parent.addView(card,cp);
        TextView header=text(title,10,MUTED,true);card.addView(header);return card;
    }
    private void navigate(String mode){Intent intent=new Intent(this,WorldSourceHubActivity.class);intent.putExtra("mode",mode);startActivity(intent);}
    @Override public void onCreate(Bundle state){super.onCreate(state);setTheme(android.R.style.Theme_Material_NoActionBar);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        LinearLayout root=new LinearLayout(this);root.setBackgroundColor(BG);root.setOrientation(LinearLayout.VERTICAL);setContentView(root);
        LinearLayout heading=new LinearLayout(this);heading.setGravity(Gravity.CENTER_VERTICAL);heading.setPadding(dp(16),dp(10),dp(16),dp(6));rowAdd(root,heading,-1,66);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.develop_uganda_logo);heading.addView(logo,new LinearLayout.LayoutParams(dp(43),dp(43)));
        LinearLayout brand=new LinearLayout(this);brand.setOrientation(LinearLayout.VERTICAL);brand.setPadding(dp(11),0,0,0);heading.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        brand.addView(text("DEVELOP.UGANDA",18,TEXT,true));brand.addView(text("WORLD SITUATION ROOM  /  OPERATIONS",10,MUTED,true));
        headerStatus=text("CONNECTING",10,ACCENT,true);headerStatus.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);rowAdd(heading,headerStatus,92,40);
        LinearLayout metadata=new LinearLayout(this);metadata.setPadding(dp(16),dp(2),dp(16),dp(8));metadata.setGravity(Gravity.CENTER_VERTICAL);rowAdd(root,metadata,-1,34);
        clock=text("UTC --",11,MUTED,false);metadata.addView(clock,new LinearLayout.LayoutParams(0,-2,1));
        updatedText=text("NO SOURCE SYNC",10,MUTED,true);metadata.addView(updatedText,new LinearLayout.LayoutParams(-2,-2));
        HorizontalScrollView scroller=new HorizontalScrollView(this);scroller.setHorizontalScrollBarEnabled(false);rowAdd(root,scroller,-1,60);
        LinearLayout tabs=new LinearLayout(this);tabs.setGravity(Gravity.CENTER_VERTICAL);tabs.setPadding(dp(14),0,dp(8),0);scroller.addView(tabs);
        String[][] categories={{"AIRCRAFT","AIRCRAFT"},{"VESSELS","VESSELS"},{"SATELLITES","SATELLITES"},{"CITY CAMERAS","CITY CAMERAS"},
                {"NEWS","WORLD NEWS"},{"RADIO","RADIO"},{"TELEVISION","TV STATIONS"},{"INTERNET","INTERNET"}};
        for(String[] c:categories){TextView tab=action(c[0],"Open " + c[1] + " monitoring sources");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(46));lp.rightMargin=dp(7);tabs.addView(tab,lp);tab.setOnClickListener(v->navigate(c[1]));}
        LinearLayout globeFrame=new LinearLayout(this);globeFrame.setOrientation(LinearLayout.VERTICAL);globeFrame.setBackground(bg(Color.rgb(9,19,31),0,0));
        root.addView(globeFrame,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout globeHeading=new LinearLayout(this);globeHeading.setGravity(Gravity.CENTER_VERTICAL);globeHeading.setPadding(dp(16),dp(8),dp(16),0);rowAdd(globeFrame,globeHeading,-1,37);
        TextView globeLabel=text("EARTH  /  GEOGRAPHIC OVERVIEW",11,MUTED,true);globeHeading.addView(globeLabel,new LinearLayout.LayoutParams(0,-2,1));
        rotationControl=action("ROTATION  ON","Toggle globe rotation");rowAdd(globeHeading,rotationControl,112,35);
        rotationControl.setOnClickListener(v->{rotate=!rotate;rotationControl.setText(rotate?"ROTATION  ON":"ROTATION  OFF");if(rotate&&foreground)earth.resume();else earth.pause();});
        earth=new OperationsGlobeView(this);globeFrame.addView(earth,new LinearLayout.LayoutParams(-1,0,1));
        earth.setOnObservationSelected(item->{detail.setText(item.title+"  •  "+item.detail+"  |  "+item.source+"  |  "+(item.timeMillis>0?utc(item.timeMillis)+" UTC":"TIME NOT SUPPLIED"));});
        LinearLayout layers=new LinearLayout(this);layers.setGravity(Gravity.CENTER_VERTICAL);layers.setPadding(dp(15),0,dp(12),0);rowAdd(globeFrame,layers,-1,47);
        airLayer=layer(layers,"AIRCRAFT",OperationsGlobeView.AIR);
        quakeLayer=layer(layers,"EARTHQUAKES",OperationsGlobeView.QUAKE);
        issLayer=layer(layers,"ISS",OperationsGlobeView.SPACE);
        detail=text("Drag to turn • pinch to zoom • tap an observed marker for details",11,MUTED,false);detail.setPadding(dp(16),dp(5),dp(16),dp(7));
        detail.setMaxLines(2);rowAdd(globeFrame,detail,-1,48);
        ScrollView infoScroll=new ScrollView(this);infoScroll.setFillViewport(false);root.addView(infoScroll,new LinearLayout.LayoutParams(-1,dp(245)));
        LinearLayout information=new LinearLayout(this);information.setOrientation(LinearLayout.VERTICAL);information.setPadding(dp(13),dp(11),dp(13),dp(14));infoScroll.addView(information);
        LinearLayout titleRow=new LinearLayout(this);titleRow.setGravity(Gravity.CENTER_VERTICAL);information.addView(titleRow,new LinearLayout.LayoutParams(-1,dp(32)));
        TextView section=text("OBSERVATION STATUS",12,TEXT,true);titleRow.addView(section,new LinearLayout.LayoutParams(0,-2,1));
        TextView refresh=action("REFRESH","Request updated observed records");rowAdd(titleRow,refresh,94,36);refresh.setOnClickListener(v->refresh());
        summaryText=text("No remote source has responded",11,MUTED,false);summaryText.setPadding(dp(2),dp(7),0,dp(9));information.addView(summaryText);
        LinearLayout cards=new LinearLayout(this);rowAdd(information,cards,-1,100);
        LinearLayout airCard=metric(cards,"AIRCRAFT / OPENSKY");airCount=text("—",19,TEXT,true);airCard.addView(airCount);airSource=text("NOT CHECKED",10,MUTED,false);airSource.setMaxLines(2);airCard.addView(airSource);
        LinearLayout quakeCard=metric(cards,"QUAKES / USGS");quakeCount=text("—",19,TEXT,true);quakeCard.addView(quakeCount);quakeSource=text("NOT CHECKED",10,MUTED,false);quakeSource.setMaxLines(2);quakeCard.addView(quakeSource);
        LinearLayout issCard=metric(cards,"ISS / OBSERVED");issCount=text("—",19,TEXT,true);issCard.addView(issCount);issSource=text("NOT CHECKED",10,MUTED,false);issSource.setMaxLines(2);issCard.addView(issSource);
        TextView foot=text("Source counts and markers are based on received records. An unavailable feed is not evidence of no activity. AIS vessels and embedded cameras require approved providers.",11,MUTED,false);
        foot.setPadding(dp(3),dp(12),dp(3),dp(8));information.addView(foot);
        TextView original=action("OPEN ORIGINAL COMMAND CENTRE","Open the preserved original monitoring dashboard");
        information.addView(original,new LinearLayout.LayoutParams(-1,dp(48)));original.setOnClickListener(v->{Intent i=new Intent(this,MainActivity.class);startActivity(i);});
    }
    private TextView layer(LinearLayout parent,String label,int type){TextView v=text("● "+label,11,type==OperationsGlobeView.AIR?ACCENT:type==OperationsGlobeView.QUAKE?WARN:Color.rgb(162,203,170),true);
        v.setGravity(Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(44),type==OperationsGlobeView.QUAKE?1.25f:1);parent.addView(v,p);
        v.setContentDescription("Toggle " + label + " map layer");v.setOnClickListener(w->{boolean next;if(type==OperationsGlobeView.AIR){viewAir=!viewAir;next=viewAir;}
            else if(type==OperationsGlobeView.QUAKE){viewQuakes=!viewQuakes;next=viewQuakes;}else {viewIss=!viewIss;next=viewIss;}
            earth.showLayer(type,next);v.setAlpha(next?1f:.35f);});return v;}
    @Override protected void onResume(){super.onResume();foreground=true;if(rotate)earth.resume();main.post(second);}
    @Override protected void onPause(){foreground=false;earth.pause();main.removeCallbacks(second);super.onPause();}
    @Override protected void onDestroy(){network.shutdownNow();super.onDestroy();}

    private String get(String address,int limit) throws Exception {
        if(!address.startsWith("https://"))throw new java.io.IOException("HTTPS required");
        HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);
        c.setRequestProperty("User-Agent","DevelopUgandaOperations/1155");c.setRequestProperty("Accept","application/json");
        try{int code=c.getResponseCode();if(code!=200)throw new java.io.IOException("HTTP "+code);
            StringBuilder s=new StringBuilder();try(InputStream in=c.getInputStream();BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"))){
                char[] buf=new char[4096];int n;while((n=r.read(buf))!=-1){s.append(buf,0,n);if(s.length()>limit)throw new java.io.IOException("Response exceeds source limit");}}
            return s.toString();
        }finally{c.disconnect();}
    }
    private boolean valid(double lat,double lon){return Double.isFinite(lat)&&Double.isFinite(lon)&&lat>=-90&&lat<=90&&lon>=-180&&lon<=180;}
    private String error(Exception ex){String e=ex.getMessage();if(e==null)e=ex.getClass().getSimpleName();return e.length()>65?e.substring(0,65):e;}
    private void refresh(){if(!fetching.compareAndSet(false,true))return;lastAttempt=SystemClock.elapsedRealtime();
        headerStatus.setText("SYNCING");summaryText.setText("Requesting observed records from source providers…");
        network.execute(()->{
            List<OperationsGlobeView.Observation> observations=new ArrayList<>();
            int sourceOk=0,sourceCount=3, aircraftReported=0,located=0,quakesReported=0;
            String air="NO RESPONSE",quake="NO RESPONSE",iss="NO RESPONSE",issValue="—";
            String aircraftValue="—",quakeValue="—";
            try{
                JSONObject payload=new JSONObject(get("https://opensky-network.org/api/states/all",6500000));
                JSONArray a=payload.optJSONArray("states");if(a==null)throw new java.io.IOException("States array absent");
                aircraftReported=a.length();int skip=Math.max(1,a.length()/900);long observedTime=payload.optLong("time",0)*1000L;
                for(int i=0;i<a.length();i++){JSONArray x=a.optJSONArray(i);if(x==null||x.isNull(5)||x.isNull(6))continue;
                    double lon=x.optDouble(5,Double.NaN),lat=x.optDouble(6,Double.NaN);if(!valid(lat,lon))continue;located++;
                    if(i%skip!=0)continue;String callsign=x.optString(1,"").trim();String ident=x.optString(0,"");if(callsign.isEmpty())callsign=ident;
                    double altitude=x.optDouble(7,Double.NaN),speed=x.optDouble(9,Double.NaN);
                    String info=String.format(Locale.US,"%.3f°, %.3f° • alt %s • speed %s",lat,lon,Double.isFinite(altitude)?String.format(Locale.US,"%.0f m",altitude):"unknown",Double.isFinite(speed)?String.format(Locale.US,"%.0f m/s",speed):"unknown");
                    observations.add(new OperationsGlobeView.Observation(OperationsGlobeView.AIR,lat,lon,callsign,info,"OpenSky",observedTime));
                }
                sourceOk++;aircraftValue=String.format(Locale.US,"%,d",aircraftReported);
                air="Observed "+(observedTime>0?utc(observedTime)+" UTC":"UTC not supplied");
            }catch(Exception ex){air="Unavailable: "+error(ex);}
            try{
                JSONObject payload=new JSONObject(get("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson",1500000));
                JSONArray arr=payload.getJSONArray("features");quakesReported=arr.length();
                for(int i=0;i<Math.min(arr.length(),350);i++){JSONObject event=arr.optJSONObject(i);if(event==null)continue;
                    JSONObject g=event.optJSONObject("geometry"),prop=event.optJSONObject("properties");if(g==null||prop==null)continue;
                    JSONArray coords=g.optJSONArray("coordinates");if(coords==null||coords.length()<2)continue;
                    double lon=coords.optDouble(0,Double.NaN),lat=coords.optDouble(1,Double.NaN);if(!valid(lat,lon))continue;
                    String title="M"+String.format(Locale.US,"%.1f",prop.optDouble("mag",0)) + "  "+prop.optString("place","location not reported");
                    observations.add(new OperationsGlobeView.Observation(OperationsGlobeView.QUAKE,lat,lon,title,String.format(Locale.US,"%.3f°, %.3f°",lat,lon),"USGS",prop.optLong("time",0)));
                }
                sourceOk++;quakeValue=Integer.toString(quakesReported);quake="M4.5+ / last 24 h";
            }catch(Exception ex){quake="Unavailable: "+error(ex);}
            try{
                JSONObject data=new JSONObject(get("https://api.wheretheiss.at/v1/satellites/25544",85000));
                double lat=data.optDouble("latitude",Double.NaN),lon=data.optDouble("longitude",Double.NaN);
                long seen=data.optLong("timestamp",0)*1000L;
                if(!valid(lat,lon)||seen<=0||Math.abs(System.currentTimeMillis()-seen)>900000L)throw new java.io.IOException("Stale or missing reported position");
                observations.add(new OperationsGlobeView.Observation(OperationsGlobeView.SPACE,lat,lon,"ISS — International Space Station",String.format(Locale.US,"%.3f°, %.3f° • altitude %.1f km",lat,lon,data.optDouble("altitude",0)),"Where The ISS At",seen));
                issValue="POSITION";iss="Observed "+utc(seen)+" UTC";sourceOk++;
            }catch(Exception ex){iss="Unavailable: "+error(ex);}
            final String fa=air,fq=quake,fi=iss,fav=aircraftValue,fqv=quakeValue,fiv=issValue;
            final int ok=sourceOk, plotted=observations.size(),validPositions=located,totalAir=aircraftReported;
            main.post(()->{fetching.set(false);if(isFinishing()||isDestroyed())return;
                airCount.setText(fav);quakeCount.setText(fqv);issCount.setText(fiv);
                airSource.setText(fa);quakeSource.setText(fq);issSource.setText(fi);
                earth.setObservations(observations);
                headerStatus.setText(ok>0?ok+"/3 READY":"OFFLINE");
                updatedText.setText(ok>0?"SYNC " + utc(System.currentTimeMillis()).substring(12)+" UTC":"SOURCE UNAVAILABLE");
                summaryText.setText(ok+" of "+sourceCount+" providers responded • "+plotted+" mapped observations • "+validPositions+" located aircraft of "+totalAir+" reported");
            });
        });
    }
}
