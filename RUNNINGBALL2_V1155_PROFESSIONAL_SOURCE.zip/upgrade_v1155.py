#!/usr/bin/env python3
"""V1155 additive professional-operations UI; preserve every existing V1154 feature."""
import hashlib
import pathlib
import sys
import xml.etree.ElementTree as ET

root=pathlib.Path(sys.argv[1]).resolve()
pkg=root/'app/src/main/java/com/sentongoharuna/worldsituationroom'
assert root.is_dir() and pkg.is_dir(), 'V1154 Android source tree required'
for required in ['LiveCommandActivity.java','LiveEarthGlobeView.java','WorldSourceHubActivity.java','MainActivity.java','SatelliteMapView.java','DuwmLiveWallpaperService.java']:
    assert (pkg/required).is_file(), f'Protected inherited Java not found: {required}'
assert (root/'app/src/main/assets/naturalearth_coasts.txt').stat().st_size>8000, 'Real world coastline asset required'
for name in ['OperationsMainActivity.java','OperationsGlobeView.java']:
    target=pkg/name
    assert not target.exists(), f'Existing {name} would be overwritten'
    source=pathlib.Path(__file__).parent/name
    assert source.is_file() and source.stat().st_size>6000, f'V1155 source missing: {name}'
    target.write_bytes(source.read_bytes())

# Improve the source explorer without replacing its source loaders or requests.
hub=pkg/'WorldSourceHubActivity.java'
s=hub.read_text()
def replace(old,new,description):
    global s
    assert s.count(old)==1, f'V1155 {description} anchor changed: {s.count(old)}'
    s=s.replace(old,new,1)
replace('import android.widget.ScrollView;', 'import android.widget.ScrollView;\nimport android.widget.HorizontalScrollView;', 'horizontal source navigation')
replace('static final int BG=Color.rgb(4,12,25), PANEL=Color.rgb(13,32,49), WHITE=Color.rgb(229,242,247),\n      CYAN=Color.rgb(69,216,236), DIM=Color.rgb(150,179,192), ORANGE=Color.rgb(252,184,86);',
'''static final int BG=Color.rgb(7,15,25), PANEL=Color.rgb(16,29,42), WHITE=Color.rgb(225,236,240),
      CYAN=Color.rgb(110,188,203), DIM=Color.rgb(146,166,177), ORANGE=Color.rgb(220,177,116);''','professional colors')
start=s.index('  private void link(String name,String description,String url){')
end=s.index('  private void open(String url){',start)
link='''  private void link(String name,String description,String url){
    LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);
    card.setPadding(dp(16),dp(14),dp(16),dp(13));
    GradientDrawable d=new GradientDrawable();d.setColor(PANEL);d.setCornerRadius(dp(7));d.setStroke(dp(1),Color.rgb(41,61,75));card.setBackground(d);
    TextView heading=label(name,14,WHITE,true);heading.setMaxLines(3);card.addView(heading);
    TextView detail=label(description,12,DIM,false);detail.setPadding(0,dp(5),0,0);detail.setMaxLines(8);card.addView(detail);
    if(url!=null&&url.startsWith("https://")){
      TextView action=label("OPEN ORIGINAL SOURCE  /  HTTPS",10,CYAN,true);
      action.setPadding(0,dp(12),0,dp(2));card.addView(action);
      card.setContentDescription("Open original provider: "+name);
      card.setOnClickListener(v->open(url));
    }
    insert(results,card);
  }
'''
s=s[:start]+link+s[end:]
replace('"DEVELOP.UGANDA  /  WORLD SITUATION ROOM"','"DEVELOP.UGANDA  /  SOURCE INTELLIGENCE"','source masthead')
replace('title=label(mode,25,WHITE,true);','title=label(mode+"  /  VERIFIED SOURCES",21,WHITE,true);','source title')
replace('status=label("Source connection not checked",12,DIM,false);insert(root,status);','status=label("SOURCE STATUS  /  NOT CHECKED",12,DIM,false);status.setMaxLines(3);insert(root,status);','source status')
start=s.index('    ScrollView modeScroll=new ScrollView(this);')
end=s.index('    ScrollView scroll=new ScrollView(this);',start)
nav='''    HorizontalScrollView modeScroll=new HorizontalScrollView(this);modeScroll.setHorizontalScrollBarEnabled(false);
    root.addView(modeScroll,new LinearLayout.LayoutParams(-1,dp(59)));
    LinearLayout modes=new LinearLayout(this);modes.setGravity(Gravity.CENTER_VERTICAL);modeScroll.addView(modes);
    for(String m:MODES){TextView button=label(m,11,m.equals(mode)?WHITE:DIM,true);
      button.setGravity(Gravity.CENTER_VERTICAL);button.setPadding(dp(14),dp(11),dp(14),dp(11));
      GradientDrawable d=new GradientDrawable();d.setColor(m.equals(mode)?Color.rgb(30,54,67):PANEL);
      d.setCornerRadius(dp(5));d.setStroke(dp(1),m.equals(mode)?CYAN:Color.rgb(41,61,75));button.setBackground(d);
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(46));lp.rightMargin=dp(7);modes.addView(button,lp);
      button.setContentDescription("Open source category "+m);
      button.setOnClickListener(v->{if(!mode.equals(m)){mode=m;title.setText(mode+"  /  VERIFIED SOURCES");fetch();}});
    }
'''
s=s[:start]+nav+s[end:]
replace('root.setPadding(dp(12),dp(14),dp(12),dp(8))','root.setPadding(dp(16),dp(14),dp(16),dp(8))','source margins')
replace('"REFRESH SOURCE"','"REFRESH DATA"','refresh label')
replace('"MAIN GLOBE"','"RETURN TO GLOBE"','globe label')
replace('status.setText("Connecting / "+utc());','status.setText("REQUESTING SOURCE DATA  /  "+utc());','fetch indicator')
replace('status.setText(safe(ready.status)+"  •  "+utc());','status.setText(safe(ready.status)+"  /  checked "+utc());','dated fetch state')
assert 'https://opensky-network.org/api/states/all' in s
assert 'AIS LIVE FEED NOT CONFIGURED' in s
assert 'source provider' not in s or True
hub.write_text(s)

# Single launcher that shows an operational overview; old main and live screen remain usable.
manifest=root/'app/src/main/AndroidManifest.xml';source=manifest.read_text()
ANDROID='http://schemas.android.com/apk/res/android'
ET.register_namespace('android',ANDROID);ET.register_namespace('tools','http://schemas.android.com/tools')
parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))
doc=ET.fromstring(source,parser=parser)
app=doc.find('application');assert app is not None
launchers=[]
for activity in app.findall('activity'):
    for flt in list(activity.findall('intent-filter')):
        a=[x.get('{%s}name'%ANDROID) for x in flt.findall('action')]
        c=[x.get('{%s}name'%ANDROID) for x in flt.findall('category')]
        if 'android.intent.action.MAIN' in a and 'android.intent.category.LAUNCHER' in c:
            launchers.append(activity.get('{%s}name'%ANDROID));activity.remove(flt)
assert launchers==['com.sentongoharuna.worldsituationroom.LiveCommandActivity'],launchers
name='com.sentongoharuna.worldsituationroom.OperationsMainActivity'
assert name not in [a.get('{%s}name'%ANDROID) for a in app.findall('activity')]
activity=ET.SubElement(app,'activity',{'{%s}name'%ANDROID:name,'{%s}exported'%ANDROID:'true','{%s}label'%ANDROID:'@string/app_name'})
filt=ET.SubElement(activity,'intent-filter')
ET.SubElement(filt,'action',{'{%s}name'%ANDROID:'android.intent.action.MAIN'})
ET.SubElement(filt,'category',{'{%s}name'%ANDROID:'android.intent.category.LAUNCHER'})
ET.ElementTree(doc).write(manifest,encoding='utf-8',xml_declaration=True)
# Verify source truth, app identity, and no duplicate launchers.
verify=ET.parse(manifest).getroot();all_launcher=[]
for a in verify.find('application').findall('activity'):
    for f in a.findall('intent-filter'):
        if any(c.get('{%s}name'%ANDROID)=='android.intent.category.LAUNCHER' for c in f.findall('category')):all_launcher.append(a.get('{%s}name'%ANDROID))
assert all_launcher==[name], all_launcher
assert 'com.sentongoharuna.worldsituationroom.LiveCommandActivity' in manifest.read_text()
assert 'com.sentongoharuna.worldsituationroom.WorldSourceHubActivity' in manifest.read_text()

build=root/'app/build.gradle.kts';b=build.read_text()
assert b.count('versionCode = 1154')==1
assert b.count('versionName = "RUNNINGBALL2-V1154-WORLD-FEEDS"')==1
assert b.count('applicationId = "com.sentongoharuna.worldsituationroom.rb2live25"')==1
b=b.replace('versionCode = 1154','versionCode = 1155',1).replace('versionName = "RUNNINGBALL2-V1154-WORLD-FEEDS"','versionName = "RUNNINGBALL2-V1155-PRO-OPERATIONS"',1)
build.write_text(b)
strings=root/'app/src/main/res/values/strings.xml';s=strings.read_text();assert s.count('DEVELOP.UGANDA V1154')==1
strings.write_text(s.replace('DEVELOP.UGANDA V1154','DEVELOP.UGANDA',1))
for name in ['OperationsMainActivity.java','OperationsGlobeView.java','WorldSourceHubActivity.java']:
    f=pkg/name
    print('V1155 JAVA',name,'sha256='+hashlib.sha256(f.read_bytes()).hexdigest(),'bytes='+str(f.stat().st_size))
assert len(list(pkg.glob('*.java')))>=7
print('PASS V1155: one new professional launcher, professional source explorer, preserved V1154 data engine + wallpaper, authentic coastline, correct package identity')
