# DU World Monitor — Globe Only Rule
THE GLOBE IS THE APP.
Primary navigation contains only GLOBE, LAYERS, SEARCH, TIMELINE and SET.
NEWS, MONITORS, REGION, REPLAY, AIR, SEA, WEATHER, ORBIT, EVENTS and INFRA remain information engines/layers feeding the Globe; they are not competing primary pages.
The existing Globe implementation is preserved; this build changes navigation/ownership around it.
