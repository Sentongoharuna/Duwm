#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";M="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/MainActivity.java"
grep -F 'F17 / 20 — STATE & BACK NAVIGATION' "$M" >/dev/null
grep -F 'F17_PREFS="f9_view_state"' "$M" >/dev/null
grep -F '.putString("country",f9CountryLens)' "$M" >/dev/null
grep -F '.putString("window",f12ReplayWindow)' "$M" >/dev/null
grep -F '.putLong("anchor",f13ReplayAnchorMs)' "$M" >/dev/null
grep -F '.putString("category",catalogNewsType)' "$M" >/dev/null
grep -F '.putString("query"' "$M" >/dev/null
grep -F '.putInt("visible",catalogVisibleLimit)' "$M" >/dev/null
grep -F 'f17RestoreState();rebuildLocalNewsPage()' "$M" >/dev/null
grep -F 'if ("NEWS".equals(catalogCategory)) f17RestoreState()' "$M" >/dev/null
grep -F 'f17BeforeDetail();showLocalNewsDetail' "$M" >/dev/null
grep -F 'CrashLedger.record(this,"F17_SAVE",e)' "$M" >/dev/null
grep -F 'CrashLedger.record(this,"F17_RESTORE",e)' "$M" >/dev/null
# cumulative ownership
grep -F 'f11CountryMatches(n,f9CountryLens)' "$M" >/dev/null
grep -F 'f12ReplayMatches(n)' "$M" >/dev/null
grep -F 'f13ReplayAnchorMs' "$M" >/dev/null
grep -F 'addF14Related(box,n)' "$M" >/dev/null
grep -F 'addF15UnifiedResults(catalogList,unifiedQuery)' "$M" >/dev/null
grep -F 'f16StateLine(f16NewsState(all,offline,prefs))' "$M" >/dev/null
! find "$P/app/src/main/java" -name '*F17*Activity.java' -print -quit | grep -q .
test "$(find "$P/app/src/main/java" -name 'NewsStore.java' | wc -l)" -eq 1
echo "F17 STATE & BACK NAVIGATION CONTRACT PASS"
