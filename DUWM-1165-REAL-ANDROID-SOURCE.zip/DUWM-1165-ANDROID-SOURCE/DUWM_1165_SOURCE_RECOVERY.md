# DUWM World Situation Room — native source recovery

This is the actual Android project reconstructed from the protected RUNNINGBALL2 baseline, original V24–V109 source chain and V1159/1160 source modules, then installed P1–P4 functional modules and the explicit native/real-map repairs.

## Verified local changes
- Main app now selects the original native `SatelliteMapView` on startup rather than making it a secondary button overlay.
- Native source-marker taps resolve against actual received aircraft/earthquake/ISS records. Unmatched markers cannot be shared as verified records.
- Modern globe frame counter/degree telemetry now increments when actual rotation is applied. Native globe revolution rate matches its documented 5.5 minutes.
- Both main and place-map screens embed existing source signal lights in reserved layout rows, rather than overlay the navigation or ISS card.
- Status/navigation bar insets are applied on modern Android and screen chrome is compacted.
- Map WebView includes a dependency-free, actual OSM-tile slippy renderer with scroll, pinch, zoom, provider-marker filtering, source timestamps, selection, and observed two-point traces.
- P1 worldwide dashboard, P2 map record bridge, P3 selection, P4 radio/TV and NPS camera source modules remain in the original app; no fake AIS vessel positions are added.

## Limits not disguised as successes
- Local Chromium map-control and data-filter checks passed, with all web tile requests blocked by the isolated environment. Internet tile loading on your phone is unverified.
- Java source was syntax-parsed locally but the Android SDK is not installed in this container; full Gradle compilation must run in the provided GitHub workflow.
- External live feeds, television/radio and camera streams have not been live-tested here. They can fail owing to source restrictions or connectivity.
- No compiled APK is claimed in this zip. Only an APK emitted from GitHub after signature and DEX checks should be installed.

The exact workflow is `DUWM-1165-REAL-SOURCE-APK.yml`, and the expected GitHub artifact is `DUWM-1165-REAL-SOURCE-APK`.
