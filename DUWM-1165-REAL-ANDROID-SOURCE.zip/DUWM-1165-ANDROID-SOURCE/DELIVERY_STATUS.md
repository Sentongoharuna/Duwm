# DUWM 1165 — real Android source delivery

## Evidence of actual modifications

- `app/src/main/java/com/sentongoharuna/worldsituationroom/OperationsMainActivity.java`: selects original `SatelliteMapView` on startup, moves rotation/native/focus controls out of the compressed globe title, centers observations on the visible original renderer, embeds source LEDs in reserved layout space.
- `app/src/main/java/com/sentongoharuna/worldsituationroom/SatelliteMapView.java`: original globe retains geographical/coastline/shading engine and now exposes a real auto-rotation toggle with touch-pause behavior.
- `app/src/main/java/com/sentongoharuna/worldsituationroom/DuwmPlaceMapActivity.java`: self-contained map HTML is loaded with a robust stream read; Android probes real map/tiles status rather than claiming online operation from a button label; requests use the app-assets page origin.
- `app/src/main/assets/duwm_place_map.html`: source-only positions, stale/invalid/null rejection, real OSM tile URLs, zoom, home, fit, tap to select, category filters, coordinate focus and honest AIS unavailable state.
- `app/src/main/java/com/sentongoharuna/worldsituationroom/DuwmSignalRail.java`: compact reserved source-status indicator.
- `app/src/main/java/com/sentongoharuna/worldsituationroom/OperationsGlobeView.java`: existing modern globe retained as optional comparison renderer.
- `app/src/main/java/com/sentongoharuna/worldsituationroom/DuwmWorldIntelligenceActivity.java`: source-backed dashboard retained.
- `app/src/main/java/com/sentongoharuna/worldsituationroom/MediaDeskActivity.java`: native media player retained.

## Verification performed

1. `python3 verification/check_source.py` — passed for current source/manifest, protected original modules, map JS syntax and cross-screen links.
2. `python3 verification/test_map.py` — passed in local Chromium with remote OSM tiles intentionally blocked (buttons, selection, source-based category filtering, invalid/stale coordinate rejection, missing AIS status).
3. `bash scripts/verify-1-2-20-2-20-full-regression.sh` — passed for original source-to-globe modules; older R27/R30 scripts are version-pinned and not used as release gates.
4. Java APK compilation, installation and internet tile loading **are not verified locally**, because an Android SDK/Gradle builder is not available in the local container. The GitHub Actions workflow performs these checks when both files are committed to the repository.

## Installation from GitHub

Upload `DUWM-1165-REAL-ANDROID-SOURCE.zip` to the repository root.
Upload `DUWM-1165-REAL-SOURCE-APK.yml` into `.github/workflows/`.
The workflow is triggered by either file's main-branch commit, checks the source archive digest, builds the actual Android project, verifies APK contents/signature, and publishes `DUWM-1165-REAL-SOURCE-APK`.

**A green source/compile result does not prove live source availability, tile loading, media playback, or visual fitness on the user's own phone.**
