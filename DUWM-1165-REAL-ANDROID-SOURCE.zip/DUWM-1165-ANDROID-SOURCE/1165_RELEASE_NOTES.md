# DUWM 1165 — original-globe source delivery

This release is versioned as 1165 at the user's request. It carries forward the substantive native source modifications already made in the recovered 1164 source package: the original SatelliteMapView is the default globe, signal lights have dedicated layout space, map asset reading is robust, and the source-backed street map has honest tile/renderer diagnostics.

Version and display metadata have been updated in Gradle, app strings, the map WebView user agent, and the source-integrity gate. **These changes are not claimed to be a newly tested visual upgrade** beyond that inherited source work.

The package is editable Java/Android source, not an APK. GitHub Actions still must compile, sign and package the APK. Successful compilation is not proof that external tiles or live feeds work on the user's phone.
