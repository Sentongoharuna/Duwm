package com.sentongoharuna.worldsituationroom;
import android.content.*;
import java.util.*;
/** 1.2/20/3-15 persistent WATCH keyed only by canonical identity. */
public final class CanonicalWatchStore{
 public static final class Watch {
  public final String canonicalId,providerId,recordId,layer,title;
  public final long watchedAtMs;
  Watch(String c,String p,String r,String l,String t,long at){canonicalId=c;providerId=p;recordId=r;layer=l;title=t;watchedAtMs=at;}
 }
 private final SharedPreferences p;
 public CanonicalWatchStore(Context c){p=c.getApplicationContext().getSharedPreferences("du_canonical_watch_v1",Context.MODE_PRIVATE);}
 public boolean watched(String id){return id!=null&&!id.isEmpty()&&p.getBoolean("w_"+id,false);}
 public void setWatched(Signal s,boolean v){
  if(s==null||s.canonicalId==null||s.canonicalId.isEmpty())return;
  SharedPreferences.Editor e=p.edit().putBoolean("w_"+s.canonicalId,v);
  if(v)e.putString("provider_"+s.canonicalId,s.providerId).putString("record_"+s.canonicalId,s.id)
    .putString("layer_"+s.canonicalId,s.layer.name()).putString("title_"+s.canonicalId,s.title)
    .putLong("watched_at_"+s.canonicalId,System.currentTimeMillis());
  e.apply();
 }
 public Watch read(String id){
  if(!watched(id))return null;
  return new Watch(id,p.getString("provider_"+id,""),p.getString("record_"+id,""),
    p.getString("layer_"+id,""),p.getString("title_"+id,""),p.getLong("watched_at_"+id,0L));
 }
 public int count(){
  int n=0;for(Map.Entry<String,?>e:p.getAll().entrySet())if(e.getKey().startsWith("w_")&&Boolean.TRUE.equals(e.getValue()))n++;return n;
 }
}
