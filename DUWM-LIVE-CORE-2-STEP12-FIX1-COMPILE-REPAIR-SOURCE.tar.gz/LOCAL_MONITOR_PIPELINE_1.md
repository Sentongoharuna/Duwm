# Local Monitor Publishing Pipeline 1
Uses the preserved real LocalMonitorActivity and MonitorApiClient engine.

Flow:
1. Capture video with Android camera OR import a video document.
2. Keep a durable local copy in MonitorStore.
3. Preview/compose the report with reporter/location/caption metadata.
4. Save as draft/local report or publish when Monitor Network is configured.
5. Queue and resume uploads; local media remains safe on upload failure.
6. Prefer resumable upload, with multipart fallback when the server does not advertise resumable support.
7. Persist upload offset/total/session and expose FAILED/QUEUED/UPLOADING/PUBLISHED states.
8. Merge the published server report back into MonitorStore while retaining the local media copy.
9. Monitor Hub now opens this publisher directly.
No server endpoint is fabricated: if Monitor Network is not configured, the report remains safely local.
