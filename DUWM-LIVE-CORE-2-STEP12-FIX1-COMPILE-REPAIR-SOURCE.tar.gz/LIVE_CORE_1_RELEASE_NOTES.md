# DUWM LIVE CORE 1
Built from the first known-good green FIX2 baseline.

- Module crash shield records recovered failures without taking down unrelated modules.
- Honest LIVE / DELAYED / OFFLINE / UNKNOWN freshness states.
- Dynamic live counter strip refreshes on a performance-governed cadence.
- Performance governor reduces refresh/animation pressure under low-memory conditions.
- Offline snapshot helper exposes last-valid cached data age.
- Integration diagnostics now include build identity, provider health, counts and diagnostics.
- Existing Local Monitor hub/player/API pipeline is preserved and contract-checked.
- Existing globe, navigation and UI are preserved; no redesign/removal pass.
- Workflow compile gate: Java compile then full assembleDebug.
- Single APK artifact.
- Auto trigger on every push to main plus manual fallback.
