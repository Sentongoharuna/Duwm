package com.sentongoharuna.worldsituationroom;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Builds exact-size RemoteViews while keeping urgency and credibility as separate concepts. */
public final class DuWidgetRenderer {
    private static final int LAYOUT_MICRO = 1;
    private static final int LAYOUT_BAR = 2;
    private static final int LAYOUT_PANEL = 3;
    private static final int LAYOUT_COMMAND = 4;

    private static final class Content {
        String title;
        String badge;
        String primary;
        String secondary;
        String detail1;
        String detail2;
        String detail3;
        String detail4;
        String source;
        String updated;
        String catalog;
        String microValue;
        String microLabel;
        WidgetSnapshot.Tone tone;
        List<Signal> cycleValues = new ArrayList<>();
        Signal selected;
        boolean cycle;
        boolean alertFrame;
    }

    private DuWidgetRenderer() { }

    /**
     * Tiny RemoteViews-only surface used immediately while the cached snapshot is being read.
     * It also gives the launcher a valid recovery surface if an OEM rejects a richer layout.
     */
    public static RemoteViews renderStarting(Context context, int widgetId,
                                             DuWidgetContract.Kind kind,
                                             boolean recovery) {
        RemoteViews views = new RemoteViews(context.getPackageName(),
                R.layout.widget_safe_fallback);
        views.setTextViewText(R.id.widget_title, kind == null
                ? "DU WORLD MONITOR" : kind.title);
        views.setTextViewText(R.id.widget_primary, recovery
                ? "WIDGET RECOVERY • TAP TO OPEN"
                : "ACQUIRING SOURCE SNAPSHOT");
        views.setTextViewText(R.id.widget_secondary, recovery
                ? "SAFE LAYOUT ACTIVE"
                : "STARTING • SOURCE STATUS PENDING");
        views.setOnClickPendingIntent(R.id.widget_root,
                openIntent(context, widgetId, kind == null ? "WIDGETS" : kind.catalog));
        return views;
    }

    public static RemoteViews render(Context context, int widgetId,
                                     DuWidgetContract.Kind kind,
                                     DuWidgetPreferences.Config config,
                                     WidgetSnapshot snapshot, Bundle options) {
        int width = options == null ? 0
                : options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
        int height = options == null ? 0
                : options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0);
        int layoutType = chooseLayout(kind, width, height);
        int layout;
        switch (layoutType) {
            case LAYOUT_MICRO: layout = R.layout.widget_micro; break;
            case LAYOUT_BAR: layout = R.layout.widget_bar; break;
            case LAYOUT_COMMAND: layout = R.layout.widget_command_center; break;
            default: layout = R.layout.widget_panel; break;
        }
        Content content = content(kind, config, snapshot);
        String parityState = DuSharedLiveState.compact(context, kind == null ? "EVENTS" : kind.catalog);
        RemoteViews views = new RemoteViews(context.getPackageName(), layout);
        int dot = dotResource(content.tone);
        int accent = toneColor(context, content.tone);

        if (layoutType == LAYOUT_MICRO) {
            views.setTextViewText(R.id.widget_title, content.title);
            views.setTextViewText(R.id.widget_primary, content.microValue);
            views.setTextViewText(R.id.widget_secondary, content.microLabel);
            views.setTextViewText(R.id.widget_cycle_value_2,
                    compactNumber(snapshot.events(config).size()));
            views.setTextViewText(R.id.widget_cycle_label_2, "ACQUIRED EVENTS");
            views.setTextViewText(R.id.widget_cycle_value_3,
                    compactNumber(snapshot.onlineFeeds));
            views.setTextViewText(R.id.widget_cycle_label_3, "LIVE/READY SOURCES");
            views.setTextViewText(R.id.widget_updated, content.updated+" · "+parityState);
            views.setImageViewResource(R.id.widget_dot, dot);
            if (content.alertFrame) {
                views.setInt(R.id.widget_root, "setBackgroundResource",
                        R.drawable.widget_background_alert);
            }
        } else if (layoutType == LAYOUT_BAR) {
            bindHeader(views, content, dot, accent);
            views.setTextViewText(R.id.widget_primary, content.primary);
            views.setTextViewText(R.id.widget_cycle_2,
                    kind == DuWidgetContract.Kind.COUNTERS
                            ? content.secondary : content.detail1);
            views.setTextViewText(R.id.widget_cycle_3,
                    kind == DuWidgetContract.Kind.COUNTERS
                            ? content.detail4 : content.source + " • " + content.updated);
            views.setTextViewText(R.id.widget_secondary, content.secondary);
            views.setTextViewText(R.id.widget_source, content.source + " • " + content.updated);
            bindCycleVisibility(views, content.cycle);
            bindInteractive(context, views, widgetId, kind, content.catalog, content.cycle);
        } else if (layoutType == LAYOUT_PANEL) {
            bindHeader(views, content, dot, accent);
            views.setTextViewText(R.id.widget_primary, content.primary);
            views.setTextViewText(R.id.widget_secondary, content.secondary);
            views.setTextViewText(R.id.widget_detail_1, content.detail1);
            views.setTextViewText(R.id.widget_detail_2, content.detail2);
            views.setTextViewText(R.id.widget_detail_3, content.detail3);
            views.setTextViewText(R.id.widget_detail_4, content.detail4);
            views.setTextViewText(R.id.widget_source, content.source);
            views.setTextViewText(R.id.widget_updated, content.updated+" · "+parityState);
            bindCycleVisibility(views, content.cycle);
            bindInteractive(context, views, widgetId, kind, content.catalog, content.cycle);
        } else {
            bindHeader(views, content, dot, accent);
            views.setTextViewText(R.id.widget_primary, content.primary);
            views.setTextViewText(R.id.widget_cycle_2, content.detail1);
            views.setTextViewText(R.id.widget_cycle_3, content.detail2);
            views.setTextViewText(R.id.widget_secondary, content.secondary);
            views.setTextViewText(R.id.widget_detail_1, content.detail1);
            views.setTextViewText(R.id.widget_detail_2, content.detail2);
            views.setTextViewText(R.id.widget_detail_3, content.detail3);
            views.setTextViewText(R.id.widget_detail_4, content.detail4);
            views.setTextViewText(R.id.widget_source, content.updated + " • " + content.source);
            views.setTextViewText(R.id.widget_counts, String.format(Locale.US,
                    "AIR %,d  •  SEA %,d  •  EVT %,d  •  ORBIT %,d  •  CAM %,d",
                    snapshot.count(Signal.Layer.FLIGHTS), snapshot.count(Signal.Layer.SHIPS),
                    snapshot.count(Signal.Layer.NEWS) + snapshot.count(Signal.Layer.NATURAL)
                            + snapshot.count(Signal.Layer.AIRSPACE),
                    snapshot.count(Signal.Layer.SATELLITES),
                    snapshot.count(Signal.Layer.WEBCAMS)));
            views.setTextViewText(R.id.widget_counts_2, String.format(Locale.US,
                    "READY %,d  •  CACHED %,d  •  OFFLINE %,d  •  OPTIONAL %,d",
                    snapshot.onlineFeeds, snapshot.cachedFeeds,
                    snapshot.offlineFeeds, snapshot.optionalFeeds));
            int media = snapshot.count(Signal.Layer.WEBCAMS)
                    + snapshot.count(Signal.Layer.RADIO) + snapshot.count(Signal.Layer.TV);
            views.setTextViewText(R.id.widget_counts_3, String.format(Locale.US,
                    "RADAR %s  •  RADIO %,d  •  TV %,d  •  MEDIA %,d",
                    state(snapshot.effectiveStatus(Signal.Layer.WEATHER)),
                    snapshot.count(Signal.Layer.RADIO), snapshot.count(Signal.Layer.TV), media));
            int bitmapWidth = width <= 0 ? 640 : width * 2;
            int bitmapHeight = height <= 0 ? 250 : Math.max(170, height);
            double presentationLongitude = normalizeLongitude(config.longitude
                    + (snapshot.assembledAtMs / 20_000L) % 360L);
            views.setImageViewBitmap(R.id.widget_globe,
                    WidgetGlobeRenderer.render(snapshot.globeRecords(config),
                            config.latitude, presentationLongitude, bitmapWidth, bitmapHeight));
            bindCycleVisibility(views, content.cycle);
            bindInteractive(context, views, widgetId, kind, content.catalog, content.cycle);
        }
        views.setOnClickPendingIntent(R.id.widget_root,
                content.selected == null
                        ? DuWidgetDeepLink.catalog(context, widgetId, content.catalog)
                        : DuWidgetDeepLink.record(context, widgetId, content.selected, content.catalog));
        return views;
    }

    private static void bindHeader(RemoteViews views, Content content, int dot, int accent) {
        views.setTextViewText(R.id.widget_title, content.title);
        views.setTextViewText(R.id.widget_badge, content.badge);
        views.setTextColor(R.id.widget_badge, accent);
        views.setImageViewResource(R.id.widget_dot, dot);
        if (content.alertFrame) {
            views.setInt(R.id.widget_root, "setBackgroundResource",
                    R.drawable.widget_background_alert);
        }
    }

    private static void bindCycleVisibility(RemoteViews views, boolean visible) {
        views.setViewVisibility(R.id.widget_prev, visible ? View.VISIBLE : View.GONE);
        views.setViewVisibility(R.id.widget_next, visible ? View.VISIBLE : View.GONE);
    }

    private static void bindInteractive(Context context, RemoteViews views, int widgetId,
                                        DuWidgetContract.Kind kind, String catalog,
                                        boolean cycle) {
        views.setOnClickPendingIntent(R.id.widget_refresh,
                actionIntent(context, widgetId, kind, DuWidgetContract.ACTION_REFRESH, 1));
        if (cycle) {
            views.setOnClickPendingIntent(R.id.widget_prev,
                    actionIntent(context, widgetId, kind, DuWidgetContract.ACTION_PREVIOUS, 2));
            views.setOnClickPendingIntent(R.id.widget_next,
                    actionIntent(context, widgetId, kind, DuWidgetContract.ACTION_NEXT, 3));
        }
        views.setOnClickPendingIntent(R.id.widget_root, openIntent(context, widgetId, catalog));
    }

    private static Content content(DuWidgetContract.Kind kind,
                                   DuWidgetPreferences.Config config,
                                   WidgetSnapshot snapshot) {
        switch (kind) {
            case ALERT: return alertContent(config, snapshot);
            case COUNTERS: return countersContent(config, snapshot);
            case LOCAL: return localContent(config, snapshot);
            case WIRE: return wireContent(config, snapshot);
            case AIR_SEA: return airSeaContent(config, snapshot);
            case HAZARDS: return hazardsContent(config, snapshot);
            case MEDIA: return mediaContent(config, snapshot);
            case WORLD_PULSE: return alertContent(config, snapshot);
            case ORBIT_WATCH: return countersContent(config, snapshot);
            case SOURCE_MATRIX: return mediaContent(config, snapshot);
            case MONITOR_STORIES: return localContent(config, snapshot);
            default: return commandContent(config, snapshot);
        }
    }

    private static Content alertContent(DuWidgetPreferences.Config config,
                                        WidgetSnapshot snapshot) {
        Content c = base(config, snapshot, "DU ALERT", "EVENTS");
        List<Signal> priorities = snapshot.priorityEvents(config);
        List<Signal> values = priorities.isEmpty() ? snapshot.events(config) : priorities;
        c.selected = snapshot.atCursor(values, config.cursor);
        c.cycleValues = values;
        c.cycle = values.size() > 1;
        c.microValue = String.valueOf(priorities.size());
        c.microLabel = priorities.isEmpty() ? "NO PRIORITY SIGNAL" : "PRIORITY SIGNALS";
        c.primary = c.selected == null ? "NO ACQUIRED PRIORITY SIGNAL"
                : WidgetSnapshot.compact(c.selected.title, 94);
        c.secondary = meta(c.selected, snapshot.assembledAtMs);
        c.detail1 = "PRIORITY " + priorities.size() + " • FILTER SEV ≥" + config.minimumSeverity;
        c.detail2 = c.selected == null ? "REGION " + config.region
                : "TYPE " + c.selected.eventType + " • REGION " + c.selected.region;
        c.detail3 = c.selected == null ? "WAITING FOR SOURCE DATA"
                : WidgetSnapshot.compact(c.selected.summary, 100);
        c.detail4 = snapshot.sourceHealthLine();
        c.source = source(c.selected);
        c.updated = age(c.selected, snapshot);
        c.badge = c.selected == null ? snapshot.healthBadge() : WidgetSnapshot.credibility(c.selected);
        c.tone = c.selected != null && c.selected.severity >= 4
                ? WidgetSnapshot.Tone.RED : priorities.isEmpty()
                ? snapshot.healthTone() : WidgetSnapshot.Tone.AMBER;
        c.alertFrame = c.selected != null && c.selected.severity >= 4;
        return c;
    }

    private static Content countersContent(DuWidgetPreferences.Config config,
                                           WidgetSnapshot snapshot) {
        Content c = base(config, snapshot, "DU LIVE COUNTERS", "SOURCES");
        int air = snapshot.count(Signal.Layer.FLIGHTS);
        int sea = snapshot.count(Signal.Layer.SHIPS);
        int events = snapshot.count(Signal.Layer.NEWS) + snapshot.count(Signal.Layer.NATURAL)
                + snapshot.count(Signal.Layer.AIRSPACE);
        int media = snapshot.count(Signal.Layer.WEBCAMS) + snapshot.count(Signal.Layer.RADIO)
                + snapshot.count(Signal.Layer.TV);
        c.microValue = compactNumber(air + sea + events);
        c.microLabel = "ACTIVE RECORDS";
        c.primary = String.format(Locale.US, "AIR %,d  •  SEA %,d  •  EVENTS %,d", air, sea, events);
        c.secondary = String.format(Locale.US, "ORBIT %,d  •  MEDIA %,d  •  WEATHER %s",
                snapshot.count(Signal.Layer.SATELLITES), media,
                state(snapshot.effectiveStatus(Signal.Layer.WEATHER)));
        c.detail1 = String.format(Locale.US, "AIRCRAFT %,d • %s", air,
                state(snapshot.effectiveStatus(Signal.Layer.FLIGHTS)));
        c.detail2 = String.format(Locale.US, "VESSELS %,d • %s", sea,
                state(snapshot.effectiveStatus(Signal.Layer.SHIPS)));
        c.detail3 = String.format(Locale.US, "EVENT/WIRE %,d • ORBITS %,d", events,
                snapshot.count(Signal.Layer.SATELLITES));
        c.detail4 = snapshot.sourceHealthLine();
        c.source = "PROVIDER-RETURNED COUNTS • NOT COMPLETE WORLD COVERAGE";
        c.updated = "SOURCE INDEX " + WidgetSnapshot.ageText(snapshot.lastSourceUpdateMs,
                snapshot.assembledAtMs);
        c.badge = snapshot.healthBadge();
        c.tone = snapshot.healthTone();
        c.cycle = false;
        return c;
    }

    private static Content localContent(DuWidgetPreferences.Config config,
                                        WidgetSnapshot snapshot) {
        Content c = base(config, snapshot, "DU LOCAL WATCH / " + config.label, "BRIEF");
        List<Signal> events = snapshot.events(config);
        c.selected = snapshot.atCursor(events, config.cursor);
        c.cycleValues = events;
        c.cycle = events.size() > 1;
        List<Signal> aircraft = snapshot.records(Signal.Layer.FLIGHTS, config);
        List<Signal> ships = snapshot.records(Signal.Layer.SHIPS, config);
        c.microValue = String.valueOf(events.size());
        c.microLabel = config.label;
        c.primary = c.selected == null ? "NO MATCHING LOCAL EVENT ACQUIRED"
                : WidgetSnapshot.compact(c.selected.title, 88);
        c.secondary = meta(c.selected, snapshot.assembledAtMs);
        c.detail1 = String.format(Locale.US, "LOCAL AIR %,d • SEA %,d • EVENTS %,d",
                aircraft.size(), ships.size(), events.size());
        c.detail2 = "WATCH " + config.region + (config.radiusKm > 0
                ? " • " + String.format(Locale.US, "%,d KM", config.radiusKm) : "");
        c.detail3 = c.selected == null ? "NO CLAIM OF SAFETY • PROVIDER COVERAGE VARIES"
                : WidgetSnapshot.compact(c.selected.summary, 96);
        c.detail4 = snapshot.sourceHealthLine();
        c.source = source(c.selected);
        c.updated = age(c.selected, snapshot);
        c.badge = c.selected == null ? snapshot.healthBadge() : WidgetSnapshot.credibility(c.selected);
        c.tone = signalTone(c.selected, snapshot.healthTone());
        c.alertFrame = c.selected != null && c.selected.severity >= 4;
        return c;
    }

    private static Content wireContent(DuWidgetPreferences.Config config,
                                       WidgetSnapshot snapshot) {
        Content c = base(config, snapshot, "DU BREAKING WIRE", "NEWS");
        List<Signal> news = snapshot.records(Signal.Layer.NEWS, config);
        c.selected = snapshot.atCursor(news, config.cursor);
        c.cycleValues = news;
        c.cycle = news.size() > 1;
        c.microValue = compactNumber(news.size());
        c.microLabel = "WIRE RECORDS";
        c.primary = c.selected == null ? "WAITING FOR SOURCE-ATTRIBUTED WIRE"
                : WidgetSnapshot.compact(c.selected.title, 112);
        c.secondary = meta(c.selected, snapshot.assembledAtMs);
        c.detail1 = c.selected == null ? "NO HEADLINE ACQUIRED" : "TYPE " + c.selected.eventType
                + " • REGION " + c.selected.region + " • SEV " + c.selected.severity;
        c.detail2 = c.selected == null ? "" : WidgetSnapshot.compact(c.selected.summary, 110);
        c.detail3 = "NEWEST FIRST • FILTER SEV ≥" + config.minimumSeverity;
        c.detail4 = snapshot.sourceHealthLine();
        c.source = source(c.selected);
        c.updated = age(c.selected, snapshot);
        c.badge = c.selected == null ? snapshot.healthBadge() : WidgetSnapshot.credibility(c.selected);
        c.tone = signalTone(c.selected, snapshot.healthTone());
        c.alertFrame = c.selected != null && c.selected.severity >= 4;
        return c;
    }

    private static Content airSeaContent(DuWidgetPreferences.Config config,
                                         WidgetSnapshot snapshot) {
        Content c = base(config, snapshot, "DU AIR & SEA TRACKER", "AIRCRAFT");
        List<Signal> aircraft = snapshot.records(Signal.Layer.FLIGHTS, config);
        List<Signal> ships = snapshot.records(Signal.Layer.SHIPS, config);
        List<Signal> combined = snapshot.combined(config, Signal.Layer.FLIGHTS, Signal.Layer.SHIPS);
        c.selected = snapshot.atCursor(combined, config.cursor);
        c.cycleValues = combined;
        c.cycle = combined.size() > 1;
        c.microValue = compactNumber(aircraft.size() + ships.size());
        c.microLabel = "MOVEMENT FIXES";
        c.primary = c.selected == null ? "WAITING FOR AIR/SEA TELEMETRY"
                : WidgetSnapshot.compact(c.selected.title, 90);
        c.secondary = c.selected == null ? snapshot.healthBadge()
                : c.selected.layer.name() + " • " + WidgetSnapshot.credibility(c.selected)
                + " • " + WidgetSnapshot.ageText(c.selected.timestampMs, snapshot.assembledAtMs);
        Signal air = snapshot.atCursor(aircraft, config.cursor);
        Signal sea = snapshot.atCursor(ships, config.cursor);
        c.detail1 = air == null ? "AIRCRAFT • NO ACQUIRED FIX"
                : "AIR • " + WidgetSnapshot.compact(air.title, 34) + " • ALT "
                + WidgetSnapshot.fact(air, "BAROMETRIC ALTITUDE", "ALTITUDE");
        c.detail2 = air == null ? "COURSE — • SPEED —"
                : "COURSE " + heading(air) + " • SPEED " + speed(air);
        c.detail3 = sea == null ? "VESSEL • KEY/COVERAGE MAY BE REQUIRED"
                : "SEA • " + WidgetSnapshot.compact(sea.title, 34) + " • "
                + WidgetSnapshot.fact(sea, "DESTINATION", "NAVIGATION STATUS");
        c.detail4 = "AIR " + aircraft.size() + " • SEA " + ships.size()
                + " • POSITIONS DO NOT PROVE INTENT";
        c.source = source(c.selected);
        c.updated = age(c.selected, snapshot);
        c.badge = c.selected == null ? snapshot.healthBadge() : WidgetSnapshot.credibility(c.selected);
        c.tone = c.selected == null ? snapshot.healthTone() : WidgetSnapshot.Tone.CYAN;
        return c;
    }

    private static Content hazardsContent(DuWidgetPreferences.Config config,
                                          WidgetSnapshot snapshot) {
        Content c = base(config, snapshot, "DU HAZARDS & WEATHER", "EVENTS");
        List<Signal> hazards = snapshot.combined(config, Signal.Layer.NATURAL,
                Signal.Layer.AIRSPACE, Signal.Layer.SPACE_WEATHER);
        c.selected = snapshot.atCursor(hazards, config.cursor);
        c.cycleValues = hazards;
        c.cycle = hazards.size() > 1;
        int natural = snapshot.records(Signal.Layer.NATURAL, config).size();
        int airspace = snapshot.records(Signal.Layer.AIRSPACE, config).size();
        int space = snapshot.records(Signal.Layer.SPACE_WEATHER, config).size();
        c.microValue = compactNumber(hazards.size());
        c.microLabel = "HAZARD RECORDS";
        c.primary = c.selected == null ? "WAITING FOR HAZARD SOURCES"
                : WidgetSnapshot.compact(c.selected.title, 96);
        c.secondary = meta(c.selected, snapshot.assembledAtMs);
        c.detail1 = String.format(Locale.US, "NATURAL %,d • AIRSPACE %,d • SPACE %,d",
                natural, airspace, space);
        FeedStatus weather = snapshot.effectiveStatus(Signal.Layer.WEATHER);
        c.detail2 = "RADAR " + state(weather) + " • "
                + (weather == null ? "NO FRAME STATE" : WidgetSnapshot.compact(weather.message, 60));
        c.detail3 = c.selected == null ? "NO MATCHING WARNING ACQUIRED"
                : WidgetSnapshot.compact(c.selected.summary, 98);
        c.detail4 = "OBSERVED WARNINGS • NOT A FORECAST • FILTER SEV ≥"
                + config.minimumSeverity;
        c.source = source(c.selected);
        c.updated = age(c.selected, snapshot);
        c.badge = c.selected == null ? snapshot.healthBadge() : WidgetSnapshot.credibility(c.selected);
        c.tone = signalTone(c.selected, weather == null
                ? snapshot.healthTone() : WidgetSnapshot.Tone.AMBER);
        c.alertFrame = c.selected != null && c.selected.severity >= 4;
        return c;
    }

    private static Content mediaContent(DuWidgetPreferences.Config config,
                                        WidgetSnapshot snapshot) {
        Content c = base(config, snapshot, "DU MEDIA WATCH", "CAMERAS");
        List<Signal> media = snapshot.combined(config, Signal.Layer.WEBCAMS,
                Signal.Layer.RADIO, Signal.Layer.TV);
        c.selected = snapshot.atCursor(media, config.cursor);
        c.cycleValues = media;
        c.cycle = media.size() > 1;
        c.microValue = compactNumber(media.size());
        c.microLabel = "PUBLIC MEDIA";
        c.primary = c.selected == null ? "NO MATCHING PUBLIC MEDIA INDEX"
                : WidgetSnapshot.compact(c.selected.title, 92);
        c.secondary = c.selected == null ? snapshot.healthBadge()
                : c.selected.layer.name() + " • " + WidgetSnapshot.credibility(c.selected)
                + " • AVAILABILITY MAY CHANGE";
        c.detail1 = String.format(Locale.US, "CAM %,d • RADIO %,d • TV %,d",
                snapshot.count(Signal.Layer.WEBCAMS), snapshot.count(Signal.Layer.RADIO),
                snapshot.count(Signal.Layer.TV));
        c.detail2 = c.selected == null ? "PUBLIC/LAWFUL INDEX ONLY"
                : "REGION " + c.selected.region + " • TYPE " + c.selected.eventType;
        c.detail3 = c.selected == null ? "KEYS MAY BE REQUIRED FOR OPTIONAL PROVIDERS"
                : WidgetSnapshot.compact(c.selected.summary, 98);
        c.detail4 = "STREAM UPTIME, RIGHTS AND GEOBLOCKING VARY";
        c.source = source(c.selected);
        c.updated = age(c.selected, snapshot);
        c.badge = c.selected == null ? snapshot.healthBadge() : "PUBLIC SOURCE";
        c.tone = c.selected == null ? snapshot.healthTone() : WidgetSnapshot.Tone.GREEN;
        return c;
    }

    private static Content commandContent(DuWidgetPreferences.Config config,
                                          WidgetSnapshot snapshot) {
        Content c = base(config, snapshot, "DU WORLD MONITOR / COMMAND CENTRE", "BRIEF");
        List<Signal> events = snapshot.events(config);
        c.selected = snapshot.atCursor(events, config.cursor);
        c.cycleValues = events;
        c.cycle = events.size() > 1;
        c.microValue = compactNumber(snapshot.count(Signal.Layer.FLIGHTS)
                + snapshot.count(Signal.Layer.SHIPS) + events.size());
        c.microLabel = "OBSERVED RECORDS";
        c.primary = c.selected == null ? "COMMAND CACHE READY • WAITING FOR EVENT SIGNAL"
                : WidgetSnapshot.compact(c.selected.title, 108);
        c.secondary = meta(c.selected, snapshot.assembledAtMs);
        c.detail1 = eventLine(events, config.cursor + 1, snapshot.assembledAtMs);
        c.detail2 = eventLine(events, config.cursor + 2, snapshot.assembledAtMs);
        c.detail3 = eventLine(events, config.cursor + 3, snapshot.assembledAtMs);
        c.detail4 = snapshot.sourceHealthLine()
                + " • COVERAGE VARIES";
        c.source = source(c.selected);
        c.updated = "CACHE " + WidgetSnapshot.ageText(snapshot.lastSourceUpdateMs,
                snapshot.assembledAtMs);
        c.badge = c.selected == null ? snapshot.healthBadge() : WidgetSnapshot.credibility(c.selected);
        c.tone = signalTone(c.selected, snapshot.healthTone());
        c.alertFrame = c.selected != null && c.selected.severity >= 4;
        return c;
    }

    private static Content base(DuWidgetPreferences.Config config, WidgetSnapshot snapshot,
                                String title, String catalog) {
        Content c = new Content();
        c.title = title;
        c.catalog = catalog;
        c.badge = snapshot.healthBadge();
        c.primary = "WAITING FOR ACQUIRED DATA";
        c.secondary = "NO SOURCE STATE";
        c.detail1 = "—";
        c.detail2 = "—";
        c.detail3 = "—";
        c.detail4 = snapshot.sourceHealthLine();
        c.source = "SOURCE • NO ACQUIRED RECORD";
        c.updated = "CACHE " + WidgetSnapshot.ageText(snapshot.lastSourceUpdateMs,
                snapshot.assembledAtMs);
        c.microValue = "0";
        c.microLabel = config.label;
        c.tone = snapshot.healthTone();
        return c;
    }

    private static String eventLine(List<Signal> events, int index, long now) {
        if (events == null || events.isEmpty()) return "• WAITING FOR ACQUIRED EVENT";
        Signal signal = events.get(Math.floorMod(index, events.size()));
        return "• " + WidgetSnapshot.compact(signal.title, 62) + " • "
                + WidgetSnapshot.credibility(signal) + " • "
                + WidgetSnapshot.ageText(signal.timestampMs, now);
    }

    private static String meta(Signal signal, long now) {
        return signal == null ? "NO ACQUIRED SIGNAL • SOURCE REQUIRED"
                : WidgetSnapshot.credibility(signal) + " • SEV " + signal.severity
                + " • " + WidgetSnapshot.ageText(signal.timestampMs, now);
    }

    private static String source(Signal signal) {
        return signal == null ? "SOURCE • NO ACQUIRED RECORD"
                : "SOURCE • " + WidgetSnapshot.compact(signal.source, 68);
    }

    private static String age(Signal signal, WidgetSnapshot snapshot) {
        long time = signal == null ? snapshot.lastSourceUpdateMs : signal.timestampMs;
        return "UPDATED • " + WidgetSnapshot.ageText(time, snapshot.assembledAtMs);
    }

    private static String state(FeedStatus status) {
        return status == null ? "NO DATA" : status.state.name().replace('_', ' ');
    }

    private static String heading(Signal signal) {
        return signal == null || Double.isNaN(signal.heading)
                ? "NOT REPORTED" : String.format(Locale.US, "%03.0f°", signal.heading);
    }

    private static String speed(Signal signal) {
        return signal == null || Double.isNaN(signal.speedMetersPerSecond)
                ? "NOT REPORTED" : String.format(Locale.US, "%.0f km/h",
                signal.speedMetersPerSecond * 3.6d);
    }

    private static String compactNumber(int value) {
        if (value >= 1_000_000) return String.format(Locale.US, "%.1fM", value / 1_000_000d);
        if (value >= 10_000) return String.format(Locale.US, "%.1fK", value / 1_000d);
        return String.format(Locale.US, "%,d", value);
    }

    /** Advances only the display angle; the plotted records and their positions remain real. */
    private static double normalizeLongitude(double value) {
        double normalized = value % 360d;
        if (normalized > 180d) normalized -= 360d;
        if (normalized < -180d) normalized += 360d;
        return normalized;
    }

    private static WidgetSnapshot.Tone signalTone(Signal signal, WidgetSnapshot.Tone fallback) {
        if (signal == null) return fallback;
        if (signal.severity >= 4) return WidgetSnapshot.Tone.RED;
        if (signal.layer == Signal.Layer.FLIGHTS || signal.layer == Signal.Layer.SHIPS
                || signal.layer == Signal.Layer.SATELLITES) return WidgetSnapshot.Tone.CYAN;
        return WidgetSnapshot.Tone.AMBER;
    }

    private static int chooseLayout(DuWidgetContract.Kind kind, int width, int height) {
        if (kind == DuWidgetContract.Kind.ALERT && (width == 0 || width < 150)
                && (height == 0 || height < 145)) return LAYOUT_MICRO;
        if (kind == DuWidgetContract.Kind.COMMAND && width >= 250 && height >= 240) {
            return LAYOUT_COMMAND;
        }
        if (height > 0 && height < 125) return LAYOUT_BAR;
        if ((kind == DuWidgetContract.Kind.COUNTERS || kind == DuWidgetContract.Kind.WIRE)
                && (height == 0 || height < 145)) return LAYOUT_BAR;
        return LAYOUT_PANEL;
    }

    private static int dotResource(WidgetSnapshot.Tone tone) {
        switch (tone) {
            case RED: return R.drawable.widget_dot_red;
            case AMBER: return R.drawable.widget_dot_amber;
            case GREEN: return R.drawable.widget_dot_green;
            case CYAN: return R.drawable.widget_dot_cyan;
            default: return R.drawable.widget_dot_gray;
        }
    }

    private static int toneColor(Context context, WidgetSnapshot.Tone tone) {
        switch (tone) {
            case RED: return context.getColor(R.color.widget_red);
            case AMBER: return context.getColor(R.color.widget_amber);
            case GREEN: return context.getColor(R.color.widget_green);
            case CYAN: return context.getColor(R.color.command_cyan);
            default: return context.getColor(R.color.widget_muted);
        }
    }

    private static PendingIntent openIntent(Context context, int widgetId, String catalog) {
        return DuWidgetDeepLink.catalog(context, widgetId, catalog);
    }

    private static PendingIntent actionIntent(Context context, int widgetId,
                                              DuWidgetContract.Kind kind,
                                              String action, int offset) {
        Intent intent = new Intent(context, WidgetActionReceiver.class)
                .setAction(action)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                .putExtra(DuWidgetContract.EXTRA_WIDGET_KIND, kind.name())
                .setData(Uri.parse("duwidget://action/" + widgetId + "/" + offset));
        return PendingIntent.getBroadcast(context, widgetId * 10 + offset, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
