package com.sentongoharuna.worldsituationroom;
import android.content.*;import java.util.*;
public final class DuSharedLiveState{
 public static final String[] SYSTEMS={"AIR","SEA","WX","EVENTS","ORBIT","MONITORS"};
 public static final class Item{public final String system,state,freshness;public final int count;public final long capturedAt;Item(String s,String st,String f,int c,long at){system=s;state=st;freshness=f;count=c;capturedAt=at;}}
 private DuSharedLiveState(){}
 public static Item item(Context c,String system){DuLiveRepository r=new DuLiveRepository(c);return new Item(system,DuOfflineUx.state(c,system),DuFreshness.label(c,system),r.count(system),System.currentTimeMillis());}
 public static java.util.List<Item> all(Context c){java.util.ArrayList<Item>x=new java.util.ArrayList<>();for(String s:SYSTEMS)x.add(item(c,s));return x;}
 public static String compact(Context c,String system){Item i=item(c,system);return i.count+" · "+i.state;}
}
