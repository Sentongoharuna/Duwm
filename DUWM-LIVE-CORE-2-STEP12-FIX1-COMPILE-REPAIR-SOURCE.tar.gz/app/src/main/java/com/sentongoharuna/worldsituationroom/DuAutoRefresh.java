package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.os.*;
public final class DuAutoRefresh{
 final Activity a;final String system;final Handler h=new Handler(Looper.getMainLooper());boolean active;
 final Runnable tick=new Runnable(){public void run(){if(!active)return;DuModuleShield.run(a,"REFRESH:"+system,()->DuProviderRetry.request(a,system));h.postDelayed(this,DuPerformancePolicy.liveRefreshMs(a));}};
 public DuAutoRefresh(Activity a,String s){this.a=a;system=s;}
 public void start(){active=true;h.removeCallbacks(tick);h.postDelayed(tick,DuPerformancePolicy.liveRefreshMs(a));}
 public void stop(){active=false;h.removeCallbacks(tick);}
}