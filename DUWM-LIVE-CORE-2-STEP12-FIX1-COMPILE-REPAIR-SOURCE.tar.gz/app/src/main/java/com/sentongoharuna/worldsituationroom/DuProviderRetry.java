package com.sentongoharuna.worldsituationroom;
import android.content.*;
public final class DuProviderRetry{
 private DuProviderRetry(){}
 public static boolean request(Context c,String system){
  if(!DuProviderBackoff.ready(c,system))return false;
  try{DuProviderRefresh.request(c,system);return true;}catch(Throwable e){DuProviderBackoff.failure(c,system);DuRecoveryState.fail(c,"RETRY:"+system,e.getMessage());return false;}
 }
 public static void result(Context c,String system,boolean ok,String reason){
  if(ok){DuProviderBackoff.success(c,system);DuRecoveryState.ok(c,"RETRY:"+system);}
  else{DuProviderBackoff.failure(c,system);DuRecoveryState.fail(c,"RETRY:"+system,reason);}
 }
}
