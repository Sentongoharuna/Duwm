package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.widget.*;import java.text.*;import java.util.*;
public final class DuCrashHistoryStrip{
 public static LinearLayout make(Activity a){String[] rows=CrashLedger.history(a);LinearLayout r=Du2Ui.panel(a,"RECOVERY HISTORY","● "+rows.length+" EVENTS","Chronological local-only record of recovered/fatal module failures. Nothing here is uploaded.");
  int shown=Math.min(6,rows.length);for(int i=0;i<shown;i++){String[]x=rows[i].split("\\|",6);if(x.length<6)continue;long at=0;try{at=Long.parseLong(x[0]);}catch(Exception ignored){}String time=at<=0?"UNKNOWN":new SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date(at));r.addView(Du2Ui.t(a,time+" · "+x[1]+" · "+x[2]+"\n"+x[3]+" · "+x[4]+" · "+x[5],8));}
  if(rows.length==0)r.addView(Du2Ui.t(a,"NO RECORDED FAILURES",8));return r;}
}
