package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.widget.*;
public final class DuProviderOpsStrip{
 public static LinearLayout make(Activity a){LinearLayout r=Du2Ui.panel(a,"SOURCE HEALTH","● LIVE DIAGNOSTICS","Actual provider state, callback latency, last success/failure, failure streak, next retry and provider reason.");for(String s:new String[]{"AIR","SEA","WX","EVENTS","ORBIT","MONITORS"}){r.addView(Du2Ui.t(a,s+"\n"+DuProviderDiagnostics.summary(a,s),8));}return r;}
}
