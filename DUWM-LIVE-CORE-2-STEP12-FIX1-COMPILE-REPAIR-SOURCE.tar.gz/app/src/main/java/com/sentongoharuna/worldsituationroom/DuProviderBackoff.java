package com.sentongoharuna.worldsituationroom;
import android.content.*;
public final class DuProviderBackoff{
 private static final String P="duwm_provider_backoff_v1";
 private DuProviderBackoff(){}
 public static final class State{public final int failures;public final long lastFailure,nextRetry,lastSuccess;State(int f,long lf,long nr,long ls){failures=f;lastFailure=lf;nextRetry=nr;lastSuccess=ls;}}
 public static State state(Context c,String provider){android.content.SharedPreferences p=c.getSharedPreferences(P,0);String k=key(provider);return new State(p.getInt(k+"_f",0),p.getLong(k+"_lf",0),p.getLong(k+"_nr",0),p.getLong(k+"_ls",0));}
 public static boolean ready(Context c,String provider){return System.currentTimeMillis()>=state(c,provider).nextRetry;}
 public static void success(Context c,String provider){String k=key(provider);c.getSharedPreferences(P,0).edit().putInt(k+"_f",0).putLong(k+"_nr",0).putLong(k+"_ls",System.currentTimeMillis()).apply();}
 public static long failure(Context c,String provider){State s=state(c,provider);int f=Math.min(8,s.failures+1);long base=15000L;long delay=Math.min(15*60*1000L,base*(1L<<Math.min(6,f-1)));long now=System.currentTimeMillis();long next=now+delay;String k=key(provider);c.getSharedPreferences(P,0).edit().putInt(k+"_f",f).putLong(k+"_lf",now).putLong(k+"_nr",next).apply();return next;}
 public static long waitMs(Context c,String provider){return Math.max(0L,state(c,provider).nextRetry-System.currentTimeMillis());}
 public static String label(Context c,String provider){State s=state(c,provider);if(s.failures==0)return "READY";long sec=(waitMs(c,provider)+999)/1000;return "RETRY "+sec+"s · FAILURES "+s.failures;}
 private static String key(String s){return s==null?"unknown":s.replaceAll("[^A-Za-z0-9_]","_").toLowerCase(java.util.Locale.ROOT);}
}
