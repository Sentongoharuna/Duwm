package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.widget.*;
public final class DuStateParityStrip{
 public static LinearLayout make(Activity a){LinearLayout r=Du2Ui.panel(a,"APP ↔ WIDGET STATE","● SHARED REPOSITORY","The app and widgets read the same canonical live-state snapshot.");for(DuSharedLiveState.Item i:DuSharedLiveState.all(a))r.addView(Du2Ui.t(a,i.system+" · "+i.count+" · "+i.state,8));return r;}
}
