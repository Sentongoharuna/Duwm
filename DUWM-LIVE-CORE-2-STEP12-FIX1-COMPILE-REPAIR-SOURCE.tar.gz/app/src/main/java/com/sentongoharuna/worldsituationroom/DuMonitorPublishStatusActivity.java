package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.os.*;import android.widget.*;
public final class DuMonitorPublishStatusActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);LinearLayout r=Du2Ui.shell(this,"MONITOR PUBLISH STATUS");r.addView(DuChronoNav.bar(this,"PUBLISH STATUS","", ""));
  MonitorStore s=new MonitorStore(this);int draft=0,queued=0,upload=0,published=0,failed=0,local=0;
  for(MonitorReport x:s.reports()){if(MonitorReport.STATE_DRAFT.equals(x.uploadState))draft++;else if(MonitorReport.STATE_QUEUED.equals(x.uploadState))queued++;else if(MonitorReport.STATE_UPLOADING.equals(x.uploadState))upload++;else if(MonitorReport.STATE_PUBLISHED.equals(x.uploadState))published++;else if(MonitorReport.STATE_FAILED.equals(x.uploadState))failed++;else local++;}
  r.addView(Du2Ui.panel(this,"END-TO-END PIPELINE","● REAL STATE","CAPTURE / IMPORT → PREVIEW → LOCATION + CAPTION → SAVE / PUBLISH → QUEUE → UPLOAD → FEED"));
  r.addView(Du2Ui.panel(this,"OUTBOX","● "+s.reports().size()+" REPORTS","DRAFT "+draft+" · LOCAL "+local+" · QUEUED "+queued+" · UPLOADING "+upload+" · PUBLISHED "+published+" · FAILED "+failed));
  Button go=Du2Ui.button(this,"OPEN PUBLISHER");go.setOnClickListener(v->startActivity(new android.content.Intent(this,LocalMonitorActivity.class)));r.addView(go);setContentView(r);
 }
}
