package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.os.*;import android.widget.*;import java.util.*;
public final class DuGlobeIntelligenceActivity extends Activity{
 Signal anchor;DuLiveRepository repo;
 public void onCreate(Bundle b){super.onCreate(b);repo=new DuLiveRepository(this);String system=getIntent().getStringExtra("system"),id=getIntent().getStringExtra("record_id");anchor=repo.find(system,id);LinearLayout r=Du2Ui.shell(this,"GLOBE INTELLIGENCE");r.addView(DuChronoNav.bar(this,"INTELLIGENCE","", ""));ScrollView sc=new ScrollView(this);LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);sc.addView(c);
  if(anchor==null){c.addView(Du2Ui.panel(this,"TARGET UNAVAILABLE","● PROVIDER SNAPSHOT CHANGED","The selected globe object is no longer present. DUWM will not invent its details."));r.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(r);return;}
  c.addView(Du2Ui.t(this,DuOfflineUx.state(this,DuSignalIntent.system(anchor)),8));c.addView(Du2Ui.panel(this,anchor.title,"● "+anchor.layer.name()+" · "+anchor.source,anchor.summary+"\n"+anchor.region));
  Button exact=Du2Ui.button(this,"OPEN EXACT RECORD");exact.setOnClickListener(v->startActivity(DuSignalIntent.detail(this,anchor)));c.addView(exact);
  if(anchor.hasLocation()){Button track=Du2Ui.button(this,"TRACK / MAP");track.setOnClickListener(v->startActivity(DuSignalIntent.track(this,anchor)));c.addView(track);}
  List<DuRelatedEngine.Relation> rel=new DuRelatedEngine(this).related(anchor,12);c.addView(Du2Ui.panel(this,"RELATED INTELLIGENCE","● "+rel.size()+" LINKS","Calculated from geography, time, region, event type and entity/topic overlap."));
  for(DuRelatedEngine.Relation x:rel){Button relatedButton=Du2Ui.button(this,String.format(Locale.US,"%.0f%% · %s · %s",x.score*100,x.signal.layer.name(),x.signal.title));relatedButton.setContentDescription("Related: "+x.why);relatedButton.setOnClickListener(v->startActivity(intent(x.signal)));c.addView(relatedButton);c.addView(Du2Ui.t(this,"↳ "+x.why+" · "+x.signal.source,8));}
  List<MonitorReport> monitors=DuMonitorRelations.near(this,anchor);for(MonitorReport m:monitors){Button monitorButton=Du2Ui.button(this,"LOCAL MONITOR · "+m.locationName+" · "+m.displayName);monitorButton.setOnClickListener(v->DuMonitorPlayer.open(this,m.id));c.addView(monitorButton);}
  r.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(r);
 }
 android.content.Intent intent(Signal s){return new android.content.Intent(this,DuGlobeIntelligenceActivity.class).putExtra("system",DuSignalIntent.system(s)).putExtra("record_id",s.id);}
 public static android.content.Intent open(android.content.Context c,Signal s){return new android.content.Intent(c,DuGlobeIntelligenceActivity.class).putExtra("system",DuSignalIntent.system(s)).putExtra("record_id",s.id);}
}
