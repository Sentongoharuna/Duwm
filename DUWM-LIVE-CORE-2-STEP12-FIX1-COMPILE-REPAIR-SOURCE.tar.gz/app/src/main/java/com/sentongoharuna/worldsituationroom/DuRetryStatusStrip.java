package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.widget.*;
public final class DuRetryStatusStrip{
 public static LinearLayout make(Activity a){LinearLayout r=Du2Ui.panel(a,"NETWORK RECOVERY","● AUTOMATIC BACKOFF","Failed providers retry progressively instead of hammering the network.");for(String s:new String[]{"AIR","SEA","WX","EVENTS","ORBIT","MONITORS"})r.addView(Du2Ui.t(a,s+" · "+DuProviderBackoff.label(a,s),9));return r;}
}
