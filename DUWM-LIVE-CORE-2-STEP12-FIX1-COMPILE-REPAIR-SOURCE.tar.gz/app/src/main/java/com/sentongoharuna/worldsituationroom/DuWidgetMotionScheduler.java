package com.sentongoharuna.worldsituationroom;
import android.appwidget.*;import android.content.*;import android.os.*;
public final class DuWidgetMotionScheduler{
 private static final Handler H=new Handler(Looper.getMainLooper());private static Runnable task;
 private DuWidgetMotionScheduler(){}
 public static void start(Context c){Context a=c.getApplicationContext();stop();task=new Runnable(){public void run(){Intent i=new Intent(AppWidgetManager.ACTION_APPWIDGET_UPDATE);i.setPackage(a.getPackageName());a.sendBroadcast(i);H.postDelayed(this,DuDeviceGovernor.widgetMs(a));}};H.post(task);}
 public static void stop(){if(task!=null)H.removeCallbacks(task);task=null;}
}
