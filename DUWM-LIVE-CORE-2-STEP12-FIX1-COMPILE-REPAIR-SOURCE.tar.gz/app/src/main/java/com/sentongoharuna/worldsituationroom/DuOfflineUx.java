package com.sentongoharuna.worldsituationroom;
import android.content.*;
public final class DuOfflineUx{
 private DuOfflineUx(){}
 public static String state(Context c,String system){
  DuLiveHealth.State s=DuLiveHealth.state(c,system);String age=DuFreshness.label(c,system);
  if(s==DuLiveHealth.State.LIVE)return "● LIVE · "+age;
  if(s==DuLiveHealth.State.DELAYED)return "● DELAYED · LAST VALID "+age;
  if(new DuLiveRepository(c).count(system)>0)return "● LAST VALID OFFLINE SNAPSHOT · "+age;
  return "● OFFLINE · NO VALID SNAPSHOT";
 }
 public static String detail(Context c,String system){
  return state(c,system)+"\n"+DuProviderDiagnostics.summary(c,system);
 }
}
