package com.sentongoharuna.worldsituationroom;
public final class DuBuildIdentity {
 public static final String NAME="DUWM LIVE CORE 1";
 public static final String ID="LIVECORE1-20260925";
 private DuBuildIdentity(){}
}
