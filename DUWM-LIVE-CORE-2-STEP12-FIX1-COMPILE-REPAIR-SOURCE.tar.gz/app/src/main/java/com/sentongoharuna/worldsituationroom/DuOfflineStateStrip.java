package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.widget.*;
public final class DuOfflineStateStrip{
 public static LinearLayout make(Activity a){LinearLayout r=Du2Ui.panel(a,"DATA FRESHNESS","● LIVE / DELAYED / OFFLINE","Every system states whether information is live or the last valid cached snapshot.");for(String s:new String[]{"AIR","SEA","WX","EVENTS","ORBIT","MONITORS"})r.addView(Du2Ui.t(a,s+" · "+DuOfflineUx.state(a,s),8));return r;}
}
