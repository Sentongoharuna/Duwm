package com.sentongoharuna.worldsituationroom;
import android.content.*;
public final class DuLiveHealth {
 public enum State { LIVE, DELAYED, OFFLINE, UNKNOWN }
 private DuLiveHealth(){}
 public static State state(Context c,String system){
  long a=DuFreshness.age(c,system);
  if(a<0)return State.UNKNOWN;
  if(a<5*60*1000L)return State.LIVE;
  if(a<30*60*1000L)return State.DELAYED;
  return State.OFFLINE;
 }
 public static String label(Context c,String system){return state(c,system).name()+" · "+DuFreshness.label(c,system);}
}
