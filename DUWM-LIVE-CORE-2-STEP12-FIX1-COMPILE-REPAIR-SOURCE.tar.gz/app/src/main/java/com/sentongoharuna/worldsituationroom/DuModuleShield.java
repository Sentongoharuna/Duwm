package com.sentongoharuna.worldsituationroom;
import android.content.*;
public final class DuModuleShield {
 private DuModuleShield(){}
 public static boolean run(Context c,String module,Runnable action){
  try{action.run();return true;}catch(Throwable e){CrashLedger.recordRecovered(c,module,e);return false;}
 }
}
