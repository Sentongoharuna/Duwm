package com.sentongoharuna.worldsituationroom;
import android.content.*;import android.os.*;
public final class DuDeviceGovernor{
 public enum Mode{FULL,BALANCED,CONSERVE}
 public static final class State{public final int battery,thermal;public final boolean charging;public final Mode mode;State(int b,int t,boolean c,Mode m){battery=b;thermal=t;charging=c;mode=m;}}
 private DuDeviceGovernor(){}
 public static State state(Context c){
  Intent i=c.registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));int level=-1,scale=100,status=-1;
  if(i!=null){level=i.getIntExtra(BatteryManager.EXTRA_LEVEL,-1);scale=i.getIntExtra(BatteryManager.EXTRA_SCALE,100);status=i.getIntExtra(BatteryManager.EXTRA_STATUS,-1);}
  int pct=level<0?-1:Math.max(0,Math.min(100,(int)(level*100f/Math.max(1,scale))));
  boolean charging=status==BatteryManager.BATTERY_STATUS_CHARGING||status==BatteryManager.BATTERY_STATUS_FULL;
  int thermal=Build.VERSION.SDK_INT>=29?((PowerManager)c.getSystemService(Context.POWER_SERVICE)).getCurrentThermalStatus():-1;
  Mode m=Mode.FULL;if((pct>=0&&pct<=15&&!charging)||(thermal>=0&&thermal>=PowerManager.THERMAL_STATUS_SEVERE))m=Mode.CONSERVE;else if((pct>=0&&pct<=30&&!charging)||(thermal>=0&&thermal>=PowerManager.THERMAL_STATUS_MODERATE)||DuPerformancePolicy.lowMemory(c))m=Mode.BALANCED;
  return new State(pct,thermal,charging,m);
 }
 public static long refreshMs(Context c){Mode m=state(c).mode;return m==Mode.CONSERVE?180000L:m==Mode.BALANCED?90000L:30000L;}
 public static long widgetMs(Context c){Mode m=state(c).mode;return m==Mode.CONSERVE?180000L:m==Mode.BALANCED?90000L:30000L;}
 public static boolean animateGlobe(Context c){return state(c).mode!=Mode.CONSERVE&&!DuAccessibility.reducedMotion(c);}
 public static String label(Context c){State s=state(c);return s.mode+" · BATTERY "+(s.battery<0?"UNKNOWN":s.battery+"%")+(s.charging?" · CHARGING":"")+" · THERMAL "+thermalName(s.thermal);}
 static String thermalName(int t){if(t<0)return"UNKNOWN";switch(t){case 0:return"NONE";case 1:return"LIGHT";case 2:return"MODERATE";case 3:return"SEVERE";case 4:return"CRITICAL";case 5:return"EMERGENCY";case 6:return"SHUTDOWN";default:return"UNKNOWN";}}
}
