package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.os.*;import android.view.*;import android.widget.*;
public final class DuLiveCounterStrip{
 public static View make(Activity a){
  HorizontalScrollView h=new HorizontalScrollView(a);LinearLayout r=new LinearLayout(a);
  Handler handler=new Handler(Looper.getMainLooper());
  String[] systems={"AIR","SEA","WX","EVENTS","ORBIT","MONITORS"};
  TextView[] cells=new TextView[systems.length];
  for(int i=0;i<systems.length;i++){TextView v=Du2Ui.t(a,"",9);v.setGravity(17);v.setTextColor(Du2Ui.C);v.setMinWidth(Du2Ui.dp(a,78));v.setContentDescription(systems[i]+" live count");cells[i]=v;r.addView(v,new LinearLayout.LayoutParams(Du2Ui.dp(a,82),Du2Ui.dp(a,48)));}
  Runnable tick=new Runnable(){public void run(){DuModuleShield.run(a,"LIVE_COUNTERS",()->{DuLiveCounts c=new DuLiveCounts(a);for(int i=0;i<systems.length;i++){String s=systems[i];DuSharedLiveState.Item z=DuSharedLiveState.item(a,s);cells[i].setText(s+"\n"+z.count+" · "+z.state);}});handler.postDelayed(this,DuPerformancePolicy.liveRefreshMs(a));}};
  tick.run();h.addView(r);return h;
 }
}
