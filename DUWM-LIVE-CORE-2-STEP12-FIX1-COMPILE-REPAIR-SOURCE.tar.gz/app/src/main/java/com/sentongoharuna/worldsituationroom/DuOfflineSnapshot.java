package com.sentongoharuna.worldsituationroom;
import android.content.*;import java.util.*;
public final class DuOfflineSnapshot{
 private DuOfflineSnapshot(){}
 public static String status(Context c,String system){
  DuLiveRepository r=new DuLiveRepository(c);
  return r.snapshot(system)==null?"NO CACHED SNAPSHOT":"LAST VALID · "+r.age(system);
 }
}
