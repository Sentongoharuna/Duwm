package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.content.*;
public final class DuMonitorSocial{
 private DuMonitorSocial(){}
 public static void share(Activity a,MonitorReport r){
  if(r==null)return;String text=(r.headline.isEmpty()?r.category:r.headline)+"\n"+r.caption+"\n"+r.locationName;
  if(r.shareUrl!=null&&!r.shareUrl.isEmpty())text+="\n"+r.shareUrl;
  Intent i=new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,text);
  a.startActivity(Intent.createChooser(i,"Share monitor report"));
 }
 public static void report(Activity a,MonitorReport r){
  if(r==null)return;new AlertDialog.Builder(a).setTitle("Report this monitor report")
   .setItems(new String[]{"MISLEADING","DANGEROUS LOCATION","HARASSMENT","SPAM","OTHER"},(d,w)->{
    a.getSharedPreferences("duwm_monitor_reports_v1",0).edit().putString(r.id,new String[]{"MISLEADING","DANGEROUS LOCATION","HARASSMENT","SPAM","OTHER"}[w]).apply();
    android.widget.Toast.makeText(a,"Report saved for review",android.widget.Toast.LENGTH_SHORT).show();
   }).setNegativeButton("CANCEL",null).show();
 }
}
