# Monitor Social Step 2
Real report cards and player now expose Like, Discussion, Share and Report.
Existing discussion engine already supports persistent comments, reply parentage through DuThreadStore, local-first posting, remote sync and like sync.
Existing reporter profile surface retains report history.
Share uses Android Sharesheet and includes a server share URL only when one exists.
Report reasons are stored locally for review; the app does not pretend a server moderation action succeeded when no moderation endpoint is configured.
