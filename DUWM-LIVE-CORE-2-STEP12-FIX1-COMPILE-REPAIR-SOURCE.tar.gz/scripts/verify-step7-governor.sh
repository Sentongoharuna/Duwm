#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuDeviceGovernor DuGovernorStrip;do test -s "$J/$f.java";done
grep -F 'BATTERY_STATUS_CHARGING' "$J/DuDeviceGovernor.java" >/dev/null
grep -F 'getCurrentThermalStatus' "$J/DuDeviceGovernor.java" >/dev/null
grep -F 'THERMAL_STATUS_SEVERE' "$J/DuDeviceGovernor.java" >/dev/null
grep -F 'DuDeviceGovernor.refreshMs(c)' "$J/DuPerformancePolicy.java" >/dev/null
grep -F 'DuDeviceGovernor.widgetMs(a)' "$J/DuWidgetMotionScheduler.java" >/dev/null
grep -F 'DuDeviceGovernor.animateGlobe(getContext())' "$J/SatelliteMapView.java" >/dev/null
grep -F 'DuGovernorStrip.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
echo "STEP7 BATTERY THERMAL GOVERNOR VERIFIED"
