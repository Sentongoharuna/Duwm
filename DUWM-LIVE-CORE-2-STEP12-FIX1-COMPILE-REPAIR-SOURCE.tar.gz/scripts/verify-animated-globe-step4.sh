#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";F="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/SatelliteMapView.java"
grep -F 'drawDuIntelligenceClusters(canvas)' "$F" >/dev/null
grep -F 'g.size()+" SIGNALS"' "$F" >/dev/null
grep -F 'Math.sin(now/420.0)' "$F" >/dev/null
grep -F 'centerLongitude += 0.018d' "$F" >/dev/null
grep -F 'DuAccessibility.reducedMotion(getContext())' "$F" >/dev/null
grep -F 'duLastTouchMs = System.currentTimeMillis()' "$F" >/dev/null
grep -F 'displayPosition(s, display)' "$F" >/dev/null
grep -F 'drawMotionTrail' "$F" >/dev/null
echo "TRUE ANIMATED GLOBE STEP4 VERIFIED"
