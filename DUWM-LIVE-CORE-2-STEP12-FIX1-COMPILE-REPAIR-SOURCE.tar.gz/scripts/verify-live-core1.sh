#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuBuildIdentity DuLiveHealth DuModuleShield DuLiveCoreDiagnostics DuOfflineSnapshot DuAutoRefresh DuLiveCounterStrip DuPerformancePolicy DuMonitorHubActivity DuMonitorPlayer DuMonitorPlayerActivity OperationsSnapshotStore CrashLedger; do
  test -f "$J/$f.java"
done
grep -F 'LIVECORE1-20260925' "$J/DuBuildIdentity.java" >/dev/null
grep -F 'LIVE, DELAYED, OFFLINE, UNKNOWN' "$J/DuLiveHealth.java" >/dev/null
grep -F 'CrashLedger.recordRecovered' "$J/DuModuleShield.java" >/dev/null
grep -F 'liveRefreshMs' "$J/DuPerformancePolicy.java" >/dev/null
grep -F 'DuLiveHealth.state' "$J/DuLiveCounterStrip.java" >/dev/null
grep -F 'LAST VALID' "$J/DuOfflineSnapshot.java" >/dev/null
grep -F 'DuLiveCoreDiagnostics.summary' "$J/DuIntegrationStatusActivity.java" >/dev/null
echo "DUWM LIVE CORE 1 CONTRACT VERIFIED"
