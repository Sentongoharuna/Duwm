#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
grep -F 'DuFirstPageTools.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
grep -F 'DuWidgetMotionScheduler.start(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
for x in 'GLOBE INTELLIGENCE' 'LOCAL MONITOR PUBLISH' 'MONITOR NETWORK' 'ASK DUWM' 'SCENE DIRECTOR' 'DETECTION HUD' 'NEWS CLUSTERS' 'WATCHLIST' 'SOURCE INDEX' 'SHARE STUDIO' 'PERFORMANCE' 'ACCESSIBILITY' 'RECOVERY' 'NAV MATRIX' 'VISUAL QA';do grep -F "$x" "$J/DuFirstPageTools.java" >/dev/null;done
grep -F 'ACTION_APPWIDGET_UPDATE' "$J/DuWidgetMotionScheduler.java" >/dev/null
grep -F 'cycleValues' "$J/DuWidgetRenderer.java" >/dev/null
echo "STEP5 FIRST PAGE AND WIDGET MOTION VERIFIED"
