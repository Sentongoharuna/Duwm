#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$P/app/src/main/AndroidManifest.xml"
test -s "$J/DuGlobeIntelligenceActivity.java"
grep -F 'mapView.highlightSignal(signal)' "$J/MainActivity.java" >/dev/null
grep -F 'DuGlobeIntelligenceActivity.open' "$J/MainActivity.java" >/dev/null
grep -F 'new DuRelatedEngine(this).related(anchor,12)' "$J/DuGlobeIntelligenceActivity.java" >/dev/null
grep -F 'DuMonitorRelations.near(this,anchor)' "$J/DuGlobeIntelligenceActivity.java" >/dev/null
grep -F 'DuSignalIntent.detail(this,anchor)' "$J/DuGlobeIntelligenceActivity.java" >/dev/null
grep -F 'DuSignalIntent.track(this,anchor)' "$J/DuGlobeIntelligenceActivity.java" >/dev/null
grep -F 'DuGlobeIntelligenceActivity' "$M" >/dev/null
echo "GLOBE TO INTELLIGENCE STEP3 VERIFIED"
