#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuCrashHistoryStrip.java"
grep -F 'MAX_HISTORY = 20' "$J/CrashLedger.java" >/dev/null
grep -F 'appendHistory(context, now, reference, component, error, fatal)' "$J/CrashLedger.java" >/dev/null
grep -F 'public static String[] history' "$J/CrashLedger.java" >/dev/null
grep -F 'RECOVERY HISTORY' "$J/DuCrashHistoryStrip.java" >/dev/null
grep -F 'DuCrashHistoryStrip.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
echo "STEP9 CRASH HISTORY VERIFIED"
