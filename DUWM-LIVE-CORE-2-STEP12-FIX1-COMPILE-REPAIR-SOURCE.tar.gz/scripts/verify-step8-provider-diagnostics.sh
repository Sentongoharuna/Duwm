#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuProviderOpsStrip.java"
grep -F 'putLong(k+":latency"' "$J/DuProviderHealthStore.java" >/dev/null
grep -F 'public static long latency' "$J/DuProviderHealthStore.java" >/dev/null
for x in 'LATENCY ' 'LAST SUCCESS ' 'LAST FAILURE ' 'FAILURES ' 'REASON ';do grep -F "$x" "$J/DuProviderDiagnostics.java" >/dev/null;done
grep -F 'DuProviderBackoff.label' "$J/DuProviderDiagnostics.java" >/dev/null
grep -F 'DuProviderOpsStrip.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
echo "STEP8 PROVIDER DIAGNOSTICS VERIFIED"
