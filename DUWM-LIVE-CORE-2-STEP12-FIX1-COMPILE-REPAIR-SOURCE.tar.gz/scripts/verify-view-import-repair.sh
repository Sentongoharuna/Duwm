#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
F="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/DuIntegratedHomeActivity.java"
grep -F 'import android.view.View;' "$F" >/dev/null
grep -F 'View x=Du2Ui.button' "$F" >/dev/null || grep -F 'View x = Du2Ui.button' "$F" >/dev/null
echo "ANDROID VIEW IMPORT REPAIR VERIFIED"
