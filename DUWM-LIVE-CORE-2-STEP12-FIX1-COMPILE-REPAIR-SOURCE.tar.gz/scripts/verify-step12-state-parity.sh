#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuSharedLiveState.java";test -s "$J/DuStateParityStrip.java"
grep -F 'DuSharedLiveState.item(a,s)' "$J/DuLiveCounterStrip.java" >/dev/null
grep -F 'DuSharedLiveState.compact(context' "$J/DuWidgetRenderer.java" >/dev/null
grep -F 'DuStateParityStrip.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
for s in AIR SEA WX EVENTS ORBIT MONITORS;do grep -F "$s" "$J/DuSharedLiveState.java" >/dev/null;done
echo "STEP12 APP WIDGET STATE PARITY VERIFIED"
