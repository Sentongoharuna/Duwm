#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuOfflineUx.java";test -s "$J/DuOfflineStateStrip.java"
grep -F 'LAST VALID OFFLINE SNAPSHOT' "$J/DuOfflineUx.java" >/dev/null
grep -F 'OFFLINE · NO VALID SNAPSHOT' "$J/DuOfflineUx.java" >/dev/null
grep -F 'DuOfflineStateStrip.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
grep -F 'DuOfflineUx.state(this,DuSignalIntent.system(anchor))' "$J/DuGlobeIntelligenceActivity.java" >/dev/null
echo "STEP10 OFFLINE UX VERIFIED"
