#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
! grep -F 'centerLongitude' "$J/SatelliteMapView.java"
grep -F 'rotationDegrees += 0.018f' "$J/SatelliteMapView.java" >/dev/null
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
grep -F 'DuOfflineUx.state(this,sys)' "$J/DuRecordDetailActivity.java" >/dev/null
! grep -F '"DUWM page "+title' "$J/Du2Ui.java"
grep -F '"DUWM page "+page' "$J/Du2Ui.java" >/dev/null
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"
grep -F 'Button relatedButton=' "$J/DuGlobeIntelligenceActivity.java" >/dev/null
grep -F 'Button monitorButton=' "$J/DuGlobeIntelligenceActivity.java" >/dev/null
echo "STEP12 COMPILE REPAIR VERIFIED"
