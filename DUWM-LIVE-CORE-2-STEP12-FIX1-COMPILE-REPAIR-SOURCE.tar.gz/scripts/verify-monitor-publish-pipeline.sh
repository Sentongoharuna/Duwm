#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in LocalMonitorActivity MonitorApiClient MonitorStore MonitorReport DuMonitorHubActivity DuMonitorPublishStatusActivity;do test -s "$J/$f.java";done
grep -F 'MediaStore.ACTION_VIDEO_CAPTURE' "$J/LocalMonitorActivity.java" >/dev/null
grep -F 'Intent.ACTION_OPEN_DOCUMENT' "$J/LocalMonitorActivity.java" >/dev/null
grep -F 'showComposer' "$J/LocalMonitorActivity.java" >/dev/null
grep -F 'PUBLISH REPORT' "$J/LocalMonitorActivity.java" >/dev/null
grep -F 'STATE_QUEUED' "$J/LocalMonitorActivity.java" >/dev/null
grep -F 'api.uploadReport' "$J/LocalMonitorActivity.java" >/dev/null
grep -F 'resumeQueuedUploads' "$J/LocalMonitorActivity.java" >/dev/null
grep -F 'LOCAL COPY SAFE' "$J/LocalMonitorActivity.java" >/dev/null
grep -F 'PUBLISH LOCAL REPORT' "$J/DuMonitorHubActivity.java" >/dev/null
grep -F 'CAPTURE / IMPORT → PREVIEW → LOCATION + CAPTION → SAVE / PUBLISH → QUEUE → UPLOAD → FEED' "$J/DuMonitorPublishStatusActivity.java" >/dev/null
grep -F 'uploadResumable' "$J/MonitorApiClient.java" >/dev/null
grep -F 'uploadMultipart' "$J/MonitorApiClient.java" >/dev/null
echo "FULL LOCAL MONITOR PUBLISHING PIPELINE VERIFIED"
