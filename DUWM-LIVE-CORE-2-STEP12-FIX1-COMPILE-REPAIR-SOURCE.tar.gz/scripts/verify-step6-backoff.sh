#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuProviderBackoff DuProviderRetry DuRetryStatusStrip;do test -s "$J/$f.java";done
grep -F '15*60*1000L' "$J/DuProviderBackoff.java" >/dev/null
grep -F 'DuProviderBackoff.ready' "$J/DuProviderRetry.java" >/dev/null
grep -F 'DuProviderRetry.request' "$J/DuAutoRefresh.java" >/dev/null
grep -F 'DuProviderRetry.result(this,layer.name()' "$J/MainActivity.java" >/dev/null
grep -F 'DuRetryStatusStrip.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
echo "STEP6 PROVIDER BACKOFF VERIFIED"
