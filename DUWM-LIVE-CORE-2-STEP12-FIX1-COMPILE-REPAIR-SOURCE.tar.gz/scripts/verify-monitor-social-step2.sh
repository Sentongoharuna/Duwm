#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuDiscussionActivity DuReporterProfileActivity DuReporterProfiles DuMonitorSocial DuMonitorHubActivity DuMonitorPlayerActivity MonitorStore MonitorApiClient DuThreadStore;do test -s "$J/$f.java";done
grep -F 'replyTo' "$J/DuDiscussionActivity.java" >/dev/null
grep -F 'DuThreadStore.parent' "$J/DuDiscussionActivity.java" >/dev/null
grep -F 'store.addComment' "$J/DuDiscussionActivity.java" >/dev/null
grep -F 'store.toggleLike' "$J/DuDiscussionActivity.java" >/dev/null
grep -F 'api.setLike' "$J/DuDiscussionActivity.java" >/dev/null
grep -F 'REPORT HISTORY' "$J/DuReporterProfileActivity.java" >/dev/null
grep -F 'SHARE REPORT' "$J/DuMonitorHubActivity.java" >/dev/null
grep -F 'DuMonitorSocial.report' "$J/DuMonitorHubActivity.java" >/dev/null
grep -F 'DuMonitorSocial.share' "$J/DuMonitorPlayerActivity.java" >/dev/null
echo "MONITOR SOCIAL STEP2 VERIFIED"
