#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";H="$J/DuIntegratedHomeActivity.java"
grep -F 'import android.Manifest;' "$H" >/dev/null
grep -F 'Manifest.permission.POST_NOTIFICATIONS' "$H" >/dev/null
grep -F 'DuLiveCounterStrip' "$H" >/dev/null
grep -F 'DuChronoNav' "$H" >/dev/null
grep -F 'DuSelectionState' "$H" >/dev/null
grep -F 'DuPageRouter' "$H" >/dev/null
echo "HOME COMPILE REPAIR STATIC CHECK PASS"
