#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuRuntimeQaStrip.java"
grep -F 'DuRuntimeQaStrip.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
grep -F 'screenWidthDp' "$J/DuRuntimeQaStrip.java" >/dev/null
grep -F 'fontScale' "$J/DuRuntimeQaStrip.java" >/dev/null
grep -F 'lowMemory' "$J/DuRuntimeQaStrip.java" >/dev/null
grep -F 'DuDeviceGovernor.label' "$J/DuRuntimeQaStrip.java" >/dev/null
grep -F 'DuVisualQa.applyInsets(a,r)' "$J/Du2Ui.java" >/dev/null
grep -F 'DuVisualQa.fill(r,a)' "$J/Du2Ui.java" >/dev/null
grep -F 'setClipToPadding(false)' "$J/Du2Ui.java" >/dev/null
grep -F 'HorizontalScrollView chipScroll' "$J/DuSystemIndexActivity.java" >/dev/null
echo "STEP11 REAL DEVICE RUNTIME QA VERIFIED"
