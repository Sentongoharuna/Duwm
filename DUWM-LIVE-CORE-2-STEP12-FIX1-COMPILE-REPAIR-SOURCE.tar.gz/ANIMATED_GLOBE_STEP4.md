# Step 4 — True Animated Globe Intelligence
- Preserves real aircraft/ship interpolation and motion trails already in SatelliteMapView.
- Adds severity-aware screen-space clustering for non-traffic intelligence.
- Multi-signal clusters pulse continuously and display live cluster counts.
- Adds slow ambient globe rotation after 5 seconds of no touch.
- Any touch immediately suspends ambient rotation; reduced-motion disables it.
- Cluster placement is recalculated from the current projected provider coordinates every frame.
