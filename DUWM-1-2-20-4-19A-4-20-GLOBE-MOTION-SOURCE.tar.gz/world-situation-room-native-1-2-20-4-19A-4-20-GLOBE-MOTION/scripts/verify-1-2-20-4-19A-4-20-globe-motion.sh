#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"; V="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/SatelliteMapView.java"
"$P/scripts/verify-1-2-20-4-19A-4-19-fix7-complete-list-contract.sh" "$P"
grep -F 'AUTO_ROTATION_DEG_PER_SECOND = 2.4d' "$V" >/dev/null
grep -F 'advanceLiveMotion(elapsed)' "$V" >/dev/null
grep -F 'postOnAnimationDelayed(this, MOTION_FRAME_MS)' "$V" >/dev/null
grep -F 'protected void onAttachedToWindow()' "$V" >/dev/null
! grep -F '+ 8_000L' "$V"
! grep -F '+ 15_000L' "$V"
echo '4.20 GLOBE MOTION GREEN GATE PASS'
