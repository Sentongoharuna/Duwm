package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;

/** Independent V25 OpenSky world map and gateway to the ORIGINAL worldwide globe.
 * Markers are FIXES RECEIVED from the provider and are not animated as new fixes.
 * Does not claim the OpenSky network covers every flight on Earth.
 */
public final class RunningballV25WorldwideAirActivity extends Activity {
  private static final int BG=0xFF041424, INK=0xFFE0EAFE, CYAN=0xFF558BDF,
      GREEN=DuwmUnifiedTheme.STATUS_GREEN, AMBER=DuwmUnifiedTheme.STATUS_ORANGE, MUTED=0xFFBECBCE;
  private final Handler handler=new Handler(Looper.getMainLooper());
  private final Runnable tick=new Runnable(){@Override public void run(){if(!active)return;if(!autoRefreshEnabled){handler.postDelayed(this,30000L);return;}RunningballV25GlobalAircraftData.refresh(RunningballV25WorldwideAirActivity.this,null);render();handler.postDelayed(this,30000L);}};
  private TextView status,detail,displacementInfo,sourceToggle,mapSizeToggle,refreshLabel,autoRefreshToggle,filterToggle,trailToggle,legend;
  private LinearLayout.LayoutParams mapLayout;
  private boolean mapExpanded=false;
  private boolean autoRefreshEnabled=true;
  private boolean sourceExpanded=false;
  private boolean airborneOnly=false,showTrails=true;
  private boolean focusMode=false,highContrast=false;
  private boolean callsignLabels=false;
  private boolean gridVisible=true;
  private int markerSize=1; // 0 compact, 1 normal, 2 large
  private TextView gridToggle,markerToggle;
  private int altitudeBand=0; // 0 all, 1 low, 2 mid, 3 high
  private LinearLayout secondaryControls;
  private TextView focusToggle,contrastToggle,labelsToggle,altitudeToggle;
  private FlightPlot plot;
  private boolean active;
  private int dp(float v){return Math.round(getResources().getDisplayMetrics().density*v);}
  private TextView text(String value,int size,int color){TextView v=new TextView(this);v.setText(value);v.setTextColor(color);v.setTextSize(size);v.setPadding(dp(10),dp(7),dp(10),dp(7));return v;}
  private void add(LinearLayout c,String title,Runnable action){
    TextView b=text(title,13,CYAN);b.setBackgroundColor(0xFF0C1B39);b.setMinimumHeight(dp(50));
    b.setOnClickListener(v->action.run());b.setContentDescription(title);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(7);c.addView(b,p);
  }
  @Override public void onCreate(Bundle saved){super.onCreate(saved);
    getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
    LinearLayout col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);col.setPadding(dp(6),dp(8),dp(6),dp(12));col.setBackgroundColor(BG);
    TextView headline=text("WORLDWIDE AIRCRAFT  /  OPEN SKY",19,GREEN);col.addView(headline);
    TextView caution=text("OBSERVED NETWORK COVERAGE · NOT EVERY AIRCRAFT ON EARTH · RATE-LIMITED",11,AMBER);col.addView(caution);
    status=text("AWAITING THE FIRST VERIFIED GLOBAL RESPONSE",12,INK);
    sourceToggle=text("SOURCE DETAILS ▾  /  TAP TO EXPAND",12,CYAN);
    sourceToggle.setBackgroundColor(0xFF0C1B39);
    sourceToggle.setOnClickListener(v->{sourceExpanded=!sourceExpanded;status.setVisibility(sourceExpanded?View.VISIBLE:View.GONE);sourceToggle.setText(sourceExpanded?"SOURCE DETAILS ▴  /  TAP TO HIDE":"SOURCE DETAILS ▾  /  TAP TO EXPAND");});
    col.addView(sourceToggle);col.addView(status);status.setVisibility(View.GONE);
    android.content.SharedPreferences prefs=getSharedPreferences("aircraft_view",MODE_PRIVATE);
    mapExpanded=prefs.getBoolean("expanded",false);
    autoRefreshEnabled=prefs.getBoolean("auto_refresh",true);
    airborneOnly=prefs.getBoolean("airborne_only",false);
    showTrails=prefs.getBoolean("show_trails",true);
    focusMode=prefs.getBoolean("focus_mode",false);
    highContrast=prefs.getBoolean("high_contrast",false);
    callsignLabels=prefs.getBoolean("callsign_labels",false);
    altitudeBand=prefs.getInt("altitude_band",0);
    gridVisible=prefs.getBoolean("grid_visible",true);
    markerSize=prefs.getInt("marker_size",1);
    plot=new FlightPlot();plot.setMinimumHeight(dp(480));
    plot.setBackgroundColor(highContrast?0xFF020814:BG);
    mapLayout=new LinearLayout.LayoutParams(-1,dp(mapExpanded?760:520));
    LinearLayout modeBar=new LinearLayout(this);modeBar.setOrientation(LinearLayout.HORIZONTAL);
    focusToggle=text(focusMode?"FOCUS: ON":"FOCUS: OFF",12,CYAN);
    contrastToggle=text(highContrast?"CONTRAST: HIGH":"CONTRAST: NORMAL",12,GREEN);
    for(TextView control:new TextView[]{focusToggle,contrastToggle}){
      control.setGravity(Gravity.CENTER);control.setMinimumHeight(dp(48));control.setBackgroundColor(0xFF0C1B39);
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(2),dp(4),dp(2),dp(4));modeBar.addView(control,lp);
    }
    focusToggle.setContentDescription("Show or hide secondary aircraft map controls");
    contrastToggle.setContentDescription("Toggle aircraft map background contrast");
    col.addView(modeBar);
    col.addView(plot,mapLayout);
    mapSizeToggle=text(mapExpanded?"RESTORE MAP  ▴":"EXPAND MAP  ▾",12,CYAN);
    mapSizeToggle.setGravity(Gravity.CENTER);
    mapSizeToggle.setBackgroundColor(0xFF0C1B39);
    mapSizeToggle.setContentDescription("Expand or restore the aircraft map height");
    mapSizeToggle.setOnClickListener(v->{
      mapExpanded=!mapExpanded;
      prefs.edit().putBoolean("expanded",mapExpanded).apply();
      mapLayout.height=dp(mapExpanded?760:520);
      plot.setLayoutParams(mapLayout);
      mapSizeToggle.setText(mapExpanded?"RESTORE MAP  ▴":"EXPAND MAP  ▾");
    });
    col.addView(mapSizeToggle);
    secondaryControls=new LinearLayout(this);secondaryControls.setOrientation(LinearLayout.VERTICAL);
    focusToggle.setOnClickListener(v->{focusMode=!focusMode;prefs.edit().putBoolean("focus_mode",focusMode).apply();focusToggle.setText(focusMode?"FOCUS: ON":"FOCUS: OFF");secondaryControls.setVisibility(focusMode?View.GONE:View.VISIBLE);});
    contrastToggle.setOnClickListener(v->{highContrast=!highContrast;prefs.edit().putBoolean("high_contrast",highContrast).apply();contrastToggle.setText(highContrast?"CONTRAST: HIGH":"CONTRAST: NORMAL");plot.setBackgroundColor(highContrast?0xFF020814:BG);plot.invalidate();});
    refreshLabel=text("NETWORK UPDATE: WAITING FOR FIRST RESPONSE",11,MUTED);
    col.addView(refreshLabel);
    autoRefreshToggle=text(autoRefreshEnabled?"AUTO REFRESH: ON · TAP TO PAUSE":"AUTO REFRESH: PAUSED · TAP TO RESUME",12,CYAN);
    autoRefreshToggle.setGravity(Gravity.CENTER);
    autoRefreshToggle.setBackgroundColor(0xFF0C1B39);
    autoRefreshToggle.setContentDescription("Toggle automatic aircraft network updates");
    autoRefreshToggle.setOnClickListener(v->{
      autoRefreshEnabled=!autoRefreshEnabled;
      prefs.edit().putBoolean("auto_refresh",autoRefreshEnabled).apply();
      autoRefreshToggle.setText(autoRefreshEnabled?"AUTO REFRESH: ON · TAP TO PAUSE":"AUTO REFRESH: PAUSED · TAP TO RESUME");
      if(autoRefreshEnabled)RunningballV25GlobalAircraftData.refreshNow(this,this::render);
      render();
    });
    secondaryControls.addView(autoRefreshToggle);
    LinearLayout layerBar=new LinearLayout(this);layerBar.setOrientation(LinearLayout.HORIZONTAL);
    filterToggle=text(airborneOnly?"FILTER: AIRBORNE":"FILTER: ALL",12,GREEN);
    trailToggle=text(showTrails?"TRAILS: ON":"TRAILS: OFF",12,CYAN);
    for(TextView control:new TextView[]{filterToggle,trailToggle}){
      control.setGravity(Gravity.CENTER);control.setMinimumHeight(dp(48));
      control.setBackgroundColor(0xFF0C1B39);
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(2),dp(4),dp(2),dp(4));layerBar.addView(control,lp);
    }
    filterToggle.setContentDescription("Toggle aircraft with reported altitude above ground only");
    trailToggle.setContentDescription("Show or hide verified two-fix aircraft displacement lines");
    filterToggle.setOnClickListener(v->{airborneOnly=!airborneOnly;prefs.edit().putBoolean("airborne_only",airborneOnly).apply();filterToggle.setText(airborneOnly?"FILTER: AIRBORNE":"FILTER: ALL");plot.invalidate();render();});
    trailToggle.setOnClickListener(v->{showTrails=!showTrails;prefs.edit().putBoolean("show_trails",showTrails).apply();trailToggle.setText(showTrails?"TRAILS: ON":"TRAILS: OFF");plot.invalidate();});
    secondaryControls.addView(layerBar);
    LinearLayout presentationBar=new LinearLayout(this);presentationBar.setOrientation(LinearLayout.HORIZONTAL);
    labelsToggle=text(callsignLabels?"LABELS: ON":"LABELS: OFF",12,CYAN);
    altitudeToggle=text(altitudeBandLabel(),12,GREEN);
    for(TextView control:new TextView[]{labelsToggle,altitudeToggle}){
      control.setGravity(Gravity.CENTER);control.setMinimumHeight(dp(48));control.setBackgroundColor(0xFF0C1B39);
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(2),dp(4),dp(2),dp(4));presentationBar.addView(control,lp);
    }
    labelsToggle.setContentDescription("Toggle aircraft callsign labels on the map");
    altitudeToggle.setContentDescription("Cycle aircraft altitude filters: all, low, medium, high");
    labelsToggle.setOnClickListener(v->{callsignLabels=!callsignLabels;prefs.edit().putBoolean("callsign_labels",callsignLabels).apply();labelsToggle.setText(callsignLabels?"LABELS: ON":"LABELS: OFF");plot.invalidate();});
    altitudeToggle.setOnClickListener(v->{altitudeBand=(altitudeBand+1)%4;prefs.edit().putInt("altitude_band",altitudeBand).apply();altitudeToggle.setText(altitudeBandLabel());plot.invalidate();render();});
    secondaryControls.addView(presentationBar);
    LinearLayout displayBar=new LinearLayout(this);displayBar.setOrientation(LinearLayout.HORIZONTAL);
    gridToggle=text(gridVisible?"GRID: ON":"GRID: OFF",12,CYAN);
    markerToggle=text(markerSize==0?"DOTS: SMALL":markerSize==1?"DOTS: NORMAL":"DOTS: LARGE",12,GREEN);
    for(TextView control:new TextView[]{gridToggle,markerToggle}){
      control.setGravity(Gravity.CENTER);control.setMinimumHeight(dp(48));control.setBackgroundColor(0xFF0C1B39);
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(2),dp(4),dp(2),dp(4));displayBar.addView(control,lp);
    }
    gridToggle.setContentDescription("Show or hide latitude and longitude grid");
    markerToggle.setContentDescription("Cycle aircraft marker size between small, normal and large");
    gridToggle.setOnClickListener(v->{gridVisible=!gridVisible;prefs.edit().putBoolean("grid_visible",gridVisible).apply();gridToggle.setText(gridVisible?"GRID: ON":"GRID: OFF");plot.invalidate();});
    markerToggle.setOnClickListener(v->{markerSize=(markerSize+1)%3;prefs.edit().putInt("marker_size",markerSize).apply();markerToggle.setText(markerSize==0?"DOTS: SMALL":markerSize==1?"DOTS: NORMAL":"DOTS: LARGE");plot.invalidate();});
    secondaryControls.addView(displayBar);
    legend=text("● GREEN: LOW / ALT UNKNOWN    ● CYAN: MID ALTITUDE    ● AMBER: HIGH ALTITUDE",10,MUTED);
    secondaryControls.addView(legend);
    // One new function only: navigate the REAL global aircraft points by zoom and pan.
    LinearLayout zoomBar=new LinearLayout(this);zoomBar.setOrientation(LinearLayout.HORIZONTAL);
    String[] captions={"ZOOM +","ZOOM -","RESET VIEW"};
    for(int z=0;z<captions.length;z++){
      final int which=z;TextView b=text(captions[z],12,CYAN);b.setGravity(Gravity.CENTER);
      b.setMinimumHeight(dp(40));b.setContentDescription(captions[z]+" global aircraft map");
      b.setBackgroundColor(0xFF0C1B39);
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(2),dp(3),dp(2),dp(3));
      zoomBar.addView(b,lp);
      b.setOnClickListener(v->{if(which==0)plot.zoomBy(1.65f);else if(which==1)plot.zoomBy(1f/1.65f);else plot.resetView();});
    }
    secondaryControls.addView(zoomBar);
    secondaryControls.addView(text("DRAG TO PAN  ·  PINCH TO ZOOM  ·  TAP AIRCRAFT FOR DETAILS",10,MUTED));
    displacementInfo=text("TWO-FIX DISPLACEMENTS: NONE UNTIL TWO DISTINCT PROVIDER REPORTS",11,AMBER);secondaryControls.addView(displacementInfo);
    detail=text("Tap a reported position for aircraft identification and last reported time.",12,INK);col.addView(detail);
    col.addView(secondaryControls);secondaryControls.setVisibility(focusMode?View.GONE:View.VISIBLE);
    add(col,"GLOBAL AIRCRAFT REGISTER / SEARCH CALLSIGNS & ICAO  ›",()->startActivity(new Intent(this,RunningballV25FlightRegisterActivity.class)));
    add(col,"OPEN ORIGINAL GLOBE / ORIGINAL LAYERS  ›",()->startActivity(new Intent(this,MainActivity.class)));
    add(col,"REQUEST AIRCRAFT UPDATE NOW  ↻",()->{status.setText("REQUESTED · WAIT FOR VERIFIED PROVIDER RESPONSE");RunningballV25GlobalAircraftData.refreshNow(this,this::render);});
    add(col,"OPEN AIRCRAFT RADAR / SELECTED 250 NM REGION  ›",()->startActivity(new Intent(this,AirRadarActivity.class)));
    add(col,"SOURCE HEALTH & ERRORS  ›",()->startActivity(new Intent(this,RunningballV25SourceHealthActivity.class)));
    add(col,"BACK TO COMMAND CENTER  ‹",this::finish);
    scroll.addView(col);setContentView(scroll);render();
  }
  @Override protected void onResume(){super.onResume();active=true;handler.removeCallbacks(tick);handler.post(tick);
    RunningballV25GlobalAircraftData.refresh(this,()->{if(active)render();});}
  @Override protected void onPause(){active=false;handler.removeCallbacks(tick);super.onPause();}
  private String altitudeBandLabel(){return new String[]{"ALT: ALL","ALT: LOW","ALT: MID","ALT: HIGH"}[altitudeBand];}
  private void render(){
    RunningballV25GlobalAircraftData.Snapshot s=RunningballV25GlobalAircraftData.read(this);
    String age=s.ageLabel();
    status.setText("SOURCE: OpenSky /states/all · HTTP "+(s.lastHttp==0?"UNTESTED":s.lastHttp)+"\n"+
      "PROVIDER RECORDS: "+s.countLabel()+" · WITH POSITION: "+(s.hasGood()?s.positionRows:"--")+
      " · CACHED POSITIONS: "+(s.hasGood()?s.displayRows:"--")+" (BOUNDED CACHE, NO FIXED MAP CLIP)\n"+
      "STATUS: "+s.status()+" · LAST GOOD: "+age+"\n"+
      "PROVIDER SOURCE AGE: "+s.providerAgeLabel()+" · NEXT CHECK: "+s.nextCheckLabel()+"\n"+
      "COVERAGE: WORLDWIDE / OPEN SKY RECEIVERS ONLY"+
      (s.error.isEmpty()?"":"\nLAST NETWORK ERROR: "+s.error));
    plot.update(s);
    refreshLabel.setText("NETWORK: "+s.status()+"  ·  LAST GOOD: "+age+"  ·  "+(autoRefreshEnabled?"NEXT CHECK: "+s.nextCheckLabel():"AUTO UPDATES PAUSED"));
    displacementInfo.setText("TWO-FIX DISPLACEMENTS: "+plot.pairCount()+" / STRAIGHT CONNECTORS, NOT RECORDED ROUTES"+"  ·  DISPLAYED: "+plot.visibleCount()+" / "+plot.totalCount());
  }
  private void selected(JSONArray item){
    if(item==null)return;
    double lat=item.optDouble(0,Double.NaN),lon=item.optDouble(1,Double.NaN);
    String code=item.optString(2,"NOT REPORTED"),call=item.optString(3,"");
    long t=item.isNull(7)?0L:item.optLong(7,0L)*1000L;
    SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'",Locale.US);sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
    String altitude=item.isNull(4)?"NOT REPORTED":String.format(Locale.US,"%.0f m",item.optDouble(4));
    String speed=item.isNull(5)?"NOT REPORTED":String.format(Locale.US,"%.0f km/h",item.optDouble(5)*3.6d);
    String heading=item.isNull(6)?"NOT REPORTED":String.format(Locale.US,"%.0f°",item.optDouble(6));
    detail.setText("AIRCRAFT  "+code+(call.isEmpty()?"":" · "+call)+"\n"+
      String.format(Locale.US,"REPORTED POSITION  %.4f, %.4f",lat,lon)+
      "\nALTITUDE  "+altitude+" · SPEED  "+speed+" · TRACK  "+heading+
      "\nLAST PROVIDER POSITION  "+(t>0?sdf.format(new Date(t)):"TIME UNAVAILABLE"));
    Intent i=new Intent(this,AirFlightDetailsActivity.class);
    i.putExtra("air_provider","OPENSKY");i.putExtra("air_hex",code);
    startActivity(i);
  }
  private final class FlightPlot extends View {
    private JSONArray points=new JSONArray();
    private JSONArray verifiedPairs=new JSONArray();
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private float zoom=1f,shiftX=0f,shiftY=0f,lastX,lastY,downX,downY;
    private boolean dragged=false;
    private final ScaleGestureDetector scale=new ScaleGestureDetector(RunningballV25WorldwideAirActivity.this,
      new ScaleGestureDetector.SimpleOnScaleGestureListener(){
        @Override public boolean onScale(ScaleGestureDetector detector){
          setZoom(zoom*detector.getScaleFactor(),detector.getFocusX(),detector.getFocusY());
          dragged=true;return true;
        }
      });
    FlightPlot(){super(RunningballV25WorldwideAirActivity.this);setBackgroundColor(0xFF041424);
      setContentDescription("OpenSky reported aircraft positions. Pinch zoom, drag pan, or use labelled zoom buttons. Tap a reported marker for real details.");}
    void update(RunningballV25GlobalAircraftData.Snapshot snapshot){
      points=snapshot.hasGood()&&snapshot.ageMs()<21600000L?snapshot.points:new JSONArray();
      verifiedPairs=new JSONArray();
      if(points.length()>0 && snapshot.priorSourceAt>0L && snapshot.sourceAt>snapshot.priorSourceAt
          && snapshot.sourceAt-snapshot.priorSourceAt<=5400000L){
        HashMap<String,JSONArray> previous=new HashMap<>();
        for(int j=0;j<snapshot.priorPoints.length();j++){
          JSONArray p=snapshot.priorPoints.optJSONArray(j);if(p==null)continue;
          String hex=p.optString(2,"").trim();if(!hex.isEmpty())previous.put(hex,p);
        }
        for(int j=0;j<points.length() && verifiedPairs.length()<400;j++){
          JSONArray now=points.optJSONArray(j);if(now==null)continue;
          JSONArray before=previous.get(now.optString(2,"").trim());if(before==null)continue;
          double a=before.optDouble(0,Double.NaN),b=before.optDouble(1,Double.NaN);
          double c=now.optDouble(0,Double.NaN),d=now.optDouble(1,Double.NaN);
          long t0=before.isNull(7)?0:before.optLong(7),t1=now.isNull(7)?0:now.optLong(7);
          if(RunningballV25AircraftTrailPolicy.qualifies(before.optString(2,""),now.optString(2,""),
              a,b,c,d,t0,t1,snapshot.priorSourceAt,snapshot.sourceAt)){
            JSONArray pair=new JSONArray();pair.put(Double.valueOf(a));pair.put(Double.valueOf(b));pair.put(Double.valueOf(c));pair.put(Double.valueOf(d));
            verifiedPairs.put(pair);
          }
        }
      }
      invalidate();
    }
    int pairCount(){return verifiedPairs.length();}
    int totalCount(){return points.length();}
    int visibleCount(){int n=0;for(int i=0;i<points.length();i++){JSONArray p=points.optJSONArray(i);if(p!=null&&passesFilter(p))n++;}return n;}
    private boolean passesFilter(JSONArray row){if(airborneOnly&&(row.isNull(4)||row.optDouble(4,0)<=100d))return false;
      if(altitudeBand==0)return true;
      if(row.isNull(4))return false;
      double altitude=row.optDouble(4,Double.NaN);
      if(Double.isNaN(altitude))return false;
      return altitudeBand==1?altitude<3000d:altitudeBand==2?(altitude>=3000d&&altitude<9000d):altitude>=9000d;}
    private float clamp(float v,float low,float high){return Math.max(low,Math.min(high,v));}
    private void clampPan(){
      shiftX=clamp(shiftX,-getWidth()*(zoom-1f)/2f,getWidth()*(zoom-1f)/2f);
      shiftY=clamp(shiftY,-getHeight()*(zoom-1f)/2f,getHeight()*(zoom-1f)/2f);
    }
    private void setZoom(float next,float fx,float fy){
      if(getWidth()<=0||getHeight()<=0)return;
      float newZoom=clamp(next,1f,12f),ratio=newZoom/zoom;
      shiftX=fx-getWidth()/2f-(fx-getWidth()/2f-shiftX)*ratio;
      shiftY=fy-getHeight()/2f-(fy-getHeight()/2f-shiftY)*ratio;
      zoom=newZoom;clampPan();invalidate();
    }
    void zoomBy(float factor){setZoom(zoom*factor,getWidth()/2f,getHeight()/2f);}
    void resetView(){zoom=1f;shiftX=0f;shiftY=0f;invalidate();}
    private float x(double lon){return ((float)((lon+180d)/360d)*getWidth()-getWidth()/2f)*zoom+getWidth()/2f+shiftX;}
    private float y(double lat){return ((float)((90d-lat)/180d)*getHeight()-getHeight()/2f)*zoom+getHeight()/2f+shiftY;}
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);
      canvas.save();canvas.clipRect(0,0,getWidth(),getHeight());
      paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(0.7f));paint.setColor(0xFF284C87);
      if(gridVisible){
      for(int lon=-180;lon<=180;lon+=30)canvas.drawLine(x(lon),0,x(lon),getHeight(),paint);
      for(int lat=-90;lat<=90;lat+=30)canvas.drawLine(0,y(lat),getWidth(),y(lat),paint);
      }
      // Source-observed end points only; a straight displacement connector is not a recorded route.
      paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1.15f));paint.setColor(0xAA558BDF);
      for(int j=0;showTrails&&j<verifiedPairs.length();j++){
        JSONArray path=verifiedPairs.optJSONArray(j);if(path==null)continue;
        canvas.drawLine(x(path.optDouble(1)),y(path.optDouble(0)),
          x(path.optDouble(3)),y(path.optDouble(2)),paint);
      }
      paint.setStyle(Paint.Style.FILL);paint.setColor(GREEN);
      float baseRadius=markerSize==0?1.1f:markerSize==1?1.6f:2.5f;
      float radius=clamp(dp(baseRadius)*(float)Math.sqrt(zoom),dp(baseRadius),dp(markerSize==2?7f:4f));
      for(int i=0;i<points.length();i++){
        JSONArray row=points.optJSONArray(i);if(row==null||!passesFilter(row))continue;
        double alt=row.isNull(4)?Double.NaN:row.optDouble(4,Double.NaN);
        paint.setColor(Double.isNaN(alt)||alt<3000?GREEN:(alt<9000?CYAN:AMBER));
        float px=x(row.optDouble(1)),py=y(row.optDouble(0));
        if(px>=-radius&&px<=getWidth()+radius&&py>=-radius&&py<=getHeight()+radius){
          canvas.drawCircle(px,py,radius,paint);
          if(callsignLabels&&zoom>=2f){
            String label=row.optString(3,"").trim();if(label.isEmpty())label=row.optString(2,"");
            if(!label.isEmpty()){
              paint.setTextSize(dp(10));paint.setColor(INK);
              canvas.drawText(label.length()>9?label.substring(0,9):label,px+dp(5),py-dp(5),paint);
            }
          }
        }
      }
      paint.setTextSize(dp(12));paint.setColor(MUTED);
      canvas.drawText(String.format(Locale.US,"OPENSKY / %d VISIBLE / ZOOM %.1fx",visibleCount(),zoom),dp(8),dp(16),paint);
      if(points.length()==0)canvas.drawText("NO RECEIVED AIRCRAFT POSITIONS",dp(9),getHeight()/2f,paint);
      else{
        paint.setTextSize(dp(10));paint.setColor(CYAN);
        canvas.drawText(verifiedPairs.length()+" TWO-FIX DISPLACEMENTS / NOT RECORDED ROUTES",dp(8),getHeight()-dp(8),paint);
      }
      canvas.restore();
    }
    @Override public boolean onTouchEvent(MotionEvent event){
      scale.onTouchEvent(event);
      int action=event.getActionMasked();
      if(action==MotionEvent.ACTION_DOWN){if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(true);lastX=downX=event.getX();lastY=downY=event.getY();dragged=false;return true;}
      if(action==MotionEvent.ACTION_POINTER_DOWN){if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(true);dragged=true;return true;}
      if(action==MotionEvent.ACTION_MOVE){
        if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(true);
        if(event.getPointerCount()==1&&!scale.isInProgress()){
          float currentX=event.getX(),currentY=event.getY();
          if(Math.abs(currentX-downX)>dp(6)||Math.abs(currentY-downY)>dp(6))dragged=true;
          if(dragged){shiftX+=currentX-lastX;shiftY+=currentY-lastY;clampPan();invalidate();}
          lastX=currentX;lastY=currentY;
        }return true;
      }
      if(action==MotionEvent.ACTION_POINTER_UP){
        dragged=true;
        int remaining=event.getActionIndex()==0?1:0;
        if(remaining<event.getPointerCount()){
          lastX=downX=event.getX(remaining);
          lastY=downY=event.getY(remaining);
        }
        return true;
      }
      if(action==MotionEvent.ACTION_UP){
        if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(false);
        if(!dragged&&!scale.isInProgress()){
          performClick();double best=Double.POSITIVE_INFINITY;JSONArray closest=null;
          for(int i=0;i<points.length();i++){
            JSONArray row=points.optJSONArray(i);if(row==null||!passesFilter(row))continue;
            double dx=x(row.optDouble(1))-event.getX(),dy=y(row.optDouble(0))-event.getY();
            double dist=dx*dx+dy*dy;
            if(dist<best){best=dist;closest=row;}
          }
          if(best<dp(22)*dp(22))selected(closest);
          else detail.setText("No received aircraft at this location. Pinch to zoom and tap a reported marker.");
        }return true;
      }
      if(action==MotionEvent.ACTION_CANCEL){if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(false);return true;}
      return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
  }
}
