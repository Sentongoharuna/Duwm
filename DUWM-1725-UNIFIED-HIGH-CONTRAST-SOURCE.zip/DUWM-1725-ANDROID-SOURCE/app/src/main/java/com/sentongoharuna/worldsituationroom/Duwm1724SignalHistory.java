package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Local observation history: only changes actually seen on this device are recorded. */
public final class Duwm1724SignalHistory {
    private Duwm1724SignalHistory(){}
    private static final String PREF="duwm1724_source_transitions";
    public static void observe(Context c,int index,Duwm1724SignalFlow.Stage state,String sourceState){
        if(c==null||index<0||index>=19||state==null)return;
        SharedPreferences prefs=c.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);
        String key="desk"+index,old=prefs.getString(key+"_stage","");
        if(state.name().equals(old))return;
        SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'",Locale.US);
        fmt.setTimeZone(TimeZone.getTimeZone("UTC"));
        String event=fmt.format(new Date())+"  "+state.label+"  /  "+safe(sourceState);
        String history=prefs.getString(key+"_history","");
        String[] rows=(event+"\n"+history).split("\n");
        StringBuilder limited=new StringBuilder();
        for(int i=0;i<Math.min(12,rows.length);i++)limited.append(rows[i]).append('\n');
        prefs.edit().putString(key+"_stage",state.name()).putString(key+"_history",limited.toString()).apply();
    }
    public static String read(Context c,int index){
        return c.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE)
                .getString("desk"+index+"_history","NO RECORDED STATUS CHANGES");
    }
    private static String safe(String text){
        if(text==null)return "UNKNOWN";
        String out=text.replace('\n',' ').replace('\r',' ').trim();
        return out.length()>80?out.substring(0,80):out;
    }
}
