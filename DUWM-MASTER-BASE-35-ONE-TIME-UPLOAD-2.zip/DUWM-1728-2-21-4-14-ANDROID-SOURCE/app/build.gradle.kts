plugins {
    id("com.android.application")
}

android {
    namespace = "com.sentongoharuna.worldsituationroom"
    compileSdk = 36
    buildToolsVersion = "36.0.0"

    defaultConfig {
        applicationId = "com.sentongoharuna.worldsituationroom.rb2live25"
        minSdk = 26
        targetSdk = 35
        versionCode = 172848
        versionName = "1728.2.21.4.35"
        testInstrumentationRunner = "com.sentongoharuna.worldsituationroom.DuwmSignalInstrumentation"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = true
        checkReleaseBuilds = true
    }
}

dependencies {
    // Real on-device image descriptions through Android AICore. The SDK must be
    // resolved and packaged; there is no reflection-only or synthetic substitute.
    implementation("com.google.mlkit:genai-image-description:1.0.0-beta1")
}
