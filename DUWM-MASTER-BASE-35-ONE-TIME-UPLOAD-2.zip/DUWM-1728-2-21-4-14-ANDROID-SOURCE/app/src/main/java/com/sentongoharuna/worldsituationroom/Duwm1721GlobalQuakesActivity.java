package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/**
 * 1721 Worldwide earthquake viewer. Uses the official USGS GeoJSON summary feed,
 * never a simulated event. A failed refresh retains an explicitly stale local
 * cache. These observations are not an emergency warning or shaking forecast.
 */
public final class Duwm1721GlobalQuakesActivity extends Activity {
    private static final String URL_FEED="https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_week.geojson";
    private static final String STORE="duwm1721_verified_global_quakes", KEY="usgs_json", FETCHED="fetched_elapsed", FETCHED_WALL="fetched_wall";
    private static final int NAVY=DuwmUnifiedTheme.APPROVED_NAVY, SILVER=DuwmUnifiedTheme.BORDER;
    private static final int WHITE=DuwmUnifiedTheme.TEXT, MUTED=DuwmUnifiedTheme.MUTED;
    private final List<Quake> readings=new ArrayList<>();
    private LinearLayout list;private TextView state,summary;private EditText filter;private double minMagnitude=4.5;
    private volatile boolean destroyed;private boolean fetching;private long feedGenerated;
    private boolean strongestFirst; private TextView sortButton;
    private int dp(float v){return Math.round(getResources().getDisplayMetrics().density*v);}
    private GradientDrawable frame(int border){GradientDrawable x=new GradientDrawable();x.setColor(NAVY);x.setCornerRadius(dp(16));x.setStroke(dp(1),border);return x;}
    private TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));return t;}
    private TextView button(String value,Runnable job){TextView t=label(value,12,WHITE);t.setGravity(Gravity.CENTER);t.setPadding(dp(8),dp(9),dp(8),dp(9));t.setMinHeight(dp(48));t.setBackground(frame(SILVER));t.setOnClickListener(v->job.run());return t;}
    private LinearLayout.LayoutParams gap(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(9);return p;}
    private static final class Quake {
        final String id,place,review,url;final double magnitude,lat,lon,depth;final long occurred,updated;final boolean tsunami;
        Quake(String i,String p,String r,String u,double m,double la,double lo,double d,long t,long update,boolean ts){id=i;place=p;review=r;url=u;magnitude=m;lat=la;lon=lo;depth=d;occurred=t;updated=update;tsunami=ts;}
    }
    @Override public void onCreate(Bundle stateBundle){super.onCreate(stateBundle);
        DuwmPageMotion32.apply(this); DuwmPageMotion33.configure(this, "EARTHQUAKES · seismic reports"); // Build 32: consistent full-page navy chrome and transition

        getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(NAVY);
        LinearLayout root=new LinearLayout(this);root.setBackgroundColor(NAVY);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(13),dp(11),dp(13),dp(12));
        root.addView(label("DUWM 1723  /  GLOBAL EARTHQUAKES",19,WHITE),gap());
        root.addView(label("Worldwide M4.5+ events • past 7 days • source: USGS Earthquake Hazards Program. Observations only, NOT a safety alert or forecast.",12,MUTED),gap());
        state=label("LOADING SAVED SOURCE RECEIPT",12,DuwmUnifiedTheme.WARNING);root.addView(state,gap());
        summary=label("Awaiting authentic source data",12,MUTED);root.addView(summary,gap());
        root.addView(button("REFRESH OFFICIAL USGS FEED",this::refresh),gap());
        filter=new EditText(this);filter.setSingleLine(true);filter.setTextColor(WHITE);filter.setHintTextColor(MUTED);filter.setTextSize(15);
        filter.setHint("Filter country, region or place");filter.setPadding(dp(12),0,dp(12),0);filter.setBackground(frame(SILVER));root.addView(filter,new LinearLayout.LayoutParams(-1,dp(50)));
        LinearLayout magnitudes=new LinearLayout(this);for(double m:new double[]{4.5,5.0,6.0}){
            TextView v=button(String.format(Locale.US,"M %.1f+",m),()->{minMagnitude=m;render();});
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(48),1);p.rightMargin=dp(5);magnitudes.addView(v,p);
        }root.addView(magnitudes,gap());
        sortButton=button("SORT: NEWEST FIRST  ▸",()->{
            strongestFirst=!strongestFirst;
            sortButton.setText(strongestFirst?"SORT: STRONGEST FIRST  ▸":"SORT: NEWEST FIRST  ▸");
            render();
        });root.addView(sortButton,gap());
        ScrollView scroll=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);scroll.addView(list);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(button("BACK TO ORIGINAL WORLD GLOBE",()->{Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);finish();}),gap());
        setContentView(root);
        filter.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){render();}public void afterTextChanged(Editable e){}});
        showCached();refresh();
    }
    private static boolean validCoords(double lat,double lon){return Double.isFinite(lat)&&Double.isFinite(lon)&&Math.abs(lat)<=90&&Math.abs(lon)<=180;}
    private static String dateUtc(long milliseconds){if(milliseconds<=0)return "TIME UNAVAILABLE";SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm 'UTC'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(milliseconds));}
    private void parse(String json) throws org.json.JSONException {JSONObject data=new JSONObject(json);if(!"FeatureCollection".equals(data.optString("type")))throw new IllegalArgumentException("Unexpected USGS response");
        JSONArray features=data.getJSONArray("features");List<Quake> found=new ArrayList<>();
        for(int i=0;i<features.length()&&i<250;i++){JSONObject feature=features.optJSONObject(i);if(feature==null)continue;
            JSONObject p=feature.optJSONObject("properties"),geo=feature.optJSONObject("geometry");if(p==null||geo==null||p.isNull("mag"))continue;
            JSONArray coords=geo.optJSONArray("coordinates");if(coords==null||coords.length()<3)continue;
            double lon=coords.optDouble(0,Double.NaN),lat=coords.optDouble(1,Double.NaN),depth=coords.optDouble(2,Double.NaN),mag=p.optDouble("mag",Double.NaN);
            if(!validCoords(lat,lon)||!Double.isFinite(mag))continue;
            String place=p.optString("place","LOCATION NOT PROVIDED"),url=p.optString("url","");if(!url.startsWith("https://earthquake.usgs.gov/"))url="";
            found.add(new Quake(feature.optString("id",""),place,p.optString("status","not stated"),url,mag,lat,lon,depth,p.optLong("time",0),p.optLong("updated",0),p.optInt("tsunami",0)==1));
        }
        long generated=data.optJSONObject("metadata")==null?0L:data.getJSONObject("metadata").optLong("generated",0L);
        found.sort((a,b)->Long.compare(b.occurred,a.occurred));
        readings.clear();readings.addAll(found);feedGenerated=generated;
    }
    private void showCached(){String cache=getSharedPreferences(STORE,MODE_PRIVATE).getString(KEY,"");if(!cache.isEmpty()){
        try{parse(cache);long when=getSharedPreferences(STORE,MODE_PRIVATE).getLong(FETCHED_WALL,0);state.setText("● CACHED SOURCE / LAST DOWNLOADED "+dateUtc(when)+" / MAY BE STALE");state.setTextColor(DuwmUnifiedTheme.WARNING);render();}
        catch(Exception e){state.setText("NO VALID CACHE AVAILABLE");readings.clear();render();}
    }else{state.setText("NO LOCAL SOURCE DATA YET");render();}}
    private void refresh(){if(fetching)return;fetching=true;state.setText("● FETCHING OFFICIAL USGS FEED…");
        new Thread(()->{String result=null,error="USGS service unavailable";HttpURLConnection c=null;
            try{c=(HttpURLConnection)new URL(URL_FEED).openConnection();c.setConnectTimeout(9000);c.setReadTimeout(12000);c.setRequestProperty("Accept","application/geo+json, application/json");
                if(c.getResponseCode()!=200)throw new IllegalStateException("HTTP "+c.getResponseCode());
                try(InputStream stream=c.getInputStream();ByteArrayOutputStream output=new ByteArrayOutputStream()){
                    byte[] bytes=new byte[8192];int n;while((n=stream.read(bytes))!=-1){if(output.size()+n>500000)throw new IllegalStateException("Feed exceeds safe device limit");output.write(bytes,0,n);}result=output.toString("UTF-8");}
                JSONObject validation=new JSONObject(result);if(!"FeatureCollection".equals(validation.optString("type"))||validation.optJSONArray("features")==null)throw new IllegalStateException("Invalid USGS feed");
            }catch(Exception e){error=e.getMessage()==null?"Feed connection unavailable":e.getMessage();}finally{if(c!=null)c.disconnect();}
            String finalResult=result,finalError=error;
            runOnUiThread(()->{fetching=false;if(destroyed)return;
                if(finalResult==null){state.setText("● OFFLINE / "+finalError+" / CACHED DATA MAY BE STALE");state.setTextColor(DuwmUnifiedTheme.DANGER);render();return;}
                try{parse(finalResult);getSharedPreferences(STORE,MODE_PRIVATE).edit().putString(KEY,finalResult).putLong(FETCHED_WALL,System.currentTimeMillis()).apply();
                    state.setText("● USGS SOURCE RECEIVED  "+dateUtc(System.currentTimeMillis()));state.setTextColor(DuwmUnifiedTheme.LIVE);render();}
                catch(Exception ex){state.setText("● INVALID SOURCE DATA / CACHED FEED RETAINED");showCached();}
            });
        },"duwm1721-real-usgs-weekly-feed").start();
    }
    private void render(){if(list==null)return;list.removeAllViews();String q=filter==null?"":filter.getText().toString().trim().toLowerCase(Locale.ROOT);int shown=0;
        List<Quake> ordered=new ArrayList<>(readings);
        if(strongestFirst)ordered.sort((a,b)->{
            int m=Double.compare(b.magnitude,a.magnitude);
            return m!=0?m:Long.compare(b.occurred,a.occurred);
        });
        for(Quake quake:ordered){if(quake.magnitude<minMagnitude||(!q.isEmpty()&&!quake.place.toLowerCase(Locale.ROOT).contains(q)))continue;
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setBackground(frame(DuwmUnifiedTheme.DIVIDER));card.setPadding(dp(12),dp(11),dp(12),dp(11));
            String m=String.format(Locale.US,"M %.1f",quake.magnitude);
            card.addView(label("●  "+m+"   /   "+quake.place,15,quake.magnitude>=6?DuwmUnifiedTheme.DANGER:DuwmUnifiedTheme.TEXT));
            card.addView(label("OCCURRED  "+dateUtc(quake.occurred)+"  •  UPDATED  "+dateUtc(quake.updated),11,MUTED),gap());
            card.addView(label("USGS STATUS  "+quake.review.toUpperCase(Locale.ROOT)+"  /  "+(quake.tsunami?"USGS TSUNAMI FLAG SET":"NO USGS TSUNAMI FLAG"),11,quake.tsunami?DuwmUnifiedTheme.WARNING:MUTED),gap());
            card.addView(label(String.format(Locale.US,"COORDS  %.3f, %.3f  /  DEPTH  %.1f km",quake.lat,quake.lon,quake.depth),11,MUTED),gap());
            LinearLayout actions=new LinearLayout(this);
            TextView map=button("OPEN ON MAP",()->{Intent i=new Intent(this,DuwmPlaceMapActivity.class);i.putExtra("focus_lat",String.format(Locale.US,"%.6f",quake.lat));i.putExtra("focus_lon",String.format(Locale.US,"%.6f",quake.lon));startActivity(i);});
            LinearLayout.LayoutParams left=new LinearLayout.LayoutParams(0,dp(48),1);left.rightMargin=dp(5);actions.addView(map,left);
            TextView source=button("USGS EVENT",()->{if(!quake.url.isEmpty())startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(quake.url)));});actions.addView(source,new LinearLayout.LayoutParams(0,dp(48),1));card.addView(actions,gap());
            TextView share=button("SHARE SOURCE-LABELLED EVENT",()->shareQuake(quake));
            card.addView(share,gap());
            list.addView(card,gap());shown++;
        }
        if(shown==0)list.addView(label(readings.isEmpty()?"No authentic events loaded. Connect to the internet and refresh.":"No events match this filter in the retrieved feed.",12,MUTED),gap());
        if(summary!=null)summary.setText("DISPLAYING "+shown+" OF "+readings.size()+" USGS EVENTS  /  FEED GENERATED "+dateUtc(feedGenerated)+"  /  M "+minMagnitude+"+");
    }
    private void shareQuake(Quake quake){
        // Sharing an official report must not imply that USGS verified eyewitness reports.
        String message=String.format(Locale.US,
                "USGS M %.1f • %s\nOccurred: %s\nUSGS updated: %s\nDepth: %.1f km\nLocation: %.4f, %.4f\nSource: %s\nDUWM source observation; not an emergency warning.",
                quake.magnitude,quake.place,dateUtc(quake.occurred),dateUtc(quake.updated),
                quake.depth,quake.lat,quake.lon,quake.url.isEmpty()?"USGS event URL unavailable":quake.url);
        Intent share=new Intent(Intent.ACTION_SEND);share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT,message);
        startActivity(Intent.createChooser(share,"Share official USGS earthquake receipt"));
    }
    @Override protected void onDestroy(){destroyed=true;super.onDestroy();}
}
