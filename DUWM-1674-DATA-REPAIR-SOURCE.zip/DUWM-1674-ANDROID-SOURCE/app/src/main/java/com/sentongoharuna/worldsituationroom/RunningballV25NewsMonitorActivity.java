package com.sentongoharuna.worldsituationroom;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.HashSet;
import java.util.Set;
/** Independently implemented native news and conflict headlines monitor. No military location tracker. */
public final class RunningballV25NewsMonitorActivity extends Activity {
  private static final int CYAN=0xFF55D6EF,GREEN=0xFF5CFFC6,AMBER=0xFFFFBE66,INK=0xFFEAF5FE,DIM=0xFFB6C4CD,RED=0xFFFF5C6E;
  private final Handler main=new Handler(Looper.getMainLooper());
  private LinearLayout rows;private TextView status;private boolean visible=false;private int tab=0;
  private String region="ALL MIDDLE EAST";private final Runnable ticker=new Runnable(){public void run(){if(!visible)return;render();RunningballV25NewsRepository.refresh(RunningballV25NewsMonitorActivity.this,false,RunningballV25NewsMonitorActivity.this::render);main.postDelayed(this,30000L);}};
  private static final String[] NAMES={"New Vision","Daily Monitor","Nile Post","The Independent","The Observer","Uganda Radio Network","ChimpReports","SoftPower News","Watchdog Uganda","NTV Uganda","NBS Television","Bukedde","Kawowo Sports","Red Pepper"};
  private static final String[] URLS={"https://www.newvision.co.ug/","https://www.monitor.co.ug/","https://nilepost.co.ug/","https://www.independent.co.ug/","https://observer.ug/","https://ugandaradionetwork.net/","https://chimpreports.com/","https://softpower.ug/","https://www.watchdoguganda.com/","https://www.ntv.co.ug/","https://nbs.ug/","https://www.bukedde.co.ug/","https://kawowo.com/","https://redpepper.co.ug/"};
  private static final String[] TOPICS={"ALL MIDDLE EAST","GAZA / ISRAEL","LEBANON","SYRIA","IRAN","IRAQ","YEMEN / RED SEA"};
  private int dp(int px){return Math.round(getResources().getDisplayMetrics().density*px);}
  private GradientDrawable bg(int border){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFF142E40,0xFF07111B});d.setCornerRadius(dp(12));d.setStroke(dp(1),border);return d;}
  private TextView text(String str,int size,int colour,boolean heavy){TextView t=new TextView(this);t.setText(str);t.setTextSize(size);t.setTextColor(colour);if(heavy)t.setTypeface(null,1);return t;}
  private void open(String url){if(!RunningballV25NewsRepository.validArticle(url))return;try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){status.setText("CANNOT OPEN BROWSER · "+e.getClass().getSimpleName());}}
  private TextView action(String s,Runnable fn){TextView t=text(s,12,CYAN,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(10),dp(12),dp(10),dp(12));t.setMinimumHeight(dp(48));t.setBackground(bg(0xFF37647A));t.setContentDescription(s);t.setOnClickListener(v->fn.run());return t;}
  private void item(String heading,String body,String foot,String url){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(11),dp(12),dp(10),dp(12));card.setBackground(bg(0xFF355668));
    card.addView(text(heading,11,CYAN,true));TextView text=text(body,14,INK,true);text.setMaxLines(4);card.addView(text);
    card.addView(text(foot,11,DIM,false));if(url!=null&&RunningballV25NewsRepository.validArticle(url)){
      card.setOnClickListener(v->open(url));card.setContentDescription(heading+" "+body+" Open original source article");card.setMinimumHeight(dp(54));
    }LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(8);rows.addView(card,lp);
  }
  private void showSource(String key,String label,int limit){long at=RunningballV25NewsRepository.last(this,key);String err=RunningballV25NewsRepository.error(this,key);
    JSONArray array=RunningballV25NewsRepository.articles(this,key);String age=RunningballV25NewsRepository.age(at);
    item(label+" / "+(at>0?"CACHED HEADLINES":"NOT LOADED"),array.length()+" returned article links · Last successful fetch: "+age,
      "Links represent the publisher's report, not independently verified incident records."+(err.isEmpty()?"":"\nLATEST ERROR: "+err),null);
    if(array.length()==0){item(label,"NO ARTICLES AVAILABLE","No invented headlines or casualty totals. Refresh or open publisher's website.",null);return;}
    Set<String> seen=new HashSet<>();int shown=0;for(int i=0;i<array.length()&&shown<limit;i++){
      JSONObject x=array.optJSONObject(i);if(x==null)continue;String title=x.optString("title","").trim(),url=x.optString("url","");
      if(title.isEmpty()||!RunningballV25NewsRepository.validArticle(url)||!seen.add(url))continue;
      if(tab==1&&!region.equals("ALL MIDDLE EAST")){
        String lower=title.toLowerCase(java.util.Locale.US);
        boolean accepts=region.equals("GAZA / ISRAEL")?(lower.contains("gaza")||lower.contains("israel")||lower.contains("palestin")||lower.contains("west bank")):
          region.equals("YEMEN / RED SEA")?(lower.contains("yemen")||lower.contains("houthi")||lower.contains("red sea")):
          lower.contains(region.toLowerCase(java.util.Locale.US));
        if(!accepts)continue;
      }
      item(x.optString("publisher",label)+" · "+x.optString("type","PUBLISHER ARTICLE"),title,
        "PUBLISHED/SEEN: "+x.optString("published","UNKNOWN")+" · FETCHED "+age+" AGO · ORIGINAL LINK",url);shown++;
    }
    if(shown==0)item("FILTERED DESK","NO MATCHING HEADLINES IN CURRENT CACHED WINDOW","This is not evidence there is no conflict; broaden the region filter.",null);
  }
  private void showDirectory(){item("UGANDA NEWS SOURCE DIRECTORY","14 named publishers and broadcasters","Automated feeds enabled for only four RSS sources; other websites are link-only pending reuse/access checks.",null);
    for(int i=0;i<NAMES.length;i++){String n=NAMES[i];String u=URLS[i];boolean auto=n.equals("The Independent")||n.equals("The Observer")||n.equals("SoftPower News")||n.equals("Watchdog Uganda");
      item(n+(auto?" · RSS COLLECTOR":" · WEBSITE ONLY"),auto?"Read latest reported headlines above":"Open publisher website for current reporting",
      auto?"Provider feed may fail or require permission; only links are stored.":"No automated scraping, article-copying or feed availability claim.",u);
    }
    item("LICENSE-GATED CONFLICT DATASETS","ACLED / UCDP / ReliefWeb","ACLED data license: NOT CONFIGURED. UCDP API token: NOT CONFIGURED. ReliefWeb approved appname: NOT CONFIGURED. This screen does not fabricate incident records.",null);
    item("METHODOLOGY","NOT A LIVE TROOP OR STRIKE TRACKER","GDELT is a monitor of reporting, not a validated conflict-event database. Article mentions, casualties, and military positions are never treated as confirmed geolocated facts.",null);
  }
  private void render(){if(rows==null)return;rows.removeAllViews();status.setText("Last received source updates · refresh within provider rate limits · no fabricated news");
    if(tab==0){showSource("ug_independent","THE INDEPENDENT",6);showSource("ug_observer","THE OBSERVER",5);showSource("ug_softpower","SOFTPOWER NEWS",5);showSource("ug_watchdog","WATCHDOG UGANDA",5);}
    else if(tab==1){showSource("conflict_middle_east","MIDDLE EAST CONFLICT COVERAGE / GDELT DOC 2.0",35);
      item("CONFLICT VERIFICATION","Headline mentions are NOT independent confirmation of a strike, location, casualty count or responsibility.","No real-time military asset positions. Open original report to examine sources and context.",null);}
    else if(tab==2){showSource("conflict_world","WORLD CONFLICT HEADLINES / GDELT DOC 2.0",35);}
    else showDirectory();
  }
  @Override public void onCreate(Bundle saved){super.onCreate(saved);getWindow().setStatusBarColor(0xFF07111B);getWindow().setNavigationBarColor(0xFF07111B);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(13),dp(16),dp(13),dp(30));root.setBackgroundColor(0xFF07111B);scroll.addView(root);
    root.addView(text("RUNNINGBALL2 V25 / VERIFIED NEWS LINKS",12,GREEN,true));root.addView(text("UGANDA + WORLD CONFLICTS",24,INK,true));
    root.addView(text("HEADLINES ARE REPORTS · NOT VERIFIED BATTLEFIELD EVENTS",11,AMBER,true));
    LinearLayout tabs=new LinearLayout(this);tabs.setOrientation(LinearLayout.VERTICAL);
    String[] labels={"UGANDA NEWS","MIDDLE EAST","WORLD CONFLICTS","ALL SOURCES"};
    for(int i=0;i<labels.length;i+=2){LinearLayout row=new LinearLayout(this);for(int j=i;j<Math.min(labels.length,i+2);j++){
        final int n=j;LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(3),dp(4),dp(3),dp(4));row.addView(action(labels[j],()->{tab=n;render();}),lp);
      }tabs.addView(row);}root.addView(tabs);
    LinearLayout topics=new LinearLayout(this);topics.setOrientation(LinearLayout.VERTICAL);
    for(int i=0;i<TOPICS.length;i+=3){LinearLayout row=new LinearLayout(this);for(int j=i;j<Math.min(TOPICS.length,i+3);j++){
      String choice=TOPICS[j];LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(2),dp(2),dp(2),dp(2));
      TextView chip=action(choice,()->{tab=1;region=choice;render();});chip.setTextSize(9);row.addView(chip,lp);
    }topics.addView(row);}root.addView(topics);
    LinearLayout refresh=new LinearLayout(this);refresh.setOrientation(LinearLayout.HORIZONTAL);
    refresh.addView(action("REFRESH REPORTING",()->RunningballV25NewsRepository.refresh(this,true,this::render)),new LinearLayout.LayoutParams(0,-2,1));
    refresh.addView(action("SOURCE DIRECTORY",()->{tab=3;render();}),new LinearLayout.LayoutParams(0,-2,1));root.addView(refresh);
    status=text("LOADING CACHED HEADLINES",11,DIM,false);status.setPadding(0,dp(8),0,dp(9));root.addView(status);
    rows=new LinearLayout(this);rows.setOrientation(LinearLayout.VERTICAL);root.addView(rows);setContentView(scroll);render();
    // Fetch is on bounded background executor, never on UI, Canvas or wallpaper render loop.
    RunningballV25NewsRepository.refresh(this,false,this::render);
  }
  @Override protected void onResume(){super.onResume();visible=true;main.removeCallbacks(ticker);main.post(ticker);}
  @Override protected void onPause(){visible=false;main.removeCallbacks(ticker);super.onPause();}
}
