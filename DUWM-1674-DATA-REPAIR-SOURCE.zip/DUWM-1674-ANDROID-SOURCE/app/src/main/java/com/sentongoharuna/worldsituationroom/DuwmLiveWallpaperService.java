package com.sentongoharuna.worldsituationroom;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

public final class DuwmLiveWallpaperService extends WallpaperService {
  @Override public Engine onCreateEngine(){ return new GlobeEngine(); }
  private final class GlobeEngine extends Engine {
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final Paint earth=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint accent=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final DuwmAircraftIntelligence air=
                  new DuwmAircraftIntelligence(DuwmLiveWallpaperService.this);
    private boolean visible=false, pending=false;
    private long lastMs=0L;
    private double rotation=0.0d;
    private static final long FRAME_MS=33L;

    private final Runnable tick=new Runnable(){
      @Override public void run(){
        pending=false;
        if(!visible)return;
        long now=SystemClock.uptimeMillis();
        long dt=lastMs==0L?FRAME_MS:Math.min(100L,Math.max(0L,now-lastMs));
        lastMs=now;
        rotation=(rotation+(dt/1000.0d)*4.0d)%360.0d;
        drawGlobe();
        schedule();
      }
    };

    GlobeEngine(){
      earth.setColor(Color.rgb(5,18,31)); earth.setStyle(Paint.Style.FILL);
      grid.setColor(Color.argb(95,58,185,220)); grid.setStyle(Paint.Style.STROKE); grid.setStrokeWidth(1.2f);
      accent.setColor(Color.rgb(58,220,132)); accent.setStyle(Paint.Style.STROKE); accent.setStrokeWidth(2f);
    }
    private void schedule(){ if(!visible||pending)return; pending=true; ui.postDelayed(tick,FRAME_MS); }
    private void stop(){ visible=false; pending=false; ui.removeCallbacks(tick); }
    @Override public void onVisibilityChanged(boolean v){ visible=v; air.setVisible(v); if(v){lastMs=0L;schedule();}else stop(); }
    @Override public void onSurfaceChanged(SurfaceHolder h,int f,int w,int x){super.onSurfaceChanged(h,f,w,x);if(visible)drawGlobe();}
    @Override public void onSurfaceDestroyed(SurfaceHolder h){stop();super.onSurfaceDestroyed(h);}
    @Override public void onDestroy(){stop();air.close();super.onDestroy();}

    private void drawGlobe(){
      SurfaceHolder h=getSurfaceHolder(); Canvas c=null;
      try{
        c=h.lockCanvas(); if(c==null)return; c.drawColor(Color.BLACK);
        float w=c.getWidth(), ht=c.getHeight(), cx=w*.5f, cy=ht*.48f, r=Math.min(w,ht)*.34f;
        c.drawCircle(cx,cy,r,earth);
        for(int lat=-60;lat<=60;lat+=30){
          float y=cy-(float)Math.sin(Math.toRadians(lat))*r;
          float rx=(float)(Math.cos(Math.toRadians(lat))*r);
          c.drawOval(cx-rx,y-r*.08f,cx+rx,y+r*.08f,grid);
        }
        for(int lon=0;lon<180;lon+=30){
          double a=Math.toRadians(lon+rotation); float rx=(float)(Math.abs(Math.cos(a))*r);
          c.drawOval(cx-rx,cy-r,cx+rx,cy+r,grid);
        }
        double a=Math.toRadians(rotation);
        c.drawCircle(cx+(float)Math.cos(a)*r,cy+(float)Math.sin(a)*r*.25f,7f,accent);
        air.draw(c);
      } finally { if(c!=null)h.unlockCanvasAndPost(c); }
    }
  }
}
