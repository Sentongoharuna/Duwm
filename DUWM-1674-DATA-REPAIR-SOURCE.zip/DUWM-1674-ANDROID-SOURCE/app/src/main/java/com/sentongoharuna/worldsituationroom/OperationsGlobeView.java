package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/** A navigation-capable globe: coastlines are Natural Earth, markers are observations only. */
public final class OperationsGlobeView extends View {
    public static final int AIR=1, QUAKE=2, SPACE=3, SEA=4;
    public static final class Observation {
        public final int type;
        public final double lat,lon;
        public final String title,detail,source;
        public final long timeMillis;
        public Observation(int type,double lat,double lon,String title,String detail,String source,long timeMillis){
            this.type=type;this.lat=lat;this.lon=lon;this.title=title;this.detail=detail;this.source=source;this.timeMillis=timeMillis;
        }
    }
    public interface OnObservationSelected {void onSelected(Observation item);}
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<List<double[]>> coastlines=new ArrayList<>();
    private final List<Observation> objects=new ArrayList<>();
    private OnObservationSelected listener;
    private boolean moving=false, aircraft=true,quakes=true,space=true,sea=true,dragging=false,auroraPalette=true,compassRingEnabled=true;
    private float speedScale=1f;
    private long previousFrame=0;
    // P3: ease rotation after touch and focus only on real reported positions.
    private long lastGestureEnd=0;
    private float rotationBlend=1f;
    private boolean focusPending=false;
    private double focusYaw=0,focusPitch=0;
    private Observation selectedObservation;

    private long frameCounter=0;
    private double totalDegrees=0;
    private double yaw=Math.toRadians(32), pitch=Math.toRadians(7);
    private float cx,cy,radius,zoom=1f,lastX,lastY,downX,downY;
    private int coastSegments=0;
    private boolean focusOn=false;
    private double focusedLat,focusedLon;
    private final ScaleGestureDetector scaler;
    private final int OCEAN_COLOR=Color.rgb(10,30,48), LAND=Color.rgb(145,216,210), GRID=Color.argb(62,103,165,188), EDGE=Color.rgb(83,150,173);

    public OperationsGlobeView(Context c){
        super(c);scaler=new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
            @Override public boolean onScale(ScaleGestureDetector d){zoom=Math.max(.78f,Math.min(1.95f,zoom*d.getScaleFactor()));invalidate();return true;}
        });loadCoasts();setContentDescription("Modern HD Earth with detailed real coastline geometry and source-observed markers. Drag to rotate, pinch to zoom, tap an actual marker for details.");
    }
    /** DUWM 1673 true visual upgrade: users can change both globe palettes live. */
    public void setGlobePalette(boolean aurora){auroraPalette=aurora;invalidate();}
    public boolean isAuroraPalette(){return auroraPalette;}
    /** Visual speed is geographic rotation, not a measurement or object update. */
    public void setRotationSpeed(float speed){speedScale=Math.max(.3f,Math.min(2.2f,speed));}
    public void setCompassRingEnabled(boolean visible){compassRingEnabled=visible;invalidate();}
    public int getObservationCount(){return objects.size();}
    public int getCoastSegmentCount(){return coastSegments;}
    public void focusAt(double lat,double lon){
        if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)return;
        focusOn=true;focusedLat=lat;focusedLon=lon;
        moving=false;yaw=Math.toRadians(lon);
        pitch=Math.max(-1.1,Math.min(1.1,Math.toRadians(lat)));
        invalidate();
    }
    public void setOnObservationSelected(OnObservationSelected l){listener=l;}
    public void setObservations(List<Observation> items){
        Observation previous=selectedObservation;
        objects.clear();
        if(items!=null)for(Observation v:items){
            if(v!=null && Double.isFinite(v.lat) && Double.isFinite(v.lon) &&
               Math.abs(v.lat)<=90d && Math.abs(v.lon)<=180d)objects.add(v);
        }
        selectedObservation=null;
        if(previous!=null)for(Observation v:objects){
            if(v.type==previous.type && v.source.equals(previous.source) && v.title.equals(previous.title)){
                selectedObservation=v;break;
            }
        }
        invalidate();
    }
    /** P3 CENTER SELECTED: only a real provider observation can control the viewpoint. */
    public boolean duwmP3FocusObservation(Observation observation){
        if(observation==null)return false;
        Observation current=null;
        for(Observation v:objects){
            if(v==observation || (v.type==observation.type && v.source.equals(observation.source) &&
               v.title.equals(observation.title) && (v.type!=QUAKE || v.timeMillis==observation.timeMillis))){
                current=v;break;
            }
        }
        // A stale selection that has disappeared from the last real feed is not invented on screen.
        if(current==null || !Double.isFinite(current.lat) || !Double.isFinite(current.lon) ||
           Math.abs(current.lat)>90d || Math.abs(current.lon)>180d)return false;
        selectedObservation=current;
        focusYaw=Math.toRadians(current.lon);
        focusPitch=Math.max(-1.32d,Math.min(1.32d,Math.toRadians(current.lat)));
        focusPending=true;
        rotationBlend=0f;
        lastGestureEnd=SystemClock.uptimeMillis();
        previousFrame=lastGestureEnd;
        postInvalidateOnAnimation();
        return true;
    }

    public void showLayer(int kind,boolean enabled){if(kind==AIR)aircraft=enabled;else if(kind==QUAKE)quakes=enabled;else if(kind==SPACE)space=enabled;else if(kind==SEA)sea=enabled;invalidate();}
    public void resume(){moving=true;previousFrame=SystemClock.uptimeMillis();postInvalidateOnAnimation();}
    public void pause(){moving=false;}
    @Override protected void onDetachedFromWindow(){pause();super.onDetachedFromWindow();}
    private int dp(float value){return (int)(value*getResources().getDisplayMetrics().density+.5f);}
    private void loadCoasts(){
        // V1159.4: actual GSHHS shorelines; no invented object positions.
        // These points are rendered on the SAME modern globe every animated frame.
        try(BufferedReader br=new BufferedReader(new InputStreamReader(getContext().getAssets().open("naturalearth_coasts.txt"),"UTF-8"))){
            String line;while((line=br.readLine())!=null){List<double[]> coast=new ArrayList<>();for(String pair:line.split(" ")){
                String[] v=pair.split(",");if(v.length!=2)continue;double lat=Double.parseDouble(v[0]),lon=Double.parseDouble(v[1]);
                if(Math.abs(lat)<=90&&Math.abs(lon)<=180)coast.add(new double[]{lat,lon});
            }if(coast.size()>=3){coastlines.add(coast);coastSegments++;}}
        }catch(Exception ignored){/* Missing coastline data is not replaced with invented geography. */}
    }
    private float[] project(double lat,double lon){
        double a=Math.toRadians(lat),b=Math.toRadians(lon)-yaw;
        double x=Math.cos(a)*Math.sin(b),y=Math.sin(a),z=Math.cos(a)*Math.cos(b);
        double cp=Math.cos(pitch),sp=Math.sin(pitch),tiltedY=y*cp-z*sp,depth=y*sp+z*cp;
        if(depth<=0.004d)return null;
        return new float[]{cx+(float)(radius*x),cy-(float)(radius*tiltedY)};
    }
    private boolean enabled(int kind){return kind==AIR?aircraft:kind==QUAKE?quakes:kind==SEA?sea:space;}
    private void strokePath(Canvas c,List<double[]> lines){Path path=new Path();boolean active=false;
        for(double[] spot:lines){float[] v=project(spot[0],spot[1]);if(v==null){active=false;continue;}
            if(!active){path.moveTo(v[0],v[1]);active=true;}else path.lineTo(v[0],v[1]);}c.drawPath(path,p);
    }
    private void grid(Canvas c,boolean meridian,int coordinate){Path path=new Path();boolean begun=false;
        for(int i=0;i<=180;i++){double lat=meridian?-90+i:coordinate,lon=meridian?coordinate:-180+2*i;
            float[] v=project(lat,lon);if(v==null){begun=false;continue;}
            if(!begun){path.moveTo(v[0],v[1]);begun=true;}else path.lineTo(v[0],v[1]);}c.drawPath(path,p);
    }
    private int tint(int kind){return kind==AIR?Color.rgb(99,184,207):kind==QUAKE?Color.rgb(238,166,105):kind==SEA?Color.rgb(91,180,255):Color.rgb(157,202,165);}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        long now=SystemClock.uptimeMillis();
        long dt=Math.min(60,Math.max(0,now-previousFrame));previousFrame=now;
        boolean rotatedThisFrame=false;
        if(!dragging && focusPending){
            double dyaw=Math.atan2(Math.sin(focusYaw-yaw),Math.cos(focusYaw-yaw));
            double dpitch=focusPitch-pitch;
            double easing=1d-Math.exp(-Math.max(1,dt)/180d);
            yaw+=dyaw*easing;pitch+=dpitch*easing;
            rotatedThisFrame=true;
            if(Math.abs(dyaw)<.002d && Math.abs(dpitch)<.002d){yaw=focusYaw;pitch=focusPitch;focusPending=false;}
        }else if(moving && !dragging && now-lastGestureEnd>950L){
            rotationBlend=Math.min(1f,rotationBlend+dt/1000f);
            double advance=dt*.000147d*rotationBlend*speedScale;
            yaw=(yaw+advance)%(2*Math.PI);
            totalDegrees+=Math.abs(advance)*180d/Math.PI;
            rotatedThisFrame=advance>0d;
        }
        if(rotatedThisFrame)frameCounter++;
        float w=getWidth(),h=getHeight();cx=w/2f;cy=h*.49f;radius=Math.max(dp(20),Math.min(w*.445f,h*.458f)*zoom);
        // DUWM 1673: distinct aurora/carbon command globe, not the frozen legacy presentation.
        int rim=auroraPalette?0xFF58E4CA:0xFF76A9EC;
        int haze=auroraPalette?0xFF36CDB3:0xFF4489D3;
        canvas.drawColor(auroraPalette?0xFF030B13:0xFF07101D);
        p.setShader(null);p.setStyle(Paint.Style.STROKE);
        p.setColor(auroraPalette?0x1741E4C4:0x164D91D3);p.setStrokeWidth(dp(25));canvas.drawCircle(cx,cy,radius+dp(8),p);
        p.setColor(auroraPalette?0x534EE6CC:0x536EA9E8);p.setStrokeWidth(dp(7));canvas.drawCircle(cx,cy,radius+dp(3),p);
        p.setColor(auroraPalette?0xC158E4CA:0xC176A9EC);p.setStrokeWidth(dp(1.4f));canvas.drawCircle(cx,cy,radius+dp(9),p);
        // Calibrated outer compass ticks track the REAL view orientation, not fake intelligence.
        for(int n=0;compassRingEnabled && n<96;n++){
            double theta=Math.PI*n/48d;
            float sx=cx+(float)Math.cos(theta)*(radius+dp(11));
            float sy=cy+(float)Math.sin(theta)*(radius+dp(11));
            float ex=cx+(float)Math.cos(theta)*(radius+dp(n%8==0?24:16));
            float ey=cy+(float)Math.sin(theta)*(radius+dp(n%8==0?24:16));
            p.setStrokeWidth(dp(n%8==0?1.5f:.65f));p.setColor(n%8==0?rim:0x668CBACB);
            canvas.drawLine(sx,sy,ex,ey,p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(auroraPalette?0xFF082A38:0xFF0B203E);canvas.drawCircle(cx,cy,radius,p);
        p.setShader(new LinearGradient(cx-radius,cy-radius,cx+radius,cy+radius,
                auroraPalette?0xFF154C58:0xFF204A68,
                auroraPalette?0xFF061827:0xFF090D21,Shader.TileMode.CLAMP));
        canvas.drawCircle(cx,cy,radius,p);p.setShader(null);
        canvas.save();Path clipping=new Path();clipping.addCircle(cx,cy,radius,Path.Direction.CW);canvas.clipPath(clipping);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(.76f));
        p.setColor(auroraPalette?0x424BA99A:0x423D86C6);
        for(int i=-150;i<=180;i+=30)grid(canvas,true,i);
        for(int i=-60;i<=60;i+=30)grid(canvas,false,i);
        // V1159.4: preserved two-pass geographic coastlines; real asset provides the positions.
        p.setColor(auroraPalette?0xA05AC3B4:0xA05A9AC4);p.setStrokeWidth(dp(4.6f));for(List<double[]> coastline:coastlines)strokePath(canvas,coastline);
        p.setColor(auroraPalette?0xFF9DF6E2:0xFFC6DEF9);p.setStrokeWidth(dp(1.45f));for(List<double[]> coastline:coastlines)strokePath(canvas,coastline);
        int max=1800,shown=0;for(Observation a:objects){if(!enabled(a.type)||shown++>max)continue;
            float[] v=project(a.lat,a.lon);if(v==null)continue;
            int color=tint(a.type);p.setStyle(Paint.Style.FILL);p.setColor(Color.argb(65,Color.red(color),Color.green(color),Color.blue(color)));
            float ring=dp(a.type==AIR?3.6f:a.type==SEA?5.0f:6.0f);canvas.drawCircle(v[0],v[1],ring,p);
            p.setColor(color);canvas.drawCircle(v[0],v[1],dp(a.type==AIR?1.6f:a.type==SEA?2.3f:2.4f),p);
            if(a==selectedObservation){
                p.setColor(Color.rgb(245,249,255));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.4f));
                canvas.drawCircle(v[0],v[1],dp(9),p);p.setStyle(Paint.Style.FILL);
            }
        }
        if(focusOn){
            float[] target=project(focusedLat,focusedLon);
            if(target!=null){
                p.setShader(null);p.setStyle(Paint.Style.STROKE);p.setColor(Color.rgb(245,231,174));
                p.setStrokeWidth(dp(1.6f));canvas.drawCircle(target[0],target[1],dp(12),p);
                canvas.drawLine(target[0]-dp(18),target[1],target[0]-dp(7),target[1],p);
                canvas.drawLine(target[0]+dp(7),target[1],target[0]+dp(18),target[1],p);
                canvas.drawLine(target[0],target[1]-dp(18),target[0],target[1]-dp(7),p);
                canvas.drawLine(target[0],target[1]+dp(7),target[0],target[1]+dp(18),p);
            }
        }
        canvas.restore();p.setShader(null);p.setColor(rim);p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(1.2f));canvas.drawCircle(cx,cy,radius,p);
        // 1674 double-axis compass framing visualizes view direction, NOT telemetry tracks.
        p.setColor(0x6649BCD8);p.setStrokeWidth(dp(.9f));
        canvas.drawOval(cx-radius-dp(12),cy-radius*.52f,cx+radius+dp(12),cy+radius*.52f,p);
        // Transparent orbital framing is graphical orientation only; no false trajectory lines.
        p.setColor(0x55358B99);p.setStrokeWidth(dp(.8f));
        canvas.drawOval(cx-radius-dp(21),cy-radius*.33f,cx+radius+dp(21),cy+radius*.33f,p);
        p.setStyle(Paint.Style.FILL);
        p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(132,153,165));p.setTextSize(dp(10));
        canvas.drawText("N",cx-dp(3),Math.max(dp(12),cy-radius-dp(8)),p);
        p.setTextSize(dp(9));p.setColor(0xFF87C9D6);
        canvas.drawText("OBSERVED MARKERS "+objects.size(),dp(13),dp(19),p);
        // Motion readout counts actual completed animation frames, not fabricated network events.
        p.setTextSize(dp(10));p.setColor(Color.rgb(156,190,202));
        canvas.drawText(moving?"EARTH ROTATION • ACTIVE":"EARTH ROTATION • PAUSED",dp(13),h-dp(18),p);
        p.setColor(Color.rgb(107,154,164));
        canvas.drawText("RENDER FRAMES "+frameCounter+"  •  ROTATION "+String.format(java.util.Locale.US,"%.1f°",totalDegrees),dp(13),h-dp(5),p);
        // Geographic projection is orthographic; only received source positions produce markers.
        if(moving || focusPending)postInvalidateOnAnimation(); // preserve original modern rotation cadence
    }
    @Override public boolean onTouchEvent(MotionEvent e){scaler.onTouchEvent(e);if(scaler.isInProgress()){
            lastGestureEnd=SystemClock.uptimeMillis();rotationBlend=0f;focusPending=false;
            previousFrame=lastGestureEnd;return true;
        }
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(true);
                downX=lastX=e.getX();downY=lastY=e.getY();dragging=true;
                focusPending=false;rotationBlend=0f;previousFrame=SystemClock.uptimeMillis();return true;
            case MotionEvent.ACTION_MOVE:
                float dx=e.getX()-lastX,dy=e.getY()-lastY;
                yaw-=dx/Math.max(1f,radius)*.68d;pitch=Math.max(-1.32d,Math.min(1.32d,pitch+dy/Math.max(1f,radius)*.35d));
                lastX=e.getX();lastY=e.getY();invalidate();return true;
            case MotionEvent.ACTION_CANCEL:
                if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(false);
                dragging=false;lastGestureEnd=SystemClock.uptimeMillis();previousFrame=lastGestureEnd;
                if(moving)postInvalidateOnAnimation();return true;
            case MotionEvent.ACTION_UP:
                if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(false);
                dragging=false;lastGestureEnd=SystemClock.uptimeMillis();previousFrame=lastGestureEnd;
                if(moving)postInvalidateOnAnimation();
                if(Math.abs(e.getX()-downX)<dp(10)&&Math.abs(e.getY()-downY)<dp(10)){
                    Observation nearest=null;float best=dp(19)*dp(19);
                    for(Observation item:objects){if(!enabled(item.type))continue;float[] point=project(item.lat,item.lon);if(point==null)continue;
                        float a=point[0]-e.getX(),b=point[1]-e.getY(),dist=a*a+b*b;if(dist<best){best=dist;nearest=item;}}
                    if(nearest!=null){selectedObservation=nearest;
                        if(listener!=null)listener.onSelected(nearest);
                    }else performClick();}
                invalidate();return true;
            default:return true;
        }
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
