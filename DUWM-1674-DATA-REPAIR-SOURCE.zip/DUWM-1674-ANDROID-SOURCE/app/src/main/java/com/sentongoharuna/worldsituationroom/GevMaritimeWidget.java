package com.sentongoharuna.worldsituationroom;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Premium vertical vessel widget: real saved AIS records only, never sample ships. */
public final class GevMaritimeWidget extends AppWidgetProvider {
    @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)paint(c,m,id);}
    public static void updateAll(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);
        int[] ids=m.getAppWidgetIds(new ComponentName(c,GevMaritimeWidget.class));for(int id:ids)paint(c,m,id);}
    private static void paint(Context c,AppWidgetManager manager,int id){
        RemoteViews r=new RemoteViews(c.getPackageName(),R.layout.rb11_marine_widget);
        String raw=c.getSharedPreferences("rb11_marine",Context.MODE_PRIVATE).getString("rows","");
        int total=0,recent=0;long now=System.currentTimeMillis();
        try{JSONObject obj=new JSONObject(raw);JSONArray rows=obj.optJSONArray("rows");
            if(rows!=null){for(int i=0;i<rows.length()&&i<800;i++){
                JSONObject a=rows.optJSONObject(i);if(a==null)continue;
                String mmsi=a.optString("mmsi","");double lat=a.optDouble("lat",Double.NaN),lon=a.optDouble("lon",Double.NaN);
                if(!GevMarineMath.validMmsi(mmsi)||!GevMarineMath.valid(lat,lon))continue;
                total++;
                double ts=a.optDouble("last_position_epoch",Double.NaN);
                if(GevMarineMath.finite(ts)&&ts>0d){long ms=(long)ts;if(ms<100000000000L)ms*=1000L;
                    if("RECENT".equals(GevMarineMath.freshness(ms,now)))recent++;}
            }}
        }catch(Exception ignored){}
        long updated=c.getSharedPreferences("rb11_marine",Context.MODE_PRIVATE).getLong("last_fetch",0L);
        String source=c.getSharedPreferences("rb11_marine",Context.MODE_PRIVATE).getString("status","not connected");
        boolean ok="live".equalsIgnoreCase(source)&&recent>0&&updated>0&&now-updated<180000L;
        r.setTextColor(R.id.rb11_marine_dot,ok?0xFF39DB9A:0xFF788C98);
        r.setTextViewText(R.id.rb11_marine_count,total>0?String.valueOf(total):"--");
        r.setTextViewText(R.id.rb11_marine_status,ok?"LIVE AIS CONTACTS":total>0?"CACHED AIS REPORTS":"NO AIS FEED");
        r.setTextViewText(R.id.rb11_marine_meta,total>0?recent+" RECENT POSITION REPORTS":"CONNECT SECURE AIS BRIDGE");
        if(updated>0L){SimpleDateFormat fmt=new SimpleDateFormat("dd MMM HH:mm 'UTC'",Locale.US);fmt.setTimeZone(TimeZone.getTimeZone("UTC"));
            r.setTextViewText(R.id.rb11_marine_footer,"FETCHED "+fmt.format(new Date(updated)));
        }else r.setTextViewText(R.id.rb11_marine_footer,"OPEN TO CONNECT AIS");
        Intent i=new Intent(c,GevMarineActivity.class);PendingIntent p=PendingIntent.getActivity(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        r.setOnClickPendingIntent(R.id.rb11_marine_root,p);manager.updateAppWidget(id,r);
    }
}
