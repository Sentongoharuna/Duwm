package com.sentongoharuna.worldsituationroom;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Evidence-only diagnostics; no simulated data and no false 'LIVE' claims. */
public final class RunningballV15SourceHealthActivity extends Activity {
  private static final int BG=0xFF08131E, WHITE=0xFFF0F9FF, MUTED=0xFF95B3C4;
  private static final int AQUA=0xFF65D9E9, AMBER=0xFFFFCA74, GREEN=0xFF65DFB2;
  private LinearLayout body;
  private TextView reports,actionMessage;
  private final Handler handler=new Handler(Looper.getMainLooper());
  private final Runnable ticker=new Runnable(){@Override public void run(){readSnapshots();handler.postDelayed(this,15000L);}};
  private int dp(float n){return Math.round(getResources().getDisplayMetrics().density*n);}
  private TextView text(String s,int sp,int color,boolean bold){TextView t=new TextView(this);
    t.setText(s);t.setTextSize(sp);t.setTextColor(color);if(bold)t.setTypeface(null,1);return t;}
  private void add(String value,int size,int color,boolean bold,int top){TextView t=text(value,size,color,bold);
    LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(top);body.addView(t,p);}
  private void button(String label,Runnable click){TextView v=text(label+"   ›",14,AQUA,true);
    v.setPadding(dp(15),dp(16),dp(12),dp(16));
    GradientDrawable bg=new GradientDrawable();bg.setColor(0xFF132B3A);bg.setCornerRadius(dp(12));
    bg.setStroke(dp(1),0xFF376D83);v.setBackground(bg);v.setOnClickListener(w->click.run());
    LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(10);body.addView(v,p);}
  private static String stamp(long time){if(time<=0)return "NEVER LOADED";
    SimpleDateFormat f=new SimpleDateFormat("dd MMM yyyy HH:mm:ss 'UTC'",Locale.US);
    f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(time));}
  private static String state(long t){if(t<=0L)return "NOT LOADED";
    long age=Math.max(0,System.currentTimeMillis()-t);
    if(age<=180000L)return "RECENT CACHED SNAPSHOT";
    if(age<=3600000L)return "OLDER CACHED SNAPSHOT";return "STALE CACHED SNAPSHOT";}
  private void open(Class<?> cls){startActivity(new Intent(this,cls));}
  private void fetchAir(){
    // AIR widget receiver performs a genuine asynchronous ADSB.LOL fetch;
    // its rate limiter and error reporting remain in charge.
    Intent refresh=new Intent(this,AirOperationsWidgets.Pulse.class);
    refresh.setAction("com.sentongoharuna.worldsituationroom.AIR_WIDGET_REFRESH");
    refresh.setPackage(getPackageName());sendBroadcast(refresh);
    actionMessage.setText("AIR REQUEST SENT • Source callback is asynchronous and throttled. Review updated time/error below.");
    handler.postDelayed(this::readSnapshots,5000L);
  }
  private void readSnapshots(){if(reports==null)return;
    JSONObject air=AirOperationsWidgets.lastData(this);
    long airTime=air.optLong("time",0L);
    String airError=getSharedPreferences("air_widget_v2",MODE_PRIVATE).getString("last_error","");
    SharedPreferences sat=getSharedPreferences("rb10_satellite",MODE_PRIVATE);
    SharedPreferences sea=getSharedPreferences("rb11_marine",MODE_PRIVATE);
    long satTime=sat.getLong("data_STATIONS_time",0L);
    long seaTime=sea.getLong("last_fetch",0L);
    String seaFeed=sea.getString("status","not connected");
    String data="AIR  /  ADSB.LOL\n"+(airTime>0?"REPORTED "+air.optInt("count",0)+" AIRCRAFT":"NO VERIFIED SNAPSHOT")+
        "\n"+(airError.isEmpty()?state(airTime):"FETCH ERROR • "+airError)+"\nLast: "+stamp(airTime)+
        "\n\nSAT  /  CELESTRAK\n"+state(satTime)+"\nLast catalogue: "+stamp(satTime)+
        "\nOrbital coordinates are estimates; this is not a live observation."+
        "\n\nSEA  /  PRIVATE AIS GATEWAY\n"+state(seaTime)+"\nGateway: "+seaFeed+
        "\nLast response: "+stamp(seaTime)+
        "\nNo configured source means no vessel observations."+
        "\n\nLocal display checked at: "+stamp(System.currentTimeMillis());
    reports.setText(data);
    RunningballV14SignalWidget.updateAll(this);
  }
  @Override public void onCreate(Bundle b){super.onCreate(b);
    getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(BG);
    body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);
    body.setPadding(dp(18),dp(20),dp(18),dp(28));sc.addView(body);
    add("RUNNINGBALL2  •  V15",12,GREEN,true,0);
    add("SOURCE HEALTH\n& VERIFICATION",24,WHITE,true,8);
    add("Actual cached observations, timestamps, source failures and required dependencies.",12,MUTED,false,8);
    reports=text("LOADING SOURCE RECORDS",14,WHITE,false);
    reports.setPadding(dp(15),dp(14),dp(15),dp(14));
    GradientDrawable card=new GradientDrawable();card.setColor(0xFF112635);
    card.setCornerRadius(dp(16));card.setStroke(dp(1),0xFF33728C);reports.setBackground(card);
    LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(14);body.addView(reports,rp);
    actionMessage=text("SOURCE STATUS • NOT A REAL-TIME DATA GUARANTEE",11,AMBER,false);
    LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);ap.topMargin=dp(12);body.addView(actionMessage,ap);
    button("REQUEST NEW AIRCRAFT REPORT",this::fetchAir);
    button("OPEN AIRCRAFT RADAR",()->open(AirRadarActivity.class));
    button("OPEN SATELLITES TO FETCH CATALOGUE",()->open(GevSatelliteActivity.class));
    button("OPEN MARITIME TO CONFIGURE AIS",()->open(GevMarineActivity.class));
    button("RECHECK LOCAL DATA AND HOME WIDGET",this::readSnapshots);
    setContentView(sc);
  }
  @Override protected void onResume(){super.onResume();handler.removeCallbacks(ticker);ticker.run();}
  @Override protected void onPause(){handler.removeCallbacks(ticker);super.onPause();}
}
