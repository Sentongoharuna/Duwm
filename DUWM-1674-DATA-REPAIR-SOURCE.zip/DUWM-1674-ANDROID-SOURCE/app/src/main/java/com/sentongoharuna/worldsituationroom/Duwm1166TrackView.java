package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;
import java.util.Locale;

/** Two-point observation path. Shows no movement unless there are two real source fixes. */
public final class Duwm1166TrackView extends View {
  private final Paint p=new Paint(3);private DuwmGeoObservationStore.Fix fix;
  public Duwm1166TrackView(Context c,DuwmGeoObservationStore.Fix value){super(c);fix=value;setMinimumHeight(240);}
  @Override protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(0xFF071C2B);p.setStrokeWidth(2);
    float w=getWidth(),h=getHeight();p.setColor(0xFF21465B);
    for(int i=1;i<5;i++)c.drawLine(w*i/5,0,w*i/5,h,p);
    for(int i=1;i<4;i++)c.drawLine(0,h*i/4,w,h*i/4,p);
    p.setColor(0xFFCAE3EB);p.setTextSize(23);
    if(fix==null||!fix.hasActualTrack()){
      c.drawText("NO TWO VERIFIED MOVEMENT FIXES",24,h*.45f,p);
      c.drawText("Observed history required to draw a track",24,h*.62f,p);return;
    }
    double latMin=Math.min(fix.lat,fix.oldLat),latMax=Math.max(fix.lat,fix.oldLat),lonMin=Math.min(fix.lon,fix.oldLon),lonMax=Math.max(fix.lon,fix.oldLon);
    double rangeLat=Math.max(.001,(latMax-latMin)*1.5),rangeLon=Math.max(.001,(lonMax-lonMin)*1.5);
    float aX=(float)(40+(fix.oldLon-lonMin+.25*(rangeLon-(lonMax-lonMin)))/rangeLon*(w-80));
    float aY=(float)(h-40-(fix.oldLat-latMin+.25*(rangeLat-(latMax-latMin)))/rangeLat*(h-80));
    float bX=(float)(40+(fix.lon-lonMin+.25*(rangeLon-(lonMax-lonMin)))/rangeLon*(w-80));
    float bY=(float)(h-40-(fix.lat-latMin+.25*(rangeLat-(latMax-latMin)))/rangeLat*(h-80));
    p.setColor(0xFF55DCEC);p.setStrokeWidth(5);c.drawLine(aX,aY,bX,bY,p);
    c.drawCircle(aX,aY,8,p);p.setColor(0xFF60EDBB);c.drawCircle(bX,bY,9,p);
    p.setTextSize(18);p.setColor(0xFFFFFFFF);c.drawText("FIRST SOURCE FIX "+fix.oldTime,12,26,p);
    c.drawText("SECOND SOURCE FIX "+fix.sourceTime,12,h-12,p);
  }
}
