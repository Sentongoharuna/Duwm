package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import java.util.Map;

/**
 * Original-widget-colour signal rail, presented on every Activity without adding home widgets.
 * Bright LEDs and short pulses require real source receipts or recorded changes.
 * Unsupported provider categories remain dim; no synthetic incoming events.
 */
public final class DuwmSignalRail extends View implements SharedPreferences.OnSharedPreferenceChangeListener {
  private static final String STORE = "duwm_1160_real_signal_receipts";
  private static final String TAG = "duwm_1160_signal_rail";
  private static final long FRESH_MS = 6L * 60L * 1000L;
  private static final long FLASH_MS = 6500L;
  private static final int[] COLORS = {
    Color.rgb(244, 77, 88),  // RED: alert, danger, conflict
    Color.rgb(251, 151, 56), // ORANGE: observed traffic movement
    Color.rgb(250, 211, 77), // YELLOW: observed satellite/watch
    Color.rgb(84, 228, 130), // GREEN: verified received source
    Color.rgb(69, 161, 247), // BLUE: vessel/weather (requires receipt)
    Color.rgb(56, 216, 235), // CYAN: communications/incoming feed
    Color.rgb(184, 131, 250),// PURPLE: news/intelligence
    Color.rgb(236, 245, 251) // WHITE: app/system active
  };
  private static final String[] LABELS = {
    "ALERT", "MOVE", "WATCH", "ACTIVE", "WATER", "FEED", "INTEL", "SYSTEM"
  };
  private final Activity host;
  private final Paint brush = new Paint(Paint.ANTI_ALIAS_FLAG);
  private final SharedPreferences prefs;
  private final RectF outer = new RectF();
  private final float density;

  private DuwmSignalRail(Activity ctx) {
    super(ctx);
    host = ctx;
    prefs = ctx.getApplicationContext().getSharedPreferences(STORE, Context.MODE_PRIVATE);
    density = getResources().getDisplayMetrics().density;
    setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
    setContentDescription("DUWM 1160 SIGNAL LIGHTS: RED ALERT, ORANGE MOVEMENT, YELLOW SATELLITE WATCH, " +
        "GREEN VERIFIED ACTIVE, BLUE WATER AND WEATHER, CYAN INCOMING FEED, " +
        "PURPLE INTELLIGENCE NEWS, WHITE SYSTEM. Dim means no recent verified source receipt.");
    setFocusable(false);
    setClickable(true);
  }

  private float dp(float px) { return px * density; }

  /** Render the same verified source lights inside a reserved status-row slot. */
  public static DuwmSignalRail embedded(Activity activity) {return new DuwmSignalRail(activity);}

  public static void attach(Activity activity) {
    if (activity == null || activity.isFinishing()) return;
    // These screens contain an embedded signal rail in a dedicated layout row.
    // Do not add another floating rail over their controls or real map records.
    if (activity instanceof OperationsMainActivity || activity instanceof DuwmPlaceMapActivity) return;
    View root = activity.getWindow() == null ? null : activity.getWindow().getDecorView();
    if (!(root instanceof FrameLayout)) return;
    FrameLayout decor = (FrameLayout) root;
    if (decor.findViewWithTag(TAG) != null) return;
    DuwmSignalRail rail = new DuwmSignalRail(activity);
    rail.setTag(TAG);
    // Compact unobtrusive 8-light chip near the bottom edge, not over the globe.
    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int)(124f*rail.density+.5f),
        (int)(30f*rail.density+.5f), Gravity.END | Gravity.BOTTOM);
    lp.rightMargin = (int)(10f*rail.density+.5f);
    lp.bottomMargin = (int)(76f*rail.density+.5f);
    decor.addView(rail, lp);
  }

  public static final class Lifecycle implements Application.ActivityLifecycleCallbacks {
    @Override public void onActivityCreated(Activity a, Bundle b) {}
    @Override public void onActivityStarted(Activity a) {}
    @Override public void onActivityResumed(Activity a) { attach(a); }
    @Override public void onActivityPaused(Activity a) { }
    @Override public void onActivityStopped(Activity a) {}
    @Override public void onActivitySaveInstanceState(Activity a, Bundle b) {}
    @Override public void onActivityDestroyed(Activity a) {}
  }

  /** Source statuses are taken only from successful parsed HTTP responses in PulseDataActivity. */
  public static void publishPulse(Context context, Map<String,String> receipts,
                                  boolean positionMoved, boolean recentNewQuake,
                                  boolean newNews, boolean newRecord, long receivedAt) {
    if (context == null || receipts == null || receivedAt <= 0L) return;
    boolean air = received(receipts, "AIRCRAFT");
    boolean quake = received(receipts, "EARTHQUAKE");
    boolean iss = received(receipts, "ISS");
    boolean news = received(receipts, "NEWS");
    boolean good = air || quake || iss || news;
    SharedPreferences p = context.getApplicationContext().getSharedPreferences(STORE, Context.MODE_PRIVATE);
    SharedPreferences.Editor edit = p.edit();
    put(edit, 0, recentNewQuake && quake, receivedAt, recentNewQuake);
    put(edit, 1, positionMoved && (air || iss), receivedAt, positionMoved);
    put(edit, 2, iss, receivedAt, newRecord && iss);
    put(edit, 3, good, receivedAt, false);
    // Blue requires actual vessel/weather observations. These feeds are not supplied by PulseDataActivity.
    // Leave an earlier independently verified marine/weather receipt alone; never invent one here.
    put(edit, 5, good, receivedAt, newRecord);
    put(edit, 6, news, receivedAt, newNews);
    edit.putLong("last_cycle", receivedAt);
    edit.apply();
  }

  /** For real marine/weather or other source adapters in the same app. Not a simulated event API. */
  public static void publishVerifiedReceipt(Context context, String kind,
                                            long sourceReceivedAt, boolean changed) {
    if (context == null || kind == null || sourceReceivedAt <= 0) return;
    int ix = -1;
    switch (kind.toUpperCase(java.util.Locale.US)) {
      case "CONFLICT": case "ALERT": ix = 0; break;
      case "TRAFFIC": case "MOVEMENT": ix = 1; break;
      case "SATELLITE": ix = 2; break;
      case "HEALTH": case "VERIFIED": ix = 3; break;
      case "VESSEL": case "MARITIME": case "WEATHER": ix = 4; break;
      case "COMMUNICATIONS": case "NETWORK": ix = 5; break;
      case "NEWS": case "INTELLIGENCE": ix = 6; break;
      default: return;
    }
    long now = System.currentTimeMillis();
    // Reject timestamps in the future or old fabricated/stale source receipts.
    if (sourceReceivedAt > now + 30000L || now-sourceReceivedAt > FRESH_MS) return;
    SharedPreferences p = context.getApplicationContext().getSharedPreferences(STORE, Context.MODE_PRIVATE);
    SharedPreferences.Editor edit = p.edit();
    put(edit, ix, true, sourceReceivedAt, changed);
    edit.apply();
  }

  private static boolean received(Map<String,String> s, String key) {
    String receipt = s.get(key);
    return receipt != null && receipt.startsWith("RECEIVED");
  }
  private static void put(SharedPreferences.Editor edit, int index, boolean trueReceipt,
                          long now, boolean pulse) {
    edit.putLong("last_"+index, trueReceipt ? now : 0L);
    edit.putLong("flash_"+index, trueReceipt && pulse ? now + FLASH_MS : 0L);
  }

  @Override protected void onAttachedToWindow() {
    super.onAttachedToWindow(); prefs.registerOnSharedPreferenceChangeListener(this);
  }
  @Override protected void onDetachedFromWindow() {
    prefs.unregisterOnSharedPreferenceChangeListener(this);
    super.onDetachedFromWindow();
  }
  @Override public void onSharedPreferenceChanged(SharedPreferences p, String key) { postInvalidate(); }

  /** Always visible, never overlapping the map: compact colour-coded receipt lights. */
  @Override protected void onDraw(Canvas c) {
    super.onDraw(c);
    float w=getWidth(),h=getHeight();
    outer.set(dp(1),dp(1),w-dp(1),h-dp(1));
    brush.setStyle(Paint.Style.FILL);brush.setColor(Color.argb(240,7,17,28));
    c.drawRoundRect(outer,dp(15),dp(15),brush);
    brush.setStyle(Paint.Style.STROKE);brush.setStrokeWidth(dp(.8f));brush.setColor(Color.rgb(34,85,97));
    c.drawRoundRect(outer,dp(15),dp(15),brush);
    brush.setShader(null);brush.setStyle(Paint.Style.FILL);brush.setTextAlign(Paint.Align.LEFT);
    brush.setColor(Color.rgb(189,215,224));brush.setTextSize(dp(8));
    c.drawText("SIG",dp(8),h*.60f,brush);
    float left=dp(30),cell=(w-left-dp(6))/8f,cy=h*.50f;
    long now=System.currentTimeMillis();boolean flashing=false;
    for(int i=0;i<8;i++){
      long last=prefs.getLong("last_"+i,0L),flash=prefs.getLong("flash_"+i,0L);
      boolean on=i==7||(last>0&&last<=now&&now-last<FRESH_MS);
      boolean blink=on&&flash>now;if(blink)flashing=true;
      float brightness=!on?.20f:blink&&(now/350L)%2==0?.34f:1f;
      int col=COLORS[i],red=Color.red(col),green=Color.green(col),blue=Color.blue(col);
      float x=left+(i+.5f)*cell;
      brush.setColor(Color.argb(on?78:25,red,green,blue));c.drawCircle(x,cy,dp(4.65f),brush);
      brush.setColor(Color.rgb((int)(red*brightness),(int)(green*brightness),(int)(blue*brightness)));
      c.drawCircle(x,cy,dp(2.55f),brush);
    }
    if(flashing)postInvalidateDelayed(280L);
  }

  private void shareSignal(int ix) {
    long now=System.currentTimeMillis(),last=prefs.getLong("last_"+ix,0L);
    boolean verified=ix==7||(last>0&&last<=now&&now-last<FRESH_MS);
    String state=verified?(ix==7?"SYSTEM ACTIVE":"RECENT VERIFIED RECEIPT"):
        "NO RECENT VERIFIED SOURCE RECEIPT";
    String message="Colour: "+LABELS[ix]+". Status: "+state+". "+
      (ix==4?"Marine/weather needs a matching real-source receipt. ":"")+
      "Animated light indicates a received change, not a simulated detection.";
    V115941ShareCards.share(host,"SOURCE SIGNAL",LABELS[ix]+" / "+state,message,
      "DEVELOP.UGANDA / SOURCE RECEIPT LEDGER",verified&&ix!=7?last:0L,null,null,"",null);
  }
  /** Tap the chip to open eight readable source states; each state can be shared. */
  @Override public boolean onTouchEvent(MotionEvent event){
    if(event.getAction()==MotionEvent.ACTION_DOWN)return true;
    if(event.getAction()!=MotionEvent.ACTION_UP)return super.onTouchEvent(event);
    performClick();
    long now=System.currentTimeMillis();String[] details=new String[8];
    for(int i=0;i<8;i++){
      long last=prefs.getLong("last_"+i,0L);
      boolean active=i==7||(last>0&&last<=now&&now-last<FRESH_MS);
      String state=active?(i==7?"SYSTEM ACTIVE":"RECEIVED"):("NO RECENT RECEIPT");
      details[i]=LABELS[i]+"  •  "+state+"  /  TAP TO SHARE";
    }
    if(!host.isFinishing())new android.app.AlertDialog.Builder(host)
      .setTitle("DEVELOP.UGANDA  /  SOURCE SIGNALS")
      .setItems(details,(dialog,which)->shareSignal(which))
      .setNegativeButton("CLOSE",null).show();
    return true;
  }
  @Override public boolean performClick(){super.performClick();return true;}
}
