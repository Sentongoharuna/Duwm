package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Locale;

/** Worldwide discovery directory: 200 real website entries, NOT 200 connected live feeds.
 * Provider configuration, access agreements and source health remain separate.
 */
public final class Duwm1669SourceDirectoryActivity extends Activity {
  private static final int BG=0xFF06131D, PANEL=0xFF112A3A, LINE=0xFF32566A, WHITE=0xFFF1F8FA, MUTED=0xFFA5BECA, AQUA=0xFF59CFDC;
  private static final String[] TYPES={"Cameras","TV","News","Vessels"};
  private final ArrayList<JSONObject> all=new ArrayList<>();
  private String selected="Cameras",query="";
  private LinearLayout results,categories;
  private TextView summary;
  private int dp(float v){return (int)(getResources().getDisplayMetrics().density*v+.5f);}
  private TextView text(String title,int size,int color){TextView t=new TextView(this);t.setText(title);t.setTextSize(size);t.setTextColor(color);return t;}
  private GradientDrawable frame(int fill){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(10));d.setStroke(dp(1),LINE);return d;}
  private void load(){try(BufferedReader r=new BufferedReader(new InputStreamReader(getAssets().open("duwm_global_200_sources.json"),"UTF-8"))){
    StringBuilder b=new StringBuilder();String line;while((line=r.readLine())!=null)b.append(line).append('\n');
    JSONArray items=new JSONObject(b.toString()).getJSONArray("sources");
    for(int i=0;i<items.length();i++)all.add(items.getJSONObject(i));
  }catch(Exception e){summary.setText("SOURCE CATALOG UNAVAILABLE: "+e.getClass().getSimpleName());}}
  private TextView button(String name,Runnable r){TextView t=text(name,12,AQUA);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setPadding(dp(14),dp(12),dp(14),dp(12));t.setGravity(Gravity.CENTER);t.setBackground(frame(PANEL));t.setOnClickListener(v->r.run());return t;}
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(BG);setContentView(scroll);Duwm1167SafeArea.install(this,scroll);
    LinearLayout body=new LinearLayout(this);body.setPadding(dp(14),dp(13),dp(14),dp(30));body.setOrientation(LinearLayout.VERTICAL);scroll.addView(body);
    TextView title=text("DEVELOP.UGANDA  /  WORLD SOURCES",21,WHITE);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);body.addView(title);
    TextView sub=text("1669  •  200 WORLDWIDE SOURCE WEBSITES  •  50 PER CATEGORY",11,AQUA);body.addView(sub);
    TextView policy=text("DISCOVERY DIRECTORY — NOT 200 LIVE DATA CONNECTIONS. Source permissions, APIs, playable streams and data freshness must be verified separately. No synthetic source receipts.",12,MUTED);policy.setPadding(0,dp(10),0,dp(10));body.addView(policy);
    summary=text("LOADING SOURCE DIRECTORY",12,AQUA);body.addView(summary);
    EditText find=new EditText(this);find.setTextSize(14);find.setSingleLine(true);find.setHint("Search source, region or capability");find.setHintTextColor(MUTED);find.setTextColor(WHITE);find.setPadding(dp(10),dp(12),dp(10),dp(12));find.setBackground(frame(PANEL));
    LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(10);body.addView(find,sp);
    find.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){query=s.toString().toLowerCase(Locale.ROOT);show();}public void afterTextChanged(Editable e){}});
    HorizontalScrollView h=new HorizontalScrollView(this);h.setHorizontalScrollBarEnabled(false);categories=new LinearLayout(this);h.addView(categories);
    LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(10);body.addView(h,hp);
    results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);body.addView(results);
    load();renderCategories();show();
  }
  private void renderCategories(){categories.removeAllViews();for(String type:TYPES){TextView t=button(type.toUpperCase(Locale.ROOT)+" 50",()->{selected=type;renderCategories();show();});t.setTextColor(type.equals(selected)?WHITE:MUTED);if(type.equals(selected))t.setBackground(frame(0xFF1E5061));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.rightMargin=dp(7);categories.addView(t,lp);}}
  private void show(){if(results==null)return;results.removeAllViews();int matched=0;
    for(JSONObject item:all){String type=item.optString("category");if(!selected.equals(type))continue;
      String searchable=(item.optString("name")+" "+item.optString("region")+" "+item.optString("kind")+" "+item.optString("access")).toLowerCase(Locale.ROOT);
      if(!searchable.contains(query))continue;matched++;
      LinearLayout card=new LinearLayout(this);card.setPadding(dp(13),dp(12),dp(13),dp(12));card.setOrientation(LinearLayout.VERTICAL);card.setBackground(frame(PANEL));
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(8);results.addView(card,lp);
      TextView headline=text(item.optString("id")+"  /  "+item.optString("name"),15,WHITE);headline.setTypeface(Typeface.DEFAULT,Typeface.BOLD);card.addView(headline);
      card.addView(text(item.optString("region")+"  •  "+item.optString("kind"),11,AQUA));
      card.addView(text(item.optString("access")+"  •  NOT YET CONNECTED",11,MUTED));
      TextView link=button("SOURCE DETAILS / WEBSITE",()->details(item));LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(-1,-2);blp.topMargin=dp(5);card.addView(link,blp);
    }
    summary.setText(selected.toUpperCase(Locale.ROOT)+"  /  "+matched+" MATCHING SOURCES  /  50 CANDIDATES");
    if(matched==0)results.addView(text("NO SOURCES MATCH THIS SEARCH",13,MUTED));
  }
  private void details(JSONObject item){String url=item.optString("url");String msg="CATEGORY: "+item.optString("category")+"\nREGION: "+item.optString("region")+"\nSOURCE: "+item.optString("name")+"\nTYPE: "+item.optString("kind")+"\nACCESS: "+item.optString("access")+"\n\nSTATUS: candidate directory entry, not a verified working API.\nWEBSITE: "+url;
    new AlertDialog.Builder(this).setTitle(item.optString("name")).setMessage(msg).setNegativeButton("CLOSE",null).setPositiveButton("OPEN SOURCE WEBSITE",(d,w)->{
      try{Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse(url));startActivity(i);}catch(Exception ex){new AlertDialog.Builder(this).setMessage("No browser available for this source.").setPositiveButton("OK",null).show();}
    }).show();
  }
}
