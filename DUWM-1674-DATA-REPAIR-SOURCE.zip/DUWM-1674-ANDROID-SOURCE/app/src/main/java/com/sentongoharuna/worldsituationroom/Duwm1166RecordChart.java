package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** Geography histogram from source-reported positions; no simulated or filled values. */
public final class Duwm1166RecordChart extends View {
  private final Paint p=new Paint(3);
  private int[] values=new int[0];private String[] names=new String[0];
  public Duwm1166RecordChart(Context context){super(context);setMinimumHeight(180);}
  public void data(String[] labels,int[] counts){names=labels==null?new String[0]:labels.clone();values=counts==null?new int[0]:counts.clone();invalidate();}
  private float sp(float x){return x*getResources().getDisplayMetrics().scaledDensity;}
  @Override protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(0xFF0A2535);int w=getWidth(),h=getHeight();
    int n=Math.min(values.length,names.length);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
    if(n==0){p.setColor(0xFFAFCAD5);p.setTextSize(sp(12));c.drawText("NO SAVED SOURCE POSITIONS",16,h/2f,p);return;}
    float top=sp(30),bottom=h-sp(44),usable=Math.max(1,bottom-top),margin=sp(9);float stride=(w-2*margin)/n;
    int max=0;for(int i=0;i<n;i++)max=Math.max(max,Math.max(0,values[i]));
    p.setColor(0xFF315062);p.setStrokeWidth(1);for(int k=0;k<=4;k++){float y=bottom-usable*k/4;c.drawLine(margin,y,w-margin,y,p);}
    for(int i=0;i<n;i++){
      float cx=margin+stride*(i+.5f);float bar=Math.max(0,values[i])*usable/Math.max(1,max);float bw=Math.max(5,stride*.55f);
      if(values[i]>0){p.setColor(0xFF48C8D9);c.drawRoundRect(new RectF(cx-bw/2,bottom-bar,cx+bw/2,bottom),sp(4),sp(4),p);}
      String count=Integer.toString(Math.max(0,values[i]));p.setColor(0xFFE4F3F7);p.setTextSize(sp(11));c.drawText(count,cx-p.measureText(count)/2,Math.max(sp(17),bottom-bar-sp(5)),p);
      String label=names[i].replace("AMERICAS","AMERICAS").replace("PACIFIC","PACIFIC").replace("EUROPE","EUROPE");
      p.setTextSize(sp(9));p.setColor(0xFFA4C3CE);while(label.length()>3&&p.measureText(label)>stride-3)label=label.substring(0,label.length()-1);
      c.drawText(label,cx-p.measureText(label)/2,h-sp(20),p);
    }
    if(max==0){p.setColor(0xFF9AB4C2);p.setTextSize(sp(11));String note="NO SAVED POSITIONS IN THESE REGIONS";c.drawText(note,Math.max(6,(w-p.measureText(note))/2),h/2f,p);}
  }
}
