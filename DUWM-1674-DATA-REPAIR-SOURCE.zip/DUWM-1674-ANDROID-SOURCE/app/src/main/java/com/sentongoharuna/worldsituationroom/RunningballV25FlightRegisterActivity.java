package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.Intent;
import org.json.JSONArray;
import java.util.Locale;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/** Independent V25 implementation: searchable RECEIVED OpenSky global aircraft sample.
 *  Not copied from God's Eye View. Neither a complete worldwide inventory nor a live ATC feed.
 */
public final class RunningballV25FlightRegisterActivity extends Activity {
  private static final int BG=0xFF07111B, PANEL=0xFF132A3A, CYAN=0xFF55D6EF,
    GREEN=0xFF5CFFC6, AMBER=0xFFFFBE66, WHITE=0xFFEAF5FE, DIM=0xFFB7CAD6;
  private final Handler ui=new Handler(Looper.getMainLooper());
  private final Runnable update=new Runnable(){@Override public void run(){if(!visible)return;render();ui.postDelayed(this,30000L);}};
  private boolean visible=false;
  private TextView summary,selection,more;
  private LinearLayout results;
  private EditText query;
  private String region="ALL";
  private int start=0;
  private static final int PAGE=45;
  private int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);}
  private TextView txt(String s,int size,int ink){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(ink);t.setPadding(dp(11),dp(11),dp(11),dp(11));return t;}
  private void action(LinearLayout parent,String label,Runnable r){TextView b=txt(label,13,CYAN);
    b.setBackgroundColor(PANEL);b.setMinimumHeight(dp(48));b.setContentDescription(label);
    b.setOnClickListener(v->r.run());LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(5);parent.addView(b,p);}
  private String utc(long ms){if(ms<=0)return "SOURCE TIME MISSING";
    SimpleDateFormat f=new SimpleDateFormat("dd MMM HH:mm:ss 'UTC'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(ms));}
  @Override public void onCreate(Bundle b){super.onCreate(b);
    getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);root.setPadding(dp(8),dp(10),dp(8),dp(25));
    root.addView(txt("GLOBAL AIRCRAFT · RECEIVED REGISTER",18,GREEN));
    root.addView(txt("OPENSKY NETWORK · Search recorded sample only · Maximum 5,000 plotted coordinates · Not all aircraft in flight",11,AMBER));
    summary=txt("AWAITING VERIFIED PROVIDER REPORT",11,WHITE);root.addView(summary);
    selection=txt("TAP A REPORTED AIRCRAFT TO INSPECT SOURCE FIELDS",12,WHITE);selection.setBackgroundColor(PANEL);root.addView(selection);
    query=new EditText(this);query.setSingleLine(true);query.setHint("Search callsign, ICAO24, reported origin");query.setTextColor(WHITE);query.setHintTextColor(DIM);query.setTextSize(13);
    query.setBackgroundColor(PANEL);query.setPadding(dp(12),dp(12),dp(12),dp(12));root.addView(query);
    query.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){}
      public void onTextChanged(CharSequence s,int a,int b,int c){start=0;render();}
      public void afterTextChanged(Editable e){}
    });
    action(root,"OPEN ICAO24 OPEN SKY DETAILS",()->{
      String requested=query.getText()==null?"":query.getText().toString().trim().toUpperCase(Locale.US);
      if(!requested.matches("[0-9A-F]{6}")){
        selection.setText("ENTER ONE VALID SIX-CHARACTER ICAO24 HEX TO OPEN OPEN SKY DETAILS");return;
      }
      Intent intent=new Intent(this,AirFlightDetailsActivity.class);
      intent.putExtra("air_provider","OPENSKY");intent.putExtra("air_hex",requested);
      startActivity(intent);
    });
    action(root,"ALL RETURNED POSITIONS",()->setRegion("ALL"));
    action(root,"AMERICAS LONGITUDES (-180° TO -30°)",()->setRegion("AMERICAS"));
    action(root,"EUROPE / AFRICA LONGITUDES (-30° TO 60°)",()->setRegion("EUROPE_AFRICA"));
    action(root,"ASIA / PACIFIC LONGITUDES (60° TO 180°)",()->setRegion("ASIA_PACIFIC"));
    results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);root.addView(results);
    more=txt("",13,CYAN);more.setMinimumHeight(dp(50));more.setBackgroundColor(PANEL);root.addView(more);
    more.setOnClickListener(v->{start+=PAGE;render();});
    action(root,"REQUEST GLOBAL DATA / PROVIDER COOLDOWN APPLIES",()->RunningballV25GlobalAircraftData.refresh(this,this::render));
    action(root,"OPEN ORIGINAL WORLD GLOBE",()->startActivity(new Intent(this,MainActivity.class)));
    action(root,"BACK TO GLOBAL AIRCRAFT MAP",this::finish);
    scroll.addView(root);setContentView(scroll);render();
  }
  private void setRegion(String id){region=id;start=0;render();}
  private boolean inRegion(JSONArray p){if("ALL".equals(region))return true;
    double lon=p.optDouble(1,Double.NaN);
    if(!Double.isFinite(lon))return false;
    if("AMERICAS".equals(region))return lon < -30;
    if("EUROPE_AFRICA".equals(region))return lon>=-30&&lon<60;
    return lon>=60;
  }
  private boolean matching(JSONArray p,String q){if(q.isEmpty())return true;
    String searchable=p.optString(2,"")+" "+p.optString(3,"")+" "+p.optString(9,"");
    return searchable.toLowerCase(Locale.ROOT).contains(q);
  }
  private void select(JSONArray p){
    String icao=p.optString(2,"").trim(),call=p.optString(3,"").trim(),origin=p.optString(9,"").trim();
    String altitude=p.isNull(4)?"NOT REPORTED":String.format(Locale.US,"%.0f m",p.optDouble(4));
    String speed=p.isNull(5)?"NOT REPORTED":String.format(Locale.US,"%.0f km/h",p.optDouble(5)*3.6d);
    String track=p.isNull(6)?"NOT REPORTED":String.format(Locale.US,"%.0f°",p.optDouble(6));
    String grounded=p.length()<9||p.isNull(8)?"NOT REPORTED":(p.optBoolean(8)?"YES":"NO");
    long t=p.isNull(7)?0L:p.optLong(7,0L)*1000L;
    selection.setText("AIRCRAFT "+(call.isEmpty()?icao:call+" / "+icao)+"\nORIGIN "+(origin.isEmpty()?"UNKNOWN":origin)+
       "\nRECEIVED POSITION "+String.format(Locale.US,"%.4f, %.4f",p.optDouble(0),p.optDouble(1))+
       "\nALT "+altitude+" · SPEED "+speed+" · TRACK "+track+" · ON GROUND "+grounded+
       "\nLAST CONTACT "+utc(t));
  }
  private void render(){if(results==null||query==null)return;
    RunningballV25GlobalAircraftData.Snapshot snap=RunningballV25GlobalAircraftData.read(this);
    String filter=query.getText()==null?"":query.getText().toString().trim().toLowerCase(Locale.ROOT);
    summary.setText("SCOPE "+region.replace('_','/')+" · SOURCE TIME "+utc(snap.sourceAt)+"\nRECEIVED "+snap.countLabel()+
      " · VALID POSITION REPORTS "+(snap.hasGood()?snap.positionRows:"--")+
      " · STORED MAP SAMPLE "+(snap.hasGood()?snap.displayRows:"--")+"\n"+
      snap.status()+" · LAST GOOD "+snap.ageLabel()+" · NEXT ALLOWED CHECK "+snap.nextCheckLabel()+
      (snap.error.isEmpty()?"":"\nERROR "+snap.error));
    results.removeAllViews();
    if(!snap.hasGood()||snap.ageMs()>21600000L){results.addView(txt("NO CURRENT VERIFIED GLOBAL POSITIONS · SHOWING NO FABRICATED FLIGHTS",12,AMBER));more.setVisibility(android.view.View.GONE);return;}
    int matched=0,shown=0;JSONArray arr=snap.points;
    for(int i=0;i<arr.length();i++){
      final JSONArray row=arr.optJSONArray(i);if(row==null||!inRegion(row)||!matching(row,filter))continue;
      if(matched++<start)continue;
      if(shown++>=PAGE)continue;
      String call=row.optString(3,"").trim(),icao=row.optString(2,""),origin=row.optString(9,"");
      TextView card=txt((call.isEmpty()?"NO CALLSIGN":call)+" · "+icao+"\n"+
        String.format(Locale.US,"POSITION  %.2f°, %.2f°",row.optDouble(0),row.optDouble(1))+
        (origin.isEmpty()?"":"  ·  "+origin),12,WHITE);
      card.setBackgroundColor(PANEL);card.setMinimumHeight(dp(52));card.setContentDescription("Inspect reported aircraft "+icao);
      card.setOnClickListener(v->{
        select(row);
        Intent detailIntent=new Intent(this,AirFlightDetailsActivity.class);
        detailIntent.putExtra("air_provider","OPENSKY");
        detailIntent.putExtra("air_hex",row.optString(2,""));
        startActivity(detailIntent);
      });LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(4);results.addView(card,lp);
    }
    // Exact matching count uses the same source sample and never implies total coverage.
    more.setText("MATCHING SAMPLED POSITION RECORDS: "+matched+" · DISPLAYED "+Math.min(Math.max(0,matched-start),PAGE)+
      "  ·  "+(matched>start+PAGE?"TAP FOR NEXT PAGE":"END OF RECEIVED SAMPLE"));
    more.setVisibility(android.view.View.VISIBLE);
    final int matchingTotal=matched;
    more.setOnClickListener(v->{if(matchingTotal>start+PAGE){start+=PAGE;render();}});
    if(matched==0){results.addView(txt("NO SOURCE-REPORTED AIRCRAFT MATCH THIS FILTER",12,AMBER));}
  }
  @Override protected void onResume(){super.onResume();visible=true;ui.post(update);RunningballV25GlobalAircraftData.refresh(this,()->{if(visible)render();});}
  @Override protected void onPause(){visible=false;ui.removeCallbacks(update);super.onPause();}
}
