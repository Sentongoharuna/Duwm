package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;

/** Independent V25 OpenSky world map and gateway to the ORIGINAL worldwide globe.
 * Markers are FIXES RECEIVED from the provider and are not animated as new fixes.
 * Does not claim the OpenSky network covers every flight on Earth.
 */
public final class RunningballV25WorldwideAirActivity extends Activity {
  private static final int BG=0xFF07111B, INK=0xFFEAF5FE, CYAN=0xFF55D6EF,
      GREEN=0xFF5CFFC6, AMBER=0xFFFFBE66, MUTED=0xFFB2C6D4;
  private final Handler handler=new Handler(Looper.getMainLooper());
  private final Runnable tick=new Runnable(){@Override public void run(){if(!active)return;RunningballV25GlobalAircraftData.refresh(RunningballV25WorldwideAirActivity.this,null);render();handler.postDelayed(this,30000L);}};
  private TextView status,detail,displacementInfo;
  private FlightPlot plot;
  private boolean active;
  private int dp(float v){return Math.round(getResources().getDisplayMetrics().density*v);}
  private TextView text(String value,int size,int color){TextView v=new TextView(this);v.setText(value);v.setTextColor(color);v.setTextSize(size);v.setPadding(dp(12),dp(12),dp(12),dp(12));return v;}
  private void add(LinearLayout c,String title,Runnable action){
    TextView b=text(title,13,CYAN);b.setBackgroundColor(0xFF132A3A);b.setMinimumHeight(dp(50));
    b.setOnClickListener(v->action.run());b.setContentDescription(title);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(7);c.addView(b,p);
  }
  @Override public void onCreate(Bundle saved){super.onCreate(saved);
    getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
    LinearLayout col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);col.setPadding(dp(10),dp(14),dp(10),dp(24));col.setBackgroundColor(BG);
    TextView headline=text("WORLDWIDE AIRCRAFT  /  OPEN SKY",19,GREEN);col.addView(headline);
    TextView caution=text("OBSERVED NETWORK COVERAGE · NOT EVERY AIRCRAFT ON EARTH · RATE-LIMITED",11,AMBER);col.addView(caution);
    status=text("AWAITING THE FIRST VERIFIED GLOBAL RESPONSE",12,INK);col.addView(status);
    plot=new FlightPlot();plot.setMinimumHeight(dp(290));col.addView(plot,new LinearLayout.LayoutParams(-1,dp(305)));
    // One new function only: navigate the REAL global aircraft points by zoom and pan.
    LinearLayout zoomBar=new LinearLayout(this);zoomBar.setOrientation(LinearLayout.HORIZONTAL);
    String[] captions={"ZOOM +","ZOOM -","RESET VIEW"};
    for(int z=0;z<captions.length;z++){
      final int which=z;TextView b=text(captions[z],12,CYAN);b.setGravity(Gravity.CENTER);
      b.setMinimumHeight(dp(48));b.setContentDescription(captions[z]+" global aircraft map");
      b.setBackgroundColor(0xFF132A3A);
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(3),dp(5),dp(3),dp(5));
      zoomBar.addView(b,lp);
      b.setOnClickListener(v->{if(which==0)plot.zoomBy(1.65f);else if(which==1)plot.zoomBy(1f/1.65f);else plot.resetView();});
    }
    col.addView(zoomBar);
    col.addView(text("Drag the received positions to pan; pinch to zoom. Source and observation ages remain unchanged.",11,MUTED));
    displacementInfo=text("TWO-FIX DISPLACEMENTS: NONE UNTIL TWO DISTINCT PROVIDER REPORTS",11,AMBER);col.addView(displacementInfo);
    detail=text("Tap a reported position for aircraft identification and last reported time.",12,INK);col.addView(detail);
    add(col,"GLOBAL AIRCRAFT REGISTER / SEARCH CALLSIGNS & ICAO  ›",()->startActivity(new Intent(this,RunningballV25FlightRegisterActivity.class)));
    add(col,"OPEN ORIGINAL GLOBE / ORIGINAL LAYERS  ›",()->startActivity(new Intent(this,MainActivity.class)));
    add(col,"REQUEST AIRCRAFT UPDATE NOW  ↻",()->{status.setText("REQUESTED · WAIT FOR VERIFIED PROVIDER RESPONSE");RunningballV25GlobalAircraftData.refreshNow(this,this::render);});
    add(col,"OPEN AIRCRAFT RADAR / SELECTED 250 NM REGION  ›",()->startActivity(new Intent(this,AirRadarActivity.class)));
    add(col,"SOURCE HEALTH & ERRORS  ›",()->startActivity(new Intent(this,RunningballV25SourceHealthActivity.class)));
    add(col,"BACK TO COMMAND CENTER  ‹",this::finish);
    scroll.addView(col);setContentView(scroll);render();
  }
  @Override protected void onResume(){super.onResume();active=true;handler.removeCallbacks(tick);handler.post(tick);
    RunningballV25GlobalAircraftData.refresh(this,()->{if(active)render();});}
  @Override protected void onPause(){active=false;handler.removeCallbacks(tick);super.onPause();}
  private void render(){
    RunningballV25GlobalAircraftData.Snapshot s=RunningballV25GlobalAircraftData.read(this);
    String age=s.ageLabel();
    status.setText("SOURCE: OpenSky /states/all · HTTP "+(s.lastHttp==0?"UNTESTED":s.lastHttp)+"\n"+
      "PROVIDER RECORDS: "+s.countLabel()+" · WITH POSITION: "+(s.hasGood()?s.positionRows:"--")+
      " · CACHED POSITIONS: "+(s.hasGood()?s.displayRows:"--")+" (BOUNDED CACHE, NO FIXED MAP CLIP)\n"+
      "STATUS: "+s.status()+" · LAST GOOD: "+age+"\n"+
      "PROVIDER SOURCE AGE: "+s.providerAgeLabel()+" · NEXT CHECK: "+s.nextCheckLabel()+"\n"+
      "COVERAGE: WORLDWIDE / OPEN SKY RECEIVERS ONLY"+
      (s.error.isEmpty()?"":"\nLAST NETWORK ERROR: "+s.error));
    plot.update(s);
    displacementInfo.setText("TWO-FIX DISPLACEMENTS: "+plot.pairCount()+" / STRAIGHT CONNECTORS, NOT RECORDED ROUTES");
  }
  private void selected(JSONArray item){
    if(item==null)return;
    double lat=item.optDouble(0,Double.NaN),lon=item.optDouble(1,Double.NaN);
    String code=item.optString(2,"NOT REPORTED"),call=item.optString(3,"");
    long t=item.isNull(7)?0L:item.optLong(7,0L)*1000L;
    SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'",Locale.US);sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
    String altitude=item.isNull(4)?"NOT REPORTED":String.format(Locale.US,"%.0f m",item.optDouble(4));
    String speed=item.isNull(5)?"NOT REPORTED":String.format(Locale.US,"%.0f km/h",item.optDouble(5)*3.6d);
    String heading=item.isNull(6)?"NOT REPORTED":String.format(Locale.US,"%.0f°",item.optDouble(6));
    detail.setText("AIRCRAFT  "+code+(call.isEmpty()?"":" · "+call)+"\n"+
      String.format(Locale.US,"REPORTED POSITION  %.4f, %.4f",lat,lon)+
      "\nALTITUDE  "+altitude+" · SPEED  "+speed+" · TRACK  "+heading+
      "\nLAST PROVIDER POSITION  "+(t>0?sdf.format(new Date(t)):"TIME UNAVAILABLE"));
    Intent i=new Intent(this,AirFlightDetailsActivity.class);
    i.putExtra("air_provider","OPENSKY");i.putExtra("air_hex",code);
    startActivity(i);
  }
  private final class FlightPlot extends View {
    private JSONArray points=new JSONArray();
    private JSONArray verifiedPairs=new JSONArray();
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private float zoom=1f,shiftX=0f,shiftY=0f,lastX,lastY,downX,downY;
    private boolean dragged=false;
    private final ScaleGestureDetector scale=new ScaleGestureDetector(RunningballV25WorldwideAirActivity.this,
      new ScaleGestureDetector.SimpleOnScaleGestureListener(){
        @Override public boolean onScale(ScaleGestureDetector detector){
          setZoom(zoom*detector.getScaleFactor(),detector.getFocusX(),detector.getFocusY());
          dragged=true;return true;
        }
      });
    FlightPlot(){super(RunningballV25WorldwideAirActivity.this);setBackgroundColor(0xFF0B1B2A);
      setContentDescription("OpenSky reported aircraft positions. Pinch zoom, drag pan, or use labelled zoom buttons. Tap a reported marker for real details.");}
    void update(RunningballV25GlobalAircraftData.Snapshot snapshot){
      points=snapshot.hasGood()&&snapshot.ageMs()<21600000L?snapshot.points:new JSONArray();
      verifiedPairs=new JSONArray();
      if(points.length()>0 && snapshot.priorSourceAt>0L && snapshot.sourceAt>snapshot.priorSourceAt
          && snapshot.sourceAt-snapshot.priorSourceAt<=5400000L){
        HashMap<String,JSONArray> previous=new HashMap<>();
        for(int j=0;j<snapshot.priorPoints.length();j++){
          JSONArray p=snapshot.priorPoints.optJSONArray(j);if(p==null)continue;
          String hex=p.optString(2,"").trim();if(!hex.isEmpty())previous.put(hex,p);
        }
        for(int j=0;j<points.length() && verifiedPairs.length()<400;j++){
          JSONArray now=points.optJSONArray(j);if(now==null)continue;
          JSONArray before=previous.get(now.optString(2,"").trim());if(before==null)continue;
          double a=before.optDouble(0,Double.NaN),b=before.optDouble(1,Double.NaN);
          double c=now.optDouble(0,Double.NaN),d=now.optDouble(1,Double.NaN);
          long t0=before.isNull(7)?0:before.optLong(7),t1=now.isNull(7)?0:now.optLong(7);
          if(RunningballV25AircraftTrailPolicy.qualifies(before.optString(2,""),now.optString(2,""),
              a,b,c,d,t0,t1,snapshot.priorSourceAt,snapshot.sourceAt)){
            JSONArray pair=new JSONArray();pair.put(Double.valueOf(a));pair.put(Double.valueOf(b));pair.put(Double.valueOf(c));pair.put(Double.valueOf(d));
            verifiedPairs.put(pair);
          }
        }
      }
      invalidate();
    }
    int pairCount(){return verifiedPairs.length();}
    private float clamp(float v,float low,float high){return Math.max(low,Math.min(high,v));}
    private void clampPan(){
      shiftX=clamp(shiftX,-getWidth()*(zoom-1f)/2f,getWidth()*(zoom-1f)/2f);
      shiftY=clamp(shiftY,-getHeight()*(zoom-1f)/2f,getHeight()*(zoom-1f)/2f);
    }
    private void setZoom(float next,float fx,float fy){
      if(getWidth()<=0||getHeight()<=0)return;
      float newZoom=clamp(next,1f,12f),ratio=newZoom/zoom;
      shiftX=fx-getWidth()/2f-(fx-getWidth()/2f-shiftX)*ratio;
      shiftY=fy-getHeight()/2f-(fy-getHeight()/2f-shiftY)*ratio;
      zoom=newZoom;clampPan();invalidate();
    }
    void zoomBy(float factor){setZoom(zoom*factor,getWidth()/2f,getHeight()/2f);}
    void resetView(){zoom=1f;shiftX=0f;shiftY=0f;invalidate();}
    private float x(double lon){return ((float)((lon+180d)/360d)*getWidth()-getWidth()/2f)*zoom+getWidth()/2f+shiftX;}
    private float y(double lat){return ((float)((90d-lat)/180d)*getHeight()-getHeight()/2f)*zoom+getHeight()/2f+shiftY;}
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);
      canvas.save();canvas.clipRect(0,0,getWidth(),getHeight());
      paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(0.7f));paint.setColor(0xFF27506A);
      for(int lon=-180;lon<=180;lon+=30)canvas.drawLine(x(lon),0,x(lon),getHeight(),paint);
      for(int lat=-90;lat<=90;lat+=30)canvas.drawLine(0,y(lat),getWidth(),y(lat),paint);
      // Source-observed end points only; a straight displacement connector is not a recorded route.
      paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1.15f));paint.setColor(0xAA55D6EF);
      for(int j=0;j<verifiedPairs.length();j++){
        JSONArray path=verifiedPairs.optJSONArray(j);if(path==null)continue;
        canvas.drawLine(x(path.optDouble(1)),y(path.optDouble(0)),
          x(path.optDouble(3)),y(path.optDouble(2)),paint);
      }
      paint.setStyle(Paint.Style.FILL);paint.setColor(GREEN);
      float radius=clamp(dp(1.6f)*(float)Math.sqrt(zoom),dp(1.6f),dp(4f));
      for(int i=0;i<points.length();i++){
        JSONArray row=points.optJSONArray(i);if(row==null)continue;
        float px=x(row.optDouble(1)),py=y(row.optDouble(0));
        if(px>=-radius&&px<=getWidth()+radius&&py>=-radius&&py<=getHeight()+radius)
          canvas.drawCircle(px,py,radius,paint);
      }
      paint.setTextSize(dp(12));paint.setColor(MUTED);
      canvas.drawText(String.format(Locale.US,"OPENSKY RECEIVED MAP / ZOOM %.1fx",zoom),dp(8),dp(16),paint);
      if(points.length()==0)canvas.drawText("NO RECEIVED AIRCRAFT POSITIONS",dp(9),getHeight()/2f,paint);
      else{
        paint.setTextSize(dp(10));paint.setColor(CYAN);
        canvas.drawText(verifiedPairs.length()+" TWO-FIX DISPLACEMENTS / NOT RECORDED ROUTES",dp(8),getHeight()-dp(8),paint);
      }
      canvas.restore();
    }
    @Override public boolean onTouchEvent(MotionEvent event){
      scale.onTouchEvent(event);
      int action=event.getActionMasked();
      if(action==MotionEvent.ACTION_DOWN){if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(true);lastX=downX=event.getX();lastY=downY=event.getY();dragged=false;return true;}
      if(action==MotionEvent.ACTION_POINTER_DOWN){if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(true);dragged=true;return true;}
      if(action==MotionEvent.ACTION_MOVE){
        if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(true);
        if(event.getPointerCount()==1&&!scale.isInProgress()){
          float currentX=event.getX(),currentY=event.getY();
          if(Math.abs(currentX-downX)>dp(6)||Math.abs(currentY-downY)>dp(6))dragged=true;
          if(dragged){shiftX+=currentX-lastX;shiftY+=currentY-lastY;clampPan();invalidate();}
          lastX=currentX;lastY=currentY;
        }return true;
      }
      if(action==MotionEvent.ACTION_POINTER_UP){
        dragged=true;
        int remaining=event.getActionIndex()==0?1:0;
        if(remaining<event.getPointerCount()){
          lastX=downX=event.getX(remaining);
          lastY=downY=event.getY(remaining);
        }
        return true;
      }
      if(action==MotionEvent.ACTION_UP){
        if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(false);
        if(!dragged&&!scale.isInProgress()){
          performClick();double best=Double.POSITIVE_INFINITY;JSONArray closest=null;
          for(int i=0;i<points.length();i++){
            JSONArray row=points.optJSONArray(i);if(row==null)continue;
            double dx=x(row.optDouble(1))-event.getX(),dy=y(row.optDouble(0))-event.getY();
            double dist=dx*dx+dy*dy;
            if(dist<best){best=dist;closest=row;}
          }
          if(best<dp(22)*dp(22))selected(closest);
          else detail.setText("No received aircraft at this location. Pinch to zoom and tap a reported marker.");
        }return true;
      }
      if(action==MotionEvent.ACTION_CANCEL){if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(false);return true;}
      return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
  }
}
