package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;
import java.util.Date;
import java.util.TimeZone;
import java.text.SimpleDateFormat;

/** V20: factual, first-screen provider pulse. Never generates artificial readings. */
public final class RunningballV20LiveFeedPulse extends LinearLayout {
  private static final int BG=0xFF0D2030, LINE=0xFF41657B, CYAN=0xFF75DEFA,
    GREEN=0xFF4CD5A8, AMBER=0xFFFFC77F, RED=0xFFFB8691, DIM=0xFFB0C4D1, WHITE=0xFFF0F8FF;
  private static final long[] LIMIT={180000L,7200000L,180000L,1200000L,1200000L,3600000L,2700000L,172800000L,14400000L};
  private static final String[] NAME={"AIRCRAFT","SATELLITES","MARITIME","EARTHQUAKES","NASA EVENTS","WORLD NEWS","WEATHER","USD / EUR","SPACE KP"};
  private static final String[] PROVIDER={"ADSB.LOL / SELECTED 250 NM","CELESTRAK / STATIONS","AIS / PRIVATE GATEWAY","USGS / 24H M2.5+","NASA / OPEN EVENTS","GDELT / ARTICLES","OPEN-METEO / MODEL","FRANKFURTER / DAILY","NOAA / OBSERVED KP"};
  private final Handler main=new Handler(Looper.getMainLooper());
  private final Cell[] cells=new Cell[9];
  private TextView status, sector, sync, activity, ticker;
  private TextView v22Compact;
  private boolean running=false;
  private long lastTap=0;
  private int tickerPointer=0;
  private final Runnable tick=new Runnable(){@Override public void run(){if(!running)return;render();main.postDelayed(this,6500L);}};
  private static final class Cell { final TextView figure, age, meta; final View dot; String last="";
    Cell(TextView f,TextView a,TextView m,View d){figure=f;age=a;meta=m;dot=d;} }
  private static final class Snapshot {String value="--";long stamp=0;String error="",note="";
    Snapshot(String n){note=n;}}
  private int dp(float v){return Math.round(getResources().getDisplayMetrics().density*v);}
  private TextView label(String s,int size,int tint,boolean bold){TextView x=new TextView(getContext());x.setText(s);x.setTextColor(tint);x.setTextSize(size);if(bold)x.setTypeface(null,1);return x;}
  private GradientDrawable panel(int border){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFF102B3C,BG});d.setStroke(dp(1),border);d.setCornerRadius(dp(13));return d;}
  private SharedPreferences p(String store){return getContext().getApplicationContext().getSharedPreferences(store,Context.MODE_PRIVATE);}
  private JSONObject object(String raw){try{return new JSONObject(raw);}catch(Exception ignored){return new JSONObject();}}
  private int number(JSONObject obj,String key){JSONArray a=obj.optJSONArray(key);return a==null?-1:a.length();}
  private int array(String raw){try{return new JSONArray(raw).length();}catch(Exception ignored){return -1;}}
  private static String age(long t){if(t<=0)return "NOT RECEIVED";long mins=Math.max(0,(System.currentTimeMillis()-t)/60000L);
    return mins==0?"<1 MIN":mins<60?mins+" MIN":mins<1440?(mins/60)+" H":(mins/1440)+" DAYS";}
  private static boolean valid(double x){return !Double.isNaN(x)&&!Double.isInfinite(x);}
  private Snapshot load(int i){Context ctx=getContext();Snapshot s=new Snapshot(PROVIDER[i]);
    if(i==0){boolean region=RunningballWorldTarget.ready(ctx);SharedPreferences a=p("air_widget_v2");JSONObject o=object(a.getString("last_snapshot","{}"));
      s.error=a.getString("last_error","");s.note=region?RunningballWorldTarget.label(ctx):"SELECT REGION FIRST";
      if(region){s.stamp=o.optLong("time",0);double lat=o.optDouble("observerLat",Double.NaN),lon=o.optDouble("observerLon",Double.NaN);
        if(!valid(lat)||!valid(lon)||Math.abs(lat-RunningballWorldTarget.lat(ctx))>.001||Math.abs(lon-RunningballWorldTarget.lon(ctx))>.001){s.stamp=0;s.error="PREVIOUS REGION / AWAITING NEW DATA";}
        if(s.stamp>0)s.value=String.valueOf(o.optInt("count",0));}
    }else if(i==1){SharedPreferences a=p("rb10_satellite");s.stamp=a.getLong("data_STATIONS_time",0);int count=array(a.getString("data_STATIONS",""));
      if(s.stamp>0&&count>=0)s.value=String.valueOf(count);s.error=p("rb19_bootstrap").getString("sat_error","");
    }else if(i==2){SharedPreferences a=p("rb11_marine");s.stamp=a.getLong("last_fetch",0);int count=number(object(a.getString("rows","{}")),"rows");
      if(s.stamp>0&&count>=0)s.value=String.valueOf(count);if(a.getString("endpoint","").trim().isEmpty()){s.stamp=0;s.note="AIS GATEWAY REQUIRED";}
    }else if(i==3||i==4){SharedPreferences a=p("rb_global_public_events");String k=i==3?"quakes":"nasa";
      s.stamp=a.getLong(k+"_time",0);int count=number(object(a.getString(k+"_raw","{}")),i==3?"features":"events");
      if(s.stamp>0&&count>=0)s.value=String.valueOf(count);s.error=a.getString(k+"_v16_error","");
      if(i==4)s.note="UP TO 65 RETURNED • NOT WORLD TOTAL";
    }else if(i>=5&&i<=7){SharedPreferences a=p("rb17_verified_feeds");String k=i==5?"news":i==6?"weather":"fx";
      s.stamp=a.getLong(k+"_received",0);JSONObject o=object(a.getString(k+"_json","{}"));s.error=a.getString(k+"_error","");
      if(i==5){int n=number(o,"articles");if(s.stamp>0&&n>=0)s.value=String.valueOf(n);s.note="RETURNED ARTICLES • NOT GLOBAL TOTAL";}
      if(i==6){boolean region=RunningballWorldTarget.ready(ctx);
        String id=region?String.format(Locale.US,"%.4f,%.4f",RunningballWorldTarget.lat(ctx),RunningballWorldTarget.lon(ctx)):"";
        if(!region||!id.equals(o.optString("region",""))){s.stamp=0;s.note=region?"AWAITING CURRENT REGION":"SELECT REGION FIRST";}
        else{double temp=o.optDouble("temperature",Double.NaN);if(s.stamp>0&&valid(temp))s.value=String.format(Locale.US,"%.1f°C",temp);}
      }if(i==7){JSONObject rates=o.optJSONObject("rates");double v=rates==null?Double.NaN:rates.optDouble("EUR",Double.NaN);
        if(s.stamp>0&&valid(v))s.value=String.format(Locale.US,"%.3f",v);s.note="REFERENCE / "+o.optString("date","DATE UNKNOWN");}
    }else if(i==8){s.stamp=RunningballV19Noaa.received(ctx);double k=RunningballV19Noaa.kp(ctx);
      if(s.stamp>0&&valid(k))s.value=String.format(Locale.US,"%.2f",k);s.error=RunningballV19Noaa.error(ctx);
      s.note="KP / "+RunningballV19Noaa.observedTime(ctx);
    }
    return s;
  }
  private View tile(int i){LinearLayout box=new LinearLayout(getContext());box.setOrientation(VERTICAL);
    box.setPadding(dp(12),dp(10),dp(11),dp(10));box.setBackground(panel(LINE));
    LinearLayout head=new LinearLayout(getContext());head.setGravity(Gravity.CENTER_VERTICAL);
    View dot=new View(getContext());GradientDrawable circle=new GradientDrawable();circle.setShape(GradientDrawable.OVAL);circle.setColor(0xFF657B91);dot.setBackground(circle);
    head.addView(dot,new LayoutParams(dp(8),dp(8)));TextView title=label("  "+NAME[i],11,CYAN,true);head.addView(title);box.addView(head);
    TextView value=label("--",22,WHITE,true);LayoutParams val=new LayoutParams(-1,-2);val.topMargin=dp(5);box.addView(value,val);
    TextView note=label("SOURCE NOT LOADED",10,DIM,false);note.setMaxLines(2);box.addView(note);
    TextView age=label("NOT RECEIVED",9,AMBER,false);LayoutParams ap=new LayoutParams(-1,-2);ap.topMargin=dp(7);box.addView(age,ap);
    cells[i]=new Cell(value,age,note,dot);
    box.setOnClickListener(v->openDetail(i));
    return box;
  }
  /** Same stored source readings, never artificial counters. */
  public void bindV22(TextView view){v22Compact=view;render();}
  private void openSource(){getContext().startActivity(new Intent(getContext(),RunningballV19SourceCenterActivity.class));}
  private void openDetail(int index){
    Context c=getContext();
    if((index==0 || index==6) && !RunningballWorldTarget.ready(c)){
      c.startActivity(new Intent(c,RunningballWorldExplorerActivity.class));return;
    }
    Class<?> target;
    switch(index){
      case 0:target=AirRadarActivity.class;break;
      case 1:target=GevSatelliteActivity.class;break;
      case 2:target=GevMarineActivity.class;break;
      case 3:case 4:target=RunningballGlobalEventsActivity.class;break;
      case 5:case 6:case 7:target=RunningballV17DetailsActivity.class;break;
      default:target=RunningballV19SourceCenterActivity.class;break;
    }
    Intent intent=new Intent(c,target);
    if(index==5)intent.putExtra("feed",RunningballV17Feeds.NEWS);
    if(index==6)intent.putExtra("feed",RunningballV17Feeds.WEATHER);
    if(index==7)intent.putExtra("feed",RunningballV17Feeds.FX);
    c.startActivity(intent);
  }
  private static String utc(){
    SimpleDateFormat f=new SimpleDateFormat("HH:mm:ss 'UTC'",Locale.US);
    f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date());
  }
  /** Only changes in authentic source snapshots are recorded. No timer-generated events. */
  private void recordChange(int index, Snapshot snap){
    if(snap.stamp<=0 || "--".equals(snap.value))return;
    Context c=getContext();
    String sector=(index==0 || index==6)?(
      RunningballWorldTarget.ready(c)?String.format(Locale.US,"%.4f,%.4f",
      RunningballWorldTarget.lat(c),RunningballWorldTarget.lon(c)):"NO REGION"):
      "GLOBAL";
    SharedPreferences state=p("rb21_verified_changes");
    String key="feed_"+index;
    long older=state.getLong(key+"_ts",0);
    String previous=state.getString(key+"_value","");
    String lastSector=state.getString(key+"_sector","");
    if(sector.equals(lastSector) && snap.stamp<=older)return;
    SharedPreferences.Editor edit=state.edit();
    edit.putLong(key+"_ts",snap.stamp).putString(key+"_value",snap.value).putString(key+"_sector",sector);
    if(older>0 && sector.equals(lastSector) && !snap.value.equals(previous)){
      String line=NAME[index]+"  "+previous+" → "+snap.value+"  ·  SOURCE UPDATE";
      String previousUpdates=state.getString("updates","");
      String[] rows=(line+"\n"+previousUpdates).split("\\n");
      StringBuilder summary=new StringBuilder();
      for(int i=0;i<Math.min(4,rows.length);i++){
        if(rows[i].isEmpty())continue;
        if(summary.length()>0)summary.append('\n');summary.append(rows[i]);
      }
      edit.putString("updates",summary.toString());
    }
    edit.apply();
  }
  private void pair(View a,View b){LinearLayout row=new LinearLayout(getContext());row.setOrientation(HORIZONTAL);
    LayoutParams l=new LayoutParams(0,-2,1);l.rightMargin=dp(5);row.addView(a,l);
    LayoutParams r=new LayoutParams(0,-2,1);r.leftMargin=dp(5);row.addView(b,r);
    LayoutParams rp=new LayoutParams(-1,-2);rp.topMargin=dp(8);addView(row,rp);}
  public RunningballV20LiveFeedPulse(Context c){super(c);setOrientation(VERTICAL);
    setPadding(dp(2),dp(11),dp(2),dp(11));
    addView(label("V21  /  WORLD OPERATIONS INTELLIGENCE",11,GREEN,true));
    TextView heading=label("WORLD SOURCE ACTIVITY",19,WHITE,true);LayoutParams hp=new LayoutParams(-1,-2);hp.topMargin=dp(4);addView(heading,hp);
    sector=label("WORLDWIDE / REGION NOT SELECTED",11,AMBER,true);LayoutParams sp=new LayoutParams(-1,-2);sp.topMargin=dp(7);addView(sector,sp);
    status=label("READINGS UPDATE ONLY WHEN SOURCES REPORT",10,DIM,false);addView(status);
    TextView chooseRegion=label("⌖  CHOOSE WORLD REGION  /  AIR AND WEATHER",12,CYAN,true);
    chooseRegion.setGravity(Gravity.CENTER);chooseRegion.setPadding(dp(10),dp(13),dp(10),dp(13));
    chooseRegion.setBackground(panel(CYAN));
    LayoutParams rp=new LayoutParams(-1,-2);rp.topMargin=dp(9);addView(chooseRegion,rp);
    chooseRegion.setOnClickListener(v->getContext().startActivity(new Intent(getContext(),RunningballWorldExplorerActivity.class)));
    ticker=label("AWAITING SOURCE REPORTS",11,CYAN,true);
    ticker.setPadding(dp(10),dp(13),dp(10),dp(13));ticker.setBackground(panel(LINE));
    LayoutParams tp=new LayoutParams(-1,-2);tp.topMargin=dp(9);addView(ticker,tp);
    ticker.setOnClickListener(v->openSource());
    activity=label("RECENT VERIFIED CHANGES  /  AWAITING NEW SOURCE VALUES",10,DIM,false);
    activity.setPadding(dp(9),dp(12),dp(9),dp(12));
    LayoutParams alp=new LayoutParams(-1,-2);alp.topMargin=dp(8);addView(activity,alp);
    for(int i=0;i<8;i+=2)pair(tile(i),tile(i+1));
    LayoutParams lp=new LayoutParams(-1,-2);lp.topMargin=dp(8);addView(tile(8),lp);
    sync=label("↻  REFRESH SOURCES  /  RESPECT PROVIDER LIMITS",12,GREEN,true);
    sync.setGravity(Gravity.CENTER);sync.setPadding(dp(8),dp(14),dp(8),dp(14));sync.setBackground(panel(GREEN));
    LayoutParams bp=new LayoutParams(-1,-2);bp.topMargin=dp(10);addView(sync,bp);
    sync.setOnClickListener(v->{long now=System.currentTimeMillis();if(now-lastTap<90000L){status.setText("REFRESH COOLDOWN / 90 SECONDS");return;}
      lastTap=now;status.setText("SOURCE REQUESTS ISSUED / CURRENT LIMITS STILL APPLY");refresh(true);});
    TextView detail=label("OPEN FULL PROVIDER HEALTH & ERRORS   ›",11,CYAN,true);detail.setPadding(dp(9),dp(13),0,dp(7));
    addView(detail);detail.setOnClickListener(v->openSource());
    render();
  }
  private void refresh(boolean manual){Context app=getContext().getApplicationContext();Runnable redraw=()->{if(running)render();};
    RunningballV16SourceRefresh.request(app,false,redraw); // no unbounded 'force' refreshes
    RunningballV17Feeds.request(app,false,redraw);
    RunningballV19SatelliteBootstrap.request(app,redraw);
    RunningballV19Noaa.request(app,redraw);
    if(RunningballWorldTarget.ready(app)){Intent i=new Intent(app,AirOperationsWidgets.Pulse.class);
      i.setAction("com.sentongoharuna.worldsituationroom.AIR_WIDGET_REFRESH");i.setPackage(app.getPackageName());app.sendBroadcast(i);}
  }
  public void start(){if(running)return;running=true;render();
    // Give first-screen layout and Pixel Launcher time to settle before network work.
    main.postDelayed(()->{if(running)refresh(false);},4000L);
    main.postDelayed(tick,6500L);
  }
  public void stop(){running=false;main.removeCallbacks(tick);}
  public void render(){int recent=0,stale=0,missing=0;Context ctx=getContext();
    sector.setText(RunningballWorldTarget.ready(ctx)?"SELECTED SECTOR  /  "+RunningballWorldTarget.label(ctx):"GLOBAL SOURCES / SELECT WORLD REGION FOR AIR & WEATHER");
    for(int i=0;i<cells.length;i++){Cell c=cells[i];Snapshot v=load(i);long now=System.currentTimeMillis();
      boolean usable=v.stamp>0&&!"--".equals(v.value);boolean old=usable&&now-v.stamp>LIMIT[i];boolean error=!v.error.isEmpty();
      if(!usable)missing++;else if(old||error)stale++;else recent++;
      String category=!usable?"NO VERIFIED DATA":error?"FETCH FAILED / CACHED":old?"STALE / CACHED":"RECENT REPORT";
      int tint=!usable||old?AMBER:error?RED:GREEN;
      if(!c.last.isEmpty()&&!c.last.equals(v.value)&&!"--".equals(v.value)&&running){
        c.figure.animate().cancel();c.figure.setAlpha(.45f);c.figure.animate().alpha(1f).setDuration(420).start();}
      recordChange(i,v);c.last=v.value;c.figure.setText(v.value);c.meta.setText(v.note);c.age.setText(category+"  ·  "+age(v.stamp)+(error?"  ·  ERROR":""));c.age.setTextColor(tint);
      GradientDrawable circle=new GradientDrawable();circle.setShape(GradientDrawable.OVAL);circle.setColor(usable&&!old&&!error?GREEN:usable&&error?RED:0xFF71869B);c.dot.setBackground(circle);
    }
    status.setText(recent+" RECENT  /  "+stale+" STALE OR FAILED  /  "+missing+" NOT LOADED  •  NO DEMO COUNTS");
    if(v22Compact!=null){
      v22Compact.setText("V22 / WORLD STATUS   "+recent+" RECENT  ·  "+stale+" DELAYED  ·  "+missing+" UNAVAILABLE\nTAP FOR ALL NINE PROVIDERS / ACTUAL REPORTS ONLY");
      v22Compact.setTextColor(recent>0?GREEN:AMBER);
    }
    int index=tickerPointer%NAME.length;
    Snapshot latest=load(index);
    String state=latest.stamp<=0||"--".equals(latest.value)?"NO VERIFIED REPORT":
      !latest.error.isEmpty()?"SOURCE ERROR / CACHED":
      System.currentTimeMillis()-latest.stamp>LIMIT[index]?"STALE / CACHED":"RECENT REPORT";
    ticker.setText("◉  "+utc()+"  /  "+NAME[index]+"  "+latest.value+"  /  "+state+"  /  "+age(latest.stamp));
    tickerPointer=(tickerPointer+1)%NAME.length;
    String updates=p("rb21_verified_changes").getString("updates","");
    activity.setText(updates.isEmpty()?"RECENT VERIFIED CHANGES  /  NO CHANGED VALUES":
      "LATEST VERIFIED SOURCE CHANGES\n"+updates);
  }
  @Override protected void onDetachedFromWindow(){stop();super.onDetachedFromWindow();}
}
