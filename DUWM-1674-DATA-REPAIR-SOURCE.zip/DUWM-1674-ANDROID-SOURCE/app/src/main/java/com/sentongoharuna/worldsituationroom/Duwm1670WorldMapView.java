package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import org.json.JSONArray;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/** Geographic map of actual observed objects. Smooth transitions are between two source reports only.
 * Country borders are WDBII/Global Self-consistent Hierarchical High-resolution Geography data,
 * NOT simulated political boundaries. A country pin is an approximate capital reference, not an event.
 */
public final class Duwm1670WorldMapView extends View {
  public static final class Pin {
    public String id, title, type, detail;
    public final double lat,lon;
    public final long observed;
    public double prevLat=Double.NaN,prevLon=Double.NaN;
    public long prevObserved;
    public double speed=Double.NaN,heading=Double.NaN,altitude=Double.NaN;
    public Pin(String id,String title,String type,double lat,double lon,long when,String detail){
      this.id=id;this.title=title;this.type=type;this.lat=lat;this.lon=lon;this.observed=when;this.detail=detail;
    }
    public boolean genuinePair(){return Double.isFinite(prevLat)&&Double.isFinite(prevLon)&&prevObserved>0&&
      observed>prevObserved&&observed-prevObserved<=5400000L&&Duwm1674TimeGuard.recent(observed,21600000L)&&
      (Math.abs(lat-prevLat)>0.00001d||Math.abs(lon-prevLon)>0.00001d);}
  }
  public interface OnPinSelected {void selected(Pin pin);}
  private final ArrayList<float[]> border=new ArrayList<>();
  private final ArrayList<Pin> pins=new ArrayList<>();
  private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
  private final ScaleGestureDetector detector;
  private OnPinSelected listener;
  private float zoom=1f,panX=0,panY=0,lastX,lastY,downX,downY;
  private boolean moving=false,dragged=false;
  private String selectedId="";
  private long animationStarted=0L;
  private int lastPaintedPins=0;
  private boolean playing=false;
  private String layer="AIRCRAFT";
  private int transitionPairs;
  private boolean scenarioVisible;
  private double scenarioLat,scenarioLon;
  private String scenarioName="";
  public void setScenarioDestination(double lat,double lon,String label){
    scenarioVisible=Double.isFinite(lat)&&Double.isFinite(lon)&&label!=null&&!label.isEmpty();
    scenarioLat=lat;scenarioLon=lon;scenarioName=label==null?"":label;invalidate();
  }
  public void clearScenario(){scenarioVisible=false;invalidate();}
  private static final int INK=0xFFB8E6EB,WHITE=0xFFF4FCFF,GRID=0xFF244B65;
  private int dp(float v){return Math.round(getResources().getDisplayMetrics().density*v);}
  public Duwm1670WorldMapView(Context c){super(c);
    detector=new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
      @Override public boolean onScale(ScaleGestureDetector d){zoom=Math.max(1f,Math.min(8f,zoom*d.getScaleFactor()));invalidate();return true;}
    });loadBorders();setContentDescription("Actual geopolitical country borders. Only real data markers; two-fix animated transitions are not a predicted future location.");
    setLayer("AIRCRAFT");
  }
  private void loadBorders(){
    try(BufferedReader r=new BufferedReader(new InputStreamReader(getContext().getAssets().open("duwm_country_borders_wdbii.txt"),"UTF-8"))){
      String line;while((line=r.readLine())!=null){String[] pairs=line.split(" ");if(pairs.length<2)continue;
        float[] out=new float[pairs.length*2];int n=0;
        for(String pair:pairs){String[] q=pair.split(",");if(q.length!=2)continue;
          try{float lat=Float.parseFloat(q[0]),lon=Float.parseFloat(q[1]);if(Math.abs(lat)<=90&&Math.abs(lon)<=180){out[n++]=lon;out[n++]=lat;}}
          catch(NumberFormatException ignore){} }
        if(n>=4){float[] valid=new float[n];System.arraycopy(out,0,valid,0,n);border.add(valid);}
      }
    }catch(Exception e){/* Do not generate fake borders when geography cannot load. */}
  }
  public int borderSegmentCount(){return border.size();}
  public void setLayer(String type){layer=type;invalidate();}
  public void setOnPinSelected(OnPinSelected callback){listener=callback;}
  public void setPins(List<Pin> data,boolean newReport){
    pins.clear();transitionPairs=0;
    if(data!=null)for(Pin p:data){if(p==null||!Double.isFinite(p.lat)||!Double.isFinite(p.lon)||
      Math.abs(p.lat)>90||Math.abs(p.lon)>180)continue;
      pins.add(p);if(p.genuinePair())transitionPairs++;
    }
    if(newReport&&transitionPairs>0){animationStarted=SystemClock.uptimeMillis();playing=true;}
    else if(newReport)playing=false; // Keep a running two-fix transition alive across UI redraws.

    invalidate();
  }
  public int pointCount(){return pins.size();}
  public int observedPairCount(){return transitionPairs;}
  public void setSelected(String id){selectedId=id==null?"":id;invalidate();}
  public void focus(double lat,double lon,float newZoom){
    if(!Double.isFinite(lat)||!Double.isFinite(lon))return;
    zoom=Math.max(1f,Math.min(8f,newZoom));
    panX=-(float)(lon/360d)*getWidth()*zoom;
    panY=(float)(lat/180d)*getHeight()*zoom;
    invalidate();
  }
  public void reset(){zoom=1f;panX=panY=0;invalidate();}
  public void resume(){moving=true;postInvalidateDelayed(90L);}
  public void pause(){moving=false;}
  @Override protected void onDetachedFromWindow(){pause();super.onDetachedFromWindow();}
  private float x(double lon){return getWidth()/2f+(float)(lon/360d*getWidth()*zoom)+panX;}
  private float y(double lat){return getHeight()/2f-(float)(lat/180d*getHeight()*zoom)+panY;}
  private float progress(){if(!playing)return 1f;
    float v=Math.min(1f,(SystemClock.uptimeMillis()-animationStarted)/15000f);
    if(v>=1f){playing=false;return 1f;}
    return v*v*(3f-2f*v);
  }
  private int color(Pin pin){switch(pin.type){
    case "AIRCRAFT":return 0xFF58DCEB;
    case "VESSEL":return 0xFF60D6B8;
    case "NEWS":return 0xFFE9BE75;
    case "EARTHQUAKE":return 0xFFFF9677;
    case "ISS":return 0xFFDDD6FF;
    default:return 0xFFA0CDE1;}}
  @Override protected void onDraw(Canvas c){super.onDraw(c);
    int w=getWidth(),h=getHeight();if(w<1||h<1)return;
    paint.setShader(new LinearGradient(0,0,0,h,0xFF0B263C,0xFF030B13,Shader.TileMode.CLAMP));
    c.drawRect(0,0,w,h,paint);paint.setShader(null);
    c.save();c.clipRect(0,0,w,h);
    paint.setStrokeWidth(dp(.65f));paint.setColor(GRID);paint.setStyle(Paint.Style.STROKE);
    for(int lon=-180;lon<=180;lon+=30)c.drawLine(x(lon),0,x(lon),h,paint);
    for(int lat=-60;lat<=60;lat+=30)c.drawLine(0,y(lat),w,y(lat),paint);
    paint.setStrokeWidth(dp(2.1f));paint.setColor(0x5522BCCF);
    for(float[] line:border)strokeBorder(c,line);
    paint.setStrokeWidth(dp(.85f));paint.setColor(0xFF7ABEC7);
    for(float[] line:border)strokeBorder(c,line);
    // An explicitly selected airport can be displayed as an estimated direct-line
    // scenario. Never display it as this aircraft's actual filed route.
    if(scenarioVisible){
      for(Pin selected:pins)if(selected.id.equals(selectedId)){
        paint.setStrokeWidth(dp(1.5f));paint.setStyle(Paint.Style.STROKE);paint.setColor(0xDDFFD49A);
        paint.setPathEffect(new android.graphics.DashPathEffect(new float[]{dp(7),dp(7)},0));
        c.drawLine(x(selected.lon),y(selected.lat),x(scenarioLon),y(scenarioLat),paint);
        paint.setPathEffect(null);break;
      }
      paint.setStyle(Paint.Style.FILL);paint.setColor(0xFFFFD7A0);
      c.drawCircle(x(scenarioLon),y(scenarioLat),dp(5),paint);
      paint.setTextSize(dp(11));String lab="SCENARIO: "+scenarioName;
      c.drawText(lab,x(scenarioLon)+dp(7),y(scenarioLat)-dp(7),paint);
    }
    long now=SystemClock.uptimeMillis();float t=progress();
    float pulse=(float)Math.sin(now/420d);
    // No fixed 2500-item clipping: every received pin is considered.
    // At wide zoom overlapping marks are de-cluttered by screen pixel cells,
    // so the CPU budget tracks actual visible geography rather than array order.
    int cellsAcross=Math.max(1,(w+dp(13)-1)/dp(13));
    int cellsDown=Math.max(1,(h+dp(13)-1)/dp(13));
    boolean[] occupied=new boolean[Math.min(1000000,cellsAcross*cellsDown)];
    int shown=0;
    for(Pin pin:pins){
      boolean hasPair=pin.genuinePair();
      double a=hasPair?pin.prevLat+(pin.lat-pin.prevLat)*t:pin.lat;
      double b=hasPair?pin.prevLon+(pin.lon-pin.prevLon)*t:pin.lon;
      float px=x(b),py=y(a);if(px< -35||px>w+35||py< -35||py>h+35)continue;
      boolean focused=pin.id.equals(selectedId);
      if(!focused&&zoom<2.6f&&cellsAcross*cellsDown<=occupied.length){
        int cellX=Math.max(0,Math.min(cellsAcross-1,(int)(px/dp(13))));
        int cellY=Math.max(0,Math.min(cellsDown-1,(int)(py/dp(13))));
        int key=cellY*cellsAcross+cellX;
        if(occupied[key])continue;
        occupied[key]=true;
      }
      shown++;
      if(hasPair){
        paint.setColor(0x8850D8D8);paint.setStrokeWidth(dp(1.25f));paint.setStyle(Paint.Style.STROKE);
        c.drawLine(x(pin.prevLon),y(pin.prevLat),x(pin.lon),y(pin.lat),paint);
      }
      int cl=color(pin);float size=dp(focused?7f:3.2f);paint.setStyle(Paint.Style.FILL);
      paint.setColor(cl);c.drawCircle(px,py,size,paint);
      if(focused){paint.setStyle(Paint.Style.STROKE);paint.setColor(0xFFC6FAFF);paint.setStrokeWidth(dp(1.5f));
        c.drawCircle(px,py,dp(13f)+dp(2)*pulse,paint);
        paint.setStyle(Paint.Style.FILL);paint.setColor(WHITE);paint.setTextSize(dp(12));
        String name=pin.title.length()>19?pin.title.substring(0,19):pin.title;
        c.drawText(name,px+dp(14),py-dp(7),paint);
      }
      if(pin.type.equals("AIRCRAFT")&&Double.isFinite(pin.heading)&&!focused){
        double hrad=Math.toRadians(pin.heading);paint.setColor(cl);paint.setStrokeWidth(dp(1.2f));paint.setStyle(Paint.Style.STROKE);
        c.drawLine(px,py,px+(float)Math.sin(hrad)*dp(8),py-(float)Math.cos(hrad)*dp(8),paint);
      }
    }
    lastPaintedPins=shown;
    c.restore();paint.setStyle(Paint.Style.FILL);paint.setColor(INK);paint.setTextSize(dp(11));
    c.drawText("GEOGRAPHIC BORDERS  /  "+layer+"  /  "+pins.size()+" VERIFIED PINS  /  "+lastPaintedPins+" VISIBLE",dp(10),dp(19),paint);
    if(pins.isEmpty()){paint.setColor(0xFF9FBAC8);paint.setTextSize(dp(13));c.drawText("NO RECEIVED POSITIONS FOR THIS LAYER",dp(12),h/2f,paint);}
    if(transitionPairs>0){paint.setColor(0xFFD4D5A6);paint.setTextSize(dp(10));
      c.drawText((playing?"ANIMATED TRANSITION":"TWO VERIFIED FIXES")+"  /  "+transitionPairs+" PAIRS  /  NOT PREDICTION",dp(8),h-dp(10),paint);
    }
    if(moving)postInvalidateDelayed(100L); // rings/transition only; no fake data position movement
  }
  private void strokeBorder(Canvas c,float[] data){
    Path p=new Path();boolean started=false;float lastX=0;
    for(int i=0;i<data.length;i+=2){float px=x(data[i]),py=y(data[i+1]);
      if(!started||Math.abs(px-lastX)>getWidth()*zoom*.40f){p.moveTo(px,py);started=true;}
      else p.lineTo(px,py);lastX=px;
    }c.drawPath(p,paint);
  }
  @Override public boolean onTouchEvent(MotionEvent e){detector.onTouchEvent(e);switch(e.getActionMasked()){
    case MotionEvent.ACTION_DOWN:lastX=downX=e.getX();lastY=downY=e.getY();dragged=false;return true;
    case MotionEvent.ACTION_MOVE:
      if(e.getPointerCount()==1&&!detector.isInProgress()){
        if(Math.abs(e.getX()-downX)>dp(6)||Math.abs(e.getY()-downY)>dp(6))dragged=true;
        if(dragged){panX+=e.getX()-lastX;panY+=e.getY()-lastY;invalidate();}
        lastX=e.getX();lastY=e.getY();}return true;
    case MotionEvent.ACTION_UP:
      if(!dragged&&!detector.isInProgress()){
        Pin nearest=null;float distance=dp(25);
        for(Pin pin:pins){float dx=e.getX()-x(pin.lon),dy=e.getY()-y(pin.lat);float d=(float)Math.hypot(dx,dy);
          if(d<distance){distance=d;nearest=pin;}}
        if(nearest!=null){setSelected(nearest.id);if(listener!=null)listener.selected(nearest);}}
      performClick();return true;
  }return true;}
  @Override public boolean performClick(){super.performClick();return true;}
}
