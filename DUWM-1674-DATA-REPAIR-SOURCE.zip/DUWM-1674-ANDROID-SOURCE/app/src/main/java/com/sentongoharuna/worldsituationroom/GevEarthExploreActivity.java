package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.LinkedHashMap;
import java.util.Locale;

/** GEV Port 03: native location explorer reuses the protected SatelliteMapView.
 * Current map is native 2D tile / orthographic globe, NOT Cesium 3D terrain.
 * Unlike globe renderer, this separate activity has no impact on wallpaper animation.
 */
public final class GevEarthExploreActivity extends Activity implements SatelliteMapView.Listener {
    private static final int BG=Color.rgb(7,11,19),PANEL=Color.rgb(16,25,36);
    private static final int CYAN=Color.rgb(113,224,240),LIGHT=Color.rgb(235,245,250);
    private static final int MUTED=Color.rgb(145,169,184),AMBER=Color.rgb(251,192,108);
    private static final String PREF="gev_earth_explore_v9";
    private static final String[] CITY={"Kampala","Entebbe","Jinja","Nairobi","Mombasa","Kigali","Bujumbura","Dar es Salaam","Dodoma","Arusha","Addis Ababa","Cairo","Dubai","London","Paris","New York","Tokyo","Singapore","Johannesburg","Riyadh"};
    private static final double[][] COORD={{.3476,32.5825},{.052,32.463},{.425,33.204},{-1.2864,36.8172},{-4.0435,39.6682},{-1.9441,30.0619},{-3.3822,29.3644},{-6.7924,39.2083},{-6.163,35.7516},{-3.3869,36.683},{9.03,38.74},{30.0444,31.2357},{25.2048,55.2708},{51.5072,-.1276},{48.8566,2.3522},{40.7128,-74.006},{35.6762,139.6503},{1.3521,103.8198},{-26.2041,28.0473},{24.7136,46.6753}};
    private SatelliteMapView map;
    private EditText search;
    private TextView readout, mode, status;
    private String label="WORLD OVERVIEW";
    private double savedLat=0.0d, savedLon=0.0d;
    private int dp(float v){return Math.round(getResources().getDisplayMetrics().density*v);}
    private GradientDrawable card(boolean accent){GradientDrawable d=new GradientDrawable();d.setColor(PANEL);d.setCornerRadius(dp(17));d.setStroke(dp(1.2f),accent?CYAN:Color.rgb(60,91,110));return d;}
    private TextView text(String s,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(sp);t.setGravity(Gravity.CENTER_VERTICAL);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private TextView button(String s,Runnable action){TextView v=text(s,11,CYAN,true);v.setGravity(Gravity.CENTER);v.setBackground(card(false));v.setPadding(dp(6),dp(8),dp(6),dp(8));v.setOnClickListener(w->action.run());return v;}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onCreate(Bundle state){super.onCreate(state);RunningballV17Insets.install(this);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        LinearLayout root=new LinearLayout(this);root.setBackgroundColor(BG);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(10),dp(10),dp(10),dp(10));
        root.addView(text("RUNNINGBALL2  /  GOD'S EYE VIEW PORT 03",11,CYAN,true),new LinearLayout.LayoutParams(-1,dp(25)));
        root.addView(text("EARTH EXPLORER  /  WORLDWIDE",22,LIGHT,true),new LinearLayout.LayoutParams(-1,dp(39)));
        root.addView(button("SET AIRCRAFT TARGET ANYWHERE",()->startActivity(new Intent(this,RunningballWorldExplorerActivity.class))),new LinearLayout.LayoutParams(-1,dp(37)));
        status=text("NATIVE EARTH  •  LOCAL COORDINATES  •  AVAILABLE TILES",10,MUTED,false);
        root.addView(status,new LinearLayout.LayoutParams(-1,dp(26)));
        TextView satellites=button("SATELLITES / ORBITAL INTELLIGENCE",()->startActivity(new Intent(this,GevSatelliteActivity.class)));
        LinearLayout.LayoutParams satp=new LinearLayout.LayoutParams(-1,dp(40));satp.topMargin=dp(4);root.addView(satellites,satp);
        TextView marine=button("MARITIME / AIS CONTACTS",()->startActivity(new Intent(this,GevMarineActivity.class)));
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(40));mp.topMargin=dp(4);root.addView(marine,mp);
        LinearLayout find=new LinearLayout(this);find.setOrientation(LinearLayout.HORIZONTAL);
        search=new EditText(this);search.setSingleLine(true);search.setTextSize(14);search.setTextColor(LIGHT);search.setHintTextColor(MUTED);search.setHint("City or geo:0.3476,32.5825");search.setInputType(InputType.TYPE_CLASS_TEXT);search.setPadding(dp(13),0,dp(13),0);search.setBackground(card(false));
        find.addView(search,new LinearLayout.LayoutParams(0,dp(45),1f));
        TextView go=button("GO",this::searchLocation);LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(dp(55),dp(45));gp.leftMargin=dp(6);find.addView(go,gp);
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,dp(45));fp.topMargin=dp(6);root.addView(find,fp);
        HorizontalScrollView strip=new HorizontalScrollView(this);strip.setHorizontalScrollBarEnabled(false);
        LinearLayout chips=new LinearLayout(this);chips.setOrientation(LinearLayout.HORIZONTAL);
        for(int i=0;i<8;i++){final int k=i;TextView c=button(CITY[i].toUpperCase(Locale.US),()->flyCity(k));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(36));lp.rightMargin=dp(6);chips.addView(c,lp);}
        strip.addView(chips);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(36));sp.topMargin=dp(9);root.addView(strip,sp);
        FrameLayout mapFrame=new FrameLayout(this);mapFrame.setBackgroundColor(BG);
        map=new SatelliteMapView(this);map.setListener(this);mapFrame.addView(map,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout overlay=new LinearLayout(this);overlay.setOrientation(LinearLayout.VERTICAL);overlay.setPadding(dp(12),dp(7),dp(12),dp(7));overlay.setBackground(card(true));
        readout=text("WORLD VIEW  /  0.00000, 0.00000",11,LIGHT,true);overlay.addView(readout);
        mode=text("3D GLOBE VIEW  •  MOVE & PINCH TO NAVIGATE",10,MUTED,false);overlay.addView(mode);
        FrameLayout.LayoutParams op=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);op.setMargins(dp(5),0,dp(5),dp(8));mapFrame.addView(overlay,op);
        LinearLayout.LayoutParams mapLp=new LinearLayout.LayoutParams(-1,0,1f);mapLp.topMargin=dp(7);root.addView(mapFrame,mapLp);
        LinearLayout tool=new LinearLayout(this);tool.setOrientation(LinearLayout.HORIZONTAL);
        String[] names={"−","+","GLOBE","MAP","CITIES"};
        Runnable[] actions={()->{map.zoomBy(-1);update();},()->{map.zoomBy(1);update();},()->{map.setGlobeMode(true);update();},()->{map.setGlobeMode(false);if(map.getZoom()<4.5)map.setCenter(map.getCenterLatitude(),map.getCenterLongitude(),5.5);update();},this::pickCity};
        for(int i=0;i<names.length;i++){TextView b=button(names[i],actions[i]);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(42),1f);lp.leftMargin=i>0?dp(5):0;tool.addView(b,lp);}
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,dp(42));tp.topMargin=dp(8);root.addView(tool,tp);
        LinearLayout bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);
        String[] nav={"SAVE VIEW","SAVED","RESET","SHARE CARD"};
        Runnable[] acts={this::saveView,this::openSaved,()->{map.setGlobeMode(true);map.setCenter(0.0d,0.0d,2.1d);label="WORLD OVERVIEW";update();},this::share};
        for(int i=0;i<nav.length;i++){TextView b=button(nav[i],acts[i]);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(43),1f);lp.leftMargin=i>0?dp(5):0;bar.addView(b,lp);}
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(43));bp.topMargin=dp(6);root.addView(bar,bp);
        root.addView(text("SATELLITE / MAP TILES DEPEND ON SOURCE AVAILABILITY  •  NO LIVE VIDEO",9,MUTED,false),new LinearLayout.LayoutParams(-1,dp(22)));
        setContentView(root);
        if(getIntent().hasExtra("geo_lat")&&getIntent().hasExtra("geo_lon")){
            double a=getIntent().getDoubleExtra("geo_lat",Double.NaN),b=getIntent().getDoubleExtra("geo_lon",Double.NaN);
            if(GevEarthCoordinates.valid(a,b))move(a,b,6.0,getIntent().getBooleanExtra("marine_observed",false)?"REPORTED VESSEL POSITION / "+getIntent().getStringExtra("marine_name"):getIntent().getBooleanExtra("satellite_estimated",false)?"ESTIMATED SATELLITE SUBPOINT / "+getIntent().getStringExtra("satellite_name"):"REPORTED AIRCRAFT POSITION");else initial();
        }else initial();
    }
    private void initial(){SharedPreferences p=getSharedPreferences(PREF,MODE_PRIVATE);
        double a=Double.longBitsToDouble(p.getLong("lat",Double.doubleToLongBits(0.0d))),b=Double.longBitsToDouble(p.getLong("lon",Double.doubleToLongBits(0.0d)));
        double zoom=Double.longBitsToDouble(p.getLong("zoom",Double.doubleToLongBits(2.25d)));
        if(!GevEarthCoordinates.valid(a,b)||!Double.isFinite(zoom)) {a=0.0d;b=0.0d;zoom=2.1d;}
        map.setGlobeMode(zoom<3.5);map.setCenter(a,b,zoom);label=p.getString("label","WORLD OVERVIEW");update();
    }
    private void move(double a,double b,double zoom,String title){map.setCenter(a,b,zoom);label=title;update();}
    private void flyCity(int i){if(i<0||i>=CITY.length)return;move(COORD[i][0],COORD[i][1],6.0,CITY[i].toUpperCase(Locale.US)+" (CITY CENTER)");}
    private void pickCity(){new AlertDialog.Builder(this).setTitle("CITY CENTER SHORTCUTS").setItems(CITY,(d,i)->flyCity(i)).show();}
    private void searchLocation(){String q=search.getText().toString().trim();if(q.isEmpty()){toast("Enter coordinates or a city name");return;}
        GevEarthCoordinates.Point coords=GevEarthCoordinates.parse(q);
        if(coords!=null){move(coords.lat,coords.lon,7.0,"COORDINATE SEARCH");hideKeyboard();return;}
        for(int i=0;i<CITY.length;i++){if(CITY[i].equalsIgnoreCase(q)){flyCity(i);hideKeyboard();return;}}
        toast("Unknown city. Choose CITIES or enter valid lat,lon coordinates.");
    }
    private void hideKeyboard(){try{((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(search.getWindowToken(),0);}catch(Exception ignored){}search.clearFocus();}
    private void update(){if(map==null||readout==null)return;
        double lat=map.getCenterLatitude(),lon=map.getCenterLongitude();savedLat=lat;savedLon=lon;
        readout.setText(label+"\n"+String.format(Locale.US,"%.5f, %.5f",lat,lon));
        mode.setText((map.isGlobeMode()?"GLOBE":"DETAILED MAP")+"   •   ZOOM "+String.format(Locale.US,"%.1f",map.getZoom())+"   •   DRAG / PINCH");
    }
    @Override public void onViewportChanged(SatelliteMapView.Bounds bounds){update();}
    @Override public void onSignalTap(Signal s){if(s!=null)toast("SELECTED: "+s.title);}
    private JSONArray listSaved(){try{return new JSONArray(getSharedPreferences(PREF,MODE_PRIVATE).getString("saved","[]"));}catch(Exception e){return new JSONArray();}}
    private void saveView(){JSONArray all=listSaved();JSONObject item=new JSONObject();try{
            item.put("label",label);item.put("lat",map.getCenterLatitude());item.put("lon",map.getCenterLongitude());item.put("zoom",map.getZoom());
            JSONArray out=new JSONArray();out.put(item);for(int i=0;i<Math.min(all.length(),11);i++)out.put(all.getJSONObject(i));
            getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("saved",out.toString()).apply();toast("VIEW SAVED");
        }catch(Exception e){toast("Unable to save view");}}
    private void openSaved(){JSONArray all=listSaved();if(all.length()==0){toast("No saved views");return;}
        String[] labels=new String[all.length()];for(int i=0;i<labels.length;i++){
            JSONObject o=all.optJSONObject(i);labels[i]=o==null?"Unavailable":o.optString("label","SAVED VIEW")+" / "+o.optString("lat","")+", "+o.optString("lon","");}
        new AlertDialog.Builder(this).setTitle("SAVED EARTH VIEWS").setItems(labels,(d,i)->{
            JSONObject o=all.optJSONObject(i);if(o==null)return;double a=o.optDouble("lat",Double.NaN),b=o.optDouble("lon",Double.NaN);
            if(!GevEarthCoordinates.valid(a,b)){toast("Invalid saved coordinates");return;}
            double z=o.optDouble("zoom",6d);map.setGlobeMode(z<3.5);move(a,b,z,o.optString("label","SAVED VIEW"));
        }).show();}
    private void share(){double a=map.getCenterLatitude(),b=map.getCenterLongitude();
        if(!GevEarthCoordinates.valid(a,b)){toast("Location unavailable");return;}
        LinkedHashMap<String,String> info=new LinkedHashMap<>();
        info.put("LATITUDE",String.format(Locale.US,"%.5f°",a));info.put("LONGITUDE",String.format(Locale.US,"%.5f°",b));
        info.put("ZOOM",String.format(Locale.US,"%.1f",map.getZoom()));info.put("PROJECTION",map.isGlobeMode()?"GLOBE":"MAP");
        info.put("POINT TYPE",label.contains("AIRCRAFT")?"LAST REPORTED AIRCRAFT COORDINATE":"MAP CENTER");
        ShareCardRenderer.share(this,new ShareCardData(
             "EARTH VIEW / "+label,"Shared Earth viewpoint. This does not establish live conditions at that location.",
             "MAP VIEW","NOT LIVE DATA","GEOGRAPHY",label,1,"RUNNINGBALL2 NATIVE MAP","",System.currentTimeMillis(),
             a,b,info,CYAN,"Map image tiles and detail depend on third-party map availability; position is a selected map center."));
    }
    @Override protected void onPause(){super.onPause();if(map!=null&&GevEarthCoordinates.valid(savedLat,savedLon))
        getSharedPreferences(PREF,MODE_PRIVATE).edit().putLong("lat",Double.doubleToLongBits(savedLat)).putLong("lon",Double.doubleToLongBits(savedLon))
        .putLong("zoom",Double.doubleToLongBits(map.getZoom())).putString("label",label).apply();}
}
