package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Build;
import android.view.WindowInsets;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;
import org.json.JSONArray;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Live source audit: the value and its actual origin, error and age appear together. */
public final class RunningballV19SourceCenterActivity extends Activity {
  private static final int BG=0xFF07121D,INK=0xFFE8F4FF,DIM=0xFF9EAEC2;
  private static final int GREEN=0xFF50DEAC, CYAN=0xFF63D5ED, AMBER=0xFFFFBF6A, RED=0xFFFF8790;
  private final Handler ui=new Handler(Looper.getMainLooper());
  private LinearLayout board;private TextView top;
  private boolean visible=false;private long lastManualRefresh=0L;
  private final Runnable redraw=new Runnable(){@Override public void run(){if(!visible)return;render();ui.postDelayed(this,9000L);}};
  private int dp(float f){return Math.round(getResources().getDisplayMetrics().density*f);}
  private TextView label(String s,int size,int tint,boolean strong){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(tint);if(strong)t.setTypeface(null,1);return t;}
  private GradientDrawable shape(int tint){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
      new int[]{0xFF132838,0xFF0A1826});g.setCornerRadius(dp(14));g.setStroke(dp(1),tint);return g;}
  private SharedPreferences pref(String name){return getSharedPreferences(name,Context.MODE_PRIVATE);}
  private static JSONObject json(String raw){try{return new JSONObject(raw);}catch(Exception e){return new JSONObject();}}
  private static int count(JSONObject obj,String field){JSONArray arr=obj.optJSONArray(field);return arr==null?-1:arr.length();}
  private static int countArray(String raw){try{return new JSONArray(raw).length();}catch(Exception e){return -1;}}
  private static String age(long t){if(t<=0)return "NEVER RECEIVED";long m=Math.max(0,(System.currentTimeMillis()-t)/60000L);
    return m<1?"<1 MIN AGO":m<60?m+" MIN AGO":m<1440?(m/60)+" H AGO":(m/1440)+" DAYS AGO";}
  private static String utc(long t){if(t<=0)return "NO SUCCESS TIME";SimpleDateFormat f=new SimpleDateFormat("dd MMM HH:mm 'UTC'",Locale.US);
    f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(t));}
  private void jump(Class<?> destination){startActivity(new Intent(this,destination));}
  private void jumpFeed(String feed){Intent i=new Intent(this,RunningballV17DetailsActivity.class);i.putExtra("feed",feed);startActivity(i);}
  private void entry(String heading,String provider,String figure,long success,long limit,String error,String requirement,Class<?> destination){
    long elapsed=success<=0?Long.MAX_VALUE:Math.max(0,System.currentTimeMillis()-success);
    boolean failed=error!=null&&!error.isEmpty();boolean available=success>0;
    String state=!available?(requirement.isEmpty()?"NOT LOADED":"SETUP REQUIRED"):
        (failed?"FETCH FAILED / CACHED":elapsed>limit?"STALE / CACHED":"RECENT SNAPSHOT");
    int tint=!available?AMBER:failed?RED:elapsed>limit?AMBER:GREEN;
    LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);
    card.setPadding(dp(13),dp(12),dp(12),dp(13));card.setBackground(shape(tint));
    card.addView(label(heading+"  •  "+state,12,tint,true));
    TextView big=label(figure,22,INK,true);LinearLayout.LayoutParams b=new LinearLayout.LayoutParams(-1,-2);b.topMargin=dp(6);card.addView(big,b);
    TextView source=label(provider+"  /  "+age(success)+"  /  "+utc(success),10,DIM,false);
    LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(5);card.addView(source,p);
    if(!requirement.isEmpty())card.addView(label(requirement,11,AMBER,false));
    if(failed)card.addView(label("ERROR: "+error,11,RED,false));
    if(destination!=null){TextView action=label("OPEN DETAILS  ›",11,CYAN,true);action.setPadding(0,dp(9),0,0);card.addView(action);
      card.setOnClickListener(v->{if(destination==RunningballV17DetailsActivity.class){if(heading.startsWith("WORLD NEWS"))jumpFeed(RunningballV17Feeds.NEWS);else if(heading.startsWith("WEATHER"))jumpFeed(RunningballV17Feeds.WEATHER);else jumpFeed(RunningballV17Feeds.FX);}else jump(destination);});}
    LinearLayout.LayoutParams m=new LinearLayout.LayoutParams(-1,-2);m.topMargin=dp(9);board.addView(card,m);
  }
  @Override public void onCreate(Bundle state){super.onCreate(state);
    getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
    board=new LinearLayout(this);board.setOrientation(LinearLayout.VERTICAL);board.setPadding(dp(16),dp(28),dp(16),dp(32));scroll.addView(board);
    scroll.setOnApplyWindowInsetsListener((view,insets)->{
      int top,bottom;
      if(Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());top=bars.top;bottom=bars.bottom;}
      else{top=insets.getSystemWindowInsetTop();bottom=insets.getSystemWindowInsetBottom();}
      board.setPadding(dp(16),dp(28)+top,dp(16),dp(32)+bottom);return insets;
    });
    setContentView(scroll);scroll.requestApplyInsets();
  }
  private void refreshPublic(boolean manual){
    Context app=getApplicationContext();
    RunningballV16SourceRefresh.request(app,manual,()->{if(visible)render();});
    RunningballV17Feeds.request(app,manual,()->{if(visible)render();});
    RunningballV19Noaa.request(app,()->{if(visible)render();});
    RunningballV19SatelliteBootstrap.request(app,()->{if(visible)render();});
    if(RunningballWorldTarget.ready(app)){
      Intent i=new Intent(app,AirOperationsWidgets.Pulse.class);
      i.setAction("com.sentongoharuna.worldsituationroom.AIR_WIDGET_REFRESH");i.setPackage(getPackageName());sendBroadcast(i);
    }
  }
  @Override protected void onResume(){super.onResume();visible=true;redraw.run();refreshPublic(false);}
  @Override protected void onPause(){visible=false;ui.removeCallbacks(redraw);super.onPause();}
  private void render(){if(board==null)return;board.removeAllViews();
    board.addView(label("RUNNINGBALL2 / GLOBAL PROVIDER MONITOR",10,GREEN,true));
    TextView heading=label("LIVE DATA SOURCES",24,INK,true);heading.setPadding(0,dp(10),0,dp(7));board.addView(heading);
    top=label("Each source has its own freshness and error state. A value of -- is not a count of zero.",12,DIM,false);board.addView(top);
    TextView reload=label("↻ REQUEST PUBLIC-SOURCE UPDATES",13,CYAN,true);reload.setGravity(Gravity.CENTER);reload.setPadding(dp(8),dp(16),dp(8),dp(16));
    reload.setBackground(shape(CYAN));LinearLayout.LayoutParams rm=new LinearLayout.LayoutParams(-1,-2);rm.topMargin=dp(16);board.addView(reload,rm);
    reload.setOnClickListener(v->{long now=System.currentTimeMillis();if(now-lastManualRefresh<90000L){android.widget.Toast.makeText(this,"Refresh cooldown: 90 seconds",android.widget.Toast.LENGTH_SHORT).show();return;}lastManualRefresh=now;top.setText("REQUESTED: source limits and existing cooldowns still apply.");refreshPublic(true);});
    boolean sector=RunningballWorldTarget.ready(this);
    SharedPreferences asp=pref("air_widget_v2");JSONObject air=json(asp.getString("last_snapshot","{}"));
    long at=sector?air.optLong("time",0):0L;String aerr=asp.getString("last_error","");
    if(sector&&at>0){double lat=air.optDouble("observerLat",Double.NaN),lon=air.optDouble("observerLon",Double.NaN);
      if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat-RunningballWorldTarget.lat(this))>.001||Math.abs(lon-RunningballWorldTarget.lon(this))>.001){at=0;aerr="PREVIOUS REGION DATA INVALIDATED";}}
    entry("AIRCRAFT / SELECTED SECTOR","ADSB.LOL • 250 NM",at>0?air.optInt("count",0)+" REPORTED":"--",at,180000L,aerr,
      sector?"":"SELECT WORLD REGION FIRST",AirRadarActivity.class);
    SharedPreferences sat=pref("rb10_satellite");int satcount=countArray(sat.getString("data_STATIONS",""));long st=sat.getLong("data_STATIONS_time",0);
    entry("SATELLITES / STATIONS","CELESTRAK • OMM CATALOGUE",st>0&&satcount>=0?satcount+" CATALOGUE ENTRIES":"--",st,7200000L,pref("rb19_bootstrap").getString("sat_error",""),
      "ORBITAL POSITIONS ARE ESTIMATES, NOT CAMERA TRACKING",GevSatelliteActivity.class);
    SharedPreferences sea=pref("rb11_marine");JSONObject ships=json(sea.getString("rows",""));int n=count(ships,"rows");
    boolean hasAis=!sea.getString("endpoint","").trim().isEmpty();
    entry("MARITIME / AIS","AISSTREAM • SECURE HTTPS GATEWAY",sea.getLong("last_fetch",0)>0&&n>=0?n+" VESSEL REPORTS":"--",
      sea.getLong("last_fetch",0),180000L,"",hasAis?"":"NO HTTPS AIS GATEWAY CONFIGURED",GevMarineActivity.class);
    SharedPreferences globe=pref("rb_global_public_events");JSONObject q=json(globe.getString("quakes_raw",""));
    long qt=globe.getLong("quakes_time",0);int nq=count(q,"features");
    entry("EARTHQUAKES / WORLD","USGS • M2.5+ PAST 24H",qt>0&&nq>=0?nq+" REPORTS":"--",qt,1200000L,globe.getString("quakes_v16_error",""),"",RunningballGlobalEventsActivity.class);
    JSONObject ev=json(globe.getString("nasa_raw",""));int ne=count(ev,"events");long et=globe.getLong("nasa_time",0);
    entry("NATURAL EVENTS / WORLD","NASA EONET • OPEN EVENTS",et>0&&ne>=0?ne+" RETURNED (CAPPED)":"--",et,1200000L,
      globe.getString("nasa_v16_error",""),"",RunningballGlobalEventsActivity.class);
    SharedPreferences nf=pref("rb17_verified_feeds");JSONObject news=json(nf.getString("news_json",""));long nt=nf.getLong("news_received",0);
    int nn=count(news,"articles");
    entry("WORLD NEWS",news.optString("provider","NEWS SOURCE")+" • LINKED ARTICLES",nt>0&&nn>=0?nn+" ARTICLES RECEIVED":"--",nt,3600000L,
      nf.getString("news_error",""),"ARTICLE COUNTS ARE NOT WORLDWIDE EVENT TOTALS",RunningballV17DetailsActivity.class);
    JSONObject wx=json(nf.getString("weather_json",""));long wt=nf.getLong("weather_received",0);
    if(!sector||!String.format(Locale.US,"%.4f,%.4f",RunningballWorldTarget.lat(this),RunningballWorldTarget.lon(this)).equals(wx.optString("region","")))wt=0;
    double temp=wx.optDouble("temperature",Double.NaN);
    entry("WEATHER / SELECTED REGION","OPEN-METEO • MODEL-DERIVED",wt>0&&Double.isFinite(temp)?String.format(Locale.US,"%.1f °C",temp):"--",
      wt,2700000L,nf.getString("weather_error",""),sector?"FORECAST / MODEL, NOT STATION OBSERVATION":"SELECT WORLD REGION FIRST",RunningballWorldExplorerActivity.class);
    JSONObject fx=json(nf.getString("fx_json",""));JSONObject rates=fx.optJSONObject("rates");long ft=nf.getLong("fx_received",0);
    entry("CURRENCY REFERENCES","FRANKFURTER • DAILY REFERENCE",ft>0&&rates!=null?"USD/EUR "+String.format(Locale.US,"%.3f",rates.optDouble("EUR",Double.NaN)):"--",
      ft,48L*3600000L,nf.getString("fx_error",""),"REFERENCE DATE: "+fx.optString("date","NOT AVAILABLE"),RunningballV17DetailsActivity.class);
    long noaa=RunningballV19Noaa.received(this);double kp=RunningballV19Noaa.kp(this);
    entry("SPACE WEATHER / PLANETARY KP","NOAA SWPC • OBSERVED KP",noaa>0&&Double.isFinite(kp)?String.format(Locale.US,"KP %.2f",kp):"--",
      noaa,2400000L,RunningballV19Noaa.error(this),"OBSERVATION: "+RunningballV19Noaa.observedTime(this),null);
    TextView foot=label("OBSERVED DATA MAY BE DELAYED. OFFLINE = PREVIOUS VERIFIED CACHE, NEVER A NEW LIVE READING. AIS REQUIRES A SERVER-SIDE PROVIDER KEY.",11,DIM,false);
    foot.setPadding(0,dp(16),0,0);board.addView(foot);
  }
}
