package com.sentongoharuna.worldsituationroom;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
/** Independent licence/attribution UI. No GEV datasets, imagery or assets are introduced by V25. */
public final class RunningballV25CreditsActivity extends Activity {
  private TextView line(String s,int size,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setPadding(0,12,0,12);return v;}
  @Override public void onCreate(Bundle state){super.onCreate(state);RunningballV17Insets.install(this);
    ScrollView outer=new ScrollView(this);outer.setBackgroundColor(0xFF07111B);LinearLayout body=new LinearLayout(this);
    body.setOrientation(LinearLayout.VERTICAL);body.setPadding(24,24,24,40);outer.addView(body);
    TextView back=line("‹ BACK",14,0xFF55D6EF);back.setMinHeight(48);back.setOnClickListener(v->finish());body.addView(back);
    body.addView(line("CREDITS & THIRD-PARTY CAUTION",22,0xFFEAF5FE));
    body.addView(line("God's Eye View — original MIT-licensed source by Bilawal Sidhu © 2026. V25 Stage 1 is an independent Android implementation. Attribution is not an endorsement by the creator.",14,0xFFEAF5FE));
    body.addView(line("Full upstream MIT notice is bundled as assets/gev-mit-license.txt. Its MIT licence covers upstream original software only, NOT third-party imagery, data, fonts, models, logos, CCTV feeds, or API access.",12,0xFFFFBE66));
    body.addView(line("No TeleGeography cables, Bhote Koshi imagery, Google 3D Tiles, Cesium ion assets, Esri tiles, CCTV height data, Google News RSS, OSM-derived datasets, third-party models or API keys were newly imported for Stage 1.",12,0xFF5CFFC6));
    for(int i=0;i<RunningballV25Sources.PROVIDERS.length;i++)
      body.addView(line(RunningballV25Sources.NAMES[i]+" · "+RunningballV25Sources.PROVIDERS[i]+"\n"+RunningballV25Sources.RIGHTS[i],12,0xFFEAF5FE));
    body.addView(line("Natural Earth: Made with Natural Earth (only if Natural Earth data are added in a later approved stage). Provider licences, quotas and paid/commercial obligations must be checked before public distribution.",12,0xFFFFBE66));
    setContentView(outer);
  }
}
