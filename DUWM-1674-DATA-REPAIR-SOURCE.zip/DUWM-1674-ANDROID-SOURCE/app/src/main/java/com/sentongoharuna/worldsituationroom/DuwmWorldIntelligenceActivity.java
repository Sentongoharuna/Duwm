package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * DUWM 1162 intelligence board. Each number is derived from parsed provider records.
 * A missing feed is never populated with synthetic data, and an event reported by
 * a news source is labelled a report, not a verified physical event.
 */
public final class DuwmWorldIntelligenceActivity extends Activity {
  private static final int BACKGROUND=Color.rgb(5,14,25), PANEL=Color.rgb(12,29,43), INK=Color.rgb(224,242,246);
  private static final int MUTED=Color.rgb(142,177,188), ACCENT=Color.rgb(80,208,229);
  private static final String[] KINDS={"AIRCRAFT","VESSELS","SATELLITES","EARTHQUAKES","WEATHER","CONFLICT REPORTS","NEWS","MARKETS","EMERGENCIES"};
  private static final long REFRESH_MS=10*60*1000L, AIR_REFRESH_MS=30*60*1000L;
  private static final int PAGE_SIZE=40, MAX_RECORDS=25000;
  private final HashMap<String,Batch> batches=new HashMap<>();
  private final HashMap<String,Long> attempted=new HashMap<>();
  private final HashMap<String,TextView> tiles=new HashMap<>();
  private final HashMap<String,Duwm1166SignalView> statusLeds=new HashMap<>();
  private final Handler handler=new Handler(Looper.getMainLooper());
  private final ExecutorService workers=Executors.newFixedThreadPool(4);
  private TextView status,contentHeading;
  private LinearLayout recordsHost,tilesHost;
  private volatile boolean started=false;
  private String selected="AIRCRAFT";
  private int recordPage=0;
  private final Runnable refreshTicker=new Runnable(){@Override public void run(){if(!started)return;refresh(false);handler.postDelayed(this,REFRESH_MS);}};

  static final class Entry {
    final String id,kind,title,detail,provider,url;
    final long sourceTime,receiptTime;
    final Double lat,lon;
    Entry(String id,String kind,String title,String detail,String provider,String url,long sourceTime,Double lat,Double lon){
      this.id=id;this.kind=kind;this.title=title;this.detail=detail;this.provider=provider;this.url=url;
      this.sourceTime=sourceTime;this.receiptTime=System.currentTimeMillis();this.lat=lat;this.lon=lon;
    }
    boolean positioned(){return lat!=null&&lon!=null&&Double.isFinite(lat)&&Double.isFinite(lon)&&Math.abs(lat)<=90&&Math.abs(lon)<=180;}
  }
  static final class Batch {
    final String type,provider,sourceUrl,status;
    final ArrayList<Entry> entries;
    final int availableCount;
    final long receivedAt;
    Batch(String kind,String provider,String sourceUrl,String status,ArrayList<Entry> entries,int count){
      this.type=kind;this.provider=provider;this.sourceUrl=sourceUrl;this.status=status;this.entries=entries;
      this.availableCount=count;this.receivedAt=System.currentTimeMillis();
    }
  }
  private int dp(float v){return (int)(getResources().getDisplayMetrics().density*v+.5f);}
  private TextView text(String value,int size,int color){TextView t=new TextView(this);t.setText(value);t.setTextColor(color);t.setTextSize(size);t.setPadding(dp(9),dp(7),dp(9),dp(7));return t;}
  private void panel(View v){GradientDrawable d=new GradientDrawable();d.setColor(PANEL);d.setCornerRadius(dp(7));d.setStroke(dp(1),Color.rgb(42,88,109));v.setBackground(d);}
  private String stamp(long t){if(t<=0)return "SOURCE TIME UNAVAILABLE";SimpleDateFormat f=new SimpleDateFormat("dd MMM yyyy  HH:mm 'UTC'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(t));}
  private TextView heading(String s){TextView t=text(s,15,INK);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}

  @Override public void onCreate(Bundle b){super.onCreate(b);
    getWindow().setStatusBarColor(BACKGROUND);getWindow().setNavigationBarColor(BACKGROUND);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BACKGROUND);
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(10),dp(6),dp(10),dp(24));scroll.addView(root);setContentView(scroll);Duwm1167SafeArea.install(this,scroll);
    LinearLayout toolbar=new LinearLayout(this);toolbar.setGravity(Gravity.CENTER_VERTICAL);
    TextView back=text("‹",27,ACCENT);toolbar.addView(back,new LinearLayout.LayoutParams(dp(40),-2));back.setOnClickListener(v->finish());
    toolbar.addView(heading("WORLD SITUATION ROOM  /  SOURCE INTELLIGENCE"),new LinearLayout.LayoutParams(0,-2,1));root.addView(toolbar);
    TextView explainer=text("9 CHANNELS  •  OBSERVED RECORDS / SOURCE TIMESTAMPS  •  NO SYNTHETIC DATA",10,MUTED);root.addView(explainer);
    status=text("WAITING FOR PROVIDER RESPONSES",11,MUTED);root.addView(status);
    LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER_VERTICAL);
    TextView refresh=text("REFRESH VERIFIED SOURCES",12,ACCENT);panel(refresh);actions.addView(refresh,new LinearLayout.LayoutParams(0,dp(42),1));refresh.setGravity(Gravity.CENTER);
    refresh.setOnClickListener(v->refresh(true));
    TextView maps=text("OPEN MAP",12,ACCENT);panel(maps);LinearLayout.LayoutParams ml=new LinearLayout.LayoutParams(dp(112),dp(42));ml.leftMargin=dp(6);actions.addView(maps,ml);maps.setGravity(Gravity.CENTER);
    maps.setOnClickListener(v->startActivity(new Intent(this,DuwmPlaceMapActivity.class)));
    root.addView(actions);
    tilesHost=new LinearLayout(this);tilesHost.setOrientation(LinearLayout.VERTICAL);root.addView(tilesHost);
    for(String type:KINDS){
      TextView tile=text(type+"   /   WAITING FOR SOURCE",12,MUTED);panel(tile);
      LinearLayout tileRow=new LinearLayout(this);tileRow.setGravity(Gravity.CENTER_VERTICAL);panel(tileRow);
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.topMargin=dp(5);tilesHost.addView(tileRow,lp);
      Duwm1166SignalView led=new Duwm1166SignalView(this);led.source(type,0,0,false,false);
      tileRow.addView(led,new LinearLayout.LayoutParams(dp(36),dp(46)));
      tileRow.addView(tile,new LinearLayout.LayoutParams(0,dp(48),1));
      tile.setGravity(Gravity.CENTER_VERTICAL);tileRow.setOnClickListener(v->{selected=type;recordPage=0;drawDetails();});tiles.put(type,tile);statusLeds.put(type,led);
    }
    contentHeading=heading("AIRCRAFT / SOURCE RECORDS");root.addView(contentHeading);
    recordsHost=new LinearLayout(this);recordsHost.setOrientation(LinearLayout.VERTICAL);root.addView(recordsHost);
    TextView policy=text("PROVIDER COUNTS ARE NOT THE SAME AS THE CAPPED ON-DEVICE POSITION SAMPLE. Air positions are rate-limited. " +
       "Vessel source: Finnish coastal AIS, not worldwide coverage. Weather values are MODEL forecasts. Conflict records are NEWS REPORTS, not independently verified incidents.",10,MUTED);
    root.addView(policy);drawDetails();
  }
  @Override public void onStart(){super.onStart();started=true;handler.post(refreshTicker);}
  @Override public void onStop(){started=false;handler.removeCallbacks(refreshTicker);super.onStop();}
  @Override public void onDestroy(){workers.shutdownNow();super.onDestroy();}
  private void refresh(boolean force){
    for(final String type:KINDS){
      // 1166 VESSELS uses source-dated Finnish AIS where its public feed responds.
      // Coverage is NOT global; unavailable responses remain unavailable.
      final long now=System.currentTimeMillis();Long was=attempted.get(type);
      long period=type.equals("AIRCRAFT")?AIR_REFRESH_MS:REFRESH_MS;
      if(!force&&was!=null&&now-was<period)continue;
      attempted.put(type,now);
      TextView t=tiles.get(type);if(t!=null)t.setText(type+"   /   REQUESTING VERIFIED RECORDS");
      workers.execute(()->{
        Batch result;
        try{result=load(type);}catch(Exception e){
          String cause=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
          result=new Batch(type,provider(type),source(type),"UNAVAILABLE: "+shorten(cause,70),new ArrayList<>(),0);
        }
        final Batch received=result;
        runOnUiThread(()->{
          if(isFinishing()||isDestroyed())return;
          batches.put(type,received);
          publishPositioned(received);
          renderTile(type);
          if(type.equals(selected)){recordPage=0;drawDetails();}
          updateStatus();
        });
      });
    }
  }
  private static String shorten(String s,int limit){return s==null?"":s.length()<=limit?s:s.substring(0,limit);}
  private void updateStatus(){int ready=0,unavailable=0;for(String type:KINDS){Batch b=batches.get(type);if(b!=null){if(b.status.equals("RECEIVED"))ready++;else unavailable++;}}
    int pending=KINDS.length-ready-unavailable;
    status.setText("RECEIVED "+ready+" / "+KINDS.length+"  •  PENDING "+pending+"  •  UNAVAILABLE "+unavailable+"\nLAST STATUS CHECK "+stamp(System.currentTimeMillis()));
  }
  private void renderTile(String type){TextView t=tiles.get(type);Batch b=batches.get(type);if(t==null||b==null)return;
    String total=b.status.equals("RECEIVED")? b.availableCount+" SOURCE RECORDS ("+b.entries.size()+" LISTED)" : b.status;
    t.setText(type+"   /   "+total);t.setTextColor(b.status.equals("RECEIVED")?ACCENT:MUTED);
    Duwm1166SignalView led=statusLeds.get(type);
    if(led!=null){long observed=0;for(Entry e:b.entries)observed=Math.max(observed,e.sourceTime);
      led.source(type,observed,b.status.equals("RECEIVED")?b.receivedAt:0,false,b.status.startsWith("UNAVAILABLE"));}
  }
  private void drawDetails(){if(recordsHost==null)return;recordsHost.removeAllViews();contentHeading.setText(selected+"   /   INDIVIDUAL PROVIDER RECORDS");
    Batch b=batches.get(selected);
    if(b==null){recordsHost.addView(text("Fetching provider records. Select a channel after the first receipt.",12,MUTED));return;}
    recordsHost.addView(text(b.provider+"  •  "+b.status+"\nLAST RECEIVED "+stamp(b.receivedAt)+"\nRECORD COUNT "+b.availableCount,11,MUTED));
    if(b.entries.isEmpty()){
      recordsHost.addView(text("No verified records available in the latest response. No substitute data is displayed. Finnish AIS is not worldwide AIS.",12,MUTED));return;
    }
    int from=Math.min(recordPage*PAGE_SIZE,b.entries.size()),until=Math.min(from+PAGE_SIZE,b.entries.size());
    recordsHost.addView(text("DISPLAYING RECORDS "+(from+1)+" TO "+until+" OF "+b.entries.size()+" — TAP FOR DETAILS",10,MUTED));
    for(int i=from;i<until;i++){Entry e=b.entries.get(i);
      StringBuilder line=new StringBuilder(e.title).append("\n").append(e.detail).append("\nSOURCE: ").append(e.provider).append("  •  ").append(stamp(e.sourceTime));
      LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);panel(row);
      Duwm1166SignalView signal=new Duwm1166SignalView(this);signal.source(e.kind,e.sourceTime,e.receiptTime,false,false);
      row.addView(signal,new LinearLayout.LayoutParams(dp(34),dp(54)));
      TextView copy=text(line.toString(),12,INK);row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
      LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(5);recordsHost.addView(row,p);
      row.setOnClickListener(v->openRecord(e));
    }
    if(until<b.entries.size()){
      TextView more=text("NEXT PAGE  /  MORE SOURCE RECORDS",12,ACCENT);panel(more);recordsHost.addView(more);
      more.setOnClickListener(v->{recordPage++;drawDetails();});
    }
    if(recordPage>0){TextView previous=text("PREVIOUS PAGE",12,ACCENT);panel(previous);recordsHost.addView(previous);
      previous.setOnClickListener(v->{recordPage--;drawDetails();});}
  }
  private void openRecord(Entry e){
    final String[] choices=e.positioned()?new String[]{"Locate real coordinate on map","Share source record","Open provider link"}:
        new String[]{"Share source record","Open provider link"};
    new android.app.AlertDialog.Builder(this).setTitle(e.title).setMessage(e.detail+"\n\n"+e.provider+"\n"+stamp(e.sourceTime))
        .setItems(choices,(dialog,which)->{
          if(e.positioned()&&which==0){Intent i=new Intent(this,DuwmPlaceMapActivity.class);
            i.putExtra("focus_lat",String.valueOf(e.lat));i.putExtra("focus_lon",String.valueOf(e.lon));startActivity(i);
          }else if((e.positioned()&&which==1)||(!e.positioned()&&which==0)){
            if(e.positioned()){
              V115941ShareCards.share(this,e.kind,e.title,e.detail,e.provider,e.sourceTime,e.lat,e.lon,e.url,null);
            }else{
              String body=e.title+"\n"+e.detail+"\nProvider: "+e.provider+"\nSource time: "+stamp(e.sourceTime)+"\n"+e.url;
              Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,body);
              startActivity(Intent.createChooser(i,"Share verified source record"));
            }
          }else{if(e.url==null||!e.url.startsWith("https://")){
                Toast.makeText(this,"No HTTPS provider link available",Toast.LENGTH_SHORT).show();return;}
              startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(e.url)));}
        }).show();
  }
  private void publishPositioned(Batch b){
    String type=b.type.equals("SATELLITES")?"ISS":b.type.equals("EARTHQUAKES")?"EARTHQUAKE":b.type;
    if(b.type.equals("VESSELS"))type="VESSEL";
    if(!Arrays.asList("ISS","EARTHQUAKE","AIRCRAFT","VESSEL","WEATHER").contains(type)||!b.status.equals("RECEIVED"))return;
    ArrayList<DuwmGeoObservationStore.Fix> fixes=new ArrayList<>();long now=System.currentTimeMillis();
    for(Entry r:b.entries)if(fixes.size()<150&&r.positioned()&&r.sourceTime>0&&now-r.sourceTime<3600000L){
      fixes.add(new DuwmGeoObservationStore.Fix(r.id,type,r.title,r.detail,r.provider,r.url,
          r.sourceTime,now,r.lat,r.lon,null,null,0));
    }
    if(!fixes.isEmpty())DuwmGeoObservationStore.publishType(this,type,fixes);
  }
  private String provider(String category){switch(category){
    case "AIRCRAFT":return "OpenSky Network";case "VESSELS":return "Digitraffic / Fintraffic AIS — Finnish waters";case "SATELLITES":return "Where The ISS At";
    case "EARTHQUAKES":return "USGS";case "WEATHER":return "Open-Meteo model forecast";
    case "NEWS":case "CONFLICT REPORTS":return "GDELT monitored news coverage";
    case "MARKETS":return "European Central Bank reference rates";case "EMERGENCIES":return "GDACS";
    default:return "No configured feed";
  }}
  private String source(String category){switch(category){
    case "AIRCRAFT":return "https://opensky-network.org/api/states/all";
    case "VESSELS":return "https://meri.digitraffic.fi/api/ais/v1/locations";
    case "SATELLITES":return "https://api.wheretheiss.at/v1/satellites/25544";
    case "EARTHQUAKES":return "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson";
    case "WEATHER":return "https://open-meteo.com/en/docs";
    case "NEWS":case "CONFLICT REPORTS":return "https://www.gdeltproject.org/";
    case "MARKETS":return "https://www.ecb.europa.eu/stats/policy_and_exchange_rates/euro_reference_exchange_rates/html/index.en.html";
    case "EMERGENCIES":return "https://www.gdacs.org/";
    default:return "";
  }}
  private Batch load(String type)throws Exception{switch(type){
    case "AIRCRAFT":return loadAircraft();case "VESSELS":return loadVessels();case "SATELLITES":return loadISS();case "EARTHQUAKES":return loadQuakes();
    case "WEATHER":return loadWeather();case "NEWS":return loadGdelt(false);
    case "CONFLICT REPORTS":return loadGdelt(true);case "MARKETS":return loadMarkets();case "EMERGENCIES":return loadDisasters();
    default:return new Batch(type,provider(type),source(type),"FEED NOT CONFIGURED",new ArrayList<>(),0);
  }}
  private String request(String u,int max)throws Exception{
    HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setRequestMethod("GET");
    c.setConnectTimeout(9000);c.setReadTimeout(12000);
    c.setRequestProperty("User-Agent","DEVELOP.UGANDA/1162 (public source monitor)");
    c.setRequestProperty("Accept","application/json, application/xml, text/xml, application/rss+xml, */*");
    try{int code=c.getResponseCode();if(code!=200)throw new java.io.IOException("HTTP "+code+(code==429?" — rate limited":""));
      try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
        byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){if(out.size()+n>max)throw new java.io.IOException("Response larger than permitted limit");out.write(buf,0,n);}
        return new String(out.toByteArray(),StandardCharsets.UTF_8);
      }
    }finally{c.disconnect();}
  }
  private Batch loadAircraft()throws Exception{
    JSONObject doc=new JSONObject(request(source("AIRCRAFT"),16000000));JSONArray states=doc.optJSONArray("states");if(states==null)throw new Exception("OpenSky states list missing");
    ArrayList<Entry> records=new ArrayList<>();int count=0;
    for(int i=0;i<states.length();i++){
      JSONArray s=states.optJSONArray(i);if(s==null||s.length()<11||s.isNull(5)||s.isNull(6))continue;
      double lon=s.optDouble(5,Double.NaN),lat=s.optDouble(6,Double.NaN);
      if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)continue;
      String id=s.optString(0,"").trim();if(id.isEmpty())continue;count++;
      if(records.size()>=MAX_RECORDS)continue;
      String callsign=s.optString(1,"").trim();if(callsign.isEmpty())callsign=id;
      long seen=s.optLong(4,0L)*1000L;
      String detail="ICAO24 "+id+" • Altitude "+(s.isNull(7)?"not reported":s.optString(7)+" m")+
          " • Speed "+(s.isNull(9)?"not reported":s.optString(9)+" m/s")+
          " • Heading "+(s.isNull(10)?"not reported":s.optString(10)+"°");
      records.add(new Entry("AIR:"+id,"AIRCRAFT",callsign,detail,provider("AIRCRAFT"),"https://opensky-network.org/",seen,lat,lon));
    }
    return new Batch("AIRCRAFT",provider("AIRCRAFT"),source("AIRCRAFT"),"RECEIVED",records,count);
  }
  /** Official Finnish marine AIS open data. Only reported coordinates, UTC times and coverage. */
  private Batch loadVessels()throws Exception{
    JSONObject doc=new JSONObject(request(source("VESSELS"),10000000));JSONArray features=doc.optJSONArray("features");
    if(features==null)throw new java.io.IOException("Finnish AIS GeoJSON features unavailable");
    ArrayList<Entry> records=new ArrayList<>();int count=0;long now=System.currentTimeMillis();
    for(int i=0;i<features.length();i++){
      JSONObject item=features.optJSONObject(i);if(item==null)continue;
      JSONObject geo=item.optJSONObject("geometry"),properties=item.optJSONObject("properties");
      JSONArray coords=geo==null?null:geo.optJSONArray("coordinates");
      if(properties==null||coords==null||coords.length()<2)continue;
      double lon=coords.optDouble(0,Double.NaN),lat=coords.optDouble(1,Double.NaN);
      if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)continue;
      String id=properties.optString("mmsi",item.optString("mmsi",""));if(id.length()<6)continue;
      long observed=properties.optLong("timestamp",properties.optLong("time",0L));
      if(observed>0&&observed<100000000000L)observed*=1000L;
      if(observed<=0){String iso=properties.optString("timestamp",properties.optString("time",""));
        observed=parseTime(iso,"yyyy-MM-dd'T'HH:mm:ssX",TimeZone.getTimeZone("UTC"));}
      if(observed<=0||observed>now+600000L||now-observed>86400000L)continue;
      count++;
      if(records.size()>=1200)continue;
      String name=properties.optString("name","").trim();if(name.isEmpty())name="AIS vessel MMSI "+id;
      String detail="MMSI "+id+"  •  Speed "+properties.optString("sog","unreported")+
        " knots  •  Course "+properties.optString("cog","unreported")+"°  •  Finnish coastal AIS coverage";
      records.add(new Entry("VESSEL:"+id,"VESSEL",name,detail,provider("VESSELS"),source("VESSELS"),observed,lat,lon));
    }
    return new Batch("VESSELS",provider("VESSELS"),source("VESSELS"),"RECEIVED",records,count);
  }
  private Batch loadISS()throws Exception{
    JSONObject j=new JSONObject(request(source("SATELLITES"),90000));
    double lat=j.optDouble("latitude",Double.NaN),lon=j.optDouble("longitude",Double.NaN);
    if(!Double.isFinite(lat)||!Double.isFinite(lon))throw new Exception("No reported ISS coordinates");
    ArrayList<Entry> arr=new ArrayList<>();arr.add(new Entry("ISS:25544","ISS","International Space Station",
      "Observed / provider-reported ISS position • Altitude "+j.optString("altitude","unknown")+" km • Velocity "+j.optString("velocity","unknown")+" km/h",
      provider("SATELLITES"),source("SATELLITES"),j.optLong("timestamp",0)*1000L,lat,lon));
    return new Batch("SATELLITES",provider("SATELLITES"),source("SATELLITES"),"RECEIVED",arr,1);
  }
  private Batch loadQuakes()throws Exception{
    JSONObject j=new JSONObject(request(source("EARTHQUAKES"),3000000));JSONArray feats=j.optJSONArray("features");if(feats==null)throw new Exception("No earthquake features");
    ArrayList<Entry> arr=new ArrayList<>();int count=0;
    for(int i=0;i<feats.length();i++){
      JSONObject e=feats.optJSONObject(i);if(e==null)continue;
      JSONObject p=e.optJSONObject("properties"),g=e.optJSONObject("geometry");JSONArray pos=g==null?null:g.optJSONArray("coordinates");
      if(p==null||pos==null||pos.length()<2)continue;
      double lon=pos.optDouble(0,Double.NaN),lat=pos.optDouble(1,Double.NaN);
      if(!Double.isFinite(lat)||!Double.isFinite(lon))continue;
      String id=e.optString("id","");if(id.isEmpty())continue;count++;
      if(arr.size()<MAX_RECORDS)arr.add(new Entry("QUAKE:"+id,"EARTHQUAKE",p.optString("title","USGS seismic event"),
        "Magnitude "+p.optString("mag","unreported")+" • "+p.optString("place","unreported"),provider("EARTHQUAKES"),
        p.optString("url",source("EARTHQUAKES")),p.optLong("time",0L),lat,lon));
    }
    return new Batch("EARTHQUAKES",provider("EARTHQUAKES"),source("EARTHQUAKES"),"RECEIVED",arr,count);
  }
  private Batch loadWeather()throws Exception{
    // Model values at fixed named reference cities; never imply ground-station readings.
    String[] names={"Kampala","London","New York","Singapore","Sydney"};
    double[][] coords={{0.3476,32.5825},{51.5074,-0.1278},{40.7128,-74.0060},{1.3521,103.8198},{-33.8688,151.2093}};
    StringBuilder la=new StringBuilder(),lo=new StringBuilder();for(int i=0;i<coords.length;i++){if(i>0){la.append(',');lo.append(',');}la.append(coords[i][0]);lo.append(coords[i][1]);}
    String url="https://api.open-meteo.com/v1/forecast?latitude="+la+"&longitude="+lo+"&current=temperature_2m,precipitation,wind_speed_10m,weather_code&timezone=UTC";
    JSONArray resp=new JSONArray(request(url,160000));ArrayList<Entry> arr=new ArrayList<>();
    for(int i=0;i<resp.length()&&i<names.length;i++){
      JSONObject o=resp.optJSONObject(i);JSONObject current=o==null?null:o.optJSONObject("current");if(current==null)continue;
      String time=current.optString("time","");long ts=parseTime(time,"yyyy-MM-dd'T'HH:mm",TimeZone.getTimeZone("UTC"));
      String details="MODEL forecast (not a station reading) • Temperature "+current.optString("temperature_2m","unknown")+
          " °C • Rain "+current.optString("precipitation","unknown")+" mm • Wind "+current.optString("wind_speed_10m","unknown")+" km/h";
      arr.add(new Entry("WEATHER:"+names[i],"WEATHER",names[i]+" weather model",details,provider("WEATHER"),source("WEATHER"),ts,coords[i][0],coords[i][1]));
    }
    if(arr.isEmpty())throw new Exception("No Open-Meteo current data in response");
    return new Batch("WEATHER",provider("WEATHER"),source("WEATHER"),"RECEIVED",arr,arr.size());
  }
  private Batch loadGdelt(boolean conflict)throws Exception{
    String query=conflict?"(war OR conflict OR airstrike OR ceasefire)":"(world OR climate OR technology OR economy)";
    String url="https://api.gdeltproject.org/api/v2/doc/doc?query="+java.net.URLEncoder.encode(query,"UTF-8")+
      "&mode=artlist&maxrecords=50&timespan=24h&format=json";
    JSONObject root=new JSONObject(request(url,900000));JSONArray articles=root.optJSONArray("articles");if(articles==null)throw new Exception("GDELT article list unavailable or temporarily throttled");
    String category=conflict?"CONFLICT REPORTS":"NEWS";ArrayList<Entry> list=new ArrayList<>();int count=0;
    for(int i=0;i<articles.length();i++){
      JSONObject a=articles.optJSONObject(i);if(a==null)continue;
      String title=a.optString("title","").trim(),link=a.optString("url","");if(title.isEmpty()||!link.startsWith("https://"))continue;
      count++;if(list.size()>=MAX_RECORDS)continue;
      String site=a.optString("domain","reporting source not specified");
      long ts=parseTime(a.optString("seendate",""),"yyyyMMdd'T'HHmmss'Z'",TimeZone.getTimeZone("UTC"));
      list.add(new Entry(category+":"+i,category,title,"NEWS COVERAGE ONLY • Publisher "+site+" • Independently unverified report",
        "GDELT / "+site,link,ts,null,null));
    }
    return new Batch(category,provider(category),source(category),"RECEIVED",list,count);
  }
  private Batch loadMarkets()throws Exception{
    String xml=request("https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml",200000);
    XmlPullParser parser=XmlPullParserFactory.newInstance().newPullParser();parser.setInput(new StringReader(xml));
    ArrayList<Entry> list=new ArrayList<>();int count=0;long date=0;
    for(int event=parser.getEventType();event!=XmlPullParser.END_DOCUMENT;event=parser.next()){
      if(event!=XmlPullParser.START_TAG||!"Cube".equals(parser.getName()))continue;
      String t=parser.getAttributeValue(null,"time");if(t!=null)date=parseTime(t,"yyyy-MM-dd",TimeZone.getTimeZone("UTC"));
      String code=parser.getAttributeValue(null,"currency"),rate=parser.getAttributeValue(null,"rate");
      if(code==null||rate==null)continue;count++;
      if(list.size()<MAX_RECORDS)list.add(new Entry("FX:"+code,"MARKETS","EUR / "+code,"1 EUR = "+rate+" "+code+" • ECB published reference rate, not a live trade quote",
       provider("MARKETS"),source("MARKETS"),date,null,null));
    }
    if(count==0)throw new Exception("ECB rate entries missing");
    return new Batch("MARKETS",provider("MARKETS"),source("MARKETS"),"RECEIVED",list,count);
  }
  private Batch loadDisasters()throws Exception{
    String xml=request("https://www.gdacs.org/xml/rss.xml",750000);
    XmlPullParser p=XmlPullParserFactory.newInstance().newPullParser();p.setInput(new StringReader(xml));
    ArrayList<Entry> out=new ArrayList<>();boolean item=false;String tag="",title="",description="",link="",pub="";int count=0;
    for(int ev=p.getEventType();ev!=XmlPullParser.END_DOCUMENT;ev=p.next()){
      if(ev==XmlPullParser.START_TAG){tag=p.getName();if("item".equalsIgnoreCase(tag)){item=true;title="";description="";link="";pub="";}}
      else if(ev==XmlPullParser.TEXT&&item){String v=p.getText();if(v==null)continue;
        if("title".equalsIgnoreCase(tag))title+=v;
        if("description".equalsIgnoreCase(tag))description+=v;
        if("link".equalsIgnoreCase(tag))link+=v;
        if("pubDate".equalsIgnoreCase(tag))pub+=v;
      }else if(ev==XmlPullParser.END_TAG){String end=p.getName();tag="";
        if("item".equalsIgnoreCase(end)&&item){item=false;String ttl=title.trim(),lnk=link.trim();if(ttl.isEmpty()||!lnk.startsWith("https://"))continue;
          count++;if(out.size()<MAX_RECORDS){long ts=parseTime(pub.trim(),"EEE, dd MMM yyyy HH:mm:ss Z",TimeZone.getTimeZone("UTC"));
            out.add(new Entry("GDACS:"+count,"EMERGENCIES",ttl,shorten(description.replaceAll("<[^>]*>"," ").trim(),250),provider("EMERGENCIES"),lnk,ts,null,null));}
        }
      }
    }
    return new Batch("EMERGENCIES",provider("EMERGENCIES"),source("EMERGENCIES"),"RECEIVED",out,count);
  }
  private long parseTime(String value,String pattern,TimeZone z){try{
    SimpleDateFormat f=new SimpleDateFormat(pattern,Locale.US);f.setLenient(false);f.setTimeZone(z);Date d=f.parse(value);return d==null?0:d.getTime();
  }catch(Exception ignored){return 0;}}
}
