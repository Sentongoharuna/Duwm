package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
/** A static plot of ACTUAL source receipt samples; no frame-based or random additions. */
public final class RunningballV25Stage2Sparkline extends View {
  private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
  private final ArrayList<Float> samples=new ArrayList<>();
  public RunningballV25Stage2Sparkline(Context context){super(context);setMinimumHeight((int)(58*getResources().getDisplayMetrics().density));}
  public void setPoints(JSONArray data){samples.clear();for(int i=0;i<data.length();i++){
    JSONObject o=data.optJSONObject(i);if(o==null)continue;
    try {String raw=o.optString("value","").trim();
      java.util.regex.Matcher m=java.util.regex.Pattern.compile("^[+-]?(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)").matcher(raw);
      if(!m.find())continue;
      float v=Float.parseFloat(m.group());
      if(!Float.isNaN(v)&&!Float.isInfinite(v))samples.add(v);
    }catch(Exception ignored){} }
    setContentDescription(samples.size()<2?"Trend unavailable; fewer than two received readings":"Trend from "+samples.size()+" received source readings");invalidate();
  }
  @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();
    paint.setColor(0xFF264858);paint.setStrokeWidth(1f);c.drawLine(0,h-4,w,h-4,paint);
    if(samples.size()<2)return;
    float min=Float.POSITIVE_INFINITY,max=Float.NEGATIVE_INFINITY;
    for(float x:samples){min=Math.min(min,x);max=Math.max(max,x);}
    float span=Math.max(.001f,max-min);paint.setColor(0xFF55D6EF);paint.setStrokeWidth(2.5f*getResources().getDisplayMetrics().density);
    for(int i=1;i<samples.size();i++){
      float x0=(i-1)*w/(samples.size()-1),x1=i*w/(samples.size()-1);
      float y0=4+(1-(samples.get(i-1)-min)/span)*(h-12),y1=4+(1-(samples.get(i)-min)/span)*(h-12);
      c.drawLine(x0,y0,x1,y1,paint);
    }
  }
}
