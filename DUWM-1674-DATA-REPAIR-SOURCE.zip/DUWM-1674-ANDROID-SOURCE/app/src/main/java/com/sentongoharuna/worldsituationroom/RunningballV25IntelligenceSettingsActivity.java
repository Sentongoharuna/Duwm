package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

/** Stage 3, independent settings. Four modes are OPTIONS selected by the user. */
public final class RunningballV25IntelligenceSettingsActivity extends Activity {
  private static final String PREF="rb25_intelligence_wallpaper";
  private final int[] labels={R.id.rb25_mode_0,R.id.rb25_mode_1,R.id.rb25_mode_2,R.id.rb25_mode_3};
  private int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);}
  private SharedPreferences state(){return getSharedPreferences(PREF,Context.MODE_PRIVATE);}
  private TextView text(String s,int sp,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);return t;}
  private void wallpaperPicker(){
    Intent choose=new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
    choose.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
      new ComponentName(this,RunningballV25IntelligenceWallpaperService.class));
    try{startActivity(choose);}catch(Exception e){startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));}
  }
  @Override public void onCreate(Bundle b){super.onCreate(b);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(0xFF07111B);
    LinearLayout column=new LinearLayout(this);column.setOrientation(LinearLayout.VERTICAL);
    column.setPadding(dp(20),dp(26),dp(20),dp(30));scroll.addView(column);
    TextView heading=text("STAGE 3 / INFORMATION WALLPAPER",20,0xFF55D6EF);column.addView(heading);
    TextView note=text("Select an independent wallpaper. The original globe remains installed and unchanged. All data comes from saved source reports; no network requests occur in wallpaper rendering.",14,0xFFEAF5FE);
    note.setPadding(0,dp(16),0,dp(18));column.addView(note);
    RadioGroup choices=new RadioGroup(this);choices.setOrientation(RadioGroup.VERTICAL);
    String[] modes={"Globe Only","Globe + Counters","Globe + Ticker","Minimal Clock + Alerts"};
    for(int i=0;i<modes.length;i++){
      RadioButton button=new RadioButton(this);button.setId(labels[i]);button.setText(modes[i]);button.setTextColor(0xFFEAF5FE);
      button.setTextSize(16);button.setMinimumHeight(dp(52));button.setContentDescription("Wallpaper mode "+modes[i]);choices.addView(button);
    }
    int selected=Math.max(0,Math.min(3,state().getInt("mode",0)));
    choices.check(labels[selected]);choices.setOnCheckedChangeListener((g,id)->{
      for(int i=0;i<labels.length;i++)if(id==labels[i]){state().edit().putInt("mode",i).apply();break;}
    });column.addView(choices);
    CheckBox low=new CheckBox(this);low.setText("Low-power rendering · 5 FPS");low.setTextColor(0xFFEAF5FE);
    low.setTextSize(15);low.setMinimumHeight(dp(50));low.setChecked(state().getBoolean("low_power",false));
    low.setOnCheckedChangeListener((b1,yes)->state().edit().putBoolean("low_power",yes).apply());column.addView(low);
    CheckBox reduced=new CheckBox(this);reduced.setText("Reduce Motion · static globe");reduced.setTextColor(0xFFEAF5FE);
    reduced.setTextSize(15);reduced.setMinimumHeight(dp(50));reduced.setChecked(state().getBoolean("reduce_motion",false));
    reduced.setOnCheckedChangeListener((b1,yes)->state().edit().putBoolean("reduce_motion",yes).apply());column.addView(reduced);
    RadioGroup rates=new RadioGroup(this);rates.setOrientation(RadioGroup.HORIZONTAL);
    for(final int fps:new int[]{15,30}){
      RadioButton r=new RadioButton(this);r.setText(fps+" FPS");r.setTextColor(0xFFEAF5FE);r.setMinimumHeight(dp(48));
      r.setId(fps==15?R.id.rb25_fps_15:R.id.rb25_fps_30);rates.addView(r);
    }
    rates.check(state().getInt("fps",30)==15?R.id.rb25_fps_15:R.id.rb25_fps_30);
    rates.setOnCheckedChangeListener((g,id)->state().edit().putInt("fps",id==R.id.rb25_fps_15?15:30).apply());column.addView(rates);
    Button apply=new Button(this);apply.setText("PREVIEW / SET INTELLIGENCE WALLPAPER");apply.setTextColor(Color.BLACK);
    apply.setContentDescription("Open Android wallpaper picker for the Intelligence wallpaper");
    apply.setOnClickListener(v->wallpaperPicker());column.addView(apply);
    Button classic=new Button(this);classic.setText("OPEN ORIGINAL LIVE GLOBE");classic.setOnClickListener(v->startActivity(new Intent(this,LiveWallpaperLauncherActivity.class)));
    column.addView(classic);
    TextView limits=text("HOME SCREEN: source-aged public data. LOCK SCREEN / PREVIEW: region and headline hidden. This wallpaper cannot guarantee a tap-to-open-app action on every launcher.",12,0xFFB6CCD9);
    limits.setPadding(0,dp(15),0,dp(15));column.addView(limits);
    setContentView(scroll);
  }
}
