package com.sentongoharuna.worldsituationroom;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.view.Gravity;

/** In-app publisher reader; embedded video works only where supported by the publisher. */
public final class Duwm1166ArticleActivity extends Activity {
  private WebView web;
  @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(0xFF06131F);
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xFF06131F);setContentView(root);Duwm1167SafeArea.install(this,root);
    String url=getIntent().getStringExtra("url");String title=getIntent().getStringExtra("title");
    TextView header=new TextView(this);header.setText("‹  "+(title==null?"SOURCE REPORT":title));header.setMaxLines(2);header.setTextColor(Color.WHITE);header.setTextSize(15);
    header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(18,13,16,13);root.addView(header);header.setOnClickListener(v->finish());
    TextView status=new TextView(this);status.setTextColor(0xFF7AE6E5);status.setTextSize(11);status.setPadding(20,6,20,7);root.addView(status);
    if(url==null||!url.startsWith("https://")){status.setText("Publisher did not provide a valid HTTPS link");return;}
    web=new WebView(this);root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
    web.setBackgroundColor(0xFF081822);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(false);
    web.getSettings().setMediaPlaybackRequiresUserGesture(true);
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){String u=req.getUrl().toString();
        if(!u.startsWith("https://")){status.setText("Blocked non-HTTPS navigation");return true;}return false;}
      @Override public void onPageFinished(WebView v,String u){status.setText("PUBLISHER CONTENT  •  "+Uri.parse(u).getHost()+"  •  Media depends on publisher permissions");}
      @Override public void onReceivedError(WebView v,WebResourceRequest req,WebResourceError error){if(req.isForMainFrame())status.setText("Publisher page unavailable — try its original source later");}
    });
    status.setText("OPENING ORIGINAL PUBLISHER INSIDE DUWM");web.loadUrl(url);
  }
  @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
  @Override protected void onDestroy(){if(web!=null){web.stopLoading();web.destroy();}super.onDestroy();}
}
