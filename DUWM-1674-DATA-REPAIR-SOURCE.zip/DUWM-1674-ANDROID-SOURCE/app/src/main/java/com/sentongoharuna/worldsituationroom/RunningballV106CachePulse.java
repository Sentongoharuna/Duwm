package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

/** V106 UI02: factual received-cache pulse; no provider calls or synthetic values. */
public final class RunningballV106CachePulse extends TextView {
  private final Handler main=new Handler(Looper.getMainLooper());
  private boolean visible=false;
  private final Runnable update=new Runnable(){@Override public void run(){
    if(!visible)return;render();main.postDelayed(this,30000L);
  }};
  public RunningballV106CachePulse(Context context){super(context);
    setTextSize(11);setTextColor(0xFFEAF5FE);
    int px=Math.round(getResources().getDisplayMetrics().density*10);
    setPadding(px,px,px,px);
    setContentDescription("World data pulse: source-received record counts and cache ages, not worldwide totals");
    render();
  }
  private static JSONArray items(String raw,String key){
    if(raw==null||raw.trim().isEmpty())return null;
    try{return new JSONObject(raw).optJSONArray(key);}catch(Exception ignored){return null;}
  }
  private static String line(String name,long time,JSONArray records,long recentLimit){
    if(time<=0||records==null)return name+": NOT RECEIVED";
    long diff=System.currentTimeMillis()-time;
    if(diff< -120000L)return name+": CLOCK ERROR / CACHED";
    long minutes=Math.max(0,diff)/60000L;
    String age=minutes<60?minutes+"m":(minutes/60)+"h "+(minutes%60)+"m";
    String state=diff<=recentLimit?"RECENT CACHE":"STALE CACHE";
    return name+": "+records.length()+" received / "+state+" / "+age;
  }
  private void render(){
    Context c=getContext().getApplicationContext();
    SharedPreferences news=c.getSharedPreferences("rb17_verified_feeds",Context.MODE_PRIVATE);
    SharedPreferences events=c.getSharedPreferences("rb_global_public_events",Context.MODE_PRIVATE);
    String n=line("NEWS",news.getLong("news_received",0L),items(news.getString("news_json",""),"articles"),3600000L);
    String q=line("USGS",events.getLong("quakes_time",0L),items(events.getString("quakes_raw",""),"features"),1200000L);
    setText("WORLD DATA PULSE / RECEIVED RECORDS\n"+n+"\n"+q+"\nOpen sources for actual event details");
  }
  @Override protected void onAttachedToWindow(){super.onAttachedToWindow();visible=getWindowVisibility()==View.VISIBLE;
    main.removeCallbacks(update);if(visible)main.post(update);
  }
  @Override protected void onWindowVisibilityChanged(int visibility){super.onWindowVisibilityChanged(visibility);
    visible=visibility==View.VISIBLE&&isAttachedToWindow();main.removeCallbacks(update);
    if(visible)main.post(update);
  }
  @Override protected void onDetachedFromWindow(){visible=false;main.removeCallbacks(update);super.onDetachedFromWindow();}
}
