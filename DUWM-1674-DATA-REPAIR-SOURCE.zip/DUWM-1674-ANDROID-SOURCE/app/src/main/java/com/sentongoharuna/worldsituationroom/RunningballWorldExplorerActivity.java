package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.HorizontalScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.net.URLEncoder;
import java.net.HttpURLConnection;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.util.Locale;

/** Navigate the entire globe, then select a 250 NM observation sector anywhere on Earth. */
public final class RunningballWorldExplorerActivity extends Activity implements SatelliteMapView.Listener {
  private static final int BG=0xFF09111D,INK=0xFFE7F6FF,CYAN=0xFF67DDF3,MUTED=0xFF9AB3C5;
  private SatelliteMapView world;
  private EditText query;
  private TextView status,coordinates;
  private String selectionName="WORLD COORDINATES";
  private long lastLookup;
  private static final String[] NAMES={"Kampala","London","New York","Tokyo","Singapore","Dubai","Paris","Cairo","Mumbai","Delhi","Beijing","Shanghai","Sydney","Melbourne","Toronto","Mexico City","São Paulo","Rio de Janeiro","Lagos","Nairobi","Johannesburg","Cape Town","Berlin","Istanbul","Riyadh","San Francisco","Los Angeles","Moscow","Bangkok","Seoul","Buenos Aires","Accra","Dar es Salaam"};
  private static final double[][] SITES={{.3476,32.5825},{51.507,-.128},{40.713,-74.006},{35.676,139.650},{1.352,103.820},{25.205,55.271},{48.857,2.352},{30.045,31.235},{19.076,72.877},{28.613,77.209},{39.904,116.407},{31.230,121.474},{-33.868,151.209},{-37.813,144.963},{43.653,-79.383},{19.433,-99.133},{-23.551,-46.633},{-22.907,-43.173},{6.524,3.379},{-1.286,36.817},{-26.204,28.047},{-33.925,18.424},{52.520,13.405},{41.009,28.978},{24.714,46.675},{37.774,-122.419},{34.052,-118.244},{55.756,37.618},{13.756,100.502},{37.566,126.978},{-34.603,-58.382},{5.560,-.205},{-6.792,39.208}};
  private int dp(float v){return Math.round(getResources().getDisplayMetrics().density*v);}
  private GradientDrawable bg(){GradientDrawable d=new GradientDrawable();d.setColor(0xFF142739);d.setCornerRadius(dp(13));d.setStroke(dp(1),0xFF38677D);return d;}
  private TextView text(String s,int sz,int color){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(sz);return t;}
  private TextView button(String s,Runnable work){TextView t=text(s,12,CYAN);t.setGravity(Gravity.CENTER);t.setBackground(bg());t.setOnClickListener(v->work.run());return t;}
  private void rowButton(LinearLayout row,String s,Runnable action){TextView b=button(s,action);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(43),1f);p.rightMargin=dp(5);row.addView(b,p);}
  @Override public void onCreate(Bundle b){super.onCreate(b);RunningballV17Insets.install(this);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    LinearLayout root=new LinearLayout(this);root.setBackgroundColor(BG);root.setPadding(dp(10),dp(10),dp(10),dp(11));root.setOrientation(LinearLayout.VERTICAL);
    TextView title=text("WORLDWIDE EARTH INTELLIGENCE",20,INK);title.setTypeface(null,Typeface.BOLD);root.addView(title);
    root.addView(text("Explore ANY latitude/longitude worldwide. Aircraft queries are regional (250 NM), not complete global radar.",11,MUTED));
    LinearLayout look=new LinearLayout(this);query=new EditText(this);query.setTextColor(INK);query.setHintTextColor(MUTED);query.setSingleLine(true);
    query.setHint("City, country region, or lat,lon");query.setTextSize(13);query.setBackground(bg());
    look.addView(query,new LinearLayout.LayoutParams(0,dp(46),1f));TextView search=button("FIND",this::lookup);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(65),dp(46));sp.leftMargin=dp(5);look.addView(search,sp);
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(46));lp.topMargin=dp(8);root.addView(look,lp);
    HorizontalScrollView strip=new HorizontalScrollView(this);LinearLayout chips=new LinearLayout(this);chips.setOrientation(LinearLayout.HORIZONTAL);
    for(int i=0;i<NAMES.length;i++){final int index=i;TextView btn=button(NAMES[i].toUpperCase(Locale.US),()->fly(SITES[index][0],SITES[index][1],NAMES[index]));LinearLayout.LayoutParams chip=new LinearLayout.LayoutParams(-2,dp(37));chip.rightMargin=dp(5);chips.addView(btn,chip);}strip.addView(chips);
    lp=new LinearLayout.LayoutParams(-1,dp(38));lp.topMargin=dp(7);root.addView(strip,lp);
    world=new SatelliteMapView(this);world.setListener(this);world.setGlobeMode(true);
    if(RunningballWorldTarget.ready(this)){double lat=RunningballWorldTarget.lat(this),lon=RunningballWorldTarget.lon(this);selectionName=RunningballWorldTarget.label(this);world.setCenter(lat,lon,3.0);}else world.setCenter(0,0,2.1);
    lp=new LinearLayout.LayoutParams(-1,0,1f);lp.topMargin=dp(7);root.addView(world,lp);
    coordinates=text("",12,INK);root.addView(coordinates);
    status=text("Choose anywhere on Earth, then select that region. Satellite and vessel sources have separate coverage limits.",11,MUTED);root.addView(status);
    LinearLayout nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);
    rowButton(nav,"GLOBE",()->{world.setGlobeMode(true);world.setCenter(0,0,2.1);selectionName="WORLD VIEW";update();});
    rowButton(nav,"MAP",()->{world.setGlobeMode(false);world.setCenter(world.getCenterLatitude(),world.getCenterLongitude(),5.4);update();});
    rowButton(nav,"−",()->{world.zoomBy(-1);update();});rowButton(nav,"+",()->{world.zoomBy(1);update();});
    lp=new LinearLayout.LayoutParams(-1,dp(43));lp.topMargin=dp(7);root.addView(nav,lp);
    TextView reset=button("RESET GLOBAL VIEW / NO REGIONAL AIRCRAFT TOTAL",()->{
      RunningballWorldTarget.resetGlobal(this);world.setGlobeMode(true);world.setCenter(0d,0d,2.1);
      Intent refresh=new Intent(this,AirOperationsWidgets.Command.class);
      refresh.setAction("com.sentongoharuna.worldsituationroom.AIR_WIDGET_REFRESH");sendBroadcast(refresh);
      selectionName="GLOBAL VIEW";status.setText("GLOBAL VIEW: select a sector for aircraft and weather. No global aircraft count is claimed.");update();
    });
    lp=new LinearLayout.LayoutParams(-1,dp(48));lp.topMargin=dp(7);root.addView(reset,lp);
    TextView select=button("SELECT MAP CENTER  /  LOAD REGIONAL AIRCRAFT",this::choose);lp=new LinearLayout.LayoutParams(-1,dp(48));lp.topMargin=dp(7);root.addView(select,lp);
    LinearLayout services=new LinearLayout(this);services.setOrientation(LinearLayout.HORIZONTAL);
    rowButton(services,"AIRCRAFT",()->{choose();open(AirRadarActivity.class);});rowButton(services,"CONTACTS",()->{choose();open(GevContactsActivity.class);});
    rowButton(services,"SATELLITES",()->{choose();open(GevSatelliteActivity.class);});rowButton(services,"VESSELS",()->open(GevMarineActivity.class));
    lp=new LinearLayout.LayoutParams(-1,dp(43));lp.topMargin=dp(6);root.addView(services,lp);
    TextView detail=button("EXPLORE DETAILED EARTH MAP",()->{Intent i=new Intent(this,GevEarthExploreActivity.class);i.putExtra("geo_lat",world.getCenterLatitude());i.putExtra("geo_lon",world.getCenterLongitude());startActivity(i);});
    lp=new LinearLayout.LayoutParams(-1,dp(44));lp.topMargin=dp(6);root.addView(detail,lp);
    TextView events=button("WORLDWIDE EARTHQUAKES AND NASA EVENTS",()->open(RunningballGlobalEventsActivity.class));
    lp=new LinearLayout.LayoutParams(-1,dp(44));lp.topMargin=dp(6);root.addView(events,lp);
    setContentView(root);update();
  }
  private void open(Class<?> cls){startActivity(new Intent(this,cls));}
  private void fly(double lat,double lon,String name){if(!RunningballWorldTarget.valid(lat,lon))return;selectionName=name;world.setCenter(lat,lon,5.0);update();}
  private void update(){if(world==null||coordinates==null)return;coordinates.setText(selectionName+"  /  "+String.format(Locale.US,"%.5f°, %.5f°",world.getCenterLatitude(),world.getCenterLongitude()));}
  @Override public void onViewportChanged(SatelliteMapView.Bounds bounds){selectionName="MAP CENTER";update();}
  @Override public void onSignalTap(Signal signal){if(signal!=null)status.setText(signal.title+" / SOURCE DETAILS VARY");}
  private void choose(){double la=world.getCenterLatitude(),lo=world.getCenterLongitude();
    if(!RunningballWorldTarget.valid(la,lo)){status.setText("INVALID EARTH POSITION");return;}
    RunningballWorldTarget.choose(this,la,lo,selectionName,"WORLD_EXPLORER");
    Intent request=new Intent(this,AirOperationsWidgets.Command.class);request.setAction("com.sentongoharuna.worldsituationroom.AIR_WIDGET_REFRESH");sendBroadcast(request);
    status.setText("REGION SELECTED: "+RunningballWorldTarget.label(this)+". Requesting ADS-B snapshot. Data may be absent or delayed.");
  }
  private void lookup(){String name=query.getText().toString().trim();if(name.isEmpty())return;
    String[] pair=name.replace("geo:","").split(",");if(pair.length==2){try{double lat=Double.parseDouble(pair[0].trim()),lon=Double.parseDouble(pair[1].trim());if(RunningballWorldTarget.valid(lat,lon)){fly(lat,lon,"COORDINATE TARGET");return;}}catch(NumberFormatException ignored){}}
    for(int i=0;i<NAMES.length;i++)if(NAMES[i].equalsIgnoreCase(name)){fly(SITES[i][0],SITES[i][1],NAMES[i]);return;}
    if(System.currentTimeMillis()-lastLookup<1600){status.setText("SEARCH RATE LIMIT • PLEASE TRY AGAIN");return;}
    lastLookup=System.currentTimeMillis();status.setText("SEARCHING GLOBAL PLACES…");
    new Thread(()->{try{String url="https://geocoding-api.open-meteo.com/v1/search?name="+URLEncoder.encode(name,"UTF-8")+"&count=8&language=en&format=json";
      HttpURLConnection con=(HttpURLConnection)new URL(url).openConnection();try{
        con.setConnectTimeout(7500);con.setReadTimeout(7500);con.setRequestProperty("Accept","application/json");
        if(con.getResponseCode()!=200)throw new IllegalStateException("HTTP "+con.getResponseCode());
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();InputStream in=con.getInputStream();try{byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){if(bytes.size()+n>150000)throw new IllegalStateException("RESULT TOO LARGE");bytes.write(buf,0,n);}}finally{in.close();}
        JSONArray results=new JSONObject(bytes.toString("UTF-8")).optJSONArray("results");
        if(results==null||results.length()==0)throw new IllegalStateException("NO LOCATION MATCH");
        final String[] options=new String[results.length()];final double[][] coords=new double[results.length()][2];
        for(int k=0;k<results.length();k++){JSONObject item=results.optJSONObject(k);if(item==null)continue;
          coords[k][0]=item.optDouble("latitude",Double.NaN);coords[k][1]=item.optDouble("longitude",Double.NaN);
          options[k]=item.optString("name","PLACE")+" · "+item.optString("country","")+" · "+item.optString("admin1","");}
        runOnUiThread(()->new AlertDialog.Builder(this).setTitle("SELECT GLOBAL LOCATION").setItems(options,(d,k)->fly(coords[k][0],coords[k][1],options[k])).show());
      }finally{con.disconnect();}}
      catch(Exception error){runOnUiThread(()->status.setText("PLACE SEARCH UNAVAILABLE: "+error.getMessage()+". Use latitude,longitude."));}
    }).start();
  }
}
