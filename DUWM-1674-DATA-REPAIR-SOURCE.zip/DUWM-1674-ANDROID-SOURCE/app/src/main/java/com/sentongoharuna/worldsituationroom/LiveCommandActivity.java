package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.content.Intent;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.HorizontalScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** V1153: live-first native screen with real, source-attributed measurements and motion. */
public final class LiveCommandActivity extends Activity {
    private static final int BG = Color.rgb(5,14,28), PANEL=Color.rgb(12,29,49);
    private static final int BLUE=Color.rgb(77,224,245), WHITE=Color.rgb(232,244,247), GREY=Color.rgb(158,182,197);
    private static final long FETCH_MS = 180000L;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final AtomicBoolean requesting=new AtomicBoolean(false);
    private final List<LiveEarthGlobeView.Position> airPoints=new ArrayList<>();
    private final List<LiveEarthGlobeView.Position> quakePoints=new ArrayList<>();
    private LiveEarthGlobeView globe;
    private TextView clock, summary, airValue, airStatus, quakeValue, quakeStatus, nasaValue, nasaStatus, issValue, issStatus;
    private TextView airToggle, quakeToggle;
    private long lastRequestedAt=-FETCH_MS;
    private long lastSuccessfulAt=0;
    private int receivedSources=0;
    private boolean displayAircraft=true, displayQuakes=true;
    private boolean resumed=false;
    private final Runnable tick=new Runnable(){@Override public void run(){
        if(!resumed)return;
        clock.setText("UTC " + timeUTC(System.currentTimeMillis()) + "  •  MOTION ACTIVE");
        if(!requesting.get() && (SystemClock.elapsedRealtime()-lastRequestedAt >= FETCH_MS)) refresh();
        ui.postDelayed(this,1000);
    }};
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private String timeUTC(long ms){
        SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);
        fmt.setTimeZone(TimeZone.getTimeZone("UTC"));return fmt.format(new Date(ms));
    }
    private GradientDrawable panel(int stroke) {
        GradientDrawable d=new GradientDrawable();d.setColor(PANEL);d.setCornerRadius(dp(12));
        d.setStroke(dp(1),stroke);return d;
    }
    private TextView text(String value,int sp,int color,boolean bold){
        TextView v=new TextView(this);v.setText(value);v.setTextColor(color);v.setTextSize(sp);
        if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return v;
    }
    private void add(LinearLayout parent,View v,int h){ parent.addView(v,new LinearLayout.LayoutParams(-1,h<0?h:dp(h))); }
    private void pad(View view,int h,int v){view.setPadding(dp(h),dp(v),dp(h),dp(v));}
    private TextView makeCard(LinearLayout host,String title,String label,TextView[] box){
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(panel(Color.rgb(27,76,102)));pad(panel,14,12);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,-2);pp.topMargin=dp(9);host.addView(panel,pp);
        TextView heading=text(title,12,BLUE,true);add(panel,heading,-2);
        TextView big=text(label,25,WHITE,true);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(4);panel.addView(big,bp);
        TextView status=text("Awaiting verified source response",12,GREY,false);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(3);panel.addView(status,sp);
        box[0]=big;box[1]=status;return big;
    }
    @Override public void onCreate(Bundle state){super.onCreate(state);setTheme(android.R.style.Theme_Material_NoActionBar);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        setContentView(root);
        LinearLayout brand=new LinearLayout(this);brand.setGravity(Gravity.CENTER_VERTICAL);pad(brand,12,9);add(root,brand,70);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.develop_uganda_logo);brand.addView(logo,new LinearLayout.LayoutParams(dp(55),dp(55)));
        LinearLayout headings=new LinearLayout(this);headings.setOrientation(LinearLayout.VERTICAL);headings.setPadding(dp(12),0,0,0);
        brand.addView(headings,new LinearLayout.LayoutParams(0,-2,1));
        add(headings,text("WORLD SITUATION ROOM",18,WHITE,true),-2);
        add(headings,text("DEVELOP.UGANDA  •  V1154 WORLD COMMAND",11,BLUE,true),-2);
        clock=text("UTC  --  •  STARTING MOTION",11,GREY,true);pad(clock,14,7);add(root,clock,32);
        globe=new LiveEarthGlobeView(this);root.addView(globe,new LinearLayout.LayoutParams(-1,dp(285)));
        LinearLayout toggleRow=new LinearLayout(this);pad(toggleRow,11,6);add(root,toggleRow,42);
        airToggle=text("● AIRCRAFT",13,BLUE,true);quakeToggle=text("● EARTHQUAKES",13,Color.rgb(255,191,87),true);
        toggleRow.addView(airToggle,new LinearLayout.LayoutParams(0,-2,1));toggleRow.addView(quakeToggle,new LinearLayout.LayoutParams(0,-2,1));
        airToggle.setOnClickListener(v->{displayAircraft=!displayAircraft;globe.showAircraft(displayAircraft);airToggle.setAlpha(displayAircraft?1f:0.35f);});
        quakeToggle.setOnClickListener(v->{displayQuakes=!displayQuakes;globe.showQuakes(displayQuakes);quakeToggle.setAlpha(displayQuakes?1f:0.35f);});
        // V1154 category rail: the rotating globe remains the first and main page.
        HorizontalScrollView ribbon=new HorizontalScrollView(this);ribbon.setHorizontalScrollBarEnabled(false);
        root.addView(ribbon,new LinearLayout.LayoutParams(-1,dp(64)));
        LinearLayout sectors=new LinearLayout(this);sectors.setGravity(Gravity.CENTER_VERTICAL);
        sectors.setPadding(dp(7),dp(5),dp(7),dp(5));ribbon.addView(sectors);
        for(String sector:WorldSourceHubActivity.MODES){
            TextView tab=text(sector,12,BLUE,true);tab.setGravity(Gravity.CENTER);
            tab.setBackground(panel(Color.rgb(29,79,100)));tab.setPadding(dp(13),dp(10),dp(13),dp(10));
            tab.setContentDescription("Open live source " + sector);
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-2,dp(48));tp.rightMargin=dp(7);sectors.addView(tab,tp);
            tab.setOnClickListener(v->{Intent next=new Intent(this,WorldSourceHubActivity.class);next.putExtra("mode",sector);startActivity(next);});
        }
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout feed=new LinearLayout(this);feed.setOrientation(LinearLayout.VERTICAL);pad(feed,12,9);scroll.addView(feed);
        summary=text("LIVE SOURCE HEALTH  |  Initialising HTTPS connections",12,BLUE,true);add(feed,summary,-2);
        TextView[] a=new TextView[2];makeCard(feed,"OPENSKY • OBSERVED AIRCRAFT", "CONNECTING",a);airValue=a[0];airStatus=a[1];
        TextView[] q=new TextView[2];makeCard(feed,"USGS • MAGNITUDE 4.5+ / LAST 24 HOURS", "CONNECTING",q);quakeValue=q[0];quakeStatus=q[1];
        TextView[] n=new TextView[2];makeCard(feed,"NASA • DSCOVR EPIC EARTH IMAGERY", "CONNECTING",n);nasaValue=n[0];nasaStatus=n[1];
        TextView[] satViews=new TextView[2];makeCard(feed,"ISS • REPORTED LIVE SPACE STATION POSITION", "CONNECTING",satViews);issValue=satViews[0];issStatus=satViews[1];
        TextView note=text("Source readings are never simulated. Network or permission failures are shown explicitly. Geolocated dots only appear after real responses. Last updates use UTC.",12,GREY,false);
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=dp(14);feed.addView(note,np);
        Button refresh=new Button(this);refresh.setText("REFRESH OBSERVED DATA");refresh.setTextColor(BLUE);refresh.setAllCaps(false);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(52));rp.topMargin=dp(10);feed.addView(refresh,rp);
        refresh.setOnClickListener(v->refresh());
        Button original=new Button(this);original.setText("OPEN ORIGINAL COMMAND CENTRE");original.setAllCaps(false);original.setTextColor(WHITE);
        LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,dp(54));op.topMargin=dp(6);feed.addView(original,op);
        original.setOnClickListener(v->{Intent open=new Intent(this,MainActivity.class);open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);startActivity(open);});
    }
    @Override protected void onResume(){super.onResume();resumed=true;globe.resumeMotion();ui.post(tick);}
    @Override protected void onPause(){resumed=false;globe.pauseMotion();ui.removeCallbacks(tick);super.onPause();}
    @Override protected void onDestroy(){worker.shutdownNow();super.onDestroy();}

    private String readJson(String url) throws Exception {
        HttpURLConnection connection=(HttpURLConnection)new URL(url).openConnection();
        connection.setConnectTimeout(7500);connection.setReadTimeout(9000);
        connection.setRequestProperty("Accept","application/json");
        connection.setRequestProperty("User-Agent","DevelopUgandaWorldSituationRoom/1153");
        try{
            int code=connection.getResponseCode();
            if(code!=200)throw new java.io.IOException("HTTP "+code);
            InputStream in=connection.getInputStream();BufferedReader reader=new BufferedReader(new InputStreamReader(in,"UTF-8"));
            StringBuilder body=new StringBuilder();String line;
            while((line=reader.readLine())!=null){body.append(line);if(body.length()>3000000)throw new java.io.IOException("Response exceeds 3MB bound");}
            reader.close();return body.toString();
        }finally{connection.disconnect();}
    }
    private static boolean valid(double lat,double lon){return !Double.isNaN(lat)&&!Double.isInfinite(lat)&&!Double.isNaN(lon)&&!Double.isInfinite(lon)&&lat>=-90&&lat<=90&&lon>=-180&&lon<=180;}
    private void refresh(){
        if(!requesting.compareAndSet(false,true))return;
        lastRequestedAt=SystemClock.elapsedRealtime();
        summary.setText("SOURCE HEALTH  |  Contacting independent providers...");
        worker.execute(()->{
            List<LiveEarthGlobeView.Position> newAir=new ArrayList<>(),newQuakes=new ArrayList<>(),newSat=new ArrayList<>();
            String av="UNAVAILABLE",qv="UNAVAILABLE",nv="UNAVAILABLE",iv="UNAVAILABLE";
            String as="",qs="",ns="",is="";int ok=0;
            try{
                JSONObject payload=new JSONObject(readJson("https://opensky-network.org/api/states/all"));
                JSONArray states=payload.optJSONArray("states");
                if(states==null)throw new java.io.IOException("No states array");
                int count=states.length(),validCount=0;
                int skip=Math.max(1,count/900);
                for(int i=0;i<count;i++){
                    JSONArray entry=states.optJSONArray(i);if(entry==null||entry.isNull(5)||entry.isNull(6))continue;
                    double lon=entry.optDouble(5,Double.NaN),lat=entry.optDouble(6,Double.NaN);
                    if(valid(lat,lon)){validCount++;if(i%skip==0)newAir.add(new LiveEarthGlobeView.Position(lat,lon));}
                }
                av=String.format(Locale.US,"%,d reported aircraft",count);
                long provider=payload.optLong("time",0);
                as="HTTPS 200  •  positions " + validCount + "  •  observed " + (provider>0?timeUTC(provider*1000L):"time not supplied") + " UTC";
                ok++;
            }catch(Exception ex){as="OpenSky: " + safeError(ex);}
            try{
                JSONObject payload=new JSONObject(readJson("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson"));
                JSONArray features=payload.getJSONArray("features");
                int count=features.length();
                for(int i=0;i<count&&i<500;i++){
                    JSONObject geometry=features.optJSONObject(i)==null?null:features.optJSONObject(i).optJSONObject("geometry");
                    if(geometry==null)continue;JSONArray coords=geometry.optJSONArray("coordinates");if(coords==null||coords.length()<2)continue;
                    double lon=coords.optDouble(0,Double.NaN),lat=coords.optDouble(1,Double.NaN);
                    if(valid(lat,lon))newQuakes.add(new LiveEarthGlobeView.Position(lat,lon));
                }
                qv=count+" reported earthquakes";
                qs="HTTPS 200  •  " + newQuakes.size() + " geolocated  •  checked " + timeUTC(System.currentTimeMillis()) + " UTC";
                ok++;
            }catch(Exception ex){qs="USGS: " + safeError(ex);}
            try{
                JSONArray arr=new JSONArray(readJson("https://epic.gsfc.nasa.gov/api/natural"));
                nv=arr.length()+" latest image records";
                String when=arr.length()>0?arr.optJSONObject(0).optString("date","not supplied"):"no image today";
                ns="NASA HTTPS 200  •  latest " + when + " UTC";
                ok++;
            }catch(Exception ex){ns="NASA: " + safeError(ex);}
            try{
                JSONObject pos=new JSONObject(readJson("https://api.wheretheiss.at/v1/satellites/25544"));
                double lat=pos.optDouble("latitude",Double.NaN),lon=pos.optDouble("longitude",Double.NaN);
                if(!valid(lat,lon))throw new java.io.IOException("ISS coordinates absent");
                long source=pos.optLong("timestamp",0);
                if(source<=0||Math.abs(System.currentTimeMillis()/1000L-source)>900L)throw new java.io.IOException("ISS position stale or undated");
                newSat.add(new LiveEarthGlobeView.Position(lat,lon));
                iv=String.format(Locale.US,"ISS %.2f° / %.2f°",lat,lon);
                is="Reported UTC "+timeUTC(source*1000L)+" • not a simulated orbit";ok++;
            }catch(Exception ex){is="ISS provider: "+safeError(ex);}
            final String rav=av,ras=as,rqv=qv,rqs=qs,rnv=nv,rns=ns,riv=iv,ris=is;
            final int successes=ok;
            ui.post(()->{
                if(isFinishing()||isDestroyed())return;
                airValue.setText(rav);airStatus.setText(ras);
                quakeValue.setText(rqv);quakeStatus.setText(rqs);
                nasaValue.setText(rnv);nasaStatus.setText(rns);issValue.setText(riv);issStatus.setText(ris);
                airPoints.clear();airPoints.addAll(newAir);quakePoints.clear();quakePoints.addAll(newQuakes);
                globe.setObservations(airPoints,quakePoints);globe.setSatellites(newSat);
                receivedSources=successes;
                if(successes>0)lastSuccessfulAt=SystemClock.elapsedRealtime();
                summary.setText("SOURCE HEALTH  |  " + receivedSources+"/4 providers reached  •  " + timeUTC(System.currentTimeMillis()) +" UTC");
                requesting.set(false);
            });
        });
    }
    private static String safeError(Exception e){
        String m=e.getMessage();if(m==null)m=e.getClass().getSimpleName();
        return m.length()>90?m.substring(0,90):m;
    }
}
