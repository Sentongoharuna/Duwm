package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/** A genuinely moving graticule. Dots are strictly fetched geolocated observations. */
public final class LiveEarthGlobeView extends View {
    public static final class Position {
        public final double lat;
        public final double lon;
        public Position(double latitude, double longitude) { lat=latitude; lon=longitude; }
    }
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Position> aircraft = new ArrayList<>();
    private final List<Position> quakes = new ArrayList<>();
    private final List<Position> satellites = new ArrayList<>();
    private final List<List<Position>> coastlines = new ArrayList<>();
    private boolean showAircraft = true;
    private boolean showQuakes = true;
    private boolean active = false;
    private long lastFrame = 0L;
    private double yaw = 0.0;
    private float cx, cy, radius;

    public LiveEarthGlobeView(Context context) {
        super(context); setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        loadWorldCoasts();
    }
    private void loadWorldCoasts() {
        try (BufferedReader reader=new BufferedReader(new InputStreamReader(getContext().getAssets().open("naturalearth_coasts.txt"),"UTF-8"))) {
            String row;
            while((row=reader.readLine())!=null){
                List<Position> coast=new ArrayList<>();
                for(String point:row.split(" ")){
                    String[] xy=point.split(",");if(xy.length!=2)continue;
                    double lat=Double.parseDouble(xy[0]),lon=Double.parseDouble(xy[1]);
                    if(!Double.isNaN(lat)&&!Double.isNaN(lon))coast.add(new Position(lat,lon));
                }
                if(coast.size()>=3)coastlines.add(coast);
            }
        }catch(Exception ignored){ /* A missing asset never creates fake coastline. */ }
    }
    private void paintCoasts(Canvas canvas) {
        p.setStyle(Paint.Style.STROKE);p.setShader(null);p.setStrokeWidth(1.55f);
        p.setColor(Color.argb(225,102,219,192));
        for(List<Position> coast:coastlines){
            Path outline=new Path();boolean visible=false;
            for(Position point:coast){
                float[] spot=screen(point.lat,point.lon);
                if(spot==null){visible=false;continue;}
                if(!visible){outline.moveTo(spot[0],spot[1]);visible=true;}
                else outline.lineTo(spot[0],spot[1]);
            }
            canvas.drawPath(outline,p);
        }
    }
    public void setObservations(List<Position> aircraftObserved, List<Position> earthquakeObserved) {
        aircraft.clear(); aircraft.addAll(aircraftObserved);
        quakes.clear(); quakes.addAll(earthquakeObserved);
        invalidate();
    }
    public void setSatellites(List<Position> received) { satellites.clear();satellites.addAll(received);invalidate(); }
    public void showAircraft(boolean show) { showAircraft=show; invalidate(); }
    public void showQuakes(boolean show) { showQuakes=show; invalidate(); }
    public void resumeMotion() { active=true; lastFrame=SystemClock.uptimeMillis(); invalidate(); }
    public void pauseMotion() { active=false; }
    @Override protected void onDetachedFromWindow() { active=false; super.onDetachedFromWindow(); }

    private float[] screen(double lat, double lon) {
        double phi = Math.toRadians(lat), lambda = Math.toRadians(lon)-yaw;
        double depth = Math.cos(phi)*Math.cos(lambda);
        if (depth <= 0) return null;
        return new float[] { cx+(float)(radius*Math.cos(phi)*Math.sin(lambda)), cy-(float)(radius*Math.sin(phi)) };
    }
    private void gridLine(Canvas c, boolean meridian, int coordinate) {
        Path path = new Path(); boolean inside=false;
        for (int step=0; step<=180; step++) {
            double lat=meridian?-90+step:coordinate;
            double lon=meridian?coordinate:-180+2.0*step;
            float[] v=screen(lat,lon);
            if(v==null){inside=false;continue;}
            if(!inside){path.moveTo(v[0],v[1]);inside=true;}else path.lineTo(v[0],v[1]);
        }
        c.drawPath(path,p);
    }
    private void plot(Canvas c,List<Position> points,int color,float size) {
        p.setColor(color);p.setStyle(Paint.Style.FILL);p.setShader(null);
        int cap=0;
        for(Position x:points){
            if(cap++>=1100)break;
            float[] v=screen(x.lat,x.lon);
            if(v!=null){c.drawCircle(v[0],v[1],size,p);}
        }
    }
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        if(active){
            long now=SystemClock.uptimeMillis();
            long delta=Math.min(80L,Math.max(0,now-lastFrame));
            yaw=(yaw+delta*0.00017)%(Math.PI*2.0);
            lastFrame=now;
        }
        final float w=getWidth(),h=getHeight();
        cx=w*0.50f;cy=h*0.50f;radius=Math.max(10f,Math.min(w*0.445f,h*0.465f));
        p.setStyle(Paint.Style.FILL);p.setShader(null);p.setColor(Color.rgb(6,17,34));
        c.drawColor(Color.rgb(5,14,28));
        p.setColor(Color.rgb(17,50,75));c.drawCircle(cx,cy,radius+12,p);
        p.setShader(new LinearGradient(cx-radius,cy-radius,cx+radius,cy+radius,
            Color.rgb(13,64,95),Color.rgb(2,18,39),Shader.TileMode.CLAMP));
        c.drawCircle(cx,cy,radius,p);p.setShader(null);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.15f);p.setColor(Color.argb(136,77,179,198));
        for(int mer=-180;mer<180;mer+=20)gridLine(c,true,mer);
        p.setColor(Color.argb(105,64,159,198));
        for(int lat=-75;lat<=75;lat+=15)gridLine(c,false,lat);
        paintCoasts(c);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3f);p.setColor(Color.rgb(67,214,222));
        c.drawCircle(cx,cy,radius,p);p.setStyle(Paint.Style.FILL);
        if(showAircraft)plot(c,aircraft,Color.rgb(80,225,255),2.5f);
        if(showQuakes)plot(c,quakes,Color.rgb(255,191,87),4.8f);
        plot(c,satellites,Color.rgb(146,255,175),6.2f);
        p.setTextSize(12f*getResources().getDisplayMetrics().scaledDensity);
        p.setColor(Color.rgb(188,224,233));
        c.drawText("ROTATING EARTH / VERIFIED OBSERVATIONS ONLY",12f,h-14f,p);
        if(active)postInvalidateDelayed(33);
    }
}
