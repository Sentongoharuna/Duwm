package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.SystemClock;
import android.view.View;

/** Animated presentation of real values, not synthetic telemetry. */
public final class Duwm1670DataPulseView extends View {
  private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
  private boolean active;private String category="MARKETS",value="--",status="NO SOURCE RECEIPT";
  private double scalar=Double.NaN;private long fetched;
  private int dp(float x){return Math.round(getResources().getDisplayMetrics().density*x);}
  public Duwm1670DataPulseView(Context c){super(c);setContentDescription("Market / weather status graphics use actual source values. Decorative motion does not represent changing prices or forecast observations.");}
  public void update(String layer,String figure,double number,String state,long sourceReceived){category=layer;value=figure;scalar=number;status=state;fetched=sourceReceived;invalidate();}
  public void start(){active=true;postInvalidateDelayed(100);}
  public void stop(){active=false;}
  @Override protected void onDetachedFromWindow(){stop();super.onDetachedFromWindow();}
  @Override protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight();c.drawColor(0xFF0A2232);
    p.setStyle(Paint.Style.FILL);p.setTextSize(dp(12));p.setColor(0xFF88DCE8);c.drawText(category+"  /  VERIFIED SOURCE STATUS",dp(16),dp(25),p);
    p.setTextSize(dp(32));p.setColor(0xFFF2F8F8);c.drawText(value.length()>18?value.substring(0,18):value,dp(16),h/2f,p);
    p.setTextSize(dp(11));p.setColor(0xFFB2C2CE);c.drawText(status.length()>58?status.substring(0,58):status,dp(16),h-dp(18),p);
    // A display activity indicator is not a data point or a fictional price chart.
    float t=(float)(SystemClock.uptimeMillis()%2200)/2200f;
    p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2));p.setColor(fetched>0?0xFF65D4C5:0xFFAD8672);
    float r=dp(18)+dp(8)*t;c.drawCircle(w-dp(36),h/2f,r,p);
    p.setColor(fetched>0?0xFF65D4C5:0xFFAD8672);p.setStyle(Paint.Style.FILL);c.drawCircle(w-dp(36),h/2f,dp(6),p);
    if(active)postInvalidateDelayed(95);
  }
}
