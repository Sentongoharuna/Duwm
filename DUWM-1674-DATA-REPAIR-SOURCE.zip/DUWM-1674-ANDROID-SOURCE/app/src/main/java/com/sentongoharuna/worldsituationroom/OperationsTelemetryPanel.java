package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** Real source-backed operational observations, never simulated entries or coordinates. */
public final class OperationsTelemetryPanel extends LinearLayout {
    public interface OnSelect {void onSelection(OperationsGlobeView.Observation observation);}
    private final int BG=Color.rgb(11,24,35), BORDER=Color.rgb(45,68,79);
    private final int TEXT=Color.rgb(229,237,240), MUTED=Color.rgb(164,186,195);
    private final int AQUA=Color.rgb(115,198,210), AMBER=Color.rgb(242,190,112), GREEN=Color.rgb(152,208,171);
    private final LinearLayout items;
    private final TextView summary, airBadge, quakeBadge, spaceBadge, label;
    private OnSelect onSelect;
    private boolean showAir=true,showQuakes=true,showSpace=true;
    private final ArrayList<OperationsGlobeView.Observation> current=new ArrayList<>();
    private String lastAir="NOT RECEIVED",lastQuake="NOT RECEIVED",lastSpace="NOT RECEIVED";
    private int sourceOk=0, sourceAir=0,sourceQuake=0,sourceSpace=0;
    private long lastReceived=0;
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable surface(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(5));d.setStroke(dp(1),BORDER);return d;}
    private TextView text(String s,int sp,int color,boolean bold){TextView v=new TextView(getContext());v.setText(s);v.setTextSize(sp);v.setTextColor(color);if(bold)v.setTypeface(Typeface.create("sans-serif-medium",0));v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private String utc(long millis){if(millis<=0)return "TIME NOT PROVIDED";SimpleDateFormat sdf=new SimpleDateFormat("dd MMM HH:mm:ss",Locale.US);sdf.setTimeZone(TimeZone.getTimeZone("UTC"));return sdf.format(new Date(millis))+" UTC";}
    public OperationsTelemetryPanel(Context c){super(c);setOrientation(VERTICAL);setBackgroundColor(BG);setPadding(dp(12),dp(8),dp(12),dp(5));
        LinearLayout top=new LinearLayout(c);top.setGravity(Gravity.CENTER_VERTICAL);addView(top,new LayoutParams(-1,dp(29)));
        label=text("OBSERVED SIGNALS  /  REAL-TIME RECEIPTS",12,TEXT,true);top.addView(label,new LayoutParams(0,-1,1));
        TextView mark=text("LIVE / UTC",10,AQUA,true);top.addView(mark);
        LinearLayout counts=new LinearLayout(c);counts.setGravity(Gravity.CENTER_VERTICAL);addView(counts,new LayoutParams(-1,dp(40)));
        airBadge=badge(counts,"AIR  —",AQUA);quakeBadge=badge(counts,"SEISMIC  —",AMBER);spaceBadge=badge(counts,"SPACE  —",GREEN);
        summary=text("Connecting to authoritative public sources; no synthetic activity",11,MUTED,false);addView(summary,new LayoutParams(-1,dp(31)));
        View line=new View(c);line.setBackgroundColor(BORDER);addView(line,new LayoutParams(-1,dp(1)));
        ScrollView sc=new ScrollView(c);sc.setFillViewport(false);sc.setVerticalScrollBarEnabled(false);addView(sc,new LayoutParams(-1,0,1));
        items=new LinearLayout(c);items.setOrientation(VERTICAL);sc.addView(items,new ScrollView.LayoutParams(-1,-2));
        render();
    }
    private TextView badge(LinearLayout p,String text,int color){TextView v=text(text,11,color,true);v.setGravity(Gravity.CENTER);v.setBackground(surface(Color.rgb(17,37,47)));LayoutParams a=new LayoutParams(0,dp(34),1);a.rightMargin=dp(6);p.addView(v,a);return v;}
    public void setOnSelect(OnSelect select){onSelect=select;}
    public void setVisibilityLayers(boolean air,boolean quakes,boolean space){showAir=air;showQuakes=quakes;showSpace=space;render();}
    public void setSyncing(){summary.setText("REQUESTING VERIFIED DATA  /  SOURCE TIMEOUTS SHOWN BELOW");}
    public void update(List<OperationsGlobeView.Observation> received,int ok,int reportedAir,int reportedQuakes,
                       String airStatus,String quakeStatus,String spaceStatus,long timestamp){
        current.clear();current.addAll(received);sourceOk=ok;sourceAir=reportedAir;sourceQuake=reportedQuakes;
        sourceSpace=0;for(OperationsGlobeView.Observation item:received)if(item.type==OperationsGlobeView.SPACE)sourceSpace++;
        lastAir=airStatus;lastQuake=quakeStatus;lastSpace=spaceStatus;lastReceived=timestamp;
        render();
    }
    private void statusRow(String title,String message,int accent){
        LinearLayout row=new LinearLayout(getContext());row.setOrientation(VERTICAL);
        row.setPadding(dp(10),dp(8),dp(8),dp(9));row.setBackground(surface(Color.rgb(15,30,41)));
        LayoutParams lp=new LayoutParams(-1,-2);lp.topMargin=dp(5);items.addView(row,lp);
        TextView heading=text(title,12,accent,true);row.addView(heading);
        TextView explanation=text(message,11,MUTED,false);explanation.setMaxLines(2);row.addView(explanation);
    }
    private String displayStatus(String s){if(s==null||s.isEmpty())return "NO CONTACT";return s;}
    private void render(){
        airBadge.setText("AIR  "+(sourceAir>0?Integer.toString(sourceAir):"—"));quakeBadge.setText("QUAKES  "+(sourceQuake>0?Integer.toString(sourceQuake):"—"));spaceBadge.setText("ISS  "+(sourceSpace>0?"RECEIVED":"—"));
        summary.setText(sourceOk+"/3 SOURCES  •  LAST CHECK "+(lastReceived>0?utc(lastReceived):"NOT YET RECEIVED"));
        items.removeAllViews();
        ArrayList<OperationsGlobeView.Observation> visible=new ArrayList<>();
        for(OperationsGlobeView.Observation o:current){if((o.type==OperationsGlobeView.AIR&&showAir)||(o.type==OperationsGlobeView.QUAKE&&showQuakes)||(o.type==OperationsGlobeView.SPACE&&showSpace))visible.add(o);}
        Collections.sort(visible,new Comparator<OperationsGlobeView.Observation>(){public int compare(OperationsGlobeView.Observation a,OperationsGlobeView.Observation b){return Long.compare(b.timeMillis,a.timeMillis);}});
        if(visible.isEmpty()){
            statusRow("AIRCRAFT / OPEN SKY",displayStatus(lastAir),AQUA);
            statusRow("EARTHQUAKES / USGS",displayStatus(lastQuake),AMBER);
            statusRow("SATELLITE / ISS",displayStatus(lastSpace),GREEN);
            TextView empty=text("NO OBSERVED MAP RECORDS. This is not a zero-activity report.",12,MUTED,false);empty.setPadding(dp(5),dp(10),0,dp(7));items.addView(empty);return;
        }
        // Prominent source status rows ensure one failing service never masquerades as an all-clear.
        if(lastAir.startsWith("Unavailable"))statusRow("AIRCRAFT SOURCE",lastAir,AQUA);
        if(lastQuake.startsWith("Unavailable"))statusRow("USGS SOURCE",lastQuake,AMBER);
        if(lastSpace.startsWith("Unavailable"))statusRow("ISS SOURCE",lastSpace,GREEN);
        // Source diversity first; fill remainder with recent actual records only.
        ArrayList<OperationsGlobeView.Observation> selected=new ArrayList<>();
        for(int type:new int[]{OperationsGlobeView.SPACE,OperationsGlobeView.QUAKE,OperationsGlobeView.AIR})for(OperationsGlobeView.Observation v:visible){if(v.type==type){selected.add(v);break;}}
        for(OperationsGlobeView.Observation v:visible){if(selected.size()>=15)break;if(!selected.contains(v))selected.add(v);}
        for(OperationsGlobeView.Observation v:selected){
            int tint=v.type==OperationsGlobeView.AIR?AQUA:v.type==OperationsGlobeView.QUAKE?AMBER:GREEN;
            LinearLayout row=new LinearLayout(getContext());row.setOrientation(VERTICAL);row.setPadding(dp(10),dp(7),dp(8),dp(8));row.setBackground(surface(Color.rgb(15,30,41)));
            LayoutParams rp=new LayoutParams(-1,-2);rp.topMargin=dp(4);items.addView(row,rp);
            String type=v.type==OperationsGlobeView.AIR?"AIRCRAFT":v.type==OperationsGlobeView.QUAKE?"SEISMIC EVENT":"SATELLITE";
            TextView heading=text(type+"   •   "+v.title,12,TEXT,true);heading.setSingleLine(true);heading.setEllipsize(android.text.TextUtils.TruncateAt.END);row.addView(heading);
            TextView metadata=text(v.source+"  /  "+utc(v.timeMillis)+"  /  TAP TO LOCATE",10,tint,false);metadata.setSingleLine(true);metadata.setEllipsize(android.text.TextUtils.TruncateAt.END);row.addView(metadata);
            row.setContentDescription("Inspect "+type+" "+v.title+" on globe");row.setOnClickListener(w->{if(onSelect!=null)onSelect.onSelection(v);});
        }
    }
}
