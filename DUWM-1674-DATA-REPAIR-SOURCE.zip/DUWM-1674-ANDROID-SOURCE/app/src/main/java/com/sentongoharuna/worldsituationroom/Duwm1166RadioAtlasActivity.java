package com.sentongoharuna.worldsituationroom;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.view.View;
import android.view.MotionEvent;
import android.widget.*;
import android.content.Intent;
import org.json.*;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** In-app station atlas with real Radio Browser geo coordinates and working audio status. */
public final class Duwm1166RadioAtlasActivity extends Activity {
  private static final int BG=0xFF06131F;
  private static final String[] LABELS={"WORLD","UGANDA","KENYA","NIGERIA","INDIA","MIDDLE EAST","SOUTH AFRICA","UK","USA"};
  private static final String[] CODES={"","UG","KE","NG","IN","AE","ZA","GB","US"};
  private LinearLayout stations,filters;private TextView status;
  private final ArrayList<Station> found=new ArrayList<>();private Atlas atlas;private MediaPlayer player;
  private static final class Station {String name,url,code,region;Double lat,lon;}
  private int dp(float x){return (int)(getResources().getDisplayMetrics().density*x+.5f);}
  private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);return t;}
  @Override public void onCreate(Bundle saved){super.onCreate(saved);getWindow().setStatusBarColor(BG);
    ScrollView sc=new ScrollView(this);sc.setBackgroundColor(BG);setContentView(sc);Duwm1167SafeArea.install(this,sc);
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(12),dp(16),dp(12),dp(24));sc.addView(root);
    root.addView(text("RADIO ATLAS   /   DUWM 1673",18,Color.WHITE));
    root.addView(text("Geotagged stations only; radio map dots are sourced from Radio Browser",11,0xFF9FBDCA));
    status=text("No station response received",12,0xFF55D9EF);root.addView(status);
    TextView stopAudio=text("■ STOP AUDIO",12,0xFFFFB978);stopAudio.setPadding(dp(4),dp(10),dp(4),dp(12));
    stopAudio.setOnClickListener(v->{stop();status.setText("PLAYBACK STOPPED  /  SELECT A STATION");});root.addView(stopAudio);
    HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setHorizontalScrollBarEnabled(false);root.addView(scroll);
    filters=new LinearLayout(this);scroll.addView(filters);
    for(int i=0;i<LABELS.length;i++){final int index=i;TextView b=text("  "+LABELS[i]+"  ",13,0xFF70E4F4);b.setPadding(dp(8),dp(14),dp(8),dp(14));b.setOnClickListener(v->fetch(CODES[index],LABELS[index]));filters.addView(b);}
    atlas=new Atlas();root.addView(atlas,new LinearLayout.LayoutParams(-1,dp(245)));
    TextView note=text("Radio map: official station coordinates and Natural Earth outlines. Tap a point to select a station.",11,0xFFA7BECA);root.addView(note);
    stations=new LinearLayout(this);stations.setOrientation(LinearLayout.VERTICAL);root.addView(stations);
    fetch("UG","UGANDA");
  }
  private void fetch(String cc,String name){status.setText(name+"  /  CONNECTING TO RADIO BROWSER");found.clear();atlas.invalidate();stations.removeAllViews();
    final String url="https://de1.api.radio-browser.info/json/stations/search?hidebroken=true&limit=75&order=votes&reverse=true"+(cc.isEmpty()?"":"&countrycode="+cc);
    new Thread(()->{ArrayList<Station> incoming=new ArrayList<>();String result;HttpURLConnection conn=null;
      try{conn=(HttpURLConnection)new URL(url).openConnection();conn.setConnectTimeout(9000);conn.setReadTimeout(12000);
        conn.setRequestProperty("User-Agent","DEVELOP.UGANDA/1673 public-radio-atlas");
        int http=conn.getResponseCode();if(http!=200)throw new IOException("Radio Browser HTTP "+http);
        ByteArrayOutputStream o=new ByteArrayOutputStream();try(InputStream in=conn.getInputStream()){byte[] b=new byte[4096];int len;while((len=in.read(b))!=-1){if(o.size()+len>1200000)throw new IOException("Radio list too large");o.write(b,0,len);}}
        JSONArray arr=new JSONArray(new String(o.toByteArray(),StandardCharsets.UTF_8));
        for(int i=0;i<arr.length();i++){JSONObject j=arr.optJSONObject(i);if(j==null)continue;
          Station s=new Station();s.name=j.optString("name","").trim();s.url=j.optString("url_resolved","").trim();s.code=j.optString("countrycode","");s.region=j.optString("country","");
          if(s.name.length()<2||!s.url.startsWith("https://"))continue;
          if(!j.isNull("geo_lat")&&!j.isNull("geo_long")){
            double lat=j.optDouble("geo_lat",Double.NaN),lon=j.optDouble("geo_long",Double.NaN);
            if(Double.isFinite(lat)&&Double.isFinite(lon)&&Math.abs(lat)<=90&&Math.abs(lon)<=180){s.lat=lat;s.lon=lon;}}
          incoming.add(s);
        }
        int positioned=0;for(Station station:incoming)if(station.lat!=null&&station.lon!=null)positioned++;
        result=name+"  /  "+incoming.size()+" HTTPS STREAM URLS RECEIVED  /  "+positioned+" MAPPED WITH SOURCE COORDINATES";
      }catch(Exception e){result="RADIO SOURCE UNAVAILABLE  /  "+e.getClass().getSimpleName();}
      finally{if(conn!=null)conn.disconnect();}
      final String message=result;runOnUiThread(()->{if(isFinishing())return;found.clear();found.addAll(incoming);status.setText(message);atlas.invalidate();renderStations();});
    },"duwm1166-radio-lookup").start();
  }
  private void renderStations(){stations.removeAllViews();if(found.isEmpty()){stations.addView(text("NO VERIFIED STATIONS RECEIVED — TRY ANOTHER REGION",12,0xFFFFB967));return;}
    int count=0;for(Station s:found){if(count++>=45)break;LinearLayout line=new LinearLayout(this);line.setOrientation(LinearLayout.HORIZONTAL);line.setPadding(dp(10),dp(11),dp(10),dp(11));
      Duwm1166SignalView signal=new Duwm1166SignalView(this);signal.reference();
      line.addView(signal,new LinearLayout.LayoutParams(dp(29),dp(31)));
      TextView name=text(s.name+"\n"+s.region+(s.lat==null?"  •  NO MAP POSITION":"  •  GPS POSITION PROVIDED"),12,Color.WHITE);line.addView(name,new LinearLayout.LayoutParams(0,-2,1));
      LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.VERTICAL);
      line.addView(actions,new LinearLayout.LayoutParams(dp(96),-2));
      TextView play=text("▶ IN APP",12,0xFF5CE3C8);play.setPadding(dp(5),dp(6),dp(5),dp(7));actions.addView(play);
      TextView share=text("▣ CARD",12,0xFFFFC887);share.setPadding(dp(5),dp(7),dp(5),dp(6));actions.addView(share);
      play.setContentDescription("Play "+s.name+" inside DUWM");share.setContentDescription("Share source-attributed card for "+s.name);
      play.setOnClickListener(v->play(s));share.setOnClickListener(v->shareStation(s));
      line.setOnClickListener(v->play(s));stations.addView(line);
    }
  }
  /** Every received station can export an actual source card; no unverified coordinates are filled in. */
  private void shareStation(Station s){
    String position=s.lat==null||s.lon==null?"Coordinates not supplied by Radio Browser":
      String.format(Locale.US,"Station map point %.5f, %.5f",s.lat,s.lon);
    Duwm1671Share.share(this,"RADIO",s.name,"Country: "+s.region+" / "+position+
        " / Direct player available in this application; stream success is checked on playback.",
        "Radio Browser / station directory",s.url,0L);
  }
  private void play(Station station){stop();status.setText("CONNECTING: "+station.name);
    try{MediaPlayer mp=new MediaPlayer();player=mp;mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
      mp.setDataSource(station.url);mp.setOnPreparedListener(p->{if(player==p){p.start();status.setText("NOW PLAYING  /  "+station.name);}});
      mp.setOnErrorListener((p,what,extra)->{status.setText("STREAM UNAVAILABLE  /  PROVIDER OR FORMAT ERROR "+what);stop();return true;});mp.prepareAsync();
    }catch(Exception e){status.setText("STREAM UNAVAILABLE  /  "+e.getClass().getSimpleName());stop();}
  }
  private void stop(){if(player!=null){try{player.reset();player.release();}catch(Exception ignored){}player=null;}}
  @Override protected void onDestroy(){stop();super.onDestroy();}
  private final class Atlas extends View {
    private final Paint pen=new Paint(3);private final ArrayList<float[]> outline=new ArrayList<>();private boolean loaded;
    Atlas(){super(Duwm1166RadioAtlasActivity.this);loadCoasts();setContentDescription("Geotagged world radio stations");}
    private void loadCoasts(){if(loaded)return;loaded=true;
      try(BufferedReader reader=new BufferedReader(new InputStreamReader(getAssets().open("naturalearth_coasts.txt"),StandardCharsets.UTF_8))){
        String line;int rows=0;while((line=reader.readLine())!=null&&rows++<4000){String[] pairs=line.trim().split(" ");
          for(String pair:pairs){String[] coords=pair.split(",");if(coords.length!=2)continue;
            try{float lat=Float.parseFloat(coords[0]),lon=Float.parseFloat(coords[1]);if(Math.abs(lat)<=90&&Math.abs(lon)<=180)outline.add(new float[]{lat,lon});}catch(Exception ignored){}}
          outline.add(null);
        }
      }catch(Exception ignored){}
    }
    private float xx(double lon){return (float)((lon+180)/360*getWidth());}
    private float yy(double lat){return (float)((90-lat)/180*getHeight());}
    @Override protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(0xFF092439);
      pen.setColor(0xFF1A5368);pen.setStrokeWidth(1f);for(int x=1;x<8;x++)c.drawLine(x*getWidth()/8f,0,x*getWidth()/8f,getHeight(),pen);
      for(int y=1;y<6;y++)c.drawLine(0,y*getHeight()/6f,getWidth(),y*getHeight()/6f,pen);
      pen.setColor(0xFF266D7B);pen.setStrokeWidth(1.1f);float[] last=null;
      for(float[] point:outline){if(point==null){last=null;continue;}if(last!=null&&Math.abs(point[1]-last[1])<70)c.drawLine(xx(last[1]),yy(last[0]),xx(point[1]),yy(point[0]),pen);last=point;}
      for(Station s:found)if(s.lat!=null&&s.lon!=null){pen.setColor(0xFF47E2CB);c.drawCircle(xx(s.lon),yy(s.lat),3.8f,pen);}
    }
    @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;
      Station best=null;double dist=100000;for(Station s:found)if(s.lat!=null&&s.lon!=null){double dx=e.getX()-xx(s.lon),dy=e.getY()-yy(s.lat);double d=dx*dx+dy*dy;
        if(d<dist){dist=d;best=s;}}
      if(best!=null&&dist<dp(32)*dp(32))play(best);return true;
    }
  }
}
