from pathlib import Path
import re
src=Path('app/src/main/java/com/sentongoharuna/worldsituationroom')
globe=(src/'OperationsGlobeView.java').read_text()
deck=(src/'Duwm1674CommandDeckActivity.java').read_text()
assert 'public static final int AIR=1, QUAKE=2, SPACE=3, SEA=4;' in globe
assert not re.search(r'private\s+final\s+int\s+SEA\s*=', globe)
assert 'OCEAN_COLOR=Color.rgb(10,30,48)' in globe
assert 'OperationsGlobeView.SEA' in deck
print('PASS 1674.1 compiler repair: maritime layer SEA and globe palette field do not collide')
