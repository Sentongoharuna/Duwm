"""Flexible release identity and explicit visible-layout revision, without a frozen globe SHA."""
from pathlib import Path
import json,re

def assert_release_at_least(project: Path, minimum: int):
    build=(project/'app/build.gradle.kts').read_text()
    code=re.search(r'versionCode\s*=\s*(\d+)',build)
    label=re.search(r'versionName\s*=\s*"([^"]+)"',build)
    assert code and label, 'Version identity missing'
    code=int(code.group(1))
    assert code>=minimum*100, (code,minimum)
    assert label.group(1)==str(code//100), 'Version name and code mismatch'
    # Future versions may rewrite the entire globe without satisfying historic appearance checks.
    current=project/'app/src/main/assets/duwm_release_ui.json'
    if current.is_file():
        data=json.loads(current.read_text())
        assert data['uiRevision']==label.group(1), 'Visible UI revision must match app release'
        assert data['launchActivity'].endswith(str(label.group(1))+'CommandDeckActivity'), 'Launcher must change for this release'
    return code
