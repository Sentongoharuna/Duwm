# DUWM 1165 — Detailed Earth restore delivery

This revision is a response to the actual 1165 screenshot. The auto-selected `SatelliteMapView` is the simplified polygon globe. The preferred detailed `OperationsGlobeView` was being hidden at startup. In this revision `OperationsGlobeView` stays visible and the alternative is opt-in.

Source files changed: `OperationsMainActivity.java`, `app/build.gradle.kts`, `verification/check_source.py`, `verification/check_detailed_globe.py`, `1165_RELEASE_NOTES.md`, `DUWM_REAL_SOURCE_CHANGE_REPORT.json`.

The source checks pass locally; a signed APK and phone behavior are not verified. All inherited media, wallpaper, widget, source-data and map classes are kept.
