#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";U="$J/Du2Ui.java"
test -s "$J/DuSemanticColor.java"
grep -F 'CRITICAL' "$J/DuSemanticColor.java" >/dev/null
grep -F 'DELAYED' "$J/DuSemanticColor.java" >/dev/null
grep -F 'LIVE' "$J/DuSemanticColor.java" >/dev/null
grep -F 'return Du2Ui.ALERT' "$J/DuSemanticColor.java" >/dev/null
grep -F 'return Du2Ui.W' "$J/DuSemanticColor.java" >/dev/null
grep -F 'return Du2Ui.G' "$J/DuSemanticColor.java" >/dev/null
grep -F 'return Du2Ui.M' "$J/DuSemanticColor.java" >/dev/null
grep -F 'DuSemanticColor.status(st)' "$U" >/dev/null
grep -F 'DuSemanticColor.status(z.state)' "$J/DuLiveCounterStrip.java" >/dev/null
# Cumulative UI contracts.
grep -F 'TITLE=14' "$J/DuTypeScale.java" >/dev/null
grep -F 'GRID=8' "$J/DuUiMetrics.java" >/dev/null
grep -F 'PAGES={"GLOBE","MONITORS","NEWS","REGION","REPLAY"}' "$J/DuFiveNav.java" >/dev/null
# Green FIX2 guards.
! grep -F 'centerLongitude' "$J/SatelliteMapView.java"
! grep -F 'rotationDegrees +=' "$J/SatelliteMapView.java"
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
! grep -F '"DUWM page "+title' "$U"
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"
echo "UPGRADE 1.1 / 20-12 SEMANTIC COLORS VERIFIED"
