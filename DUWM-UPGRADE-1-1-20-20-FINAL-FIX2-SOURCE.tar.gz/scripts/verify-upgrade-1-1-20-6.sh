#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";N="$J/DuChronoNav.java"
grep -F 'Du2Ui.dp(a,48)' "$N" >/dev/null
grep -F 'Du2Ui.dp(a,92)' "$N" >/dev/null
grep -F 'c.setGravity(Gravity.CENTER)' "$N" >/dev/null
grep -F 'b.setAllCaps(false)' "$N" >/dev/null
! grep -F 'new LinearLayout.LayoutParams(0,72' "$N"
! grep -F 'new LinearLayout.LayoutParams(0,80' "$N"
# 5/20 permanent top-level nav remains.
grep -F 'PAGES={"GLOBE","MONITORS","NEWS","REGION","REPLAY"}' "$J/DuFiveNav.java" >/dev/null
# Prior cumulative changes remain.
! grep -F 'startActivity(new Intent(this,DuOnboardingActivity.class));finish();return;' "$J/DuIntegratedHomeActivity.java"
grep -F 'dp(a,38),dp(a,38)' "$J/Du2Ui.java" >/dev/null
grep -F 'DuCompactOpsStatus.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
# Green FIX2 regressions stay gone.
! grep -F 'centerLongitude' "$J/SatelliteMapView.java"
! grep -F 'rotationDegrees +=' "$J/SatelliteMapView.java"
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
! grep -F '"DUWM page "+title' "$J/Du2Ui.java"
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"
echo "UPGRADE 1.1 / 20-6 COMPACT CHRONO NAV VERIFIED"
