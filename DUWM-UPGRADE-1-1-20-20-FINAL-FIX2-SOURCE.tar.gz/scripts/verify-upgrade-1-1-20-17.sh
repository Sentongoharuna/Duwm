#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";H="$J/DuIntegratedHomeActivity.java"
test -s "$J/DuUiOwnership.java";test -s "$J/DuSystemSummary.java"
grep -F 'NAVIGATION="FIVE_NAV"' "$J/DuUiOwnership.java" >/dev/null
grep -F 'COUNTS="SITUATION_STRIP"' "$J/DuUiOwnership.java" >/dev/null
grep -F 'DIAGNOSTICS="SYSTEM_DRAWER"' "$J/DuUiOwnership.java" >/dev/null
grep -F 'DuSystemSummary.make(this)' "$H" >/dev/null
for x in DuRetryStatusStrip DuGovernorStrip DuProviderOpsStrip DuCrashHistoryStrip DuOfflineStateStrip DuRuntimeQaStrip DuStateParityStrip;do ! grep -F "r.addView($x.make(this))" "$H";done
# Underlying feature classes are retained, not deleted.
for f in DuRetryStatusStrip DuGovernorStrip DuProviderOpsStrip DuCrashHistoryStrip DuOfflineStateStrip DuRuntimeQaStrip DuStateParityStrip;do test -s "$J/$f.java";done
# Five destination shell remains the only top-level nav definition.
grep -F 'PAGES={"GLOBE","MONITORS","NEWS","REGION","REPLAY"}' "$J/DuFiveNav.java" >/dev/null
# Green FIX2 guards.
! grep -F 'centerLongitude' "$J/SatelliteMapView.java"
! grep -F 'rotationDegrees +=' "$J/SatelliteMapView.java"
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
! grep -F '"DUWM page "+title' "$J/Du2Ui.java"
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"
echo "UPGRADE 1.1 / 20-17 UI OWNERSHIP VERIFIED"
