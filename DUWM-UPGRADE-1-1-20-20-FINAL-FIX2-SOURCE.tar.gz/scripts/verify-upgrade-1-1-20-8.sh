#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";F="$J/DuFiveNav.java";C="$J/DuChronoNav.java"
grep -F 'b.setText(active?"● "+page:page)' "$F" >/dev/null
grep -F 'Typeface.BOLD' "$F" >/dev/null
grep -F 'b.setAlpha(active?1f:.72f)' "$F" >/dev/null
grep -F 'b.setSelected(active)' "$F" >/dev/null
grep -F 'current destination' "$F" >/dev/null
grep -F 'c.setText("● "+(current==null?"CURRENT":current))' "$C" >/dev/null
# 5/20 permanent destinations and 7/20 strip remain.
grep -F 'PAGES={"GLOBE","MONITORS","NEWS","REGION","REPLAY"}' "$F" >/dev/null
grep -F 'String[] systems={"AIR","SEA","WX","EVENTS","ORBIT","MONITORS"}' "$J/DuLiveCounterStrip.java" >/dev/null
# Prior cumulative changes.
! grep -F 'startActivity(new Intent(this,DuOnboardingActivity.class));finish();return;' "$J/DuIntegratedHomeActivity.java"
grep -F 'dp(a,38),dp(a,38)' "$J/Du2Ui.java" >/dev/null
grep -F 'DuCompactOpsStatus.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
# Green FIX2 regression guards.
! grep -F 'centerLongitude' "$J/SatelliteMapView.java"
! grep -F 'rotationDegrees +=' "$J/SatelliteMapView.java"
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
! grep -F '"DUWM page "+title' "$J/Du2Ui.java"
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"
echo "UPGRADE 1.1 / 20-8 ACTIVE PAGE STATE VERIFIED"
