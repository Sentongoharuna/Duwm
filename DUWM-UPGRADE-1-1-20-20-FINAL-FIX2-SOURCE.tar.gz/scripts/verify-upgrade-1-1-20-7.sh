#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";S="$J/DuLiveCounterStrip.java"
grep -F 'String[] systems={"AIR","SEA","WX","EVENTS","ORBIT","MONITORS"}' "$S" >/dev/null
grep -F 'DuSharedLiveState.item(a,s)' "$S" >/dev/null
grep -F 'DuDeviceGovernor.refreshMs(a)' "$S" >/dev/null
grep -F 'DuLiveCounterStrip.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
grep -F 'DuLiveCounterStrip.make(this)' "$J/DuGlobeCommandActivity.java" >/dev/null
! grep -F 'DuMetricRow.make(this,"REGION","EAST AFRICA","MODE","WORLD","STATE","LIVE")' "$J/DuGlobeCommandActivity.java"
# Permanent five-nav + compact chrono remain.
grep -F 'PAGES={"GLOBE","MONITORS","NEWS","REGION","REPLAY"}' "$J/DuFiveNav.java" >/dev/null
grep -F 'Du2Ui.dp(a,48)' "$J/DuChronoNav.java" >/dev/null
# Earlier cumulative upgrades retained.
! grep -F 'startActivity(new Intent(this,DuOnboardingActivity.class));finish();return;' "$J/DuIntegratedHomeActivity.java"
grep -F 'dp(a,38),dp(a,38)' "$J/Du2Ui.java" >/dev/null
grep -F 'DuCompactOpsStatus.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
# Green FIX2 guards.
! grep -F 'centerLongitude' "$J/SatelliteMapView.java"
! grep -F 'rotationDegrees +=' "$J/SatelliteMapView.java"
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
! grep -F '"DUWM page "+title' "$J/Du2Ui.java"
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"
echo "UPGRADE 1.1 / 20-7 SITUATION STRIP VERIFIED"
