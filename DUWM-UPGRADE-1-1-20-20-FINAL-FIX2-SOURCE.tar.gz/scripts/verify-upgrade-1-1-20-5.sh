#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuFiveNav.java"
grep -F 'PAGES={"GLOBE","MONITORS","NEWS","REGION","REPLAY"}' "$J/DuFiveNav.java" >/dev/null
grep -F 'DuFiveNav.make(this,"GLOBE")' "$J/DuIntegratedHomeActivity.java" >/dev/null
grep -F 'DuFiveNav.make(this,"GLOBE")' "$J/DuGlobeCommandActivity.java" >/dev/null
grep -F 'DuFiveNav.make(this,"MONITORS")' "$J/DuMonitorHubActivity.java" >/dev/null
grep -F 'DuFiveNav.make(this,"NEWS")' "$J/DuIntelligencePageActivity.java" >/dev/null
grep -F 'du_ui_focus' "$J/MainActivity.java" >/dev/null
# Previous cumulative 1/20, 3/20, 4/20 retained.
! grep -F 'startActivity(new Intent(this,DuOnboardingActivity.class));finish();return;' "$J/DuIntegratedHomeActivity.java"
grep -F 'dp(a,38),dp(a,38)' "$J/Du2Ui.java" >/dev/null
grep -F 'DuCompactOpsStatus.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
# Green-base regressions remain forbidden.
! grep -F 'centerLongitude' "$J/SatelliteMapView.java"
! grep -F 'rotationDegrees +=' "$J/SatelliteMapView.java"
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
! grep -F '"DUWM page "+title' "$J/Du2Ui.java"
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"
echo "UPGRADE 1.1 / 20-5 FIVE DESTINATION NAV VERIFIED"
