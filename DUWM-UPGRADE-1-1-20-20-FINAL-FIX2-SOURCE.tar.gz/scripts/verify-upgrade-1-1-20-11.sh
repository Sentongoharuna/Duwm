#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";U="$J/Du2Ui.java"
test -s "$J/DuTypeScale.java"
for x in 'META=8' 'LABEL=9' 'BODY=10' 'SECTION=12' 'TITLE=14' 'VALUE=18';do grep -F "$x" "$J/DuTypeScale.java" >/dev/null;done
grep -F 'DuTypeScale.TITLE' "$U" >/dev/null
grep -F 'DuTypeScale.SECTION' "$U" >/dev/null
grep -F 'DuTypeScale.META' "$U" >/dev/null
grep -F 'DuTypeScale.LABEL' "$J/DuLiveCounterStrip.java" >/dev/null
grep -F 'DuTypeScale.LABEL' "$J/DuFiveNav.java" >/dev/null
grep -F 'DuTypeScale.BODY' "$J/DuChronoNav.java" >/dev/null
# 10/20 spacing contract remains.
grep -F 'GRID=8' "$J/DuUiMetrics.java" >/dev/null
grep -F 'TOUCH=48' "$J/DuUiMetrics.java" >/dev/null
# Permanent navigation + active state remain.
grep -F 'PAGES={"GLOBE","MONITORS","NEWS","REGION","REPLAY"}' "$J/DuFiveNav.java" >/dev/null
grep -F 'b.setText(active?"● "+page:page)' "$J/DuFiveNav.java" >/dev/null
# Earlier cumulative upgrades retained.
! grep -F 'startActivity(new Intent(this,DuOnboardingActivity.class));finish();return;' "$J/DuIntegratedHomeActivity.java"
grep -F 'dp(a,38),dp(a,38)' "$U" >/dev/null
grep -F 'DuCompactOpsStatus.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
grep -F 'static LinearLayout compactPanel' "$U" >/dev/null
# Green FIX2 regression guards.
! grep -F 'centerLongitude' "$J/SatelliteMapView.java"
! grep -F 'rotationDegrees +=' "$J/SatelliteMapView.java"
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
! grep -F '"DUWM page "+title' "$U"
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"
echo "UPGRADE 1.1 / 20-11 TYPOGRAPHY HIERARCHY VERIFIED"
