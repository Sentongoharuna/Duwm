#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuOrientationUi.java"
grep -F 'Configuration.ORIENTATION_LANDSCAPE' "$J/DuOrientationUi.java" >/dev/null
grep -F 'drawerDp(Context c)' "$J/DuOrientationUi.java" >/dev/null
grep -F 'navCellDp(Context c)' "$J/DuOrientationUi.java" >/dev/null
grep -F 'DuOrientationUi.navCellDp(a)' "$J/DuFiveNav.java" >/dev/null
grep -F 'DuOrientationUi.drawerDp(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
grep -F 'DuOrientationUi.drawerDp(this)' "$J/DuGlobeCommandActivity.java" >/dev/null
grep -F 'DuOrientationUi.orientContent(this,c)' "$J/DuMonitorHubActivity.java" >/dev/null
# Responsive/inset foundations retained.
grep -F 'fontScale>=1.20f' "$J/DuResponsiveUi.java" >/dev/null
grep -F 'DuSystemInsets.apply(a,r)' "$J/Du2Ui.java" >/dev/null
grep -F 'PAGES={"GLOBE","MONITORS","NEWS","REGION","REPLAY"}' "$J/DuFiveNav.java" >/dev/null
# Green FIX2 guards.
! grep -F 'centerLongitude' "$J/SatelliteMapView.java"
! grep -F 'rotationDegrees +=' "$J/SatelliteMapView.java"
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
! grep -F '"DUWM page "+title' "$J/Du2Ui.java"
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"
echo "UPGRADE 1.1 / 20-15 ORIENTATION OWNERSHIP VERIFIED"
