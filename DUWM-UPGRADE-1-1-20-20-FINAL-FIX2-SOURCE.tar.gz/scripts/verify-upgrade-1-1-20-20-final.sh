#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
grep -F 'ID="DUWM-UPGRADE-1.1-20of20"' "$J/DuBuildIdentity.java" >/dev/null
grep -F 'UPGRADE_1_1_COMPLETE=true' "$J/DuBuildIdentity.java" >/dev/null
grep -F 'VERSION="UPGRADE-1.1-19"' "$J/DuUiContract.java" >/dev/null
grep -F 'PAGES={"GLOBE","MONITORS","NEWS","REGION","REPLAY"}' "$J/DuFiveNav.java" >/dev/null
grep -F 'DuSystemSummary.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
grep -F 'DuDirectRoute.handle(this,getIntent())' "$J/MainActivity.java" >/dev/null
grep -F 'DuSystemInsets.apply(a,r)' "$J/Du2Ui.java" >/dev/null
grep -F 'DuOrientationUi.navCellDp(a)' "$J/DuFiveNav.java" >/dev/null
grep -F 'DuSemanticColor.status' "$J/Du2Ui.java" >/dev/null
grep -F 'GRID=8' "$J/DuUiMetrics.java" >/dev/null
grep -F 'TITLE=14' "$J/DuTypeScale.java" >/dev/null
grep -F 'String[] systems={"AIR","SEA","WX","EVENTS","ORBIT","MONITORS"}' "$J/DuLiveCounterStrip.java" >/dev/null
! grep -F 'startActivity(new Intent(this,DuOnboardingActivity.class));finish();return;' "$J/DuIntegratedHomeActivity.java"
! grep -F 'DuProStrip.make(this,"WORLD")' "$J/DuIntegratedHomeActivity.java"
! grep -F 'DuChronoNav.bar(this,"GLOBE"' "$J/DuIntegratedHomeActivity.java"
# Known STEP12 compiler regressions remain impossible.
! grep -R -F 'centerLongitude' "$J"
! grep -R -F 'rotationDegrees +=' "$J"
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
! grep -F '"DUWM page "+title' "$J/Du2Ui.java"
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"
echo "DUWM UPGRADE 1.1 20/20 FINAL CONTRACT PASS"
