#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
! grep -F 'centerLongitude' "$J/SatelliteMapView.java"
! grep -F 'rotationDegrees +=' "$J/SatelliteMapView.java"
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
! grep -F '"DUWM page "+title' "$J/Du2Ui.java"
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"
grep -F 'drawDuIntelligenceClusters(canvas)' "$J/SatelliteMapView.java" >/dev/null
grep -F 'drawMotionTrail' "$J/SatelliteMapView.java" >/dev/null
echo "STEP12 FIX2 VERIFIED"
