#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";H="$J/DuIntegratedHomeActivity.java"
test -s "$J/DuUiContract.java"
grep -F 'TOP_LEVEL={"GLOBE","MONITORS","NEWS","REGION","REPLAY"}' "$J/DuUiContract.java" >/dev/null
grep -F 'HEADER_OWNER="Du2Ui.shell"' "$J/DuUiContract.java" >/dev/null
grep -F 'NAV_OWNER="DuFiveNav"' "$J/DuUiContract.java" >/dev/null
grep -F 'COUNT_OWNER="DuLiveCounterStrip"' "$J/DuUiContract.java" >/dev/null
grep -F 'STATUS_OWNER="DuCompactOpsStatus"' "$J/DuUiContract.java" >/dev/null
grep -F 'SYSTEM_OWNER="DuSystemSummary"' "$J/DuUiContract.java" >/dev/null
grep -F 'NORMAL_START_ONBOARDING=false' "$J/DuUiContract.java" >/dev/null
grep -F 'UI_CONTRACT=DuUiContract.VERSION' "$J/DuBuildIdentity.java" >/dev/null

# First-page ownership: exactly one of each primary owner.
test "$(grep -o 'DuFiveNav.make(this,"GLOBE")' "$H" | wc -l)" -eq 1
test "$(grep -o 'DuLiveCounterStrip.make(this)' "$H" | wc -l)" -eq 1
test "$(grep -o 'DuCompactOpsStatus.make(this)' "$H" | wc -l)" -eq 1
test "$(grep -o 'DuSystemSummary.make(this)' "$H" | wc -l)" -eq 1

# No old first-page duplicates.
! grep -F 'DuProStrip.make(this,"WORLD")' "$H"
! grep -F 'DuChronoNav.bar(this,"GLOBE"' "$H"
! grep -F 'startActivity(new Intent(this,DuOnboardingActivity.class));finish();return;' "$H"

# All five routes must be defined by the permanent nav owner.
grep -F 'PAGES={"GLOBE","MONITORS","NEWS","REGION","REPLAY"}' "$J/DuFiveNav.java" >/dev/null

echo "UPGRADE 1.1 / 20-19 UI CONTRACT PASS"
