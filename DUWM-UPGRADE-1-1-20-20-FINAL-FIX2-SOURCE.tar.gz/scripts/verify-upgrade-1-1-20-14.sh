#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuResponsiveUi.java"
grep -F 'fontScale>=1.20f' "$J/DuResponsiveUi.java" >/dev/null
grep -F 'screenWidthDp<390' "$J/DuResponsiveUi.java" >/dev/null
grep -F 'DuResponsiveUi.navCellDp(a)' "$J/DuFiveNav.java" >/dev/null
grep -F 'DuResponsiveUi.maxLabelLines(a)' "$J/DuFiveNav.java" >/dev/null
grep -F 'DuResponsiveUi.situationCellDp(a)' "$J/DuLiveCounterStrip.java" >/dev/null
grep -F 'setSingleLine(!DuResponsiveUi.largeFont(a))' "$J/DuLiveCounterStrip.java" >/dev/null
grep -F 'DuResponsiveUi.maxLabelLines(a)' "$J/DuChronoNav.java" >/dev/null
grep -F 'DuResponsiveUi.largeFont(a)?4:3' "$J/Du2Ui.java" >/dev/null
# Insets + cumulative system retained.
grep -F 'DuSystemInsets.apply(a,r)' "$J/Du2Ui.java" >/dev/null
grep -F 'GRID=8' "$J/DuUiMetrics.java" >/dev/null
grep -F 'TITLE=14' "$J/DuTypeScale.java" >/dev/null
grep -F 'PAGES={"GLOBE","MONITORS","NEWS","REGION","REPLAY"}' "$J/DuFiveNav.java" >/dev/null
# Green FIX2 guards.
! grep -F 'centerLongitude' "$J/SatelliteMapView.java"
! grep -F 'rotationDegrees +=' "$J/SatelliteMapView.java"
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
! grep -F '"DUWM page "+title' "$J/Du2Ui.java"
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"
echo "UPGRADE 1.1 / 20-14 FONT DISPLAY SCALE RESILIENCE VERIFIED"
