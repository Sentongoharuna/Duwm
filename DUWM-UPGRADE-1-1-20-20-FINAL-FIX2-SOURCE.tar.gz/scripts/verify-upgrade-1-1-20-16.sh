#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuDirectRoute.java"
grep -F 'record_id' "$J/DuDirectRoute.java" >/dev/null
grep -F 'DuSignalIntent.detail(a,s)' "$J/DuDirectRoute.java" >/dev/null
grep -F 'monitor_id' "$J/DuDirectRoute.java" >/dev/null
grep -F 'DuMonitorPlayer.open(a,monitor)' "$J/DuDirectRoute.java" >/dev/null
grep -F 'DuWidgetContract.EXTRA_OPEN_CATALOG' "$J/DuDirectRoute.java" >/dev/null
grep -F 'DuDirectRoute.top(a,page)' "$J/DuFiveNav.java" >/dev/null
grep -F 'DuDirectRoute.handle(this,getIntent())' "$J/MainActivity.java" >/dev/null
grep -F 'DuDirectRoute.handle(this,getIntent())' "$J/DuIntegratedHomeActivity.java" >/dev/null
# Cumulative shell remains.
grep -F 'PAGES={"GLOBE","MONITORS","NEWS","REGION","REPLAY"}' "$J/DuFiveNav.java" >/dev/null
grep -F 'DuOrientationUi.navCellDp(a)' "$J/DuFiveNav.java" >/dev/null
grep -F 'DuSystemInsets.apply(a,r)' "$J/Du2Ui.java" >/dev/null
# Green FIX2 guards.
! grep -F 'centerLongitude' "$J/SatelliteMapView.java"
! grep -F 'rotationDegrees +=' "$J/SatelliteMapView.java"
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
! grep -F '"DUWM page "+title' "$J/Du2Ui.java"
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"
echo "UPGRADE 1.1 / 20-16 DIRECT ROUTES VERIFIED"
