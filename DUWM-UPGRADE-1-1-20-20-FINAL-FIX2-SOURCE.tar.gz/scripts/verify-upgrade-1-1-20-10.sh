#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";U="$J/Du2Ui.java"
test -s "$J/DuUiMetrics.java"
grep -F 'GRID=8' "$J/DuUiMetrics.java" >/dev/null
grep -F 'TOUCH=48' "$J/DuUiMetrics.java" >/dev/null
grep -F 'RADIUS=12' "$J/DuUiMetrics.java" >/dev/null
grep -F 'DuUiMetrics.PANEL_X' "$U" >/dev/null
grep -F 'DuUiMetrics.TOUCH' "$U" >/dev/null
grep -F 'dp(a,16),dp(a,8),dp(a,16),dp(a,8)' "$U" >/dev/null
grep -F 'DuUiMetrics.EDGE' "$J/DuFiveNav.java" >/dev/null
grep -F 'DuUiMetrics.EDGE' "$J/DuChronoNav.java" >/dev/null
grep -F 'DuUiMetrics.EDGE' "$J/DuLiveCounterStrip.java" >/dev/null
# Cumulative 5-9 contracts remain.
grep -F 'PAGES={"GLOBE","MONITORS","NEWS","REGION","REPLAY"}' "$J/DuFiveNav.java" >/dev/null
grep -F 'b.setText(active?"● "+page:page)' "$J/DuFiveNav.java" >/dev/null
grep -F 'static LinearLayout compactPanel' "$U" >/dev/null
# Earlier cumulative changes.
! grep -F 'startActivity(new Intent(this,DuOnboardingActivity.class));finish();return;' "$J/DuIntegratedHomeActivity.java"
grep -F 'dp(a,38),dp(a,38)' "$U" >/dev/null
grep -F 'DuCompactOpsStatus.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
# Green FIX2 regression guards.
! grep -F 'centerLongitude' "$J/SatelliteMapView.java"
! grep -F 'rotationDegrees +=' "$J/SatelliteMapView.java"
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
! grep -F '"DUWM page "+title' "$U"
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"
echo "UPGRADE 1.1 / 20-10 SPACING SYSTEM VERIFIED"
