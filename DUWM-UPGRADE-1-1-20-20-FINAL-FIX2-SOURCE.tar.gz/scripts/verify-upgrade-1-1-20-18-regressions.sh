#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"

echo "== FIX2 compiler regression gate =="
! grep -R -F 'centerLongitude' "$J"
! grep -R -F 'rotationDegrees +=' "$J"
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
! grep -F '"DUWM page "+title' "$J/Du2Ui.java"
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"

echo "== Upgrade 1.1 cumulative contract =="
! grep -F 'startActivity(new Intent(this,DuOnboardingActivity.class));finish();return;' "$J/DuIntegratedHomeActivity.java"
grep -F 'dp(a,38),dp(a,38)' "$J/Du2Ui.java" >/dev/null
grep -F 'DuCompactOpsStatus.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
grep -F 'PAGES={"GLOBE","MONITORS","NEWS","REGION","REPLAY"}' "$J/DuFiveNav.java" >/dev/null
grep -F 'Du2Ui.dp(a,48)' "$J/DuChronoNav.java" >/dev/null
grep -F 'String[] systems={"AIR","SEA","WX","EVENTS","ORBIT","MONITORS"}' "$J/DuLiveCounterStrip.java" >/dev/null
grep -F 'b.setText(active?"● "+page:page)' "$J/DuFiveNav.java" >/dev/null
grep -F 'static LinearLayout compactPanel' "$J/Du2Ui.java" >/dev/null
grep -F 'GRID=8' "$J/DuUiMetrics.java" >/dev/null
grep -F 'TITLE=14' "$J/DuTypeScale.java" >/dev/null
grep -F 'DuSemanticColor.status' "$J/Du2Ui.java" >/dev/null
grep -F 'DuSystemInsets.apply(a,r)' "$J/Du2Ui.java" >/dev/null
grep -F 'fontScale>=1.20f' "$J/DuResponsiveUi.java" >/dev/null
grep -F 'DuOrientationUi.navCellDp(a)' "$J/DuFiveNav.java" >/dev/null
grep -F 'DuDirectRoute.handle(this,getIntent())' "$J/MainActivity.java" >/dev/null
grep -F 'DuSystemSummary.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null

echo "UPGRADE 1.1 / 20-18 REGRESSION GATE PASS"
