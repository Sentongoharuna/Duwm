#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuCompactOpsStatus.java"
grep -F 'DuCompactOpsStatus.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
grep -F 'LIVE · ' "$J/DuCompactOpsStatus.java" >/dev/null
# Duplicated ProStrip must not own the primary home/globe surfaces.
! grep -F 'DuProStrip.make' "$J/DuIntegratedHomeActivity.java"
! grep -F 'DuProStrip.make' "$J/DuGlobeCommandActivity.java"
# Previous cumulative changes remain.
! grep -F 'startActivity(new Intent(this,DuOnboardingActivity.class));finish();return;' "$J/DuIntegratedHomeActivity.java"
grep -F 'dp(a,38),dp(a,38)' "$J/Du2Ui.java" >/dev/null
grep -F '"DU WORLD MONITOR",14' "$J/Du2Ui.java" >/dev/null
# Green-base regression guards.
! grep -F 'centerLongitude' "$J/SatelliteMapView.java"
! grep -F 'rotationDegrees +=' "$J/SatelliteMapView.java"
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
! grep -F '"DUWM page "+title' "$J/Du2Ui.java"
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"
echo "UPGRADE 1.1 / 20-4 COMPACT STATUS VERIFIED"
