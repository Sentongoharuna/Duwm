#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";U="$J/Du2Ui.java"
# 1/20 remains retained.
! grep -F 'startActivity(new Intent(this,DuOnboardingActivity.class));finish();return;' "$J/DuIntegratedHomeActivity.java"
# 3/20 compact header contract.
grep -F 'DU WORLD MONITOR' "$U" >/dev/null
grep -F 'dp(a,38),dp(a,38)' "$U" >/dev/null
grep -F '"DU WORLD MONITOR",14' "$U" >/dev/null
grep -F '● LIVE · EAST AFRICA · ' "$U" >/dev/null
# Green FIX2 regressions remain forbidden.
! grep -F 'centerLongitude' "$J/SatelliteMapView.java"
! grep -F 'rotationDegrees +=' "$J/SatelliteMapView.java"
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
! grep -F '"DUWM page "+title' "$U"
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"
echo "UPGRADE 1.1 / 20-3 COMPACT DU HEADER VERIFIED"
