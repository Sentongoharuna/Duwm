#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";U="$J/Du2Ui.java"
test -s "$J/DuSystemInsets.java"
grep -F 'setOnApplyWindowInsetsListener' "$J/DuSystemInsets.java" >/dev/null
grep -F 'getSystemWindowInsetTop' "$J/DuSystemInsets.java" >/dev/null
grep -F 'getSystemWindowInsetBottom' "$J/DuSystemInsets.java" >/dev/null
grep -F 'getSystemWindowInsetLeft' "$J/DuSystemInsets.java" >/dev/null
grep -F 'getSystemWindowInsetRight' "$J/DuSystemInsets.java" >/dev/null
grep -F 'DuSystemInsets.apply(a,r)' "$U" >/dev/null
grep -F 'DuSystemInsets.apply(this,r)' "$J/DuSituationRoomActivity.java" >/dev/null
# Cumulative UI system remains.
grep -F 'GRID=8' "$J/DuUiMetrics.java" >/dev/null
grep -F 'TITLE=14' "$J/DuTypeScale.java" >/dev/null
grep -F 'DuSemanticColor.status' "$U" >/dev/null
grep -F 'PAGES={"GLOBE","MONITORS","NEWS","REGION","REPLAY"}' "$J/DuFiveNav.java" >/dev/null
# Green FIX2 guards.
! grep -F 'centerLongitude' "$J/SatelliteMapView.java"
! grep -F 'rotationDegrees +=' "$J/SatelliteMapView.java"
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
! grep -F '"DUWM page "+title' "$U"
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"
echo "UPGRADE 1.1 / 20-13 SYSTEM INSETS VERIFIED"
