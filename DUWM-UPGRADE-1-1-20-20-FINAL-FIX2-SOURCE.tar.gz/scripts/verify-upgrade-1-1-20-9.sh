#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";U="$J/Du2Ui.java"
grep -F 'static LinearLayout compactPanel' "$U" >/dev/null
grep -F 'body.setMaxLines(3)' "$U" >/dev/null
grep -F 'TruncateAt.END' "$U" >/dev/null
for f in DuWorldSystemPageActivity DuTransportMarketPageActivity DuIntelligencePageActivity DuMediaPageActivity;do
  grep -F 'Du2Ui.compactPanel(this,"PURPOSE"' "$J/$f.java" >/dev/null
  grep -F 'Du2Ui.compactPanel(this,"WORKFLOW"' "$J/$f.java" >/dev/null
done
# 5-8 cumulative UI contracts remain.
grep -F 'PAGES={"GLOBE","MONITORS","NEWS","REGION","REPLAY"}' "$J/DuFiveNav.java" >/dev/null
grep -F 'b.setText(active?"● "+page:page)' "$J/DuFiveNav.java" >/dev/null
grep -F 'String[] systems={"AIR","SEA","WX","EVENTS","ORBIT","MONITORS"}' "$J/DuLiveCounterStrip.java" >/dev/null
grep -F 'Du2Ui.dp(a,48)' "$J/DuChronoNav.java" >/dev/null
# Earlier changes retained.
! grep -F 'startActivity(new Intent(this,DuOnboardingActivity.class));finish();return;' "$J/DuIntegratedHomeActivity.java"
grep -F 'dp(a,38),dp(a,38)' "$U" >/dev/null
grep -F 'DuCompactOpsStatus.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
# Green FIX2 guards.
! grep -F 'centerLongitude' "$J/SatelliteMapView.java"
! grep -F 'rotationDegrees +=' "$J/SatelliteMapView.java"
! grep -F 'DuOfflineUx.state(this,system)' "$J/DuRecordDetailActivity.java"
! grep -F '"DUWM page "+title' "$U"
! grep -F 'Button b=Du2Ui.button' "$J/DuGlobeIntelligenceActivity.java"
echo "UPGRADE 1.1 / 20-9 COMPACT SECONDARY CARDS VERIFIED"
