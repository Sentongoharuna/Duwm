#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
grep -F 'ALERT=Color.rgb(218,70,76),W=Color.rgb(214,166,70);' "$J/Du2Ui.java" >/dev/null
grep -F 'Du2Ui.W' "$J/DuSemanticColor.java" >/dev/null
grep -F 'Du2Ui.W' "$J/DuCompactOpsStatus.java" >/dev/null
echo "20/20 FIX2 WARNING TOKEN IS INSIDE Du2Ui"
