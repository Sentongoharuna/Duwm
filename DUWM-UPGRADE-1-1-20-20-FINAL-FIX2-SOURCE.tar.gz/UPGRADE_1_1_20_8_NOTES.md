# Upgrade 1.1 / 20-8 — Active Page State
- Active top-level destination gains a cyan leading dot, bold monospace label, full opacity and selected state.
- Inactive destinations remain muted at 72% opacity.
- Accessibility text explicitly identifies the current destination.
- Chronological sub-page current label uses the same cyan dot + bold language.
- No route or engine changes.
