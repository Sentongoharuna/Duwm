# Upgrade 1.1 / 20-11 — Typography Hierarchy
Named type scale:
- META 8sp
- LABEL 9sp
- BODY 10sp
- SECTION 12sp
- TITLE 14sp
- VALUE 18sp
The shared header, panels, compact cards, situation strip and navigation now use these tokens instead of scattered sizes.
Monospace remains the DUWM operational identity.
