package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.os.*;import android.view.*;import android.widget.*;
public final class DuLiveCounterStrip{
 private DuLiveCounterStrip(){}
 public static View make(Activity a){
  HorizontalScrollView scroll=new HorizontalScrollView(a);scroll.setHorizontalScrollBarEnabled(false);scroll.setFillViewport(true);
  LinearLayout row=new LinearLayout(a);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(Du2Ui.dp(a,DuUiMetrics.EDGE),0,Du2Ui.dp(a,DuUiMetrics.EDGE),0);
  String[] systems={"AIR","SEA","WX","EVENTS","ORBIT","MONITORS"};TextView[] cells=new TextView[systems.length];
  for(int i=0;i<systems.length;i++){TextView v=Du2Ui.t(a,"",DuTypeScale.LABEL);v.setGravity(Gravity.CENTER);v.setSingleLine(!DuResponsiveUi.largeFont(a));v.setMaxLines(DuResponsiveUi.maxLabelLines(a));v.setMinWidth(Du2Ui.dp(a,88));cells[i]=v;row.addView(v,new LinearLayout.LayoutParams(Du2Ui.dp(a,DuResponsiveUi.situationCellDp(a)),Du2Ui.dp(a,40)));}
  Handler h=new Handler(Looper.getMainLooper());
  Runnable tick=new Runnable(){public void run(){DuModuleShield.run(a,"SITUATION_STRIP",()->{for(int i=0;i<systems.length;i++){String s=systems[i];DuSharedLiveState.Item z=DuSharedLiveState.item(a,s);cells[i].setText(s+" "+z.count);cells[i].setTextColor(DuSemanticColor.status(z.state));cells[i].setContentDescription(s+" "+z.count+" "+z.state);}});h.postDelayed(this,DuDeviceGovernor.refreshMs(a));}};
  tick.run();scroll.addView(row);return scroll;
 }
}
