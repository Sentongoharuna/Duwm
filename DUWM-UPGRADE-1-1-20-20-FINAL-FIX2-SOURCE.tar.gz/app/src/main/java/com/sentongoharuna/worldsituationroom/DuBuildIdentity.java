package com.sentongoharuna.worldsituationroom;
public final class DuBuildIdentity {
 public static final String NAME="DUWM LIVE CORE 1";
 public static final String ID="DUWM-UPGRADE-1.1-20of20";public static final String UI_CONTRACT=DuUiContract.VERSION;
 public static final boolean UPGRADE_1_1_COMPLETE=true;private DuBuildIdentity(){}
}
