package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.content.*;
public final class DuDirectRoute{
 private DuDirectRoute(){}
 public static boolean handle(Activity a,Intent i){
  if(i==null)return false;
  String system=i.getStringExtra("system"),id=i.getStringExtra("record_id");
  if(system!=null&&id!=null){Signal s=new DuLiveRepository(a).find(system,id);if(s!=null){a.startActivity(DuSignalIntent.detail(a,s));return true;}}
  String monitor=i.getStringExtra("monitor_id");if(monitor!=null&&!monitor.isEmpty()){DuMonitorPlayer.open(a,monitor);return true;}
  String catalog=i.getStringExtra(DuWidgetContract.EXTRA_OPEN_CATALOG);if(catalog!=null&&!catalog.isEmpty()){DuPageRouter.open(a,catalog);return true;}
  return false;
 }
 public static Intent top(Activity a,String page){Intent i;if("GLOBE".equals(page))i=new Intent(a,DuGlobeCommandActivity.class);else if("MONITORS".equals(page))i=new Intent(a,DuMonitorHubActivity.class);else i=new Intent(a,MainActivity.class).putExtra("du_ui_focus",page);return i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);}
}
