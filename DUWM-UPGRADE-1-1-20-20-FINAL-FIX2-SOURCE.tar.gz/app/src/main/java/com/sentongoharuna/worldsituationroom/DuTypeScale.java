package com.sentongoharuna.worldsituationroom;
public final class DuTypeScale{
 public static final int META=8;
 public static final int LABEL=9;
 public static final int BODY=10;
 public static final int SECTION=12;
 public static final int TITLE=14;
 public static final int VALUE=18;
 private DuTypeScale(){}
}
