package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.content.*;import android.widget.*;
public final class DuFirstPageTools{
 private DuFirstPageTools(){}
 public static LinearLayout make(Activity a){
  LinearLayout box=Du2Ui.compactPanel(a,"LIVE OPERATIONS TOOLS","● DIRECT ACCESS","All upgraded tools are named here. Tap directly into the existing function.");
  String[][] tools={{"GLOBE INTELLIGENCE","GLOBE"},{"LOCAL MONITOR PUBLISH","PUBLISH"},{"MONITOR NETWORK","MONITORS"},{"ASK DUWM","ASK"},{"SCENE DIRECTOR","SCENE"},{"DETECTION HUD","DETECTION"},{"NEWS CLUSTERS","CLUSTERS"},{"WATCHLIST","WATCHLIST"},{"SOURCE INDEX","SOURCES"},{"SHARE STUDIO","SHARE"},{"PERFORMANCE","PERFORMANCE"},{"ACCESSIBILITY","ACCESSIBILITY"},{"RECOVERY","RECOVERY"},{"NAV MATRIX","NAV"},{"VISUAL QA","VISUAL"}};
  for(String[] x:tools){Button b=Du2Ui.button(a,x[0]);b.setOnClickListener(v->open(a,x[1]));box.addView(b);}
  return box;
 }
 static void open(Activity a,String k){
  if("GLOBE".equals(k)){DuPageRouter.open(a,"GLOBE");return;}
  if("PUBLISH".equals(k)){a.startActivity(new Intent(a,LocalMonitorActivity.class));return;}
  if("MONITORS".equals(k)){a.startActivity(new Intent(a,DuMonitorHubActivity.class));return;}
  if("ASK".equals(k)){a.startActivity(new Intent(a,DuAskActivity.class));return;}
  if("SCENE".equals(k)){a.startActivity(new Intent(a,DuSceneDirectorActivity.class));return;}
  if("DETECTION".equals(k)){a.startActivity(new Intent(a,DuDetectionActivity.class));return;}
  if("CLUSTERS".equals(k)){a.startActivity(new Intent(a,DuNewsClustersActivity.class));return;}
  if("WATCHLIST".equals(k)){a.startActivity(new Intent(a,DuWatchlistActivity.class));return;}
  if("SOURCES".equals(k)){a.startActivity(new Intent(a,DuSystemIndexActivity.class));return;}
  if("SHARE".equals(k)){a.startActivity(new Intent(a,DuShareStudioActivity.class));return;}
  if("PERFORMANCE".equals(k)){a.startActivity(new Intent(a,DuPerformanceActivity.class));return;}
  if("ACCESSIBILITY".equals(k)){a.startActivity(new Intent(a,DuAccessibilityActivity.class));return;}
  if("RECOVERY".equals(k)){a.startActivity(new Intent(a,DuRecoveryActivity.class));return;}
  if("NAV".equals(k)){a.startActivity(new Intent(a,DuNavigationMatrixActivity.class));return;}
  if("VISUAL".equals(k)){a.startActivity(new Intent(a,DuVisualQaActivity.class));}
 }
}
