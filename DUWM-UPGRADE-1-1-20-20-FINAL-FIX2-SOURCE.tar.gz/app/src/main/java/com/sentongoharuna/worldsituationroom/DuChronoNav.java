package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.graphics.*;import android.view.*;import android.widget.*;
public final class DuChronoNav{
 private DuChronoNav(){}
 public static View bar(Activity a,String current,String back,String next){
  LinearLayout row=new LinearLayout(a);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(Du2Ui.dp(a,DuUiMetrics.EDGE),0,Du2Ui.dp(a,DuUiMetrics.EDGE),0);
  Button b=compact(a,back==null||back.isEmpty()?"‹":"‹ "+back,false);
  TextView c=Du2Ui.t(a,current==null?"CURRENT":current,DuTypeScale.BODY);c.setGravity(Gravity.CENTER);c.setTextColor(Du2Ui.C);c.setTypeface(android.graphics.Typeface.MONOSPACE,android.graphics.Typeface.BOLD);c.setText("● "+(current==null?"CURRENT":current));c.setMaxLines(DuResponsiveUi.maxLabelLines(a));c.setContentDescription((current==null?"Current":current)+" current page");
  Button n=compact(a,next==null||next.isEmpty()?"›":next+" ›",false);
  if(back==null||back.isEmpty()){b.setEnabled(false);b.setAlpha(.35f);}else b.setOnClickListener(v->DuPageRouter.open(a,back));
  if(next==null||next.isEmpty()){n.setEnabled(false);n.setAlpha(.35f);}else n.setOnClickListener(v->DuPageRouter.open(a,next));
  row.addView(b,new LinearLayout.LayoutParams(Du2Ui.dp(a,92),Du2Ui.dp(a,48)));
  row.addView(c,new LinearLayout.LayoutParams(0,Du2Ui.dp(a,48),1));
  row.addView(n,new LinearLayout.LayoutParams(Du2Ui.dp(a,92),Du2Ui.dp(a,48)));
  return row;
 }
 static Button compact(Activity a,String text,boolean active){Button b=Du2Ui.button(a,text);b.setMinHeight(Du2Ui.dp(a,48));b.setTextSize(DuTypeScale.LABEL);b.setTextColor(active?Du2Ui.C:Du2Ui.M);b.setAllCaps(false);return b;}
 public static String next(String page){
  if(page==null)return "";
  String[] order={"GLOBE","NEWS","WIRE","EVENTS","AIR","SEA","WX","ORBIT","SOURCES","MONITORS"};
  for(int i=0;i<order.length-1;i++)if(order[i].equals(page))return order[i+1];
  return "";
 }
}
