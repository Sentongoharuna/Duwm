package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.widget.*;
public final class DuSystemSummary{
 private DuSystemSummary(){}
 public static LinearLayout make(Activity a){
  DuDeviceGovernor.State d=DuDeviceGovernor.state(a);
  int live=0,delayed=0,offline=0;for(String s:DuSharedLiveState.SYSTEMS){DuLiveHealth.State x=DuLiveHealth.state(a,s);if(x==DuLiveHealth.State.LIVE)live++;else if(x==DuLiveHealth.State.DELAYED)delayed++;else offline++;}
  String text="SOURCES "+live+" LIVE · "+delayed+" DELAYED · "+offline+" OFFLINE\nDEVICE "+d.mode+" · RECOVERY "+(CrashLedger.hasRecentCrash(a)?"RECENT EVENT":"CLEAR");
  return Du2Ui.compactPanel(a,"SYSTEM STATUS","● CONSOLIDATED",text);
 }
}
