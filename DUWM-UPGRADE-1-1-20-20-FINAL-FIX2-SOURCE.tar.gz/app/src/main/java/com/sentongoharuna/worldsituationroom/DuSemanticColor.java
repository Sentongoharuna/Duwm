package com.sentongoharuna.worldsituationroom;
import android.content.*;
public final class DuSemanticColor{
 private DuSemanticColor(){}
 public static int status(String value){
  String s=value==null?"":value.toUpperCase(java.util.Locale.ROOT);
  if(s.contains("CRITICAL")||s.contains("BREAKING")||s.contains("FATAL")||s.contains("EMERGENCY"))return Du2Ui.ALERT;
  if(s.contains("DELAYED")||s.contains("DEGRADED")||s.contains("WARNING")||s.contains("RETRY"))return Du2Ui.W;
  if(s.contains("LIVE")||s.contains("READY")||s.contains("HEALTHY")||s.contains("SUCCESS"))return Du2Ui.G;
  return Du2Ui.M;
 }
 public static int action(){return Du2Ui.C;}
 public static int metadata(){return Du2Ui.M;}
}
