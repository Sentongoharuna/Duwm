package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.widget.*;
public final class DuCompactOpsStatus{
 private DuCompactOpsStatus(){}
 public static TextView make(Activity a){
  int live=0,delayed=0,offline=0;
  for(String s:DuSharedLiveState.SYSTEMS){DuLiveHealth.State x=DuLiveHealth.state(a,s);if(x==DuLiveHealth.State.LIVE)live++;else if(x==DuLiveHealth.State.DELAYED)delayed++;else offline++;}
  TextView v=Du2Ui.t(a,"● "+live+" LIVE · "+delayed+" DELAYED · "+offline+" OFFLINE",8);
  v.setTextColor(offline>0?Du2Ui.M:delayed>0?Du2Ui.W:Du2Ui.G);v.setContentDescription("System status: "+live+" live, "+delayed+" delayed, "+offline+" offline");
  return v;
 }
}
