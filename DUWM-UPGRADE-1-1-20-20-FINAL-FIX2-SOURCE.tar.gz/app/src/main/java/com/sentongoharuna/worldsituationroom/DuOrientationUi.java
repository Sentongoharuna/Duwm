package com.sentongoharuna.worldsituationroom;
import android.content.*;import android.content.res.*;import android.widget.*;
public final class DuOrientationUi{
 private DuOrientationUi(){}
 public static boolean landscape(Context c){return c.getResources().getConfiguration().orientation==Configuration.ORIENTATION_LANDSCAPE;}
 public static int globeWeight(Context c){return landscape(c)?2:1;}
 public static int drawerDp(Context c){return landscape(c)?224:320;}
 public static int navCellDp(Context c){return landscape(c)?112:DuResponsiveUi.navCellDp(c);}
 public static void orientContent(Context c,LinearLayout row){row.setOrientation(landscape(c)?LinearLayout.HORIZONTAL:LinearLayout.VERTICAL);}
}
