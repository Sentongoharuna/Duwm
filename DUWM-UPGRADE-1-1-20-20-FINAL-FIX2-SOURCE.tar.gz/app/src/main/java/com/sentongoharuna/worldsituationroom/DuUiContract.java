package com.sentongoharuna.worldsituationroom;
public final class DuUiContract{
 public static final String VERSION="UPGRADE-1.1-19";
 public static final String[] TOP_LEVEL={"GLOBE","MONITORS","NEWS","REGION","REPLAY"};
 public static final String HEADER_OWNER="Du2Ui.shell";
 public static final String NAV_OWNER="DuFiveNav";
 public static final String COUNT_OWNER="DuLiveCounterStrip";
 public static final String STATUS_OWNER="DuCompactOpsStatus";
 public static final String SYSTEM_OWNER="DuSystemSummary";
 public static final boolean NORMAL_START_ONBOARDING=false;
 private DuUiContract(){}
}
