package com.sentongoharuna.worldsituationroom;
import android.content.*;
public final class DuUiMetrics{
 public static final int GRID=8;
 public static final int EDGE=8;
 public static final int GAP=8;
 public static final int PANEL_X=8;
 public static final int PANEL_Y=8;
 public static final int TOUCH=48;
 public static final int RADIUS=12;
 private DuUiMetrics(){}
 public static int dp(Context c,int value){return Math.round(value*c.getResources().getDisplayMetrics().density);}
}
