package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.os.*;import android.view.*;
public final class DuSystemInsets{
 private DuSystemInsets(){}
 public static void apply(Activity a,View root){
  if(root==null)return;final int l=root.getPaddingLeft(),t=root.getPaddingTop(),r=root.getPaddingRight(),b=root.getPaddingBottom();
  if(Build.VERSION.SDK_INT>=21){root.setOnApplyWindowInsetsListener((v,in)->{int top=in.getSystemWindowInsetTop(),bottom=in.getSystemWindowInsetBottom(),left=in.getSystemWindowInsetLeft(),right=in.getSystemWindowInsetRight();v.setPadding(l+left,t+top,r+right,b+bottom);return in;});root.requestApplyInsets();}
  root.setFitsSystemWindows(false);
 }
}
