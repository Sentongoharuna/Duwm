package com.sentongoharuna.worldsituationroom;
public final class DuUiOwnership{
 public static final String NAVIGATION="FIVE_NAV";
 public static final String COUNTS="SITUATION_STRIP";
 public static final String STATUS="COMPACT_OPS";
 public static final String GLOBE="GLOBE_STAGE";
 public static final String TOOLS="INTELLIGENCE_DRAWER";
 public static final String DIAGNOSTICS="SYSTEM_DRAWER";
 private DuUiOwnership(){}
}
