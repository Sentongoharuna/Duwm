package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.content.*;import android.view.*;import android.widget.*;
public final class DuFiveNav{
 public static final String[] PAGES={"GLOBE","MONITORS","NEWS","REGION","REPLAY"};
 private DuFiveNav(){}
 public static View make(Activity a,String current){
  HorizontalScrollView scroll=new HorizontalScrollView(a);scroll.setHorizontalScrollBarEnabled(false);scroll.setFillViewport(true);
  LinearLayout row=new LinearLayout(a);row.setGravity(Gravity.CENTER_VERTICAL);
  for(String page:PAGES){Button b=Du2Ui.button(a,page);boolean active=page.equals(current);b.setTextSize(DuTypeScale.LABEL);b.setText(active?"● "+page:page);b.setTextColor(active?Du2Ui.C:Du2Ui.M);b.setTypeface(android.graphics.Typeface.MONOSPACE,active?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL);b.setAlpha(active?1f:.72f);b.setMaxLines(DuResponsiveUi.maxLabelLines(a));b.setContentDescription(page+(active?" current destination":" destination"));b.setSelected(active);b.setOnClickListener(v->{if(!active)open(a,page);});row.addView(b,new LinearLayout.LayoutParams(Du2Ui.dp(a,DuOrientationUi.navCellDp(a)),Du2Ui.dp(a,48)));}
  scroll.addView(row);return scroll;
 }
 public static void open(Activity a,String page){
  if("NEWS".equals(page)){DuPageRouter.open(a,"NEWS");return;}a.startActivity(DuDirectRoute.top(a,page));
 }
}
