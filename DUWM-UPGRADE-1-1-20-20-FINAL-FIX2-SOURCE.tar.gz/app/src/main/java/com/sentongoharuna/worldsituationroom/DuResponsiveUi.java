package com.sentongoharuna.worldsituationroom;
import android.content.*;import android.content.res.*;
public final class DuResponsiveUi{
 private DuResponsiveUi(){}
 public static boolean largeFont(Context c){return c.getResources().getConfiguration().fontScale>=1.20f;}
 public static boolean narrow(Context c){return c.getResources().getConfiguration().screenWidthDp<390;}
 public static int navCellDp(Context c){return narrow(c)||largeFont(c)?104:96;}
 public static int situationCellDp(Context c){return narrow(c)||largeFont(c)?104:92;}
 public static int maxLabelLines(Context c){return largeFont(c)?2:1;}
}
