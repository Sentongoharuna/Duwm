# Upgrade 1.1 / 20-9 — Reduce Card Inflation
- Adds a compact shared secondary-panel treatment.
- PURPOSE and WORKFLOW explanatory cards use tighter padding/type and a 3-line ellipsized body.
- Primary live/intelligence cards remain full-size.
- Existing routes and data engines are unchanged.
