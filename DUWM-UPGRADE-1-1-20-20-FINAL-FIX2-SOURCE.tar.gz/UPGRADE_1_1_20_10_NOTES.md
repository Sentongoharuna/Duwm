# Upgrade 1.1 / 20-10 — Spacing System
- Centralizes 8dp grid, 8dp edge/gap/panel rhythm, 48dp minimum touch target, and 12dp radius token.
- Shared panels align to the 8dp grid.
- Shared text uses 16dp horizontal / 8dp vertical padding.
- Five-nav, chronological nav and Situation Strip share the same 8dp edge rhythm.
- Existing drawable appearance is preserved; radius token is established for later drawable consolidation rather than rewriting working drawables in this step.
