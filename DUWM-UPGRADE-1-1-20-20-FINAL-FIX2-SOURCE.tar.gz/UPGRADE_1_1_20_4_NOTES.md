# Upgrade 1.1 / 20-4
Remove duplicated LIVE / OPS / SRC / SYNC presentation from the primary operational shell.
A single compact truthful status line now summarizes how many canonical systems are LIVE, DELAYED or OFFLINE.
Cumulative changes from 1/20 and 3/20 are retained.
