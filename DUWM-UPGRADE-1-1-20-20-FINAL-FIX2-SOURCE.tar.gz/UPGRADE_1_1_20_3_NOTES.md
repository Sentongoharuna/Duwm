# Upgrade 1.1 / 20-3 — Compact DU Header
Cumulative from 1/20.
- Preserves the DU logo and DU WORLD MONITOR identity.
- Reduces logo footprint from 48dp to 38dp.
- Reduces brand type from 16sp to 14sp.
- Simplifies the operational subtitle to LIVE · EAST AFRICA · current page.
- Reduces shared header padding where the existing exact header padding contract is present.
- Does not change routes, provider engines, globe engine, Monitor Network, widgets, or intelligence logic.
