# Upgrade 1.1 / 20-6
Replaces oversized BACK / CURRENT / NEXT navigation cards at the shared DuChronoNav owner.
- Fixed 48dp rail height.
- Compact 92dp back/next controls.
- Current destination occupies flexible center space.
- Disabled edge controls fade instead of becoming large dead cards.
- Permanent five-destination shell from 5/20 is preserved.
- No data/provider/globe engine changes.
