# Upgrade 1.1 / 20-1
Single isolated change:
- Normal app startup no longer redirects into the 1/4–4/4 welcome sequence.
- Existing onboarding/help implementation is retained in source.
- No provider, globe, Monitor, widget, navigation, diagnostics, recovery or visual-engine changes are included.
- Built directly from the confirmed green STEP12 FIX2 source.
