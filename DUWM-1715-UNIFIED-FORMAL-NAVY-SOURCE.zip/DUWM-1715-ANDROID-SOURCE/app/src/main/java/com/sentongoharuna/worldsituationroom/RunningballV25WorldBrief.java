package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;
/** Independent V25 V7 World Brief. Only labels real provider caches; never invents events. */
public final class RunningballV25WorldBrief extends LinearLayout {
  private static final int CYAN=0xFF558BDF,GREEN=0xFF558BDF,AMBER=0xFF558BDF,INK=0xFFE0EAFE,MUTED=0xFFBECCE5;
  private static final String[] PLACES={"KAMPALA","LONDON","NEW YORK","TOKYO","SINGAPORE","DUBAI","PARIS","NAIROBI"};
  private static final double[] LAT={0.3476,51.5074,40.7128,35.6762,1.3521,25.2048,48.8566,-1.2864};
  private static final double[] LON={32.5825,-0.1278,-74.0060,139.6503,103.8198,55.2708,2.3522,36.8172};
  private final Handler ui=new Handler(Looper.getMainLooper());
  private final TextView state,regional;private final LinearLayout dispatchRows;
  private final Context app;private boolean active=false;private long lastTap=0L;
  private final Runnable poll=new Runnable(){@Override public void run(){if(!active)return;render();ui.postDelayed(this,10000L);}};
  private int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);}
  private TextView label(String s,int sp,int color,boolean strong){TextView t=new TextView(getContext());t.setText(s);t.setTextColor(color);t.setTextSize(sp);if(strong)t.setTypeface(null,1);return t;}
  private GradientDrawable box(int border){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFF112549,0xFF050D22});d.setStroke(dp(1),border);d.setCornerRadius(dp(12));return d;}
  private SharedPreferences prefs(String file){return app.getSharedPreferences(file,Context.MODE_PRIVATE);}
  private JSONObject parse(String s){try{return new JSONObject(s);}catch(Exception e){return new JSONObject();}}
  private static String clean(String text,int len){if(text==null)return "";String s=text.replace('\n',' ').replace('\r',' ').trim();return s.length()>len?s.substring(0,len)+"…":s;}
  private static String age(long when){if(when<=0)return "NO REPORT";long minutes=Math.max(0,System.currentTimeMillis()-when)/60000L;return minutes<1?"<1m":minutes<60?minutes+"m":minutes<1440?(minutes/60)+"h":(minutes/1440)+"d";}
  private static boolean validUrl(String url){return url!=null&&url.startsWith("https://")&&!url.contains(" ");}
  private TextView action(String title,Runnable onClick){TextView t=label(title,11,CYAN,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(12),dp(12),dp(12),dp(12));t.setMinimumHeight(dp(48));t.setBackground(box(0xFF284C87));t.setContentDescription(title);t.setOnClickListener(v->onClick.run());return t;}
  private void open(Class<?> target){getContext().startActivity(new Intent(getContext(),target));}
  private void sourceRow(String head,String detail,String footer,Runnable click){
    LinearLayout item=new LinearLayout(getContext());item.setOrientation(VERTICAL);item.setPadding(dp(10),dp(9),dp(10),dp(9));item.setBackground(box(0xFF284C87));
    item.addView(label(head,11,CYAN,true));
    TextView title=label(detail,13,INK,false);title.setMaxLines(3);item.addView(title);
    item.addView(label(footer,10,MUTED,false));
    if(click!=null){item.setMinimumHeight(dp(52));item.setOnClickListener(v->click.run());item.setContentDescription(head+" "+detail);}
    LayoutParams params=new LayoutParams(-1,-2);params.topMargin=dp(6);dispatchRows.addView(item,params);
  }
  private void news(){
    RunningballV25Sources.Result status=RunningballV25Sources.read(app,5);
    JSONObject cache=parse(prefs("rb17_verified_feeds").getString("news_json","{}"));JSONArray a=cache.optJSONArray("articles");
    if(status.fetchedAt<=0||a==null||a.length()==0){sourceRow("WORLD NEWS · "+status.status,"No verified headlines yet. Open Source Health to inspect publisher errors.","GDELT / DW · "+status.errorReason,()->open(RunningballV25SourceHealthActivity.class));return;}
    String provider=cache.optString("provider","NEWS PROVIDER");
    for(int i=0,shown=0;i<a.length()&&shown<3;i++){
      JSONObject item=a.optJSONObject(i);if(item==null)continue;
      String title=clean(item.optString("title",""),155),url=item.optString("url","");
      if(title.isEmpty()||!validUrl(url))continue;
      sourceRow("NEWS  "+(shown+1)+"  ·  "+status.status,title,clean(provider,55)+"  ·  FETCH "+age(status.fetchedAt),()->{try{
        Intent open=new Intent(Intent.ACTION_VIEW,Uri.parse(url));getContext().startActivity(open);}catch(Exception e){open(RunningballV17DetailsActivity.class);}});
      shown++;
    }
  }
  private void quakes(){
    RunningballV25Sources.Result status=RunningballV25Sources.read(app,3);
    JSONObject cache=parse(prefs("rb_global_public_events").getString("quakes_raw","{}"));JSONArray features=cache.optJSONArray("features");
    if(status.fetchedAt<=0||features==null||features.length()==0){sourceRow("EARTHQUAKES · "+status.status,"No USGS records received; check the provider status.","USGS · "+status.errorReason,()->open(RunningballGlobalEventsActivity.class));return;}
    for(int i=0,shown=0;i<features.length()&&shown<3;i++){
      JSONObject item=features.optJSONObject(i);JSONObject properties=item==null?null:item.optJSONObject("properties");if(properties==null)continue;
      double mag=properties.optDouble("mag",Double.NaN);String location=clean(properties.optString("place",""),98);
      if(!Double.isFinite(mag)||location.isEmpty())continue;
      long happened=properties.optLong("time",0L);String detail=String.format(Locale.US,"M %.1f  ·  %s",mag,location);
      sourceRow("EARTHQUAKE  ·  "+status.status,detail,"USGS event "+age(happened)+" ago · feed fetch "+age(status.fetchedAt),()->open(RunningballGlobalEventsActivity.class));shown++;
    }
  }
  private void nasa(){
    RunningballV25Sources.Result status=RunningballV25Sources.read(app,4);
    JSONObject cache=parse(prefs("rb_global_public_events").getString("nasa_raw","{}"));JSONArray events=cache.optJSONArray("events");
    if(status.fetchedAt<=0||events==null||events.length()==0){sourceRow("NATURAL EVENTS · "+status.status,"No NASA EONET events loaded; check the provider.","NASA EONET · "+status.errorReason,()->open(RunningballGlobalEventsActivity.class));return;}
    for(int i=0,shown=0;i<events.length()&&shown<2;i++){
      JSONObject e=events.optJSONObject(i);if(e==null)continue;
      String title=clean(e.optString("title",""),138);if(title.isEmpty())continue;
      JSONArray tags=e.optJSONArray("categories");JSONObject category=tags==null?null:tags.optJSONObject(0);
      String type=category==null?"NATURAL EVENT":clean(category.optString("title","NATURAL EVENT"),50);
      sourceRow("NASA EONET  ·  "+status.status,title,type+"  ·  FETCH "+age(status.fetchedAt)+" · curated event",()->open(RunningballGlobalEventsActivity.class));shown++;
    }
  }
  private void refresh(){long now=System.currentTimeMillis();if(now-lastTap<90000L){state.setText("REFRESH COOLDOWN · LAST REQUESTS MAY STILL BE RUNNING");return;}
    lastTap=now;state.setText("DATA REQUESTS SENT · AWAITING VERIFIED RESPONSES");
    Runnable done=()->ui.post(this::render);
    try{RunningballV16SourceRefresh.request(app,false,done);}catch(RuntimeException ignored){}
    try{RunningballV17Feeds.request(app,false,done);}catch(RuntimeException ignored){}
    try{RunningballV19SatelliteBootstrap.request(app,done);}catch(RuntimeException ignored){}
    try{RunningballV19Noaa.request(app,done);}catch(RuntimeException ignored){}
    if(RunningballWorldTarget.ready(app))airRequest();
  }
  private void airRequest(){Intent i=new Intent(app,AirOperationsWidgets.Pulse.class);
    i.setAction("com.sentongoharuna.worldsituationroom.AIR_WIDGET_REFRESH");i.setPackage(app.getPackageName());app.sendBroadcast(i);
  }
  private void choose(int n){RunningballWorldTarget.choose(app,LAT[n],LON[n],PLACES[n],"USER_PRESET");
    airRequest();RunningballV17Feeds.request(app,false,()->ui.post(this::render));render();
  }
  public RunningballV25WorldBrief(Context c){super(c);app=c.getApplicationContext();setOrientation(VERTICAL);
    setPadding(dp(11),dp(12),dp(11),dp(12));setBackground(box(CYAN));
    addView(label("WORLD BRIEF  /  VERIFIED ACTUAL INFORMATION",14,GREEN,true));
    state=label("READING GLOBAL PROVIDER CACHES",11,INK,false);addView(state);
    regional=label("AIRCRAFT · SELECT A REGION FOR 250 NM OBSERVATIONS",11,AMBER,true);regional.setPadding(0,dp(8),0,dp(7));addView(regional);
    HorizontalScrollView horizontal=new HorizontalScrollView(c);horizontal.setHorizontalScrollBarEnabled(false);
    LinearLayout places=new LinearLayout(c);places.setOrientation(HORIZONTAL);
    for(int n=0;n<PLACES.length;n++){final int index=n;TextView b=action(PLACES[n],()->choose(index));
      LayoutParams lp=new LayoutParams(-2,-2);lp.rightMargin=dp(7);places.addView(b,lp);}
    horizontal.addView(places);addView(horizontal,new LayoutParams(-1,-2));
    LinearLayout options=new LinearLayout(c);options.setOrientation(HORIZONTAL);
    options.addView(action("REFRESH WORLD FEEDS",this::refresh),new LayoutParams(0,-2,1));
    options.addView(action("SOURCE ERRORS",()->open(RunningballV25SourceHealthActivity.class)),new LayoutParams(0,-2,1));
    LayoutParams op=new LayoutParams(-1,-2);op.topMargin=dp(8);addView(options,op);
    dispatchRows=new LinearLayout(c);dispatchRows.setOrientation(VERTICAL);addView(dispatchRows);
    addView(label("GLOBAL EVENTS WORK WITHOUT REGION · AIS NEEDS AN AUTHORIZED GATEWAY · NO FAKE WORLD AIRCRAFT TOTALS",10,AMBER,false));
    render();
  }
  public void render(){
    int actual=0;for(int i=0;i<9;i++){RunningballV25Sources.Result r=RunningballV25Sources.read(app,i);
      if(r.fetchedAt>0)actual++;}
    state.setText(actual+" / 9 SOURCES WITH VERIFIED CACHED REPORTS  ·  SOURCE ERRORS SHOWN WHEN MISSING");
    regional.setText(RunningballWorldTarget.ready(app)?
      "AIRCRAFT · "+RunningballWorldTarget.label(app)+" · REGIONAL 250 NM, NOT WORLDWIDE":"AIRCRAFT + WEATHER · CHOOSE REGION TO LOAD OBSERVATIONS");
    dispatchRows.removeAllViews();news();quakes();nasa();
  }
  @Override protected void onAttachedToWindow(){super.onAttachedToWindow();active=true;ui.removeCallbacks(poll);ui.post(poll);}
  @Override protected void onDetachedFromWindow(){active=false;ui.removeCallbacks(poll);super.onDetachedFromWindow();}
}
