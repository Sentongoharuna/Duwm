package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 1711: 19 native desks share an honest status footer BELOW the content.
 * No translucent source buttons float above video, maps, tracks, or news.
 * Only wraps a single Activity content child so existing complex layouts
 * with multiple decor children are not rearranged or intercepted.
 */
public final class Duwm1711NativeDeskDock {
    private Duwm1711NativeDeskDock() {}
    private static final String TAG="duwm1711-native-dock";
    private static int dp(Activity a, float v) {
        return Math.max(1,Math.round(v*a.getResources().getDisplayMetrics().density));
    }
    private static GradientDrawable pill(Activity a,int index) {
        GradientDrawable d=Duwm1709SectorOutline.card(a,index,DuwmUnifiedTheme.PANEL,false);
        return d;
    }
    private static TextView label(Activity a,String s,int size,int color,boolean bold) {
        TextView t=new TextView(a);
        t.setText(s);t.setTextSize(size);t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        return t;
    }
    private static TextView action(Activity a,int sector,String s,Runnable fn) {
        TextView t=label(a,s,11,DuwmUnifiedTheme.TEXT,true);
        t.setBackground(pill(a,sector));
        t.setOnClickListener(v->fn.run());
        t.setContentDescription(s);
        t.setMinHeight(dp(a,48));
        t.setMinimumHeight(dp(a,48));
        return t;
    }
    public static boolean attach(Activity a,Duwm1683DeskCatalog.Desk desk) {
        if(a==null || desk==null || a.isFinishing())return false;
        FrameLayout content=a.findViewById(android.R.id.content);
        if(content==null || content.findViewWithTag(TAG)!=null || content.getChildCount()!=1)return false;
        View original=content.getChildAt(0);
        if(original==null)return false;
        int sector=Duwm1709SectorOutline.index(desk);
        if(sector<0)return false;

        LinearLayout shell=new LinearLayout(a);
        shell.setTag(TAG);shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(DuwmUnifiedTheme.BACKGROUND);

        // Move, never duplicate, the existing native page. Its own renderer and
        // event listeners remain alive in a dedicated, unobstructed viewport.
        content.removeView(original);
        shell.addView(original,new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,0,1f));

        LinearLayout footer=new LinearLayout(a);
        footer.setOrientation(LinearLayout.VERTICAL);
        footer.setPadding(dp(a,8),dp(a,2),dp(a,8),dp(a,4));
        footer.setBackgroundColor(DuwmUnifiedTheme.APPROVED_NAVY);
        View accent=new View(a);
        accent.setBackgroundColor(Duwm1709SectorOutline.color(sector));
        footer.addView(accent,new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,dp(a,1)));
        String status=Duwm1683DeskCatalog.status(a,desk);
        TextView caption=label(a,String.format(java.util.Locale.US,
                "DUWM 1715  /  SECTOR %02d OF 19  /  %s  /  %s",
                sector+1,desk.title.toUpperCase(java.util.Locale.US),
                status==null?"SOURCE STATE UNKNOWN":status),10,DuwmUnifiedTheme.MUTED,false);
        caption.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
        caption.setContentDescription("Sector "+(sector+1)+" of 19. "+desk.title+". "+status);
        footer.addView(caption,new LinearLayout.LayoutParams(-1,dp(a,20)));
        LinearLayout controls=new LinearLayout(a);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        TextView details=action(a,sector,"SOURCE",()->Duwm1683DeskDetailKit.show(a,desk));
        TextView matrix=action(a,sector,"OPS MATRIX",()->a.startActivity(
                new Intent(a,Duwm1712OperationsMatrixActivity.class)));
        TextView all=action(a,sector,"19 DESKS",()->a.startActivity(new Intent(a,DuwmOptionsActivity.class)));
        TextView globe=action(a,sector,"GLOBE",()->{
            Intent i=new Intent(a,MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            a.startActivity(i);
        });
        controls.addView(details,new LinearLayout.LayoutParams(0,dp(a,48),1f));
        LinearLayout.LayoutParams opsParams=new LinearLayout.LayoutParams(0,dp(a,48),1.25f);
        opsParams.leftMargin=dp(a,4);controls.addView(matrix,opsParams);
        LinearLayout.LayoutParams p2=new LinearLayout.LayoutParams(0,dp(a,48),1f);p2.leftMargin=dp(a,4);
        controls.addView(all,p2);
        LinearLayout.LayoutParams p3=new LinearLayout.LayoutParams(0,dp(a,48),0.9f);p3.leftMargin=dp(a,4);
        controls.addView(globe,p3);
        footer.addView(controls,new LinearLayout.LayoutParams(-1,dp(a,48)));
        shell.addView(footer,new LinearLayout.LayoutParams(-1,dp(a,84)));
        content.addView(shell,new FrameLayout.LayoutParams(-1,-1));
        return true;
    }
}
