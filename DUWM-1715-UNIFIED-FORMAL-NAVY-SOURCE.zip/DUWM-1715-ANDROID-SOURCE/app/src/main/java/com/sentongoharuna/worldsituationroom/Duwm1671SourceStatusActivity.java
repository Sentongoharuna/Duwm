package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.EditText;
import android.text.TextWatcher;
import android.text.Editable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** True provider diagnostic board: last receipt, last known source time, state and error. */
public final class Duwm1671SourceStatusActivity extends Activity {
  private static final int BG=0xFF050D22,CYAN=0xFF558BDF,WHITE=0xFFDCE9FD,MUTED=0xFFBAC7CA,AMBER=0xFFFFB45A;
  private LinearLayout rows;private boolean issuesOnly=false,compactRows=false;private String sourceQuery="";private StringBuilder lastReport=new StringBuilder();private TextView issueFilter,receiptSummary;private Duwm1690EvidenceBars healthEvidence;private final Handler handler=new Handler(Looper.getMainLooper());private boolean foreground;
  private final Runnable ticker=new Runnable(){@Override public void run(){if(!foreground)return;render();handler.postDelayed(this,30000);}};
  private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}
  private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  private GradientDrawable bg(){GradientDrawable d=new GradientDrawable();d.setColor(0xFF0D1E3B);d.setCornerRadius(dp(10));d.setStroke(dp(1),0xFF284C87);return d;}
  private static String utc(long t){if(t<=0)return "NOT SUPPLIED";SimpleDateFormat f=new SimpleDateFormat("dd MMM HH:mm:ss 'UTC'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(t));}
  @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(BG);setContentView(scroll);Duwm1167SafeArea.install(this,scroll);
    LinearLayout root=new LinearLayout(this);root.setPadding(dp(14),dp(14),dp(14),dp(28));root.setOrientation(LinearLayout.VERTICAL);scroll.addView(root);
    root.addView(text("DEVELOP.UGANDA / VERIFIED PROVIDER MONITOR",12,CYAN,true));root.addView(Duwm1693Chrome.title(text("SOURCE HEALTH  /  1701",26,WHITE,true)));
    root.addView(text("A connected directory is not a live feed. 'Received' means the phone has a provider response. Stale and rate-limited receipts remain visible.",12,MUTED,false));
    TextView refresh=text("REFRESH AIRCRAFT + NEWS + REGIONAL AIS",12,CYAN,true);refresh.setPadding(dp(12),dp(14),dp(12),dp(14));refresh.setGravity(Gravity.CENTER);refresh.setBackground(bg());root.addView(refresh);
    refresh.setOnClickListener(v->{
      RunningballV25GlobalAircraftData.refreshNow(this,this::render);
      RunningballV25NewsRepository.refresh(this,true,this::render);
      RunningballV17Feeds.request(this,true,this::render);
      Duwm1674MaritimeRefresh.refresh(this,this::render);
    });
    EditText sourceSearch=new EditText(this);sourceSearch.setSingleLine(true);sourceSearch.setTextSize(14);
    sourceSearch.setTextColor(WHITE);sourceSearch.setHintTextColor(MUTED);sourceSearch.setHint("Search provider, error, receipt or coverage");
    sourceSearch.setPadding(dp(12),0,dp(12),0);sourceSearch.setBackground(bg());root.addView(sourceSearch,new LinearLayout.LayoutParams(-1,dp(53)));
    sourceSearch.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}
      public void onTextChanged(CharSequence s,int start,int before,int count){sourceQuery=s.toString().trim().toLowerCase(Locale.US);render();}
      public void afterTextChanged(Editable e){} });
    issueFilter=text("SHOW ONLY UNAVAILABLE / DELAYED RECEIPTS",12,CYAN,true);
    issueFilter.setPadding(dp(12),dp(13),dp(12),dp(13));issueFilter.setBackground(bg());root.addView(issueFilter);
    issueFilter.setOnClickListener(v->{issuesOnly=!issuesOnly;issueFilter.setText(issuesOnly?"SHOWING ISSUES ONLY  /  TAP FOR ALL":"SHOW ONLY UNAVAILABLE / DELAYED RECEIPTS");render();});
    TextView density=text("SOURCE DETAILS  /  EXPANDED  •  TAP FOR COMPACT",12,CYAN,true);
    density.setPadding(dp(12),dp(12),dp(12),dp(12));density.setBackground(bg());root.addView(density);
    density.setOnClickListener(v->{compactRows=!compactRows;density.setText(compactRows?"INCIDENT DETAIL  /  COMPACT  •  TAP TO EXPAND":"INCIDENT DETAIL  /  EXPANDED  •  TAP TO COMPACT");render();});
    healthEvidence=new Duwm1690EvidenceBars(this);
    TextView healthChartToggle=text("SHOW PROVIDER RECEIPT CHART  ▸",12,CYAN,true);
    healthChartToggle.setPadding(dp(10),dp(12),dp(10),dp(12));healthChartToggle.setBackground(bg());
    root.addView(healthChartToggle);
    healthEvidence.setVisibility(android.view.View.GONE);
    root.addView(healthEvidence,new LinearLayout.LayoutParams(-1,dp(224)));
    healthChartToggle.setOnClickListener(v->{boolean open=healthEvidence.getVisibility()!=android.view.View.VISIBLE;
      healthEvidence.setVisibility(open?android.view.View.VISIBLE:android.view.View.GONE);
      healthChartToggle.setText(open?"HIDE PROVIDER RECEIPT CHART  ▴":"SHOW PROVIDER RECEIPT CHART  ▸");});
    receiptSummary=text("PROVIDER RECEIPT AUDIT / AWAITING LOCAL STORE",13,WHITE,true);
    receiptSummary.setPadding(dp(12),dp(12),dp(12),dp(12));receiptSummary.setBackground(bg());
    root.addView(receiptSummary,new LinearLayout.LayoutParams(-1,-2));
    rows=new LinearLayout(this);rows.setOrientation(LinearLayout.VERTICAL);root.addView(rows);
    TextView export=text("SHARE CURRENT SOURCE DIAGNOSTICS  /  TEXT",12,CYAN,true);
    export.setPadding(dp(12),dp(16),dp(12),dp(16));export.setBackground(bg());root.addView(export);
    export.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");
      i.putExtra(Intent.EXTRA_SUBJECT,"DUWM 1701 source receipt diagnostics");
      i.putExtra(Intent.EXTRA_TEXT,lastReport.toString());startActivity(Intent.createChooser(i,"Share genuine provider diagnostics"));});
    TextView globe=text("RETURN TO ORIGINAL COMMAND GLOBE",12,CYAN,true);globe.setPadding(dp(12),dp(16),dp(12),dp(16));globe.setBackground(bg());root.addView(globe);
    globe.setOnClickListener(v->{Intent home=new Intent(this,MainActivity.class);
      home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(home);});
    render();
  }
  private TextView row(String header,String body,boolean ok){
    TextView t=text((ok?"● RECEIVED / CURRENT  |  ":"● REVIEW SOURCE  |  ")+header+(compactRows?"":"\n"+body),12,ok?WHITE:AMBER,true);
    t.setPadding(dp(17),dp(13),dp(12),dp(15));
    GradientDrawable surface=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
      new int[]{ok?0xFF124647:0xFF54382D,0xFF122B4D});
    surface.setCornerRadius(dp(9));surface.setStroke(dp(1),ok?0xFF2D927E:0xFF9B6947);t.setBackground(surface);
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(8);
    boolean queryMatch=sourceQuery.isEmpty()||(header+" "+body).toLowerCase(Locale.US).contains(sourceQuery);
    if((!issuesOnly||!ok)&&queryMatch){
      rows.addView(t,lp);lastReport.append("\n").append(header).append(" / ")
        .append(ok?"RECEIVED OR CURRENT":"REVIEW").append("\n").append(body).append("\n");
    }return t;
  }
  private void render(){if(rows==null)return;rows.removeAllViews();
    lastReport=new StringBuilder("DUWM 1701 / SOURCE RECEIPT DIAGNOSTICS\nGenerated on device: "+utc(System.currentTimeMillis())+
      "\nThis is a local provider receipt report, not proof of globally live sources.\n");RunningballV25GlobalAircraftData.Snapshot g=RunningballV25GlobalAircraftData.read(this);
    int current=0,received=0,unavailable=0,old=0;long now=System.currentTimeMillis();
    for(int k=0;k<RunningballV25Sources.IDS.length;k++){
      RunningballV25Sources.Result r=RunningballV25Sources.read(this,k);
      if(r.fetchedAt>0){received++;if(r.status==RunningballV25Sources.Status.LIVE && r.fetchedAt<=now&&now-r.fetchedAt<3600000L)current++;
        else old++;}else unavailable++;
    }
    if(receiptSummary!=null)receiptSummary.setText("PROVIDER AUDIT  •  "+current+" CURRENT  /  "+old+
      " OLD OR NON-LIVE  /  "+unavailable+" NEVER RECEIVED\n"+
      "LOCAL STORE  /  "+RunningballV25Sources.IDS.length+" SOURCE CATEGORIES; NO CLAIM OF WORLDWIDE COVERAGE");
    if(healthEvidence!=null)healthEvidence.setValues("PROVIDER MATRIX / PHONE RECEIPTS",
      new String[]{"RECEIVED AT LEAST ONCE","CURRENT < 1 HOUR","OLD / NON-LIVE","NOT RECEIVED"},
      new long[]{received,current,old,unavailable});
    row("OPENSKY / WORLDWIDE AIRCRAFT","STATE "+g.status()+"\nPROVIDER REPORT: "+utc(g.sourceAt)+"\nLAST FETCH: "+utc(g.receivedAt)+"\nHTTP: "+g.lastHttp+"  /  NEXT ATTEMPT "+g.nextCheckLabel()+"\nVALID POSITIONS: "+(g.positionRows>=0?g.positionRows:"--")+(g.error.isEmpty()?"":"\nERROR: "+g.error),g.hasGood()&&g.ageMs()<3600000L&&g.error.isEmpty());
    Duwm1674UnifiedReceipts.Receipt aircraft=Duwm1674UnifiedReceipts.aircraft(this);
    Duwm1674UnifiedReceipts.Receipt maritime=Duwm1674UnifiedReceipts.maritime(this);
    Duwm1674UnifiedReceipts.Receipt headlines=Duwm1674UnifiedReceipts.news(this);
    row("OPEN AIRCRAFT MAP  ›","POSITIONS "+aircraft.count()+" / "+aircraft.detail,aircraft.current)
      .setOnClickListener(v->startActivity(new Intent(this,Duwm1670FlightMapActivity.class)));
    row("OPEN MARITIME AIS MAP  ›","AIS POSITIONS "+maritime.count()+" / "+maritime.detail,maritime.current)
      .setOnClickListener(v->startActivity(new Intent(this,GevMarineActivity.class)));
    row("OPEN NEWSROOM  ›","SOURCE ITEMS "+headlines.count()+" / "+headlines.detail,headlines.current)
      .setOnClickListener(v->startActivity(new Intent(this,Duwm1166NewsDeskActivity.class)));
    for(int i=0;i<RunningballV25Sources.IDS.length;i++){
      if(i==0||i==2||i==5)continue; // avoid contradictory legacy-cache indicators
      RunningballV25Sources.Result r=RunningballV25Sources.read(this,i);
      boolean good=r.fetchedAt>0&&r.status==RunningballV25Sources.Status.LIVE&&
        r.fetchedAt<=System.currentTimeMillis()&&System.currentTimeMillis()-r.fetchedAt<3600000L;
      row(RunningballV25Sources.NAMES[i]+" / "+r.provider,
        "STATUS: "+r.status.toString().replace('_',' ')+"\nLAST FETCH: "+utc(r.fetchedAt)+"\nSOURCE TIME: "+utc(r.sourceTime)+"\nVALUE / COUNT: "+r.value+"\nCOVERAGE: "+r.coverage+
        (r.errorReason.isEmpty()?"":"\nERROR: "+r.errorReason),good);
    }
    int news=new NewsStore(this).load().size();int nativeNews=0;long nativeAt=0L;String failed="";
    for(String key:RunningballV25NewsRepository.KEYS){
      nativeNews+=RunningballV25NewsRepository.articles(this,key).length();
      nativeAt=Math.max(nativeAt,RunningballV25NewsRepository.last(this,key));
      if(failed.isEmpty())failed=RunningballV25NewsRepository.error(this,key);
    }
    org.json.JSONArray globalNews=RunningballV17Feeds.cached(this,RunningballV17Feeds.NEWS).optJSONArray("articles");
    int globalCount=globalNews==null?0:globalNews.length();
    row("REAL NEWS FEED RECEIPTS", "OLDER CACHE "+news+" · RSS/GDELT "+nativeNews+" · GLOBAL DW/GDELT "+globalCount+
      "\nLATEST NATIVE RECEIPT: "+utc(nativeAt)+(failed.isEmpty()?"":"\nLATEST FEED ERROR: "+failed)+
      "\nSource-directory websites are not counted as fetched articles.", news+nativeNews+globalCount>0);
    int ships=0,earth=0,iss=0;for(DuwmGeoObservationStore.Fix f:DuwmGeoObservationStore.read(this)){
      if("VESSEL".equals(f.type)||"VESSELS".equals(f.type))ships++;if("EARTHQUAKE".equals(f.type))earth++;if("ISS".equals(f.type))iss++;}
    row("LOCAL GEO OBSERVATION CACHE","Vessel fixes: "+ships+" · Earthquakes: "+earth+" · ISS: "+iss+". Figures are stored records, not global simultaneous totals.",ships+earth+iss>0);
  }
  @Override protected void onResume(){super.onResume();foreground=true;handler.post(ticker);}
  @Override protected void onPause(){foreground=false;handler.removeCallbacks(ticker);super.onPause();}
}
