package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Global public events, never simulated markers. USGS / NASA source attribution and age shown. */
public final class RunningballGlobalEventsActivity extends Activity {
  private static final int BG=0xFF050D22,CYAN=0xFF558BDF,INK=0xFFDCE9FD,DIM=0xFF4C78C4;
  private static final String USGS="https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson";
  private static final String NASA="https://eonet.gsfc.nasa.gov/api/v3/events?status=open&limit=65";
  private final String PREF="rb_global_public_events";
  private LinearLayout list;
  private TextView state;
  private int dp(int n){return Math.round(getResources().getDisplayMetrics().density*n);}
  private TextView text(String s,int size,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);return v;}
  private GradientDrawable bg(){GradientDrawable g=new GradientDrawable();g.setColor(0xFF0C1B39);g.setCornerRadius(dp(13));g.setStroke(dp(1),0xFF426CAF);return g;}
  private TextView button(String label,Runnable r){TextView v=text(label,12,CYAN);v.setGravity(Gravity.CENTER);v.setBackground(bg());v.setPadding(dp(8),dp(12),dp(8),dp(12));v.setOnClickListener(w->r.run());return v;}
  @Override public void onCreate(Bundle saved){super.onCreate(saved);RunningballV17Insets.install(this);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(BG);
    LinearLayout root=new LinearLayout(this);root.setPadding(dp(15),dp(20),dp(15),dp(20));root.setOrientation(LinearLayout.VERTICAL);sc.addView(root);
    root.addView(text("WORLDWIDE PUBLIC EVENT SIGNALS",20,INK));
    root.addView(text("Real global observations: USGS recent earthquakes and NASA EONET natural events. These are reported events, not a live satellite video feed.",12,DIM));
    LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.HORIZONTAL);
    TextView earthquakes=button("USGS  /  EARTHQUAKES",()->load("quakes",USGS));controls.addView(earthquakes,new LinearLayout.LayoutParams(0,dp(49),1));
    TextView nature=button("NASA  /  NATURAL EVENTS",()->load("nasa",NASA));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(49),1);p.leftMargin=dp(6);controls.addView(nature,p);
    LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(49));cp.topMargin=dp(10);root.addView(controls,cp);
    state=text("CHOOSE WORLDWIDE DATASET",12,CYAN);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(13);root.addView(state,sp);
    list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(8);root.addView(list,lp);
    setContentView(sc);load("quakes",USGS);
  }
  private String stamp(long when){if(when<=0L)return "TIME UNAVAILABLE";
    SimpleDateFormat fmt=new SimpleDateFormat("dd MMM HH:mm 'UTC'",Locale.US);fmt.setTimeZone(TimeZone.getTimeZone("UTC"));return fmt.format(new Date(when));}
  private void item(String title,String facts,String source,double lat,double lon){
    TextView v=button(title+"\n"+facts+"\n"+source+"  •  TAP FOR EARTH POSITION",()->{
      if(!RunningballWorldTarget.valid(lat,lon)){state.setText("EVENT LOCATION NOT REPORTED");return;}
      Intent i=new Intent(this,GevEarthExploreActivity.class);i.putExtra("geo_lat",lat);i.putExtra("geo_lon",lon);startActivity(i);
    });v.setGravity(Gravity.LEFT);v.setTextColor(INK);
    LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(7);list.addView(v,p);
  }
  private void show(String kind,String raw,long fetched,boolean cached,String error){list.removeAllViews();
    state.setText((cached?"CACHED / NOT A LIVE UPDATE":"DOWNLOADED REPORT")+" • "+stamp(fetched)+(error.isEmpty()?"":" • "+error));
    int shown=0;try{
      JSONObject data=new JSONObject(raw);
      if("quakes".equals(kind)){
        JSONArray a=data.optJSONArray("features");if(a!=null)for(int i=0;i<a.length()&&shown<75;i++){
          JSONObject e=a.optJSONObject(i);if(e==null)continue;JSONObject prop=e.optJSONObject("properties");JSONObject geom=e.optJSONObject("geometry");if(prop==null||geom==null)continue;
          JSONArray geo=geom.optJSONArray("coordinates");if(geo==null||geo.length()<2)continue;double lon=geo.optDouble(0,Double.NaN),lat=geo.optDouble(1,Double.NaN);
          if(!RunningballWorldTarget.valid(lat,lon))continue;
          String mag=prop.isNull("mag")?"Magnitude not reported":String.format(Locale.US,"M %.1f",prop.optDouble("mag",Double.NaN));
          item(mag+" · "+prop.optString("place","Unnamed event"),stamp(prop.optLong("time",0L))+String.format(Locale.US,"  •  %.3f, %.3f",lat,lon),"USGS • 24H M2.5+",lat,lon);shown++;
        }
      }else{
        JSONArray a=data.optJSONArray("events");if(a!=null)for(int i=0;i<a.length()&&shown<65;i++){
          JSONObject e=a.optJSONObject(i);if(e==null)continue;JSONArray geo=e.optJSONArray("geometry");if(geo==null||geo.length()==0)continue;
          JSONObject last=geo.optJSONObject(geo.length()-1);if(last==null)continue;if(!"Point".equals(last.optString("type")))continue;
          JSONArray coords=last.optJSONArray("coordinates");if(coords==null||coords.length()<2)continue;
          double lon=coords.optDouble(0,Double.NaN),lat=coords.optDouble(1,Double.NaN);if(!RunningballWorldTarget.valid(lat,lon))continue;
          item(e.optString("title","NASA NATURAL EVENT"),"Reported location "+String.format(Locale.US,"%.3f, %.3f",lat,lon)+" • OBSERVED / CURATED","NASA EONET • EVENT",lat,lon);shown++;
        }
      }
    }catch(Exception ex){state.setText("INVALID SOURCE RESPONSE: "+ex.getMessage());}
    if(shown==0)item("NO GEOLOCATED EVENTS AVAILABLE","Provider unavailable, empty or only polygon observations","NO SAMPLE DATA",Double.NaN,Double.NaN);
  }
  private void load(String kind,String endpoint){SharedPreferences cache=getSharedPreferences(PREF,Context.MODE_PRIVATE);
    state.setText("REQUESTING GLOBAL "+kind.toUpperCase(Locale.US)+" DATA...");
    new Thread(()->{HttpURLConnection conn=null;String raw=null,error="";long stamp=0;
      try{conn=(HttpURLConnection)new URL(endpoint).openConnection();conn.setConnectTimeout(9000);conn.setReadTimeout(9000);
        conn.setRequestProperty("User-Agent","RUNNINGBALL2-Worldwide-Events/1.0");
        if(conn.getResponseCode()!=200)throw new IllegalStateException("HTTP "+conn.getResponseCode());
        ByteArrayOutputStream out=new ByteArrayOutputStream();InputStream in=conn.getInputStream();try{byte[] chunk=new byte[8192];int n;while((n=in.read(chunk))!=-1){if(out.size()+n>1_600_000)throw new IllegalStateException("SOURCE RESPONSE TOO LARGE");out.write(chunk,0,n);}}finally{in.close();}
        raw=out.toString("UTF-8");new JSONObject(raw);stamp=System.currentTimeMillis();cache.edit().putString(kind+"_raw",raw).putLong(kind+"_time",stamp).apply();
      }catch(Exception e){error=e.getMessage()==null?"SOURCE ERROR":e.getMessage();raw=cache.getString(kind+"_raw","");stamp=cache.getLong(kind+"_time",0L);}
      finally{if(conn!=null)conn.disconnect();}
      final String body=raw==null?"":raw,reason=error;final long time=stamp;final boolean cached=!reason.isEmpty();
      runOnUiThread(()->show(kind,body,time,cached,reason));
    }).start();
  }
}
