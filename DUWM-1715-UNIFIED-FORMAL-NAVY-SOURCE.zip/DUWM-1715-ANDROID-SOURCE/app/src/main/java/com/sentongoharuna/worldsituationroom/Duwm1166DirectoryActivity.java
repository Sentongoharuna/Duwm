package com.sentongoharuna.worldsituationroom;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;
import java.util.List;

/** One entry point to dedicated real-source desks, with independent LEDs. */
public final class Duwm1166DirectoryActivity extends Activity {
  private static final int BG=0xFF050D22,WHITE=0xFFE2F2F6,MUTED=0xFF4C78C4;
  private static final String[][] DESKS={
    {"AIRCRAFT","Flight records, regions, positions and actual-fix charts"},
    {"VESSELS","AIS provider status, vessel positions and actual track fixes"},
    {"SATELLITES","ISS and satellite source observations"},
    {"WORLD MAP","Full-screen geographic intelligence"},
    {"NEWS","Uganda, world, war, economics, Western, Middle East, Africa, India"},
    {"RADIO ATLAS","Interactive world station positions, regional streams"},
    {"TELEVISION","In-app TV playback from supported sources"},
    {"PUBLIC CAMERAS","Source-backed camera images and available streams"},
    {"NASA","NASA Earth imagery and original satellite explorer"},
    {"EARTHQUAKES","USGS reports, regions and map positions"},
    {"WEATHER","Provider model forecasts and regions"},
    {"MARKETS","ECB reference data and source details"},
    {"EMERGENCIES","GDACS alerts and event reports"},
    {"SOURCE INTELLIGENCE","All available provider records and timestamps"}
  };
  private int dp(float value){return (int)(value*getResources().getDisplayMetrics().density+.5f);}
  private TextView text(String s,int size,int tone){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(tone);return t;}
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(BG);setContentView(scroll);Duwm1167SafeArea.install(this,scroll);
    LinearLayout root=new LinearLayout(this);root.setPadding(dp(12),dp(15),dp(12),dp(25));root.setOrientation(LinearLayout.VERTICAL);scroll.addView(root);
    root.addView(text("DEVELOP.UGANDA / INTELLIGENCE SYSTEM",12,0xFF558BDF));TextView h=text("WORLD SITUATION ROOM",26,WHITE);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(h);
    root.addView(text("1167  •  RECEIVED SOURCE DATA ONLY  •  SELECT AN INTELLIGENCE DESK",11,MUTED));
    List<DuwmGeoObservationStore.Fix> fixes=DuwmGeoObservationStore.read(this);
    for(String[] desk:DESKS){LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(9),dp(12),dp(8),dp(12));
      GradientDrawable bg=new GradientDrawable();bg.setColor(0xFF0C1B39);bg.setCornerRadius(dp(12));bg.setStroke(dp(1),0xFF284C87);card.setBackground(bg);
      LinearLayout.LayoutParams param=new LinearLayout.LayoutParams(-1,-2);param.topMargin=dp(8);root.addView(card,param);
      String category=desk[0];Duwm1166SignalView led=new Duwm1166SignalView(this);
      long observed=0,received=0;for(DuwmGeoObservationStore.Fix f:fixes)if(matches(category,f.type)&&f.sourceTime>observed){observed=f.sourceTime;received=f.receivedAt;}
      if(category.equals("SOURCE INTELLIGENCE")||category.equals("RADIO ATLAS")||category.equals("TELEVISION")||category.equals("PUBLIC CAMERAS"))led.reference();
      else led.source(category,observed,received,false,false);
      card.addView(led,new LinearLayout.LayoutParams(dp(34),dp(52)));
      LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(5),0,0,0);card.addView(info,new LinearLayout.LayoutParams(0,-2,1));
      TextView t=text(category,15,WHITE);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);info.addView(t);
      TextView sub=text(desk[1],11,MUTED);sub.setMaxLines(3);info.addView(sub);
      TextView arrow=text("›",28,0xFF558BDF);card.addView(arrow);
      card.setContentDescription("Open "+category+" intelligence desk");card.setOnClickListener(v->open(category));
    }
  }
  private boolean matches(String category,String type){if(category.equals("AIRCRAFT"))return type.equals("AIRCRAFT");if(category.equals("VESSELS"))return type.equals("VESSEL");
    if(category.equals("SATELLITES"))return type.equals("ISS");if(category.equals("EARTHQUAKES"))return type.equals("EARTHQUAKE");return false;}
  private void open(String name){Intent intent;
    switch(name){
      case "NEWS":intent=new Intent(this,Duwm1166NewsDeskActivity.class);break;
      case "RADIO ATLAS":intent=new Intent(this,Duwm1166RadioAtlasActivity.class);break;
      case "WORLD MAP":intent=new Intent(this,DuwmPlaceMapActivity.class);break;
      case "TELEVISION":case "PUBLIC CAMERAS":intent=new Intent(this,MediaDeskActivity.class);intent.putExtra("mode",name.equals("TELEVISION")?"TV STATIONS":"PUBLIC CAMERAS");break;
      case "NASA":intent=new Intent(this,RunningballV107EpicActivity.class);break;
      case "MARKETS":case "EMERGENCIES":case "SOURCE INTELLIGENCE":intent=new Intent(this,DuwmWorldIntelligenceActivity.class);break;
      case "AIRCRAFT":case "VESSELS":case "SATELLITES":case "EARTHQUAKES":case "WEATHER":intent=new Intent(this,Duwm1166RecordsActivity.class);intent.putExtra("kind",name);break;
      default:intent=new Intent(this,DuwmWorldIntelligenceActivity.class);
    }startActivity(intent);
  }
}
