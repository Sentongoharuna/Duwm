package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.Locale;

/** 1712: One source-backed operations matrix covering all 19 native desks.
 * This is a full-screen activity, never a second globe or a map overlay.
 * Values are read from existing on-device provider receipts. No synthetic
 * events, counts, fixes, status updates, or source connectivity claims.
 */
public final class Duwm1712OperationsMatrixActivity extends Activity {
    private static final int NAVY=DuwmUnifiedTheme.APPROVED_NAVY;
    private final Duwm1683DeskCatalog.Desk[] desks=Duwm1683DeskCatalog.ALL;
    private LinearLayout cards;
    private TextView summary;
    private String query="";
    private int filter=0;
    private boolean attentionFirst=false;
    // 1713: a real-receipt comparison never invents cross-source agreement.
    private boolean compareMode=false;
    private int leftSector=0;
    private int rightSector=2;
    private Duwm1713ReceiptCoverageView coverageView;
    // 1714: pins refer to existing desk IDs (0..18), never to observations or invented activity.
    // The pinned set is local and persists across sessions without network permissions.
    private static final String WATCH_PREFS = "duwm1714_sector_watchlist";
    private static final String WATCH_MASK = "watched_sector_bitmask";
    private int pinnedMask=0;
    private static final String[] FILTERS={"ALL 19","NEEDS REVIEW","RECENT RECEIPTS","LOCAL TOOLS","WATCHED"};
    private boolean isWatched(int index){ return index>=0&&index<desks.length&&(pinnedMask & (1<<index))!=0; }
    private int watchedCount(){ return Integer.bitCount(pinnedMask); }
    private void setWatched(int index,boolean watch){
        if(index<0||index>=desks.length) return;
        if(watch) pinnedMask |= (1<<index); else pinnedMask &= ~(1<<index);
        getSharedPreferences(WATCH_PREFS, MODE_PRIVATE).edit().putInt(WATCH_MASK,pinnedMask).apply();
        render();
    }
    private void confirmClearWatchlist(){
        new AlertDialog.Builder(this)
            .setTitle("CLEAR WATCHLIST?")
            .setMessage("Unpin the selected sector shortcuts? Stored provider receipts and report data will not be deleted.")
            .setNegativeButton("CANCEL",null)
            .setPositiveButton("UNPIN ALL",(d,w)->{
                pinnedMask=0;
                getSharedPreferences(WATCH_PREFS, MODE_PRIVATE).edit().putInt(WATCH_MASK,0).apply();
                render();
            }).show();
    }

    private int dp(float v){return Math.max(1,Math.round(v*getResources().getDisplayMetrics().density));}
    private TextView text(String s,int sp,int color,boolean bold){
        TextView t=new TextView(this);
        t.setText(s);t.setTextColor(color);t.setTextSize(sp);
        if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setMaxLines(3);t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        return t;
    }
    private TextView button(String caption,Runnable action){
        TextView b=text(caption,10,DuwmUnifiedTheme.TEXT,true);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(46));
        GradientDrawable background=new GradientDrawable();
        background.setColor(DuwmUnifiedTheme.PANEL);
        background.setCornerRadius(dp(DuwmUnifiedTheme.FORMAL_CORNER_DP));
        background.setStroke(dp(1),DuwmUnifiedTheme.BORDER);
        b.setBackground(background);
        b.setOnClickListener(v->action.run());
        b.setContentDescription(caption);
        return b;
    }
    private LinearLayout.LayoutParams below(int top){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.topMargin=dp(top);return p;
    }
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        // Mask off any legacy or malformed values outside the 19 known sectors.
        pinnedMask=getSharedPreferences(WATCH_PREFS,MODE_PRIVATE).getInt(WATCH_MASK,0) & ((1<<19)-1);
        getWindow().setStatusBarColor(NAVY);
        getWindow().setNavigationBarColor(NAVY);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(NAVY);
        root.setPadding(dp(10),dp(9),dp(10),dp(8));
        LinearLayout titleRow=new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=text("DUWM  /  OPERATIONS MATRIX",16,DuwmUnifiedTheme.TEXT,true);
        title.setSingleLine(true);
        titleRow.addView(title,new LinearLayout.LayoutParams(0,dp(48),1f));
        titleRow.addView(button("GLOBE",this::toGlobe),new LinearLayout.LayoutParams(dp(73),dp(46)));
        root.addView(titleRow);
        TextView subtitle=text("19 SECTORS  /  STORED PROVIDER RECEIPTS  /  NO SIMULATED ACTIVITY",
                10,DuwmUnifiedTheme.MUTED,false);
        root.addView(subtitle,below(1));

        EditText search=new EditText(this);
        search.setSingleLine(true);
        search.setHint("Search sector, provider, status or category");
        search.setTextSize(13);
        search.setTextColor(DuwmUnifiedTheme.TEXT);
        search.setHintTextColor(DuwmUnifiedTheme.MUTED);
        search.setPadding(dp(12),0,dp(12),0);
        GradientDrawable field=new GradientDrawable();
        field.setColor(DuwmUnifiedTheme.PANEL);
        field.setCornerRadius(dp(DuwmUnifiedTheme.FORMAL_CORNER_DP));
        field.setStroke(dp(1),DuwmUnifiedTheme.BORDER);
        search.setBackground(field);
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){
                query=s==null?"":s.toString().trim().toLowerCase(Locale.US);render();
            }
            public void afterTextChanged(Editable e){}
        });
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(48));
        sp.topMargin=dp(7);root.addView(search,sp);

        HorizontalScrollView filterScroll=new HorizontalScrollView(this);
        filterScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tabs=new LinearLayout(this);
        tabs.setGravity(Gravity.CENTER_VERTICAL);
        for(int i=0;i<FILTERS.length;i++){
            final int index=i;
            TextView b=button(FILTERS[i],()->{filter=index;render();});
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(i==0?75:132),dp(44));
            p.rightMargin=dp(5);tabs.addView(b,p);
        }
        TextView sort=button("SORT: REVIEW",()->{
            attentionFirst=!attentionFirst;render();
        });
        tabs.addView(sort,new LinearLayout.LayoutParams(dp(130),dp(44)));
        TextView compare=button("COMPARE TWO",()->{
            compareMode=!compareMode;
            render();
        });
        LinearLayout.LayoutParams compareParams=new LinearLayout.LayoutParams(dp(140),dp(44));
        compareParams.leftMargin=dp(5);
        tabs.addView(compare,compareParams);
        TextView clear=button("CLEAR PINS",this::confirmClearWatchlist);
        LinearLayout.LayoutParams clearParams=new LinearLayout.LayoutParams(dp(116),dp(44));
        clearParams.leftMargin=dp(5);
        tabs.addView(clear,clearParams);
        filterScroll.addView(tabs);
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,dp(46));
        fp.topMargin=dp(7);root.addView(filterScroll,fp);

        summary=text("READING ON-DEVICE RECEIPTS",11,DuwmUnifiedTheme.ACCENT_BRIGHT,true);
        summary.setPadding(dp(5),dp(6),dp(5),dp(6));
        root.addView(summary,below(4));
        coverageView=new Duwm1713ReceiptCoverageView(this);
        LinearLayout.LayoutParams coverageParams=new LinearLayout.LayoutParams(-1,dp(19));
        coverageParams.topMargin=dp(2);
        root.addView(coverageView,coverageParams);
        root.addView(text("SOURCE RECEIPTS  •  GREEN RECENT  •  AMBER REVIEW  •  BLUE LOCAL  •  GREY OTHER",
                9,DuwmUnifiedTheme.MUTED,false),below(3));

        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        cards=new LinearLayout(this);
        cards.setOrientation(LinearLayout.VERTICAL);
        cards.setPadding(0,dp(4),0,dp(14));
        scroll.addView(cards);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));
        // Footer is outside scroll and cannot obscure any mapped globe content.
        LinearLayout footer=new LinearLayout(this);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        TextView desksButton=button("19 DESKS",()->startActivity(
                new Intent(this,DuwmOptionsActivity.class)));
        TextView sourcesButton=button("SOURCE HEALTH",()->startActivity(
                new Intent(this,Duwm1671SourceStatusActivity.class)));
        TextView refreshButton=button("REFRESH VIEW",this::render);
        for(TextView b:new TextView[]{desksButton,sourcesButton,refreshButton}){
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(48),1f);
            p.rightMargin=dp(4);footer.addView(b,p);
        }
        root.addView(footer,below(3));
        setContentView(root);
        render();
    }
    private void toGlobe(){
        Intent i=new Intent(this,MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);finish();
    }
    private boolean attention(Duwm1684DeskDiagnostics.Snapshot s){
        String state=s.state.toUpperCase(Locale.US);
        return state.contains("NO RECEIPT")||state.contains("FAILED")||
                state.contains("OFFLINE")||state.contains("DELAY")||
                state.contains("AGED")||state.contains("STALE")||
                state.contains("ERROR")||state.contains("KEY REQUIRED")||
                state.contains("UNAVAILABLE");
    }
    private boolean recent(Duwm1684DeskDiagnostics.Snapshot s){
        String state=s.state.toUpperCase(Locale.US);
        return state.equals("RECENT")||state.equals("LIVE");
    }
    private boolean visible(Duwm1683DeskCatalog.Desk d,Duwm1684DeskDiagnostics.Snapshot s){
        if(filter==1&&!attention(s))return false;
        if(filter==2&&!recent(s))return false;
        if(filter==3&&!s.state.equals("LOCAL TOOL"))return false;
        if(filter==4&&!isWatched(Duwm1709SectorOutline.index(d)))return false;
        if(query.isEmpty())return true;
        String searchable=(d.title+" "+d.category+" "+d.subtitle+" "+s.provider+" "+s.state)
                .toLowerCase(Locale.US);
        return searchable.contains(query);
    }
    private int stateColor(Duwm1684DeskDiagnostics.Snapshot s){
        if(attention(s))return DuwmUnifiedTheme.WARNING;
        if(recent(s))return DuwmUnifiedTheme.LIVE;
        return DuwmUnifiedTheme.MUTED;
    }
    private void render(){
        if(cards==null)return;
        cards.removeAllViews();
        int recent=0,review=0,local=0,shown=0;
        final Duwm1684DeskDiagnostics.Snapshot[] snapshots=new Duwm1684DeskDiagnostics.Snapshot[desks.length];
        for(int i=0;i<desks.length;i++){
            snapshots[i]=Duwm1684DeskDiagnostics.read(this,desks[i]);
            if(recent(snapshots[i]))recent++;
            if(attention(snapshots[i]))review++;
            if("LOCAL TOOL".equals(snapshots[i].state))local++;
        }
        // Coverage segments represent these 19 actual receipt interpretations only.
        // A missing receipt is never rendered as zero aircraft, ships or incidents.
        int[] statuses=new int[desks.length];
        for(int i=0;i<desks.length;i++){
            statuses[i]="LOCAL TOOL".equals(snapshots[i].state)?3:
                    attention(snapshots[i])?2:recent(snapshots[i])?1:0;
        }
        if(coverageView!=null) coverageView.setStatuses(statuses);
        if(compareMode){
            render1713Comparison(snapshots);
            return;
        }
        // Priority ordering only changes presentation, never the underlying records.
        for(int pass=0;pass<(attentionFirst?2:1);pass++){
            for(int i=0;i<desks.length;i++){
                if(attentionFirst&&attention(snapshots[i])!=(pass==0))continue;
                if(!visible(desks[i],snapshots[i]))continue;
                addCard(i,desks[i],snapshots[i]);shown++;
            }
        }
        summary.setText(String.format(Locale.US,
                "19 SECTORS  •  %d RECENT  •  %d REVIEW  •  %d LOCAL  •  %d PINNED  •  %d SHOWN",
                recent,review,local,watchedCount(),shown));
        if(shown==0){
            TextView empty=text(filter==4 ? "NO WATCHED SECTORS. Select PIN on any sector card to keep its shortcut here. Provider receipts are unchanged." :
                    "NO SECTORS MATCH THESE FILTERS. Stored records have not been deleted.",
                    12,DuwmUnifiedTheme.MUTED,false);
            empty.setPadding(dp(14),dp(28),dp(14),dp(28));
            cards.addView(empty,below(6));
        }
    }
    /** 1713: no extra globe, no floating panel; a full-screen two-source inspector. */
    private void pick1713Sector(boolean left){
        String[] labels=new String[desks.length];
        for(int i=0;i<desks.length;i++){
            labels[i]=String.format(Locale.US,"%02d  %s",i+1,desks[i].title);
        }
        new AlertDialog.Builder(this)
                .setTitle(left?"SELECT FIRST SOURCE / SECTOR":"SELECT SECOND SOURCE / SECTOR")
                .setItems(labels,(dialog,which)->{
                    if(left)leftSector=which;else rightSector=which;
                    render();
                })
                .setNegativeButton("CANCEL",null)
                .show();
    }
    private void render1713Comparison(Duwm1684DeskDiagnostics.Snapshot[] snapshots){
        summary.setText("COMPARE TWO  •  SEPARATE STORED PROVIDER RECEIPTS  •  NOT A CORRELATION CLAIM");
        LinearLayout controls=new LinearLayout(this);
        TextView a=button(String.format(Locale.US,"SOURCE A  %02d",leftSector+1),
                ()->pick1713Sector(true));
        TextView b=button(String.format(Locale.US,"SOURCE B  %02d",rightSector+1),
                ()->pick1713Sector(false));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(47),1f);
        lp.rightMargin=dp(5);
        controls.addView(a,lp);
        controls.addView(b,new LinearLayout.LayoutParams(0,dp(47),1f));
        cards.addView(controls,below(5));
        add1713ComparisonCard(leftSector,snapshots[leftSector],"SOURCE A");
        add1713ComparisonCard(rightSector,snapshots[rightSector],"SOURCE B");
        TextView warning=text("COMPARISON USES STORED RECEIPTS ONLY. Different providers, locations, " +
                "observation times and coverage cannot establish that two events are related.",
                10,DuwmUnifiedTheme.MUTED,false);
        warning.setPadding(dp(12),dp(12),dp(12),dp(12));
        warning.setBackground(Duwm1709SectorOutline.card(this,leftSector,DuwmUnifiedTheme.PANEL,false));
        cards.addView(warning,below(8));
        TextView back=button("BACK TO ALL 19 SECTORS",()->{compareMode=false;filter=0;render();});
        cards.addView(back,below(10));
    }
    private void add1713ComparisonCard(int index,Duwm1684DeskDiagnostics.Snapshot snapshot,String label){
        final Duwm1683DeskCatalog.Desk desk=desks[index];
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(13),dp(12),dp(13),dp(12));
        card.setBackground(Duwm1709SectorOutline.card(this,index,DuwmUnifiedTheme.PANEL,false));
        cards.addView(card,below(8));
        card.addView(text(label+"  /  "+String.format(Locale.US,"%02d",index+1)+"  "+
                desk.title.toUpperCase(Locale.US),13,DuwmUnifiedTheme.TEXT,true));
        TextView state=text("STATE  "+snapshot.state+"  •  VALUE  "+snapshot.count,
                12,stateColor(snapshot),true);
        card.addView(state,below(9));
        TextView evidence=text("PROVIDER  "+snapshot.provider+
                "\nLAST LOCAL RECEIPT  "+snapshot.received+
                "\nSOURCE OBSERVATION  "+snapshot.sourceTime+
                "\nCOVERAGE  "+snapshot.coverage+
                "\nLAST ERROR  "+snapshot.error,
                11,DuwmUnifiedTheme.MUTED,false);
        evidence.setMaxLines(Integer.MAX_VALUE);
        card.addView(evidence,below(8));
        LinearLayout buttons=new LinearLayout(this);
        TextView receipt=button("FULL RECEIPT",()->new AlertDialog.Builder(this)
                .setTitle(desk.title+" / SOURCE RECEIPT")
                .setMessage(snapshot.report()).setPositiveButton("CLOSE",null).show());
        TextView open=button("OPEN DESK",()->startActivity(Duwm1683DeskCatalog.intent(this,desk)));
        LinearLayout.LayoutParams first=new LinearLayout.LayoutParams(0,dp(46),1f);
        first.rightMargin=dp(5);
        buttons.addView(receipt,first);
        buttons.addView(open,new LinearLayout.LayoutParams(0,dp(46),1f));
        card.addView(buttons,below(10));
    }
    private void addCard(int index,Duwm1683DeskCatalog.Desk d,
                         Duwm1684DeskDiagnostics.Snapshot s){
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(11),dp(10),dp(11),dp(10));
        card.setBackground(Duwm1709SectorOutline.card(this,index,DuwmUnifiedTheme.PANEL,false));
        LinearLayout.LayoutParams cp=below(7);cards.addView(card,cp);
        TextView title=text(String.format(Locale.US,"%02d  %s",index+1,d.title.toUpperCase(Locale.US)),
                13,DuwmUnifiedTheme.TEXT,true);
        card.addView(title);
        TextView watchState=text(isWatched(index)?"PINNED FOR REVIEW  •  STORED LOCALLY":
                "NOT PINNED  •  WATCHLIST SHORTCUT OPTIONAL",9,
                isWatched(index)?DuwmUnifiedTheme.ACCENT_BRIGHT:DuwmUnifiedTheme.MUTED,false);
        card.addView(watchState,below(3));
        TextView state=text(s.state.toUpperCase(Locale.US)+"  •  "+s.count,
                11,stateColor(s),true);
        card.addView(state,below(5));
        TextView provider=text("PROVIDER  "+s.provider+"\nLAST RECEIPT  "+s.received,
                10,DuwmUnifiedTheme.MUTED,false);
        provider.setMaxLines(4);
        card.addView(provider,below(4));
        LinearLayout buttons=new LinearLayout(this);
        TextView open=button("OPEN DESK",()->startActivity(Duwm1683DeskCatalog.intent(this,d)));
        TextView details=button("SOURCE RECEIPT",()->new AlertDialog.Builder(this)
                .setTitle(d.title+" / SOURCE DETAILS")
                .setMessage(s.report())
                .setPositiveButton("OPEN DESK",(dialog,which)->startActivity(
                        Duwm1683DeskCatalog.intent(this,d)))
                .setNegativeButton("CLOSE",null).show());
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(44),1f);
        ap.rightMargin=dp(6);buttons.addView(open,ap);
        buttons.addView(details,new LinearLayout.LayoutParams(0,dp(44),1.3f));
        card.addView(buttons,below(8));
        // Separate docked row inside the card, not an overlay on a map or source.
        TextView pin=button(isWatched(index)?"UNPIN SECTOR":"PIN TO WATCHLIST",
                ()->setWatched(index,!isWatched(index)));
        card.addView(pin,below(5));
    }
    @Override protected void onResume(){super.onResume();render();}
}
