package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import org.json.JSONArray;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** 1671 worldwide command home: a real, rotating Globe + category-specific source instruments. */
public final class Duwm1671MissionActivity extends Activity {
  private static final int BG=0xFF050D22,WHITE=0xFFE4EDFE,AQUA=0xFF558BDF,MUTED=0xFF4C78C4,AMBER=0xFF558BDF;
  private static final String[] SECTORS={"AIRCRAFT","VESSELS","NEWS","MARKETS","WEATHER","EARTHQUAKES","SATELLITES","TV STATIONS","PUBLIC CAMERAS","RADIO"};
  private final Handler handler=new Handler(Looper.getMainLooper());private boolean foreground;
  private final Runnable tick=new Runnable(){@Override public void run(){if(!foreground)return;refresh();handler.postDelayed(this,24000L);}};
  private int selected=0;private String lastObservationKey="";private Duwm1670HomeTelemetryView strip;private OperationsGlobeView globe;private Duwm1670WorldMapView sectorMap;
  private Duwm1671TrendView sectorTrend;private Duwm1671EventBars sectorEvents;
  private TextView headline,provider,metric,description,clock;
  private int dp(float x){return Math.round(x*getResources().getDisplayMetrics().density);}
  private TextView text(String v,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(v);t.setTextColor(color);t.setTextSize(size);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  private GradientDrawable border(){GradientDrawable d=new GradientDrawable();d.setColor(0xFF112549);d.setCornerRadius(dp(10));d.setStroke(dp(1),0xFF426CAF);return d;}
  private TextView button(String s,Runnable fn){TextView t=text(s,12,AQUA,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(7),dp(11),dp(7),dp(11));t.setBackground(border());t.setOnClickListener(v->fn.run());return t;}
  private static String time(long ms){if(ms<=0)return "NO PROVIDER TIME";SimpleDateFormat f=new SimpleDateFormat("dd MMM HH:mm 'UTC'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(ms));}
  private void row(LinearLayout root,String a,Runnable aRun,String b,Runnable bRun){LinearLayout r=new LinearLayout(this);
    LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(7);root.addView(r,rp);
    r.addView(button(a,aRun),new LinearLayout.LayoutParams(0,dp(48),1));TextView second=button(b,bRun);
    LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(48),1);sp.leftMargin=dp(6);r.addView(second,sp);}
  @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    ScrollView sc=new ScrollView(this);sc.setBackgroundColor(BG);setContentView(sc);Duwm1167SafeArea.install(this,sc);
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(12),dp(12),dp(12),dp(30));sc.addView(root);
    root.addView(text("DEVELOP.UGANDA    /    GLOBAL MISSION CONTROL",12,AQUA,true));
    root.addView(text("WORLD SITUATION ROOM 1673",24,WHITE,true));
    clock=text("UTC  /  SOURCE CLOCK",11,MUTED,false);root.addView(clock);
    root.addView(text("One original Earth globe, ten independently identified intelligence desks and measured source status.",11,MUTED,false));
    strip=new Duwm1670HomeTelemetryView(this);LinearLayout.LayoutParams rib=new LinearLayout.LayoutParams(-1,dp(72));rib.topMargin=dp(9);root.addView(strip,rib);
    globe=new OperationsGlobeView(this);LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,dp(300));gp.topMargin=dp(10);root.addView(globe,gp);
    row(root,"DETAILED ORIGINAL GLOBE",()->startActivity(new Intent(this,OperationsMainActivity.class)),"PROVIDER HEALTH",()->startActivity(new Intent(this,Duwm1671SourceStatusActivity.class)));
    row(root,"REQUEST AIRCRAFT UPDATE",()->{
      provider.setText("REQUESTING FRESH OPEN SKY DATA / CHECKING PROVIDER RULES");
      RunningballV25GlobalAircraftData.refreshNow(this,()->{if(foreground)refresh();});
    },"PUBLIC AIS / NO KEY",()->startActivity(new Intent(this,GevMarineActivity.class)));
    root.addView(text("WORLD DATA FILTER  /  SELECT ONE DESK",12,AMBER,true));
    Spinner sector=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,SECTORS);
    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);sector.setAdapter(adapter);sector.setBackground(border());root.addView(sector,new LinearLayout.LayoutParams(-1,dp(50)));
    sector.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){@Override public void onItemSelected(AdapterView<?> p,View v,int n,long id){selected=n;refresh();}@Override public void onNothingSelected(AdapterView<?> p){}});
    headline=text("AIRCRAFT INTELLIGENCE",19,WHITE,true);headline.setPadding(0,dp(12),0,dp(5));root.addView(headline);
    metric=text("NO SOURCE RECEIPT",17,AQUA,true);root.addView(metric);
    provider=text("CHECKING PROVIDER",11,AMBER,false);root.addView(provider);
    sectorMap=new Duwm1670WorldMapView(this);sectorMap.setOnPinSelected(pin->{description.setText(pin.title+"  /  "+pin.detail+"\nREPORTED "+time(pin.observed));});
    LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(230));mp.topMargin=dp(8);root.addView(sectorMap,mp);
    sectorTrend=new Duwm1671TrendView(this);root.addView(sectorTrend,new LinearLayout.LayoutParams(-1,dp(200)));
    sectorEvents=new Duwm1671EventBars(this);root.addView(sectorEvents,new LinearLayout.LayoutParams(-1,dp(150)));
    description=text("DATA AND VISUALS ARE LINKED TO ACTUAL RECEIPTS",11,MUTED,false);description.setPadding(dp(12),dp(12),dp(12),dp(12));description.setBackground(border());root.addView(description);
    row(root,"OPEN SELECTED SPECIALIST PAGE",this::openSpecialist,"RECEIVED SOURCE DETAILS",()->startActivity(new Intent(this,Duwm1671SourceStatusActivity.class)));
    row(root,"AIRCRAFT / FLIGHT MAP",()->openSector(0),"VESSELS / AIS MAP",()->openSector(1));
    row(root,"WORLD NEWS / COUNTRY ATLAS",()->openSector(2),"MARKETS / FX CHART",()->openSector(3));
    row(root,"WEATHER / FORECAST",()->openSector(4),"EARTHQUAKE EVENTS",()->openSector(5));
    row(root,"SATELLITE / ORBITS",()->openSector(6),"IN-APP LIVE TV",()->openSector(7));
    row(root,"PUBLIC STREET CAMERAS",()->openSector(8),"WORLD RADIO",()->openSector(9));
    root.addView(text("GLOBE MOTION = VISUAL ORIENTATION. RECEIVED POSITIONS MOVE ONLY BETWEEN ACTUAL REPORTS. COUNTERS, MEDIA, QUOTES AND EVENT TIMES ARE FROM SAVED SOURCES, WITH STALE STATES VISIBLE.",10,MUTED,false));
    refresh();
  }
  private void openSector(int n){Intent i=new Intent(this,Duwm1671SectorActivity.class);i.putExtra(Duwm1671SectorActivity.EXTRA_KIND,SECTORS[n]);startActivity(i);}
  private void openSpecialist(){openSector(selected);}
  private void refresh(){if(strip==null||globe==null||sectorMap==null)return;strip.update();
    clock.setText("UTC "+time(System.currentTimeMillis())+"   /   CONTENT SHOWS SOURCE RECEIPT TIME");
    List<OperationsGlobeView.Observation> earth=new ArrayList<>();RunningballV25GlobalAircraftData.Snapshot planes=RunningballV25GlobalAircraftData.read(this);
    if(planes.hasGood()&&planes.ageMs()<21600000L)for(int i=0;i<planes.points.length()&&earth.size()<160;i+=Math.max(1,planes.points.length()/160)){
      JSONArray row=planes.points.optJSONArray(i);if(row==null)continue;double lat=row.optDouble(0,Double.NaN),lon=row.optDouble(1,Double.NaN);
      if(Double.isFinite(lat)&&Double.isFinite(lon))earth.add(new OperationsGlobeView.Observation(OperationsGlobeView.AIR,lat,lon,row.optString(3,row.optString(2)),"OpenSky reported aircraft position","OpenSky",row.optLong(7)*1000L));
    }
    for(DuwmGeoObservationStore.Fix f:DuwmGeoObservationStore.read(this)){
      if("EARTHQUAKE".equals(f.type))earth.add(new OperationsGlobeView.Observation(OperationsGlobeView.QUAKE,f.lat,f.lon,f.title,f.detail,f.provider,f.sourceTime));
      if("ISS".equals(f.type))earth.add(new OperationsGlobeView.Observation(OperationsGlobeView.SPACE,f.lat,f.lon,f.title,f.detail,f.provider,f.sourceTime));
    }
    globe.setObservations(earth);
    String kind=SECTORS[selected];headline.setText(kind+" / SOURCE OPERATIONS");sectorMap.setVisibility(View.GONE);sectorTrend.setVisibility(View.GONE);sectorEvents.setVisibility(View.GONE);
    if(selected==0){metric.setText(planes.countLabel()+" PROVIDER REPORTS / "+planes.displayRows+" SAMPLED POSITIONS");
      provider.setText("OPENSKY  /  "+planes.status()+"  /  SOURCE "+time(planes.sourceAt)+"  /  NEXT "+planes.nextCheckLabel());
      description.setText("Track aircraft through real two-fix motion, speed, altitude and course on the full Flight Map. Airline ETA requires authorized schedule data.");
      sectorMap.setVisibility(View.VISIBLE);sectorMap.setLayer("AIRCRAFT");ArrayList<Duwm1670WorldMapView.Pin> pins=new ArrayList<>();
      if(planes.hasGood()&&planes.ageMs()<21600000L)for(int i=0;i<planes.points.length()&&pins.size()<1000;i++){
        JSONArray row=planes.points.optJSONArray(i);if(row==null)continue;double lat=row.optDouble(0,Double.NaN),lon=row.optDouble(1,Double.NaN);
        if(!Double.isFinite(lat)||!Double.isFinite(lon))continue;
        Duwm1670WorldMapView.Pin pin=new Duwm1670WorldMapView.Pin(row.optString(2),row.optString(3,"AIRCRAFT"),"AIRCRAFT",lat,lon,row.optLong(7)*1000L,"Position from OpenSky");
        if(!row.isNull(6))pin.heading=row.optDouble(6,Double.NaN);pins.add(pin);
      }sectorMap.setPins(pins,false);
    }else if(selected==1||selected==5||selected==6){int id=selected==1?2:selected==5?3:1;
      RunningballV25Sources.Result r=RunningballV25Sources.read(this,id);String type=selected==1?"VESSEL":selected==5?"EARTHQUAKE":"ISS";
      ArrayList<Duwm1670WorldMapView.Pin> markers=new ArrayList<>();ArrayList<DuwmGeoObservationStore.Fix> events=new ArrayList<>();
      for(DuwmGeoObservationStore.Fix f:DuwmGeoObservationStore.read(this))if(type.equals(f.type)||"VESSEL".equals(type)&&"VESSELS".equals(f.type)){
        Duwm1670WorldMapView.Pin p=new Duwm1670WorldMapView.Pin(f.id,f.title,type,f.lat,f.lon,f.sourceTime,f.detail+" / "+f.provider);
        if(f.hasActualTrack()){p.prevLat=f.oldLat;p.prevLon=f.oldLon;p.prevObserved=f.oldTime;}markers.add(p);events.add(f);
      }
      metric.setText(markers.size()+" CACHED MAP FIXES / "+r.value+" PROVIDER COUNT");provider.setText(r.provider+" / "+r.display());
      long lastObserved=0L;for(DuwmGeoObservationStore.Fix f:events)lastObserved=Math.max(lastObserved,f.sourceTime);
      String latestKey=kind+":"+lastObserved+":"+markers.size();boolean newSource=!latestKey.equals(lastObservationKey);lastObservationKey=latestKey;
      sectorMap.setLayer(kind);sectorMap.setPins(markers,newSource);sectorMap.setVisibility(View.VISIBLE);
      if(selected==5){sectorEvents.setVisibility(View.VISIBLE);sectorEvents.setEvents(events,System.currentTimeMillis());}
      description.setText(selected==1?"AIS positions only where a provider is configured and observations exist. A ship without two reports has no fabricated moving track.":
        selected==6?"ISS observation markers are separate from CelesTrak orbital propagation estimates. Open the satellite desk for orbital computations.":"USGS event pins, source time and 24-hour time bins, drawn only from received earthquake events.");
    }else if(selected==3||selected==4){int id=selected==3?7:6;RunningballV25Sources.Result r=RunningballV25Sources.read(this,id);
      Duwm1671Measurements.capture(this,id);metric.setText(r.value);provider.setText(r.provider+" / "+r.display());
      sectorTrend.setVisibility(View.VISIBLE);sectorTrend.setData(selected==3?"USD/EUR REFERENCE RATE":"TEMPERATURE / SELECTED REGION",selected==3?"USD/EUR":"°C",Duwm1671Measurements.history(this,id));
      description.setText("Real value: "+r.value+" / "+r.coverage+". The graph only joins distinct values saved from successful source receipts.");
    }else if(selected==2){List<NewsItem> stories=new NewsStore(this).load();metric.setText(stories.size()+" SAVED ARTICLES");
      RunningballV25Sources.Result r=RunningballV25Sources.read(this,5);provider.setText(r.provider+" / "+r.display());
      description.setText("Use News Atlas to filter 50 Africa, 50 conflict, 50 Western and 50 ISS/space publisher candidates. Publisher-map locations are country references, not event coordinates. Real articles are distinguished from the directory.");
    }else{metric.setText("MEDIA DIRECTORY / ON-DEMAND PLAYER");provider.setText("STREAM OR CAMERA CONNECTION TESTED WHEN SELECTED");
      description.setText("Open native media desk for real stream playback, country selection or camera snapshots. Do not mark an inaccessible channel LIVE.");}
  }
  @Override protected void onResume(){super.onResume();foreground=true;if(globe!=null)globe.resume();if(strip!=null)strip.resume();if(sectorTrend!=null)sectorTrend.start();if(sectorMap!=null)sectorMap.resume();handler.removeCallbacks(tick);handler.post(tick);RunningballV25GlobalAircraftData.refresh(this,()->{if(foreground)refresh();});}
  @Override protected void onPause(){foreground=false;handler.removeCallbacks(tick);if(globe!=null)globe.pause();if(strip!=null)strip.pause();if(sectorTrend!=null)sectorTrend.stop();if(sectorMap!=null)sectorMap.pause();super.onPause();}
}
