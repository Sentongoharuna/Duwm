package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.text.TextUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import android.widget.LinearLayout;
import android.widget.TextView;
/** Native Stage 2 entry with every completed stage and source board clearly visible. */
public final class RunningballV25Stage2Panel extends LinearLayout {
  private static final int INK=0xFFE0EAFE,CYAN=0xFF558BDF,GREEN=0xFF558BDF,AMBER=0xFF558BDF,MUTED=0xFF7799C3;
  private final TextView[] figures=new TextView[9],health=new TextView[9];
  private final TextView activity,ticker,overview,newsTicker,v9Pulse;
  private TextView globalAirHealth;
  private long lastNewsRequest=0L;
  private final Handler main=new Handler(Looper.getMainLooper());private boolean active=false;
  private final Runnable tick=new Runnable(){public void run(){if(!active)return;RunningballV25GlobalAircraftData.refresh(getContext(),null);render();main.postDelayed(this,10000L);}};
  private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
  private TextView text(String s,int size,int color,boolean bold){TextView v=new TextView(getContext());v.setText(s);v.setTextSize(size);v.setTextColor(color);if(bold)v.setTypeface(null,1);return v;}
  private GradientDrawable panel(int border){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFF112549,0xFF050D22});d.setCornerRadius(dp(13));d.setStroke(dp(1),border);return d;}
  private void launch(Class<?> cl){getContext().startActivity(new Intent(getContext(),cl));}
  private void board(int index){Intent i=new Intent(getContext(),RunningballV25Stage2BoardActivity.class);i.putExtra("board",index);getContext().startActivity(i);}
  public RunningballV25Stage2Panel(Context c){super(c);setOrientation(VERTICAL);setPadding(dp(11),dp(12),dp(11),dp(13));setBackground(panel(CYAN));
    TextView heading=text("V25 / STAGE ACCESS · ALL WORKING MODULES",13,GREEN,true);addView(heading);
    overview=text("LOADING SOURCE-VERIFIED COUNTERS",12,INK,false);overview.setPadding(0,dp(7),0,dp(10));addView(overview);
    addView(new RunningballV105QuickRail(c),new LayoutParams(-1,-2));
    TextView stage1=text("STAGE 1  ·  WORLDWIDE CORE / OPEN SOURCE HEALTH  ›",12,GREEN,true);
    stage1.setPadding(dp(8),dp(12),dp(8),dp(12));stage1.setMinHeight(dp(48));stage1.setBackground(panel(GREEN));stage1.setContentDescription("Open completed Stage 1 source health");stage1.setOnClickListener(v->launch(RunningballV25SourceHealthActivity.class));addView(stage1);
    TextView stage2=text("STAGE 2  ·  LIVE INTELLIGENCE BOARD INDEX  ↓",12,CYAN,true);stage2.setPadding(dp(7),dp(11),dp(7),dp(7));addView(stage2);
    TextView stage3=text("STAGE 3  ·  INFORMATION WALLPAPER  ›",12,CYAN,true);
    stage3.setMinimumHeight(dp(52));stage3.setPadding(dp(10),dp(12),dp(10),dp(12));
    stage3.setBackground(panel(CYAN));
    stage3.setOnClickListener(v->launch(RunningballV25IntelligenceSettingsActivity.class));
    stage3.setContentDescription("Open Stage 3 information wallpaper settings and Android wallpaper picker");
    addView(stage3);
    TextView worldAir=text("WORLDWIDE AIRCRAFT  /  OPEN SKY GLOBAL  ›",14,GREEN,true);
    worldAir.setMinimumHeight(dp(58));worldAir.setPadding(dp(11),dp(15),dp(11),dp(15));
    worldAir.setBackground(panel(GREEN));
    worldAir.setContentDescription("Open global aircraft map and original world globe");
    worldAir.setOnClickListener(v->launch(RunningballV25WorldwideAirActivity.class));
    addView(worldAir);
    globalAirHealth=text("GLOBAL AIR / AWAITING VERIFIED RESPONSE",11,AMBER,false);
    globalAirHealth.setContentDescription("Worldwide OpenSky provider status and received aircraft count");
    addView(globalAirHealth);
    addView(text("STAGE 4 · VALIDATED SGP4 — NOT BUILT",10,MUTED,false));
    addView(text("STAGE 5 · OPTIONAL EXPANDED SOURCES — NOT APPROVED",10,MUTED,false));
    TextView ugNews=text("UGANDA NEWS  ›  LOCAL PUBLISHER HEADLINES",12,GREEN,true);
    ugNews.setMinimumHeight(dp(48));ugNews.setPadding(dp(11),dp(13),dp(11),dp(13));ugNews.setBackground(panel(GREEN));
    ugNews.setOnClickListener(v->{Intent i=new Intent(getContext(),RunningballV25NewsMonitorActivity.class);i.putExtra("desk","UGANDA");getContext().startActivity(i);});
    ugNews.setContentDescription("Open Uganda publisher news monitor");addView(ugNews);
    TextView conflicts=text("WORLD CONFLICTS  ›  MIDDLE EAST + GLOBAL REPORTS",12,AMBER,true);
    conflicts.setMinimumHeight(dp(48));conflicts.setPadding(dp(11),dp(13),dp(11),dp(13));conflicts.setBackground(panel(AMBER));
    conflicts.setOnClickListener(v->{Intent i=new Intent(getContext(),RunningballV25NewsMonitorActivity.class);i.putExtra("desk","MIDDLE EAST");getContext().startActivity(i);});
    conflicts.setContentDescription("Open Middle East and worldwide conflict headlines");addView(conflicts);
    TextView newsroom=text("V9 / LIVE NEWSROOM  ›  UGANDA · MIDDLE EAST · WORLD",12,GREEN,true);
    newsroom.setMinimumHeight(dp(48));newsroom.setPadding(dp(11),dp(12),dp(11),dp(12));newsroom.setBackground(panel(GREEN));
    newsroom.setOnClickListener(v->launch(RunningballV25NewsroomActivity.class));
    newsroom.setContentDescription("Open live Uganda and global newsroom with received reports");addView(newsroom);
    v9Pulse=text("NEWSROOM: AWAITING RECEIVED ARTICLES",11,CYAN,false);
    v9Pulse.setPadding(dp(9),dp(10),dp(9),dp(10));v9Pulse.setBackground(panel(0xFF284C87));
    v9Pulse.setOnClickListener(v->launch(RunningballV25NewsroomActivity.class));
    v9Pulse.setContentDescription("Open consolidated latest news and source health");addView(v9Pulse);
    RunningballV25WorldBrief worldBrief=new RunningballV25WorldBrief(c);
    LayoutParams worldLp=new LayoutParams(-1,-2);worldLp.topMargin=dp(9);addView(worldBrief,worldLp);
    addView(text("Tap each board for source age, actual value, trend, updates and a native detail route.",10,MUTED,false));
    newsTicker=text("WORLD NEWS · AWAITING REAL HEADLINES",11,CYAN,true);
    newsTicker.setSingleLine(true);newsTicker.setEllipsize(TextUtils.TruncateAt.MARQUEE);
    newsTicker.setMarqueeRepeatLimit(-1);newsTicker.setMinHeight(dp(48));
    newsTicker.setPadding(dp(8),dp(12),dp(8),dp(12));newsTicker.setBackground(panel(CYAN));
    newsTicker.setOnClickListener(v->board(5));newsTicker.setContentDescription("Open latest publisher-linked world news");
    LayoutParams newsLp=new LayoutParams(-1,-2);newsLp.topMargin=dp(9);addView(newsTicker,newsLp);
    boolean columns=getResources().getConfiguration().screenWidthDp>=400 && getResources().getConfiguration().fontScale<=1.25f;
    LinearLayout currentRow=null;
    for(int i=0;i<9;i++){
      if(columns && i%2==0 && i!=8){currentRow=new LinearLayout(c);currentRow.setOrientation(HORIZONTAL);
        LayoutParams rp=new LayoutParams(-1,-2);rp.topMargin=dp(7);addView(currentRow,rp);}
      final int index=i;LinearLayout item=new LinearLayout(c);item.setOrientation(VERTICAL);item.setPadding(dp(11),dp(10),dp(11),dp(9));item.setBackground(panel(0xFF284C87));
      TextView name=text(RunningballV25Sources.NAMES[i]+"    ›",12,CYAN,true);item.addView(name);
      figures[i]=text("--",columns?19:22,INK,true);item.addView(figures[i]);
      health[i]=text("AWAITING REPORT",10,AMBER,false);item.addView(health[i]);
      item.setMinimumHeight(dp(70));item.setContentDescription("Open "+RunningballV25Sources.NAMES[i]+" verified board");item.setOnClickListener(v->board(index));
      if(columns){LayoutParams cp=i==8?new LayoutParams(-1,-2):new LayoutParams(0,-2,1);
        cp.leftMargin=(i%2==1)?dp(4):0;cp.rightMargin=(i%2==0&&i!=8)?dp(4):0;
        if(i==8){LayoutParams lastLp=new LayoutParams(-1,-2);lastLp.topMargin=dp(7);addView(item,lastLp);}
        else currentRow.addView(item,cp);
      }else{LayoutParams lp=new LayoutParams(-1,-2);lp.topMargin=dp(7);addView(item,lp);}
    }
    ticker=text("SOURCE ACTIVITY / NO VERIFIED CHANGE RECORDED",11,GREEN,false);ticker.setPadding(dp(7),dp(12),dp(7),dp(12));ticker.setBackground(panel(GREEN));
    LayoutParams tp=new LayoutParams(-1,-2);tp.topMargin=dp(10);addView(ticker,tp);
    ticker.setMinHeight(dp(48));ticker.setOnClickListener(v->launch(RunningballV25SourceHealthActivity.class));ticker.setContentDescription("Open Source Health and latest source changes");
    activity=text("SOURCE CHANGE LEDGER / AWAITING RECEIVED REPORTS",11,INK,false);activity.setPadding(0,dp(8),0,dp(10));addView(activity);
    render();
  }
  public void render(){
    RunningballV25GlobalAircraftData.Snapshot global=RunningballV25GlobalAircraftData.read(getContext());
    globalAirHealth.setText("GLOBAL AIRCRAFT / "+global.countLabel()+" OPENSKY RECORDS · "+global.status()+
      "\nSOURCE AGE "+global.providerAgeLabel()+" · NEXT POLL "+global.nextCheckLabel()+
      " · NETWORK COVERAGE, NOT ALL WORLD AIRCRAFT");
    globalAirHealth.setTextColor(global.hasGood()&&global.ageMs()<900000L?GREEN:AMBER);
    int live=0;for(int i=0;i<9;i++){
      RunningballV25Sources.Result v=RunningballV25Sources.read(getContext(),i);
      if(v.status==RunningballV25Sources.Status.LIVE)live++;
      RunningballV25Stage2History.update(getContext(),i);
      figures[i].setText(v.value);
      boolean ok=v.status==RunningballV25Sources.Status.LIVE;
      health[i].setText((i==7?"DAILY REFERENCE · FETCHED "+v.age():v.display())+" · "+v.provider+"\n"+v.coverage);
      health[i].setTextColor(ok?GREEN:AMBER);
    }
    overview.setText(live+" / 9 RECENT SOURCE CACHES  ·  NO SYNTHETIC COUNTS");
    RunningballV25Sources.Result news=RunningballV25Sources.read(getContext(),5);
    String headline="WORLD NEWS · NO VERIFIED HEADLINES";
    boolean verified=false;
    if(news.fetchedAt>0 && news.status!=RunningballV25Sources.Status.NO_DATA_FOR_REGION){
      try{JSONObject cache=new JSONObject(getContext().getSharedPreferences("rb17_verified_feeds",Context.MODE_PRIVATE).getString("news_json","{}"));
        JSONArray articles=cache.optJSONArray("articles");
        JSONObject first=articles!=null&&articles.length()>0?articles.optJSONObject(0):null;
        String title=first==null?"":first.optString("title","").trim();
        if(!title.isEmpty()){
          headline="NEWS · "+title+"  •  "+cache.optString("provider",news.provider)+"  •  FETCH AGE "+news.age();verified=true;
        }
      }catch(Exception ignored){}
    }
    newsTicker.setText(headline);newsTicker.setSelected(active&&verified&&!getContext().getSharedPreferences("rb25_visual_preferences",Context.MODE_PRIVATE).getBoolean("reduce_motion",false));
    int receivedNews=0,failedNews=0;String firstNews="";
    for(String key:RunningballV25NewsRepository.KEYS){
      if(RunningballV25NewsRepository.last(getContext(),key)>0)receivedNews++;
      if(!RunningballV25NewsRepository.error(getContext(),key).isEmpty())failedNews++;
      if(firstNews.isEmpty()){
        JSONArray rows=RunningballV25NewsRepository.articles(getContext(),key);
        JSONObject row=rows.length()>0?rows.optJSONObject(0):null;
        if(row!=null)firstNews=row.optString("title","").trim();
      }
    }
    v9Pulse.setText("V9 / NEWSROOM  ·  "+receivedNews+"/6 RECEIVED FEEDS"+
      (failedNews>0?"  ·  "+failedNews+" FETCH ERRORS":"")+"\n"+
      (firstNews.isEmpty()?"NO PUBLISHER HEADLINES RECEIVED · TAP FOR SOURCE HEALTH":
       "PUBLISHER REPORT: "+firstNews));
    RunningballV25ChangeLedger.update(getContext());String s=RunningballV25ChangeLedger.summary(getContext());
    ticker.setText(s.equals("NO VERIFIED CHANGES RECORDED")?"SOURCE ACTIVITY · NO VERIFIED UPDATES":"LATEST VERIFIED UPDATE  ›  "+s.split("\\n")[0]);
    activity.setText("SOURCE CHANGE LEDGER (RECEIVED VALUES ONLY)\n"+s);
  }
  @Override protected void onAttachedToWindow(){super.onAttachedToWindow();active=true;main.removeCallbacks(tick);main.post(tick);
    RunningballV25GlobalAircraftData.refresh(getContext(),()->{if(active)render();});
    long now=System.currentTimeMillis();if(now-lastNewsRequest>60000L){lastNewsRequest=now;
      RunningballV25NewsRepository.refresh(getContext(),false,()->{if(active)render();});}
  }
  @Override protected void onDetachedFromWindow(){active=false;newsTicker.setSelected(false);main.removeCallbacks(tick);super.onDetachedFromWindow();}
}
