package com.sentongoharuna.worldsituationroom;
import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.content.Context;
import org.json.*;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Users may add public RSS/Atom/JSON feed URLs; reports actual parse and fetch states. */
public final class Duwm1166CustomFeedActivity extends Activity {
 private TextView state;private EditText input;private static final int BG=0xFF050D22;
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);
  LinearLayout main=new LinearLayout(this);main.setBackgroundColor(BG);main.setOrientation(LinearLayout.VERTICAL);main.setPadding(24,32,24,24);setContentView(main);Duwm1167SafeArea.install(this,main);
  TextView heading=new TextView(this);heading.setText("ADD PUBLIC NEWS FEED");heading.setTextSize(22);heading.setTextColor(-1);main.addView(heading);
  TextView explanation=new TextView(this);explanation.setText("Enter an HTTPS RSS, Atom or JSON Feed URL. Public websites without a feed may not be readable. Publishers retain attribution.");explanation.setTextColor(0xFFC0CED1);main.addView(explanation);
  input=new EditText(this);input.setSingleLine(true);input.setTextColor(-1);input.setHint("https://publisher.example/feed.xml");input.setHintTextColor(0xFF4C78C4);main.addView(input);
  Button add=new Button(this);add.setText("IMPORT REAL SOURCE ARTICLES");main.addView(add);state=new TextView(this);state.setTextColor(0xFF558BDF);main.addView(state);
  add.setOnClickListener(v->fetch(input.getText().toString().trim()));
 }
 private boolean safe(String url){try{URL u=new URL(url);if(!"https".equalsIgnoreCase(u.getProtocol()))return false;
   String h=u.getHost().toLowerCase(Locale.US);return !h.isEmpty()&&!h.equals("localhost")&&!h.endsWith(".local")&&!h.endsWith(".internal")&&!h.startsWith("127.")&&!h.startsWith("10.")&&!h.startsWith("192.168.")&&!h.equals("0.0.0.0");
  }catch(Exception e){return false;}}
 private void fetch(String endpoint){if(!safe(endpoint)){state.setText("Enter a public HTTPS RSS/Atom/JSON feed URL");return;}
  state.setText("Contacting publisher. No received stories yet.");
  new Thread(()->{int count=0;String message;HttpURLConnection c=null;
   try{c=(HttpURLConnection)new URL(endpoint).openConnection();c.setConnectTimeout(8500);c.setReadTimeout(12000);
    c.setRequestProperty("User-Agent","DEVELOP.UGANDA/1166 news reader");int status=c.getResponseCode();if(status!=200)throw new IOException("HTTP "+status);
    ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[]b=new byte[8192];int n;while((n=in.read(b))!=-1){if(out.size()+n>2*1024*1024)throw new IOException("Feed exceeds 2 MB");out.write(b,0,n);}}
    String xml=new String(out.toByteArray(),StandardCharsets.UTF_8);List<RssParser.Item> rows;
    if(xml.trim().startsWith("{"))rows=NewsReaders.jsonFeed(xml);else rows=RssParser.parse(xml);
    ArrayList<NewsItem> all=new NewsStore(this).load();HashSet<String> known=new HashSet<>();for(NewsItem i:all)known.add(i.id);
    long now=System.currentTimeMillis();String host=new URL(endpoint).getHost();for(RssParser.Item row:rows){
       String link=RssParser.cleanLink(row.link);if(!safe(link))continue;NewsItem n=new NewsItem();n.title=row.title;n.summary=row.description;
       n.link=link;n.imageUrl=row.imageUrl;n.sourceId="custom:"+host;n.sourceName=row.sourceName.isEmpty()?host:row.sourceName;
       n.region="GLOBAL";n.topic="NEWS";n.language="EN";n.id=NewsItem.idFor(link);n.publishedAt=row.timestampMs;n.firstSeenAt=now;
       if(known.add(n.id)){all.add(n);count++;}
    }
    new NewsStore(this).save(all);getSharedPreferences("duwm1166_custom",MODE_PRIVATE).edit().putString("last_feed",endpoint).putLong("last_success",now).apply();
    message="RECEIVED: "+rows.size()+" articles  •  NEW: "+count+"  •  SOURCE "+host;
   }catch(Exception e){message="Feed unavailable: "+e.getClass().getSimpleName()+"  •  No synthetic headlines added";}
   finally{if(c!=null)c.disconnect();}
   String result=message;runOnUiThread(()->state.setText(result));
  },"duwm1166-custom-rss").start();
 }
}
