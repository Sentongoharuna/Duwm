package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
/** V105 UI01. Independent native shortcuts to EXISTING source-backed screens. */
public final class RunningballV105QuickRail extends LinearLayout {
  private static final int CYAN=0xFF558BDF, GREEN=0xFF558BDF, WHITE=0xFFE0EAFE;
  private int dp(int value){return Math.round(getResources().getDisplayMetrics().density*value);}
  private GradientDrawable plate(int border){
    GradientDrawable shape=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
      new int[]{0xFF12294A,0xFF050D22});
    shape.setCornerRadius(dp(16));shape.setStroke(dp(1),border);return shape;
  }
  private TextView action(Context c,String title,String description,int tint,Class<?> destination){
    TextView button=new TextView(c);button.setText(title);button.setTextSize(12);
    button.setTextColor(WHITE);button.setTypeface(null,1);button.setGravity(Gravity.CENTER);
    button.setMinHeight(dp(52));button.setPadding(dp(5),dp(8),dp(5),dp(8));
    button.setBackground(plate(tint));button.setContentDescription(description);
    button.setOnClickListener(v->getContext().startActivity(new Intent(getContext(),destination)));
    return button;
  }
  public RunningballV105QuickRail(Context c){super(c);
    setOrientation(VERTICAL);setPadding(0,dp(7),0,dp(9));
    TextView label=new TextView(c);label.setText("QUICK ACCESS / DATA MODULES");
    label.setTextSize(11);label.setTextColor(CYAN);label.setTypeface(null,1);
    label.setPadding(dp(2),dp(1),dp(2),dp(7));addView(label,new LayoutParams(-1,-2));
    LinearLayout row=new LinearLayout(c);row.setOrientation(HORIZONTAL);
    row.addView(action(c,"AIR","V105 quick access worldwide aircraft",GREEN,RunningballV25WorldwideAirActivity.class),cell(false));
    row.addView(action(c,"NEWS","V105 quick access live newsroom",CYAN,RunningballV25NewsroomActivity.class),cell(true));
    row.addView(action(c,"DATA","V105 quick access source health",CYAN,RunningballV25SourceHealthActivity.class),cell(true));
    addView(row,new LayoutParams(-1,-2));
    TextView nasa=action(c,"NASA EARTH PHOTO / SHARE","V107 NASA EPIC real photo and credit card",GREEN,RunningballV107EpicActivity.class);
    LayoutParams np=new LayoutParams(-1,-2);np.topMargin=dp(7);addView(nasa,np);
    TextView quake=action(c,"USGS SHAKE MAP / SHARE","V108 USGS event-specific ShakeMap and credited share card",CYAN,RunningballV108ShakeMapActivity.class);
    LayoutParams qp=new LayoutParams(-1,-2);qp.topMargin=dp(7);addView(quake,qp);
    addView(new RunningballV106CachePulse(c),new LayoutParams(-1,-2));
  }
  private LayoutParams cell(boolean margin){
    LayoutParams p=new LayoutParams(0,-2,1f);if(margin)p.leftMargin=dp(7);return p;
  }
}
