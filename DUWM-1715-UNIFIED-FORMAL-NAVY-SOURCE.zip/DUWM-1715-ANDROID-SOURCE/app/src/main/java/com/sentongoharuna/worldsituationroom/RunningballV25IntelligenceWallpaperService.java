package com.sentongoharuna.worldsituationroom;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Stage 3 independent implementation; the V24 DuwmLiveWallpaperService is unchanged.
 * CACHE-ONLY Canvas wallpaper: NO internet permissions, HTTP clients, pollers or synthetic data.
 * Reading bounded SharedPreferences on the main thread at most once per 45 seconds.
 * The app's existing visible-screen pollers own the real network requests.
 */
public final class RunningballV25IntelligenceWallpaperService extends WallpaperService {
  private static final int BG=0xFF050D22, CYAN=0xFF558BDF, GREEN=0xFF558BDF,
                           AMBER=0xFF558BDF, INK=0xFFE0EAFE, MUTED=0xFFC2D0D3;
  private static final long CACHE_INTERVAL_MS=45000L;
  private static final int MAX_ROWS=110, MAX_RAW_CHARS=500000;
  private static final class Dot {
    final double lat,lon;final int tone;final boolean stale;
    Dot(double latitude,double longitude,int color,boolean delayed){lat=latitude;lon=longitude;tone=color;stale=delayed;}
  }
  private static final class Data {
    final ArrayList<Dot> dots=new ArrayList<>();
    String air="--",quake="--",nasa="--",headline="NO VERIFIED HEADLINE",region="GLOBAL VIEW";
    String overall="NO DATA YET",age="NO DATA YET",alert="NO VERIFIED MAJOR EVENT RECEIVED";
    int live=0,reporting=0;
    long fetched=0L;
  }
  @Override public Engine onCreateEngine(){return new IntelligenceEngine();}
  private final class IntelligenceEngine extends Engine {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final KeyguardManager keyguard=(KeyguardManager)getSystemService(Context.KEYGUARD_SERVICE);
    private final PowerManager power=(PowerManager)getSystemService(Context.POWER_SERVICE);
    private boolean visible=false,pending=false,surfaceReady=false,reduceMotion=false,lowPower=false;
    private long frameAt=0L,cacheAt=0L,frames=0L,lastFrameMs=0L,totalFrameMs=0L;
    private double rotation=0d;
    private int mode=0,fps=30;
    private Data data=new Data();
    private final Runnable tick=new Runnable(){@Override public void run(){
      pending=false;if(!canDraw())return;
      long now=SystemClock.uptimeMillis();
      if(cacheAt==0||now-cacheAt>=CACHE_INTERVAL_MS){
        loadSettings();data=readReceived();cacheAt=now;
      }
      long dt=frameAt==0?0:Math.min(100,Math.max(0,now-frameAt));frameAt=now;
      if(!reduceMotion && mode!=3)rotation=(rotation+dt/1000.0d*4.0d)%360d;
      long start=SystemClock.uptimeMillis();render();long spent=SystemClock.uptimeMillis()-start;
      totalFrameMs+=spent;frames++;lastFrameMs=spent;
      if(frames%30==0)android.util.Log.i("RB25IntelligenceWallpaper","frames="+frames+" average_draw_ms="+(totalFrameMs/frames)+" last_draw_ms="+lastFrameMs);
      schedule();
    }};
    IntelligenceEngine(){
      text.setTypeface(android.graphics.Typeface.create("sans-serif-medium",android.graphics.Typeface.NORMAL));
      setOffsetNotificationsEnabled(false);
      loadSettings();
    }
    private SharedPreferences pref(String name){return getApplicationContext().getSharedPreferences(name,Context.MODE_PRIVATE);}
    private boolean canDraw(){return visible&&surfaceReady&&(power==null||power.isInteractive());}
    private void loadSettings(){
      SharedPreferences s=pref("rb25_intelligence_wallpaper");
      mode=Math.max(0,Math.min(3,s.getInt("mode",0)));
      lowPower=s.getBoolean("low_power",false);
      fps=s.getInt("fps",30);if(fps!=5&&fps!=15&&fps!=30)fps=30;
      reduceMotion=s.getBoolean("reduce_motion",false)||pref("rb25_visual_preferences").getBoolean("reduce_motion",false);
      try{reduceMotion|=Settings.Global.getFloat(getContentResolver(),Settings.Global.ANIMATOR_DURATION_SCALE,1f)==0f;}
      catch(Exception ignored){}
    }
    private void schedule(){
      if(!canDraw()||pending)return;pending=true;
      int rate=lowPower?5:reduceMotion?1:fps;
      handler.postDelayed(tick,Math.max(33,1000/rate));
    }
    private void pause(){pending=false;handler.removeCallbacks(tick);frameAt=0L;}
    @Override public void onVisibilityChanged(boolean value){visible=value;
      if(value){frameAt=0;cacheAt=0;if(canDraw())schedule();}else pause();}
    @Override public void onSurfaceCreated(SurfaceHolder holder){super.onSurfaceCreated(holder);surfaceReady=true;if(canDraw())schedule();}
    @Override public void onSurfaceChanged(SurfaceHolder holder,int format,int width,int height){
      super.onSurfaceChanged(holder,format,width,height);surfaceReady=true;if(canDraw())schedule();}
    @Override public void onSurfaceDestroyed(SurfaceHolder holder){surfaceReady=false;pause();super.onSurfaceDestroyed(holder);}
    @Override public void onDestroy(){pause();super.onDestroy();}
    private JSONObject object(String raw){try{return raw.length()<=MAX_RAW_CHARS?new JSONObject(raw):new JSONObject();}
      catch(Exception ignored){return new JSONObject();}}
    private void add(Data d,double lat,double lon,int tone,boolean stale){
      if(d.dots.size()>=MAX_ROWS||!Double.isFinite(lat)||!Double.isFinite(lon)
         ||Math.abs(lat)>90||Math.abs(lon)>180)return;
      d.dots.add(new Dot(lat,lon,tone,stale));
    }
    private void positions(Data d,RunningballV25Sources.Result air,RunningballV25Sources.Result quake,
                           RunningballV25Sources.Result nasa){
      if(air.fetchedAt>0&&air.status!=RunningballV25Sources.Status.NO_DATA_FOR_REGION){
        JSONObject snap=object(pref("air_widget_v2").getString("last_snapshot","{}"));
        boolean valid=RunningballWorldTarget.ready(getApplicationContext())&&
          Math.abs(snap.optDouble("observerLat",999d)-RunningballWorldTarget.lat(getApplicationContext()))<.001d&&
          Math.abs(snap.optDouble("observerLon",999d)-RunningballWorldTarget.lon(getApplicationContext()))<.001d;
        JSONArray rows=snap.optJSONArray("items");
        if(valid&&rows!=null)for(int i=0;i<rows.length()&&i<55;i++){
          JSONObject r=rows.optJSONObject(i);if(r==null)continue;
          double seen=r.optDouble("seen_pos",999d);
          if(seen>=0&&seen<=120)add(d,r.optDouble("lat",Double.NaN),r.optDouble("lon",Double.NaN),GREEN,air.status!=RunningballV25Sources.Status.LIVE);
        }
      }
      if(quake.fetchedAt>0){
        JSONArray events=object(pref("rb_global_public_events").getString("quakes_raw","{}")).optJSONArray("features");
        if(events!=null)for(int i=0;i<events.length()&&i<35;i++){
          JSONObject event=events.optJSONObject(i);if(event==null)continue;
          JSONObject geom=event.optJSONObject("geometry");JSONArray co=geom==null?null:geom.optJSONArray("coordinates");
          if(co!=null&&co.length()>=2)add(d,co.optDouble(1,Double.NaN),co.optDouble(0,Double.NaN),AMBER,quake.status!=RunningballV25Sources.Status.LIVE);
        }
      }
      if(nasa.fetchedAt>0){
        JSONArray events=object(pref("rb_global_public_events").getString("nasa_raw","{}")).optJSONArray("events");
        if(events!=null)for(int i=0;i<events.length()&&i<30;i++){
          JSONObject event=events.optJSONObject(i);if(event==null)continue;
          JSONArray geo=event.optJSONArray("geometry");JSONObject g=geo==null||geo.length()==0?null:geo.optJSONObject(geo.length()-1);
          JSONArray co=g==null?null:g.optJSONArray("coordinates");
          if(g!=null&&"Point".equalsIgnoreCase(g.optString("type",""))&&co!=null&&co.length()>=2)
            add(d,co.optDouble(1,Double.NaN),co.optDouble(0,Double.NaN),CYAN,nasa.status!=RunningballV25Sources.Status.LIVE);
        }
      }
    }
    private Data readReceived(){
      Data d=new Data();RunningballV25Sources.Result[] records=new RunningballV25Sources.Result[9];
      for(int i=0;i<records.length;i++){
        records[i]=RunningballV25Sources.read(getApplicationContext(),i);
        if(records[i].fetchedAt>0){d.reporting++;d.fetched=Math.max(d.fetched,records[i].fetchedAt);}
        if(records[i].status==RunningballV25Sources.Status.LIVE)d.live++;
      }
      d.air=records[0].value;d.quake=records[3].value;d.nasa=records[4].value;
      d.region=RunningballWorldTarget.ready(getApplicationContext())?RunningballWorldTarget.label(getApplicationContext()):"GLOBAL VIEW";
      d.overall=d.reporting>0?(d.live==0?"STALE / CACHED SOURCES":d.live+" / 9 RECENT SOURCE CACHES"):"NO DATA YET";
      d.age=d.fetched>0?"LATEST FETCH "+age(d.fetched):"NO DATA YET";
      RunningballV25Sources.Result news=records[5];
      if(news.fetchedAt>0){
        JSONArray items=object(pref("rb17_verified_feeds").getString("news_json","{}")).optJSONArray("articles");
        if(items!=null)for(int i=0;i<items.length()&&i<10;i++){
          JSONObject entry=items.optJSONObject(i);String line=entry==null?"":entry.optString("title","").trim();
          if(line.length()>=8){d.headline=shorten(line,120);break;}
        }
      }
      RunningballV25Sources.Result quakes=records[3];
      if(quakes.fetchedAt>0){
        JSONArray events=object(pref("rb_global_public_events").getString("quakes_raw","{}")).optJSONArray("features");
        if(events!=null)for(int i=0;i<events.length()&&i<75;i++){
          JSONObject entry=events.optJSONObject(i),properties=entry==null?null:entry.optJSONObject("properties");
          if(properties!=null&&properties.optDouble("mag",0)>=5){
            d.alert="USGS "+(quakes.status==RunningballV25Sources.Status.LIVE?"REPORTED":"CACHED")+" M "+String.format(Locale.US,"%.1f",properties.optDouble("mag"))+" · "+shorten(properties.optString("place","LOCATION UNKNOWN"),65);
            break;
          }
        }
      }
      positions(d,records[0],quakes,records[4]);
      // Global aircraft positions are cached by the visible app, NEVER fetched by this wallpaper.
      if(!RunningballWorldTarget.ready(getApplicationContext())){
        RunningballV25GlobalAircraftData.Snapshot global=RunningballV25GlobalAircraftData.readWallpaper(getApplicationContext());
        if(global.hasGood()&&global.ageMs()<21600000L){
          d.air=global.countLabel();
          d.region="WORLDWIDE / OPENSKY NETWORK COVERAGE";
          d.fetched=Math.max(d.fetched,global.receivedAt);
          d.overall="GLOBAL AIR "+global.status()+" · "+d.live+"/9 OTHER SOURCES RECENT";
          int stride=Math.max(1,global.points.length()/55);
          for(int i=0;i<global.points.length();i+=stride){
            JSONArray point=global.points.optJSONArray(i);
            if(point!=null)add(d,point.optDouble(0,Double.NaN),point.optDouble(1,Double.NaN),GREEN,global.ageMs()>900000L);
          }
        }
      }
      return d;
    }
    private String shorten(String s,int max){String clean=s==null?"":s.replace('\n',' ').replace('\r',' ').trim();return clean.length()<=max?clean:clean.substring(0,max-1)+"…";}
    private String age(long stamp){if(stamp<=0)return "NO DATA";long sec=Math.max(0,(System.currentTimeMillis()-stamp)/1000L);
      if(sec<60)return sec+"s AGO";long minutes=sec/60L;if(minutes<60)return minutes+"m AGO";
      if(minutes<1440)return (minutes/60)+"h "+(minutes%60)+"m AGO";return (minutes/1440)+"d AGO";}
    private void textLine(Canvas c,String value,float x,float y,float sp,int color,boolean strong,float width){
      text.setStyle(Paint.Style.FILL);text.setColor(color);text.setTextSize(sp);text.setAlpha(255);
      text.setTypeface(android.graphics.Typeface.create(strong?"sans-serif-medium":"sans-serif",android.graphics.Typeface.NORMAL));
      String label=shorten(value,150);while(label.length()>2&&text.measureText(label)>width)label=label.substring(0,label.length()-2)+"…";
      c.drawText(label,x,y,text);
    }
    private void globe(Canvas c,float w,float h){
      float dp=getResources().getDisplayMetrics().density;
      float radius=Math.min(w*.40f,h*.29f),cx=w*.5f,cy=h*.42f;
      paint.setStyle(Paint.Style.FILL);paint.setShader(new LinearGradient(cx-radius,cy-radius,cx+radius,cy+radius,
        new int[]{0xFF284C87,0xFF0B1B38,0xFF050D22},null,Shader.TileMode.CLAMP));
      c.drawCircle(cx,cy,radius,paint);paint.setShader(null);
      paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(1f,dp*.8f));paint.setColor(0xFF284C87);
      for(int lat=-60;lat<=60;lat+=30){float ry=(float)Math.sin(Math.toRadians(lat))*radius;
        float rx=(float)Math.cos(Math.toRadians(lat))*radius;
        c.drawOval(cx-rx,cy-ry-radius*.07f,cx+rx,cy-ry+radius*.07f,paint);
      }
      for(int longitude=0;longitude<180;longitude+=30){float rx=(float)(Math.abs(Math.cos(Math.toRadians(longitude+rotation)))*radius);
        c.drawOval(cx-rx,cy-radius,cx+rx,cy+radius,paint);
      }
      paint.setStyle(Paint.Style.FILL);
      c.save();android.graphics.Path mask=new android.graphics.Path();mask.addCircle(cx,cy,radius,android.graphics.Path.Direction.CW);c.clipPath(mask);
      for(Dot dot:data.dots){
        double lat=Math.toRadians(dot.lat),relLon=Math.toRadians(dot.lon+rotation);
        double facing=Math.cos(lat)*Math.cos(relLon);
        if(facing<=0)continue;
        float px=cx+(float)(Math.cos(lat)*Math.sin(relLon))*radius;
        float py=cy-(float)Math.sin(lat)*radius;
        paint.setColor(dot.tone);paint.setAlpha(dot.stale?65:215);c.drawCircle(px,py,Math.max(2f,dp*2.4f),paint);
      }
      c.restore();paint.setAlpha(255);paint.setStyle(Paint.Style.STROKE);paint.setColor(CYAN);
      paint.setStrokeWidth(Math.max(1f,dp*.8f));c.drawCircle(cx,cy,radius,paint);
      paint.setStyle(Paint.Style.FILL);
    }
    private void render(){
      SurfaceHolder holder=getSurfaceHolder();Canvas c=null;
      try{
        c=holder.lockCanvas();if(c==null)return;
        long t0=SystemClock.uptimeMillis();float w=c.getWidth(),h=c.getHeight(),density=getResources().getDisplayMetrics().density;
        c.drawColor(BG);
        boolean privateView=isPreview()||(keyguard!=null&&keyguard.isKeyguardLocked());
        boolean mobile=w<440*density;
        float pad=Math.max(14*density,w*.045f),size=Math.max(13*density,Math.min(17*density,w*.040f));
        textLine(c,"RUNNINGBALL2 / WORLD INTELLIGENCE",pad,Math.max(pad+19*density,h*.065f),size,CYAN,true,w-2*pad);
        SimpleDateFormat utc=new SimpleDateFormat("HH:mm:ss 'UTC'",Locale.US);utc.setTimeZone(TimeZone.getTimeZone("UTC"));
        textLine(c,utc.format(new Date()),pad,Math.max(pad+53*density,h*.110f),size*1.15f,INK,true,w-2*pad);
        if(mode!=3)globe(c,w,h);
        float footer=h-Math.max(66*density,h*.20f);
        textLine(c,privateView?"REGION HIDDEN / PREVIEW":shorten(data.region,38),pad,footer,size,CYAN,true,w-2*pad);
        if(mode==1){
          textLine(c,"AIR "+data.air+"  ·  QUAKE 24H "+data.quake+"  ·  EVENTS "+data.nasa,
            pad,footer+26*density,size*.89f,INK,true,w-2*pad);
        }else if(mode==2){
          textLine(c,privateView?"HEADLINE HIDDEN IN PREVIEW":data.headline,pad,footer+26*density,size*.85f,INK,false,w-2*pad);
        }else if(mode==3){
          textLine(c,"PUBLIC EVENT MONITOR",pad,h*.40f,size*1.1f,GREEN,true,w-2*pad);
          textLine(c,privateView?"ALERTS HIDDEN ON LOCK SCREEN":data.alert,pad,h*.47f,size,INK,false,w-2*pad);
        }
        textLine(c,data.overall,pad,h-51*density,size*.84f,MUTED,false,w-2*pad);
        String since=data.fetched>0?age(data.fetched):"NO DATA YET";
        textLine(c,data.fetched>0?"LAST CACHED REPORT "+since:"NO DATA YET",pad,h-29*density,size*.83f,
          data.live==0||data.fetched>0&&System.currentTimeMillis()-data.fetched>3600000L?AMBER:GREEN,false,w-2*pad);
        textLine(c,"REPORTED POSITIONS ONLY · SOURCE-AGED",pad,h-9*density,Math.max(10*density,size*.7f),MUTED,false,w-2*pad);
        lastFrameMs=SystemClock.uptimeMillis()-t0;
      }catch(Exception e){android.util.Log.e("RB25IntelligenceWallpaper","Wallpaper draw failed",e);}
      finally{if(c!=null)holder.unlockCanvasAndPost(c);}
    }
  }
}
