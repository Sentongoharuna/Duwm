package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Independent native implementation using original NASA/NOAA DSCOVR EPIC data.
 * The photo is a NASA Earth observation, NOT an illustration of a news story or disaster.
 * NASA does not endorse RUNNINGBALL2. See NASA media usage guidelines. */
public final class RunningballV107EpicActivity extends Activity {
  static final String API="https://epic.gsfc.nasa.gov/api/natural";
  static final long TTL_MS=6L*60*60*1000;
  static final int INK=0xFFE0EAFE,CYAN=0xFF558BDF,GREEN=0xFF558BDF,AMBER=0xFF558BDF;
  private final ExecutorService io=Executors.newSingleThreadExecutor();
  private TextView status,headline,caption,timeLine;
  private ImageView preview;
  private Button share;
  private volatile boolean closed=false;
  private long lastTap=0;
  private Record record;
  private static final class Record {
    final String image,date,caption,url;
    final long observed;
    Record(String image,String date,String caption,String url,long observed){
      this.image=image;this.date=date;this.caption=caption;this.url=url;this.observed=observed;
    }
  }
  private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
  private TextView label(String str,int sp,int color){TextView t=new TextView(this);t.setText(str);t.setTextSize(sp);t.setTextColor(color);return t;}
  private Button button(String name){Button b=new Button(this);b.setAllCaps(false);b.setText(name);b.setTextColor(INK);b.setMinHeight(dp(52));b.setBackgroundColor(0xFF25568F);return b;}
  @Override public void onCreate(Bundle saved){super.onCreate(saved);
    // DUWM 1167 common safe area is installed after the scroll root is attached.
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(0xFF050D22);
    LinearLayout col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);
    col.setPadding(dp(16),dp(20),dp(16),dp(30));scroll.addView(col);setContentView(scroll);Duwm1167SafeArea.install(this,scroll);
    col.addView(label("RUNNINGBALL2 / V107 / OBSERVED NASA IMAGE",12,GREEN));
    TextView title=label("NASA EARTH IMAGERY",25,INK);title.setTypeface(null,1);col.addView(title);
    col.addView(label("DSCOVR / EPIC · Latest received natural-color Earth observation",12,CYAN));
    status=label("NO DATA YET · CHECKING NASA EPIC",13,AMBER);status.setPadding(0,dp(14),0,dp(12));col.addView(status);
    preview=new ImageView(this);preview.setBackgroundColor(0xFF0C1A35);
    preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
    col.addView(preview,new LinearLayout.LayoutParams(-1,dp(290)));
    headline=label("Image not loaded",17,INK);headline.setPadding(0,dp(14),0,dp(7));col.addView(headline);
    caption=label("No image metadata received",13,INK);col.addView(caption);
    timeLine=label("OBSERVATION TIME: NOT RECEIVED",12,CYAN);
    timeLine.setPadding(0,dp(10),0,dp(10));col.addView(timeLine);
    share=button("SHARE NASA IMAGE CARD");share.setEnabled(false);col.addView(share);
    share.setOnClickListener(v->shareObserved());
    Button refresh=button("REFRESH NASA EPIC IMAGE");col.addView(refresh);
    refresh.setOnClickListener(v->{long now=System.currentTimeMillis();
      if(now-lastTap<60000L){status.setText("REFRESH COOLDOWN · 60 SECONDS");return;}
      lastTap=now;refresh(true);
    });
    Button source=button("OPEN NASA IMAGE SOURCE");col.addView(source);
    source.setOnClickListener(v->{if(record!=null){try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(record.url)));}
      catch(Exception e){status.setText("BROWSER UNAVAILABLE");}}});
    col.addView(label("SOURCE: NASA/NOAA DSCOVR EPIC. NO NASA ENDORSEMENT. PHOTO IS NOT A FORECAST OR A PHOTO OF AN UNRELATED EVENT.",11,AMBER));
    refresh(false);
  }
  static String imageUrl(String date,String image){
    if(date==null||!date.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}"))throw new IllegalArgumentException("date");
    if(image==null||!image.matches("[A-Za-z0-9_-]{8,80}"))throw new IllegalArgumentException("image identifier");
    String y=date.substring(0,4),m=date.substring(5,7),d=date.substring(8,10);
    return "https://epic.gsfc.nasa.gov/archive/natural/"+y+"/"+m+"/"+d+"/jpg/"+image+".jpg";
  }
  static long parseTime(String date) throws Exception {
    SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);
    f.setLenient(false);f.setTimeZone(TimeZone.getTimeZone("UTC"));
    return f.parse(date).getTime();
  }
  static Record readRecord(String json) throws Exception {
    JSONArray list=new JSONArray(json);Record best=null;
    for(int i=0;i<list.length();i++){
      JSONObject item=list.optJSONObject(i);if(item==null)continue;
      String date=item.optString("date",""),image=item.optString("image","");
      try {
        long observed=parseTime(date);String uri=imageUrl(date,image);
        if(observed>System.currentTimeMillis()+86400000L)continue;
        if(best==null||observed>best.observed)
          best=new Record(image,date,item.optString("caption","NASA EPIC observed Earth"),uri,observed);
      }catch(Exception ignore){} // invalid metadata is not converted into a fabricated record
    }
    if(best==null)throw new IllegalArgumentException("NASA EPIC returned no valid observations");
    return best;
  }
  private static byte[] getBytes(String endpoint,int maxBytes) throws Exception {
    HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection();
    try {
      c.setConnectTimeout(7000);c.setReadTimeout(9000);c.setInstanceFollowRedirects(false);
      c.setRequestProperty("User-Agent","RUNNINGBALL2/V107 NASA EPIC original-source credit");
      if(c.getResponseCode()!=200)throw new IllegalStateException("NASA HTTP "+c.getResponseCode());
      long length=c.getContentLengthLong();if(length>maxBytes)throw new IllegalStateException("NASA response too large");
      try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
        byte[] buf=new byte[8192];int n;
        while((n=in.read(buf))!=-1){if(out.size()+n>maxBytes)throw new IllegalStateException("NASA response limit");out.write(buf,0,n);}
        return out.toByteArray();
      }
    }finally{c.disconnect();}
  }
  private static Bitmap imageBitmap(String url) throws Exception {
    if(!url.startsWith("https://epic.gsfc.nasa.gov/archive/natural/"))throw new IllegalArgumentException("unapproved host");
    byte[] bytes=getBytes(url,2000000);
    BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;
    BitmapFactory.decodeByteArray(bytes,0,bytes.length,o);
    if(o.outWidth<100||o.outHeight<100||o.outWidth>8000||o.outHeight>8000)throw new IllegalArgumentException("invalid image");
    o.inJustDecodeBounds=false;o.inSampleSize=Math.max(1,Math.max(o.outWidth,o.outHeight)/1500);
    Bitmap result=BitmapFactory.decodeByteArray(bytes,0,bytes.length,o);
    if(result==null)throw new IllegalArgumentException("image decode failed");return result;
  }
  private void refresh(boolean manual){
    SharedPreferences prefs=getSharedPreferences("rb107_epic",MODE_PRIVATE);
    long last=prefs.getLong("fetched",0L);
    String cached=prefs.getString("json","");
    boolean shouldFetch=manual || cached.isEmpty() || System.currentTimeMillis()-last>TTL_MS;
    status.setText(shouldFetch?"REQUESTING NASA SOURCE · AWAITING RESPONSE":"NASA CACHED METADATA · CHECKING IMAGE");
    io.execute(()->{
      String json=cached;String error="";long fetched=last;
      if(shouldFetch){try {
        json=new String(getBytes(API,260000),java.nio.charset.StandardCharsets.UTF_8);
        readRecord(json);fetched=System.currentTimeMillis();
        prefs.edit().putString("json",json).putLong("fetched",fetched).remove("error").apply();
      }catch(Exception ex){error="NASA METADATA FAILED: "+ex.getClass().getSimpleName();
        prefs.edit().putString("error",error).apply();}}
      Record selected=null;Bitmap image=null;
      try{selected=readRecord(json);image=imageBitmap(selected.url);}
      catch(Exception e){if(error.isEmpty())error="NASA IMAGE OR METADATA UNAVAILABLE: "+e.getClass().getSimpleName();}
      final Record complete=selected;final Bitmap photo=image;final String err=error;final long successAt=fetched;
      runOnUiThread(()->{
        if(closed){if(photo!=null)photo.recycle();return;}
        record=complete;share.setEnabled(complete!=null);
        String stamp=successAt>0?" · CACHED "+((System.currentTimeMillis()-successAt)/60000L)+" MIN":" · NO SUCCESS TIME";
        status.setText((err.isEmpty()?"NASA EPIC IMAGE RECEIVED":"NASA EPIC IMAGE/FEED ISSUE · "+err)+stamp);
        if(complete==null){headline.setText("NO VERIFIED NASA IMAGE");caption.setText("No source observation available");return;}
        headline.setText("NASA DSCOVR EPIC · "+complete.image);
        caption.setText(complete.caption);timeLine.setText("OBSERVED UTC · "+complete.date+" · ORIGINAL SOURCE: NASA/NOAA");
        if(photo!=null)preview.setImageBitmap(photo);
      });
    });
  }
  private void shareObserved(){
    Record r=record;if(r==null){status.setText("NO VERIFIED NASA IMAGE TO SHARE");return;}
    Map<String,String> facts=new LinkedHashMap<>();
    facts.put("OBSERVED UTC",r.date);
    facts.put("IMAGE ID",r.image);
    facts.put("IMAGE_CREDIT","NASA/NOAA DSCOVR EPIC");
    facts.put("IMAGE_LICENSE","NASA_EDITORIAL");
    facts.put("IMAGE_RECORD_URL",r.url);
    facts.put("IMAGE",r.url);
    facts.put("NASA API",API);
    ShareCardData card=new ShareCardData(
      "EARTH OBSERVED FROM SPACE",r.caption,"OBSERVED IMAGE","NASA SOURCE RECORD",
      "SPACE / EARTH","GLOBAL",1,"NASA/NOAA DSCOVR EPIC",r.url,r.observed,
      Double.NaN,Double.NaN,facts,CYAN,"NASA SOURCE PHOTO / NO ENDORSEMENT / VERIFY ORIGINAL");
    ShareCardRenderer.share(this,card);
  }
  @Override protected void onDestroy(){closed=true;io.shutdownNow();super.onDestroy();}
}
