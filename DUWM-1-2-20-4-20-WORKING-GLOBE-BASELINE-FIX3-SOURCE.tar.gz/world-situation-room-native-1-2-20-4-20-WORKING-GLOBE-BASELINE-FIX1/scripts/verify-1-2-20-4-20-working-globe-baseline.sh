#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"; V="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/SatelliteMapView.java"
echo "RUNNING PRE-4.19A WORKING-GLOBE BASELINE GATE"
echo "3309dfc06fe8608653c77e54d19391428f686e42d243f0031c5da21e9b33adcb  $V" | sha256sum -c -
grep -F 'private final Runnable framePulse = new Runnable()' "$V" >/dev/null
grep -F 'updateAutoRotation();' "$V" >/dev/null
grep -F 'postOnAnimationDelayed(framePulse, frameDelayMs);' "$V" >/dev/null
! grep -F 'liveRotationPhaseDeg' "$V"
! grep -F 'motionLoopRunning' "$V"
! grep -F 'advanceLiveMotion' "$V"
mapfile -t CHECKS < <(find "$P/scripts" -maxdepth 1 -type f -name 'verify-1-2-20-4-*.sh' ! -name 'verify-1-2-20-4-20-working-globe-baseline.sh' ! -name 'verify-1-2-20-4-20-working-globe-baseline-fix1.sh' | sort -V)
for check in "${CHECKS[@]}"; do
  echo "RUNNING PRESENT BASELINE CHECK: $(basename "$check")"
  if bash "$check" "$P"; then
    echo "VERIFIED: $(basename "$check")"
  else
    rc=$?
    echo "::error::Baseline verifier failed: $(basename "$check") (exit $rc)"
    exit "$rc"
  fi
done
echo "1.2/20/4.20 WORKING GLOBE BASELINE FIX3 GATE PASS"
exit 0
