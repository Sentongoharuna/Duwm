# WORKING GLOBE BASELINE FIX2

Repairs the baseline verifier path propagation bug.

The 4.20 baseline enumerated child verifier scripts and ran each as:
`bash "$check"`

Child verifiers default `P` to the current working directory, while this
workflow extracts the Android project under `$RUNNER_TEMP/duwm/...`.
Therefore 4.1 looked for the 3.20 verifier in the repository working
directory and failed with exit code 127 even though the verifier was present
inside the source archive.

FIX2 passes the extracted project path to every child verifier:
`bash "$check" "$P"`

No Android application source was downgraded or replaced by this repair.
