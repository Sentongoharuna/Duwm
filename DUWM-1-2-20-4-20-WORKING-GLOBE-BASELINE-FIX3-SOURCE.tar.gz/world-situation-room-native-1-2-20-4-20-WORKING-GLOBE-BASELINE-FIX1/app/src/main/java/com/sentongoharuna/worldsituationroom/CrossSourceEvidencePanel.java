package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4-8 evidence roles preserve independent provider records and never score truth. */
public final class CrossSourceEvidencePanel {
 public enum Role { PRIMARY_RECORD, RELATED_PROVIDER_RECORD, SAME_PROVIDER_RELATED }
 public static final class Evidence {
  public final Role role; public final Signal signal;
  Evidence(Role r,Signal s){role=r;signal=s;}
 }
 public static List<Evidence> build(Signal focus,List<Signal> related,int limit){
  if(focus==null)return Collections.emptyList();
  ArrayList<Evidence> out=new ArrayList<>();
  out.add(new Evidence(Role.PRIMARY_RECORD,focus));
  HashSet<String> seen=new HashSet<>();seen.add(focus.canonicalId);
  if(related!=null)for(Signal s:related){
   if(s==null||s.canonicalId==null||!seen.add(s.canonicalId))continue;
   Role r=focus.providerId.equals(s.providerId)?Role.SAME_PROVIDER_RELATED:Role.RELATED_PROVIDER_RECORD;
   out.add(new Evidence(r,s));if(out.size()>=limit)break;
  }
  return Collections.unmodifiableList(out);
 }
 public static int distinctProviders(List<Evidence> evidence){
  HashSet<String>x=new HashSet<>();if(evidence!=null)for(Evidence e:evidence)if(e!=null&&e.signal!=null)x.add(e.signal.providerId);return x.size();
 }
 public static int distinctLayers(List<Evidence> evidence){
  EnumSet<Signal.Layer>x=EnumSet.noneOf(Signal.Layer.class);if(evidence!=null)for(Evidence e:evidence)if(e!=null&&e.signal!=null)x.add(e.signal.layer);return x.size();
 }
}
