package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4-12 East Africa operations lens over the same worldwide canonical records. */
public final class EastAfricaOperationsView {
 public static final class Snapshot {
  public final List<Signal> records; public final Map<Signal.Layer,Integer> layers;
  public final Map<String,Integer> places; public final int providerCount,liveFreshCount,watchedCount,changeCount;
  Snapshot(List<Signal>r,Map<Signal.Layer,Integer>l,Map<String,Integer>p,int pc,int f,int w,int c){
   records=Collections.unmodifiableList(r);layers=Collections.unmodifiableMap(l);places=Collections.unmodifiableMap(p);
   providerCount=pc;liveFreshCount=f;watchedCount=w;changeCount=c;
  }
 }
 public static Snapshot build(Collection<List<Signal>> all,CanonicalWatchStore watch,LiveChangeRegistry changes,int limit){
  ArrayList<Signal> records=new ArrayList<>();HashSet<String>seen=new HashSet<>(),providers=new HashSet<>();
  EnumMap<Signal.Layer,Integer>counts=new EnumMap<>(Signal.Layer.class);LinkedHashMap<String,Integer>places=new LinkedHashMap<>();
  int fresh=0,watched=0,changed=0;
  if(all!=null)for(List<Signal>list:all)if(list!=null)for(Signal s:list){
   if(s==null||s.canonicalId==null||!seen.add(s.canonicalId))continue;
   RegionalPriorityEngine.Result rr=RegionalPriorityEngine.evaluate(s);
   if(rr.band!=RegionalPriorityEngine.Band.UGANDA&&rr.band!=RegionalPriorityEngine.Band.EAST_AFRICA)continue;
   records.add(s);providers.add(s.providerId);counts.put(s.layer,counts.getOrDefault(s.layer,0)+1);
   String place=countryBand(s);places.put(place,places.getOrDefault(place,0)+1);
   if(s.freshness!=null&&(s.freshness.state==ObjectFreshness.State.LIVE||s.freshness.state==ObjectFreshness.State.FRESH))fresh++;
   if(watch!=null&&watch.watched(s.canonicalId))watched++;
   if(changes!=null&&!changes.changesFor(s.canonicalId).isEmpty())changed++;
  }
  records.sort((a,b)->Long.compare(b.timestampMs,a.timestampMs));
  if(records.size()>limit)records=new ArrayList<>(records.subList(0,limit));
  return new Snapshot(records,new EnumMap<>(counts),places,providers.size(),fresh,watched,changed);
 }
 private static String countryBand(Signal s){
  if(s.hasLocation()){
   double a=s.latitude,o=s.longitude;
   if(a>=-1.6&&a<=4.3&&o>=29.4&&o<=35.1)return "UGANDA";
   if(a>=-5.0&&a<=5.5&&o>=33.5&&o<=42.5)return "KENYA";
   if(a>=-12.0&&a<=-0.8&&o>=29.0&&o<=40.8)return "TANZANIA";
   if(a>=-2.9&&a<=-1.0&&o>=28.8&&o<=30.9)return "RWANDA";
   if(a>=-4.6&&a<=-2.2&&o>=28.9&&o<=30.9)return "BURUNDI";
   if(a>=3.4&&a<=12.3&&o>=23.4&&o<=35.9)return "SOUTH SUDAN";
  }
  return "EAST AFRICA / UNRESOLVED COUNTRY";
 }
}
