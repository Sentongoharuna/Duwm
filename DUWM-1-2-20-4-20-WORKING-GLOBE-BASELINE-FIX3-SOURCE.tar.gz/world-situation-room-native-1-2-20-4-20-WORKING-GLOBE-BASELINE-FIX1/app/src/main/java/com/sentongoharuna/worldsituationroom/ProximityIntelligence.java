package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4-6 factual proximity from current located canonical provider records. */
public final class ProximityIntelligence {
 public static final class Nearby {
  public final Signal signal; public final double distanceKm,bearingDeg; public final String direction;
  Nearby(Signal s,double d,double b,String dir){signal=s;distanceKm=d;bearingDeg=b;direction=dir;}
 }
 public static List<Nearby> around(Signal focus,Collection<List<Signal>> layers,double radiusKm,int limit){
  if(focus==null||!focus.hasLocation())return Collections.emptyList();
  ArrayList<Nearby> out=new ArrayList<>();HashSet<String> seen=new HashSet<>();
  if(layers!=null)for(List<Signal> list:layers)if(list!=null)for(Signal s:list){
   if(s==null||!s.hasLocation()||s.canonicalId==null||s.canonicalId.equals(focus.canonicalId)||!seen.add(s.canonicalId))continue;
   double d=km(focus.latitude,focus.longitude,s.latitude,s.longitude);
   if(d>radiusKm)continue;
   double b=bearing(focus.latitude,focus.longitude,s.latitude,s.longitude);
   out.add(new Nearby(s,d,b,compass(b)));
  }
  out.sort((a,b)->Double.compare(a.distanceKm,b.distanceKm));
  if(out.size()>limit)return Collections.unmodifiableList(new ArrayList<>(out.subList(0,limit)));
  return Collections.unmodifiableList(out);
 }
 private static double km(double a,double b,double c,double d){
  double r=6371.0088,p1=Math.toRadians(a),p2=Math.toRadians(c),dp=Math.toRadians(c-a),dl=Math.toRadians(d-b);
  double h=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);
  return 2*r*Math.asin(Math.min(1d,Math.sqrt(h)));
 }
 private static double bearing(double a,double b,double c,double d){
  double p1=Math.toRadians(a),p2=Math.toRadians(c),dl=Math.toRadians(d-b);
  double y=Math.sin(dl)*Math.cos(p2),x=Math.cos(p1)*Math.sin(p2)-Math.sin(p1)*Math.cos(p2)*Math.cos(dl);
  return (Math.toDegrees(Math.atan2(y,x))+360d)%360d;
 }
 private static String compass(double b){String[]p={"N","NE","E","SE","S","SW","W","NW"};return p[((int)Math.floor((b+22.5)/45d))%8];}
}
