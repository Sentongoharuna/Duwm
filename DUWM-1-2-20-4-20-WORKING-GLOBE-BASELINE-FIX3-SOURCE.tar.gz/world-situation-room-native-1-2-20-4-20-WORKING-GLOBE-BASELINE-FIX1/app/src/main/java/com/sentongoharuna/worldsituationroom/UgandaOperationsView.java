package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4-11 Uganda operations snapshot from the same worldwide canonical record engine. */
public final class UgandaOperationsView {
 public static final class Snapshot {
  public final List<Signal> records; public final Map<Signal.Layer,Integer> layers;
  public final int providerCount,liveFreshCount,watchedCount,changeCount;
  Snapshot(List<Signal>r,Map<Signal.Layer,Integer>l,int p,int f,int w,int c){
   records=Collections.unmodifiableList(r);layers=Collections.unmodifiableMap(l);
   providerCount=p;liveFreshCount=f;watchedCount=w;changeCount=c;
  }
 }
 public static Snapshot build(Collection<List<Signal>> all,CanonicalWatchStore watch,LiveChangeRegistry changes,int limit){
  ArrayList<Signal> records=new ArrayList<>();HashSet<String>seen=new HashSet<>(),providers=new HashSet<>();
  EnumMap<Signal.Layer,Integer>counts=new EnumMap<>(Signal.Layer.class);int fresh=0,watched=0,changed=0;
  if(all!=null)for(List<Signal>list:all)if(list!=null)for(Signal s:list){
   if(s==null||s.canonicalId==null||!seen.add(s.canonicalId))continue;
   RegionalPriorityEngine.Result rr=RegionalPriorityEngine.evaluate(s);if(rr.band!=RegionalPriorityEngine.Band.UGANDA)continue;
   records.add(s);providers.add(s.providerId);counts.put(s.layer,counts.getOrDefault(s.layer,0)+1);
   if(s.freshness!=null&&(s.freshness.state==ObjectFreshness.State.LIVE||s.freshness.state==ObjectFreshness.State.FRESH))fresh++;
   if(watch!=null&&watch.watched(s.canonicalId))watched++;
   if(changes!=null&&!changes.changesFor(s.canonicalId).isEmpty())changed++;
  }
  records.sort((a,b)->Long.compare(b.timestampMs,a.timestampMs));
  if(records.size()>limit)records=new ArrayList<>(records.subList(0,limit));
  return new Snapshot(records,new EnumMap<>(counts),providers.size(),fresh,watched,changed);
 }
}
