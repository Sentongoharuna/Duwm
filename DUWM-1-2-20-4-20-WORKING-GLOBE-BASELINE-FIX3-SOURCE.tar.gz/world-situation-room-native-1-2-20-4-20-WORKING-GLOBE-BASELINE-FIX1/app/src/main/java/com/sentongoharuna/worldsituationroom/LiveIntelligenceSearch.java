package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4-16 unified live intelligence search over current canonical records and operational metadata. */
public final class LiveIntelligenceSearch {
 public static final class Hit {
  public final Signal signal; public final int rank; public final String matchedBy;
  Hit(Signal s,int r,String m){signal=s;rank=r;matchedBy=m;}
 }
 public static List<Hit> search(String raw,Collection<List<Signal>> layers,CanonicalWatchStore watch,
                                LiveChangeRegistry changes,int limit){
  String q=norm(raw);if(q.isEmpty())return Collections.emptyList();
  ArrayList<Hit> out=new ArrayList<>();HashSet<String> seen=new HashSet<>();
  if(layers!=null)for(List<Signal>list:layers)if(list!=null)for(Signal s:list){
   if(s==null||s.canonicalId==null||!seen.add(s.canonicalId))continue;
   int rank=0;String by="";
   String canonical=norm(s.canonicalId),nativeId=norm(s.id),title=norm(s.title),provider=norm(s.providerName+" "+s.providerId);
   String region=norm(s.region),layer=norm(s.layer.name()),callsign=norm(s.facts.get("CALLSIGN")),norad=norm(s.facts.get("NORAD CATALOG"));
   if(q.equals(canonical)){rank=100;by="CANONICAL ID";}
   else if(q.equals(nativeId)||q.equals(callsign)||q.equals(norad)){rank=95;by="EXACT PROVIDER ID / CALLSIGN / NORAD";}
   else if(title.contains(q)){rank=80;by="TITLE";}
   else if(provider.contains(q)){rank=65;by="PROVIDER";}
   else if(region.contains(q)){rank=60;by="REGION";}
   else if(layer.contains(q)){rank=55;by="LAYER";}
   else if("watched".equals(q)&&watch!=null&&watch.watched(s.canonicalId)){rank=70;by="WATCH";}
   else if("changed".equals(q)&&changes!=null&&!changes.changesFor(s.canonicalId).isEmpty()){rank=70;by="CHANGE HISTORY";}
   if(rank>0)out.add(new Hit(s,rank,by));
  }
  out.sort((a,b)->{int r=Integer.compare(b.rank,a.rank);return r!=0?r:Long.compare(b.signal.timestampMs,a.signal.timestampMs);});
  if(out.size()>limit)out=new ArrayList<>(out.subList(0,limit));
  return Collections.unmodifiableList(out);
 }
 private static String norm(String s){return s==null?"":s.trim().toLowerCase(Locale.ROOT);}
}
