package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4-9 conservative News/Event link candidates; a link is never confirmation. */
public final class NewsEventLinkEngine {
 public enum Basis { EXISTING_RELATIONSHIP_ID, LOCATION_AND_TIME }
 public static final class Link {
  public final Signal news,event; public final Basis basis; public final double distanceKm; public final long timeDeltaMs;
  Link(Signal n,Signal e,Basis b,double d,long t){news=n;event=e;basis=b;distanceKm=d;timeDeltaMs=t;}
 }
 public static List<Link> linksFor(Signal focus,Collection<List<Signal>> layers,int limit){
  if(focus==null)return Collections.emptyList();
  ArrayList<Signal> news=new ArrayList<>(),events=new ArrayList<>();
  if(layers!=null)for(List<Signal> list:layers)if(list!=null)for(Signal s:list){
   if(s==null)continue;if(s.layer==Signal.Layer.NEWS)news.add(s);
   else if(s.layer==Signal.Layer.NATURAL||s.layer==Signal.Layer.WEATHER||s.layer==Signal.Layer.AIRSPACE)events.add(s);
  }
  ArrayList<Link> out=new ArrayList<>();HashSet<String> seen=new HashSet<>();
  for(Signal n:news)for(Signal e:events){
   if(!focus.canonicalId.equals(n.canonicalId)&&!focus.canonicalId.equals(e.canonicalId))continue;
   Basis basis=null;double d=Double.NaN;long dt=Math.abs(n.timestampMs-e.timestampMs);
   if(n.relationshipId!=null&&!n.relationshipId.isEmpty()&&n.relationshipId.equals(e.relationshipId))basis=Basis.EXISTING_RELATIONSHIP_ID;
   else if(n.hasLocation()&&e.hasLocation()){
    d=km(n.latitude,n.longitude,e.latitude,e.longitude);
    if(d<=100d&&dt<=6L*60L*60L*1000L)basis=Basis.LOCATION_AND_TIME;
   }
   if(basis==null)continue;
   String key=n.canonicalId+"|"+e.canonicalId;if(!seen.add(key))continue;
   out.add(new Link(n,e,basis,d,dt));if(out.size()>=limit)return Collections.unmodifiableList(out);
  }
  return Collections.unmodifiableList(out);
 }
 private static double km(double a,double b,double c,double d){
  double r=6371.0088,p1=Math.toRadians(a),p2=Math.toRadians(c),dp=Math.toRadians(c-a),dl=Math.toRadians(d-b);
  double h=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);
  return 2*r*Math.asin(Math.min(1d,Math.sqrt(h)));
 }
}
