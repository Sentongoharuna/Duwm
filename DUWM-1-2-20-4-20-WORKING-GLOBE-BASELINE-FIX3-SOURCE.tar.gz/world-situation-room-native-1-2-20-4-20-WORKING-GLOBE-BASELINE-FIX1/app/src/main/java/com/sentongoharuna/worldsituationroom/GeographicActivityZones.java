package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4-3 observed geographic concentration from current located provider records. */
public final class GeographicActivityZones {
 public static final class Zone {
  public final double latitude,longitude,radiusKm;
  public final int objectCount,layerCount;
  public final String dominantLayer;
  Zone(double a,double o,double r,int c,int lc,String d){latitude=a;longitude=o;radiusKm=r;objectCount=c;layerCount=lc;dominantLayer=d;}
 }
 public static List<Zone> detect(Collection<List<Signal>> layers){
  ArrayList<Signal> all=new ArrayList<>();
  if(layers!=null)for(List<Signal> list:layers)if(list!=null)for(Signal s:list)if(valid(s))all.add(s);
  ArrayList<Zone> out=new ArrayList<>();HashSet<String> used=new HashSet<>();
  for(Signal seed:all){
   if(used.contains(seed.canonicalId))continue;
   ArrayList<Signal> members=new ArrayList<>();
   for(Signal s:all)if(distanceKm(seed.latitude,seed.longitude,s.latitude,s.longitude)<=75d)members.add(s);
   if(members.size()<4)continue;
   double lat=0,lon=0;EnumMap<Signal.Layer,Integer> counts=new EnumMap<>(Signal.Layer.class);
   for(Signal s:members){lat+=s.latitude;lon+=s.longitude;counts.put(s.layer,counts.getOrDefault(s.layer,0)+1);}
   lat/=members.size();lon/=members.size();
   double radius=0;for(Signal s:members)radius=Math.max(radius,distanceKm(lat,lon,s.latitude,s.longitude));
   Signal.Layer dom=null;int max=0;for(Map.Entry<Signal.Layer,Integer>e:counts.entrySet())if(e.getValue()>max){dom=e.getKey();max=e.getValue();}
   out.add(new Zone(lat,lon,Math.min(75d,radius),members.size(),counts.size(),dom==null?"UNKNOWN":dom.name()));
   for(Signal s:members)used.add(s.canonicalId);
  }
  out.sort((a,b)->Integer.compare(b.objectCount,a.objectCount));
  return Collections.unmodifiableList(out);
 }
 private static boolean valid(Signal s){return s!=null&&s.canonicalId!=null&&!s.canonicalId.isEmpty()&&s.hasLocation();}
 private static double distanceKm(double a,double b,double c,double d){
  double r=6371.0088,p1=Math.toRadians(a),p2=Math.toRadians(c),dp=Math.toRadians(c-a),dl=Math.toRadians(d-b);
  double h=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);
  return 2*r*Math.asin(Math.min(1d,Math.sqrt(h)));
 }
}
