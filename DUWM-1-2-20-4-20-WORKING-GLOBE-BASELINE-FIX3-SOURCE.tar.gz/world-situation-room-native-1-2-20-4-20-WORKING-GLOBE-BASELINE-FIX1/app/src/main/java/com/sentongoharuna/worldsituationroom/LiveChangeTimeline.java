package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4-7 chronological meaningful-change timeline from LiveChangeRegistry only. */
public final class LiveChangeTimeline {
 public static final class Entry {
  public final LiveChangeRegistry.Kind kind; public final long detectedAtMs; public final String detail;
  Entry(LiveChangeRegistry.Change c){kind=c.kind;detectedAtMs=c.detectedAtMs;detail=c.detail;}
 }
 public static List<Entry> forObject(LiveChangeRegistry registry,String canonicalId,int limit){
  if(registry==null||canonicalId==null||canonicalId.isEmpty())return Collections.emptyList();
  List<LiveChangeRegistry.Change> changes=registry.changesFor(canonicalId);
  ArrayList<Entry> out=new ArrayList<>();
  for(LiveChangeRegistry.Change c:changes){
   if(c==null)continue;
   out.add(new Entry(c)); if(out.size()>=limit)break;
  }
  return Collections.unmodifiableList(out);
 }
 public static String transitionSummary(List<Entry> entries){
  if(entries==null||entries.isEmpty())return "NO MATERIAL CHANGE DETECTED";
  EnumMap<LiveChangeRegistry.Kind,Integer> counts=new EnumMap<>(LiveChangeRegistry.Kind.class);
  for(Entry e:entries)counts.put(e.kind,counts.getOrDefault(e.kind,0)+1);
  StringBuilder b=new StringBuilder();for(Map.Entry<LiveChangeRegistry.Kind,Integer>e:counts.entrySet()){
   if(b.length()>0)b.append(" • ");b.append(e.getKey().name()).append(" ").append(e.getValue());
  }
  return b.toString();
 }
}
