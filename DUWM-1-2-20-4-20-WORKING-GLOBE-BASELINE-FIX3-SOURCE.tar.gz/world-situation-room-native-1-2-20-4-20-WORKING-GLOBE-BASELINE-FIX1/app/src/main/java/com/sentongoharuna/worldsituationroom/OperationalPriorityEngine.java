package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4-15 operational attention priority; never rewrites source severity or asserts danger. */
public final class OperationalPriorityEngine {
 public enum Band { ROUTINE, WATCH, ELEVATED, HIGH_ATTENTION }
 public static final class Result {
  public final Band band; public final int points; public final List<String> reasons;
  Result(Band b,int p,List<String>r){band=b;points=p;reasons=Collections.unmodifiableList(r);}
 }
 public static Result evaluate(Signal s,CanonicalWatchStore watch,LiveChangeRegistry changes,
                               RegionalPriorityEngine.Result region,IncidentFormationEngine.Incident incident){
  if(s==null)return new Result(Band.ROUTINE,0,Collections.singletonList("No current object"));
  int p=0;ArrayList<String>why=new ArrayList<>();
  if(s.freshness!=null&&(s.freshness.state==ObjectFreshness.State.LIVE||s.freshness.state==ObjectFreshness.State.FRESH)){p+=10;why.add("Current provider record");}
  if(watch!=null&&watch.watched(s.canonicalId)){p+=20;why.add("User WATCH identity");}
  List<LiveChangeRegistry.Change> cs=changes==null?Collections.emptyList():changes.changesFor(s.canonicalId);
  if(!cs.isEmpty()){p+=20;why.add("Meaningful detected change");}
  if(region!=null&&region.band==RegionalPriorityEngine.Band.UGANDA){p+=20;why.add("Uganda relevance");}
  else if(region!=null&&region.band==RegionalPriorityEngine.Band.EAST_AFRICA){p+=10;why.add("East Africa relevance");}
  if(incident!=null&&incident.state==IncidentFormationEngine.State.MULTI_SOURCE_RELATED){p+=15;why.add("Multi-source related candidate");}
  if(s.severity>=3){p+=15;why.add("Provider/source severity "+s.severity);}
  p=Math.min(100,p);
  Band b=p>=70?Band.HIGH_ATTENTION:p>=45?Band.ELEVATED:p>=20?Band.WATCH:Band.ROUTINE;
  if(why.isEmpty())why.add("No operational attention factors");
  return new Result(b,p,why);
 }
}
