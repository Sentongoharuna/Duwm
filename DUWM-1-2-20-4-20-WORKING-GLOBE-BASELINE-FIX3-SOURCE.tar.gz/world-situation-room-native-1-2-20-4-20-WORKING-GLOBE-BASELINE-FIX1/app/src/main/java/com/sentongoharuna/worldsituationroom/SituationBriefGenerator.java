package com.sentongoharuna.worldsituationroom;
import java.util.*;
/** 1.2/20/4-17 factual situation brief assembled only from current provider-returned records. */
public final class SituationBriefGenerator {
 public static final class Brief {
  public final String scope; public final int records,providers,liveFresh,changed,watched;
  public final Map<Signal.Layer,Integer> layers; public final List<Signal> newest;
  Brief(String s,int r,int p,int f,int c,int w,Map<Signal.Layer,Integer>l,List<Signal>n){scope=s;records=r;providers=p;liveFresh=f;changed=c;watched=w;layers=Collections.unmodifiableMap(l);newest=Collections.unmodifiableList(n);}
 }
 public static Brief build(String scope,Collection<List<Signal>> all,CanonicalWatchStore watch,LiveChangeRegistry changes,int limit){
  ArrayList<Signal>x=new ArrayList<>();HashSet<String>seen=new HashSet<>(),providers=new HashSet<>();EnumMap<Signal.Layer,Integer>counts=new EnumMap<>(Signal.Layer.class);int fresh=0,changed=0,watched=0;
  if(all!=null)for(List<Signal>list:all)if(list!=null)for(Signal s:list){
   if(s==null||s.canonicalId==null||!seen.add(s.canonicalId)||!inScope(scope,s))continue;
   x.add(s);providers.add(s.providerId);counts.put(s.layer,counts.getOrDefault(s.layer,0)+1);
   if(s.freshness!=null&&(s.freshness.state==ObjectFreshness.State.LIVE||s.freshness.state==ObjectFreshness.State.FRESH))fresh++;
   if(changes!=null&&!changes.changesFor(s.canonicalId).isEmpty())changed++;
   if(watch!=null&&watch.watched(s.canonicalId))watched++;
  }
  x.sort((a,b)->Long.compare(b.timestampMs,a.timestampMs));int total=x.size();if(x.size()>limit)x=new ArrayList<>(x.subList(0,limit));
  return new Brief(scope,total,providers.size(),fresh,changed,watched,new EnumMap<>(counts),x);
 }
 private static boolean inScope(String scope,Signal s){
  if("UGANDA".equals(scope))return RegionalPriorityEngine.evaluate(s).band==RegionalPriorityEngine.Band.UGANDA;
  if("EAST_AFRICA".equals(scope)){RegionalPriorityEngine.Band b=RegionalPriorityEngine.evaluate(s).band;return b==RegionalPriorityEngine.Band.UGANDA||b==RegionalPriorityEngine.Band.EAST_AFRICA;}
  return true;
 }
}