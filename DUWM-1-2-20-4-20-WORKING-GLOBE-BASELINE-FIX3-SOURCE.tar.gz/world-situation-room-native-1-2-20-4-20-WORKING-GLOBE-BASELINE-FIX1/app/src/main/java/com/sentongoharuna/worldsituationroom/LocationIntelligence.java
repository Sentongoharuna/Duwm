package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4-10 factual location snapshot from current located canonical records. */
public final class LocationIntelligence {
 public static final class Snapshot {
  public final double latitude,longitude,radiusKm;
  public final List<Signal> records;
  public final Map<Signal.Layer,Integer> layerCounts;
  public final int providerCount,watchedCount;
  Snapshot(double a,double o,double r,List<Signal>x,Map<Signal.Layer,Integer>lc,int pc,int wc){
   latitude=a;longitude=o;radiusKm=r;records=Collections.unmodifiableList(x);
   layerCounts=Collections.unmodifiableMap(lc);providerCount=pc;watchedCount=wc;
  }
 }
 public static Snapshot around(double lat,double lon,double radiusKm,Collection<List<Signal>> layers,CanonicalWatchStore watch,int limit){
  ArrayList<Signal>x=new ArrayList<>();HashSet<String>seen=new HashSet<>(),providers=new HashSet<>();
  EnumMap<Signal.Layer,Integer>counts=new EnumMap<>(Signal.Layer.class);int watched=0;
  if(layers!=null)for(List<Signal>list:layers)if(list!=null)for(Signal s:list){
   if(s==null||!s.hasLocation()||s.canonicalId==null||!seen.add(s.canonicalId))continue;
   double d=km(lat,lon,s.latitude,s.longitude);if(d>radiusKm)continue;
   x.add(s);providers.add(s.providerId);counts.put(s.layer,counts.getOrDefault(s.layer,0)+1);
   if(watch!=null&&watch.watched(s.canonicalId))watched++;
  }
  x.sort((a,b)->Double.compare(km(lat,lon,a.latitude,a.longitude),km(lat,lon,b.latitude,b.longitude)));
  if(x.size()>limit)x=new ArrayList<>(x.subList(0,limit));
  return new Snapshot(lat,lon,radiusKm,x,new EnumMap<>(counts),providers.size(),watched);
 }
 private static double km(double a,double b,double c,double d){
  double r=6371.0088,p1=Math.toRadians(a),p2=Math.toRadians(c),dp=Math.toRadians(c-a),dl=Math.toRadians(d-b);
  double h=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);
  return 2*r*Math.asin(Math.min(1d,Math.sqrt(h)));
 }
}
