package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4-1 detects factual cross-refresh changes by canonical identity. */
public final class LiveChangeRegistry {
 public enum Kind { APPEARED, MOVED, HEADING_CHANGED, SPEED_CHANGED, SEVERITY_CHANGED, STATE_CHANGED, UPDATED, DISAPPEARED }
 public static final class Change {
  public final String canonicalId;
  public final Kind kind;
  public final long detectedAtMs;
  public final String detail;
  Change(String id,Kind k,long at,String d){canonicalId=id;kind=k;detectedAtMs=at;detail=d;}
 }
 private static final class Snapshot {
  final double lat,lon,heading,speed; final int severity; final long providerTime; final String freshness;
  Snapshot(Signal s){
   lat=s.latitude;lon=s.longitude;heading=s.heading;speed=s.speedMetersPerSecond;severity=s.severity;
   providerTime=s.timestampChain==null?s.timestampMs:s.timestampChain.providerTimeMs;
   freshness=s.freshness==null?"UNKNOWN":s.freshness.state.name();
  }
 }
 private final EnumMap<Signal.Layer,LinkedHashMap<String,Snapshot>> previous=new EnumMap<>(Signal.Layer.class);
 private final LinkedHashMap<String,ArrayDeque<Change>> history=new LinkedHashMap<>(128,0.75f,true);
 public synchronized List<Change> accept(Signal.Layer layer,List<Signal> current,long now){
  LinkedHashMap<String,Snapshot> before=previous.get(layer);
  LinkedHashMap<String,Snapshot> next=new LinkedHashMap<>();
  ArrayList<Change> out=new ArrayList<>();
  if(current!=null)for(Signal s:current){
   if(s==null||s.canonicalId==null||s.canonicalId.isEmpty())continue;
   Snapshot n=new Snapshot(s);next.put(s.canonicalId,n);
   Snapshot o=before==null?null:before.get(s.canonicalId);
   if(o==null){
    if(before!=null)add(out,new Change(s.canonicalId,Kind.APPEARED,now,"New provider record in current refresh"));
    continue;
   }
   if(moved(o,n))add(out,new Change(s.canonicalId,Kind.MOVED,now,
     String.format(Locale.US,"%.1f km observed displacement",distanceKm(o.lat,o.lon,n.lat,n.lon))));
   if(finite(o.heading)&&finite(n.heading)&&angle(o.heading,n.heading)>=12d)
    add(out,new Change(s.canonicalId,Kind.HEADING_CHANGED,now,
      String.format(Locale.US,"Heading %.0f° → %.0f°",o.heading,n.heading)));
   if(finite(o.speed)&&finite(n.speed)&&Math.abs(n.speed-o.speed)>=5d)
    add(out,new Change(s.canonicalId,Kind.SPEED_CHANGED,now,
      String.format(Locale.US,"Speed %.1f → %.1f m/s",o.speed,n.speed)));
   if(o.severity!=n.severity)add(out,new Change(s.canonicalId,Kind.SEVERITY_CHANGED,now,
      "Severity "+o.severity+" → "+n.severity));
   if(!o.freshness.equals(n.freshness))add(out,new Change(s.canonicalId,Kind.STATE_CHANGED,now,
      "Freshness "+o.freshness+" → "+n.freshness));
   if(n.providerTime>o.providerTime)add(out,new Change(s.canonicalId,Kind.UPDATED,now,
      "Provider observation advanced"));
  }
  if(before!=null)for(String id:before.keySet())if(!next.containsKey(id))
    add(out,new Change(id,Kind.DISAPPEARED,now,"Absent from current provider refresh"));
  previous.put(layer,next);
  return Collections.unmodifiableList(out);
 }
 private void add(List<Change>out,Change c){
  out.add(c);ArrayDeque<Change>h=history.get(c.canonicalId);
  if(h==null){h=new ArrayDeque<>();history.put(c.canonicalId,h);}
  h.addLast(c);while(h.size()>32)h.removeFirst();
  while(history.size()>1024){Iterator<String>i=history.keySet().iterator();if(!i.hasNext())break;i.next();i.remove();}
 }
 public synchronized List<Change> changesFor(String id){
  ArrayDeque<Change>h=history.get(id);if(h==null)return Collections.emptyList();
  ArrayList<Change>o=new ArrayList<>(h);Collections.reverse(o);return o;
 }
 private static boolean moved(Snapshot a,Snapshot b){
  return finite(a.lat)&&finite(a.lon)&&finite(b.lat)&&finite(b.lon)&&distanceKm(a.lat,a.lon,b.lat,b.lon)>=0.25d;
 }
 private static boolean finite(double v){return Double.isFinite(v);}
 private static double angle(double a,double b){double d=Math.abs(a-b)%360d;return d>180d?360d-d:d;}
 private static double distanceKm(double a,double b,double c,double d){
  double r=6371.0088, p1=Math.toRadians(a),p2=Math.toRadians(c),dp=Math.toRadians(c-a),dl=Math.toRadians(d-b);
  double h=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);
  return 2*r*Math.asin(Math.min(1d,Math.sqrt(h)));
 }
}
