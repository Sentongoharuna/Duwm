package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4-14 meaningful changes for watched canonical identities only. */
public final class WatchChangeDetection {
 public static final class Item {
  public final CanonicalWatchStore.Watch watch; public final Signal current;
  public final LiveChangeRegistry.Change latest; public final int totalChanges;
  Item(CanonicalWatchStore.Watch w,Signal s,LiveChangeRegistry.Change c,int n){watch=w;current=s;latest=c;totalChanges=n;}
 }
 public static List<Item> build(CanonicalWatchStore store,Collection<List<Signal>> layers,LiveChangeRegistry registry,int limit){
  if(store==null||registry==null)return Collections.emptyList();
  LinkedHashMap<String,Signal> current=new LinkedHashMap<>();
  if(layers!=null)for(List<Signal>list:layers)if(list!=null)for(Signal s:list)
    if(s!=null&&s.canonicalId!=null)current.put(s.canonicalId,s);
  ArrayList<Item> out=new ArrayList<>();
  for(CanonicalWatchStore.Watch w:store.all()){
   List<LiveChangeRegistry.Change> changes=registry.changesFor(w.canonicalId);
   if(changes.isEmpty())continue;
   out.add(new Item(w,current.get(w.canonicalId),changes.get(0),changes.size()));
  }
  out.sort((a,b)->Long.compare(b.latest.detectedAtMs,a.latest.detectedAtMs));
  if(out.size()>limit)out=new ArrayList<>(out.subList(0,limit));
  return Collections.unmodifiableList(out);
 }
 public static String state(Item i){
  if(i==null)return "UNKNOWN";
  if(i.current==null)return "CURRENT RECORD MISSING";
  return i.current.freshness==null?"UNKNOWN":i.current.freshness.state.name();
 }
}
