package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4-4 evidence-preserving incident candidate formation. */
public final class IncidentFormationEngine {
 public enum State { SINGLE_SOURCE, MULTI_SOURCE_RELATED }
 public static final class Incident {
  public final String incidentId; public final State state;
  public final double latitude,longitude,radiusKm;
  public final List<Signal> records; public final int providerCount,layerCount;
  Incident(String id,State s,double a,double o,double r,List<Signal>x,int pc,int lc){
   incidentId=id;state=s;latitude=a;longitude=o;radiusKm=r;records=Collections.unmodifiableList(x);providerCount=pc;layerCount=lc;
  }
 }
 public static List<Incident> form(Collection<List<Signal>> layers){
  ArrayList<Signal> all=new ArrayList<>();
  if(layers!=null)for(List<Signal> list:layers)if(list!=null)for(Signal s:list)if(s!=null&&s.hasLocation())all.add(s);
  LinkedHashMap<String,ArrayList<Signal>> groups=new LinkedHashMap<>();
  for(Signal s:all){
   String key=s.relationshipId==null||s.relationshipId.isEmpty()?s.canonicalId:s.relationshipId;
   groups.computeIfAbsent(key,k->new ArrayList<>()).add(s);
  }
  ArrayList<Incident> out=new ArrayList<>();
  for(Map.Entry<String,ArrayList<Signal>>e:groups.entrySet()){
   ArrayList<Signal>x=e.getValue(); if(x.isEmpty())continue;
   LinkedHashSet<String> providers=new LinkedHashSet<>();EnumSet<Signal.Layer> ls=EnumSet.noneOf(Signal.Layer.class);
   double lat=0,lon=0;for(Signal s:x){providers.add(s.providerId);ls.add(s.layer);lat+=s.latitude;lon+=s.longitude;}
   lat/=x.size();lon/=x.size();double radius=0;for(Signal s:x)radius=Math.max(radius,km(lat,lon,s.latitude,s.longitude));
   State st=(providers.size()>=2||ls.size()>=2)?State.MULTI_SOURCE_RELATED:State.SINGLE_SOURCE;
   out.add(new Incident("incident:"+e.getKey(),st,lat,lon,radius,new ArrayList<>(x),providers.size(),ls.size()));
  }
  out.sort((a,b)->Integer.compare(b.records.size(),a.records.size()));return Collections.unmodifiableList(out);
 }
 public static Incident forObject(List<Incident> incidents,String canonicalId){
  if(incidents==null||canonicalId==null)return null;
  for(Incident i:incidents)for(Signal s:i.records)if(canonicalId.equals(s.canonicalId))return i;return null;
 }
 private static double km(double a,double b,double c,double d){
  double r=6371.0088,p1=Math.toRadians(a),p2=Math.toRadians(c),dp=Math.toRadians(c-a),dl=Math.toRadians(d-b);
  double h=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);
  return 2*r*Math.asin(Math.min(1d,Math.sqrt(h)));
 }
}
