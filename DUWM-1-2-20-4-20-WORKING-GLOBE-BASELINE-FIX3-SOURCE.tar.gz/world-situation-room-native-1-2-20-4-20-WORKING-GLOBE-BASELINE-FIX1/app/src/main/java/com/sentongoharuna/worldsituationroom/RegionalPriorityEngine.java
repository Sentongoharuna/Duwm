package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4-5 geographic relevance for Uganda/East Africa; relevance is not severity or confirmation. */
public final class RegionalPriorityEngine {
 public enum Band { UGANDA, EAST_AFRICA, GLOBAL }
 public static final class Result {
  public final Band band; public final int relevance; public final String reason;
  Result(Band b,int r,String why){band=b;relevance=r;reason=why;}
 }
 public static Result evaluate(Signal s){
  if(s==null)return new Result(Band.GLOBAL,0,"No object");
  if(s.hasLocation()){
   if(inUganda(s.latitude,s.longitude))return new Result(Band.UGANDA,100,"Observed coordinates inside Uganda bounds");
   if(inEastAfrica(s.latitude,s.longitude))return new Result(Band.EAST_AFRICA,70,"Observed coordinates inside East Africa bounds");
  }
  String text=(s.region+" "+s.title+" "+s.summary).toLowerCase(Locale.ROOT);
  if(has(text,"uganda","kampala","entebbe","jinja","mbarara","gulu","mbale","masaka","arua","lira","soroti","kabale","hoima","kasese","moroto","fort portal"))
   return new Result(Band.UGANDA,85,"Provider text names a controlled Uganda place");
  if(has(text,"kenya","nairobi","mombasa","kisumu","tanzania","dar es salaam","arusha","rwanda","kigali","burundi","bujumbura","south sudan","juba"))
   return new Result(Band.EAST_AFRICA,60,"Provider text names a controlled East Africa place");
  return new Result(Band.GLOBAL,10,"Global object; no Uganda/East Africa relevance detected");
 }
 private static boolean inUganda(double a,double o){return a>=-1.6&&a<=4.3&&o>=29.4&&o<=35.1;}
 private static boolean inEastAfrica(double a,double o){return a>=-12.5&&a<=12.5&&o>=28.0&&o<=52.0;}
 private static boolean has(String text,String... terms){for(String t:terms)if(text.contains(t))return true;return false;}
}
