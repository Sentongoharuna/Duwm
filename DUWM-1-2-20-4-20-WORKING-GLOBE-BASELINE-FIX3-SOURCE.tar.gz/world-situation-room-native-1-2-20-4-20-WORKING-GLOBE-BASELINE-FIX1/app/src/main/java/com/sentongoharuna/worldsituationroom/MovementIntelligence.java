package com.sentongoharuna.worldsituationroom;
import java.util.*;

/** 1.2/20/4-2 movement intelligence from consecutive observed provider fixes only. */
public final class MovementIntelligence {
 public static final class State {
  public final boolean available;
  public final double distanceKm,bearingDeg,derivedSpeedMps;
  public final long elapsedMs,fromProviderMs,toProviderMs;
  public final String direction;
  State(boolean a,double d,double b,double s,long e,long f,long t,String dir){
   available=a;distanceKm=d;bearingDeg=b;derivedSpeedMps=s;elapsedMs=e;fromProviderMs=f;toProviderMs=t;direction=dir;
  }
 }
 public static State from(List<CanonicalTimelineRegistry.Entry> newestFirst){
  if(newestFirst==null||newestFirst.size()<2)return unavailable();
  CanonicalTimelineRegistry.Entry to=newestFirst.get(0),from=null;
  for(int i=1;i<newestFirst.size();i++){
   CanonicalTimelineRegistry.Entry e=newestFirst.get(i);
   if(valid(e)&&valid(to)&&e.providerTimeMs<to.providerTimeMs){from=e;break;}
  }
  if(from==null)return unavailable();
  long dt=to.providerTimeMs-from.providerTimeMs;
  if(dt<=0L)return unavailable();
  double km=distanceKm(from.latitude,from.longitude,to.latitude,to.longitude);
  double bearing=bearing(from.latitude,from.longitude,to.latitude,to.longitude);
  double speed=(km*1000d)/(dt/1000d);
  return new State(true,km,bearing,speed,dt,from.providerTimeMs,to.providerTimeMs,compass(bearing));
 }
 private static State unavailable(){return new State(false,Double.NaN,Double.NaN,Double.NaN,0L,0L,0L,"UNKNOWN");}
 private static boolean valid(CanonicalTimelineRegistry.Entry e){
  return e!=null&&Double.isFinite(e.latitude)&&Double.isFinite(e.longitude)&&e.latitude>=-90&&e.latitude<=90&&e.longitude>=-180&&e.longitude<=180;
 }
 private static double distanceKm(double a,double b,double c,double d){
  double r=6371.0088,p1=Math.toRadians(a),p2=Math.toRadians(c),dp=Math.toRadians(c-a),dl=Math.toRadians(d-b);
  double h=Math.sin(dp/2)*Math.sin(dp/2)+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)*Math.sin(dl/2);
  return 2*r*Math.asin(Math.min(1d,Math.sqrt(h)));
 }
 private static double bearing(double a,double b,double c,double d){
  double p1=Math.toRadians(a),p2=Math.toRadians(c),dl=Math.toRadians(d-b);
  double y=Math.sin(dl)*Math.cos(p2),x=Math.cos(p1)*Math.sin(p2)-Math.sin(p1)*Math.cos(p2)*Math.cos(dl);
  return (Math.toDegrees(Math.atan2(y,x))+360d)%360d;
 }
 private static String compass(double b){
  String[] p={"N","NE","E","SE","S","SW","W","NW"};
  return p[((int)Math.floor((b+22.5d)/45d))%8];
 }
}
