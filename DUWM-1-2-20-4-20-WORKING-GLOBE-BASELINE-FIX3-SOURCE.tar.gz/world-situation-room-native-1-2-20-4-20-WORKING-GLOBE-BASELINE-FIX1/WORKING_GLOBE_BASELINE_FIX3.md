FIX3 hardens the cumulative baseline gate after the FIX2 run reached and printed
4-10 LOCATION INTELLIGENCE PASS but the GitHub step still returned exit 1.

Changes:
- project path is passed to every child verifier;
- every child verifier is checked explicitly;
- an actual failing verifier is named with its exit code;
- successful completion exits 0 explicitly;
- Android app source is otherwise preserved.
