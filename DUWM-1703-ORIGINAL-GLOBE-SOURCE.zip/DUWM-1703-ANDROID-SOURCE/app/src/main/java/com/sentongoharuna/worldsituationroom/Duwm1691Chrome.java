package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Typeface;
import android.widget.TextView;

/** Styles existing native page headers in place. No duplicate dashboard, globe or feed. */
public final class Duwm1691Chrome {
    private Duwm1691Chrome(){}
    public static TextView title(TextView t){
        Context c=t.getContext();float d=c.getResources().getDisplayMetrics().density;
        GradientDrawable surface=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{0xFF163E4C,0xFF102735,0xFF091F2B});
        surface.setCornerRadius(11*d);surface.setStroke(Math.max(1,(int)d),0xFF357482);
        t.setBackground(surface);t.setPadding(Math.round(12*d),Math.round(8*d),Math.round(10*d),Math.round(8*d));
        t.setTextColor(0xFFECF9FA);t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        t.setMinHeight(Math.round(53*d));return t;
    }
}
