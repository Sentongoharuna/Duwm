package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;
import java.util.Locale;

/** 1691 rebuild of the EXISTING 1690 evidence panel. Inputs are real source cache
 * counts passed from existing native pages; independent categories MUST NOT be summed
 * into a fabricated total or called percentages of worldwide activity. */
public final class Duwm1690EvidenceBars extends View {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final String[] labels=new String[4];
    private final long[] counts=new long[4];
    private final int[] accents={0xFF6FE2E4,0xFF8CDFC3,0xFF91CAE8,0xFF8E9FE3};
    private String heading="SOURCE SAMPLE";private boolean rowMode=false;
    private final float density;
    public Duwm1690EvidenceBars(Context c){super(c);density=getResources().getDisplayMetrics().density;
        rowMode=c.getSharedPreferences("duwm1693_presentation",Context.MODE_PRIVATE).getBoolean("receipt_ranked_bars",false);
        setOnClickListener(v->{rowMode=!rowMode;
            getContext().getSharedPreferences("duwm1693_presentation",Context.MODE_PRIVATE).edit().putBoolean("receipt_ranked_bars",rowMode).apply();invalidate();});
        setOnLongClickListener(v->{StringBuilder report=new StringBuilder("DUWM 1700 / ").append(heading);
            for(int i=0;i<counts.length;i++)report.append('\n').append(labels[i]).append(": ").append(counts[i]);
            android.content.ClipboardManager clip=(android.content.ClipboardManager)getContext().getSystemService(Context.CLIPBOARD_SERVICE);
            if(clip!=null)clip.setPrimaryClip(android.content.ClipData.newPlainText("Source-backed counts",report.toString()));
            android.widget.Toast.makeText(getContext(),"Actual source counts copied",android.widget.Toast.LENGTH_SHORT).show();return true;});
        setValues("SOURCE SAMPLE",new String[]{"RECEIVED","MATCHED","DATED","SELECTED"},new long[]{0,0,0,0});}
    public void setValues(String title,String[] categories,long[] values){
        heading=(title==null||title.isEmpty())?"RECEIVED SOURCE DATA":title;
        StringBuilder description=new StringBuilder(heading).append(". Local provider sample. ");
        for(int i=0;i<4;i++){
            labels[i]=(categories!=null&&i<categories.length&&categories[i]!=null)?categories[i]:"RECORDS";
            counts[i]=Math.max(0,values!=null&&i<values.length?values[i]:0);
            description.append(labels[i]).append(' ').append(counts[i]).append(". ");
        }
        setContentDescription(description.append(" Tap to switch between actual count tiles and a relative bar view.").toString());invalidate();
    }
    private long maxCount(){long max=0;for(long n:counts)max=Math.max(max,n);return max;}
    private float d(float x){return x*density;}
    private void fill(int color){p.setColor(color);p.setStyle(Paint.Style.FILL);p.setStrokeWidth(1f);}
    private void label(Canvas c,String text,float x,float baseline,float maxWidth,int size,int color,boolean bold){
        fill(color);p.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",Typeface.NORMAL));p.setTextSize(d(size));
        String shown=text==null?"":text;
        while(shown.length()>3&&p.measureText(shown)>maxWidth)shown=shown.substring(0,shown.length()-2)+"…";
        c.drawText(shown,x,baseline,p);
    }
    @Override protected void onDraw(Canvas c){super.onDraw(c);
        float w=getWidth(),h=getHeight();if(w<d(190)||h<d(156))return;
        float pad=d(10),gap=d(7),head=d(51),cw=(w-2*pad-gap)/2f;
        float ch=(h-head-pad-gap)/2f;
        fill(0xFF0C2430);c.drawRoundRect(new RectF(0,0,w,h),d(13),d(13),p);
        fill(0xFF45CDCF);c.drawRoundRect(new RectF(d(10),d(9),d(13),d(33)),d(2),d(2),p);
        label(c,heading,d(21),d(23),w-d(32),12,0xFFE5F5F7,true);
        label(c,rowMode?"RANKED RECEIVED COUNTS  •  TAP FOR COUNT CARDS":"EXACT SOURCE COUNTS  •  TAP TO RANK",d(21),d(39),w-d(32),9,0xFF91B9C4,false);
        if(maxCount()==0){
            fill(0xFF173E49);c.drawRoundRect(new RectF(d(10),d(52),w-d(10),h-d(9)),d(10),d(10),p);
            label(c,"NO RECORDS IN THIS VIEW",d(23),d(87),w-d(45),14,0xFFD2E6EA,true);
            label(c,"Zero is not evidence of zero real-world activity",d(23),d(115),w-d(45),10,0xFF93B9C2,false);
            label(c,"Refresh a provider, then inspect its receipt time",d(23),d(141),w-d(45),10,0xFF93B9C2,false);
            return;
        }
        long max=0;for(long n:counts)max=Math.max(max,n);
        if(rowMode){
            int[] rank={0,1,2,3};
            for(int i=0;i<4;i++)for(int j=i+1;j<4;j++)if(counts[rank[j]]>counts[rank[i]]){
                int tmp=rank[i];rank[i]=rank[j];rank[j]=tmp;}
            float rowHeight=(h-head-pad)/4f;
            for(int row=0;row<4;row++){int k=rank[row];
                float y=head+row*rowHeight,x=pad,barX=x+d(9),barW=w-2*pad-d(18);
                fill(0xFF143443);c.drawRoundRect(new RectF(x,y,x+w-2*pad,y+rowHeight-d(5)),d(7),d(7),p);
                label(c,labels[k],barX,y+d(15),barW-d(65),10,0xFFB2D0D7,true);
                label(c,String.format(Locale.US,"%,d",counts[k]),w-pad-d(61),y+d(15),d(55),12,0xFFF0FCFC,true);
                fill(0xFF254A59);c.drawRoundRect(new RectF(barX,y+d(23),barX+barW,y+d(31)),d(3),d(3),p);
                if(max>0&&counts[k]>0){fill(accents[k]);
                    c.drawRoundRect(new RectF(barX,y+d(23),barX+Math.max(d(3),barW*counts[k]/(float)max),y+d(31)),d(3),d(3),p);}
            }
            return;
        }
        for(int k=0;k<4;k++){
            int r=k/2,col=k%2;float x=pad+(cw+gap)*col,y=head+(ch+gap)*r;
            fill(0xFF153849);c.drawRoundRect(new RectF(x,y,x+cw,y+ch),d(10),d(10),p);
            fill(accents[k]);c.drawRoundRect(new RectF(x+d(9),y+d(10),x+d(12),y+d(24)),d(2),d(2),p);
            String number=String.format(Locale.US,"%,d",counts[k]);
            label(c,number,x+d(19),y+d(33),cw-d(30),22,0xFFF0FCFC,true);
            label(c,labels[k],x+d(10),y+d(51),cw-d(19),9,0xFFB2D0D7,true);
            float yBar=y+ch-d(13),barX=x+d(10),barW=cw-d(20);
            fill(0xFF244B58);c.drawRoundRect(new RectF(barX,yBar,barX+barW,yBar+d(4)),d(2),d(2),p);
            if(max>0&&counts[k]>0){fill(accents[k]);float width=Math.max(d(3),barW*(counts[k]/(float)max));
                c.drawRoundRect(new RectF(barX,yBar,barX+width,yBar+d(4)),d(2),d(2),p);}
        }
    }
}
