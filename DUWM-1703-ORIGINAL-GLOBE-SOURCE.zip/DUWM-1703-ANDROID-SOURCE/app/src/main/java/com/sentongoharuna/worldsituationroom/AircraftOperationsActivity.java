package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Operational aircraft register. Only observed, timestamped data; no extrapolation. */
public final class AircraftOperationsActivity extends Activity {
    private static final int BG=0xFF081824,PANEL=0xFF081824,BORDER=0xFF185769,INK=0xFFDAE9ED,
                             MUTED=0xFF678E96,CYAN=0xFF39B5C3,WARN=0xFF47D2DB;
    private static final long REQUERY_MS=125000L;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final AtomicBoolean busy=new AtomicBoolean(false);
    private TextView source,metrics,notice,sortButton,showMore;
    private EditText search;
    private LinearLayout items;
    private AirTrackStore.Snapshot current;
    private long lastTry=-REQUERY_MS;
    private int sortMode=0,pageSize=80,altitudeBand=0;private boolean airborneOnly=false,recentContactOnly=false;private TextView filterState;
    private String failure="";
    private int dp(float d){return Math.round(d*getResources().getDisplayMetrics().density);}
    private TextView text(String s,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);
        t.setTextColor(color);t.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",Typeface.NORMAL));return t;}
    private GradientDrawable shape(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(8));d.setStroke(dp(1),BORDER);return d;}
    private TextView click(String s){TextView t=text(s,13,CYAN,true);t.setGravity(Gravity.CENTER);
        t.setBackground(shape(PANEL));t.setPadding(dp(8),dp(10),dp(8),dp(10));return t;}
    private void line(LinearLayout root,View v,int height){root.addView(v,new LinearLayout.LayoutParams(-1,height<0?height:dp(height)));}
    private String utc(long seconds){if(seconds<=0)return "NOT SUPPLIED";
        return Duwm1674TimeGuard.utc(seconds);}
    private String age(long seconds){if(seconds<=0)return "unknown age";
        long dt=Math.max(0,System.currentTimeMillis()/1000L-seconds);
        return dt<60?dt+" sec ago":dt<3600?(dt/60)+" min ago":(dt/3600)+" hr ago";}
    private String num(double v,String unit,int decimals){return Double.isFinite(v)?String.format(Locale.US,"%."+decimals+"f %s",v,unit):"not reported";}
    private void gap(LinearLayout l,int h){View v=new View(this);line(l,v,h);}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(14),dp(8),dp(14),dp(8));root.setBackgroundColor(BG);setContentView(root);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);line(root,top,59);
        TextView back=click("‹  EARTH");top.addView(back,new LinearLayout.LayoutParams(dp(75),dp(45)));
        back.setOnClickListener(v->finish());
        LinearLayout names=new LinearLayout(this);names.setOrientation(LinearLayout.VERTICAL);names.setPadding(dp(12),0,0,0);top.addView(names,new LinearLayout.LayoutParams(0,-2,1));
        names.addView(text("AIRCRAFT  /  RECEIVED TRACKS",18,INK,true));names.addView(text("OBSERVED POSITIONS  •  SOURCE TIMES",10,MUTED,true));
        TextView map=click("MAP");top.addView(map,new LinearLayout.LayoutParams(dp(62),dp(45)));
        map.setContentDescription("Open the existing received-aircraft geographic map");
        map.setOnClickListener(v->startActivity(new Intent(this,Duwm1670FlightMapActivity.class)));
        source=text("CHECKING SOURCE",12,CYAN,true);source.setPadding(dp(2),dp(14),dp(2),dp(8));line(root,source,-2);
        metrics=text("No received aircraft snapshot yet",12,MUTED,false);line(root,metrics,-2);
        notice=text("OpenSky receiver coverage is not worldwide flight coverage. No estimates, interpolated tracks or fake counts.",12,MUTED,false);
        final String sourceCoverage=notice.getText().toString();
        notice.setText("OPENSKY RECEIVER COVERAGE  ▸  TAP FOR LIMITATIONS");
        notice.setOnClickListener(v->{boolean expanded=notice.getText().toString().equals(sourceCoverage);
            notice.setText(expanded?"OPENSKY RECEIVER COVERAGE  ▸  TAP FOR LIMITATIONS":sourceCoverage);});
        notice.setPadding(0,dp(6),0,dp(9));line(root,notice,-2);
        LinearLayout query=new LinearLayout(this);query.setGravity(Gravity.CENTER_VERTICAL);line(root,query,56);
        search=new EditText(this);search.setSingleLine(true);search.setTextSize(14);search.setTextColor(INK);search.setHintTextColor(MUTED);
        search.setHint("Search callsign, ICAO24 or country");search.setBackground(shape(PANEL));search.setPadding(dp(10),0,dp(9),0);
        LinearLayout.LayoutParams qlp=new LinearLayout.LayoutParams(0,dp(49),1);qlp.rightMargin=dp(8);query.addView(search,qlp);
        TextView refresh=click("REFRESH");query.addView(refresh,new LinearLayout.LayoutParams(dp(92),dp(49)));refresh.setOnClickListener(v->fetch(true));
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){pageSize=80;render();}
            public void afterTextChanged(Editable e){} });
        LinearLayout toolbar=new LinearLayout(this);toolbar.setGravity(Gravity.CENTER_VERTICAL);line(root,toolbar,52);
        TextView label=text("RECEIVED FLIGHT RECORDS",11,MUTED,true);toolbar.addView(label,new LinearLayout.LayoutParams(0,-2,1));
        sortButton=click("SORT: RECENT");toolbar.addView(sortButton,new LinearLayout.LayoutParams(dp(150),dp(40)));
        sortButton.setOnClickListener(v->{sortMode=(sortMode+1)%4;render();});
        TextView locateLatest=click("LOCATE NEWEST MATCH ON ORIGINAL GLOBE  ◎");
        locateLatest.setContentDescription("Focus the original globe on the latest reported aircraft matching current filters");
        line(root,locateLatest,45);
        locateLatest.setOnClickListener(v->focusLatestObservedAircraft());
        TextView filterToggle=click("FILTERS  ▸");line(root,filterToggle,40);
        LinearLayout flightFilters=new LinearLayout(this);flightFilters.setOrientation(LinearLayout.VERTICAL);line(root,flightFilters,-2);
        flightFilters.setVisibility(View.GONE);
        filterToggle.setOnClickListener(v->{boolean open=flightFilters.getVisibility()!=View.VISIBLE;
            flightFilters.setVisibility(open?View.VISIBLE:View.GONE);
            filterToggle.setText(open?"HIDE FILTERS  ▴":"FILTERS  ▸");});
        LinearLayout stateRow=new LinearLayout(this);stateRow.setGravity(Gravity.CENTER_VERTICAL);
        flightFilters.addView(stateRow,new LinearLayout.LayoutParams(-1,dp(47)));
        TextView airborne=click("ALL FLIGHT STATES");stateRow.addView(airborne,new LinearLayout.LayoutParams(0,dp(44),1));
        TextView recent=click("ALL CONTACT AGES");LinearLayout.LayoutParams ageLp=new LinearLayout.LayoutParams(0,dp(44),1);ageLp.leftMargin=dp(7);stateRow.addView(recent,ageLp);
        airborne.setOnClickListener(v->{airborneOnly=!airborneOnly;pageSize=80;airborne.setText(airborneOnly?"AIRBORNE ONLY":"ALL FLIGHT STATES");render();});
        recent.setOnClickListener(v->{recentContactOnly=!recentContactOnly;pageSize=80;recent.setText(recentContactOnly?"CONTACT ≤ 5 MIN":"ALL CONTACT AGES");render();});
        TextView altitude=click("ALTITUDE / ALL RECEIVED");
        altitude.setContentDescription("Filter aircraft using reported barometric altitude: all, below ten thousand feet, above thirty thousand feet");
        flightFilters.addView(altitude,new LinearLayout.LayoutParams(-1,dp(44)));
        altitude.setOnClickListener(v->{altitudeBand=(altitudeBand+1)%3;pageSize=80;
            altitude.setText(altitudeBand==1?"ALTITUDE / BELOW 10,000 FT":altitudeBand==2?"ALTITUDE / ABOVE 30,000 FT":"ALTITUDE / ALL RECEIVED");
            render();});
        filterState=text("CURRENT FILTER / NO RECORDS",11,CYAN,true);filterState.setPadding(dp(2),dp(6),dp(2),dp(5));line(root,filterState,-2);
        ScrollView scroll=new ScrollView(this);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        items=new LinearLayout(this);items.setOrientation(LinearLayout.VERTICAL);scroll.addView(items);
        showMore=click("SHOW MORE OBSERVED RECORDS");line(root,showMore,48);
        TextView reset=click("RESET SEARCH / FILTERS");reset.setContentDescription("Reset aircraft search, sort and contact filters");
        LinearLayout.LayoutParams resetLp=new LinearLayout.LayoutParams(-1,dp(44));resetLp.topMargin=dp(4);
        flightFilters.addView(reset,resetLp);
        reset.setOnClickListener(v->{search.setText("");airborneOnly=false;recentContactOnly=false;altitudeBand=0;altitude.setText("ALTITUDE / ALL RECEIVED");sortMode=0;pageSize=80;
            airborne.setText("ALL FLIGHT STATES");recent.setText("ALL CONTACT AGES");render();});
        showMore.setVisibility(View.GONE);showMore.setOnClickListener(v->{pageSize=Math.min(1000,pageSize+80);render();});
        current=AirTrackStore.current();
        String initial=getIntent()==null?null:getIntent().getStringExtra("query");
        if(initial!=null&&!initial.trim().isEmpty())search.setText(initial.trim());
        render();if(current==null||System.currentTimeMillis()-current.receivedAtMillis>120000L)fetch(false);
        ui.postDelayed(()->{if(!isFinishing()&&!isDestroyed()){
            AirTrackStore.Snapshot latest=AirTrackStore.current();
            if(latest!=null&&latest!=current){current=latest;render();}
        }},3500);
    }
    private void render(){if(items==null)return;items.removeAllViews();
        AirTrackStore.Snapshot snap=current;
        String sortLabel=new String[]{"SORT: RECENT","SORT: CALLSIGN","SORT: ALTITUDE","SORT: SPEED"}[sortMode];sortButton.setText(sortLabel);
        if(snap==null){source.setText("SOURCE: NO REPORT RECEIVED");source.setTextColor(WARN);metrics.setText("0 records available; provider may be unavailable.");
            items.addView(message(failure.isEmpty()?"Waiting for the first provider response. Tap REFRESH if required.":"Connection issue: "+failure));if(filterState!=null)filterState.setText("NO PROVIDER POSITIONS RECEIVED");
            showMore.setVisibility(View.GONE);return;}
        boolean stale=snap.sourceTimeSec<=0 || Math.abs(System.currentTimeMillis()/1000L-snap.sourceTimeSec)>180;
        source.setText((stale?"LAST REPORTED — ":"SOURCE OBSERVATION — ")+utc(snap.sourceTimeSec));source.setTextColor(stale?WARN:CYAN);
        String sub=String.format(Locale.US,"%,d positions available · %,d received · %,d missing/invalid positions",snap.records.size(),snap.reportedCount,snap.rejectedUnlocated);
        if(!failure.isEmpty())sub+="  |  Latest request failed: "+failure;
        metrics.setText(sub);
        String query=search.getText().toString().toLowerCase(Locale.US).trim();
        List<AirTrackStore.Flight> filtered=new ArrayList<>();
        long nowSec=System.currentTimeMillis()/1000L;
        for(AirTrackStore.Flight f:snap.records){
            if(airborneOnly&&f.ground)continue;
            if(altitudeBand!=0 && (!Double.isFinite(f.altMeters) ||
                (altitudeBand==1 && f.altMeters>=3048.0d) ||
                (altitudeBand==2 && f.altMeters<9144.0d)))continue;
            if(recentContactOnly&&(f.lastContactSec<=0L||f.lastContactSec>nowSec+60L||nowSec-f.lastContactSec>300L))continue;
            if(!query.isEmpty()&&!f.callsign.toLowerCase(Locale.US).contains(query)
               &&!f.icao24.toLowerCase(Locale.US).contains(query)&&!f.origin.toLowerCase(Locale.US).contains(query))continue;
            filtered.add(f);}
        switch(sortMode){
            case 1:Collections.sort(filtered,(a,b)->a.display().compareToIgnoreCase(b.display()));break;
            case 2:Collections.sort(filtered,(a,b)->Double.compare(finite(b.altMeters),finite(a.altMeters)));break;
            case 3:Collections.sort(filtered,(a,b)->Double.compare(finite(b.velocityMs),finite(a.velocityMs)));break;
            default:Collections.sort(filtered,(a,b)->Long.compare(b.lastContactSec,a.lastContactSec));
        }
        if(filterState!=null)filterState.setText("MATCHING "+filtered.size()+" / "+snap.records.size()+" ACTUAL POSITIONS"+
            (airborneOnly?"  •  AIRBORNE":"")+(recentContactOnly?"  •  CONTACT ≤ 5 MIN":"")+(altitudeBand==1?"  •  BELOW 10K FT":altitudeBand==2?"  •  ABOVE 30K FT":"")+
            "  •  SOURCE "+utc(snap.sourceTimeSec));
        int max=Math.min(pageSize,filtered.size());
        if(max==0)items.addView(message("No received aircraft match this search. This does not mean no aircraft are operating."));
        for(int i=0;i<max;i++)addFlight(items,filtered.get(i));
        showMore.setVisibility(filtered.size()>max?View.VISIBLE:View.GONE);
        showMore.setText("SHOW MORE   "+max+" / "+filtered.size());
    }
    /** Never invent a track: place a focus marker only on a received state vector. */
    private void focusLatestObservedAircraft(){
        AirTrackStore.Snapshot snap=current;
        if(snap==null||snap.records.isEmpty()){
            notice.setText("NO RECEIVED AIRCRAFT POSITIONS TO LOCATE");return;
        }
        String q=search.getText().toString().trim().toLowerCase(Locale.US);
        long now=System.currentTimeMillis()/1000L;
        AirTrackStore.Flight best=null;
        for(AirTrackStore.Flight f:snap.records){
            if(f.lastContactSec<=0||!Double.isFinite(f.lat)||!Double.isFinite(f.lon)||Math.abs(f.lat)>90||Math.abs(f.lon)>180)continue;
            if(airborneOnly&&f.ground)continue;
            if(altitudeBand!=0&&(!Double.isFinite(f.altMeters)||
                (altitudeBand==1&&f.altMeters>=3048.0d)||(altitudeBand==2&&f.altMeters<9144.0d)))continue;
            if(recentContactOnly&&(f.lastContactSec<=0||f.lastContactSec>now+60||now-f.lastContactSec>300))continue;
            if(!q.isEmpty()&&!f.callsign.toLowerCase(Locale.US).contains(q)&&
                !f.icao24.toLowerCase(Locale.US).contains(q)&&!f.origin.toLowerCase(Locale.US).contains(q))continue;
            if(best==null||f.lastContactSec>best.lastContactSec)best=f;
        }
        if(best==null){notice.setText("NO OBSERVED AIRCRAFT MATCH CURRENT FILTERS  •  TRY RESET");return;}
        Intent intent=new Intent(this,OperationsMainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra("focus_lat",best.lat);intent.putExtra("focus_lon",best.lon);
        intent.putExtra("focus_label",best.display()+"  •  OpenSky reported  •  "+age(best.lastContactSec));
        startActivity(intent);
    }
    private double finite(double n){return Double.isFinite(n)?n:-1e12;}
    private TextView message(String s){TextView t=text(s,14,MUTED,false);t.setPadding(dp(14),dp(20),dp(14),dp(20));return t;}
    private void addFlight(LinearLayout parent,AirTrackStore.Flight f){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),dp(12),dp(12),dp(10));
        box.setBackground(shape(PANEL));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(8);parent.addView(box,p);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);line(box,head,29);
        TextView name=text(f.display(),17,INK,true);head.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        TextView status=text(f.ground?"GROUND":"AIRBORNE",11,f.ground?WARN:CYAN,true);head.addView(status);
        TextView code=text("ICAO24 "+f.icao24.toUpperCase(Locale.US)+"   •   "+f.origin,12,MUTED,false);line(box,code,-2);
        TextView numbers=text("ALT  "+num(f.altMeters,"m",0)+"     SPEED  "+num(f.velocityMs*3.6,"km/h",0),13,INK,false);
        numbers.setPadding(0,dp(7),0,dp(2));line(box,numbers,-2);
        TextView time=text("CONTACT  "+age(f.lastContactSec)+"   ·   SOURCE  OpenSky",11,MUTED,false);line(box,time,-2);
        TextView expand=click("DETAILS  /  LOCATE ON GLOBE");LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(44));bp.topMargin=dp(7);box.addView(expand,bp);
        expand.setOnClickListener(v->{if(box.getChildCount()>5){while(box.getChildCount()>5)box.removeViewAt(5);return;}
            TextView info=text("Coordinates  "+String.format(Locale.US,"%.5f°, %.5f°",f.lat,f.lon)+"\n"
                    +"Last contact  "+utc(f.lastContactSec)+"\n"
                    +"Position time  "+utc(f.positionTimeSec)+"\n"
                    +"Heading  "+num(f.headingDeg,"°",1)+"\n"
                    +"Vertical rate  "+num(f.verticalRateMs,"m/s",1)+"\n"
                    +"Squawk  "+(f.squawk.isEmpty()?"not reported":f.squawk)+"\n"
                    +"Reported origin  "+f.origin+"\n"
                    +"Evidence  Provider-reported state vector. No predicted path.",13,INK,false);
            info.setPadding(0,dp(10),0,dp(10));line(box,info,-2);
            TextView locate=click("LOCATE OBSERVED POSITION ON EARTH");line(box,locate,46);
            TextView shareFlight=click("SHARE THIS AIRCRAFT DATA CARD");line(box,shareFlight,48);
            shareFlight.setContentDescription("Share observed aircraft "+f.display());
            shareFlight.setOnClickListener(q->V115941ShareCards.share(this,"AIRCRAFT",f.display(),
                "ICAO24 "+f.icao24+" | "+f.origin+" | ALT "+num(f.altMeters,"m",0)+
                " | SPEED "+num(f.velocityMs*3.6,"km/h",0)+" | "+
                (f.ground?"ON GROUND":"AIRBORNE"),"OpenSky",f.positionTimeSec*1000L,
                f.lat,f.lon,"https://opensky-network.org/",null));
            locate.setOnClickListener(w->{Intent i=new Intent(this,OperationsMainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                i.putExtra("focus_lat",f.lat);i.putExtra("focus_lon",f.lon);
                i.putExtra("focus_label",f.display()+"  ·  OpenSky  ·  "+age(f.lastContactSec));
                startActivity(i);finish();});
        });
    }
    private void fetch(boolean user){if(!busy.compareAndSet(false,true))return;
        long now=SystemClock.elapsedRealtime();if(lastTry>=0&&now-lastTry<REQUERY_MS){busy.set(false);
            if(user){failure="Refresh cooldown: wait "+((REQUERY_MS-(now-lastTry))/1000)+" sec";render();}return;}
        lastTry=now;source.setText("CONTACTING OPENSKY…");failure="";
        io.execute(()->{AirTrackStore.Snapshot received=null;String issue="";
            HttpURLConnection c=null;
            try{URL u=new URL("https://opensky-network.org/api/states/all");c=(HttpURLConnection)u.openConnection();
                c.setConnectTimeout(9000);c.setReadTimeout(12000);c.setRequestProperty("Accept","application/json");
                c.setRequestProperty("User-Agent","DevelopUgandaAirspace/1156");
                int status=c.getResponseCode();if(status!=200)throw new java.io.IOException("HTTP "+status);
                StringBuilder out=new StringBuilder();try(InputStream stream=c.getInputStream();BufferedReader br=new BufferedReader(new InputStreamReader(stream,"UTF-8"))){
                    char[] chars=new char[8192];int n;while((n=br.read(chars))!=-1){out.append(chars,0,n);
                        if(out.length()>7000000)throw new java.io.IOException("response too large");}}
                received=AirTrackStore.publish(new JSONObject(out.toString()));
            }catch(Exception ex){issue=ex.getMessage()==null?ex.getClass().getSimpleName():ex.getMessage();if(issue.length()>85)issue=issue.substring(0,85);
            }finally{if(c!=null)c.disconnect();}
            final AirTrackStore.Snapshot snapshot=received;final String err=issue;
            ui.post(()->{busy.set(false);if(isFinishing()||isDestroyed())return;
                if(snapshot!=null)current=snapshot;failure=err;render();});
        });
    }
    @Override protected void onDestroy(){io.shutdownNow();super.onDestroy();}
}
