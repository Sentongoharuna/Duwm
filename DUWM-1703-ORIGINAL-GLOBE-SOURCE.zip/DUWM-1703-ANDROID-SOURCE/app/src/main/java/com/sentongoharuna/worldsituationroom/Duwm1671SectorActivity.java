package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** Source-specific real data desk: each sector has a different map, chart or native media player. */
public final class Duwm1671SectorActivity extends Activity {
  public static final String EXTRA_KIND="duwm1671_kind";
  private static final String[] SECTORS={"AIRCRAFT","VESSELS","NEWS","MARKETS","WEATHER","EARTHQUAKES","SATELLITES","TV STATIONS","PUBLIC CAMERAS","RADIO"};
  private static final int BG=0xFF081824,WHITE=0xFFE3F3F7,AQUA=0xFF47D2DB,DIM=0xFFBDCACD,AMBER=0xFF47D2DB;
  private int selected=0;
  private TextView headline,count,status,detail,link;
  private Duwm1670WorldMapView map;private Duwm1671TrendView trend;private Duwm1671EventBars eventBars;
  private LinearLayout.LayoutParams mapLayout;private TextView mapSizeControl;private boolean expandedMap=false;
  private Duwm1678VisualKit.PulsePanel sectorBand;
  private final Handler handler=new Handler(Looper.getMainLooper());private boolean onScreen=false;
  private Duwm1670WorldMapView.Pin current;
  private String priorObservedKey="";
  private boolean extendedGeoWindow=false;private TextView geoWindowControl;
  private final Runnable ticker=new Runnable(){@Override public void run(){if(!onScreen)return;render();handler.postDelayed(this,25000);}};
  private int dp(float a){return Math.round(a*getResources().getDisplayMetrics().density);}
  private TextView text(String v,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(v);t.setTextColor(color);t.setTextSize(sp);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  private GradientDrawable surface(){GradientDrawable d=new GradientDrawable();d.setColor(0xFF104757);d.setCornerRadius(dp(10));d.setStroke(dp(1),0xFF185769);return d;}
  private TextView button(String label,Runnable r){TextView t=text(label,12,AQUA,true);t.setPadding(dp(12),dp(12),dp(12),dp(12));t.setBackground(surface());t.setGravity(Gravity.CENTER);t.setOnClickListener(v->r.run());return t;}
  private static String utc(long time){if(time<=0)return "SOURCE TIME UNAVAILABLE";SimpleDateFormat f=new SimpleDateFormat("dd MMM HH:mm:ss 'UTC'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(time));}
  @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    String kind=getIntent().getStringExtra(EXTRA_KIND);for(int i=0;i<SECTORS.length;i++)if(SECTORS[i].equals(kind))selected=i;
    ScrollView s=new ScrollView(this);s.setBackgroundColor(BG);s.setFillViewport(true);setContentView(s);Duwm1167SafeArea.install(this,s);
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(13),dp(12),dp(13),dp(28));s.addView(root);
    root.addView(text("DEVELOP.UGANDA  /  SPECIALIST OPERATIONS",12,AQUA,true));root.addView(Duwm1691Chrome.title(text("1700 / SPECIALIST INTELLIGENCE",23,WHITE,true)));
    sectorBand=new Duwm1678VisualKit.PulsePanel(this,SECTORS[selected]);
    LinearLayout.LayoutParams bandLp=new LinearLayout.LayoutParams(-1,dp(86));bandLp.topMargin=dp(8);root.addView(sectorBand,bandLp);
    root.addView(text("Map markers, graphs and counters appear only when actual source records exist.",11,DIM,false));
    Spinner spinner=new Spinner(this);ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,SECTORS);a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);spinner.setAdapter(a);spinner.setBackground(surface());root.addView(spinner,new LinearLayout.LayoutParams(-1,dp(50)));spinner.setSelection(selected);
    spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){@Override public void onItemSelected(AdapterView<?> p,View v,int pos,long id){selected=pos;current=null;render();Duwm1685PageUpgrade.onSectorChanged(Duwm1671SectorActivity.this,SECTORS[pos]);}@Override public void onNothingSelected(AdapterView<?> p){}});
    headline=text("AWAITING SOURCE DATA",19,WHITE,true);headline.setPadding(0,dp(14),0,dp(6));root.addView(headline);
    count=text("--",17,AQUA,true);root.addView(count);
    status=text("NOT YET CHECKED",11,AMBER,false);status.setPadding(0,dp(5),0,dp(10));root.addView(status);
    map=new Duwm1670WorldMapView(this);map.setOnPinSelected(p->{current=p;showPin();});
    mapLayout=new LinearLayout.LayoutParams(-1,dp(530));root.addView(map,mapLayout);
    mapSizeControl=button("EXPAND OBSERVATION MAP",()->{expandedMap=!expandedMap;mapLayout.height=dp(expandedMap?780:530);
      map.setLayoutParams(mapLayout);mapSizeControl.setText(expandedMap?"COMPACT OBSERVATION MAP":"EXPAND OBSERVATION MAP");});
    root.addView(mapSizeControl,new LinearLayout.LayoutParams(-1,dp(46)));
    geoWindowControl=button("MAP DATA WINDOW  /  LAST 24 HOURS",()->{extendedGeoWindow=!extendedGeoWindow;
      geoWindowControl.setText(extendedGeoWindow?"MAP DATA WINDOW  /  LAST 72 HOURS":"MAP DATA WINDOW  /  LAST 24 HOURS");
      current=null;render();});
    root.addView(geoWindowControl,new LinearLayout.LayoutParams(-1,dp(45)));
    trend=new Duwm1671TrendView(this);root.addView(trend,new LinearLayout.LayoutParams(-1,dp(170)));
    eventBars=new Duwm1671EventBars(this);root.addView(eventBars,new LinearLayout.LayoutParams(-1,dp(155)));
    detail=text("SELECT AN ACTUAL RECEIVED OBSERVATION",12,WHITE,false);detail.setBackground(surface());detail.setPadding(dp(12),dp(13),dp(12),dp(13));root.addView(detail);
    LinearLayout actions=new LinearLayout(this);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);ap.topMargin=dp(10);root.addView(actions,ap);
    actions.addView(button("OPEN FULL DESK",this::openProvider),new LinearLayout.LayoutParams(0,dp(54),1));
    TextView share=button("SHARE 9:16 CARD",this::share);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(54),1);sp.leftMargin=dp(8);actions.addView(share,sp);
    link=button("SOURCE HEALTH / RECEIPTS",()->startActivity(new Intent(this,Duwm1671SourceStatusActivity.class)));root.addView(link);
    root.addView(button("RETURN TO MISSION CONTROL",()->startActivity(new Intent(this,Duwm1671MissionActivity.class))));
    root.addView(text("SOURCE POLICY / Measurements and movements require genuine provider records. Visual scanning graphics are decorative. Missing providers remain labelled unavailable.",11,DIM,false));
    render();
  }
  private int sourceIndex(){switch(selected){case 1:return 2;case 2:return 5;case 3:return 7;case 4:return 6;case 5:return 3;case 6:return 1;default:return -1;}}
  private String recordType(){switch(selected){case 1:return "VESSEL";case 5:return "EARTHQUAKE";case 6:return "ISS";default:return "";}}
  private void render(){if(map==null||status==null)return;String k=SECTORS[selected];
    sectorBand.setMode(k);count.setTextColor(Duwm1678VisualKit.accent(k));headline.setText(k+" / WORLD INTELLIGENCE");
    int src=sourceIndex();RunningballV25Sources.Result result=src>=0?RunningballV25Sources.read(this,src):null;
    if(result!=null){status.setText(result.provider+"  /  "+result.display()+"  /  "+result.coverage+(result.errorReason.isEmpty()?"":"\n"+result.errorReason));
      count.setText((result.value==null?"--":result.value)+"  /  LAST FETCH "+result.age());}
    else{status.setText("CHOOSE AN ITEM OR LAUNCH NATIVE PLAYER. LIVE ONLY WHEN A PROVIDER SUCCEEDS.");count.setText(k);}
    sectorBand.setReceipt(result!=null&&result.fetchedAt>0?"RECEIPT / "+result.provider:"SOURCE NOT YET RECEIVED",
      result!=null&&result.fetchedAt>0?1:0,result!=null&&result.fetchedAt>0&&result.errorReason.isEmpty());
    map.setVisibility(View.GONE);mapSizeControl.setVisibility(View.GONE);geoWindowControl.setVisibility(View.GONE);trend.setVisibility(View.GONE);eventBars.setVisibility(View.GONE);
    if(selected==0){RunningballV25GlobalAircraftData.Snapshot snapshot=RunningballV25GlobalAircraftData.read(this);
      count.setText(snapshot.countLabel()+" PROVIDER AIRCRAFT  /  "+snapshot.displayRows+" CACHED MAP RECORDS");status.setText("OPENSKY GLOBAL STATES  •  "+snapshot.status()+"  •  "+snapshot.ageLabel()+"  •  NEXT "+snapshot.nextCheckLabel());
      detail.setText("Open the full moving aircraft map to track received positions, altitude, heading, speed, and hypothetical destination ETA scenarios.");
    }else if(selected==1||selected==5||selected==6){String type=recordType();ArrayList<Duwm1670WorldMapView.Pin> points=new ArrayList<>();ArrayList<DuwmGeoObservationStore.Fix> eventFixes=new ArrayList<>();long newest=0;
      for(DuwmGeoObservationStore.Fix f:DuwmGeoObservationStore.read(this)){
        if(!type.equals(f.type)&&!(type.equals("VESSEL")&&"VESSELS".equals(f.type)))continue;
        long age=System.currentTimeMillis()-f.receivedAt;
        if(f.receivedAt<=0||age<0||age>(extendedGeoWindow?72L:24L)*3600000L)continue;
        Duwm1670WorldMapView.Pin pin=new Duwm1670WorldMapView.Pin(f.id,f.title,type,f.lat,f.lon,f.sourceTime,f.detail+" / "+f.provider);
        if(f.hasActualTrack()){pin.prevLat=f.oldLat;pin.prevLon=f.oldLon;pin.prevObserved=f.oldTime;}
        points.add(pin);eventFixes.add(f);newest=Math.max(newest,f.receivedAt);
      }
      String newKey=type+":"+newest+":"+points.size();
      boolean newlyArrived=!newKey.equals(priorObservedKey);priorObservedKey=newKey;
      map.setVisibility(View.VISIBLE);mapSizeControl.setVisibility(View.VISIBLE);geoWindowControl.setVisibility(View.VISIBLE);map.setLayer(k);map.setPins(points,newlyArrived);
      sectorBand.setReceipt(points.isEmpty()?"NO POSITIONED RECORDS IN CACHE":"GEO RECORDS FROM SAVED SOURCE",points.size(),!points.isEmpty());
      count.setText(points.size()+" CACHED POSITIONED RECORDS  /  "+(extendedGeoWindow?"LAST 72H":"LAST 24H"));
      status.setText((result==null?"":result.display()+" / ")+"LATEST LOCAL RECEIPT "+utc(newest)+" / SOURCE POSITION ONLY");
      if(selected==5){eventBars.setVisibility(View.VISIBLE);eventBars.setEvents(eventFixes,System.currentTimeMillis());}
      if(current==null)detail.setText(points.isEmpty()?"NO RECENT VERIFIED POSITIONS IN THE DEVICE CACHE. RECHECK SOURCE / REGION.":"TAP A REPORTED POSITION TO INSPECT TIME, SOURCE AND SHARE CARD.");
    }else if(selected==3||selected==4){int idx=selected==3?7:6;Duwm1671Measurements.capture(this,idx);
      trend.setVisibility(View.VISIBLE);trend.setData((selected==3?"USD/EUR REFERENCE":"REGIONAL TEMPERATURE"),selected==3?"USD/EUR":"°C",Duwm1671Measurements.history(this,idx));
      detail.setText("Historical chart uses only distinct provider receipts saved on this phone. A single received value cannot form a valid time series. Markets are reference FX, not streaming trade quotes.");
    }else if(selected==2){detail.setText("Regional publisher countries are displayed in the News Atlas. News articles have no invented incident coordinates; full source photography and 9:16 cards are available in the real news desk.");}
    else if(selected==7||selected==8||selected==9){detail.setText("Use the native in-app media desk to browse actual registered sources. Player displays stream errors, distinguishes snapshots from live feeds and stops playback when leaving.");}
  }
  private void showPin(){if(current==null)return;Duwm1670WorldMapView.Pin p=current;
    detail.setText(p.title+"  /  "+p.id+"\n"+String.format(Locale.US,"COORDINATES %.4f°, %.4f°",p.lat,p.lon)+"\nSOURCE OBSERVED "+utc(p.observed)+"\n"+p.detail+"\n"+(p.genuinePair()?"TWO DISTINCT REAL OBSERVATIONS AVAILABLE":"MOVEMENT NOT VERIFIED FROM MULTIPLE FIXES"));
  }
  private void share(){if(current!=null){Duwm1670WorldMapView.Pin p=current;
      Duwm1671Share.share(this,SECTORS[selected],p.title,String.format(Locale.US,"LAT %.4f  LON %.4f\n%s",p.lat,p.lon,p.detail),"RECEIVED POSITION / ON-DEVICE SOURCE", "",p.observed);return;}
    int idx=sourceIndex();if(idx<0){android.widget.Toast.makeText(this,"Select a received record first",android.widget.Toast.LENGTH_SHORT).show();return;}
    RunningballV25Sources.Result r=RunningballV25Sources.read(this,idx);
    if(r.fetchedAt<=0){android.widget.Toast.makeText(this,"No verified provider receipt to share",android.widget.Toast.LENGTH_SHORT).show();return;}
    Duwm1671Share.share(this,SECTORS[selected],r.value,r.coverage+" / "+r.display(),r.provider,r.endpoint,r.fetchedAt);
  }
  private void openProvider(){Intent i;switch(selected){case 0:i=new Intent(this,Duwm1670FlightMapActivity.class);break;
      case 1:i=new Intent(this,GevMarineActivity.class);break;
      case 2:i=new Intent(this,Duwm1670NewsAtlasActivity.class);break;
      case 3:case 4:i=new Intent(this,DuwmWorldIntelligenceActivity.class);i.putExtra("kind",selected==3?"MARKETS":"WEATHER");break;
      case 5:i=new Intent(this,Duwm1668GeopoliticalLensActivity.class);break;
      case 6:i=new Intent(this,GevSatelliteActivity.class);break;
      default:i=new Intent(this,MediaDeskActivity.class);i.putExtra("mode",selected==7?"TV STATIONS":selected==8?"PUBLIC CAMERAS":"RADIO");break;}
    startActivity(i);
  }
  @Override protected void onResume(){super.onResume();onScreen=true;if(map!=null)map.resume();if(trend!=null)trend.start();if(sectorBand!=null)sectorBand.start();handler.removeCallbacks(ticker);handler.post(ticker);}
  @Override protected void onPause(){onScreen=false;handler.removeCallbacks(ticker);if(map!=null)map.pause();if(trend!=null)trend.stop();if(sectorBand!=null)sectorBand.stop();super.onPause();}
}
