package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** Only paints actual DISTINCT provider receipt timestamps retained on this device.
 * Numeric trends are drawn only when every plotted point is an actual numeric provider value. */
public final class Duwm1685ReceiptChart extends View {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Duwm1683DeskCatalog.Desk desk;
    private final float den;
    public Duwm1685ReceiptChart(Context c,Duwm1683DeskCatalog.Desk d){
        super(c);desk=d;den=getResources().getDisplayMetrics().density;
        setContentDescription("Verified, timestamped local source-receipt history only. No synthetic data or interpolated coordinates.");
    }
    private void text(Canvas c,String t,float x,float y,float sp,int color){
        p.setColor(color);p.setStrokeWidth(1);p.setStyle(Paint.Style.FILL);
        p.setTypeface(android.graphics.Typeface.create("sans-serif-medium",0));p.setTextSize(sp*den);
        c.drawText(t,x,y,p);
    }
    private String utc(long time){
        SimpleDateFormat fmt=new SimpleDateFormat("dd MMM HH:mm 'UTC'",Locale.US);
        fmt.setTimeZone(TimeZone.getTimeZone("UTC"));return fmt.format(new Date(time));
    }
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        float w=getWidth(),h=getHeight();if(w<=0||h<=0)return;
        p.setStyle(Paint.Style.FILL);p.setColor(0xFF082736);
        c.drawRoundRect(0,0,w,h,12*den,12*den,p);
        text(c,"OBSERVED RECEIPT HISTORY  /  THIS PHONE",12*den,24*den,11,0xFF83E7EC);
        List<Duwm1685ReceiptHistory.Point> pts=Duwm1685ReceiptHistory.read(getContext(),desk);
        if(pts.isEmpty()){
            text(c,desk.source<0?"NO PROVIDER SERIES FOR LOCAL TOOL":"NO SOURCE SNAPSHOTS RECEIVED",12*den,h*.54f,12,0xFFE4F4F7);
            text(c,"Nothing plotted until a real receipt is stored",12*den,h*.73f,10,0xFF8DAFBC);
            return;
        }
        float l=18*den,r=w-18*den,t=44*den,b=h-28*den;
        p.setStyle(Paint.Style.STROKE);p.setColor(0x5547D2DB);p.setStrokeWidth(1*den);
        for(int i=0;i<4;i++){float y=t+(b-t)*(i+1)/5f;c.drawLine(l,y,r,y,p);}
        boolean numerical=pts.size()>=2;
        for(Duwm1685ReceiptHistory.Point q:pts)if(!q.numerical)numerical=false;
        double lo=Double.POSITIVE_INFINITY,hi=Double.NEGATIVE_INFINITY;
        for(Duwm1685ReceiptHistory.Point q:pts){if(q.numerical){lo=Math.min(lo,q.value);hi=Math.max(hi,q.value);}}
        long first=pts.get(0).sourceAt,last=pts.get(pts.size()-1).sourceAt;
        Path trace=new Path();
        for(int i=0;i<pts.size();i++){
            Duwm1685ReceiptHistory.Point q=pts.get(i);
            float x=last>first?l+(r-l)*(q.sourceAt-first)/(float)(last-first):w/2;
            float y=numerical&&hi>lo?b-(float)((q.value-lo)/(hi-lo))*(b-t):t+(b-t)*.52f;
            if(i==0)trace.moveTo(x,y);else trace.lineTo(x,y);
            p.setStyle(Paint.Style.FILL);p.setColor(0xFF83E7EC);c.drawCircle(x,y,3.4f*den,p);
            p.setStyle(Paint.Style.STROKE);p.setColor(0xAA83E7EC);p.setStrokeWidth(1.6f*den);
            c.drawLine(x,b,x,b+4*den,p);
        }
        if(numerical&&pts.size()>1){
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.1f*den);p.setColor(0xFF47D2DB);c.drawPath(trace,p);
            text(c,String.format(Locale.US,"SOURCE VALUE %.3g – %.3g",lo,hi),l,t+9*den,10,0xFFE4F4F7);
        }else{
            text(c,pts.size()+" RECEIPT TIME MARKERS / NO NUMERIC TREND",l,t+9*den,10,0xFFE4F4F7);
        }
        String firstLabel=utc(first),lastLabel=utc(last);
        text(c,firstLabel,l,h-9*den,9,0xFF8DAFBC);
        p.setTextSize(9*den);
        if(last>first)text(c,lastLabel,Math.max(l,w-22*den-p.measureText(lastLabel)),h-9*den,9,0xFF8DAFBC);
    }
}
