package com.sentongoharuna.worldsituationroom;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.view.View;
import android.view.MotionEvent;
import android.widget.*;
import android.content.Intent;
import org.json.*;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** In-app station atlas with real Radio Browser geo coordinates and working audio status. */
public final class Duwm1166RadioAtlasActivity extends Activity {
  private static final int BG=0xFF081824;
  private static final String[] LABELS={"WORLD","UGANDA","KENYA","NIGERIA","INDIA","MIDDLE EAST","SOUTH AFRICA","UK","USA"};
  private static final String[] CODES={"","UG","KE","NG","IN","AE","ZA","GB","US"};
  private LinearLayout stations,filters;private final ArrayList<TextView> regionButtons=new ArrayList<>();private TextView status,playingStation;private Duwm1690EvidenceBars radioEvidence;
  private String stationSearch="",activeCountry="UG",activeCountryName="UGANDA";
  private int requestGeneration=0,stationLimit=36;private boolean mappedOnly=false,savedOnly=false,regionZoom=false,selectedMapFocus=false;private Station selected;private TextView savedFilter,focusMapControl;
  private final ArrayList<Station> found=new ArrayList<>();private Atlas atlas;private MediaPlayer player;private boolean fullAtlas=true;private LinearLayout.LayoutParams atlasLayout;
  private static final class Station {String name,url,code,region;Double lat,lon;int originalOrder;}
  private int dp(float x){return (int)(getResources().getDisplayMetrics().density*x+.5f);}
  private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);return t;}
  @Override public void onCreate(Bundle saved){super.onCreate(saved);getWindow().setStatusBarColor(BG);
    ScrollView sc=new ScrollView(this);sc.setBackgroundColor(BG);setContentView(sc);Duwm1167SafeArea.install(this,sc);
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(12),dp(16),dp(12),dp(24));sc.addView(root);
    root.addView(Duwm1693Chrome.title(text("WORLD RADIO  /  SOURCE ATLAS 1699",21,Color.WHITE)));
    root.addView(text("Geotagged stations only; radio map dots are sourced from Radio Browser",11,0xFF39B5C3));
    status=text("No station response received",12,0xFF47D2DB);root.addView(status);
    playingStation=text("PLAYER / SELECT A RECEIVED RADIO STREAM",13,Color.WHITE);
    playingStation.setPadding(dp(9),dp(12),dp(9),dp(12));playingStation.setBackgroundColor(0xFF0F4150);root.addView(playingStation);
    radioEvidence=new Duwm1690EvidenceBars(this);
    LinearLayout controls=new LinearLayout(this);root.addView(controls);
    TextView pauseAudio=text("Ⅱ  PAUSE / RESUME",12,0xFF47D2DB);pauseAudio.setPadding(dp(4),dp(13),dp(4),dp(13));
    controls.addView(pauseAudio,new LinearLayout.LayoutParams(0,-2,1));
    pauseAudio.setOnClickListener(v->{if(player==null)return;try{if(player.isPlaying()){player.pause();status.setText("PAUSED  /  "+(selected==null?"STATION":selected.name));}
      else{player.start();status.setText("PLAYING  /  "+(selected==null?"STATION":selected.name));}}catch(Exception e){status.setText("PLAYER NOT READY");}});
    TextView prevReceived=text("◀◀  PREVIOUS",12,0xFF47D2DB);
    prevReceived.setPadding(dp(5),dp(13),dp(8),dp(13));controls.addView(prevReceived,new LinearLayout.LayoutParams(0,-2,1));
    prevReceived.setOnClickListener(v->playAdjacentStation(-1));
    TextView nextReceived=text("▶▶  NEXT",12,0xFF47D2DB);
    nextReceived.setPadding(dp(5),dp(13),dp(8),dp(13));controls.addView(nextReceived,new LinearLayout.LayoutParams(0,-2,1));
    nextReceived.setOnClickListener(v->playNextReceivedStation());
    TextView stopAudio=text("■  STOP",12,0xFF47D2DB);stopAudio.setPadding(dp(4),dp(13),dp(4),dp(13));
    controls.addView(stopAudio,new LinearLayout.LayoutParams(0,-2,1));
    stopAudio.setOnClickListener(v->{stop();status.setText("PLAYBACK STOPPED  /  SELECT A STATION");});
    EditText search=new EditText(this);search.setSingleLine(true);search.setTextColor(Color.WHITE);search.setHintTextColor(0xFFB5C1C4);
    search.setHint("Find a received station or country");search.setTextSize(14);
    search.setPadding(dp(12),0,dp(12),0);root.addView(search,new LinearLayout.LayoutParams(-1,dp(50)));
    search.addTextChangedListener(new android.text.TextWatcher(){
      @Override public void beforeTextChanged(CharSequence s,int st,int count,int after){}
      @Override public void onTextChanged(CharSequence s,int st,int before,int count){stationSearch=s.toString().trim().toLowerCase(Locale.ROOT);renderStations();atlas.invalidate();}
      @Override public void afterTextChanged(android.text.Editable e){}
    });
    LinearLayout advancedRadio=new LinearLayout(this);advancedRadio.setOrientation(LinearLayout.VERTICAL);
    TextView toggleRadioFilters=text("MORE STATION FILTERS  ▸",12,0xFF47D2DB);
    toggleRadioFilters.setPadding(dp(10),dp(12),dp(10),dp(12));root.addView(toggleRadioFilters);
    root.addView(advancedRadio);
    advancedRadio.setVisibility(android.view.View.GONE);
    toggleRadioFilters.setOnClickListener(v->{boolean open=advancedRadio.getVisibility()!=android.view.View.VISIBLE;
      advancedRadio.setVisibility(open?android.view.View.VISIBLE:android.view.View.GONE);
      toggleRadioFilters.setText(open?"HIDE STATION FILTERS  ▴":"MORE STATION FILTERS  ▸");});
    TextView onlyMap=text("MAP FILTER: ALL RECEIVED STATIONS  /  TAP TO SHOW GEOTAGGED ONLY",12,0xFF47D2DB);
    onlyMap.setPadding(dp(6),dp(12),dp(4),dp(12));advancedRadio.addView(onlyMap);
    onlyMap.setOnClickListener(v->{mappedOnly=!mappedOnly;onlyMap.setText(mappedOnly?"MAP FILTER: GEOTAGGED STATIONS ONLY  /  TAP FOR ALL":"MAP FILTER: ALL RECEIVED STATIONS  /  TAP FOR GEOTAGGED ONLY");renderStations();atlas.invalidate();});
    savedFilter=text("☆ SAVED STATIONS IN RECEIVED REGION  /  SHOW ALL",12,0xFF47D2DB);
    savedFilter.setPadding(dp(6),dp(10),dp(4),dp(10));advancedRadio.addView(savedFilter);
    savedFilter.setOnClickListener(v->{savedOnly=!savedOnly;renderStations();atlas.invalidate();});
    TextView stationSort=text("DIRECTORY ORDER / TAP TO SORT A–Z",12,0xFF47D2DB);
    stationSort.setPadding(dp(7),dp(12),dp(7),dp(12));advancedRadio.addView(stationSort);
    stationSort.setOnClickListener(v->{alphabeticalStations=!alphabeticalStations;
      found.sort((a,b)->alphabeticalStations?a.name.compareToIgnoreCase(b.name):Integer.compare(a.originalOrder,b.originalOrder));
      stationSort.setText(alphabeticalStations?"STATIONS A–Z / TAP FOR PROVIDER ORDER":"DIRECTORY ORDER / TAP TO SORT A–Z");renderStations();});
    HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setHorizontalScrollBarEnabled(false);root.addView(scroll);
    filters=new LinearLayout(this);scroll.addView(filters);
    for(int i=0;i<LABELS.length;i++){final int index=i;TextView b=text("  "+LABELS[i]+"  ",13,0xFF47D2DB);
      b.setPadding(dp(8),dp(14),dp(8),dp(14));b.setOnClickListener(v->fetch(CODES[index],LABELS[index]));
      filters.addView(b);regionButtons.add(b);}
    focusMapControl=text("MAP: WORLD  /  TAP TO FIT RECEIVED STATIONS",12,0xFF47D2DB);
    focusMapControl.setPadding(dp(10),dp(13),dp(8),dp(13));root.addView(focusMapControl);
    focusMapControl.setOnClickListener(v->{
      if(!regionZoom){regionZoom=true;selectedMapFocus=false;}
      else if(!selectedMapFocus && selected!=null && selected.lat!=null && selected.lon!=null){selectedMapFocus=true;}
      else{regionZoom=false;selectedMapFocus=false;}
      focusMapControl.setText(selectedMapFocus?"MAP: SELECTED STATION  /  TAP FOR WORLD":
          regionZoom?"MAP: MATCHING STATIONS  /  TAP TO FOCUS SELECTED":"MAP: WORLD  /  TAP TO FIT RECEIVED STATIONS");
      if(atlas!=null){atlas.updateBounds();atlas.invalidate();}});
    TextView atlasSize=text("ATLAS FIRST  /  EXPANDED  •  TAP TO PRIORITIZE STATION LIST",12,0xFF47D2DB);
    atlasSize.setPadding(dp(10),dp(11),dp(10),dp(11));atlasSize.setBackgroundColor(0xFF124353);root.addView(atlasSize);
    atlas=new Atlas();atlasLayout=new LinearLayout.LayoutParams(-1,dp(490));root.addView(atlas,atlasLayout);
    atlasSize.setOnClickListener(v->{fullAtlas=!fullAtlas;atlasLayout.height=dp(fullAtlas?490:210);
      atlas.setLayoutParams(atlasLayout);atlasSize.setText(fullAtlas?"ATLAS FIRST  /  EXPANDED  •  TAP FOR STATION LIST":"STATION LIST FIRST  /  COMPACT ATLAS  •  TAP TO EXPAND");});
    TextView radioSummaryToggle=text("SHOW RECEIVED STATION CHART  ▸",12,0xFF47D2DB);
    radioSummaryToggle.setPadding(dp(10),dp(12),dp(10),dp(12));root.addView(radioSummaryToggle);
    LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,dp(225));rlp.topMargin=dp(8);root.addView(radioEvidence,rlp);
    radioEvidence.setVisibility(android.view.View.GONE);
    radioSummaryToggle.setOnClickListener(v->{boolean open=radioEvidence.getVisibility()!=android.view.View.VISIBLE;
      radioEvidence.setVisibility(open?android.view.View.VISIBLE:android.view.View.GONE);
      radioSummaryToggle.setText(open?"HIDE RECEIVED STATION CHART  ▴":"SHOW RECEIVED STATION CHART  ▸");});
    TextView note=text("Radio map: official station coordinates and Natural Earth outlines. Tap a point to select a station.",11,0xFFB5C1C4);root.addView(note);
    stations=new LinearLayout(this);stations.setOrientation(LinearLayout.VERTICAL);root.addView(stations);
    fetch("UG","UGANDA");
  }
  private boolean alphabeticalStations=false;
  private boolean isSaved(Station s){return s!=null&&s.url!=null&&getSharedPreferences("duwm_radio_stations",MODE_PRIVATE).getBoolean(s.url,false);}
  private void saveStation(Station s){if(s==null||s.url==null||!s.url.startsWith("https://"))return;
    getSharedPreferences("duwm_radio_stations",MODE_PRIVATE).edit().putBoolean(s.url,!isSaved(s)).apply();renderStations();atlas.invalidate();}
  private void fetch(String cc,String name){activeCountry=cc;activeCountryName=name;stop();selected=null;selectedMapFocus=false;stationLimit=36;
    if(focusMapControl!=null)focusMapControl.setText(regionZoom?"MAP: MATCHING STATIONS  /  TAP TO FOCUS SELECTED":"MAP: WORLD  /  TAP TO FIT RECEIVED STATIONS");final int generation=++requestGeneration;
    for(int i=0;i<regionButtons.size();i++){
      TextView b=regionButtons.get(i);boolean chosen=CODES[i].equals(cc);
      b.setTextColor(chosen?Color.WHITE:0xFF47D2DB);
      b.setBackgroundColor(chosen?0xFF175568:0xFF081824);
      b.setContentDescription(LABELS[i]+(chosen?" selected radio region":" radio region"));
    }
    status.setText(name+"  /  CONNECTING TO RADIO BROWSER");found.clear();
    if(atlas!=null){atlas.updateBounds();atlas.invalidate();}if(stations!=null)stations.removeAllViews();
    final String url="https://de1.api.radio-browser.info/json/stations/search?hidebroken=true&limit=75&order=votes&reverse=true"+(cc.isEmpty()?"":"&countrycode="+cc);
    new Thread(()->{ArrayList<Station> incoming=new ArrayList<>();String result;HttpURLConnection conn=null;
      try{conn=(HttpURLConnection)new URL(url).openConnection();conn.setConnectTimeout(9000);conn.setReadTimeout(12000);
        conn.setRequestProperty("User-Agent","DEVELOP.UGANDA/1673 public-radio-atlas");
        int http=conn.getResponseCode();if(http!=200)throw new IOException("Radio Browser HTTP "+http);
        ByteArrayOutputStream o=new ByteArrayOutputStream();try(InputStream in=conn.getInputStream()){byte[] b=new byte[4096];int len;while((len=in.read(b))!=-1){if(o.size()+len>1200000)throw new IOException("Radio list too large");o.write(b,0,len);}}
        JSONArray arr=new JSONArray(new String(o.toByteArray(),StandardCharsets.UTF_8));
        for(int i=0;i<arr.length();i++){JSONObject j=arr.optJSONObject(i);if(j==null)continue;
          Station s=new Station();s.originalOrder=i;s.name=j.optString("name","").trim();s.url=j.optString("url_resolved","").trim();s.code=j.optString("countrycode","");s.region=j.optString("country","");
          if(s.name.length()<2||!s.url.startsWith("https://"))continue;
          if(!j.isNull("geo_lat")&&!j.isNull("geo_long")){
            double lat=j.optDouble("geo_lat",Double.NaN),lon=j.optDouble("geo_long",Double.NaN);
            if(Double.isFinite(lat)&&Double.isFinite(lon)&&Math.abs(lat)<=90&&Math.abs(lon)<=180){s.lat=lat;s.lon=lon;}}
          incoming.add(s);
        }
        int positioned=0;for(Station station:incoming)if(station.lat!=null&&station.lon!=null)positioned++;
        result=name+"  /  "+incoming.size()+" HTTPS STREAM URLS RECEIVED  /  "+positioned+" MAPPED WITH SOURCE COORDINATES";
      }catch(Exception e){result="RADIO SOURCE UNAVAILABLE  /  "+e.getClass().getSimpleName();}
      finally{if(conn!=null)conn.disconnect();}
      final String message=result;runOnUiThread(()->{if(isFinishing()||generation!=requestGeneration)return;
        found.clear();found.addAll(incoming);if(alphabeticalStations)found.sort((a,b)->a.name.compareToIgnoreCase(b.name));status.setText(message);atlas.invalidate();renderStations();});
    },"duwm1166-radio-lookup").start();
  }
  private boolean stationVisible(Station s){return (!savedOnly||isSaved(s))&&(!mappedOnly || (s.lat!=null&&s.lon!=null)) &&
    (stationSearch.isEmpty() || (s.name+" "+s.region+" "+s.code).toLowerCase(Locale.ROOT).contains(stationSearch));}
  private void renderStations(){if(stations==null)return;stations.removeAllViews();
    int visible=0,mapped=0,savedCount=0,unlocated=0;
    for(Station station:found){if(isSaved(station))savedCount++;if(station.lat==null||station.lon==null)unlocated++;
      if(stationVisible(station)){visible++;if(station.lat!=null&&station.lon!=null)mapped++;}}
    if(atlas!=null){atlas.updateBounds();atlas.invalidate();}
    if(radioEvidence!=null)radioEvidence.setValues("RADIO / RECEIVED DIRECTORY SAMPLE",
      new String[]{"DIRECTORY RECORDS","CURRENT FILTER","WITH GPS POSITION","SAVED STATIONS"},
      new long[]{found.size(),visible,mapped,savedCount});
    if(savedFilter!=null)savedFilter.setText((savedOnly?"★ SAVED ONLY":"☆ ALL RECEIVED")+"  /  "+visible+" MATCHING  /  "+mapped+" ON MAP  •  TAP TO FILTER");
    if(found.isEmpty()){stations.addView(text("NO VERIFIED STATIONS RECEIVED — TRY ANOTHER REGION",12,0xFF47D2DB));return;}
    int count=0;for(Station s:found){if(!stationVisible(s))continue;if(count++>=stationLimit)break;LinearLayout line=new LinearLayout(this);line.setOrientation(LinearLayout.HORIZONTAL);line.setPadding(dp(10),dp(11),dp(10),dp(11));
      Duwm1166SignalView signal=new Duwm1166SignalView(this);signal.reference();
      line.addView(signal,new LinearLayout.LayoutParams(dp(29),dp(31)));
      TextView name=text(s.name+"\n"+s.region+(s.lat==null?"  •  NO MAP POSITION":"  •  GPS POSITION PROVIDED"),13,s==selected?0xFF47D2DB:Color.WHITE);line.addView(name,new LinearLayout.LayoutParams(0,-2,1));
      LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.VERTICAL);
      line.addView(actions,new LinearLayout.LayoutParams(dp(96),-2));
      TextView play=text("▶ IN APP",12,0xFF47D2DB);play.setPadding(dp(5),dp(6),dp(5),dp(7));actions.addView(play);
      TextView share=text("▣ CARD",12,0xFF47D2DB);share.setPadding(dp(5),dp(7),dp(5),dp(6));actions.addView(share);
      TextView save=text(isSaved(s)?"★ SAVED":"☆ SAVE",12,0xFF47D2DB);save.setPadding(dp(5),dp(7),dp(5),dp(6));actions.addView(save);
      save.setOnClickListener(v->saveStation(s));
      play.setContentDescription("Play "+s.name+" inside DUWM");share.setContentDescription("Share source-attributed card for "+s.name);
      play.setOnClickListener(v->play(s));share.setOnClickListener(v->shareStation(s));
      line.setOnClickListener(v->play(s));stations.addView(line);
    }
    if(visible>stationLimit){TextView next=text("LOAD NEXT STATIONS  •  "+Math.min(36,visible-stationLimit)+" MORE  /  "+visible+" MATCHING",13,0xFF47D2DB);
      next.setPadding(dp(13),dp(17),dp(13),dp(17));next.setBackgroundColor(0xFF104454);stations.addView(next);
      next.setOnClickListener(v->{stationLimit+=36;renderStations();});}
    if(count==0)stations.addView(text("NO RECEIVED STATIONS MATCH THIS FILTER. CLEAR SEARCH OR CHANGE REGION.",13,0xFFB5C1C4));
  }
  /** Every received station can export an actual source card; no unverified coordinates are filled in. */
  private void shareStation(Station s){
    String position=s.lat==null||s.lon==null?"Coordinates not supplied by Radio Browser":
      String.format(Locale.US,"Station map point %.5f, %.5f",s.lat,s.lon);
    Duwm1671Share.share(this,"RADIO",s.name,"Country: "+s.region+" / "+position+
        " / Direct player available in this application; stream success is checked on playback.",
        "Radio Browser / station directory",s.url,0L);
  }
  private void playNextReceivedStation(){playAdjacentStation(1);}
  private void playAdjacentStation(int direction){
    ArrayList<Station> eligible=new ArrayList<>();for(Station s:found)if(stationVisible(s))eligible.add(s);
    if(eligible.isEmpty()){status.setText("NO RECEIVED STATIONS MATCH THE CURRENT FILTER");return;}
    int index=eligible.indexOf(selected);
    int next=index<0?(direction<0?eligible.size()-1:0):(index+direction+eligible.size())%eligible.size();
    play(eligible.get(next));
  }
  private void play(Station station){stop();selected=station;if(atlas!=null){atlas.updateBounds();atlas.invalidate();}renderStations();
    status.setText("CONNECTING: "+station.name);playingStation.setText("TUNED  /  "+station.name+"  /  "+station.region);
    try{MediaPlayer mp=new MediaPlayer();player=mp;mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
      mp.setDataSource(station.url);mp.setOnPreparedListener(p->{if(player==p){p.start();status.setText("NOW PLAYING  /  "+station.name);playingStation.setText("ON AIR  /  "+station.name+"  /  "+station.region);}});
      mp.setOnErrorListener((p,what,extra)->{status.setText("STREAM UNAVAILABLE  /  PROVIDER OR FORMAT ERROR "+what);stop();return true;});mp.prepareAsync();
    }catch(Exception e){status.setText("STREAM UNAVAILABLE  /  "+e.getClass().getSimpleName());stop();}
  }
  private void stop(){if(player!=null){try{player.reset();player.release();}catch(Exception ignored){}player=null;}
    if(playingStation!=null)playingStation.setText("PLAYER / STOPPED");}
  @Override protected void onDestroy(){stop();super.onDestroy();}
  private final class Atlas extends View {
    private final Paint pen=new Paint(3);private final ArrayList<float[]> outline=new ArrayList<>();private boolean loaded;
    Atlas(){super(Duwm1166RadioAtlasActivity.this);loadCoasts();setContentDescription("Geotagged world radio stations");}
    private void loadCoasts(){if(loaded)return;loaded=true;
      try(BufferedReader reader=new BufferedReader(new InputStreamReader(getAssets().open("naturalearth_coasts.txt"),StandardCharsets.UTF_8))){
        String line;int rows=0;while((line=reader.readLine())!=null&&rows++<4000){String[] pairs=line.trim().split(" ");
          for(String pair:pairs){String[] coords=pair.split(",");if(coords.length!=2)continue;
            try{float lat=Float.parseFloat(coords[0]),lon=Float.parseFloat(coords[1]);if(Math.abs(lat)<=90&&Math.abs(lon)<=180)outline.add(new float[]{lat,lon});}catch(Exception ignored){}}
          outline.add(null);
        }
      }catch(Exception ignored){}
    }
    private double west=-180,east=180,south=-90,north=90;
    void updateBounds(){west=-180;east=180;south=-90;north=90;if(!regionZoom)return;
      if(selectedMapFocus && selected!=null && selected.lat!=null && selected.lon!=null){
        west=Math.max(-180,selected.lon-6d);east=Math.min(180,selected.lon+6d);
        south=Math.max(-90,selected.lat-4d);north=Math.min(90,selected.lat+4d);return;}
      double minLon=181,maxLon=-181,minLat=91,maxLat=-91;int amount=0;
      for(Station s:found)if(stationVisible(s)&&s.lat!=null&&s.lon!=null){
        minLon=Math.min(minLon,s.lon);maxLon=Math.max(maxLon,s.lon);
        minLat=Math.min(minLat,s.lat);maxLat=Math.max(maxLat,s.lat);amount++;}
      if(amount==0)return;
      double padLon=Math.max(5.0,(maxLon-minLon)*0.15),padLat=Math.max(3.0,(maxLat-minLat)*0.15);
      west=Math.max(-180,minLon-padLon);east=Math.min(180,maxLon+padLon);
      south=Math.max(-90,minLat-padLat);north=Math.min(90,maxLat+padLat);
    }
    private float xx(double lon){return (float)((lon-west)/Math.max(.001,east-west)*getWidth());}
    private float yy(double lat){return (float)((north-lat)/Math.max(.001,north-south)*getHeight());}
    @Override protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(0xFF0F4150);
      pen.setColor(0xFF185769);pen.setStrokeWidth(1f);for(int x=1;x<8;x++)c.drawLine(x*getWidth()/8f,0,x*getWidth()/8f,getHeight(),pen);
      for(int y=1;y<6;y++)c.drawLine(0,y*getHeight()/6f,getWidth(),y*getHeight()/6f,pen);
      pen.setColor(0xFF185769);pen.setStrokeWidth(1.1f);float[] last=null;
      for(float[] point:outline){if(point==null){last=null;continue;}if(last!=null&&Math.abs(point[1]-last[1])<70)c.drawLine(xx(last[1]),yy(last[0]),xx(point[1]),yy(point[0]),pen);last=point;}
      for(Station s:found)if(stationVisible(s)&&s.lat!=null&&s.lon!=null){
        if(s.lon<west||s.lon>east||s.lat<south||s.lat>north)continue;
        pen.setColor(s==selected?0xFFFFFFFF:0xFF47D2DB);
        float rad=s==selected?dp(8):dp(4);
        if(s==selected){pen.setStyle(Paint.Style.STROKE);pen.setStrokeWidth(dp(2));c.drawCircle(xx(s.lon),yy(s.lat),dp(14),pen);pen.setStyle(Paint.Style.FILL);}
        c.drawCircle(xx(s.lon),yy(s.lat),rad,pen);
        if(s==selected){ // Selected station label is derived from the received directory, not invented map data.
          String label=s.name.length()>29?s.name.substring(0,26)+"…":s.name;
          pen.setColor(0xFFFAFFFF);pen.setTextSize(dp(12));pen.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
          float tx=Math.min(Math.max(dp(8),xx(s.lon)-dp(36)),Math.max(dp(8),getWidth()-dp(196)));
          float ty=Math.max(dp(23),Math.min(getHeight()-dp(10),yy(s.lat)-dp(18)));
          c.drawText(label,tx,ty,pen);pen.setTypeface(android.graphics.Typeface.DEFAULT);
        }
      }
    }
    @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;
      Station best=null;double dist=100000;for(Station s:found)if(stationVisible(s)&&s.lat!=null&&s.lon!=null){double dx=e.getX()-xx(s.lon),dy=e.getY()-yy(s.lat);double d=dx*dx+dy*dy;
        if(d<dist){dist=d;best=s;}}
      if(best!=null&&dist<dp(32)*dp(32))play(best);return true;
    }
  }
}
