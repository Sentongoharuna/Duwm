"""Real-file source integrity gate for DUWM 1167 native Android project.
Does not claim Android runtime correctness or external-source connectivity.
"""
from pathlib import Path
import xml.etree.ElementTree as ET, hashlib, json, subprocess, tempfile, re
ROOT=Path(__file__).resolve().parents[1]
PKG=ROOT/'app/src/main/java/com/sentongoharuna/worldsituationroom'
MAIN=ROOT/'app/src/main'

def require(cond,why):
    if not cond:raise AssertionError(why)

def source(n):
    p=PKG/n
    require(p.is_file(),f'Android source missing: {n}')
    return p.read_text(encoding='utf-8')

app=source('OperationsMainActivity.java')
sphere=source('SatelliteMapView.java')
map_activity=source('DuwmPlaceMapActivity.java')
rail=source('DuwmSignalRail.java')
world=source('DuwmWorldIntelligenceActivity.java')
media=source('MediaDeskActivity.java')
require('earth=new OperationsGlobeView(this)' in app,'Detailed Natural Earth globe must be instantiated')
require('originalToggle.setOnClickListener(v->switchOriginalRenderer());' in app,'Legacy mode switch missing')
require('originalMode=false;' in app and 'earth.setVisibility(View.VISIBLE)' in app,'Detailed globe not selected on startup')
require('switchOriginalRenderer();\n        earth.postInvalidateOnAnimation();' not in app,'Legacy polygon globe must not overwrite detailed startup')
require('originalToggle.setText("LEGACY")' in app and 'originalToggle.setText("DETAILED")' in app,'Globe mode controls are mislabeled')
require('LIVE EARTH' in app and 'naturalearth_coasts.txt' in source('OperationsGlobeView.java'),'Original detailed-coastline globe missing')
require('Class.forName("com.sentongoharuna.worldsituationroom.SatelliteMapView")' in app,'Original protected globe not wired')
require('setAutoRotationEnabled(rotate)' in app and 'setAutoRotationEnabled(boolean enabled)' in sphere,'Original visible globe rotation control absent')
require('if(originalMode && originalEarth instanceof SatelliteMapView){inspectObservation(item,true);}' in app,'Center Selected is not aimed at visible native globe')
require('globeControls.addView(rotationControl,rotateP)' in app,'Globe buttons still squeeze the title')
require('DuwmSignalRail.embedded(this)' in app and 'verifiedRailRow' in app,'Native globe status lights not reserved in layout')
require('DuwmSignalRail.embedded(this)' in map_activity and 'mapStatusRow' in map_activity,'Map signal lights not reserved in layout')
require('window.duwmRenderStatus' in map_activity and 'tileLoadSuccess' in map_activity,'Real renderer/tile diagnostic missing')
require('Map tile server unavailable' in map_activity or 'MAP TILE SERVER UNAVAILABLE' in map_activity,'Offline tile status not truthful')
require('ByteArrayOutputStream out=new ByteArrayOutputStream()' in map_activity,'HTML asset loading is not robust')
require('https://appassets.androidplatform.net/assets/' in map_activity,'Map document has an unsafe/misleading base origin')
require('new Intent(this,DuwmPlaceMapActivity.class)' in app,'Geographic map not reachable')
require('new Intent(this,DuwmWorldIntelligenceActivity.class)' in map_activity,'Worldwide dashboard not reachable')
require('class DuwmWorldIntelligenceActivity' in world and 'loadAircraft' in world,'Worldwide dashboard implementation missing')
require('class MediaDeskActivity' in media,'In-app radio/TV source missing')
require('V115941ShareCards.share(' in app,'Selected observation sharing missing')
require('DuwmSignalRail' in rail,'Signal rail code absent')
manifest=ET.parse(MAIN/'AndroidManifest.xml').getroot()
android='{http://schemas.android.com/apk/res/android}'
activities=[v.attrib.get(android+'name','') for v in manifest.iter('activity')]
for name in ('OperationsMainActivity','DuwmPlaceMapActivity','DuwmWorldIntelligenceActivity','MediaDeskActivity'):
    require(any(a.endswith('.'+name) for a in activities),f'AndroidManifest unregistered: {name}')
permissions=[v.attrib.get(android+'name','') for v in manifest.iter('uses-permission')]
require('android.permission.INTERNET' in permissions,'No internet permission for actual OSM tiles')
html=(MAIN/'assets/duwm_place_map.html').read_text(encoding='utf-8')
for entry in ('tile.openstreetmap.org','window.duwmReceive','window.duwmMode','window.duwmFocus','window.duwmRenderStatus', 'AIS feed not configured', 'Source:', 'sourceLine'):
    require(entry in html,f'Map missing: {entry}')
for forbidden in ('Math.random(', 'fakePositions', 'demoAircraft', 'maplibregl.Map(', 'maplibregl-v6'):
    require(forbidden not in html,f'Forbidden map behavior: {forbidden}')
require("typeof p.lat==='number'" in html and "typeof p.time==='number'" in html, 'Map accepts missing coordinates/timestamps')
require('naturalearth_coasts.txt' in '\n'.join(x.name for x in (MAIN/'assets').iterdir()), 'Original real-coastline file missing')
require('DuwmLiveWallpaperService.java' in '\n'.join(x.name for x in PKG.iterdir()), 'Original live wallpaper code missing')
with tempfile.NamedTemporaryFile(mode='w',suffix='.js') as output:
    blocks=re.findall(r'<script(?: [^>]*)?>([\s\S]*?)</script>',html)
    require(len(blocks)==1,'Expected single self-contained map engine script')
    output.write(blocks[0]);output.flush()
    subprocess.run(['node','--check',output.name],check=True)
config=(ROOT/'app/build.gradle.kts').read_text()
require(('versionCode = 167000' in config and 'versionName = "1670"' in config) or ('versionCode = 167100' in config and 'versionName = "1671"' in config) or ('versionCode = 167200' in config and 'versionName = "1672"' in config),'Android version identity drifted')
report=json.loads((ROOT/'DUWM_REAL_SOURCE_CHANGE_REPORT.json').read_text())
for name,digest in report['unmodified_source_components'].items():
    actual=hashlib.sha256((PKG/name).read_bytes()).hexdigest()
    require(actual==digest,f'Protected component unexpectedly modified: {name}')
print('PASS: native source files, original globe, real source links, Android manifest, map JS and protected component hashes.')
print('NOT VERIFIED HERE: Gradle APK compilation, external tile requests, live provider receipts, device playback.')
