from pathlib import Path
import hashlib, json
from xml.etree import ElementTree as ET
P=Path(__file__).resolve().parents[1]
J=P/'app/src/main/java/com/sentongoharuna/worldsituationroom'
code=(J/'Duwm1668GeopoliticalLensActivity.java').read_text()
home=(J/'OperationsMainActivity.java').read_text()
assert 'versionCode = 167200' in (P/'app/build.gradle.kts').read_text()
assert 'versionName = "1672"' in (P/'app/build.gradle.kts').read_text()
assert 'GEO LENS 1668' in home and 'new Intent(this,Duwm1668GeopoliticalLensActivity.class)' in home
assert 'DuwmGeoObservationStore.publishType(this,kind,fresh)' in home
for token in ['DuwmGeoObservationStore.read(this)','new OperationsGlobeView(this)', 'setObservations(mapped)', 'earth.focusAt(f.lat,f.lon)','SOURCE TIME UNAVAILABLE','NO RECENT SOURCE FIXES','hasActualTrack()', 'SYNC SOURCES','Share observed data']:
 assert token in code,token
assert 'Math.random(' not in code
manifest=ET.parse(P/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
assert any(e.get(ns+'name')=='.Duwm1668GeopoliticalLensActivity' for e in manifest.iter('activity'))
report=json.loads((P/'DUWM_REAL_SOURCE_CHANGE_REPORT.json').read_text())
for name,digest in report['unmodified_source_components'].items():
 assert hashlib.sha256((J/name).read_bytes()).hexdigest()==digest, name+' protected file changed'
print('PASS DUWM 1668 source: real observation lens, geographic filters, data-driven globe, user access and preserved original core.')
