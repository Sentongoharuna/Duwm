#!/usr/bin/env python3
"""Guard the actual DUWM 1671 source additions; NOT a substitute for Android compilation or live provider testing."""
from pathlib import Path
from xml.etree import ElementTree as ET
import hashlib,json
P=Path(__file__).resolve().parents[1]
J=P/'app/src/main/java/com/sentongoharuna/worldsituationroom'
build=(P/'app/build.gradle.kts').read_text()
assert 'versionCode = 167200' in build and 'versionName = "1672"' in build
assert 'applicationId = "com.sentongoharuna.worldsituationroom.rb2live25"' in build
required={
 'Duwm1671MissionActivity.java':['new OperationsGlobeView(this)','globe.resume()','Duwm1670HomeTelemetryView','Duwm1671SectorActivity','Duwm1671SourceStatusActivity','Duwm1671Measurements.capture','RunningballV25GlobalAircraftData.refresh'],
 'Duwm1671SectorActivity.java':['"AIRCRAFT","VESSELS","NEWS","MARKETS","WEATHER","EARTHQUAKES","SATELLITES","TV STATIONS","PUBLIC CAMERAS","RADIO"','DuwmGeoObservationStore.read','Duwm1671Share.share','Duwm1671TrendView','Duwm1671EventBars','MediaDeskActivity','GevMarineActivity','GevSatelliteActivity'],
 'Duwm1671SourceStatusActivity.java':['RunningballV25Sources.IDS','lastHttp','nextCheckLabel','errorReason','NewsStore(this).load'],
 'Duwm1671Measurements.java':['getSharedPreferences','fetchedAt','JSONArray','o.optLong("received")==r.fetchedAt','history(Context c,int provider)'],
 'Duwm1671TrendView.java':['WAITING FOR TWO DISTINCT VERIFIED RECEIPTS','Historical values from actual cached provider receipts','SystemClock.uptimeMillis()'],
 'Duwm1671EventBars.java':['SOURCE-OBSERVED EVENTS','f.sourceTime','86400000L'],
 'Duwm1671Share.java':['W=1080,H=1920','NO PUBLISHER PHOTO ATTACHED','share-cards','SOURCE DATA / NOT INDEPENDENTLY VERIFIED','Bitmap.CompressFormat.PNG'],
 'Duwm1670FlightMapActivity.java':['callsignFilter','followSelected','SHARE FLIGHT CARD','SCENARIO ONLY','RunningballV25AircraftTrailPolicy.qualifies','setScenarioDestination'],
 'Duwm1670HomeTelemetryView.java':['"AIR","SEA","NEWS","WX","FX","QUAKE"','RunningballV25Sources','RunningballV25GlobalAircraftData'],
 'OperationsMainActivity.java':['"1672 GLOBAL MISSION"','new Intent(this,Duwm1671MissionActivity.class)','earth=new OperationsGlobeView(this)'],
}
for name,strings in required.items():
 s=(J/name).read_text()
 for token in strings:assert token.lower() in s.lower(),(name,token)
assert 'Math.random(' not in '\n'.join((J/x).read_text() for x in required if x!='OperationsMainActivity.java')
root=ET.parse(P/'app/src/main/AndroidManifest.xml').getroot();ns='{http://schemas.android.com/apk/res/android}'
activities={a.attrib.get(ns+'name','') for a in root.iter('activity')}
for a in ['Duwm1671MissionActivity','Duwm1671SectorActivity','Duwm1671SourceStatusActivity']:
 assert '.'+a in activities,('Manifest missing '+a)
old=json.loads((P/'DUWM_REAL_SOURCE_CHANGE_REPORT.json').read_text())['unmodified_source_components']
for name,sha in old.items():assert hashlib.sha256((J/name).read_bytes()).hexdigest()==sha,'Protected original component modified: '+name
assets=P/'app/src/main/assets'
assert (assets/'naturalearth_coasts.txt').stat().st_size>150000
assert (assets/'duwm_country_borders_wdbii.txt').stat().st_size>150000
assert len(json.loads((assets/'duwm_news_200_region_sources.json').read_text())['sources'])==200
assert len(json.loads((assets/'duwm_global_200_sources.json').read_text())['sources'])==200
print('PASS 1671: native mission, all ten specialist desk routes, true receipt charts, share-card exporter, flight follow, source-health transparency, original globe and retained source directories')
print('LIMITS: This checks source wiring and integrity, not Java compilation, actual provider availability, successful stream playback or on-device frame rates.')
