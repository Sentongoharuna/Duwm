package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** GEV Port 05 / Maritime Intelligence.
 * Public bounded Open Waters AIS snapshots are supported without an API key;
 * a private, properly authorized HTTPS gateway remains optional.
 * No AIS provider reception means no fabricated ships. Not for navigation. */
public final class GevMarineActivity extends Activity {
    private static final String PREF="rb11_marine";
    private static final long MAX_BYTES=8L*1024L*1024L,STALE_MS=30L*60L*1000L;
    private static final int BG=Color.rgb(7,13,21), FG=Color.rgb(231,245,251), CYAN=Color.rgb(119,226,244), MUTED=Color.rgb(141,166,183), GREEN=Color.rgb(96,236,178), AMBER=Color.rgb(251,187,114);
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final ArrayList<Ship> ships=new ArrayList<>();
    private TextView banner,detail,summary,foot;private EditText endpoint,search;private LinearLayout list;private GevMarineRadarView radar;
    private String sourceStatus="not configured",sourceName="AISStream gateway";
    private boolean loading;private int selected=-1;private long lastSuccess;private String error="";
    private static final String[] PUBLIC_REGIONS={
      "EAST AFRICA / INDIAN OCEAN", "GULF OF ADEN", "RED SEA", "MEDITERRANEAN",
      "NORTH SEA / EUROPE", "ARABIAN GULF", "BAY OF BENGAL", "SINGAPORE / MALACCA",
      "JAPAN", "EAST CHINA SEA", "US ATLANTIC", "GULF OF MEXICO",
      "PANAMA", "BRAZIL / SOUTH ATLANTIC", "SOUTH AFRICA", "AUSTRALIA / TASMAN"};
    // Each public area is <=100 square degrees; a region is a request window,
    // not a claim of comprehensive regional AIS receiver coverage.
    private static final double[][] PUBLIC_BBOX={
      {-7,37,-1,43},{10,42,16,50},{18,34,26,42},{32,12,40,20},
      {49,0,57,8},{22,48,30,56},{10,80,18,88},{0,99,6,106},
      {31,133,39,141},{22,114,30,122},{35,-78,43,-70},{25,-94,31,-86},
      {6,-83,12,-77},{-28,-47,-20,-39},{-37,15,-29,23},{-37,146,-29,154}};
    private int publicRegion=0;private long lastPublicRequest=0L;
    private final Runnable publicPoller=new Runnable(){
        @Override public void run(){
            if(!isFinishing()&&endpoint!=null&&endpoint.getText().toString().trim().isEmpty()&&
               System.currentTimeMillis()-lastPublicRequest>=60000L)fetchPublic();
            ui.postDelayed(this,60000L);
        }
    };
    private boolean showMovingOnly=false;
    private int visibleShipRows=85; // Lazy pagination, not a maximum number of available ships.

    private static final class Ship {
        String mmsi="",name="",imo="",type="",destination="";
        double lat,lon,sog=Double.NaN,cog=Double.NaN,heading=Double.NaN;
        long observed;
    }
    private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable background(boolean sel){GradientDrawable d=new GradientDrawable();d.setColor(Color.rgb(17,26,36));d.setCornerRadius(dp(23));d.setStroke(dp(1),sel?CYAN:Color.rgb(55,108,126));return d;}
    private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private TextView button(String text,Runnable run){TextView b=txt(text,11,CYAN,true);b.setGravity(Gravity.CENTER);b.setBackground(background(false));b.setOnClickListener(v->run.run());return b;}
    private SharedPreferences prefs(){return getSharedPreferences(PREF,MODE_PRIVATE);}
    @Override protected void onCreate(Bundle state){super.onCreate(state);RunningballV17Insets.install(this);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        // One scrollable document fixes fixed-height controls crowding out
        // the vessel list on phone screens with navigation or display scaling.
        ScrollView page=new ScrollView(this);page.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);root.setPadding(dp(12),dp(10),dp(12),dp(10));
        root.addView(txt("RUNNINGBALL2 / GOD'S EYE VIEW PORT 05",11,CYAN,true),new LinearLayout.LayoutParams(-1,dp(25)));
        root.addView(txt("MARITIME INTELLIGENCE",22,FG,true),new LinearLayout.LayoutParams(-1,dp(42)));
        banner=txt("NO AIS FEED CONNECTED",12,AMBER,true);root.addView(banner,new LinearLayout.LayoutParams(-1,dp(44)));
        endpoint=new EditText(this);endpoint.setSingleLine(true);endpoint.setTextColor(FG);endpoint.setHintTextColor(MUTED);endpoint.setTextSize(12);
        endpoint.setHint("https://your-ais-server.example/api/vessels");endpoint.setBackground(background(false));endpoint.setPadding(dp(12),0,dp(10),0);
        endpoint.setText(prefs().getString("endpoint",""));
        root.addView(endpoint,new LinearLayout.LayoutParams(-1,dp(45)));
        TextView guide=txt("OPTIONAL HTTPS AIS GATEWAY • PUBLIC REGIONAL AIS BELOW NEEDS NO KEY",10,MUTED,false);
        root.addView(guide,new LinearLayout.LayoutParams(-1,dp(28)));
        LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.addView(button("CONNECT / REFRESH",()->fetch(true)),new LinearLayout.LayoutParams(0,dp(43),1.25f));
        LinearLayout.LayoutParams moving=new LinearLayout.LayoutParams(0,dp(43),1f);moving.leftMargin=dp(6);
        controls.addView(button("MOVING / ALL",()->{showMovingOnly=!showMovingOnly;render();}),moving);root.addView(controls);
        TextView publicTitle=txt("PUBLIC AIS / NO API KEY  •  SELECT AN OCEAN REGION",11,CYAN,true);
        LinearLayout.LayoutParams pl=new LinearLayout.LayoutParams(-1,dp(32));pl.topMargin=dp(6);root.addView(publicTitle,pl);
        Spinner publicAreas=new Spinner(this);
        ArrayAdapter<String> regions=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,PUBLIC_REGIONS);
        regions.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        publicAreas.setAdapter(regions);publicAreas.setBackground(background(false));root.addView(publicAreas,new LinearLayout.LayoutParams(-1,dp(48)));
        publicRegion=Math.min(PUBLIC_REGIONS.length-1,Math.max(0,prefs().getInt("public_region",0)));
        publicAreas.setSelection(publicRegion);
        publicAreas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(AdapterView<?> parent,android.view.View view,int index,long id){
                publicRegion=index;prefs().edit().putInt("public_region",index).apply();
                if(radar!=null){double[] a=PUBLIC_BBOX[index];radar.setPort((a[0]+a[2])/2,(a[1]+a[3])/2,500);}
            }
            @Override public void onNothingSelected(AdapterView<?> parent){}
        });
        TextView publicLoad=button("LOAD ACTUAL PUBLIC AIS POSITIONS  ↻",this::fetchPublic);
        LinearLayout.LayoutParams publicLp=new LinearLayout.LayoutParams(-1,dp(46));publicLp.topMargin=dp(6);root.addView(publicLoad,publicLp);
        search=new EditText(this);search.setSingleLine(true);search.setTextColor(FG);search.setHintTextColor(MUTED);search.setHint("Search name • MMSI • destination");
        search.setTextSize(13);search.setPadding(dp(12),0,dp(10),0);search.setBackground(background(false));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(43));sp.topMargin=dp(7);root.addView(search,sp);
        summary=txt("0 VERIFIED VESSEL REPORTS",12,CYAN,true);root.addView(summary,new LinearLayout.LayoutParams(-1,dp(34)));
        LinearLayout ports=new LinearLayout(this);ports.setOrientation(LinearLayout.HORIZONTAL);
        ports.addView(button("MOMBASA",()->radar.setPort(-4.04,39.67,140)),new LinearLayout.LayoutParams(0,dp(31),1));
        ports.addView(button("DAR ES SALAAM",()->radar.setPort(-6.82,39.28,140)),new LinearLayout.LayoutParams(0,dp(31),1));
        ports.addView(button("DURBAN",()->radar.setPort(-29.88,31.05,140)),new LinearLayout.LayoutParams(0,dp(31),1));
        root.addView(ports);
        radar=new GevMarineRadarView(this);root.addView(radar,new LinearLayout.LayoutParams(-1,dp(170)));
        radar.setOnShipSelected(index->{selected=index;showSelected();renderList();});
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list,new LinearLayout.LayoutParams(-1,-2));
        detail=txt("SELECT A VESSEL TO VIEW ITS LAST REPORTED POSITION",12,FG,true);root.addView(detail,new LinearLayout.LayoutParams(-1,dp(71)));
        LinearLayout bottom=new LinearLayout(this);bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.addView(button("EARTH POSITION",this::openEarth),new LinearLayout.LayoutParams(0,dp(44),1));
        LinearLayout.LayoutParams share=new LinearLayout.LayoutParams(0,dp(44),1);share.leftMargin=dp(7);bottom.addView(button("SHARE CARD",this::share),share);
        root.addView(bottom);
        foot=txt("OPEN WATERS PUBLIC AIS OR OPTIONAL HTTPS GATEWAY • NOT FOR NAVIGATION",10,MUTED,false);
        root.addView(foot,new LinearLayout.LayoutParams(-1,dp(33)));
        page.addView(root,new ScrollView.LayoutParams(-1,-2));setContentView(page);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){renderList();}
            public void afterTextChanged(Editable e){} });
        restore();render();if(!endpoint.getText().toString().trim().isEmpty())fetch(false);else fetchPublic();
    }
    private static long timestamp(JSONObject row){
        double raw=row.optDouble("last_position_epoch",Double.NaN);
        if(GevMarineMath.finite(raw)&&raw>0d){long n=(long)raw;return n<100000000000L?n*1000L:n;}
        String iso=row.optString("last_position_UTC","");if(iso.isEmpty())return 0L;
        try{String trimmed=iso.trim();if(trimmed.endsWith("Z"))trimmed=trimmed.substring(0,trimmed.length()-1);
            if(trimmed.length()>19)trimmed=trimmed.substring(0,19);
            SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date d=f.parse(trimmed);return d==null?0L:d.getTime();}catch(Exception ignored){return 0L;}
    }
    private void decode(String json,boolean freshNetwork){
        ArrayList<Ship> found=new ArrayList<>();
        JSONObject data;try{data=new JSONObject(json);}catch(Exception e){error="INVALID AIS GATEWAY JSON";return;}
        JSONArray arr=data.optJSONArray("rows");if(arr==null){error="AIS GATEWAY RESPONSE LACKS rows ARRAY";return;}
        sourceName=data.optString("source","AISStream gateway");sourceStatus=data.optString("status","unknown");
        for(int i=0;i<arr.length()&&found.size()<18000;i++){
            JSONObject row=arr.optJSONObject(i);if(row==null)continue;
            Ship ship=new Ship();ship.lat=row.optDouble("lat",Double.NaN);ship.lon=row.optDouble("lon",Double.NaN);
            ship.mmsi=row.optString("mmsi","").trim();if(!GevMarineMath.valid(ship.lat,ship.lon)||!GevMarineMath.validMmsi(ship.mmsi))continue;
            ship.name=row.optString("name","").trim();if(ship.name.isEmpty())ship.name="MMSI "+ship.mmsi;
            ship.imo=row.optString("imo","");ship.type=row.optString("type","");ship.destination=row.optString("destination","");
            ship.sog=row.optDouble("speed",Double.NaN);ship.cog=row.optDouble("course",Double.NaN);ship.heading=row.optDouble("heading",Double.NaN);
            ship.observed=timestamp(row);found.add(ship);
        }
        if(freshNetwork)lastSuccess=System.currentTimeMillis();
        ships.clear();ships.addAll(found);selected=-1;
        Collections.sort(ships,(a,b)->Long.compare(b.observed,a.observed));
    }
    private void restore(){lastSuccess=prefs().getLong("last_fetch",0L);sourceStatus=prefs().getString("status","cached");
        String raw=prefs().getString("rows","");if(!raw.isEmpty())decode(raw,false);}
    private void fetch(boolean manual){if(loading)return;
        String rawUrl=endpoint.getText().toString().trim();
        try{URL u=new URL(rawUrl);if(!"https".equalsIgnoreCase(u.getProtocol())||u.getUserInfo()!=null||u.getQuery()!=null)
            throw new IllegalArgumentException("HTTPS URL WITHOUT CREDENTIALS OR QUERY REQUIRED");
            if(u.getHost()==null||u.getHost().isEmpty())throw new IllegalArgumentException("INVALID HOST");
        }catch(Exception e){banner.setText("CONFIGURE HTTPS AIS GATEWAY • NOT CONNECTED");return;}
        prefs().edit().putString("endpoint",rawUrl).apply();loading=true;banner.setText("CONNECTING TO AIS SNAPSHOT …");
        io.execute(()->{String content=null;String failure=null;HttpURLConnection c=null;
            try{c=(HttpURLConnection)new URL(rawUrl+(rawUrl.endsWith("?")?"":"?maxRows=5000")).openConnection();c.setConnectTimeout(8500);c.setReadTimeout(9500);
                c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","RUNNINGBALL2-Maritime/11");
                if(c.getResponseCode()!=200)throw new IllegalStateException("AIS GATEWAY HTTP "+c.getResponseCode());
                try(InputStream s=c.getInputStream();ByteArrayOutputStream b=new ByteArrayOutputStream()){
                    byte[] buf=new byte[8192];int n;while((n=s.read(buf))!=-1){if(b.size()+n>MAX_BYTES)throw new IllegalStateException("AIS SNAPSHOT EXCEEDS MEMORY SAFETY BOUND");b.write(buf,0,n);}content=b.toString("UTF-8");}
                JSONObject verify=new JSONObject(content);if(!verify.has("rows")||verify.optJSONArray("rows")==null)throw new IllegalStateException("AIS JSON MISSING rows");
            }catch(Exception e){failure=e.getMessage()==null?"AIS CONNECTION ERROR":e.getMessage();}finally{if(c!=null)c.disconnect();}
            final String data=content,fail=failure;
            ui.post(()->{loading=false;if(isFinishing())return;
                if(fail==null&&data!=null){error="";decode(data,true);
                    prefs().edit().putString("rows",data).putString("status",sourceStatus).putLong("last_fetch",lastSuccess).apply();
                }else{error=fail==null?"NO DATA":fail;sourceStatus="offline";}
                render();GevMaritimeWidget.updateAll(this);RunningballV14SignalWidget.updateAll(this);
            });
        });
    }
    /** Open Waters anonymous GeoJSON endpoint, 2026 public API. It accepts only
     * geographically bounded requests for unauthenticated clients; never send a
     * global anonymous request, bypass authentication or invent ship markers. */
    private void fetchPublic(){
        if(loading)return;
        long now=System.currentTimeMillis();if(now-lastPublicRequest<8000L){banner.setText("PUBLIC AIS REQUEST ALREADY SENT • WAIT FOR RECEIPT");return;}
        lastPublicRequest=now;loading=true;error="";
        final int region=Math.max(0,Math.min(PUBLIC_REGIONS.length-1,publicRegion));
        final double[] b=PUBLIC_BBOX[region];
        final String address=String.format(Locale.US,
            "https://ais.openwaters.io/v1/vessels?bbox=%.5f,%.5f,%.5f,%.5f",
            b[0],b[1],b[2],b[3]);
        banner.setText("REQUESTING PUBLIC AIS • "+PUBLIC_REGIONS[region]);
        io.execute(()->{
            String data=null,failure=null;HttpURLConnection c=null;
            try{
                c=(HttpURLConnection)new URL(address).openConnection();
                c.setConnectTimeout(10000);c.setReadTimeout(16000);
                c.setRequestProperty("Accept","application/geo+json, application/json");
                c.setRequestProperty("User-Agent","develop.uganda-DUWM-1672/1.0");
                int http=c.getResponseCode();if(http!=200)throw new IllegalStateException("OPEN WATERS HTTP "+http+(http==429?" / RATE LIMITED":""));
                ByteArrayOutputStream out=new ByteArrayOutputStream();
                try(InputStream in=c.getInputStream()){
                    byte[] buffer=new byte[8192];int n;
                    while((n=in.read(buffer))!=-1){if(out.size()+n>MAX_BYTES)throw new IllegalStateException("AIS RESPONSE EXCEEDS MEMORY SAFETY BOUND");out.write(buffer,0,n);}
                }
                JSONObject featureCollection=new JSONObject(out.toString("UTF-8"));
                JSONArray features=featureCollection.optJSONArray("features");
                if(features==null)throw new IllegalStateException("AIS DID NOT RETURN A GEOJSON FEATURE LIST");
                JSONArray rows=new JSONArray();
                for(int i=0;i<features.length();i++){
                    JSONObject feature=features.optJSONObject(i);if(feature==null)continue;
                    JSONObject geo=feature.optJSONObject("geometry");JSONObject properties=feature.optJSONObject("properties");
                    if(geo==null||properties==null)continue;
                    JSONArray coordinates=geo.optJSONArray("coordinates");
                    if(coordinates==null||coordinates.length()<2)continue;
                    double lon=coordinates.optDouble(0,Double.NaN),lat=coordinates.optDouble(1,Double.NaN);
                    if(!GevMarineMath.valid(lat,lon))continue;
                    JSONObject v=new JSONObject();v.put("lat",lat);v.put("lon",lon);
                    v.put("mmsi",properties.optString("mmsi",feature.optString("id","")));
                    v.put("name",properties.optString("name",""));v.put("type",properties.optString("type",""));
                    v.put("speed",properties.has("sog")?properties.optDouble("sog"):JSONObject.NULL);
                    v.put("course",properties.has("cog")?properties.optDouble("cog"):JSONObject.NULL);
                    v.put("heading",properties.has("heading")?properties.optDouble("heading"):JSONObject.NULL);
                    v.put("last_position_UTC",properties.optString("seen",""));
                    rows.put(v);
                }
                JSONObject packet=new JSONObject();packet.put("rows",rows);
                packet.put("source","Open Waters AIS / anonymous area GeoJSON");
                packet.put("status","live");packet.put("region",PUBLIC_REGIONS[region]);
                packet.put("sourceUrl",address);data=packet.toString();
            }catch(Exception e){failure=e.getMessage()==null?"PUBLIC AIS UNAVAILABLE":e.getMessage();}
            finally{if(c!=null)c.disconnect();}
            final String json=data,err=failure;
            ui.post(()->{
                loading=false;if(isFinishing())return;
                if(json!=null&&err==null){error="";decode(json,true);
                    prefs().edit().putString("rows",json).putString("status",sourceStatus)
                        .putLong("last_fetch",lastSuccess).apply();
                    double[] r=PUBLIC_BBOX[region];radar.setPort((r[0]+r[2])/2,(r[1]+r[3])/2,500);
                }else{error=err==null?"NO AIS RESPONSE":err;sourceStatus="offline";}
                render();GevMaritimeWidget.updateAll(this);RunningballV14SignalWidget.updateAll(this);
            });
        });
    }
    private String utc(long t){if(t<=0L)return "NO TIMESTAMP";SimpleDateFormat f=new SimpleDateFormat("dd MMM HH:mm 'UTC'",Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(t));}
    private Ship chosen(){return selected>=0&&selected<ships.size()?ships.get(selected):null;}
    private void render(){long now=System.currentTimeMillis();int recent=0,moving=0;
        for(Ship ship:ships){if("RECENT".equals(GevMarineMath.freshness(ship.observed,now)))recent++;
            if(GevMarineMath.reported(ship.sog)&&ship.sog>0.5d)moving++;}
        boolean live="live".equalsIgnoreCase(sourceStatus)&&recent>0&&error.isEmpty()&&lastSuccess>0&&now-lastSuccess<180000L;
        if(ships.isEmpty()){banner.setText(error.isEmpty()?"NO AIS RECEIVED IN THIS REGION • CHOOSE A REGION / RETRY":"AIS UNAVAILABLE • "+error);}
        else banner.setText((live?"LIVE AIS REPORTS":"AIS CACHED / UNVERIFIED")+" • "+sourceStatus.toUpperCase(Locale.US)+(error.isEmpty()?"":" • "+error));
        boolean connected=!prefs().getString("endpoint","").trim().isEmpty() ||
            sourceName.startsWith("Open Waters") || lastPublicRequest>0L;
        summary.setText(!connected?"AIS NOT REQUESTED  •  SELECT PUBLIC REGION OR CONNECT GATEWAY":
          lastSuccess<=0?"AIS DATA NOT RECEIVED  •  REPORTED VESSELS --":
          ships.size()+" REPORTED VESSELS  •  "+recent+" RECENT  •  "+moving+" MOVING");
        foot.setText(sourceName+" • RECEIVED "+utc(lastSuccess)+" • AIS COVERAGE IS PARTIAL / POSITIONS MAY BE STALE");
        ArrayList<GevMarineRadarView.Point> plots=new ArrayList<>();
        for(int i=0;i<ships.size();i++){Ship ship=ships.get(i);
            plots.add(new GevMarineRadarView.Point(i,ship.lat,ship.lon,ship.observed,ship.name,ship.mmsi));}
        radar.setRecords(plots);
        renderList();showSelected();
    }
    private void renderList(){if(list==null)return;list.removeAllViews();String q=search.getText().toString().trim().toLowerCase(Locale.US);long now=System.currentTimeMillis();int shown=0,eligible=0;
        for(int i=0;i<ships.size();i++){
            Ship v=ships.get(i);if(showMovingOnly&&(!GevMarineMath.reported(v.sog)||v.sog<0.5d))continue;
            String label=(v.name+" "+v.mmsi+" "+v.destination+" "+v.type).toLowerCase(Locale.US);if(!label.contains(q))continue;
            eligible++;if(shown>=visibleShipRows)continue;
            String speed=GevMarineMath.reported(v.sog)?String.format(Locale.US,"%.1f kn",v.sog):"SPEED --";
            final int index=i;
            String line=v.name+"\n"+v.mmsi+"  •  "+speed+"  •  "+GevMarineMath.freshness(v.observed,now);
            TextView item=txt(line,12,i==selected?CYAN:FG,i==selected);item.setPadding(dp(12),dp(6),dp(9),dp(6));item.setBackground(background(i==selected));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(64));lp.bottomMargin=dp(6);list.addView(item,lp);
            item.setOnClickListener(view->{selected=index;showSelected();renderList();});shown++;
        }
        if(shown==0)list.addView(txt(ships.isEmpty()?"NO VESSELS RECEIVED. CHECK REGION, COVERAGE AND PROVIDER STATUS.":"NO VESSELS MATCH THIS FILTER",12,MUTED,false));
        if(eligible>shown){
            final int remaining=eligible-shown;
            TextView load=button("LOAD MORE VERIFIED SHIPS  •  "+remaining+" REMAINING",()->{visibleShipRows+=85;renderList();});
            list.addView(load,new LinearLayout.LayoutParams(-1,dp(52)));
        }
    }
    private void showSelected(){Ship s=chosen();if(s==null){detail.setText("SELECT A VESSEL TO INSPECT REPORTED POSITION");return;}
        String speed=GevMarineMath.reported(s.sog)?String.format(Locale.US,"%.1f KNOTS",s.sog):"SPEED UNKNOWN";
        String cog=GevMarineMath.finite(s.cog)?String.format(Locale.US,"%.0f°",s.cog):"--";
        detail.setText(s.name+" • "+speed+" • COG "+cog+"\n"+String.format(Locale.US,"%.4f, %.4f",s.lat,s.lon)+" • "+utc(s.observed));
    }
    private void openEarth(){Ship s=chosen();if(s==null){banner.setText("SELECT A VESSEL FIRST");return;}
        Intent i=new Intent(this,GevEarthExploreActivity.class);i.putExtra("geo_lat",s.lat);i.putExtra("geo_lon",s.lon);
        i.putExtra("marine_observed",true);i.putExtra("marine_name",s.name);startActivity(i);
    }
    private void share(){Ship s=chosen();if(s==null){banner.setText("SELECT A VESSEL FIRST");return;}
        LinkedHashMap<String,String> facts=new LinkedHashMap<>();facts.put("MMSI",s.mmsi);facts.put("POSITION",String.format(Locale.US,"%.4f, %.4f",s.lat,s.lon));
        facts.put("SPEED",GevMarineMath.reported(s.sog)?String.format(Locale.US,"%.1f kn",s.sog):"Unavailable");
        facts.put("COURSE",GevMarineMath.finite(s.cog)?String.format(Locale.US,"%.0f°",s.cog):"Unavailable");
        facts.put("HEADING",GevMarineMath.finite(s.heading)?String.format(Locale.US,"%.0f°",s.heading):"Unavailable");
        facts.put("DESTINATION",s.destination.isEmpty()?"Not reported":s.destination);
        facts.put("LAST AIS POSITION",utc(s.observed));facts.put("FEED STATUS",sourceStatus);
        ShareCardRenderer.share(this,new ShareCardData(s.name,"Last reported AIS vessel location; not a live-video observation.",
            "MARITIME AIS",GevMarineMath.freshness(s.observed,System.currentTimeMillis()),"MARITIME","GLOBAL",1,
            sourceName,"",s.observed>0?s.observed:lastSuccess,s.lat,s.lon,facts,CYAN,
            "AIS reception and timestamps may be delayed or incomplete. Not for navigation or safety decisions."));
    }
    @Override protected void onResume(){super.onResume();ui.removeCallbacks(publicPoller);ui.postDelayed(publicPoller,60000L);}
    @Override protected void onPause(){ui.removeCallbacks(publicPoller);super.onPause();}
    @Override protected void onDestroy(){super.onDestroy();io.shutdownNow();ui.removeCallbacksAndMessages(null);}
}
