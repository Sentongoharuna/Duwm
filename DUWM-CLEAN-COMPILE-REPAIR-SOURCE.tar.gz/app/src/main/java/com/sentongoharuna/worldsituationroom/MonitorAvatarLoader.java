package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.View;
import android.widget.ImageView;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.net.ssl.HttpsURLConnection;

/** Bounded HTTPS image loader for reporter avatars; failures retain the initials fallback. */
public final class MonitorAvatarLoader {
    private static final int MAX_AVATAR_BYTES = 2 * 1024 * 1024;
    private static final int MAX_DECODE_EDGE = 384;
    private final File cacheDirectory;
    private final ExecutorService executor = Executors.newFixedThreadPool(2);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final LruCache<String, Bitmap> memory = new LruCache<String, Bitmap>(4 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) {
            return value == null ? 0 : value.getByteCount();
        }
    };

    public MonitorAvatarLoader(Context context) {
        cacheDirectory = new File(context.getCacheDir(), "monitor-avatars");
        if (!cacheDirectory.exists()) cacheDirectory.mkdirs();
    }

    public void load(String avatarUrl, ImageView image, View fallback) {
        if (!MonitorReport.safeHttps(avatarUrl) || image == null) return;
        final String key = digest(avatarUrl);
        image.setTag(key);
        Bitmap remembered = memory.get(key);
        if (remembered != null && !remembered.isRecycled()) {
            showIfCurrent(key, image, fallback, remembered);
            return;
        }
        File cached = new File(cacheDirectory, key + ".img");
        Bitmap local = cached.isFile() ? decodeBoundedFile(cached) : null;
        if (local != null) {
            memory.put(key, local);
            showIfCurrent(key, image, fallback, local);
            return;
        }
        executor.execute(() -> {
            HttpsURLConnection connection = null;
            try {
                connection = (HttpsURLConnection) new URL(avatarUrl).openConnection();
                connection.setInstanceFollowRedirects(false);
                connection.setConnectTimeout(8_000);
                connection.setReadTimeout(12_000);
                connection.setRequestProperty("Accept", "image/*");
                int code = connection.getResponseCode();
                if (code < 200 || code >= 300) return;
                int length = connection.getContentLength();
                if (length > MAX_AVATAR_BYTES) return;
                byte[] bytes;
                try (BufferedInputStream input = new BufferedInputStream(connection.getInputStream());
                     ByteArrayOutputStream output = new ByteArrayOutputStream(
                             Math.max(8_192, Math.min(MAX_AVATAR_BYTES, Math.max(0, length))))) {
                    byte[] buffer = new byte[16 * 1024];
                    int total = 0;
                    int read;
                    while ((read = input.read(buffer)) != -1) {
                        total += read;
                        if (total > MAX_AVATAR_BYTES) return;
                        output.write(buffer, 0, read);
                    }
                    bytes = output.toByteArray();
                }
                Bitmap bitmap = decodeBoundedBytes(bytes);
                if (bitmap == null) return;
                memory.put(key, bitmap);
                File partial = new File(cacheDirectory, key + ".part");
                try (FileOutputStream output = new FileOutputStream(partial)) {
                    output.write(bytes);
                }
                if (!partial.renameTo(cached)) partial.delete();
                main.post(() -> showIfCurrent(key, image, fallback, bitmap));
            } catch (Exception | OutOfMemoryError ignored) {
                // The initials fallback is deliberately retained for unavailable remote images.
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    /** Loads the app-owned profile image through the same bounded memory cache. */
    public void loadLocal(File file, ImageView image, View fallback) {
        if (file == null || image == null || !file.isFile()) return;
        final String key = "local:" + file.getAbsolutePath() + ':' + file.lastModified();
        image.setTag(key);
        Bitmap remembered = memory.get(key);
        if (remembered != null && !remembered.isRecycled()) {
            showIfCurrent(key, image, fallback, remembered);
            return;
        }
        try {
            Bitmap bitmap = decodeBoundedFile(file);
            if (bitmap == null) return;
            memory.put(key, bitmap);
            showIfCurrent(key, image, fallback, bitmap);
        } catch (RuntimeException | OutOfMemoryError ignored) {
            // Initials remain visible when a damaged image or low-memory device refuses decode.
        }
    }

    private void showIfCurrent(String key, ImageView image, View fallback, Bitmap bitmap) {
        if (!key.equals(image.getTag())) return;
        image.setImageBitmap(bitmap);
        image.setVisibility(View.VISIBLE);
        if (fallback != null) fallback.setVisibility(View.GONE);
    }

    public void shutdown() {
        executor.shutdownNow();
        main.removeCallbacksAndMessages(null);
    }

    private static Bitmap decodeBoundedFile(File file) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
        BitmapFactory.Options decode = boundedOptions(bounds);
        try {
            return decode == null ? null : BitmapFactory.decodeFile(file.getAbsolutePath(), decode);
        } catch (RuntimeException | OutOfMemoryError ignored) {
            return null;
        }
    }

    private static Bitmap decodeBoundedBytes(byte[] bytes) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
        BitmapFactory.Options decode = boundedOptions(bounds);
        try {
            return decode == null ? null : BitmapFactory.decodeByteArray(
                    bytes, 0, bytes.length, decode);
        } catch (RuntimeException | OutOfMemoryError ignored) {
            return null;
        }
    }

    private static BitmapFactory.Options boundedOptions(BitmapFactory.Options bounds) {
        if (bounds.outWidth < 1 || bounds.outHeight < 1
                || bounds.outWidth > 20_000 || bounds.outHeight > 20_000) return null;
        int sample = 1;
        while (bounds.outWidth / sample > MAX_DECODE_EDGE
                || bounds.outHeight / sample > MAX_DECODE_EDGE) {
            sample *= 2;
        }
        BitmapFactory.Options decode = new BitmapFactory.Options();
        decode.inSampleSize = Math.max(1, sample);
        decode.inPreferredConfig = Bitmap.Config.ARGB_8888;
        return decode;
    }

    private static String digest(String value) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256")
                    .digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder output = new StringBuilder();
            for (int index = 0; index < 12; index++) {
                output.append(String.format(java.util.Locale.US, "%02x", hash[index]));
            }
            return output.toString();
        } catch (Exception ignored) {
            return Integer.toHexString(value.hashCode());
        }
    }
}
