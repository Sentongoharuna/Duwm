package com.sentongoharuna.worldsituationroom;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Native short-video desk for location-labelled eyewitness reporting. It borrows the immediate,
 * vertical interaction model of story apps without copying their branding or hiding source state.
 */
public final class LocalMonitorActivity extends Activity {
    private static final int BG = Color.rgb(5, 8, 12);
    private static final int PANEL = Color.rgb(8, 12, 17);
    private static final int PANEL_ALT = Color.rgb(14, 21, 29);
    private static final int LINE = Color.rgb(39, 53, 65);
    private static final int TEXT = Color.rgb(235, 241, 244);
    private static final int MUTED = Color.rgb(139, 155, 166);
    private static final int CYAN = Color.rgb(112, 177, 201);
    private static final int RED = Color.rgb(219, 73, 80);
    private static final int GREEN = Color.rgb(75, 166, 124);
    private static final int AMBER = Color.rgb(199, 151, 68);

    private static final int REQUEST_CAPTURE = 4101;
    private static final int REQUEST_PICK = 4102;
    private static final int REQUEST_LOCATION = 4103;
    private static final int REQUEST_AVATAR = 4104;
    private static final String EXTRA_SAFE_MEDIA = "safe_media";
    private static final String EXTRA_FORCE_MEDIA = "force_full_media";
    private static final String[] FILTERS = {"FOR YOU", "LIVE", "NEARBY", "FOLLOWING"};

    private final ExecutorService fileExecutor = Executors.newSingleThreadExecutor();
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final List<MonitorReport> reports = new ArrayList<>();
    private final List<ProgressBar> progressSegments = new ArrayList<>();
    private final Set<String> uploadingIds = new HashSet<>();
    private final SimpleDateFormat utcTime = new SimpleDateFormat("dd MMM • HH:mm 'UTC'", Locale.US);

    private MonitorProfileStore profiles;
    private MonitorStore store;
    private MonitorApiClient api;
    private MonitorAvatarLoader avatarLoader;
    private LinearLayout storyRow;
    private LinearLayout filterRow;
    private LinearLayout chromeDetails;
    private FrameLayout reportStage;
    private TextView networkState;
    private TextView positionState;
    private ProgressBar networkProgress;
    private ProgressBar uploadMeter;
    private StoryVideoView activeVideo;
    private String filter = "FOR YOU";
    private int currentIndex;
    private String pendingCaptureFile = "";
    private String requestedReportId = "";
    private boolean attachCoordinates;
    private boolean chromeExpanded = true;
    private boolean navigating;
    private float touchDownX;
    private float touchDownY;
    private long touchDownAt;
    private long lastTapAt;
    private boolean holdMuted;
    private Runnable pendingSingleTap;
    private boolean destroyed;
    private boolean mediaSafeMode;

    private final Runnable muteHold = () -> {
        if (activeVideo == null || destroyed) return;
        holdMuted = true;
        activeVideo.setMuted(true);
        Toast.makeText(this, "MUTED • RELEASE TO RESTORE SOUND", Toast.LENGTH_SHORT).show();
    };

    private final Runnable progressTick = new Runnable() {
        @Override public void run() {
            if (destroyed) return;
            try {
                updateStoryProgress();
            } catch (RuntimeException error) {
                CrashLedger.recordRecovered(
                        LocalMonitorActivity.this, "LocalMonitorActivity.progressTick", error);
                stopVideo();
                mediaSafeMode = true;
            }
            uiHandler.postDelayed(this, 160L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        utcTime.setTimeZone(TimeZone.getTimeZone("UTC"));
        boolean forceMedia = getIntent().getBooleanExtra(EXTRA_FORCE_MEDIA, false);
        mediaSafeMode = getIntent().getBooleanExtra(EXTRA_SAFE_MEDIA, false)
                || !forceMedia && CrashLedger.recentCrashMentions(
                this, "LocalMonitorActivity");
        try {
            profiles = new MonitorProfileStore(this);
            store = new MonitorStore(this);
            api = new MonitorApiClient(profiles);
            avatarLoader = new MonitorAvatarLoader(this);
            requestedReportId = MonitorReport.trim(
                    getIntent().getStringExtra("report_id"), 120);
            buildInterface();
            refreshFeed(true);
            uiHandler.post(progressTick);
            uiHandler.postDelayed(this::resumeQueuedUploads, 900L);
            uiHandler.postDelayed(() -> {
                if (!destroyed) CrashLedger.markStable(this);
            }, 8_000L);
        } catch (RuntimeException error) {
            String reference = CrashLedger.recordRecovered(
                    this, "LocalMonitorActivity.onCreate", error);
            showLocalMonitorRecovery(reference);
        }
    }

    private void showLocalMonitorRecovery(String reference) {
        stopVideo();
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setGravity(Gravity.CENTER);
        shell.setPadding(dp(24), dp(28), dp(24), dp(28));
        shell.setBackgroundColor(BG);
        TextView title = text("LOCAL MONITORS RECOVERED SAFELY", AMBER, 16, true);
        title.setGravity(Gravity.CENTER);
        shell.addView(title);
        TextView detail = text(
                "Your saved reports were not deleted. Open the feed in safe video mode, or return to the globe.",
                TEXT, 10, false);
        detail.setGravity(Gravity.CENTER);
        shell.addView(detail, marginParams(0, 10, 0, 16));
        TextView code = text("CRASH REFERENCE • " + fallback(reference, "NOT AVAILABLE"),
                CYAN, 8, true);
        code.setGravity(Gravity.CENTER);
        shell.addView(code, marginParams(0, 0, 0, 18));
        Button safe = actionButton("OPEN REPORTS IN SAFE VIDEO MODE", CYAN);
        safe.setOnClickListener(view -> restartLocal(true, false));
        shell.addView(safe, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        Button globe = actionButton("RETURN TO GLOBE", TEXT);
        globe.setOnClickListener(view -> finish());
        shell.addView(globe, marginParams(0, 8, 0, 0));
        setContentView(shell);
    }

    private void restartLocal(boolean safeMedia, boolean forceMedia) {
        Intent restart = new Intent(this, LocalMonitorActivity.class);
        restart.putExtra(EXTRA_SAFE_MEDIA, safeMedia);
        restart.putExtra(EXTRA_FORCE_MEDIA, forceMedia);
        if (!requestedReportId.isEmpty()) restart.putExtra("report_id", requestedReportId);
        startActivity(restart);
        finish();
    }

    private void buildInterface() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(0, insets.getSystemWindowInsetTop(), 0,
                    insets.getSystemWindowInsetBottom());
            return insets;
        });

        reportStage = new FrameLayout(this);
        reportStage.setBackgroundColor(Color.BLACK);
        reportStage.setOnClickListener(view -> togglePlayback());
        reportStage.setOnTouchListener(this::handleSwipe);
        root.addView(reportStage, fullFrame());

        LinearLayout topChrome = new LinearLayout(this);
        topChrome.setOrientation(LinearLayout.VERTICAL);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(6), dp(4), dp(6), dp(4));
        header.setBackgroundColor(Color.argb(220, 5, 8, 12));
        Button close = compactButton("‹ GLOBE");
        close.setContentDescription("Return to globe");
        close.setOnClickListener(view -> finish());
        header.addView(close, new LinearLayout.LayoutParams(dp(72), dp(44)));
        ImageView brandMark = new ImageView(this);
        brandMark.setImageResource(R.drawable.du_brand_mark);
        brandMark.setContentDescription("DU World Monitor");
        header.addView(brandMark, new LinearLayout.LayoutParams(dp(34), dp(34)));
        LinearLayout identity = new LinearLayout(this);
        identity.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("DU LOCAL MONITORS", TEXT, 12, true);
        title.setLetterSpacing(0.06f);
        identity.addView(title);
        identity.addView(text("LOCAL WITNESSES • SOURCE STATE VISIBLE",
                MUTED, 7, true));
        identity.setOnClickListener(view -> {
            chromeExpanded = !chromeExpanded;
            chromeDetails.setVisibility(chromeExpanded ? View.VISIBLE : View.GONE);
        });
        header.addView(identity, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        networkProgress = new ProgressBar(this);
        networkProgress.setIndeterminate(true);
        networkProgress.setIndeterminateTintList(ColorStateList.valueOf(CYAN));
        header.addView(networkProgress, new LinearLayout.LayoutParams(dp(24), dp(24)));
        Button profile = compactButton("ME");
        profile.setContentDescription("My Local Monitor profile");
        profile.setOnClickListener(view -> showOwnProfile());
        header.addView(profile, new LinearLayout.LayoutParams(dp(48), dp(44)));
        Button collapse = compactButton("⌃");
        collapse.setContentDescription("Show or hide feed controls");
        collapse.setOnClickListener(view -> {
            chromeExpanded = !chromeExpanded;
            chromeDetails.setVisibility(chromeExpanded ? View.VISIBLE : View.GONE);
            collapse.setText(chromeExpanded ? "⌃" : "⌄");
        });
        header.addView(collapse, new LinearLayout.LayoutParams(dp(42), dp(44)));
        topChrome.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        chromeDetails = new LinearLayout(this);
        chromeDetails.setOrientation(LinearLayout.VERTICAL);
        chromeDetails.setBackgroundColor(Color.argb(205, 8, 12, 17));

        LinearLayout connection = new LinearLayout(this);
        connection.setGravity(Gravity.CENTER_VERTICAL);
        connection.setPadding(dp(10), 0, dp(8), 0);
        networkState = text("CHECKING LOCAL MONITOR NETWORK", CYAN, 8, true);
        networkState.setSingleLine(true);
        networkState.setEllipsize(TextUtils.TruncateAt.END);
        connection.addView(networkState, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button connect = compactButton("NETWORK");
        connect.setOnClickListener(view -> showNetworkSettings());
        connection.addView(connect, new LinearLayout.LayoutParams(dp(82), dp(32)));
        connection.setOnClickListener(view -> showNetworkSettings());
        chromeDetails.addView(connection, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));

        uploadMeter = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        uploadMeter.setMax(1000);
        uploadMeter.setProgressTintList(ColorStateList.valueOf(CYAN));
        uploadMeter.setProgressBackgroundTintList(ColorStateList.valueOf(LINE));
        uploadMeter.setVisibility(View.GONE);
        chromeDetails.addView(uploadMeter, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));

        HorizontalScrollView filterScroller = new HorizontalScrollView(this);
        filterScroller.setHorizontalScrollBarEnabled(false);
        filterRow = new LinearLayout(this);
        filterRow.setPadding(dp(5), dp(4), dp(5), dp(3));
        for (String item : FILTERS) {
            Button button = compactButton(item);
            button.setTextColor(item.equals(filter) ? CYAN : MUTED);
            button.setOnClickListener(view -> {
                filter = item;
                refreshFeed(true);
                rebuildFilterColors(filterRow);
            });
            filterRow.addView(button, new LinearLayout.LayoutParams(
                    dp(Math.max(78, item.length() * 9 + 22)), dp(34)));
        }
        filterScroller.addView(filterRow);
        chromeDetails.addView(filterScroller, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(41)));

        HorizontalScrollView stories = new HorizontalScrollView(this);
        stories.setHorizontalScrollBarEnabled(false);
        storyRow = new LinearLayout(this);
        storyRow.setGravity(Gravity.CENTER_VERTICAL);
        storyRow.setPadding(dp(6), dp(2), dp(6), dp(2));
        stories.addView(storyRow);
        chromeDetails.addView(stories, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(68)));
        topChrome.addView(chromeDetails, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        FrameLayout.LayoutParams chromeParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP);
        topChrome.setElevation(dp(8));
        root.addView(topChrome, chromeParams);

        Button report = actionButton("＋ REPORT", TEXT);
        report.setTextColor(TEXT);
        report.setBackground(pressableBackground(RED, RED, 18));
        report.setOnClickListener(view -> showCreateMenu());
        FrameLayout.LayoutParams reportParams = new FrameLayout.LayoutParams(
                dp(112), dp(50), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        reportParams.setMargins(0, 0, 0, dp(8));
        report.setElevation(dp(10));
        root.addView(report, reportParams);

        setContentView(root);
    }

    private void rebuildFilterColors(LinearLayout row) {
        for (int index = 0; index < row.getChildCount(); index++) {
            View child = row.getChildAt(index);
            if (child instanceof Button) {
                Button button = (Button) child;
                button.setTextColor(button.getText().toString().equals(filter) ? CYAN : MUTED);
            }
        }
    }

    private void refreshFeed(boolean network) {
        if (destroyed || store == null || profiles == null || api == null) return;
        String keepId = !requestedReportId.isEmpty() ? requestedReportId
                : currentReport() == null ? "" : currentReport().id;
        applyFeed(store.reports(), keepId);
        requestedReportId = "";
        if (!network) return;
        networkProgress.setVisibility(View.VISIBLE);
        networkProgress.setIndeterminate(true);
        networkState.setText(mediaSafeMode
                ? "SAFE VIDEO MODE • REPORT DETAILS AVAILABLE • TAP VIDEO TO RETRY"
                : profiles.networkConfigured()
                ? "SYNCING SOURCE-LABELLED REPORTS…"
                : "LOCAL MODE • CONNECT NETWORK FOR REPORTS FROM OTHER PHONES");
        networkState.setTextColor(mediaSafeMode ? AMBER
                : profiles.networkConfigured() ? CYAN : AMBER);
        api.loadFeed(filter, profiles.profile().homeLocation, (remote, error) -> {
            if (destroyed) return;
            networkProgress.setVisibility(View.GONE);
            if (!remote.isEmpty()) {
                List<MonitorReport> merged = store.mergeRemote(remote);
                applyFeed(merged, keepId);
            }
            if (error == null || error.isEmpty()) {
                networkState.setText("● CONNECTED • REPORTS SYNCED • SOURCE STATE VISIBLE");
                networkState.setTextColor(GREEN);
            } else {
                networkState.setText(error.toUpperCase(Locale.ROOT));
                networkState.setTextColor(AMBER);
            }
        });
    }

    private void applyFeed(List<MonitorReport> source, String keepId) {
        try {
            applyFeedUnsafe(source == null ? new ArrayList<>() : source, keepId);
        } catch (RuntimeException error) {
            String reference = CrashLedger.recordRecovered(
                    this, "LocalMonitorActivity.applyFeed", error);
            renderReportFailure(reference);
        }
    }

    private void applyFeedUnsafe(List<MonitorReport> source, String keepId) {
        reports.clear();
        MonitorProfileStore.Profile me = profiles.profile();
        for (MonitorReport report : source) {
            if (report == null || profiles.isBlocked(report.profileId)) continue;
            report.following = profiles.isFollowing(report.profileId);
            boolean own = me.id.equals(report.profileId);
            if ("LIVE".equals(filter) && !report.live) continue;
            if ("FOLLOWING".equals(filter) && !own && !report.following) continue;
            if ("NEARBY".equals(filter) && !own && !nearHome(report, me.homeLocation)) continue;
            reports.add(report);
        }
        currentIndex = 0;
        if (!keepId.isEmpty()) {
            for (int index = 0; index < reports.size(); index++) {
                if (keepId.equals(reports.get(index).id)) {
                    currentIndex = index;
                    break;
                }
            }
        }
        rebuildStories();
        renderCurrentReport();
    }

    private boolean nearHome(MonitorReport report, String home) {
        String target = home == null ? "" : home.trim().toLowerCase(Locale.ROOT);
        if (target.isEmpty()) return false;
        String location = report == null || report.locationName == null ? ""
                : report.locationName.toLowerCase(Locale.ROOT);
        return location.contains(target) || target.contains(location);
    }

    private void rebuildStories() {
        storyRow.removeAllViews();
        MonitorProfileStore.Profile me = profiles.profile();
        storyRow.addView(story(me.displayName, me.handle, me.avatarColor, false, null,
                        () -> showCreateMenu()),
                new LinearLayout.LayoutParams(dp(64), dp(64)));
        Set<String> shown = new HashSet<>();
        for (int index = 0; index < reports.size() && shown.size() < 14; index++) {
            MonitorReport report = reports.get(index);
            String key = report.profileId.isEmpty() ? report.handle : report.profileId;
            if (!shown.add(key)) continue;
            final int target = index;
            storyRow.addView(story(report.displayName, report.handle,
                            report.avatarColor, report.live, report, () -> {
                                currentIndex = target;
                                renderCurrentReport();
                    }),
                    new LinearLayout.LayoutParams(dp(64), dp(64)));
        }
    }

    private View story(
            String name,
            String handle,
            int color,
            boolean live,
            MonitorReport report,
            Runnable action) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER);
        FrameLayout ringView = new FrameLayout(this);
        GradientDrawable ring = new GradientDrawable();
        ring.setShape(GradientDrawable.OVAL);
        ring.setColor(color);
        ring.setStroke(dp(2), live ? RED : CYAN);
        ringView.setBackground(ring);
        View avatar = report == null ? avatarForOwn(name, color, 34)
                : avatarForReport(report, 34);
        FrameLayout.LayoutParams avatarParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        avatarParams.setMargins(dp(3), dp(3), dp(3), dp(3));
        ringView.addView(avatar, avatarParams);
        cell.addView(ringView, new LinearLayout.LayoutParams(dp(42), dp(42)));
        TextView label = text(live ? "● LIVE" : shortName(handle.isEmpty() ? name : handle),
                live ? RED : TEXT, 7, true);
        label.setSingleLine(true);
        label.setGravity(Gravity.CENTER);
        cell.addView(label, new LinearLayout.LayoutParams(dp(62), dp(18)));
        cell.setOnClickListener(view -> action.run());
        return cell;
    }

    private void renderCurrentReport() {
        try {
            renderCurrentReportUnsafe();
        } catch (RuntimeException error) {
            String reference = CrashLedger.recordRecovered(
                    this, "LocalMonitorActivity.renderCurrentReport", error);
            renderReportFailure(reference);
        }
    }

    private void renderCurrentReportUnsafe() {
        stopVideo();
        reportStage.removeAllViews();
        progressSegments.clear();
        if (reports.isEmpty()) {
            renderEmptyFeed();
            return;
        }
        currentIndex = Math.max(0, Math.min(currentIndex, reports.size() - 1));
        MonitorReport report = reports.get(currentIndex);

        FrameLayout card = new FrameLayout(this);
        card.setBackgroundColor(Color.BLACK);
        card.setOnClickListener(view -> togglePlayback());
        card.setOnTouchListener(this::handleSwipe);
        reportStage.addView(card, fullFrame());

        Uri playable = report.hasLocalVideo() ? store.mediaUri(report.localFileName)
                : report.hasRemoteVideo() ? Uri.parse(report.videoUrl) : null;
        TextView playback = text(mediaSafeMode
                ? "SAFE VIDEO MODE\nTAP TO RETRY THIS FEED WITH VIDEO"
                : "PREPARING VIDEO…", mediaSafeMode ? AMBER : CYAN, 9, true);
        playback.setGravity(Gravity.CENTER);
        card.addView(playback, fullFrame());
        if (mediaSafeMode) {
            activeVideo = null;
            playback.setOnClickListener(view -> {
                CrashLedger.clear(this);
                restartLocal(false, true);
            });
        } else {
            StoryVideoView storyVideo = new StoryVideoView(this);
            activeVideo = storyVideo;
            storyVideo.setBackgroundColor(Color.BLACK);
            storyVideo.setOnClickListener(view -> togglePlayback());
            storyVideo.setOnTouchListener(this::handleSwipe);
            card.addView(storyVideo, 0, fullFrame());
            if (playable != null) {
                storyVideo.setLooping(!report.live && !report.story);
                storyVideo.setOnCompletionListener(player -> {
                    if (!destroyed && storyVideo == activeVideo
                            && report.story && !navigating) navigateAnimated(1);
                });
                storyVideo.setOnPreparedListener(player -> {
                    if (destroyed || storyVideo != activeVideo) return;
                    playback.setVisibility(View.GONE);
                    storyVideo.setBackgroundColor(Color.TRANSPARENT);
                    storyVideo.start();
                });
                storyVideo.setOnInfoListener((ignored, what, extra) -> {
                    if (destroyed || storyVideo != activeVideo) return true;
                    if (what == MediaPlayer.MEDIA_INFO_BUFFERING_START) {
                        playback.setText("BUFFERING SOURCE VIDEO…");
                        playback.setVisibility(View.VISIBLE);
                    } else if (what == MediaPlayer.MEDIA_INFO_BUFFERING_END) {
                        playback.setVisibility(View.GONE);
                    }
                    return false;
                });
                storyVideo.setOnErrorListener((player, what, extra) -> {
                    if (destroyed || storyVideo != activeVideo) return true;
                    playback.setText("VIDEO UNAVAILABLE • REPORT DETAILS REMAIN VISIBLE");
                    playback.setTextColor(AMBER);
                    playback.setVisibility(View.VISIBLE);
                    return true;
                });
                storyVideo.setVideoURI(playable);
            } else {
                playback.setText("VIDEO FILE NOT AVAILABLE ON THIS DEVICE");
                playback.setTextColor(AMBER);
            }
        }

        addProgressSegments(card);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(10), dp(4), dp(6), dp(4));
        top.setBackground(panelBackground(Color.argb(190, 5, 8, 12), LINE, 14));
        String stateLabel = report.isDraft() ? "● PRIVATE DRAFT"
                : report.live ? "● LIVE" : "● LOCAL REPORT";
        TextView state = text(stateLabel,
                report.isDraft() ? AMBER : report.live ? RED : CYAN, 8, true);
        top.addView(state);
        TextView truth = text("  " + report.truthState + "  •  " + report.ageText(
                System.currentTimeMillis()) + " AGO", report.truthState.equals("CONFIRMED")
                ? GREEN : AMBER, 8, true);
        top.addView(truth, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button fit = compactButton(activeVideo == null
                ? "SAFE" : activeVideo.isFillMode() ? "FILL" : "FIT");
        fit.setContentDescription("Toggle full-screen crop");
        fit.setEnabled(activeVideo != null);
        fit.setOnClickListener(view -> {
            boolean fill = activeVideo != null && activeVideo.toggleFillMode();
            fit.setText(fill ? "FILL" : "FIT");
            Toast.makeText(this, fill ? "FULL-SCREEN FILL" : "SHOW COMPLETE FRAME",
                    Toast.LENGTH_SHORT).show();
        });
        top.addView(fit, new LinearLayout.LayoutParams(dp(50), dp(34)));
        Button more = compactButton("•••");
        more.setOnClickListener(view -> showReportMenu(report));
        top.addView(more, new LinearLayout.LayoutParams(dp(48), dp(34)));
        FrameLayout.LayoutParams topParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44), Gravity.TOP);
        topParams.setMargins(dp(8), dp(58), dp(8), 0);
        card.addView(top, topParams);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);
        actions.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        View profile = verticalAvatarAction(report, "PROFILE");
        profile.setOnClickListener(view -> showReporterProfile(report));
        Button like = verticalAction(report.liked ? "♥" : "♡", formatCount(report.likes));
        like.setTextColor(report.liked ? RED : TEXT);
        like.setOnClickListener(view -> toggleLike(report));
        Button comments = verticalAction("◉", formatCount(report.commentCount));
        comments.setOnClickListener(view -> showComments(report));
        Button share = verticalAction("↗", "SHARE");
        share.setOnClickListener(view -> shareReport(report));
        actions.addView(profile, new LinearLayout.LayoutParams(dp(64), dp(68)));
        actions.addView(like, new LinearLayout.LayoutParams(dp(64), dp(68)));
        actions.addView(comments, new LinearLayout.LayoutParams(dp(64), dp(68)));
        actions.addView(share, new LinearLayout.LayoutParams(dp(64), dp(68)));
        if (report.isDraft()) {
            Button edit = verticalAction("✎", "EDIT");
            edit.setTextColor(AMBER);
            edit.setOnClickListener(view -> showComposer(report.localFileName, report));
            actions.addView(edit, new LinearLayout.LayoutParams(dp(64), dp(68)));
        }
        FrameLayout.LayoutParams actionParams = new FrameLayout.LayoutParams(
                dp(70), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END | Gravity.BOTTOM);
        actionParams.setMargins(0, 0, dp(5), dp(74));
        card.addView(actions, actionParams);

        LinearLayout information = new LinearLayout(this);
        information.setOrientation(LinearLayout.VERTICAL);
        information.setPadding(dp(12), dp(10), dp(78), dp(10));
        information.setBackgroundColor(Color.argb(188, 5, 8, 12));
        LinearLayout reporter = new LinearLayout(this);
        reporter.setGravity(Gravity.CENTER_VERTICAL);
        reporter.addView(avatarForReport(report, 40),
                new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        names.setPadding(dp(8), 0, 0, 0);
        names.addView(text(report.displayName
                + (report.profileVerified ? "  ✓" : ""), TEXT, 10, true));
        names.addView(text(report.handle + "  •  " + report.locationName,
                CYAN, 8, true));
        reporter.addView(names, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        information.addView(reporter);
        if (!report.headline.isEmpty()) {
            TextView headline = text(report.headline, TEXT, 13, true);
            headline.setMaxLines(2);
            headline.setEllipsize(TextUtils.TruncateAt.END);
            information.addView(headline, marginParams(0, 7, 0, 2));
        }
        TextView caption = text(report.caption.isEmpty()
                ? report.isDraft() ? "Private draft — tap EDIT to finish this report."
                : "No caption supplied by this local monitor." : report.caption,
                TEXT, 11, false);
        caption.setMaxLines(3);
        caption.setEllipsize(TextUtils.TruncateAt.END);
        information.addView(caption, marginParams(0, report.headline.isEmpty() ? 7 : 2, 0, 5));
        TextView facts = text(report.category + "  •  "
                        + utcTime.format(new Date(report.createdAtMs)) + "  •  "
                        + report.stateLine(), report.uploadState.equals(MonitorReport.STATE_FAILED)
                        ? RED : MUTED, 8, true);
        facts.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        information.addView(facts);
        if (report.locationApproximate) {
            information.addView(text("LOCATION SHOWN APPROXIMATELY FOR REPORTER SAFETY",
                    AMBER, 7, true), marginParams(0, 3, 0, 0));
        }
        if (MonitorReport.STATE_FAILED.equals(report.uploadState)
                && !report.uploadError.isEmpty()) {
            information.addView(text("UPLOAD ERROR • " + report.uploadError,
                    RED, 7, true), marginParams(0, 3, 0, 0));
        }
        if (report.live) {
            information.addView(text(formatCount(report.viewerCount)
                    + " WATCHING • LIVE AVAILABILITY DEPENDS ON REPORTER CONNECTION",
                    RED, 8, true), marginParams(0, 4, 0, 0));
        }
        FrameLayout.LayoutParams infoParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        infoParams.setMargins(0, 0, 0, dp(62));
        card.addView(information, infoParams);

        positionState = text((currentIndex + 1) + " / " + reports.size()
                + "  •  SWIPE UP/DOWN", TEXT, 7, true);
        positionState.setGravity(Gravity.CENTER);
        positionState.setBackgroundColor(Color.argb(130, 5, 8, 12));
        FrameLayout.LayoutParams positionParams = new FrameLayout.LayoutParams(
                dp(156), dp(22), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        positionParams.setMargins(0, dp(106), 0, 0);
        card.addView(positionState, positionParams);
    }

    private void renderReportFailure(String reference) {
        stopVideo();
        if (reportStage == null) {
            showLocalMonitorRecovery(reference);
            return;
        }
        reportStage.removeAllViews();
        LinearLayout safe = new LinearLayout(this);
        safe.setOrientation(LinearLayout.VERTICAL);
        safe.setGravity(Gravity.CENTER);
        safe.setPadding(dp(24), dp(24), dp(24), dp(24));
        safe.addView(text("REPORT VIEW RECOVERED", AMBER, 16, true));
        TextView explanation = text(
                "A damaged report or media response was isolated. Your other reports remain saved.",
                TEXT, 10, false);
        explanation.setGravity(Gravity.CENTER);
        safe.addView(explanation, marginParams(0, 9, 0, 14));
        safe.addView(text("REFERENCE • " + fallback(reference, "NOT AVAILABLE"),
                CYAN, 8, true), marginParams(0, 0, 0, 14));
        Button retry = actionButton("REOPEN IN SAFE VIDEO MODE", CYAN);
        retry.setOnClickListener(view -> restartLocal(true, false));
        safe.addView(retry, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        reportStage.addView(safe, fullFrame());
    }

    private void renderEmptyFeed() {
        LinearLayout empty = new LinearLayout(this);
        empty.setOrientation(LinearLayout.VERTICAL);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(dp(28), dp(28), dp(28), dp(28));
        empty.addView(text("NO " + filter + " REPORTS YET", TEXT, 17, true));
        TextView detail = text(
                profiles.networkConfigured()
                        ? "No source-labelled video report matches this view. Refresh or publish the first report from your location."
                        : "Reports captured now stay safely on this phone. Connect a secure Monitor Network to exchange reports with people in other locations.",
                MUTED, 11, false);
        detail.setGravity(Gravity.CENTER);
        empty.addView(detail, marginParams(0, 10, 0, 20));
        Button create = actionButton("＋ CREATE LOCATION REPORT", RED);
        create.setOnClickListener(view -> showCreateMenu());
        empty.addView(create, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        Button connect = actionButton("CONNECT MONITOR NETWORK", CYAN);
        connect.setOnClickListener(view -> showNetworkSettings());
        empty.addView(connect, marginParams(0, 8, 0, 0));
        reportStage.addView(empty, fullFrame());
    }

    private boolean handleSwipe(View view, MotionEvent event) {
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            touchDownX = event.getX();
            touchDownY = event.getY();
            touchDownAt = System.currentTimeMillis();
            holdMuted = false;
            uiHandler.postDelayed(muteHold, 420L);
            return true;
        }
        if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
            if (Math.abs(event.getX() - touchDownX) > dp(16)
                    || Math.abs(event.getY() - touchDownY) > dp(16)) {
                uiHandler.removeCallbacks(muteHold);
                if (pendingSingleTap != null) {
                    uiHandler.removeCallbacks(pendingSingleTap);
                    pendingSingleTap = null;
                    lastTapAt = 0L;
                }
            }
            return true;
        }
        if (event.getActionMasked() == MotionEvent.ACTION_UP) {
            uiHandler.removeCallbacks(muteHold);
            if (holdMuted && activeVideo != null) {
                activeVideo.setMuted(false);
                holdMuted = false;
                return true;
            }
            float vertical = event.getY() - touchDownY;
            float horizontal = event.getX() - touchDownX;
            if (Math.abs(vertical) > dp(70) && Math.abs(vertical) > Math.abs(horizontal)) {
                chromeExpanded = false;
                chromeDetails.setVisibility(View.GONE);
                navigateAnimated(vertical < 0 ? 1 : -1);
            } else if (Math.abs(horizontal) < dp(18) && Math.abs(vertical) < dp(18)) {
                long now = System.currentTimeMillis();
                if (now - lastTapAt < 300L) {
                    if (pendingSingleTap != null) uiHandler.removeCallbacks(pendingSingleTap);
                    pendingSingleTap = null;
                    MonitorReport report = currentReport();
                    if (report != null && !report.isDraft()) toggleLike(report);
                    lastTapAt = 0L;
                } else {
                    lastTapAt = now;
                    pendingSingleTap = () -> {
                        if (lastTapAt == now) view.performClick();
                        pendingSingleTap = null;
                    };
                    uiHandler.postDelayed(pendingSingleTap, 310L);
                }
            }
            return true;
        }
        if (event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
            uiHandler.removeCallbacks(muteHold);
            if (holdMuted && activeVideo != null) activeVideo.setMuted(false);
            holdMuted = false;
        }
        return true;
    }

    private void togglePlayback() {
        if (activeVideo == null) return;
        if (activeVideo.isPlaying()) activeVideo.pause();
        else activeVideo.start();
    }

    private void showNext() {
        navigateAnimated(1);
    }

    private void showPrevious() {
        navigateAnimated(-1);
    }

    private void navigateAnimated(int direction) {
        if (reports.isEmpty() || navigating) return;
        navigating = true;
        float distance = Math.max(dp(90), reportStage.getHeight() * 0.14f);
        reportStage.animate()
                .translationY(direction > 0 ? -distance : distance)
                .alpha(0.18f)
                .setDuration(130L)
                .withEndAction(() -> {
                    currentIndex = (currentIndex + direction + reports.size()) % reports.size();
                    renderCurrentReport();
                    reportStage.setTranslationY(direction > 0 ? distance : -distance);
                    reportStage.setAlpha(0.18f);
                    reportStage.animate().translationY(0f).alpha(1f).setDuration(170L)
                            .withEndAction(() -> navigating = false).start();
                }).start();
    }

    private MonitorReport currentReport() {
        return reports.isEmpty() || currentIndex < 0 || currentIndex >= reports.size()
                ? null : reports.get(currentIndex);
    }

    private void toggleLike(MonitorReport report) {
        boolean liked = store.toggleLike(report.id);
        report.liked = liked;
        report.likes = Math.max(0, report.likes + (liked ? 1 : -1));
        if (MonitorReport.STATE_PUBLISHED.equals(report.uploadState)) {
            api.setLike(report.id, liked, (success, message) -> {
                if (!destroyed && !success) {
                    Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                }
            });
        }
        renderCurrentReport();
    }

    private void showComments(MonitorReport report) {
        boolean resumePlayback = activeVideo != null && activeVideo.isPlaying();
        if (activeVideo != null) activeVideo.pause();
        LinearLayout shell = dialogShell();
        shell.setPadding(dp(14), dp(12), dp(14), dp(12));
        shell.setMinimumHeight(Math.round(
                getResources().getDisplayMetrics().heightPixels * 0.68f));
        shell.setBackground(panelBackground(PANEL, LINE, 24));
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = text("COMMENTS / " + formatCount(report.commentCount), TEXT, 14, true);
        header.addView(heading, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button close = compactButton("CLOSE");
        header.addView(close, new LinearLayout.LayoutParams(dp(68), dp(38)));
        shell.addView(header, marginParams(0, 0, 0, 5));
        TextView truth = text("COMMENTS ARE USER STATEMENTS • THEY DO NOT VERIFY A REPORT",
                AMBER, 8, true);
        shell.addView(truth, marginParams(0, 0, 0, 8));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(list);
        shell.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        fillComments(list, store.comments(report.id));
        LinearLayout composer = new LinearLayout(this);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        EditText input = edit("ADD A RESPECTFUL, FACTUAL COMMENT", "");
        composer.addView(input, new LinearLayout.LayoutParams(0, dp(52), 1f));
        Button post = actionButton("POST", CYAN);
        composer.addView(post, new LinearLayout.LayoutParams(dp(76), dp(52)));
        shell.addView(composer, marginParams(0, 8, 0, 0));

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(shell);
        dialog.setCanceledOnTouchOutside(true);
        dialog.setOnDismissListener(ignored -> {
            if (resumePlayback && activeVideo != null) activeVideo.start();
        });
        close.setOnClickListener(view -> dialog.dismiss());
        post.setOnClickListener(view -> {
            String body = MonitorReport.trim(input.getText().toString(), 500);
            if (body.isEmpty()) {
                input.setError("Write a comment first");
                return;
            }
            MonitorProfileStore.Profile me = profiles.profile();
            MonitorReport.Comment comment = new MonitorReport.Comment();
            comment.profileId = me.id;
            comment.displayName = me.displayName;
            comment.handle = me.handle;
            comment.body = body;
            comment.pending = profiles.networkConfigured();
            store.addComment(report.id, comment);
            report.commentCount++;
            heading.setText("COMMENTS / " + formatCount(report.commentCount));
            input.setText("");
            fillComments(list, store.comments(report.id));
            scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
            if (MonitorReport.STATE_PUBLISHED.equals(report.uploadState)) {
                api.postComment(report.id, comment, (success, message) -> {
                    if (!destroyed && !success) {
                        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(
                    Color.TRANSPARENT));
            window.setGravity(Gravity.BOTTOM);
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,
                    Math.round(getResources().getDisplayMetrics().heightPixels * 0.70f));
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.dimAmount = 0.45f;
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.setAttributes(attributes);
        }
        api.loadComments(report.id, (comments, error) -> {
            if (!destroyed && dialog.isShowing() && !comments.isEmpty()) {
                store.mergeComments(report.id, comments);
                fillComments(list, store.comments(report.id));
            }
        });
    }

    private void fillComments(LinearLayout list, List<MonitorReport.Comment> comments) {
        list.removeAllViews();
        if (comments.isEmpty()) {
            list.addView(text("No comments yet. Be the first to add useful local context.",
                    MUTED, 10, false), marginParams(0, 18, 0, 18));
            return;
        }
        for (MonitorReport.Comment comment : comments) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(9), dp(7), dp(9), dp(7));
            card.setBackground(panelBackground(PANEL_ALT, LINE, 12));
            card.addView(text(comment.displayName + "  " + comment.handle,
                    CYAN, 9, true));
            card.addView(text(comment.body, TEXT, 10, false), marginParams(0, 4, 0, 2));
            card.addView(text(utcTime.format(new Date(comment.createdAtMs))
                    + (comment.pending ? " • SYNC PENDING" : ""), MUTED, 7, false));
            list.addView(card, marginParams(0, 0, 0, 6));
        }
    }

    private void shareReport(MonitorReport report) {
        Intent share = new Intent(Intent.ACTION_SEND);
        Uri local = report.hasLocalVideo() ? store.mediaUri(report.localFileName) : null;
        if (local != null) {
            share.setType("video/mp4");
            share.putExtra(Intent.EXTRA_STREAM, local);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            share.setClipData(ClipData.newRawUri("Local monitor video", local));
        } else {
            share.setType("text/plain");
        }
        String text = report.displayName + " " + report.handle + " • "
                + report.locationName + "\n" + report.caption + "\n"
                + report.truthState + " • " + report.sourceLabel
                + (report.shareUrl.isEmpty() ? "" : "\n" + report.shareUrl);
        share.putExtra(Intent.EXTRA_TEXT, text);
        try {
            startActivity(Intent.createChooser(share, "Share location video report"));
        } catch (RuntimeException error) {
            Toast.makeText(this, "No sharing app is available", Toast.LENGTH_SHORT).show();
        }
    }

    private void showReporterProfile(MonitorReport report) {
        LinearLayout shell = dialogShell();
        LinearLayout identity = new LinearLayout(this);
        identity.setGravity(Gravity.CENTER_VERTICAL);
        identity.addView(avatarForReport(report, 60),
                new LinearLayout.LayoutParams(dp(60), dp(60)));
        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        names.setPadding(dp(12), 0, 0, 0);
        names.addView(text(report.displayName + (report.profileVerified ? "  ✓" : ""),
                TEXT, 15, true));
        names.addView(text(report.handle, CYAN, 10, true));
        names.addView(text(report.locationName, MUTED, 9, false));
        identity.addView(names);
        shell.addView(identity, marginParams(0, 0, 0, 12));
        int count = 0;
        for (MonitorReport value : reports) if (value.profileId.equals(report.profileId)) count++;
        shell.addView(text(count + " REPORTS IN THIS FEED  •  "
                + (report.following ? "FOLLOWING" : "NOT FOLLOWING"), MUTED, 9, true));
        shell.addView(text("Profile verification and report credibility are separate. A verified profile does not automatically confirm a video report.",
                AMBER, 9, false), marginParams(0, 9, 0, 0));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(shell)
                .setNegativeButton("CLOSE", null)
                .setNeutralButton("BLOCK", (ignored, which) -> confirmBlock(report))
                .setPositiveButton(report.following ? "UNFOLLOW" : "FOLLOW", (ignored, which) -> {
                    boolean following = profiles.toggleFollow(report.profileId);
                    report.following = following;
                    api.setFollowing(report.profileId, following, (success, message) -> {
                        if (!destroyed && !success) {
                            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                        }
                    });
                    rebuildStories();
                    renderCurrentReport();
                })
                .create();
        dialog.show();
    }

    private void confirmBlock(MonitorReport report) {
        new AlertDialog.Builder(this)
                .setTitle("Block " + report.handle + "?")
                .setMessage("Their reports will be hidden on this phone. You can reconnect by clearing app data or through a future account service.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("BLOCK", (dialog, which) -> {
                    profiles.block(report.profileId);
                    refreshFeed(false);
                })
                .show();
    }

    private void showReportMenu(MonitorReport report) {
        MonitorProfileStore.Profile me = profiles.profile();
        boolean own = me.id.equals(report.profileId);
        List<String> choices = new ArrayList<>();
        if (report.isDraft() && own) choices.add("Edit private draft");
        if (MonitorReport.STATE_FAILED.equals(report.uploadState) && own) {
            choices.add("Resume secure upload");
        }
        if (MonitorReport.STATE_LOCAL.equals(report.uploadState) && own
                && profiles.networkConfigured()) choices.add("Publish this local report");
        if (!own) {
            choices.add("Report harmful or misleading content");
            choices.add("Block this profile");
        }
        if (own) choices.add(report.isDraft()
                ? "Discard private draft and video" : "Delete my report from this phone");
        new AlertDialog.Builder(this)
                .setTitle("Report controls")
                .setItems(choices.toArray(new String[0]), (dialog, which) -> {
                    String choice = choices.get(which);
                    if (choice.startsWith("Edit")) showComposer(report.localFileName, report);
                    else if (choice.startsWith("Resume") || choice.startsWith("Publish")) {
                        retryUpload(report);
                    }
                    else if (choice.startsWith("Report harmful")) flagReport(report);
                    else if (choice.startsWith("Block")) confirmBlock(report);
                    else if (choice.startsWith("Delete") || choice.startsWith("Discard")) {
                        store.deleteOwnReport(report.id, me.id);
                        refreshFeed(false);
                    }
                })
                .show();
    }

    private void flagReport(MonitorReport report) {
        EditText reason = edit("WHY SHOULD THIS REPORT BE REVIEWED?", "");
        new AlertDialog.Builder(this)
                .setTitle("Flag report for review")
                .setView(reason)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SEND", (dialog, which) -> {
                    api.reportContent(report.id, reason.getText().toString(), (success, message) ->
                            Toast.makeText(this, success ? "Report sent for review" : message,
                                    Toast.LENGTH_LONG).show());
                })
                .show();
    }

    private void showCreateMenu() {
        List<String> choices = new ArrayList<>();
        choices.add("Record a video report");
        choices.add("Choose a video from this phone");
        choices.add("Start a LIVE location report");
        int draftCount = draftCount();
        if (draftCount > 0) choices.add("Resume saved drafts (" + draftCount + ")");
        new AlertDialog.Builder(this)
                .setTitle("Create Local Monitor report")
                .setItems(choices.toArray(new String[0]), (dialog, which) -> {
                    if (which == 0) showRecordDurationMenu();
                    else if (which == 1) pickVideo();
                    else if (which == 2) showGoLive();
                    else showDrafts();
                })
                .setNegativeButton("CANCEL", null)
                .show();
    }

    private void showRecordDurationMenu() {
        String[] choices = {"15 seconds", "30 seconds", "60 seconds", "3 minutes", "5 minutes"};
        int[] seconds = {15, 30, 60, 180, 300};
        new AlertDialog.Builder(this)
                .setTitle("Maximum recording length")
                .setItems(choices, (dialog, which) -> startCameraCapture(seconds[which]))
                .setNegativeButton("CANCEL", null)
                .show();
    }

    private int draftCount() {
        int count = 0;
        MonitorProfileStore.Profile me = profiles.profile();
        for (MonitorReport report : store.reports()) {
            if (report.isDraft() && me.id.equals(report.profileId)) count++;
        }
        return count;
    }

    private void showDrafts() {
        MonitorProfileStore.Profile me = profiles.profile();
        List<MonitorReport> drafts = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        for (MonitorReport report : store.reports()) {
            if (!report.isDraft() || !me.id.equals(report.profileId)) continue;
            drafts.add(report);
            labels.add(fallback(report.headline, fallback(report.caption, "Untitled report"))
                    + "\n" + report.locationName + " • "
                    + utcTime.format(new Date(report.createdAtMs)));
        }
        if (drafts.isEmpty()) {
            Toast.makeText(this, "No saved drafts", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Private report drafts")
                .setItems(labels.toArray(new String[0]), (dialog, which) -> {
                    MonitorReport draft = drafts.get(which);
                    showComposer(draft.localFileName, draft);
                })
                .setNegativeButton("CLOSE", null)
                .show();
    }

    private void startCameraCapture(int durationSeconds) {
        try {
            pendingCaptureFile = store.createCaptureTarget();
            Uri output = store.mediaUri(pendingCaptureFile);
            Intent capture = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
            capture.putExtra(MediaStore.EXTRA_OUTPUT, output);
            capture.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
            capture.putExtra(MediaStore.EXTRA_DURATION_LIMIT,
                    Math.max(15, Math.min(300, durationSeconds)));
            capture.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            capture.setClipData(ClipData.newRawUri("Local monitor capture", output));
            startActivityForResult(capture, REQUEST_CAPTURE);
        } catch (ActivityNotFoundException error) {
            store.discardMedia(pendingCaptureFile);
            pendingCaptureFile = "";
            Toast.makeText(this, "No camera app can record video", Toast.LENGTH_LONG).show();
        } catch (Exception error) {
            Toast.makeText(this, "Unable to prepare camera: " + error.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void pickVideo() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("video/*");
        pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(pick, REQUEST_PICK);
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, "No file picker is available", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CAPTURE) {
            String captured = pendingCaptureFile;
            pendingCaptureFile = "";
            File file = store.mediaFile(captured);
            if (resultCode == RESULT_OK && file != null && file.length() > 1_024L) {
                showComposer(captured);
            } else {
                store.discardMedia(captured);
                Toast.makeText(this, "Video recording was cancelled", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        if (requestCode == REQUEST_PICK && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            importPickedVideo(data.getData());
            return;
        }
        if (requestCode == REQUEST_AVATAR && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            importProfilePhoto(data.getData());
        }
    }

    private void pickProfilePhoto() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("image/*");
        pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivityForResult(pick, REQUEST_AVATAR);
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, "No image picker is available", Toast.LENGTH_LONG).show();
        }
    }

    private void importProfilePhoto(Uri source) {
        if (destroyed || networkProgress == null) return;
        networkProgress.setVisibility(View.VISIBLE);
        fileExecutor.execute(() -> {
            try {
                profiles.importAvatar(getContentResolver(), source);
                runOnUiThread(() -> {
                    if (destroyed) return;
                    networkProgress.setVisibility(View.GONE);
                    rebuildStories();
                    renderCurrentReport();
                    Toast.makeText(this, "Profile photo saved on this phone",
                            Toast.LENGTH_LONG).show();
                });
            } catch (Exception | OutOfMemoryError error) {
                runOnUiThread(() -> {
                    if (destroyed) return;
                    networkProgress.setVisibility(View.GONE);
                    Toast.makeText(this, fallback(error.getMessage(),
                            "The profile photo could not be processed safely"),
                            Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void importPickedVideo(Uri source) {
        if (destroyed || networkProgress == null || networkState == null) return;
        networkProgress.setVisibility(View.VISIBLE);
        networkState.setText("SECURING A PRIVATE LOCAL COPY OF THE SELECTED VIDEO…");
        networkState.setTextColor(CYAN);
        fileExecutor.execute(() -> {
            try {
                String fileName = store.importVideo(getContentResolver(), source);
                runOnUiThread(() -> {
                    if (destroyed) return;
                    networkProgress.setVisibility(View.GONE);
                    showComposer(fileName);
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    if (destroyed) return;
                    networkProgress.setVisibility(View.GONE);
                    networkState.setText("VIDEO IMPORT FAILED");
                    networkState.setTextColor(RED);
                    Toast.makeText(this, fallback(error.getMessage(),
                            "The selected video could not be imported"),
                            Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void showComposer(String fileName) {
        showComposer(fileName, null);
    }

    private void showComposer(String fileName, MonitorReport existing) {
        MonitorProfileStore.Profile me = profiles.profile();
        LinearLayout shell = dialogShell();
        shell.addView(text(existing == null ? "NEW LOCATION VIDEO REPORT" : "FINISH SAVED DRAFT",
                TEXT, 15, true));
        long duration = store.durationMs(fileName);
        shell.addView(text("VIDEO READY • " + formatDuration(duration)
                        + " • SAVED PRIVATELY ON THIS PHONE",
                GREEN, 8, true), marginParams(0, 4, 0, 8));
        EditText headline = edit("SHORT HEADLINE", existing == null ? "" : existing.headline);
        shell.addView(headline, marginParams(0, 0, 0, 7));
        EditText caption = edit("WHAT IS HAPPENING? INCLUDE WHAT YOU SAW, NOT WHAT YOU ASSUME.",
                existing == null ? "" : existing.caption);
        caption.setSingleLine(false);
        caption.setMinLines(3);
        caption.setMaxLines(5);
        shell.addView(caption, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(104)));
        EditText location = edit("CITY, DISTRICT OR LOCAL AREA", existing == null
                ? me.homeLocation : existing.locationName);
        shell.addView(location, marginParams(0, 7, 0, 0));
        EditText category = edit("CATEGORY", existing == null ? "LOCAL UPDATE" : existing.category);
        shell.addView(category, marginParams(0, 7, 0, 0));
        Button coordinates = actionButton(attachCoordinates
                ? "✓ DEVICE COORDINATES WILL BE ATTACHED" : "ATTACH DEVICE COORDINATES", CYAN);
        coordinates.setOnClickListener(view -> requestCoordinates(coordinates));
        shell.addView(coordinates, marginParams(0, 7, 0, 0));
        CheckBox approximate = checkBox(
                "Protect location — place any attached map marker approximately", existing == null
                        || existing.locationApproximate);
        shell.addView(approximate, marginParams(0, 5, 0, 0));
        CheckBox story = checkBox("Story report — remove from the feed after 24 hours",
                existing == null || existing.story);
        shell.addView(story, marginParams(0, 7, 0, 0));
        CheckBox rights = checkBox(
                "I recorded this video or have permission to publish it, and I will not endanger people by revealing sensitive locations.",
                false);
        shell.addView(rights, marginParams(0, 6, 0, 0));
        shell.addView(text(
                "Every new public report begins as UNVERIFIED. Likes do not change verification. Network moderators or named official sources may update credibility later.",
                AMBER, 8, false), marginParams(0, 7, 0, 0));

        ScrollView scroller = new ScrollView(this);
        scroller.addView(shell);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(scroller)
                .setNegativeButton("SAVE DRAFT", null)
                .setNeutralButton("DISCARD", null)
                .setPositiveButton(profiles.networkConfigured()
                        ? "PUBLISH REPORT" : "SAVE LOCAL REPORT", null)
                .create();
        dialog.setOnShowListener(ignored -> {
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(view -> {
                MonitorReport draft = prepareReport(existing, me, fileName, duration,
                        headline, caption, location, category, approximate, story);
                draft.uploadState = MonitorReport.STATE_DRAFT;
                draft.uploadError = "";
                draft.uploadSessionId = "";
                draft.expiresAtMs = 0L;
                store.upsert(draft);
                dialog.dismiss();
                filter = "FOR YOU";
                refreshFeed(false);
                Toast.makeText(this, "Private draft saved on this phone",
                        Toast.LENGTH_LONG).show();
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(view ->
                    new AlertDialog.Builder(this)
                            .setTitle("Discard this video?")
                            .setMessage("The private report video will be removed from this phone.")
                            .setNegativeButton("KEEP", null)
                            .setPositiveButton("DISCARD", (confirm, which) -> {
                                if (existing != null) {
                                    store.deleteOwnReport(existing.id, me.id);
                                } else {
                                    store.discardMedia(fileName);
                                }
                                dialog.dismiss();
                                refreshFeed(false);
                            }).show());
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
                String body = MonitorReport.trim(caption.getText().toString(), 600);
                String place = MonitorReport.trim(location.getText().toString(), 80);
                if (body.isEmpty()) {
                    caption.setError("Explain what is happening");
                    return;
                }
                if (place.isEmpty()) {
                    location.setError("State the report location");
                    return;
                }
                if (!rights.isChecked()) {
                    Toast.makeText(this, "Confirm recording rights and safety first",
                            Toast.LENGTH_LONG).show();
                    return;
                }
                MonitorReport report = prepareReport(existing, me, fileName, duration,
                        headline, caption, location, category, approximate, story);
                report.createdAtMs = System.currentTimeMillis();
                report.expiresAtMs = report.story
                        ? report.createdAtMs + 24L * 60L * 60L * 1000L : 0L;
                report.truthState = "UNVERIFIED";
                report.uploadState = profiles.networkConfigured()
                        ? MonitorReport.STATE_QUEUED : MonitorReport.STATE_LOCAL;
                report.sourceLabel = "LOCAL MONITOR / SELF-REPORTED";
                Location coordinate = attachCoordinates ? bestLastLocation() : null;
                if (coordinate != null) {
                    report.latitude = approximate.isChecked()
                            ? approximateCoordinate(coordinate.getLatitude())
                            : coordinate.getLatitude();
                    report.longitude = approximate.isChecked()
                            ? approximateCoordinate(coordinate.getLongitude())
                            : coordinate.getLongitude();
                } else {
                    GeoIndex.Point placePoint = GeoIndex.find(place);
                    if (placePoint == null) placePoint = GeoIndex.find(me.homeLocation);
                    if (placePoint != null) {
                        report.latitude = placePoint.latitude;
                        report.longitude = placePoint.longitude;
                        report.locationApproximate = true;
                    }
                }
                store.upsert(report);
                dialog.dismiss();
                filter = "FOR YOU";
                refreshFeed(false);
                if (profiles.networkConfigured()) upload(report);
                else Toast.makeText(this,
                        "Saved on this phone. Connect Monitor Network to publish across locations.",
                        Toast.LENGTH_LONG).show();
            });
        });
        dialog.show();
    }

    private MonitorReport prepareReport(
            MonitorReport existing,
            MonitorProfileStore.Profile me,
            String fileName,
            long duration,
            EditText headline,
            EditText caption,
            EditText location,
            EditText category,
            CheckBox approximate,
            CheckBox story) {
        MonitorReport report = existing == null ? new MonitorReport() : existing;
        report.profileId = me.id;
        report.displayName = me.displayName;
        report.handle = me.handle;
        report.avatarColor = me.avatarColor;
        report.headline = MonitorReport.trim(headline.getText().toString(), 120);
        report.locationName = fallback(MonitorReport.trim(location.getText().toString(), 80),
                fallback(me.homeLocation, "Location not stated"));
        report.caption = MonitorReport.trim(caption.getText().toString(), 600);
        report.category = fallback(MonitorReport.trim(category.getText().toString(), 40),
                "LOCAL UPDATE").toUpperCase(Locale.ROOT);
        report.localFileName = fileName;
        report.durationMs = duration;
        report.story = story.isChecked();
        report.locationApproximate = approximate.isChecked();
        report.truthState = "UNVERIFIED";
        report.sourceLabel = "LOCAL MONITOR / SELF-REPORTED";
        return report;
    }

    private static double approximateCoordinate(double value) {
        return Math.round(value * 100d) / 100d;
    }

    private void upload(MonitorReport report) {
        if (!uploadingIds.add(report.id)) return;
        File video = store.mediaFile(report.localFileName);
        if (video == null) {
            uploadingIds.remove(report.id);
            report.uploadState = MonitorReport.STATE_FAILED;
            report.uploadError = "The local report video is unavailable";
            store.upsert(report);
            refreshFeed(false);
            return;
        }
        report.uploadState = MonitorReport.STATE_UPLOADING;
        report.uploadError = "";
        report.uploadTotal = video.length();
        store.upsert(report);
        networkProgress.setVisibility(View.VISIBLE);
        networkProgress.setIndeterminate(true);
        uploadMeter.setVisibility(View.VISIBLE);
        uploadMeter.setProgress(report.uploadTotal > 0L
                ? (int) Math.min(1000L, report.uploadOffset * 1000L / report.uploadTotal) : 0);
        networkState.setText("UPLOADING • LOCAL COPY SAFE • RESUME STATE SAVED");
        networkState.setTextColor(CYAN);
        api.uploadReport(report, video, new MonitorApiClient.UploadCallback() {
            @Override
            public void onProgress(long uploadedBytes, long totalBytes) {
                if (destroyed) return;
                report.uploadState = MonitorReport.STATE_UPLOADING;
                report.uploadOffset = uploadedBytes;
                report.uploadTotal = totalBytes;
                store.upsert(report);
                int progress = totalBytes > 0L
                        ? (int) Math.min(1000L, uploadedBytes * 1000L / totalBytes) : 0;
                uploadMeter.setProgress(progress);
                networkState.setText("UPLOADING " + (progress / 10) + "% • LOCAL COPY SAFE");
            }

            @Override
            public void onResult(MonitorReport published, String error) {
                uploadingIds.remove(report.id);
                if (destroyed) return;
                networkProgress.setVisibility(View.GONE);
                uploadMeter.setVisibility(View.GONE);
                if (published != null) {
                    store.removeRecordKeepMedia(report.id);
                    store.upsert(published);
                    networkState.setText("● REPORT PUBLISHED • UNVERIFIED UNTIL CORROBORATED");
                    networkState.setTextColor(GREEN);
                    refreshFeed(false);
                } else {
                    report.uploadState = MonitorReport.STATE_FAILED;
                    report.uploadError = error;
                    store.upsert(report);
                    networkState.setText("UPLOAD PAUSED • LOCAL VIDEO SAFE • TAP RETRY TO RESUME");
                    networkState.setTextColor(RED);
                    refreshFeed(false);
                }
                uiHandler.postDelayed(LocalMonitorActivity.this::resumeQueuedUploads, 350L);
            }
        });
    }

    private void resumeQueuedUploads() {
        if (destroyed || !profiles.networkConfigured()) return;
        MonitorProfileStore.Profile me = profiles.profile();
        for (MonitorReport report : store.reports()) {
            if (!me.id.equals(report.profileId) || report.isDraft()) continue;
            if (MonitorReport.STATE_QUEUED.equals(report.uploadState)
                    || MonitorReport.STATE_UPLOADING.equals(report.uploadState)) {
                upload(report);
                return;
            }
        }
    }

    private void retryUpload(MonitorReport report) {
        if (!profiles.networkConfigured()) {
            showNetworkSettings();
            return;
        }
        upload(report);
    }

    private void requestCoordinates(Button button) {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            attachCoordinates = !attachCoordinates;
            button.setText(attachCoordinates ? "✓ DEVICE COORDINATES WILL BE ATTACHED"
                    : "ATTACH DEVICE COORDINATES");
            return;
        }
        requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_LOCATION) {
            attachCoordinates = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            Toast.makeText(this, attachCoordinates
                    ? "Coordinates enabled for the next report"
                    : "Location remains manual; reporting still works",
                    Toast.LENGTH_LONG).show();
        }
    }

    private Location bestLastLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) return null;
        LocationManager manager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (manager == null) return null;
        Location best = null;
        try {
            for (String provider : manager.getProviders(true)) {
                Location candidate = manager.getLastKnownLocation(provider);
                if (candidate != null && (best == null
                        || candidate.getTime() > best.getTime())) best = candidate;
            }
        } catch (SecurityException ignored) { }
        return best;
    }

    private void showGoLive() {
        if (!profiles.networkConfigured()) {
            new AlertDialog.Builder(this)
                    .setTitle("Connect Monitor Network")
                    .setMessage("A real live feed needs a secure publishing and playback service. The app will not pretend that a local recording is live.")
                    .setNegativeButton("CANCEL", null)
                    .setPositiveButton("CONNECT", (dialog, which) -> showNetworkSettings())
                    .show();
            return;
        }
        MonitorProfileStore.Profile me = profiles.profile();
        LinearLayout shell = dialogShell();
        EditText title = edit("WHAT ARE YOU REPORTING LIVE?", "Live report");
        EditText location = edit("LIVE LOCATION", me.homeLocation);
        CheckBox safety = checkBox(
                "I have permission to broadcast and will not expose victims, children, private property or dangerous tactical locations.",
                false);
        shell.addView(title);
        shell.addView(location, marginParams(0, 7, 0, 0));
        shell.addView(safety, marginParams(0, 7, 0, 0));
        shell.addView(text("The connected service must return separate HTTPS publisher and playback addresses. Viewers watch natively inside this app.",
                MUTED, 8, false), marginParams(0, 7, 0, 0));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Start LIVE location report")
                .setView(shell)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("CREATE LIVE SESSION", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    if (!safety.isChecked()) {
                        Toast.makeText(this, "Confirm live safety first", Toast.LENGTH_LONG).show();
                        return;
                    }
                    Location coordinate = attachCoordinates ? bestLastLocation() : null;
                    networkProgress.setVisibility(View.VISIBLE);
                    networkState.setText("CREATING SECURE LIVE SESSION…");
                    api.startLive(title.getText().toString(), location.getText().toString(),
                            coordinate == null ? Double.NaN : coordinate.getLatitude(),
                            coordinate == null ? Double.NaN : coordinate.getLongitude(),
                            (session, error) -> {
                                networkProgress.setVisibility(View.GONE);
                                if (session == null) {
                                    networkState.setText("LIVE SESSION FAILED • " + error.toUpperCase(Locale.ROOT));
                                    networkState.setTextColor(RED);
                                    return;
                                }
                                MonitorReport report = new MonitorReport();
                                report.id = session.reportId.isEmpty() ? session.id : session.reportId;
                                report.profileId = me.id;
                                report.displayName = me.displayName;
                                report.handle = me.handle;
                                report.avatarColor = me.avatarColor;
                                report.locationName = fallback(location.getText().toString(), me.homeLocation);
                                report.caption = fallback(title.getText().toString(), "Live report");
                                report.category = "LIVE LOCATION REPORT";
                                report.truthState = "UNVERIFIED";
                                report.sourceLabel = "LOCAL MONITOR / LIVE";
                                report.live = true;
                                report.videoUrl = session.playbackUrl;
                                report.uploadState = MonitorReport.STATE_PUBLISHED;
                                report.createdAtMs = System.currentTimeMillis();
                                report.expiresAtMs = session.expiresAtMs;
                                store.upsert(report);
                                dialog.dismiss();
                                openPublisher(session.publisherUrl);
                                filter = "LIVE";
                                refreshFeed(false);
                            });
                }));
        dialog.show();
    }

    private void openPublisher(String publisherUrl) {
        if (!MonitorReport.safeHttps(publisherUrl)) {
            Toast.makeText(this, "The live publisher address is unavailable",
                    Toast.LENGTH_LONG).show();
            return;
        }
        Intent publish = new Intent(Intent.ACTION_VIEW, Uri.parse(publisherUrl));
        try {
            startActivity(publish);
            Toast.makeText(this,
                    "Return to Local Monitors after the broadcasting camera opens",
                    Toast.LENGTH_LONG).show();
        } catch (ActivityNotFoundException error) {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_TEXT, publisherUrl);
            try {
                startActivity(Intent.createChooser(
                        share, "Open publisher with a broadcasting app"));
            } catch (RuntimeException unavailable) {
                Toast.makeText(this, "No broadcasting app is available",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    private void showOwnProfile() {
        MonitorProfileStore.Profile me = profiles.profile();
        LinearLayout shell = dialogShell();
        shell.addView(text("MY LOCAL MONITOR PROFILE", TEXT, 15, true));
        LinearLayout photoRow = new LinearLayout(this);
        photoRow.setGravity(Gravity.CENTER_VERTICAL);
        photoRow.addView(avatarForOwn(me.displayName, me.avatarColor, 70),
                new LinearLayout.LayoutParams(dp(72), dp(72)));
        LinearLayout photoText = new LinearLayout(this);
        photoText.setOrientation(LinearLayout.VERTICAL);
        photoText.setPadding(dp(12), 0, 0, 0);
        photoText.addView(text(me.avatarFileName.isEmpty()
                ? "ADD A REAL PROFILE PHOTO" : "PROFILE PHOTO SAVED", TEXT, 10, true));
        photoText.addView(text("The photo remains private on this phone until a connected service accepts it.",
                MUTED, 8, false));
        photoRow.addView(photoText, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        shell.addView(photoRow, marginParams(0, 8, 0, 4));
        EditText name = edit("DISPLAY NAME", me.displayName);
        EditText handle = edit("HANDLE", me.handle);
        EditText location = edit("HOME CITY OR AREA", me.homeLocation);
        EditText bio = edit("SHORT REPORTER BIO", me.bio);
        bio.setSingleLine(false);
        bio.setMaxLines(3);
        shell.addView(name, marginParams(0, 8, 0, 0));
        shell.addView(handle, marginParams(0, 7, 0, 0));
        shell.addView(location, marginParams(0, 7, 0, 0));
        shell.addView(bio, marginParams(0, 7, 0, 0));
        Button network = actionButton(profiles.networkConfigured()
                ? "MONITOR NETWORK • CONNECTED" : "CONNECT MONITOR NETWORK", CYAN);
        network.setOnClickListener(view -> showNetworkSettings());
        shell.addView(network, marginParams(0, 9, 0, 0));
        shell.addView(text("Your profile is stored on this phone until a Monitor Network account accepts it. A profile badge never confirms the truth of an individual report.",
                AMBER, 8, false), marginParams(0, 8, 0, 0));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(shell)
                .setNegativeButton("CANCEL", null)
                .setNeutralButton(me.avatarFileName.isEmpty() ? "ADD PHOTO" : "CHANGE PHOTO", null)
                .setPositiveButton("SAVE PROFILE", (ignored, which) -> {
                    profiles.saveProfile(name.getText().toString(), handle.getText().toString(),
                            location.getText().toString(), bio.getText().toString());
                    refreshFeed(false);
                })
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_NEUTRAL)
                .setOnClickListener(view -> {
                    profiles.saveProfile(name.getText().toString(), handle.getText().toString(),
                            location.getText().toString(), bio.getText().toString());
                    dialog.dismiss();
                    pickProfilePhoto();
                }));
        dialog.show();
    }

    private void showNetworkSettings() {
        LinearLayout shell = dialogShell();
        shell.addView(text("MONITOR NETWORK CONNECTION", TEXT, 15, true));
        shell.addView(text(
                "This is the secure service that exchanges profiles, videos, live playback, likes and comments between phones. It must implement the R30 API contract and use HTTPS.",
                MUTED, 9, false), marginParams(0, 5, 0, 9));
        EditText endpoint = edit("HTTPS API ADDRESS", profiles.apiBase());
        EditText token = edit("ACCOUNT ACCESS TOKEN", profiles.apiToken());
        token.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText liveToken = edit("OPTIONAL LIVE PUBLISH TOKEN", profiles.liveToken());
        liveToken.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        shell.addView(endpoint);
        shell.addView(token, marginParams(0, 7, 0, 0));
        shell.addView(liveToken, marginParams(0, 7, 0, 0));
        shell.addView(text("Tokens are encrypted with Android Keystore. Empty fields disconnect the service; local reports remain on this phone.",
                GREEN, 8, false), marginParams(0, 8, 0, 0));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(shell)
                .setNegativeButton("CANCEL", null)
                .setNeutralButton("DISCONNECT", null)
                .setPositiveButton("SAVE & TEST", null)
                .create();
        dialog.setOnShowListener(ignored -> {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(view -> {
                profiles.saveNetwork("", "", "");
                dialog.dismiss();
                refreshFeed(true);
            });
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
                try {
                    profiles.saveNetwork(endpoint.getText().toString(), token.getText().toString(),
                            liveToken.getText().toString());
                    dialog.dismiss();
                    refreshFeed(true);
                } catch (IllegalArgumentException error) {
                    endpoint.setError(error.getMessage());
                } catch (RuntimeException error) {
                    String reference = CrashLedger.recordRecovered(
                            this, "LocalMonitorActivity.saveNetwork", error);
                    Toast.makeText(this,
                            "Network settings were not changed • " + reference,
                            Toast.LENGTH_LONG).show();
                }
            });
        });
        dialog.show();
    }

    private void stopVideo() {
        if (activeVideo != null) {
            try {
                activeVideo.stopPlayback();
            } catch (Exception ignored) { }
            activeVideo = null;
        }
    }

    private void addProgressSegments(FrameLayout card) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), 0, dp(8), 0);
        int visible = Math.max(1, Math.min(8, reports.size()));
        int selected = reports.size() <= 8 ? currentIndex
                : Math.min(7, (int) ((long) currentIndex * 8L / reports.size()));
        for (int index = 0; index < visible; index++) {
            ProgressBar segment = new ProgressBar(this, null,
                    android.R.attr.progressBarStyleHorizontal);
            segment.setMax(1000);
            segment.setProgress(index < selected ? 1000 : 0);
            segment.setProgressTintList(ColorStateList.valueOf(TEXT));
            segment.setProgressBackgroundTintList(ColorStateList.valueOf(
                    Color.argb(120, 139, 155, 166)));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(3), 1f);
            params.setMargins(dp(1), 0, dp(1), 0);
            row.addView(segment, params);
            progressSegments.add(segment);
        }
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(8), Gravity.TOP);
        params.setMargins(0, dp(52), 0, 0);
        card.addView(row, params);
    }

    private void updateStoryProgress() {
        if (activeVideo == null || progressSegments.isEmpty() || reports.isEmpty()) return;
        int selected = reports.size() <= 8 ? currentIndex
                : Math.min(7, (int) ((long) currentIndex * 8L / reports.size()));
        int duration = activeVideo.getDuration();
        int current = activeVideo.getCurrentPosition();
        int progress = duration > 0 ? Math.max(0, Math.min(1000,
                (int) ((long) current * 1000L / duration))) : 0;
        for (int index = 0; index < progressSegments.size(); index++) {
            progressSegments.get(index).setProgress(index < selected ? 1000
                    : index == selected ? progress : 0);
        }
    }

    private View avatarForReport(MonitorReport report, int size) {
        MonitorProfileStore.Profile me = profiles.profile();
        File local = me.id.equals(report.profileId) ? profiles.avatarFile() : null;
        return photoAvatar(report.displayName, report.avatarColor, size, local, report.avatarUrl);
    }

    private View avatarForOwn(String name, int color, int size) {
        return photoAvatar(name, color, size, profiles.avatarFile(), "");
    }

    private View photoAvatar(
            String name,
            int color,
            int size,
            File local,
            String remoteUrl) {
        FrameLayout frame = new FrameLayout(this);
        TextView fallback = avatar(name, color, size);
        frame.addView(fallback, fullFrame());
        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setContentDescription("Reporter profile photo");
        GradientDrawable clip = new GradientDrawable();
        clip.setShape(GradientDrawable.OVAL);
        clip.setColor(Color.BLACK);
        clip.setStroke(dp(1), Color.WHITE);
        image.setBackground(clip);
        image.setClipToOutline(true);
        image.setVisibility(View.GONE);
        frame.addView(image, fullFrame());
        if (local != null && local.isFile()) {
            avatarLoader.loadLocal(local, image, fallback);
        } else if (MonitorReport.safeHttps(remoteUrl)) {
            avatarLoader.load(remoteUrl, image, fallback);
        }
        return frame;
    }

    private View verticalAvatarAction(MonitorReport report, String label) {
        LinearLayout action = new LinearLayout(this);
        action.setOrientation(LinearLayout.VERTICAL);
        action.setGravity(Gravity.CENTER);
        action.setPadding(dp(8), dp(2), dp(8), dp(2));
        action.addView(avatarForReport(report, 40),
                new LinearLayout.LayoutParams(dp(42), dp(42)));
        TextView text = text(label, TEXT, 7, true);
        text.setGravity(Gravity.CENTER);
        action.addView(text, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(20)));
        action.setBackgroundColor(Color.TRANSPARENT);
        return action;
    }

    private TextView avatar(String name, int color, int size) {
        TextView avatar = text(initial(name), Color.WHITE, Math.max(12, size / 3), true);
        avatar.setGravity(Gravity.CENTER);
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.OVAL);
        shape.setColor(color);
        shape.setStroke(dp(1), Color.WHITE);
        avatar.setBackground(shape);
        return avatar;
    }

    private Button verticalAction(String symbol, String label) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(symbol + "\n" + label);
        button.setTextColor(TEXT);
        button.setTextSize(9);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setGravity(Gravity.CENTER);
        button.setPadding(0, 0, 0, 0);
        button.setBackgroundColor(Color.TRANSPARENT);
        return button;
    }

    private Button footerButton(String label) {
        Button button = compactButton(label);
        button.setTextSize(8);
        return button;
    }

    private LinearLayout.LayoutParams weightedFooter() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(50), 1f);
        params.setMargins(dp(2), 0, dp(2), 0);
        return params;
    }

    private LinearLayout dialogShell() {
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setPadding(dp(16), dp(14), dp(16), dp(12));
        shell.setBackgroundColor(PANEL);
        return shell;
    }

    private EditText edit(String hint, String value) {
        EditText field = new EditText(this);
        field.setHint(hint);
        field.setHintTextColor(MUTED);
        field.setTextColor(TEXT);
        field.setTextSize(11);
        field.setSingleLine(true);
        field.setText(value == null ? "" : value);
        field.setPadding(dp(12), dp(6), dp(12), dp(6));
        field.setBackground(panelBackground(PANEL_ALT, LINE, 12));
        return field;
    }

    private CheckBox checkBox(String label, boolean checked) {
        CheckBox box = new CheckBox(this);
        box.setText(label);
        box.setTextColor(TEXT);
        box.setTextSize(9);
        box.setChecked(checked);
        box.setButtonTintList(new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{CYAN, MUTED}));
        return box;
    }

    private Button compactButton(String label) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(label);
        button.setTextColor(TEXT);
        button.setTextSize(9);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setPadding(dp(4), 0, dp(4), 0);
        button.setMinHeight(0);
        button.setMinimumHeight(0);
        button.setBackground(pressableBackground(PANEL_ALT, LINE, 12));
        return button;
    }

    private Button actionButton(String label, int color) {
        Button button = compactButton(label);
        button.setTextColor(color);
        button.setBackground(pressableBackground(PANEL_ALT, color, 14));
        button.setMinHeight(dp(46));
        return button;
    }

    private TextView text(String value, int color, int sizeSp, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextColor(color);
        text.setTextSize(sizeSp);
        text.setTypeface(Typeface.create(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL));
        return text;
    }

    private GradientDrawable panelBackground(int fill, int stroke, int radiusDp) {
        GradientDrawable background = new GradientDrawable();
        background.setColor(fill);
        background.setCornerRadius(dp(radiusDp));
        background.setStroke(dp(1), stroke);
        return background;
    }

    private RippleDrawable pressableBackground(int fill, int stroke, int radiusDp) {
        return new RippleDrawable(ColorStateList.valueOf(Color.argb(70, 255, 255, 255)),
                panelBackground(fill, stroke, radiusDp), null);
    }

    private LinearLayout.LayoutParams marginParams(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return params;
    }

    private FrameLayout.LayoutParams fullFrame() {
        return new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static String initial(String name) {
        String clean = name == null ? "" : name.trim();
        return clean.isEmpty() ? "M" : clean.substring(0, 1).toUpperCase(Locale.ROOT);
    }

    private static String shortName(String name) {
        String clean = name == null ? "" : name.trim();
        return clean.length() <= 10 ? clean : clean.substring(0, 9) + "…";
    }

    private static String formatCount(int value) {
        if (value >= 1_000_000) return String.format(Locale.US, "%.1fM", value / 1_000_000d);
        if (value >= 1_000) return String.format(Locale.US, "%.1fK", value / 1_000d);
        return String.valueOf(Math.max(0, value));
    }

    private static String formatDuration(long durationMs) {
        long seconds = Math.max(0L, durationMs / 1_000L);
        return String.format(Locale.US, "%d:%02d", seconds / 60L, seconds % 60L);
    }

    private static String fallback(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        uiHandler.removeCallbacksAndMessages(null);
        if (reportStage != null) reportStage.animate().cancel();
        stopVideo();
        if (api != null) api.shutdown();
        if (avatarLoader != null) avatarLoader.shutdown();
        fileExecutor.shutdownNow();
        super.onDestroy();
    }
}
