package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.content.*;
public final class DuPerformancePolicy{
 public static boolean lowMemory(Context c){ActivityManager a=(ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE);ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo();a.getMemoryInfo(m);return m.lowMemory;}
 public static int markerBudget(Context c){return lowMemory(c)?220:520;}
 public static int hudBudget(Context c){return lowMemory(c)?60:120;}
 public static long wallpaperFrameMs(Context c){return lowMemory(c)?7000:3000;}
 public static int imageWorkers(Context c){return lowMemory(c)?1:3;}
 public static int imageCacheBytes(Context c){return lowMemory(c)?6*1024*1024:16*1024*1024;}
}