package com.sentongoharuna.worldsituationroom;
import android.content.*;import org.json.*;import java.util.*;
public final class DuThreadStore{
 static final String P="duwm_thread_meta_v1";
 public static void parent(Context c,String commentId,String parentId){c.getSharedPreferences(P,0).edit().putString("p:"+commentId,parentId==null?"":parentId).apply();}
 public static String parent(Context c,String commentId){return c.getSharedPreferences(P,0).getString("p:"+commentId,"");}
 public static int react(Context c,String commentId,String type){String k="r:"+commentId+":"+type;android.content.SharedPreferences p=c.getSharedPreferences(P,0);boolean on=!p.getBoolean(k,false);p.edit().putBoolean(k,on).apply();return on?1:0;}
 public static boolean reacted(Context c,String commentId,String type){return c.getSharedPreferences(P,0).getBoolean("r:"+commentId+":"+type,false);}
}