package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URLEncoder;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Direct native feed coordinator. Each provider is isolated, rate-budgeted and backed by
 * its own last-good cache so an outage can only mark that feed offline.
 */
public final class WorldDataRepository {
    public interface Listener {
        void onLayer(Signal.Layer layer, List<Signal> signals, FeedStatus status);
        void onWeather(String host, List<RadarFrame> frames, FeedStatus status);
        void onSearchResult(Place place, String error);
    }

    public static final class RadarFrame {
        public final String path;
        public final long timestampMs;

        RadarFrame(String path, long timestampMs) {
            this.path = path;
            this.timestampMs = timestampMs;
        }
    }

    public static final class Place {
        public final String name;
        public final double latitude;
        public final double longitude;
        public final double south;
        public final double west;
        public final double north;
        public final double east;
        public final boolean countryScope;
        public final String countryCode;

        Place(String name, double latitude, double longitude,
              double south, double west, double north, double east,
              boolean countryScope, String countryCode) {
            this.name = name;
            this.latitude = latitude;
            this.longitude = longitude;
            this.south = south;
            this.west = west;
            this.north = north;
            this.east = east;
            this.countryScope = countryScope;
            this.countryCode = countryCode == null ? "" : countryCode.toUpperCase(Locale.ROOT);
        }
    }

    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    // Four workers are enough for live feeds without creating a launch-time CPU/network burst
    // on phones. Slow providers stay isolated and scheduled refreshes never run on the UI thread.
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(4);
    private final HttpCache http;
    private final OperationsSnapshotStore snapshotStore;
    private final WidgetStateStore widgetStateStore;
    private final SecurePrefs securePrefs;
    private final AppPreferences preferences;
    private final EnumMap<Signal.Layer, List<Signal>> latest =
            new EnumMap<>(Signal.Layer.class);
    private final EnumMap<Signal.Layer, FeedStatus> statuses =
            new EnumMap<>(Signal.Layer.class);
    private final Map<String, AtomicBoolean> busy = new HashMap<>();
    private AisStreamClient ais;
    private volatile boolean running;
    private volatile long lastFlightRequest;
    private volatile SatelliteMapView.Bounds trackingBounds;
    private volatile boolean detailedTracking;
    private long lastViewportFlightKick;
    private String openSkyToken = "";
    private long openSkyTokenExpiry;
    private volatile List<Signal> latestGkgSignals = Collections.emptyList();
    private volatile List<Signal> latestFrequencySignals = Collections.emptyList();
    private volatile List<OrbitalPropagator.OrbitalRecord> orbitalRecords =
            Collections.emptyList();
    private volatile long lastOrbitalElementRequest;
    private volatile long lastOrbitalSourceAt;
    private volatile boolean orbitalElementsFromCache = true;

    public WorldDataRepository(Context context, Listener listener) {
        this.listener = listener;
        http = new HttpCache(context);
        snapshotStore = new OperationsSnapshotStore(context);
        widgetStateStore = new WidgetStateStore(context);
        securePrefs = new SecurePrefs(context);
        preferences = new AppPreferences(context);
        for (Signal.Layer layer : Signal.Layer.values()) {
            latest.put(layer, Collections.emptyList());
            statuses.put(layer, FeedStatus.loading("Waiting for first update"));
        }
        for (String name : Arrays.asList(
                "flights", "weather", "airspace", "orbit", "natural", "news", "gkg", "space", "webcams",
                "radio", "tv", "infrastructure", "markets")) {
            busy.put(name, new AtomicBoolean(false));
        }
        ais = buildAisClient();
    }

    public void start() {
        if (running) return;
        running = true;
        // Paint useful content immediately, then let network feeds join progressively.
        publishPublicMediaDirectory();
        publishStrategicReferences();
        scheduler.execute(this::hydrateCachedState);
        // Start the small, high-value feeds first. Large directories join later so the globe,
        // controls and cached records remain responsive from the first frame.
        scheduler.scheduleWithFixedDelay(this::refreshWeather, 450L,
                AppConfig.WEATHER_MS, TimeUnit.MILLISECONDS);
        scheduler.scheduleWithFixedDelay(this::refreshFlights, 900L, 15_000L,
                TimeUnit.MILLISECONDS);
        scheduler.scheduleWithFixedDelay(this::refreshNaturalEvents, 1_500L,
                AppConfig.NATURAL_EVENTS_MS, TimeUnit.MILLISECONDS);
        scheduler.scheduleWithFixedDelay(this::refreshNews, 2_600L,
                AppConfig.NEWS_MS, TimeUnit.MILLISECONDS);
        scheduler.scheduleWithFixedDelay(this::refreshAirspace, 3_300L,
                AppConfig.AIRSPACE_MS, TimeUnit.MILLISECONDS);
        scheduler.scheduleWithFixedDelay(this::refreshSpaceWeather, 4_000L,
                AppConfig.SPACE_WEATHER_MS, TimeUnit.MILLISECONDS);
        scheduler.schedule(ais::start, 4_800L, TimeUnit.MILLISECONDS);
        // Element downloads obey CelesTrak's two-hour cache guidance. The inexpensive local
        // projection runs every 15 seconds so moving orbital context never blocks the UI.
        scheduler.scheduleWithFixedDelay(this::refreshOrbitalLayer, 5_100L,
                AppConfig.ORBITAL_PROPAGATION_MS, TimeUnit.MILLISECONDS);
        scheduler.scheduleWithFixedDelay(this::refreshWebcams, 5_600L,
                AppConfig.WEBCAMS_MS, TimeUnit.MILLISECONDS);
        scheduler.scheduleWithFixedDelay(this::refreshRadio, 6_800L,
                AppConfig.RADIO_MS, TimeUnit.MILLISECONDS);
        scheduler.scheduleWithFixedDelay(this::refreshTv, 8_800L,
                AppConfig.TV_MS, TimeUnit.MILLISECONDS);
        scheduler.scheduleWithFixedDelay(this::refreshMarkets, 10_500L,
                AppConfig.MARKETS_MS, TimeUnit.MILLISECONDS);
        scheduler.scheduleWithFixedDelay(this::refreshGkg, 13_000L,
                AppConfig.GKG_MS, TimeUnit.MILLISECONDS);
        scheduler.scheduleWithFixedDelay(this::refreshInfrastructure, 17_000L,
                AppConfig.INFRASTRUCTURE_MS, TimeUnit.MILLISECONDS);
    }

    public void stop() {
        running = false;
        ais.stop();
        scheduler.shutdownNow();
        snapshotStore.shutdown();
    }

    public void reloadCredentials() {
        lastFlightRequest = 0L;
        openSkyToken = "";
        openSkyTokenExpiry = 0L;
        ais.start();
        publishPublicMediaDirectory();
        scheduler.execute(this::refreshFlights);
        scheduler.execute(this::refreshWebcams);
        scheduler.execute(this::refreshRadio);
        scheduler.execute(this::refreshMarkets);
    }

    public SecurePrefs securePrefs() {
        return securePrefs;
    }

    public AppPreferences preferences() {
        return preferences;
    }

    public List<Signal> snapshot(Signal.Layer layer) {
        synchronized (latest) {
            return latest.get(layer);
        }
    }

    public FeedStatus status(Signal.Layer layer) {
        synchronized (statuses) {
            return statuses.get(layer);
        }
    }

    public void refreshNow() {
        lastFlightRequest = 0L;
        scheduler.execute(this::refreshFlights);
        scheduler.execute(this::refreshWeather);
        scheduler.execute(this::refreshAirspace);
        scheduler.execute(this::refreshNaturalEvents);
        scheduler.execute(this::refreshNews);
        scheduler.execute(this::refreshSpaceWeather);
        scheduler.execute(this::refreshOrbitalLayer);
        scheduler.execute(this::refreshWebcams);
        scheduler.execute(this::refreshRadio);
        scheduler.execute(this::refreshTv);
        scheduler.execute(this::refreshMarkets);
        scheduler.execute(this::refreshGkg);
        scheduler.execute(this::refreshInfrastructure);
    }

    /**
     * Lets rate-limited traffic providers follow the native map instead of repeatedly
     * downloading the whole planet. A material switch into detailed mode starts a new
     * sector request; ordinary pans are coalesced to protect free provider quotas.
     */
    public void updateTrackingViewport(
            SatelliteMapView.Bounds bounds,
            boolean detailed,
            double zoom) {
        if (bounds == null) return;
        boolean effectiveDetail = detailed && zoom >= 3.5d;
        boolean enteredDetail = effectiveDetail && !detailedTracking;
        trackingBounds = bounds;
        detailedTracking = effectiveDetail;
        ais.updateViewport(bounds, effectiveDetail);
        long now = System.currentTimeMillis();
        if (running && enteredDetail && now - lastViewportFlightKick > 60_000L) {
            lastViewportFlightKick = now;
            lastFlightRequest = 0L;
            scheduler.execute(this::refreshFlights);
        }
    }

    /** Radio Browser asks clients to record a station click whenever playback starts. */
    public void recordRadioClick(String signalId) {
        if (signalId == null || !signalId.startsWith("radio-")) return;
        String stationUuid = signalId.substring("radio-".length());
        if (!stationUuid.matches("[A-Za-z0-9-]{8,80}")) return;
        scheduler.execute(() -> {
            for (String baseUrl : radioBrowserServers()) {
                try {
                    http.getUncached(baseUrl + "/json/url/" + stationUuid);
                    return;
                } catch (Exception ignored) {
                    // Try the next discovered mirror; playback itself remains independent.
                }
            }
        });
    }

    public void search(String query) {
        String clean = query == null ? "" : query.trim();
        if (clean.isEmpty()) {
            main.post(() -> listener.onSearchResult(null, "Enter a city or country"));
            return;
        }
        GeoIndex.Point builtIn = GeoIndex.findExact(clean);
        scheduler.execute(() -> {
            try {
                String encoded = URLEncoder.encode(clean, StandardCharsets.UTF_8.name());
                HttpCache.Result result = http.get(AppConfig.NOMINATIM + encoded,
                        "search_" + clean.toLowerCase(Locale.ROOT), 7L * 24L * 60L * 60L * 1000L);
                JSONArray values = new JSONArray(result.body);
                if (values.length() == 0) {
                    throw new IllegalArgumentException("No matching place found");
                }
                JSONObject first = values.getJSONObject(0);
                double latitude = Double.parseDouble(first.getString("lat"));
                double longitude = Double.parseDouble(first.getString("lon"));
                JSONArray box = first.optJSONArray("boundingbox");
                double south = box != null && box.length() >= 4
                        ? Double.parseDouble(box.getString(0)) : latitude - 5d;
                double north = box != null && box.length() >= 4
                        ? Double.parseDouble(box.getString(1)) : latitude + 5d;
                double west = box != null && box.length() >= 4
                        ? Double.parseDouble(box.getString(2)) : longitude - 5d;
                double east = box != null && box.length() >= 4
                        ? Double.parseDouble(box.getString(3)) : longitude + 5d;
                JSONObject address = first.optJSONObject("address");
                String countryCode = address == null ? ""
                        : clean(address.optString("country_code", ""));
                String type = clean(first.optString("type", ""));
                String category = clean(first.optString("category", first.optString("class", "")));
                boolean countryScope = "country".equalsIgnoreCase(type)
                        || "boundary".equalsIgnoreCase(category)
                        && Math.abs(north - south) >= 4d && Math.abs(east - west) >= 4d;
                Place place = new Place(first.optString("display_name", clean),
                        latitude, longitude, south, west, north, east,
                        countryScope, countryCode);
                main.post(() -> listener.onSearchResult(place, ""));
            } catch (Exception error) {
                if (builtIn != null) {
                    Place fallback = new Place(clean, builtIn.latitude, builtIn.longitude,
                            builtIn.latitude - 5d, builtIn.longitude - 5d,
                            builtIn.latitude + 5d, builtIn.longitude + 5d,
                            false, "");
                    main.post(() -> listener.onSearchResult(fallback,
                            "Using the offline place index"));
                    return;
                }
                String message = shortError(error, "Search unavailable");
                main.post(() -> listener.onSearchResult(null, message));
            }
        });
    }

    /**
     * Replays last-good responses before any slow network request finishes. Cached data is
     * always marked CACHED, never LIVE, so fast startup does not weaken the credibility model.
     */
    private void hydrateCachedState() {
        if (!running) return;
        // Normalized snapshots restore traffic and other already-parsed records before every
        // provider-specific cache has been revisited. They are never advertised as live.
        try {
            for (OperationsSnapshotStore.Snapshot restored
                    : snapshotStore.loadAll().values()) {
                FeedStatus current = status(restored.layer);
                if (current != null && (current.state == FeedStatus.State.LIVE
                        || current.state == FeedStatus.State.READY)) continue;
                publish(restored.layer, restored.signals, restored.status);
            }
        } catch (RuntimeException ignored) {
            // A damaged local snapshot cannot delay the independent provider caches below.
        }
        try {
            HttpCache.Result cached = http.peek("rainviewer", 2L * 60L * 60L * 1000L);
            if (cached != null) {
                JSONObject root = new JSONObject(cached.body);
                String host = root.getString("host");
                JSONArray past = root.getJSONObject("radar").getJSONArray("past");
                List<RadarFrame> frames = parseRadarFrames(past);
                long time = frames.isEmpty() ? System.currentTimeMillis()
                        : frames.get(frames.size() - 1).timestampMs;
                FeedStatus status = new FeedStatus(FeedStatus.State.CACHED, frames.size(),
                        "Instant last-good animated radar history", time);
                synchronized (statuses) {
                    statuses.put(Signal.Layer.WEATHER, status);
                }
                widgetStateStore.recordWeather(frames, status);
                main.post(() -> listener.onWeather(host, frames, status));
            }
        } catch (Exception ignored) {
            // A corrupt individual cache entry is ignored; the scheduled live request replaces it.
        }

        try {
            List<Signal> values = new ArrayList<>();
            HttpCache.Result usgs = http.peek("usgs_all_day", 24L * 60L * 60L * 1000L);
            HttpCache.Result eonet = http.peek("nasa_eonet", 48L * 60L * 60L * 1000L);
            if (usgs != null) values.addAll(parseUsgs(usgs.body));
            if (eonet != null) values.addAll(parseEonet(eonet.body));
            if (!values.isEmpty()) {
                Collections.sort(values, (first, second) ->
                        compareNewestFirst(first.timestampMs, second.timestampMs));
                publish(Signal.Layer.NATURAL, values, new FeedStatus(
                        FeedStatus.State.CACHED, values.size(),
                        "Instant last-good USGS / NASA snapshot", System.currentTimeMillis()));
            }
        } catch (Exception ignored) {
            // Live refresh remains isolated and will still run.
        }

        try {
            HttpCache.Result alerts = http.peek("noaa_swpc_alerts", 48L * 60L * 60L * 1000L);
            HttpCache.Result kp = http.peek("noaa_swpc_kp", 48L * 60L * 60L * 1000L);
            List<Signal> values = new ArrayList<>();
            if (kp != null) values.addAll(parsePlanetaryKp(kp.body));
            if (alerts != null) values.addAll(parseSpaceWeatherAlerts(alerts.body));
            if (!values.isEmpty()) {
                Collections.sort(values, (first, second) ->
                        compareNewestFirst(first.timestampMs, second.timestampMs));
                publish(Signal.Layer.SPACE_WEATHER, values, new FeedStatus(
                        FeedStatus.State.CACHED, values.size(),
                        "Instant last-good NOAA space-weather snapshot",
                        System.currentTimeMillis()));
            }
        } catch (Exception ignored) {
            // The scheduled official NOAA refresh remains isolated from other feeds.
        }

        try {
            List<Signal> values = new ArrayList<>();
            HttpCache.Result gdelt = http.peek("gdelt_wire", 12L * 60L * 60L * 1000L);
            if (gdelt != null) values.addAll(parseGdelt(gdelt.body));
            for (String feed : preferences.rssFeeds()) {
                String host = URI.create(feed).getHost();
                HttpCache.Result rss = http.peek("rss_" + host,
                        24L * 60L * 60L * 1000L);
                if (rss != null) values.addAll(parseRss(feed, host, rss.body));
            }
            if (!values.isEmpty()) {
                values = corroborate(values);
                Collections.sort(values, (first, second) ->
                        compareNewestFirst(first.timestampMs, second.timestampMs));
                if (values.size() > 240) values = new ArrayList<>(values.subList(0, 240));
                publish(Signal.Layer.NEWS, values, new FeedStatus(
                        FeedStatus.State.CACHED, values.size(),
                        "Instant last-good global wire", System.currentTimeMillis()));
            }
        } catch (Exception ignored) {
            // Live refresh remains isolated and will still run.
        }

        try {
            HttpCache.Result radio = http.peek("radio_browser", 24L * 60L * 60L * 1000L);
            if (radio != null) {
                List<Signal> values = parseRadioStations(radio.body);
                if (!values.isEmpty()) {
                    publish(Signal.Layer.RADIO, values, new FeedStatus(
                            FeedStatus.State.CACHED, values.size(),
                            "Instant last-good public radio directory",
                            System.currentTimeMillis()));
                }
            }
        } catch (Exception ignored) {
            // Live refresh remains isolated and will still run.
        }

        try {
            HttpCache.Result channels = http.peek("iptv_channels",
                    36L * 60L * 60L * 1000L);
            HttpCache.Result streams = http.peek("iptv_streams",
                    36L * 60L * 60L * 1000L);
            HttpCache.Result blocklist = http.peek("iptv_blocklist",
                    36L * 60L * 60L * 1000L);
            if (channels != null && streams != null && blocklist != null) {
                List<Signal> values = parseTvStations(
                        channels.body, streams.body, blocklist.body);
                if (!values.isEmpty()) {
                    publish(Signal.Layer.TV, values, new FeedStatus(
                            FeedStatus.State.CACHED, values.size(),
                            "Instant last-good safe public TV index",
                            System.currentTimeMillis()));
                }
            }
        } catch (Exception ignored) {
            // The scheduled TV refresh remains isolated from other sources.
        }

        try {
            if (!securePrefs.get(SecurePrefs.WINDY_KEY).trim().isEmpty()) {
                LinkedHashMap<String, Signal> indexed = new LinkedHashMap<>();
                for (int offset = 0; offset <= AppConfig.WINDY_WEBCAM_MAX_OFFSET;
                     offset += AppConfig.WINDY_WEBCAM_PAGE_SIZE) {
                    HttpCache.Result webcams = http.peek("windy_webcams_" + offset,
                            24L * 60L * 60L * 1000L);
                    if (webcams == null) continue;
                    for (Signal signal : parseWebcams(webcams.body)) {
                        indexed.put(signal.id, signal);
                    }
                }
                if (!indexed.isEmpty()) {
                    List<Signal> values = new ArrayList<>(indexed.values());
                    publish(Signal.Layer.WEBCAMS, values, new FeedStatus(
                            FeedStatus.State.CACHED, values.size(),
                            "Instant last-good provider-permitted camera atlas",
                            System.currentTimeMillis()));
                }
            }
        } catch (Exception ignored) {
            // Live refresh remains isolated and will still run.
        }
    }

    private void publishPublicMediaDirectory() {
        long now = System.currentTimeMillis();
        List<Signal> values = new ArrayList<>();
        String userStream = securePrefs.get(SecurePrefs.PUBLIC_SAFETY_STREAM);
        String userName = securePrefs.get(SecurePrefs.PUBLIC_SAFETY_NAME);
        if (safePublicHttpsUrl(userStream)) {
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("CATEGORY", "USER-AUTHORIZED PUBLIC SAFETY AUDIO");
            facts.put("MEDIA TYPE", "AUDIO");
            facts.put("ACCESS", "Direct HTTPS stream entered by the device owner");
            facts.put("LEGAL NOTICE", "Listen only where access and local law permit");
            facts.put("CREDIBILITY", "Audio source availability does not verify spoken claims");
            values.add(new Signal("media-user-public-safety",
                    Signal.Layer.MEDIA,
                    userName.trim().isEmpty() ? "PUBLIC SAFETY AUDIO / USER FEED" : userName,
                    "Direct native audio playback. The app does not bypass authentication, "
                            + "decrypt protected traffic or redistribute a provider directory.",
                    Double.NaN, Double.NaN, Double.NaN, now,
                    "User-authorized direct public stream", userStream,
                    Signal.Credibility.PUBLIC_SOURCE, "MEDIA", "GLOBAL", 1, facts));
        } else {
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("CATEGORY", "PUBLIC SAFETY AUDIO CONFIGURATION");
            facts.put("STATUS", "No direct HTTPS audio stream configured");
            facts.put("HOW TO ENABLE", "Provider Settings • add a lawful public direct stream");
            facts.put("LIMIT", "The app will not scrape, bypass or invent scanner streams");
            values.add(new Signal("media-user-public-safety-unconfigured",
                    Signal.Layer.MEDIA, "PUBLIC SAFETY AUDIO / NOT CONNECTED",
                    "A direct, lawful stream can be played natively after the user supplies it.",
                    Double.NaN, Double.NaN, Double.NaN, now,
                    "DU World Monitor provider registry", "",
                    Signal.Credibility.PUBLIC_SOURCE, "MEDIA", "GLOBAL", 1, facts));
        }
        values.add(directorySignal("media-openmhz", "PUBLIC SAFETY • OPENMHZ DIRECTORY",
                "User-selectable public-safety radio archives and streams where agencies make them public.",
                "OpenMHz", "https://openmhz.com/", "PUBLIC SAFETY AUDIO", now));
        values.add(directorySignal("media-broadcastify", "PUBLIC SAFETY • BROADCASTIFY DIRECTORY",
                "Public scanner directory. Availability, delay and local listening rules vary.",
                "Broadcastify", "https://www.broadcastify.com/listen/", "PUBLIC SAFETY AUDIO", now - 1L));
        values.add(directorySignal("media-noaa", "RADIO • NOAA WEATHER RADIO DIRECTORY",
                "Official U.S. weather-radio station directory.",
                "NOAA / National Weather Service", "https://www.weather.gov/nwr/station_listing",
                "WEATHER RADIO", now - 2L));
        values.addAll(latestFrequencySignals);
        publish(Signal.Layer.MEDIA, values, new FeedStatus(FeedStatus.State.READY,
                values.size(), latestFrequencySignals.isEmpty()
                ? "Public call/frequency references ready"
                : "Worldwide aviation-frequency atlas + public audio registry ready", now));
    }

    private void publishStrategicReferences() {
        long now = System.currentTimeMillis();
        List<Signal> values = ReferenceCatalog.signals(now);
        publish(Signal.Layer.INFRASTRUCTURE, values, new FeedStatus(
                FeedStatus.State.READY, values.size(),
                "Static public context — never treated as live activity", now));
    }

    private Signal directorySignal(
            String id,
            String title,
            String summary,
            String source,
            String url,
            String category,
            long indexedAt) {
        Map<String, String> facts = new LinkedHashMap<>();
        facts.put("CATEGORY", category);
        facts.put("ACCESS", "Public publisher or public directory");
        facts.put("NOTICE", "Reference entry only — no direct secure media URL is exposed by this provider");
        return new Signal(id, Signal.Layer.MEDIA, title, summary,
                Double.NaN, Double.NaN, Double.NaN, indexedAt, source, url,
                Signal.Credibility.PUBLIC_SOURCE, "MEDIA", "GLOBAL", 1, facts);
    }

    private AisStreamClient buildAisClient() {
        return new AisStreamClient(securePrefs, (signals, status) ->
                publish(Signal.Layer.SHIPS, signals, status));
    }

    private void refreshFlights() {
        if (!running || !enter("flights")) return;
        try {
            String clientId = securePrefs.get(SecurePrefs.OPENSKY_CLIENT_ID);
            String clientSecret = securePrefs.get(SecurePrefs.OPENSKY_CLIENT_SECRET);
            boolean authenticated = !clientId.trim().isEmpty() && !clientSecret.trim().isEmpty();
            SatelliteMapView.Bounds bounds = trackingBounds;
            boolean sector = detailedTracking && usableSector(bounds);
            int requestCredits = sector ? openSkyCreditCost(bounds) : 4;
            long interval;
            if (authenticated) {
                interval = sector ? AppConfig.FLIGHTS_SECTOR_AUTHENTICATED_MS * requestCredits
                        : AppConfig.FLIGHTS_GLOBAL_AUTHENTICATED_MS;
            } else {
                interval = sector ? AppConfig.FLIGHTS_SECTOR_ANONYMOUS_MS * requestCredits
                        : AppConfig.FLIGHTS_GLOBAL_ANONYMOUS_MS;
            }
            long now = System.currentTimeMillis();
            if (now - lastFlightRequest < interval) return;
            lastFlightRequest = now;
            String coverage = sector ? "visible map sector" : "global overview";
            publishLoading(Signal.Layer.FLIGHTS, "Refreshing " + coverage
                    + (authenticated ? " with OpenSky OAuth" : " anonymously"));

            Map<String, String> headers = new HashMap<>();
            if (authenticated) {
                headers.put("Authorization", "Bearer " + openSkyToken(clientId, clientSecret));
            }
            String requestUrl = sector ? openSkySectorUrl(bounds) : AppConfig.OPENSKY_STATES;
            String cacheKey = sector ? "opensky_sector_" + Integer.toHexString(requestUrl.hashCode())
                    : "opensky_states_global";
            HttpCache.Result response = http.get(requestUrl, headers,
                    cacheKey, 6L * 60L * 60L * 1000L);
            JSONObject root = new JSONObject(response.body);
            JSONArray states = root.optJSONArray("states");
            if (states == null) states = new JSONArray();
            int activeCount = states.length();
            // Preserve all sector traffic and a large, representative global snapshot.
            int stride = Math.max(1, (int) Math.ceil(activeCount / 12_000d));
            List<Signal> signals = new ArrayList<>();
            for (int index = 0; index < states.length(); index += stride) {
                JSONArray state = states.optJSONArray(index);
                if (state == null || state.length() < 11 || state.isNull(5) || state.isNull(6)) {
                    continue;
                }
                double longitude = state.optDouble(5, Double.NaN);
                double latitude = state.optDouble(6, Double.NaN);
                if (!valid(latitude, longitude)) continue;
                String icao = state.optString(0, "unknown");
                String callsign = clean(state.optString(1, ""));
                String country = clean(state.optString(2, "Unknown"));
                double altitude = state.isNull(7) ? Double.NaN : state.optDouble(7, Double.NaN);
                boolean onGround = state.optBoolean(8, false);
                double speed = state.isNull(9) ? Double.NaN : state.optDouble(9, Double.NaN);
                double heading = state.isNull(10) ? Double.NaN : state.optDouble(10, Double.NaN);
                double verticalRate = state.length() <= 11 || state.isNull(11)
                        ? Double.NaN : state.optDouble(11, Double.NaN);
                String squawk = state.length() <= 14 || state.isNull(14)
                        ? "" : clean(state.optString(14, ""));
                int positionSource = state.length() <= 16 || state.isNull(16)
                        ? -1 : state.optInt(16, -1);
                int aircraftCategory = state.length() <= 17 || state.isNull(17)
                        ? 0 : state.optInt(17, 0);
                long snapshotSeconds = root.optLong("time", now / 1000L);
                long contactSeconds = state.isNull(4)
                        ? snapshotSeconds : state.optLong(4, snapshotSeconds);
                long positionSeconds = state.isNull(3)
                        ? contactSeconds : state.optLong(3, contactSeconds);
                long positionTime = positionSeconds * 1000L;
                Map<String, String> facts = new LinkedHashMap<>();
                facts.put("CALLSIGN", callsign.trim().isEmpty() ? "Not reported" : callsign);
                facts.put("ICAO24", icao.toUpperCase(Locale.ROOT));
                facts.put("ORIGIN COUNTRY", country);
                facts.put("ALTITUDE", Double.isNaN(altitude)
                        ? "Not reported" : String.format(Locale.US, "%.0f m", altitude));
                facts.put("SPEED", Double.isNaN(speed)
                        ? "Not reported" : String.format(Locale.US, "%.0f km/h", speed * 3.6d));
                facts.put("HEADING", Double.isNaN(heading)
                        ? "Not reported" : String.format(Locale.US, "%.0f°", heading));
                facts.put("STATE", onGround ? "On ground" : "Airborne");
                facts.put("AIRCRAFT CATEGORY", openSkyAircraftCategory(aircraftCategory));
                facts.put("VERTICAL RATE", Double.isNaN(verticalRate)
                        ? "Not reported" : String.format(Locale.US, "%+.1f m/s", verticalRate));
                facts.put("SQUAWK", squawk.isEmpty() ? "Not reported" : squawk);
                facts.put("POSITION SOURCE", openSkyPositionSource(positionSource));
                facts.put("LAST CONTACT", String.format(Locale.US, "%d s after position",
                        Math.max(0L, contactSeconds - positionSeconds)));
                facts.put("POSITION MODE", "Provider fix; motion estimated for at most 60 s");
                facts.put("TIMESTAMP TYPE", "OpenSky provider position time");
                facts.put("COVERAGE", sector ? "Current detailed map sector" : "Global overview");
                GeoIndex.Point countryPoint = GeoIndex.find(country);
                signals.add(new Signal(
                        "flight-" + icao,
                        Signal.Layer.FLIGHTS,
                        callsign.trim().isEmpty() ? "AIRCRAFT " + icao.toUpperCase(Locale.ROOT) : callsign,
                        onGround ? "Surface position" : "Live aircraft state vector",
                        latitude,
                        longitude,
                        heading,
                        speed,
                        positionTime,
                        "OpenSky Network",
                        "https://opensky-network.org",
                        Signal.Credibility.RAW_SIGNAL,
                        "AVIATION",
                        countryPoint == null ? "GLOBAL" : countryPoint.region,
                        1,
                        facts));
            }
            FeedStatus.State state = response.fromCache
                    ? FeedStatus.State.CACHED : FeedStatus.State.LIVE;
            publish(Signal.Layer.FLIGHTS, signals, new FeedStatus(state, activeCount,
                    response.fromCache ? "Last good OpenSky " + coverage + " snapshot"
                            : String.format(Locale.US,
                            "OpenSky %s • %d-credit request • next about %ds",
                            coverage, requestCredits, interval / 1000L),
                    System.currentTimeMillis()));
        } catch (Exception error) {
            publishFailure(Signal.Layer.FLIGHTS, shortError(error, "OpenSky feed offline"));
        } finally {
            leave("flights");
        }
    }

    private static boolean usableSector(SatelliteMapView.Bounds bounds) {
        if (bounds == null || bounds.west > bounds.east) return false;
        double latitudeSpan = Math.max(0d, bounds.north - bounds.south);
        double longitudeSpan = Math.max(0d, bounds.east - bounds.west);
        // OpenSky accepts a geographic bbox; avoid accidentally treating a near-global
        // viewport as a cheap sector query.
        return latitudeSpan > 0.01d && longitudeSpan > 0.01d
                && latitudeSpan * longitudeSpan <= 400d;
    }

    private static int openSkyCreditCost(SatelliteMapView.Bounds bounds) {
        double area = Math.max(0d, bounds.north - bounds.south)
                * Math.max(0d, bounds.east - bounds.west);
        if (area <= 25d) return 1;
        if (area <= 100d) return 2;
        return 3;
    }

    private static String openSkySectorUrl(SatelliteMapView.Bounds bounds) {
        return String.format(Locale.US,
                "%s&lamin=%.5f&lomin=%.5f&lamax=%.5f&lomax=%.5f",
                AppConfig.OPENSKY_STATES,
                Math.max(-90d, bounds.south), Math.max(-180d, bounds.west),
                Math.min(90d, bounds.north), Math.min(180d, bounds.east));
    }

    private static String openSkyPositionSource(int value) {
        switch (value) {
            case 0: return "ADS-B";
            case 1: return "ASTERIX";
            case 2: return "MLAT";
            case 3: return "FLARM";
            default: return "Not reported";
        }
    }

    private static String openSkyAircraftCategory(int value) {
        switch (value) {
            case 2: return "Light";
            case 3: return "Small";
            case 4: return "Large";
            case 5: return "High-vortex large";
            case 6: return "Heavy";
            case 7: return "High performance";
            case 8: return "Rotorcraft";
            case 9: return "Glider / sailplane";
            case 10: return "Lighter-than-air";
            case 11: return "Parachutist / skydiver";
            case 12: return "Ultralight / paraglider";
            case 14: return "Unmanned aerial vehicle";
            case 15: return "Space / trans-atmospheric";
            case 16: return "Surface emergency vehicle";
            case 17: return "Surface service vehicle";
            case 18: return "Point obstacle";
            case 19: return "Cluster obstacle";
            case 20: return "Line obstacle";
            case 1: return "No emitter category information";
            default: return "Not reported";
        }
    }

    private String openSkyToken(String clientId, String clientSecret) throws Exception {
        long now = System.currentTimeMillis();
        if (!openSkyToken.trim().isEmpty() && now < openSkyTokenExpiry - 30_000L) {
            return openSkyToken;
        }
        JSONObject token = new JSONObject(http.postOpenSkyToken(clientId, clientSecret));
        openSkyToken = token.getString("access_token");
        openSkyTokenExpiry = now + token.optLong("expires_in", 1800L) * 1000L;
        return openSkyToken;
    }

    private void refreshWeather() {
        if (!running || !enter("weather")) return;
        try {
            main.post(() -> listener.onWeather("", Collections.emptyList(),
                    FeedStatus.loading("Refreshing RainViewer radar")));
            HttpCache.Result response = http.get(AppConfig.RAINVIEWER, "rainviewer",
                    2L * 60L * 60L * 1000L);
            JSONObject root = new JSONObject(response.body);
            String host = root.getString("host");
            JSONArray past = root.getJSONObject("radar").getJSONArray("past");
            List<RadarFrame> frames = parseRadarFrames(past);
            if (frames.isEmpty()) throw new IllegalStateException("No radar frames returned");
            long time = frames.get(frames.size() - 1).timestampMs;
            FeedStatus status = new FeedStatus(response.fromCache
                    ? FeedStatus.State.CACHED : FeedStatus.State.LIVE,
                    frames.size(), response.fromCache
                    ? "Cached 2-hour radar animation"
                    : "2-hour animated radar • 10-minute frames", time);
            synchronized (statuses) {
                statuses.put(Signal.Layer.WEATHER, status);
            }
            widgetStateStore.recordWeather(frames, status);
            main.post(() -> listener.onWeather(host, frames, status));
        } catch (Exception error) {
            FeedStatus status = new FeedStatus(FeedStatus.State.OFFLINE, 0,
                    shortError(error, "RainViewer feed offline"), System.currentTimeMillis());
            synchronized (statuses) {
                statuses.put(Signal.Layer.WEATHER, status);
            }
            widgetStateStore.recordWeather(Collections.emptyList(), status);
            main.post(() -> listener.onWeather("", Collections.emptyList(), status));
        } finally {
            leave("weather");
        }
    }

    private static List<RadarFrame> parseRadarFrames(JSONArray values) throws Exception {
        List<RadarFrame> result = new ArrayList<>();
        int first = Math.max(0, values.length() - 12);
        for (int index = first; index < values.length(); index++) {
            JSONObject frame = values.getJSONObject(index);
            String path = clean(frame.optString("path", ""));
            long time = frame.optLong("time", 0L) * 1000L;
            if (!path.isEmpty() && time > 0L) result.add(new RadarFrame(path, time));
        }
        return Collections.unmodifiableList(result);
    }

    private void refreshAirspace() {
        if (!running || !enter("airspace")) return;
        publishLoading(Signal.Layer.AIRSPACE,
                "Refreshing official worldwide aviation warnings");
        try {
            HttpCache.Result response = http.get(AppConfig.AVIATION_SIGMETS,
                    "awc_world_sigmets", 12L * 60L * 60L * 1000L);
            List<Signal> values = AviationWarningParser.parse(response.body);
            Collections.sort(values, (first, second) ->
                    compareNewestFirst(first.timestampMs, second.timestampMs));
            publish(Signal.Layer.AIRSPACE, values, new FeedStatus(
                    response.fromCache ? FeedStatus.State.CACHED : FeedStatus.State.LIVE,
                    values.size(), response.fromCache
                    ? "Cached official worldwide SIGMET products"
                    : "Official worldwide SIGMET products • representative map points",
                    response.fromCache
                            ? Math.max(1L, http.cacheUpdatedAtMs("awc_world_sigmets"))
                            : System.currentTimeMillis()));
        } catch (Exception error) {
            publishFailure(Signal.Layer.AIRSPACE,
                    shortError(error, "Aviation Weather Center feed offline"));
        } finally {
            leave("airspace");
        }
    }

    private static final class OrbitalLoad {
        final List<OrbitalPropagator.OrbitalRecord> records;
        final boolean fromCache;
        final long sourceAtMs;

        OrbitalLoad(List<OrbitalPropagator.OrbitalRecord> records,
                    boolean fromCache, long sourceAtMs) {
            this.records = records;
            this.fromCache = fromCache;
            this.sourceAtMs = sourceAtMs;
        }
    }

    private void refreshOrbitalLayer() {
        if (!running || !enter("orbit")) return;
        long now = System.currentTimeMillis();
        long freshCacheAt = completeFreshOrbitalCacheAt(now);
        boolean loadElements = lastOrbitalElementRequest <= 0L
                || now - lastOrbitalElementRequest >= AppConfig.ORBITAL_ELEMENTS_MS;
        boolean requestNetwork = loadElements && freshCacheAt <= 0L;
        List<String> errors = new ArrayList<>();
        if (loadElements) {
            lastOrbitalElementRequest = requestNetwork ? now : freshCacheAt;
            publishLoading(Signal.Layer.SATELLITES,
                    requestNetwork ? "Refreshing cached public orbital elements"
                            : "Loading fresh cached public orbital elements");
            List<List<OrbitalPropagator.OrbitalRecord>> groups = new ArrayList<>();
            boolean anyCached = false;
            long oldestSource = Long.MAX_VALUE;
            String[][] sources = {
                    {AppConfig.CELESTRAK_STATIONS, "celestrak_stations", "SPACE STATIONS"},
                    {AppConfig.CELESTRAK_WEATHER, "celestrak_weather", "WEATHER"},
                    {AppConfig.CELESTRAK_GPS, "celestrak_gps", "GPS OPERATIONAL"}
            };
            for (String[] source : sources) {
                try {
                    OrbitalLoad loaded = loadOrbitalGroup(
                            source[0], source[1], source[2], requestNetwork);
                    groups.add(loaded.records);
                    anyCached |= loaded.fromCache;
                    if (loaded.sourceAtMs > 0L) {
                        oldestSource = Math.min(oldestSource, loaded.sourceAtMs);
                    }
                } catch (Exception error) {
                    errors.add(source[2] + " " + shortError(error, "offline"));
                }
            }
            List<OrbitalPropagator.OrbitalRecord> merged = OrbitalPropagator.merge(groups);
            if (!merged.isEmpty()) {
                orbitalRecords = Collections.unmodifiableList(merged);
                orbitalElementsFromCache = anyCached;
                lastOrbitalSourceAt = oldestSource < Long.MAX_VALUE ? oldestSource : now;
            }
        }

        try {
            if (orbitalRecords.isEmpty()) {
                publishFailure(Signal.Layer.SATELLITES, errors.isEmpty()
                        ? "CelesTrak orbital elements unavailable" : join(errors, "; "));
                return;
            }
            List<Signal> values = OrbitalPropagator.signals(orbitalRecords, now);
            FeedStatus.State state = orbitalElementsFromCache
                    ? FeedStatus.State.CACHED : FeedStatus.State.READY;
            String message = "Calculated every 15s from CelesTrak GP elements • elements "
                    + "cached for 2h • not live telemetry";
            if (!errors.isEmpty()) message += " • partial: " + join(errors, "; ");
            publish(Signal.Layer.SATELLITES, values, new FeedStatus(
                    state, values.size(), message,
                    lastOrbitalSourceAt > 0L ? lastOrbitalSourceAt : now));
        } catch (RuntimeException error) {
            publishFailure(Signal.Layer.SATELLITES,
                    shortError(error, "Orbital projection unavailable"));
        } finally {
            leave("orbit");
        }
    }

    private long completeFreshOrbitalCacheAt(long now) {
        long stations = http.cacheUpdatedAtMs("celestrak_stations");
        long weather = http.cacheUpdatedAtMs("celestrak_weather");
        long gps = http.cacheUpdatedAtMs("celestrak_gps");
        if (stations <= 0L || weather <= 0L || gps <= 0L) return 0L;
        long oldest = Math.min(stations, Math.min(weather, gps));
        return now - oldest < AppConfig.ORBITAL_ELEMENTS_MS ? oldest : 0L;
    }

    private OrbitalLoad loadOrbitalGroup(
            String url, String key, String group, boolean requestNetwork)
            throws Exception {
        long maximumAge = 14L * 24L * 60L * 60L * 1000L;
        HttpCache.Result result = requestNetwork
                ? http.get(url, key, maximumAge) : http.peek(key, maximumAge);
        if (result == null) throw new IllegalStateException("No cached element set");
        long sourceAt = result.fromCache ? http.cacheUpdatedAtMs(key)
                : System.currentTimeMillis();
        return new OrbitalLoad(OrbitalPropagator.parse(result.body, group),
                result.fromCache, sourceAt);
    }

    private void refreshNaturalEvents() {
        if (!running || !enter("natural")) return;
        publishLoading(Signal.Layer.NATURAL, "Refreshing USGS and NASA EONET");
        List<Signal> result = new ArrayList<>();
        int successfulFeeds = 0;
        boolean cached = false;
        List<String> errors = new ArrayList<>();
        try {
            HttpCache.Result usgs = http.get(AppConfig.USGS, "usgs_all_day",
                    24L * 60L * 60L * 1000L);
            result.addAll(parseUsgs(usgs.body));
            successfulFeeds++;
            cached |= usgs.fromCache;
        } catch (Exception error) {
            errors.add("USGS " + shortError(error, "offline"));
        }
        try {
            HttpCache.Result eonet = http.get(AppConfig.EONET, "nasa_eonet",
                    48L * 60L * 60L * 1000L);
            result.addAll(parseEonet(eonet.body));
            successfulFeeds++;
            cached |= eonet.fromCache;
        } catch (Exception error) {
            errors.add("EONET " + shortError(error, "offline"));
        }
        Collections.sort(result, (first, second) ->
                compareNewestFirst(first.timestampMs, second.timestampMs));
        if (successfulFeeds > 0) {
            FeedStatus.State state = cached ? FeedStatus.State.CACHED : FeedStatus.State.LIVE;
            String message = errors.isEmpty() ? "Official USGS + NASA events"
                    : "Partial feed — " + join(errors, "; ");
            publish(Signal.Layer.NATURAL, result,
                    new FeedStatus(state, result.size(), message, System.currentTimeMillis()));
        } else {
            publishFailure(Signal.Layer.NATURAL, join(errors, "; "));
        }
        leave("natural");
    }

    private List<Signal> parseUsgs(String body) throws Exception {
        List<Signal> result = new ArrayList<>();
        JSONArray features = new JSONObject(body).getJSONArray("features");
        for (int index = 0; index < features.length(); index++) {
            JSONObject feature = features.getJSONObject(index);
            JSONObject properties = feature.getJSONObject("properties");
            JSONArray coordinates = feature.getJSONObject("geometry").getJSONArray("coordinates");
            double longitude = coordinates.getDouble(0);
            double latitude = coordinates.getDouble(1);
            double depth = coordinates.length() > 2 ? coordinates.optDouble(2, Double.NaN) : Double.NaN;
            double magnitude = properties.optDouble("mag", 0d);
            int severity = magnitude >= 7d ? 5 : magnitude >= 6d ? 4
                    : magnitude >= 5d ? 3 : magnitude >= 4d ? 2 : 1;
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("MAGNITUDE", String.format(Locale.US, "M %.1f", magnitude));
            facts.put("DEPTH", Double.isNaN(depth)
                    ? "Not reported" : String.format(Locale.US, "%.1f km", depth));
            facts.put("FELT REPORTS", String.valueOf(properties.optInt("felt", 0)));
            facts.put("ALERT", clean(properties.optString("alert", "None")));
            result.add(new Signal(
                    "usgs-" + feature.optString("id", String.valueOf(index)),
                    Signal.Layer.NATURAL,
                    "EARTHQUAKE — " + properties.optString("place", "Location pending"),
                    properties.optString("title", "USGS seismic event"),
                    latitude, longitude, Double.NaN,
                    properties.optLong("time", System.currentTimeMillis()),
                    "U.S. Geological Survey",
                    properties.optString("url", "https://earthquake.usgs.gov"),
                    Signal.Credibility.CONFIRMED,
                    "DISASTER", regionFor(latitude, longitude), severity, facts));
        }
        return result;
    }

    private List<Signal> parseEonet(String body) throws Exception {
        List<Signal> result = new ArrayList<>();
        JSONArray events = new JSONObject(body).getJSONArray("events");
        for (int index = 0; index < events.length(); index++) {
            JSONObject event = events.getJSONObject(index);
            JSONArray geometry = event.optJSONArray("geometry");
            if (geometry == null || geometry.length() == 0) continue;
            JSONObject latestGeometry = geometry.getJSONObject(geometry.length() - 1);
            double[] point = firstCoordinate(latestGeometry.optJSONArray("coordinates"));
            if (point == null || !valid(point[1], point[0])) continue;
            JSONArray categories = event.optJSONArray("categories");
            String category = categories != null && categories.length() > 0
                    ? categories.getJSONObject(0).optString("title", "Natural event")
                    : "Natural event";
            String upper = category.toUpperCase(Locale.ROOT);
            int severity = upper.contains("WILDFIRE") || upper.contains("STORM")
                    || upper.contains("VOLCANO") ? 4 : 3;
            String url = event.optString("link", "https://eonet.gsfc.nasa.gov");
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("CATEGORY", category);
            facts.put("STATUS", event.optBoolean("closed", false) ? "Closed" : "Open");
            facts.put("EVENT ID", event.optString("id", "Not reported"));
            result.add(new Signal(
                    "eonet-" + event.optString("id", String.valueOf(index)),
                    Signal.Layer.NATURAL,
                    event.optString("title", category),
                    "NASA-tracked open natural event",
                    point[1], point[0], Double.NaN,
                    parseIso(latestGeometry.optString("date", "")),
                    "NASA EONET", url,
                    Signal.Credibility.CONFIRMED,
                    "DISASTER", regionFor(point[1], point[0]), severity, facts));
        }
        return result;
    }

    private void refreshNews() {
        if (!running || !enter("news")) return;
        publishLoading(Signal.Layer.NEWS, "Polling global wire sources");
        List<Signal> result = new ArrayList<>();
        int successful = 0;
        boolean cached = false;
        List<String> errors = new ArrayList<>();
        try {
            HttpCache.Result gdelt = http.get(AppConfig.GDELT, "gdelt_wire",
                    12L * 60L * 60L * 1000L);
            result.addAll(parseGdelt(gdelt.body));
            successful++;
            cached |= gdelt.fromCache;
        } catch (Exception error) {
            errors.add("GDELT " + shortError(error, "offline"));
        }
        for (String feed : preferences.rssFeeds()) {
            try {
                String host = URI.create(feed).getHost();
                HttpCache.Result rss = http.get(feed, "rss_" + host,
                        24L * 60L * 60L * 1000L);
                result.addAll(parseRss(feed, host, rss.body));
                successful++;
                cached |= rss.fromCache;
            } catch (Exception error) {
                errors.add("RSS " + hostOrFeed(feed) + " offline");
            }
        }
        result.addAll(latestGkgSignals);
        result = corroborate(result);
        Collections.sort(result, (first, second) ->
                compareNewestFirst(first.timestampMs, second.timestampMs));
        if (result.size() > 240) result = new ArrayList<>(result.subList(0, 240));
        if (successful > 0) {
            String message = errors.isEmpty() ? "GDELT DOC + GKG themes + public RSS wire"
                    : "Partial wire — " + errors.size() + " source(s) offline";
            publish(Signal.Layer.NEWS, result, new FeedStatus(
                    cached ? FeedStatus.State.CACHED : FeedStatus.State.LIVE,
                    result.size(), message, System.currentTimeMillis()));
        } else {
            publishFailure(Signal.Layer.NEWS, "All wire feeds offline");
        }
        leave("news");
    }

    /**
     * Reads the newest 15-minute GKG archive and publishes only a bounded set of themes that
     * match the app's declared desk. This runs after startup and never blocks the command view.
     */
    private void refreshGkg() {
        if (!running || !enter("gkg")) return;
        try {
            HttpCache.Result pointer = http.get(AppConfig.GDELT_LAST_UPDATE,
                    "gdelt_last_update", 2L * 60L * 60L * 1000L);
            String archiveUrl = "";
            for (String line : pointer.body.split("[\\r\\n]+")) {
                if (!line.contains(".gkg.csv.zip")) continue;
                for (String part : line.trim().split("\\s+")) {
                    if ((part.startsWith("https://data.gdeltproject.org/")
                            || part.startsWith("http://data.gdeltproject.org/"))
                            && part.endsWith(".gkg.csv.zip")) {
                        archiveUrl = part.replace("http://", "https://");
                        break;
                    }
                }
                if (!archiveUrl.isEmpty()) break;
            }
            if (archiveUrl.isEmpty()) throw new IllegalStateException("GKG pointer missing");
            HttpCache.BytesResult archive = http.getBytes(archiveUrl,
                    "gdelt_gkg_current", 2L * 60L * 60L * 1000L,
                    24L * 1024L * 1024L);
            List<Signal> gkg = parseGkgArchive(archive.bytes);
            latestGkgSignals = Collections.unmodifiableList(gkg);

            List<Signal> combined = new ArrayList<>();
            for (Signal signal : snapshot(Signal.Layer.NEWS)) {
                if (!signal.id.startsWith("gkg-")) combined.add(signal);
            }
            combined.addAll(gkg);
            combined = corroborate(combined);
            Collections.sort(combined, (first, second) ->
                    compareNewestFirst(first.timestampMs, second.timestampMs));
            if (combined.size() > 360) {
                combined = new ArrayList<>(combined.subList(0, 360));
            }
            FeedStatus previous = status(Signal.Layer.NEWS);
            FeedStatus.State state = archive.fromCache
                    ? FeedStatus.State.CACHED
                    : previous != null && previous.state == FeedStatus.State.LIVE
                    ? FeedStatus.State.LIVE : FeedStatus.State.READY;
            publish(Signal.Layer.NEWS, combined, new FeedStatus(state, combined.size(),
                    String.format(Locale.US,
                            "GDELT DOC + RSS + %,d current GKG theme signals", gkg.size()),
                    System.currentTimeMillis()));
        } catch (Exception ignored) {
            // GKG is a heavier enrichment. DOC/RSS remains usable and its status is preserved.
        } finally {
            leave("gkg");
        }
    }

    private List<Signal> parseGkgArchive(byte[] bytes) throws Exception {
        List<Signal> result = new ArrayList<>();
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(bytes))) {
            ZipEntry entry = zip.getNextEntry();
            if (entry == null) throw new IllegalArgumentException("Empty GKG archive");
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(zip, StandardCharsets.UTF_8), 32 * 1024);
            String line;
            int scanned = 0;
            while ((line = reader.readLine()) != null && scanned++ < 50_000
                    && result.size() < 180) {
                String[] fields = line.split("\\t", -1);
                if (fields.length < 16) continue;
                String themes = fields[8].trim().isEmpty() ? fields[7] : fields[8];
                List<String> relevant = relevantGkgThemes(themes);
                if (relevant.isEmpty()) continue;
                String document = clean(fields[4]);
                String source = clean(fields[3]);
                String recordId = clean(fields[0]);
                String primary = relevant.get(0);
                String[] location = firstGkgLocation(fields[10].trim().isEmpty()
                        ? fields[9] : fields[10]);
                double latitude = location == null ? Double.NaN : number(location[1]);
                double longitude = location == null ? Double.NaN : number(location[2]);
                if (!valid(latitude, longitude)) {
                    latitude = Double.NaN;
                    longitude = Double.NaN;
                }
                String locationName = location == null ? "LOCATION NOT RESOLVED" : location[0];
                long timestamp = parseGkgDate(recordId, fields[1]);
                String displayTheme = primary.replace('_', ' ');
                String type = classify(themes + " " + displayTheme);
                Map<String, String> facts = new LinkedHashMap<>();
                facts.put("GKG THEMES", join(relevant, " • "));
                facts.put("GKG LOCATION", locationName);
                facts.put("GKG TONE", firstDelimited(fields[15], ','));
                facts.put("PUBLISHER", source.isEmpty() ? "Not reported" : source);
                facts.put("RECORD ID", recordId);
                facts.put("SIGNAL TYPE", "GDELT Global Knowledge Graph theme signal");
                result.add(new Signal(
                        "gkg-" + Integer.toHexString((recordId + document + primary).hashCode()),
                        Signal.Layer.NEWS,
                        "GKG THEME • " + displayTheme + " • " + locationName,
                        "Automated theme metadata from the newest 15-minute GKG archive. "
                                + "It is a raw discovery signal, not confirmation of an event.",
                        latitude, longitude, Double.NaN, timestamp,
                        (source.isEmpty() ? "GDELT GKG" : source + " via GDELT GKG"),
                        safePublicHttpsUrl(document) ? document : "https://www.gdeltproject.org",
                        Signal.Credibility.UNVERIFIED, type,
                        valid(latitude, longitude) ? regionFor(latitude, longitude) : "GLOBAL",
                        severity(themes, type), facts));
            }
        }
        return result;
    }

    private static List<String> relevantGkgThemes(String value) {
        LinkedHashMap<String, String> found = new LinkedHashMap<>();
        for (String token : value.split(";")) {
            String clean = token.trim();
            int offset = clean.indexOf(',');
            if (offset > 0) clean = clean.substring(0, offset);
            String upper = clean.toUpperCase(Locale.ROOT);
            if (upper.contains("PROTEST") || upper.contains("CONFLICT")
                    || upper.contains("TERROR") || upper.contains("MILITARY")
                    || upper.contains("DISASTER") || upper.contains("EARTHQUAKE")
                    || upper.contains("FLOOD") || upper.contains("WILDFIRE")
                    || upper.contains("STORM") || upper.contains("COUP")
                    || upper.contains("ELECTION") || upper.contains("POLITICAL")
                    || upper.contains("CRISISLEX") || upper.contains("ECON_")) {
                found.put(upper, upper);
                if (found.size() >= 6) break;
            }
        }
        return new ArrayList<>(found.values());
    }

    private static String[] firstGkgLocation(String value) {
        for (String raw : value.split(";")) {
            String[] parts = raw.split("#", -1);
            if (parts.length < 7) continue;
            // V2Locations: type#full name#country#adm1#lat#lon#feature id#offset.
            double latitude = number(parts[4]);
            double longitude = number(parts[5]);
            if (valid(latitude, longitude)) {
                return new String[]{clean(parts[1]), parts[4], parts[5]};
            }
        }
        return null;
    }

    private static long parseGkgDate(String recordId, String dateField) {
        String digits = (recordId == null ? "" : recordId).replaceAll("[^0-9]", "");
        if (digits.length() >= 14) {
            return parseWithPatterns(digits.substring(0, 14),
                    new String[]{"yyyyMMddHHmmss"});
        }
        String date = dateField == null ? "" : dateField.replaceAll("[^0-9]", "");
        if (date.length() >= 14) {
            return parseWithPatterns(date.substring(0, 14),
                    new String[]{"yyyyMMddHHmmss"});
        }
        return System.currentTimeMillis();
    }

    private static String firstDelimited(String value, char delimiter) {
        if (value == null) return "Not reported";
        int offset = value.indexOf(delimiter);
        String clean = (offset < 0 ? value : value.substring(0, offset)).trim();
        return clean.isEmpty() ? "Not reported" : clean;
    }

    private static double number(String value) {
        try {
            return Double.parseDouble(value == null ? "" : value.trim());
        } catch (Exception ignored) {
            return Double.NaN;
        }
    }

    private List<Signal> parseGdelt(String body) throws Exception {
        List<Signal> result = new ArrayList<>();
        JSONArray articles = new JSONObject(body).optJSONArray("articles");
        if (articles == null) return result;
        for (int index = 0; index < articles.length(); index++) {
            JSONObject article = articles.getJSONObject(index);
            String title = clean(article.optString("title", ""));
            if (title.trim().isEmpty()) continue;
            String country = clean(article.optString("sourcecountry", ""));
            GeoIndex.Point point = GeoIndex.find(country + " " + title);
            String type = classify(title);
            int severity = severity(title, type);
            String domain = clean(article.optString("domain", "Unknown publisher"));
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("PUBLISHER", domain);
            facts.put("SOURCE COUNTRY", country.trim().isEmpty() ? "Not reported" : country);
            facts.put("SIGNAL TYPE", "Raw headline indexed by GDELT");
            result.add(new Signal(
                    "gdelt-" + Integer.toHexString((article.optString("url") + title).hashCode()),
                    Signal.Layer.NEWS,
                    title,
                    "Fast headline signal. Read the source before treating details as fact.",
                    point == null ? Double.NaN : point.latitude,
                    point == null ? Double.NaN : point.longitude,
                    Double.NaN,
                    parseGdeltDate(article.optString("seendate", "")),
                    domain + " via GDELT",
                    article.optString("url", "https://www.gdeltproject.org"),
                    Signal.Credibility.UNVERIFIED,
                    type,
                    point == null ? "GLOBAL" : point.region,
                    severity,
                    facts));
        }
        return result;
    }

    private List<Signal> parseRss(String feed, String host, String body) throws Exception {
        List<Signal> result = new ArrayList<>();
        for (RssParser.Item item : RssParser.parse(body)) {
            GeoIndex.Point point = GeoIndex.find(item.title + " " + item.description);
            String type = classify(item.title + " " + item.description);
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("PUBLISHER", host);
            facts.put("WIRE TYPE", "Published RSS report");
            result.add(new Signal(
                    "rss-" + Integer.toHexString((item.link + item.title).hashCode()),
                    Signal.Layer.NEWS,
                    item.title,
                    limit(item.description, 260),
                    point == null ? Double.NaN : point.latitude,
                    point == null ? Double.NaN : point.longitude,
                    Double.NaN,
                    item.timestampMs,
                    host,
                    item.link.trim().isEmpty() ? feed : item.link,
                    Signal.Credibility.REPORTED,
                    type,
                    point == null ? "GLOBAL" : point.region,
                    severity(item.title, type),
                    facts));
        }
        return result;
    }

    private List<Signal> corroborate(List<Signal> signals) {
        List<Signal> result = new ArrayList<>(signals.size());
        for (Signal candidate : signals) {
            if (candidate.credibility != Signal.Credibility.UNVERIFIED) {
                result.add(candidate);
                continue;
            }
            Set<String> sources = new HashSet<>();
            sources.add(candidate.source);
            for (Signal other : signals) {
                if (candidate == other) continue;
                if (Math.abs(candidate.timestampMs - other.timestampMs) > 12L * 60L * 60L * 1000L) {
                    continue;
                }
                if (titleSimilarity(candidate.title, other.title) >= 0.48d) {
                    sources.add(other.source);
                }
            }
            result.add(sources.size() >= 2
                    ? candidate.withCredibility(Signal.Credibility.REPORTED) : candidate);
        }
        return result;
    }

    private void refreshSpaceWeather() {
        if (!running || !enter("space")) return;
        publishLoading(Signal.Layer.SPACE_WEATHER,
                "Refreshing official NOAA space-weather products");
        List<Signal> result = new ArrayList<>();
        int successful = 0;
        boolean cached = false;
        List<String> errors = new ArrayList<>();
        try {
            HttpCache.Result kp = http.get(AppConfig.NOAA_PLANETARY_K_INDEX,
                    "noaa_swpc_kp", 48L * 60L * 60L * 1000L);
            result.addAll(parsePlanetaryKp(kp.body));
            successful++;
            cached |= kp.fromCache;
        } catch (Exception error) {
            errors.add("Kp product " + shortError(error, "offline"));
        }
        try {
            HttpCache.Result alerts = http.get(AppConfig.NOAA_SPACE_WEATHER_ALERTS,
                    "noaa_swpc_alerts", 48L * 60L * 60L * 1000L);
            result.addAll(parseSpaceWeatherAlerts(alerts.body));
            successful++;
            cached |= alerts.fromCache;
        } catch (Exception error) {
            errors.add("alert product " + shortError(error, "offline"));
        }
        Collections.sort(result, (first, second) ->
                compareNewestFirst(first.timestampMs, second.timestampMs));
        if (result.size() > 40) result = new ArrayList<>(result.subList(0, 40));
        if (successful > 0) {
            String message = errors.isEmpty()
                    ? "Official NOAA planetary K-index + alerts"
                    : "Partial NOAA feed — " + join(errors, "; ");
            publish(Signal.Layer.SPACE_WEATHER, result, new FeedStatus(
                    cached ? FeedStatus.State.CACHED : FeedStatus.State.LIVE,
                    result.size(), message, System.currentTimeMillis()));
        } else {
            publishFailure(Signal.Layer.SPACE_WEATHER,
                    errors.isEmpty() ? "NOAA space-weather feed offline" : join(errors, "; "));
        }
        leave("space");
    }

    private List<Signal> parsePlanetaryKp(String body) throws Exception {
        JSONArray rows = new JSONArray(body);
        List<Signal> result = new ArrayList<>();
        JSONObject latest = null;
        for (int index = rows.length() - 1; index >= 0; index--) {
            JSONObject row = rows.optJSONObject(index);
            if (row != null && row.has("Kp")) {
                latest = row;
                break;
            }
        }
        if (latest == null) return result;
        double kp = latest.optDouble("Kp", Double.NaN);
        if (Double.isNaN(kp)) return result;
        int severity = kp >= 8d ? 5 : kp >= 7d ? 4 : kp >= 5d ? 3 : kp >= 4d ? 2 : 1;
        Map<String, String> facts = new LinkedHashMap<>();
        facts.put("PLANETARY K-INDEX", String.format(Locale.US, "%.2f", kp));
        facts.put("RUNNING A-INDEX", String.valueOf(latest.optInt("a_running", 0)));
        facts.put("REPORTING STATIONS", String.valueOf(latest.optInt("station_count", 0)));
        facts.put("MEASUREMENT", "Official geomagnetic observation; not a terrestrial incident");
        String time = clean(latest.optString("time_tag", ""));
        result.add(new Signal(
                "noaa-kp-" + time.replaceAll("[^0-9]", ""),
                Signal.Layer.SPACE_WEATHER,
                String.format(Locale.US, "PLANETARY GEOMAGNETIC INDEX • KP %.2f", kp),
                kp >= 5d ? "Geomagnetic storm-level conditions are present in the latest NOAA product."
                        : "Latest planetary geomagnetic activity reported by NOAA SWPC.",
                Double.NaN, Double.NaN, Double.NaN,
                parseWithPatterns(time, new String[]{"yyyy-MM-dd'T'HH:mm:ss"}),
                "NOAA Space Weather Prediction Center",
                "https://www.swpc.noaa.gov/",
                Signal.Credibility.CONFIRMED,
                "SPACE WEATHER", "GLOBAL", severity, facts));
        return result;
    }

    private List<Signal> parseSpaceWeatherAlerts(String body) throws Exception {
        JSONArray rows = new JSONArray(body);
        List<Signal> result = new ArrayList<>();
        int limit = Math.min(rows.length(), 30);
        for (int index = 0; index < limit; index++) {
            JSONObject row = rows.optJSONObject(index);
            if (row == null) continue;
            String productId = clean(row.optString("product_id", "NOAA"));
            String issued = clean(row.optString("issue_datetime", ""));
            String message = cleanMultiline(row.optString("message", ""));
            if (message.isEmpty()) continue;
            String upper = message.toUpperCase(Locale.ROOT);
            int severity = containsAny(upper, "G5", "S5", "R5") ? 5
                    : containsAny(upper, "G4", "S4", "R4", "G3", "S3", "R3") ? 4
                    : containsAny(upper, "G2", "S2", "R2", "G1", "S1", "R1") ? 3
                    : upper.contains("WARNING") || upper.contains("ALERT") ? 2 : 1;
            String title = firstAlertHeadline(message);
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("PRODUCT ID", productId);
            facts.put("PRODUCT CLASS", upper.contains("WARNING") ? "WARNING"
                    : upper.contains("WATCH") ? "WATCH"
                    : upper.contains("ALERT") ? "ALERT" : "ADVISORY");
            facts.put("SCOPE", "Global space-weather product; impacts vary by latitude and system");
            facts.put("CREDIBILITY", "Official structured source; impact language remains NOAA's");
            result.add(new Signal(
                    "noaa-space-" + productId + "-" + issued.replaceAll("[^0-9]", ""),
                    Signal.Layer.SPACE_WEATHER,
                    title,
                    limit(message, 520),
                    Double.NaN, Double.NaN, Double.NaN,
                    parseWithPatterns(issued, new String[]{
                            "yyyy-MM-dd HH:mm:ss.SSS", "yyyy-MM-dd HH:mm:ss"}),
                    "NOAA Space Weather Prediction Center",
                    "https://www.swpc.noaa.gov/products/alerts-watches-and-warnings",
                    Signal.Credibility.CONFIRMED,
                    "SPACE WEATHER", "GLOBAL", severity, facts));
        }
        return result;
    }

    private static String firstAlertHeadline(String message) {
        for (String line : message.split("\\n")) {
            String clean = line.trim();
            String upper = clean.toUpperCase(Locale.ROOT);
            if (clean.length() >= 8 && (upper.contains("WARNING")
                    || upper.contains("WATCH") || upper.contains("ALERT"))) {
                return limit(clean.replaceAll("\\s+", " "), 110);
            }
        }
        String first = message.split("\\n", 2)[0].trim();
        return first.isEmpty() ? "NOAA SPACE-WEATHER PRODUCT" : limit(first, 110);
    }

    private static String cleanMultiline(String value) {
        if (value == null) return "";
        return value.replace("\r", "").trim().replaceAll("[ \\t]+", " ")
                .replaceAll("\\n{3,}", "\\n\\n");
    }

    private void refreshRadio() {
        if (!running || !enter("radio")) return;
        publishLoading(Signal.Layer.RADIO, "Refreshing public internet radio directory");
        try {
            Exception lastFailure = null;
            for (String baseUrl : radioBrowserServers()) {
                try {
                    HttpCache.Result response = http.get(baseUrl + AppConfig.RADIO_BROWSER_PATH,
                            "radio_browser", 24L * 60L * 60L * 1000L);
                    List<Signal> values = parseRadioStations(response.body);
                    publish(Signal.Layer.RADIO, values, new FeedStatus(response.fromCache
                            ? FeedStatus.State.CACHED : FeedStatus.State.LIVE,
                            values.size(), response.fromCache
                            ? "Last-good public radio directory"
                            : "Public internet stations checked by Radio Browser",
                            System.currentTimeMillis()));
                    return;
                } catch (Exception error) {
                    lastFailure = error;
                }
            }
            if (lastFailure != null) throw lastFailure;
            throw new IllegalStateException("No public radio directory server found");
        } catch (Exception error) {
            publishFailure(Signal.Layer.RADIO,
                    shortError(error, "Public radio directory offline"));
        } finally {
            leave("radio");
        }
    }

    private List<String> radioBrowserServers() {
        List<String> result = new ArrayList<>();
        try {
            for (InetAddress address : InetAddress.getAllByName(AppConfig.RADIO_BROWSER_DNS)) {
                String host = address.getCanonicalHostName();
                if (host != null && host.endsWith(".api.radio-browser.info")) {
                    String base = "https://" + host;
                    if (!result.contains(base)) result.add(base);
                }
            }
            Collections.shuffle(result);
        } catch (Exception ignored) {
            // The documented fallback below keeps this feed isolated from DNS discovery failures.
        }
        if (!result.contains(AppConfig.RADIO_BROWSER_FALLBACK)) {
            result.add(AppConfig.RADIO_BROWSER_FALLBACK);
        }
        return result;
    }

    private List<Signal> parseRadioStations(String body) throws Exception {
        JSONArray stations = new JSONArray(body);
        List<Signal> result = new ArrayList<>();
        for (int index = 0; index < stations.length(); index++) {
            JSONObject station = stations.optJSONObject(index);
            if (station == null || station.optInt("lastcheckok", 1) == 0) continue;
            String stream = clean(station.optString("url_resolved",
                    station.optString("url", "")));
            // The native app deliberately refuses cleartext audio endpoints.
            if (!stream.startsWith("https://")) continue;
            String name = clean(station.optString("name", "Public radio"));
            String country = clean(station.optString("country", ""));
            String state = clean(station.optString("state", ""));
            String language = clean(station.optString("language", ""));
            String codec = clean(station.optString("codec", ""));
            String tags = limit(station.optString("tags", ""), 120);
            int bitrate = station.optInt("bitrate", 0);
            double latitude = station.isNull("geo_lat")
                    ? Double.NaN : station.optDouble("geo_lat", Double.NaN);
            double longitude = station.isNull("geo_long")
                    ? Double.NaN : station.optDouble("geo_long", Double.NaN);
            if (!valid(latitude, longitude)) {
                latitude = Double.NaN;
                longitude = Double.NaN;
            }
            GeoIndex.Point countryPoint = GeoIndex.find(country);
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("COUNTRY", country.trim().isEmpty() ? "Not reported" : country);
            if (!state.trim().isEmpty()) facts.put("AREA", state);
            facts.put("LANGUAGE", language.trim().isEmpty() ? "Not reported" : language);
            facts.put("AUDIO", (codec.trim().isEmpty() ? "Stream" : codec)
                    + (bitrate > 0 ? " • " + bitrate + " kbps" : ""));
            if (!tags.trim().isEmpty()) facts.put("TAGS", tags);
            facts.put("ACCESS", "Public internet radio — tap to play natively");
            facts.put("DIRECTORY CHECK", station.optString(
                    "lastchecktime_iso8601", "Provider timestamp unavailable"));
            result.add(new Signal(
                    "radio-" + station.optString("stationuuid", String.valueOf(index)),
                    Signal.Layer.RADIO,
                    "RADIO • " + name,
                    "Public internet audio station indexed by the Radio Browser community directory.",
                    latitude, longitude, Double.NaN,
                    parseIso(station.optString("lastchecktime_iso8601", "")),
                    name + " via Radio Browser",
                    stream,
                    Signal.Credibility.PUBLIC_SOURCE,
                    "RADIO",
                    countryPoint == null ? "GLOBAL" : countryPoint.region,
                    1,
                    facts));
        }
        return result;
    }

    private void refreshTv() {
        if (!running || !enter("tv")) return;
        publishLoading(Signal.Layer.TV, "Refreshing safe direct public TV index");
        try {
            HttpCache.Result channels = http.get(AppConfig.IPTV_CHANNELS,
                    "iptv_channels", 36L * 60L * 60L * 1000L);
            HttpCache.Result streams = http.get(AppConfig.IPTV_STREAMS,
                    "iptv_streams", 36L * 60L * 60L * 1000L);
            HttpCache.Result blocklist = http.get(AppConfig.IPTV_BLOCKLIST,
                    "iptv_blocklist", 36L * 60L * 60L * 1000L);
            List<Signal> values = parseTvStations(
                    channels.body, streams.body, blocklist.body);
            boolean cached = channels.fromCache || streams.fromCache || blocklist.fromCache;
            publish(Signal.Layer.TV, values, new FeedStatus(
                    cached ? FeedStatus.State.CACHED : FeedStatus.State.LIVE,
                    values.size(),
                    cached ? "Last-good safe public TV index"
                            : "Direct HTTPS public TV streams • blocked/NSFW entries removed",
                    System.currentTimeMillis()));
        } catch (Exception error) {
            publishFailure(Signal.Layer.TV,
                    shortError(error, "Public TV index offline"));
        } finally {
            leave("tv");
        }
    }

    /**
     * Joins IPTV-org channel metadata with stream records. Only metadata-backed,
     * non-NSFW, non-blocklisted direct HTTPS streams are admitted to native playback.
     */
    private List<Signal> parseTvStations(
            String channelBody,
            String streamBody,
            String blocklistBody) throws Exception {
        JSONArray channelRows = new JSONArray(channelBody);
        Map<String, TvMetadata> channels = new HashMap<>();
        for (int index = 0; index < channelRows.length(); index++) {
            JSONObject row = channelRows.optJSONObject(index);
            if (row == null || row.optBoolean("is_nsfw", false)) continue;
            String id = clean(row.optString("id", ""));
            if (id.isEmpty() || !clean(row.optString("closed", "")).isEmpty()) continue;
            channels.put(id, new TvMetadata(
                    clean(row.optString("name", id)),
                    clean(row.optString("country", "")),
                    joinJsonArray(row.optJSONArray("categories"))));
        }

        Set<String> blocked = new HashSet<>();
        JSONArray blockedRows = new JSONArray(blocklistBody);
        for (int index = 0; index < blockedRows.length(); index++) {
            JSONObject row = blockedRows.optJSONObject(index);
            if (row != null) {
                String channel = clean(row.optString("channel", ""));
                if (!channel.isEmpty()) blocked.add(channel);
            }
        }

        JSONArray streamRows = new JSONArray(streamBody);
        Set<String> seenUrls = new HashSet<>();
        List<Signal> result = new ArrayList<>();
        long indexedAt = System.currentTimeMillis();
        for (int index = 0; index < streamRows.length(); index++) {
            JSONObject row = streamRows.optJSONObject(index);
            if (row == null) continue;
            String channelId = clean(row.optString("channel", ""));
            TvMetadata metadata = channels.get(channelId);
            if (metadata == null || blocked.contains(channelId)) continue;
            String url = clean(row.optString("url", ""));
            if (!safePublicHttpsUrl(url) || !seenUrls.add(url)) continue;

            String streamTitle = clean(row.optString("title", ""));
            String title = metadata.name.isEmpty() ? streamTitle : metadata.name;
            if (title.isEmpty()) title = channelId;
            String quality = clean(row.optString("quality", ""));
            String labels = joinJsonArray(row.optJSONArray("labels"));
            String referrer = limit(clean(row.optString("referrer", "")), 300);
            String userAgent = limit(clean(row.optString("user_agent", "")), 300);

            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("CHANNEL ID", channelId);
            facts.put("COUNTRY CODE", metadata.country.isEmpty()
                    ? "Not reported" : metadata.country);
            facts.put("CATEGORY", metadata.categories.isEmpty()
                    ? "GENERAL" : metadata.categories.toUpperCase(Locale.ROOT));
            if (!quality.isEmpty()) facts.put("QUALITY", quality);
            if (!labels.isEmpty()) facts.put("AVAILABILITY", labels);
            if (!referrer.isEmpty()) facts.put("PLAYBACK REFERRER", referrer);
            if (!userAgent.isEmpty()) facts.put("PLAYBACK USER AGENT", userAgent);
            facts.put("ACCESS", "Direct HTTPS stream — opens in the native player");
            facts.put("SAFETY", "Non-NSFW metadata; provider blocklist and closed channels removed");

            result.add(new Signal(
                    "tv-" + Integer.toHexString((channelId + "|" + url).hashCode()),
                    Signal.Layer.TV,
                    "TV • " + title,
                    "Public television stream indexed by the IPTV-org community directory. "
                            + "Availability, rights and regional access remain controlled by the broadcaster.",
                    Double.NaN, Double.NaN, Double.NaN,
                    indexedAt - index,
                    title + " via IPTV-org",
                    url,
                    Signal.Credibility.PUBLIC_SOURCE,
                    metadata.categories.isEmpty() ? "TV" : firstCategory(metadata.categories),
                    "GLOBAL",
                    1,
                    facts));
        }
        Collections.sort(result, (first, second) ->
                first.title.compareToIgnoreCase(second.title));
        return result;
    }

    private void refreshMarkets() {
        if (!running || !enter("markets")) return;
        publishLoading(Signal.Layer.MARKETS, "Refreshing reference markets");
        List<Signal> values = new ArrayList<>();
        List<String> errors = new ArrayList<>();
        boolean cached = false;
        try {
            HttpCache.Result fx = http.get(AppConfig.FRANKFURTER_RATES,
                    "markets_fx", 24L * 60L * 60L * 1000L);
            values.addAll(parseFxRates(fx.body));
            cached |= fx.fromCache;
        } catch (Exception error) {
            errors.add("FX reference offline");
        }
        try {
            Map<String, String> headers = new HashMap<>();
            String key = securePrefs.get(SecurePrefs.COINGECKO_KEY);
            if (!key.trim().isEmpty()) headers.put("x-cg-demo-api-key", key);
            HttpCache.Result crypto = http.get(AppConfig.COINGECKO_SIMPLE, headers,
                    "markets_crypto", 6L * 60L * 60L * 1000L);
            values.addAll(parseCryptoPrices(crypto.body));
            cached |= crypto.fromCache;
        } catch (Exception error) {
            errors.add("crypto quote offline / demo key may be required");
        }
        values.add(marketAvailabilitySignal());
        if (values.size() > 1 || errors.isEmpty()) {
            String message = errors.isEmpty()
                    ? "FX and crypto reference quotes • not trading prices"
                    : "Partial market desk • " + join(errors, "; ");
            publish(Signal.Layer.MARKETS, values, new FeedStatus(
                    cached ? FeedStatus.State.CACHED : FeedStatus.State.LIVE,
                    values.size(), message, System.currentTimeMillis()));
        } else {
            publish(Signal.Layer.MARKETS, values, new FeedStatus(
                    FeedStatus.State.OFFLINE, values.size(), join(errors, "; "),
                    System.currentTimeMillis()));
        }
        leave("markets");
    }

    private List<Signal> parseFxRates(String body) throws Exception {
        JSONObject root = new JSONObject(body);
        JSONObject rates = root.getJSONObject("rates");
        String base = root.optString("base", "USD");
        long timestamp = parseWithPatterns(root.optString("date", ""),
                new String[]{"yyyy-MM-dd"});
        if (timestamp <= 0L) timestamp = System.currentTimeMillis();
        List<Signal> result = new ArrayList<>();
        java.util.Iterator<String> keys = rates.keys();
        while (keys.hasNext()) {
            String currency = keys.next();
            double rate = rates.optDouble(currency, Double.NaN);
            if (Double.isNaN(rate)) continue;
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("REFERENCE RATE", String.format(Locale.US, "1 %s = %,.4f %s",
                    base, rate, currency));
            facts.put("QUOTE CLASS", "Daily reference rate — not executable");
            facts.put("PRICE TIME", root.optString("date", "Provider date unavailable"));
            facts.put("NOTICE", "Informational only; not financial advice");
            result.add(new Signal("market-fx-" + currency.toLowerCase(Locale.ROOT),
                    Signal.Layer.MARKETS, base + "/" + currency + " REFERENCE RATE",
                    "Latest provider reference rate. It may differ from bank, cash or trading rates.",
                    Double.NaN, Double.NaN, Double.NaN, timestamp,
                    "Frankfurter / European Central Bank reference data",
                    "https://frankfurter.dev", Signal.Credibility.PUBLIC_SOURCE,
                    "MARKET", "GLOBAL", 1, facts));
        }
        return result;
    }

    private List<Signal> parseCryptoPrices(String body) throws Exception {
        JSONObject root = new JSONObject(body);
        String[][] assets = {{"bitcoin", "BTC"}, {"ethereum", "ETH"}, {"solana", "SOL"}};
        List<Signal> result = new ArrayList<>();
        for (String[] asset : assets) {
            JSONObject value = root.optJSONObject(asset[0]);
            if (value == null) continue;
            double price = value.optDouble("usd", Double.NaN);
            if (Double.isNaN(price)) continue;
            double change = value.optDouble("usd_24h_change", Double.NaN);
            long timestamp = value.optLong("last_updated_at",
                    System.currentTimeMillis() / 1000L) * 1000L;
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("USD PRICE", String.format(Locale.US, "$%,.2f", price));
            facts.put("24H CHANGE", Double.isNaN(change) ? "Not reported"
                    : String.format(Locale.US, "%+.2f%%", change));
            facts.put("QUOTE CLASS", "Provider reference quote — not executable");
            facts.put("NOTICE", "Volatile asset • informational only • not financial advice");
            result.add(new Signal("market-crypto-" + asset[0], Signal.Layer.MARKETS,
                    asset[1] + " / USD", "Latest provider crypto reference quote.",
                    Double.NaN, Double.NaN, Double.NaN, timestamp,
                    "CoinGecko", "https://www.coingecko.com",
                    Signal.Credibility.PUBLIC_SOURCE, "MARKET", "GLOBAL",
                    !Double.isNaN(change) && Math.abs(change) >= 10d ? 3 : 1, facts));
        }
        return result;
    }

    private Signal marketAvailabilitySignal() {
        Map<String, String> facts = new LinkedHashMap<>();
        facts.put("COMMODITIES", "No keyless official near-real-time quote connected");
        facts.put("GOLD / OIL", "No value displayed — prevents stale or invented prices");
        facts.put("CRYPTO KEY", securePrefs.get(SecurePrefs.COINGECKO_KEY).isEmpty()
                ? "Optional CoinGecko demo key not set" : "Encrypted demo key configured");
        facts.put("NOTICE", "Provider availability status, not a market quote");
        return new Signal("market-provider-status", Signal.Layer.MARKETS,
                "COMMODITIES / PROVIDER STATUS",
                "The desk exposes missing coverage instead of filling it with estimates.",
                Double.NaN, Double.NaN, Double.NaN, System.currentTimeMillis(),
                "DU World Monitor provider registry", "",
                Signal.Credibility.PUBLIC_SOURCE, "MARKET", "GLOBAL", 1, facts);
    }

    private void refreshInfrastructure() {
        if (!running || !enter("infrastructure")) return;
        List<Signal> values = ReferenceCatalog.signals(System.currentTimeMillis());
        try {
            HttpCache.Result airports = http.get(AppConfig.OURAIRPORTS_AIRPORTS,
                    "ourairports_airports", 7L * 24L * 60L * 60L * 1000L);
            HttpCache.Result runways = http.get(AppConfig.OURAIRPORTS_RUNWAYS,
                    "ourairports_runways", 7L * 24L * 60L * 60L * 1000L);
            HttpCache.Result frequencies = http.get(AppConfig.OURAIRPORTS_FREQUENCIES,
                    "ourairports_frequencies", 7L * 24L * 60L * 60L * 1000L);
            values.addAll(parseAirportAtlas(airports.body, runways.body));
            latestFrequencySignals = Collections.unmodifiableList(
                    parseAirportFrequencies(airports.body, frequencies.body));
            publishPublicMediaDirectory();
            boolean cached = airports.fromCache || runways.fromCache || frequencies.fromCache;
            publish(Signal.Layer.INFRASTRUCTURE, values, new FeedStatus(
                    cached ? FeedStatus.State.CACHED : FeedStatus.State.LIVE,
                    values.size(), cached
                    ? "Cached worldwide airport/runway atlas + port references"
                    : "Nightly OurAirports atlas + World Port Index references",
                    System.currentTimeMillis()));
        } catch (Exception error) {
            publish(Signal.Layer.INFRASTRUCTURE, values, new FeedStatus(
                    FeedStatus.State.READY, values.size(),
                    "Built-in major airport/port context • nightly atlas unavailable",
                    System.currentTimeMillis()));
        } finally {
            leave("infrastructure");
        }
    }

    private List<Signal> parseAirportAtlas(String airportsBody, String runwaysBody) {
        Map<String, RunwayInfo> runwayByAirport = new HashMap<>();
        String[] runwayLines = runwaysBody.split("[\\r\\n]+");
        for (int index = 1; index < runwayLines.length; index++) {
            List<String> row = csvRow(runwayLines[index]);
            if (row.size() < 8) continue;
            String airport = row.get(2);
            if (airport.isEmpty() || "1".equals(row.get(7))) continue;
            RunwayInfo info = runwayByAirport.get(airport);
            if (info == null) {
                info = new RunwayInfo();
                runwayByAirport.put(airport, info);
            }
            info.count++;
            int length = integer(row.get(3));
            if (length > info.longestFeet) {
                info.longestFeet = length;
                info.surface = row.size() > 5 ? clean(row.get(5)) : "";
            }
            if (row.size() > 6 && "1".equals(row.get(6))) info.lighted++;
        }

        List<Signal> result = new ArrayList<>();
        String[] lines = airportsBody.split("[\\r\\n]+");
        long indexedAt = System.currentTimeMillis();
        for (int index = 1; index < lines.length && result.size() < 1_800; index++) {
            List<String> row = csvRow(lines[index]);
            if (row.size() < 18) continue;
            String type = row.get(2);
            boolean include = "large_airport".equals(type)
                    || "medium_airport".equals(type) && "yes".equalsIgnoreCase(row.get(11));
            if (!include) continue;
            double latitude = number(row.get(4));
            double longitude = number(row.get(5));
            if (!valid(latitude, longitude)) {
                // Current OurAirports ordering is lat at 4 / lon at 5 after id,ident,type,name.
                latitude = number(row.get(4));
                longitude = number(row.get(5));
            }
            if (!valid(latitude, longitude)) continue;
            String ident = clean(row.get(1));
            String name = clean(row.get(3));
            String country = clean(row.get(8));
            String municipality = clean(row.get(10));
            String iata = clean(row.get(13));
            String gps = clean(row.get(12));
            RunwayInfo runway = runwayByAirport.get(ident);
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("CATEGORY", "AIRPORT / RUNWAY REFERENCE");
            facts.put("IDENTIFIERS", joinNonEmpty(iata, gps, ident));
            facts.put("COUNTRY CODE", country.isEmpty() ? "Not reported" : country);
            facts.put("MUNICIPALITY", municipality.isEmpty() ? "Not reported" : municipality);
            facts.put("AIRPORT CLASS", type.replace('_', ' '));
            facts.put("SCHEDULED SERVICE", row.get(11));
            facts.put("ELEVATION", row.get(6).isEmpty() ? "Not reported" : row.get(6) + " ft");
            facts.put("RUNWAYS", runway == null ? "No open runway record joined"
                    : runway.count + " open • longest " + runway.longestFeet + " ft • "
                    + (runway.surface.isEmpty() ? "surface not reported" : runway.surface));
            facts.put("LIGHTED RUNWAYS", runway == null ? "Not reported"
                    : String.valueOf(runway.lighted));
            facts.put("LIVE STATUS", "Not asserted — nightly reference data only");
            result.add(new Signal("ourairports-" + ident, Signal.Layer.INFRASTRUCTURE,
                    name + (iata.isEmpty() ? "" : " / " + iata),
                    "Nightly public-domain airport and runway reference. It does not report "
                            + "NOTAMs, delays, closures or current operations.",
                    latitude, longitude, Double.NaN, indexedAt,
                    "OurAirports public-domain data", "https://ourairports.com/data/",
                    Signal.Credibility.PUBLIC_SOURCE, "INFRASTRUCTURE",
                    regionFor(latitude, longitude), 1, facts));
        }
        return result;
    }

    private List<Signal> parseAirportFrequencies(String airportsBody, String frequenciesBody) {
        Map<String, AirportRef> airports = new HashMap<>();
        String[] airportLines = airportsBody.split("[\\r\\n]+");
        for (int index = 1; index < airportLines.length; index++) {
            List<String> row = csvRow(airportLines[index]);
            if (row.size() < 14) continue;
            double latitude = number(row.get(4));
            double longitude = number(row.get(5));
            if (!valid(latitude, longitude)) continue;
            airports.put(row.get(1), new AirportRef(row.get(1), clean(row.get(3)),
                    clean(row.get(10)), clean(row.get(8)), latitude, longitude));
        }
        List<Signal> result = new ArrayList<>();
        String[] lines = frequenciesBody.split("[\\r\\n]+");
        long indexedAt = System.currentTimeMillis();
        for (int index = 1; index < lines.length && result.size() < 5_000; index++) {
            List<String> row = csvRow(lines[index]);
            if (row.size() < 6) continue;
            AirportRef airport = airports.get(row.get(2));
            if (airport == null) continue;
            String type = clean(row.get(3));
            String description = clean(row.get(4));
            String frequency = clean(row.get(5));
            if (frequency.isEmpty()) continue;
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("CATEGORY", "AVIATION FREQUENCY REFERENCE");
            facts.put("FREQUENCY", frequency + " MHz");
            facts.put("SERVICE", type.isEmpty() ? "Not reported" : type);
            facts.put("DESCRIPTION", description.isEmpty() ? "Not reported" : description);
            facts.put("AIRPORT", airport.name + " / " + airport.ident);
            facts.put("LOCATION", joinNonEmpty(airport.municipality, airport.country));
            facts.put("AUDIO", "Reference frequency only — no receiver or stream asserted");
            facts.put("TIMESTAMP TYPE", "Nightly dataset retrieval time");
            result.add(new Signal("frequency-" + row.get(0), Signal.Layer.MEDIA,
                    airport.ident + " • " + (type.isEmpty() ? "FREQUENCY" : type)
                            + " • " + frequency + " MHz",
                    "Public aviation-frequency reference. Frequency assignment and reception "
                            + "can change; confirm with the relevant authority before operational use.",
                    airport.latitude, airport.longitude, Double.NaN, indexedAt,
                    "OurAirports public-domain frequency data", "https://ourairports.com/data/",
                    Signal.Credibility.PUBLIC_SOURCE, "MEDIA",
                    regionFor(airport.latitude, airport.longitude), 1, facts));
        }
        return result;
    }

    private static List<String> csvRow(String line) {
        List<String> result = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean quoted = false;
        for (int index = 0; index < line.length(); index++) {
            char value = line.charAt(index);
            if (value == '"') {
                if (quoted && index + 1 < line.length() && line.charAt(index + 1) == '"') {
                    field.append('"');
                    index++;
                } else {
                    quoted = !quoted;
                }
            } else if (value == ',' && !quoted) {
                result.add(field.toString());
                field.setLength(0);
            } else {
                field.append(value);
            }
        }
        result.add(field.toString());
        return result;
    }

    private static int integer(String value) {
        try {
            return Integer.parseInt(value == null ? "" : value.trim());
        } catch (Exception ignored) {
            return 0;
        }
    }

    private static String joinNonEmpty(String... values) {
        List<String> clean = new ArrayList<>();
        for (String value : values) {
            if (value != null && !value.trim().isEmpty() && !clean.contains(value.trim())) {
                clean.add(value.trim());
            }
        }
        return clean.isEmpty() ? "Not reported" : join(clean, " • ");
    }

    private static final class RunwayInfo {
        int count;
        int lighted;
        int longestFeet;
        String surface = "";
    }

    private static final class AirportRef {
        final String ident;
        final String name;
        final String municipality;
        final String country;
        final double latitude;
        final double longitude;

        AirportRef(String ident, String name, String municipality, String country,
                   double latitude, double longitude) {
            this.ident = ident;
            this.name = name;
            this.municipality = municipality;
            this.country = country;
            this.latitude = latitude;
            this.longitude = longitude;
        }
    }

    private void refreshWebcams() {
        if (!running || !enter("webcams")) return;
        String key = securePrefs.get(SecurePrefs.WINDY_KEY);
        if (key.trim().isEmpty()) {
            publish(Signal.Layer.WEBCAMS, Collections.emptyList(),
                    new FeedStatus(FeedStatus.State.KEY_REQUIRED, 0,
                            "Add a Windy Webcams key in Settings", System.currentTimeMillis()));
            leave("webcams");
            return;
        }
        publishLoading(Signal.Layer.WEBCAMS,
                "Indexing provider-permitted worldwide public camera pages");
        try {
            Map<String, String> headers = Collections.singletonMap("x-windy-api-key", key);
            LinkedHashMap<String, Signal> indexed = new LinkedHashMap<>();
            int livePages = 0;
            int cachedPages = 0;
            int failedPages = 0;
            int consecutiveFailures = 0;
            int totalPages = AppConfig.WINDY_WEBCAM_MAX_OFFSET
                    / AppConfig.WINDY_WEBCAM_PAGE_SIZE + 1;
            for (int offset = 0; offset <= AppConfig.WINDY_WEBCAM_MAX_OFFSET;
                 offset += AppConfig.WINDY_WEBCAM_PAGE_SIZE) {
                try {
                    HttpCache.Result response = http.get(webcamPageUrl(offset), headers,
                            "windy_webcams_" + offset,
                            24L * 60L * 60L * 1000L);
                    if (response.fromCache) cachedPages++; else livePages++;
                    consecutiveFailures = 0;
                    for (Signal signal : parseWebcams(response.body)) {
                        indexed.put(signal.id, signal);
                    }
                    if (livePages + cachedPages == 1 && !indexed.isEmpty()) {
                        List<Signal> firstPage = new ArrayList<>(indexed.values());
                        publish(Signal.Layer.WEBCAMS, firstPage, new FeedStatus(
                                response.fromCache ? FeedStatus.State.CACHED
                                        : FeedStatus.State.LIVE,
                                firstPage.size(),
                                "First worldwide camera page ready • indexing remaining pages",
                                System.currentTimeMillis()));
                    }
                } catch (Exception pageError) {
                    failedPages++;
                    consecutiveFailures++;
                    // Fail fast during a provider/network outage instead of waiting on every page.
                    if (consecutiveFailures >= 3) break;
                }
            }
            List<Signal> values = new ArrayList<>(indexed.values());
            if (values.isEmpty()) throw new IllegalStateException("No public camera pages available");
            FeedStatus.State state = livePages > 0
                    ? FeedStatus.State.LIVE : FeedStatus.State.CACHED;
            String message = String.format(Locale.US,
                    "Worldwide public camera atlas • %,d unique • %d/%d live pages%s",
                    values.size(), livePages, totalPages,
                    failedPages > 0 ? " • " + failedPages + " unavailable" :
                            cachedPages > 0 ? " • " + cachedPages + " cached" : "");
            publish(Signal.Layer.WEBCAMS, values, new FeedStatus(
                    state, values.size(), message, System.currentTimeMillis()));
        } catch (Exception error) {
            publishFailure(Signal.Layer.WEBCAMS, shortError(error, "Windy Webcams offline"));
        } finally {
            leave("webcams");
        }
    }

    private List<Signal> parseWebcams(String body) throws Exception {
        JSONObject root = new JSONObject(body);
        JSONArray webcams = root.optJSONArray("webcams");
        if (webcams == null && root.optJSONObject("result") != null) {
            webcams = root.getJSONObject("result").optJSONArray("webcams");
        }
        if (webcams == null) webcams = new JSONArray();
        List<Signal> result = new ArrayList<>();
        for (int index = 0; index < webcams.length(); index++) {
            JSONObject webcam = webcams.getJSONObject(index);
            JSONObject location = webcam.optJSONObject("location");
            if (location == null) continue;
            double latitude = location.optDouble("latitude", Double.NaN);
            double longitude = location.optDouble("longitude", Double.NaN);
            if (!valid(latitude, longitude)) continue;
            JSONObject images = webcam.optJSONObject("images");
            JSONObject currentImage = images == null ? null : images.optJSONObject("current");
            String url = firstString(currentImage,
                    "preview", "thumbnail", "toenail", "full", "url");
            if (!safePublicHttpsUrl(url)) url = "";
            String title = clean(webcam.optString("title", "Public webcam"));
            String country = clean(location.optString("country", ""));
            String city = clean(location.optString("city", ""));
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("LOCATION", (city + (city.trim().isEmpty() || country.trim().isEmpty() ? "" : ", ") + country).trim());
            facts.put("SIGNAL", "Public camera indexed by the provider");
            facts.put("ACCESS", "Publicly broadcast camera; availability controlled by publisher");
            facts.put("ATLAS", "Windy provider listing — free-tier offsets through 1,000");
            facts.put("WEB CAM ID", webcam.optString("id", String.valueOf(index)));
            facts.put("MEDIA TYPE", "CAMERA IMAGE");
            facts.put("DIRECT VIEW", url.isEmpty()
                    ? "Provider did not expose a safe direct frame"
                    : "Latest provider frame opens in the native viewer");
            GeoIndex.Point point = GeoIndex.find(country);
            result.add(new Signal(
                    "webcam-" + webcam.optString("id", String.valueOf(index)),
                    Signal.Layer.WEBCAMS,
                    title,
                    "Public camera listing. The app displays the latest direct provider frame "
                            + "when available; the marker is not an emergency report.",
                    latitude, longitude, Double.NaN, System.currentTimeMillis(),
                    "Windy Webcams API", url,
                    Signal.Credibility.PUBLIC_SOURCE,
                    "WEBCAM", point == null ? "GLOBAL" : point.region, 1, facts));
        }
        return result;
    }

    private static String webcamPageUrl(int offset) {
        return AppConfig.WINDY_WEBCAMS
                + "?limit=" + AppConfig.WINDY_WEBCAM_PAGE_SIZE
                + "&offset=" + offset
                + "&include=location,urls,images";
    }

    private void publishLoading(Signal.Layer layer, String message) {
        FeedStatus previous = status(layer);
        publish(layer, snapshot(layer), new FeedStatus(FeedStatus.State.LOADING,
                previous == null ? 0 : previous.count, message, System.currentTimeMillis()));
    }

    private void publishFailure(Signal.Layer layer, String message) {
        List<Signal> previous = snapshot(layer);
        FeedStatus.State state = previous.isEmpty()
                ? FeedStatus.State.OFFLINE : FeedStatus.State.CACHED;
        publish(layer, previous, new FeedStatus(state, previous.size(), message,
                System.currentTimeMillis()));
    }

    private void publish(Signal.Layer layer, List<Signal> signals, FeedStatus status) {
        List<Signal> immutable = Collections.unmodifiableList(new ArrayList<>(signals));
        synchronized (latest) {
            latest.put(layer, immutable);
        }
        synchronized (statuses) {
            statuses.put(layer, status);
        }
        snapshotStore.saveAsync(layer, immutable, status);
        widgetStateStore.recordLayer(layer, immutable, status);
        main.post(() -> listener.onLayer(layer, immutable, status));
    }

    private boolean enter(String name) {
        AtomicBoolean guard = busy.get(name);
        return guard != null && guard.compareAndSet(false, true);
    }

    private void leave(String name) {
        AtomicBoolean guard = busy.get(name);
        if (guard != null) guard.set(false);
    }

    private static double[] firstCoordinate(JSONArray coordinates) {
        if (coordinates == null || coordinates.length() == 0) return null;
        Object first = coordinates.opt(0);
        if (first instanceof Number && coordinates.length() >= 2
                && coordinates.opt(1) instanceof Number) {
            return new double[]{coordinates.optDouble(0), coordinates.optDouble(1)};
        }
        if (first instanceof JSONArray) {
            return firstCoordinate((JSONArray) first);
        }
        return null;
    }

    private static String classify(String text) {
        String value = text.toLowerCase(Locale.ROOT);
        if (containsAny(value, "earthquake", "wildfire", "flood", "storm", "hurricane",
                "cyclone", "volcano", "landslide", "tsunami", "disaster")) return "DISASTER";
        if (containsAny(value, "protest", "demonstration", "rally", "strike", "unrest")) return "PROTEST";
        if (containsAny(value, "war", "attack", "missile", "airstrike", "clash", "killed",
                "explosion", "conflict", "military", "shooting")) return "CONFLICT";
        if (containsAny(value, "election", "president", "parliament", "minister", "government",
                "sanction", "diplomatic", "politic")) return "POLITICS";
        return "OTHER";
    }

    private static int severity(String text, String type) {
        String value = text.toLowerCase(Locale.ROOT);
        if (containsAny(value, "mass casualty", "major earthquake", "tsunami", "invasion",
                "state of emergency", "catastrophic")) return 5;
        if (containsAny(value, "killed", "dead", "explosion", "missile", "airstrike", "hurricane",
                "evacuation", "wildfire")) return 4;
        if (!type.equals("OTHER")) return 3;
        return 2;
    }

    private static double titleSimilarity(String first, String second) {
        Set<String> a = meaningfulWords(first);
        Set<String> b = meaningfulWords(second);
        if (a.isEmpty() || b.isEmpty()) return 0d;
        Set<String> intersection = new HashSet<>(a);
        intersection.retainAll(b);
        Set<String> union = new HashSet<>(a);
        union.addAll(b);
        return intersection.size() / (double) union.size();
    }

    private static Set<String> meaningfulWords(String value) {
        Set<String> words = new HashSet<>();
        for (String word : value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]", " ").split("\\s+")) {
            if (word.length() >= 4 && !word.matches("this|that|with|from|after|over|says|have|will")) {
                words.add(word);
            }
        }
        return words;
    }

    private static String regionFor(double latitude, double longitude) {
        if (latitude < -10d && longitude > 105d) return "OCEANIA";
        if (longitude < -30d) return "AMERICAS";
        if (longitude >= -20d && longitude <= 55d && latitude >= -38d && latitude <= 38d) return "AFRICA";
        if (longitude >= -25d && longitude <= 60d && latitude > 38d) return "EUROPE";
        if (longitude >= 25d && longitude <= 65d && latitude >= 10d && latitude <= 42d) return "MIDDLE EAST";
        if (longitude > 55d) return "ASIA";
        return "GLOBAL";
    }

    private static long parseGdeltDate(String value) {
        String[] patterns = {"yyyyMMdd'T'HHmmss'Z'", "yyyyMMddHHmmss"};
        return parseWithPatterns(value, patterns);
    }

    private static long parseIso(String value) {
        String[] patterns = {"yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss'Z'",
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"};
        return parseWithPatterns(value, patterns);
    }

    private static long parseWithPatterns(String value, String[] patterns) {
        for (String pattern : patterns) {
            try {
                SimpleDateFormat format = new SimpleDateFormat(pattern, Locale.US);
                format.setLenient(true);
                format.setTimeZone(TimeZone.getTimeZone("UTC"));
                Date parsed = format.parse(value);
                if (parsed != null) return parsed.getTime();
            } catch (ParseException ignored) {
                // Try the next known provider format.
            }
        }
        return System.currentTimeMillis();
    }

    private static String firstString(JSONObject object, String... keys) {
        if (object == null) return "";
        for (String key : keys) {
            Object raw = object.opt(key);
            if (raw instanceof String && !((String) raw).trim().isEmpty()) return (String) raw;
            if (raw instanceof JSONObject) {
                JSONObject nested = (JSONObject) raw;
                String value = firstString(nested, "day", "current", "url", "detail");
                if (!value.trim().isEmpty()) return value;
            }
        }
        return "";
    }

    private static String joinJsonArray(JSONArray values) {
        if (values == null || values.length() == 0) return "";
        StringBuilder joined = new StringBuilder();
        for (int index = 0; index < values.length(); index++) {
            String value = clean(values.optString(index, ""));
            if (value.isEmpty()) continue;
            if (joined.length() > 0) joined.append(", ");
            joined.append(value);
        }
        return joined.toString();
    }

    private static String firstCategory(String categories) {
        int comma = categories.indexOf(',');
        String first = comma < 0 ? categories : categories.substring(0, comma);
        String clean = first.trim();
        return clean.isEmpty() ? "TV" : clean.toUpperCase(Locale.ROOT);
    }

    /** Refuses cleartext, user-info, local-network and literal-IP media targets. */
    private static boolean safePublicHttpsUrl(String value) {
        return PublicMediaPolicy.isSafePublicHttpsUrl(value);
    }

    private static String hostOrFeed(String feed) {
        try {
            String host = URI.create(feed).getHost();
            return host == null ? feed : host;
        } catch (Exception ignored) {
            return feed;
        }
    }

    private static boolean containsAny(String value, String... needles) {
        for (String needle : needles) if (value.contains(needle)) return true;
        return false;
    }

    private static boolean valid(double latitude, double longitude) {
        return !Double.isNaN(latitude) && !Double.isNaN(longitude)
                && latitude >= -90d && latitude <= 90d
                && longitude >= -180d && longitude <= 180d;
    }

    private static String clean(String value) {
        return value == null ? "" : value.trim().replaceAll("\\s+", " ");
    }

    private static final class TvMetadata {
        final String name;
        final String country;
        final String categories;

        TvMetadata(String name, String country, String categories) {
            this.name = name;
            this.country = country;
            this.categories = categories;
        }
    }

    private static String limit(String value, int max) {
        String clean = clean(value);
        return clean.length() <= max ? clean : clean.substring(0, max - 1) + "…";
    }

    private static String join(List<String> values, String separator) {
        StringBuilder result = new StringBuilder();
        for (String value : values) {
            if (result.length() > 0) result.append(separator);
            result.append(value);
        }
        return result.toString();
    }

    private static String shortError(Exception error, String fallback) {
        String message = error.getMessage();
        if (message == null || message.trim().isEmpty()) return fallback;
        message = message.replaceAll("[\\r\\n]+", " ").trim();
        return message.length() > 110 ? message.substring(0, 109) + "…" : message;
    }

    private static int compareNewestFirst(long first, long second) {
        return first == second ? 0 : first < second ? 1 : -1;
    }
}
