package com.sentongoharuna.worldsituationroom;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/** Local identity, follow state and optional secure Monitor Network connection. */
public final class MonitorProfileStore {
    private static final String STORE = "du_local_monitor_profile_v1";
    private static final String PROFILE_ID = "profile_id";
    private static final String DISPLAY_NAME = "display_name";
    private static final String HANDLE = "handle";
    private static final String HOME_LOCATION = "home_location";
    private static final String BIO = "bio";
    private static final String API_BASE = "api_base";
    private static final String FOLLOWING = "following";
    private static final String BLOCKED = "blocked";
    private static final String CREATED_AT = "created_at";
    private static final String AVATAR_FILE = "profile-avatar.jpg";

    private final SharedPreferences preferences;
    private final SecurePrefs securePrefs;
    private final File profileDirectory;

    public MonitorProfileStore(Context context) {
        Context app = context.getApplicationContext();
        preferences = app.getSharedPreferences(STORE, Context.MODE_PRIVATE);
        securePrefs = new SecurePrefs(app);
        profileDirectory = new File(app.getFilesDir(), "monitor-profile");
        if (!profileDirectory.exists()) profileDirectory.mkdirs();
        ensureIdentity();
    }

    public synchronized Profile profile() {
        Profile profile = new Profile();
        profile.id = SafePreferences.string(preferences, PROFILE_ID, "");
        profile.displayName = SafePreferences.string(
                preferences, DISPLAY_NAME, "Local Monitor");
        profile.handle = MonitorReport.normalHandle(SafePreferences.string(
                preferences, HANDLE, "localmonitor"));
        profile.homeLocation = clean(SafePreferences.string(
                preferences, HOME_LOCATION, ""), 80);
        profile.bio = clean(SafePreferences.string(preferences, BIO, ""), 180);
        profile.createdAtMs = SafePreferences.longValue(
                preferences, CREATED_AT, System.currentTimeMillis());
        profile.avatarColor = avatarColor(profile.id);
        File avatar = avatarFile();
        profile.avatarFileName = avatar == null ? "" : avatar.getName();
        return profile;
    }

    /** Imports and bounds a real local profile image without granting other apps file access. */
    public synchronized void importAvatar(ContentResolver resolver, Uri source) throws IOException {
        if (resolver == null || source == null) throw new IOException("No profile photo selected");
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream input = resolver.openInputStream(source)) {
            if (input == null) throw new IOException("Profile photo could not be opened");
            BitmapFactory.decodeStream(input, null, bounds);
        }
        if (bounds.outWidth < 1 || bounds.outHeight < 1) {
            throw new IOException("Selected file is not a readable image");
        }
        if (bounds.outWidth > 20_000 || bounds.outHeight > 20_000) {
            throw new IOException("Selected profile photo dimensions are too large");
        }
        int sample = 1;
        while (bounds.outWidth / sample > 1_024 || bounds.outHeight / sample > 1_024) {
            sample *= 2;
        }
        BitmapFactory.Options decode = new BitmapFactory.Options();
        decode.inSampleSize = Math.max(1, sample);
        Bitmap bitmap;
        try (InputStream input = resolver.openInputStream(source)) {
            if (input == null) throw new IOException("Profile photo could not be reopened");
            bitmap = BitmapFactory.decodeStream(input, null, decode);
        }
        if (bitmap == null) throw new IOException("Selected profile photo could not be decoded");
        int sourceWidth = bitmap.getWidth();
        int sourceHeight = bitmap.getHeight();
        float scale = Math.min(1f, 512f / Math.max(sourceWidth, sourceHeight));
        int targetWidth = Math.max(1, Math.round(sourceWidth * scale));
        int targetHeight = Math.max(1, Math.round(sourceHeight * scale));
        Bitmap bounded = targetWidth == sourceWidth && targetHeight == sourceHeight
                ? bitmap : Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true);
        File partial = new File(profileDirectory, AVATAR_FILE + ".part");
        File target = new File(profileDirectory, AVATAR_FILE);
        try (FileOutputStream output = new FileOutputStream(partial)) {
            if (!bounded.compress(Bitmap.CompressFormat.JPEG, 90, output)) {
                throw new IOException("Unable to encode profile photo");
            }
            output.flush();
        } finally {
            if (bounded != bitmap) bounded.recycle();
            bitmap.recycle();
        }
        if (target.exists() && !target.delete()) {
            partial.delete();
            throw new IOException("Unable to replace previous profile photo");
        }
        if (!partial.renameTo(target)) {
            partial.delete();
            throw new IOException("Unable to secure profile photo");
        }
    }

    public synchronized File avatarFile() {
        File value = new File(profileDirectory, AVATAR_FILE);
        return value.isFile() && value.length() > 256L ? value : null;
    }

    public synchronized void clearAvatar() {
        File value = avatarFile();
        if (value != null) value.delete();
    }

    public synchronized void saveProfile(
            String displayName,
            String handle,
            String homeLocation,
            String bio) {
        preferences.edit()
                .putString(DISPLAY_NAME, fallback(clean(displayName, 48), "Local Monitor"))
                .putString(HANDLE, MonitorReport.normalHandle(handle).substring(1))
                .putString(HOME_LOCATION, clean(homeLocation, 80))
                .putString(BIO, clean(bio, 180))
                .apply();
    }

    public synchronized String apiBase() {
        String value = SafePreferences.string(preferences, API_BASE, "");
        return safeApiBase(value) ? stripTrailingSlash(value.trim()) : "";
    }

    public synchronized String apiToken() {
        return securePrefs.get(SecurePrefs.MONITOR_API_TOKEN);
    }

    public synchronized String liveToken() {
        return securePrefs.get(SecurePrefs.MONITOR_LIVE_TOKEN);
    }

    public synchronized void saveNetwork(String apiBase, String apiToken, String liveToken) {
        String cleanBase = apiBase == null ? "" : apiBase.trim();
        if (!cleanBase.isEmpty() && !safeApiBase(cleanBase)) {
            throw new IllegalArgumentException("Monitor Network address must use public HTTPS");
        }
        preferences.edit().putString(API_BASE, stripTrailingSlash(cleanBase)).apply();
        securePrefs.put(SecurePrefs.MONITOR_API_TOKEN, apiToken);
        securePrefs.put(SecurePrefs.MONITOR_LIVE_TOKEN, liveToken);
    }

    public boolean networkConfigured() {
        return !apiBase().isEmpty();
    }

    public synchronized boolean isFollowing(String profileId) {
        return !clean(profileId, 120).isEmpty()
                && SafePreferences.stringSet(
                preferences, FOLLOWING, new HashSet<>()).contains(profileId);
    }

    public synchronized boolean toggleFollow(String profileId) {
        String id = clean(profileId, 120);
        if (id.isEmpty() || id.equals(profile().id)) return false;
        Set<String> values = new HashSet<>(
                SafePreferences.stringSet(preferences, FOLLOWING, new HashSet<>()));
        boolean following;
        if (values.contains(id)) {
            values.remove(id);
            following = false;
        } else {
            values.add(id);
            following = true;
        }
        preferences.edit().putStringSet(FOLLOWING, values).apply();
        return following;
    }

    public synchronized boolean isBlocked(String profileId) {
        return SafePreferences.stringSet(
                preferences, BLOCKED, new HashSet<>()).contains(profileId);
    }

    public synchronized void block(String profileId) {
        String id = clean(profileId, 120);
        if (id.isEmpty() || id.equals(profile().id)) return;
        Set<String> values = new HashSet<>(
                SafePreferences.stringSet(preferences, BLOCKED, new HashSet<>()));
        values.add(id);
        preferences.edit().putStringSet(BLOCKED, values).apply();
    }

    public synchronized void unblock(String profileId) {
        Set<String> values = new HashSet<>(
                SafePreferences.stringSet(preferences, BLOCKED, new HashSet<>()));
        values.remove(profileId);
        preferences.edit().putStringSet(BLOCKED, values).apply();
    }

    private void ensureIdentity() {
        if (!clean(SafePreferences.string(preferences, PROFILE_ID, ""), 120).isEmpty()) return;
        String id = UUID.randomUUID().toString();
        String shortId = id.replace("-", "").substring(0, 7).toLowerCase(Locale.ROOT);
        preferences.edit()
                .putString(PROFILE_ID, id)
                .putString(DISPLAY_NAME, "Local Monitor")
                .putString(HANDLE, "monitor_" + shortId)
                .putLong(CREATED_AT, System.currentTimeMillis())
                .apply();
    }

    private static int avatarColor(String id) {
        int[] palette = {
                0xff70b1c9, 0xff4ba67c, 0xffc79744, 0xffae8be0,
                0xffdb4950, 0xff55a7d9, 0xffd078a4, 0xff87aa68
        };
        int hash = id == null ? 0 : id.hashCode();
        return palette[Math.floorMod(hash, palette.length)];
    }

    private static boolean safeApiBase(String value) {
        if (!MonitorReport.safeHttps(value)) return false;
        try {
            java.net.URI uri = java.net.URI.create(value.trim());
            String host = uri.getHost();
            return host != null && !host.trim().isEmpty()
                    && uri.getUserInfo() == null && uri.getFragment() == null;
        } catch (Exception ignored) {
            return false;
        }
    }

    private static String stripTrailingSlash(String value) {
        String clean = value == null ? "" : value.trim();
        while (clean.endsWith("/")) clean = clean.substring(0, clean.length() - 1);
        return clean;
    }

    private static String clean(String value, int maximum) {
        return MonitorReport.trim(value, maximum).replaceAll("[\\r\\n\\t]+", " ");
    }

    private static String fallback(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }

    public static final class Profile {
        public String id = "";
        public String displayName = "Local Monitor";
        public String handle = "@localmonitor";
        public String homeLocation = "";
        public String bio = "";
        public long createdAtMs;
        public int avatarColor;
        public String avatarFileName = "";

        public JSONObject toJson() throws JSONException {
            JSONObject value = new JSONObject();
            value.put("id", id);
            value.put("display_name", displayName);
            value.put("handle", handle);
            value.put("home_location", homeLocation);
            value.put("bio", bio);
            value.put("created_at_ms", createdAtMs);
            value.put("avatar_color", avatarColor);
            value.put("has_profile_photo", !avatarFileName.isEmpty());
            return value;
        }
    }
}
