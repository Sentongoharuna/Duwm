package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.view.*;import android.widget.*;
public final class DuVisualEngine{
 public static View make(Activity a,String system,String id){DuLiveRepository r=new DuLiveRepository(a);Signal s=r.find(system,id);if(s!=null)return DuProviderRecordView.make(a,s);
  LinearLayout b=new LinearLayout(a);b.setOrientation(LinearLayout.VERTICAL);b.setBackgroundResource(R.drawable.du_visual_engine);
  TextView h=Du2Ui.t(a,system+" · "+id,17);h.setGravity(17);h.setTextColor(Du2Ui.C);b.addView(h);
  TextView state=Du2Ui.t(a,"● "+r.status(system)+" · COUNT "+r.count(system)+" · AGE "+r.age(system),9);state.setTextColor(Du2Ui.G);b.addView(state);
  TextView x=Du2Ui.t(a,"Provider values appear here only when a matching preserved record exists.",9);x.setTextColor(Du2Ui.M);b.addView(x);return b;
 }
}