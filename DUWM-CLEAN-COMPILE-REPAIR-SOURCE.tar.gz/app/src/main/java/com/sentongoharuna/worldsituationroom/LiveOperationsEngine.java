package com.sentongoharuna.worldsituationroom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * One truth layer for the whole application. It de-duplicates records, removes expired
 * traffic, preserves provider-returned totals, and translates raw provider states into the
 * same explicit freshness language used by the map, pages, counters and source matrix.
 * It never manufactures a signal or promotes credibility.
 */
public final class LiveOperationsEngine {
    public enum SourceCondition {
        ACQUIRING,
        FRESH,
        DELAYED,
        CACHED,
        OFFLINE,
        KEY_REQUIRED
    }

    public static final class LayerSnapshot {
        public final Signal.Layer layer;
        public final List<Signal> signals;
        public final List<Signal> newAcquisitions;
        public final FeedStatus status;
        public final SourceCondition condition;
        public final int providerCount;
        public final int displayedCount;
        public final long sourceAgeMs;
        public final long newestRecordAtMs;

        LayerSnapshot(
                Signal.Layer layer,
                List<Signal> signals,
                List<Signal> newAcquisitions,
                FeedStatus status,
                SourceCondition condition,
                int providerCount,
                long sourceAgeMs,
                long newestRecordAtMs) {
            this.layer = layer;
            this.signals = signals;
            this.newAcquisitions = newAcquisitions;
            this.status = status;
            this.condition = condition;
            this.providerCount = Math.max(0, providerCount);
            this.displayedCount = signals.size();
            this.sourceAgeMs = Math.max(0L, sourceAgeMs);
            this.newestRecordAtMs = newestRecordAtMs;
        }
    }

    private static final int MAX_SEEN_ACQUISITIONS = 24_000;
    private final EnumMap<Signal.Layer, RawLayer> raw = new EnumMap<>(Signal.Layer.class);
    private final EnumMap<Signal.Layer, LayerSnapshot> snapshots =
            new EnumMap<>(Signal.Layer.class);
    private final EnumMap<Signal.Layer, Long> lastFreshAt =
            new EnumMap<>(Signal.Layer.class);
    private final Set<String> seenAcquisitions = new LinkedHashSet<>();

    public synchronized LayerSnapshot accept(
            Signal.Layer layer,
            List<Signal> signals,
            FeedStatus status,
            long nowMs) {
        List<Signal> safeSignals = signals == null
                ? Collections.emptyList() : new ArrayList<>(signals);
        FeedStatus safeStatus = status == null
                ? FeedStatus.loading("Waiting for provider") : status;
        raw.put(layer, new RawLayer(safeSignals, safeStatus));
        if (safeStatus.state == FeedStatus.State.LIVE
                || safeStatus.state == FeedStatus.State.READY) {
            lastFreshAt.put(layer, safeStatus.updatedAtMs > 0L
                    ? safeStatus.updatedAtMs : nowMs);
        } else if (safeStatus.state == FeedStatus.State.CACHED
                && !lastFreshAt.containsKey(layer)) {
            // Persistent snapshots retain the time of the last successful save here.
            lastFreshAt.put(layer, safeStatus.updatedAtMs > 0L
                    ? safeStatus.updatedAtMs : nowMs);
        }
        LayerSnapshot snapshot = build(layer, safeSignals, safeStatus, nowMs, true);
        snapshots.put(layer, snapshot);
        trimSeen();
        return snapshot;
    }

    /** Re-evaluates ages without waiting for another provider callback. */
    public synchronized EnumMap<Signal.Layer, LayerSnapshot> refreshAll(long nowMs) {
        EnumMap<Signal.Layer, LayerSnapshot> result = new EnumMap<>(Signal.Layer.class);
        for (Map.Entry<Signal.Layer, RawLayer> entry : raw.entrySet()) {
            LayerSnapshot snapshot = build(entry.getKey(), entry.getValue().signals,
                    entry.getValue().status, nowMs, false);
            snapshots.put(entry.getKey(), snapshot);
            result.put(entry.getKey(), snapshot);
        }
        return result;
    }

    public synchronized LayerSnapshot snapshot(Signal.Layer layer) {
        return snapshots.get(layer);
    }

    private LayerSnapshot build(
            Signal.Layer layer,
            List<Signal> input,
            FeedStatus rawStatus,
            long nowMs,
            boolean collectAcquisitions) {
        LinkedHashMap<String, Signal> newestById = new LinkedHashMap<>();
        long newestRecord = 0L;
        long hardAge = hardAgeMs(layer);
        for (Signal signal : input) {
            if (signal == null || signal.layer != layer) continue;
            if (isExpired(signal, hardAge, nowMs)) continue;
            Signal previous = newestById.get(signal.id);
            if (previous == null || signal.timestampMs >= previous.timestampMs) {
                newestById.put(signal.id, signal);
            }
            newestRecord = Math.max(newestRecord, signal.timestampMs);
        }
        List<Signal> visible = Collections.unmodifiableList(
                new ArrayList<>(newestById.values()));

        long freshAt = lastFreshAt.containsKey(layer)
                ? lastFreshAt.get(layer) : rawStatus.updatedAtMs;
        long sourceAge = freshAt <= 0L ? Long.MAX_VALUE
                : Math.max(0L, nowMs - freshAt);
        SourceCondition condition = conditionFor(
                rawStatus.state, sourceAge, freshAgeMs(layer));
        FeedStatus.State displayState = displayState(rawStatus.state, condition);
        String message = stateMessage(condition, sourceAge, rawStatus.message);
        FeedStatus displayStatus = new FeedStatus(displayState, rawStatus.count,
                message, freshAt > 0L ? freshAt : rawStatus.updatedAtMs);

        List<Signal> acquisitions = new ArrayList<>();
        boolean announce = collectAcquisitions
                && (rawStatus.state == FeedStatus.State.LIVE
                || rawStatus.state == FeedStatus.State.READY);
        if (announce) {
            for (Signal signal : visible) {
                String token = acquisitionToken(signal);
                if (seenAcquisitions.add(token)) acquisitions.add(signal);
            }
            Collections.sort(acquisitions, (first, second) ->
                    first.timestampMs == second.timestampMs ? 0
                            : first.timestampMs < second.timestampMs ? 1 : -1);
        } else if (collectAcquisitions) {
            // Cached startup records are remembered but never announced as new live arrivals.
            for (Signal signal : visible) seenAcquisitions.add(acquisitionToken(signal));
        }
        if (acquisitions.size() > 48) {
            acquisitions = new ArrayList<>(acquisitions.subList(0, 48));
        }
        return new LayerSnapshot(layer, visible,
                Collections.unmodifiableList(acquisitions), displayStatus, condition,
                rawStatus.count, sourceAge, newestRecord);
    }

    private static SourceCondition conditionFor(
            FeedStatus.State state,
            long ageMs,
            long freshAgeMs) {
        switch (state) {
            case LOADING: return SourceCondition.ACQUIRING;
            case OFFLINE: return SourceCondition.OFFLINE;
            case KEY_REQUIRED: return SourceCondition.KEY_REQUIRED;
            case CACHED: return SourceCondition.CACHED;
            case DELAYED: return SourceCondition.DELAYED;
            case LIVE:
            case READY:
            default:
                return ageMs > freshAgeMs
                        ? SourceCondition.DELAYED : SourceCondition.FRESH;
        }
    }

    private static FeedStatus.State displayState(
            FeedStatus.State original,
            SourceCondition condition) {
        switch (condition) {
            case ACQUIRING: return FeedStatus.State.LOADING;
            case DELAYED: return FeedStatus.State.DELAYED;
            case CACHED: return FeedStatus.State.CACHED;
            case OFFLINE: return FeedStatus.State.OFFLINE;
            case KEY_REQUIRED: return FeedStatus.State.KEY_REQUIRED;
            case FRESH:
            default:
                return original == FeedStatus.State.READY
                        ? FeedStatus.State.READY : FeedStatus.State.LIVE;
        }
    }

    private static String stateMessage(
            SourceCondition condition,
            long ageMs,
            String providerMessage) {
        String message = providerMessage == null ? "" : providerMessage.trim();
        if (condition == SourceCondition.DELAYED) {
            return "Delayed • last successful source update " + ageLabel(ageMs)
                    + " ago" + (message.isEmpty() ? "" : " • " + message);
        }
        if (condition == SourceCondition.CACHED) {
            return "Cached last-known data • source age " + ageLabel(ageMs)
                    + (message.isEmpty() ? "" : " • " + message);
        }
        return message;
    }

    public static String ageLabel(long ageMs) {
        if (ageMs == Long.MAX_VALUE) return "unknown";
        long seconds = Math.max(0L, ageMs / 1000L);
        if (seconds < 60L) return seconds + "s";
        long minutes = seconds / 60L;
        if (minutes < 60L) return minutes + "m";
        long hours = minutes / 60L;
        if (hours < 48L) return hours + "h";
        return hours / 24L + "d";
    }

    private static boolean isExpired(Signal signal, long hardAge, long nowMs) {
        if (hardAge == Long.MAX_VALUE || signal.timestampMs <= 0L) return false;
        // Keep modest future clock skew, but remove a record once its observation exceeds TTL.
        return nowMs - signal.timestampMs > hardAge;
    }

    private static String acquisitionToken(Signal signal) {
        boolean directory = signal.layer == Signal.Layer.WEBCAMS
                || signal.layer == Signal.Layer.RADIO
                || signal.layer == Signal.Layer.TV
                || signal.layer == Signal.Layer.MEDIA
                || signal.layer == Signal.Layer.INFRASTRUCTURE
                || signal.layer == Signal.Layer.SATELLITES;
        return directory ? signal.layer + ":" + signal.id
                : signal.layer + ":" + signal.id + "@" + signal.timestampMs;
    }

    private void trimSeen() {
        while (seenAcquisitions.size() > MAX_SEEN_ACQUISITIONS) {
            Iterator<String> iterator = seenAcquisitions.iterator();
            if (!iterator.hasNext()) return;
            iterator.next();
            iterator.remove();
        }
    }

    private static long freshAgeMs(Signal.Layer layer) {
        switch (layer) {
            case FLIGHTS: return 3L * 60L * 1000L;
            case SHIPS: return 2L * 60L * 1000L;
            case WEATHER: return 12L * 60L * 1000L;
            case AIRSPACE: return 15L * 60L * 1000L;
            case NATURAL:
            case NEWS: return 6L * 60L * 1000L;
            case SPACE_WEATHER: return 25L * 60L * 1000L;
            case SATELLITES: return 2L * 60L * 60L * 1000L + 15L * 60L * 1000L;
            case MARKETS: return 20L * 60L * 1000L;
            case WEBCAMS: return 20L * 60L * 1000L;
            case RADIO: return 45L * 60L * 1000L;
            case TV: return 13L * 60L * 60L * 1000L;
            case INFRASTRUCTURE:
            case MEDIA:
            default: return 26L * 60L * 60L * 1000L;
        }
    }

    private static long hardAgeMs(Signal.Layer layer) {
        switch (layer) {
            case FLIGHTS: return 25L * 60L * 1000L;
            case SHIPS: return 20L * 60L * 1000L;
            case NEWS: return 96L * 60L * 60L * 1000L;
            case AIRSPACE: return 12L * 60L * 60L * 1000L;
            case SATELLITES: return 14L * 24L * 60L * 60L * 1000L;
            case NATURAL: return 35L * 24L * 60L * 60L * 1000L;
            case SPACE_WEATHER: return 7L * 24L * 60L * 60L * 1000L;
            case MARKETS: return 2L * 24L * 60L * 60L * 1000L;
            case WEATHER:
            case INFRASTRUCTURE:
            case WEBCAMS:
            case RADIO:
            case TV:
            case MEDIA:
            default: return Long.MAX_VALUE;
        }
    }

    private static final class RawLayer {
        final List<Signal> signals;
        final FeedStatus status;

        RawLayer(List<Signal> signals, FeedStatus status) {
            this.signals = signals;
            this.status = status;
        }
    }
}
