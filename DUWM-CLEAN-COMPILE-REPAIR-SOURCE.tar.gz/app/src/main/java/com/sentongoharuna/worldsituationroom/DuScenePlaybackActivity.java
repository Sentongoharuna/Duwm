package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.os.*;import android.widget.*;import java.util.*;
public final class DuScenePlaybackActivity extends Activity{
 List<DuSceneStore.Scene> scenes;int i=0;Handler h=new Handler();LinearLayout r;TextView state;boolean playing=true;
 final Runnable next=new Runnable(){public void run(){if(!playing||scenes.isEmpty())return;show(i);i=(i+1)%scenes.size();h.postDelayed(this,scenes.get((i+scenes.size()-1)%scenes.size()).holdMs);}};
 public void onCreate(Bundle b){super.onCreate(b);scenes=DuSceneStore.load(this);r=Du2Ui.shell(this,"SCENE PLAYBACK");state=Du2Ui.t(this,"",10);r.addView(state);Button toggle=Du2Ui.button(this,"PLAY / PAUSE");toggle.setOnClickListener(v->{playing=!playing;if(playing)h.post(next);else h.removeCallbacks(next);});r.addView(toggle);setContentView(r);h.post(next);}
 void show(int n){DuSceneStore.Scene s=scenes.get(n);DuSpatialState.sensor(this,s.sensor);DuSelectionState.set(this,s.system,s.recordId,s.title);state.setText((n+1)+"/"+scenes.size()+" · "+s.name+"\n"+s.system+" · "+s.title+"\nSENSOR "+s.sensor+" · HOLD "+s.holdMs/1000+"s");}
 protected void onDestroy(){h.removeCallbacksAndMessages(null);super.onDestroy();}
}