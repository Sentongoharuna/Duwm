package com.sentongoharuna.worldsituationroom;
import android.content.*;import java.util.*;
public final class DuLiveCounts{
 final Context c;final DuLiveRepository repo;
 public DuLiveCounts(Context c){this.c=c.getApplicationContext();repo=new DuLiveRepository(this.c);}
 public int count(String s){if("MONITORS".equals(s))try{return new MonitorStore(c).reports().size();}catch(Exception e){return 0;}return repo.count(s);}
 public int events(){return count("EVENTS")+count("NEWS")+count("AIRWX");}
 public int media(){return count("CAM")+count("RADIO")+count("TV")+count("MONITORS");}
 public String line(){return "AIR "+count("AIR")+" · SEA "+count("SEA")+" · WX "+count("WX")+" · EVENTS "+events()+" · ORBIT "+count("ORBIT")+" · MONITORS "+count("MONITORS");}
 public Map<String,Integer> all(){LinkedHashMap<String,Integer>m=new LinkedHashMap<>();for(String s:new String[]{"AIR","SEA","WX","AIRWX","EVENTS","NEWS","ORBIT","INFRA","MARKETS","CAM","RADIO","TV","MONITORS"})m.put(s,count(s));return Collections.unmodifiableMap(m);}
}