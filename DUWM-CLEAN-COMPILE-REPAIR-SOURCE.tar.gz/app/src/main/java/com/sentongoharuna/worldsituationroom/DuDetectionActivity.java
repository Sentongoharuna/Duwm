package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.os.*;import android.widget.*;
public final class DuDetectionActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);LinearLayout r=Du2Ui.shell(this,"DETECTION HUD");r.addView(DuChronoNav.bar(this,"DETECTION","", ""));
  r.addView(Du2Ui.panel(this,"LIVE GLOBE DETECTION","● PROVIDER OBJECTS","Bounding boxes are projected from the same real AIR / SEA / ORBIT / EVENT / PUBLIC CAM coordinates drawn by the globe. Boxes move as the globe pans, zooms, rotates and provider fixes update."));
  r.addView(Du2Ui.panel(this,"STATE BANDS","● NORMAL  ● DEGRADED  ● CRITICAL","Box colour follows measured signal severity. The tracked object receives a larger box and TRACK LOCK label."));
  Button globe=Du2Ui.button(this,"OPEN LIVE DETECTION GLOBE");globe.setOnClickListener(v->DuPageRouter.open(this,"GLOBE"));r.addView(globe);
  r.addView(Du2Ui.panel(this,"PRIVACY","ASSET / EVENT DETECTION ONLY","No face recognition, person identification or named-person tracking is performed."));
  setContentView(r);
 }
}