package com.sentongoharuna.worldsituationroom;
import android.content.*;import java.util.*;
public final class DuSignalIntent{
 private DuSignalIntent(){}
 public static String system(Signal s){if(s==null)return"GLOBE";switch(s.layer){
  case FLIGHTS:return"AIR";case SHIPS:return"SEA";case WEATHER:return"WX";case AIRSPACE:return"AIRWX";
  case NATURAL:return"EVENTS";case NEWS:return"NEWS";case SATELLITES:return"ORBIT";case SPACE_WEATHER:return"EVENTS";
  case INFRASTRUCTURE:return"INFRA";case MARKETS:return"MARKETS";case WEBCAMS:return"CAM";case RADIO:return"RADIO";case TV:return"TV";case MEDIA:return"MONITORS";default:return"GLOBE";}}
 public static Intent detail(Context c,Signal s){
  String sys=system(s);DuSpatialState.select(c,sys,s.id,s.title);
  Intent i=new DuObjectPayload(sys,s.id,s.title,s.source,DuLiveRepository.place(s),String.valueOf(s.timestampMs)).put(new Intent(c,DuRecordDetailActivity.class));
  i.putExtra("source_url",s.sourceUrl);i.putExtra("summary",s.summary);i.putExtra("latitude",s.latitude);i.putExtra("longitude",s.longitude);i.putExtra("heading",s.heading);i.putExtra("speed_mps",s.speedMetersPerSecond);i.putExtra("severity",s.severity);i.putExtra("event_type",s.eventType);i.putExtra("region",s.region);
  return i;
 }
 public static Intent track(Context c,Signal s){Intent i=detail(c,s);i.setClass(c,DuTrackActivity.class);return i;}
}