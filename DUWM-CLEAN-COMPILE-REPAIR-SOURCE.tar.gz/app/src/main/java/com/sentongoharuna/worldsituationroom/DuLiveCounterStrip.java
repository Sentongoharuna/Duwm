package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.view.*;import android.widget.*;
public final class DuLiveCounterStrip{
 public static View make(Activity a){DuLiveCounts c=new DuLiveCounts(a);HorizontalScrollView h=new HorizontalScrollView(a);LinearLayout r=new LinearLayout(a);for(String s:new String[]{"AIR","SEA","WX","EVENTS","ORBIT","MONITORS"}){TextView v=Du2Ui.t(a,s+"\n"+("EVENTS".equals(s)?c.events():c.count(s)),9);v.setGravity(17);v.setTextColor(Du2Ui.C);v.setMinWidth(Du2Ui.dp(a,78));v.setContentDescription(s+" live count");r.addView(v,new LinearLayout.LayoutParams(Du2Ui.dp(a,82),Du2Ui.dp(a,48)));}h.addView(r);return h;}
}