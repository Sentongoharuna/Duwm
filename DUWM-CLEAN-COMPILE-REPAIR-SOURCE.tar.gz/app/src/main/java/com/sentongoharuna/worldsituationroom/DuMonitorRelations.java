package com.sentongoharuna.worldsituationroom;
import android.content.*;import java.util.*;
public final class DuMonitorRelations{
 public static List<MonitorReport> near(Context c,Signal a){List<MonitorReport> out=new ArrayList<>();if(a==null)return out;for(MonitorReport r:new MonitorStore(c).reports()){long dt=Math.abs(a.timestampMs-r.createdAtMs);boolean time=dt<=24L*60*60*1000L;boolean geo=false;if(a.hasLocation()&&Double.isFinite(r.latitude)&&Double.isFinite(r.longitude))geo=DuProximityEngine.distance(a.latitude,a.longitude,r.latitude,r.longitude)<=150;if(time&&geo)out.add(r);}Collections.sort(out,(x,y)->Long.compare(y.createdAtMs,x.createdAtMs));return out.subList(0,Math.min(8,out.size()));}
}