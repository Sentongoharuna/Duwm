package com.sentongoharuna.worldsituationroom;

import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * Small RFC 6455 client for the app's one optional WSS feed. It validates TLS hostnames and
 * the WebSocket accept challenge, masks all client frames, answers pings, bounds payloads and
 * supports fragmented text messages. No browser engine or third-party networking SDK is used.
 */
public final class NativeWebSocket {
    public interface Listener {
        void onOpen(NativeWebSocket socket);
        void onText(NativeWebSocket socket, String text);
        void onClosed(NativeWebSocket socket, int code, String reason);
        void onFailure(NativeWebSocket socket, Throwable error);
    }

    private static final String GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
    private static final long MAX_MESSAGE_BYTES = 16L * 1024L * 1024L;
    private final URI uri;
    private final String userAgent;
    private final Listener listener;
    private final SecureRandom random = new SecureRandom();
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Object writeLock = new Object();
    private volatile SSLSocket socket;
    private volatile OutputStream output;
    private volatile boolean cancelled;
    private volatile boolean opened;

    public NativeWebSocket(String url, String userAgent, Listener listener) {
        uri = URI.create(url);
        if (!"wss".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null) {
            throw new IllegalArgumentException("Only WSS endpoints are permitted");
        }
        this.userAgent = userAgent;
        this.listener = listener;
    }

    public void connect() {
        worker.execute(this::runConnection);
    }

    public boolean send(String text) {
        if (text == null || !opened || cancelled) return false;
        try {
            writeFrame(0x1, text.getBytes(StandardCharsets.UTF_8));
            return true;
        } catch (IOException error) {
            fail(error);
            return false;
        }
    }

    public void close(int code, String reason) {
        if (cancelled) return;
        String cleanReason = reason == null ? "" : reason;
        byte[] reasonBytes = cleanReason.getBytes(StandardCharsets.UTF_8);
        int reasonLength = Math.min(123, reasonBytes.length);
        byte[] payload = new byte[2 + reasonLength];
        payload[0] = (byte) ((code >>> 8) & 0xff);
        payload[1] = (byte) (code & 0xff);
        System.arraycopy(reasonBytes, 0, payload, 2, reasonLength);
        try {
            if (opened) writeFrame(0x8, payload);
        } catch (IOException ignored) {
            // The peer may already have closed the transport.
        }
        cancel();
    }

    public void cancel() {
        cancelled = true;
        opened = false;
        SSLSocket current = socket;
        socket = null;
        if (current != null) {
            try {
                current.close();
            } catch (IOException ignored) {
                // Closing a broken socket is best-effort.
            }
        }
        worker.shutdownNow();
    }

    private void runConnection() {
        try {
            int port = uri.getPort() > 0 ? uri.getPort() : 443;
            Socket transport = new Socket();
            transport.connect(new InetSocketAddress(uri.getHost(), port), 9_000);
            transport.setTcpNoDelay(true);
            SSLSocket tls = (SSLSocket) ((SSLSocketFactory) SSLSocketFactory.getDefault())
                    .createSocket(transport, uri.getHost(), port, true);
            tls.startHandshake();
            if (!HttpsURLConnection.getDefaultHostnameVerifier()
                    .verify(uri.getHost(), tls.getSession())) {
                throw new SSLPeerUnverifiedException("TLS hostname verification failed");
            }
            socket = tls;
            InputStream input = tls.getInputStream();
            output = tls.getOutputStream();
            performUpgrade(input);
            if (cancelled) return;
            opened = true;
            listener.onOpen(this);
            readFrames(input);
        } catch (Throwable error) {
            if (!cancelled) fail(error);
        } finally {
            opened = false;
            SSLSocket current = socket;
            socket = null;
            if (current != null) {
                try {
                    current.close();
                } catch (IOException ignored) {
                    // Best-effort transport cleanup.
                }
            }
            worker.shutdown();
        }
    }

    private void performUpgrade(InputStream input) throws Exception {
        byte[] nonce = new byte[16];
        random.nextBytes(nonce);
        String key = Base64.encodeToString(nonce, Base64.NO_WRAP);
        String path = uri.getRawPath();
        if (path == null || path.isEmpty()) path = "/";
        if (uri.getRawQuery() != null && !uri.getRawQuery().isEmpty()) {
            path += "?" + uri.getRawQuery();
        }
        String request = "GET " + path + " HTTP/1.1\r\n"
                + "Host: " + uri.getHost() + "\r\n"
                + "Upgrade: websocket\r\n"
                + "Connection: Upgrade\r\n"
                + "Sec-WebSocket-Key: " + key + "\r\n"
                + "Sec-WebSocket-Version: 13\r\n"
                + "User-Agent: " + userAgent + "\r\n\r\n";
        synchronized (writeLock) {
            output.write(request.getBytes(StandardCharsets.US_ASCII));
            output.flush();
        }
        String headers = readHttpHeaders(input);
        String[] lines = headers.split("\\r\\n");
        if (lines.length == 0 || !lines[0].matches("HTTP/1\\.[01] 101(?: .*)?")) {
            throw new IOException(lines.length == 0 ? "Empty WebSocket response"
                    : "WebSocket upgrade refused: " + lines[0]);
        }
        String accept = "";
        for (int index = 1; index < lines.length; index++) {
            int colon = lines[index].indexOf(':');
            if (colon <= 0) continue;
            if ("sec-websocket-accept".equals(lines[index].substring(0, colon)
                    .trim().toLowerCase(Locale.ROOT))) {
                accept = lines[index].substring(colon + 1).trim();
            }
        }
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        String expected = Base64.encodeToString(
                sha1.digest((key + GUID).getBytes(StandardCharsets.US_ASCII)), Base64.NO_WRAP);
        if (!expected.equals(accept)) throw new IOException("Invalid WebSocket accept challenge");
    }

    private static String readHttpHeaders(InputStream input) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        int matched = 0;
        while (bytes.size() < 16 * 1024) {
            int value = input.read();
            if (value < 0) throw new EOFException("Connection closed during WebSocket upgrade");
            bytes.write(value);
            if ((matched == 0 || matched == 2) && value == '\r') matched++;
            else if ((matched == 1 || matched == 3) && value == '\n') matched++;
            else matched = value == '\r' ? 1 : 0;
            if (matched == 4) return bytes.toString(StandardCharsets.US_ASCII.name());
        }
        throw new IOException("WebSocket response headers too large");
    }

    private void readFrames(InputStream input) throws IOException {
        ByteArrayOutputStream fragmented = null;
        int fragmentedOpcode = 0;
        while (!cancelled) {
            int first = input.read();
            if (first < 0) throw new EOFException("WebSocket transport ended");
            int second = readByte(input);
            boolean fin = (first & 0x80) != 0;
            int opcode = first & 0x0f;
            boolean masked = (second & 0x80) != 0;
            long length = second & 0x7f;
            if (length == 126) {
                length = ((long) readByte(input) << 8) | readByte(input);
            } else if (length == 127) {
                length = 0L;
                for (int index = 0; index < 8; index++) {
                    length = (length << 8) | readByte(input);
                }
            }
            if (length < 0L || length > MAX_MESSAGE_BYTES) {
                throw new IOException("WebSocket payload exceeds safety limit");
            }
            byte[] mask = masked ? readExactly(input, 4) : null;
            byte[] payload = readExactly(input, (int) length);
            if (mask != null) {
                for (int index = 0; index < payload.length; index++) {
                    payload[index] = (byte) (payload[index] ^ mask[index & 3]);
                }
            }
            if (opcode == 0x8) {
                int code = payload.length >= 2
                        ? ((payload[0] & 0xff) << 8) | (payload[1] & 0xff) : 1000;
                String reason = payload.length > 2
                        ? new String(payload, 2, payload.length - 2, StandardCharsets.UTF_8) : "";
                if (!cancelled) listener.onClosed(this, code, reason);
                return;
            }
            if (opcode == 0x9) {
                writeFrame(0xA, payload);
                continue;
            }
            if (opcode == 0xA) continue;
            if (opcode == 0x1 || opcode == 0x2) {
                if (fin) {
                    if (opcode == 0x1) listener.onText(this,
                            new String(payload, StandardCharsets.UTF_8));
                } else {
                    fragmentedOpcode = opcode;
                    fragmented = new ByteArrayOutputStream();
                    fragmented.write(payload);
                }
                continue;
            }
            if (opcode == 0x0 && fragmented != null) {
                if ((long) fragmented.size() + payload.length > MAX_MESSAGE_BYTES) {
                    throw new IOException("Fragmented WebSocket message exceeds safety limit");
                }
                fragmented.write(payload);
                if (fin) {
                    if (fragmentedOpcode == 0x1) listener.onText(this,
                            new String(fragmented.toByteArray(), StandardCharsets.UTF_8));
                    fragmented = null;
                    fragmentedOpcode = 0;
                }
            }
        }
    }

    private void writeFrame(int opcode, byte[] payload) throws IOException {
        OutputStream current = output;
        if (current == null) throw new IOException("WebSocket is not connected");
        if (payload.length > MAX_MESSAGE_BYTES) throw new IOException("Message too large");
        byte[] mask = new byte[4];
        random.nextBytes(mask);
        synchronized (writeLock) {
            current.write(0x80 | (opcode & 0x0f));
            int length = payload.length;
            if (length <= 125) {
                current.write(0x80 | length);
            } else if (length <= 0xffff) {
                current.write(0x80 | 126);
                current.write((length >>> 8) & 0xff);
                current.write(length & 0xff);
            } else {
                current.write(0x80 | 127);
                long longLength = length;
                for (int shift = 56; shift >= 0; shift -= 8) {
                    current.write((int) ((longLength >>> shift) & 0xffL));
                }
            }
            current.write(mask);
            for (int index = 0; index < payload.length; index++) {
                current.write(payload[index] ^ mask[index & 3]);
            }
            current.flush();
        }
    }

    private void fail(Throwable error) {
        if (cancelled) return;
        cancelled = true;
        opened = false;
        listener.onFailure(this, error);
        SSLSocket current = socket;
        if (current != null) {
            try {
                current.close();
            } catch (IOException ignored) {
                // Best-effort cleanup after failure.
            }
        }
        worker.shutdownNow();
    }

    private static int readByte(InputStream input) throws IOException {
        int value = input.read();
        if (value < 0) throw new EOFException("Unexpected WebSocket EOF");
        return value;
    }

    private static byte[] readExactly(InputStream input, int length) throws IOException {
        byte[] result = new byte[length];
        int offset = 0;
        while (offset < length) {
            int read = input.read(result, offset, length - offset);
            if (read < 0) throw new EOFException("Unexpected WebSocket EOF");
            offset += read;
        }
        return result;
    }
}
