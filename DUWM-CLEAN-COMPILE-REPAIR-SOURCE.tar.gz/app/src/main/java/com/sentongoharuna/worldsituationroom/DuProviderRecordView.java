package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.content.*;import android.view.*;import android.widget.*;import java.text.*;import java.util.*;
public final class DuProviderRecordView{
 public static View make(Activity a,Signal s){
  LinearLayout c=Du2Ui.panel(a,s.title,"● "+s.layer.name()+" · "+s.source,s.summary);if(s.layer==Signal.Layer.NEWS||s.layer==Signal.Layer.NATURAL||s.layer==Signal.Layer.MEDIA||s.layer==Signal.Layer.WEBCAMS)c.addView(DuRemoteImageCard.make(a,s));
  String speed=DuLiveRepository.num(s.speedMetersPerSecond," m/s");
  String heading=DuLiveRepository.num(s.heading,"°");
  c.addView(DuMetricRow.make(a,"HEADING",heading,"SPEED",speed,"SEVERITY",String.valueOf(s.severity)));
  TextView geo=Du2Ui.t(a,"PLACE  "+DuLiveRepository.place(s)+"\nTIME   "+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date(s.timestampMs))+"\nTYPE   "+s.eventType+" · "+s.credibility.name(),9);geo.setTextColor(Du2Ui.M);c.addView(geo);if(s.hasLocation()){DuMiniMapView mini=new DuMiniMapView(a,s.id);mini.setPosition(s.latitude,s.longitude);c.addView(mini,new LinearLayout.LayoutParams(-1,Du2Ui.dp(a,130)));}
  LinearLayout facts=new LinearLayout(a);facts.setOrientation(LinearLayout.VERTICAL);int n=0;
  for(Map.Entry<String,String> f:s.facts.entrySet()){if(n++>=6)break;TextView x=Du2Ui.t(a,f.getKey().toUpperCase(Locale.ROOT)+"  "+f.getValue(),9);x.setTextColor(Du2Ui.C);facts.addView(x);}c.addView(facts);
  Button d=Du2Ui.button(a,"OPEN EXACT RECORD");d.setOnClickListener(v->{DuSpatialState.select(a,s.layer.name(),s.id,s.title);Intent i=new DuObjectPayload(s.layer.name(),s.id,s.title,s.source,DuLiveRepository.place(s),String.valueOf(s.timestampMs)).put(new Intent(a,DuRecordDetailActivity.class));i.putExtra("source_url",s.sourceUrl);i.putExtra("summary",s.summary);i.putExtra("latitude",s.latitude);i.putExtra("longitude",s.longitude);i.putExtra("heading",s.heading);i.putExtra("speed_mps",s.speedMetersPerSecond);a.startActivity(i);});c.addView(d);
  return c;
 }
}