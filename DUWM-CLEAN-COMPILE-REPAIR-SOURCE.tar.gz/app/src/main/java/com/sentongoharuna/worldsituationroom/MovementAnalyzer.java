package com.sentongoharuna.worldsituationroom;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Bounded on-device movement-pattern observer. It reports only what recent provider fixes
 * support and never calls a pattern a confirmed diversion, hostile act or military identity.
 */
public final class MovementAnalyzer {
    public static final class Watch {
        public final String kind;
        public final String detail;
        public final int severity;
        public final Signal signal;
        public final long observedAtMs;

        Watch(String kind, String detail, int severity, Signal signal, long observedAtMs) {
            this.kind = kind;
            this.detail = detail;
            this.severity = severity;
            this.signal = signal;
            this.observedAtMs = observedAtMs;
        }
    }

    private static final long HISTORY_MS = 45L * 60L * 1000L;
    private static final int MAX_TRACKS = 4_000;
    private final Map<String, Deque<Point>> tracks = new HashMap<>();
    private List<Watch> watches = Collections.emptyList();

    public synchronized void ingest(Signal.Layer layer, List<Signal> values, long nowMs) {
        if (layer != Signal.Layer.FLIGHTS && layer != Signal.Layer.SHIPS) return;
        List<Watch> detected = new ArrayList<>();
        for (Signal signal : values) {
            if (!signal.hasLocation() || signal.timestampMs <= 0L) continue;
            Deque<Point> track = tracks.get(signal.id);
            if (track == null) {
                if (tracks.size() >= MAX_TRACKS) removeOldestTrack();
                track = new ArrayDeque<>();
                tracks.put(signal.id, track);
            }
            Point last = track.peekLast();
            if (last == null || last.timestampMs != signal.timestampMs) {
                track.addLast(new Point(signal));
            }
            while (!track.isEmpty() && nowMs - track.peekFirst().timestampMs > HISTORY_MS) {
                track.removeFirst();
            }
            if (layer == Signal.Layer.FLIGHTS) detectAircraft(signal, track, detected, nowMs);
            else detectVessel(signal, track, detected, nowMs);
        }
        prune(nowMs);
        Collections.sort(detected, (first, second) -> {
            int severity = Integer.compare(second.severity, first.severity);
            return severity != 0 ? severity
                    : Long.compare(second.observedAtMs, first.observedAtMs);
        });
        if (detected.size() > 40) detected = new ArrayList<>(detected.subList(0, 40));
        watches = Collections.unmodifiableList(detected);
    }

    public synchronized List<Watch> snapshot() {
        return watches;
    }

    private static void detectAircraft(Signal signal, Deque<Point> track,
                                       List<Watch> result, long nowMs) {
        String squawk = value(signal, "SQUAWK");
        if ("7500".equals(squawk) || "7600".equals(squawk) || "7700".equals(squawk)) {
            result.add(new Watch("EMERGENCY SQUAWK OBSERVED",
                    "Provider reports transponder code " + squawk
                            + ". Treat as raw telemetry and verify with an authoritative source.",
                    5, signal, nowMs));
        }
        double verticalRate = number(value(signal, "VERTICAL RATE"));
        if (!Double.isNaN(verticalRate) && verticalRate <= -18d) {
            result.add(new Watch("RAPID DESCENT RATE",
                    String.format(Locale.US,
                            "Provider-reported vertical rate %.1f m/s. Aircraft type, phase of flight and intent are unknown.",
                            verticalRate), 4, signal, nowMs));
        }
        String callsign = value(signal, "CALLSIGN").toUpperCase(Locale.ROOT);
        if (callsign.matches("^(RCH|REACH|CNV|FORTE|NATO|LAGR|QID|DUKE|EVAC).*")) {
            result.add(new Watch("SPECIAL-USE CALLSIGN PATTERN",
                    "The public callsign matches a commonly observed state/special-use pattern. "
                            + "This does not confirm operator, mission or military status.",
                    2, signal, nowMs));
        }
        if (track.size() >= 4) {
            double turn = accumulatedTurn(track);
            Point first = track.peekFirst();
            Point last = track.peekLast();
            double displacement = SatelliteMapView.distanceKm(first.latitude, first.longitude,
                    last.latitude, last.longitude);
            long duration = last.timestampMs - first.timestampMs;
            if (duration >= 4L * 60L * 1000L && turn >= 250d && displacement <= 45d) {
                result.add(new Watch("POSSIBLE HOLDING / LOITER PATTERN",
                        String.format(Locale.US,
                                "Recent fixes accumulated %.0f° of course change while net displacement stayed near %.0f km. This is an observed pattern, not a confirmed diversion.",
                                turn, displacement), 3, signal, nowMs));
            }
        }
    }

    private static void detectVessel(Signal signal, Deque<Point> track,
                                     List<Watch> result, long nowMs) {
        if (track.size() >= 3) {
            Point first = track.peekFirst();
            Point last = track.peekLast();
            long duration = last.timestampMs - first.timestampMs;
            double displacement = SatelliteMapView.distanceKm(first.latitude, first.longitude,
                    last.latitude, last.longitude);
            if (duration >= 15L * 60L * 1000L
                    && !Double.isNaN(signal.speedMetersPerSecond)
                    && signal.speedMetersPerSecond <= 0.35d && displacement <= 2d) {
                result.add(new Watch("PROLONGED LOW-SPEED VESSEL",
                        "Recent AIS fixes show little movement. The vessel may be anchored, berthed, "
                                + "waiting or experiencing ordinary traffic; this is not an incident claim.",
                        2, signal, nowMs));
            }
            if (duration <= 30L * 60L * 1000L && accumulatedTurn(track) >= 120d
                    && !Double.isNaN(signal.speedMetersPerSecond)
                    && signal.speedMetersPerSecond >= 2.5d) {
                result.add(new Watch("ABRUPT COURSE CHANGE OBSERVED",
                        "AIS course changes crossed the transparent threshold inside 30 minutes. "
                                + "Route, traffic, weather and navigational intent are unknown.",
                        3, signal, nowMs));
            }
        }
    }

    private static double accumulatedTurn(Deque<Point> track) {
        double total = 0d;
        Point previous = null;
        for (Point point : track) {
            if (previous != null && !Double.isNaN(previous.heading)
                    && !Double.isNaN(point.heading)) {
                double difference = Math.abs(point.heading - previous.heading) % 360d;
                total += Math.min(difference, 360d - difference);
            }
            previous = point;
        }
        return total;
    }

    private void prune(long nowMs) {
        List<String> stale = new ArrayList<>();
        for (Map.Entry<String, Deque<Point>> entry : tracks.entrySet()) {
            Deque<Point> track = entry.getValue();
            while (!track.isEmpty() && nowMs - track.peekFirst().timestampMs > HISTORY_MS) {
                track.removeFirst();
            }
            if (track.isEmpty()) stale.add(entry.getKey());
        }
        for (String key : stale) tracks.remove(key);
    }

    private void removeOldestTrack() {
        String oldestKey = null;
        long oldest = Long.MAX_VALUE;
        for (Map.Entry<String, Deque<Point>> entry : tracks.entrySet()) {
            Point point = entry.getValue().peekLast();
            if (point != null && point.timestampMs < oldest) {
                oldest = point.timestampMs;
                oldestKey = entry.getKey();
            }
        }
        if (oldestKey != null) tracks.remove(oldestKey);
    }

    private static String value(Signal signal, String key) {
        String value = signal.facts.get(key);
        return value == null ? "" : value.trim();
    }

    private static double number(String value) {
        if (value == null) return Double.NaN;
        String clean = value.replaceAll("[^0-9+.-]", "");
        try {
            return clean.isEmpty() ? Double.NaN : Double.parseDouble(clean);
        } catch (NumberFormatException ignored) {
            return Double.NaN;
        }
    }

    private static final class Point {
        final double latitude;
        final double longitude;
        final double heading;
        final long timestampMs;

        Point(Signal signal) {
            latitude = signal.latitude;
            longitude = signal.longitude;
            heading = signal.heading;
            timestampMs = signal.timestampMs;
        }
    }
}
