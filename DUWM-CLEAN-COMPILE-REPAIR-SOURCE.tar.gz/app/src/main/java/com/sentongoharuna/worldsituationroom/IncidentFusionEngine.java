package com.sentongoharuna.worldsituationroom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Deterministic cross-layer scene builder. A scene is an analyst lead, never proof that
 * nearby aircraft, vessels or orbital objects caused, joined or confirmed an event.
 */
public final class IncidentFusionEngine {
    private IncidentFusionEngine() { }

    public static final class Scene {
        public final Signal anchor;
        public final int nearbyAircraft;
        public final int nearbyVessels;
        public final int nearbyOrbitalObjects;
        public final int nearbyWarnings;
        public final int relatedReports;
        public final int independentSources;
        public final int observedScore;
        public final String sourceNames;
        public final String label;

        Scene(Signal anchor, int nearbyAircraft, int nearbyVessels,
              int nearbyOrbitalObjects, int nearbyWarnings, int relatedReports,
              int independentSources, int observedScore, String sourceNames,
              String label) {
            this.anchor = anchor;
            this.nearbyAircraft = nearbyAircraft;
            this.nearbyVessels = nearbyVessels;
            this.nearbyOrbitalObjects = nearbyOrbitalObjects;
            this.nearbyWarnings = nearbyWarnings;
            this.relatedReports = relatedReports;
            this.independentSources = independentSources;
            this.observedScore = observedScore;
            this.sourceNames = sourceNames;
            this.label = label;
        }
    }

    public static List<Scene> build(
            EnumMap<Signal.Layer, List<Signal>> layers,
            long nowMs) {
        if (layers == null) return Collections.emptyList();
        List<Signal> anchors = new ArrayList<>();
        addAnchors(anchors, layers.get(Signal.Layer.NATURAL), nowMs);
        addAnchors(anchors, layers.get(Signal.Layer.NEWS), nowMs);
        Collections.sort(anchors, (first, second) -> first.timestampMs == second.timestampMs
                ? 0 : first.timestampMs < second.timestampMs ? 1 : -1);
        if (anchors.size() > 90) anchors = new ArrayList<>(anchors.subList(0, 90));

        List<Scene> scenes = new ArrayList<>();
        for (Signal anchor : anchors) {
            if (!anchor.hasLocation()) continue;
            int aircraft = nearbyCurrent(anchor, layers.get(Signal.Layer.FLIGHTS),
                    500d, nowMs, 25L * 60L * 1000L);
            int vessels = nearbyCurrent(anchor, layers.get(Signal.Layer.SHIPS),
                    300d, nowMs, 45L * 60L * 1000L);
            int orbital = nearbyCurrent(anchor, layers.get(Signal.Layer.SATELLITES),
                    900d, nowMs, 3L * 60L * 1000L);
            int warnings = nearbyCurrent(anchor, layers.get(Signal.Layer.AIRSPACE),
                    650d, nowMs, 6L * 60L * 60L * 1000L);
            Set<String> sources = new LinkedHashSet<>();
            sources.add(anchor.source);
            int reports = 0;
            for (Signal candidate : allEventSignals(layers)) {
                if (candidate == anchor || !candidate.hasLocation()) continue;
                if (Math.abs(candidate.timestampMs - anchor.timestampMs)
                        > 12L * 60L * 60L * 1000L) continue;
                if (SatelliteMapView.distanceKm(anchor.latitude, anchor.longitude,
                        candidate.latitude, candidate.longitude) > 320d) continue;
                reports++;
                sources.add(candidate.source);
            }
            int score = Math.min(99, anchor.severity * 11
                    + Math.min(24, reports * 6)
                    + Math.min(14, aircraft * 2)
                    + Math.min(12, vessels * 3)
                    + Math.min(10, orbital)
                    + Math.min(10, warnings * 3)
                    + Math.min(12, Math.max(0, sources.size() - 1) * 4));
            String label = sources.size() >= 2 || reports >= 1
                    ? "MULTI-SOURCE WATCH" : "SINGLE-SOURCE WATCH";
            scenes.add(new Scene(anchor, aircraft, vessels, orbital, warnings,
                    reports, sources.size(), score, joinSources(sources), label));
        }
        Collections.sort(scenes, (first, second) -> {
            if (first.observedScore != second.observedScore) {
                return second.observedScore - first.observedScore;
            }
            return first.anchor.timestampMs == second.anchor.timestampMs ? 0
                    : first.anchor.timestampMs < second.anchor.timestampMs ? 1 : -1;
        });
        if (scenes.size() > 60) return new ArrayList<>(scenes.subList(0, 60));
        return scenes;
    }

    private static void addAnchors(List<Signal> output, List<Signal> values, long nowMs) {
        if (values == null) return;
        for (Signal signal : values) {
            if (signal == null || !signal.hasLocation() || signal.timestampMs <= 0L) continue;
            long age = Math.max(0L, nowMs - signal.timestampMs);
            if (age > 72L * 60L * 60L * 1000L) continue;
            if (signal.severity >= 3 || signal.layer == Signal.Layer.NATURAL) {
                output.add(signal);
            }
        }
    }

    private static int nearbyCurrent(Signal anchor, List<Signal> values,
                                     double radiusKm, long nowMs, long freshnessMs) {
        if (values == null) return 0;
        int count = 0;
        for (Signal signal : values) {
            if (signal == null || !signal.hasLocation()) continue;
            if (signal.timestampMs <= 0L || nowMs - signal.timestampMs > freshnessMs) continue;
            if (SatelliteMapView.distanceKm(anchor.latitude, anchor.longitude,
                    signal.latitude, signal.longitude) <= radiusKm) count++;
        }
        return count;
    }

    private static List<Signal> allEventSignals(
            EnumMap<Signal.Layer, List<Signal>> layers) {
        List<Signal> result = new ArrayList<>();
        List<Signal> natural = layers.get(Signal.Layer.NATURAL);
        List<Signal> news = layers.get(Signal.Layer.NEWS);
        if (natural != null) result.addAll(natural);
        if (news != null) result.addAll(news);
        return result;
    }

    private static String joinSources(Set<String> sources) {
        StringBuilder result = new StringBuilder();
        int count = 0;
        for (String source : sources) {
            if (source == null || source.trim().isEmpty()) continue;
            if (result.length() > 0) result.append(" • ");
            result.append(source.trim());
            if (++count >= 5) break;
        }
        return result.length() == 0 ? "Source not reported" : result.toString();
    }
}
