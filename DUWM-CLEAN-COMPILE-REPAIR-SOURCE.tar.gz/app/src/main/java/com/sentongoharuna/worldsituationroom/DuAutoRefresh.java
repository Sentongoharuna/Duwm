package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.os.*;
public final class DuAutoRefresh{
 final Activity a;final String system;final Handler h=new Handler(Looper.getMainLooper());boolean active;
 final Runnable tick=new Runnable(){public void run(){if(!active)return;DuProviderRefresh.request(a,system);h.postDelayed(this,5*60*1000L);}};
 public DuAutoRefresh(Activity a,String s){this.a=a;system=s;}
 public void start(){active=true;h.removeCallbacks(tick);h.postDelayed(tick,5*60*1000L);}
 public void stop(){active=false;h.removeCallbacks(tick);}
}