package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.view.*;import android.widget.*;
public final class DuChartsPanel{
 public static View make(Activity a,String system){LinearLayout c=Du2Ui.panel(a,"LIVE TRENDS","● SOURCE HISTORY","Charts use locally observed provider callback history; no synthetic points.");String key="COUNT:"+(DuLiveRepository.layer(system)==null?system:DuLiveRepository.layer(system).name());DuSparklineView s=new DuSparklineView(a);s.setData(system+" PROVIDER RECORD COUNT",DuTrendStore.values(a,key));c.addView(s,new LinearLayout.LayoutParams(-1,Du2Ui.dp(a,150)));return c;}
}