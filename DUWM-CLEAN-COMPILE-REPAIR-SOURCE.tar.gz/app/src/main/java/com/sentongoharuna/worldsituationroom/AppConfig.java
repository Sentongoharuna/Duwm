package com.sentongoharuna.worldsituationroom;

/**
 * All providers and refresh budgets live in one native configuration file.
 * API credentials are never compiled here; users enter optional keys in Settings.
 */
public final class AppConfig {
    private AppConfig() {}

    public static final String USER_AGENT =
            "DuWorldMoniterAndroid/24.0 (com.sentongoharuna.worldsituationroom)";

    // Keyless live providers.
    // extended=1 asks OpenSky for its provider-reported aircraft emitter category.
    public static final String OPENSKY_STATES =
            "https://opensky-network.org/api/states/all?extended=1";
    public static final String OPENSKY_TOKEN =
            "https://auth.opensky-network.org/auth/realms/opensky-network/protocol/openid-connect/token";
    public static final String RAINVIEWER = "https://api.rainviewer.com/public/weather-maps.json";
    public static final String USGS =
            "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson";
    public static final String EONET =
            "https://eonet.gsfc.nasa.gov/api/v3/events?status=open&limit=120&days=30";
    public static final String NOAA_SPACE_WEATHER_ALERTS =
            "https://services.swpc.noaa.gov/products/alerts.json";
    public static final String NOAA_PLANETARY_K_INDEX =
            "https://services.swpc.noaa.gov/products/noaa-planetary-k-index.json";
    // Official worldwide SIGMET/airspace weather advisories. The app plots a representative
    // point and links back to the source; it never substitutes for operational briefing data.
    public static final String AVIATION_SIGMETS =
            "https://aviationweather.gov/api/data/airsigmet?format=json";
    // CelesTrak public GP/OMM element groups. Positions shown in the app are calculated from
    // these elements rather than claimed as live telemetry. Provider guidance asks clients to
    // cache data and avoid polling more frequently than once every two hours.
    public static final String CELESTRAK_STATIONS =
            "https://celestrak.org/NORAD/elements/gp.php?GROUP=STATIONS&FORMAT=JSON";
    public static final String CELESTRAK_WEATHER =
            "https://celestrak.org/NORAD/elements/gp.php?GROUP=WEATHER&FORMAT=JSON";
    public static final String CELESTRAK_GPS =
            "https://celestrak.org/NORAD/elements/gp.php?GROUP=GPS-OPS&FORMAT=JSON";
    public static final String GDELT =
            "https://api.gdeltproject.org/api/v2/doc/doc?query=(conflict%20OR%20protest%20OR%20earthquake%20OR%20wildfire%20OR%20flood%20OR%20storm)%20sourcelang:english&mode=artlist&maxrecords=100&format=json&sort=datedesc";
    // The GKG is a bulk 15-minute metadata firehose. R21 downloads only the current archive,
    // parses it off the UI thread and keeps a bounded set of relevant theme signals.
    public static final String GDELT_LAST_UPDATE =
            "https://data.gdeltproject.org/gdeltv2/lastupdate.txt";
    public static final String NOMINATIM =
            "https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=1&q=";
    public static final String RADIO_BROWSER_DNS = "all.api.radio-browser.info";
    public static final String RADIO_BROWSER_PATH =
            "/json/stations/search?hidebroken=true&limit=500&order=clickcount&reverse=true";
    public static final String RADIO_BROWSER_FALLBACK =
            "https://de1.api.radio-browser.info";
    // Community-maintained public television index. R18 filters blocked, closed, NSFW,
    // cleartext and metadata-less records before exposing a stream to the native player.
    public static final String IPTV_CHANNELS = "https://iptv-org.github.io/api/channels.json";
    public static final String IPTV_STREAMS = "https://iptv-org.github.io/api/streams.json";
    public static final String IPTV_BLOCKLIST = "https://iptv-org.github.io/api/blocklist.json";
    // Nightly public-domain aviation reference data. It is deliberately staged well after
    // launch and cached for a day; it is context, not live airport operational status.
    public static final String OURAIRPORTS_AIRPORTS =
            "https://davidmegginson.github.io/ourairports-data/airports.csv";
    public static final String OURAIRPORTS_RUNWAYS =
            "https://davidmegginson.github.io/ourairports-data/runways.csv";
    public static final String OURAIRPORTS_FREQUENCIES =
            "https://davidmegginson.github.io/ourairports-data/airport-frequencies.csv";
    // Reference-rate and crypto sources. Values are visibly labelled as reference quotes,
    // never as executable trading prices or financial advice.
    public static final String FRANKFURTER_RATES =
            "https://api.frankfurter.app/latest?from=USD&to=EUR,GBP,JPY,CNY,CHF,ZAR,KES,UGX,AUD,CAD";
    public static final String COINGECKO_SIMPLE =
            "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana&vs_currencies=usd&include_24hr_change=true&include_last_updated_at=true";

    // Keyed providers. Keys are stored locally through SecurePrefs, not in source.
    public static final String AIS_STREAM = "wss://stream.aisstream.io/v0/stream";
    public static final String WINDY_WEBCAMS =
            "https://api.windy.com/webcams/api/v3/webcams";
    // Windy's free listing currently permits offsets through 1,000. R18 walks every
    // permitted 100-item page, de-duplicates it and labels the result as provider-limited.
    public static final int WINDY_WEBCAM_PAGE_SIZE = 100;
    public static final int WINDY_WEBCAM_MAX_OFFSET = 1_000;

    // Native raster map. Tiles are cached locally and always carry attribution in the UI.
    public static final String SATELLITE_TILES =
            "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/%d/%d/%d";
    public static final String DARK_FALLBACK_TILES =
            "https://a.basemaps.cartocdn.com/dark_all/%d/%d/%d.png";
    // Transparent road/place labels are drawn over satellite imagery at detailed zooms.
    public static final String LABEL_TILES =
            "https://a.basemaps.cartocdn.com/dark_only_labels/%d/%d/%d.png";

    // OpenSky charges fewer credits for a small bounding box. Global refreshes therefore
    // remain conservative while the detailed satellite viewport can update more often.
    public static final long FLIGHTS_GLOBAL_ANONYMOUS_MS = 15L * 60L * 1000L;
    public static final long FLIGHTS_SECTOR_ANONYMOUS_MS = 4L * 60L * 1000L;
    public static final long FLIGHTS_GLOBAL_AUTHENTICATED_MS = 2L * 60L * 1000L;
    public static final long FLIGHTS_SECTOR_AUTHENTICATED_MS = 30L * 1000L;
    public static final long WEATHER_MS = 5L * 60L * 1000L;
    public static final long AIRSPACE_MS = 10L * 60L * 1000L;
    public static final long NATURAL_EVENTS_MS = 2L * 60L * 1000L;
    public static final long NEWS_MS = 90L * 1000L;
    public static final long GKG_MS = 15L * 60L * 1000L;
    public static final long SPACE_WEATHER_MS = 15L * 60L * 1000L;
    public static final long ORBITAL_ELEMENTS_MS = 2L * 60L * 60L * 1000L;
    public static final long ORBITAL_PROPAGATION_MS = 15L * 1000L;
    public static final long RSS_MS = 5L * 60L * 1000L;
    public static final long WEBCAMS_MS = 10L * 60L * 1000L;
    public static final long RADIO_MS = 30L * 60L * 1000L;
    public static final long TV_MS = 12L * 60L * 60L * 1000L;
    public static final long INFRASTRUCTURE_MS = 24L * 60L * 60L * 1000L;
    public static final long MARKETS_MS = 10L * 60L * 1000L;

    // Only openly available feeds are enabled by default. More can be added in Settings.
    public static final String[] DEFAULT_RSS = {
            "https://feeds.bbci.co.uk/news/world/rss.xml",
            "https://www.aljazeera.com/xml/rss/all.xml"
    };
}
