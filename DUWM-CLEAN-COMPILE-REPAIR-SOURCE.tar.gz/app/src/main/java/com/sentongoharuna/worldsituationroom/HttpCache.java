package com.sentongoharuna.worldsituationroom;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.GZIPInputStream;

import javax.net.ssl.HttpsURLConnection;

/** HTTPS client with per-feed last-good caching and no external networking dependency. */
public final class HttpCache {
    public static final class Result {
        public final String body;
        public final boolean fromCache;

        Result(String body, boolean fromCache) {
            this.body = body;
            this.fromCache = fromCache;
        }
    }

    public static final class BytesResult {
        public final byte[] bytes;
        public final boolean fromCache;

        BytesResult(byte[] bytes, boolean fromCache) {
            this.bytes = bytes;
            this.fromCache = fromCache;
        }
    }

    // A failed free-tier feed must not look like a frozen application. Last-good cache is
    // preferred after these bounded waits and every provider remains independently retryable.
    private static final int CONNECT_TIMEOUT_MS = 5_000;
    private static final int READ_TIMEOUT_MS = 8_000;
    private static final int MAX_REDIRECTS = 4;
    private static final long MAX_RESPONSE_BYTES = 64L * 1024L * 1024L;
    private static final long BACKOFF_BASE_MS = 15_000L;
    private static final long BACKOFF_MAX_MS = 10L * 60L * 1000L;
    private final File directory;
    private final Map<String, FailureState> failures = new ConcurrentHashMap<>();

    public HttpCache(Context context) {
        directory = new File(context.getApplicationContext().getCacheDir(), "feed-cache-v5");
        if (!directory.exists()) directory.mkdirs();
    }

    /** Returns a last-good response immediately without touching the network. */
    public Result peek(String cacheKey, long maxStaleMs) {
        File cacheFile = fileFor(cacheKey);
        if (!cacheFile.isFile()
                || System.currentTimeMillis() - cacheFile.lastModified() > maxStaleMs) {
            return null;
        }
        try {
            return new Result(readUtf8(cacheFile), true);
        } catch (IOException ignored) {
            return null;
        }
    }

    /** Timestamp of a provider cache entry, or zero when no last-good response exists. */
    public long cacheUpdatedAtMs(String cacheKey) {
        File cacheFile = fileFor(cacheKey);
        return cacheFile.isFile() ? cacheFile.lastModified() : 0L;
    }

    public Result get(String url, String cacheKey, long maxStaleMs) throws IOException {
        return get(url, Collections.emptyMap(), cacheKey, maxStaleMs);
    }

    public Result get(String url, Map<String, String> headers,
                      String cacheKey, long maxStaleMs) throws IOException {
        File cacheFile = fileFor(cacheKey);
        long backoff = backoffRemainingMs(cacheKey);
        if (backoff > 0L) {
            if (cacheFile.isFile()
                    && System.currentTimeMillis() - cacheFile.lastModified() <= maxStaleMs) {
                return new Result(readUtf8(cacheFile), true);
            }
            throw new IOException("Provider retry backoff active for "
                    + Math.max(1L, backoff / 1000L) + "s");
        }
        IOException failure;
        try {
            String body = request(url, "GET", headers, null);
            writeAtomically(cacheFile, body);
            markSuccess(cacheKey);
            return new Result(body, false);
        } catch (IOException error) {
            failure = error;
            markFailure(cacheKey);
        }
        if (cacheFile.isFile()
                && System.currentTimeMillis() - cacheFile.lastModified() <= maxStaleMs) {
            return new Result(readUtf8(cacheFile), true);
        }
        throw failure;
    }

    /** Binary equivalent used for bounded ZIP feeds such as the current GDELT GKG file. */
    public BytesResult getBytes(String url, String cacheKey, long maxStaleMs,
                                long maximumBytes) throws IOException {
        String failureKey = cacheKey + "_binary";
        File cacheFile = fileFor(failureKey);
        long backoff = backoffRemainingMs(failureKey);
        if (backoff > 0L) {
            if (cacheFile.isFile()
                    && System.currentTimeMillis() - cacheFile.lastModified() <= maxStaleMs) {
                try (FileInputStream input = new FileInputStream(cacheFile)) {
                    return new BytesResult(readBounded(input, maximumBytes), true);
                }
            }
            throw new IOException("Provider retry backoff active for "
                    + Math.max(1L, backoff / 1000L) + "s");
        }
        IOException failure;
        try {
            byte[] bytes = requestBytes(url, "GET", Collections.emptyMap(), null,
                    Math.min(MAX_RESPONSE_BYTES, Math.max(1L, maximumBytes)));
            writeAtomically(cacheFile, bytes);
            markSuccess(failureKey);
            return new BytesResult(bytes, false);
        } catch (IOException error) {
            failure = error;
            markFailure(failureKey);
        }
        if (cacheFile.isFile()
                && System.currentTimeMillis() - cacheFile.lastModified() <= maxStaleMs) {
            try (FileInputStream input = new FileInputStream(cacheFile)) {
                return new BytesResult(readBounded(input, maximumBytes), true);
            }
        }
        throw failure;
    }

    /** Small provider bookkeeping request that must never be represented as cached data. */
    public String getUncached(String url) throws IOException {
        return request(url, "GET", Collections.emptyMap(), null);
    }

    public String postOpenSkyToken(String clientId, String clientSecret) throws IOException {
        String body = "grant_type=client_credentials&client_id="
                + formEncode(clientId) + "&client_secret=" + formEncode(clientSecret);
        return request(AppConfig.OPENSKY_TOKEN, "POST",
                Collections.singletonMap("Content-Type",
                        "application/x-www-form-urlencoded; charset=utf-8"),
                body.getBytes(StandardCharsets.UTF_8));
    }

    /** Remaining provider-specific exponential retry delay, useful for source diagnostics. */
    public long backoffRemainingMs(String cacheKey) {
        FailureState state = failures.get(cacheKey);
        return state == null ? 0L
                : Math.max(0L, state.nextAttemptMs - System.currentTimeMillis());
    }

    private void markSuccess(String cacheKey) {
        failures.remove(cacheKey);
    }

    private synchronized void markFailure(String cacheKey) {
        FailureState previous = failures.get(cacheKey);
        int attempts = previous == null ? 1 : Math.min(7, previous.attempts + 1);
        long multiplier = 1L << Math.min(5, attempts - 1);
        long delay = Math.min(BACKOFF_MAX_MS, BACKOFF_BASE_MS * multiplier);
        // Stable, small jitter keeps providers from receiving synchronized retries.
        delay += Math.floorMod(cacheKey.hashCode(), 3_001);
        failures.put(cacheKey,
                new FailureState(attempts, System.currentTimeMillis() + delay));
    }

    private static String request(String startUrl, String method,
                                  Map<String, String> headers, byte[] requestBody)
            throws IOException {
        byte[] bytes = requestBytes(startUrl, method, headers, requestBody,
                MAX_RESPONSE_BYTES);
        return new String(stripUtf8Bom(bytes), StandardCharsets.UTF_8);
    }

    private static byte[] requestBytes(String startUrl, String method,
                                       Map<String, String> headers, byte[] requestBody,
                                       long maximumBytes) throws IOException {
        URL current = new URL(startUrl);
        for (int redirect = 0; redirect <= MAX_REDIRECTS; redirect++) {
            if (!"https".equalsIgnoreCase(current.getProtocol())) {
                throw new IOException("Only HTTPS feeds are permitted");
            }
            HttpsURLConnection connection = (HttpsURLConnection) current.openConnection();
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);
            connection.setRequestMethod(method);
            connection.setRequestProperty("User-Agent", AppConfig.USER_AGENT);
            connection.setRequestProperty("Accept",
                    "application/json, application/geo+json, application/xml, text/xml, */*");
            connection.setRequestProperty("Accept-Encoding", "gzip");
            for (Map.Entry<String, String> header : headers.entrySet()) {
                connection.setRequestProperty(header.getKey(), header.getValue());
            }
            if (requestBody != null) {
                connection.setDoOutput(true);
                connection.setFixedLengthStreamingMode(requestBody.length);
                try (OutputStream output = connection.getOutputStream()) {
                    output.write(requestBody);
                }
            }
            int code;
            try {
                code = connection.getResponseCode();
            } catch (IOException error) {
                connection.disconnect();
                throw error;
            }
            if (code >= 300 && code < 400) {
                String location = connection.getHeaderField("Location");
                connection.disconnect();
                if (location == null || location.trim().isEmpty()) {
                    throw new IOException("HTTP " + code + " without redirect target");
                }
                current = new URL(current, location);
                // RFC 7231: common 301/302/303 redirects after a form POST become GET.
                if (code == 303 || ((code == 301 || code == 302) && "POST".equals(method))) {
                    method = "GET";
                    requestBody = null;
                }
                continue;
            }
            if (code < 200 || code >= 300) {
                connection.disconnect();
                throw new IOException("HTTP " + code);
            }
            String contentEncoding = connection.getContentEncoding();
            byte[] bytes;
            try (InputStream raw = connection.getInputStream();
                 InputStream input = "gzip".equalsIgnoreCase(contentEncoding)
                         ? new GZIPInputStream(raw) : raw) {
                bytes = readBounded(input, maximumBytes);
            } finally {
                connection.disconnect();
            }
            return bytes;
        }
        throw new IOException("Too many HTTPS redirects");
    }

    private static Charset charsetFrom(String contentType) {
        if (contentType != null) {
            for (String part : contentType.split(";")) {
                String clean = part.trim();
                if (clean.toLowerCase(Locale.ROOT).startsWith("charset=")) {
                    try {
                        return Charset.forName(clean.substring("charset=".length()).trim()
                                .replace("\"", ""));
                    } catch (Exception ignored) {
                        // Fall through to the modern feed default.
                    }
                }
            }
        }
        return StandardCharsets.UTF_8;
    }

    private static byte[] stripUtf8Bom(byte[] value) {
        if (value.length >= 3 && value[0] == (byte) 0xef
                && value[1] == (byte) 0xbb && value[2] == (byte) 0xbf) {
            byte[] clean = new byte[value.length - 3];
            System.arraycopy(value, 3, clean, 0, clean.length);
            return clean;
        }
        return value;
    }

    private static byte[] readBounded(InputStream input, long maximum) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[16 * 1024];
        long total = 0L;
        int read;
        while ((read = input.read(buffer)) != -1) {
            total += read;
            if (total > maximum) throw new IOException("Feed response exceeds safety limit");
            output.write(buffer, 0, read);
        }
        return output.toByteArray();
    }

    private File fileFor(String cacheKey) {
        String safe = cacheKey.replaceAll("[^A-Za-z0-9._-]", "_");
        return new File(directory, safe + ".cache");
    }

    private static void writeAtomically(File target, String body) throws IOException {
        writeAtomically(target, body.getBytes(StandardCharsets.UTF_8));
    }

    private static void writeAtomically(File target, byte[] bytes) throws IOException {
        File temporary = new File(target.getParentFile(), target.getName() + ".tmp");
        try (FileOutputStream output = new FileOutputStream(temporary)) {
            output.write(bytes);
            output.flush();
        }
        if (target.exists() && !target.delete()) {
            throw new IOException("Unable to replace response cache");
        }
        if (!temporary.renameTo(target)) throw new IOException("Unable to commit response cache");
    }

    private static String readUtf8(File source) throws IOException {
        try (FileInputStream input = new FileInputStream(source)) {
            return new String(readBounded(input, MAX_RESPONSE_BYTES), StandardCharsets.UTF_8);
        }
    }

    private static String formEncode(String value) throws IOException {
        try {
            return URLEncoder.encode(value == null ? "" : value, "UTF-8");
        } catch (Exception error) {
            throw new IOException("Unable to encode authorization form", error);
        }
    }

    private static final class FailureState {
        final int attempts;
        final long nextAttemptMs;

        FailureState(int attempts, long nextAttemptMs) {
            this.attempts = attempts;
            this.nextAttemptMs = nextAttemptMs;
        }
    }
}
