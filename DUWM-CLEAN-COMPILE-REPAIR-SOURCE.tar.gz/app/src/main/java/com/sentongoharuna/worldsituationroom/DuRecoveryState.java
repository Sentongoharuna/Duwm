package com.sentongoharuna.worldsituationroom;
import android.content.*;
public final class DuRecoveryState{
 static final String P="duwm_recovery_v1";
 public static void fail(Context c,String area,String reason){c.getSharedPreferences(P,0).edit().putString(area+":state","RECOVERING").putString(area+":reason",trim(reason)).putLong(area+":time",System.currentTimeMillis()).apply();}
 public static void ok(Context c,String area){c.getSharedPreferences(P,0).edit().putString(area+":state","READY").putString(area+":reason","").putLong(area+":time",System.currentTimeMillis()).apply();}
 public static String state(Context c,String area){return c.getSharedPreferences(P,0).getString(area+":state","UNKNOWN");}
 public static String reason(Context c,String area){return c.getSharedPreferences(P,0).getString(area+":reason","");}
 static String trim(String s){if(s==null)return"Unknown failure";s=s.replaceAll("[\\r\\n]+"," ").trim();return s.length()>120?s.substring(0,120):s;}
}