package com.sentongoharuna.worldsituationroom;
import android.content.*;import android.view.*;
public final class DuGestureCoordinator{
 public enum Owner{NONE,GLOBE,SHEET,PAGE,EDGE_BACK}
 final float edge,slop;Owner owner=Owner.NONE;float downX,downY;
 public DuGestureCoordinator(Context c){float d=c.getResources().getDisplayMetrics().density;edge=24*d;slop=8*d;}
 public void down(MotionEvent e,int width){downX=e.getX();downY=e.getY();owner=downX<=edge||downX>=width-edge?Owner.EDGE_BACK:Owner.NONE;}
 public Owner move(MotionEvent e,boolean sheetHandle,boolean globeSurface){if(owner==Owner.EDGE_BACK)return owner;float dx=e.getX()-downX,dy=e.getY()-downY;if(owner==Owner.NONE&&Math.hypot(dx,dy)>=slop){if(sheetHandle&&Math.abs(dy)>Math.abs(dx))owner=Owner.SHEET;else if(globeSurface)owner=Owner.GLOBE;else if(Math.abs(dx)>Math.abs(dy)*1.35)owner=Owner.PAGE;}return owner;}
 public void release(){owner=Owner.NONE;}public Owner owner(){return owner;}
}