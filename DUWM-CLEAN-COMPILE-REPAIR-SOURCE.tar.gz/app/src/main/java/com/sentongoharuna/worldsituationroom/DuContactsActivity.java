package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.os.*;import android.content.*;import android.widget.*;import java.util.*;
public final class DuContactsActivity extends Activity{
 DuObjectPayload payload;DuLiveRepository repo;LinearLayout list;double radius=250;
 public void onCreate(Bundle b){super.onCreate(b);payload=DuObjectPayload.from(getIntent());repo=new DuLiveRepository(this);LinearLayout r=Du2Ui.shell(this,"CONTACTS / "+payload.system);r.addView(DuChronoNav.bar(this,"CONTACTS","", ""));
  LinearLayout range=new LinearLayout(this);for(String q:new String[]{"50 KM","250 KM","1000 KM"}){Button x=Du2Ui.button(this,q);x.setOnClickListener(v->{radius=Double.parseDouble(q.split(" ")[0]);render();});range.addView(x,new LinearLayout.LayoutParams(0,48,1));}r.addView(range);
  ScrollView sc=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);sc.addView(list);r.addView(sc,new LinearLayout.LayoutParams(-1,0,1));render();setContentView(r);
 }
 void render(){list.removeAllViews();Signal anchor=repo.find(payload.system,payload.id);if(anchor==null){list.addView(Du2Ui.panel(this,"TARGET NOT IN CURRENT SNAPSHOT","● WAITING",payload.id+" is not present in the retained provider snapshot. No position is guessed."));return;}
  List<Signal> pool=new ArrayList<>();for(String s:new String[]{"AIR","SEA","ORBIT","EVENTS","AIRWX","INFRA","CAM"})pool.addAll(repo.signals(s));
  List<DuProximityEngine.Contact> found=DuProximityEngine.nearby(anchor,pool,radius,40);
  list.addView(Du2Ui.panel(this,"NEAR "+anchor.title,"● "+found.size()+" CONTACTS","Radius "+String.format(Locale.US,"%.0f km",radius)+" · distance and bearing calculated from provider coordinates."));
  for(DuProximityEngine.Contact c:found){Signal s=c.signal;LinearLayout card=Du2Ui.panel(this,s.title,"● "+s.layer.name()+" · "+s.source,String.format(Locale.US,"%.1f km · %.0f° %s · %s",c.distanceKm,c.bearingDeg,DuProximityEngine.compass(c.bearingDeg),DuLiveRepository.place(s)));
   LinearLayout a=new LinearLayout(this);Button d=Du2Ui.button(this,"DETAIL");d.setOnClickListener(v->startActivity(DuSignalIntent.detail(this,s)));Button t=Du2Ui.button(this,"TRACK");t.setOnClickListener(v->startActivity(DuSignalIntent.track(this,s)));a.addView(d,new LinearLayout.LayoutParams(0,50,1));a.addView(t,new LinearLayout.LayoutParams(0,50,1));card.addView(a);list.addView(card);}
  if(found.isEmpty())list.addView(Du2Ui.panel(this,"NO NEARBY CONTACTS","SOURCE-BOUND","No current provider object falls inside this radius. Increase range or wait for provider updates."));
 }
 protected void onResume(){super.onResume();if(list!=null)render();}
}