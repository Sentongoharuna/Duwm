package com.sentongoharuna.worldsituationroom;

import java.util.Locale;
import java.util.TimeZone;

/**
 * Selects a useful opening region from the device timezone without asking for GPS, a
 * location permission, an account, or a network lookup. The result is intentionally broad:
 * it is a map lens, never a claim about the user's precise location.
 */
public final class RegionalFocus {
    public final String name;
    public final String worldRegion;
    public final double latitude;
    public final double longitude;
    public final String timezoneId;

    private RegionalFocus(
            String name,
            String worldRegion,
            double latitude,
            double longitude,
            String timezoneId) {
        this.name = name;
        this.worldRegion = worldRegion;
        this.latitude = latitude;
        this.longitude = longitude;
        this.timezoneId = timezoneId;
    }

    public static RegionalFocus detect() {
        TimeZone zone = TimeZone.getDefault();
        String id = zone == null ? "UTC" : zone.getID();
        String key = id.toLowerCase(Locale.ROOT);

        if (containsAny(key, "kampala", "nairobi", "addis_ababa", "dar_es_salaam",
                "mogadishu", "djibouti", "asmara", "khartoum", "juba")) {
            return focus("EAST AFRICA", "AFRICA", 1.3d, 35.0d, id);
        }
        if (containsAny(key, "lagos", "accra", "abidjan", "dakar", "freetown",
                "monrovia", "banjul", "bamako", "ouagadougou", "niamey")) {
            return focus("WEST AFRICA", "AFRICA", 8.0d, -1.5d, id);
        }
        if (containsAny(key, "johannesburg", "maputo", "lusaka", "harare", "gaborone",
                "windhoek", "maseru", "mbabane", "blantyre")) {
            return focus("SOUTHERN AFRICA", "AFRICA", -23.0d, 27.0d, id);
        }
        if (containsAny(key, "cairo", "tripoli", "tunis", "algiers", "casablanca",
                "el_aaiun")) {
            return focus("NORTH AFRICA", "AFRICA", 28.0d, 15.0d, id);
        }
        if (key.startsWith("africa/")) {
            return focus("AFRICA", "AFRICA", 7.0d, 21.0d, id);
        }

        if (containsAny(key, "riyadh", "dubai", "muscat", "qatar", "bahrain", "kuwait",
                "baghdad", "tehran", "amman", "beirut", "jerusalem", "gaza",
                "damascus", "aden")) {
            return focus("MIDDLE EAST", "MIDDLE EAST", 28.0d, 45.0d, id);
        }
        if (containsAny(key, "kolkata", "karachi", "dhaka", "kathmandu", "colombo",
                "thimphu", "maldives")) {
            return focus("SOUTH ASIA", "ASIA", 23.0d, 79.0d, id);
        }
        if (containsAny(key, "bangkok", "jakarta", "singapore", "kuala_lumpur", "manila",
                "ho_chi_minh", "phnom_penh", "vientiane", "yangon", "brunei",
                "dili")) {
            return focus("SOUTHEAST ASIA", "ASIA", 9.0d, 110.0d, id);
        }
        if (containsAny(key, "tokyo", "seoul", "shanghai", "hong_kong", "taipei",
                "ulaanbaatar", "chongqing", "macau")) {
            return focus("EAST ASIA", "ASIA", 36.0d, 112.0d, id);
        }
        if (containsAny(key, "almaty", "tashkent", "bishkek", "dushanbe", "ashgabat",
                "yerevan", "baku", "tbilisi")) {
            return focus("CENTRAL ASIA", "ASIA", 42.0d, 67.0d, id);
        }
        if (key.startsWith("asia/")) {
            return focus("ASIA", "ASIA", 34.0d, 89.0d, id);
        }

        if (key.startsWith("europe/") || containsAny(key, "london", "dublin", "lisbon")) {
            return focus("EUROPE", "EUROPE", 51.0d, 15.0d, id);
        }
        if (containsAny(key, "new_york", "chicago", "denver", "los_angeles", "anchorage",
                "halifax", "toronto", "vancouver", "winnipeg", "edmonton", "phoenix")) {
            return focus("NORTH AMERICA", "AMERICAS", 43.0d, -101.0d, id);
        }
        if (containsAny(key, "mexico", "guatemala", "belize", "costa_rica", "panama",
                "el_salvador", "managua", "tegucigalpa", "havana", "jamaica",
                "puerto_rico", "santo_domingo")) {
            return focus("CENTRAL AMERICA", "AMERICAS", 17.0d, -87.0d, id);
        }
        if (containsAny(key, "sao_paulo", "buenos_aires", "lima", "bogota", "caracas",
                "santiago", "montevideo", "asuncion", "la_paz", "guyana", "paramaribo")) {
            return focus("SOUTH AMERICA", "AMERICAS", -16.0d, -60.0d, id);
        }
        if (key.startsWith("america/")) {
            return focus("AMERICAS", "AMERICAS", 15.0d, -83.0d, id);
        }

        if (key.startsWith("australia/") || containsAny(key, "auckland", "fiji", "guam",
                "port_moresby", "noumea", "tahiti", "honolulu", "apia", "tongatapu")) {
            return focus("OCEANIA", "OCEANIA", -23.0d, 143.0d, id);
        }

        int offsetHours = zone == null ? 0 : zone.getOffset(System.currentTimeMillis()) / 3_600_000;
        if (offsetHours >= 8) return focus("ASIA–PACIFIC", "ASIA", 20.0d, 120.0d, id);
        if (offsetHours >= 4) return focus("WESTERN ASIA", "ASIA", 27.0d, 62.0d, id);
        if (offsetHours >= 1) return focus("EUROPE–AFRICA", "GLOBAL", 34.0d, 18.0d, id);
        if (offsetHours <= -8) return focus("PACIFIC AMERICAS", "AMERICAS", 37.0d, -122.0d, id);
        if (offsetHours <= -3) return focus("AMERICAS", "AMERICAS", 12.0d, -75.0d, id);
        return focus("GLOBAL", "GLOBAL", 12.0d, 18.0d, id);
    }

    private static RegionalFocus focus(
            String name,
            String region,
            double latitude,
            double longitude,
            String timezoneId) {
        return new RegionalFocus(name, region, latitude, longitude, timezoneId);
    }

    private static boolean containsAny(String value, String... fragments) {
        for (String fragment : fragments) {
            if (value.contains(fragment)) return true;
        }
        return false;
    }
}
