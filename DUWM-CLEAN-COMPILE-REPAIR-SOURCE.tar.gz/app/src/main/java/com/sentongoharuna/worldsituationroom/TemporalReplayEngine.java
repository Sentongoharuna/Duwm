package com.sentongoharuna.worldsituationroom;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Bounded in-memory 4D timeline made only from records the app actually received.
 * No missing position is interpolated and no historical point is manufactured.
 */
public final class TemporalReplayEngine {
    public static final long WINDOW_MS = 60L * 60L * 1000L;
    private static final long MIN_FRAME_INTERVAL_MS = 10_000L;
    private static final int MAX_FRAMES = 360;
    private final Deque<Frame> frames = new ArrayDeque<>();

    public static final class Snapshot {
        public final long capturedAtMs;
        public final List<Signal> signals;

        Snapshot(long capturedAtMs, List<Signal> signals) {
            this.capturedAtMs = capturedAtMs;
            this.signals = signals;
        }
    }

    private static final class Frame {
        final long capturedAtMs;
        final List<Signal> signals;

        Frame(long capturedAtMs, List<Signal> signals) {
            this.capturedAtMs = capturedAtMs;
            this.signals = signals;
        }
    }

    public synchronized void capture(
            EnumMap<Signal.Layer, List<Signal>> current,
            long nowMs) {
        if (current == null) return;
        List<Signal> selected = new ArrayList<>();
        for (Signal.Layer layer : Signal.Layer.values()) {
            if (!isTemporalLayer(layer)) continue;
            appendSample(selected, current.get(layer), cap(layer));
        }
        if (selected.isEmpty()) return;
        Frame last = frames.peekLast();
        if (last != null && nowMs - last.capturedAtMs < MIN_FRAME_INTERVAL_MS) {
            // Startup feeds arrive in quick succession. Replace the partial frame so the first
            // replay point represents the most complete state reached in that ten-second slot.
            frames.removeLast();
        }
        frames.addLast(new Frame(nowMs,
                Collections.unmodifiableList(new ArrayList<>(selected))));
        while (!frames.isEmpty()
                && nowMs - frames.peekFirst().capturedAtMs > WINDOW_MS) {
            frames.removeFirst();
        }
        while (frames.size() > MAX_FRAMES) frames.removeFirst();
    }

    public synchronized Snapshot snapshotAt(long requestedMs) {
        if (frames.isEmpty()) {
            return new Snapshot(requestedMs, Collections.emptyList());
        }
        Frame selected = frames.peekFirst();
        for (Frame frame : frames) {
            if (frame.capturedAtMs > requestedMs) break;
            selected = frame;
        }
        return new Snapshot(selected.capturedAtMs, selected.signals);
    }

    public synchronized long oldestMs() {
        Frame frame = frames.peekFirst();
        return frame == null ? 0L : frame.capturedAtMs;
    }

    public synchronized long newestMs() {
        Frame frame = frames.peekLast();
        return frame == null ? 0L : frame.capturedAtMs;
    }

    public synchronized int frameCount() {
        return frames.size();
    }

    public static boolean isTemporalLayer(Signal.Layer layer) {
        return layer == Signal.Layer.FLIGHTS
                || layer == Signal.Layer.SHIPS
                || layer == Signal.Layer.AIRSPACE
                || layer == Signal.Layer.NATURAL
                || layer == Signal.Layer.NEWS
                || layer == Signal.Layer.SATELLITES
                || layer == Signal.Layer.SPACE_WEATHER;
    }

    private static void appendSample(List<Signal> output, List<Signal> values, int limit) {
        if (values == null || values.isEmpty() || limit <= 0) return;
        if (values.size() <= limit) {
            for (Signal signal : values) {
                if (signal != null && signal.hasLocation()) output.add(signal);
            }
            return;
        }
        Set<String> added = new HashSet<>();
        int stride = Math.max(1, (values.size() + limit - 1) / limit);
        for (int index = 0; index < values.size() && output.size() < 4_000; index += stride) {
            Signal signal = values.get(index);
            if (signal != null && signal.hasLocation() && added.add(signal.id)) {
                output.add(signal);
                if (added.size() >= limit) break;
            }
        }
    }

    private static int cap(Signal.Layer layer) {
        switch (layer) {
            case FLIGHTS: return 700;
            case SHIPS: return 420;
            case SATELLITES: return 240;
            case AIRSPACE: return 180;
            case NATURAL: return 180;
            case NEWS: return 180;
            case SPACE_WEATHER: return 40;
            default: return 0;
        }
    }
}
