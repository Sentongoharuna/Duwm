package com.sentongoharuna.worldsituationroom;
import android.content.*;import org.json.*;import java.util.*;
public final class DuTrackHistoryStore{
 private static final String P="duwm_track_history_v1";private static final int MAX=32;
 public static final class Fix{public final double lat,lon;public final long time;Fix(double a,double o,long t){lat=a;lon=o;time=t;}}
 public static synchronized void ingest(Context c,List<Signal> values){
  if(values==null)return;android.content.SharedPreferences p=c.getSharedPreferences(P,0);android.content.SharedPreferences.Editor e=p.edit();
  for(Signal s:values){if(s==null||!s.hasLocation()||(s.layer!=Signal.Layer.FLIGHTS&&s.layer!=Signal.Layer.SHIPS&&s.layer!=Signal.Layer.SATELLITES))continue;
   try{JSONArray a=new JSONArray(p.getString(s.id,"[]"));JSONObject last=a.length()>0?a.optJSONObject(a.length()-1):null;
    if(last==null||s.timestampMs>last.optLong("t")||s.latitude!=last.optDouble("a")||s.longitude!=last.optDouble("o")){
     JSONObject x=new JSONObject();x.put("a",s.latitude);x.put("o",s.longitude);x.put("t",s.timestampMs);a.put(x);
     JSONArray b=new JSONArray();for(int i=Math.max(0,a.length()-MAX);i<a.length();i++)b.put(a.get(i));e.putString(s.id,b.toString());
    }
   }catch(Exception ignored){}
  }e.apply();
 }
 public static List<Fix> load(Context c,String id){List<Fix> out=new ArrayList<>();try{JSONArray a=new JSONArray(c.getSharedPreferences(P,0).getString(id,"[]"));for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);out.add(new Fix(x.getDouble("a"),x.getDouble("o"),x.getLong("t")));}}catch(Exception ignored){}return out;}
}