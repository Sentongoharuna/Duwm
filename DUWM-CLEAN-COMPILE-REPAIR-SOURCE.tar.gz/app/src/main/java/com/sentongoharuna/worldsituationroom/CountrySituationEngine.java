package com.sentongoharuna.worldsituationroom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Transparent country-lens scoring. Scores describe the density of recent records inside a
 * coarse geographic envelope; they are not a forecast, official travel advice or a political
 * judgement. The method is intentionally deterministic and runs fully on the phone.
 */
public final class CountrySituationEngine {
    private static final long HOUR = 60L * 60L * 1000L;

    public static final class CountryState {
        public final String iso;
        public final String name;
        public final String region;
        public final double latitude;
        public final double longitude;
        public final int score;
        public final String level;
        public final int eventRecords;
        public final int priorityRecords;
        public final int aircraft;
        public final int vessels;
        public final int sourceCount;
        public final int recentSixHours;
        public final int previousSixHours;

        CountryState(Country country, int score, String level, int eventRecords,
                     int priorityRecords, int aircraft, int vessels, int sourceCount,
                     int recentSixHours, int previousSixHours) {
            iso = country.iso;
            name = country.name;
            region = country.region;
            latitude = country.latitude;
            longitude = country.longitude;
            this.score = score;
            this.level = level;
            this.eventRecords = eventRecords;
            this.priorityRecords = priorityRecords;
            this.aircraft = aircraft;
            this.vessels = vessels;
            this.sourceCount = sourceCount;
            this.recentSixHours = recentSixHours;
            this.previousSixHours = previousSixHours;
        }

        public int movement() {
            return recentSixHours - previousSixHours;
        }
    }

    private static final Country[] COUNTRIES = {
            country("UG", "Uganda", "AFRICA", -1.6, 29.5, 4.4, 35.1),
            country("KE", "Kenya", "AFRICA", -4.9, 33.8, 5.2, 41.9),
            country("TZ", "Tanzania", "AFRICA", -11.8, 29.2, -0.8, 40.7),
            country("CD", "DR Congo", "AFRICA", -13.6, 12.2, 5.5, 31.5),
            country("SD", "Sudan", "AFRICA", 8.6, 21.8, 22.3, 38.7),
            country("SS", "South Sudan", "AFRICA", 3.4, 23.4, 12.3, 35.9),
            country("ET", "Ethiopia", "AFRICA", 3.3, 32.8, 14.9, 48.1),
            country("SO", "Somalia", "AFRICA", -1.8, 40.9, 12.2, 51.7),
            country("NG", "Nigeria", "AFRICA", 4.2, 2.6, 13.9, 14.7),
            country("ZA", "South Africa", "AFRICA", -35.0, 16.0, -22.0, 33.2),
            country("EG", "Egypt", "AFRICA", 21.7, 24.6, 31.8, 36.9),
            country("LY", "Libya", "AFRICA", 19.3, 9.2, 33.3, 25.2),
            country("IL", "Israel / Palestinian Territories", "MIDDLE EAST", 29.3, 34.1, 33.5, 35.9),
            country("LB", "Lebanon", "MIDDLE EAST", 33.0, 35.0, 34.8, 36.7),
            country("SY", "Syria", "MIDDLE EAST", 32.2, 35.6, 37.4, 42.4),
            country("IQ", "Iraq", "MIDDLE EAST", 28.8, 38.7, 37.4, 48.9),
            country("IR", "Iran", "MIDDLE EAST", 24.3, 44.0, 40.0, 63.4),
            country("YE", "Yemen", "MIDDLE EAST", 12.0, 42.4, 19.1, 54.7),
            country("UA", "Ukraine", "EUROPE", 44.2, 22.0, 52.5, 40.3),
            country("RU", "Russia", "EUROPE", 41.0, 19.0, 82.0, 180.0),
            country("TR", "Türkiye", "EUROPE", 35.7, 25.6, 42.3, 44.9),
            country("PK", "Pakistan", "ASIA", 23.5, 60.8, 37.1, 77.9),
            country("AF", "Afghanistan", "ASIA", 29.0, 60.5, 38.6, 74.9),
            country("IN", "India", "ASIA", 6.4, 68.0, 35.7, 97.5),
            country("CN", "China", "ASIA", 18.0, 73.5, 53.6, 134.8),
            country("TW", "Taiwan", "ASIA", 21.8, 119.2, 25.4, 122.1),
            country("KP", "North Korea", "ASIA", 37.6, 124.0, 43.1, 130.8),
            country("MM", "Myanmar", "ASIA", 9.5, 92.0, 28.6, 101.3),
            country("US", "United States", "AMERICAS", 24.0, -125.0, 49.7, -66.0),
            country("MX", "Mexico", "AMERICAS", 14.3, -118.5, 32.8, -86.5),
            country("VE", "Venezuela", "AMERICAS", 0.5, -73.6, 12.5, -59.5),
            country("BR", "Brazil", "AMERICAS", -34.0, -74.0, 5.5, -34.0),
            country("HT", "Haiti", "AMERICAS", 18.0, -74.6, 20.1, -71.6),
            country("AU", "Australia", "OCEANIA", -44.0, 112.0, -10.0, 154.0)
    };

    private CountrySituationEngine() {}

    public static List<CountryState> analyze(Map<Signal.Layer, List<Signal>> layers,
                                             long nowMs) {
        List<Signal> events = new ArrayList<>();
        add(events, layers.get(Signal.Layer.NEWS));
        add(events, layers.get(Signal.Layer.NATURAL));
        add(events, layers.get(Signal.Layer.SPACE_WEATHER));
        List<Signal> aircraft = safe(layers.get(Signal.Layer.FLIGHTS));
        List<Signal> vessels = safe(layers.get(Signal.Layer.SHIPS));
        List<CountryState> result = new ArrayList<>();
        for (Country country : COUNTRIES) {
            int records = 0;
            int priority = 0;
            int recent = 0;
            int previous = 0;
            double weight = 0d;
            Set<String> sources = new LinkedHashSet<>();
            for (Signal signal : events) {
                if (!signal.hasLocation() || !country.contains(signal.latitude, signal.longitude)) {
                    continue;
                }
                long age = Math.max(0L, nowMs - signal.timestampMs);
                if (age > 72L * HOUR) continue;
                records++;
                if (signal.severity >= 4) priority++;
                if (age <= 6L * HOUR) recent++;
                else if (age <= 12L * HOUR) previous++;
                sources.add(normalizeSource(signal.source));
                double credibility = signal.credibility == Signal.Credibility.CONFIRMED ? 1d
                        : signal.credibility == Signal.Credibility.REPORTED ? 0.76d : 0.45d;
                double decay = Math.max(0.12d, 1d - age / (72d * HOUR));
                weight += signal.severity * credibility * decay;
            }
            int air = countRecent(aircraft, country, nowMs, 20L * 60L * 1000L);
            int sea = countRecent(vessels, country, nowMs, 60L * 60L * 1000L);
            int score = Math.min(99, (int) Math.round(weight * 4.2d
                    + Math.min(10, priority * 2) + Math.min(8, sources.size())));
            String level = score >= 70 ? "HIGH OBSERVED PRESSURE"
                    : score >= 45 ? "ELEVATED"
                    : score >= 20 ? "WATCH" : "BASELINE";
            result.add(new CountryState(country, score, level, records, priority,
                    air, sea, sources.size(), recent, previous));
        }
        Collections.sort(result, (first, second) -> {
            int score = Integer.compare(second.score, first.score);
            return score != 0 ? score : first.name.compareTo(second.name);
        });
        return result;
    }

    private static int countRecent(List<Signal> values, Country country,
                                   long nowMs, long windowMs) {
        int count = 0;
        for (Signal signal : values) {
            if (!signal.hasLocation() || nowMs - signal.timestampMs > windowMs) continue;
            if (country.contains(signal.latitude, signal.longitude)) count++;
        }
        return count;
    }

    private static void add(List<Signal> target, List<Signal> source) {
        if (source != null) target.addAll(source);
    }

    private static List<Signal> safe(List<Signal> source) {
        return source == null ? Collections.emptyList() : source;
    }

    private static String normalizeSource(String value) {
        String clean = value == null ? "unknown" : value.trim().toLowerCase(Locale.ROOT);
        int via = clean.indexOf(" via ");
        return via > 0 ? clean.substring(0, via) : clean;
    }

    private static Country country(String iso, String name, String region,
                                   double south, double west, double north, double east) {
        return new Country(iso, name, region, south, west, north, east);
    }

    private static final class Country {
        final String iso;
        final String name;
        final String region;
        final double south;
        final double west;
        final double north;
        final double east;
        final double latitude;
        final double longitude;

        Country(String iso, String name, String region,
                double south, double west, double north, double east) {
            this.iso = iso;
            this.name = name;
            this.region = region;
            this.south = south;
            this.west = west;
            this.north = north;
            this.east = east;
            latitude = (south + north) / 2d;
            longitude = (west + east) / 2d;
        }

        boolean contains(double latitude, double longitude) {
            if (latitude < south || latitude > north) return false;
            return west <= east ? longitude >= west && longitude <= east
                    : longitude >= west || longitude <= east;
        }
    }
}
