package com.sentongoharuna.worldsituationroom;
import android.content.*;import java.util.*;
public final class DuLiveRepository{
 private final OperationsSnapshotStore store; private final Context context;
 public DuLiveRepository(Context c){context=c.getApplicationContext();store=new OperationsSnapshotStore(context);}
 public static Signal.Layer layer(String s){String k=s==null?"":s.toUpperCase(Locale.ROOT);
  if(k.equals("AIR")||k.equals("AIRCRAFT")||k.equals("FLIGHTS"))return Signal.Layer.FLIGHTS;
  if(k.equals("SEA")||k.equals("SHIPS"))return Signal.Layer.SHIPS;
  if(k.equals("WX")||k.equals("WEATHER"))return Signal.Layer.WEATHER;
  if(k.equals("AIRWX")||k.equals("AIRSPACE"))return Signal.Layer.AIRSPACE;
  if(k.equals("EVENTS")||k.equals("RISK"))return Signal.Layer.NATURAL;
  if(k.equals("NEWS")||k.equals("WIRE"))return Signal.Layer.NEWS;
  if(k.equals("ORBIT")||k.equals("ORBITS"))return Signal.Layer.SATELLITES;
  if(k.equals("INFRA"))return Signal.Layer.INFRASTRUCTURE;
  if(k.equals("MARKETS"))return Signal.Layer.MARKETS;
  if(k.equals("CAM")||k.equals("CAMERAS"))return Signal.Layer.WEBCAMS;
  if(k.equals("RADIO"))return Signal.Layer.RADIO;if(k.equals("TV"))return Signal.Layer.TV;
  return null;
 }
 public OperationsSnapshotStore.Snapshot snapshot(String system){Signal.Layer l=layer(system);return l==null?null:store.loadAll().get(l);}
 public List<Signal> signals(String system){OperationsSnapshotStore.Snapshot s=snapshot(system);return s==null?Collections.emptyList():DuRecoveryGuard.valid(context,"PROVIDER:"+system,s.signals);}
 public Signal find(String system,String id){if(id==null)return null;for(Signal s:signals(system))if(id.equals(s.id))return s;return null;}
 public int count(String system){OperationsSnapshotStore.Snapshot s=snapshot(system);return s==null?0:s.status.count;}
 public String status(String system){OperationsSnapshotStore.Snapshot s=snapshot(system);return s==null?"NO SNAPSHOT":s.status.state.name();}
 public String age(String system){OperationsSnapshotStore.Snapshot s=snapshot(system);if(s==null)return"UNKNOWN";long m=Math.max(0,(System.currentTimeMillis()-s.savedAtMs)/60000);return m<1?"NOW":m+"m";}
 public static String num(double v,String suffix){return Double.isNaN(v)||Double.isInfinite(v)?"—":String.format(Locale.US,"%.1f%s",v,suffix);}
 public static String place(Signal s){return s==null?"—":s.region+(s.hasLocation()?String.format(Locale.US," · %.4f, %.4f",s.latitude,s.longitude):"");}
 public static String fact(Signal s,String key){if(s==null)return"—";String v=s.facts.get(key);return v==null||v.trim().isEmpty()?"—":v;}
}