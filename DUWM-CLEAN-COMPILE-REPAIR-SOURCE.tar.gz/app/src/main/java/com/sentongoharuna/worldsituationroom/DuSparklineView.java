package com.sentongoharuna.worldsituationroom;
import android.content.*;import android.graphics.*;import android.view.*;import java.util.*;
public final class DuSparklineView extends View{
 final Paint p=new Paint(1);double[] values=new double[0];String label="TREND";
 public DuSparklineView(Context c){super(c);setMinimumHeight(dp(130));}
 public void setData(String l,double[]v){label=l==null?"TREND":l;values=v==null?new double[0]:Arrays.copyOf(v,Math.min(v.length,96));invalidate();}
 protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight();c.drawColor(Color.rgb(5,12,17));p.setTextSize(dp(9));p.setColor(Color.LTGRAY);c.drawText(label,dp(8),dp(16),p);if(values.length<2){c.drawText("INSUFFICIENT SOURCE HISTORY",dp(8),h/2f,p);return;}double lo=values[0],hi=values[0];for(double v:values){lo=Math.min(lo,v);hi=Math.max(hi,v);}if(hi==lo)hi=lo+1;p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2));p.setColor(Color.rgb(72,190,214));Path path=new Path();for(int i=0;i<values.length;i++){float x=dp(8)+(w-dp(16))*i/(float)(values.length-1),y=dp(24)+(h-dp(38))*(float)((hi-values[i])/(hi-lo));if(i==0)path.moveTo(x,y);else path.lineTo(x,y);}c.drawPath(path,p);p.setStyle(Paint.Style.FILL);p.setColor(Color.LTGRAY);c.drawText(String.format(Locale.US,"MIN %.1f  MAX %.1f  N %d",lo,hi,values.length),dp(8),h-dp(6),p);}
 int dp(int n){return(int)(n*getResources().getDisplayMetrics().density+.5f);}
}