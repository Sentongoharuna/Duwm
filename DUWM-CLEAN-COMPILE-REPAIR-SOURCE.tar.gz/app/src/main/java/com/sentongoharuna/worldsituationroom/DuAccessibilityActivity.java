package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.os.*;import android.widget.*;
public final class DuAccessibilityActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);LinearLayout r=Du2Ui.shell(this,"ACCESSIBILITY");r.addView(DuChronoNav.bar(this,"ACCESSIBILITY","", ""));TextView h=Du2Ui.t(this,"READABILITY & MOTION",18);DuAccessibility.heading(h);r.addView(h);
  Switch motion=new Switch(this);motion.setText("REDUCE MOTION");motion.setChecked(DuAccessibility.reducedMotion(this));DuAccessibility.target(motion,"Reduce DUWM motion and transitions");motion.setOnCheckedChangeListener((v,on)->DuAccessibility.reducedMotion(this,on));r.addView(motion);
  r.addView(Du2Ui.panel(this,"TOUCH TARGETS","● 48DP MINIMUM","Primary DUWM controls use a minimum 48dp interactive target."));
  r.addView(Du2Ui.panel(this,"FONT SCALING","● SYSTEM CONTROLLED","Text uses Android scaled text sizing so system font scaling remains effective. Scrollable pages protect content from clipping."));
  r.addView(Du2Ui.panel(this,"TALKBACK","● SEMANTIC LABELS","Core buttons, mini maps, video controls, widgets, sheet handle and interactive intelligence surfaces expose accessibility descriptions."));
  r.addView(Du2Ui.panel(this,"CONTRAST","DARK OPERATIONS THEME","Critical text uses high-luminance foregrounds on dark surfaces; state colour is accompanied by written labels."));
  setContentView(r);
 }
}