package com.sentongoharuna.worldsituationroom;

/** Explicit feed health prevents one provider failure from taking down the situation desk. */
public final class FeedStatus {
    public enum State {
        LOADING,
        LIVE,
        /** A previously live source has exceeded its expected freshness budget. */
        DELAYED,
        CACHED,
        READY,
        OFFLINE,
        KEY_REQUIRED
    }

    public final State state;
    public final int count;
    public final String message;
    public final long updatedAtMs;

    public FeedStatus(State state, int count, String message, long updatedAtMs) {
        this.state = state;
        this.count = Math.max(0, count);
        this.message = message == null ? "" : message;
        this.updatedAtMs = updatedAtMs;
    }

    public static FeedStatus loading(String message) {
        return new FeedStatus(State.LOADING, 0, message, System.currentTimeMillis());
    }
}
