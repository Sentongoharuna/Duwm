package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Collections;
import java.util.EnumMap;
import java.util.List;

/**
 * Tiny durable source-health index used by widgets. It contains no API keys and no invented
 * events. Full records remain in {@link OperationsSnapshotStore}; this store also covers feeds
 * such as radar whose provider response is a frame list rather than ordinary signals.
 */
public final class WidgetStateStore {
    private static final String STORE = "du_widget_source_health_v1";
    private final Context context;
    private final SharedPreferences values;

    public WidgetStateStore(Context context) {
        this.context = context.getApplicationContext();
        values = this.context.getSharedPreferences(STORE, Context.MODE_PRIVATE);
    }

    public void recordLayer(Signal.Layer layer, List<Signal> signals, FeedStatus status) {
        if (layer == null || status == null) return;
        long newest = newestTimestamp(signals);
        values.edit()
                .putString(key(layer, "state"), status.state.name())
                .putInt(key(layer, "count"), Math.max(status.count,
                        signals == null ? 0 : signals.size()))
                .putString(key(layer, "message"), status.message)
                .putLong(key(layer, "updated"), status.updatedAtMs)
                .putLong(key(layer, "newest"), newest)
                .putLong("last_any_update", System.currentTimeMillis())
                .apply();
        DuWidgetUpdater.requestUpdate(context);
    }

    public void recordWeather(List<WorldDataRepository.RadarFrame> frames, FeedStatus status) {
        recordLayer(Signal.Layer.WEATHER, Collections.emptyList(), status);
        long newest = 0L;
        if (frames != null) {
            for (WorldDataRepository.RadarFrame frame : frames) {
                newest = Math.max(newest, frame.timestampMs);
            }
        }
        values.edit().putLong(key(Signal.Layer.WEATHER, "newest"), newest).apply();
    }

    public EnumMap<Signal.Layer, FeedStatus> loadStatuses() {
        EnumMap<Signal.Layer, FeedStatus> result = new EnumMap<>(Signal.Layer.class);
        for (Signal.Layer layer : Signal.Layer.values()) {
            String name = SafePreferences.string(values, key(layer, "state"), "");
            if (name == null || name.isEmpty()) continue;
            try {
                FeedStatus.State state = FeedStatus.State.valueOf(name);
                result.put(layer, new FeedStatus(state,
                        SafePreferences.integer(values, key(layer, "count"), 0),
                        SafePreferences.string(values, key(layer, "message"), ""),
                        SafePreferences.longValue(values, key(layer, "updated"), 0L)));
            } catch (IllegalArgumentException ignored) {
                // A future state written by a newer app is ignored by an older restored build.
            }
        }
        return result;
    }

    public long newestAt(Signal.Layer layer) {
        return SafePreferences.longValue(values, key(layer, "newest"), 0L);
    }

    public long lastAnyUpdate() {
        return SafePreferences.longValue(values, "last_any_update", 0L);
    }

    private static String key(Signal.Layer layer, String suffix) {
        return layer.name().toLowerCase(java.util.Locale.ROOT) + "_" + suffix;
    }

    private static long newestTimestamp(List<Signal> signals) {
        long newest = 0L;
        if (signals != null) {
            for (Signal signal : signals) newest = Math.max(newest, signal.timestampMs);
        }
        return newest;
    }
}
