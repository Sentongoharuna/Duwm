package com.sentongoharuna.worldsituationroom;
import android.content.*;
public final class DuWidgetParity{
 public static String status(Context c){WidgetSnapshot w=WidgetSnapshot.load(c);DuLiveCounts a=new DuLiveCounts(c);int airW=w.count(Signal.Layer.FLIGHTS),seaW=w.count(Signal.Layer.SHIPS),wxW=w.count(Signal.Layer.WEATHER),orbitW=w.count(Signal.Layer.SATELLITES);boolean ok=airW==a.count("AIR")&&seaW==a.count("SEA")&&wxW==a.count("WX")&&orbitW==a.count("ORBIT");return ok?"PARITY":"SYNCING";}
}