package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.view.*;import android.widget.*;import java.util.*;
public final class DuRelatedPanel{
 public static View make(Activity a,String system,String id){DuLiveRepository repo=new DuLiveRepository(a);Signal anchor=repo.find(system,id);LinearLayout c=Du2Ui.panel(a,"RELATED INTELLIGENCE","● CALCULATED","Relationships use time, geography, region, event type and entity/topic overlap across real provider records.");if(anchor==null){c.addView(Du2Ui.t(a,"CURRENT RECORD NOT AVAILABLE IN PROVIDER SNAPSHOT",9));return c;}
  for(DuRelatedEngine.Relation r:new DuRelatedEngine(a).related(anchor,12)){Button x=Du2Ui.button(a,String.format(Locale.US,"%.0f%% · %s · %s",r.score*100,r.signal.layer.name(),r.signal.title));x.setContentDescription("Related because "+r.why);x.setOnClickListener(v->a.startActivity(DuSignalIntent.detail(a,r.signal)));c.addView(x);TextView why=Du2Ui.t(a,"↳ "+r.why+" · "+r.signal.source,8);why.setTextColor(Du2Ui.M);c.addView(why);}
  List<MonitorReport> monitors=DuMonitorRelations.near(a,anchor);for(MonitorReport m:monitors){Button x=Du2Ui.button(a,"MONITOR · "+m.displayName+" · "+m.locationName);x.setOnClickListener(v->DuMonitorPlayer.open(a,m.id));c.addView(x);}
  if(c.getChildCount()<=0)c.addView(Du2Ui.t(a,"NO STRONG RELATED RECORDS IN CURRENT SNAPSHOTS",9));return c;}
}