package com.sentongoharuna.worldsituationroom;
import android.content.*;
public final class DuProviderRefresh{
 public static final String ACTION="com.sentongoharuna.worldsituationroom.REFRESH_PROVIDERS";
 public static void request(Context c,String system){Intent i=new Intent(c,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT|Intent.FLAG_ACTIVITY_SINGLE_TOP);i.putExtra("du_refresh",true);i.putExtra("du_refresh_system",system==null?"ALL":system);c.startActivity(i);}
}