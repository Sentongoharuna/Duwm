#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuSessionState.java"
grep -F 'DuSessionState.indexSystem(this)' "$J/DuSystemIndexActivity.java" >/dev/null
grep -F 'DuSessionState.indexQuery(this)' "$J/DuSystemIndexActivity.java" >/dev/null
grep -F 'DuSelectionState.set(this,p.system,p.id,p.title)' "$J/DuRecordDetailActivity.java" >/dev/null
grep -F 'DuSessionState.page(this,"TRACK")' "$J/DuTrackActivity.java" >/dev/null
grep -F 'DuSessionState.page(this,"COCKPIT")' "$J/DuCockpitActivity.java" >/dev/null
grep -F 'RESTORE LAST TARGET' "$J/DuIntegratedHomeActivity.java" >/dev/null
grep -F 'DuSpatialState.sensor(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
echo "DUWM2 PROCESS RESTORATION PASS"
