#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";S="$J/SatelliteMapView.java"
if grep -E '\bdp[[:space:]]*\(' "$S" >/dev/null; then echo "ERROR: stale dp() remains"; exit 1; fi
! grep -R -F 'setStrokeWidthduPx' "$J" >/dev/null
! grep -R -F 'trackedSignalId' "$J" >/dev/null
! grep -R -F 'displayCoordinate(signal)' "$J" >/dev/null
grep -F 'duPx(signal.id.equals(DuSelectionState.id(getContext())) ? 22 : 15)' "$S" >/dev/null
grep -F 'paint.setStrokeWidth(duPx(1));' "$S" >/dev/null
echo "DUWM COMPILE REPAIR STATIC CHECK PASS"
