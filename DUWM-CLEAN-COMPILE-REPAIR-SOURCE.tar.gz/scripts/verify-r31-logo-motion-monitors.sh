#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
grep -F 'versionCode = 34' "$ROOT/app/build.gradle.kts"
grep -F 'versionName = "31.0-2026-logo-motion-monitors"' "$ROOT/app/build.gradle.kts"
for x in WorldPulse OrbitWatch SourceMatrix MonitorStories; do grep -F "class $x" "$ROOT/app/src/main/java/com/sentongoharuna/worldsituationroom/DuWidgetProviders.java"; done
grep -F 'android:icon="@mipmap/ic_launcher"' "$ROOT/app/src/main/AndroidManifest.xml"
grep -F 'ShareCardProvider' "$ROOT/app/src/main/AndroidManifest.xml"
grep -F 'LocalMonitorActivity' "$ROOT/app/src/main/AndroidManifest.xml"
if [[ $# -gt 0 ]]; then test -s "$1"; test "$(head -c 2 "$1")" = 'PK'; fi
echo 'R31 logo + 12-widget + Local Monitor contract verified'
