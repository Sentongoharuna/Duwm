#!/usr/bin/env python3
import pathlib,re,sys
p=pathlib.Path(sys.argv[1]);j=p/"app/src/main/java/com/sentongoharuna/worldsituationroom";manifest=(p/"app/src/main/AndroidManifest.xml").read_text();errors=[];refs=set()
for f in j.glob("Du*.java"):refs.update(re.findall(r'\b(Du[A-Za-z0-9_]+Activity)\.class\b',f.read_text(errors="ignore")))
for c in sorted(refs):
 if not (j/(c+".java")).exists():errors.append("missing source "+c)
 if f'android:name=".{c}"' not in manifest:errors.append("missing manifest "+c)
checks={"MainActivity.java":["DuSignalIntent.detail(MainActivity.this, signal)"],"DuContextBar.java":["DuSignalIntent.track(a,s)"],"DuTrackActivity.java":["DuContactsActivity.class","DuCockpitActivity.class"],"DuMonitorHubActivity.java":["DuMonitorPlayer.open","DuReporterProfiles.open","DuDiscussion.open"],"DuAskActivity.java":["DuSignalIntent.detail(this,s)","DuSignalIntent.track(this,s)"],"DuWidgetRenderer.java":["DuWidgetDeepLink.record"],"DuNotificationCenter.java":["DuSignalIntent.detail(c,s)"],"Du2More.java":["DuNewsClustersActivity.class","DuSceneDirectorActivity.class","DuDetectionActivity.class","DuPerformanceActivity.class","DuAccessibilityActivity.class","DuRecoveryActivity.class","DuNavigationMatrixActivity.class"]}
for fn,ns in checks.items():
 t=(j/fn).read_text(errors="ignore")
 for n in ns:
  if n not in t:errors.append(fn+": missing route "+n)
matrix=(j/"DuNavigationMatrix.java").read_text();rows=re.findall(r'\{"([^"]+)","([^"]+)","([^"]+)","([^"]+)"\}',matrix)
if len(rows)<20:errors.append("matrix too small "+str(len(rows)))
for row in rows:
 if not row[3]:errors.append("blank back "+str(row))
if errors:
 print("NAVIGATION MATRIX FAIL");[print(" -",e) for e in errors];sys.exit(1)
print("DUWM2 NAVIGATION MATRIX PASS",len(rows),"core routes",len(refs),"referenced activities")
