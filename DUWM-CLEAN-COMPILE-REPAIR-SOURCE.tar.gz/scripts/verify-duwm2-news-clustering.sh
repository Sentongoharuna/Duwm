#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$P/app/src/main/AndroidManifest.xml"
for f in DuNewsClusterEngine.java DuNewsClustersActivity.java;do test -s "$J/$f";done
grep -F 's.layer==Signal.Layer.NEWS' "$J/DuNewsClusterEngine.java" >/dev/null
grep -F '12L*60L*60L*1000L' "$J/DuNewsClusterEngine.java" >/dev/null
grep -F 'DuProximityEngine.distance' "$J/DuNewsClusterEngine.java" >/dev/null
grep -F 'c.sources.size()+" SOURCES' "$J/DuNewsClustersActivity.java" >/dev/null
grep -F 'DuSignalIntent.detail(this,s)' "$J/DuNewsClustersActivity.java" >/dev/null
grep -F 'OPEN NEWS CLUSTERS' "$J/DuMediaPageActivity.java" >/dev/null
grep -F 'NEWS CLUSTERS' "$J/Du2More.java" >/dev/null
grep -F 'DuNewsClustersActivity' "$M" >/dev/null
echo "DUWM2 NEWS CLUSTERING PASS"
