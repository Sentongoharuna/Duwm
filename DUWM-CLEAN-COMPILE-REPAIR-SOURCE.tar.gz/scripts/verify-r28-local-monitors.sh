#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "$0")/.." && pwd)"
main="$project_dir/app/src/main/java/com/sentongoharuna/worldsituationroom"
manifest="$project_dir/app/src/main/AndroidManifest.xml"
gradle_file="$project_dir/app/build.gradle.kts"
apk="${1:-}"

EXPECTED_VERSION_CODE=31 \
EXPECTED_VERSION_NAME=28.0-2026-local-monitors \
  "$project_dir/scripts/verify-r27-live-motion-widgets.sh" "$apk"

test -s "$main/LocalMonitorActivity.java"
test -s "$main/MonitorReport.java"
test -s "$main/MonitorStore.java"
test -s "$main/MonitorProfileStore.java"
test -s "$main/MonitorApiClient.java"
test -s "$main/MonitorMediaProvider.java"
test -s "$project_dir/LOCAL_MONITORS_API.md"
test -s "$project_dir/R28_RELEASE_NOTES.md"

grep -Fq 'versionCode = 31' "$gradle_file"
grep -Fq 'versionName = "28.0-2026-local-monitors"' "$gradle_file"
grep -Fq 'android:name=".LocalMonitorActivity"' "$manifest"
grep -Fq 'android:name=".MonitorMediaProvider"' "$manifest"
grep -Fq 'android.permission.ACCESS_COARSE_LOCATION' "$manifest"
grep -Fq 'addMissionAction(row, "MONITORS", view -> openLocalMonitors());' \
  "$main/MainActivity.java"
grep -Fq 'Every new public report begins as **UNVERIFIED**.' \
  "$project_dir/R28_RELEASE_NOTES.md"
grep -Fq 'STATE_LOCAL = "LOCAL_ONLY"' "$main/MonitorReport.java"
grep -Fq 'MediaStore.ACTION_VIDEO_CAPTURE' "$main/LocalMonitorActivity.java"
grep -Fq 'Intent.ACTION_OPEN_DOCUMENT' "$main/LocalMonitorActivity.java"
grep -Fq 'Start a LIVE location report' "$main/LocalMonitorActivity.java"
grep -Fq '/v1/live/sessions' "$main/MonitorApiClient.java"
grep -Fq '/comments' "$main/MonitorApiClient.java"
grep -Fq '/like' "$main/MonitorApiClient.java"
grep -Fq '/follow' "$main/MonitorApiClient.java"
grep -Fq '/flag' "$main/MonitorApiClient.java"
grep -Fq 'Android Keystore' "$project_dir/R28_RELEASE_NOTES.md"

if grep -REn 'android\.webkit\.WebView|<WebView|loadUrl\(' "$project_dir/app/src/main"; then
  echo 'R28 Local Monitors must remain native and cannot embed hosted pages.' >&2
  exit 1
fi

if grep -En '^[[:space:]]*(implementation|api)\(' "$gradle_file"; then
  echo 'R28 introduced a forbidden external runtime dependency.' >&2
  exit 1
fi

if test -n "$apk"; then
  sdk_root="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
  build_tools="$(find "$sdk_root/build-tools" -mindepth 1 -maxdepth 1 -type d \
    | sort -V | tail -n 1)"
  manifest_dump="$("$build_tools/aapt2" dump xmltree "$apk" --file AndroidManifest.xml)"
  grep -Fq 'LocalMonitorActivity' <<<"$manifest_dump"
  grep -Fq 'MonitorMediaProvider' <<<"$manifest_dump"

  inspect_dir="$(mktemp -d)"
  trap 'test -d "$inspect_dir" && rm -rf -- "$inspect_dir"' EXIT
  unzip -q "$apk" 'classes*.dex' -d "$inspect_dir"
  dex_dump="$({ for dex in "$inspect_dir"/classes*.dex; do "$build_tools/dexdump" -f "$dex"; done; })"
  for component in LocalMonitorActivity MonitorReport MonitorStore \
    MonitorProfileStore MonitorApiClient MonitorMediaProvider; do
    grep -Fq "/$component;" <<<"$dex_dump"
  done
fi

echo 'R28 LOCAL MONITORS PASS: profiles + local video + secure sync + live sessions + social controls'
