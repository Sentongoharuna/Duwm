#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";F="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/SatelliteMapView.java"
grep -F 'private float duPx(float value)' "$F" >/dev/null
grep -F 'private static String compactHudId' "$F" >/dev/null
! grep -F '}\n\n    private static String compactHudId' "$F" >/dev/null
! grep -F 'trackedSignalId' "$F" >/dev/null
! grep -F 'displayCoordinate(signal)' "$F" >/dev/null
grep -F 'displayPosition(signal, display);' "$F" >/dev/null
echo "BUILD06 JAVA FORMAT REPAIR VERIFIED"
