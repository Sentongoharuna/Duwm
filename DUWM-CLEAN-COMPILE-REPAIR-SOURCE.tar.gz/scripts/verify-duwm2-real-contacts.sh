#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuProximityEngine.java"
grep -F '6371.0088' "$J/DuProximityEngine.java" >/dev/null
grep -F 'DuProximityEngine.nearby(anchor,pool,radius,40)' "$J/DuContactsActivity.java" >/dev/null
grep -F 'repo.find(payload.system,payload.id)' "$J/DuContactsActivity.java" >/dev/null
grep -F 'repo.signals(s)' "$J/DuContactsActivity.java" >/dev/null
grep -F 'DuSignalIntent.detail(this,s)' "$J/DuContactsActivity.java" >/dev/null
grep -F 'DuSignalIntent.track(this,s)' "$J/DuContactsActivity.java" >/dev/null
grep -F 'No position is guessed' "$J/DuContactsActivity.java" >/dev/null
echo "DUWM2 REAL CONTACTS PASS"
