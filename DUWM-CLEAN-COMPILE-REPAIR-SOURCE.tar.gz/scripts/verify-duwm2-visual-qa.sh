#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$P/app/src/main/AndroidManifest.xml"
test -s "$J/DuVisualQa.java";test -s "$J/DuVisualQaActivity.java"
grep -F 'DuVisualQa.fill(r,a)' "$J/Du2Ui.java" >/dev/null
grep -F 'DuVisualQa.applyInsets(a,r)' "$J/Du2Ui.java" >/dev/null
grep -F 'ORIENTATION_LANDSCAPE?240:360' "$J/DuIntegratedHomeActivity.java" >/dev/null
grep -F 'HorizontalScrollView chipScroll' "$J/DuSystemIndexActivity.java" >/dev/null
grep -F 'STATUS BAR · OVERLAP · SCROLL · SHEET · ROTATION' "$J/DuVisualQaActivity.java" >/dev/null
grep -F '"VISUAL QA"' "$J/Du2More.java" >/dev/null
grep -F 'DuVisualQaActivity' "$M" >/dev/null
echo "DUWM2 REAL DEVICE VISUAL QA SAFEGUARDS PASS"
