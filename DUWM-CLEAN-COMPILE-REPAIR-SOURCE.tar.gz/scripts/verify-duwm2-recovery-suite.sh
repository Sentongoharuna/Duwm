#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$P/app/src/main/AndroidManifest.xml"
for f in DuRecoveryState.java DuRecoveryGuard.java DuRecoveryActivity.java;do test -s "$J/$f";done
grep -F 'DuRecoveryGuard.valid(context,"PROVIDER:"+system,s.signals)' "$J/DuLiveRepository.java" >/dev/null
grep -F 'Provider returned null collection' "$J/DuRecoveryGuard.java" >/dev/null
grep -F 'malformed record(s) ignored' "$J/DuRecoveryGuard.java" >/dev/null
grep -F 'DuRecoveryState.fail(image.getContext(),"IMAGE"' "$J/DuRemoteImageLoader.java" >/dev/null
grep -F 'DuRecoveryState.fail(this,"VIDEO"' "$J/DuMonitorPlayerActivity.java" >/dev/null
grep -F 'DuRecoveryState.fail(this,"NETWORK:"+layer.name()' "$J/MainActivity.java" >/dev/null
grep -F '"EMPTY CACHE","MALFORMED DATA","IMAGE FAIL","VIDEO FAIL"' "$J/DuRecoveryActivity.java" >/dev/null
grep -F '"RECOVERY"' "$J/Du2More.java" >/dev/null
grep -F 'DuRecoveryActivity' "$M" >/dev/null
echo "DUWM2 RECOVERY SUITE PASS"
