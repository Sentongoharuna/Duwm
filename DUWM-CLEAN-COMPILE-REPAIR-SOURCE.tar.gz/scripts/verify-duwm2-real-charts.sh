#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuSparklineView.java DuTrendStore.java DuChartsPanel.java;do test -s "$J/$f";done
grep -F 'DuTrendStore.record(this, "COUNT:"+layer.name(), safeSignals.size())' "$J/MainActivity.java" >/dev/null
grep -F 'INSUFFICIENT SOURCE HISTORY' "$J/DuSparklineView.java" >/dev/null
grep -F 'DuChartsPanel.make(this,page)' "$J/DuWorldSystemPageActivity.java" >/dev/null
grep -F 'DuChartsPanel.make(this,page)' "$J/DuTransportMarketPageActivity.java" >/dev/null
grep -F 'DuChartsPanel.make(this,"SOURCES")' "$J/DuSourceHealthPageActivity.java" >/dev/null
echo "DUWM2 REAL CHARTS PASS"
