#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuWidgetDeepLink.java DuWidgetParity.java;do test -s "$J/$f";done
grep -F 'DuSignalIntent.detail(c,s)' "$J/DuWidgetDeepLink.java" >/dev/null
grep -F 'content.selected == null' "$J/DuWidgetRenderer.java" >/dev/null
grep -F 'DuWidgetDeepLink.record(context, widgetId, content.selected' "$J/DuWidgetRenderer.java" >/dev/null
grep -F 'DuWidgetDeepLink.catalog(context, widgetId, catalog)' "$J/DuWidgetRenderer.java" >/dev/null
grep -F 'WidgetSnapshot.load(c)' "$J/DuWidgetParity.java" >/dev/null
grep -F 'new DuLiveCounts(c)' "$J/DuWidgetParity.java" >/dev/null
grep -F 'APP ↔ WIDGET DATA' "$J/DuWidgetsPageActivity.java" >/dev/null
echo "DUWM2 WIDGET EXACT RECORD DEEPLINKS PASS"
