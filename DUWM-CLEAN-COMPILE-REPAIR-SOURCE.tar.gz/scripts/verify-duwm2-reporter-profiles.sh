#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$P/app/src/main/AndroidManifest.xml"
for f in DuReporterProfile.java DuReporterProfileActivity.java DuReporterProfiles.java;do test -s "$J/$f";done
grep -F 'MonitorProfileStore' "$J/DuReporterProfile.java" >/dev/null
grep -F 'profileVerified' "$J/DuReporterProfile.java" >/dev/null
grep -F 'REPORT HISTORY' "$J/DuReporterProfileActivity.java" >/dev/null
grep -F '"REPORTS",String.valueOf(p.reports)' "$J/DuReporterProfileActivity.java" >/dev/null
grep -F 'profiles.toggleFollow(id)' "$J/DuReporterProfileActivity.java" >/dev/null
grep -F 'avatars.load' "$J/DuReporterProfileActivity.java" >/dev/null
grep -F 'REPORTER PROFILE' "$J/DuMonitorHubActivity.java" >/dev/null
grep -F 'DuReporterProfileActivity' "$M" >/dev/null
echo "DUWM2 REPORTER PROFILES PASS"
