#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
UI="$J/Du2Ui.java"
! grep -qE '(^|,)R=Color\.' "$UI"
! grep -R -F 'Du2Ui.R' "$J" >/dev/null
grep -F 'R.drawable.du_brand_mark' "$UI" >/dev/null
grep -F 'ALERT=Color.rgb(218,70,76)' "$UI" >/dev/null
echo "DUWM2 RESOURCE SYMBOL COLLISION FIX PASS"
