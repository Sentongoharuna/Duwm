#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuProviderRefresh.java";test -s "$J/DuAutoRefresh.java"
grep -F 'repository.refreshNow()' "$J/MainActivity.java" >/dev/null
grep -F 'getBooleanExtra("du_refresh", false)' "$J/MainActivity.java" >/dev/null
grep -F 'DuProviderRefresh.request(a,s)' "$J/DuStatePanel.java" >/dev/null
! grep -F 'DuFreshness.mark(a,s)' "$J/DuStatePanel.java" >/dev/null
grep -F 'REFRESH ALL LIVE PROVIDERS' "$J/DuSourceHealthPageActivity.java" >/dev/null
grep -F 'REFRESH PROVIDERS' "$J/DuIntegrationStatusActivity.java" >/dev/null
echo "DUWM2 REAL PROVIDER REFRESH PASS"
