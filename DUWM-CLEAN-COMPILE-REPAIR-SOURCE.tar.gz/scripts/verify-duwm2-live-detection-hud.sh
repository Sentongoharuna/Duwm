#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
grep -F 'drawDuDetectionHud(canvas)' "$J/SatelliteMapView.java" >/dev/null
grep -F 'projectInto(display[0], display[1], point)' "$J/SatelliteMapView.java" >/dev/null
grep -F 'Signal.Layer.FLIGHTS' "$J/SatelliteMapView.java" >/dev/null
grep -F 'Signal.Layer.SHIPS' "$J/SatelliteMapView.java" >/dev/null
grep -F 'Signal.Layer.SATELLITES' "$J/SatelliteMapView.java" >/dev/null
grep -F 'signal.id.equals(trackedSignalId)' "$J/SatelliteMapView.java" >/dev/null
grep -F 'TRACK LOCK' "$J/SatelliteMapView.java" >/dev/null
grep -F 'No face recognition' "$J/DuDetectionActivity.java" >/dev/null
echo "DUWM2 LIVE DETECTION HUD PASS"
