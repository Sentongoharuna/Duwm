#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuTrackHistoryStore.java";test -s "$J/DuObservedTrailView.java"
grep -F 'MAX_FIXES_PER_TRACK = 32' "$J/SatelliteMapView.java" >/dev/null
grep -F 'public List<double[]> observedTrack' "$J/SatelliteMapView.java" >/dev/null
grep -F 'DuTrackHistoryStore.ingest(this, safeSignals)' "$J/MainActivity.java" >/dev/null
grep -F 'DuObservedTrailView.make(this,p.id)' "$J/DuTrackActivity.java" >/dev/null
grep -F 'DuObservedTrailView.make(this,p.id)' "$J/DuCockpitActivity.java" >/dev/null
grep -F 'Only coordinates received from the provider' "$J/DuObservedTrailView.java" >/dev/null
echo "DUWM2 LIVE PROVIDER TRACKS PASS"
