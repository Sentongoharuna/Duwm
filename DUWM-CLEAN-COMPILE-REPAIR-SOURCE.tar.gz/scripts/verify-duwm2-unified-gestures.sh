#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuGestureCoordinator.java DuPageSwipe.java DuGestureHelpActivity.java;do test -s "$J/$f";done
grep -F 'Owner{NONE,GLOBE,SHEET,PAGE,EDGE_BACK}' "$J/DuGestureCoordinator.java" >/dev/null
grep -F 'edge=24*d' "$J/DuGestureCoordinator.java" >/dev/null
grep -F 'requestDisallowInterceptTouchEvent(true)' "$J/DuDraggableSheet.java" >/dev/null
grep -F 'requestDisallowInterceptTouchEvent(true)' "$J/SatelliteMapView.java" >/dev/null
grep -F 'new DuPageSwipe' "$J/DuWorldSystemPageActivity.java" >/dev/null
grep -F 'Math.abs(dx)>Du2Ui.dp(a,72)' "$J/DuPageSwipe.java" >/dev/null
echo "DUWM2 UNIFIED GESTURES PASS"
