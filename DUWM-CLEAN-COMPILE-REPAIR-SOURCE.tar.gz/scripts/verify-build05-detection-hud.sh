#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";F="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/SatelliteMapView.java"
grep -F 'private float duPx(float value)' "$F" >/dev/null
grep -F 'displayPosition(signal, display);' "$F" >/dev/null
grep -F 'DuSelectionState.id(getContext())' "$F" >/dev/null
! grep -F 'displayCoordinate(signal)' "$F" >/dev/null
! grep -F 'trackedSignalId' "$F" >/dev/null
! grep -E '\bdp\([0-9]+\)' "$F" >/dev/null
grep -F 'TRACK LOCK' "$F" >/dev/null
echo "BUILD05 DETECTION HUD SYMBOL REPAIR VERIFIED"
