#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
F="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/SatelliteMapView.java"
grep -F 'displayPosition(signal, display);' "$F" >/dev/null
if grep -F 'displayCoordinate(signal)' "$F" >/dev/null; then
  echo "ERROR: stale nonexistent displayCoordinate(signal) remains"
  exit 1
fi
if grep -E '\bdp\([0-9]+\)' "$F" >/dev/null; then
  echo "ERROR: stale nonexistent dp(int) calls remain in SatelliteMapView"
  exit 1
fi
grep -F 'DuPerformancePolicy.hudBudget(getContext())' "$F" >/dev/null
grep -F 'TRACK LOCK' "$F" >/dev/null
echo "BUILD03 SATELLITE HUD REPAIR VERIFIED"
