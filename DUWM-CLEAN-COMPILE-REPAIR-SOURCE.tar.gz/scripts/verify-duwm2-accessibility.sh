#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$P/app/src/main/AndroidManifest.xml"
for f in DuAccessibility.java DuAccessibilityActivity.java;do test -s "$J/$f";done
grep -F 'setMinimumWidth' "$J/DuAccessibility.java" >/dev/null
grep -F 'setMinimumHeight' "$J/DuAccessibility.java" >/dev/null
grep -F 'setContentDescription' "$J/DuAccessibility.java" >/dev/null
grep -F 'ANIMATOR_DURATION_SCALE' "$J/DuAccessibility.java" >/dev/null
grep -F 'DuAccessibility.motionMs(a,180)' "$J/DuDraggableSheet.java" >/dev/null
grep -F 'DuAccessibility.reducedMotion' "$J/DuWorldWallpaperService.java" >/dev/null
grep -F '"ACCESSIBILITY"' "$J/Du2More.java" >/dev/null
grep -F 'DuAccessibilityActivity' "$M" >/dev/null
echo "DUWM2 ACCESSIBILITY PASS"
