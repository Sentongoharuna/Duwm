#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuLiveStats.java DuInteraction.java DuRecordDetailActivity.java DuSystemIndexActivity.java DuMonitorHubActivity.java;do test -s "$J/$f";done
grep -F 'Filter "+sys+" records / source / place' "$J/DuSystemIndexActivity.java" >/dev/null
grep -F 'LIVE INDEX' "$J/DuRecordDetailActivity.java" >/dev/null
grep -F 'REPORTER PROFILES' "$J/DuMonitorHubActivity.java" >/dev/null
grep -F 'BREAKING WIRE' "$J/DuGlobeCommandActivity.java" >/dev/null
grep -F 'DuSystemIndexActivity.class' "$J/Du2More.java" >/dev/null
grep -R -F 'LIVE SOURCE INDEX' "$J" >/dev/null
echo "DUWM2 SOLUTIONS PACK PASS"
