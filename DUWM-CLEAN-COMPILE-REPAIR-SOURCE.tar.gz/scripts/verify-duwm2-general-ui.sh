#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
P="$ROOT/app/src/main/java/com/sentongoharuna/worldsituationroom"
grep -R -F "LIVE SOURCE INDEX" "$P" >/dev/null
grep -R -F "SHARE THIS PAGE AS CARD" "$P" >/dev/null
grep -F 'new String[]{"GLOBE","NEWS","MAP","MONITORS","MORE"}' "$P/Du2Nav.java" >/dev/null
grep -F 'Du2Ui.shell(this,"INTELLIGENCE & SYSTEMS")' "$P/Du2More.java" >/dev/null
grep -F 'LOCAL MONITORS / LIVE REPORTING' "$P/Du2Monitors.java" >/dev/null
test -s "$ROOT/app/src/main/res/drawable/du2_action.xml"
echo "DUWM2 GENERAL UI CONTRACT PASS"
