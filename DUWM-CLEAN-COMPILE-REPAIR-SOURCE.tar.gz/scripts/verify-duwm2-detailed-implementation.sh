#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuImplementationContract.java"
test -s "$J/DuStatePanel.java"
grep -F 'Aircraft/airspace tracking' "$J/DuImplementationContract.java" >/dev/null
grep -F 'Maritime tracking' "$J/DuImplementationContract.java" >/dev/null
grep -F 'Weather intelligence' "$J/DuImplementationContract.java" >/dev/null
grep -F 'Orbital intelligence' "$J/DuImplementationContract.java" >/dev/null
grep -F 'Ground reporting' "$J/DuImplementationContract.java" >/dev/null
grep -F 'Provider health' "$J/DuImplementationContract.java" >/dev/null
grep -F 'DuStatePanel.make' "$J/DuRecordDetailActivity.java" >/dev/null
grep -F 'DuStatePanel.make' "$J/DuSystemIndexActivity.java" >/dev/null
grep -F 'DuImplementationContract.chain' "$J/DuRecordDetailActivity.java" >/dev/null
grep -F 'DuChronoNav.bar' "$J/DuRecordDetailActivity.java" >/dev/null
grep -F 'DuGeoPreview.make' "$J/DuRecordDetailActivity.java" >/dev/null
grep -F 'DuObjectPayload.from' "$J/DuRecordDetailActivity.java" >/dev/null
grep -F 'RENDER PNG & SHARE' "$J/DuShareStudioActivity.java" >/dev/null
test -s "$P/docs/DUWM2-DETAILED-IMPLEMENTATION-MATRIX.md"
echo "DUWM2 DETAILED IMPLEMENTATION PASS"
