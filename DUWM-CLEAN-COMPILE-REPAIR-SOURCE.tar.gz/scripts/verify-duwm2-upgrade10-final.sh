#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
grep -F 'enum State{COLLAPSED,HALF,FULL}' "$J/DuDraggableSheet.java" >/dev/null
grep -F 'MotionEvent.ACTION_MOVE' "$J/DuDraggableSheet.java" >/dev/null
grep -F 'nearest(getTranslationY())' "$J/DuDraggableSheet.java" >/dev/null
grep -F 'getSharedPreferences(PREF,0)' "$J/DuDraggableSheet.java" >/dev/null
grep -F 'setDuration(180)' "$J/DuDraggableSheet.java" >/dev/null
grep -F 'return new DuDraggableSheet(a)' "$J/DuIntelligenceSheet.java" >/dev/null
grep -F 'FrameLayout.LayoutParams sp' "$J/DuIntegratedHomeActivity.java" >/dev/null
grep -F 'DuLiveCounterStrip.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
echo "DUWM2 UPGRADE10 FINAL PASS"
