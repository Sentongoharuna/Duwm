#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$P/app/src/main/AndroidManifest.xml"
for f in DuNotificationCenter.java DuAlertEngine.java;do test -s "$J/$f";done
grep -F 'DuSignalIntent.detail(c,s)' "$J/DuNotificationCenter.java" >/dev/null
grep -F 's.source' "$J/DuNotificationCenter.java" >/dev/null
grep -F 'DuLiveRepository.place(s)' "$J/DuNotificationCenter.java" >/dev/null
grep -F 's.severity<4' "$J/DuAlertEngine.java" >/dev/null
grep -F 'DuAlertEngine.inspect(this, layer, safeSignals)' "$J/MainActivity.java" >/dev/null
grep -F 'android.permission.POST_NOTIFICATIONS' "$M" >/dev/null
grep -F 'POST_NOTIFICATIONS' "$J/DuIntegratedHomeActivity.java" >/dev/null
echo "DUWM2 EXACT RECORD NOTIFICATIONS PASS"
