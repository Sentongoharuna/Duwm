#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuLiveCounts.java DuLiveCounterStrip.java;do test -s "$J/$f";done
grep -F 'OperationsSnapshotStore' "$J/DuLiveRepository.java" >/dev/null
grep -F 'return repo.count(s)' "$J/DuLiveCounts.java" >/dev/null
grep -F 'new MonitorStore(c).reports().size()' "$J/DuLiveCounts.java" >/dev/null
grep -F 'DuLiveCounterStrip.make(this)' "$J/DuIntegratedHomeActivity.java" >/dev/null
grep -F 'DuLiveCounterStrip.make(this)' "$J/DuSituationRoomActivity.java" >/dev/null
grep -F 'DuLiveCounterStrip.make(this)' "$J/DuSourceHealthPageActivity.java" >/dev/null
grep -F 'DuLiveCounterStrip.make(this)' "$J/DuSystemIndexActivity.java" >/dev/null
grep -F 'return new DuLiveCounts(c).count(s)' "$J/DuProviderBridge.java" >/dev/null
echo "DUWM2 SHARED LIVE COUNTERS PASS"
