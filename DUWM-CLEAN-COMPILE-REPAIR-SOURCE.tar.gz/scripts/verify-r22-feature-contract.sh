#!/usr/bin/env bash
set -euo pipefail

project_dir="${1:-}"
apk_path="${2:-}"

if [[ -z "$project_dir" || ! -d "$project_dir" ]]; then
  echo "Usage: verify-r21-feature-contract.sh PROJECT_DIR [APK]" >&2
  exit 2
fi

java_root="$project_dir/app/src/main/java/com/sentongoharuna/worldsituationroom"
source_root="$project_dir/app/src"

require_file() {
  [[ -s "$1" ]] || { echo "Missing required file: $1" >&2; exit 1; }
}

require_text() {
  local file="$1"
  local marker="$2"
  grep -Fq -- "$marker" "$file" || {
    echo "R22 feature contract missing '$marker' in $file" >&2
    exit 1
  }
}

for file in \
  MainActivity.java SatelliteMapView.java WorldDataRepository.java AisStreamClient.java \
  NativeMediaActivity.java SignalBeaconView.java SituationAnalyzer.java AppConfig.java \
  SecurePrefs.java HttpCache.java ReferenceCatalog.java RegionalFocus.java \
  CountrySituationEngine.java MovementAnalyzer.java ShareCardData.java \
  ShareCardRenderer.java ShareCardProvider.java; do
  require_file "$java_root/$file"
done

if grep -R -nE 'import[[:space:]]+android\.webkit|new[[:space:]]+WebView|chatgpt\.site|github\.io/Sentongoharuna' "$source_root"; then
  echo "Hosted-site or WebView code violates the standalone native contract." >&2
  exit 1
fi

# Identity and native architecture.
require_text "$project_dir/app/build.gradle.kts" 'applicationId = "com.sentongoharuna.worldsituationroom"'
require_text "$project_dir/app/build.gradle.kts" 'versionCode = 25'
require_text "$project_dir/app/build.gradle.kts" 'versionName = "22.1-2026-api23-lint-repair"'
require_text "$project_dir/app/build.gradle.kts" 'minSdk = 23'
require_text "$project_dir/app/src/main/res/values/strings.xml" '<string name="app_name">du-world moniter</string>'

# R19 retains the R18.1 startup responsiveness contract.
require_text "$java_root/MainActivity.java" 'showStartupShell("PREPARING NATIVE COMMAND DECK")'
require_text "$java_root/MainActivity.java" 'startupHandler.postDelayed(this::initializeApplication'
require_text "$java_root/MainActivity.java" 'APP READY • LIVE SOURCES JOINING'
require_text "$java_root/MainActivity.java" 'Executors.newSingleThreadExecutor()'
require_text "$java_root/SatelliteMapView.java" 'buildRenderSnapshot(value)'
require_text "$java_root/SatelliteMapView.java" 'frameDelayMs = signals.size() > 1_800'
require_text "$java_root/WorldDataRepository.java" 'Executors.newScheduledThreadPool(4)'
require_text "$java_root/WorldDataRepository.java" 'scheduleWithFixedDelay(this::refreshWeather'
require_text "$java_root/HttpCache.java" 'CONNECT_TIMEOUT_MS = 5_000'
require_text "$java_root/HttpCache.java" 'READ_TIMEOUT_MS = 8_000'

# Globe-first R18 interface and direct native pages.
require_text "$java_root/MainActivity.java" 'layersPanel.setVisibility(View.GONE)'
require_text "$java_root/MainActivity.java" 'wirePanel.setVisibility(View.GONE)'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "GLOBE"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "REGION"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "AIR"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "SEA"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "WX"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "EVENTS"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "WIRE"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "NEWS"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "BRIEF"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "CAM"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "RADIO"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "TV"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "SPACE"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "INFRA"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "CALLS"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "RISK"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "ANALYST"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "MARKETS"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "AIRPORTS"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "PORTS"'
require_text "$java_root/MainActivity.java" 'addMissionAction(row, "SOURCES"'
require_text "$java_root/MainActivity.java" 'CROSS-SOURCE WATCH'
require_text "$java_root/MainActivity.java" 'NOT CONFIRMATION'
require_text "$java_root/MainActivity.java" 'NOT A FORECAST'
require_text "$java_root/MainActivity.java" 'LATEST ACQUISITION'
require_text "$java_root/MainActivity.java" 'SOURCE HEALTH /'
require_text "$java_root/MainActivity.java" 'LOCAL ON'

# R20 visible expansion desks.
require_text "$java_root/MainActivity.java" 'WEATHER OPERATIONS / RADAR TIMELINE'
require_text "$java_root/MainActivity.java" 'COUNTRY WATCH / OBSERVED SIGNAL PRESSURE'
require_text "$java_root/MainActivity.java" 'ON-DEVICE ANALYST / OBSERVED PATTERNS'
require_text "$java_root/MainActivity.java" 'SOURCE REGISTRY / COVERAGE AND LIMITS'
require_text "$java_root/MainActivity.java" 'REUTERS / AP / AFP'
require_text "$java_root/MainActivity.java" 'PUBLIC SAFETY AUDIO'
require_text "$java_root/MainActivity.java" 'MILITARY IDENTITY'
require_text "$java_root/MainActivity.java" 'COMMODITIES'
require_text "$java_root/SatelliteMapView.java" 'setRadarFrames('
require_text "$java_root/SatelliteMapView.java" 'updateRadarAnimation()'
require_text "$java_root/CountrySituationEngine.java" 'not a forecast'
require_text "$java_root/MovementAnalyzer.java" 'EMERGENCY SQUAWK OBSERVED'
require_text "$java_root/MovementAnalyzer.java" 'POSSIBLE HOLDING / LOITER PATTERN'

# R21 universal visible share-card contract.
require_text "$java_root/MainActivity.java" 'SHARE THIS PAGE AS CARD'
require_text "$java_root/MainActivity.java" 'Button share = compactButton("SHARE CARD")'
require_text "$java_root/MainActivity.java" 'detailShareButton = actionButton("SHARE CARD", GREEN)'
require_text "$java_root/MainActivity.java" 'shareSignal(Signal signal)'
require_text "$java_root/NativeMediaActivity.java" 'SHARE INFORMATION CARD'
require_text "$java_root/ShareCardData.java" 'public static final String BRAND = "du-world moniter"'
require_text "$java_root/ShareCardRenderer.java" 'private static final int WIDTH = 1080'
require_text "$java_root/ShareCardRenderer.java" 'private static final int HEIGHT = 1350'
require_text "$java_root/ShareCardRenderer.java" 'Intent.ACTION_SEND'
require_text "$java_root/ShareCardRenderer.java" 'Intent.EXTRA_STREAM'
require_text "$java_root/ShareCardRenderer.java" 'Intent.FLAG_GRANT_READ_URI_PERMISSION'
require_text "$java_root/ShareCardRenderer.java" 'FULL DETAILS INCLUDED IN THE SHARED TEXT'
require_text "$java_root/ShareCardProvider.java" 'extends ContentProvider'
require_text "$project_dir/app/src/main/AndroidManifest.xml" 'android:name=".ShareCardProvider"'
require_text "$project_dir/app/src/main/AndroidManifest.xml" 'android:grantUriPermissions="true"'

# R19 private regional lens, recency desk and observed cross-domain checks.
require_text "$java_root/RegionalFocus.java" 'timezone without asking for GPS'
require_text "$java_root/RegionalFocus.java" 'EAST AFRICA'
require_text "$java_root/MainActivity.java" 'TIME_WINDOWS = {"1H", "6H", "24H", "72H"}'
require_text "$java_root/MainActivity.java" 'CROSS-DOMAIN PROXIMITY WATCHES'
require_text "$java_root/MainActivity.java" 'PROXIMITY IS NOT CONFIRMATION'
require_text "$java_root/MainActivity.java" 'derived from timezone only, not GPS'
require_text "$java_root/SituationAnalyzer.java" 'class DomainWatch'
require_text "$java_root/SituationAnalyzer.java" 'Proximity does not prove connection.'
require_text "$java_root/SituationAnalyzer.java" '500d, nowMs, 20L * 60L * 1000L'
require_text "$java_root/SituationAnalyzer.java" '300d, nowMs, 45L * 60L * 1000L'

# Interactive globe, detailed satellite/radar map and honest motion estimates.
require_text "$java_root/SatelliteMapView.java" 'extends View'
require_text "$java_root/SatelliteMapView.java" 'updateAutoRotation()'
require_text "$java_root/SatelliteMapView.java" 'onDoubleTap(MotionEvent event)'
require_text "$java_root/SatelliteMapView.java" 'onScale(ScaleGestureDetector detector)'
require_text "$java_root/SatelliteMapView.java" 'drawBaseTiles(canvas)'
require_text "$java_root/SatelliteMapView.java" 'drawRadarTiles(canvas)'
require_text "$java_root/SatelliteMapView.java" 'drawLabelTiles(canvas)'
require_text "$java_root/SatelliteMapView.java" 'FLIGHT_ESTIMATE_LIMIT_MS = 60_000L'
require_text "$java_root/SatelliteMapView.java" 'VESSEL_ESTIMATE_LIMIT_MS = 120_000L'
require_text "$java_root/SatelliteMapView.java" 'SHORT ESTIMATE ACTIVE'
require_text "$java_root/MainActivity.java" 'SOURCE POSITION AGE'
require_text "$java_root/MainActivity.java" 'FOLLOW ON SATELLITE MAP'

# R22 stable detailed-map renderer: no duplicate fallback cache, no black tile holes.
require_text "$java_root/TileStore.java" 'private final Map<String, Bitmap> pinnedMemory'
require_text "$java_root/TileStore.java" 'private final ConcurrentMap<String, TileTask> queuedTasks'
require_text "$java_root/TileStore.java" 'private final ConcurrentMap<String, HttpsURLConnection> activeConnections'
require_text "$java_root/TileStore.java" 'public Bitmap peek(String key)'
require_text "$java_root/TileStore.java" 'public void prioritizeViewport(Set<String> keepKeys)'
require_text "$java_root/TileStore.java" '"native-map-tiles-v6-" + safeNamespace'
require_text "$java_root/TileStore.java" 'if (!safe.contains(entry.getKey())) entry.getValue().disconnect();'
require_text "$java_root/SatelliteMapView.java" 'baseTiles = new TileStore(context, "base"'
require_text "$java_root/SatelliteMapView.java" 'overlayTiles = new TileStore(context, "overlay"'
require_text "$java_root/SatelliteMapView.java" 'requestBaseViewport(z, count, cachedBaseTiles)'
require_text "$java_root/SatelliteMapView.java" 'baseTiles.request(key, primary, fallback'
require_text "$java_root/SatelliteMapView.java" 'drawParentTileFallback('
require_text "$java_root/SatelliteMapView.java" 'drawStableTilePlaceholder('
require_text "$java_root/SatelliteMapView.java" 'nextBaseRetryMs = now + 15_000L'
require_text "$java_root/SatelliteMapView.java" 'PINNED VIEWPORT • RETRY 15S'
require_text "$java_root/MainActivity.java" 'feedPulse.setBackgroundColor(Color.TRANSPARENT)'
if grep -Fq 'request("dark_"' "$java_root/SatelliteMapView.java"; then
  echo "R22 must not create a duplicate dark-fallback request/cache key." >&2
  exit 1
fi

# Every promised live/public provider and graceful source isolation.
for marker in \
  OPENSKY_STATES RAINVIEWER USGS EONET NOAA_SPACE_WEATHER_ALERTS \
  NOAA_PLANETARY_K_INDEX GDELT NOMINATIM RADIO_BROWSER_DNS IPTV_CHANNELS \
  IPTV_STREAMS IPTV_BLOCKLIST AIS_STREAM WINDY_WEBCAMS SATELLITE_TILES LABEL_TILES \
  GDELT_LAST_UPDATE OURAIRPORTS_AIRPORTS OURAIRPORTS_RUNWAYS \
  OURAIRPORTS_FREQUENCIES FRANKFURTER_RATES COINGECKO_SIMPLE; do
  require_text "$java_root/AppConfig.java" "$marker"
done
require_text "$java_root/WorldDataRepository.java" 'publishFailure('
require_text "$java_root/WorldDataRepository.java" 'FeedStatus.State.CACHED'
require_text "$java_root/WorldDataRepository.java" 'OpenSky feed offline'
require_text "$java_root/WorldDataRepository.java" 'RainViewer feed offline'
require_text "$java_root/WorldDataRepository.java" 'All wire feeds offline'
require_text "$java_root/WorldDataRepository.java" 'Windy Webcams offline'
require_text "$java_root/WorldDataRepository.java" 'parseGkgArchive('
require_text "$java_root/WorldDataRepository.java" 'parseAirportAtlas('
require_text "$java_root/WorldDataRepository.java" 'parseAirportFrequencies('
require_text "$java_root/WorldDataRepository.java" 'parseCryptoPrices('

# Details, credibility and source attribution.
for marker in CALLSIGN 'ORIGIN COUNTRY' ALTITUDE SPEED HEADING 'POSITION SOURCE'; do
  require_text "$java_root/WorldDataRepository.java" "$marker"
done
for marker in MMSI TYPE 'FLAG / MID' DESTINATION SPEED HEADING; do
  require_text "$java_root/AisStreamClient.java" "$marker"
done
require_text "$java_root/MainActivity.java" 'UNVERIFIED — DEVELOPING'
require_text "$java_root/MainActivity.java" 'case REPORTED: return "REPORTED"'
require_text "$java_root/MainActivity.java" 'CONFIRMED — OFFICIAL SOURCE'
require_text "$java_root/MainActivity.java" 'SOURCE  '
require_text "$java_root/MainActivity.java" 'TIMESTAMP  '
require_text "$java_root/SituationAnalyzer.java" 'Correlation is not confirmation.'

# Native public-media playback and device-only secret storage.
require_text "$java_root/MainActivity.java" 'new MediaPlayer()'
require_text "$java_root/NativeMediaActivity.java" 'new VideoView(this)'
require_text "$java_root/NativeMediaActivity.java" 'new ImageView(this)'
require_text "$java_root/NativeMediaActivity.java" 'CAMERA_REFRESH_MS = 12_000L'
require_text "$java_root/SecurePrefs.java" 'AndroidKeyStore'
require_text "$project_dir/app/src/main/AndroidManifest.xml" 'android:name=".NativeMediaActivity"'

if [[ -n "$apk_path" ]]; then
  require_file "$apk_path"
  : "${ANDROID_SDK_ROOT:?ANDROID_SDK_ROOT is required for compiled APK verification}"
  build_tools="$ANDROID_SDK_ROOT/build-tools/36.0.0"
  require_file "$build_tools/aapt"
  require_file "$build_tools/apksigner"

  badging_file="$(mktemp)"
  dex_strings="$(mktemp)"
  trap 'rm -f "$badging_file" "$dex_strings"' EXIT
  "$build_tools/aapt" dump badging "$apk_path" > "$badging_file"
  grep -Fq "package: name='com.sentongoharuna.worldsituationroom' versionCode='25'" "$badging_file"
  grep -Fq "sdkVersion:'23'" "$badging_file"
  grep -Fq "targetSdkVersion:'35'" "$badging_file"
  grep -Fq "application-label:'du-world moniter'" "$badging_file"
  "$build_tools/apksigner" verify --verbose "$apk_path" >/dev/null
  unzip -tq "$apk_path"

  while IFS= read -r dex; do
    unzip -p "$apk_path" "$dex" | strings >> "$dex_strings"
  done < <(unzip -Z1 "$apk_path" | grep -E '^classes[0-9]*\.dex$')

  for marker in \
    'SOURCE-AWARE' 'CROSS-SOURCE WATCH' 'CROSS-DOMAIN WATCH' 'NOT A FORECAST' \
    'FOLLOW ON SATELLITE MAP' 'SOURCE POSITION AGE' 'SHORT ESTIMATE ACTIVE' \
    'OpenSky Network' 'AISStream.io' 'RainViewer' 'NASA EONET' 'GDELT' 'USGS' \
    'Windy Webcams API' 'Radio Browser' 'IPTV-org' 'UNVERIFIED' 'REPORTED' \
    'CONFIRMED' 'PUBLIC SOURCE' 'LOCAL ON' 'TIME: 24H' 'REGIONAL LENS' \
    'PROXIMITY IS NOT CONFIRMATION' 'APP READY' 'PREPARING NATIVE COMMAND DECK' \
    'RADAR TIMELINE' 'OBSERVED SIGNAL PRESSURE' 'ON-DEVICE ANALYST' \
    'SOURCE REGISTRY' 'GKG THEME' 'MARKET RADAR' 'AVIATION FREQUENCY REFERENCE' \
    'du-world moniter' 'SHARE THIS PAGE AS CARD' 'SHARE CARD' \
    'LIVE INTELLIGENCE / SHARE CARD' 'FULL DETAILS INCLUDED IN THE SHARED TEXT' \
    'PINNED VIEWPORT' 'SATELLITE SYNC' 'SAT TRACK'; do
    grep -Fq -- "$marker" "$dex_strings" || {
      echo "Compiled APK is missing required R22 marker: $marker" >&2
      exit 1
    }
  done

  for class_name in \
    SatelliteMapView WorldDataRepository AisStreamClient NativeMediaActivity \
    SituationAnalyzer SignalBeaconView RegionalFocus CountrySituationEngine \
    MovementAnalyzer ShareCardData ShareCardRenderer ShareCardProvider; do
    grep -Fq "Lcom/sentongoharuna/worldsituationroom/$class_name;" "$dex_strings" || {
      echo "Compiled APK is missing native class: $class_name" >&2
      exit 1
    }
  done

  if grep -Ei 'android/webkit/WebView|chatgpt\.site|github\.io/Sentongoharuna' "$dex_strings"; then
    echo "Compiled APK contains forbidden hosted-site or WebView code." >&2
    exit 1
  fi
fi

echo "R22 stable-map, universal-share-card and complete-operations contract passed."
