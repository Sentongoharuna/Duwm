#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$P/app/src/main/AndroidManifest.xml"
for f in DuSceneStore.java DuScenePlaybackActivity.java DuSceneDirectorActivity.java;do test -s "$J/$f";done
grep -F 'DuSelectionState.system(c)' "$J/DuSceneStore.java" >/dev/null
grep -F 'DuSpatialState.sensor(c)' "$J/DuSceneStore.java" >/dev/null
grep -F '"ADD CURRENT","PLAY","SHARE PLAN"' "$J/DuSceneDirectorActivity.java" >/dev/null
grep -F 'Collections.swap' "$J/DuSceneDirectorActivity.java" >/dev/null
grep -F 'DuSpatialState.sensor(this,s.sensor)' "$J/DuScenePlaybackActivity.java" >/dev/null
grep -F 'h.postDelayed(this' "$J/DuScenePlaybackActivity.java" >/dev/null
grep -F 'DuScenePlaybackActivity' "$M" >/dev/null
echo "DUWM2 SCENE DIRECTOR PASS"
