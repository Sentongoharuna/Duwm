#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuMonitorState.java DuOfflineActivity.java DuDeepLinkActivity.java DuLandscapeCommandActivity.java;do test -s "$J/$f";done
grep -F 'addTextChangedListener' "$J/DuSystemIndexActivity.java" >/dev/null
grep -F 'SharedPreferences' "$J/DuMonitorState.java" >/dev/null
grep -F 'SCREEN_ORIENTATION_SENSOR_LANDSCAPE' "$J/DuLandscapeCommandActivity.java" >/dev/null
grep -F 'android:scheme="duwm"' "$P/app/src/main/AndroidManifest.xml" >/dev/null
grep -F 'DuOfflineActivity.class' "$J/Du2More.java" >/dev/null
echo "DUWM2 FUNCTIONAL SOLUTIONS PASS"
