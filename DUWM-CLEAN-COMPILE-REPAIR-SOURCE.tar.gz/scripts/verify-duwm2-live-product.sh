#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuFreshness.java DuRefreshController.java DuObjectPayload.java DuShareRenderer.java DuMediaVisual.java;do test -s "$J/$f";done
grep -F 'Bitmap.createBitmap' "$J/DuShareRenderer.java" >/dev/null
grep -F 'FileProvider.getUriForFile' "$J/DuShareRenderer.java" >/dev/null
grep -F 'RENDER PNG & SHARE' "$J/DuShareStudioActivity.java" >/dev/null
grep -F 'DuObjectPayload.from' "$J/DuRecordDetailActivity.java" >/dev/null
grep -F 'DuFreshness.health' "$J/DuSourceHealthPageActivity.java" >/dev/null
grep -F 'androidx.core.content.FileProvider' "$P/app/src/main/AndroidManifest.xml" >/dev/null
test -s "$P/app/src/main/res/xml/du_file_paths.xml"
echo "DUWM2 LIVE PRODUCT PASS"
