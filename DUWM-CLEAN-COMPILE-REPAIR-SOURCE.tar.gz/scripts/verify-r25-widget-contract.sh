#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$root"

fail() {
  echo "R25 CONTRACT FAILURE: $*" >&2
  exit 1
}

manifest="app/src/main/AndroidManifest.xml"
java_root="app/src/main/java/com/sentongoharuna/worldsituationroom"

grep -Eq 'versionCode = 28' app/build.gradle.kts || fail "versionCode is not 28"
grep -Eq 'versionName = "25\.0-2026-home-intelligence"' app/build.gradle.kts \
  || fail "versionName is not R25 home intelligence"
grep -Eq 'minSdk = 23' app/build.gradle.kts || fail "API 23 support changed"

providers=(
  AlertBeacon LiveCounters LocalWatch BreakingWire
  AirSeaTracker HazardsWeather MediaWatch CommandCentre
)
descriptors=(
  alert counters local wire airsea hazards media command
)

for provider in "${providers[@]}"; do
  grep -Fq ".DuWidgetProviders\$$provider" "$manifest" \
    || fail "manifest provider missing: $provider"
  grep -Fq "class $provider extends BaseSituationWidgetProvider" \
    "$java_root/DuWidgetProviders.java" || fail "provider class missing: $provider"
done

for descriptor in "${descriptors[@]}"; do
  file="app/src/main/res/xml/widget_${descriptor}_info.xml"
  test -s "$file" || fail "widget descriptor missing: $file"
  grep -Eq 'android:configure="com\.sentongoharuna\.worldsituationroom\.WidgetConfigActivity"' \
    "$file" || fail "configuration activity missing from $file"
  grep -Eq 'android:resizeMode="horizontal\|vertical"' "$file" \
    || fail "responsive resize contract missing from $file"
  grep -Eq 'android:updatePeriodMillis="1800000"' "$file" \
    || fail "safe platform cadence missing from $file"
done

for required in \
  DuWidgetRenderer WidgetSnapshot WidgetGlobeRenderer DuWidgetPreferences \
  DuWidgetUpdater WidgetRefreshScheduler WidgetRefreshJobService \
  WidgetStateStore WidgetActionReceiver WidgetBootReceiver WidgetConfigActivity; do
  test -s "$java_root/$required.java" || fail "widget implementation missing: $required"
done

grep -Eq 'SOURCE.*UPDATED|UPDATED.*SOURCE|source\(c\.selected\)' \
  "$java_root/DuWidgetRenderer.java" || fail "source/timestamp disclosure removed"
grep -Eq 'UNVERIFIED|credibility' "$java_root/DuWidgetRenderer.java" \
  || fail "credibility state removed"
grep -Eq 'WIDGETS' "$java_root/MainActivity.java" \
  || fail "in-app widget deck is not visible"
grep -Eq 'requestPinAppWidget' "$java_root/MainActivity.java" \
  || fail "one-tap widget pinning is missing"
grep -Eq 'EXTRA_OPEN_CATALOG' "$java_root/MainActivity.java" \
  || fail "widget deep links are missing"
grep -Eq 'setPeriodic\(MINIMUM_PERIOD_MS\)' "$java_root/WidgetRefreshScheduler.java" \
  || fail "network-aware periodic refresh is missing"
grep -Eq 'ACQUISITION_WINDOW_MS = 27_000L' "$java_root/WidgetRefreshJobService.java" \
  || fail "bounded background acquisition is missing"

if grep -REn 'android\.webkit\.WebView|<WebView|loadUrl\(' app/src/main; then
  fail "WebView or hosted-app loading found in standalone native source"
fi

apk="${1:-}"
if test -n "$apk"; then
  test -s "$apk" || fail "APK not found: $apk"
  sdk_root="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
  test -n "$sdk_root" || fail "ANDROID_SDK_ROOT/ANDROID_HOME is required for APK checks"
  build_tools="$(find "$sdk_root/build-tools" -mindepth 1 -maxdepth 1 -type d \
    | sort -V | tail -n 1)"
  aapt="$build_tools/aapt"
  aapt2="$build_tools/aapt2"
  apksigner="$build_tools/apksigner"
  dexdump="$build_tools/dexdump"
  for tool in "$aapt" "$aapt2" "$apksigner" "$dexdump"; do
    test -x "$tool" || fail "required APK inspection tool missing: $tool"
  done

  badging="$($aapt dump badging "$apk")"
  grep -Eq "package: name='com\.sentongoharuna\.worldsituationroom'.*versionCode='28'.*versionName='25\.0-2026-home-intelligence'" \
    <<<"$badging" || fail "compiled package/version contract failed"
  grep -Eq "provides-component:'app-widget'" <<<"$badging" \
    || fail "APK is not advertising widgets"
  signature_report="$("$apksigner" verify --verbose "$apk")"
  grep -Eq 'Verified using v2 scheme.*true' <<<"$signature_report" \
    || fail "APK v2 signature verification failed"

  manifest_dump="$($aapt2 dump xmltree "$apk" --file AndroidManifest.xml)"
  for provider in "${providers[@]}"; do
    grep -Fq "DuWidgetProviders\$$provider" <<<"$manifest_dump" \
      || fail "compiled manifest provider missing: $provider"
  done
  for component in WidgetConfigActivity WidgetActionReceiver WidgetBootReceiver \
    WidgetRefreshJobService; do
    grep -Fq "$component" <<<"$manifest_dump" \
      || fail "compiled component missing: $component"
  done

  inspect_dir="$(mktemp -d)"
  trap 'test -n "${inspect_dir:-}" && test -d "$inspect_dir" && rm -rf -- "$inspect_dir"' EXIT
  unzip -q "$apk" 'classes*.dex' -d "$inspect_dir"
  dex_dump="$({ for dex in "$inspect_dir"/classes*.dex; do "$dexdump" -f "$dex"; done; })"
  for provider in "${providers[@]}"; do
    grep -Fq "DuWidgetProviders\$$provider;" <<<"$dex_dump" \
      || fail "compiled provider class missing: $provider"
  done
  for component in DuWidgetRenderer WidgetSnapshot WidgetConfigActivity \
    WidgetRefreshJobService; do
    grep -Fq "/$component;" <<<"$dex_dump" \
      || fail "compiled widget class missing: $component"
  done
fi

echo "R25 CONTRACT PASS: standalone native app + eight advanced source-aware widgets"
