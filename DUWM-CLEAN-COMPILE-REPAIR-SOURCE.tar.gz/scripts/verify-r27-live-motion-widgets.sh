#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$root"

fail() {
  echo "R27 LIVE MOTION WIDGET FAILURE: $*" >&2
  exit 1
}

manifest="app/src/main/AndroidManifest.xml"
java_root="app/src/main/java/com/sentongoharuna/worldsituationroom"
expected_version_code="${EXPECTED_VERSION_CODE:-30}"
expected_version_name="${EXPECTED_VERSION_NAME:-27.0-2026-live-motion-widgets}"

grep -Fq "versionCode = $expected_version_code" app/build.gradle.kts \
  || fail "versionCode is not $expected_version_code"
grep -Fq "versionName = \"$expected_version_name\"" app/build.gradle.kts \
  || fail "versionName is not $expected_version_name"
grep -Eq 'minSdk = 23' app/build.gradle.kts || fail "API 23 support changed"

providers=(
  AlertBeacon LiveCounters LocalWatch BreakingWire
  AirSeaTracker HazardsWeather MediaWatch CommandCentre
)
descriptors=(
  alert counters local wire airsea hazards media command
)

for provider in "${providers[@]}"; do
  grep -Fq ".DuWidgetProviders\$$provider" "$manifest" \
    || fail "manifest provider missing: $provider"
  grep -Fq "class $provider extends BaseSituationWidgetProvider" \
    "$java_root/DuWidgetProviders.java" || fail "provider class missing: $provider"
done

for descriptor in "${descriptors[@]}"; do
  file="app/src/main/res/xml/widget_${descriptor}_info.xml"
  test -s "$file" || fail "widget descriptor missing: $file"
  grep -Eq 'android:configure="com\.sentongoharuna\.worldsituationroom\.WidgetConfigActivity"' \
    "$file" || fail "configuration activity missing from $file"
  grep -Eq 'android:resizeMode="horizontal\|vertical"' "$file" \
    || fail "responsive resize contract missing from $file"
  grep -Eq 'android:updatePeriodMillis="1800000"' "$file" \
    || fail "safe platform cadence missing from $file"
  grep -Fq "android:previewLayout=\"@layout/widget_preview_${descriptor}\"" "$file" \
    || fail "scalable picker preview missing from $file"
  grep -Fq "android:previewImage=\"@drawable/widget_preview_${descriptor}\"" "$file" \
    || fail "Android 15+ preview fallback missing from $file"
  test -s "app/src/main/res/layout/widget_preview_${descriptor}.xml" \
    || fail "preview layout missing: $descriptor"
  test -s "app/src/main/res/drawable-nodpi/widget_preview_${descriptor}.png" \
    || fail "preview image missing: $descriptor"
done

runtime_layouts=(widget_micro widget_bar widget_panel widget_command_center widget_safe_fallback)
for runtime in "${runtime_layouts[@]}"; do
  file="app/src/main/res/layout/${runtime}.xml"
  test -s "$file" || fail "runtime layout missing: $file"
  if grep -Eq '<(View|Space)([[:space:]>])' "$file"; then
    fail "unsupported RemoteViews element remains in $file"
  fi
done

motion_layouts=(widget_micro widget_bar widget_panel widget_command_center)
for runtime in "${motion_layouts[@]}"; do
  file="app/src/main/res/layout/${runtime}.xml"
  grep -Fq '<ViewFlipper' "$file" || fail "live rotor missing from $file"
  grep -Fq 'android:autoStart="true"' "$file" || fail "auto-start motion missing from $file"
  grep -Fq '<TextClock' "$file" || fail "seconds clock missing from $file"
  grep -Fq '@+id/widget_pulse' "$file" || fail "independent signal pulse missing from $file"
done

grep -Fq '@+id/widget_globe_motion' app/src/main/res/layout/widget_command_center.xml \
  || fail "command globe motion surface is missing"
for phase in {0..7}; do
  test -s "app/src/main/res/drawable/widget_globe_motion_${phase}.xml" \
    || fail "rotating globe phase missing: $phase"
  grep -Fq "@drawable/widget_globe_motion_${phase}" \
    app/src/main/res/layout/widget_command_center.xml \
    || fail "rotating globe phase is not wired: $phase"
done

for required in \
  DuWidgetRenderer WidgetSnapshot WidgetGlobeRenderer DuWidgetPreferences \
  DuWidgetUpdater WidgetRefreshScheduler WidgetRefreshJobService \
  WidgetStateStore WidgetActionReceiver WidgetBootReceiver WidgetConfigActivity; do
  test -s "$java_root/$required.java" || fail "widget implementation missing: $required"
done

grep -Eq 'SOURCE.*UPDATED|UPDATED.*SOURCE|source\(c\.selected\)' \
  "$java_root/DuWidgetRenderer.java" || fail "source/timestamp disclosure removed"
grep -Eq 'UNVERIFIED|credibility' "$java_root/DuWidgetRenderer.java" \
  || fail "credibility state removed"
grep -Eq 'WIDGETS' "$java_root/MainActivity.java" \
  || fail "in-app widget deck is not visible"
grep -Eq 'requestPinAppWidget' "$java_root/MainActivity.java" \
  || fail "one-tap widget pinning is missing"
grep -Eq 'EXTRA_OPEN_CATALOG' "$java_root/MainActivity.java" \
  || fail "widget deep links are missing"
grep -Eq 'setPeriodic\(MINIMUM_PERIOD_MS\)' "$java_root/WidgetRefreshScheduler.java" \
  || fail "network-aware periodic refresh is missing"
grep -Eq 'ACQUISITION_WINDOW_MS = 27_000L' "$java_root/WidgetRefreshJobService.java" \
  || fail "bounded background acquisition is missing"
grep -Eq 'setImageViewResource\(R\.id\.widget_dot' "$java_root/DuWidgetRenderer.java" \
  || fail "RemoteViews-safe signal indicator binding is missing"
grep -Fq 'setTextViewText(R.id.widget_counts_2' "$java_root/DuWidgetRenderer.java" \
  || fail "rotating source-health figures are missing"
grep -Fq 'setTextViewText(R.id.widget_counts_3' "$java_root/DuWidgetRenderer.java" \
  || fail "rotating media/weather figures are missing"
grep -Fq 'normalizeLongitude' "$java_root/DuWidgetRenderer.java" \
  || fail "time-phased globe orientation is missing"
grep -Eq 'renderStarting\(' "$java_root/DuWidgetRenderer.java" \
  || fail "safe launcher recovery surface is missing"
grep -Eq 'scheduleImmediate\(context\)' "$java_root/BaseSituationWidgetProvider.java" \
  || fail "first-add immediate acquisition is missing"

if grep -REn 'android\.webkit\.WebView|<WebView|loadUrl\(' app/src/main; then
  fail "WebView or hosted-app loading found in standalone native source"
fi

apk="${1:-}"
if test -n "$apk"; then
  test -s "$apk" || fail "APK not found: $apk"
  sdk_root="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
  test -n "$sdk_root" || fail "ANDROID_SDK_ROOT/ANDROID_HOME is required for APK checks"
  build_tools="$(find "$sdk_root/build-tools" -mindepth 1 -maxdepth 1 -type d \
    | sort -V | tail -n 1)"
  aapt="$build_tools/aapt"
  aapt2="$build_tools/aapt2"
  apksigner="$build_tools/apksigner"
  dexdump="$build_tools/dexdump"
  for tool in "$aapt" "$aapt2" "$apksigner" "$dexdump"; do
    test -x "$tool" || fail "required APK inspection tool missing: $tool"
  done

  badging="$($aapt dump badging "$apk")"
  grep -Fq "package: name='com.sentongoharuna.worldsituationroom' versionCode='$expected_version_code' versionName='$expected_version_name'" \
    <<<"$badging" || fail "compiled package/version contract failed"
  grep -Eq "provides-component:'app-widget'" <<<"$badging" \
    || fail "APK is not advertising widgets"
  signature_report="$("$apksigner" verify --verbose "$apk")"
  grep -Eq 'Verified using v2 scheme.*true' <<<"$signature_report" \
    || fail "APK v2 signature verification failed"

  manifest_dump="$($aapt2 dump xmltree "$apk" --file AndroidManifest.xml)"
  for provider in "${providers[@]}"; do
    grep -Fq "DuWidgetProviders\$$provider" <<<"$manifest_dump" \
      || fail "compiled manifest provider missing: $provider"
  done
  for component in WidgetConfigActivity WidgetActionReceiver WidgetBootReceiver \
    WidgetRefreshJobService; do
    grep -Fq "$component" <<<"$manifest_dump" \
      || fail "compiled component missing: $component"
  done

  inspect_dir="$(mktemp -d)"
  trap 'test -n "${inspect_dir:-}" && test -d "$inspect_dir" && rm -rf -- "$inspect_dir"' EXIT
  unzip -q "$apk" 'classes*.dex' -d "$inspect_dir"
  dex_dump="$({ for dex in "$inspect_dir"/classes*.dex; do "$dexdump" -f "$dex"; done; })"
  for provider in "${providers[@]}"; do
    grep -Fq "DuWidgetProviders\$$provider;" <<<"$dex_dump" \
      || fail "compiled provider class missing: $provider"
  done
  for component in DuWidgetRenderer WidgetSnapshot WidgetConfigActivity \
    WidgetRefreshJobService; do
    grep -Fq "/$component;" <<<"$dex_dump" \
      || fail "compiled widget class missing: $component"
  done

  resource_dump="$($aapt dump resources "$apk")"
  for descriptor in "${descriptors[@]}"; do
    grep -Fq "widget_preview_${descriptor}" <<<"$resource_dump" \
      || fail "compiled preview resource missing: $descriptor"
  done
  for phase in {0..7}; do
    grep -Fq "widget_globe_motion_${phase}" <<<"$resource_dump" \
      || fail "compiled rotating globe phase missing: $phase"
  done
fi

echo "R27 LIVE MOTION PASS: eight widgets + independent pulses + live clocks + rotating figures + animated globe"
