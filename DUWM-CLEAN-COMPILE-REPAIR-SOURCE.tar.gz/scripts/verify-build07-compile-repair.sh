#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";S="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/SatelliteMapView.java";H="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/DuIntegratedHomeActivity.java"
! grep -F 'setStrokeWidthduPx' "$S" >/dev/null
! grep -E '\bdp\([0-9]+\)' "$S" >/dev/null
! grep -F '}\n\n    private static String compactHudId' "$S" >/dev/null
grep -F 'paint.setStrokeWidth(duPx(1));' "$S" >/dev/null
grep -F 'private float duPx(float value)' "$S" >/dev/null
echo "BUILD07 COMPILE REPAIR VERIFIED"
