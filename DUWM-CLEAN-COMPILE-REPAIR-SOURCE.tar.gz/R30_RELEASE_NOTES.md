# DU World Monitor R30 — Crash Repair + Brand System

R30 keeps the R29 immersive Local Monitors feed, the R27 live-motion widget deck and the existing
native globe. This release concentrates on surviving damaged state, vendor media failures and late
network callbacks without sacrificing locally stored reports.

## Stability and recovery

- A process-level crash ledger stores a short local recovery reference. It never uploads a stack
  trace or personal report data.
- Two recent fatal launches automatically open the command deck in recovery mode with live network
  feeds paused. The local globe interface and saved Local Monitor records remain accessible.
- Main globe feed callbacks, analysis ticks and clock ticks now have UI isolation boundaries. A
  malformed provider response can be rejected without closing the whole app.
- Local Monitors has its own recovery screen and a safe video mode. A suspected media crash reopens
  report details without autoplay, then lets the user deliberately retry the video path.
- MediaPlayer callbacks are generation-bound. A completed callback from an older story can no
  longer control the new story after a swipe.
- Remote and local reporter avatars use bounded decoding plus a 4 MiB memory cache. Decode failures
  and low-memory conditions retain the initials avatar instead of taking down the feed.
- Network callbacks are cancelled and ignored after Local Monitors closes.
- SharedPreferences reads tolerate old values stored under the wrong type, covering the main app,
  provider settings, Local Monitor identity, report cache and all widget configuration/state.
- Camera imports, profile images, live-publisher handoff, sharing and shutdown paths now retain a
  usable error surface when the receiving phone component is missing or fails.

## Brand and marketing presentation

- The visible product name is **DU World Monitor**. The Android package remains
  `com.sentongoharuna.worldsituationroom`, so R30 upgrades the installed app rather than creating a
  second installation.
- A new globe-and-DU mark combines cyan global coverage lines, a gold monitoring orbit and a red
  live-source beacon.
- Modern Android launchers receive an adaptive icon; Android 6–7 devices retain a vector fallback.
- The startup deck, main header, Local Monitors header, widgets and native share cards use one
  coherent wordmark.
- Brand promise: **See the world. Hear the local witness.**
- Tapping the main wordmark opens a concise product story grounded in real functionality: global
  public-source layers, local reports, source health, timestamps and credibility labels.

## Truth and service boundary

R30 does not invent network users or streams. Cross-device profiles, comments, uploads and real
live publishing still require a separately configured public HTTPS service implementing the R30
Local Monitors API contract. New public reports continue to start as **UNVERIFIED**.
