# DUWM2 full integration
Single launcher: Integrated World Operations.
Primary globe remains preserved geographic engine.
Every built upgrade is reachable through dock, intelligence sheet, MORE, or ALL TOOLS.
All dedicated systems route through DuPageRouter.
Record context routes through DuObjectPayload/DuFlow/DuSelectionState.
Share uses PNG renderer.
Search, watchlist, offline, monitors, widgets, wallpaper, source health, command center and QA remain reachable.
Integration Status exposes READY/DELEGATED provider capabilities instead of hiding incomplete external adapters.
