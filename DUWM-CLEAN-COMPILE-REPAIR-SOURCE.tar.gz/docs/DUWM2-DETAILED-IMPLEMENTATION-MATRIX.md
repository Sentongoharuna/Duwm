# DUWM2 Detailed Implementation Matrix
Every visible function must satisfy:
1. PURPOSE: clear domain-specific job.
2. INPUT: system/record/source/place/time context when available.
3. PRESENTATION: domain-specific visual and telemetry labels.
4. STATE: HEALTHY/STALE/UNAVAILABLE/UNKNOWN with freshness.
5. ACTIONS: detail/source/map/follow/share only where meaningful.
6. ROUTING: dedicated page, never generic globe except explicit MAP/GLOBE.
7. RECOVERY: retry, sources, offline/cached path.
8. CONTEXT: selection preserved through detail/map/share/back.
9. HONESTY: missing provider values display unknown/dash; never invented.
10. NAVIGATION: BACK/GLOBE/CURRENT/NEXT and breadcrumbs where applicable.

Domain contracts:
AIR/AIRSPACE: track, heading, altitude, speed, source.
SEA: vessel, heading, route, position, source.
WX/AIRWX: condition, wind, pressure, hazard, freshness.
ORBIT: satellite, track/pass, status, source.
EVENTS/RISK: severity, place, timeline, related, source.
NEWS/WIRE: chronology, source/publisher, place/time, related, share.
MONITORS: reporter, media, location, history, follow/comment/map/share.
SOURCES: health, freshness, affected systems, retry.
MARKETS: movement, trend, freshness, related.
