#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
C="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/CanonicalObjectId.java"
S="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/Signal.java"
V="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/SatelliteMapView.java"
test -s "$C"
grep -F 'provider + layer + provider-native record id' "$C" >/dev/null
grep -F 'public final String canonicalId;' "$S" >/dev/null
grep -F 'CanonicalObjectId.of(source, layer, this.id)' "$S" >/dev/null
grep -F 's.canonicalId.hashCode()' "$V" >/dev/null
# Real provider-native IDs remain stable and are not replaced by coordinates/timestamps.
grep -F '"flight-" + icao' "$P/app/src/main/java/com/sentongoharuna/worldsituationroom/WorldDataRepository.java" >/dev/null
grep -F '"usgs-" + feature.optString("id"' "$P/app/src/main/java/com/sentongoharuna/worldsituationroom/WorldDataRepository.java" >/dev/null
grep -F '"orbit-" + record.catalogId' "$P/app/src/main/java/com/sentongoharuna/worldsituationroom/OrbitalPropagator.java" >/dev/null
grep -F '"news-"+n.id' "$P/app/src/main/java/com/sentongoharuna/worldsituationroom/NewsSignals.java" >/dev/null
"$P/scripts/verify-1-2-20-1-fix2.sh" "$P"
echo "1.2/20/2-1 CANONICAL OBJECT ID PASS"
