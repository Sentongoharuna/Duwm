#!/usr/bin/env python3
"""Generate and verify the compact Repair 2 workflow without modifying app/source bytes."""
from __future__ import annotations

import copy
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import textwrap
import zipfile

import yaml

ROOT = Path(__file__).resolve().parent
ORIGINAL = ROOT / "deliverables_1728_2_21_3_repair2"
OUTPUT = ROOT / "deliverables_1728_2_21_3_start_fix"
CHECKS = ROOT / "start_fix_21_3_checks"
NAME = "DUWM-1728.2-21-3-REPAIR2-APK.yml"
SOURCE_NAME = "DUWM-1728.2-21-3-REPAIR2-SOURCE.zip"
PROJECT_NAME = "DUWM-1728-2-21-3-ANDROID-SOURCE"
MANIFEST_NAME = "1728_2_21_3_SOURCE_SHA256.json"
SOURCE_SHA = "d2b1507dcccf2346aff415cd0951adbb15afc205c0e6bfca22abbcbd3b4b5c91"
MANIFEST_SHA = "edbffa497d78f20cc1c643efb1644f201cfacda82d87e7127b39e8915e9b7d32"
ORIGINAL_WORKFLOW_SHA = "dae3683fc9af520e284442e5aaffefb1485bda220cfee51b3f503aa4831995ca"
MAXIMUM_WORKFLOW_BYTES = 250_000
ACTIONLINT = ROOT / "android-toolchain/actionlint-1.7.12/actionlint"

RESTORE_RUN = textwrap.dedent(r"""
    set -euo pipefail
    python3 - <<'PY_RESTORE'
    import hashlib,json,os,pathlib,stat,tempfile,zipfile
    source=pathlib.Path('DUWM-1728.2-21-3-REPAIR2-SOURCE.zip')
    expected_zip='d2b1507dcccf2346aff415cd0951adbb15afc205c0e6bfca22abbcbd3b4b5c91'
    expected_manifest='edbffa497d78f20cc1c643efb1644f201cfacda82d87e7127b39e8915e9b7d32'
    project_name='DUWM-1728-2-21-3-ANDROID-SOURCE'
    manifest_name='1728_2_21_3_SOURCE_SHA256.json'
    # This compact workflow requires the full matching Repair 2 ZIP at the
    # repository root. No predecessor archive or embedded patch is used.
    if source.is_symlink() or not source.is_file():
        raise SystemExit('Missing required regular file: '+source.name+' at the repository root. This compact workflow requires the full Repair 2 source ZIP; older source archives are not a fallback.')
    actual_zip=hashlib.sha256(source.read_bytes()).hexdigest()
    if actual_zip!=expected_zip:
        raise SystemExit('Repair 2 source ZIP SHA-256 mismatch: expected '+expected_zip+', got '+actual_zip+'. Upload the matching full Repair 2 source ZIP; older archives cannot replace it.')
    runner_temp=pathlib.Path(os.environ['RUNNER_TEMP']).resolve()
    root=pathlib.Path(tempfile.mkdtemp(prefix='duwm1728221-3-start-fix-',dir=runner_temp))
    project=root/project_name
    project.mkdir()
    def safe_target(name):
        rel=pathlib.PurePosixPath(name)
        if not rel.parts or rel.is_absolute() or '..' in rel.parts or chr(92) in name or rel.as_posix()!=name:
            raise ValueError('Unsafe or noncanonical source path: '+name)
        target=project.joinpath(*rel.parts)
        if not target.resolve().is_relative_to(project):
            raise ValueError('Source path escapes isolated project: '+name)
        return target
    with zipfile.ZipFile(source) as archive:
        if archive.testzip() is not None:raise ValueError('Corrupt Repair 2 source ZIP')
        seen=set()
        for info in archive.infolist():
            rel=pathlib.PurePosixPath(info.filename)
            if not rel.parts or rel.is_absolute() or '..' in rel.parts or chr(92) in info.filename or rel.parts[0]!=project_name:
                raise ValueError('Unsafe or unexpected source ZIP root')
            mode=info.external_attr>>16
            if stat.S_ISLNK(mode) or (stat.S_IFMT(mode) not in (0,stat.S_IFREG,stat.S_IFDIR)):
                raise ValueError('Source ZIP links and special files are rejected')
            canonical=rel.as_posix()+('/' if info.is_dir() else '')
            if info.filename!=canonical:raise ValueError('Noncanonical source ZIP member')
            if info.filename in seen:raise ValueError('Duplicate source ZIP member')
            seen.add(info.filename)
            if info.is_dir():continue
            if len(rel.parts)<2:raise ValueError('Source file has no project-relative path')
            target=safe_target('/'.join(rel.parts[1:]))
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(archive.read(info))
    manifest=project/manifest_name
    if hashlib.sha256(manifest.read_bytes()).hexdigest()!=expected_manifest:
        raise ValueError('Repair 2 source manifest SHA-256 mismatch')
    expected=json.loads(manifest.read_text(encoding='utf-8'))
    if not isinstance(expected,dict) or not expected:raise ValueError('Invalid source manifest')
    for name,want in expected.items():
        target=safe_target(name)
        if not target.is_file() or target.is_symlink() or hashlib.sha256(target.read_bytes()).hexdigest()!=want:
            raise ValueError('Source integrity failed: '+name)
    actual={p.relative_to(project).as_posix() for p in project.rglob('*') if p.is_file()}
    if actual!=set(expected)|{manifest_name}:raise ValueError('Unexpected or missing source files')
    print('PASS exact /21/3 Repair 2 full source:',len(expected),'packaged file hashes; no predecessor fallback')
    with open(os.environ['GITHUB_ENV'],'a',encoding='utf-8') as env:
        env.write('PROJECT='+str(project)+'\n')
        env.write('BUILD_LOG_DIR='+str(runner_temp/'duwm1728221-3-logs')+'\n')
    PY_RESTORE
""").lstrip()


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def replace_top_block(text: str, key: str, replacement: str) -> str:
    begin = re.search(r"(?m)^['\"]?" + re.escape(key) + r"['\"]?:(?:\n|[^\n]*\n)", text)
    require(begin is not None, "Missing top-level key: " + key)
    after = re.search(r"(?m)^[A-Za-z][A-Za-z0-9_-]*:", text[begin.end():])
    end = begin.end() + after.start() if after else len(text)
    return text[:begin.start()] + replacement + text[end:]


def replace_restore(text: str, name: str, run: str) -> str:
    starts = list(re.finditer(r"(?m)^( *)- name: ([^\n]*)\n", text))
    selected = [item for item in starts if item.group(2).startswith("Restore exact Repair 2")]
    require(len(selected) == 1, "Expected exactly one original restoration step")
    begin = selected[0]
    indent = begin.group(1)
    end = next((item.start() for item in starts if item.start() > begin.start() and item.group(1) == indent), len(text))
    step = indent + "- name: " + name + "\n" + indent + "  shell: bash\n" + indent + "  run: |\n"
    step += "".join(indent + "    " + line + "\n" for line in run.splitlines())
    return text[:begin.start()] + step + text[end:]


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    CHECKS.mkdir(parents=True, exist_ok=True)
    original_bytes = (ORIGINAL / NAME).read_bytes()
    source = ORIGINAL / SOURCE_NAME
    require(sha(original_bytes) == ORIGINAL_WORKFLOW_SHA, "Original workflow changed")
    require(sha(source.read_bytes()) == SOURCE_SHA, "Source ZIP changed")
    original = yaml.load(original_bytes, Loader=yaml.BaseLoader)
    replacement = {"name": "Restore exact full Repair 2 source ZIP (required)", "shell": "bash", "run": RESTORE_RUN}
    restore_index = next(i for i, step in enumerate(original["jobs"]["compile-development"]["steps"]) if step.get("name", "").startswith("Restore exact Repair 2"))
    old_restore = original["jobs"]["compile-development"]["steps"][restore_index]
    payload_keys = [key for key in old_restore.get("env", {}) if key.startswith("DUWM_PATCH_")]
    require(len(payload_keys) == 42, "Expected exactly 42 original embedded payload values")
    branch_names = original["on"]["push"]["branches"]
    new_on = copy.deepcopy(original["on"])
    new_on["push"]["paths"] = [".github/workflows/" + NAME, SOURCE_NAME]
    on_text = "'on':\n  workflow_dispatch: {}\n  push:\n    branches:\n"
    on_text += "".join("      - " + value + "\n" for value in branch_names)
    on_text += "    paths:\n" + "".join("      - " + value + "\n" for value in new_on["push"]["paths"])
    text = replace_restore(original_bytes.decode("utf-8"), replacement["name"], RESTORE_RUN)
    text = replace_top_block(text, "on", on_text)
    new_name = original["name"] + " | Start fix"
    new_run_name = original["run-name"] + " | Start fix"
    text = re.sub(r"(?m)^name: [^\n]*$", lambda _: "name: " + json.dumps(new_name), text, count=1)
    text = re.sub(r"(?m)^run-name: [^\n]*$", lambda _: "run-name: " + json.dumps(new_run_name), text, count=1)
    text = "# Compact workflow: requires the exact full Repair 2 SOURCE.zip at the repository root.\n# No predecessor recovery payload is embedded; all build and native verification gates are retained.\n" + text
    final_bytes = text.encode("utf-8")
    require(len(final_bytes) <= MAXIMUM_WORKFLOW_BYTES, "Workflow exceeds the conservative 250000-byte generation budget")
    require("DUWM_PATCH_" not in text, "Embedded predecessor payload remains")
    final = yaml.load(final_bytes, Loader=yaml.BaseLoader)
    expected = copy.deepcopy(original)
    expected["name"], expected["run-name"], expected["on"] = new_name, new_run_name, new_on
    expected["jobs"]["compile-development"]["steps"][restore_index] = replacement
    require(final == expected, "Unexpected change outside restoration, trigger paths, and display/run names")
    unchanged_steps = []
    for job_name, job in original["jobs"].items():
        for index, step in enumerate(job["steps"]):
            if job_name == "compile-development" and index == restore_index:
                continue
            require(step == final["jobs"][job_name]["steps"][index], "Changed CI step: " + step.get("name", str(index)))
            unchanged_steps.append({"job": job_name, "step": step.get("name", str(index)), "run_sha256": sha(step["run"].encode()) if "run" in step else None})
    output = OUTPUT / NAME
    output.write_bytes(final_bytes)
    with zipfile.ZipFile(source) as archive:
        manifest_bytes = archive.read(PROJECT_NAME + "/" + MANIFEST_NAME)
    require(sha(manifest_bytes) == MANIFEST_SHA, "Pinned source manifest changed")
    expected_files = json.loads(manifest_bytes)
    cases = []
    prior = ROOT / "deliverables_1728_2_21_3_repair1/DUWM-1728.2-21-3-CLEAR-PICTURE-SOURCE.zip"
    for case in ("exact-full-source", "corrupt-source", "missing-source", "missing-source-with-known-predecessor"):
        case_root = Path(tempfile.mkdtemp(prefix=case + "-", dir=CHECKS))
        repo, runner_temp = case_root / "repo", case_root / "runner-temp"
        repo.mkdir(); runner_temp.mkdir()
        github_env = case_root / "GITHUB_ENV"
        github_env.write_text("")
        if case in ("exact-full-source", "corrupt-source"):
            shutil.copyfile(source, repo / SOURCE_NAME)
            if case == "corrupt-source":
                broken = bytearray((repo / SOURCE_NAME).read_bytes())
                broken[len(broken) // 2] ^= 1
                (repo / SOURCE_NAME).write_bytes(broken)
        if case == "missing-source-with-known-predecessor":
            shutil.copyfile(prior, repo / prior.name)
        env = os.environ.copy()
        env.update(RUNNER_TEMP=str(runner_temp), GITHUB_ENV=str(github_env))
        result = subprocess.run(["bash", "-e", "-o", "pipefail", "-c", final["jobs"]["compile-development"]["steps"][restore_index]["run"]], cwd=repo, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        log_name = case.upper() + ".txt"
        (OUTPUT / log_name).write_text(result.stdout, encoding="utf-8")
        facts = {"case": case, "exit_code": result.returncode, "log": log_name}
        if case == "exact-full-source":
            require(result.returncode == 0, result.stdout)
            values = dict(line.split("=", 1) for line in github_env.read_text().splitlines())
            project = Path(values["PROJECT"])
            require(project.is_relative_to(runner_temp) and project.name == PROJECT_NAME, "Restoration escaped its isolated runner directory")
            require(sha((project / MANIFEST_NAME).read_bytes()) == MANIFEST_SHA, "Restored manifest differs")
            require({p.relative_to(project).as_posix() for p in project.rglob("*") if p.is_file()} == set(expected_files) | {MANIFEST_NAME}, "Restored file set differs")
            for name, digest in expected_files.items():
                require(sha((project / name).read_bytes()) == digest, "Independent restored hash mismatch: " + name)
            facts.update(result="PASS", manifest_sha256=MANIFEST_SHA, independently_verified_files=len(expected_files), total_restored_files=len(expected_files) + 1, exact_file_set=True, isolated_runner_temp=True)
        else:
            require(result.returncode != 0, "Invalid source was accepted: " + case)
            require(github_env.read_text() == "", "Invalid source exported PROJECT")
            phrase = "SHA-256 mismatch" if case == "corrupt-source" else "Missing required regular file"
            require(phrase in result.stdout, "Unexpected failure reason: " + result.stdout)
            facts.update(result="REJECTED", project_exported=False, explicit_expected_failure=True)
        cases.append(facts)
    lint = subprocess.run([str(ACTIONLINT), str(output)], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (OUTPUT / "ACTIONLINT.txt").write_text(lint.stdout, encoding="utf-8")
    require(lint.returncode == 0, lint.stdout)
    require(sha(source.read_bytes()) == SOURCE_SHA and sha((ORIGINAL / NAME).read_bytes()) == ORIGINAL_WORKFLOW_SHA, "Frozen input changed during validation")
    package = json.loads((ORIGINAL / "1728_2_21_3_PACKAGE_VERIFICATION.json").read_text())
    stages = package["required_native_stages"]
    require(len(stages) == 19 and final["jobs"]["native-broadcast-tests"] == original["jobs"]["native-broadcast-tests"], "Native stage/gate configuration changed")
    validation = {
        "schema": 1, "status": "PASS", "scope": "WORKFLOW_ONLY_START_FIX; no app/source changes or new APK/native execution",
        "workflow": NAME, "original_workflow_bytes": len(original_bytes), "original_workflow_sha256": ORIGINAL_WORKFLOW_SHA,
        "workflow_bytes": len(final_bytes), "workflow_sha256": sha(final_bytes), "generation_size_cap_bytes": MAXIMUM_WORKFLOW_BYTES,
        "under_preferred_25000_bytes": len(final_bytes) < 25_000, "github_documented_workflow_limit": "500 KB", "limits_source": "https://docs.github.com/en/actions/reference/limits",
        "removed_embedded_payload_values": len(payload_keys), "removed_embedded_payload_value_bytes": sum(len(old_restore["env"][key].encode()) for key in payload_keys),
        "source_zip": SOURCE_NAME, "source_zip_bytes": source.stat().st_size, "source_zip_sha256": SOURCE_SHA, "source_zip_unchanged": True,
        "manifest_sha256": MANIFEST_SHA, "full_matching_source_zip_required": True, "predecessor_fallback": False,
        "workflow_display_name": new_name, "run_name": new_run_name, "push_branches": branch_names, "push_paths": new_on["push"]["paths"], "manual_dispatch_retained": "workflow_dispatch" in final["on"],
        "allowed_structural_changes_only": True, "allowed_changes": ["Restoration step", "Push paths", "Workflow and run display names"],
        "unchanged_non_restore_steps": unchanged_steps, "native_job_structurally_identical": True, "required_native_stages": stages,
        "restoration_cases": cases, "actionlint": {"exit_code": lint.returncode, "tool_sha256": sha(ACTIONLINT.read_bytes()), "workflow_sha256": sha(final_bytes)},
        "generator": Path(__file__).name, "generator_sha256": sha(Path(__file__).read_bytes()),
        "historical_large_workflow_packager_used": False, "github_run_dispatched": False, "github_admission_verified": False, "app_tests_rerun": False, "apk_built": False, "repaired_native_execution": False,
    }
    (OUTPUT / "START-FIX-VALIDATION.json").write_text(json.dumps(validation, indent=2) + "\n", encoding="utf-8")
    summary = f"""Repair 2 workflow-only start fix: PASS

Workflow: {NAME}
Original workflow: {len(original_bytes):,} bytes; SHA-256 {ORIGINAL_WORKFLOW_SHA}
Compact workflow: {len(final_bytes):,} bytes; SHA-256 {sha(final_bytes)}
Generator budget: {MAXIMUM_WORKFLOW_BYTES:,} bytes, below the documented 500 KB service limit.
Official limit: https://docs.github.com/en/actions/reference/limits

The exact full source ZIP {SOURCE_NAME} is REQUIRED at the repository root.
It is unchanged: {source.stat().st_size:,} bytes; SHA-256 {SOURCE_SHA}
This compact workflow does not use an older-source fallback or an embedded patch.
The supplied {Path(__file__).name} is the current compact-workflow generator.
The historical larger workflow packager inside the frozen source ZIP is not used by this loader.

Validation:
- Executed the actual generated restore step against the exact full source ZIP: PASS.
- Independently checked all {len(expected_files)} packaged file hashes, the pinned manifest hash, and exact {len(expected_files)+1}-file set.
- Corrupt ZIP, missing ZIP, and missing ZIP with a known older predecessor: all rejected before PROJECT was exported.
- Structural comparison: only restoration, trigger paths and display names changed.
- All {len(unchanged_steps)} other steps and the complete native job remain unchanged; all 19 native stages remain required.
- Actual actionlint: PASS.
- Frozen original workflow and full source ZIP hashes remained unchanged.

Upload this YAML as a replacement at .github/workflows/{NAME}.
Its own filename and the exact full source ZIP filename remain push triggers on the existing allowed branches, including main.
This is local workflow validation. No GitHub run, new APK, or repaired native execution is claimed.
"""
    (OUTPUT / "START-FIX-VALIDATION.txt").write_text(summary, encoding="utf-8")
    print(json.dumps({key: validation[key] for key in ("status", "workflow", "original_workflow_bytes", "workflow_bytes", "workflow_sha256", "source_zip_sha256", "allowed_structural_changes_only")}, indent=2))
    print("RESTORE CASES:", ", ".join(item["case"] + "=" + item["result"] for item in cases))
    print("ACTIONLINT: PASS; required native stages:", len(stages))


if __name__ == "__main__":
    main()
