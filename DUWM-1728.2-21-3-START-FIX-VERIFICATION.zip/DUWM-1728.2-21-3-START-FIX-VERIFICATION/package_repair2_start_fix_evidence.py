#!/usr/bin/env python3
"""Package the workflow-only startup correction and its scoped validation."""
from pathlib import Path
import copy
import hashlib
import json
import zipfile
import yaml

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'deliverables_1728_2_21_3_start_fix'
PRIOR = ROOT / 'deliverables_1728_2_21_3_repair2'
NAME = 'DUWM-1728.2-21-3-REPAIR2-APK.yml'
SOURCE = PRIOR / 'DUWM-1728.2-21-3-REPAIR2-SOURCE.zip'
WORKFLOW = OUT / NAME

def sha(data):
    return hashlib.sha256(data).hexdigest()

def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()

new_bytes = WORKFLOW.read_bytes()
old_bytes = (PRIOR / NAME).read_bytes()
source_bytes = SOURCE.read_bytes()
assert sha(old_bytes) == 'dae3683fc9af520e284442e5aaffefb1485bda220cfee51b3f503aa4831995ca'
assert sha(source_bytes) == 'd2b1507dcccf2346aff415cd0951adbb15afc205c0e6bfca22abbcbd3b4b5c91'
assert len(new_bytes) < 25000, 'The corrected workflow must remain comfortably below the service limit'
old = yaml.safe_load(old_bytes)
new = yaml.safe_load(new_bytes)
left, right = copy.deepcopy(old), copy.deepcopy(new)
for item in (left, right):
    for key in ('name', 'run-name', 'on'):
        item.pop(key, None)
    item['jobs']['compile-development']['steps'].pop(1)
assert left == right, 'Unrelated build, test, artifact or native-gate behavior changed'
assert new['on']['workflow_dispatch'] == {}
assert 'main' in new['on']['push']['branches']
assert '.github/workflows/' + NAME in new['on']['push']['paths']
assert 'DUWM_PATCH_' not in new_bytes.decode()

observation = json.loads((ROOT / 'github21_3_repair2_start_failure/OBSERVED-GITHUB-FAILURE.json').read_text())
assert observation['uploaded_source']['sha256'] == sha(source_bytes)
assert observation['uploaded_workflow']['sha256'] == sha(old_bytes)
assert observation['run']['jobs_created'] == 0
validation = json.loads((OUT / 'START-FIX-VALIDATION.json').read_text())
assert validation['status'] == 'PASS'
assert validation['workflow_sha256'] == sha(new_bytes)
assert validation['source_zip_sha256'] == sha(source_bytes)
assert validation['actionlint']['exit_code'] == 0

files = {}
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.suffix in {'.py', '.json', '.txt', '.md', '.yml'}:
        if path.name not in {'DELIVERY-FILES.json', 'EVIDENCE-PACKAGE-RESULT.json'}:
            files[path.name] = path.read_bytes()
files['OBSERVED-GITHUB-FAILURE.json'] = encoded(observation)
files['package_repair2_start_fix_evidence.py'] = Path(__file__).read_bytes()
generator = ROOT / validation['generator']
assert generator.parent == ROOT and sha(generator.read_bytes()) == validation['generator_sha256']
files[generator.name] = generator.read_bytes()
files['historical/OVERSIZED-WORKFLOW-DO-NOT-UPLOAD.txt'] = old_bytes
files['CURRENT-FILE-BINDINGS.json'] = encoded({
    'status': 'PASS', 'scope': 'Workflow-only startup fix; unchanged Repair2 Android source',
    'previous_workflow_bytes': len(old_bytes), 'previous_workflow_sha256': sha(old_bytes),
    'current_workflow_bytes': len(new_bytes), 'current_workflow_sha256': sha(new_bytes),
    'source_zip_bytes': len(source_bytes), 'source_zip_sha256': sha(source_bytes),
    'source_already_uploaded_exactly': True,
    'all_non_restoration_ci_steps_structurally_unchanged': True,
    'new_successful_github_run_verified': False, 'new_apk_created': False,
    'native_execution_for_repair2_verified': False,
})
files['README.txt'] = f'''DUWM 1728.2/21/3 Repair 2 - Actions startup fix

The exact workflow uploaded at commit 75a7d9e11bc0ba6e7a7168ab09bc81aa638c3262
was {len(old_bytes):,} bytes. GitHub documents a 500 KB workflow-file limit:
https://docs.github.com/en/actions/reference/limits
Run 42421574552 failed immediately and created zero jobs:
https://github.com/Sentongoharuna/Duwm/actions/runs/42421574552

The corrected YAML is {len(new_bytes):,} bytes. Its exact filename stays
{NAME}; replace that file in .github/workflows/ and commit to main.
The run display identifies the startup correction. Manual dispatch is retained.

The exact Repair 2 source ZIP is already in the repository. Its Git blob and
local SHA match. No source re-upload is needed. The corrected workflow now
requires that full source archive and checks its ZIP hash, source manifest and
every extracted file. Historical baseline patch recovery is not used.

The app source, Android build and all 19 mandatory native stages remain unchanged.
Only the restoration step, trigger declarations and display names may differ
from the supplied original YAML; every other CI step and setting was compared.

The included validation covers local workflow generation, exact-source restore,
failure handling and actionlint. It does not claim a new GitHub run, APK or
Android native success. The prior Repair 2 source/host verification remains
applicable to the unchanged source. Its old large workflow packaging receipts
describe the previous delivery; use this compact workflow and its included
generator for this startup correction.

GitHub rejected writes earlier with 403 Resource not accessible by integration;
this task performed repository reads and produced the corrected files locally.
An authorized repository user must commit the replacement to execute it.

CURRENT-FILE-BINDINGS.json binds this YAML to the unchanged source ZIP.
OBSERVED-GITHUB-FAILURE.json records the observed failure and diagnosis basis.
EVIDENCE-SHA256.json hashes every other member of this verification archive.
The included Python generator records its original workspace input layout.
The historical oversized workflow is retained under historical/ as a text
input for reproduction. It must not be uploaded as an active workflow.
'''.encode()
files['EVIDENCE-SHA256.json'] = encoded({k: sha(v) for k, v in sorted(files.items())})
target = OUT / 'DUWM-1728.2-21-3-START-FIX-VERIFICATION.zip'
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(files.items()):
        archive.writestr('DUWM-1728.2-21-3-START-FIX-VERIFICATION/' + name, data)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    for name, data in files.items():
        assert archive.read('DUWM-1728.2-21-3-START-FIX-VERIFICATION/' + name) == data
report = {'status': 'PASS', 'members': len(files), 'files': {
    p.name: {'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
    for p in (WORKFLOW, target)}}
(OUT / 'EVIDENCE-PACKAGE-RESULT.json').write_bytes(encoded(report))
print(json.dumps(report, indent=2))
