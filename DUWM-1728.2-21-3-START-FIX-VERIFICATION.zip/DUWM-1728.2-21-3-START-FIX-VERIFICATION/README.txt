DUWM 1728.2/21/3 Repair 2 - Actions startup fix

The exact workflow uploaded at commit 75a7d9e11bc0ba6e7a7168ab09bc81aa638c3262
was 514,655 bytes. GitHub documents a 500 KB workflow-file limit:
https://docs.github.com/en/actions/reference/limits
Run 42421574552 failed immediately and created zero jobs:
https://github.com/Sentongoharuna/Duwm/actions/runs/42421574552

The corrected YAML is 16,858 bytes. Its exact filename stays
DUWM-1728.2-21-3-REPAIR2-APK.yml; replace that file in .github/workflows/ and commit to main.
The run display identifies the startup correction. Manual dispatch is retained.

The exact Repair 2 source ZIP is already in the repository. Its Git blob and
local SHA match. No source re-upload is needed. The corrected workflow now
requires that full source archive and checks its ZIP hash, source manifest and
every extracted file. Historical baseline patch recovery is not used.

The app source, Android build and all 19 mandatory native stages remain unchanged.
Only the restoration step, trigger declarations and display names may differ
from the supplied original YAML; every other CI step and setting was compared.

The included validation covers local workflow generation, exact-source restore,
failure handling and actionlint. It does not claim a new GitHub run, APK or
Android native success. The prior Repair 2 source/host verification remains
applicable to the unchanged source. Its old large workflow packaging receipts
describe the previous delivery; use this compact workflow and its included
generator for this startup correction.

GitHub rejected writes earlier with 403 Resource not accessible by integration;
this task performed repository reads and produced the corrected files locally.
An authorized repository user must commit the replacement to execute it.

CURRENT-FILE-BINDINGS.json binds this YAML to the unchanged source ZIP.
OBSERVED-GITHUB-FAILURE.json records the observed failure and diagnosis basis.
EVIDENCE-SHA256.json hashes every other member of this verification archive.
The included Python generator records its original workspace input layout.
The historical oversized workflow is retained under historical/ as a text
input for reproduction. It must not be uploaded as an active workflow.
