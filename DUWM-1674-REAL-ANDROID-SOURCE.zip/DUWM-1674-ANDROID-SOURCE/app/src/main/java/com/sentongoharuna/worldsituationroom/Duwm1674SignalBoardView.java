package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.View;
import java.util.Locale;

/**
 * Eight genuine source-receipt freshness channels.
 * Brightness is a visual status effect, not a claim that a new observation arrived.
 * Unknown sources remain unlit. Tap to open full source health.
 */
public final class Duwm1674SignalBoardView extends View {
    private static final int N=8;
    private static final long ONE_HOUR=3600000L;
    private final Paint ink=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final String[] labels=new String[N];
    private final long[] received=new long[N];
    private final boolean[] usable=new boolean[N];
    private final boolean[] historical=new boolean[N];
    private boolean animated;
    public Duwm1674SignalBoardView(Context c){
        super(c);setContentDescription("Eight source receipt freshness channels. Tap for provider health details.");
        for(int i=0;i<N;i++)labels[i]="SRC "+(i+1);
        setClickable(true);
    }
    private float dp(float v){return v*getResources().getDisplayMetrics().density;}
    public void update(){
        for(int i=0;i<N;i++){
            RunningballV25Sources.Result r=RunningballV25Sources.read(getContext(),i);
            labels[i]=r.key==null?"SRC "+(i+1):r.key.toUpperCase(Locale.US);
            received[i]=r.fetchedAt;
            usable[i]=r.fetchedAt>0 && (r.status==RunningballV25Sources.Status.LIVE || r.status==RunningballV25Sources.Status.DELAYED);
            historical[i]=r.fetchedAt>0 && !usable[i];
            // The newer native RSS collector and the public AIS desk have separate receipt caches.
            // Do not extinguish their lights simply because the legacy V17 source is empty.
            if(i==5){
                for(String feed:RunningballV25NewsRepository.KEYS){
                    if(RunningballV25NewsRepository.articles(getContext(),feed).length()<=0)continue;
                    long at=RunningballV25NewsRepository.last(getContext(),feed);
                    if(at>received[i]){received[i]=at;usable[i]=System.currentTimeMillis()-at<3600000L;historical[i]=!usable[i];}
                }
            }
            if(i==2){
                android.content.SharedPreferences p=getContext().getSharedPreferences("rb11_marine",Context.MODE_PRIVATE);
                long at=p.getLong("last_fetch",0L);
                try{
                    org.json.JSONObject o=new org.json.JSONObject(p.getString("rows","{}"));
                    org.json.JSONArray ships=o.optJSONArray("rows");
                    if(at>received[i] && ships!=null && ships.length()>0){
                        received[i]=at;usable[i]=System.currentTimeMillis()-at<1800000L;historical[i]=!usable[i];
                    }
                }catch(Exception ignored){}
            }
        }
        StringBuilder details=new StringBuilder("Source receipts: ");
        for(int i=0;i<N;i++){
            if(i>0)details.append(", ");
            details.append(labels[i]).append(usable[i]?" received":" unavailable");
        }
        setContentDescription(details.toString()+". Tap for last contact and any errors.");
        invalidate();
    }
    public void resume(){animated=true;update();postInvalidateDelayed(1000);}
    public void pause(){animated=false;}
    @Override protected void onDetachedFromWindow(){pause();super.onDetachedFromWindow();}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        float w=getWidth(),h=getHeight();if(w<=1||h<=1)return;
        ink.setStyle(Paint.Style.FILL);ink.setColor(0xFF0C2032);
        canvas.drawRoundRect(new RectF(0,0,w,h),dp(13),dp(13),ink);
        ink.setTextSize(dp(11));ink.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        ink.setColor(0xFFB3E4F6);canvas.drawText("LIVE SOURCE SIGNALS  /  8 CHANNELS",dp(12),dp(18),ink);
        ink.setTypeface(android.graphics.Typeface.DEFAULT);ink.setColor(0xFF8DB9CB);
        ink.setTextSize(dp(9));canvas.drawText("GREEN: recent receipt  •  AMBER: aged  •  GREY: none",dp(12),dp(33),ink);
        long now=System.currentTimeMillis();
        float cellW=(w-dp(22))/4f;
        float top=dp(41);float cellH=(h-top-dp(8))/2f;
        float cycle=(float)((1d+Math.sin(SystemClock.uptimeMillis()/350d))/2d);
        for(int i=0;i<N;i++){
            int row=i/4,column=i%4;
            float left=dp(11)+column*cellW;
            float y=top+row*cellH;
            long age=received[i]>0?Math.max(0,now-received[i]):Long.MAX_VALUE;
            boolean fresh=usable[i] && age<ONE_HOUR;
            boolean aged=received[i]>0&&!fresh;
            int color=fresh?0xFF37E7CE:aged?0xFFFFC078:0xFF6A8192;
            ink.setColor(0xFF112D42);
            canvas.drawRoundRect(new RectF(left+dp(2),y+dp(2),left+cellW-dp(2),y+cellH-dp(2)),dp(8),dp(8),ink);
            float cx=left+dp(16),cy=y+cellH*.39f;
            if(fresh){ink.setColor(0x4444EED7);canvas.drawCircle(cx,cy,dp(10f)+cycle*dp(3),ink);}
            ink.setColor(color);canvas.drawCircle(cx,cy,dp(6.5f)+(fresh?cycle*dp(.8f):0),ink);
            ink.setColor(0xFFEAF6FF);ink.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);ink.setTextSize(dp(9));
            String label=labels[i];if(label.length()>9)label=label.substring(0,8)+"…";
            canvas.drawText(label,left+dp(27),cy+dp(3),ink);
            ink.setColor(0xFFA9C9D5);ink.setTypeface(android.graphics.Typeface.DEFAULT);ink.setTextSize(dp(8));
            String ageText=received[i]<=0?"NO RECEIPT":age<60000?"< 1 MIN":age<ONE_HOUR?(age/60000)+" MIN":age<86400000?(age/ONE_HOUR)+" HOURS":(age/86400000)+" DAYS";
            canvas.drawText(ageText,left+dp(8),y+cellH-dp(8),ink);
        }
        if(animated)postInvalidateDelayed(600);
    }
}
