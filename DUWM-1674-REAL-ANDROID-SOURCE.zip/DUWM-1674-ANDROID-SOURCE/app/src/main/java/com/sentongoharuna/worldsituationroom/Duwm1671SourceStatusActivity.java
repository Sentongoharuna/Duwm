package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** True provider diagnostic board: last receipt, last known source time, state and error. */
public final class Duwm1671SourceStatusActivity extends Activity {
  private static final int BG=0xFF071521,CYAN=0xFF67D9E6,WHITE=0xFFEBF7FC,MUTED=0xFFACC5D0,AMBER=0xFFF3C382;
  private LinearLayout rows;private final Handler handler=new Handler(Looper.getMainLooper());private boolean foreground;
  private final Runnable ticker=new Runnable(){@Override public void run(){if(!foreground)return;render();handler.postDelayed(this,30000);}};
  private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}
  private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  private GradientDrawable bg(){GradientDrawable d=new GradientDrawable();d.setColor(0xFF102A3C);d.setCornerRadius(dp(10));d.setStroke(dp(1),0xFF365E72);return d;}
  private static String utc(long t){if(t<=0)return "NOT SUPPLIED";SimpleDateFormat f=new SimpleDateFormat("dd MMM HH:mm:ss 'UTC'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(t));}
  @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(BG);setContentView(scroll);Duwm1167SafeArea.install(this,scroll);
    LinearLayout root=new LinearLayout(this);root.setPadding(dp(14),dp(14),dp(14),dp(28));root.setOrientation(LinearLayout.VERTICAL);scroll.addView(root);
    root.addView(text("DEVELOP.UGANDA / VERIFIED PROVIDER MONITOR",12,CYAN,true));root.addView(text("SOURCE HEALTH   1672",26,WHITE,true));
    root.addView(text("A connected directory is not a live feed. 'Received' means the phone has a provider response. Stale and rate-limited receipts remain visible.",12,MUTED,false));
    TextView refresh=text("CHECK LOCAL CACHE AND REQUEST GLOBAL AIRCRAFT SOURCE",12,CYAN,true);refresh.setPadding(dp(12),dp(14),dp(12),dp(14));refresh.setGravity(Gravity.CENTER);refresh.setBackground(bg());root.addView(refresh);
    refresh.setOnClickListener(v->RunningballV25GlobalAircraftData.refreshNow(this,this::render));
    rows=new LinearLayout(this);rows.setOrientation(LinearLayout.VERTICAL);root.addView(rows);
    TextView globe=text("RETURN TO DETAILED MOVING GLOBE",12,CYAN,true);globe.setPadding(dp(12),dp(16),dp(12),dp(16));globe.setBackground(bg());root.addView(globe);globe.setOnClickListener(v->startActivity(new Intent(this,OperationsMainActivity.class)));
    render();
  }
  private void row(String header,String body,boolean ok){TextView t=text(header+"\n"+body,12,ok?WHITE:AMBER,true);t.setPadding(dp(13),dp(13),dp(13),dp(13));t.setBackground(bg());LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(8);rows.addView(t,lp);}
  private void render(){if(rows==null)return;rows.removeAllViews();RunningballV25GlobalAircraftData.Snapshot g=RunningballV25GlobalAircraftData.read(this);
    row("OPENSKY / WORLDWIDE AIRCRAFT","STATE "+g.status()+"\nPROVIDER REPORT: "+utc(g.sourceAt)+"\nLAST FETCH: "+utc(g.receivedAt)+"\nHTTP: "+g.lastHttp+"  /  NEXT ATTEMPT "+g.nextCheckLabel()+"\nVALID POSITIONS: "+(g.positionRows>=0?g.positionRows:"--")+(g.error.isEmpty()?"":"\nERROR: "+g.error),g.hasGood()&&g.ageMs()<3600000L&&g.error.isEmpty());
    for(int i=0;i<RunningballV25Sources.IDS.length;i++){RunningballV25Sources.Result r=RunningballV25Sources.read(this,i);
      boolean good=r.fetchedAt>0&&(r.status==RunningballV25Sources.Status.LIVE||r.status==RunningballV25Sources.Status.DELAYED);
      row(RunningballV25Sources.NAMES[i]+" / "+r.provider,
        "STATUS: "+r.status.toString().replace('_',' ')+"\nLAST FETCH: "+utc(r.fetchedAt)+"\nSOURCE TIME: "+utc(r.sourceTime)+"\nVALUE / COUNT: "+r.value+"\nCOVERAGE: "+r.coverage+
        (r.errorReason.isEmpty()?"":"\nERROR: "+r.errorReason),good);
    }
    int news=new NewsStore(this).load().size();int nativeNews=0;long nativeAt=0L;String failed="";
    for(String key:RunningballV25NewsRepository.KEYS){
      nativeNews+=RunningballV25NewsRepository.articles(this,key).length();
      nativeAt=Math.max(nativeAt,RunningballV25NewsRepository.last(this,key));
      if(failed.isEmpty())failed=RunningballV25NewsRepository.error(this,key);
    }
    org.json.JSONArray globalNews=RunningballV17Feeds.cached(this,RunningballV17Feeds.NEWS).optJSONArray("articles");
    int globalCount=globalNews==null?0:globalNews.length();
    row("REAL NEWS FEED RECEIPTS", "OLDER CACHE "+news+" · RSS/GDELT "+nativeNews+" · GLOBAL DW/GDELT "+globalCount+
      "\nLATEST NATIVE RECEIPT: "+utc(nativeAt)+(failed.isEmpty()?"":"\nLATEST FEED ERROR: "+failed)+
      "\nSource-directory websites are not counted as fetched articles.", news+nativeNews+globalCount>0);
    int ships=0,earth=0,iss=0;for(DuwmGeoObservationStore.Fix f:DuwmGeoObservationStore.read(this)){
      if("VESSEL".equals(f.type)||"VESSELS".equals(f.type))ships++;if("EARTHQUAKE".equals(f.type))earth++;if("ISS".equals(f.type))iss++;}
    row("LOCAL GEO OBSERVATION CACHE","Vessel fixes: "+ships+" · Earthquakes: "+earth+" · ISS: "+iss+". Figures are stored records, not global simultaneous totals.",ships+earth+iss>0);
  }
  @Override protected void onResume(){super.onResume();foreground=true;handler.post(ticker);}
  @Override protected void onPause(){foreground=false;handler.removeCallbacks(ticker);super.onPause();}
}
