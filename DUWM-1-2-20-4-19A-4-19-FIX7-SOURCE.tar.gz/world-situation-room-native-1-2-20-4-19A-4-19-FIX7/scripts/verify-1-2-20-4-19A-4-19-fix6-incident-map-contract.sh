#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
I="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/IncidentFormationEngine.java"

"$P/scripts/verify-1-2-20-4-19A-4-19-fix5-incident-bucket-compile-repair.sh" "$P"

grep -F 'LinkedHashMap<String,List<Signal>>groups=new LinkedHashMap<>()' "$I" >/dev/null
grep -F 'List<Signal> bucket=groups.get(key)' "$I" >/dev/null
grep -F 'Map.Entry<String,List<Signal>>e:groups.entrySet()' "$I" >/dev/null
! grep -F 'LinkedHashMap<String,ArrayList<Signal>>groups' "$I"
! grep -F 'Map.Entry<String,ArrayList<Signal>>' "$I"

echo "1.2/20/4.19A/4.19 FIX6 INCIDENT MAP/LIST CONTRACT PASS"
