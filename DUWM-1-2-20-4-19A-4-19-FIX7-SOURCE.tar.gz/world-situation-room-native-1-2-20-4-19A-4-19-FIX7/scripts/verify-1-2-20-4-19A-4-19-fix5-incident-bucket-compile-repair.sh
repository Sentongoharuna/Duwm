#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
I="$J/IncidentFormationEngine.java"

"$P/scripts/verify-1-2-20-4-19A-4-19-fix4-syntax-repair.sh" "$P"

grep -F 'List<Signal> bucket=groups.get(key)' "$I" >/dev/null
! grep -F 'ArrayList<Signal> bucket=groups.get(key)' "$I"

echo "1.2/20/4.19A/4.19 FIX5 INCIDENT BUCKET TYPE REPAIR PASS"
