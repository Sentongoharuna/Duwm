#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"; I="$P/app/src/main/java/com/sentongoharuna/worldsituationroom/IncidentFormationEngine.java"
"$P/scripts/verify-1-2-20-4-19A-4-19-fix6-incident-map-contract.sh" "$P"
grep -F 'LinkedHashMap<String,List<Signal>>groups' "$I" >/dev/null
grep -F 'List<Signal> bucket=groups.get(key)' "$I" >/dev/null
grep -F 'Map.Entry<String,List<Signal>>e:groups.entrySet()' "$I" >/dev/null
grep -F 'List<Signal>x=e.getValue();' "$I" >/dev/null
! grep -F 'ArrayList<Signal>x=e.getValue();' "$I"
echo "FIX7 COMPLETE INCIDENT LIST CONTRACT PASS"
