package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.graphics.Bitmap;
import android.widget.ImageView;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.content.Intent;
import android.app.AlertDialog;
import android.text.InputType;
import android.widget.Toast;
import java.io.File;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.text.TextWatcher;
import android.text.Editable;
import android.content.ActivityNotFoundException;
import android.media.MediaMetadataRetriever;
import android.provider.OpenableColumns;
import android.database.Cursor;
import java.util.Locale;
import android.widget.ScrollView;
import android.widget.TextView;

/** User-visible list of this installation's successful Gallery exports, not an artificial feed. */
public final class Duwm1726GalleryLibraryActivity extends Activity {
    private final ExecutorService thumbnails=Executors.newFixedThreadPool(2);
    private final Handler ui=new Handler(Looper.getMainLooper());
    private int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);}
    private TextView label(String value,int size){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size);
        t.setTextColor(DuwmUnifiedTheme.TEXT);t.setGravity(Gravity.CENTER_VERTICAL);
        t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        t.setPadding(dp(14),dp(10),dp(14),dp(10));return t;
    }
    /** Get only information available from the actual on-device recording. */
    private String metadata(Uri uri) {
        StringBuilder details=new StringBuilder("Saved to Gallery");
        try (Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.SIZE},null,null,null)) {
            if(c!=null && c.moveToFirst() && !c.isNull(0)) {
                long bytes=c.getLong(0);
                details.append(" • ").append(String.format(Locale.US,"%.1f MB",bytes/1048576.0));
            }
        } catch (Exception ignored) { /* A moved file is still shown, never fake metadata. */ }
        MediaMetadataRetriever retriever=new MediaMetadataRetriever();
        try {
            retriever.setDataSource(this,uri);
            String millis=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if(millis!=null) {
                long seconds=Long.parseLong(millis)/1000;
                details.append(" • ").append(seconds/60).append("m ").append(seconds%60).append("s");
            }
            String width=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
            String height=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
            if(width!=null && height!=null)details.append(" • ").append(width).append("×").append(height);
        } catch(Exception ignored) { /* Metadata may be inaccessible or incomplete. */ }
        finally {try{retriever.release();}catch(Exception ignored){}}
        return details.toString();
    }
    private void shareVideo(Uri uri) {
        try {
            Intent share=new Intent(Intent.ACTION_SEND);
            share.setType("video/mp4");
            share.putExtra(Intent.EXTRA_STREAM,uri);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share,"Share recorded video"));
        } catch(Exception e) {
            new android.app.AlertDialog.Builder(this).setTitle("Sharing unavailable")
                .setMessage("This recording cannot currently be shared from this device.")
                .setPositiveButton("OK",null).show();
        }
    }
    /** New clip is exported to Gallery; the original stays untouched. */
    private void trimVideo(Uri original){
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18),dp(4),dp(18),dp(4));
        EditText start=new EditText(this);start.setHint("Start seconds, e.g. 0");start.setInputType(InputType.TYPE_CLASS_NUMBER);start.setText("0");
        EditText stop=new EditText(this);stop.setHint("End seconds, e.g. 15");stop.setInputType(InputType.TYPE_CLASS_NUMBER);stop.setText("15");
        form.addView(start);form.addView(stop);
        new AlertDialog.Builder(this).setTitle("Trim MP4 / preserve original")
            .setMessage("Enter start and end times. Trimming is lossless; the first decodable keyframe may precede the requested start slightly.")
            .setView(form).setNegativeButton("CANCEL",null).setPositiveButton("EXPORT CLIP",(dialog,which)->{
                final long from,to;
                try{from=Long.parseLong(start.getText().toString())*1000L;to=Long.parseLong(stop.getText().toString())*1000L;}
                catch(NumberFormatException invalid){Toast.makeText(this,"Use numeric seconds",Toast.LENGTH_LONG).show();return;}
                new Thread(()->{
                    File temp=null;try{
                        temp=Duwm1728VideoTrim.trim(getApplicationContext(),original,from,to);
                        String name="DUWM_TRIM_"+System.currentTimeMillis()+".mp4";
                        Uri published=Duwm1724GalleryPublisher.publish(getApplicationContext(),temp,name);
                        Duwm1726GalleryIndex.add(getApplicationContext(),published,name);
                        runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Clip exported")
                            .setMessage("Saved a separate MP4 to your phone Gallery. The original was not modified.")
                            .setPositiveButton("OK",(d,w)->recreate()).show());
                    }catch(Exception ex){android.util.Log.e("DUWM-TRIM","Clip export failed",ex);
                        runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Trim failed")
                            .setMessage("The original recording remains unchanged. The requested range or codec may not be supported.")
                            .setPositiveButton("OK",null).show());
                    }finally{if(temp!=null)temp.delete();}
                },"duwm1728-lossless-trim").start();
            }).show();
    }
    @Override public void onCreate(Bundle b){super.onCreate(b);
        getWindow().setStatusBarColor(DuwmUnifiedTheme.APPROVED_NAVY);
        getWindow().setNavigationBarColor(DuwmUnifiedTheme.APPROVED_NAVY);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(DuwmUnifiedTheme.APPROVED_NAVY);
        root.setPadding(dp(12),dp(8),dp(12),dp(8));
        root.addView(label("MONITORS CAM  /  MY RECORDINGS",18));
        root.addView(label("Actual Gallery exports • search, play, share • device-only index",11));
        EditText search=new EditText(this);
        search.setSingleLine(true); search.setTextSize(14);
        search.setHint("Search saved recordings");
        search.setHintTextColor(DuwmUnifiedTheme.MUTED);
        search.setTextColor(DuwmUnifiedTheme.TEXT);
        search.setPadding(dp(14),dp(10),dp(14),dp(10));
        GradientDrawable searchBorder=new GradientDrawable();
        searchBorder.setColor(DuwmUnifiedTheme.APPROVED_NAVY);
        searchBorder.setStroke(dp(1),DuwmUnifiedTheme.BORDER);
        searchBorder.setCornerRadius(dp(20));search.setBackground(searchBorder);
        root.addView(search,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView count=label("",12);root.addView(count);
        ScrollView scroll=new ScrollView(this);
        LinearLayout cards=new LinearLayout(this);cards.setOrientation(LinearLayout.VERTICAL);
        scroll.setFillViewport(true);
        scroll.addView(cards);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));
        final java.util.List<String[]> recordings=Duwm1726GalleryIndex.list(this);
        final Runnable render=()->{
            cards.removeAllViews();String term=search.getText().toString().trim().toLowerCase(Locale.ROOT);
            int matches=0;
            for(String[] record:recordings){
                if(!record[1].toLowerCase(Locale.ROOT).contains(term))continue;
                matches++;
                final Uri uri=Uri.parse(record[0]);
                LinearLayout entry=new LinearLayout(this);entry.setOrientation(LinearLayout.VERTICAL);
                entry.setPadding(dp(5),dp(3),dp(5),dp(5));
                GradientDrawable bg=new GradientDrawable();bg.setColor(DuwmUnifiedTheme.APPROVED_NAVY);
                bg.setStroke(dp(1),DuwmUnifiedTheme.BORDER);bg.setCornerRadius(dp(19));
                entry.setBackground(bg);
                entry.addView(label("▶  "+record[1],14));
                ImageView thumbnail=new ImageView(this);
                thumbnail.setScaleType(ImageView.ScaleType.CENTER_CROP);
                thumbnail.setContentDescription("Thumbnail of original recorded MP4");
                thumbnail.setBackgroundColor(DuwmUnifiedTheme.APPROVED_NAVY);
                entry.addView(thumbnail,new LinearLayout.LayoutParams(-1,dp(122)));
                thumbnails.execute(()->{
                    Bitmap bitmap=null;MediaMetadataRetriever mmr=new MediaMetadataRetriever();
                    try{mmr.setDataSource(getApplicationContext(),uri);
                        bitmap=mmr.getFrameAtTime(500000L,MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                    }catch(Exception ignored){}finally{try{mmr.release();}catch(Exception ignored){}}
                    final Bitmap frame=bitmap;
                    ui.post(()->{if(!isFinishing() && !isDestroyed() && thumbnail.getParent()!=null){
                        if(frame!=null)thumbnail.setImageBitmap(frame);
                        else thumbnail.setContentDescription("Preview unavailable; tap PLAY for the original video");
                    }else if(frame!=null)frame.recycle();});
                });
                TextView detail=label(metadata(uri),11);detail.setTextColor(DuwmUnifiedTheme.MUTED);
                entry.addView(detail);
                LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
                TextView play=label("PLAY",13);play.setGravity(Gravity.CENTER);
                TextView share=label("SHARE",13);share.setGravity(Gravity.CENTER);
                TextView trim=label("TRIM",13);trim.setGravity(Gravity.CENTER);
                TextView edit=label("EDIT",13);edit.setGravity(Gravity.CENTER);
                actions.addView(play,new LinearLayout.LayoutParams(0,dp(50),1f));
                actions.addView(share,new LinearLayout.LayoutParams(0,dp(50),1f));
                actions.addView(trim,new LinearLayout.LayoutParams(0,dp(50),1f));
                actions.addView(edit,new LinearLayout.LayoutParams(0,dp(50),1f));
                play.setOnClickListener(v->{try{
                    Intent view=new Intent(Intent.ACTION_VIEW);
                    view.setDataAndType(uri,"video/mp4");
                    view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(view);
                }catch(Exception e){new android.app.AlertDialog.Builder(this)
                    .setTitle("Video unavailable")
                    .setMessage("The recording may have been moved or deleted. No files were changed.")
                    .setPositiveButton("OK",null).show();}});
                share.setOnClickListener(v->shareVideo(uri));
                trim.setOnClickListener(v->trimVideo(uri));
                edit.setOnClickListener(v->{Intent next=new Intent(this,Duwm1728VideoEditorActivity.class);
                    next.putExtra(Duwm1728VideoEditorActivity.EXTRA_VIDEO_URI,uri.toString());
                    next.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(next);});
                entry.addView(actions);
                LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,-2);
                params.setMargins(0,dp(5),0,dp(7));cards.addView(entry,params);
            }
            count.setText(matches+" recorded video"+(matches==1?"":"s")+" matching • "
                +recordings.size()+" Gallery exports indexed");
            if(matches==0)cards.addView(label(recordings.isEmpty()
                ? "No Gallery recordings on this installation. Record in MONITORS CAM first."
                : "No recordings match your search.",13));
        };
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){render.run();}
            public void afterTextChanged(Editable e){}
        });
        render.run();
        TextView back=label("BACK TO MONITORS CAM",13);back.setGravity(Gravity.CENTER);
        GradientDrawable backShape=new GradientDrawable();
        backShape.setColor(DuwmUnifiedTheme.APPROVED_NAVY);
        backShape.setStroke(dp(1),DuwmUnifiedTheme.BORDER);backShape.setCornerRadius(dp(18));
        back.setBackground(backShape);
        back.setOnClickListener(v->finish());root.addView(back,new LinearLayout.LayoutParams(-1,dp(52)));
        setContentView(root);
    }
    @Override protected void onDestroy(){thumbnails.shutdownNow();super.onDestroy();}
}
