package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.SystemClock;
import java.io.File;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicReference;
import java.util.List;

/** Experimental native MP4 overlay renderer. Original never modified. Output only reported after muxer completes.
 * H264/Surface/Canvas support is device-specific; fail cleanly if unavailable.
 * Re-encodes video while copying original AAC audio if compatible. Native audio effects are not added.
 */
public final class Duwm1728OverlayRenderer {
    private Duwm1728OverlayRenderer() {}
    public static final class Spec {
        public long fromMs, toMs;
        public String title="", place="", description="";
        public boolean bottom=true;
        public Uri pipVideo=null; // explicit second clip, no audio overlay
        public String ticker="";
        public String template="GENERAL REPORT";
        public int tickerSpeed=48;  // output pixels per second at a 1280-pixel canvas
        public String captions=""; // reporter-written subtitles, NOT automatic speech recognition
        public List<Duwm1728TickerTimeline.Cue> captionCues=java.util.Collections.emptyList();
        public Duwm1728CaptureTelemetry.Snapshot capturedTelemetry=null;
        public List<Duwm1728TelemetryTimeline.Point> recordedTrack=java.util.Collections.emptyList();
        public boolean includeSourceSummary=false, includeCoordinates=false;
        public List<Duwm1728TickerTimeline.Cue> tickerCues=java.util.Collections.emptyList();
    }
    private static String safe(String s,int max){return s==null?"":s.replaceAll("[\\r\\n\\t]+"," ").trim().substring(0,Math.min(max,s.replaceAll("[\\r\\n\\t]+"," ").trim().length()));}
    private static void text(Canvas c,Paint p,String text,float x,float y,float size,int color){
        p.setColor(color);p.setTextSize(size);p.setTypeface(android.graphics.Typeface.create("sans-serif-medium",1));
        c.drawText(safe(text,70),x,y,p);
    }
    private static void paintInset(Canvas canvas, Paint paint, Bitmap inset){
        if(inset==null)return;
        float w=canvas.getWidth(),h=canvas.getHeight();
        float right=w*0.965f,top=h*0.055f;
        float bw=w*0.25f,bh=Math.min(h*0.30f,bw*(inset.getHeight()/(float)inset.getWidth()));
        RectF area=new RectF(right-bw,top,right,top+bh);
        paint.setStyle(Paint.Style.FILL);paint.setColor(0xFF041424);
        canvas.drawRoundRect(new RectF(area.left-5,area.top-5,area.right+5,area.bottom+5),8,8,paint);
        paint.setColor(android.graphics.Color.WHITE);paint.setFilterBitmap(true);
        canvas.drawBitmap(inset,null,area,paint);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(2f,w*0.002f));paint.setColor(0xFFDEE5EF);
        canvas.drawRect(area,paint);paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFFDEE5EF);paint.setTextSize(Math.max(10,w*0.012f));
        canvas.drawText("SECOND VIDEO • MUTED",area.left+5,Math.min(h-5,area.bottom+16),paint);
    }
    private static void paintOverlay(Canvas c,Paint p,Spec s,long elapsedMs){
        float w=c.getWidth(),h=c.getHeight(),line=Math.max(18f,w*0.029f),pad=w*0.04f;
        float top=s.bottom?h-Math.max(100f,line*5.4f):h*0.045f;
        p.setColor(0xEA041424);p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(new RectF(pad*0.45f,top,w-pad*0.45f,top+line*5.0f),w*0.012f,w*0.012f,p);
        p.setColor(0xFFDEE5EF);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(1.2f,w*0.0018f));
        c.drawRoundRect(new RectF(pad*0.45f,top,w-pad*0.45f,top+line*5.0f),w*0.012f,w*0.012f,p);
        p.setStyle(Paint.Style.FILL);
        String tag=safe(s.template,25).toUpperCase(java.util.Locale.ROOT);
        // Report type is user-selected. The overlay does not imply independent verification.
        text(c,p,"DUWM  /  "+tag,pad,top+line*1.15f,line*0.78f,Color.WHITE);
        text(c,p,safe(s.title,42),pad,top+line*2.25f,line*0.9f,Color.WHITE);
        text(c,p,safe(s.place,44),pad,top+line*3.25f,line*0.76f,0xFFDEE5EF);
        text(c,p,safe(s.description,55),pad,top+line*4.15f,line*0.65f,0xFFDEE5EF);
        text(c,p,"REPORTER-ENTERED / UNVERIFIED",pad,top+line*4.85f,line*0.50f,0xFFFBC02D);
        // Reserve the ticker rectangle and place distinct information rows without overlapping.
        final float tickerBar=Math.max(23f,line*1.6f);
        final float tickerY=s.bottom?top-tickerBar-5f:top+line*5f+6f;
        final float telemetryTop=s.bottom?tickerY-line*3.2f:tickerY+tickerBar+line*0.3f;
        // A saved capture record contains only capture-END data. Never imply a live/per-frame track.
        if(s.includeSourceSummary && s.capturedTelemetry!=null){
            Duwm1728CaptureTelemetry.Snapshot source=s.capturedTelemetry;
            Duwm1728TelemetryTimeline.Point measured=Duwm1728TelemetryTimeline.at(s.recordedTrack,elapsedMs+s.fromMs);
            if(measured!=null)source=measured.snapshot;
            p.setStyle(Paint.Style.FILL);p.setColor(0xE8041424);
            c.drawRoundRect(new RectF(pad*0.45f,telemetryTop,w-pad*0.45f,telemetryTop+line*2.9f),w*0.006f,w*0.006f,p);
            text(c,p,measured==null?source.captureTimeLabel():"RECORDED SENSOR SAMPLE @ "+
                (measured.atMs/1000)+"s • "+source.captureTimeLabel(),
                pad,telemetryTop+line*0.65f,line*0.42f,0xFFDEE5EF);
            text(c,p,"DEVICE HDG "+source.compass+" | ALT "+source.altitude+" | GPS ACC "+source.gpsAccuracy,
                 pad,telemetryTop+line*1.35f,line*0.42f,0xFFF5F7FA);
            text(c,p,source.weather,pad,telemetryTop+line*2.02f,line*0.42f,0xFFDEE5EF);
            text(c,p,source.gpsSummary(s.includeCoordinates)+" / RECORDED, NOT LIVE",
                 pad,telemetryTop+line*2.7f,line*0.44f,0xFFFBC02D);
        }
        // Reporter-written caption cues, NOT generated speech recognition.
        Duwm1728TickerTimeline.Cue sub=Duwm1728TickerTimeline.active(s.captionCues,elapsedMs);
        if(sub!=null){
            final float subtitleBottom=s.bottom?(s.includeSourceSummary&&s.capturedTelemetry!=null?telemetryTop-line*0.3f:tickerY-line*0.3f):
                (s.includeSourceSummary&&s.capturedTelemetry!=null?telemetryTop+line*6.2f:tickerY+tickerBar+line*3.1f);
            final float subtitleTop=s.bottom?subtitleBottom-line*2.65f:subtitleBottom-line*2.65f;
            p.setStyle(Paint.Style.FILL);p.setColor(0xE9041424);
            c.drawRoundRect(new RectF(pad*0.45f,subtitleTop,w-pad*0.45f,subtitleBottom),w*0.006f,w*0.006f,p);
            p.setTypeface(android.graphics.Typeface.create("sans-serif-medium",1));
            p.setTextSize(Math.max(12f,line*0.50f));
            p.setColor(0xFFF5F7FA);
            String caption=safe(sub.text,180);
            String[] words=caption.split(" +");
            StringBuilder row=new StringBuilder("REPORTER CAPTION: ");
            int drawn=0;float y=subtitleTop+line*0.74f;
            for(String word:words){
                String candidate=row.length()==0?word:row+" "+word;
                if(p.measureText(candidate)>w-pad*2.4f && row.length()>0){
                    c.drawText(row.toString(),pad,y,p);y+=line*0.69f;drawn++;
                    if(drawn>=2){row=new StringBuilder("...");break;}
                    row=new StringBuilder(word);
                }else row=new StringBuilder(candidate);
            }
            if(row.length()>0 && drawn<3)c.drawText(row.toString(),pad,y,p);
        }
        // Draw the actual moving broadcast ticker into each encoded frame.
        // Its text is chosen by the clip-relative timestamp, never live wall clock data.
        Duwm1728TickerTimeline.Cue active=Duwm1728TickerTimeline.active(s.tickerCues,elapsedMs);
        if(active!=null) {
            String current=active.text;
            final float barHeight=tickerBar;
            final float y=tickerY;
            final float left=pad*0.45f,right=w-left;
            p.setStyle(Paint.Style.FILL);p.setColor(0xF0041424);
            c.drawRoundRect(new RectF(left,y,right,y+barHeight),w*0.006f,w*0.006f,p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(1f,w*0.0015f));p.setColor(0xFFDEE5EF);
            c.drawRoundRect(new RectF(left,y,right,y+barHeight),w*0.006f,w*0.006f,p);
            p.setStyle(Paint.Style.FILL);
            final float inset=Math.max(7f,w*0.012f);
            final float font=Math.max(13f,line*0.62f);
            final String prefix="REPORTER UPDATE  •  ";
            p.setTypeface(android.graphics.Typeface.create("sans-serif-medium",1));p.setTextSize(font);
            float prefixWidth=p.measureText(prefix);
            float clipLeft=left+inset+prefixWidth;
            float available=Math.max(2f,right-inset-clipLeft);
            p.setColor(0xFFF5F7FA);
            c.drawText(prefix,left+inset,y+barHeight*0.71f,p);
            float textWidth=p.measureText(current);
            float pxPerSecond=s.tickerSpeed*(w/1280f);
            float scroll=Duwm1728TickerTimeline.offsetPixels(elapsedMs-active.atMs,textWidth,available,pxPerSecond);
            int state=c.save();
            c.clipRect(clipLeft,y,clipLeft+available,y+barHeight);
            p.setColor(0xFFDEE5EF);
            c.drawText(current,clipLeft+scroll,y+barHeight*0.71f,p);
            c.restoreToCount(state);
        }
    }
    public static File export(Context ctx,Uri source,Spec spec) throws Exception {
        if(spec==null || spec.fromMs<0 || spec.toMs<=spec.fromMs || spec.toMs-spec.fromMs>45000L)
            throw new IllegalArgumentException("Overlay export must be a clip of at most 45 seconds");
        spec.tickerCues=Duwm1728TickerTimeline.parse(spec.ticker);
        spec.captionCues=Duwm1728TickerTimeline.parse(spec.captions);
        if(spec.tickerSpeed<12||spec.tickerSpeed>140)throw new IllegalArgumentException("Unsupported ticker speed");
        if(!spec.tickerCues.isEmpty() && spec.tickerCues.get(spec.tickerCues.size()-1).atMs >= spec.toMs-spec.fromMs)
            throw new IllegalArgumentException("Ticker update is after clip end");
        if(!spec.captionCues.isEmpty() && spec.captionCues.get(spec.captionCues.size()-1).atMs >= spec.toMs-spec.fromMs)
            throw new IllegalArgumentException("Caption time is after clip end");
        if(spec.includeCoordinates && (spec.capturedTelemetry==null || !spec.capturedTelemetry.preciseEnabled))
            throw new IllegalArgumentException("No consenting captured coordinate source");
        final long fromUs=spec.fromMs*1000L,toUs=spec.toMs*1000L;
        MediaMetadataRetriever retriever=new MediaMetadataRetriever();
        MediaMetadataRetriever insetRetriever=null;
        MediaExtractor audio=null;MediaCodec encoder=null;MediaMuxer muxer=null;
        File output=File.createTempFile("DUWM_EDIT_",".mp4",ctx.getCacheDir());
        boolean success=false;android.view.Surface input=null;
        try {
            retriever.setDataSource(ctx,source);
            if(spec.pipVideo!=null){
                if(spec.pipVideo.equals(source))throw new IllegalArgumentException("Inset must be a different video");
                insetRetriever=new MediaMetadataRetriever();insetRetriever.setDataSource(ctx,spec.pipVideo);
                if(insetRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)==null)
                    throw new IllegalArgumentException("Inset source has no video track");
            }
            String d=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if(d==null || Long.parseLong(d)<spec.toMs)throw new IllegalArgumentException("Clip range exceeds source duration");
            int w=Integer.parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
            int h=Integer.parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
            if(w<2||h<2)throw new IllegalArgumentException("No usable video track");
            double down=Math.min(1.0,1280.0/Math.max(w,h));
            w=Math.max(2,((int)(w*down)) & ~1);h=Math.max(2,((int)(h*down)) & ~1);
            final int width=w,height=h,fps=24;
            MediaFormat fmt=MediaFormat.createVideoFormat("video/avc",width,height);
            fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            fmt.setInteger(MediaFormat.KEY_BIT_RATE,Math.min(8000000,Math.max(1600000,width*height*5)));
            fmt.setInteger(MediaFormat.KEY_FRAME_RATE,fps);
            fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL,2);
            encoder=MediaCodec.createEncoderByType("video/avc");
            encoder.configure(fmt,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);
            input=encoder.createInputSurface();encoder.start();
            muxer=new MediaMuxer(output.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            audio=new MediaExtractor();audio.setDataSource(ctx,source,null);
            int audioSrc=-1,audioDest=-1;
            for(int t=0;t<audio.getTrackCount();t++){
                MediaFormat track=audio.getTrackFormat(t);
                String mime=track.getString(MediaFormat.KEY_MIME);
                if(mime!=null && mime.equalsIgnoreCase("audio/mp4a-latm")){
                    audioSrc=t;audioDest=muxer.addTrack(track);audio.selectTrack(t);break;
                }
            }
            final MediaCodec e=encoder;final MediaMuxer m=muxer;
            final AtomicReference<Throwable> drainError=new AtomicReference<>();
            final Object finish=new Object();
            final int[] videoDest={-1};final boolean[] started={false};
            final long[] firstVideoTime={-1L},previousVideoTime={-1L};
            Thread drain=new Thread(()->{
                MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
                try{
                    for(;;){
                        int index=e.dequeueOutputBuffer(info,1000000);
                        if(index==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){
                            if(started[0])throw new IllegalStateException("Encoder output changed twice");
                            videoDest[0]=m.addTrack(e.getOutputFormat());m.start();started[0]=true;
                        }else if(index>=0){
                            ByteBuffer data=e.getOutputBuffer(index);
                            if(data!=null && info.size>0 && started[0]){
                                data.position(info.offset);data.limit(info.offset+info.size);
                                if(firstVideoTime[0]<0)firstVideoTime[0]=info.presentationTimeUs;
                                info.presentationTimeUs=Math.max(0L,info.presentationTimeUs-firstVideoTime[0]);
                                if(info.presentationTimeUs<=previousVideoTime[0])info.presentationTimeUs=previousVideoTime[0]+1;
                                previousVideoTime[0]=info.presentationTimeUs;
                                m.writeSampleData(videoDest[0],data,info);
                            }
                            boolean eos=(info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                            e.releaseOutputBuffer(index,false);
                            if(eos)break;
                        }
                    }
                }catch(Throwable error){drainError.set(error);}
                synchronized(finish){finish.notifyAll();}
            },"duwm1728-overlay-encode-drain");
            drain.start();
            Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
            long startClock=SystemClock.elapsedRealtime();
            int count=(int)Math.ceil((spec.toMs-spec.fromMs)*fps/1000.0);
            for(int n=0;n<count;n++){
                if(drainError.get()!=null)throw new IllegalStateException("Encoder failed",drainError.get());
                long target=startClock+n*1000L/fps;
                long wait=target-SystemClock.elapsedRealtime();
                if(wait>0)SystemClock.sleep(wait);
                long sampleUs=fromUs+n*1000000L/fps;
                Bitmap frame=retriever.getFrameAtTime(Math.min(sampleUs,toUs-1),MediaMetadataRetriever.OPTION_CLOSEST);
                if(frame==null)throw new IllegalStateException("Unable to decode original video frame");
                Canvas canvas=null;
                try{
                    canvas=input.lockCanvas(null);
                    canvas.drawColor(0xFF041424);
                    float sx=width/(float)frame.getWidth(),sy=height/(float)frame.getHeight();
                    float scale=Math.min(sx,sy),dw=frame.getWidth()*scale,dh=frame.getHeight()*scale;
                    canvas.drawBitmap(frame,null,new RectF((width-dw)/2,(height-dh)/2,(width+dw)/2,(height+dh)/2),paint);
                    paintOverlay(canvas,paint,spec,(long)n*1000L/fps);
                    if(insetRetriever!=null){
                        Bitmap small=insetRetriever.getFrameAtTime(n*1000000L/fps,MediaMetadataRetriever.OPTION_CLOSEST);
                        if(small!=null){try{paintInset(canvas,paint,small);}finally{small.recycle();}}
                    }
                }finally{frame.recycle();if(canvas!=null)input.unlockCanvasAndPost(canvas);}
            }
            encoder.signalEndOfInputStream();
            drain.join(15000L);
            if(drain.isAlive())throw new IllegalStateException("Encoder did not finish");
            if(drainError.get()!=null)throw new IllegalStateException("Encoder error",drainError.get());
            if(!started[0])throw new IllegalStateException("No encoded video frames");
            if(audioSrc>=0){
                audio.seekTo(fromUs,MediaExtractor.SEEK_TO_CLOSEST_SYNC);
                ByteBuffer buffer=ByteBuffer.allocateDirect(2*1024*1024);
                MediaCodec.BufferInfo ai=new MediaCodec.BufferInfo();long previous=-1L;
                while(true){
                    long stamp=audio.getSampleTime();if(stamp<0||stamp>=toUs)break;
                    if(stamp>=fromUs){
                        buffer.clear();int size=audio.readSampleData(buffer,0);if(size<0)break;
                        long pts=Math.max(0,stamp-fromUs);
                        if(pts>previous){ai.offset=0;ai.size=size;ai.flags=audio.getSampleFlags();ai.presentationTimeUs=pts;
                            m.writeSampleData(audioDest,buffer,ai);previous=pts;}
                    }
                    if(!audio.advance())break;
                }
            }
            muxer.stop();success=true;return output;
        }finally{
            if(input!=null)try{input.release();}catch(Exception ignored){}
            if(encoder!=null){try{encoder.stop();}catch(Exception ignored){}try{encoder.release();}catch(Exception ignored){}}
            if(audio!=null)try{audio.release();}catch(Exception ignored){}
            if(muxer!=null)try{muxer.release();}catch(Exception ignored){}
            try{retriever.release();}catch(Exception ignored){}
            if(insetRetriever!=null)try{insetRetriever.release();}catch(Exception ignored){}
            if(!success)output.delete();
        }
    }
}
