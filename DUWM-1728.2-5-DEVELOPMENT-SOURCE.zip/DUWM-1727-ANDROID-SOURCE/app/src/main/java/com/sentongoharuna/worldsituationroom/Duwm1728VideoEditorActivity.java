package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.Toast;
import java.io.File;

/** Native private video editor. Preview uses the original; exports a NEW MP4 with user-entered overlay. */
public final class Duwm1728VideoEditorActivity extends Activity {
    public static final String EXTRA_VIDEO_URI="duwm.editor.video";
    private Uri source;
    private VideoView player;
    private TextView overlay;
    private EditText title,place,caption,from,to,ticker,subtitles;
    private android.widget.CheckBox sourceSummary,preciseExport;
    private Duwm1728CaptureTelemetry.Snapshot provenance;
    private TextView tickerPreview,templateButton,speedButton;
    private final String[] templates={"GENERAL REPORT","BREAKING NEWS","WEATHER","TRAFFIC","INTERVIEW","EMERGENCY"};
    private int selectedTemplate=0,tickerSpeed=48;
    private final Handler tickerClock = new Handler(Looper.getMainLooper());
    private static final int CAPTION_DICTATION_REQUEST=17283;
    private static final int PIP_VIDEO_REQUEST=17284, SUBTITLE_SRT_REQUEST=17285;
    private Uri pipVideo; private TextView pipSelection;
    private Duwm1728RecordedAudioTranscriber recordedAudioTranscriber;
    private java.util.List<Duwm1728TelemetryTimeline.Point> recordedTrack=java.util.Collections.emptyList();
    private android.widget.CheckBox recordedTrackToggle;
    private String lastPreviewCue="";
    private final Runnable previewClock=new Runnable(){@Override public void run(){
        updateTickerPreview();tickerClock.postDelayed(this,250);
    }};
    private boolean bottom=true,busy=false;
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView label(String value,int size){TextView t=new TextView(this);t.setText(value);t.setTextColor(0xFFF5F7FA);t.setTextSize(size);t.setPadding(dp(12),dp(10),dp(12),dp(10));return t;}
    private TextView button(String value,Runnable onClick){TextView v=label(value,13);v.setGravity(Gravity.CENTER);v.setMinHeight(dp(48));
        GradientDrawable bg=new GradientDrawable();bg.setColor(0xFF081B2B);bg.setCornerRadius(dp(14));bg.setStroke(dp(1),0xFFDEE5EF);v.setBackground(bg);v.setOnClickListener(x->onClick.run());return v;}
    private EditText field(String hint,String value){EditText e=new EditText(this);e.setSingleLine(true);e.setText(value);e.setHint(hint);e.setHintTextColor(0xFFA0A5AE);e.setTextColor(Color.WHITE);e.setTextSize(14);return e;}
    private LinearLayout.LayoutParams params(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(8);return p;}
    @Override public void onCreate(Bundle saved){super.onCreate(saved);getWindow().setStatusBarColor(0xFF041424);getWindow().setNavigationBarColor(0xFF041424);
        String raw=getIntent().getStringExtra(EXTRA_VIDEO_URI);if(raw==null){finish();return;}source=Uri.parse(raw);
        provenance=Duwm1728CaptureTelemetry.load(getApplicationContext(),source);
        recordedTrack=Duwm1728TelemetryTimeline.load(getApplicationContext(),source);
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setBackgroundColor(0xFF041424);
        ScrollView scroll=new ScrollView(this);LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(12),dp(8),dp(12),dp(20));
        body.addView(label("MONITORS CAM  /  VIDEO EDITOR",18),params());
        body.addView(label("Private edit • original stays unchanged • reporting text is SELF-REPORTED",11),params());
        FrameLayout preview=new FrameLayout(this);player=new VideoView(this);player.setVideoURI(source);
        preview.addView(player,new FrameLayout.LayoutParams(-1,-1));overlay=label("DUWM / UNVERIFIED REPORT",12);overlay.setBackgroundColor(0xE8041424);
        FrameLayout.LayoutParams olp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);preview.addView(overlay,olp);
        body.addView(preview,new LinearLayout.LayoutParams(-1,dp(260)));
        body.addView(button("▶ PLAY / PAUSE PREVIEW",()->{if(player.isPlaying())player.pause();else player.start();}),params());
        body.addView(label("The preview is illustrative. Only a successfully exported MP4 has permanent overlays.",11),params());
        title=field("Headline","FIELD REPORT");place=field("Place / city","LOCATION NOT PROVIDED");caption=field("Description","EYEWITNESS ACCOUNT");
        for(EditText t:new EditText[]{title,place,caption}){body.addView(t,params());t.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){refresh();}public void afterTextChanged(android.text.Editable e){}
        });}
        body.addView(label("BROADCAST NEWS TICKER • REPORTER-ENTERED UPDATES",12),params());
        ticker=field("00:00=First update;00:15=Next update", "00:00=Eyewitness report — awaiting independent verification");
        ticker.setSingleLine(false);ticker.setMinLines(2);ticker.setMaxLines(5);body.addView(ticker,params());
        body.addView(label("Time is relative to start of the exported clip. Enter MM:SS=message; separate updates with semicolons. Up to 12 updates, 180 characters each.",11),params());
        body.addView(label("TIMED SUBTITLES • REPORTER-WRITTEN / NOT AUTOMATIC SPEECH TRANSCRIPTION",12),params());
        subtitles=field("00:00=Words spoken or translated by reporter;00:08=Next caption", "");
        subtitles.setSingleLine(false);subtitles.setMinLines(2);subtitles.setMaxLines(5);
        body.addView(subtitles,params());
        body.addView(button("DICTATE A CAPTION WITH MICROPHONE / REVIEW BEFORE EXPORT",this::dictateCaption),params());
        body.addView(button("IMPORT TIME-CODED .SRT CAPTIONS FROM FILE",this::chooseSubtitleFile),params());
        body.addView(button("TRANSCRIBE RECORDED VIDEO AUDIO (ON-DEVICE, IF SUPPORTED)",this::transcribeRecordedAudio),params());
        body.addView(label("Android 13+ and compatible on-device recognizer required. This reads decoded audio from the selected video; no substitute microphone transcription. Timed captions require actual word timestamps and your review.",11),params());
        body.addView(label("Imported subtitle timestamps come from the selected file, NOT automatic transcription. Review every caption before export.",11),params());
        pipSelection=label("PICTURE-IN-PICTURE: OFF",12);body.addView(pipSelection,params());
        body.addView(button("SELECT SECOND VIDEO FOR PICTURE-IN-PICTURE",this::choosePipVideo),params());
        body.addView(button("REMOVE PICTURE-IN-PICTURE",()->{pipVideo=null;pipSelection.setText("PICTURE-IN-PICTURE: OFF");}),params());
        body.addView(label("Inset is a separately selected video, muted. Its frames are drawn into the final export; the main video audio remains primary.",11),params());
        body.addView(label("This speech recognition listens to your microphone NOW. It does not transcribe the source video automatically.",11),params());
        body.addView(label("Caption cues use clip-relative MM:SS=words and render directly into exported MP4. Review accuracy before exporting.",11),params());
        sourceSummary=new android.widget.CheckBox(this);
        sourceSummary.setText("Embed actual MONITORS CAM capture-end telemetry snapshot");
        sourceSummary.setTextColor(0xFFF5F7FA);
        sourceSummary.setEnabled(provenance!=null);
        sourceSummary.setChecked(false);body.addView(sourceSummary,params());
        recordedTrackToggle=new android.widget.CheckBox(this);
        recordedTrackToggle.setText("Use actual time-stamped sensor samples when available (not live)");
        recordedTrackToggle.setTextColor(0xFFF5F7FA);
        recordedTrackToggle.setEnabled(!recordedTrack.isEmpty());recordedTrackToggle.setChecked(false);
        body.addView(recordedTrackToggle,params());
        preciseExport=new android.widget.CheckBox(this);
        preciseExport.setText("Also disclose precise captured GPS in this edited export (privacy risk)");
        preciseExport.setTextColor(0xFFF5F7FA);
        preciseExport.setEnabled(provenance!=null && provenance.preciseEnabled);
        preciseExport.setChecked(false);body.addView(preciseExport,params());
        body.addView(label(provenance==null?"NO CAPTURE PROVENANCE FOR THIS FILE — GPS, heading, altitude and weather will not be invented.":
            "CAPTURE-END SENSOR/PROVIDER SNAPSHOT AVAILABLE. Not a continuously recorded telemetry track.",11),params());
        templateButton=button("REPORT STYLE: GENERAL REPORT",()->{selectedTemplate=(selectedTemplate+1)%templates.length;templateButton.setText("REPORT STYLE: "+templates[selectedTemplate]);refresh();});
        body.addView(templateButton,params());
        speedButton=button("TICKER SPEED: NORMAL",()->{tickerSpeed=tickerSpeed==48?30:tickerSpeed==30?80:48;speedButton.setText("TICKER SPEED: "+(tickerSpeed==30?"SLOW":tickerSpeed==80?"FAST":"NORMAL"));});
        body.addView(speedButton,params());
        tickerPreview=label("REPORTER UPDATE —",12);tickerPreview.setSingleLine(true);
        tickerPreview.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
        tickerPreview.setMarqueeRepeatLimit(-1);tickerPreview.setSelected(true);
        tickerPreview.setBackgroundColor(0xFF081B2B);body.addView(tickerPreview,params());
        ticker.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){refresh();}
            public void afterTextChanged(android.text.Editable e){}
        });
        body.addView(button("OVERLAY POSITION  /  TOP OR BOTTOM",()->{bottom=!bottom;FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(-1,-2,bottom?Gravity.BOTTOM:Gravity.TOP);overlay.setLayoutParams(p);}),params());
        body.addView(label("TRIM RANGE (SECONDS) • max exported clip 45 seconds",12),params());
        LinearLayout times=new LinearLayout(this);times.setOrientation(LinearLayout.HORIZONTAL);
        from=field("Start seconds","0");to=field("End seconds","15");from.setInputType(2);to.setInputType(2);
        times.addView(from,new LinearLayout.LayoutParams(0,-2,1));times.addView(to,new LinearLayout.LayoutParams(0,-2,1));body.addView(times,params());
        body.addView(button("PREVIEW CLIP START",()->{try{player.seekTo(Integer.parseInt(from.getText().toString())*1000);player.start();}catch(Exception e){notice("Use a valid start time");}}),params());
        body.addView(button("EXPORT MP4 WITH PERMANENT GRAPHICS TO GALLERY",this::export),params());
        body.addView(button("CLOSE EDITOR",this::finish),params());scroll.addView(body);page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(page);
        player.setOnErrorListener((mp,what,extra)->{notice("Source video cannot be played on this device");return true;});refresh();
    }
    private void refresh(){
        if(overlay!=null && title!=null)overlay.setText("DUWM / "+templates[selectedTemplate]+"\n"+title.getText()+"\n"+place.getText()+"\n"+caption.getText()+"\nUNVERIFIED / REPORTER-ENTERED");
        updateTickerPreview();
    }
    private void updateTickerPreview(){
        if(tickerPreview==null || ticker==null)return;
        try {
            java.util.List<Duwm1728TickerTimeline.Cue> cues=Duwm1728TickerTimeline.parse(ticker.getText().toString());
            long start=0;try{if(from!=null)start=Long.parseLong(from.getText().toString().trim())*1000L;}catch(Exception ignored){}
            long playback=player==null?0:Math.max(0,player.getCurrentPosition()-start);
            String msg="REPORTER UPDATE • "+Duwm1728TickerTimeline.at(cues,playback);
            // Avoid resetting the marquee every frame; update only on cue transitions.
            if(!msg.equals(lastPreviewCue)){tickerPreview.setText(msg);lastPreviewCue=msg;}
            tickerPreview.setTextColor(0xFFF5F7FA);
        }catch(IllegalArgumentException ex){
            String msg="CHECK TICKER: "+ex.getMessage();
            if(!msg.equals(lastPreviewCue)){tickerPreview.setText(msg);lastPreviewCue=msg;}
            tickerPreview.setTextColor(0xFFFBC02D);
        }
    }
    private void dictateCaption(){
        if(busy){notice("Cannot dictate while exporting");return;}
        try{
            Intent intent=new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT,"Speak a caption for manual review");
            startActivityForResult(intent,CAPTION_DICTATION_REQUEST);
        }catch(android.content.ActivityNotFoundException e){notice("No speech recognition app on this phone");}
    }
    private void transcribeRecordedAudio(){
        if(busy || recordedAudioTranscriber!=null){notice("Editor is busy");return;}
        if(!Duwm1728RecordedAudioTranscriber.canAttempt(this)){
            notice("This device has no compatible on-device recorded-audio recognizer. Import SRT captions instead.");return;
        }
        long fromMs,toMs;
        try{fromMs=Long.parseLong(from.getText().toString().trim())*1000L;
            toMs=Long.parseLong(to.getText().toString().trim())*1000L;
            if(fromMs<0||toMs<=fromMs||toMs-fromMs>45000)throw new IllegalArgumentException();
        }catch(Exception ex){notice("Select a valid video range up to 45 seconds");return;}
        new AlertDialog.Builder(this).setTitle("Transcribe the actual video soundtrack?")
            .setMessage("Uses the phone's on-device recognition service and decoded recorded audio. Some devices do not support audio injection or word timestamps. Never accept subtitles without reviewing them. No camera microphone fallback is requested by DUWM.")
            .setNegativeButton("CANCEL",null).setPositiveButton("START",(d,w)->{
                recordedAudioTranscriber=new Duwm1728RecordedAudioTranscriber(this);
                notice("Attempting on-device recorded-audio recognition");
                recordedAudioTranscriber.transcribe(source,fromMs,toMs,new Duwm1728RecordedAudioTranscriber.Listener(){
                    @Override public void error(String message){recordedAudioTranscriber=null;notice(message);}
                    @Override public void done(Duwm1728RecordedAudioTranscriber.Result result){
                        recordedAudioTranscriber=null;
                        final EditText review=field("Review transcription / time codes",result.hasVerifiedWordTimes?result.timedCaptions:result.text);
                        review.setSingleLine(false);review.setMinLines(3);
                        String explanation=result.hasVerifiedWordTimes
                            ?"Word timestamps reported by the recognizer; grouped into timed subtitle cues. Verify every word and its timing."
                            :"The recognizer did NOT return reliable word timestamps. Transcript text only: use manual caption times or import SRT.";
                        new AlertDialog.Builder(Duwm1728VideoEditorActivity.this)
                            .setTitle("Review recorded-audio transcript")
                            .setMessage(explanation).setView(review).setNegativeButton("DISCARD",null)
                            .setPositiveButton(result.hasVerifiedWordTimes?"IMPORT TIMED CAPTIONS":"COPY TEXT",(dialog,which)->{
                                if(result.hasVerifiedWordTimes){try{String checked=review.getText().toString().trim();
                                    Duwm1728TickerTimeline.parse(checked);subtitles.setText(checked);
                                }catch(IllegalArgumentException ex){notice("Correct subtitle time codes: "+ex.getMessage());}}
                                if(!result.hasVerifiedWordTimes){android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
                                    cm.setPrimaryClip(android.content.ClipData.newPlainText("DUWM transcript for manual timing",review.getText().toString()));}
                            }).show();
                    }
                });
            }).show();
    }
    private void choosePipVideo(){
        Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("video/*");
        startActivityForResult(pick,PIP_VIDEO_REQUEST);
    }
    private void chooseSubtitleFile(){
        Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
        pick.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/plain","application/x-subrip","application/octet-stream"});
        startActivityForResult(pick,SUBTITLE_SRT_REQUEST);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null)return;
        if(request==PIP_VIDEO_REQUEST){
            Uri selected=data.getData();if(selected==null)return;
            try{getContentResolver().takePersistableUriPermission(selected,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(SecurityException ignored){}
            if(selected.equals(source)){notice("Choose a different video for the inset");return;}
            pipVideo=selected;pipSelection.setText("PICTURE-IN-PICTURE: SECOND VIDEO SELECTED");return;
        }
        if(request==SUBTITLE_SRT_REQUEST){
            Uri selected=data.getData();if(selected==null)return;
            try(java.io.InputStream in=getContentResolver().openInputStream(selected)){
                if(in==null)throw new IllegalArgumentException("File unavailable");
                byte[] bytes=new byte[65537];int offset=0,read;
                while(offset<bytes.length && (read=in.read(bytes,offset,bytes.length-offset))>0)offset+=read;
                if(offset>65536)throw new IllegalArgumentException("Subtitle file exceeds 64 KiB");
                String text=new String(bytes,0,offset,java.nio.charset.StandardCharsets.UTF_8);
                String cues=Duwm1728SubtitleImport.convertSrt(text);
                new AlertDialog.Builder(this).setTitle("Review imported time codes")
                    .setMessage("This imports manually time-coded subtitles. It does not transcribe original audio. Review and edit the text before export.")
                    .setNegativeButton("DISCARD",null).setPositiveButton("IMPORT",(d,w)->subtitles.setText(cues)).show();
            }catch(Exception ex){notice("Subtitle import failed: "+ex.getMessage());}return;
        }
        if(request!=CAPTION_DICTATION_REQUEST)return;
        java.util.ArrayList<String> phrases=data.getStringArrayListExtra(
            android.speech.RecognizerIntent.EXTRA_RESULTS);
        if(phrases==null||phrases.isEmpty())return;
        String guess=phrases.get(0).replaceAll("[\\r\\n;=]+"," ").trim();
        if(guess.length()>180)guess=guess.substring(0,180);
        long now=player==null?0:Math.max(0,player.getCurrentPosition());
        long start=0;try{start=Long.parseLong(from.getText().toString().trim())*1000L;}catch(Exception ignored){}
        long clipMs=Math.max(0,now-start);String cue=String.format(java.util.Locale.US,
            "%02d:%02d=%s",clipMs/60000,(clipMs/1000)%60,guess);
        final String candidate=(subtitles.getText().toString().trim().isEmpty()?"":
            subtitles.getText().toString().trim()+";")+cue;
        new AlertDialog.Builder(this).setTitle("Review dictated words")
          .setMessage("Recognized microphone speech, NOT source-video transcription:\n\n"+guess+
              "\n\nAt video time "+(clipMs/1000)+" seconds. Edit the resulting caption if needed.")
          .setNegativeButton("DISCARD",null).setPositiveButton("ADD CAPTION",(d,w)->subtitles.setText(candidate)).show();
    }
    private void notice(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private void export(){if(busy)return;
        final Duwm1728OverlayRenderer.Spec spec=new Duwm1728OverlayRenderer.Spec();
        try{spec.fromMs=Long.parseLong(from.getText().toString().trim())*1000L;spec.toMs=Long.parseLong(to.getText().toString().trim())*1000L;
            if(spec.fromMs<0||spec.toMs<=spec.fromMs||spec.toMs-spec.fromMs>45000)throw new IllegalArgumentException("45 seconds maximum");
        }catch(Exception e){notice("Enter a valid clip range (maximum 45 seconds)");return;}
        spec.title=title.getText().toString();spec.place=place.getText().toString();spec.description=caption.getText().toString();spec.bottom=bottom;
        spec.template=templates[selectedTemplate];spec.ticker=ticker.getText().toString();spec.tickerSpeed=tickerSpeed;
        spec.captions=subtitles.getText().toString();
        spec.pipVideo=pipVideo;
        spec.capturedTelemetry=provenance;
        spec.recordedTrack=recordedTrackToggle.isChecked()?recordedTrack:java.util.Collections.emptyList();
        spec.includeSourceSummary=provenance!=null && (sourceSummary.isChecked()||recordedTrackToggle.isChecked());
        spec.includeCoordinates=spec.includeSourceSummary && preciseExport.isChecked();
        try{java.util.List<Duwm1728TickerTimeline.Cue> cues=Duwm1728TickerTimeline.parse(spec.ticker);
            if(!cues.isEmpty()&&cues.get(cues.size()-1).atMs>=spec.toMs-spec.fromMs)throw new IllegalArgumentException("Ticker time exceeds exported clip");
            java.util.List<Duwm1728TickerTimeline.Cue> captions=Duwm1728TickerTimeline.parse(spec.captions);
            if(!captions.isEmpty() && captions.get(captions.size()-1).atMs>=spec.toMs-spec.fromMs)
                throw new IllegalArgumentException("Caption time exceeds exported clip");
        }catch(Exception ex){notice("Correct ticker/caption timing before exporting: "+ex.getMessage());return;}
        busy=true;notice("Rendering a separate MP4. Keep this screen open.");
        new Thread(()->{File tmp=null;
            try{tmp=Duwm1728OverlayRenderer.export(getApplicationContext(),source,spec);
                String filename="DUWM_EDIT_"+System.currentTimeMillis()+".mp4";
                Uri newUri=Duwm1724GalleryPublisher.publish(getApplicationContext(),tmp,filename);
                Duwm1726GalleryIndex.add(getApplicationContext(),newUri,filename);
                runOnUiThread(()->{busy=false;new AlertDialog.Builder(this).setTitle("Export completed")
                    .setMessage("A separate MP4 containing the edited graphics was saved in Movies / DUWM Monitors Cam. Original untouched.")
                    .setPositiveButton("OK",(d,w)->finish()).show();});
            }catch(Exception ex){android.util.Log.e("DUWM-EDITOR","MP4 export failed",ex);runOnUiThread(()->{busy=false;
                new AlertDialog.Builder(this).setTitle("Video export unavailable")
                    .setMessage("This phone could not render the selected clip using its native video encoder. No completed video was claimed or published; your original remains unchanged.")
                    .setPositiveButton("OK",null).show();});
            }finally{if(tmp!=null)tmp.delete();}
        },"duwm1728-video-editor").start();
    }
    @Override protected void onPause(){tickerClock.removeCallbacks(previewClock);if(player!=null)player.pause();super.onPause();}
    @Override protected void onResume(){super.onResume();tickerClock.removeCallbacks(previewClock);tickerClock.post(previewClock);}
    @Override protected void onDestroy(){tickerClock.removeCallbacks(previewClock);if(recordedAudioTranscriber!=null)recordedAudioTranscriber.close();super.onDestroy();}
}
