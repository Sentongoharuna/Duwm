package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.EnumMap;
import java.util.Locale;

/**
 * DUWM 1715 signal-light revision. One slim, non-floating status rail on all
 * native information screens; the original globe, maps, streams and touch
 * targets remain the original content view, resized below the rail.
 *
 * A sector lamp represents a received-source status or a local tool. An actual
 * receipt burst alone permits a short pulse. There is NO decorative fake-live
 * timer, synthetic feed data, network request or invented severity.
 */
public final class Duwm1715SignalLights {
    private Duwm1715SignalLights() {}
    private static final String TAG = "duwm1715-global-signal-rail";
    private static final Object LOCK = new Object();
    private static final EnumMap<Signal.Layer, FeedStatus> LAST_STATUS =
            new EnumMap<>(Signal.Layer.class);
    private static final EnumMap<Signal.Layer, Long> LAST_NEW =
            new EnumMap<>(Signal.Layer.class);
    private static final long RECEIPT_PULSE_MS = 12_000L;
    private static final long REFRESH_MS = 12_000L;
    private static final Handler UI = new Handler(Looper.getMainLooper());
    // Declare visible before any static initializer lambda that reads it.
    // Otherwise javac rejects COALESCED_REFRESH with `illegal forward reference`.
    private static java.lang.ref.WeakReference<SignalRail> visible =
            new java.lang.ref.WeakReference<>(null);
    private static final Runnable COALESCED_REFRESH = () -> {
        SignalRail rail=visible.get();
        if(rail!=null)rail.refresh();
    };
    private static int dp(Context c,float v) {
        return Math.max(1,Math.round(c.getResources().getDisplayMetrics().density*v));
    }
    public static int indicatorColor(String status) {
        Duwm1724SignalFlow.Stage stage=Duwm1724SignalFlow.fromText(status);
        return stage==Duwm1724SignalFlow.Stage.LOCAL?DuwmUnifiedTheme.LOCAL_SIGNAL:stage.color;
    }
    /** The 19 lamps all use the same health policy, but DIFFERENT actual receipts. */
    public static Duwm1724SignalFlow.Stage stageFor(Context context,int sector){
        return lampFor(context,sector).stage;
    }
    public static View indicator(Context c,int color,String description,int size) {
        View v=new View(c);
        GradientDrawable d=new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        d.setStroke(dp(c,1),Color.rgb(222,229,239));
        v.setBackground(d);
        v.setContentDescription(description);
        v.setFocusable(false);
        v.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
        v.setMinimumWidth(dp(c,size));
        v.setMinimumHeight(dp(c,size));
        return v;
    }
    private static int sectorFor(Signal.Layer layer) {
        if(layer==null)return -1;
        switch(layer) {
            case FLIGHTS: case AIRSPACE: return 0;
            case SHIPS: return 1;
            case NATURAL: return 2;
            case WEATHER: return 3;
            case SATELLITES: case SPACE_WEATHER: return 4;
            case NEWS: return 7;
            case RADIO: return 9;
            case TV: return 10;
            case WEBCAMS: return 11;
            case MARKETS: return 13;
            default: return -1;
        }
    }
    /** Only source callbacks update these lights; cached results cannot flash NEW. */
    public static void sourceUpdate(Signal.Layer layer,FeedStatus status,int genuinelyNew) {
        if(layer==null || status==null)return;
        synchronized (LOCK) {
            LAST_STATUS.put(layer,status);
            if(genuinelyNew>0 && (status.state==FeedStatus.State.LIVE ||
                    status.state==FeedStatus.State.READY)) {
                LAST_NEW.put(layer,System.currentTimeMillis());
            }
        }
        // Coalesce quick batches of provider callbacks into one UI refresh.
        UI.removeCallbacks(COALESCED_REFRESH);
        UI.postDelayed(COALESCED_REFRESH,180L);
    }
    private static final class LampState {
        final String state;
        final int color;
        final Duwm1724SignalFlow.Stage stage;
        final boolean newReceipt;
        LampState(String state,Duwm1724SignalFlow.Stage stage,boolean newReceipt) {
            this.state=state;this.stage=stage;this.color=stage.color;this.newReceipt=newReceipt;
        }
    }
    private static LampState lampFor(Context context,int index) {
        Duwm1683DeskCatalog.Desk desk=Duwm1683DeskCatalog.ALL[index];
        Duwm1684DeskDiagnostics.Snapshot snap=Duwm1684DeskDiagnostics.read(context,desk);
        Duwm1724SignalFlow.Stage stage=Duwm1724SignalFlow.fromText(snap.state);
        String state=snap.state;
        boolean newlyAccepted=false;
        long now=System.currentTimeMillis();
        synchronized(LOCK) {
            Duwm1724SignalFlow.Stage selected=null;
            String selectedStatus=state;
            for(Signal.Layer layer:Signal.Layer.values()) {
                if(sectorFor(layer)!=index)continue;
                FeedStatus feed=LAST_STATUS.get(layer);
                Long time=LAST_NEW.get(layer);
                boolean pulse=time!=null && now>=time && now-time<RECEIPT_PULSE_MS;
                if(feed!=null && stage!=Duwm1724SignalFlow.Stage.LOCAL) {
                    Duwm1724SignalFlow.Stage candidate=Duwm1724SignalFlow.fromFeed(feed,now,
                            Duwm1724SignalFlow.budgetFor(layer),pulse);
                    // For multiple real sources, display the WORST known condition,
                    // not whichever provider happened to be iterated last.
                    if(candidate.rank>=0 && (selected==null || candidate.rank<selected.rank)) {
                        selected=candidate;
                        selectedStatus=layer.name()+" / "+feed.state.name()+" / "+candidate.label;
                    }
                }
            }
            if(selected!=null){stage=selected;state=selectedStatus;
                newlyAccepted=selected==Duwm1724SignalFlow.Stage.RECEIVING;}
        }
        return new LampState(state,stage,newlyAccepted);
    }
    private static void openSignalCentre(Context context,int sector){
        if(context==null)return;
        android.content.Intent intent=new android.content.Intent(context,Duwm1716SignalCenterActivity.class);
        if(sector>=0 && sector<Duwm1683DeskCatalog.ALL.length)
            intent.putExtra(Duwm1716SignalCenterActivity.EXTRA_SECTOR,sector);
        if(!(context instanceof Activity))intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
    public static View sectorLamp(Context c,int index,int size){
        LampState state=lampFor(c,index);
        View v=indicator(c,state.color,"Sector "+(index+1)+", "+
                Duwm1683DeskCatalog.ALL[index].title+", "+state.state,size);
        if(state.newReceipt) v.setAlpha(1f);
        return v;
    }
    /** Idempotent: only one slim top rail, never an overlay on the globe. */
    public static boolean attach(Activity activity) {
        if(activity==null || activity.isFinishing())return false;
        FrameLayout content=activity.findViewById(android.R.id.content);
        if(content==null || content.getChildCount()!=1)return false;
        SignalRail current=findRail(content);
        if(current!=null){ visible=new java.lang.ref.WeakReference<>(current); current.refresh(); return true; }
        View original=content.getChildAt(0);
        if(original==null || original.getTag()!=null && TAG.equals(original.getTag()))return false;
        // A vertical shell reserves true layout space; no FLAG_NOT_TOUCHABLE or
        // transparent overlay is placed above map, video, news or globe.
        LinearLayout shell=new LinearLayout(activity);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(DuwmUnifiedTheme.APPROVED_NAVY);
        // 1720: reserve the device's real status/navigation insets on the
        // OUTERMOST rail shell, not on the globe. Android 15+ may draw app
        // content behind both bars even with a matching status-bar colour.
        shell.setFitsSystemWindows(false);
        shell.setOnApplyWindowInsetsListener((view, insets) -> {
            int top=Math.max(0,insets.getSystemWindowInsetTop());
            int bottom=Math.max(0,insets.getSystemWindowInsetBottom());
            if(view.getPaddingTop()!=top || view.getPaddingBottom()!=bottom) {
                view.setPadding(0,top,0,bottom);
            }
            return insets;
        });
        SignalRail rail=new SignalRail(activity);
        shell.addView(rail,new LinearLayout.LayoutParams(-1,dp(activity,34)));
        content.removeView(original);
        shell.addView(original,new LinearLayout.LayoutParams(-1,0,1f));
        content.addView(shell,new FrameLayout.LayoutParams(-1,-1));
        visible=new java.lang.ref.WeakReference<>(rail);
        rail.refresh();
        return true;
    }
    private static SignalRail findRail(View view) {
        if (view == null) return null;
        View tagged = view.findViewWithTag(TAG);
        return tagged instanceof SignalRail ? (SignalRail)tagged : null;
    }
    private static final class SignalRail extends LinearLayout {
        private final View[] lamps=new View[Duwm1683DeskCatalog.ALL.length];
        private final TextView title;
        private final Runnable heartbeat=new Runnable() {
            @Override public void run(){refresh(); if(isAttachedToWindow())postDelayed(this,REFRESH_MS);}
        };
        SignalRail(Context context) {
            super(context);
            setTag(TAG);
            setOrientation(LinearLayout.HORIZONTAL);
            setGravity(Gravity.CENTER_VERTICAL);
            setPadding(dp(context,8),dp(context,1),dp(context,6),dp(context,1));
            setBackgroundColor(DuwmUnifiedTheme.PANEL);
            GradientDrawable background=new GradientDrawable();
            background.setColor(DuwmUnifiedTheme.PANEL);
            background.setStroke(dp(context,1),DuwmUnifiedTheme.DIVIDER);
            setBackground(background);
            title=new TextView(context);
            title.setText("SIGNALS / 19");
            title.setContentDescription("Open full-screen Signal Centre with 19 real source states");
            title.setOnClickListener(v->openSignalCentre(context,-1));
            title.setTextSize(10f);
            title.setTextColor(DuwmUnifiedTheme.MUTED);
            title.setSingleLine(true);
            title.setGravity(Gravity.CENTER_VERTICAL);
            title.setTypeface(android.graphics.Typeface.create("sans-serif-medium",0));
            addView(title,new LinearLayout.LayoutParams(dp(context,82),-1));
            HorizontalScrollView scroll=new HorizontalScrollView(context);
            scroll.setHorizontalScrollBarEnabled(false);
            scroll.setFillViewport(false);
            scroll.setContentDescription("19 sector source indicators, scroll for remaining sectors");
            LinearLayout row=new LinearLayout(context);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for(int i=0;i<lamps.length;i++) {
                View led=indicator(context,DuwmUnifiedTheme.UNAVAILABLE,
                        "Sector "+(i+1)+" awaiting actual source receipt",8);
                LinearLayout slot=new LinearLayout(context);
                slot.setGravity(Gravity.CENTER);
                slot.setOrientation(LinearLayout.VERTICAL);
                slot.addView(led,new LinearLayout.LayoutParams(dp(context,8),dp(context,8)));
                View sectorMark=new View(context);
                sectorMark.setBackgroundColor(Duwm1709SectorOutline.color(i));
                LinearLayout.LayoutParams mark=new LinearLayout.LayoutParams(dp(context,8),dp(context,1));
                mark.topMargin=dp(context,3);
                slot.addView(sectorMark,mark);
                LinearLayout.LayoutParams slotParams=new LinearLayout.LayoutParams(dp(context,14),dp(context,19));
                slotParams.leftMargin=dp(context,1);
                row.addView(slot,slotParams);
                final int selectedSector=i;
                slot.setContentDescription("Open signal receipt details for sector "+(i+1));
                slot.setOnClickListener(v->openSignalCentre(context,selectedSector));
                lamps[i]=led;
            }
            scroll.addView(row);
            addView(scroll,new LinearLayout.LayoutParams(0,-1,1f));
        }
        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();removeCallbacks(heartbeat);postDelayed(heartbeat,REFRESH_MS);
        }
        @Override protected void onDetachedFromWindow() {
            removeCallbacks(heartbeat);
            if(visible.get()==this)visible.clear();
            super.onDetachedFromWindow();
        }
        void refresh() {
            if(!isAttachedToWindow())return;
            int live=0,review=0;
            Context c=getContext();
            for(int i=0;i<lamps.length;i++) {
                LampState state=lampFor(c,i);
                Duwm1724SignalHistory.observe(c,i,state.stage,state.state);
                View v=lamps[i];
                GradientDrawable drawable=(GradientDrawable)v.getBackground();
                drawable.setColor(state.color);
                // Only genuine newly accepted records get a short pulse; a
                // disconnected feed is never animated to imply activity.
                if(state.newReceipt){v.animate().cancel();v.setAlpha(.75f);v.animate().alpha(1f).setDuration(300).start();}
                else {v.animate().cancel();v.setAlpha(1f);}
                v.setContentDescription(String.format(Locale.US,"Sector %02d, %s, %s%s",i+1,
                    Duwm1683DeskCatalog.ALL[i].title,state.state,state.newReceipt?", new receipt":""));
                if(state.stage==Duwm1724SignalFlow.Stage.HEALTHY ||
                   state.stage==Duwm1724SignalFlow.Stage.RECEIVING)live++;
                else if(Duwm1724SignalFlow.requiresReview(state.stage))review++;
            }
            title.setText(review>0 ? "REVIEW "+review : "GREEN "+live+"/19");
            title.setTextColor(review>0 ? DuwmUnifiedTheme.STATUS_RED :
                live>0 ? DuwmUnifiedTheme.STATUS_GREEN : DuwmUnifiedTheme.MUTED);
            title.setContentDescription("Open Signal Centre. 19 sector lights. "+live+
                    " recent source indicators, "+review+
                    " sectors requiring review. Red outage; orange degraded; yellow stale; blue connecting; cyan genuinely receiving; green current; grey no receipt; silver local tool.");
        }
    }
}
