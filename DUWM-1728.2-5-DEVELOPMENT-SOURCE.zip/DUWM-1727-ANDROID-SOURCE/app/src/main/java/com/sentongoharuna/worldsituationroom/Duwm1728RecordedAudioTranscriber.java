package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.Intent;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** Optional, device-dependent transcription from the SOURCE VIDEO's decoded audio.
 * Requires an on-device recognizer that honours Android 13's injected PCM stream.
 * Does not use, claim, or silently substitute microphone dictation.
 */
public final class Duwm1728RecordedAudioTranscriber {
    public interface Listener { void done(Result result); void error(String message); }
    public static final class Result {
        public final String text, timedCaptions;
        public final boolean hasVerifiedWordTimes;
        Result(String value,String timings,boolean verified){text=value;timedCaptions=timings;hasVerifiedWordTimes=verified;}
    }
    private final Context context;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final AtomicBoolean finished=new AtomicBoolean(false);
    private SpeechRecognizer recognizer;
    private ParcelFileDescriptor readPipe,writePipe;
    private Listener callbacks;
    private final Runnable timeout=()->fail("Transcription timed out; try SRT import or manual caption entry");
    public Duwm1728RecordedAudioTranscriber(Context c){context=c.getApplicationContext();}
    public static boolean canAttempt(Context c){
        return Build.VERSION.SDK_INT>=33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(c);
    }
    public void transcribe(Uri video,long fromMs,long toMs,Listener listener){
        if(Looper.myLooper()!=Looper.getMainLooper())throw new IllegalStateException("Start on UI thread");
        if(!canAttempt(context)){listener.error("On-device recorded-audio recognition unavailable on this Android phone");return;}
        if(video==null || fromMs<0 || toMs<=fromMs || toMs-fromMs>45000){listener.error("Select a clip up to 45 seconds");return;}
        callbacks=listener;
        try {
            ParcelFileDescriptor[] pipes=ParcelFileDescriptor.createPipe();readPipe=pipes[0];writePipe=pipes[1];
            recognizer=SpeechRecognizer.createOnDeviceSpeechRecognizer(context);
            recognizer.setRecognitionListener(new RecognitionListener(){
                @Override public void onReadyForSpeech(Bundle params){}
                @Override public void onBeginningOfSpeech(){}
                @Override public void onRmsChanged(float rmsdB){}
                @Override public void onBufferReceived(byte[] buffer){}
                @Override public void onEndOfSpeech(){}
                @Override public void onPartialResults(Bundle partialResults){}
                @Override public void onEvent(int eventType, Bundle params){}
                @Override public void onError(int error){fail("Recorded-audio recognition unavailable (service error "+error+"). Try importing an SRT file.");}
                @Override public void onResults(Bundle bundle){
                    ArrayList<String> result=bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if(result==null||result.isEmpty()||result.get(0).trim().isEmpty()){fail("No recognizable speech was returned");return;}
                    String text=result.get(0).trim();
                    String timed="";boolean verified=false;
                    if(Build.VERSION.SDK_INT>=34){
                        ArrayList<android.speech.RecognitionPart> parts=bundle.getParcelableArrayList(SpeechRecognizer.RECOGNITION_PARTS,android.speech.RecognitionPart.class);
                        if(parts!=null&&!parts.isEmpty()){
                            long prev=-1;boolean good=true;int nonzero=0;
                            for(android.speech.RecognitionPart part:parts){long ts=part.getTimestampMillis();
                                if(ts<prev || ts<0 || ts>toMs-fromMs){good=false;break;}if(ts>0)nonzero++;prev=ts;}
                            if(good&&nonzero>0){timed=toTimedCues(parts);verified=!timed.isEmpty();}
                        }
                    }
                    if(finished.compareAndSet(false,true)){cleanup();callbacks.done(new Result(text,timed,verified));}
                }
            });
            Intent request=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            request.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            request.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE,readPipe);
            request.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT,1);
            request.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING,AudioFormat.ENCODING_PCM_16BIT);
            request.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE,16000);
            request.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true);
            if(Build.VERSION.SDK_INT>=34)request.putExtra(RecognizerIntent.EXTRA_REQUEST_WORD_TIMING,true);
            recognizer.startListening(request);
            main.postDelayed(timeout,55000);
            new Thread(()->{
                try(OutputStream out=new ParcelFileDescriptor.AutoCloseOutputStream(writePipe)){
                    writePipe=null;decodePcm(context,video,fromMs,toMs,out);
                }catch(Exception ex){main.post(()->fail("Cannot decode recorded audio: "+ex.getMessage()));}
            },"duwm-recorded-audio-decode").start();
        }catch(Exception ex){fail("Cannot start recorded-audio recognition: "+ex.getMessage());}
    }
    private static String toTimedCues(ArrayList<android.speech.RecognitionPart> parts){
        // Group actual word offsets into <= 12 caption cues. Never interpolate guessed offsets.
        java.util.LinkedHashMap<Long,StringBuilder> groups=new java.util.LinkedHashMap<>();
        for(android.speech.RecognitionPart p:parts){String word=p.getRawText().replaceAll("[;=\\r\\n]+"," ").trim();if(word.isEmpty())continue;
            long bin=(p.getTimestampMillis()/4000L)*4000L;
            StringBuilder b=groups.get(bin);if(b==null){b=new StringBuilder();groups.put(bin,b);}
            if(b.length()+word.length()+1>180){continue;}
            if(b.length()>0)b.append(' ');b.append(word);
        }
        if(groups.size()>12)return "";
        StringBuilder output=new StringBuilder();
        for(java.util.Map.Entry<Long,StringBuilder> e:groups.entrySet()){
            if(output.length()>0)output.append(';');long seconds=e.getKey()/1000;
            output.append(String.format(Locale.US,"%02d:%02d=",seconds/60,seconds%60)).append(e.getValue());
        }
        return output.toString();
    }
    private static void decodePcm(Context context, Uri video,long fromMs,long toMs,OutputStream output) throws Exception{
        MediaExtractor extractor=new MediaExtractor();MediaCodec decoder=null;
        try{
            extractor.setDataSource(context,video,null);
            int selected=-1;
            for(int i=0;i<extractor.getTrackCount();i++){
                MediaFormat m=extractor.getTrackFormat(i);String mime=m.getString(MediaFormat.KEY_MIME);
                if(mime!=null&&mime.startsWith("audio/")){selected=i;break;}
            }
            if(selected<0)throw new IOException("Video contains no audio track");
            MediaFormat format=extractor.getTrackFormat(selected);
            extractor.selectTrack(selected);extractor.seekTo(fromMs*1000,MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            String mime=format.getString(MediaFormat.KEY_MIME);
            decoder=MediaCodec.createDecoderByType(mime);decoder.configure(format,null,null,0);decoder.start();
            boolean inputDone=false,outputDone=false;MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
            long limit=toMs*1000,iterations=0;
            int channels=format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)?format.getInteger(MediaFormat.KEY_CHANNEL_COUNT):1;
            int sampleRate=format.containsKey(MediaFormat.KEY_SAMPLE_RATE)?format.getInteger(MediaFormat.KEY_SAMPLE_RATE):44100;
            double inputFramePosition=0,nextOutputInputFrame=0;
            while(!outputDone && ++iterations<30000 && !Thread.currentThread().isInterrupted()){
                if(!inputDone){int ix=decoder.dequeueInputBuffer(10000);
                    if(ix>=0){ByteBuffer buf=decoder.getInputBuffer(ix);buf.clear();int count=extractor.readSampleData(buf,0);
                        long pts=extractor.getSampleTime();
                        if(count<0||pts>=limit){decoder.queueInputBuffer(ix,0,0,Math.max(fromMs*1000,pts<0?0:pts),MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputDone=true;}
                        else{decoder.queueInputBuffer(ix,0,count,pts,0);extractor.advance();}
                    }
                }
                int ox=decoder.dequeueOutputBuffer(info,10000);
                if(ox==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){MediaFormat f=decoder.getOutputFormat();
                    channels=f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)?f.getInteger(MediaFormat.KEY_CHANNEL_COUNT):channels;
                    sampleRate=f.containsKey(MediaFormat.KEY_SAMPLE_RATE)?f.getInteger(MediaFormat.KEY_SAMPLE_RATE):sampleRate;
                    int encoding=f.containsKey(MediaFormat.KEY_PCM_ENCODING)?f.getInteger(MediaFormat.KEY_PCM_ENCODING):AudioFormat.ENCODING_PCM_16BIT;
                    if(encoding!=AudioFormat.ENCODING_PCM_16BIT)throw new IOException("Unsupported decoded PCM format");
                }else if(ox>=0){
                    if(info.size>0){ByteBuffer pcm=decoder.getOutputBuffer(ox).duplicate().order(ByteOrder.LITTLE_ENDIAN);
                        pcm.position(info.offset);pcm.limit(info.offset+info.size);
                        if(channels<1||channels>8||sampleRate<8000||sampleRate>192000)throw new IOException("Invalid audio format");
                        int frames=info.size/(channels*2);short[] mono=new short[frames];
                        for(int frame=0;frame<frames;frame++){
                            int total=0;for(int c=0;c<channels;c++)total+=pcm.getShort();mono[frame]=(short)(total/channels);
                        }
                        long packetUs=info.presentationTimeUs;
                        java.io.ByteArrayOutputStream chunk=new java.io.ByteArrayOutputStream();
                        double ratio=sampleRate/16000d;
                        for(int j=0;j<frames;j++){
                            double sourceTime=packetUs+(j*1000000d/sampleRate);
                            if(sourceTime<fromMs*1000d||sourceTime>=limit)continue;
                            double absFrame=sourceTime*sampleRate/1000000d;
                            if(absFrame+1e-5>=nextOutputInputFrame){short v=mono[j];chunk.write(v&255);chunk.write((v>>8)&255);nextOutputInputFrame=absFrame+ratio;}
                        }
                        output.write(chunk.toByteArray());
                    }
                    outputDone=(info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                    decoder.releaseOutputBuffer(ox,false);
                }
            }
            if(iterations>=30000)throw new IOException("Decoder did not finish");
            output.flush();
        }finally{if(decoder!=null){try{decoder.stop();}catch(Exception ignored){}decoder.release();}extractor.release();}
    }
    private void fail(String message){if(finished.compareAndSet(false,true)){cleanup();if(callbacks!=null)callbacks.error(message);}}
    private void cleanup(){main.removeCallbacks(timeout);if(recognizer!=null){recognizer.cancel();recognizer.destroy();recognizer=null;}
        try{if(readPipe!=null)readPipe.close();}catch(IOException ignored){}readPipe=null;
        try{if(writePipe!=null)writePipe.close();}catch(IOException ignored){}writePipe=null;
    }
    public void close(){if(finished.compareAndSet(false,true))cleanup();}
}
