package com.sentongoharuna.worldsituationroom;

import java.util.Locale;

/**
 * Real receipt-driven source health; severity (red->green) is distinct from
 * neutral no-data and local-only services. The UI never invents activity.
 * This policy is pure Java so the decision rules can be regression-tested.
 */
public final class Duwm1724SignalFlow {
    private Duwm1724SignalFlow() {}
    public enum Stage {
        OUTAGE("OUTAGE",0xFFD50000,0),        // red - confirmed connection failure
        DEGRADED("DEGRADED",0xFFF57C00,1),     // orange - authentication/provider interruption
        AGED("STALE / CACHED",0xFFFBC02D,2), // yellow - old result, not live
        CONNECTING("CONNECTING",0xFF0D47A1,3),// blue - request in progress
        RECEIVING("NEW RECEIPT",0xFF00ACC1,4),// cyan - actual newly accepted record
        HEALTHY("CURRENT",0xFF00C853,5),     // green - source within its freshness budget
        UNKNOWN("NO RECEIPT",0xFF687786,-1), // grey is not a poor-quality reading
        LOCAL("LOCAL TOOL",0xFFDEE5EF,-1);   // no provider receipt implied
        public final String label;public final int color;public final int rank;
        Stage(String label,int color,int rank){this.label=label;this.color=color;this.rank=rank;}
    }
    public static Stage fromText(String status) {
        String v=status==null?"":status.toUpperCase(Locale.US);
        if(v.contains("LOCAL TOOL")||v.contains("NOT A LIVE FEED"))return Stage.LOCAL;
        if(v.contains("OFFLINE")||v.contains("OUTAGE")||v.contains("SOURCE READ FAILED")||v.contains("FAILED")||v.contains("ERROR"))return Stage.OUTAGE;
        if(v.contains("KEY REQUIRED")||v.contains("DEGRADED")||v.contains("DENIED")||v.contains("DELAYED")||v.contains("BLOCKED"))return Stage.DEGRADED;
        if(v.contains("NO RECEIPT")||v.contains("NOT CONFIGURED")||v.contains("NO DATA")||v.contains("UNKNOWN")||v.contains("NOT RECEIVED")||v.trim().isEmpty())return Stage.UNKNOWN;
        if(v.contains("SAVED")||v.contains("AGED")||v.contains("STALE")||v.contains("CACHED")||v.contains("CACHE"))return Stage.AGED;
        if(v.contains("LOADING")||v.contains("CONNECTING")||v.contains("SYNCING")||v.contains("FETCHING"))return Stage.CONNECTING;
        if(v.contains("NEW RECEIPT")||v.contains("RECEIVING"))return Stage.RECEIVING;
        if(v.contains("RECENT")||v.contains("LIVE")||v.contains("READY")||v.contains("CURRENT"))return Stage.HEALTHY;
        return Stage.UNKNOWN;
    }
    /** A live source goes stale if no new provider update arrives within its window. */
    public static Stage fromFeed(FeedStatus status,long now,long budgetMs,boolean newAccepted) {
        if(status==null)return Stage.UNKNOWN;
        switch(status.state){
            case OFFLINE:return Stage.OUTAGE;
            case KEY_REQUIRED:return Stage.DEGRADED;
            case DELAYED:return Stage.DEGRADED;
            case CACHED:return Stage.AGED;
            case LOADING:
                if(status.updatedAtMs<=0||status.updatedAtMs>now+60_000L)return Stage.UNKNOWN;
                return now-status.updatedAtMs>Math.max(60_000L,budgetMs)?Stage.DEGRADED:Stage.CONNECTING;
            case LIVE:case READY:
                if(status.updatedAtMs<=0||status.updatedAtMs>now+60_000L)return Stage.UNKNOWN;
                if(now-status.updatedAtMs>Math.max(30_000L,budgetMs))return Stage.AGED;
                return newAccepted?Stage.RECEIVING:Stage.HEALTHY;
            default:return Stage.UNKNOWN;
        }
    }
    public static long budgetFor(Signal.Layer layer) {
        if(layer==null)return 15*60_000L;
        switch(layer) {
            case FLIGHTS:case AIRSPACE:return 5*60_000L;
            case SHIPS:return 20*60_000L;
            case NEWS:return 45*60_000L;
            case WEATHER:return 90*60_000L;
            case SATELLITES:case SPACE_WEATHER:return 30*60_000L;
            case MARKETS:return 30*60_000L;
            default:return 15*60_000L;
        }
    }
    public static boolean requiresReview(Stage stage) {
        return stage==Stage.OUTAGE||stage==Stage.DEGRADED||stage==Stage.AGED;
    }
}
