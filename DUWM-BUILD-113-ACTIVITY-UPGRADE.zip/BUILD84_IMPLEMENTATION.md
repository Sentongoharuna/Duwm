# DUWM Build 84 — Globe controls and performance

Base: Build 83. Original Android project and renderer retained.

## Source changes
1. Split crowded globe controls into three usable rows.
2. Keep primary rotation control in first row.
3. Move HUD control to advanced row.
4. Move collision control to advanced row.
5. Move density control to view row.
6. Move reset control to view row.
7. Move legacy toggle to view row.
8. Move focus toggle to view row.
9. Add reduced-motion control.
10. Apply reduced motion directly to renderer.
11. Save reduced-motion preference.
12. Restore reduced-motion preference on dashboard launch.
13. Add observation freshness control.
14. Apply freshness setting to renderer.
15. Save freshness preference.
16. Restore freshness preference on launch.
17. Reduce globe auto-rotation velocity in low-motion mode.
18. Reset both globe renderer and legacy viewport redraw.
19. Add observation-quality summary accessor (valid, invalid, duplicate, rejected).
20. Add descriptive accessible labels for new controls.

Source modified: OperationsMainActivity.java, OperationsGlobeView.java.
No fake data or duplicate globe. No APK/device verification yet.
