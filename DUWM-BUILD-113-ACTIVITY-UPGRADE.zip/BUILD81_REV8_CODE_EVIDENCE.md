# Build 81 Revision 8 — actual Java changes

Modified Duwm1721GlobalQuakesActivity.java. Added 24h/72h/7d time windows, shallow-depth filtering, shared filter predicate, filtered M6+ and tsunami-flag counts, strongest magnitude, average depth, and shareable USGS summary. Preserved existing official feed and navigation. APK and device testing not yet verified.
