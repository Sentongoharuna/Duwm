# Build 81 Rev16 — Original globe improvements

Modified OperationsGlobeView.java (no replacement globe).

- Screen-space marker collision avoidance prevents thousands of dots from overpainting one another.
- Selected observations remain visible even when dense.
- Original provider observations and geographic positions are retained; no fabricated tracking data.
- Compact HUD reduces overlap over the rotating Earth.
- Extended render diagnostics are suppressed in compact mode.
- Live feed delay remains visible.
- Public setters allow command-deck controls to toggle HUD and collision avoidance.
- No new network calls or permissions.

Static source inspection only. APK and on-device behavior not yet tested.
