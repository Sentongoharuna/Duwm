# DUWM Build 89 — Visible Command Bar

Source-level changes in OperationsMainActivity.java:
- New always-visible four-desk quick navigation: Aircraft, Vessels, News, Television.
- Each quick action uses a distinct thin colored outline and dark-blue fill.
- The previous wide horizontal desk navigation is collapsed by default.
- New ALL 19 DESKS control expands or collapses the existing navigation list.
- Focus Mode hides the quick desk bar and all-desks toggle to prioritize the globe.
- Revised home title and connectivity indicator colors.

This is a source change, not a verified compiled APK. No claim of 20 completed functional upgrades.
