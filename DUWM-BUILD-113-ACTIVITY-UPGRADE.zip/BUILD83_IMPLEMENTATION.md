# DUWM Build 83 — Advanced globe interaction

Actual Java modifications:
- `OperationsGlobeView.java`: three marker-density settings alter screen-space collision spacing, without changing observation data.
- `OperationsMainActivity.java`: working density control connected to the renderer.
- Density setting persists using SharedPreferences.
- RESET EARTH control restores the original zoom and orientation.
- Existing globe, sources, 19 desks and prior Build 82 changes preserved.

This is a targeted improvement, not a completed 19-desk overhaul. APK compilation and on-device behavior have not been verified.
