# Build 81 functional radio changes

- Radio Browser station lookup retries three independently hosted HTTPS API mirrors after HTTP/network/JSON failures.
- Each failed connection is disconnected before trying the next mirror.
- Playback errors now stop and release the failed player and show an actionable message.
- Completed streams release the player and update the UI.

These are Android Java behavior changes, not YAML or packaging upgrades. Compilation and device playback are not yet verified.
