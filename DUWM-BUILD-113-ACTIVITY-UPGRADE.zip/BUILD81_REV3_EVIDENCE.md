# Build 81 functional revision 3

Actual Android code change: `Duwm1723GlobalWeatherActivity.java`.

- Adds four actionable weather quick-location buttons: Kampala, Nairobi, London, Tokyo.
- Each sets real latitude and longitude values, updates the place label, and invokes the existing Open-Meteo forecast request.
- No weather values are fabricated; network errors remain visible through the existing status mechanism.
- 48dp+ touch target height for presets.

This is one weather-page functional enhancement (with multiple behaviors), **not** an upgrade to all 19 sections. Android compilation and device verification have not been performed.
