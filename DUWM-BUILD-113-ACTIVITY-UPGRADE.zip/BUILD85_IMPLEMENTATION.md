# DUWM Build 85 — Globe functional upgrades

Modified `OperationsGlobeView.java` from Build 84.

1. Zoom-dependent observation draw budget: 2,200/4,000/8,000.
2. Retain observations in memory when a display marker is suppressed.
3. Display cluster-count badges at closer zoom, only for three or more observations.
4. Use original observation type colours for cluster badges.
5. Bound badge text at 99+ for readability.
6. Draw a high-contrast selected-observation ring above all cluster badges.
7. Restore canvas text alignment after badges.
8. Display received and drawn marker counts separately.
9. Preserve all original globe geographic geometry, controls, and data sources.

These are source-level improvements, not a claim of on-device verification.
