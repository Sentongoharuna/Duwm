# DUWM Build 86 — functional globe changes

Source base: Build 85. Original Android project and data feeds preserved.

## Changes
1. Corrected Java local-variable declaration order for globe control rows (existing Build 85 compile blocker).
2. Added fresh-observations-only renderer filter using source timestamps and provider freshness checks.
3. Preserved selected observation when stale filtering is active.
4. Added an observable freshness-filtered count.
5. Added a dashboard toggle for fresh/all observations.
6. Persisted the selected freshness mode using Android SharedPreferences.
7. Added globe double-tap zoom (1.35x) with gesture timing and distance checks.
8. Preserved pinch-to-zoom and drag-to-rotate interactions.
9. Globe redraws immediately when changing freshness mode without a network request.

Modified: OperationsMainActivity.java; OperationsGlobeView.java.
No fabricated observations. This is not a verified APK or 20 independent upgrades.
