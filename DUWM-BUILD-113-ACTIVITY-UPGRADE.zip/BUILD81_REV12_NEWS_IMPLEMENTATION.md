# Build 81 Revision 12: news intelligence functionality

Modified `Duwm1166NewsDeskActivity.java` in the preserved application.

- New shareable filtered publisher digest containing up to 15 received headlines, dates, sources and original URLs.
- Share action handles empty filters without opening an empty share sheet.
- Digest shows category, total matched count and generation timestamp.
- Digest explicitly marks publisher-supplied information and warns to verify reports.
- News screen displays unique publisher count for the current filters.
- News screen displays last-24-hour report count for the current filters.
- News screen displays received publisher-image count for the current filters.
- New functionality uses the existing NewsStore data and filters, not invented headlines.

Source patch checked. APK compilation and device tests are not yet verified.
