# DUWM Build 88 — visible screen changes

Modified OperationsMainActivity.java in the existing source project.

- Added an always-visible TOOLS + / TOOLS − button on the globe control bar.
- Advanced globe control rows are collapsed on first launch, enlarging the Earth viewport.
- Advanced controls remain functional and can be expanded at any time.
- Full-screen focus now hides the photo rail, source heartbeat rail, share action, map shortcut, and observation-action row.
- Focus mode restores these elements when leaving focus.
- Photo action rail reduced from 40dp to 34dp.
- Photo action buttons reduced from 39dp to 31dp.
- Share button reduced from 39dp to 34dp.
- Map shortcut reduced from 43dp to 35dp.
- Observation action row reduced from 39dp to 35dp.
- Bottom telemetry panel reduced from 117dp to 76dp.

The original globe and source integrations are unchanged. This is source-only verification; APK compilation and visual device testing remain outstanding.
