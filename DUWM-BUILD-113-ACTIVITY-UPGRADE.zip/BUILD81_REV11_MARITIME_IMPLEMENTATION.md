# Build 81 Revision 11 — Maritime functional changes

Modified `GevMarineActivity.java` in the existing DUWM Android application.

- AIS stale-only toggle based on the existing source-receipt freshness classification.
- Stale-only filter combines with existing region, vessel type, speed, recent and search filters.
- Filter updates map markers, radar and vessel register together without a network request.
- Shareable AIS digest calculates visible vessel counts, moving/stale counts and cargo/tanker/passenger counts from current received records.
- Share includes actual source and receipt time, partial coverage warning and not-for-navigation disclaimer.
- Accessible labels added to both controls.

No vessel positions are simulated. Android compilation and on-device behavior are not yet verified.
