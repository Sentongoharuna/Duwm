# Build 81 Rev 15 - Actual camera UI implementation

File: Duwm1718MonitorsCamActivity.java

- Recording control shows a live mm:ss elapsed clock using the existing telemetry tick.
- Accessibility announces elapsed and remaining seconds.
- Recording control pulses during the final ten seconds.
- Stop/finish resets control alpha and accessibility label.
- Framing-grid control text now reflects the state immediately after each toggle.

These changes do not claim to implement all 19 sections. Android compilation and device testing are not yet verified.
