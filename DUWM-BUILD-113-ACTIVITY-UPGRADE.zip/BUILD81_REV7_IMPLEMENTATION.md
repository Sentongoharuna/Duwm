# Build 81 functional revision 7 — Weather refresh

Actual source change: `app/src/main/java/com/sentongoharuna/worldsituationroom/Duwm1723GlobalWeatherActivity.java`.

- Adds a user-controlled 15-minute automatic forecast refresh switch.
- Stores the choice in Android SharedPreferences and restores it on reopening.
- Runs refresh only while the Weather activity is visible; cancels callbacks on pause/destroy.
- Prevents overlapping requests by checking the existing `fetching` flag.
- Reuses the existing Open-Meteo HTTP request, validation, coordinate checks, attribution and error handling.
- Keeps a one-minute scheduler tick but only requests when 15 minutes have elapsed.

This is a source-level feature. No claim of device validation or APK compilation is made.
