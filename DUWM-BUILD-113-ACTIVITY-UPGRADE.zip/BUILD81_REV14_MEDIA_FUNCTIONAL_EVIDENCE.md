# Build 81 revision 14 — Native MediaDesk functionality

Modified existing `MediaDeskActivity.java` (not a replacement application).

- Native audio/video connection watchdog stops streams stuck connecting after 20 seconds.
- Watchdog cancels when Android reports a prepared, playing stream.
- Watchdog cancels on Stop and when switching sources.
- Remember selected Radio/TV/News/Earth Images/Public Cameras desk across app sessions.
- Add one-tap CLEAR search control to the media directory.
- Preserve prior source, station, player, camera and sharing functions.

Verification: Java source edited; archive integrity tested. APK compilation and device playback not verified.
