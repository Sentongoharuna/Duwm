Build 81 additional functional changes (source verified):
1. Radio stream connection times out after 20 seconds rather than hanging indefinitely.
2. Timeout is cancelled after successful playback preparation.
3. Playback generation guards stale asynchronous callbacks from changing the current station.
4. Stop cancels pending timeout and invalidates prior playback callbacks.
5. Activity destruction invalidates pending directory fetches.
6. Saved-station action checks map view for null before invalidation.
APK compilation and on-device playback remain unverified.
