# Build 82 — original globe renderer upgrade

Modified OperationsGlobeView.java.

- Adaptive screen-space collision grid: 15dp at overview, 11dp at intermediate zoom, 8dp at close zoom.
- Marker collision suppression retains observations and does not falsify data.
- Aircraft/vessel trail animation limited to closer zoom to prevent global route clutter.
- Reduced pulse ring size and amplitude to improve map legibility.
- Selected observation remains exempt from collision suppression.

ZIP verified; APK compilation and device behavior not yet verified.
