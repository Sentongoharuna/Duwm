# DUWM Build 87 — Globe observation interaction corrections

Source: `OperationsGlobeView.java`

1. Single shared source-aware freshness predicate for rendering and tap selection.
2. Fresh-only mode now prevents selection of hidden stale markers.
3. Existing selected observations remain selectable even when stale, matching their visual protection.
4. Selected observation receives accessibility announcement with provider and observation age.
5. Added read-only selected observation summary for command-dashboard use.
6. Added explicit selection clearing without deleting received data.
7. All changes preserve the original globe geometry and provider observations.

ZIP integrity tested. Android compilation and phone tests not performed.
