# DUWM Build 81 — Radio directory usability

Modified: `app/src/main/java/com/sentongoharuna/worldsituationroom/Duwm1166RadioAtlasActivity.java`

1. Default radio map reduced from 490dp to 210dp so stations are reachable sooner.
2. Initial map toggle label now accurately says compact/list first.
3. Added a visible REFRESH STATIONS action that retries the currently selected country.
4. Added an accessibility description for the retry control.
5. Replaced the ambiguous empty-state notice with actionable refresh/country guidance.
6. Reworded the radio map subtitle to explain source-based positioning and playback.

These are radio-page source modifications, not a claim that remote radio streams always work. No changes to the original globe or aircraft tracker. APK compilation and device behavior not verified.
