# Build 81 functional revision 6 — Radio directory

Changed Android source: app/src/main/java/com/sentongoharuna/worldsituationroom/Duwm1166RadioAtlasActivity.java

- Added a worldwide, server-side Radio Browser station-name search with minimum two-character validation.
- Added clear-search action to return to selected region.
- Switching regional tabs clears the remote search so regional filtering works again.
- Increased maximum fetched station results from 75 to 250, retaining incremental on-screen pagination and the existing streaming playback behavior.
- URL-encoded remote search terms to prevent malformed search queries.
- Preserved mirror failover, playback timeout, and existing saved stations.

Not 1,000 website integrations. This implements an additional actual directory search capability using Radio Browser's distributed API, not scraping or claiming rights to third-party content. No APK compilation or Android device validation performed in this environment.
