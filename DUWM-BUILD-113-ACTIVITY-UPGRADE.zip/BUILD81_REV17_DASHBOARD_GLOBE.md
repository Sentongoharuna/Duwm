# Build 81 revision 17 — dashboard integration of globe renderer controls

Modified: OperationsMainActivity.java

- Adds real HUD compact/detail control wired to OperationsGlobeView.setCompactHud.
- Adds marker collision ON/OFF control wired to OperationsGlobeView.setMarkerCollisionAvoidance.
- Persists both settings using Android SharedPreferences.
- Restores preferences when the dashboard recreates the globe.
- Hides observation overlay and HUD during Focus mode to clear the globe.
- Keeps the existing globe and all existing observation data sources.

Static source checks passed; Android APK compilation and device behavior remain unverified.
