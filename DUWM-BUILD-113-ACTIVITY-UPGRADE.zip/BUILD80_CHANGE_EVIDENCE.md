# DUWM Build 80 — source change evidence

Base: DUWM-BUILD-79-SOURCE.zip. Original globe and prior project source retained.

Modified: app/src/main/java/com/sentongoharuna/worldsituationroom/RunningballV25WorldwideAirActivity.java

1. Added a user-selectable aircraft tap behavior: full details page or inline map preview.
2. Inline preview updates actual selected aircraft data without forcing navigation.
3. Saves tap behavior in Android SharedPreferences and restores it on reopening.
4. Adds an accessible 48dp tap-mode control.
5. Adds reset-aircraft-filters action for airborne/altitude/callsign labels.
6. Persists reset filter values and updates the map and labels immediately.

Verification: source delta inspected and ZIP CRC checked. No successful APK compile or device test claimed.
