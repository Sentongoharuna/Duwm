# DUWM Build 88 — Globe gesture and interaction upgrade

Modified actual Android source `OperationsGlobeView.java` (preserving original globe).

- Pinch zoom expanded to 3.0x for inspecting crowded areas.
- Double-tap zoom now cycles back to full-Earth view at maximum zoom.
- Touch-slop detection prevents small finger jitter from rotating Earth.
- Tap-selection is suppressed after a genuine drag.
- Tap-selection is suppressed after pinch scaling.
- Larger touch targets for selecting markers at close zoom.
- Public zoomIn/zoomOut/setGlobeZoom/getGlobeZoom methods for dashboard integration.
- Public selected-object state for future contextual controls.
- Zoom bounds enforced centrally.

These are code-level changes, not 20 independently verified upgrades. Compilation and device behavior require testing.
