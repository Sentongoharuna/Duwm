# Build 81 Revision 9 — Multi-section Android changes

Based on REV8 source. No workflow changes.

- `Duwm1723GlobalWeatherActivity.java` — Add eight additional worldwide weather presets, keeping coordinate-driven API retrieval
- `Duwm1723GlobalWeatherActivity.java` — Use real geographic latitude coordinates for the eight added weather locations
- `Duwm1723GlobalWeatherActivity.java` — Use real geographic longitude coordinates for the eight added weather locations
- `Duwm1166RadioAtlasActivity.java` — Provide keyboard search action for radio station discovery
- `Duwm1166RadioAtlasActivity.java` — Allow Radio keyboard Search to perform a worldwide server search directly
- `Duwm1166RadioAtlasActivity.java` — Provide immediate local Radio station-filter reset without network access
- `Duwm1166NewsDeskActivity.java` — Add keyboard search affordance to the News desk
- `Duwm1166NewsDeskActivity.java` — Execute News search and dismiss keyboard on IME Search

APK compilation and on-device behavior not yet verified. These are targeted changes, not a completed 19-section overhaul.
