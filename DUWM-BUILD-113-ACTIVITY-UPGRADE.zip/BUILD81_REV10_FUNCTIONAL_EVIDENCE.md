# DUWM Build 81 Revision 10 — Functional improvements

Modified existing Android Java source (not YAML):

- GevSatelliteActivity.java: persistent horizon filter using computed elevation >= 10 degrees for user-selected region, show 45/100/250 records, controls update without network request, invalid estimated positions excluded from horizon results. Positions are approximate Kepler predictions, not live satellite telemetry.
- Duwm1718MonitorsCamActivity.java: direct camera framing grid toggle with persistent preference and immediate preview redraw.

Source-level verification: modifications applied to existing activity files. Android compilation and physical-device behavior not verified. Prior Build 81 source retained.
