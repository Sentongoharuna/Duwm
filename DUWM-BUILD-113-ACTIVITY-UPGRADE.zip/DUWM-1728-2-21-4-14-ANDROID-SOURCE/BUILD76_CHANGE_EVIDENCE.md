# DUWM Build 76 — Implemented source changes

Base: Build 75 ZIP, preserving existing Android source and original globe.

Modified file: app/src/main/java/com/sentongoharuna/worldsituationroom/RunningballV25WorldwideAirActivity.java

1. Added aircraft callsign-label overlay control (LABELS: ON/OFF).
2. Callsign or ICAO labels draw beside actual received markers when map zoom >= 2x; no synthetic positions.
3. Added altitude-band cycling control (ALL, LOW <3000 m, MID 3000–8999 m, HIGH >=9000 m).
4. Altitude band filters both drawn markers and marker selection via passesFilter().
5. Saved both settings in Android SharedPreferences and restored on reopen.
6. Updated visible counts to reflect the new altitude filtering.
7. Added accessibility descriptions to new controls.

Verification: ZIP CRC checked. No Android APK compilation or on-device validation has been performed. This is not a 60-upgrade completion.
