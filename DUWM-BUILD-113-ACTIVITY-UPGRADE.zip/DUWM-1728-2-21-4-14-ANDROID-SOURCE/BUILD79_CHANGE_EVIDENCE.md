# DUWM Build 79 — implemented source delta
Base: Build 78 source ZIP. No new globe or replacement application.

Modified file: app/src/main/java/com/sentongoharuna/worldsituationroom/RunningballV25WorldwideAirActivity.java

1. Adds an Android ACTION_SEND chooser for a selected aircraft's actual displayed provider report.
2. Prevents sharing placeholder details when no aircraft is selected.
3. Includes an explicit OpenSky observation disclaimer, without inventing recorded routes.
4. Adds long-press copy of selected aircraft details to the Android clipboard.
5. Gives feedback after clipboard copy.
6. Adds accessibility instructions for the detail field.

This is a source implementation, not an APK/device verification. Other prior build changes retained.
