package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.net.Uri;
import android.util.AtomicFile;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Atomic private raw-measurement sidecars, bound to the exact source URI. */
public final class Duwm1728MeasurementStore {
    private static final int SCHEMA = 1;
    private static final int INPUT_FIELDS = 46;
    private static final int MAX_BYTES = 8 * 1024 * 1024;
    private static final String TAG = "DUWM-MEASUREMENTS";
    private Duwm1728MeasurementStore() {}

    private static String key(Uri source) throws Exception {
        if(source==null)throw new IOException("Measurement source URI required");
        byte[] bytes=MessageDigest.getInstance("SHA-256").digest(source.toString().getBytes(StandardCharsets.UTF_8));
        StringBuilder hex=new StringBuilder();
        for(byte value:bytes)hex.append(String.format(Locale.US,"%02x",value&255));
        return hex.toString();
    }
    private static AtomicFile file(Context context,Uri source,boolean create) throws Exception {
        if(context==null)throw new IOException("Measurement context required");
        File directory=new File(context.getFilesDir(),"measurement-timelines");
        if(create&&!directory.isDirectory()&&!directory.mkdirs())throw new IOException("Measurement storage unavailable");
        return new AtomicFile(new File(directory,key(source)+".json"));
    }

    /** Prefer the four-argument overload so an empty capture retains its disclosure preset. */
    public static synchronized boolean save(Context context,Uri source,List<Duwm1728Measurements.Sample> samples) {
        boolean allowed=samples!=null&&!samples.isEmpty();
        if(samples!=null)for(Duwm1728Measurements.Sample sample:samples)
            if(sample==null||!sample.coordinatesAllowed)allowed=false;
        return save(context,source,samples,allowed);
    }

    /** An empty successful save is still a measured-capture marker. No end-snapshot fallback. */
    public static synchronized boolean save(Context context,Uri source,List<Duwm1728Measurements.Sample> samples,
                                             boolean coordinatesAllowed) {
        AtomicFile atomic=null;FileOutputStream output=null;
        try {
            JSONArray values=new JSONArray();
            for(Duwm1728Measurements.Sample sample:Duwm1728Measurements.normalize(samples))
                values.put(encode(sample.inputCopy()));
            JSONObject data=new JSONObject();
            data.put("schema",SCHEMA);data.put("policy",1);data.put("source_key",key(source));
            data.put("measurement_capture",true);data.put("coordinates_allowed",coordinatesAllowed);
            data.put("samples",values);
            byte[] bytes=data.toString().getBytes(StandardCharsets.UTF_8);
            if(bytes.length>MAX_BYTES)throw new IOException("Measurement timeline exceeds size limit");
            atomic=file(context,source,true);output=atomic.startWrite();output.write(bytes);atomic.finishWrite(output);
            return true;
        } catch(Exception failure) {
            if(atomic!=null&&output!=null)atomic.failWrite(output);
            Log.w(TAG,"Measurement timeline could not be saved",failure);return false;
        }
    }

    public static synchronized boolean hasCapture(Context context,Uri source) {
        try{return read(context,source)!=null;}
        catch(Exception failure){Log.w(TAG,"Measurement marker could not be read",failure);return false;}
    }
    public static synchronized boolean coordinatesAllowed(Context context,Uri source) {
        try{JSONObject value=read(context,source);return value!=null&&bool(value,"coordinates_allowed");}
        catch(Exception failure){Log.w(TAG,"Coordinate disclosure preset could not be read",failure);return false;}
    }
    public static synchronized List<Duwm1728Measurements.Sample> load(Context context,Uri source) {
        try {
            JSONObject value=read(context,source);
            if(value==null)return Collections.emptyList();
            JSONArray samples=value.getJSONArray("samples");
            List<Duwm1728Measurements.Sample> result=new ArrayList<>();
            for(int index=0;index<samples.length();index++)
                result.add(Duwm1728Measurements.sample(decode(samples.getJSONObject(index))));
            return Duwm1728Measurements.normalize(result);
        } catch(Exception failure) {
            Log.w(TAG,"Measurement timeline could not be read",failure);return Collections.emptyList();
        }
    }

    private static JSONObject read(Context context,Uri source) throws Exception {
        if(context==null||source==null)return null;
        AtomicFile atomic=file(context,source,false);
        try(InputStream input=atomic.openRead();ByteArrayOutputStream bytes=new ByteArrayOutputStream()) {
            byte[] buffer=new byte[4096];int count;
            while((count=input.read(buffer))!=-1) {
                if(bytes.size()+count>MAX_BYTES)throw new IOException("Measurement metadata exceeds size limit");
                bytes.write(buffer,0,count);
            }
            JSONObject value=new JSONObject(new String(bytes.toByteArray(),StandardCharsets.UTF_8));
            if(value.length()!=6||integer(value,"schema")!=SCHEMA||integer(value,"policy")!=1
                    ||!key(source).equals(string(value,"source_key",64))
                    ||!bool(value,"measurement_capture"))throw new IOException("Measurement schema or source identity invalid");
            bool(value,"coordinates_allowed");
            JSONArray samples=value.getJSONArray("samples");
            if(samples.length()>Duwm1728Measurements.MAX_SAMPLES)throw new IOException("Too many measurement samples");
            return value;
        } catch(FileNotFoundException missing){return null;}
    }

    private static JSONObject encode(Duwm1728Measurements.Input in) throws Exception {
        JSONObject value=new JSONObject();
        value.put("now_elapsed_ms",in.nowElapsedMs);value.put("source_ms",in.sourceMs);value.put("utc_ms",in.utcMs);
        value.put("recording",in.recording);value.put("coordinates_allowed",in.coordinatesAllowed);
        value.put("location_enabled",in.locationEnabled);value.put("location_available",in.locationAvailable);
        value.put("location_mocked",in.locationMocked);value.put("fix_elapsed_ms",in.fixElapsedMs);
        number(value,"latitude",in.latitude);number(value,"longitude",in.longitude);
        number(value,"horizontal_accuracy_m",in.horizontalAccuracyMeters);number(value,"altitude_m",in.altitudeMeters);
        number(value,"vertical_accuracy_m",in.verticalAccuracyMeters);number(value,"speed_mps",in.speedMps);
        number(value,"speed_accuracy_mps",in.speedAccuracyMps);
        value.put("location_source",in.locationSource);value.put("altitude_reference",in.altitudeReference);
        value.put("heading_enabled",in.headingEnabled);number(value,"heading_degrees",in.headingDegrees);
        value.put("heading_elapsed_ms",in.headingElapsedMs);value.put("heading_accuracy",in.headingAccuracy);
        value.put("heading_source",in.headingSource);
        value.put("fps_enabled",in.fpsEnabled);number(value,"preview_fps",in.previewFps);
        value.put("fps_elapsed_ms",in.fpsElapsedMs);value.put("fps_window_ms",in.fpsWindowMs);
        value.put("fps_frames",in.fpsFrames);value.put("fps_source",in.fpsSource);
        value.put("place",in.place);value.put("place_source",in.placeSource);
        number(value,"place_query_latitude",in.placeQueryLatitude);number(value,"place_query_longitude",in.placeQueryLongitude);
        value.put("place_fix_elapsed_ms",in.placeFixElapsedMs);value.put("place_received_elapsed_ms",in.placeReceivedElapsedMs);
        value.put("weather_enabled",in.weatherEnabled);value.put("weather_provider",in.weatherProvider);
        value.put("weather_description",in.weatherDescription);value.put("weather_source",in.weatherSource);
        number(value,"temperature_c",in.temperatureC);number(value,"wind_mps",in.windMps);
        number(value,"weather_query_latitude",in.weatherQueryLatitude);number(value,"weather_query_longitude",in.weatherQueryLongitude);
        value.put("weather_code",in.weatherCode);value.put("weather_utc_ms",in.weatherUtcMs);
        value.put("weather_received_elapsed_ms",in.weatherReceivedElapsedMs);
        return value;
    }

    private static Duwm1728Measurements.Input decode(JSONObject value) throws Exception {
        if(value.length()!=INPUT_FIELDS)throw new IOException("Measurement sample field count invalid");
        Duwm1728Measurements.Input in=new Duwm1728Measurements.Input();
        in.nowElapsedMs=integer(value,"now_elapsed_ms");in.sourceMs=integer(value,"source_ms");in.utcMs=integer(value,"utc_ms");
        in.recording=bool(value,"recording");in.coordinatesAllowed=bool(value,"coordinates_allowed");
        in.locationEnabled=bool(value,"location_enabled");in.locationAvailable=bool(value,"location_available");
        in.locationMocked=bool(value,"location_mocked");in.fixElapsedMs=integer(value,"fix_elapsed_ms");
        in.latitude=number(value,"latitude");in.longitude=number(value,"longitude");
        in.horizontalAccuracyMeters=number(value,"horizontal_accuracy_m");in.altitudeMeters=number(value,"altitude_m");
        in.verticalAccuracyMeters=number(value,"vertical_accuracy_m");in.speedMps=number(value,"speed_mps");
        in.speedAccuracyMps=number(value,"speed_accuracy_mps");
        in.locationSource=string(value,"location_source",64);in.altitudeReference=string(value,"altitude_reference",16);
        in.headingEnabled=bool(value,"heading_enabled");in.headingDegrees=number(value,"heading_degrees");
        in.headingElapsedMs=integer(value,"heading_elapsed_ms");in.headingAccuracy=intValue(value,"heading_accuracy");
        in.headingSource=string(value,"heading_source",64);
        in.fpsEnabled=bool(value,"fps_enabled");in.previewFps=number(value,"preview_fps");
        in.fpsElapsedMs=integer(value,"fps_elapsed_ms");in.fpsWindowMs=integer(value,"fps_window_ms");
        in.fpsFrames=intValue(value,"fps_frames");in.fpsSource=string(value,"fps_source",64);
        in.place=string(value,"place",100);in.placeSource=string(value,"place_source",64);
        in.placeQueryLatitude=number(value,"place_query_latitude");in.placeQueryLongitude=number(value,"place_query_longitude");
        in.placeFixElapsedMs=integer(value,"place_fix_elapsed_ms");in.placeReceivedElapsedMs=integer(value,"place_received_elapsed_ms");
        in.weatherEnabled=bool(value,"weather_enabled");in.weatherProvider=string(value,"weather_provider",64);
        in.weatherDescription=string(value,"weather_description",80);in.weatherSource=string(value,"weather_source",64);
        in.temperatureC=number(value,"temperature_c");in.windMps=number(value,"wind_mps");
        in.weatherQueryLatitude=number(value,"weather_query_latitude");in.weatherQueryLongitude=number(value,"weather_query_longitude");
        in.weatherCode=intValue(value,"weather_code");in.weatherUtcMs=integer(value,"weather_utc_ms");
        in.weatherReceivedElapsedMs=integer(value,"weather_received_elapsed_ms");
        return in;
    }

    private static void number(JSONObject object,String key,double value) throws Exception {
        object.put(key,Double.isFinite(value)?value:JSONObject.NULL);
    }
    private static double number(JSONObject object,String key) throws Exception {
        Object value=object.get(key);
        if(value==JSONObject.NULL)return Double.NaN;
        if(!(value instanceof Number))throw new IOException("Numeric measurement required: "+key);
        double result=((Number)value).doubleValue();
        if(!Double.isFinite(result))throw new IOException("Nonfinite measurement: "+key);
        return result;
    }
    private static long integer(JSONObject object,String key) throws Exception {
        Object value=object.get(key);
        if(!(value instanceof Long)&&!(value instanceof Integer))throw new IOException("Integer measurement required: "+key);
        return ((Number)value).longValue();
    }
    private static int intValue(JSONObject object,String key) throws Exception {
        long value=integer(object,key);
        if(value<Integer.MIN_VALUE||value>Integer.MAX_VALUE)throw new IOException("Integer measurement outside range: "+key);
        return (int)value;
    }
    private static boolean bool(JSONObject object,String key) throws Exception {
        Object value=object.get(key);
        if(!(value instanceof Boolean))throw new IOException("Boolean measurement required: "+key);
        return (Boolean)value;
    }
    private static String string(JSONObject object,String key,int maximum) throws Exception {
        Object value=object.get(key);
        if(!(value instanceof String)||((String)value).codePointCount(0,((String)value).length())>maximum)
            throw new IOException("Measurement text outside schema: "+key);
        return (String)value;
    }
}
