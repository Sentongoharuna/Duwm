# Build 70 — implemented source changes

Source: `app/src/main/java/com/sentongoharuna/worldsituationroom/RunningballV25WorldwideAirActivity.java`

1. Provider diagnostics start collapsed to prioritize the actual aircraft map.
2. New tap-to-expand/tap-to-hide source details control.
3. Aircraft map increased from 305dp to 460dp tall.
4. Map zoom controls reduced from 48dp to 40dp high.
5. Vertical spacing and text padding tightened.
6. Compact pan/zoom/aircraft instructions.

The original globe and existing camera are preserved. This is not a 60-upgrade release. APK compilation and device behavior remain unverified.
