# DUWM Build 72 — Source change evidence

Base: Build 71 source ZIP, all original files retained.

Changed: app/src/main/java/com/sentongoharuna/worldsituationroom/RunningballV25WorldwideAirActivity.java

1. Added an aircraft-map expand/restore control.
2. Expanded aircraft-map mode uses 760dp height (standard remains 520dp).
3. Map size changes update the existing FlightPlot rather than creating a new map.
4. Added an accessible description to the map-size control.
5. Added a compact network-status line below the map.
6. Network-status line updates from actual snapshot status, last-good age and next-check label.

Source integrity and Java text transformations checked. Android compilation and device behavior NOT verified. These are six targeted changes, NOT 60 upgrades.
