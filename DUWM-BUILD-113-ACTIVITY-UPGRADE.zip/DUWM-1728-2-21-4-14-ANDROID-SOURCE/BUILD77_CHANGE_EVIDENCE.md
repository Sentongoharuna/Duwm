# DUWM Build 77 — Aircraft map presentation controls

Base: Build 76 ZIP; original globe and other application source retained.

Modified source: app/src/main/java/com/sentongoharuna/worldsituationroom/RunningballV25WorldwideAirActivity.java

1. Added latitude/longitude grid visibility toggle.
2. Grid visibility is applied directly to the map Canvas drawing.
3. Grid preference persists across page restarts.
4. Added three aircraft marker sizes: small, normal, large.
5. Marker radius now responds to the selected size and map zoom.
6. Marker size preference persists across page restarts.
7. Both display controls have accessibility descriptions.
8. Both controls repaint the map immediately without requesting new network data.

Evidence: search source for gridVisible, markerSize, displayBar, gridToggle and markerToggle.
Verification: ZIP CRC test only. Android compilation and on-device testing are not yet verified. This is not completion of 60 substantial upgrades.
