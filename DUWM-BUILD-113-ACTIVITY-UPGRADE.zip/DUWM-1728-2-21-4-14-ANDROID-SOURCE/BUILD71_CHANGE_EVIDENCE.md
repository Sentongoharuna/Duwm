BUILD 71 SOURCE CHANGE EVIDENCE
Base: Build 70 source ZIP

aircraft:
 - Aircraft plot height increased from 460dp to 520dp
 - Reduced surrounding margins for map prominence
camera:
 - Larger recording label and screen-reader action
 - Reduced top-bar height 40dp to 36dp
 - Reduced tools button width 82dp to 72dp
 - Reduced dock padding for more preview area

APK build and on-device behavior NOT VERIFIED. These six edits are not 60 upgrades.
