# DUWM Build 78 — source change evidence

Base: DUWM-BUILD-77-SOURCE.zip. The original globe and other application pages are retained.

Modified: app/src/main/java/com/sentongoharuna/worldsituationroom/RunningballV25WorldwideAirActivity.java

1. Adds callsign label collision avoidance to the aircraft map, using screen-space occupancy cells (76dp × 20dp).
2. Leaves all received aircraft markers visible; only redundant overlapping text labels are suppressed.
3. Adds a live ON/OFF toggle to allow labels to overlap when desired.
4. Persists the user's label collision preference using SharedPreferences.
5. Updates the map immediately on toggle without requesting network data.
6. Provides an accessibility description for the new toggle.

This is a targeted aircraft readability improvement, not 60 upgrades. Compilation and device testing remain unverified.
