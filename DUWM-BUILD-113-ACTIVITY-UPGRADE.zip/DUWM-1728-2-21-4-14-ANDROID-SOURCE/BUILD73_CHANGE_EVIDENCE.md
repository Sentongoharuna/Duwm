# DUWM Build 73 — Source changes

Base: Build 72 ZIP, preserving all original project files.

Changed: `app/src/main/java/com/sentongoharuna/worldsituationroom/RunningballV25WorldwideAirActivity.java`

1. Added aircraft automatic-refresh pause/resume control.
2. Pause prevents the periodic network refresh while retaining the existing map display.
3. Resume requests a fresh provider snapshot.
4. Refresh preference is saved across app sessions.
5. Map expanded/restored preference is saved across app sessions.
6. Initial map height and button label now match the saved map-size preference.
7. Network status explicitly reports when automatic updates are paused.
8. Added accessibility description to refresh control.

Source checks: ZIP CRC and source assertions. APK compilation/device behavior not verified. Not a completed 60-upgrade release.
