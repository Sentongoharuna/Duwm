# Build 74 — source evidence (not APK verification)

Base: Build 73 source ZIP.

Modified: `app/src/main/java/com/sentongoharuna/worldsituationroom/RunningballV25WorldwideAirActivity.java`

1. Toggle airborne-only aircraft based on provider-reported altitude >100m.
2. Persist aircraft filter in SharedPreferences.
3. Toggle verified two-fix displacement connector visibility.
4. Persist trail visibility preference.
5. Render altitude-band marker colors (green/cyan/amber) with legend.
6. Display visible vs total provider-received aircraft counts.
7. Respect active filter when selecting map aircraft.
8. Add accessible touch targets and labels to layer controls.

Modified: `app/build.gradle.kts` — versionCode 172874, versionName 74.

Not verified: GitHub build, APK installation, runtime behavior. The original globe is preserved.
