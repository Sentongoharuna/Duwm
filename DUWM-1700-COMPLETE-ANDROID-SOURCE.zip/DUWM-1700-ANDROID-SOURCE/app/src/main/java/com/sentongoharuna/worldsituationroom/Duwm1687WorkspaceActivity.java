package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;
import java.util.Locale;

/** 1687 deep-workspace for every ORIGINAL native desk. It does not replace a provider or the globe.
 * Only locally received provider readings are used as values. Visual sector illustrations are labelled schematic.
 */
public final class Duwm1687WorkspaceActivity extends Activity {
    public static final String EXTRA_DESK="duwm_1687_workspace_index";
    private static final String[] TABS={"LIVE","DETAILS","HISTORY","COMPARE","SOURCES","TOOLS"};
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable tick=new Runnable(){@Override public void run(){if(!isFinishing()&&!isDestroyed()){drawTab();handler.postDelayed(this,30000L);}}};
    private LinearLayout body,tabbar;private ScrollView contentScroller;
    private TextView title,sourceStatus;
    private int deskIndex=0,tab=0;private boolean recentHistory=false,compareAll=false;
    private Duwm1683DeskCatalog.Desk desk;
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String value,int sp,int color,boolean bold){
        TextView v=new TextView(this);v.setText(value);v.setTextSize(sp);v.setTextColor(color);
        v.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",Typeface.NORMAL));
        v.setGravity(Gravity.CENTER_VERTICAL);v.setPadding(dp(10),dp(8),dp(10),dp(8));return v;
    }
    private GradientDrawable box(int color,boolean emphasis){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(12));
        d.setStroke(dp(1),emphasis?DuwmUnifiedTheme.ACCENT:DuwmUnifiedTheme.BORDER);return d;
    }
    private TextView action(String name,Runnable fn){
        TextView v=text(name,12,DuwmUnifiedTheme.ACCENT_BRIGHT,true);v.setGravity(Gravity.CENTER);
        v.setBackground(box(DuwmUnifiedTheme.PANEL_SELECTED,true));v.setOnClickListener(w->fn.run());
        v.setContentDescription(name);return v;
    }
    private LinearLayout panel(String heading){
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(9),dp(8),dp(9),dp(9));p.setBackground(box(DuwmUnifiedTheme.PANEL,false));
        TextView h=text(heading,13,DuwmUnifiedTheme.ACCENT_BRIGHT,true);p.addView(h);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(12);body.addView(p,lp);
        return p;
    }
    private TextView item(LinearLayout p,String label,String value){
        TextView head=text(label,11,DuwmUnifiedTheme.MUTED,true);p.addView(head);
        TextView field=text(value==null||value.trim().isEmpty()?"NOT REPORTED":value,15,DuwmUnifiedTheme.TEXT,false);
        field.setTextIsSelectable(true);p.addView(field);return field;
    }
    public static void openSource(Activity origin,Duwm1683DeskCatalog.Desk d){
        int i=0;for(int k=0;k<Duwm1683DeskCatalog.ALL.length;k++)if(Duwm1683DeskCatalog.ALL[k].title.equals(d.title)){i=k;break;}
        Intent intent=new Intent(origin,Duwm1687WorkspaceActivity.class);intent.putExtra(EXTRA_DESK,i);
        intent.putExtra("duwm_1687_initial_tab",4);origin.startActivity(intent);
    }
    public static void open(Activity origin,Duwm1683DeskCatalog.Desk d){
        int i=0;for(int k=0;k<Duwm1683DeskCatalog.ALL.length;k++)if(Duwm1683DeskCatalog.ALL[k].title.equals(d.title)){i=k;break;}
        Intent intent=new Intent(origin,Duwm1687WorkspaceActivity.class);intent.putExtra(EXTRA_DESK,i);origin.startActivity(intent);
    }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(DuwmUnifiedTheme.BACKGROUND);getWindow().setNavigationBarColor(DuwmUnifiedTheme.BACKGROUND);
        deskIndex=Math.min(Math.max(0,getIntent().getIntExtra(EXTRA_DESK,0)),Duwm1683DeskCatalog.ALL.length-1);
        desk=Duwm1683DeskCatalog.ALL[deskIndex];
        tab=Math.min(5,Math.max(0,getIntent().getIntExtra("duwm_1687_initial_tab",0)));
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(DuwmUnifiedTheme.BACKGROUND);setContentView(shell);
        LinearLayout toolbar=new LinearLayout(this);toolbar.setPadding(dp(8),dp(7),dp(8),dp(5));toolbar.setGravity(Gravity.CENTER_VERTICAL);
        shell.addView(toolbar,new LinearLayout.LayoutParams(-1,dp(55)));
        toolbar.addView(action("‹",this::finish),new LinearLayout.LayoutParams(dp(45),-1));
        title=text("1700 / "+desk.title.toUpperCase(Locale.US),15,DuwmUnifiedTheme.TEXT,true);title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);toolbar.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        toolbar.addView(action("OPEN DATA",this::nativePage),new LinearLayout.LayoutParams(dp(90),-1));
        sourceStatus=text("CHECKING ACTUAL SOURCE RECEIPTS",11,DuwmUnifiedTheme.ACCENT_BRIGHT,true);
        sourceStatus.setContentDescription("Tap to inspect provider timestamps, errors and receipt evidence");
        sourceStatus.setOnClickListener(v->startActivity(new Intent(this,Duwm1671SourceStatusActivity.class)));
        sourceStatus.setBackground(box(DuwmUnifiedTheme.PANEL_SELECTED,false));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(39));sp.setMargins(dp(13),0,dp(13),dp(7));shell.addView(sourceStatus,sp);
        HorizontalScrollView tabs=new HorizontalScrollView(this);tabs.setHorizontalScrollBarEnabled(false);
        tabbar=new LinearLayout(this);tabbar.setPadding(dp(8),0,dp(8),0);tabs.addView(tabbar);
        shell.addView(tabs,new LinearLayout.LayoutParams(-1,dp(50)));
        ScrollView scroller=new ScrollView(this);contentScroller=scroller;scroller.setFillViewport(true);
        shell.addView(scroller,new LinearLayout.LayoutParams(-1,0,1));
        body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(14),dp(10),dp(14),dp(22));scroller.addView(body);
        LinearLayout foot=new LinearLayout(this);foot.setPadding(dp(7),dp(5),dp(7),dp(7));foot.setGravity(Gravity.CENTER_VERTICAL);
        shell.addView(foot,new LinearLayout.LayoutParams(-1,dp(59)));
        foot.addView(action("‹ PREV",()->move(-1)),new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout.LayoutParams b=new LinearLayout.LayoutParams(0,-1,2);b.leftMargin=dp(7);b.rightMargin=dp(7);
        foot.addView(action("SHARE PORTRAIT",()->Duwm1687ShareCard.share(this,desk)),b);
        foot.addView(action("NEXT ›",()->move(1)),new LinearLayout.LayoutParams(0,-1,1));
        drawTab();
    }
    private void move(int delta){deskIndex=(deskIndex+delta+Duwm1683DeskCatalog.ALL.length)%Duwm1683DeskCatalog.ALL.length;
        desk=Duwm1683DeskCatalog.ALL[deskIndex];tab=0;title.setText("1700 / "+desk.title.toUpperCase(Locale.US));drawTab();}
    private void nativePage(){startActivity(Duwm1683DeskCatalog.intent(this,desk));}
    private void shareReceipt(Duwm1684DeskDiagnostics.Snapshot s){
        String value="DUWM 1700 / "+desk.title+"\nProvider: "+s.provider+"\nState: "+s.state+
            "\nReturned value: "+s.count+"\nReceived: "+s.received+"\nSource time: "+s.sourceTime+
            "\nCoverage: "+s.coverage+"\nError / note: "+s.error+
            "\nBased on stored device receipts. Not a guarantee of live worldwide coverage.";
        Intent share=new Intent(Intent.ACTION_SEND);share.setType("text/plain");
        share.putExtra(Intent.EXTRA_SUBJECT,"DUWM 1700 / "+desk.title+" source receipt");
        share.putExtra(Intent.EXTRA_TEXT,value);startActivity(Intent.createChooser(share,"Share desk receipt"));
    }
    private void addChart(LinearLayout target,int height){
        Duwm1685ReceiptHistory.capture(this,desk);
        Duwm1685ReceiptChart chart=new Duwm1685ReceiptChart(this,desk);
        target.addView(chart,new LinearLayout.LayoutParams(-1,dp(height)));
    }
    /** Source-backed visual replaces the old schematic on the LIVE tab of all 19 desks. */
    private void receiptOverview(){
        List<Duwm1685ReceiptHistory.Point> history=Duwm1685ReceiptHistory.read(this,desk);
        int numeric=0,lastDay=0,older=0;long now=System.currentTimeMillis();
        for(Duwm1685ReceiptHistory.Point r:history){
            if(r.numerical)numeric++;
            if(r.sourceAt>0&&r.sourceAt<=now&&now-r.sourceAt<=86400000L)lastDay++;
            else older++;
        }
        Duwm1690EvidenceBars observations=new Duwm1690EvidenceBars(this);
        observations.setValues(desk.title.toUpperCase(Locale.US)+" / DEVICE RECEIPTS",
            new String[]{"RECEIPTS STORED","NUMERIC VALUES","WITHIN 24H","OLDER / UNDATED"},
            new long[]{history.size(),numeric,lastDay,older});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(232));lp.bottomMargin=dp(10);
        body.addView(observations,lp);
    }
    private void subhead(String s){TextView v=text(s,12,DuwmUnifiedTheme.MUTED,true);body.addView(v);}
    private void visual(int height){
        Duwm1687OpsVisual art=new Duwm1687OpsVisual(this,desk);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(height));p.bottomMargin=dp(10);body.addView(art,p);
    }
    private void actions(LinearLayout host,String first,Runnable f,String second,Runnable g){
        LinearLayout row=new LinearLayout(this);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(49));lp.topMargin=dp(8);host.addView(row,lp);
        LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(0,-1,1);a.rightMargin=dp(7);
        row.addView(action(first,f),a);row.addView(action(second,g),new LinearLayout.LayoutParams(0,-1,1));
    }
    private void drawTab(){
        if(body==null||desk==null)return;
        Duwm1685ReceiptHistory.capture(this,desk);
        final Duwm1684DeskDiagnostics.Snapshot s=Duwm1684DeskDiagnostics.read(this,desk);
        sourceStatus.setText("PROVIDER  /  "+s.provider+"  •  "+s.state+"  •  RECEIVED "+s.received);
        boolean review=s.state.contains("NO RECEIPT")||s.state.contains("FAILED")||s.state.contains("AGED")||s.state.contains("ERROR");
        sourceStatus.setTextColor(review?0xFFE8B988:DuwmUnifiedTheme.ACCENT_BRIGHT);
        tabbar.removeAllViews();
        for(int i=0;i<TABS.length;i++){
            final int index=i;
            TextView button=text(TABS[i],11,i==tab?DuwmUnifiedTheme.TEXT:DuwmUnifiedTheme.MUTED,true);
            button.setGravity(Gravity.CENTER);button.setBackground(box(i==tab?DuwmUnifiedTheme.PANEL_SELECTED:DuwmUnifiedTheme.PANEL,i==tab));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(TABS[i].length()>9?114:98),dp(43));p.rightMargin=dp(5);
            tabbar.addView(button,p);button.setOnClickListener(v->{tab=index;drawTab();
                if(contentScroller!=null)contentScroller.scrollTo(0,0);});
        }
        body.removeAllViews();
        subhead("WORLD SITUATION ROOM  /  ORIGINAL COMMAND / 1700  /  "+desk.category.toUpperCase(Locale.US));
        if(tab==0){
            receiptOverview();
            LinearLayout p=panel("01   LIVE OPERATIONAL SOURCE");
            item(p,"DESK",desk.title.toUpperCase(Locale.US));item(p,"SOURCE STATE",s.state);
            item(p,"ACTUAL RETURNED VALUE",s.count);item(p,"PROVIDER",s.provider);
            item(p,"RECEIPT / SOURCE TIME",s.received+"  /  "+s.sourceTime);
            item(p,"DATA STATUS",s.error==null||s.error.isEmpty()?"No provider error recorded in this receipt":s.error);
            actions(p,"OPEN NATIVE LIVE PAGE",this::nativePage,"SHARE NEW 9:16",()->Duwm1687ShareCard.share(this,desk));
            LinearLayout change=panel("LATEST VERIFIED RECEIPT CHANGE");
            java.util.List<Duwm1685ReceiptHistory.Point> history=Duwm1685ReceiptHistory.read(this,desk);
            if(history.size()<2){item(change,"COMPARISON","Two distinct provider receipts are required to compare this desk.");}
            else{
                Duwm1685ReceiptHistory.Point last=history.get(history.size()-1),previous=history.get(history.size()-2);
                if(last.numerical&&previous.numerical){
                    item(change,"SOURCE VALUE CHANGE",String.format(Locale.US,"%+.2f",last.value-previous.value)+
                        "  ("+String.format(Locale.US,"%.2f",previous.value)+" → "+String.format(Locale.US,"%.2f",last.value)+")");
                    item(change,"EVIDENCE","Difference between two stored numeric provider receipts; not movement or rate of events.");
                }else item(change,"COMPARISON","Provider supplied non-numeric values; no invented change calculated.");
            }
            LinearLayout next=panel("02   SECTOR MISSION / NATIVE MAP & MEDIA");item(next,"FUNCTION",desk.description);
            item(next,"COVERAGE / LIMITATION",desk.howToRead);
        }else if(tab==1){
            visual(218);
            LinearLayout data=panel("01   RECORDED DETAIL / PROVIDER RETURN");
            item(data,"RECEIVED VALUE",s.count);item(data,"RECORDED SOURCE TIME",s.sourceTime);
            item(data,"LAST LOCAL RECEIPT",s.received);item(data,"GEOGRAPHIC / PROVIDER SCOPE",s.coverage);
            item(data,"DATA INTERPRETATION",s.explanation);
            LinearLayout nativeView=panel("02   OPEN ORIGINAL MAP, FEED OR PLAYER");
            item(nativeView,"EXISTING NATIVE VIEW",desk.subtitle);
            item(nativeView,"REAL DATA ONLY",desk.howToRead);
            actions(nativeView,"OPEN NATIVE DATA",this::nativePage,"SOURCE HEALTH",()->startActivity(new Intent(this,Duwm1671SourceStatusActivity.class)));
        }else if(tab==2){
            LinearLayout hist=panel("01   RECEIPT TIMELINE / THIS DEVICE");addChart(hist,231);
            List<Duwm1685ReceiptHistory.Point> pts=Duwm1685ReceiptHistory.read(this,desk);
            item(hist,"OBSERVED SNAPSHOTS",Duwm1685ReceiptHistory.label(this,desk));
            item(hist,"CHART RULE",pts.size()<2?"At least two different real receipt times are required for a trend.":
                "Values are plotted only if every received point has a genuine numeric field.");
            LinearLayout p=panel("02   SOURCE TIMESTAMPS");
            actions(p,recentHistory?"SHOW ALL STORED RECEIPTS":"FILTER LAST 24H RECEIPTS",()->{recentHistory=!recentHistory;drawTab();},
                compareAll?"COMPARE CURRENT SECTOR":"COMPARE ALL DESKS",()->{compareAll=!compareAll;tab=3;drawTab();});
            java.text.SimpleDateFormat format=new java.text.SimpleDateFormat("dd MMM yyyy HH:mm:ss 'UTC'",Locale.US);
            format.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            if(pts.isEmpty())item(p,"NO HISTORY","No distinct provider receipt has been saved on this device.");
            int visiblePoints=0;
            for(int i=pts.size()-1;i>=0;i--){Duwm1685ReceiptHistory.Point point=pts.get(i);
                if(recentHistory && (point.sourceAt<=0 || System.currentTimeMillis()-point.sourceAt>86400000L))continue;
                visiblePoints++;
                item(p,String.format(Locale.US,"RECEIPT %02d",i+1),format.format(new java.util.Date(point.sourceAt))+"  /  "+(point.numerical?String.format(Locale.US,"%.4f",point.value):"NON-NUMERIC"));}
            if(recentHistory && visiblePoints==0)item(p,"LAST 24 HOURS","No qualifying genuine source receipt was stored in this time window.");
        }else if(tab==3){
            visual(174);
            LinearLayout compare=panel("01   REAL SOURCE-STATE COMPARISON");
            actions(compare,compareAll?"COMPARE SELECTED CATEGORY":"COMPARE ALL 19 DESKS",()->{compareAll=!compareAll;drawTab();},
                "OPEN REAL SOURCE",this::nativePage);
            item(compare,"SELECTED DESK",desk.title+" / "+s.state+" / "+s.count);
            int shown=0;
            for(Duwm1683DeskCatalog.Desk other:Duwm1683DeskCatalog.ALL){
                if(other==desk || (!compareAll&&!other.category.equals(desk.category)))continue;
                Duwm1684DeskDiagnostics.Snapshot peer=Duwm1684DeskDiagnostics.read(this,other);
                TextView peerLink=item(compare,other.title.toUpperCase(Locale.US),peer.state+"  •  "+peer.count+"  •  "+peer.provider);
                peerLink.setTextIsSelectable(false);
                peerLink.setContentDescription("Inspect "+other.title+" actual source receipts");
                peerLink.setOnClickListener(v->{desk=other;
                  for(int k=0;k<Duwm1683DeskCatalog.ALL.length;k++)if(Duwm1683DeskCatalog.ALL[k]==other){deskIndex=k;break;}
                  title.setText("1700 / "+desk.title.toUpperCase(Locale.US));tab=0;drawTab();});
                if(++shown>=(compareAll?18:5))break;
            }
            LinearLayout limit=panel("02   COMPARISON LIMITATIONS");
            item(limit,"HOW TO READ","These are separately received states from different providers or tools. Counts are NOT comparable measurements or evidence of events in the same location.");
            actions(limit,"ALL 19 SOURCE STATES",()->startActivity(new Intent(this,DuwmOptionsActivity.class)),"OPEN NATIVE DESK",this::nativePage);
        }else if(tab==4){
            LinearLayout p=panel("01   SOURCE PROVENANCE & ERROR DIAGNOSTICS");
            item(p,"RECEIVING PROVIDER",s.provider);item(p,"STATUS",s.state);
            item(p,"LATEST RECEIPT",s.received);item(p,"SOURCE-REPORTED OBSERVATION",s.sourceTime);
            item(p,"AVAILABLE COVERAGE",s.coverage);item(p,"LAST FAILURE / NOTE",s.error);
            item(p,"PROVENANCE CAUTION",s.explanation);
            actions(p,"ALL SOURCE HEALTH",()->startActivity(new Intent(this,Duwm1671SourceStatusActivity.class)),"SHARE TEXT RECEIPT",()->shareReceipt(s));
        }else{
            visual(174);
            LinearLayout p=panel("01   EXECUTE ORIGINAL NATIVE DESK");
            item(p,"NATIVE MODULE",desk.title+"  /  "+desk.subtitle);
            actions(p,"OPEN LIVE DESK",this::nativePage,"SHARE NEW 9:16",()->Duwm1687ShareCard.share(this,desk));
            LinearLayout w=panel("02   CROSS-SECTOR WORKSPACE");
            actions(w,"ALL 19 DESKS",()->startActivity(new Intent(this,DuwmOptionsActivity.class)),"SOURCE DIAGNOSTICS",()->startActivity(new Intent(this,Duwm1671SourceStatusActivity.class)));
            item(w,"DATA HONESTY","No fabricated camera positions, vessel paths, flights, TV availability, source timestamps or market prices. Actual source availability depends on provider and network.");
        }
        TextView disclaimer=text("1700 / Real provider receipts only. Animated interface geometry is NOT a detected object, live geographic position or provider-provided track. Use the original native desk for geographic observations and playable media.",11,DuwmUnifiedTheme.MUTED,false);
        body.addView(disclaimer);
    }
    @Override protected void onResume(){super.onResume();handler.removeCallbacks(tick);handler.postDelayed(tick,30000L);drawTab();}
    @Override protected void onPause(){handler.removeCallbacks(tick);super.onPause();}
}
