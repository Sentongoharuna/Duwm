package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.content.ClipData;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.util.UUID;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.MediaController;
import android.text.Editable;
import android.text.TextWatcher;
import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Real source media workspace: native audio/video, not a list of outbound websites. */
public final class MediaDeskActivity extends Activity {
  static final int BG=Color.rgb(8,24,36), PANEL=Color.rgb(15,67,83), LINE=Color.rgb(40,145,162), WHITE=Color.rgb(217,233,236), MUTED=Color.rgb(108,148,157), CYAN=Color.rgb(57,181,195), AMBER=Color.rgb(71,210,219);
  static final String[] MODES={"RADIO","TV STATIONS","WORLD NEWS","EARTH IMAGES","PUBLIC CAMERAS"};
  private final Handler ui=new Handler(Looper.getMainLooper());
  private final ExecutorService io=Executors.newFixedThreadPool(4);
  private final AtomicInteger request=new AtomicInteger(0);
  private final ArrayList<Item> items=new ArrayList<>();
  private LinearLayout records,playerBox,cameraInput;
  private Duwm1678VisualKit.PulsePanel mediaBand;
  private TextView status,playing,modeTitle,sourceSummary,visibleSourceCount,mediaFullScreenButton;
  private EditText query;private boolean largePlayer=false,alphabetical=false,secureSourcesOnly=false,focusPlayer=false,savedMediaOnly=false;private int shownLimit=45;private TextView sortMedia,secureFilter,focusPlayerControl,savedMediaControl;private ScrollView recordsScroll;private Duwm1690EvidenceBars mediaEvidence;
  private boolean showMediaSourceChart=false;private int mediaSort=0;
  private LinearLayout.LayoutParams videoSize,cameraSize;
  private VideoView video;
  private ImageView cameraView;
  private TextView cameraReload;
  private Item currentCamera;
  private long cameraSequence=0;
  private final Runnable cameraRefresh=new Runnable(){@Override public void run(){
    if(active && mode.equals("PUBLIC CAMERAS") && currentCamera!=null &&
       currentCamera.image!=null && !currentCamera.image.toLowerCase(Locale.ROOT).contains(".m3u8")){
      duwmP4CameraFrame(currentCamera);ui.postDelayed(this,60000L);
    }
  }};
  private MediaPlayer audio;
  private Item lastSelectedMedia;
  private String mode="RADIO";
  private boolean active=true;
  private String playingUrl="";
  private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
  private TextView text(String t,int size,int color,boolean strong){TextView v=new TextView(this);v.setText(t);v.setTextColor(color);v.setTextSize(size);if(strong)v.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return v;}
  private GradientDrawable panel(){return Duwm1678VisualKit.panel(this,mode,false);}
  private String utc(){SimpleDateFormat f=new SimpleDateFormat("dd MMM yyyy HH:mm 'UTC'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date());}
  static final class Item {String title,meta,url,image,source,detail;Item(String t,String m,String u,String i,String s,String d){title=t;meta=m;url=u;image=i;source=s;detail=d;}}
  private void label(LinearLayout parent,String value,int size,int color,boolean strong){TextView t=text(value,size,color,strong);parent.addView(t);}
  @Override public void onCreate(Bundle state){super.onCreate(state);setTheme(android.R.style.Theme_Material_NoActionBar);
    getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    String requested=getIntent().getStringExtra("mode");if(requested!=null)for(String m:MODES)if(m.equals(requested))mode=m;
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);root.setPadding(dp(8),dp(3),dp(8),dp(5));setContentView(root);Duwm1167SafeArea.install(this,root);
    LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);root.addView(top);
    ImageView mark=new ImageView(this);mark.setImageResource(R.drawable.develop_uganda_logo);top.addView(mark,new LinearLayout.LayoutParams(dp(30),dp(30)));
    LinearLayout brand=new LinearLayout(this);brand.setPadding(dp(10),0,0,0);brand.setOrientation(LinearLayout.VERTICAL);top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
    TextView mediaHeader=text("DUWM 1700  /  MEDIA INTELLIGENCE",14,WHITE,true);
    brand.addView(Duwm1693Chrome.title(mediaHeader));
    TextView back=text("GLOBE",12,CYAN,true);back.setPadding(dp(10),dp(12),dp(10),dp(12));top.addView(back);back.setOnClickListener(v->finish());
    modeTitle=text(mode,18,WHITE,true);modeTitle.setPadding(0,dp(3),0,dp(2));root.addView(modeTitle);
    status=text("NO SOURCE RECEIVED",12,MUTED,false);status.setPadding(0,0,0,dp(3));root.addView(status);
    mediaBand=new Duwm1678VisualKit.PulsePanel(this,mode);
    LinearLayout.LayoutParams mediaBandLp=new LinearLayout.LayoutParams(-1,dp(49));mediaBandLp.bottomMargin=dp(4);
    root.addView(mediaBand,mediaBandLp);
    mediaBand.setVisibility(View.GONE); // source status and player now lead; no duplicate decorative banner.
    android.widget.HorizontalScrollView tabScroll=new android.widget.HorizontalScrollView(this);
    tabScroll.setHorizontalScrollBarEnabled(false);root.addView(tabScroll,new LinearLayout.LayoutParams(-1,dp(38)));
    LinearLayout tabHolder=new LinearLayout(this);tabHolder.setOrientation(LinearLayout.HORIZONTAL);tabScroll.addView(tabHolder);
    for(String name:MODES){TextView b=text(name,12,Duwm1678VisualKit.accent(name),true);
      b.setGravity(Gravity.CENTER);b.setPadding(dp(9),dp(10),dp(9),dp(10));
      b.setBackground(Duwm1678VisualKit.panel(this,name,name.equals(mode)));
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(name.equals("PUBLIC CAMERAS")?146:115),dp(34));
      lp.setMargins(dp(2),dp(2),dp(2),dp(2));tabHolder.addView(b,lp);
      b.setOnClickListener(v->{if(!mode.equals(name)){stopPlayback();lastSelectedMedia=null;
        mode=name;shownLimit=45;modeTitle.setText(mode);mediaBand.setMode(name);
        for(int k=0;k<tabHolder.getChildCount();k++){View tab=tabHolder.getChildAt(k);
          tab.setBackground(Duwm1678VisualKit.panel(this,MODES[k],MODES[k].equals(mode)));}
        query.setText("");cameraInput.setVisibility(mode.equals("PUBLIC CAMERAS")?View.VISIBLE:View.GONE);
        cameraReload.setVisibility(mode.equals("PUBLIC CAMERAS")?View.VISIBLE:View.GONE);
        if(mediaFullScreenButton!=null)mediaFullScreenButton.setVisibility(mode.equals("TV STATIONS")?View.VISIBLE:View.GONE);
        load();}});
    }
    LinearLayout rowSearch=new LinearLayout(this);rowSearch.setGravity(Gravity.CENTER_VERTICAL);root.addView(rowSearch);
    query=new EditText(this);query.setSingleLine(true);query.setHint("Search available records / stations");query.setTextSize(14);query.setTextColor(WHITE);query.setHintTextColor(MUTED);rowSearch.addView(query,new LinearLayout.LayoutParams(0,dp(40),1));
    TextView refresh=text("REFRESH",12,CYAN,true);refresh.setPadding(dp(10),dp(12),dp(4),dp(12));rowSearch.addView(refresh);refresh.setOnClickListener(v->load());
    sortMedia=text("SORT: SOURCE",11,CYAN,true);sortMedia.setPadding(dp(7),dp(12),0,dp(12));rowSearch.addView(sortMedia);
    sortMedia.setOnClickListener(v->{mediaSort=(mediaSort+1)%3;shownLimit=45;
      sortMedia.setText(mediaSort==1?"SORT: A–Z":mediaSort==2?"SORT: IMAGES FIRST":"SORT: SOURCE");render();});
    secureFilter=text("HTTPS SOURCES / ALL",11,CYAN,true);secureFilter.setPadding(dp(8),dp(9),dp(8),dp(9));
    root.addView(secureFilter,new LinearLayout.LayoutParams(-1,dp(38)));
    secureFilter.setOnClickListener(v->{secureSourcesOnly=!secureSourcesOnly;shownLimit=45;
      secureFilter.setText(secureSourcesOnly?"HTTPS SOURCE LINKS ONLY / ON":"HTTPS SOURCES / ALL");render();});
    savedMediaControl=text("☆ SHOW ALL REAL SOURCE LISTINGS  /  TAP FOR SAVED",12,CYAN,true);
    savedMediaControl.setPadding(dp(8),dp(12),dp(8),dp(12));root.addView(savedMediaControl,new LinearLayout.LayoutParams(-1,dp(43)));
    savedMediaControl.setOnClickListener(v->{savedMediaOnly=!savedMediaOnly;
      savedMediaControl.setText(savedMediaOnly?"★ SAVED SOURCE LISTINGS ONLY  /  TAP FOR ALL":"☆ ALL SOURCE LISTINGS  /  TAP FOR SAVED");render();});
    query.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){shownLimit=45;render();}public void afterTextChanged(Editable e){} });
    playerBox=new LinearLayout(this);playerBox.setOrientation(LinearLayout.VERTICAL);playerBox.setPadding(dp(8),dp(5),dp(8),dp(5));playerBox.setBackground(Duwm1678VisualKit.panel(this,mode,true));root.addView(playerBox);
    playing=text("IN-APP PLAYER  /  Select an available station",13,WHITE,true);playerBox.addView(playing);
    video=new VideoView(this);video.setVisibility(View.GONE);videoSize=new LinearLayout.LayoutParams(-1,dp(300));playerBox.addView(video,videoSize);
    MediaController videoController=new MediaController(this);
    videoController.setAnchorView(video);video.setMediaController(videoController);
    cameraView=new ImageView(this);cameraView.setScaleType(ImageView.ScaleType.FIT_CENTER);
    cameraView.setBackgroundColor(Color.rgb(5,14,23));cameraView.setVisibility(View.GONE);
    cameraSize=new LinearLayout.LayoutParams(-1,dp(300));playerBox.addView(cameraView,cameraSize);
    android.widget.HorizontalScrollView playerControlsScroll=new android.widget.HorizontalScrollView(this);
    playerControlsScroll.setHorizontalScrollBarEnabled(false);
    playerBox.addView(playerControlsScroll,new LinearLayout.LayoutParams(-1,dp(55)));
    LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER_VERTICAL);
    playerControlsScroll.addView(controls);
    TextView toggle=text("PAUSE / RESUME",12,CYAN,true);toggle.setPadding(0,dp(12),dp(20),dp(8));controls.addView(toggle);
    toggle.setOnClickListener(v->{try{
       if(audio!=null){if(audio.isPlaying()){audio.pause();playing.setText("PAUSED  /  Radio");}else{audio.start();playing.setText("ON AIR  /  Radio");}}
       else if(video!=null&&video.getVisibility()==View.VISIBLE){if(video.isPlaying()){video.pause();playing.setText("PAUSED  /  TV");}else{video.start();playing.setText("PLAYING TV");}}
    }catch(Exception e){playing.setText("PLAYBACK UNAVAILABLE  /  "+shortText(e.getMessage(),90));}});
    TextView prevMedia=text("PREVIOUS SOURCE",12,CYAN,true);
    prevMedia.setPadding(0,dp(12),dp(14),dp(8));controls.addView(prevMedia);
    prevMedia.setOnClickListener(v->playAdjacentMediaSource(-1));
    TextView nextMedia=text("NEXT SOURCE",12,CYAN,true);nextMedia.setPadding(0,dp(12),dp(14),dp(8));controls.addView(nextMedia);
    nextMedia.setOnClickListener(v->playNextMediaSource());
    TextView stop=text("STOP",12,AMBER,true);stop.setPadding(0,dp(12),dp(15),dp(8));controls.addView(stop);stop.setOnClickListener(v->stopPlayback());
    focusPlayerControl=text("FOCUS PLAYER",12,CYAN,true);focusPlayerControl.setPadding(0,dp(12),dp(12),dp(8));controls.addView(focusPlayerControl);
    focusPlayerControl.setOnClickListener(v->{focusPlayer=!focusPlayer;
      if(recordsScroll!=null)recordsScroll.setVisibility(focusPlayer?View.GONE:View.VISIBLE);
      if(visibleSourceCount!=null)visibleSourceCount.setVisibility(focusPlayer?View.GONE:View.VISIBLE);
      applyPlayerSize();
      focusPlayerControl.setText(focusPlayer?"SHOW SOURCE LIST":"FOCUS PLAYER");});
    TextView resize=text("EXPAND PLAYER",12,CYAN,true);resize.setPadding(0,dp(12),dp(12),dp(8));controls.addView(resize);
    resize.setOnClickListener(v->{largePlayer=!largePlayer;applyPlayerSize();
       resize.setText(largePlayer?"COMPACT PLAYER":"EXPAND PLAYER");});
    LinearLayout mediaActions=new LinearLayout(this);mediaActions.setGravity(Gravity.CENTER_VERTICAL);
    playerBox.addView(mediaActions);
    mediaFullScreenButton=text("▣ FULL-SCREEN TV",12,CYAN,true);
    mediaFullScreenButton.setPadding(dp(6),dp(13),dp(8),dp(12));mediaActions.addView(mediaFullScreenButton,new LinearLayout.LayoutParams(0,-2,1));
    mediaFullScreenButton.setVisibility(mode.equals("TV STATIONS")?View.VISIBLE:View.GONE);
    mediaFullScreenButton.setOnClickListener(v->openFullScreenMedia());
    TextView shareCurrent=text("▣ SHARE CURRENT CARD",12,AMBER,true);
    shareCurrent.setPadding(dp(8),dp(13),dp(2),dp(12));mediaActions.addView(shareCurrent,new LinearLayout.LayoutParams(0,-2,1));
    shareCurrent.setOnClickListener(v->{if(lastSelectedMedia==null){playing.setText("SELECT A REAL TV OR RADIO SOURCE FIRST");return;}
      shareSourceCard(lastSelectedMedia,new ImageView(this));});
    cameraReload=text("REFRESH CAMERA FRAME",11,CYAN,true);cameraReload.setPadding(dp(6),dp(8),0,dp(8));
    playerBox.addView(cameraReload);
    cameraReload.setVisibility(mode.equals("PUBLIC CAMERAS")?View.VISIBLE:View.GONE);
    cameraReload.setOnClickListener(v->{
      if(mode.equals("PUBLIC CAMERAS") && currentCamera!=null)play(currentCamera);
    });
    TextView info=text("Audio and video use Android's native player. Availability depends on the broadcaster and stream format.",10,MUTED,false);
    playerBox.addView(info,new LinearLayout.LayoutParams(-1,-2));
    sourceSummary=text("SOURCE STATUS / not checked",11,MUTED,false);sourceSummary.setPadding(0,dp(10),0,dp(9));root.addView(sourceSummary);
    cameraInput=new LinearLayout(this);cameraInput.setGravity(Gravity.CENTER_VERTICAL);
    EditText cameraUrl=new EditText(this);cameraUrl.setTextColor(WHITE);cameraUrl.setHintTextColor(MUTED);
    cameraUrl.setTextSize(11);cameraUrl.setSingleLine(true);
    cameraUrl.setHint("Optional authorized HTTPS .jpg / .png / .m3u8 camera URL");
    cameraInput.addView(cameraUrl,new LinearLayout.LayoutParams(0,dp(46),1));
    TextView setCamera=text("ADD",12,CYAN,true);setCamera.setPadding(dp(10),dp(10),dp(10),dp(10));
    cameraInput.addView(setCamera);
    cameraInput.setVisibility(mode.equals("PUBLIC CAMERAS")?View.VISIBLE:View.GONE);
    root.addView(cameraInput);
    String stored=getPreferences(0).getString("duwm_p4_camera_url","");if(!stored.isEmpty())cameraUrl.setText(stored);
    setCamera.setOnClickListener(v->{String url=cameraUrl.getText().toString().trim();
      if(!duwmP4MediaUrl(url) || !(url.toLowerCase(Locale.ROOT).contains(".jpg") ||
          url.toLowerCase(Locale.ROOT).contains(".jpeg") ||
          url.toLowerCase(Locale.ROOT).contains(".png") ||
          url.toLowerCase(Locale.ROOT).contains(".m3u8"))){
        status.setText("CAMERA NOT ADDED / Provide an authorized HTTPS JPEG, PNG or HLS feed");return;
      }
      getPreferences(0).edit().putString("duwm_p4_camera_url",url).apply();
      if(mode.equals("PUBLIC CAMERAS"))load();
    });
    mediaEvidence=new Duwm1690EvidenceBars(this);
    visibleSourceCount=text("RECEIVED SOURCES / WAITING",11,CYAN,true);
    visibleSourceCount.setPadding(dp(6),dp(6),dp(6),dp(6));root.addView(visibleSourceCount);
    recordsScroll=new ScrollView(this);recordsScroll.setFillViewport(true);root.addView(recordsScroll,new LinearLayout.LayoutParams(-1,0,1));
    records=new LinearLayout(this);records.setOrientation(LinearLayout.VERTICAL);recordsScroll.addView(records);
    load();
  }
  private void applyPlayerSize(){
    int px=dp(focusPlayer?540:(largePlayer?510:300));
    if(videoSize!=null&&video!=null){videoSize.height=px;video.setLayoutParams(videoSize);}
    if(cameraSize!=null&&cameraView!=null){cameraSize.height=px;cameraView.setLayoutParams(cameraSize);}
  }
  private void playNextMediaSource(){playAdjacentMediaSource(1);}
  private void playAdjacentMediaSource(int direction){
    if(!(mode.equals("RADIO")||mode.equals("TV STATIONS")||mode.equals("PUBLIC CAMERAS"))){
      playing.setText("SELECT A RADIO, TV OR CAMERA MODE FOR PLAYBACK");return;}
    String filter=query==null?"":query.getText().toString().trim().toLowerCase(Locale.ROOT);
    ArrayList<Item> choices=new ArrayList<>();
    for(Item i:items){String link=i.url!=null?i.url:i.image;
      if(secureSourcesOnly&&(link==null||!link.startsWith("https://")))continue;
      if(savedMediaOnly&&!savedMedia(i))continue;
      if(!filter.isEmpty()&&!(i.title+" "+i.meta+" "+i.detail).toLowerCase(Locale.ROOT).contains(filter))continue;
      choices.add(i);
    }
    if(mediaSort==1)choices.sort((a,b)->String.valueOf(a.title).compareToIgnoreCase(String.valueOf(b.title)));
    else if(mediaSort==2)choices.sort((a,b)->Boolean.compare(b.image!=null&&b.image.startsWith("https://"),
                                                            a.image!=null&&a.image.startsWith("https://")));
    if(choices.isEmpty()){playing.setText("NO RECEIVED MEDIA SOURCES MATCH THESE FILTERS");return;}
    int selectedIndex=-1;if(lastSelectedMedia!=null)for(int i=0;i<choices.size();i++){
      if(choices.get(i)==lastSelectedMedia||(choices.get(i).url!=null&&choices.get(i).url.equals(lastSelectedMedia.url))){selectedIndex=i;break;}}
    int next=selectedIndex<0?(direction<0?choices.size()-1:0):(selectedIndex+direction+choices.size())%choices.size();
    play(choices.get(next));
  }
  private void stopPlayback(){ui.removeCallbacks(cameraRefresh);cameraSequence++;currentCamera=null;
    if(cameraView!=null)cameraView.setVisibility(View.GONE);
    getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    playingUrl="";if(audio!=null){try{audio.reset();audio.release();}catch(Exception ignored){}audio=null;}if(video!=null){video.stopPlayback();video.setVisibility(View.GONE);}if(playing!=null)playing.setText("IN-APP PLAYER  /  Stopped");}
  @Override protected void onStop(){stopPlayback();super.onStop();}
  @Override protected void onResume(){super.onResume();if(mediaBand!=null)mediaBand.start();}
  @Override protected void onPause(){if(mediaBand!=null)mediaBand.stop();super.onPause();}
  @Override public void onDestroy(){active=false;request.incrementAndGet();stopPlayback();io.shutdownNow();super.onDestroy();}
  private void openFullScreenMedia(){
    Item it=lastSelectedMedia;
    if(it==null||!mode.equals("TV STATIONS")||it.url==null||!it.url.startsWith("https://")){
      playing.setText("FULL SCREEN IS AVAILABLE AFTER SELECTING A DIRECT TV STREAM");return;}
    Intent intent=new Intent(this,NativeMediaActivity.class);
    intent.putExtra(NativeMediaActivity.EXTRA_KIND,NativeMediaActivity.KIND_VIDEO);
    intent.putExtra(NativeMediaActivity.EXTRA_TITLE,it.title);
    intent.putExtra(NativeMediaActivity.EXTRA_SOURCE,it.source);
    intent.putExtra(NativeMediaActivity.EXTRA_URL,it.url);
    startActivity(intent);
  }
  private void play(Item it){
    if(it!=null)lastSelectedMedia=it;
    if(mode.equals("PUBLIC CAMERAS")){duwmP4PlayCamera(it);return;}
    if(it.url==null||!it.url.startsWith("https://")){playing.setText("UNAVAILABLE  /  No HTTPS stream supplied");return;}
    stopPlayback();playingUrl=it.url;playing.setText("CONNECTING  /  "+it.title);
    if(mode.equals("TV STATIONS")){
      video.setVisibility(View.VISIBLE);getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
      video.setOnPreparedListener(mp->{if(!active||!it.url.equals(playingUrl))return;playing.setText("PLAYING TV  /  "+it.title);mediaBand.setReceipt("TV PLAYER READY / "+it.title,items.size(),true);video.start();});
      video.setOnErrorListener((mp,what,extra)->{playing.setText("TV STREAM FAILED  /  Provider unavailable or unsupported codec ("+what+")");return true;});
      video.setVideoURI(Uri.parse(it.url));video.requestFocus();video.start();
    }else{
      try{
        MediaPlayer p=new MediaPlayer();audio=p;
        p.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
        p.setDataSource(this,Uri.parse(it.url));
        p.setOnPreparedListener(mp->{if(audio!=mp||!active||!playingUrl.equals(it.url))return;mp.start();playing.setText("ON AIR  /  "+it.title);mediaBand.setReceipt("RADIO AUDIO RECEIVED / "+it.title,items.size(),true);});
        p.setOnErrorListener((mp,what,extra)->{if(audio==mp)playing.setText("RADIO UNAVAILABLE  /  Provider or audio codec error ("+what+")");return true;});
        p.prepareAsync();
      }catch(Exception ex){stopPlayback();playing.setText("RADIO UNAVAILABLE  /  "+shortText(ex.getMessage(),120));}
    }
  }
  private void sourceImage(ImageView view,String source){if(source==null||!source.startsWith("https://"))return;view.setTag(source);
    io.execute(()->{try{if(!goodImageUri(source))return;byte[] bytes=getBytes(source,1300000); BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(bytes,0,bytes.length,o);if(o.outWidth<1||o.outHeight<1)return;
      o.inJustDecodeBounds=false;o.inSampleSize=Math.max(1,Math.max(o.outWidth/480,o.outHeight/320));Bitmap b=BitmapFactory.decodeByteArray(bytes,0,bytes.length,o);
      if(b!=null)ui.post(()->{if(active&&source.equals(view.getTag())){view.setImageBitmap(b);view.setVisibility(View.VISIBLE);}});
    }catch(Exception ignored){/* Empty source image is an honest state, never synthesize one. */}});
  }
  private boolean goodImageUri(String input){try{URI u=new URI(input);String host=u.getHost();return "https".equalsIgnoreCase(u.getScheme())&&host!=null&&host.indexOf('.')>0&&!host.equals("localhost")&&!host.endsWith(".local")&&host.indexOf(':')<0;}catch(Exception e){return false;}}
  private String shortText(String s,int max){if(s==null)return "Not provided";s=s.replaceAll("[\\p{Cntrl}]+"," ").trim();return s.length()>max?s.substring(0,max)+"...":s;}
  private byte[] getBytes(String path,int max) throws Exception {if(!path.startsWith("https://"))throw new java.io.IOException("HTTPS required");HttpURLConnection c=(HttpURLConnection)new URL(path).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(12000);c.setInstanceFollowRedirects(true);c.setRequestProperty("User-Agent","DevelopUgandaWorldSituationRoom/1157 (source-attributed)");
    try{int code=c.getResponseCode();if(code!=200)throw new java.io.IOException("HTTP "+code);
      try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){if(out.size()+n>max)throw new java.io.IOException("Provider response larger than bound");out.write(buf,0,n);}return out.toByteArray();}
    }finally{c.disconnect();}}
  private String get(String path,int max) throws Exception {return new String(getBytes(path,max),"UTF-8");}
  private void load(){shownLimit=45;int token=request.incrementAndGet();String requested=mode;status.setText("CONNECTING TO PUBLIC SOURCE  /  "+utc());mediaBand.setReceipt("CHECKING SOURCE CONNECTION",0,false);sourceSummary.setText("Only received data will appear. Sources may be blocked or require licences.");
    items.clear();render();io.execute(()->{
      ArrayList<Item> fresh=new ArrayList<>();String state;
      try{
        if(requested.equals("PUBLIC CAMERAS"))state=duwmP4LoadCameras(fresh);
        else if(requested.equals("RADIO"))state=loadRadio(fresh);
        else if(requested.equals("TV STATIONS"))state=loadTelevision(fresh);
        else if(requested.equals("WORLD NEWS"))state=loadNews(fresh);
        else state=loadEarth(fresh);
      }catch(Exception e){state="UNAVAILABLE  /  "+shortText(e.getMessage(),130);}
      boolean cached=false;
      if(fresh.size()<2){ArrayList<Item> old=restoreDirectory(requested);
        if(old.size()>fresh.size()){fresh.clear();fresh.addAll(old);cached=true;}}
      else saveDirectory(requested,fresh);
      final boolean cacheUsed=cached;final String result=cacheUsed?"CACHED SOURCE DIRECTORY / REFRESH UNSUCCESSFUL / "+state:state;
      ui.post(()->{if(!active||request.get()!=token)return;items.clear();items.addAll(fresh);status.setText(result);
        sourceSummary.setText((cacheUsed?"CACHED - PREVIOUSLY RECEIVED / ":"RECEIVED / ")+items.size()+" SOURCE ENTRIES / "+utc());
        mediaBand.setReceipt(items.isEmpty()?"NO RECEIVED SOURCES / RETRY":cacheUsed?"CACHED LIST / NOT VERIFIED LIVE":"SOURCE DIRECTORY RECEIVED",items.size(),!items.isEmpty()&&!cacheUsed);
        render();});
    });}
  // Store real source directory receipts so failed networks do not make every media list empty.
  // Cached streams are explicitly stale until a native player successfully opens them.
  private void saveDirectory(String kind,ArrayList<Item> data){if(data==null||data.size()<2)return;
    JSONArray arr=new JSONArray();for(int i=0;i<data.size()&&i<100;i++){
      Item v=data.get(i);JSONObject o=new JSONObject();try{o.put("title",v.title);o.put("meta",v.meta);
        o.put("url",v.url);o.put("image",v.image);o.put("source",v.source);o.put("detail",v.detail);
        arr.put(o);}catch(Exception ignored){}
    }
    getSharedPreferences("duwm1678_media_directory",MODE_PRIVATE).edit()
      .putString("entries_"+kind,arr.toString()).putLong("saved_"+kind,System.currentTimeMillis()).apply();
  }
  private ArrayList<Item> restoreDirectory(String kind){ArrayList<Item> out=new ArrayList<>();
    String raw=getSharedPreferences("duwm1678_media_directory",MODE_PRIVATE)
      .getString("entries_"+kind,"");if(raw.isEmpty())return out;
    try{JSONArray arr=new JSONArray(raw);for(int i=0;i<arr.length()&&i<100;i++){
      JSONObject o=arr.optJSONObject(i);if(o==null)continue;
      out.add(new Item(o.optString("title",""),o.optString("meta",""),
        o.isNull("url")?null:o.optString("url",null),
        o.isNull("image")?null:o.optString("image",null),o.optString("source",""),
        o.optString("detail","")));
    }}catch(Exception ignored){}return out;
  }
  private String loadRadio(ArrayList<Item> out)throws Exception {
    String api="https://de1.api.radio-browser.info/json/stations/search?limit=500&hidebroken=true&order=clickcount&reverse=true";
    out.add(new Item("KEXP / Seattle Public Radio",
      "Official KEXP HTTPS AAC 160 kbps • broadcaster source; network playback unverified",
      "https://kexp.streamguys1.com/kexp160.aac",null,"KEXP official",
      "Native audio player. Availability confirmed only after Android player prepares this stream."));
    JSONArray a;
    try{a=new JSONArray(get(api,2400000));}catch(Exception network){
      return "KEXP AVAILABLE TO TRY / Radio Browser directory unavailable: "+shortText(network.getMessage(),75);
    }
    for(int i=0;i<a.length();i++){JSONObject s=a.optJSONObject(i);if(s==null)continue;String url=s.optString("url_resolved",s.optString("url",""));if(!url.startsWith("https://"))continue;
      String name=shortText(s.optString("name","Unnamed station"),100);if(name.isEmpty())continue;
      String country=shortText(s.optString("country","unknown country"),70);String codec=s.optString("codec","format unknown");String verified=shortText(s.optString("lastchecktime_iso8601","not reported"),40);
      String image=s.optString("favicon","");if(!image.startsWith("https://"))image=null;
      out.add(new Item(name,country+"  /  "+codec+"  /  "+s.optString("bitrate","?")+" kbps  /  checked "+verified,url,image,"Radio Browser","Public broadcaster-supplied stream listing; availability not guaranteed"));
    }
    return "RADIO BROWSER  /  "+out.size()+" HTTPS streams received  /  Tap PLAY to listen here";
  }
  private String loadTelevision(ArrayList<Item> out)throws Exception {
    out.add(new Item("DW English / International News",
      "HLS • Broadcaster stream listing • availability and rights may vary by region",
      "https://dwamdstream102.akamaized.net/hls/live/2015525/dwstream102/master.m3u8",
      null,"Deutsche Welle","In-app native HLS player. No claim of active playback until prepared."));
    JSONArray streams;
    try{streams=new JSONArray(get("https://iptv-org.github.io/api/streams.json",15000000));}
    catch(Exception network){return "DW CHANNEL AVAILABLE TO TRY / IPTV source catalogue unavailable: "+shortText(network.getMessage(),75);}
    
    ArrayList<JSONObject> candidates=new ArrayList<>();
    for(int i=0;i<streams.length()&&candidates.size()<140;i++){JSONObject item=streams.optJSONObject(i);if(item==null)continue;String url=item.optString("url","");
      String low=url.toLowerCase(Locale.ROOT);if(!url.startsWith("https://")||low.contains(".mpd")||!low.contains(".m3u8")||(!item.isNull("referrer")&&item.optString("referrer","").length()>0))continue;
      String title=item.optString("title",item.optString("channel",""));if(title.toLowerCase(Locale.ROOT).contains("adult"))continue;
      candidates.add(item);
    }
    Map<String,JSONObject> channels=new HashMap<>();Map<String,String> logos=new HashMap<>();boolean gotLogos=false;
    try{JSONArray list=new JSONArray(get("https://iptv-org.github.io/api/channels.json",19000000));for(int i=0;i<list.length();i++){JSONObject c=list.optJSONObject(i);if(c!=null&&!c.optBoolean("is_nsfw",false)&&c.isNull("closed"))channels.put(c.optString("id",""),c);}}catch(Exception e){/* Stream metadata still usable. */}
    try{JSONArray list=new JSONArray(get("https://iptv-org.github.io/api/logos.json",16000000));for(int i=0;i<list.length();i++){JSONObject x=list.optJSONObject(i);if(x==null||!x.optBoolean("in_use",false))continue;String channel=x.optString("channel","");String u=x.optString("url","");String format=x.optString("format","");if(u.startsWith("https://")&&(format.equalsIgnoreCase("PNG")||format.equalsIgnoreCase("JPEG")||format.equalsIgnoreCase("WebP"))&&!logos.containsKey(channel))logos.put(channel,u);}gotLogos=!logos.isEmpty();}catch(Exception e){/* No fabricated logos if API unavailable. */}
    for(JSONObject s:candidates){String channel=s.optString("channel","");JSONObject info=channels.get(channel);String title=s.optString("title","");if(title.isEmpty()&&info!=null)title=info.optString("name",channel);if(title.isEmpty())title=channel;
      if(channels.size()>0&&info==null)continue;String url=s.optString("url","");String logo=logos.get(channel);
      String meta=info==null?"HLS live stream / catalogue":shortText(info.optString("country","unknown country"),35)+"  /  HLS stream";
      out.add(new Item(shortText(title,110),meta,url,logo,"IPTV-org","HLS playback depends on Android device, broadcaster and country rights"));
    }
    return "IPTV-ORG / "+out.size()+" listed HTTPS HLS streams; source logos "+(gotLogos?"loaded":"unavailable")+" / Playback is best effort";
  }
  private static String imageAttr(XmlPullParser p){for(int i=0;i<p.getAttributeCount();i++)if("url".equalsIgnoreCase(p.getAttributeName(i))){String v=p.getAttributeValue(i);if(v!=null&&v.startsWith("https://"))return v;}return null;}
  private void parseFeed(String provider,String path,ArrayList<Item> out,int max)throws Exception{
    XmlPullParserFactory factory=XmlPullParserFactory.newInstance();factory.setNamespaceAware(true);XmlPullParser parser=factory.newPullParser();parser.setInput(new StringReader(get(path,2400000)));
    boolean in=false;String tag="",title="",url="",date="",desc="",image=null;int count=0;
    for(int ev=parser.getEventType();ev!=XmlPullParser.END_DOCUMENT&&count<max;ev=parser.next()){
      if(ev==XmlPullParser.START_TAG){String n=parser.getName();tag=n==null?"":n;
        if("item".equalsIgnoreCase(tag)){in=true;title="";url="";date="";desc="";image=null;}
        else if(in&&(tag.equalsIgnoreCase("thumbnail")||tag.equalsIgnoreCase("content")||tag.equalsIgnoreCase("enclosure"))){String candidate=imageAttr(parser);if(candidate!=null&&image==null){if(!tag.equalsIgnoreCase("enclosure")||String.valueOf(parser.getAttributeValue(null,"type")).startsWith("image/"))image=candidate;}}
      }else if(ev==XmlPullParser.TEXT&&in){String t=parser.getText();if("title".equalsIgnoreCase(tag))title+=t;else if("link".equalsIgnoreCase(tag))url+=t;else if("pubDate".equalsIgnoreCase(tag))date+=t;else if("description".equalsIgnoreCase(tag))desc+=t;
      }else if(ev==XmlPullParser.END_TAG){String n=parser.getName();if("item".equalsIgnoreCase(n)&&in){
          if(image==null){Matcher m=Pattern.compile("<img[^>]+src=[\\\"'](https://[^\\\"']+)[\\\"']",Pattern.CASE_INSENSITIVE).matcher(desc);if(m.find())image=m.group(1);}
          String clean=shortText(desc.replaceAll("<[^>]+>"," ").replaceAll("&nbsp;"," ").replaceAll("&amp;","&"),200);
          if(!title.trim().isEmpty()){out.add(new Item(shortText(title,180),provider+"  /  "+shortText(date,90),url.trim().startsWith("https://")?url.trim():null,image,provider,clean));count++;}
          in=false;
        }tag="";}
    }
    if(count==0)throw new java.io.IOException(provider+" returned no RSS stories");
  }
  private String loadNews(ArrayList<Item> out)throws Exception{
    String[][] feeds={{"BBC WORLD","https://feeds.bbci.co.uk/news/world/rss.xml"},{"AL JAZEERA","https://www.aljazeera.com/xml/rss/all.xml"},{"FRANCE 24","https://www.france24.com/en/rss"},{"DW WORLD","https://rss.dw.com/xml/rss-en-world"},{"THE INDEPENDENT UGANDA","https://www.independent.co.ug/feed/"}};
    int success=0;StringBuilder errors=new StringBuilder();for(String[] f:feeds){try{parseFeed(f[0],f[1],out,8);success++;}catch(Exception e){errors.append(f[0]).append(" unavailable; ");}}
    return "NEWS / "+out.size()+" stories from "+success+" of "+feeds.length+" publishers / "+errors;
  }
  private String loadEarth(ArrayList<Item> out)throws Exception{
    JSONArray a=new JSONArray(get("https://epic.gsfc.nasa.gov/api/natural",300000));
    for(int i=0;i<a.length()&&i<18;i++){JSONObject p=a.optJSONObject(i);if(p==null)continue;String filename=p.optString("image","");String date=p.optString("date","");
      if(!filename.matches("[A-Za-z0-9_\\-]+")||date.length()<10)continue;String day=date.substring(0,10);if(!day.matches("\\d{4}-\\d{2}-\\d{2}"))continue;
      String image="https://epic.gsfc.nasa.gov/archive/natural/"+day.replace('-','/')+"/thumbs/"+filename+".jpg";
      out.add(new Item("NASA DSCOVR EPIC / "+day,"NASA source photo  /  "+date,null,image,"NASA EPIC",shortText(p.optString("caption","Earth observation"),200)));
    }
    return "NASA EPIC  /  "+out.size()+" source-photograph records  /  Archive image URLs supplied by NASA metadata";
  }
  private boolean duwmP4MediaUrl(String v){
    try{java.net.URI uri=new java.net.URI(v);String h=uri.getHost();
      return "https".equalsIgnoreCase(uri.getScheme()) && h!=null && h.contains(".") &&
             !h.equalsIgnoreCase("localhost") && !h.endsWith(".local") && uri.getUserInfo()==null;
    }catch(Exception ignored){return false;}
  }
  private String duwmP4LoadCameras(ArrayList<Item> out){
    // Static image URLs are not continuous video, and must be described as snapshots.
    out.add(new Item("Yellowstone Old Faithful / NPS",
        "PUBLIC CAMERA • periodically updated still image • capture time may not be supplied",
        "https://www.nps.gov/webcams-yell/oldfaithful.jpg",
        "https://www.nps.gov/webcams-yell/oldfaithful.jpg",
        "US National Park Service","Official NPS image source; tap to request newest available JPEG."));
    String extra=getPreferences(0).getString("duwm_p4_camera_url","");
    if(duwmP4MediaUrl(extra))out.add(new Item("USER-ADDED CAMERA",
        "Provided HTTPS source • not endorsed or independently verified",
        extra,extra.toLowerCase(Locale.ROOT).contains(".m3u8")?null:extra,
        "User-configured stream","Playback checked by Android at request time; no fabricated camera frames."));
    return "PUBLIC CAMERAS / "+out.size()+" source entries • images are snapshots, not continuous video";
  }
  private void duwmP4PlayCamera(Item it){
    String u=it.image!=null?it.image:it.url;
    if(!duwmP4MediaUrl(u)){playing.setText("CAMERA UNAVAILABLE / No authorized HTTPS source");return;}
    stopPlayback();currentCamera=it;playingUrl=u;
    if(u.toLowerCase(Locale.ROOT).contains(".m3u8")){
      video.setVisibility(View.VISIBLE);playing.setText("CAMERA HLS / CONNECTING / "+it.title);
      video.setOnPreparedListener(mp->{if(!active||!u.equals(playingUrl))return;
        video.start();playing.setText("CAMERA HLS / PLAYING / "+it.title);});
      video.setOnErrorListener((mp,what,extra)->{
        playing.setText("CAMERA HLS UNAVAILABLE / error "+what);return true;});
      video.setVideoURI(Uri.parse(u));video.requestFocus();return;
    }
    duwmP4CameraFrame(it);ui.postDelayed(cameraRefresh,60000L);
  }
  private void duwmP4CameraFrame(Item it){
    final String url=it.image!=null?it.image:it.url;
    if(!duwmP4MediaUrl(url))return;
    final long seq=++cameraSequence;
    playing.setText("CAMERA IMAGE / REQUESTING SOURCE FRAME / "+it.title);
    io.execute(()->{
      HttpURLConnection c=null;
      try{
        c=(HttpURLConnection)new URL(url).openConnection();
        c.setUseCaches(false);c.setInstanceFollowRedirects(true);
        c.setConnectTimeout(9000);c.setReadTimeout(13000);
        c.setRequestProperty("Cache-Control","no-cache");
        int statusCode=c.getResponseCode();
        if(statusCode!=200)throw new java.io.IOException("HTTP "+statusCode);
        if(!"https".equalsIgnoreCase(c.getURL().getProtocol()))throw new java.io.IOException("Non-HTTPS camera redirect");
        final long lastModified=c.getLastModified();
        try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
          byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){
            if(out.size()+n>3500000)throw new java.io.IOException("Camera image exceeds 3.5MB");
            out.write(b,0,n);
          }
          byte[] bytes=out.toByteArray();
          BitmapFactory.Options opt=new BitmapFactory.Options();opt.inJustDecodeBounds=true;
          BitmapFactory.decodeByteArray(bytes,0,bytes.length,opt);
          if(opt.outWidth<1||opt.outHeight<1)throw new java.io.IOException("No decodable camera image");
          opt.inJustDecodeBounds=false;opt.inSampleSize=Math.max(1,Math.max(opt.outWidth/900,opt.outHeight/650));
          Bitmap frame=BitmapFactory.decodeByteArray(bytes,0,bytes.length,opt);
          if(frame==null)throw new java.io.IOException("Unable to decode provider frame");
          String received=utc();
          ui.post(()->{if(active && seq==cameraSequence && mode.equals("PUBLIC CAMERAS") && url.equals(playingUrl)){
            cameraView.setImageBitmap(frame);cameraView.setVisibility(View.VISIBLE);
            SimpleDateFormat fmt=new SimpleDateFormat("dd MMM HH:mm 'UTC'",Locale.US);
            fmt.setTimeZone(TimeZone.getTimeZone("UTC"));
            String captured=lastModified>0?fmt.format(new Date(lastModified)):
                "source capture time unknown";
            playing.setText("CAMERA IMAGE RECEIVED / "+received+" / "+captured);
          }});
        }
      }catch(Exception ex){String msg=shortText(ex.getMessage(),90);
        ui.post(()->{if(active&&seq==cameraSequence)playing.setText("CAMERA UNAVAILABLE / "+msg);});
      }finally{if(c!=null)c.disconnect();}
    });
  }
  private boolean savedMedia(Item item){return item!=null&&item.url!=null&&item.url.startsWith("https://")&&
    getSharedPreferences("duwm1693_saved_media",MODE_PRIVATE).getBoolean(item.url,false);}
  private void toggleMediaSaved(Item item){if(item==null||item.url==null||!item.url.startsWith("https://"))return;
    getSharedPreferences("duwm1693_saved_media",MODE_PRIVATE).edit().putBoolean(item.url,!savedMedia(item)).apply();render();}
  private void render(){if(records==null)return;records.removeAllViews();String filter=query==null?"":query.getText().toString().trim().toLowerCase(Locale.ROOT);
    ArrayList<Item> visible=new ArrayList<>();int validHttps=0,withImages=0;
    for(Item it:items){
      String link=it.url!=null?it.url:it.image;
      if(link!=null&&link.startsWith("https://"))validHttps++;
      if(it.image!=null&&it.image.startsWith("https://"))withImages++;
      if(secureSourcesOnly&&(link==null||!link.startsWith("https://")))continue;
      if(savedMediaOnly&&!savedMedia(it))continue;
      if(!filter.isEmpty()&&!(it.title+" "+it.meta+" "+it.detail).toLowerCase(Locale.ROOT).contains(filter))continue;
      visible.add(it);
    }
    mediaEvidence.setValues("MEDIA / RECEIVED SOURCE DIRECTORY",
      new String[]{"RECEIVED LISTINGS","MATCH SEARCH / FILTER","HTTPS LINKS LISTED","SOURCE IMAGE URLs"},
      new long[]{items.size(),visible.size(),validHttps,withImages});
    TextView showReport=text(showMediaSourceChart?"HIDE REAL SOURCE COUNTS  ▴":"SHOW REAL SOURCE COUNTS  ▸",12,CYAN,true);
    showReport.setPadding(dp(12),dp(13),dp(12),dp(13));showReport.setBackground(panel());
    records.addView(showReport,new LinearLayout.LayoutParams(-1,dp(44)));
    showReport.setOnClickListener(v->{showMediaSourceChart=!showMediaSourceChart;render();});
    if(showMediaSourceChart)records.addView(mediaEvidence,new LinearLayout.LayoutParams(-1,dp(225)));
    if(mediaSort==1)visible.sort((a,b)->String.valueOf(a.title).compareToIgnoreCase(String.valueOf(b.title)));
    else if(mediaSort==2)visible.sort((a,b)->{
      boolean ia=a.image!=null&&a.image.startsWith("https://"),ib=b.image!=null&&b.image.startsWith("https://");
      return Boolean.compare(ib,ia);
    });
    int drawn=0;for(Item it:visible){if(drawn>=shownLimit)break;drawn++;
      LinearLayout card=new LinearLayout(this);card.setPadding(dp(10),dp(10),dp(10),dp(10));card.setOrientation(LinearLayout.VERTICAL);card.setBackground(Duwm1678VisualKit.panel(this,mode,false));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(9);records.addView(card,lp);
      LinearLayout content=new LinearLayout(this);content.setGravity(Gravity.CENTER_VERTICAL);card.addView(content);
      ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setVisibility(View.GONE);LinearLayout.LayoutParams art=new LinearLayout.LayoutParams(dp(112),dp(83));art.rightMargin=dp(10);content.addView(img,art);
      if(it.image!=null){sourceImage(img,it.image);}
      LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);content.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
      copy.addView(Duwm1678VisualKit.chip(this,mode.equals("PUBLIC CAMERAS")?"PUBLIC SNAPSHOT / LISTED":mode.equals("TV STATIONS")?"TV STREAM / TEST ON PLAY":mode.equals("RADIO")?"RADIO STREAM / TEST ON PLAY":"PUBLISHER / SOURCE RECORD",mode));label(copy,it.title,16,WHITE,true);label(copy,it.meta,12,MUTED,false);label(copy,"SOURCE / "+it.source+(it.image!=null?"  •  Source image supplied":"  •  No source image"),10,CYAN,false);
      if(it.detail!=null&&!it.detail.isEmpty()){TextView detail=text(it.detail,12,MUTED,false);detail.setPadding(0,dp(7),0,dp(4));detail.setMaxLines(4);card.addView(detail);}
      TextView action=text(mode.equals("RADIO")?"▶ PLAY RADIO INSIDE APP":mode.equals("TV STATIONS")?"▶ PLAY TV INSIDE APP":mode.equals("PUBLIC CAMERAS")?"▶ VIEW SOURCE CAMERA":"VIEW SOURCE DETAILS",12,CYAN,true);
      action.setPadding(0,dp(10),0,dp(3));card.addView(action);
      action.setOnClickListener(v->{if(mode.equals("RADIO")||mode.equals("TV STATIONS")||mode.equals("PUBLIC CAMERAS"))play(it);else details(it);});
      content.setContentDescription("Open received source: "+it.title);
      content.setOnClickListener(v->{if(mode.equals("RADIO")||mode.equals("TV STATIONS")||mode.equals("PUBLIC CAMERAS"))play(it);else details(it);});
      TextView share=text("▣  SHARE 9:16 SOURCE CARD",12,Duwm1678VisualKit.accent(mode),true);
      share.setContentDescription("Share source card for "+it.title);
      share.setPadding(0,dp(12),0,dp(8));card.addView(share);
      share.setOnClickListener(v->shareSourceCard(it,img));
      TextView save=text(savedMedia(it)?"★ SAVED SOURCE  /  TAP TO REMOVE":"☆ SAVE VERIFIED SOURCE LISTING",12,CYAN,true);
      save.setPadding(0,dp(11),0,dp(9));card.addView(save);
      save.setOnClickListener(v->toggleMediaSaved(it));
    }
    if(visibleSourceCount!=null)visibleSourceCount.setText("RECEIVED "+items.size()+"  /  MATCHING "+visible.size()+"  /  SHOWN "+drawn+"  /  MODE "+mode+
      "  /  STREAM AVAILABILITY VERIFIED ONLY AFTER PLAYBACK");
    if(visible.size()>drawn){final int remaining=visible.size()-drawn;
      TextView more=text("LOAD NEXT "+Math.min(45,remaining)+" SOURCE ENTRIES  /  "+remaining+" REMAIN",13,CYAN,true);
      more.setGravity(Gravity.CENTER);more.setPadding(dp(8),dp(16),dp(8),dp(16));more.setBackground(panel());
      records.addView(more);more.setOnClickListener(v->{shownLimit+=45;render();});}
    if(drawn==0){TextView empty=text("NO SOURCE RECORDS FOR THIS FILTER\n\nRefresh the source or select another media category. Stream availability depends on the provider. No sample media is displayed.",13,AMBER,false);empty.setPadding(dp(16),dp(22),dp(16),dp(22));empty.setBackground(Duwm1678VisualKit.panel(this,mode,false));records.addView(empty);TextView retry=text("↻  RETRY SOURCE CONNECTION",12,Duwm1678VisualKit.accent(mode),true);retry.setGravity(Gravity.CENTER);retry.setPadding(dp(10),dp(18),dp(10),dp(18));records.addView(retry);retry.setOnClickListener(v->load());}
  }

  // V1159.4: Share only the received source record. No invented captions, positions or images.
  private void shareSourceCard(Item it,ImageView preview){
    Bitmap visible=null;
    Drawable drawable=preview.getDrawable();
    if(drawable instanceof BitmapDrawable)visible=((BitmapDrawable)drawable).getBitmap();
    final Bitmap sourceOnScreen=visible;
    Toast.makeText(this,"Preparing source-attributed share card",Toast.LENGTH_SHORT).show();
    io.execute(()->{
      try{
        Bitmap actual=sourceOnScreen;
        if(actual==null && it.image!=null && goodImageUri(it.image)){
          try{
            byte[] bytes=getBytes(it.image,1300000);
            BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;
            BitmapFactory.decodeByteArray(bytes,0,bytes.length,o);
            if(o.outWidth>0 && o.outHeight>0 && ((long)o.outWidth*o.outHeight)<22000000L){
              o.inJustDecodeBounds=false;o.inSampleSize=Math.max(1,Math.max(o.outWidth/1500,o.outHeight/1500));
              actual=BitmapFactory.decodeByteArray(bytes,0,bytes.length,o);
            }
          }catch(Exception ignored){/* The unavailable image is never replaced by a guessed picture. */}
        }
        Bitmap card=V115941ShareCards.render(this,
          mode.equals("WORLD NEWS")?"NEWS":mode.equals("EARTH IMAGES")?"SATELLITE / EARTH PHOTO":
          mode.equals("RADIO")?"RADIO":"TELEVISION",
          it.title,it.meta+" | "+it.detail,it.source,0L,null,null,
          it.url!=null?it.url:it.image,actual);
        File dir=new File(getCacheDir(),"sharecards");if(!dir.isDirectory()&&!dir.mkdirs())throw new java.io.IOException("Cache not writable");
        String filename="card-"+UUID.randomUUID().toString().replace("-","").substring(0,24)+".png";
        File out=new File(dir,filename);
        try(FileOutputStream stream=new FileOutputStream(out)){
          if(!card.compress(Bitmap.CompressFormat.PNG,100,stream))throw new java.io.IOException("Unable to encode PNG");
        }
        card.recycle();
        Uri uri=new Uri.Builder().scheme("content").authority(getPackageName()+".v11593sourcecards").appendPath("cards").appendPath(filename).build();
        String line=it.title+"\n"+it.meta+"\n"+it.detail+"\nSource: "+it.source+(it.url==null?"":"\nOriginal: "+it.url);
        ui.post(()->{if(!active)return;
          Intent share=new Intent(Intent.ACTION_SEND);
          share.setType("image/png");share.putExtra(Intent.EXTRA_STREAM,uri);share.putExtra(Intent.EXTRA_TEXT,line);
          share.setClipData(ClipData.newUri(getContentResolver(),"Source-attributed card",uri));
          share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
          try{startActivity(Intent.createChooser(share,"Share source-attributed record"));}
          catch(Exception e){Toast.makeText(this,"No compatible sharing app available",Toast.LENGTH_LONG).show();}
        });
      }catch(Exception e){ui.post(()->{if(active)Toast.makeText(this,"Card could not be prepared: "+shortText(e.getMessage(),70),Toast.LENGTH_LONG).show();});}
    });
  }
  private static float paragraph(Canvas c,Paint p,String text,float x,float y,float maxWidth,float lineHeight,int maxLines){
    String cleaned=text==null?"Not provided":text.replaceAll("[\\p{Cntrl}]+"," ").trim();
    if(cleaned.isEmpty())cleaned="Not provided";
    String[] words=cleaned.split(" +");String line="";int count=0;
    for(String word:words){String test=line.isEmpty()?word:line+" "+word;
      if(p.measureText(test)<=maxWidth){line=test;continue;}
      if(!line.isEmpty()){c.drawText(line,x,y,p);y+=lineHeight;count++;line="";if(count>=maxLines)return y;}
      while(p.measureText(word)>maxWidth && word.length()>1){int cut=word.length()-1;
        while(cut>1&&p.measureText(word.substring(0,cut))>maxWidth)cut--;
        c.drawText(word.substring(0,cut),x,y,p);y+=lineHeight;count++;
        if(count>=maxLines)return y;word=word.substring(cut);
      }line=word;
    }
    if(!line.isEmpty()&&count<maxLines){c.drawText(line,x,y,p);y+=lineHeight;}
    return y;
  }
  private Bitmap composeSourceCard(Item it,Bitmap received){
    int w=960,h=1280;Bitmap b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
    Canvas c=new Canvas(b);c.drawColor(Color.rgb(8,24,36));
    Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    p.setColor(Color.rgb(57,181,195));c.drawRect(0,0,w,12,p);
    p.setColor(Color.rgb(222,237,241));p.setTextSize(39);p.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));
    c.drawText("DEVELOP.UGANDA",42,79,p);
    p.setTextSize(22);p.setColor(Color.rgb(57,181,195));c.drawText("WORLD SITUATION ROOM  /  SOURCE-ATTRIBUTED",42,121,p);
    final float photoTop=158,photoBottom=550;
    if(received!=null&&!received.isRecycled()&&received.getWidth()>0&&received.getHeight()>0){
      Rect src;
      float srcRatio=(float)received.getWidth()/received.getHeight(), boxRatio=876f/(photoBottom-photoTop);
      if(srcRatio>boxRatio){int sw=Math.max(1,(int)(received.getHeight()*boxRatio));int left=(received.getWidth()-sw)/2;src=new Rect(left,0,left+sw,received.getHeight());}
      else {int sh=Math.max(1,(int)(received.getWidth()/boxRatio));int top=(received.getHeight()-sh)/2;src=new Rect(0,top,received.getWidth(),top+sh);}
      c.drawBitmap(received,src,new Rect(42,(int)photoTop,918,(int)photoBottom),p);
      p.setColor(Color.rgb(57,181,195));p.setTextSize(20);c.drawText("SOURCE IMAGE RECEIVED",46,588,p);
    }else{
      p.setColor(Color.rgb(14,60,74));c.drawRect(42,photoTop,918,photoBottom,p);
      p.setColor(Color.rgb(57,181,195));p.setTextSize(31);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
      c.drawText("SOURCE IMAGE NOT AVAILABLE",85,345,p);
      p.setTextSize(20);c.drawText("No replacement photograph was created.",85,388,p);
    }
    float y=640;p.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));p.setTextSize(42);p.setColor(Color.WHITE);
    y=paragraph(c,p,it.title,42,y,876,50,3)+7;
    p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(25);p.setColor(Color.rgb(188,201,204));
    y=paragraph(c,p,it.meta,42,y,876,34,3)+12;
    p.setTextSize(26);p.setColor(Color.rgb(213,228,231));
    y=paragraph(c,p,it.detail,42,y,876,37,5)+22;
    y=Math.min(y,1125);
    p.setColor(Color.rgb(24,87,105));c.drawRect(42,1152,918,1155,p);
    p.setTextSize(23);p.setColor(Color.rgb(57,181,195));
    paragraph(c,p,"SOURCE: "+it.source,42,1191,876,26,1);
    p.setTextSize(18);p.setColor(Color.rgb(103,142,150));
    paragraph(c,p,it.url==null?"Original link not supplied by provider":"ORIGINAL: "+it.url,42,1229,876,24,2);
    return b;
  }

  private void details(Item it){new android.app.AlertDialog.Builder(this).setTitle(it.title).setMessage(it.meta+"\n\n"+it.detail+"\n\nSOURCE: "+it.source+"\n\nImage only if supplied by the original source.")
    .setPositiveButton("CLOSE",(d,w)->{}).setNeutralButton(it.url!=null?"READ ORIGINAL":"NO SOURCE LINK",(d,w)->{if(it.url!=null&&it.url.startsWith("https://"))startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(it.url)));}).show();}
}
