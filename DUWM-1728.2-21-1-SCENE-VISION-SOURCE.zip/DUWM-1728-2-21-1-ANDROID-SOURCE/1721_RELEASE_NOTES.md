# DUWM 1721 — Global earthquake receipts + MONITORS CAM capture evidence

Upgrades the actual 1720 Android project. Retains its original MainActivity, one SatelliteMapView globe, 19 source desks, global discovery, My World, and the exact approved #041424 background / #DEE5EF outlines / #F5F7FA text.

**Worldwide:** New native Global Earthquakes full-screen page accessible from the original globe's existing mission dock, My World and Global Discovery. It downloads the official USGS M4.5+ past-seven-days GeoJSON feed over HTTPS, with magnitude filters, text search, occurrence/updated times in UTC, original source status/URL, source-data age, and map focus for genuine coordinates. The last valid feed is cached, marked cached/offline when necessary. This is not a safety-warning system or a quake forecast.

**MONITORS CAM:** Six reporter-selected situation categories, labelled self-reported and rendered in recorded MP4 frames when device recording surfaces support it. For a valid completed video the app computes the SHA-256 fingerprint, duration, frame count, size, UTC receipt date and whether precise GPS was opted in. This remains a *private on-device receipt*, not external proof of authenticity. Last receipt is viewable/shareable as text. GPS stays disabled by default. The original review/report composer remains the destination after recording.

**Important verification:** Java parser and source invariants are checked locally. Android :app:assembleDebug and device MediaRecorder surface encoder success must be confirmed by GitHub and real phone testing. The app does not claim footage is verified. No additional globe, new application shell or demo telemetry is introduced.
