# DUWM 1728.2/18 — automatic production and caption files

## Requested behavior

A new clean camera recording now proceeds to a completed MP4 automatically. The
normal flow does not ask for an AI server address, API key, account, headline edit,
caption edit, or a reporter-approval checkbox. Manual tools remain optional.
`AUTO PRODUCE` also starts the same local flow for an already opened recording.
`AI HELP` explains the current device capability and has an on/off setting for
automatic production after new recordings. It contains no connection form.

The editing policy keeps the full source duration and original aspect ratio,
uses FIT framing and the compact broadcast composition, retains the soundtrack,
and adds source-timed speech captions when the phone supplies supported on-device
recorded-audio recognition and usable word starts. It does not invent a news
headline or pretend to perform visual event verification. The output is marked
as automatic and unverified/unreviewed, never as reviewed by the reporter.

Speech recognition is a real Android on-device service, not a model bundled in
this APK. Compatibility depends on the installed engine and language support.
If recognition is unsupported, times are missing, or any chunk fails, the
automatic path still renders the full video with its original audio and clearly
reports that automatic captions were omitted. No cloud upload or fabricated
transcript replaces an unavailable model. The app does not have a general-purpose
offline chatbot or semantic video understanding model in this build.

## Automatic lifecycle

Recognition uses at most 45 seconds per source-audio request and chains requests
over the recording. It requires support for the exact request, the expected
segmented file session, and a completed injected stream. Ordinary microphone-style
results are not accepted as source captions. The PCM path uses a fixed 16 kHz
source timeline, preserves timing gaps, and exposes cancellation to the active
writer. RecognitionPart gives word starts; caption ends are derived and bounded,
not advertised as measured word ends.

The actual encoder preflight, native renderer, retained-copy recovery and Gallery
publisher complete the job. A saved result is reported only after Gallery returns
and the existing recovery core records the outcome. An automatic-attempt receipt
prevents reopening the same capture from silently producing another copy. An
interrupted or failed attempt can be retried with AUTO PRODUCE; existing retained
exports remain accessible through Recovery. Sharing is a separate user action.

## Caption-file controls

CAPTION FILES supports SAVE SRT, SHARE SRT and IMPORT SRT. Original-video timing
includes all committed cues; selected-clip timing intersects the trim and rebases
to zero. Clip-based import adds the current trim start. The shared UTF-8 codec
preserves exact milliseconds, overlaps and stable equal-start ordering, literal
angle-bracket text, Unicode and embedded U+FEFF. Limits are 20,000 cues, 500 UTF-16
units per cue, and 32 MiB; invalid input fails without partial replacement.

Exports use frozen snapshots. Save success requires write, flush and close, and
the private provider grants read-only access to generated SRT files. Import reads
and validates a candidate before explicit replacement. Cancelling or failing a
file operation preserves the current caption draft. Malformed stored cue arrays
block automatic overwriting until the user accepts a valid replacement.

## Inherited fixes and evidence

The exact delivered /17 source ZIP is the baseline:
`e8b7d30bbe126744c071278dd321f50eb520f2000348ef46c17175a9b60a5c32`.
Its GitHub run 42388645605 completed successfully: all eleven native stages passed.
The three /17 playback/control repairs remain present. Prior /17 evidence is
retained as prior-version evidence and does not count as /18 native execution.

This source defines thirteen required native stages: the previous eleven plus
`caption_files` and `automatic_production`. The automatic stage must launch the
actual clean-master flow, obtain a saved MP4, decode its frames/audio, exercise
the finished-video review, and check duplicate suppression. Caption-file tests
use real ContentResolver bytes with an explicit ActivityMonitor picker-result
seam; they do not claim that a third-party document UI or recipient app was used.

The accompanying VERIFICATION ZIP records what was actually executed. Compilation
and host tests are distinct from Android installation, on-device inference,
physical-camera capture and a new /18 GitHub emulator run.

## Researched primary references

- Android SpeechRecognizer and exact-request support:
  https://developer.android.com/reference/android/speech/SpeechRecognizer
- Recorded-audio and segmented-session contracts, including the documented
  fallback risk when a service ignores EXTRA_AUDIO_SOURCE:
  https://developer.android.com/reference/android/speech/RecognizerIntent
- RecognitionPart reports word start offsets:
  https://developer.android.com/reference/android/speech/RecognitionPart
- ML Kit's newer speech API supports explicit file input but introduces a new
  dependency and device restrictions; timed output requires streaming input:
  https://developers.google.com/ml-kit/genai/speech-recognition/android
- A separately bundled speech model remains an alternative requiring model
  packaging and device validation:
  https://github.com/ggml-org/whisper.cpp/tree/master/examples/whisper.android

No unconfigured external service is represented as functioning built-in AI.
