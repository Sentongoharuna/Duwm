# DUWM 1725 — high-contrast source health across the full app

- Retains the 1724 complete Android codebase and original single rotating globe.
- Retains exactly sampled #041424 reference navy, #DEE5EF silver outlines, and white text.
- Saturated data-provider health stages: red #D50000 worst; orange #F57C00; yellow #FBC02D; blue #1565C0; cyan #00ACC1; green #00C853 best.
- Grey = no receipt and silver = local-only functionality; neither is scored as success or outage.
- Corrects legacy 8-source desk, standalone source LEDs, old compact source screens, and worldwide channels that previously incorrectly collapsed health colours to blue.
- Source rail is 19-slot, per-provider receipt driven, and shows review status before healthy count. Only real new receipts pulse briefly. No invented feed values.
- Shared native chrome remains navy/silver, ticker source indicator is static and reflects whether real records are present.
- Global places, 19 desks, worldwide earthquake/weather, MONITORS CAM 9:10/16:9, automatic Gallery export, and private reporter review are retained.

## Build policy
The ZIP contains source, not an APK. A green Android GitHub Actions compilation, signature checks, and physical-device verification are required for APK validation.
