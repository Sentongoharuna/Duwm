# DUWM 1728.2/12 — Broadcast Review

## Continuation
Built from the latest 1728.2/11 FRAMING-CONTROLS source, itself based on /10. Keeps the original command centre, single globe, existing native camera, all data desks, dark navy colour, signal policies and full-picture/crop controls. No replacement shell.

## Visible and functional changes
- Review the finished MP4 inside the app, with playback, timeline seeking, replay and sharing.
- Broadcast Studio retains the most recent completed export per source, so Review and Share remain available after reopening a draft.
- Compact Broadcast Studio controls, green ready/saved accents, progress and cancellation.
- Picture-in-picture clips retain their real proportions. Portrait clips are fitted into the inset area without vertical squashing; preview and encoded frames use the same geometry.
- Draft migration accepts framing keys from the earlier /11 package variants, preserving FIT/FILL and crop position.
- My Recordings uses the same native review and share flow and full-frame thumbnails.
- All native pages reserve side cutouts/navigation areas as well as top/bottom bars. Insets remain owned by one outer shell.
- Android 6–9 Gallery publishing now registers a shareable MediaStore content URI instead of returning file://. Modern Android retains the pending-item publication flow.

## Evidence and scope
The workflow compiles the actual application and a separate test APK, verifies package name/version/signer, then installs and exercises native Android rendering and real MP4 export. A native-tested artifact is published only if those tests pass. Synthetic colour-marker videos and tone soundtracks are used solely in the test APK; they are not injected as app news or real camera footage.

The latest /11 framing geometry remains authoritative. KEEP FULL PICTURE adds navy bars when source/output shapes differ; FILL FRAME supports crop anchors. The selected preview and export share the same production layout.

Tests include broadcast graphics/ticker movement, exact subtitle end times, trim timing, frame ratios, crop anchors, rotated video, AAC retention, portrait inset proportions, saved-MP4 review/share wiring and system insets. The accompanying verification evidence records the checks actually executed for the delivered APK. The supplied workflow must run in GitHub before claiming a successful GitHub build; source tests alone do not prove an installed APK.

## Remaining requirements
Actual AI analysis still requires a configured authenticated production server and valid model credentials. No live AI inference is claimed by these mocked service contract tests. Physical phone camera quality, Samsung-specific codecs, recipient-app acceptance and performance require phone testing. This update does not add streaming or public uploads.

## Build identity
- versionCode: 172812
- versionName: 1728.2.12
- launcher: DUWM 1728.2/12 • DEVELOP.UGANDA
- application ID: com.sentongoharuna.worldsituationroom.rb2live25
- compile SDK / build tools: 36 / 36.0.0
- target SDK / minimum SDK: 35 / 23
- build runtime: Java 17, Gradle 8.13, Android Gradle Plugin 8.11.1

The optional existing DUWM_DEBUG_KEYSTORE_BASE64 secret retains the debug signer. Without a retained signer, each CI run may use a new debug key; do not delete an existing install containing private drafts merely to work around a signing mismatch.

## Usage
Record or select a clean master, choose output shape and framing, produce/review the report, then save. Use REVIEW to inspect the real saved MP4, and SHARE to choose a destination. Sharing opens Android's chooser; it does not publish or send automatically. Last Export and My Recordings reopen saved outputs.

## Primary implementation references
- Android system insets: https://developer.android.com/develop/ui/views/layout/edge-to-edge
- Android content URI read grants: https://developer.android.com/reference/android/content/Intent#FLAG_GRANT_READ_URI_PERMISSION
- Android shared media publication: https://developer.android.com/training/data-storage/shared/media
