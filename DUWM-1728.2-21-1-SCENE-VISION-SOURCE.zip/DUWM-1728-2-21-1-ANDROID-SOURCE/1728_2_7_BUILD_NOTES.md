# DUWM 1728.2/7 — Dark Navy + Measured Camera/Source Health

## Actual scope
Upgrade of the complete 1728.2/6 source, not a replacement application or globe.
The original globe, its dark geography palette, all 19 desks and previous video-editing modules remain.
This checkpoint improves operational UI; it does NOT complete the AI-generated broadcast-output engine.

## Changes implemented
1. A fixed six-channel camera health dock above the Record control: CAM, MIC, GPS, HEAD, WX and SAVE. The existing shared opaque lamps blink independently using the original real-state colour policy. Tap a channel to inspect the evidence and limitation behind its state.
2. Camera state requires freshly decoded camera frames. Low decoded-source FPS and insufficient source dimensions are warnings, not silently called Pro/60 fps. Old callbacks cannot repopulate a newly switched or released camera session.
3. Microphone OFF remains neutral; permission alone is not called working audio. During recording the actual MediaRecorder amplitude is sampled once by the existing meter and shared with the status dock. Silence, high levels and read failures have separate labels.
4. Location stays opt-in. Freshness uses Android monotonic location time. Missing, stale, low-accuracy and Android-marked mock fixes cannot be shown healthy. Status evidence does not expose exact coordinates.
5. Compass status includes freshness and sensor-reported accuracy. Weather transitions use explicit opt-in requests and actual returned responses; a result from an obsolete request cannot restore weather after GPS has been disabled. No automatic weather/network polling added.
6. Gallery status distinguishes no export, saving, failure and a successful MediaStore publisher result. A returned URI is not represented as a physical playback test.
7. Signal Centre updates visible stored-receipt summaries every two seconds and rebuilds only when its status/receipt key changes. Scrolling is retained. Connecting is no longer counted as no receipt. This does not fetch network feeds.
8. Native AlertDialogs and controls inherit #041424 backgrounds, #DEE5EF borders and #F5F7FA text. Camera imagery and video pixels are not darkened by a window filter.
9. Camera and source-centre UI refresh timers stop when their activity is paused. Per-lamp lifecycle and Android animation-scale handling are preserved.
10. Android versionCode 172807, versionName 1728.2.7, launcher label DUWM 1728.2/7. Version validator now strictly maps 1728.2/N to 172800 + N, including negative mismatch tests.

## Tests actually executed here
- 5,815 assertions executing the production colour/motion/source policy.
- 188 assertions executing the new production camera-health policy.
- 8 positive/negative release-version cases.
- Original app/source protection and all six inherited broadcast-editor regression scripts.
- 272 application Java files parsed successfully; 1 separate instrumentation file parsed.
- 77 main Android XML files validated.
- Eleven inherited editor, transcription, telemetry, capabilities and Gallery-publisher modules retained byte-for-byte.

These are host/software/source results, NOT successful device-camera tests. Source assertions check integration tokens; they do not execute Android UI code.

## Not verified
- Full Android Gradle build, APK signing and installation for 1728.2/7.
- Native Canvas pixel tests: added to the separate Android test APK but not executed here.
- Physical-phone colours, animation, camera/audio, Gallery playback or exported broadcast output.
- AI headlines/tickers, aspect-ratio quality, HDR/4K/60 fps, streaming or server-side publication. Existing incomplete features remain incomplete.
The local environment has no Android SDK or Gradle installation. dl.google.com could not be resolved, so SDK bootstrap was unavailable. No compiled APK is claimed.

## Build/run instructions
Upload the matching SOURCE.zip to the GitHub repository root and the APK.yml to .github/workflows/.
The push build checks all hashes and policies, compiles debug and Android-test APKs, validates signing, version and compiled class presence, then publishes artifacts.
Run the workflow manually with verify_android_pixels enabled to execute native colours/layout tests and capture the actual original-globe screen. The camera dock fixture PNG is clearly marked TEST-FIXTURES; it is not a real camera/sensor observation. The original-globe screenshot/video is a separate actual app capture.
The emulator uses a prepared Bash script, not newline-separated shell invocations.

## Physical-phone acceptance
- Approve the actual navy and saturated signals against the user's reference.
- Open camera: no permission, no frames, ready, recording, low FPS, and failure are distinguishable.
- MIC off stays neutral; enabling permission alone stays untested until real amplitude is read.
- Optional GPS is hidden by default. Stale, mock and low-accuracy inputs do not go green.
- Turn GPS off while weather fetch is pending: no stale response may return as current.
- Source Centre updates without manual reread and preserves scroll/filter selection.
- Save a real recording; verify Gallery URI, player, sound and source labels on the phone.

## Primary API references reviewed
- https://developer.android.com/reference/android/location/Location#getElapsedRealtimeNanos()
- https://developer.android.com/reference/android/media/MediaRecorder#getMaxAmplitude()
- https://developer.android.com/reference/android/view/View
- https://github.com/ReactiveCircus/android-emulator-runner
