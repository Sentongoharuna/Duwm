# DUWM 1718 — WORLDWIDE + MONITORS CAM

**Lineage:** 1717 FIX1 signed APK succeeded on GitHub. 1718 modifies its complete source, not a new standalone shell. VersionCode 171800 / versionName 1718.

## Implemented in 1718 Android source
- New `Duwm1718GlobalDiscoverActivity`: 20 geographic shortcuts across six world regions, search any city via device geocoder (may require network/provider service), save up to 40 followed places in private on-device preferences, see real local time for known geographic presets, open existing OpenStreetMap source map at chosen coordinates, return to the one original globe. Country-neutral default: ALL for news, not Uganda.
- New `Duwm1718MonitorsCamActivity`: native preview for front/back camera, zoom when available, 15-300 second recording, optional microphone with runtime permission, optional fresh GPS with explicit consent, real compass when rotation-vector sensor available, altitude if provided by fresh GPS, reporter/place/situation free text, opt-in model weather via Open-Meteo. Default exact GPS is WITHHELD. 12 FPS 540×960 H264 MP4 is encoded by MediaRecorder input Surface with full video frames drawn using Canvas including source labels, UTC clock and actual sensor or unavailable status. **The recorder refuses/discards capture if a particular Android encoder cannot accept Canvas-rendered frames**; it must never claim it burned metadata when it did not. No dummy sensor data or fake LIVE badge.
- MONITORS CAM footage returns to existing `LocalMonitorActivity` composer, where reporter must explicitly confirm recording rights and decide whether to keep a private draft or publish. Every report starts UNVERIFIED. No automatic uploading.
- Same existing original globe, 19 desks, signal lights, navy `#041424`, silver `#DEE5EF`, full-screen page patterns and source-backed statuses. The report composer now uses the approved global palette.

## NOT claimed
- A worldwide backend or public reporting server, AI fact checking, automatic reporter verification, worldwide live video broadcasting and commercial weather data rights are NOT provided by this source update.
- Weather model availability is network dependent. Open-Meteo's no-key endpoint has noncommercial use terms; obtain the proper licence before a commercial rollout.
- Encoder support and recording quality have to be tested on real Android phones. Source parsing does not substitute for an APK build and device playback test.
- GPS embedded into a shared MP4 cannot later be removed from the pixels. User must opt in, and safety warning is in the camera UI.

## CI contract
Compile all Android Java with `:app:assembleDebug`, check APK signing and versionCode, and publish the real APK artifact regardless of optional emulator download failure. Do not call a source-only ZIP an APK.
