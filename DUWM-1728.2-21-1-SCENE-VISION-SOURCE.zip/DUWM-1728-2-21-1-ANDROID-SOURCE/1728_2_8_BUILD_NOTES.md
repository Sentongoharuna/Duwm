# DUWM 1728.2/8 — clean capture and shared broadcast output

This is an INTEGRATION DEVELOPMENT BUILD, not an all-green production release.

## Actual implementation
- Existing original globe, maps, 19 desks and signal engine retained unchanged.
- Camera-first viewfinder and fixed recording dock; reporter/advanced controls in a separate panel.
- Native camera-to-recorder clean master, with optional audio and private telemetry sidecars.
- Automatic route from completed capture into broadcast review, instead of the unrelated reporting form.
- One platform-independent broadcast composition shared by Android Canvas preview and exported frames.
- Solid #D50000 approved Breaking News badge; navy #041424; silver borders; coloured telemetry; separated captions and real time-based moving tickers.
- Independent 9:10, 9:16 and 16:9 crops, no stretching or silent upscaling.
- Sequential MediaCodec/SurfaceTexture/EGL export with source presentation timestamps, compatible AAC copying, cancellation, progress and output inspection.
- Removed fixed 45-second, 1280-pixel, 24-fps editing/export caps. The separate optional on-device recognition request still has a 45-second limit; the private AI server defaults to 10-minute analysis requests. Neither truncates the recording or export.
- Private AI-production client and separately deployable authenticated server: eight sampled visual frames, actual audio transcription, reviewed headline/ticker/captions. Automatic post-capture AI drafting is supported after explicit saved consent and connection setup. Cloud access is not configured in this package and has NOT been exercised.
- Original and broadcast files saved separately. Existing labels already inside older recordings cannot be erased by this update.

## Evidence executed locally
- Host JVM compilation of the actual shared composition and Java2D adapter.
- 113 executable raster/layout/motion/privacy/cue/aspect checks, including exact solid colours and ticker frame changes.
- Three six-second H.264 test MP4s rendered from that composition: 720x800, 720x1280, 1280x720 at 30fps. Test fixtures, not a phone recording or AI-generated event report.
- 13 private-server authentication, validation, limits, failure and cleanup tests. Provider calls are mocked; no live AI inference claimed.
- Original protected globe and application integrity checks.
- Java source syntax and Android XML parsing. Syntax is not Android compilation.

## Mandatory outstanding gates
- Full Android Gradle compilation, signing and installation for 1728.2.8.
- Run the bundled native Android Canvas and EGL/MP4 tests; collect actual MP4, pixel and audio evidence.
- Physical-camera orientation/framing/recording, microphone routing and Gallery playback.
- Deploy/connect an owner-authorised AI endpoint and test genuine inference with consent.
- HDR tone mapping/output, slow motion, time lapse, seamless in-recording lens switching, live streaming/resumable upload and map insets remain outside this correction and are NOT declared complete.

## What a green item means here
Host graphics tests are green ONLY at host-renderer scope. Client/server code is implemented but NOT a deployed AI service. No real-camera or APK claim follows from passing syntax tests.
