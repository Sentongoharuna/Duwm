# DUWM 1728 — Phase 1 development checkpoint (NOT A RELEASE)

Camera recording improvements added to the existing single-globe project:

- Existing HD/Pro 9:10/16:9 output retained.
- 4K landscape / 30fps and 60fps requests now require matching camera preview dimensions/FPS and H264 encoder capabilities; no automatic upscaling claims. Device results remain unverified.
- Camera2 reports advertised 4K, 60fps, high-speed, stabilisation and non-standard HDR profile support separately from actual recording success.
- Legacy camera video stabilization can be toggled only when supported.
- Exposed front/back camera IDs can be selected (physical lens switching during recording is NOT implemented).
- Audio input selection supports available Android input devices; preferred routing uses MediaRecorder.setPreferredDevice on Android 9+.
- Device/platform voice oriented source profiles are offered without guaranteeing noise suppression.
- Slow motion, time lapse, true HDR10 capture, in-recording seamless lens switching and full noise suppression are NOT IMPLEMENTED; UI explicitly discloses this.
- Android APK compilation and device tests NOT completed.

Verification: verification/check_source.py and verification/JavaSyntaxCheck.java passed for 261 Java files; additional test_phase1.py checks passed.

No final release ZIP/YAML should be issued until all 1728 acceptance criteria pass.
