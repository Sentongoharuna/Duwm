# DUWM 1724 – MONITORS CAM quality, Gallery export, and real six-stage signal flow

This release upgrades the **existing original globe** and native app. It does not create another globe, alternative launcher, fake feed or dummy activity. The primary palette remains `#041424` navy, `#DEE5EF` silver borders, `#F5F7FA` white and `#A0A5AE` secondary text. Status accents are reserved for genuine data-source conditions.

## MONITORS CAM

- **Gallery:** When a completed private MP4 is verified, copy it atomically into the Android system video gallery under `Movies/DUWM Monitors Cam` using `MediaStore` and `IS_PENDING` on Android 10+. The private source continues into World Monitor's review composer. If gallery publishing fails, the private file remains and the app reports that no gallery save occurred. Android 6–9 requests legacy storage permission.
- **Aspect:** Choose **9:10 portrait** (720×800 HD or 1080×1200 Pro) or **16:9 landscape** (1280×720 HD or 1920×1080 Pro). The UI requests landscape orientation for widescreen recording and scales the preview without stretching faces. The encoder pixel ratio is exact if supported.
- **Quality:** HD requests 24fps / 5Mbps; Pro requests 30fps / 12Mbps H.264. Device sensor preview must genuinely support the selected output dimensions; the app blocks disguised upscaling. Actual frame rate and bit rate depend on device capabilities, CPU load, and encoder acceptance. Audio is optional, with 128kbps AAC target.
- **Telemetry:** Source-labelled GPS, UTC, altitude, device compass, modelled weather, self-reported location/situation, private draft and SHA-256 receipt are retained. Exact GPS remains opt-in and appears permanently in both private and Gallery copies if enabled.

## Data provider signal flow

Receipts drive each indicator independently. From worst to best: **red** outage, **orange** degraded/unavailable access, **yellow** cached or stale information, **blue** connecting, **cyan** genuinely new accepted information, and **green** fresh healthy source. **Grey** means no receipt (not an outage); **silver** means local-only tool (not a live data feed). An actual successful source receipt can show cyan briefly, then green until its freshness window expires; without a reply it becomes yellow, and a stalled connection becomes orange. No artificial activity/blinking. For multiple providers in a sector, show the worst confirmed known condition.

The Signal Centre provides legend, named source status, provider/last receipt evidence and an on-device history of up to 12 actual status transitions per sector. The original globe retains its protected size and the non-overlapping 19-signal rail.

## Verification boundaries

Source checks include Python project integrity, Java syntax parsing, a compiled pure-Java signal-state regression suite, and a hash-verified source ZIP. **These are not a substitute for a green GitHub Android compilation.** Hardware acceptance must record/stop both aspect ratios, confirm real decoded MP4 dimensions, physically inspect Gallery copies, test overlays and audio, test screen rotation, and verify truthful status transitions with real provider updates.

Public design references used for concepts (not copied proprietary code): Atlassian Statuspage component health and incident severity, Grafana status history, Android MediaStore video publishing and camera recording APIs.
