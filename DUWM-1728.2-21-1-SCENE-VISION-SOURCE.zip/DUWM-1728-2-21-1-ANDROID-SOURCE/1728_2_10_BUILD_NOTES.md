# DUWM 1728.2/10 — Broadcast timing and output checks

## Scope
Continues the complete 1728.2/9 project, not another app, globe or camera shell.
Real Android identity: versionName 1728.2.10; versionCode 172810.

## Implemented changes
1. Broadcast Studio now automatically inspects the actual source tracks and advertised Android encoder before enabling export. The compact output panel shows requested dimensions, frame rate, presence/absence of audio, duration and centre-crop area. Tap for full details or recheck. Codec support is not represented as a completed export or a measured 4K/60 camera guarantee.
2. Shared preflight logic is called again inside the actual export operation. HDR and non-AAC source audio are rejected clearly instead of silently mis-converting or dropping sound. No new automatic downscale or upscaling is introduced.
3. Ticker update origins are attached to source-video time, persisted with drafts, and clipped to the selected range. A later trim carries in the then-current update instead of restarting a previous event as new.
4. AI captions retain absolute source timestamps; response timebases and analysed range are explicit. The app validates the full response before replacing the draft. A new mocked server test verifies the source/clip offsets.
5. SRT import retains exact start AND end milliseconds, permits recordings beyond 45 seconds and more than twelve captions, keeps silent gaps, and provides an editable review dialog. The 64 KiB file limit and 5000-cue ceiling remain. Invalid/overlapping cues require correction.
6. Manual start-only captions expire after six seconds or the next cue, whichever comes first; exact custom end times are available through SRT. AI/imported timed captions keep their supplied ends.
7. Preview seeking and the visible playback counter refer to the selected trimmed broadcast. Preview and exporter use the same prepared cue lists. No changes to the shared navy/red/silver layout were needed.
8. Saved-output confirmation displays inspected dimensions, duration, size and audio-track presence from the produced MP4. A metadata check is not a playback/listening test.
9. Format, style, subtitles, ticker and inset changes require renewed review; source-state errors disable export rather than retaining a stale approved preview.
10. Native Android tests retain all /9 checks and add output inspection plus a fourth, trimmed MP4 export with AAC audio and source-preservation checks. Test failures are not masked.

## Executed locally
- 30 production timeline/SRT/seek/negative test cases.
- 113 shared broadcast-layout/pixel/motion/privacy assertions.
- 128 AI-start state checks and regression rejecting the old missing startAi(spec()) method.
- 5815 production signal-policy/animation and 188 capture-health assertions.
- 14 AI service tests using mocked providers, not actual AI inference.
- Java syntax parsing: 280 application files and 2 instrumentation files.
- Original app integrity, XML, version identity, archive checksums and fallback recovery.
- 275 /9 application Java files preserved byte-for-byte, including the original globe and clean-camera recording engine.

## GitHub baseline verified in this session
1728.2/9 run 42351095467 passed both compile-development and native-broadcast-tests.
That verifies the /9 emulator fixture exports, not this /10 source or the user's physical camera.

## Not verified / not completed
/10 Android API compilation, install, new native encoder tests and physical-phone operation are NOT claimed here. The local environment lacks the Android SDK/Gradle and cannot resolve the external SDK download hosts. Run the supplied workflow for those build/emulator gates.
A configured HTTPS AI service and real model credentials are still required for automatic AI production. No credentials are included and no live AI was called. Full HDR conversion, slow motion/time-lapse, seamless physical lens changes, live streaming, resumable uploads and geographic map inset remain outside this change. Earlier uploaded burnt-in labels cannot be erased by these fixes.

## Deliverables
Upload SOURCE.zip to repository root and APK.yml to .github/workflows/.
The YAML can alternatively restore this exact project from the known /8 PRO-BROADCAST source using its embedded checked patch. Matching /9 bases are also supported.
Compiled artifact: DUWM-1728.2-10-COMPILED-DEVELOPMENT-APK.
Only after native tests pass: DUWM-1728.2-10-NATIVE-TESTED-DEVELOPMENT-APK.
All artifacts are debug/development outputs; physical phone and production-service testing remain separate.

## Primary technical reference
Android MediaMuxer: https://developer.android.com/reference/android/media/MediaMuxer
Android VideoCapabilities: https://developer.android.com/reference/android/media/MediaCodecInfo.VideoCapabilities
These APIs provide track/codec information; advertised support alone is not physical recording evidence.
