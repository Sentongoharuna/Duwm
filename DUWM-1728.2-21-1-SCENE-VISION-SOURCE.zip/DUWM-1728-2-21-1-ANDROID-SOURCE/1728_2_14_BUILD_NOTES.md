# DUWM 1728.2/14 — Export recovery

This continues the exact delivered 1728.2/13 Broadcast Controls source, whose
SHA256 is `2bedae2dd91869b7e74c88e8b10877c94bcae1eae6bbf7c74630ec332e6cda3f`.
The app ID remains `com.sentongoharuna.worldsituationroom.rb2live25`. This build
uses version code `172814`, version name `1728.2.14`, and launcher label
`DUWM 1728.2/14 • DEVELOP.UGANDA`.

## Completed exports survive a failed Gallery save

Previously the editor deleted its completed temporary MP4 after any Gallery
publication attempt, including a failed attempt. The original recording and
draft survived, but repeating the save required another render.

The editor now retains the completed MP4 in durable app-private storage before
publishing it to Gallery. A successful Gallery result is recorded before local
cleanup. A failed or interrupted save leaves a recovery entry. Recovery entries
are distinct from the editor's last successfully saved Gallery broadcast.

## Pending broadcasts

The editor and My Recordings both open the native Pending Broadcasts screen.
It lists the retained filename, actual byte size, creation time and save state.
Available actions are Review Copy, Share Copy, Save to Gallery, and Delete Copy.
A retry uses the completed MP4 directly; it does not restart the renderer.

The native review player identifies recovery copies. Its existing full-screen,
playback, seek, loop, mute and paused-resume controls remain available. Sharing
uses a private read-only content provider and a temporary content-URI read grant.
No automatic external sharing is added.

An interrupted or uncertain publication is explicitly unconfirmed. The screen
asks the user to check Gallery before deliberately creating another copy.
Concurrent saves of the same retained export are rejected. A recorded successful
publication returns the existing saved URI instead of publishing again.

Deleting a retained copy requires confirmation and does not delete the original
recording, draft or a previously saved Gallery video. Retained copies belong to
this installation; uninstalling or clearing app data removes them. There is no
silent quota eviction of completed pending broadcasts.

## Preserved application

The original single globe, navy `#041424` theme, native camera, all existing
desks, source receipts, broadcast renderer and Gallery publisher are retained.
`verification/1728_2_13_PRESERVED_JAVA.json` protects 281 unchanged production
Java files from the delivered /13 source. Existing production changes are
limited to the editor, saved-video review and My Recordings activities, with
new recovery components added separately.

## Reproducible build and verification

`verification/check_1728_2_14.py` checks source preservation, release identity,
host regressions and recovery policies. Host tests do not establish Android
runtime behavior. The workflow performs actual Java compilation and assembles
application and instrumentation APKs, then verifies identity and signatures.

All eight previous native stages remain required: signals, graphics, exports4,
framing, inset1, review, editor_controls and review_controls. A ninth recovery
stage exercises the new persistence, provider, retry and user interface path.
The full native gate requires every stage to pass under one run identity with
the exact installed app and test APK hashes. System ANR overlays and unavailable
MediaStore storage are failures or blockers, never successful UI/Gallery proof.
Injected failure tests are labelled separately from real Gallery publication.

The delivered source ZIP and workflow form a matched pair. The workflow checks
all packaged source hashes. If the /14 ZIP is absent, its embedded checked patch
can restore the exact source from a known /10, /11, /12 or /13 source ZIP.
A mismatched complete /14 ZIP is rejected. A generated workflow is not evidence
that GitHub Actions ran or passed.

## Build status and scope

The accompanying verification report contains the actual executed results,
including any incomplete native stages. The APK is a signed debug/development
build. No release-key, physical-phone, recipient-app or live-AI validation is
implied. Live AI still requires the configured authenticated service. The
optional CI debug-key secret can preserve an existing signer; no private key is
included in these files.
