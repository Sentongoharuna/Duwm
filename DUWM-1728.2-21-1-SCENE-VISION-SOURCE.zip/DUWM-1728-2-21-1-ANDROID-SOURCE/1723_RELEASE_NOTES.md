# DUWM 1723 — Worldwide Forecasts + Camera Gestures

Based on DUWM 1722 complete source. Preserves exactly one protected rotating original globe, 19 desks, native signal status and reference #041424 navy / #DEE5EF silver palette.

## User-visible changes
- Worldwide full-screen weather: selected saved global locations can open provider-model conditions, a 7-day daily and 12-hour hourly outlook, with UTC retrieval times and a clearly labelled offline cache. Network calls happen only on an explicit user tap.
- Global Discovery cards for any chosen location offer a **7-DAY WORLD WEATHER** action. The original globe Explore > Weather opens this same screen. My World adds World Weather navigation.
- Camera preview accepts tap-to-focus and pinch-to-zoom through actual Android legacy Camera APIs, when supported; both are disabled during recording.
- Corrected shell, video-overlay, My World, camera, quake and Global Discovery visible build labels to 1723. No new globes or replacement launches.

## Limitations and safety
- Weather is a third-party numerical model feed (Open-Meteo), **not** locally measured, official warning or real-time observation; user must check API/commercial license before launch.
- Optional camera overlay recording remains device-dependent; no successful hardware capture claimed without device tests.
- UI/Java source checks do not substitute for Android Gradle compilation, installation or real recording validation.
