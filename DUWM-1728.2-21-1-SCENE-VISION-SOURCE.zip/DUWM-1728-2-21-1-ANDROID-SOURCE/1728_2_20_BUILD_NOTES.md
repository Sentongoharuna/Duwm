# DUWM 1728.2/20 — automatic ticker pages and built-in caption readiness

## Exact starting point

This build extends the delivered /19 AUTO-REPORT source, SHA-256
`710339087ec92cb7c96a6942578327bacefac52feeca9c09fa12f5bc25d9789a`.
Its 831-entry source manifest is retained unchanged. Four existing production
Java files integrate the two upgrades; two new speech helpers are added. The
other 296 /19 production Java files remain byte-for-byte unchanged, including
the original globe, native camera, 19 desks, caption editor, Gallery recovery,
SRT/document sharing and saved-video review. The dark navy remains #041424.

## Automatic ticker excerpts

The /19 shared painter scrolled all tickers at a fixed speed. Some automatically
selected source excerpts had intervals too short for their tail to enter the
visible ticker area. The reproduction uses the actual speech cue policy,
automatic report plan and shared desktop painter, not a mock layout.

In /20, an active structured automatic ticker uses measured one-line pages.
Each page is fully fitted to the ticker viewport. Pages divide the existing cue
interval deterministically, and the first and last pages are reachable within
that interval. Stored excerpt words and source times stay unchanged. Trimming
still clips and rebases display intervals; it does not rewrite source metadata.
The existing caption pager supplies the same bounded measurement/cache policy.
Manual tickers keep their original continuous scrolling behavior. Manually
replacing an automatic ticker switches back to that behavior.

Automatic excerpts are still excerpts; this change does not remove the existing
report policy's excerpt length or pretend a headline is a full transcript. The
complete caption document and original SRT remain available. Page intervals are
display choices rather than new speech timestamps. Very dense or very short cues
can still be too fast to read, and can contain more pages than encoded frames.

## Caption readiness without server setup

On-device recognition previously accepted only the phone's exact language tag
or its bare primary language. An en-UG request, for example, could reject an
installed en-GB model. /20 chooses an installed compatible model deterministically:
exact language tag, then the bare primary language, then a compatible same-language
regional tag. Malformed or unrelated tags and conflicting writing scripts are
rejected. Pending or merely downloadable models are never treated as installed.
If the selected tag changes, DUWM checks the final exact recorded-audio request
again before starting recognition or delivering audio. Errors, timeouts and
indeterminate support retain the caption-free fallback. Recognition remains
segmented recorded-source audio; an ordinary microphone result cannot complete it.

AI HELP now automatically checks this phone and shows the requested language,
selected model and a specific readiness state. CHECK CAPTIONS repeats the check.
This uses the recording request's file/segmented/timing configuration with an
unfed pipe; it never reads the video, listens to the microphone, starts recognition
or requests a model download. The check is bounded and releases its resources on
completion, dismissal, automatic-production start or activity destruction. A
positive support response means ready to attempt captions; actual words, timestamps
and complete audio delivery are still required during production. The selected
language is included in the automatic caption result/receipt.

Everything in this automatic path stays in the app/device. There is no address,
account or API-key form. Speech still depends on the installed Android recognition
service and supported language model. When captions cannot be obtained, automatic
production finishes the MP4 with its original AAC audio and reports the omission.
This is not a bundled general-purpose chat model or a claim of semantic visual
editing. The existing automatic edit retains the complete source recording,
fits its original picture shape, adds compact graphics and publishes to Gallery.

## Inherited Actions repairs

The observed /18 run compiled successfully and passed 12 of 13 native stages.
The caption_files stage failed because its RadioButton test treated performClick's
click-listener boolean as the selection outcome. The exact /19 repaired test is
retained: it verifies the selected button, opposite button, RadioGroup selection
and actual caption-file controller time basis. Ordinary button checks remain strict.

The matching /20 workflow retains the RUNNER_TEMP/GITHUB_ENV context repair and
Node 24 actions: checkout v5, setup-java v5, setup-python v6, Gradle setup v5,
upload-artifact v6, download-artifact v7 and android-emulator-runner v2. It restores
the exact full /20 source or a checked patch over exact /10 through /19 archives.
A corrupt present /20 archive is rejected rather than silently ignored.

Fifteen native stages are mandatory. The new automatic_ready stage uses a clearly
identified synthetic transcript to drive the real editor, renderer, Gallery and
output decode. It checks first/last automatic ticker pages, timing preservation,
manual takeover and the actual help dialog. This is not speech-recognition proof.
All earlier stages remain required. Failed, missing, obstructed, altered or wrong-
APK evidence must fail; a compiler result never substitutes for native execution.

## Verification and use

Executed results belong to DUWM-1728.2-20-VERIFICATION.zip. This source document
sets requirements and does not assert a current Android native pass. The local
runtime lacks KVM and has an unresolved API35 storage/system-process failure;
no equivalent failing boot is repeated. Actual phone speech, camera capture and
all fifteen native stages need a current matching GitHub/device run.

Install DUWM-1728.2-20-AUTO-READY.apk as the development build. To run Actions,
place DUWM-1728.2-20-AUTO-READY-SOURCE.zip at repository root and the matching
DUWM-1728.2-20-AUTO-READY-APK.yml under .github/workflows/. Push to main or use
workflow_dispatch. Compiled development APKs remain distinct from APKs published
only after all required native stages pass.

## Primary references consulted

- https://developer.android.com/reference/android/speech/RecognitionSupport
- https://developer.android.com/reference/android/speech/SpeechRecognizer
- https://developer.android.com/reference/android/speech/RecognizerIntent
- https://developer.android.com/reference/android/view/View#performClick()

RecognitionSupport distinguishes installed, scheduled and downloadable language
support for the checked request. SpeechRecognizer.checkRecognitionSupport checks
the supplied intent; its positive result does not establish transcription accuracy.
