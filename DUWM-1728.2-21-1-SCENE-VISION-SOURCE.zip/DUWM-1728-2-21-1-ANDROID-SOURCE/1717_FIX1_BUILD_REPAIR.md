# DUWM 1717 FIX1 — verified GitHub compiler error repair

Base: DUWM-1717-RECEIPT-AUDIT-SOURCE.zip (SHA-256: 7f76aea61e3bd1bf025d9babda31a1e0e6559c08c2f1ddaa41f3f965c7c98760).
GitHub run: https://github.com/Sentongoharuna/Duwm/actions/runs/42211817796

Root cause: Duwm1715SignalLights.java:40, Java compiler error `illegal forward reference`.
A static Runnable initializer read the field `visible` before its declaration.

Repair: Move the existing WeakReference<SignalRail> field declaration before
COALESCED_REFRESH; do not change signal timings, styling, providers, visual
components, activity launching or the original globe. Include regression guard
verification/check_1717_fix1.py. 1717 is kept as the version name/code until a
real GitHub Action produces and verifies the repaired APK.

The earlier syntax-only parser does not type-check Java field initialization.
Full `:app:assembleDebug` on GitHub Actions remains required. Do not claim an
APK is compiled or green based only on source validation.
