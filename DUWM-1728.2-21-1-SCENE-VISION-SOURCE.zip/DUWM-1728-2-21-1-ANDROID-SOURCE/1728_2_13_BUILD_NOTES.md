# DUWM 1728.2/13 — Broadcast controls

This continues the exact delivered 1728.2/12 Broadcast Review source. The app ID
is `com.sentongoharuna.worldsituationroom.rb2live25`, the version code is
`172813`, and the version name is `1728.2.13`. The launcher identifies
`DUWM 1728.2/13 • DEVELOP.UGANDA`.

## Editor

The native broadcast editor gains MARK IN, MARK OUT and RESET TRIM buttons.
The marks use the current playhead position in milliseconds. Both marks are
clamped to the actual source duration and retain a valid, nonempty trim range.
The existing numeric trim inputs remain available. Changing a trim mark clears
the previous approval, refreshes the visible bounds and uses the existing
preview and export timeline.

The preview and its controls share a responsive workspace. Landscape places
the video beside a scrolling control column; portrait keeps the video above
the controls. This preserves a usable picture area when the additional trim
controls are present, without replacing the native player during rotation.

Repeated preview updates are scheduled only during playback. Unchanged clock
text and seek values are not rewritten. Edits, seeks, framing changes and an
asynchronous inset-video frame still request an immediate refresh. This removes
the known paused-screen refresh loop; it is not a measured phone benchmark.

## Saved-video review

The existing native MP4 review screen gains an expanded viewing mode, with a
visible path back to its controls, plus LOOP and MUTE controls. The same player
preserves the video's proportions. Resume position and playback preferences are
stored separately for each content URI. Reopening a saved video restores the
position while remaining paused. Completion clears the resumable end position.

Read-grant sharing, unavailable-file handling, background metadata inspection
and lifecycle cleanup continue to use the existing native review route.

## Original application

The original single globe, navy `#041424` theme, native camera, all existing
desks, source receipt handling and export renderer are retained. The
`verification/1728_2_12_PRESERVED_JAVA.json` file protects 280 unchanged production
Java files from the exact /12 source. The only existing production Java files
edited for /13 are the video editor and saved-video review activities.

## Verification and reproducible build

`verification/check_1728_2_13.py` checks the release identity and preserved source,
then runs the host rendering, timing, framing, trim and signal policy tests. Host
checks do not establish Android runtime or physical-phone behavior.

The workflow performs actual Android Java compilation, assembles both APKs,
checks the application's identity and signature, and runs eight independent
native stages: `signals`, `graphics`, `exports4`, `framing`, `inset1`, `review`,
`editor_controls` and `review_controls`. Each stage writes its own result,
phase history and hashed evidence tied to the installed application and test
APK. The full native gate requires all eight passes from one run identity.
A system ANR dialog is recorded as an environment obstruction, not dismissed
or converted into a successful pixel test.

The supplied source ZIP and YAML are a matched pair. The workflow verifies every
packaged source hash. If the complete /13 ZIP is absent from the repository, its
checked embedded patch can recover the exact same source from the known /10,
/11 or /12 source ZIP. It rejects an incorrect complete /13 ZIP.

## Limits

Actual local build and native-stage outcomes are recorded in the accompanying
verification report. A generated workflow is not evidence of a successful
GitHub Actions run. Physical-phone capture, live AI inference, third-party
recipient acceptance and legacy-device runtime remain separate checks.
AI production still requires the configured authenticated service.

The delivered APK is a signed debug/development build. A CI build can use the
existing optional retained debug-key secret; without it, GitHub may use a
different signing key. No private signing key is included in these files.
