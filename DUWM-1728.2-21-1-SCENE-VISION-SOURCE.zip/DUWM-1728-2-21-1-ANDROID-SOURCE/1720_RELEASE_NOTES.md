# DUWM 1720 — screenshot-led layout, exact palette, camera and worldwide upgrades

Base: complete DUWM 1719 source, with one original `SatelliteMapView` globe.

- Home palette now obtains background, cards, borders and readable labels from the exact approved `DuwmUnifiedTheme`: navy `#041424`, silver `#DEE5EF`, main text `#F5F7FA`, secondary `#A0A5AE`. Genuine source state lights retain semantic colours.
- Shared 19-sector signal rail now reserves Android status and gesture bar insets at its outer shell, eliminating overlap with Android's top clock and indicators while keeping the globe in its original container. No duplicate insets on the MainActivity root.
- MONITORS CAM includes real device-supported single-shot autofocus and exposure compensation +/- buttons, plus a switchable preview-only composition grid. No fake sensor values; the existing video compositor still burns telemetry into an MP4 only on compatible devices.
- Global Discovery adds all-world and 6 geographic region filters, plus shareable saved-location clock cards. Search still resolves any world city using device Geocoder; presets are navigational shortcuts, not live events.
- Source and YAML are independently downloadable. Green APK requires compilation and actual camera recording/MP4 playback on target phone; syntax-only tests cannot establish recording compatibility.
