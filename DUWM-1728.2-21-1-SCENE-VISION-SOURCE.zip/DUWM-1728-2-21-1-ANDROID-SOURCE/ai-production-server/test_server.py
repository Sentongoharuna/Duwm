"""Executed contract tests; provider calls are deliberately mocked, never called live."""
import importlib.util
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
spec=importlib.util.spec_from_file_location('duwm_server',Path(__file__).with_name('server.py'))
server=importlib.util.module_from_spec(spec);spec.loader.exec_module(server)
client=TestClient(server.app)
TOKEN='local-test-device-token-not-for-deployment'

def setup(monkeypatch):
    monkeypatch.setenv('DUWM_DEVICE_TOKEN',TOKEN)
    monkeypatch.setenv('OPENAI_API_KEY','TEST-ONLY-NO-REAL-KEY')
    monkeypatch.setenv('OPENAI_VISION_MODEL','TEST-MODEL')

def test_missing_configuration(monkeypatch):
    for key in ('DUWM_DEVICE_TOKEN','OPENAI_API_KEY','OPENAI_VISION_MODEL'):monkeypatch.delenv(key,raising=False)
    assert client.get('/health').json()['configured'] is False
    assert client.post('/v1/produce?to_ms=1000').status_code==503

def test_auth_is_required(monkeypatch):
    setup(monkeypatch)
    assert client.post('/v1/produce?to_ms=1000').status_code==401
    assert client.post('/v1/produce?to_ms=1000',headers={'Authorization':'Bearer wrong'}).status_code==401

@pytest.mark.parametrize('query',['from_ms=-1&to_ms=1000','from_ms=1000&to_ms=1000','from_ms=0&to_ms=600001'])
def test_time_bounds(monkeypatch,query):
    setup(monkeypatch)
    assert client.post('/v1/produce?'+query,headers={'Authorization':'Bearer '+TOKEN,'Content-Type':'video/mp4'}).status_code==400

def test_mime_and_small_upload(monkeypatch):
    setup(monkeypatch)
    h={'Authorization':'Bearer '+TOKEN}
    assert client.post('/v1/produce?to_ms=1000',headers=h).status_code==415
    h['Content-Type']='video/mp4'
    assert client.post('/v1/produce?to_ms=1000',headers=h,content=b'bad').status_code==400

def test_size_limit(monkeypatch):
    setup(monkeypatch);monkeypatch.setattr(server,'MAX_BYTES',1024)
    assert client.post('/v1/produce?to_ms=1000',headers={'Authorization':'Bearer '+TOKEN,'Content-Type':'video/mp4'},content=b'x'*1025).status_code==413

def test_validation_never_approves_breaking():
    result=server.validate_report({'headline':'A reviewed draft','category':'BREAKING NEWS','ticker':[]},2000)
    assert result['category']=='FIELD REPORT'
    assert result['ticker']==[{'at_ms':0,'text':'A reviewed draft'}]
    assert 'verified' not in result

def test_times_quantised_and_deduplicated():
    result=server.validate_report({'headline':'Test','ticker':[{'at_ms':100,'text':'one'},{'at_ms':900,'text':'two'},{'at_ms':1500,'text':'three'},{'at_ms':-1,'text':'no'},{'at_ms':3000,'text':'no'}]},2000)
    assert result['ticker']==[{'at_ms':0,'text':'two'},{'at_ms':1000,'text':'three'}]

def test_malformed_model_fields():
    result=server.validate_report({'headline':'test','ticker':[None,{'at_ms':'bad','text':'no'},{'at_ms':0,'text':'  clean\n words;= '}], 'uncertainties':None},2000)
    assert result['ticker'][0]['text']=='clean words,-'
    assert result['uncertainties']==[]
    with pytest.raises(ValueError):server.validate_report({'headline':''},2000)

def test_authorised_flow_and_temporary_cleanup(monkeypatch):
    setup(monkeypatch);seen={}
    def fake(path,directory,start,end,notes):
        seen['path']=path;seen['length']=path.stat().st_size
        assert start==0 and end==1000
        return {'schema':'duwm.report.v1','headline':'TEST FIXTURE','review_required':True,'independently_verified':False}
    monkeypatch.setattr(server,'produce',fake)
    response=client.post('/v1/produce?to_ms=1000',headers={'Authorization':'Bearer '+TOKEN,'Content-Type':'video/mp4'},content=b'x'*600)
    assert response.status_code==200
    assert response.json()['review_required'] is True
    assert seen['length']==600 and not seen['path'].exists()

def test_model_failure_not_success(monkeypatch):
    setup(monkeypatch)
    def failure(*args):raise RuntimeError('TEST FAILURE')
    monkeypatch.setattr(server,'produce',failure)
    response=client.post('/v1/produce?to_ms=1000',headers={'Authorization':'Bearer '+TOKEN,'Content-Type':'video/mp4'},content=b'x'*600)
    assert response.status_code==502
    assert 'no report was approved' in response.text

def test_streaming_hash(tmp_path):
    path=tmp_path/'x';path.write_bytes(b'fixture')
    import hashlib
    assert server.file_hash(path)==hashlib.sha256(b'fixture').hexdigest()


def test_trimmed_reply_declares_time_bases(monkeypatch, tmp_path):
    import json
    setup(monkeypatch)
    source=tmp_path/'source.mp4';source.write_bytes(b'host fixture only')
    def fake_run(command, *args):
        if command[0]=='ffprobe':
            return json.dumps({'format':{'duration':'15.0'},'streams':[{'codec_type':'video'},{'codec_type':'audio'}]}).encode()
        Path(command[-1]).write_bytes(b'not media - mock only')
        return b''
    def fake_api(path, **kwargs):
        if path=='audio/transcriptions':return {'text':'hello','segments':[{'start':.25,'end':.75,'text':'hello'}],'words':[]}
        return {'output':[{'content':[{'type':'output_text','text':json.dumps({'headline':'Fixture','ticker':[{'at_ms':1000,'text':'Test'}]})}]}]}
    monkeypatch.setattr(server,'run',fake_run);monkeypatch.setattr(server,'api',fake_api)
    result=server.produce(source,tmp_path,5000,9000,'test notes')
    assert result['clip_from_ms']==5000 and result['clip_to_ms']==9000
    assert result['ticker_timebase']=='clip_relative_ms' and result['caption_timebase']=='source_absolute_ms'
    assert result['captions']==[{'start_ms':5250,'end_ms':5750,'text':'hello'}]
    assert result['ticker']==[{'at_ms':1000,'text':'Test'}]
    assert result['breaking_approved'] is False and result['review_required'] is True
