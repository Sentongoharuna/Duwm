# DUWM private AI-production service — not deployed

This source is a real client/service integration, not an activated AI service. No API key or server account was supplied. End-to-end cloud analysis is **not tested**.

## Start
1. Install Python 3.11+, FFmpeg and the packages in requirements.txt.
2. Set OPENAI_API_KEY on the server only. Set OPENAI_VISION_MODEL to a vision-capable Responses API model available to your account. No model name is silently guessed.
3. Set DUWM_DEVICE_TOKEN to a random server-issued value of at least 24 characters. This is a private single-owner prototype; production use requires per-user authentication, rate limiting, retention controls, security review and abuse protection.
4. Run `uvicorn server:app --host 127.0.0.1 --port 8080 --workers 1` behind an HTTPS reverse proxy. Configure upload size and request time limits. Run as non-root in a restricted container; keep FFmpeg patched.
5. In Broadcast Review > AI settings, enter the HTTPS server base URL and device token, **not the provider API key**. The device token is encrypted with Android Keystore.
6. Tap AI PRODUCE and approve transmission. The original MP4/audio (and any metadata already embedded in that file) is sent to your server. The server sends extracted frames and the audio to the configured model provider. Precise GPS sidecar data is not sent.

Eight sampled frames and actual soundtrack transcription are used. This is not continuous video understanding, an authenticity detector, independent verification, or live broadcasting. All generated headlines/tickers remain drafts until reporter review. The local export itself makes no network requests. The service deletes temporary media when the request finishes; provider retention is governed by your provider account policies, not this code.

The default analysis duration limit is 600 seconds and upload limit 512 MiB. These are disclosed server resource limits, not silent video trimming. MAX_ANALYSIS_SECONDS is configurable. Android broadcast export has no artificial 45-second limit.

## Primary API references
- https://developers.openai.com/api/docs/guides/images-vision
- https://developers.openai.com/api/docs/guides/speech-to-text
- https://developers.openai.com/api/reference/resources/responses/methods/create
