package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.Instrumentation;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.widget.VideoView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/** Test-only capture fence for the paused synthetic red/blue saved-video fixture. */
final class DuwmRenderedFrameCapture {
    private static final long TIMEOUT_MS = 5000;
    // Identical to DuwmBroadcastChecks.screenColour: each channel difference must be < 40.
    private static final int CHANNEL_TOLERANCE = 40;

    static final class Capture {
        final Bitmap bitmap;
        final int[] origin, size;
        final boolean ready;
        final String diagnostic;

        Capture(Bitmap bitmap, Geometry geometry, boolean ready, String diagnostic) {
            this.bitmap = bitmap;
            origin = geometry == null ? new int[2] : new int[]{geometry.x, geometry.y};
            size = geometry == null ? new int[2] : new int[]{geometry.width, geometry.height};
            this.ready = ready;
            this.diagnostic = diagnostic;
        }
    }

    private DuwmRenderedFrameCapture() {}

    /**
     * Returns an untouched UiAutomation screenshot; the caller owns/recycles its bitmap.
     * Readiness requires two consecutive frame fences and captures with identical geometry,
     * the fullscreen hierarchy, no pending layout, and both original strict marker colours.
     * A submitted frame alone is insufficient: SurfaceView composition is asynchronous.
     * On timeout ready is false; the caller must fail after saving/checking obstruction.
     */
    static Capture captureReviewFullscreen(Instrumentation runner, Activity activity,
            VideoView expectedVideo, File folder, String name) throws Exception {
        if (Looper.myLooper() == Looper.getMainLooper())
            throw new IllegalStateException("Capture must run on the instrumentation thread");
        if (expectedVideo == null) throw new IllegalArgumentException("Expected VideoView required");
        if (!folder.isDirectory() && !folder.mkdirs()) throw new IOException("Cannot create capture proof folder");
        final long started = SystemClock.elapsedRealtime(), deadline = started + TIMEOUT_MS;
        Handler main = new Handler(Looper.getMainLooper());
        StringBuilder log = new StringBuilder("REAL UIAUTOMATION SCREENSHOT; pixels are never altered\n")
                .append("timeout_ms=").append(TIMEOUT_MS).append(" sdk=").append(Build.VERSION.SDK_INT)
                .append(" required_consecutive_captures=2 channel_difference<").append(CHANNEL_TOLERANCE).append('\n');
        Bitmap latest = null;
        Geometry latestGeometry = null, previousGood = null;
        int consecutive = 0, attempts = 0;
        boolean ready = false, transferred = false;
        try {
            while (SystemClock.elapsedRealtime() < deadline && !ready) {
                FrameFence fence = new FrameFence(main, activity, expectedVideo, deadline);
                if (!fence.await()) {
                    log.append("frame_fence_timeout elapsed_ms=").append(SystemClock.elapsedRealtime() - started)
                            .append(" frame={").append(fence.geometry).append("} latest={").append(latestGeometry).append("}\n");
                    // A final real screenshot remains useful even when the app cannot render.
                    Bitmap diagnostic = runner.getUiAutomation().takeScreenshot();
                    if (diagnostic != null) {
                        if (latest != null) latest.recycle();
                        latest = diagnostic;
                        if (fence.geometry != null) latestGeometry = fence.geometry;
                    }
                    break;
                }
                Geometry before = geometryOnMain(main, activity, expectedVideo, deadline);
                if (before == null) {
                    log.append("geometry_before_timeout\n");
                    break;
                }
                Bitmap screenshot = runner.getUiAutomation().takeScreenshot();
                Geometry after = geometryOnMain(main, activity, expectedVideo, deadline);
                attempts++;
                if (screenshot != null) {
                    if (latest != null) latest.recycle();
                    latest = screenshot;
                    latestGeometry = before;
                }
                boolean geometryMatches = before.matches(fence.geometry) && before.matches(after);
                boolean markers = screenshot != null && marker(screenshot, before, .10f, .45f, 0xFFC91010)
                        && marker(screenshot, before, .90f, .50f, 0xFF1043D0);
                boolean acceptable = geometryMatches && before.usable && after != null && after.usable && markers;
                consecutive = acceptable ? (before.matches(previousGood) ? consecutive + 1 : 1) : 0;
                previousGood = acceptable ? before : null;
                log.append("attempt=").append(attempts).append(" elapsed_ms=").append(SystemClock.elapsedRealtime() - started)
                        .append(" fence=").append(fence.committed ? "hardware_frame_commit" : "posted_draw")
                        .append(" frame={").append(fence.geometry).append("} before={").append(before)
                        .append("} after={").append(after).append("} markers=").append(markers)
                        .append(" left=").append(sample(screenshot, before, .10f, .45f))
                        .append(" right=").append(sample(screenshot, before, .90f, .50f))
                        .append(" consecutive=").append(consecutive).append('\n');
                ready = consecutive >= 2 && SystemClock.elapsedRealtime() <= deadline;
            }
            if (latest == null) latest = runner.getUiAutomation().takeScreenshot();
            if (latestGeometry == null) log.append("geometry_unavailable: returned origin=0,0 size=0,0; readiness is false\n");
            String diagnostic = (ready ? "READY" : "TIMEOUT") + " after "
                    + (SystemClock.elapsedRealtime() - started) + "ms; captures=" + attempts;
            log.append(diagnostic).append('\n');
            writeText(new File(folder, name + "-CAPTURE.txt"), log.toString());
            if (!ready && latest != null) {
                try (FileOutputStream out = new FileOutputStream(new File(folder, name + "-TIMEOUT.png"))) {
                    if (!latest.compress(Bitmap.CompressFormat.PNG, 100, out))
                        throw new IOException("Cannot retain timed-out screenshot");
                }
            }
            Capture result = new Capture(latest, latestGeometry, ready, diagnostic);
            transferred = true;
            return result;
        } finally {
            if (!transferred && latest != null) latest.recycle();
        }
    }

    private static Geometry geometryOnMain(Handler main, Activity activity, VideoView video, long deadline)
            throws Exception {
        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<Geometry> result = new AtomicReference<>();
        AtomicReference<Throwable> failure = new AtomicReference<>();
        Runnable read = () -> {
            try { if (SystemClock.elapsedRealtime() <= deadline) result.set(new Geometry(activity, video)); }
            catch (Throwable error) { failure.set(error); }
            finally { done.countDown(); }
        };
        main.post(read);
        if (!done.await(Math.max(0, deadline - SystemClock.elapsedRealtime()), TimeUnit.MILLISECONDS)) main.removeCallbacks(read);
        if (failure.get() instanceof Error) throw (Error) failure.get();
        if (failure.get() instanceof Exception) throw (Exception) failure.get();
        return result.get();
    }

    /** One new traversal, followed by its commit (API29+) or the next frame callback. */
    private static final class FrameFence implements ViewTreeObserver.OnPreDrawListener {
        final Handler main;
        final Activity activity;
        final VideoView video;
        final long deadline;
        final CountDownLatch done = new CountDownLatch(1);
        final AtomicBoolean finished = new AtomicBoolean();
        final Runnable committedCallback = () -> complete(true);
        final Runnable postedDrawCallback = () -> complete(false);
        View decor;
        ViewTreeObserver observer;
        volatile Geometry geometry;
        volatile boolean committed;
        volatile Throwable failure;

        FrameFence(Handler main, Activity activity, VideoView video, long deadline) {
            this.main = main; this.activity = activity; this.video = video; this.deadline = deadline;
        }
        boolean await() throws Exception {
            main.post(() -> {
                if (finished.get() || SystemClock.elapsedRealtime() > deadline) return;
                try {
                    decor = activity.getWindow().getDecorView();
                    observer = decor.getViewTreeObserver();
                    observer.addOnPreDrawListener(this);
                    decor.postInvalidateOnAnimation();
                } catch (Throwable error) { failure = error; complete(false); }
            });
            try {
                boolean completed = done.await(Math.max(0, deadline - SystemClock.elapsedRealtime()), TimeUnit.MILLISECONDS);
                if (failure instanceof Error) throw (Error) failure;
                if (failure instanceof Exception) throw (Exception) failure;
                return completed && geometry != null;
            } finally {
                finished.set(true);
                main.post(() -> {
                    if (observer != null && observer.isAlive()) {
                        observer.removeOnPreDrawListener(this);
                        if (Build.VERSION.SDK_INT >= 29) observer.unregisterFrameCommitCallback(committedCallback);
                    }
                    if (decor != null) decor.removeCallbacks(postedDrawCallback);
                });
            }
        }
        @Override public boolean onPreDraw() {
            if (observer != null && observer.isAlive()) observer.removeOnPreDrawListener(this);
            if (finished.get()) return true;
            try {
                geometry = new Geometry(activity, video);
                if (Build.VERSION.SDK_INT >= 29 && decor.isHardwareAccelerated())
                    observer.registerFrameCommitCallback(committedCallback);
                else decor.postOnAnimation(postedDrawCallback);
            } catch (Throwable error) { failure = error; complete(false); }
            return true;
        }
        private void complete(boolean wasCommitted) {
            if (finished.compareAndSet(false, true)) { committed = wasCommitted; done.countDown(); }
        }
    }

    private static final class Geometry {
        final int x, y, width, height, decorWidth, decorHeight;
        final Rect exitBounds = new Rect();
        final boolean usable, layoutPending, fullscreenHierarchy;

        Geometry(Activity activity, VideoView video) {
            View decor = activity.getWindow().getDecorView();
            int[] location = new int[2]; video.getLocationOnScreen(location);
            x = location[0]; y = location[1]; width = video.getWidth(); height = video.getHeight();
            decorWidth = decor.getWidth(); decorHeight = decor.getHeight();
            View header = decor.findViewWithTag("broadcast-review-header");
            View controls = decor.findViewWithTag("broadcast-review-controls");
            View exit = decor.findViewWithTag("broadcast-review-exit-fullscreen");
            if (exit != null) {
                exit.getLocationOnScreen(location);
                exitBounds.set(location[0], location[1], location[0] + exit.getWidth(), location[1] + exit.getHeight());
            }
            fullscreenHierarchy = header != null && !header.isShown() && controls != null && !controls.isShown()
                    && exit != null && exit.isShown() && exit.isEnabled();
            boolean pending = false;
            for (View ancestor = video; ancestor != null;) {
                pending |= ancestor.isLayoutRequested();
                ViewParent parent = ancestor.getParent();
                ancestor = parent instanceof View ? (View) parent : null;
            }
            layoutPending = pending;
            Rect visible = new Rect();
            boolean fullyVisible = video.getLocalVisibleRect(visible) && visible.equals(new Rect(0, 0, width, height));
            usable = !activity.isFinishing() && !activity.isDestroyed() && decor.hasWindowFocus()
                    && video == decor.findViewWithTag("broadcast-review-video") && video.isShown()
                    && video.isAttachedToWindow() && video.getHolder().getSurface().isValid()
                    && width > 64 && height > 64 && fullscreenHierarchy && fullyVisible && !layoutPending;
        }
        boolean matches(Geometry other) {
            return other != null && x == other.x && y == other.y && width == other.width && height == other.height
                    && decorWidth == other.decorWidth && decorHeight == other.decorHeight && exitBounds.equals(other.exitBounds);
        }
        @Override public String toString() {
            return "video=" + x + "," + y + "," + width + "x" + height + " decor=" + decorWidth + "x" + decorHeight
                    + " exit=" + exitBounds.toShortString() + " fullscreen=" + fullscreenHierarchy
                    + " layoutPending=" + layoutPending + " usable=" + usable;
        }
    }

    private static boolean marker(Bitmap screenshot, Geometry geometry, float x, float y, int wanted) {
        Integer actual = pixel(screenshot, geometry, x, y);
        return actual != null && Math.abs(Color.red(actual) - Color.red(wanted)) < CHANNEL_TOLERANCE
                && Math.abs(Color.green(actual) - Color.green(wanted)) < CHANNEL_TOLERANCE
                && Math.abs(Color.blue(actual) - Color.blue(wanted)) < CHANNEL_TOLERANCE;
    }
    private static Integer pixel(Bitmap screenshot, Geometry geometry, float x, float y) {
        if (screenshot == null || geometry == null || geometry.width < 1 || geometry.height < 1) return null;
        int px = geometry.x + Math.round((geometry.width - 1) * x), py = geometry.y + Math.round((geometry.height - 1) * y);
        return px >= 0 && py >= 0 && px < screenshot.getWidth() && py < screenshot.getHeight() ? screenshot.getPixel(px, py) : null;
    }
    private static String sample(Bitmap screenshot, Geometry geometry, float x, float y) {
        Integer value = pixel(screenshot, geometry, x, y);
        return value == null ? "unavailable" : String.format(Locale.ROOT, "%08x", value);
    }
    private static void writeText(File file, String text) throws IOException {
        try (FileOutputStream out = new FileOutputStream(file)) { out.write(text.getBytes(StandardCharsets.UTF_8)); }
    }
}
