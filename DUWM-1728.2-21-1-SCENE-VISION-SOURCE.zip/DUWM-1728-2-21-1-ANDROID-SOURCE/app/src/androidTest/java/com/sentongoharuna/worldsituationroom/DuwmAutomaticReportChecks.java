package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.SystemClock;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import org.json.JSONArray;
import org.json.JSONObject;

/** Synthetic supplied transcript -> real automatic report/editor/MP4/Gallery.
 * Only the recognition result boundary is seeded, explicitly in test code.
 * This stage never asserts that the synthetic words were spoken or recognized. */
final class DuwmAutomaticReportChecks {
    private static final String WORDS="Workers are continuing construction at the building while equipment moves around the site and pedestrians walk past the main entrance beside Wilson Road today. The recording continues while people pass the entrance and vehicles move through the same picture. These exact supplied words must also appear at the end of the caption.";
    private static final String NOTES="Reporter supplied fixture notes; no location or event independently verified.";
    private static final String CAPTION_STATUS="SYNTHETIC SUPPLIED TRANSCRIPT • no recognition callback or accuracy claim";
    private final DuwmNativeEvidence proof;private int checks;
    DuwmAutomaticReportChecks(DuwmNativeEvidence proof){this.proof=proof;}
    int count(){return checks;}
    private void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    private interface Action { void run()throws Exception; }
    private interface Condition { boolean ready()throws Exception; }
    private static void rethrow(Throwable failure)throws Exception {
        if(failure instanceof InvocationTargetException){rethrow(((InvocationTargetException)failure).getTargetException());return;}
        if(failure instanceof Error)throw (Error)failure;if(failure instanceof Exception)throw (Exception)failure;if(failure!=null)throw new RuntimeException(failure);
    }
    private void ui(Instrumentation runner,Action action)throws Exception {
        AtomicReference<Throwable> failure=new AtomicReference<>();runner.runOnMainSync(()->{try{action.run();}catch(Throwable error){failure.set(error);}});rethrow(failure.get());
    }
    private static Object field(Object object,String name)throws Exception{java.lang.reflect.Field field=object.getClass().getDeclaredField(name);field.setAccessible(true);return field.get(object);}
    private static void set(Object object,String name,Object value)throws Exception{java.lang.reflect.Field field=object.getClass().getDeclaredField(name);field.setAccessible(true);field.set(object,value);}
    private static Object call(Object object,String name)throws Exception{java.lang.reflect.Method method=object.getClass().getDeclaredMethod(name);method.setAccessible(true);try{return method.invoke(object);}catch(InvocationTargetException failure){rethrow(failure);return null;}}
    private void await(Instrumentation runner,Condition condition,long timeout,String label)throws Exception {
        AtomicBoolean ready=new AtomicBoolean();long deadline=SystemClock.elapsedRealtime()+timeout;
        do{ui(runner,()->ready.set(condition.ready()));if(ready.get())break;Thread.sleep(75);}while(SystemClock.elapsedRealtime()<deadline);check(ready.get(),label);
    }
    private Activity open(Instrumentation runner,File source)throws Exception {
        Activity editor=runner.startActivitySync(new Intent(runner.getTargetContext(),Duwm1728VideoEditorActivity.class)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(Duwm1728VideoEditorActivity.EXTRA_VIDEO_URI,Uri.fromFile(source).toString())
            .putExtra("notes",NOTES).putExtra("report_category","WEATHER"));
        await(runner,()->(Boolean)field(editor,"prepared"),15000,"Actual fixture editor player prepared");return editor;
    }
    private void finish(Instrumentation runner,Activity activity)throws Exception{if(activity==null)return;ui(runner,activity::finish);await(runner,activity::isDestroyed,15000,"Fixture Activity destroyed before reopening or cleanup");}
    private static void copy(InputStream input,OutputStream output)throws IOException{byte[] bytes=new byte[65536];int count;while((count=input.read(bytes))!=-1)output.write(bytes,0,count);}
    private void png(Bitmap image,File folder,String name)throws Exception{try(OutputStream output=new FileOutputStream(new File(folder,name))){check(image.compress(Bitmap.CompressFormat.PNG,100,output),"Save actual image "+name);}}
    private void screenshot(Instrumentation runner,Activity editor,File folder)throws Exception {
        await(runner,()->{
            View edit=(View)field(editor,"editButton");edit.requestRectangleOnScreen(new Rect(0,0,edit.getWidth(),edit.getHeight()),true);
            Rect visible=new Rect();int target=Math.round(48*edit.getResources().getDisplayMetrics().density);
            return edit.isEnabled()&&edit.isShown()&&edit.getGlobalVisibleRect(visible)&&visible.height()>=target-1&&visible.width()>=target-1;
        },3000,"Actual report EDIT control has a reachable48 dp target");
        ui(runner,()->check(((View)field(editor,"editButton")).performClick(),"Actual EDIT control opens report details"));
        await(runner,()->{
            AlertDialog dialog=(AlertDialog)field(editor,"detailsDialog");if(dialog==null||!dialog.isShowing())return false;
            View info=dialog.getWindow().getDecorView().findViewWithTag("broadcast-editor-auto-report-info");if(info==null)return false;
            info.requestRectangleOnScreen(new Rect(0,0,info.getWidth(),info.getHeight()),true);Rect visible=new Rect();
            return info.isShown()&&info.getGlobalVisibleRect(visible)&&visible.height()>=Math.min(info.getHeight(),Math.round(48*info.getResources().getDisplayMetrics().density));
        },3000,"Actual automatic-report explanation is reachable in the editor");
        boolean idle=true;try{runner.getUiAutomation().waitForIdle(100,3000);}catch(TimeoutException unsettled){idle=false;}
        Bitmap image=runner.getUiAutomation().takeScreenshot();check(image!=null,"Actual editor screenshot available");
        try{png(image,folder,"ANDROID-AUTO-REPORT-EDITOR.png");}finally{image.recycle();}
        proof.assertUnobstructed("ANDROID-AUTO-REPORT-EDITOR");check(idle,"Automatic report editor becomes quiet for screenshot capture");
        ui(runner,()->{AlertDialog dialog=(AlertDialog)field(editor,"detailsDialog");check(dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick(),"Actual DONE button closes report details");});
        await(runner,()->field(editor,"detailsDialog")==null,3000,"Actual report details dialog has closed");
    }
    private static List<Duwm1728BroadcastLayout.Cue> supplied(){return Arrays.asList(
        new Duwm1728BroadcastLayout.Cue(137,1567,WORDS),
        new Duwm1728BroadcastLayout.Cue(1601,1889,"Second supplied update; exact café text and source milliseconds remain attached."));}
    private void sameCues(List<Duwm1728BroadcastLayout.Cue> actual,List<Duwm1728BroadcastLayout.Cue> expected,String label){
        check(actual.size()==expected.size(),label+" count");for(int index=0;index<actual.size();index++){
            Duwm1728BroadcastLayout.Cue a=actual.get(index),e=expected.get(index);
            check(a.startMs==e.startMs&&a.endMs==e.endMs&&a.text.equals(e.text),label+" exact words and milliseconds "+index);
        }
    }
    private List<Duwm1728ExportRecovery.Entry> sourceReceipts(Context target,Uri source)throws Exception{
        ArrayList<Duwm1728ExportRecovery.Entry> result=new ArrayList<>();for(Duwm1728ExportRecovery.Entry entry:Duwm1728ExportRecovery.list(target))if(source.equals(entry.sourceUri))result.add(entry);return result;
    }
    private JSONObject awaitSaved(Instrumentation runner,Activity editor,Context target,String key)throws Exception {
        AtomicReference<String> state=new AtomicReference<>("");long deadline=SystemClock.elapsedRealtime()+120000;
        do{
            String raw=target.getSharedPreferences(Duwm1728AutomaticProduction.PREFS,Context.MODE_PRIVATE).getString(key,"");
            JSONObject receipt=raw.isEmpty()?null:new JSONObject(raw);
            if(receipt!=null&&"SAVED_WITH_CAPTIONS".equals(receipt.optString("state"))){
                await(runner,()->!(Boolean)field(editor,"autoProducing")&&!(Boolean)field(editor,"busy")&&field(editor,"lastBroadcast")!=null,15000,"Actual editor completes automatic report export");return receipt;
            }
            ui(runner,()->state.set((String)field(editor,"automaticStatus")));
            check(!"FAILED".equals(state.get())&&!"CANCELLED".equals(state.get())&&!"INTERRUPTED".equals(state.get()),"Automatic supplied-transcript export must succeed: "+state.get());
            Thread.sleep(100);
        }while(SystemClock.elapsedRealtime()<deadline);
        throw new AssertionError("Automatic report did not publish an MP4 in120 seconds: "+state.get());
    }
    private static final class RecordingCanvas implements Duwm1728BroadcastLayout.Painter {
        final Duwm1728BroadcastCanvas canvas;final ArrayList<String> captions=new ArrayList<>();boolean inCaption;
        RecordingCanvas(Bitmap image){canvas=new Duwm1728BroadcastCanvas(new Canvas(image));}
        public void rect(float x,float y,float width,float height,int color,float radius){if(color==0xE4041424)inCaption=true;canvas.rect(x,y,width,height,color,radius);}
        public void line(float x,float y,float xx,float yy,int color,float width){canvas.line(x,y,xx,yy,color,width);}
        public void text(String value,float x,float y,float size,int color,boolean bold){if(inCaption)captions.add(value);canvas.text(value,x,y,size,color,bold);}
        public float measure(String value,float size,boolean bold){return canvas.measure(value,size,bold);}
        public Object captionMeasurementKey(){return canvas.captionMeasurementKey();}
        public void clip(float x,float y,float width,float height){canvas.clip(x,y,width,height);}
        public void unclip(){canvas.unclip();}
    }
    private Duwm1728CaptionPages.Plan pages(RecordingCanvas painter,int width,int height,String text){
        float unit=Math.min(width,height)/1080f,available=Math.min(width-68*unit,width*(width>height?.73f:.88f))-32*unit;
        return Duwm1728CaptionPages.plan(painter,text,29*unit,true,available,2);
    }
    private JSONArray nativePages(Duwm1728OverlayRenderer.Spec spec)throws Exception {
        JSONArray facts=new JSONArray();Duwm1728BroadcastLayout.Cue cue=spec.renderedCaptions.get(0);long duration=cue.endMs-cue.startMs;
        for(int[] size:new int[][]{{720,800},{720,1280},{1280,720}}){
            Bitmap image=Bitmap.createBitmap(size[0],size[1],Bitmap.Config.ARGB_8888);
            try{
                Duwm1728CaptionPages.Plan plan=pages(new RecordingCanvas(image),size[0],size[1],cue.text);StringBuilder ranges=new StringBuilder(),visible=new StringBuilder();float panelTop=-1,panelHeight=-1;
                for(int page=0;page<plan.pageCount();page++){
                    Duwm1728CaptionPages.Page selected=plan.pages.get(page);ranges.append(cue.text,selected.startChar,selected.endChar);
                    long at=cue.startMs+plan.pageStartMs(page,duration);RecordingCanvas painter=new RecordingCanvas(image);
                    Duwm1728BroadcastLayout.Geometry geometry=Duwm1728BroadcastLayout.draw(painter,size[0],size[1],Duwm1728OverlayRenderer.reportAt(spec,at),at);
                    check(painter.captions.equals(selected.lines),"Actual Android Canvas issues every selected caption row");
                    check(geometry.captionTop>geometry.headerBottom&&geometry.captionBottom<geometry.tagTop,"Native caption panel remains inside safe frame");
                    if(panelTop<0){panelTop=geometry.captionTop;panelHeight=geometry.captionHeight;}
                    check(geometry.captionTop==panelTop&&geometry.captionHeight==panelHeight,"Native multi-page panel remains stable");
                    for(String row:selected.lines){visible.append(row.replace(" ",""));check(painter.measure(row,plan.textSize,true)<=geometry.captionWidth-32*geometry.unit+.02f,"Actual Android font measurement fits every visible row");}
                }
                check(ranges.toString().equals(cue.text)&&visible.toString().equals(cue.text.replace(" ","")),"Native pages retain every supplied character without generated ellipsis");
                facts.put(new JSONObject().put("width",size[0]).put("height",size[1]).put("pages",plan.pageCount())
                    .put("minimum_page_ms",plan.minimumPageDurationMs(duration)).put("code_points_per_second",plan.codePointsPerSecond(duration))
                    .put("human_readability_asserted",false));
            }finally{image.recycle();}
        }
        return facts;
    }
    private static boolean white(int pixel){return Color.red(pixel)>160&&Color.green(pixel)>160&&Color.blue(pixel)>160;}
    private double maskScore(Bitmap actual,Bitmap expected,Duwm1728BroadcastLayout.Geometry geometry){
        int left=Math.max(0,(int)geometry.captionLeft),right=Math.min(actual.getWidth(),(int)Math.ceil(geometry.captionLeft+geometry.captionWidth));
        int top=Math.max(0,(int)geometry.captionTop),bottom=Math.min(actual.getHeight(),(int)Math.ceil(geometry.captionBottom));
        int observed=0,wanted=0,both=0;
        for(int y=top;y<bottom;y++)for(int x=left;x<right;x++){
            boolean a=white(actual.getPixel(x,y)),e=white(expected.getPixel(x,y));if(a)observed++;if(e)wanted++;if(a&&e)both++;
        }
        check(observed>60&&wanted>60,"Decoded and expected caption regions both contain actual glyph pixels");
        return 2.0*both/(observed+wanted);
    }
    private JSONObject decodedPages(File video,Duwm1728OverlayRenderer.Spec spec,File folder)throws Exception {
        MediaMetadataRetriever reader=new MediaMetadataRetriever();Bitmap first=null,last=null,expectedFirst=null,expectedLast=null;
        try{
            reader.setDataSource(video.getAbsolutePath());int width=Integer.parseInt(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)),height=Integer.parseInt(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
            check(width==960&&height==540,"Finished automatic report retains the exact source picture dimensions");
            check(Math.abs(Long.parseLong(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION))-spec.toMs)<180,"Finished automatic report retains complete source duration");
            check("yes".equalsIgnoreCase(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)),"Finished automatic report contains original audio");
            expectedFirst=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);expectedLast=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
            Duwm1728BroadcastLayout.Cue cue=spec.renderedCaptions.get(0);long duration=cue.endMs-cue.startMs;
            Duwm1728CaptionPages.Plan plan=pages(new RecordingCanvas(expectedFirst),width,height,cue.text);check(plan.pageCount()>=2,"Native long-cue fixture exercises at least two encoded caption pages");
            long firstAt=cue.startMs+(plan.pageStartMs(0,duration)+plan.pageEndMs(0,duration))/2;
            int finalPage=plan.pageCount()-1;long lastAt=cue.startMs+(plan.pageStartMs(finalPage,duration)+plan.pageEndMs(finalPage,duration))/2;
            check(plan.minimumPageDurationMs(duration)>150,"Codec fixture leaves multiple video frames per sampled display page");
            Duwm1728BroadcastLayout.Geometry geometry=Duwm1728BroadcastLayout.draw(new RecordingCanvas(expectedFirst),width,height,Duwm1728OverlayRenderer.reportAt(spec,firstAt),firstAt);
            Duwm1728BroadcastLayout.draw(new RecordingCanvas(expectedLast),width,height,Duwm1728OverlayRenderer.reportAt(spec,lastAt),lastAt);
            first=reader.getFrameAtTime(firstAt*1000,MediaMetadataRetriever.OPTION_CLOSEST);last=reader.getFrameAtTime(lastAt*1000,MediaMetadataRetriever.OPTION_CLOSEST);
            check(first!=null&&last!=null,"Actual finished MP4 decodes frames from first and last caption pages");
            png(first,folder,"ANDROID-AUTO-REPORT-PAGE-1.png");png(last,folder,"ANDROID-AUTO-REPORT-PAGE-LAST.png");
            double firstCorrect=maskScore(first,expectedFirst,geometry),firstWrong=maskScore(first,expectedLast,geometry);
            double lastCorrect=maskScore(last,expectedLast,geometry),lastWrong=maskScore(last,expectedFirst,geometry);
            check(firstCorrect>.80&&lastCorrect>.80,"Decoded caption glyph masks match the actual Android renderer's expected pages: "+firstCorrect+", "+lastCorrect);
            check(firstCorrect>firstWrong+.08&&lastCorrect>lastWrong+.08,"Decoded pages distinguish first and last supplied text, not a static repeated caption");
            StringBuilder lastWords=new StringBuilder();for(String row:plan.pages.get(finalPage).lines){if(lastWords.length()>0)lastWords.append(' ');lastWords.append(row);}
            check(lastWords.toString().endsWith("at the end of the caption."),"Actual final page contains the formerly truncated source tail");
            return new JSONObject().put("width",width).put("height",height).put("pages",plan.pageCount()).put("first_frame_requested_ms",firstAt).put("last_frame_requested_ms",lastAt)
                .put("first_expected_rows",new JSONArray(plan.pages.get(0).lines)).put("last_expected_rows",new JSONArray(plan.pages.get(finalPage).lines))
                .put("first_correct_glyph_dice",firstCorrect).put("first_wrong_page_glyph_dice",firstWrong).put("last_correct_glyph_dice",lastCorrect).put("last_wrong_page_glyph_dice",lastWrong)
                .put("comparison","Binary white-glyph masks in caption panel; actual Android shared renderer compared to decoded MP4, not OCR")
                .put("minimum_page_ms",plan.minimumPageDurationMs(duration)).put("code_points_per_second",plan.codePointsPerSecond(duration)).put("human_readability_asserted",false);
        }finally{reader.release();if(first!=null)first.recycle();if(last!=null)last.recycle();if(expectedFirst!=null)expectedFirst.recycle();if(expectedLast!=null)expectedLast.recycle();}
    }
    private void tracks(File video)throws Exception {
        MediaExtractor extractor=new MediaExtractor();try{
            extractor.setDataSource(video.getAbsolutePath());boolean avc=false,aac=false;
            for(int index=0;index<extractor.getTrackCount();index++){
                MediaFormat format=extractor.getTrackFormat(index);String mime=format.getString(MediaFormat.KEY_MIME);
                if("video/avc".equals(mime))avc=true;
                if("audio/mp4a-latm".equals(mime)){aac=true;check(format.getInteger(MediaFormat.KEY_SAMPLE_RATE)==48000&&format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)==1,"Actual retained AAC track has original48 kHz mono format");}
            }
            check(avc&&aac,"Finished native file has actual AVC video and AAC audio tracks");
        }finally{extractor.release();}
    }
    private static boolean replaceCaptions(Activity editor,List<Duwm1728BroadcastLayout.Cue> cues)throws Exception{
        java.lang.reflect.Method method=editor.getClass().getDeclaredMethod("replaceAppliedCaptions",List.class,String.class);method.setAccessible(true);
        try{return (Boolean)method.invoke(editor,cues,"Reviewed synthetic replacement");}catch(InvocationTargetException failure){rethrow(failure);return false;}
    }
    private void draftRecovery(Instrumentation runner,Activity editor,Context target,String key,Duwm1728AutomaticProduction.Plan expected)throws Exception{
        proof.phase("automatic_report.corrupt_draft_protection");SharedPreferences preferences=target.getSharedPreferences("duwm_production_drafts",Context.MODE_PRIVATE);
        String valid=preferences.getString(key,"");check(!valid.isEmpty(),"Actual source has a persisted valid trimmed draft before corruption tests");
        for(String invalidField:new String[]{"automatic_tickers","automatic_headline_start_ms"}){
            JSONObject invalid=new JSONObject(valid);
            if("automatic_tickers".equals(invalidField))invalid.put(invalidField,"not a cue array");else invalid.put(invalidField,"137");
            String raw=invalid.toString();check(preferences.edit().putString(key,raw).commit(),"Seed only this fixture's corrupt "+invalidField);
            ui(runner,()->{
                call(editor,"loadDraft");call(editor,"refresh");
                check((Boolean)field(editor,"draftRestoreBlocked")&&!(Boolean)field(editor,"draftCaptionRecoveryAllowed"),"Corrupt report metadata blocks destructive caption-only recovery");
                ((CheckBox)field(editor,"approval")).setChecked(true);call(editor,"updateExportState");
                check(!((TextView)field(editor,"exportButton")).isEnabled(),"Corrupt report remains ineligible for export even with approval checked");
                boolean rejected=false;try{replaceCaptions(editor,supplied());}catch(IllegalArgumentException expectedError){rejected=true;}
                check(rejected,"Actual caption replacement refuses corrupt unrelated report metadata");
                check(!(Boolean)call(editor,"saveDraft"),"Partially decoded report cannot overwrite original persisted bytes");
                java.lang.reflect.Method export=editor.getClass().getDeclaredMethod("export",boolean.class);export.setAccessible(true);export.invoke(editor,false);
                check(!(Boolean)field(editor,"busy"),"Direct export path also rejects a blocked report");
            });
            check(raw.equals(preferences.getString(key,"")),"Rejected recovery keeps exact original corrupt-draft bytes");
            check(preferences.edit().putString(key,valid).commit(),"Restore this fixture's valid draft for next independent case");
            ui(runner,()->{call(editor,"loadDraft");call(editor,"refresh");check(!(Boolean)field(editor,"draftRestoreBlocked"),"Valid report restores after isolated corruption case");});
        }
        proof.phase("automatic_report.caption_only_draft_recovery");String badCaptions=new JSONObject(valid).put("automatic_captions","not a cue array").toString();
        check(preferences.edit().putString(key,badCaptions).commit(),"Seed only this fixture's invalid caption array");
        ui(runner,()->{
            call(editor,"loadDraft");call(editor,"refresh");
            check((Boolean)field(editor,"draftRestoreBlocked")&&(Boolean)field(editor,"draftCaptionRecoveryAllowed"),"Caption-only corruption permits explicit reviewed replacement after other report data restores");
            Duwm1728OverlayRenderer.Spec partial=(Duwm1728OverlayRenderer.Spec)field(editor,"previewSpec");
            check(partial.fromMs==300&&partial.toMs==1700&&expected.title.equals(partial.title)&&expected.description.equals(partial.description),"Bad captions do not discard valid title, summary or trim");
            sameCues(partial.automaticTickers,expected.tickers,"Bad captions preserve exact structured ticker document");
            check(NOTES.equals(field(editor,"captureNotes"))&&(Long)field(editor,"automaticHeadlineStart")==137&&(Long)field(editor,"automaticHeadlineEnd")==1567,"Bad captions retain capture notes and exact headline-source times");
            check(badCaptions.equals(preferences.getString(key,"")),"Caption-only load still preserves original invalid array until explicit replacement");
            check(replaceCaptions(editor,supplied()),"Actual explicit reviewed caption replacement repairs only invalid captions");
            check(!(Boolean)field(editor,"draftRestoreBlocked")&&!(Boolean)field(editor,"draftCaptionRecoveryAllowed")&&!((CheckBox)field(editor,"approval")).isChecked(),"Successful repair clears recovery state and old approval");
            Duwm1728OverlayRenderer.Spec repaired=(Duwm1728OverlayRenderer.Spec)field(editor,"previewSpec");sameCues(repaired.automaticCaptions,supplied(),"Repaired caption document exact words and times");sameCues(repaired.automaticTickers,expected.tickers,"Caption repair retains source ticker document");
            check(repaired.fromMs==300&&repaired.toMs==1700&&expected.title.equals(repaired.title)&&expected.description.equals(repaired.description),"Caption repair preserves independently restored report fields");
            call(editor,"loadDraft");call(editor,"refresh");Duwm1728OverlayRenderer.Spec durable=(Duwm1728OverlayRenderer.Spec)field(editor,"previewSpec");
            sameCues(durable.automaticCaptions,supplied(),"Repaired captions read back from actual saved draft");sameCues(durable.automaticTickers,expected.tickers,"Repaired saved draft retains exact source ticker times");
            check(!(Boolean)field(editor,"draftRestoreBlocked")&&durable.fromMs==300&&durable.toMs==1700,"Saved caption repair is valid and retains exact trim on reload");
        });
    }
    @SuppressWarnings("unchecked")
    void run(Instrumentation runner,File folder)throws Exception {
        Context target=runner.getTargetContext();File source=new File(target.getCacheDir(),"auto-report-"+UUID.randomUUID()+".mp4");
        Uri sourceUri=Uri.fromFile(source);String sourceKey=Duwm1728CaptureTelemetry.storageKey(sourceUri),receiptKey=Duwm1728AutomaticProduction.receiptKey(sourceKey);
        Set<Uri> ownedGallery=new LinkedHashSet<>();Set<String> ownedRecovery=new LinkedHashSet<>();Activity editor=null;JSONObject result=null;Throwable failure=null;
        proof.phase("automatic_report.fixture");try(InputStream input=runner.getContext().getAssets().open("framing_fixture.mp4");OutputStream output=new FileOutputStream(source)){copy(input,output);}
        String sourceHash=DuwmNativeEvidence.hash(source);
        try{
            proof.phase("automatic_report.supplied_transcript_seam");editor=open(runner,source);final Activity first=editor;
            AtomicReference<Long> duration=new AtomicReference<>();ui(runner,()->{
                duration.set((Long)field(first,"durationMs"));check(Math.abs(duration.get()-2000)<=80,"Independent source player identifies the two-second fixture");
                check(!(Boolean)field(first,"autoProducing")&&!(Boolean)field(first,"busy"),"Fixture is idle before explicit synthetic recognition-result seam");
                List<Duwm1728BroadcastLayout.Cue> cues=(List<Duwm1728BroadcastLayout.Cue>)field(first,"automaticCues");cues.clear();cues.addAll(supplied());
                set(first,"automaticCaptionStatus",CAPTION_STATUS);set(first,"autoProducing",true);call(first,"finishAutomaticPlan");
            });
            JSONObject receipt=awaitSaved(runner,first,target,receiptKey);Uri gallery=Uri.parse(receipt.getString("uri"));ownedGallery.add(gallery);
            check("content".equals(gallery.getScheme())&&"media".equals(gallery.getAuthority()),"Actual automatic report is published in Gallery");
            check(CAPTION_STATUS.equals(receipt.getString("caption_status")),"Receipt explicitly discloses the supplied synthetic transcript");
            Duwm1728AutomaticProduction.Plan expected=Duwm1728AutomaticProduction.plan(duration.get(),supplied(),CAPTION_STATUS,NOTES);
            AtomicReference<Duwm1728OverlayRenderer.Spec> selected=new AtomicReference<>();ui(runner,()->{
                Duwm1728OverlayRenderer.Spec spec=(Duwm1728OverlayRenderer.Spec)field(first,"previewSpec");selected.set(spec);
                check(spec.fromMs==0&&spec.toMs==duration.get()&&"ORIGINAL".equals(spec.ratio)&&"FIT".equals(spec.frameMode)&&"COMPACT".equals(spec.composition),"Real automatic plan retains full source and selected presentation defaults");
                check(expected.title.equals(spec.title)&&expected.description.equals(spec.description),"Actual headline and byline come from the shared production report plan");
                check("WEATHER".equals(spec.template)&&!spec.breakingApproved&&!spec.includeCoordinates,"Only explicit source category is retained, with no approval or precise-coordinate invention");
                check(!((CheckBox)field(first,"approval")).isChecked()&&"AUTO-CAPTIONS • UNREVIEWED".equals(spec.provenance),"Automatic report is never marked reviewed");
                sameCues(spec.automaticCaptions,supplied(),"Actual editor source captions");sameCues(spec.automaticTickers,expected.tickers,"Actual editor exact source ticker excerpts");
                check(spec.ticker.isEmpty(),"Structured millisecond excerpts are not serialized through the legacy whole-second ticker string");
                check("RECORDED_SPEECH".equals(field(first,"automaticContentSource"))&&NOTES.equals(field(first,"captureNotes")),"Editor retains report content origin and complete reporter-provided notes");
                check((Long)field(first,"automaticHeadlineStart")==137&&(Long)field(first,"automaticHeadlineEnd")==1567,"Editor retains exact headline source interval");
                TextView info=(TextView)field(first,"automaticReportInfo");check(info.getText().toString().contains("source-time ticker excerpts")&&info.getText().toString().contains("timed pages"),"Visible report explanation describes actual excerpts and caption pages");
            });
            screenshot(runner,first,folder);Duwm1728OverlayRenderer.Spec spec=selected.get();
            check(spec.renderedTickers.size()==2&&spec.renderedTickers.get(0).startMs==137&&spec.renderedTickers.get(0).endMs==1567&&spec.renderedTickers.get(1).startMs==1601,"Native production renderer retains subsecond ticker boundaries");
            check(Duwm1728BroadcastLayout.active(spec.renderedTickers,136)==null&&Duwm1728BroadcastLayout.active(spec.renderedTickers,137)!=null
                &&Duwm1728BroadcastLayout.active(spec.renderedTickers,1567)==null&&Duwm1728BroadcastLayout.active(spec.renderedTickers,1601)!=null,"Automatic ticker exact boundaries and source silence gap remain intact");
            byte[] sourceSrt=Duwm1728CaptionSrt.exportCues(supplied(),Duwm1728CaptionSrt.TimeBase.ORIGINAL,duration.get(),0,duration.get());
            check(Arrays.equals(sourceSrt,Duwm1728CaptionSrt.exportCues(spec.automaticCaptions,Duwm1728CaptionSrt.TimeBase.ORIGINAL,duration.get(),0,duration.get())),"Actual automatic editor leaves complete source SRT bytes unchanged");
            proof.phase("automatic_report.native_page_rendering");JSONArray pageFacts=nativePages(spec);
            File artifact=new File(folder,"ANDROID-AUTO-REPORT.mp4");try(InputStream input=target.getContentResolver().openInputStream(gallery);OutputStream output=new FileOutputStream(artifact)){check(input!=null,"Read the actual Gallery output");copy(input,output);}
            String outputHash=DuwmNativeEvidence.hash(artifact);List<Duwm1728ExportRecovery.Entry> entries=sourceReceipts(target,sourceUri);check(entries.size()==1,"One supplied transcript produced one actual export receipt");
            Duwm1728ExportRecovery.Entry entry=entries.get(0);ownedRecovery.add(entry.id);check(entry.state==Duwm1728ExportRecovery.State.PUBLISHED&&gallery.equals(entry.publishedUri)&&outputHash.equals(entry.sha256)&&artifact.length()==entry.bytes,"Durable publication receipt identifies the exact finished MP4 bytes");
            proof.phase("automatic_report.decoded_caption_pages");JSONObject decoded=decodedPages(artifact,spec,folder);tracks(artifact);
            finish(runner,first);editor=null;proof.phase("automatic_report.draft_reopen_and_trim");editor=open(runner,source);final Activity reopened=editor;
            ui(runner,()->{
                check(!(Boolean)field(reopened,"autoProducing")&&!(Boolean)field(reopened,"busy"),"Reopened completed report does not start another automatic export");
                Duwm1728OverlayRenderer.Spec restored=(Duwm1728OverlayRenderer.Spec)field(reopened,"previewSpec");sameCues(restored.automaticCaptions,supplied(),"Reopened source captions");sameCues(restored.automaticTickers,expected.tickers,"Reopened source ticker excerpts");
                check(expected.title.equals(restored.title)&&expected.description.equals(restored.description)&&NOTES.equals(field(reopened,"captureNotes")),"Draft reopening restores report content and original capture notes");
                set(reopened,"updatingFields",true);try{((EditText)field(reopened,"from")).setText("0.300");((EditText)field(reopened,"to")).setText("1.700");}finally{set(reopened,"updatingFields",false);}call(reopened,"refresh");
                Duwm1728OverlayRenderer.Spec trimmed=(Duwm1728OverlayRenderer.Spec)field(reopened,"previewSpec");sameCues(trimmed.automaticTickers,expected.tickers,"Trimming preserves original ticker document");sameCues(trimmed.automaticCaptions,supplied(),"Trimming preserves original caption document");
                check(trimmed.renderedTickers.size()==2&&trimmed.renderedTickers.get(0).startMs==0&&trimmed.renderedTickers.get(0).endMs==1267
                    &&trimmed.renderedTickers.get(1).startMs==1301&&trimmed.renderedTickers.get(1).endMs==1400,"Trim intersects and rebases precise ticker milliseconds without whole-second rounding");
                check((Boolean)call(reopened,"saveDraft"),"Save actual trimmed report draft");
            });
            finish(runner,reopened);editor=null;editor=open(runner,source);final Activity trimmedReopen=editor;
            ui(runner,()->{
                Duwm1728OverlayRenderer.Spec restored=(Duwm1728OverlayRenderer.Spec)field(trimmedReopen,"previewSpec");check(restored.fromMs==300&&restored.toMs==1700,"Second reopen retains exact trimmed bounds");sameCues(restored.automaticTickers,expected.tickers,"Second reopen retains original source ticker milliseconds");
            });
            draftRecovery(runner,trimmedReopen,target,sourceKey,expected);
            ui(runner,()->{
                ((EditText)field(trimmedReopen,"ticker")).setText("00:00=Explicit manual replacement");
                Duwm1728OverlayRenderer.Spec manual=(Duwm1728OverlayRenderer.Spec)field(trimmedReopen,"previewSpec");check(manual.automaticTickers.isEmpty()&&manual.renderedTickers.size()==1&&"Explicit manual replacement".equals(manual.renderedTickers.get(0).text),"An actual manual ticker edit explicitly replaces automatic excerpts");
                sameCues(manual.automaticCaptions,supplied(),"Manual ticker edit leaves all source caption words and times exact");
            });
            check(sourceHash.equals(DuwmNativeEvidence.hash(source)),"Automatic rendering, trimming and draft reopening preserve original MP4 bytes");
            check(sourceReceipts(target,sourceUri).size()==1,"Draft reopening and manual ticker replacement create no duplicate export");
            result=new JSONObject().put("status","PASS").put("run_id",proof.runId()).put("scope","SYNTHETIC_TRANSCRIPT_REAL_NATIVE_AUTOMATIC_REPORT_EDITOR_ENCODER_GALLERY")
                .put("transcript_supplied_by_test",true).put("recognition_callbacks_injected",false).put("recognition_result_boundary_seeded",true)
                .put("on_device_recognition_accuracy_verified",false).put("physical_camera_verified",false).put("source_sha256",sourceHash)
                .put("gallery_uri",gallery.toString()).put("output_sha256",outputHash).put("output_bytes",artifact.length()).put("caption_status",CAPTION_STATUS)
                .put("source_caption_count",supplied().size()).put("source_caption_words_and_times_exact",true).put("source_srt_bytes_unchanged",true)
                .put("source_ticker_millisecond_boundaries_exact",true).put("trim_rebase_and_reopen_verified",true).put("manual_ticker_replacement_verified",true)
                .put("corrupt_report_metadata_preserved_and_export_blocked",true).put("caption_only_recovery_retains_other_report_data",true)
                .put("automatic_export_not_reporter_approved",true).put("headline",expected.title).put("report_evidence",expected.sourceEvidence)
                .put("native_canvas_pages",pageFacts).put("decoded_mp4_pages",decoded).put("display_page_timing_is_derived",true).put("human_readability_asserted",false);
        }catch(Exception|Error error){failure=error;throw error;}
        finally{
            Throwable cleanup=null;try{finish(runner,editor);}catch(Exception|Error error){cleanup=error;}
            try{for(Duwm1728ExportRecovery.Entry entry:sourceReceipts(target,sourceUri)){ownedRecovery.add(entry.id);if(entry.publishedUri!=null)ownedGallery.add(entry.publishedUri);}}
                catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            for(Uri uri:ownedGallery)try{check(target.getContentResolver().delete(uri,null,null)==1,"Delete exactly this test-owned Gallery output");}catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            for(String id:ownedRecovery)try{Duwm1728ExportRecovery.discard(target,id);}catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            try{
                check(target.getSharedPreferences(Duwm1728AutomaticProduction.PREFS,Context.MODE_PRIVATE).edit().remove(receiptKey).commit(),"Remove only test source automatic receipt");
                check(target.getSharedPreferences("duwm_production_drafts",Context.MODE_PRIVATE).edit().remove(sourceKey).commit(),"Remove only test source draft");
                check(target.getSharedPreferences("duwm1728_saved_broadcasts",Context.MODE_PRIVATE).edit().remove(sourceKey).commit(),"Remove only test source last-output shortcut");
                SharedPreferences index=target.getSharedPreferences("duwm1726_gallery_exports",Context.MODE_PRIVATE);StringBuilder retained=new StringBuilder();
                for(String row:index.getString("items","").split("\n")){int separator=row.indexOf('\t');boolean own=false;if(separator>=0)for(Uri uri:ownedGallery)if(uri.toString().equals(row.substring(0,separator))){own=true;break;}
                    if(!row.isEmpty()&&!own){if(retained.length()>0)retained.append('\n');retained.append(row);}}
                check(index.edit().putString("items",retained.toString()).commit(),"Remove only test-owned Gallery index rows");
            }catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            if(source.exists()&&!source.delete()){IOException error=new IOException("Cannot remove owned automatic-report fixture");if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            if(cleanup!=null){if(failure!=null)failure.addSuppressed(cleanup);else rethrow(cleanup);}
        }
        check(result!=null,"Automatic report checks and owned-fixture cleanup completed");result.put("checks",checks).put("test_owned_gallery_and_receipt_cleanup_complete",true);
        try(OutputStream output=new FileOutputStream(new File(folder,"AUTO-REPORT-NATIVE.json"))){output.write(result.toString(2).getBytes(StandardCharsets.UTF_8));}
        proof.phase("automatic_report.complete");
    }
}
