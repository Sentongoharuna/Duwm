package com.sentongoharuna.worldsituationroom;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.*;

/** Real caption controls and export acceptance. Included only in the instrumentation APK. */
final class DuwmCaptionEditingChecks {
    private final DuwmNativeEvidence proof;
    private int checks;
    DuwmCaptionEditingChecks(DuwmNativeEvidence proof){this.proof=proof;}
    int count(){return checks;}
    private void check(boolean value,String why){checks++;if(!value)throw new AssertionError(why);}
    private interface Action{void run()throws Exception;}
    private void ui(Instrumentation runner,Action action)throws Exception{
        AtomicReference<Throwable> error=new AtomicReference<>();runner.runOnMainSync(()->{try{action.run();}catch(Throwable t){error.set(t);}});
        Throwable t=error.get();if(t instanceof Error)throw (Error)t;if(t instanceof Exception)throw (Exception)t;
    }
    private Object field(Object object,String name)throws Exception{java.lang.reflect.Field f=object.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(object);}
    private void set(Object object,String name,Object value)throws Exception{java.lang.reflect.Field f=object.getClass().getDeclaredField(name);f.setAccessible(true);f.set(object,value);}
    private void invoke(Object object,String name)throws Exception{java.lang.reflect.Method m=object.getClass().getDeclaredMethod(name);m.setAccessible(true);m.invoke(object);}
    private View tagged(Window window,String name){View v=window.getDecorView().findViewWithTag(name);check(v!=null,"Actual control exists: "+name);return v;}
    private void click(Instrumentation runner,Window window,String name)throws Exception{
        ui(runner,()->{if(window.getDecorView().findViewWithTag(name)==null&&name.matches("caption-edit-(row|edit|preview|delete)-[0-9]+")){
            View list=window.getDecorView().findViewWithTag("caption-edit-list");check(list instanceof ListView,"Caption list supports reaching offscreen rows");
            ((ListView)list).setSelection(Integer.parseInt(name.substring(name.lastIndexOf('-')+1)));}});runner.waitForIdleSync();
        ui(runner,()->{View v=tagged(window,name);v.requestRectangleOnScreen(new Rect(0,0,v.getWidth(),v.getHeight()),true);});runner.waitForIdleSync();
        ui(runner,()->{View v=tagged(window,name);check(v.isShown()&&v.isEnabled()&&v.getGlobalVisibleRect(new Rect()),"Control visible and reachable: "+name);check(v.performClick(),"Control responds: "+name);});runner.waitForIdleSync();
    }
    private void text(Instrumentation runner,Window window,String name,String value)throws Exception{ui(runner,()->((EditText)tagged(window,name)).setText(value));}
    private Dialog parent(Instrumentation runner,Activity activity)throws Exception{AtomicReference<Dialog> out=new AtomicReference<>();ui(runner,()->out.set((Dialog)field(activity,"captionEditor")));check(out.get()!=null,"Caption transaction exists");return out.get();}
    private AlertDialog child(Instrumentation runner,Dialog parent)throws Exception{AtomicReference<AlertDialog> out=new AtomicReference<>();ui(runner,()->out.set((AlertDialog)field(parent,"cueDialog")));check(out.get()!=null&&out.get().isShowing(),"Cue form is visible");return out.get();}
    private void capture(Instrumentation runner,File folder,String name)throws Exception{
        runner.waitForIdleSync();Bitmap b=runner.getUiAutomation().takeScreenshot();check(b!=null,"Actual screenshot available: "+name);
        try{png(b,folder,name);}finally{b.recycle();}proof.assertUnobstructed(name);
    }
    private void png(Bitmap b,File folder,String name)throws Exception{try(OutputStream out=new FileOutputStream(new File(folder,name+".png"))){check(b.compress(Bitmap.CompressFormat.PNG,100,out),"Write image: "+name);}}
    private Activity open(Instrumentation runner,File source)throws Exception{
        Activity a=runner.startActivitySync(new Intent(runner.getTargetContext(),Duwm1728VideoEditorActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(Duwm1728VideoEditorActivity.EXTRA_VIDEO_URI,Uri.fromFile(source).toString()).putExtra("broadcast_ratio","16:9"));
        AtomicBoolean ready=new AtomicBoolean();long until=android.os.SystemClock.elapsedRealtime()+15000;
        do{ui(runner,()->ready.set((Boolean)field(a,"prepared")));if(!ready.get())Thread.sleep(100);}while(!ready.get()&&android.os.SystemClock.elapsedRealtime()<until);
        check(ready.get(),"Actual source player prepared");return a;
    }
    private int position(Instrumentation runner,Activity a)throws Exception{AtomicInteger n=new AtomicInteger();ui(runner,()->n.set(((MediaPlayer)field(a,"player")).getCurrentPosition()));return n.get();}
    private void seek(Instrumentation runner,Activity a,long wanted)throws Exception{
        ui(runner,()->{java.lang.reflect.Method m=a.getClass().getDeclaredMethod("seekSource",long.class);m.setAccessible(true);m.invoke(a,wanted);});
        long until=android.os.SystemClock.elapsedRealtime()+5000;int n;
        do{Thread.sleep(60);n=position(runner,a);}while(Math.abs(n-wanted)>100&&android.os.SystemClock.elapsedRealtime()<until);
        check(Math.abs(n-wanted)<=100,"Native source seek completed at subsecond position");
    }
    @SuppressWarnings("unchecked") private List<Duwm1728BroadcastLayout.Cue> cues(Object a)throws Exception{return (List<Duwm1728BroadcastLayout.Cue>)field(a,"aiCaptions");}
    private void sameCue(Duwm1728BroadcastLayout.Cue c,long start,long end,String words){check(c.startMs==start&&c.endMs==end&&words.equals(c.text),"Preserve exact source cue "+start+"–"+end+": "+words);}
    private void verifyCommitted(Activity a)throws Exception{
        List<Duwm1728BroadcastLayout.Cue> c=cues(a);check(c.size()==3,"All original cues survive, including outside trim");
        sameCue(c.get(0),300,650,"CORRECTED CAPTION");sameCue(c.get(1),1000,1200,"UNCHANGED SECOND");sameCue(c.get(2),1600,1850,"OUTSIDE SELECTED TRIM");
        Duwm1728OverlayRenderer.Spec s=(Duwm1728OverlayRenderer.Spec)field(a,"previewSpec");
        check(s!=null&&s.fromMs==150&&s.toMs==1500,"Caption change retains exact selected trim");
        check("CAPTIONS".equals(s.composition)&&"FIT".equals(s.frameMode)&&"16:9".equals(s.ratio)&&s.frameX==.5f&&s.frameY==.5f,"Caption change retains composition and framing");
        check(!((CheckBox)field(a,"approval")).isChecked(),"Committed caption change requires fresh review approval");
        check(((EditText)field(a,"subtitles")).getText().length()==0,"Exact cues do not return through start-only legacy parser");
        check(s.automaticCaptions.size()==3&&s.renderedCaptions.size()==2,"Draft keeps outside cue while export clips to selected trim");
        sameCue(s.renderedCaptions.get(0),150,500,"CORRECTED CAPTION");sameCue(s.renderedCaptions.get(1),850,1050,"UNCHANGED SECOND");
        check(Duwm1728BroadcastLayout.active(s.renderedCaptions,500)==null,"Exact end excludes the first caption");
        check(Duwm1728BroadcastLayout.active(s.renderedCaptions,700)==null,"Silence gap remains after editing");
    }
    void run(Instrumentation runner,File folder)throws Exception{
        proof.phase("caption_editing.fixture");File source=new File(runner.getTargetContext().getCacheDir(),"caption-editing-"+System.nanoTime()+".mp4");
        try(InputStream in=runner.getContext().getAssets().open("framing_fixture.mp4");OutputStream out=new FileOutputStream(source)){copy(in,out);}
        String digest=hash(source);Activity activity=null;Duwm1728OverlayRenderer.Spec edited;
        try{
            activity=open(runner,source);final Activity a=activity;
            ui(runner,()->{
                check((Long)field(a,"durationMs")>=1850,"Fixture supports cues beyond selected trim");set(a,"updatingFields",true);
                try{((EditText)field(a,"title")).setText("CAPTION EDITOR NATIVE TEST");((EditText)field(a,"from")).setText("0.150");((EditText)field(a,"to")).setText("1.500");
                    set(a,"aiCaptions",new ArrayList<>(Arrays.asList(new Duwm1728BroadcastLayout.Cue(300,650,"ORIGINAL CAPTION"),new Duwm1728BroadcastLayout.Cue(1000,1200,"UNCHANGED SECOND"),new Duwm1728BroadcastLayout.Cue(1600,1850,"OUTSIDE SELECTED TRIM"))));
                    set(a,"captionKind","Imported SRT • native test fixture");set(a,"captionOriginMs",71L);set(a,"selectedComposition","CAPTIONS");
                }finally{set(a,"updatingFields",false);}invoke(a,"refresh");invoke(a,"saveDraft");((CheckBox)field(a,"approval")).setChecked(true);
            });
            proof.phase("caption_editing.cancel_and_validation");click(runner,a.getWindow(),"caption-editor-button");Dialog d=parent(runner,a);
            capture(runner,folder,"ANDROID-CAPTION-EDITOR");click(runner,d.getWindow(),"caption-edit-row-0");AlertDialog cue=child(runner,d);
            text(runner,cue.getWindow(),"caption-cue-text","CORRECTED CAPTION");text(runner,cue.getWindow(),"caption-cue-end","0.250");click(runner,cue.getWindow(),"caption-cue-save");
            check(cue.isShowing(),"Invalid reversed caption range keeps edit form open");
            ui(runner,()->sameCue(cues(a).get(0),300,650,"ORIGINAL CAPTION"));capture(runner,folder,"ANDROID-CAPTION-INVALID");
            text(runner,cue.getWindow(),"caption-cue-end","0.650");click(runner,cue.getWindow(),"caption-cue-save");
            click(runner,d.getWindow(),"caption-edit-cancel");
            ui(runner,()->{sameCue(cues(a).get(0),300,650,"ORIGINAL CAPTION");check(cues(a).size()==3,"Cancel preserves complete source set");
                check((Long)field(a,"captionOriginMs")==71L&&"Imported SRT • native test fixture".equals(field(a,"captionKind")),"Cancel preserves saved origin and provenance label");check(((CheckBox)field(a,"approval")).isChecked(),"Canceled edit does not invalidate an unchanged report");});
            proof.phase("caption_editing.edit_preview_return");seek(runner,a,637);click(runner,a.getWindow(),"caption-editor-button");d=parent(runner,a);
            click(runner,d.getWindow(),"caption-edit-row-0");cue=child(runner,d);text(runner,cue.getWindow(),"caption-cue-text","CORRECTED CAPTION");click(runner,cue.getWindow(),"caption-cue-save");
            click(runner,d.getWindow(),"caption-edit-preview-0");check(!d.isShowing(),"Source preview reveals actual video without committing transaction");
            ui(runner,()->{sameCue(cues(a).get(0),300,650,"ORIGINAL CAPTION");Duwm1728OverlayRenderer.Spec transientSpec=(Duwm1728OverlayRenderer.Spec)field(a,"captionPreviewSpec");
                check(transientSpec!=null&&transientSpec.fromMs==0&&transientSpec.toMs==(Long)field(a,"durationMs"),"Uncommitted source preview uses full source bounds");
                sameCue(transientSpec.automaticCaptions.get(0),300,650,"CORRECTED CAPTION");
                sameCue(((Duwm1728OverlayRenderer.Spec)field(a,"previewSpec")).automaticCaptions.get(0),300,650,"ORIGINAL CAPTION");});
            click(runner,a.getWindow(),"caption-editor-button");check(parent(runner,a)==d&&d.isShowing(),"Return resumes the same working transaction");
            ui(runner,()->check(field(a,"captionPreviewSpec")==null,"Return removes transient preview without committing it"));
            click(runner,d.getWindow(),"caption-edit-preview-2");
            long previewDeadline=android.os.SystemClock.elapsedRealtime()+5000;int outsidePosition;
            do{Thread.sleep(60);outsidePosition=position(runner,a);}while(Math.abs(outsidePosition-1600)>100&&android.os.SystemClock.elapsedRealtime()<previewDeadline);
            check(Math.abs(outsidePosition-1600)<=100,"Source preview reaches a retained caption beyond selected trim");
            ui(runner,()->{Duwm1728OverlayRenderer.Spec committed=(Duwm1728OverlayRenderer.Spec)field(a,"previewSpec");check(committed.fromMs==150&&committed.toMs==1500,"Out-of-trim preview cannot rewrite the selected export range");});
            click(runner,a.getWindow(),"caption-editor-button");check(parent(runner,a)==d,"Out-of-trim source preview retains same transaction");
            proof.phase("caption_editing.add_mark_delete");seek(runner,a,637);int at=position(runner,a);click(runner,d.getWindow(),"caption-edit-add");cue=child(runner,d);
            final AlertDialog marks=cue;click(runner,cue.getWindow(),"caption-cue-mark-start");click(runner,cue.getWindow(),"caption-cue-mark-end");
            ui(runner,()->{long start=Duwm1728CaptionEditPolicy.parseTime(((EditText)tagged(marks.getWindow(),"caption-cue-start")).getText().toString());long end=Duwm1728CaptionEditPolicy.parseTime(((EditText)tagged(marks.getWindow(),"caption-cue-end")).getText().toString());check(Math.abs(start-at)<=50&&Math.abs(end-at)<=50,"Both marks preserve actual subsecond source position");});
            text(runner,cue.getWindow(),"caption-cue-start","0.700");text(runner,cue.getWindow(),"caption-cue-end","0.850");text(runner,cue.getWindow(),"caption-cue-text","TEMPORARY ADDED CUE");click(runner,cue.getWindow(),"caption-cue-save");
            click(runner,d.getWindow(),"caption-edit-row-1");cue=child(runner,d);click(runner,cue.getWindow(),"caption-cue-delete");
            ui(runner,()->check(cues(a).size()==3,"Add and delete remain in working copy before Apply"));
            proof.phase("caption_editing.apply");click(runner,d.getWindow(),"caption-edit-apply");ui(runner,()->verifyCommitted(a));capture(runner,folder,"ANDROID-CAPTION-APPLIED");
            AtomicReference<Duwm1728OverlayRenderer.Spec> selected=new AtomicReference<>();ui(runner,()->selected.set((Duwm1728OverlayRenderer.Spec)field(a,"previewSpec")));edited=selected.get();
            ui(runner,a::finish);runner.waitForIdleSync();activity=null;
            proof.phase("caption_editing.reopen");activity=open(runner,source);final Activity restored=activity;ui(runner,()->verifyCommitted(restored));click(runner,restored.getWindow(),"caption-editor-button");
            capture(runner,folder,"ANDROID-CAPTION-RESTORED");Dialog reopenedDialog=parent(runner,restored);
            click(runner,reopenedDialog.getWindow(),"caption-edit-preview-2");
            long closePreviewDeadline=android.os.SystemClock.elapsedRealtime()+5000;int closingPosition;
            do{Thread.sleep(60);closingPosition=position(runner,restored);}while(Math.abs(closingPosition-1600)>100&&android.os.SystemClock.elapsedRealtime()<closePreviewDeadline);
            check(Math.abs(closingPosition-1600)<=100,"Restored draft can preview its retained outside-trim cue");
            click(runner,restored.getWindow(),"caption-editor-button");click(runner,reopenedDialog.getWindow(),"caption-edit-cancel");
            long closeDeadline=android.os.SystemClock.elapsedRealtime()+5000;
            do{Thread.sleep(60);closingPosition=position(runner,restored);}while((closingPosition<150||closingPosition>=1500)&&android.os.SystemClock.elapsedRealtime()<closeDeadline);
            check(closingPosition>=150&&closingPosition<1500,"Closing full-source caption preview restores actual player within selected trim");
            ui(runner,()->{verifyCommitted(restored);check(field(restored,"captionPreviewSpec")==null&&field(restored,"captionEditor")==null,"Cancel clears only the temporary transaction and preview");});
            ui(runner,restored::finish);runner.waitForIdleSync();activity=null;
            export(runner,source,edited,folder);check(digest.equals(hash(source)),"Actual editing and export preserve recording bytes");
            org.json.JSONObject record=new org.json.JSONObject().put("status","PASS").put("scope","SYNTHETIC_NATIVE_CAPTION_UI_AND_EDITED_SPEC_ENCODER")
                .put("source_sha256",digest).put("exact_cues_retained",3).put("rendered_cues_within_trim",2).put("trim_start_ms",150).put("trim_end_ms",1500)
                .put("invalid_edit_rejected",true).put("cancel_is_lossless",true).put("preview_returns_same_transaction",true).put("playhead_marks",true)
                .put("draft_reopened",true).put("physical_camera_verified",false);
            try(OutputStream out=new FileOutputStream(new File(folder,"CAPTION-EDITING-NATIVE.json"))){out.write(record.toString(2).getBytes("UTF-8"));}proof.phase("caption_editing.complete");
        }finally{if(activity!=null){final Activity closing=activity;ui(runner,closing::finish);runner.waitForIdleSync();}source.delete();}
    }
    private void export(Instrumentation runner,File source,Duwm1728OverlayRenderer.Spec spec,File folder)throws Exception{
        proof.phase("caption_editing.encode_current_spec");check(spec!=null&&spec.automaticCaptions.get(0).text.equals("CORRECTED CAPTION"),"Encoder uses specification actually produced by caption editor");
        File rendered=Duwm1728OverlayRenderer.export(runner.getTargetContext(),Uri.fromFile(source),spec);File output=new File(folder,"ANDROID-CAPTION-EDITED.mp4");
        try(InputStream in=new FileInputStream(rendered);OutputStream out=new FileOutputStream(output)){copy(in,out);}finally{rendered.delete();}
        proof.phase("caption_editing.decode_and_audio");MediaMetadataRetriever reader=new MediaMetadataRetriever();Bitmap before=null,active=null,gap=null,canvas=Bitmap.createBitmap(960,540,Bitmap.Config.ARGB_8888);
        try{reader.setDataSource(output.getAbsolutePath());check("960".equals(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH))&&"540".equals(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)),"Edited output preserves exact dimensions");
            check(Math.abs(Long.parseLong(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION))-1350)<180,"Edited output preserves selected trim duration");
            before=reader.getFrameAtTime(50000,MediaMetadataRetriever.OPTION_CLOSEST);active=reader.getFrameAtTime(300000,MediaMetadataRetriever.OPTION_CLOSEST);gap=reader.getFrameAtTime(650000,MediaMetadataRetriever.OPTION_CLOSEST);
            check(before!=null&&active!=null&&gap!=null,"Decode edited MP4 before, during and after first cue");png(active,folder,"ANDROID-CAPTION-DECODED");
            Duwm1728BroadcastLayout.Geometry g=Duwm1728BroadcastLayout.draw(new Duwm1728BroadcastCanvas(new Canvas(canvas)),960,540,Duwm1728OverlayRenderer.reportAt(spec,300),300);
            int x=Math.round(g.captionLeft+12*g.unit),y=Math.round(g.captionTop+7*g.unit);
            colour(before,x,y,0xFFC91010,"Caption absent before exact source start");colour(active,x,y,0xFF041424,"Edited caption panel is encoded while active");colour(gap,x,y,0xFFC91010,"Encoded gap remains after exact caption end");
        }finally{reader.release();canvas.recycle();if(before!=null)before.recycle();if(active!=null)active.recycle();if(gap!=null)gap.recycle();}
        MediaExtractor extractor=new MediaExtractor();try{extractor.setDataSource(output.getAbsolutePath());boolean audio=false;
            for(int i=0;i<extractor.getTrackCount();i++){MediaFormat f=extractor.getTrackFormat(i);if("audio/mp4a-latm".equals(f.getString(MediaFormat.KEY_MIME))){audio=true;check(f.getInteger(MediaFormat.KEY_SAMPLE_RATE)==48000&&f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)==1,"Edited output retains original AAC sample rate and channels");}}
            check(audio,"Edited output contains an actual AAC track");
        }finally{extractor.release();}
    }
    private void colour(Bitmap b,int x,int y,int wanted,String message){int c=b.getPixel(x,y);check(Math.abs(Color.red(c)-Color.red(wanted))<45&&Math.abs(Color.green(c)-Color.green(wanted))<45&&Math.abs(Color.blue(c)-Color.blue(wanted))<45,message);}
    private static void copy(InputStream in,OutputStream out)throws IOException{byte[] data=new byte[65536];int n;while((n=in.read(data))!=-1)out.write(data,0,n);}
    private static String hash(File path)throws Exception{java.security.MessageDigest d=java.security.MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(path)){byte[] data=new byte[65536];int n;while((n=in.read(data))!=-1)d.update(data,0,n);}StringBuilder s=new StringBuilder();for(byte b:d.digest())s.append(String.format(Locale.US,"%02x",b&255));return s.toString();}
}
