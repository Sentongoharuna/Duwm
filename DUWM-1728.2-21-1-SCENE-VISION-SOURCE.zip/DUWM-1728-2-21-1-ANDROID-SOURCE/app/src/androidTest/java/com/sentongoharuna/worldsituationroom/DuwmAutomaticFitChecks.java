package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.RectF;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.SystemClock;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import org.json.JSONArray;
import org.json.JSONObject;

/** Synthetic supplied source words, a real portrait source, and the actual
 * editor -> encoder -> Gallery path. Capability fallback is not forced, speech
 * recognition is not simulated, and no physical-camera claim is made. */
final class DuwmAutomaticFitChecks {
    private static final String WORDS="WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW TAIL";
    private static final String NOTES="Synthetic portrait headline fixture; no event or source speech inferred.";
    private static final String CAPTION_STATUS="SYNTHETIC PORTRAIT HEADLINE TRANSCRIPT • no recognition callback or accuracy claim";
    private final DuwmNativeEvidence proof;private int checks;
    DuwmAutomaticFitChecks(DuwmNativeEvidence proof){this.proof=proof;}
    int count(){return checks;}
    private void check(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
    private interface Action {void run()throws Exception;}
    private interface Condition {boolean ready()throws Exception;}
    private static void rethrow(Throwable error)throws Exception {
        if(error instanceof InvocationTargetException){rethrow(((InvocationTargetException)error).getTargetException());return;}
        if(error instanceof Error)throw (Error)error;if(error instanceof Exception)throw (Exception)error;if(error!=null)throw new RuntimeException(error);
    }
    private void ui(Instrumentation runner,Action action)throws Exception {AtomicReference<Throwable> error=new AtomicReference<>();runner.runOnMainSync(()->{try{action.run();}catch(Throwable failure){error.set(failure);}});rethrow(error.get());}
    private static Object field(Object object,String name)throws Exception {java.lang.reflect.Field f=object.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(object);}
    private static void set(Object object,String name,Object value)throws Exception {java.lang.reflect.Field f=object.getClass().getDeclaredField(name);f.setAccessible(true);f.set(object,value);}
    private static Object call(Object object,String name)throws Exception {java.lang.reflect.Method method=object.getClass().getDeclaredMethod(name);method.setAccessible(true);try{return method.invoke(object);}catch(InvocationTargetException failure){rethrow(failure);return null;}}
    private void await(Instrumentation runner,Condition condition,long timeout,String label)throws Exception {
        AtomicBoolean ready=new AtomicBoolean();long deadline=SystemClock.elapsedRealtime()+timeout;
        do{ui(runner,()->ready.set(condition.ready()));if(ready.get())break;Thread.sleep(75);}while(SystemClock.elapsedRealtime()<deadline);check(ready.get(),label);
    }
    private Activity open(Instrumentation runner,File source)throws Exception {
        Activity editor=runner.startActivitySync(new Intent(runner.getTargetContext(),Duwm1728VideoEditorActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(Duwm1728VideoEditorActivity.EXTRA_VIDEO_URI,Uri.fromFile(source).toString()).putExtra("notes",NOTES).putExtra("report_category","WEATHER"));
        await(runner,()->(Boolean)field(editor,"prepared"),15000,"Actual portrait source editor prepared");return editor;
    }
    private void finish(Instrumentation runner,Activity editor)throws Exception {if(editor==null)return;ui(runner,editor::finish);await(runner,editor::isDestroyed,15000,"Test-owned editor destroyed before reopen or cleanup");}
    private static void copy(InputStream input,OutputStream output)throws IOException {byte[] bytes=new byte[65536];int count;while((count=input.read(bytes))!=-1)output.write(bytes,0,count);}
    private static List<Duwm1728BroadcastLayout.Cue> supplied(){return Arrays.asList(new Duwm1728BroadcastLayout.Cue(137,1937,WORDS));}
    private void sameCues(List<Duwm1728BroadcastLayout.Cue> actual,List<Duwm1728BroadcastLayout.Cue> expected,String label){check(actual.size()==expected.size(),label+" count");for(int i=0;i<actual.size();i++){Duwm1728BroadcastLayout.Cue a=actual.get(i),b=expected.get(i);check(a.startMs==b.startMs&&a.endMs==b.endMs&&a.text.equals(b.text),label+" exact source words/times");}}
    private List<Duwm1728ExportRecovery.Entry> sourceReceipts(Context context,Uri source)throws Exception {ArrayList<Duwm1728ExportRecovery.Entry> result=new ArrayList<>();for(Duwm1728ExportRecovery.Entry entry:Duwm1728ExportRecovery.list(context))if(source.equals(entry.sourceUri))result.add(entry);return result;}
    private JSONObject awaitSaved(Instrumentation runner,Activity editor,Context target,String key)throws Exception {
        AtomicReference<String> state=new AtomicReference<>("");long deadline=SystemClock.elapsedRealtime()+120000;
        do{
            String raw=target.getSharedPreferences(Duwm1728AutomaticProduction.PREFS,Context.MODE_PRIVATE).getString(key,"");JSONObject receipt=raw.isEmpty()?null:new JSONObject(raw);
            if(receipt!=null&&"SAVED_WITH_CAPTIONS".equals(receipt.optString("state"))){await(runner,()->!(Boolean)field(editor,"autoProducing")&&!(Boolean)field(editor,"busy")&&field(editor,"lastBroadcast")!=null,15000,"Actual editor finishes the automatic portrait output");return receipt;}
            ui(runner,()->state.set((String)field(editor,"automaticStatus")));check(!"FAILED".equals(state.get())&&!"CANCELLED".equals(state.get())&&!"INTERRUPTED".equals(state.get()),"Automatic portrait output succeeds: "+state.get());Thread.sleep(100);
        }while(SystemClock.elapsedRealtime()<deadline);throw new AssertionError("Automatic-fit fixture did not publish within120 seconds: "+state.get());
    }
    private static final class Drawn {
        final String text;final float x,y,size,width;final RectF clip;
        Drawn(String text,float x,float y,float size,float width,RectF clip){this.text=text;this.x=x;this.y=y;this.size=size;this.width=width;this.clip=clip;}
    }
    private static final class RecordingCanvas implements Duwm1728BroadcastLayout.Painter {
        final Duwm1728BroadcastCanvas canvas;final Duwm1728BroadcastLayout.Geometry geometry;final List<Drawn> headlines=new ArrayList<>(),bylines=new ArrayList<>();final Deque<RectF> clips=new ArrayDeque<>();
        RecordingCanvas(Bitmap image,String composition){canvas=new Duwm1728BroadcastCanvas(new Canvas(image));geometry=new Duwm1728BroadcastLayout.Geometry(image.getWidth(),image.getHeight(),false,composition,0);}
        public void rect(float x,float y,float w,float h,int c,float radius){canvas.rect(x,y,w,h,c,radius);}
        public void line(float x,float y,float xx,float yy,int c,float stroke){canvas.line(x,y,xx,yy,c,stroke);}
        public void text(String text,float x,float y,float size,int color,boolean bold){
            if(y>=geometry.headlineTop&&y<geometry.headlineTop+geometry.headlineHeight&&!clips.isEmpty()){
                Drawn row=new Drawn(text,x,y,size,measure(text,size,bold),new RectF(clips.peek()));if(bold&&color==Duwm1728BroadcastLayout.WHITE)headlines.add(row);else if(!bold&&color==Duwm1728BroadcastLayout.SILVER)bylines.add(row);
            }canvas.text(text,x,y,size,color,bold);
        }
        public float measure(String text,float size,boolean bold){return canvas.measure(text,size,bold);}
        public Object captionMeasurementKey(){return canvas.captionMeasurementKey();}
        public void clip(float x,float y,float w,float h){RectF next=new RectF(x,y,x+w,y+h);if(!clips.isEmpty())next.intersect(clips.peek());clips.push(next);canvas.clip(x,y,w,h);}
        public void unclip(){clips.pop();canvas.unclip();}
    }
    private void assertRows(RecordingCanvas draw,String title,boolean portrait){
        check(!draw.headlines.isEmpty()&&draw.headlines.size()<=2,"Native headline uses at most two complete static rows");StringBuilder text=new StringBuilder();float left=draw.geometry.x+22*draw.geometry.unit,available=draw.geometry.width-44*draw.geometry.unit;
        for(Drawn row:draw.headlines){text.append(row.text.replace(" ",""));check(Math.abs(row.x-left)<.02f&&row.width<=available+.02f,"Actual Android font metrics fit the entire selected row in its existing viewport");}
        check(text.toString().equals(title.replace(" ","")),"Native rows retain every selected headline character including TAIL");
        if(portrait){check(draw.headlines.size()==2,"Portrait source exercises the repaired two-row layout");check(draw.headlines.get(1).text.endsWith("TAIL"),"Last native headline row contains the selected source tail");
            for(Drawn row:draw.headlines)check(row.clip.bottom<=draw.geometry.headlineTop+57*draw.geometry.unit+.02f,"Headline stays in its separate upper band");
            check(draw.bylines.size()==1&&draw.bylines.get(0).clip.top>=draw.geometry.headlineTop+59*draw.geometry.unit-.02f,"Byline remains in its separate lower band without overlap");}
    }
    private JSONArray nativeRows(Duwm1728OverlayRenderer.Spec spec){
        JSONArray facts=new JSONArray();for(int[] size:new int[][]{{720,800},{720,1280},{1280,720},{1920,1080},{1080,1920},{1072,1920},{540,960}}){Bitmap image=Bitmap.createBitmap(size[0],size[1],Bitmap.Config.ARGB_8888);
            try{RecordingCanvas draw=new RecordingCanvas(image,spec.composition);Duwm1728BroadcastLayout.draw(draw,size[0],size[1],Duwm1728OverlayRenderer.reportAt(spec,1000),1000);assertRows(draw,spec.title,size[1]>size[0]);JSONArray rows=new JSONArray();for(Drawn row:draw.headlines)rows.put(row.text);
                facts.put(new JSONObject().put("width",size[0]).put("height",size[1]).put("rows",rows).put("text_size_pixels",draw.headlines.get(0).size));
            }catch(org.json.JSONException error){throw new RuntimeException(error);}finally{image.recycle();}}
        return facts;
    }
    private static boolean white(int pixel){return Color.red(pixel)>160&&Color.green(pixel)>160&&Color.blue(pixel)>160;}
    private double maskScore(Bitmap actual,Bitmap expected,RectF region,int minimum){
        int left=Math.max(0,(int)Math.ceil(region.left)),right=Math.min(actual.getWidth(),(int)Math.floor(region.right)),top=Math.max(0,(int)Math.ceil(region.top)),bottom=Math.min(actual.getHeight(),(int)Math.floor(region.bottom));
        int observed=0,wanted=0,both=0;for(int y=top;y<bottom;y++)for(int x=left;x<right;x++){boolean a=white(actual.getPixel(x,y)),e=white(expected.getPixel(x,y));if(a)observed++;if(e)wanted++;if(a&&e)both++;}
        check(observed>minimum&&wanted>minimum,"Decoded and expected headline regions both contain actual glyph pixels");return 2.0*both/(observed+wanted);
    }
    private JSONObject decodedHeadline(File video,Duwm1728OverlayRenderer.Spec spec,Duwm1728ExportPreflight.Result plan,File folder)throws Exception {
        MediaMetadataRetriever reader=new MediaMetadataRetriever();Bitmap frame=null,expected=null,legacy=null;
        try{
            reader.setDataSource(video.getAbsolutePath());int width=Integer.parseInt(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)),height=Integer.parseInt(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
            check(width==plan.width&&height==plan.height,"Actual encoded dimensions match the device-selected automatic output plan");check(width<=plan.requestedWidth&&height<=plan.requestedHeight&&height>width,"Portrait output remains bounded by the original upright source");
            check(Math.abs(Long.parseLong(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION))-(spec.toMs-spec.fromMs))<180,"Finished video retains the complete source duration");check("yes".equalsIgnoreCase(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)),"Finished video contains the original AAC soundtrack");
            frame=reader.getFrameAtTime(1000000,MediaMetadataRetriever.OPTION_CLOSEST);check(frame!=null&&frame.getWidth()==width&&frame.getHeight()==height,"Actual published MP4 decodes a full-size portrait frame");
            expected=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);legacy=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);RecordingCanvas draw=new RecordingCanvas(expected,spec.composition),old=new RecordingCanvas(legacy,spec.composition);
            Duwm1728BroadcastLayout.Report report=Duwm1728OverlayRenderer.reportAt(spec,1000);check(report.automaticHeadlineFit,"Real editor flag propagates into the shared export report");Duwm1728BroadcastLayout.draw(draw,width,height,report,1000);assertRows(draw,spec.title,true);
            report.automaticHeadlineFit=false;Duwm1728BroadcastLayout.draw(old,width,height,report,1000);check(old.headlines.size()==1&&!old.headlines.get(0).text.equals(spec.title),"Disabled flag reproduces inherited portrait headline truncation");
            float u=draw.geometry.unit;RectF area=new RectF(draw.geometry.x+22*u,draw.geometry.headlineTop+2*u,draw.geometry.x+draw.geometry.width-22*u,draw.geometry.headlineTop+57*u);
            double correct=maskScore(frame,expected,area,30),wrong=maskScore(frame,legacy,area,30);check(correct>.70&&correct>wrong+.12,"Decoded headline glyphs match complete new layout and differ from inherited truncation: "+correct+" / "+wrong);
            Drawn last=draw.headlines.get(draw.headlines.size()-1);String prefix=last.text.substring(0,last.text.length()-4);float tailLeft=last.x+draw.measure(prefix,last.size,true);
            RectF tail=new RectF(tailLeft-1,last.y-last.size*1.1f,last.x+last.width+1,last.y+last.size*.3f);double tailScore=maskScore(frame,expected,tail,8);check(tailScore>.60,"Actual decoded MP4 retains final TAIL glyphs rather than only leading source words");
            try(OutputStream output=new FileOutputStream(new File(folder,"ANDROID-AUTO-FIT-HEADLINE.png"))){check(frame.compress(Bitmap.CompressFormat.PNG,100,output),"Save actual decoded portrait headline frame");}
            return new JSONObject().put("width",width).put("height",height).put("frame_requested_ms",1000).put("selected_title",spec.title).put("first_row",draw.headlines.get(0).text).put("last_row",last.text)
                .put("correct_glyph_dice",correct).put("inherited_layout_glyph_dice",wrong).put("tail_glyph_dice",tailScore).put("comparison","Actual Android shared-renderer white glyph masks against decoded MP4, including final TAIL; not OCR");
        }finally{reader.release();if(frame!=null)frame.recycle();if(expected!=null)expected.recycle();if(legacy!=null)legacy.recycle();}
    }
    private void tracks(File video)throws Exception {
        MediaExtractor extractor=new MediaExtractor();try{extractor.setDataSource(video.getAbsolutePath());boolean avc=false,aac=false;
            for(int i=0;i<extractor.getTrackCount();i++){MediaFormat format=extractor.getTrackFormat(i);String mime=format.getString(MediaFormat.KEY_MIME);if("video/avc".equals(mime))avc=true;
                if("audio/mp4a-latm".equals(mime)){aac=true;check(format.getInteger(MediaFormat.KEY_SAMPLE_RATE)==48000&&format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)==1,"Original48 kHz mono AAC format retained");}}
            check(avc&&aac,"Published automatic-fit file has real AVC video and AAC audio");
        }finally{extractor.release();}
    }
    private void draftProtection(Instrumentation runner,Activity editor,Context context,String key)throws Exception {
        proof.phase("automatic_fit.strict_draft_flags");SharedPreferences preferences=context.getSharedPreferences("duwm_production_drafts",Context.MODE_PRIVATE);String valid=preferences.getString(key,"");check(!valid.isEmpty(),"Actual automatic plan has a persisted draft");
        List<JSONObject> invalids=new ArrayList<>();for(String flag:new String[]{"automatic_headline_fit","automatic_output_sizing"}){
            invalids.add(new JSONObject(valid).put(flag,"true"));invalids.add(new JSONObject(valid).put(flag,JSONObject.NULL));}
        invalids.add(new JSONObject(valid).put("automatic_output_sizing",true).put("ratio","9:16"));invalids.add(new JSONObject(valid).put("automatic_output_sizing",true).put("frame_mode","FILL"));
        invalids.add(new JSONObject(valid).put("automatic_output_sizing",true).put("ratio","ORIGINAL").put("frame_mode","FIT").put("frame_x",2));
        invalids.add(new JSONObject(valid).put("automatic_output_sizing",true).put("ratio","ORIGINAL").put("frame_mode","FIT").put("frame_y","NaN"));
        for(JSONObject invalid:invalids){String raw=invalid.toString();check(preferences.edit().putString(key,raw).commit(),"Seed only fixture-owned malformed automatic metadata");
            ui(runner,()->{call(editor,"loadDraft");call(editor,"refresh");check((Boolean)field(editor,"draftRestoreBlocked")&&!(Boolean)field(editor,"draftCaptionRecoveryAllowed"),"Malformed flags or contradictory automatic framing block partial restore and caption-only recovery");
                ((CheckBox)field(editor,"approval")).setChecked(true);call(editor,"updateExportState");check(!((TextView)field(editor,"exportButton")).isEnabled(),"Malformed automatic metadata remains ineligible for export");
                check(!(Boolean)call(editor,"saveDraft"),"Malformed automatic draft cannot be silently overwritten");java.lang.reflect.Method export=editor.getClass().getDeclaredMethod("export",boolean.class);export.setAccessible(true);export.invoke(editor,false);check(!(Boolean)field(editor,"busy"),"Direct export also rejects blocked automatic metadata");});
            check(raw.equals(preferences.getString(key,"")),"Malformed-draft bytes remain exact after rejected save/export");check(preferences.edit().putString(key,valid).commit(),"Restore fixture-owned valid draft");
            ui(runner,()->{call(editor,"loadDraft");call(editor,"refresh");check(!(Boolean)field(editor,"draftRestoreBlocked")&&(Boolean)field(editor,"automaticHeadlineFit")&&(Boolean)field(editor,"automaticOutputSizing"),"Valid automatic flags restore after an isolated invalid case");});
        }
        JSONObject old=new JSONObject(valid);old.remove("automatic_headline_fit");old.remove("automatic_output_sizing");check(preferences.edit().putString(key,old.toString()).commit(),"Seed only fixture-owned older draft without new flags");
        ui(runner,()->{call(editor,"loadDraft");call(editor,"refresh");Duwm1728OverlayRenderer.Spec restored=(Duwm1728OverlayRenderer.Spec)field(editor,"previewSpec");check(!(Boolean)field(editor,"draftRestoreBlocked")&&!restored.automaticHeadlineFit&&!restored.automaticOutputSizing,"Old drafts restore their legacy manual defaults without acquiring automatic behavior");});
        check(preferences.edit().putString(key,valid).commit(),"Restore valid fixture after older-draft check");ui(runner,()->{call(editor,"loadDraft");call(editor,"refresh");});
    }
    @SuppressWarnings("unchecked")
    void run(Instrumentation runner,File folder)throws Exception {
        Context target=runner.getTargetContext();File source=new File(target.getCacheDir(),"auto-fit-"+UUID.randomUUID()+".mp4");Uri sourceUri=Uri.fromFile(source);String sourceKey=Duwm1728CaptureTelemetry.storageKey(sourceUri),receiptKey=Duwm1728AutomaticProduction.receiptKey(sourceKey);
        Set<Uri> galleryOwned=new LinkedHashSet<>();Set<String> recoveryOwned=new LinkedHashSet<>();Activity editor=null;JSONObject result=null;Throwable failure=null;
        proof.phase("automatic_fit.portrait_fixture");try(InputStream input=runner.getContext().getAssets().open("automatic_fit_fixture.mp4");OutputStream output=new FileOutputStream(source)){copy(input,output);}String sourceHash=DuwmNativeEvidence.hash(source);
        try{
            proof.phase("automatic_fit.supplied_transcript_seam");editor=open(runner,source);final Activity first=editor;AtomicReference<Long> duration=new AtomicReference<>();
            ui(runner,()->{duration.set((Long)field(first,"durationMs"));check(Math.abs(duration.get()-2000)<=80&&(Integer)field(first,"sourceW")==540&&(Integer)field(first,"sourceH")==960,"Real portrait fixture is two seconds with540×960 upright picture");check(!(Boolean)field(first,"autoProducing")&&!(Boolean)field(first,"busy"),"Fixture is idle before explicitly seeded synthetic result");
                List<Duwm1728BroadcastLayout.Cue> cues=(List<Duwm1728BroadcastLayout.Cue>)field(first,"automaticCues");cues.clear();cues.addAll(supplied());set(first,"automaticCaptionStatus",CAPTION_STATUS);set(first,"autoProducing",true);call(first,"finishAutomaticPlan");});
            JSONObject receipt=awaitSaved(runner,first,target,receiptKey);Uri gallery=Uri.parse(receipt.getString("uri"));galleryOwned.add(gallery);check("content".equals(gallery.getScheme())&&"media".equals(gallery.getAuthority()),"Actual automatically finished portrait video is published to Gallery");check(CAPTION_STATUS.equals(receipt.getString("caption_status")),"Receipt explicitly identifies synthetic supplied transcript");
            Duwm1728AutomaticProduction.Plan expected=Duwm1728AutomaticProduction.plan(duration.get(),supplied(),CAPTION_STATUS,NOTES);AtomicReference<Duwm1728OverlayRenderer.Spec> selected=new AtomicReference<>();AtomicReference<Duwm1728ExportPreflight.Result> selectedPlan=new AtomicReference<>();
            ui(runner,()->{Duwm1728OverlayRenderer.Spec spec=(Duwm1728OverlayRenderer.Spec)field(first,"previewSpec");Duwm1728ExportPreflight.Result plan=(Duwm1728ExportPreflight.Result)field(first,"outputPlan");selected.set(spec);selectedPlan.set(plan);
                check(spec.automaticHeadlineFit&&spec.automaticOutputSizing&&plan!=null&&plan.automaticSizing,"Actual automatic completion enables both fitting policies and real output inspection");
                check(spec.fromMs==0&&spec.toMs==duration.get()&&"ORIGINAL".equals(spec.ratio)&&"FIT".equals(spec.frameMode)&&"COMPACT".equals(spec.composition),"Automatic fitting retains whole source, original aspect and compact composition");
                check(expected.title.equals(spec.title)&&spec.title.endsWith("TAIL"),"Actual editor retains the exact selected source headline");sameCues(spec.automaticCaptions,supplied(),"Actual editor caption source");sameCues(spec.automaticTickers,expected.tickers,"Actual editor ticker source");
                check(plan.sourceWidth==540&&plan.sourceHeight==960&&plan.requestedWidth==540&&plan.requestedHeight==960&&plan.rotation%180!=0,"Output inspection uses the actual upright rotated source");
                check(plan.width<=plan.requestedWidth&&plan.height<=plan.requestedHeight&&plan.fps==30&&plan.audio,"Device-selected compatible size retains source fps/audio without upscaling");});
            Duwm1728OverlayRenderer.Spec spec=selected.get();Duwm1728ExportPreflight.Result plan=selectedPlan.get();byte[] srt=Duwm1728CaptionSrt.exportCues(supplied(),Duwm1728CaptionSrt.TimeBase.ORIGINAL,duration.get(),0,duration.get());
            check(Arrays.equals(srt,Duwm1728CaptionSrt.exportCues(spec.automaticCaptions,Duwm1728CaptionSrt.TimeBase.ORIGINAL,duration.get(),0,duration.get())),"Headline fitting preserves source SRT bytes");
            proof.phase("automatic_fit.native_headline_rows");JSONArray rows=nativeRows(spec);File artifact=new File(folder,"ANDROID-AUTO-FIT.mp4");try(InputStream input=target.getContentResolver().openInputStream(gallery);OutputStream output=new FileOutputStream(artifact)){check(input!=null,"Read exact Gallery output bytes");copy(input,output);}
            String outputHash=DuwmNativeEvidence.hash(artifact);List<Duwm1728ExportRecovery.Entry> entries=sourceReceipts(target,sourceUri);check(entries.size()==1,"One source produces one actual finished export receipt");Duwm1728ExportRecovery.Entry entry=entries.get(0);recoveryOwned.add(entry.id);check(entry.state==Duwm1728ExportRecovery.State.PUBLISHED&&gallery.equals(entry.publishedUri)&&outputHash.equals(entry.sha256)&&artifact.length()==entry.bytes,"Durable receipt identifies exact published MP4 bytes");
            proof.phase("automatic_fit.decoded_headline");JSONObject decoded=decodedHeadline(artifact,spec,plan,folder);tracks(artifact);finish(runner,first);editor=null;
            proof.phase("automatic_fit.reopen_and_manual_headline");editor=open(runner,source);final Activity reopened=editor;ui(runner,()->{Duwm1728OverlayRenderer.Spec restored=(Duwm1728OverlayRenderer.Spec)field(reopened,"previewSpec");check(restored.automaticHeadlineFit&&restored.automaticOutputSizing&&expected.title.equals(restored.title),"Actual saved draft restores both automatic flags and exact selected title");sameCues(restored.automaticCaptions,supplied(),"Reopened source captions");});
            draftProtection(runner,reopened,target,sourceKey);
            ui(runner,()->{((EditText)field(reopened,"title")).setText("MANUAL HEADLINE • Explicit replacement");Duwm1728OverlayRenderer.Spec manual=(Duwm1728OverlayRenderer.Spec)field(reopened,"previewSpec");check(!manual.automaticHeadlineFit&&manual.automaticOutputSizing&&!Duwm1728OverlayRenderer.reportAt(manual,1000).automaticHeadlineFit,"Real manual headline edit disables only automatic headline fitting");sameCues(manual.automaticCaptions,supplied(),"Manual headline keeps source captions");sameCues(manual.automaticTickers,expected.tickers,"Manual headline keeps source ticker excerpts");check((Long)field(reopened,"automaticHeadlineStart")==-1&&(Long)field(reopened,"automaticHeadlineEnd")==-1,"Manual headline clears previous source-headline interval");check((Boolean)call(reopened,"saveDraft"),"Manual takeover can be saved");call(reopened,"loadDraft");call(reopened,"refresh");check(!(Boolean)field(reopened,"automaticHeadlineFit"),"Saved manual headline does not silently reacquire automatic fitting");});
            check(sourceHash.equals(DuwmNativeEvidence.hash(source)),"Rendering, draft validation and manual takeover leave original source MP4 bytes exact");check(sourceReceipts(target,sourceUri).size()==1,"Reopen, corruption checks and manual edit do not create duplicate automatic exports");
            JSONObject sizing=new JSONObject().put("requested_width",plan.requestedWidth).put("requested_height",plan.requestedHeight).put("selected_width",plan.width).put("selected_height",plan.height).put("resolution_adjusted",plan.resolutionAdjusted).put("reason",plan.selectionReason).put("encoder",plan.encoder).put("fps",plan.fps).put("bitrate",plan.bitrate).put("fallback_forced_by_test",false);
            result=new JSONObject().put("status","PASS").put("run_id",proof.runId()).put("scope","SYNTHETIC_PORTRAIT_TRANSCRIPT_REAL_EDITOR_AUTOMATIC_ENCODER_GALLERY_HEADLINE_AND_DRAFTS")
                .put("transcript_supplied_by_test",true).put("recognition_result_boundary_seeded",true).put("recognition_callbacks_injected",false).put("on_device_recognition_accuracy_verified",false).put("physical_camera_verified",false)
                .put("source_sha256",sourceHash).put("output_sha256",outputHash).put("output_bytes",artifact.length()).put("gallery_uri",gallery.toString()).put("caption_status",CAPTION_STATUS)
                .put("source_title_and_srt_exact",true).put("strict_draft_flags_verified",true).put("old_draft_defaults_preserved",true).put("manual_headline_takeover_verified",true).put("native_canvas_headlines",rows).put("decoded_mp4_headline",decoded).put("actual_output_plan",sizing).put("human_readability_asserted",false);
        }catch(Exception|Error error){failure=error;throw error;}
        finally{
            Throwable cleanup=null;try{finish(runner,editor);}catch(Exception|Error error){cleanup=error;}
            try{for(Duwm1728ExportRecovery.Entry entry:sourceReceipts(target,sourceUri)){recoveryOwned.add(entry.id);if(entry.publishedUri!=null)galleryOwned.add(entry.publishedUri);}}catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            for(Uri uri:galleryOwned)try{check(target.getContentResolver().delete(uri,null,null)==1,"Delete exactly this fixture-owned Gallery output");}catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            for(String id:recoveryOwned)try{Duwm1728ExportRecovery.discard(target,id);}catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            try{
                check(target.getSharedPreferences(Duwm1728AutomaticProduction.PREFS,Context.MODE_PRIVATE).edit().remove(receiptKey).commit(),"Remove only fixture-owned automatic receipt");check(target.getSharedPreferences("duwm_production_drafts",Context.MODE_PRIVATE).edit().remove(sourceKey).commit(),"Remove only fixture-owned draft");check(target.getSharedPreferences("duwm1728_saved_broadcasts",Context.MODE_PRIVATE).edit().remove(sourceKey).commit(),"Remove only fixture-owned saved-output shortcut");
                SharedPreferences index=target.getSharedPreferences("duwm1726_gallery_exports",Context.MODE_PRIVATE);StringBuilder retained=new StringBuilder();for(String row:index.getString("items","").split("\n")){int separator=row.indexOf('\t');boolean own=false;if(separator>=0)for(Uri uri:galleryOwned)if(uri.toString().equals(row.substring(0,separator))){own=true;break;}if(!row.isEmpty()&&!own){if(retained.length()>0)retained.append('\n');retained.append(row);}}
                check(index.edit().putString("items",retained.toString()).commit(),"Remove only fixture-owned Gallery index rows");
            }catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            if(source.exists()&&!source.delete()){IOException error=new IOException("Cannot remove fixture-owned automatic-fit source");if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}if(cleanup!=null){if(failure!=null)failure.addSuppressed(cleanup);else rethrow(cleanup);}
        }
        check(result!=null,"Automatic-fit checks and owned fixture cleanup complete");result.put("checks",checks).put("test_owned_gallery_and_receipt_cleanup_complete",true);try(OutputStream output=new FileOutputStream(new File(folder,"AUTO-FIT-NATIVE.json"))){output.write(result.toString(2).getBytes(StandardCharsets.UTF_8));}proof.phase("automatic_fit.complete");
    }
}
