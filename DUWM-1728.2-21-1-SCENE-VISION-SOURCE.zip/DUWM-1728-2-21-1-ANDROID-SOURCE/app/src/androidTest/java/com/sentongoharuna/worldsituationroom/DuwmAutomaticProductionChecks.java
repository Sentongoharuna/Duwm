package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.SystemClock;
import android.view.View;
import android.view.Window;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.VideoView;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import org.json.JSONArray;
import org.json.JSONObject;

/** Automatic editing of an actual AAC/video fixture through the native editor.
 * No transcription callback is injected. The observed installed-service result
 * is recorded, including honest caption-free fallback; recognition accuracy and
 * a physical camera are outside this synthetic-device stage.
 */
final class DuwmAutomaticProductionChecks {
    private final DuwmNativeEvidence proof;
    private int checks;
    private final Set<String> observedStates=new LinkedHashSet<>();
    DuwmAutomaticProductionChecks(DuwmNativeEvidence proof){this.proof=proof;}
    int count(){return checks;}
    private void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    private interface Action { void run()throws Exception; }
    private interface Condition { boolean ready()throws Exception; }
    private void ui(Instrumentation runner,Action action)throws Exception {
        AtomicReference<Throwable> failure=new AtomicReference<>();runner.runOnMainSync(()->{try{action.run();}catch(Throwable error){failure.set(error);}});
        rethrow(failure.get());
    }
    private static void rethrow(Throwable failure)throws Exception {
        if(failure instanceof Error)throw (Error)failure;
        if(failure instanceof Exception)throw (Exception)failure;
        if(failure!=null)throw new RuntimeException(failure);
    }
    private Object field(Object object,String name)throws Exception {
        java.lang.reflect.Field field=object.getClass().getDeclaredField(name);field.setAccessible(true);return field.get(object);
    }
    private void await(Instrumentation runner,Condition condition,long timeout,String message)throws Exception {
        AtomicBoolean ready=new AtomicBoolean();long deadline=SystemClock.elapsedRealtime()+timeout;
        do{ui(runner,()->ready.set(condition.ready()));if(ready.get())break;Thread.sleep(75);}while(SystemClock.elapsedRealtime()<deadline);
        check(ready.get(),message);
    }
    private View tagged(Window window,String tag){View view=window.getDecorView().findViewWithTag(tag);check(view!=null,"Actual control exists: "+tag);return view;}
    private void reachable(Instrumentation runner,Window window,String tag)throws Exception {
        await(runner,()->{
            View view=window.getDecorView().findViewWithTag(tag);if(view==null)return false;
            view.requestRectangleOnScreen(new Rect(0,0,view.getWidth(),view.getHeight()),true);
            Rect visible=new Rect();int target=Math.round(48*view.getResources().getDisplayMetrics().density);
            return view.isShown()&&view.getHeight()>=target-1&&view.getWidth()>=target-1
                &&view.getGlobalVisibleRect(visible)&&visible.height()>=target-1&&visible.width()>=target-1;
        },3000,"Control has a reachable 48 dp target: "+tag);
    }
    private void click(Instrumentation runner,Window window,String tag)throws Exception {
        reachable(runner,window,tag);ui(runner,()->{View view=tagged(window,tag);check(view.isEnabled(),"Control enabled: "+tag);check(view.performClick(),"Actual control responds: "+tag);});
    }
    private void screenshot(Instrumentation runner,File folder,String name)throws Exception {
        boolean idle=true;try{runner.getUiAutomation().waitForIdle(100,3000);}catch(TimeoutException unsettled){idle=false;}
        Bitmap image=runner.getUiAutomation().takeScreenshot();check(image!=null,"Actual device screenshot available: "+name);
        try(OutputStream output=new FileOutputStream(new File(folder,name+".png"))){check(image.compress(Bitmap.CompressFormat.PNG,100,output),"Write device screenshot: "+name);}
        finally{image.recycle();}
        proof.assertUnobstructed(name);check(idle,"UI accessibility became quiet within the bounded capture wait: "+name);
    }
    private Activity open(Instrumentation runner,File source)throws Exception {
        Activity editor=runner.startActivitySync(new Intent(runner.getTargetContext(),Duwm1728VideoEditorActivity.class)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(Duwm1728VideoEditorActivity.EXTRA_VIDEO_URI,Uri.fromFile(source).toString())
            .putExtra("clean_master",true));
        await(runner,()->(Boolean)field(editor,"prepared"),15000,"Actual clean-master source player prepared");return editor;
    }
    private void finish(Instrumentation runner,Activity activity)throws Exception {
        if(activity==null)return;ui(runner,activity::finish);await(runner,activity::isDestroyed,15000,"Activity lifecycle finished before cleanup or reopening");
    }
    private JSONObject receipt(Context context,String key)throws Exception {
        String raw=context.getSharedPreferences(Duwm1728AutomaticProduction.PREFS,Context.MODE_PRIVATE).getString(key,"");
        return raw.isEmpty()?null:new JSONObject(raw);
    }
    private JSONObject awaitSaved(Instrumentation runner,Activity editor,Context target,String receiptKey,File folder)throws Exception {
        long deadline=SystemClock.elapsedRealtime()+120000;JSONObject latest=null;String state="";
        while(SystemClock.elapsedRealtime()<deadline){
            latest=receipt(target,receiptKey);
            if(latest!=null){state=latest.optString("state");observedStates.add(state);}
            AtomicReference<String> uiState=new AtomicReference<>("");ui(runner,()->uiState.set((String)field(editor,"automaticStatus")));
            observedStates.add(uiState.get());
            if("SAVED_WITH_CAPTIONS".equals(state)||"SAVED_WITHOUT_CAPTIONS".equals(state)){
                await(runner,()->!(Boolean)field(editor,"autoProducing")&&!(Boolean)field(editor,"busy")&&field(editor,"lastBroadcast")!=null,
                    15000,"Automatic completion reaches the real editor and unlocks controls");return latest;
            }
            if("FAILED".equals(state)||"CANCELLED".equals(state)||"INTERRUPTED".equals(state)||"FAILED".equals(uiState.get())){
                screenshot(runner,folder,"ANDROID-AUTOMATIC-PRODUCTION");
                check(false,"Automatic native flow must produce a Gallery MP4, not a failure: receipt="+latest+" UI="+uiState.get());
            }
            Thread.sleep(100);
        }
        screenshot(runner,folder,"ANDROID-AUTOMATIC-PRODUCTION");
        check(false,"Automatic clean-master export did not produce a successful Gallery receipt within 120 seconds: "+latest);return latest;
    }
    private List<Duwm1728ExportRecovery.Entry> sourceReceipts(Context context,Uri source)throws Exception {
        ArrayList<Duwm1728ExportRecovery.Entry> own=new ArrayList<>();
        for(Duwm1728ExportRecovery.Entry entry:Duwm1728ExportRecovery.list(context))if(source.equals(entry.sourceUri))own.add(entry);return own;
    }
    private static final class AudioFacts {
        final String mime,sha256;final int rate,channels,samples;final long bytes;
        AudioFacts(String mime,String sha256,int rate,int channels,int samples,long bytes){this.mime=mime;this.sha256=sha256;this.rate=rate;this.channels=channels;this.samples=samples;this.bytes=bytes;}
        JSONObject json()throws Exception{return new JSONObject().put("mime",mime).put("sample_rate",rate).put("channels",channels).put("packets",samples).put("payload_bytes",bytes).put("payload_sha256",sha256);}
    }
    /** Hash actual demuxed AAC packets, excluding only samples outside the full-source range. */
    private AudioFacts audio(File file,long toUs)throws Exception {
        MediaExtractor extractor=new MediaExtractor();
        try{
            extractor.setDataSource(file.getAbsolutePath());MediaFormat selected=null;
            for(int index=0;index<extractor.getTrackCount();index++){
                MediaFormat format=extractor.getTrackFormat(index);String mime=format.getString(MediaFormat.KEY_MIME);
                if(mime!=null&&mime.startsWith("audio/")){check(selected==null,"Fixture output has one source audio track");selected=format;extractor.selectTrack(index);}
            }
            check(selected!=null,"Finished MP4 contains an actual audio track");
            check("audio/mp4a-latm".equals(selected.getString(MediaFormat.KEY_MIME)),"Audio remains AAC");
            extractor.seekTo(0,MediaExtractor.SEEK_TO_PREVIOUS_SYNC);ByteBuffer data=ByteBuffer.allocateDirect(2*1024*1024);
            MessageDigest digest=MessageDigest.getInstance("SHA-256");int samples=0;long bytes=0,last=-1;
            while(extractor.getSampleTime()>=0&&extractor.getSampleTime()<toUs){
                long timestamp=extractor.getSampleTime();data.clear();int count=extractor.readSampleData(data,0);if(count<0)break;
                check(timestamp>last,"Audio packets keep strictly increasing timestamps");last=timestamp;
                byte[] packet=new byte[count];data.position(0);data.get(packet);digest.update(packet);samples++;bytes+=count;
                if(!extractor.advance())break;
            }
            check(samples>0&&bytes>0,"AAC track contains actual encoded audio packets");
            return new AudioFacts(selected.getString(MediaFormat.KEY_MIME),hex(digest.digest()),selected.getInteger(MediaFormat.KEY_SAMPLE_RATE),selected.getInteger(MediaFormat.KEY_CHANNEL_COUNT),samples,bytes);
        }finally{extractor.release();}
    }
    private void near(int actual,int expected,String label){
        check(Math.abs(Color.red(actual)-Color.red(expected))<45&&Math.abs(Color.green(actual)-Color.green(expected))<45
            &&Math.abs(Color.blue(actual)-Color.blue(expected))<45,label+" actual="+Integer.toHexString(actual));
    }
    private JSONObject media(File source,File output,Duwm1728OverlayRenderer.Spec spec,File folder)throws Exception {
        MediaMetadataRetriever original=new MediaMetadataRetriever(),finished=new MediaMetadataRetriever();
        Bitmap raw=null,decoded=null,geometryImage=null;
        long duration=0,sourceDuration=0;int width=0,height=0;
        try{
            original.setDataSource(source.getAbsolutePath());finished.setDataSource(output.getAbsolutePath());
            width=Integer.parseInt(finished.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
            height=Integer.parseInt(finished.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
            duration=Long.parseLong(finished.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
            sourceDuration=Long.parseLong(original.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
            check(width==960&&height==540,"Automatic output retains the fixture's original 960x540 picture shape");
            check(Math.abs(sourceDuration-2000)<=80,"Independent source metadata identifies the two-second fixture");
            check(spec.fromMs==0&&spec.toMs==sourceDuration,"Actual automatic selection uses the complete source metadata range");
            check(Math.abs(duration-(spec.toMs-spec.fromMs))<=180,"Automatic output retains the complete selected source duration");
            check("yes".equalsIgnoreCase(finished.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)),"Saved file metadata confirms audio");
            raw=original.getFrameAtTime(500000,MediaMetadataRetriever.OPTION_CLOSEST);
            decoded=finished.getFrameAtTime(500000,MediaMetadataRetriever.OPTION_CLOSEST);
            check(raw!=null&&decoded!=null,"Actual source and finished MP4 frames decode");
            for(int x:new int[]{160,480,800})near(decoded.getPixel(x,180),raw.getPixel(x,180),"Automatic video keeps source picture zone "+x);
            geometryImage=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
            Duwm1728BroadcastLayout.Geometry geometry=Duwm1728BroadcastLayout.draw(new Duwm1728BroadcastCanvas(new Canvas(geometryImage)),width,height,Duwm1728OverlayRenderer.reportAt(spec,500),500);
            check("COMPACT".equals(geometry.composition)&&geometry.headlineVisible&&geometry.tickerVisible,"Encoded plan uses actual compact broadcast geometry");
            int panelX=Math.round(geometry.x+geometry.width*.85f),panelY=Math.round(geometry.headlineTop+8*geometry.unit);
            near(decoded.getPixel(panelX,panelY),0xFF041424,"Finished MP4 contains the navy broadcast panel");
            check(Math.abs(Color.blue(raw.getPixel(panelX,panelY))-Color.blue(decoded.getPixel(panelX,panelY)))>60,"Broadcast graphics are burned into saved video, not only a UI overlay");
            try(OutputStream image=new FileOutputStream(new File(folder,"ANDROID-AUTOMATIC-DECODED.png"))){check(decoded.compress(Bitmap.CompressFormat.PNG,100,image),"Save real decoded automatic output frame");}
        }finally{original.release();finished.release();if(raw!=null)raw.recycle();if(decoded!=null)decoded.recycle();if(geometryImage!=null)geometryImage.recycle();}
        MediaExtractor video=new MediaExtractor();try{
            video.setDataSource(output.getAbsolutePath());boolean avc=false;
            for(int i=0;i<video.getTrackCount();i++)if("video/avc".equals(video.getTrackFormat(i).getString(MediaFormat.KEY_MIME)))avc=true;
            check(avc,"Actual saved automatic MP4 uses AVC video");
        }finally{video.release();}
        // Compare packet STARTS inside the actual source/selected interval, as
        // production does. A final AAC packet may legitimately extend beyond
        // the video boundary; container padding is not a missing-audio failure.
        AudioFacts sourceAudio=audio(source,spec.toMs*1000),savedAudio=audio(output,(spec.toMs-spec.fromMs)*1000);
        check(savedAudio.rate==48000&&savedAudio.channels==1,"Saved AAC retains 48 kHz mono source format");
        check(sourceAudio.samples==savedAudio.samples&&sourceAudio.bytes==savedAudio.bytes&&sourceAudio.sha256.equals(savedAudio.sha256),"Automatic output retains the exact source AAC packet payloads");
        return new JSONObject().put("width",width).put("height",height).put("duration_ms",duration).put("source_duration_ms",sourceDuration)
            .put("aac_packet_start_interval_ms",new JSONArray().put(0).put(spec.toMs-spec.fromMs))
            .put("source_audio",sourceAudio.json()).put("saved_audio",savedAudio.json()).put("source_picture_markers_verified",true).put("navy_graphics_burned_into_video",true);
    }
    private void accessibilityClick(Instrumentation runner,String text)throws Exception {
        long deadline=SystemClock.elapsedRealtime()+3000;boolean clicked=false;
        while(!clicked&&SystemClock.elapsedRealtime()<deadline){
            AccessibilityNodeInfo root=runner.getUiAutomation().getRootInActiveWindow();
            if(root!=null)try{
                List<AccessibilityNodeInfo> nodes=root.findAccessibilityNodeInfosByText(text);
                try{for(AccessibilityNodeInfo node:nodes)if(text.contentEquals(node.getText()==null?"":node.getText())&&node.isEnabled()&&node.isVisibleToUser()){
                    clicked=node.performAction(AccessibilityNodeInfo.ACTION_CLICK);if(clicked)break;
                }}finally{for(AccessibilityNodeInfo node:nodes)node.recycle();}
            }finally{root.recycle();}
            if(!clicked)Thread.sleep(75);
        }
        check(clicked,"Activate actual native dialog button "+text);
    }
    private Activity review(Instrumentation runner,Activity editor,Uri saved,File folder)throws Exception {
        Instrumentation.ActivityMonitor monitor=runner.addMonitor(Duwm1728BroadcastReviewActivity.class.getName(),null,false);
        Activity review=null;
        try{
            click(runner,editor.getWindow(),"broadcast-editor-last-export");accessibilityClick(runner,"REVIEW");
            review=runner.waitForMonitorWithTimeout(monitor,15000);check(review!=null,"Last Export opens the actual finished-broadcast review Activity");
        }finally{runner.removeMonitor(monitor);}
        final Activity actual=review;
        try{
            await(runner,()->(Boolean)field(actual,"ready"),15000,"Native review player prepares the automatically saved MP4");
            ui(runner,()->{
                check(saved.equals(field(actual,"savedVideo")),"Review reads the actual automatic Gallery URI");
                MediaPlayer player=(MediaPlayer)field(actual,"mediaPlayer");
                check(player!=null&&player.getVideoWidth()==960&&player.getVideoHeight()==540,"Actual review decoder reports original dimensions");
                check(!((VideoView)field(actual,"video")).isPlaying(),"Finished review begins paused for human inspection");
            });
            click(runner,actual.getWindow(),"broadcast-review-play");
            await(runner,()->((VideoView)field(actual,"video")).isPlaying()&&((VideoView)field(actual,"video")).getCurrentPosition()>=150,
                5000,"Actual automatic output plays and advances in review");
            click(runner,actual.getWindow(),"broadcast-review-play");
            ui(runner,()->check(!((VideoView)field(actual,"video")).isPlaying(),"Actual review playback pauses"));
            screenshot(runner,folder,"ANDROID-AUTOMATIC-REVIEW");return review;
        }catch(Exception|Error failure){try{finish(runner,actual);}catch(Exception|Error cleanup){failure.addSuppressed(cleanup);}throw failure;}
    }

    void run(Instrumentation runner,File folder)throws Exception {
        Context target=runner.getTargetContext();File source=new File(target.getCacheDir(),"automatic-production-"+UUID.randomUUID()+".mp4");
        Uri sourceUri=Uri.fromFile(source);String sourceKey=Duwm1728CaptureTelemetry.storageKey(sourceUri),receiptKey=Duwm1728AutomaticProduction.receiptKey(sourceKey);
        Activity editor=null,review=null;Uri gallery=null;Throwable failure=null;JSONObject result=null;
        Set<Uri> ownedGallery=new LinkedHashSet<>();Set<String> ownedRecovery=new LinkedHashSet<>();
        try{
            proof.phase("automatic_production.fixture");
            try(InputStream input=runner.getContext().getAssets().open("framing_fixture.mp4");OutputStream output=new FileOutputStream(source)){copy(input,output);}
            String sourceHash=DuwmNativeEvidence.hash(source);
            SharedPreferences settings=target.getSharedPreferences(Duwm1728AutomaticProduction.PREFS,Context.MODE_PRIVATE);
            check(settings.getBoolean("enabled",true),"Automatic editing is enabled by default");
            check(!settings.contains(receiptKey)&&!target.getSharedPreferences("duwm_production_drafts",Context.MODE_PRIVATE).contains(sourceKey),"Unique clean-master fixture has no previous attempt or draft");
            proof.phase("automatic_production.clean_master_launch");editor=open(runner,source);final Activity first=editor;
            JSONObject savedReceipt=awaitSaved(runner,first,target,receiptKey,folder);
            String savedState=savedReceipt.getString("state"),captionStatus=savedReceipt.getString("caption_status");
            check(sourceKey.equals(savedReceipt.getString("source_key"))&&savedReceipt.getLong("updated_at")>0,"Durable automatic receipt belongs to this source");
            gallery=Uri.parse(savedReceipt.getString("uri"));ownedGallery.add(gallery);final Uri saved=gallery;
            check("content".equals(gallery.getScheme())&&"media".equals(gallery.getAuthority()),"Automatic completion is a real Gallery URI");
            AtomicReference<Duwm1728OverlayRenderer.Spec> selected=new AtomicReference<>();AtomicReference<String> displayedCaptionStatus=new AtomicReference<>("");
            ui(runner,()->{
                check(!(Boolean)field(first,"autoProducing")&&!(Boolean)field(first,"busy"),"Automatic production finished without a manual export press");
                check(saved.equals(field(first,"lastBroadcast")),"Editor exposes its actual automatic output");
                check(!((CheckBox)field(first,"approval")).isChecked(),"Automatic editing never marks the recording reporter-reviewed");
                Duwm1728OverlayRenderer.Spec spec=(Duwm1728OverlayRenderer.Spec)field(first,"previewSpec");selected.set(spec);
                long actualDuration=(Long)field(first,"durationMs");
                check(spec!=null&&spec.fromMs==0&&spec.toMs==actualDuration&&Math.abs(actualDuration-2000)<=80,"Automatic plan retains the complete, independently bounded fixture duration");
                check("ORIGINAL".equals(spec.ratio)&&"FIT".equals(spec.frameMode)&&"COMPACT".equals(spec.composition),"Automatic plan retains original aspect and compact native graphics");
                boolean withCaptions="SAVED_WITH_CAPTIONS".equals(savedState);
                check(withCaptions?!spec.automaticCaptions.isEmpty():spec.automaticCaptions.isEmpty(),"Saved caption outcome matches the actual production cue list");
                Duwm1728AutomaticProduction.Plan sourcePlan=Duwm1728AutomaticProduction.plan(actualDuration,spec.automaticCaptions,captionStatus,(String)field(first,"captureNotes"));
                check(sourcePlan.title.equals(spec.title)&&sourcePlan.description.equals(spec.description)&&!spec.breakingApproved&&!spec.includeCoordinates&&spec.pipVideo==null,"Automatic plan uses only actual source words or labelled notes and avoids breaking approval, precise coordinates and unrelated inset footage");
                check((withCaptions?"AUTO-CAPTIONS • UNREVIEWED":"AUTO-EDITED • UNVERIFIED").equals(spec.provenance),"Saved plan uses truthful unreviewed provenance");
                displayedCaptionStatus.set((String)field(first,"automaticCaptionStatus"));
                check(captionStatus.equals(displayedCaptionStatus.get()),"Receipt and editor disclose the same actual caption outcome");
                if(!withCaptions)check(captionStatus.startsWith("CAPTIONS UNAVAILABLE")||captionStatus.startsWith("NO WORDS RETURNED"),"Caption-free output discloses unavailable recognition or a completed request returning no words");
                check(savedState.equals(field(first,"automaticStatus")),"Automatic editor and durable result agree");
                check(((TextView)field(first,"state")).getText().toString().startsWith("VIDEO READY"),"Finished automatic output is visibly ready");
            });
            for(String tag:new String[]{"broadcast-editor-auto-produce","broadcast-editor-auto-help","broadcast-editor-last-export"})reachable(runner,first.getWindow(),tag);
            screenshot(runner,folder,"ANDROID-AUTOMATIC-PRODUCTION");
            proof.phase("automatic_production.gallery_decode_and_audio");
            File artifact=new File(folder,"ANDROID-AUTOMATIC-BROADCAST.mp4");
            try(InputStream input=target.getContentResolver().openInputStream(gallery);OutputStream output=new FileOutputStream(artifact)){
                check(input!=null,"Read the actual automatically published Gallery MP4");copy(input,output);
            }
            check(artifact.length()>0,"Published automatic MP4 contains real bytes");
            List<Duwm1728ExportRecovery.Entry> entries=sourceReceipts(target,sourceUri);check(entries.size()==1,"One fresh recording produced one durable export receipt");
            Duwm1728ExportRecovery.Entry entry=entries.get(0);ownedRecovery.add(entry.id);
            check(entry.state==Duwm1728ExportRecovery.State.PUBLISHED&&gallery.equals(entry.publishedUri),"Recovery receipt confirms actual Gallery publication");
            String outputHash=DuwmNativeEvidence.hash(artifact);check(entry.bytes==artifact.length()&&entry.sha256.equals(outputHash),"Gallery output matches its durably retained completed-MP4 digest");
            JSONObject media=media(source,artifact,selected.get(),folder);
            proof.phase("automatic_production.finished_review");review=review(runner,first,gallery,folder);finish(runner,review);review=null;
            String receiptBefore=settings.getString(receiptKey,"");finish(runner,first);editor=null;

            proof.phase("automatic_production.reopen_without_duplicate");editor=open(runner,source);final Activity reopened=editor;
            await(runner,()->saved.equals(field(reopened,"lastBroadcast")),15000,"Reopened clean master restores the successful automatic output");
            long observeUntil=SystemClock.elapsedRealtime()+2000;
            do{
                ui(runner,()->check(!(Boolean)field(reopened,"autoProducing")&&!(Boolean)field(reopened,"busy"),"Previously attempted clean master does not restart automatic production"));
                check(receiptBefore.equals(settings.getString(receiptKey,"")),"Reopen leaves the same source-specific attempt receipt unchanged");
                Thread.sleep(100);
            }while(SystemClock.elapsedRealtime()<observeUntil);
            List<Duwm1728ExportRecovery.Entry> after=sourceReceipts(target,sourceUri);
            check(after.size()==1&&entry.id.equals(after.get(0).id)&&gallery.equals(after.get(0).publishedUri),"Reopening did not create another MP4 or recovery receipt");
            ui(runner,()->check(!((CheckBox)field(reopened,"approval")).isChecked(),"Restored automatic report still requires human review"));
            check(sourceHash.equals(DuwmNativeEvidence.hash(source)),"Automatic editing and review preserve the clean-master bytes");
            result=new JSONObject().put("status","PASS").put("run_id",proof.runId()).put("scope","REAL_NATIVE_AUTOMATIC_EDIT_EXPORT_AND_REVIEW")
                .put("source_sha256",sourceHash).put("gallery_uri",gallery.toString()).put("output_sha256",outputHash).put("output_bytes",artifact.length())
                .put("automatic_receipt",savedReceipt).put("observed_states",new JSONArray(observedStates))
                .put("caption_outcome",savedState).put("caption_status",captionStatus).put("caption_count",selected.get().automaticCaptions.size())
                .put("media",media).put("clean_master_triggered_without_export_click",true).put("same_recording_reopen_no_duplicate",true)
                .put("reporter_approval_remained_false",true).put("actual_saved_video_review_played",true)
                .put("recognition_callbacks_injected",false).put("on_device_recognition_accuracy_verified",false)
                .put("physical_camera_verified",false).put("external_server_configured_by_test",false);
        }catch(Exception|Error error){failure=error;throw error;}
        finally{
            Throwable cleanup=null;
            try{finish(runner,review);}catch(Exception|Error error){cleanup=error;}
            try{finish(runner,editor);}catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            // Recover only receipts associated with this unique fixture source;
            // a failure after Gallery publication must not leak that owned row.
            try{for(Duwm1728ExportRecovery.Entry entry:sourceReceipts(target,sourceUri)){
                ownedRecovery.add(entry.id);if(entry.publishedUri!=null)ownedGallery.add(entry.publishedUri);
            }}catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            for(Uri uri:ownedGallery)try{check(target.getContentResolver().delete(uri,null,null)==1,"Delete exactly this test-owned automatic Gallery item");}
                catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            for(String id:ownedRecovery)try{Duwm1728ExportRecovery.discard(target,id);}
                catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            try{
                check(target.getSharedPreferences(Duwm1728AutomaticProduction.PREFS,Context.MODE_PRIVATE).edit().remove(receiptKey).commit(),"Remove only the test source's automatic receipt");
                check(target.getSharedPreferences("duwm_production_drafts",Context.MODE_PRIVATE).edit().remove(sourceKey).commit(),"Remove only the test source's draft");
                check(target.getSharedPreferences("duwm1728_saved_broadcasts",Context.MODE_PRIVATE).edit().remove(sourceKey).commit(),"Remove only the test source's last-export shortcut");
                SharedPreferences index=target.getSharedPreferences("duwm1726_gallery_exports",Context.MODE_PRIVATE);StringBuilder retained=new StringBuilder();
                for(String row:index.getString("items","").split("\n")){
                    int separator=row.indexOf('\t');boolean own=false;
                    if(separator>=0)for(Uri uri:ownedGallery)if(uri.toString().equals(row.substring(0,separator))){own=true;break;}
                    if(!row.isEmpty()&&!own){if(retained.length()>0)retained.append('\n');retained.append(row);}
                }
                check(index.edit().putString("items",retained.toString()).commit(),"Remove only test-owned Gallery-index rows");
            }catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            if(source.exists()&&!source.delete()){IOException error=new IOException("Cannot remove owned automatic-production fixture");if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            if(cleanup!=null){if(failure!=null)failure.addSuppressed(cleanup);else rethrow(cleanup);}
        }
        check(result!=null,"Automatic stage completed all required checks and fixture cleanup");result.put("checks",checks).put("test_owned_gallery_and_receipt_cleanup_complete",true);
        try(OutputStream output=new FileOutputStream(new File(folder,"AUTOMATIC-PRODUCTION-NATIVE.json"))){output.write(result.toString(2).getBytes(StandardCharsets.UTF_8));}
        proof.phase("automatic_production.complete");
    }
    private static void copy(InputStream input,OutputStream output)throws IOException {
        byte[] buffer=new byte[65536];int count;while((count=input.read(buffer))!=-1)output.write(buffer,0,count);
    }
    private static String hex(byte[] bytes){StringBuilder value=new StringBuilder();for(byte item:bytes)value.append(String.format(Locale.ROOT,"%02x",item&255));return value.toString();}
}
