package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Instrumentation;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import org.json.JSONArray;
import org.json.JSONObject;

/** Real app controls and ContentResolver I/O, with explicit test-owned document results.
 * ActivityMonitor intercepts the actual UI-started document/share Intents. This
 * proves DUWM's result handling and file bytes, not external DocumentsUI or a
 * recipient app. No network AI, physical-camera or recipient claim is made.
 */
final class DuwmCaptionFilesChecks {
    private final DuwmNativeEvidence proof;
    private int checks;
    private final List<Uri> ownedDocuments=new ArrayList<>();
    private final Set<String> ownedSnapshots=new LinkedHashSet<>();
    private final JSONArray intercepted=new JSONArray();
    DuwmCaptionFilesChecks(DuwmNativeEvidence proof){this.proof=proof;}
    int count(){return checks;}
    private synchronized void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    private interface Action { void run()throws Exception; }
    private interface Condition { boolean ready()throws Exception; }
    private void ui(Instrumentation runner,Action action)throws Exception {
        AtomicReference<Throwable> failure=new AtomicReference<>();
        runner.runOnMainSync(()->{try{action.run();}catch(Throwable error){failure.set(error);}});
        rethrow(failure.get());
    }
    private static void rethrow(Throwable error)throws Exception {
        if(error instanceof Error)throw (Error)error;
        if(error instanceof Exception)throw (Exception)error;
        if(error!=null)throw new RuntimeException(error);
    }
    private Object field(Object object,String name)throws Exception {
        java.lang.reflect.Field field=object.getClass().getDeclaredField(name);field.setAccessible(true);return field.get(object);
    }
    private void set(Object object,String name,Object value)throws Exception {
        java.lang.reflect.Field field=object.getClass().getDeclaredField(name);field.setAccessible(true);field.set(object,value);
    }
    private void invoke(Object object,String name)throws Exception {
        java.lang.reflect.Method method=object.getClass().getDeclaredMethod(name);method.setAccessible(true);method.invoke(object);
    }
    private void awaitUi(Instrumentation runner,Condition condition,String message)throws Exception {
        AtomicBoolean ready=new AtomicBoolean();long deadline=SystemClock.elapsedRealtime()+15000;
        do{ui(runner,()->ready.set(condition.ready()));if(ready.get())break;Thread.sleep(75);}
        while(SystemClock.elapsedRealtime()<deadline);
        check(ready.get(),message);
    }
    private View tagged(Window window,String name){
        View view=window.getDecorView().findViewWithTag(name);check(view!=null,"Actual control exists: "+name);return view;
    }
    private void reachable(Instrumentation runner,Window window,String tag)throws Exception {
        AtomicBoolean ready=new AtomicBoolean();AtomicReference<String> bounds=new AtomicReference<>("");
        long deadline=SystemClock.elapsedRealtime()+3000;
        do{
            ui(runner,()->{
                View view=window.getDecorView().findViewWithTag(tag);if(view==null)return;
                view.requestRectangleOnScreen(new Rect(0,0,view.getWidth(),view.getHeight()),true);
                Rect visible=new Rect();int minimum=Math.round(48*view.getResources().getDisplayMetrics().density);
                boolean shown=view.getGlobalVisibleRect(visible);
                bounds.set(view.getWidth()+"x"+view.getHeight()+" visible="+visible+" minimum="+minimum);
                ready.set(view.isShown()&&shown&&view.getHeight()>=minimum-1&&view.getWidth()>=minimum-1
                    &&visible.height()>=minimum-1&&visible.width()>=minimum-1);
            });
            if(ready.get())break;Thread.sleep(75);
        }while(SystemClock.elapsedRealtime()<deadline);
        check(ready.get(),"Control has a reachable 48 dp target: "+tag+" "+bounds.get());
    }
    private void click(Instrumentation runner,Window window,String tag)throws Exception {
        reachable(runner,window,tag);
        ui(runner,()->{View view=tagged(window,tag);check(view.isEnabled(),"Control enabled: "+tag);check(view.performClick(),"Actual control responds: "+tag);});
    }
    private Activity openEditor(Instrumentation runner,File source)throws Exception {
        Activity activity=runner.startActivitySync(new Intent(runner.getTargetContext(),Duwm1728VideoEditorActivity.class)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(Duwm1728VideoEditorActivity.EXTRA_VIDEO_URI,Uri.fromFile(source).toString())
            .putExtra("broadcast_ratio","16:9"));
        awaitUi(runner,()->(Boolean)field(activity,"prepared"),"Actual fixture video player prepared");return activity;
    }
    private Object controller(Instrumentation runner,Activity activity)throws Exception {
        AtomicReference<Object> value=new AtomicReference<>();ui(runner,()->value.set(field(activity,"captionFiles")));
        check(value.get()!=null,"Editor owns the actual caption-file controller");return value.get();
    }
    private AlertDialog dialog(Instrumentation runner,Object controller,String name)throws Exception {
        AtomicReference<AlertDialog> value=new AtomicReference<>();
        awaitUi(runner,()->{value.set((AlertDialog)field(controller,name));return value.get()!=null&&value.get().isShowing();},"Actual "+name+" is shown");
        return value.get();
    }
    private void status(Instrumentation runner,Object controller,String prefix)throws Exception {
        AtomicReference<String> actual=new AtomicReference<>("");
        awaitUi(runner,()->{actual.set((String)field(controller,"statusText"));
            return actual.get().startsWith(prefix)&&!(Boolean)field(controller,"working");},"Caption-file status becomes "+prefix);
        ui(runner,()->{TextView text=(TextView)field(controller,"status");
            check(text!=null&&text.getText().toString().equals(actual.get()),"Visible status matches actual controller state: "+actual.get());});
    }
    private void basis(Instrumentation runner,Object controller,AlertDialog dialog,boolean clip)throws Exception {
        String tag=clip?"caption-files-clip":"caption-files-original";
        String other=clip?"caption-files-original":"caption-files-clip";
        reachable(runner,dialog.getWindow(),tag);
        ui(runner,()->{
            RadioButton selected=(RadioButton)tagged(dialog.getWindow(),tag),opposite=(RadioButton)tagged(dialog.getWindow(),other);
            check(selected.isEnabled(),"Time-basis control enabled: "+tag);
            check(selected.isClickable(),"Time-basis control accepts clicks: "+tag);
            check(selected.getParent() instanceof RadioGroup&&selected.getParent()==opposite.getParent(),"Time-basis controls share the actual RadioGroup");
            // CompoundButton toggles before returning View.performClick's
            // OnClickListener boolean. RadioGroup selection uses a checked-change
            // listener, so that boolean may be false after a successful selection.
            // https://developer.android.com/reference/android/view/View#performClick()
            selected.performClick();
            check(selected.isChecked(),"Explicit file time basis is selected: "+tag);
            check(!opposite.isChecked(),"Opposite file time basis is unselected: "+other);
            check(((RadioGroup)selected.getParent()).getCheckedRadioButtonId()==selected.getId(),"RadioGroup tracks the selected time-basis control");
            check(field(controller,"basis")== (clip?Duwm1728CaptionSrt.TimeBase.SELECTED_CLIP:Duwm1728CaptionSrt.TimeBase.ORIGINAL),
                    "Actual caption controller receives the selected time basis");
        });
    }
    private void capture(Instrumentation runner,File folder,String name)throws Exception {
        boolean idle=true;
        try{runner.getUiAutomation().waitForIdle(100,3000);}catch(TimeoutException unsettled){idle=false;}
        Bitmap image=runner.getUiAutomation().takeScreenshot();check(image!=null,"Actual UI screenshot available: "+name);
        try(OutputStream output=new FileOutputStream(new File(folder,name+".png"))){
            check(image.compress(Bitmap.CompressFormat.PNG,100,output),"Save actual UI screenshot: "+name);
        }finally{image.recycle();}
        proof.assertUnobstructed(name);
        check(idle,"Accessibility became quiet for 100 ms within 3 seconds: "+name);
    }
    @SuppressWarnings("unchecked") private List<Duwm1728BroadcastLayout.Cue> cues(Object activity)throws Exception {
        return (List<Duwm1728BroadcastLayout.Cue>)field(activity,"aiCaptions");
    }
    private static Duwm1728BroadcastLayout.Cue cue(long start,long end,String words){return new Duwm1728BroadcastLayout.Cue(start,end,words);}
    private static List<Duwm1728BroadcastLayout.Cue> originalCues(){
        return Arrays.asList(cue(100,200,"BEFORE THE CLIP"),cue(250,350,"CROSSES THE START"),cue(270,300,"ENDS AT CLIP START"),
            cue(300,325,"STARTS AT CLIP START"),cue(350,400,"Literal <angle> & value=42; مرحبا 世界"),cue(410,450,"Unicode 🛰️ e\u0301"),
            cue(470,520,"Embedded\uFEFFword survives"),cue(550,1200,"UNDERLYING OVERLAP"),cue(600,700,"LATEST START"),
            cue(750,850,"EQUAL START FIRST"),cue(750,900,"EQUAL START LAST"),cue(920,960,"Cue eleven"),cue(980,1020,"Cue twelve"),
            cue(1040,1080,"Cue thirteen"),cue(1100,1140,"Cue fourteen"),cue(1160,1190,"Cue fifteen"),cue(1210,1240,"Cue sixteen"),
            cue(1270,1300,"Cue seventeen"),cue(1330,1360,"Cue eighteen"),cue(1400,1650,"CROSSES THE END"),
            cue(1470,1490,"LAST INSIDE"),cue(1500,1600,"STARTS AT CLIP END"),cue(1660,1880,"OUTSIDE AFTER CLIP"));
    }
    /** Independent expected values for the selected 300..1500 ms fixture range. */
    private static List<Duwm1728BroadcastLayout.Cue> clipCues(List<Duwm1728BroadcastLayout.Cue> original){
        int[] indexes={1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
        long[] starts={0,0,50,110,170,250,300,450,450,620,680,740,800,860,910,970,1030,1100,1170};
        long[] ends={50,25,100,150,220,900,400,550,600,660,720,780,840,890,940,1000,1060,1200,1190};
        ArrayList<Duwm1728BroadcastLayout.Cue> result=new ArrayList<>();
        for(int i=0;i<indexes.length;i++)result.add(cue(starts[i],ends[i],original.get(indexes[i]).text));return result;
    }
    private static List<Duwm1728BroadcastLayout.Cue> sourceFromClip(List<Duwm1728BroadcastLayout.Cue> relative){
        ArrayList<Duwm1728BroadcastLayout.Cue> source=new ArrayList<>();
        for(Duwm1728BroadcastLayout.Cue item:relative)source.add(cue(item.startMs+300,item.endMs+300,item.text));return source;
    }
    private void same(List<Duwm1728BroadcastLayout.Cue> expected,List<Duwm1728BroadcastLayout.Cue> actual,String label){
        check(expected.size()==actual.size(),label+" preserves all "+expected.size()+" cues");
        for(int i=0;i<expected.size();i++){
            Duwm1728BroadcastLayout.Cue first=expected.get(i),second=actual.get(i);
            check(first.startMs==second.startMs&&first.endMs==second.endMs&&first.text.equals(second.text),label+" exact cue "+i);
        }
    }
    private void seed(Activity activity,List<Duwm1728BroadcastLayout.Cue> initial)throws Exception {
        check((Long)field(activity,"durationMs")>=1880,"Fixture includes captions beyond the selected range");set(activity,"updatingFields",true);
        try{
            ((EditText)field(activity,"title")).setText("CAPTION FILES NATIVE FIXTURE");
            ((EditText)field(activity,"from")).setText("0.300");((EditText)field(activity,"to")).setText("1.500");
            ((EditText)field(activity,"subtitles")).setText("");set(activity,"aiCaptions",new ArrayList<>(initial));
            set(activity,"captionKind","Imported SRT • native file fixture");set(activity,"captionOriginMs",71L);
            set(activity,"selectedComposition","COMPACT");set(activity,"selectedRatio","16:9");set(activity,"selectedTemplate",2);
            set(activity,"frameMode","FIT");set(activity,"frameX",.25f);set(activity,"frameY",.75f);
        }finally{set(activity,"updatingFields",false);}
        invoke(activity,"refresh");invoke(activity,"saveDraft");((CheckBox)field(activity,"approval")).setChecked(true);
    }
    private String draft(Activity activity)throws Exception {
        return activity.getSharedPreferences("duwm_production_drafts",Context.MODE_PRIVATE)
            .getString(Duwm1728CaptureTelemetry.storageKey((Uri)field(activity,"source")),"");
    }
    private final class EditorState {
        final List<Duwm1728BroadcastLayout.Cue> captions;
        final String draft,kind,legacy,from,to,ratio,mode,composition;
        final boolean approved;final long origin;final float x,y;final Uri source;
        EditorState(Activity activity)throws Exception {
            captions=new ArrayList<>(cues(activity));draft=draft(activity);kind=(String)field(activity,"captionKind");
            legacy=((EditText)field(activity,"subtitles")).getText().toString();from=((EditText)field(activity,"from")).getText().toString();
            to=((EditText)field(activity,"to")).getText().toString();ratio=(String)field(activity,"selectedRatio");mode=(String)field(activity,"frameMode");
            composition=(String)field(activity,"selectedComposition");approved=((CheckBox)field(activity,"approval")).isChecked();
            origin=(Long)field(activity,"captionOriginMs");x=(Float)field(activity,"frameX");y=(Float)field(activity,"frameY");source=(Uri)field(activity,"source");
        }
        void unchanged(Activity activity,String label)throws Exception {
            same(captions,cues(activity),label);
            check(draft.equals(draft(activity)),label+" leaves the saved draft byte-for-byte unchanged");
            check(kind.equals(field(activity,"captionKind"))&&origin==(Long)field(activity,"captionOriginMs"),label+" retains caption provenance and saved origin");
            check(legacy.equals(((EditText)field(activity,"subtitles")).getText().toString()),label+" retains legacy field");
            check(approved==((CheckBox)field(activity,"approval")).isChecked(),label+" retains approval");
            check(from.equals(((EditText)field(activity,"from")).getText().toString())&&to.equals(((EditText)field(activity,"to")).getText().toString()),label+" retains trim text");
            check(ratio.equals(field(activity,"selectedRatio"))&&mode.equals(field(activity,"frameMode"))&&composition.equals(field(activity,"selectedComposition"))
                &&x==(Float)field(activity,"frameX")&&y==(Float)field(activity,"frameY")&&source.equals(field(activity,"source")),label+" retains source, layout and framing");
        }
    }
    private EditorState state(Instrumentation runner,Activity activity)throws Exception {
        AtomicReference<EditorState> saved=new AtomicReference<>();ui(runner,()->saved.set(new EditorState(activity)));return saved.get();
    }
    private void committed(Activity activity,File source,List<Duwm1728BroadcastLayout.Cue> expected,List<Duwm1728BroadcastLayout.Cue> rendered)throws Exception {
        same(expected,cues(activity),"Committed source-time captions");
        Duwm1728OverlayRenderer.Spec spec=(Duwm1728OverlayRenderer.Spec)field(activity,"previewSpec");
        check(spec!=null&&spec.fromMs==300&&spec.toMs==1500,"Import retains the exact selected trim");
        check("16:9".equals(spec.ratio)&&"FIT".equals(spec.frameMode)&&spec.frameX==.25f&&spec.frameY==.75f
            &&"COMPACT".equals(spec.composition)&&"WEATHER".equals(spec.template),"Import retains layout, category and framing anchors");
        check(Uri.fromFile(source).equals(field(activity,"source")),"Import retains the original source URI");
        same(expected,spec.automaticCaptions,"Actual preview specification");same(rendered,spec.renderedCaptions,"Actual selected-range preview captions");
        check(!((CheckBox)field(activity,"approval")).isChecked(),"Applied caption import clears approval");
        check(((EditText)field(activity,"subtitles")).getText().length()==0,"Import does not route exact cues through the legacy text field");
        check(((String)field(activity,"captionKind")).startsWith("Imported SRT"),"Imported provenance remains truthful");
        JSONObject persisted=new JSONObject(draft(activity));JSONArray array=persisted.getJSONArray("automatic_captions");
        check(array.length()==expected.size(),"Applied import immediately updates persisted complete caption list");
        for(int i=0;i<expected.size();i++){
            JSONObject item=array.getJSONObject(i);Duwm1728BroadcastLayout.Cue wanted=expected.get(i);
            check(item.getLong("start_ms")==wanted.startMs&&item.getLong("end_ms")==wanted.endMs&&item.getString("text").equals(wanted.text),"Persisted exact cue "+i);
        }
    }
    private Uri document(Context target,String label,byte[] initial)throws Exception {
        ContentValues values=new ContentValues();values.put(MediaStore.MediaColumns.DISPLAY_NAME,"duwm-native-"+label+"-"+UUID.randomUUID()+".srt");
        values.put(MediaStore.MediaColumns.MIME_TYPE,Duwm1728CaptionFileStore.MIME);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/DUWM-Caption-Files-Native/");
        values.put(MediaStore.MediaColumns.IS_PENDING,1);
        Uri uri=target.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
        check(uri!=null&&"content".equals(uri.getScheme()),"Create test-owned Downloads document: "+label);ownedDocuments.add(uri);
        if(initial!=null)try(OutputStream output=target.getContentResolver().openOutputStream(uri,"wt")){
            check(output!=null,"Open actual input fixture document");output.write(initial);
        }
        return uri;
    }
    private byte[] readUri(Context target,Uri uri)throws Exception {
        try(InputStream input=target.getContentResolver().openInputStream(uri);ByteArrayOutputStream output=new ByteArrayOutputStream()){
            if(input==null)throw new IOException("ContentResolver did not open "+uri);
            byte[] buffer=new byte[8192];int count;
            while((count=input.read(buffer))!=-1){if(output.size()+count>Duwm1728CaptionSrt.MAX_BYTES)throw new IOException("Unexpected oversized fixture document");output.write(buffer,0,count);}
            return output.toByteArray();
        }
    }
    private void savedBytes(Context target,Uri uri,File folder,String name,List<Duwm1728BroadcastLayout.Cue> expected)throws Exception {
        byte[] actual=readUri(target,uri);check(actual.length>0,"Actual saved document has bytes: "+name);
        try(OutputStream output=new FileOutputStream(new File(folder,name))){output.write(actual);}
        String strict=Duwm1728CaptionSrt.read(new java.io.ByteArrayInputStream(actual));
        same(expected,Duwm1728CaptionSrt.parse(strict),"Actual ContentResolver SRT "+name);
        check(strict.contains("<angle>")&&strict.contains("مرحبا 世界")&&strict.contains("Embedded\uFEFFword"),"Actual saved bytes preserve literal and Unicode caption words");
    }

    /** A deliberate external-activity test seam, attached before the real UI action. */
    private final class Picker extends Instrumentation.ActivityMonitor {
        final String action;final Activity activity;final Object controller;final Uri destination;
        final boolean cancel,mutateAfterSnapshot,readOnlyDestination;
        final AtomicReference<Intent> actual=new AtomicReference<>();final AtomicReference<Throwable> failure=new AtomicReference<>();
        final AtomicInteger calls=new AtomicInteger();volatile Duwm1728CaptionFileStore.Snapshot snapshot;
        Picker(String action,Activity activity,Object controller,Uri destination,boolean cancel,boolean mutate,boolean readOnly){
            this.action=action;this.activity=activity;this.controller=controller;this.destination=destination;
            this.cancel=cancel;mutateAfterSnapshot=mutate;readOnlyDestination=readOnly;
        }
        @Override public Instrumentation.ActivityResult onStartActivity(Intent intent){
            String launched=intent.getAction();
            if(!Intent.ACTION_CREATE_DOCUMENT.equals(launched)&&!Intent.ACTION_OPEN_DOCUMENT.equals(launched)
                    &&!Intent.ACTION_CHOOSER.equals(launched)&&!Intent.ACTION_SEND.equals(launched))return null;
            try{
                check(action.equals(launched),"Actual native action starts expected Intent: "+action+"; actual="+launched);
                check(calls.incrementAndGet()==1,"The user action launches one external Intent");actual.set(new Intent(intent));
                intercepted.put(new JSONObject().put("action",launched).put("intercepted",true).put("result",cancel?"CANCELLED":"TEST_OWNED_URI_OR_BLOCKED_CHOOSER")
                    .put("simulated_committed_edit_after_snapshot",mutateAfterSnapshot));
                Uri selected=destination;
                if(Intent.ACTION_CREATE_DOCUMENT.equals(launched)){
                    check(intent.hasCategory(Intent.CATEGORY_OPENABLE)&&Duwm1728CaptionFileStore.MIME.equals(intent.getType()),"Save uses an openable SRT create-document contract");
                    String id=(String)field(controller,"pendingSaveId");check(id.matches("[0-9a-f]{32}"),"Pending snapshot identity exists before picker launch");
                    snapshot=Duwm1728CaptionFileStore.find(activity,id);ownedSnapshots.add(id);
                    check(snapshot.bytes>0&&snapshot.sha256.matches("[0-9a-f]{64}"),"Frozen snapshot is readable before the picker result");
                    check(snapshot.name.equals(intent.getStringExtra(Intent.EXTRA_TITLE)),"Picker filename describes the actual frozen file");
                    if(mutateAfterSnapshot){
                        // Test-only simulated concurrent committed change. Normal editor
                        // controls are locked while its real picker request is pending.
                        set(activity,"aiCaptions",new ArrayList<>(Arrays.asList(cue(400,500,"SIMULATED NEWER COMMITTED DRAFT"))));
                        set(activity,"captionKind","Native test simulated later draft");invoke(activity,"refresh");invoke(activity,"saveDraft");
                        ((CheckBox)field(activity,"approval")).setChecked(true);
                    }
                    if(readOnlyDestination)selected=snapshot.uri;
                }else if(Intent.ACTION_OPEN_DOCUMENT.equals(launched)){
                    check(intent.hasCategory(Intent.CATEGORY_OPENABLE),"Import requests an openable document");
                    String[] types=intent.getStringArrayExtra(Intent.EXTRA_MIME_TYPES);
                    check(types!=null&&Arrays.asList(types).contains(Duwm1728CaptionFileStore.MIME),"Import includes SRT MIME type");
                }
                if(cancel||Intent.ACTION_CHOOSER.equals(launched))return new Instrumentation.ActivityResult(Activity.RESULT_CANCELED,null);
                check(selected!=null,"Document seam returns a concrete test-owned URI");
                return new Instrumentation.ActivityResult(Activity.RESULT_OK,new Intent().setData(selected)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION));
            }catch(Throwable error){failure.set(error);return new Instrumentation.ActivityResult(Activity.RESULT_CANCELED,null);}
        }
    }
    private Picker launch(Instrumentation runner,Activity activity,Object controller,AlertDialog dialog,String button,String action,
            Uri destination,boolean cancel,boolean mutate,boolean readOnly,String terminal)throws Exception {
        Picker picker=new Picker(action,activity,controller,destination,cancel,mutate,readOnly);runner.addMonitor(picker);
        try{
            click(runner,dialog.getWindow(),button);long deadline=SystemClock.elapsedRealtime()+15000;
            while(picker.actual.get()==null&&picker.failure.get()==null&&SystemClock.elapsedRealtime()<deadline)Thread.sleep(75);
            rethrow(picker.failure.get());check(picker.actual.get()!=null,"Real UI action reached the intercepted "+action+" contract");
            status(runner,controller,terminal);rethrow(picker.failure.get());check(picker.calls.get()==1,"One activity-result flow completed");
            if(Intent.ACTION_CREATE_DOCUMENT.equals(action))ui(runner,()->check(((String)field(controller,"pendingSaveId")).isEmpty(),"Pending save ID clears after the actual result"));
            return picker;
        }finally{runner.removeMonitor(picker);}
    }
    @SuppressWarnings("unchecked") private void candidate(Instrumentation runner,Object controller,List<Duwm1728BroadcastLayout.Cue> expected)throws Exception {
        ui(runner,()->{
            List<Duwm1728BroadcastLayout.Cue> actual=(List<Duwm1728BroadcastLayout.Cue>)field(controller,"candidate");
            check(actual!=null,"Import candidate exists before confirmation");same(expected,actual,"Validated candidate");
            boolean immutable=false;try{actual.add(cue(0,1,"must not change"));}catch(UnsupportedOperationException intended){immutable=true;}
            check(immutable,"Validated candidate is immutable until explicit replacement");
        });
    }
    private void denyRead(Context target,Uri uri,String label)throws Exception {
        boolean denied=false;try{readUri(target,uri);}catch(IOException|SecurityException|IllegalArgumentException expected){denied=true;}
        check(denied,label);
    }
    private Uri verifyShare(Context target,Picker interceptedShare,List<Duwm1728BroadcastLayout.Cue> expected)throws Exception {
        Intent chooser=interceptedShare.actual.get();check(Intent.ACTION_CHOOSER.equals(chooser.getAction()),"Actual share opens a chooser contract");
        Intent send=(Intent)chooser.getParcelableExtra(Intent.EXTRA_INTENT);
        check(send!=null&&Intent.ACTION_SEND.equals(send.getAction())&&Duwm1728CaptionFileStore.MIME.equals(send.getType()),"Chooser wraps SRT ACTION_SEND");
        Uri uri=(Uri)send.getParcelableExtra(Intent.EXTRA_STREAM);
        check(uri!=null&&"content".equals(uri.getScheme())&&(target.getPackageName()+".caption-files").equals(uri.getAuthority()),"Shared SRT uses the app's content provider");
        String id=Duwm1728CaptionFileStore.entryId(target,uri);ownedSnapshots.add(id);
        for(Intent intent:new Intent[]{chooser,send}){
            check((intent.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION)!=0,"Both chooser and send carry a read grant");
            check((intent.getFlags()&Intent.FLAG_GRANT_WRITE_URI_PERMISSION)==0,"Share never grants write access");
            ClipData data=intent.getClipData();check(data!=null&&data.getItemCount()==1&&uri.equals(data.getItemAt(0).getUri()),"ClipData carries the exact shared URI");
        }
        Duwm1728CaptionFileStore.Snapshot snapshot=Duwm1728CaptionFileStore.find(target,id);
        check(snapshot.shared,"Snapshot is retained before being offered to a recipient");
        byte[] bytes=readUri(target,uri);check(bytes.length==snapshot.bytes&&sha256(bytes).equals(snapshot.sha256),"Shared content bytes match frozen snapshot digest and length");
        same(expected,Duwm1728CaptionSrt.parse(Duwm1728CaptionSrt.read(new java.io.ByteArrayInputStream(bytes))),"Actual provider share payload");
        ContentResolver resolver=target.getContentResolver();check(Duwm1728CaptionFileStore.MIME.equals(resolver.getType(uri)),"Provider reports application/x-subrip");
        try(Cursor metadata=resolver.query(uri,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)){
            check(metadata!=null&&metadata.moveToFirst(),"Provider returns document metadata");
            check(snapshot.name.equals(metadata.getString(0))&&metadata.getLong(1)==bytes.length,"Provider filename and size describe the actual file");
        }
        ProviderInfo provider=target.getPackageManager().getProviderInfo(new ComponentName(target,Duwm1728CaptionFileProvider.class),0);
        check(!provider.exported&&provider.grantUriPermissions,"Manifest exposes only explicit URI read grants");
        for(String mode:new String[]{"w","wt","wa","rw","rwt"}){
            boolean denied=false;try(ParcelFileDescriptor ignored=resolver.openFileDescriptor(uri,mode)){}
            catch(IOException|SecurityException|IllegalArgumentException expectedFailure){denied=true;}
            check(denied,"Provider denies write mode "+mode);
        }
        Uri traversal=new Uri.Builder().scheme("content").authority(uri.getAuthority()).appendPath("snapshots").appendPath("../"+id+".srt").build();
        denyRead(target,traversal,"Provider rejects encoded path traversal");
        denyRead(target,uri.buildUpon().appendQueryParameter("file","../private").build(),"Provider rejects query-bearing paths");
        denyRead(target,uri.buildUpon().fragment("private").build(),"Provider rejects fragment-bearing paths");
        check(Arrays.equals(bytes,readUri(target,uri)),"Denied accesses do not alter the shared snapshot");return uri;
    }

    void run(Instrumentation runner,File folder)throws Exception {
        check(Build.VERSION.SDK_INT>=29,"Document fixture uses the real MediaStore.Downloads API");
        Context target=runner.getTargetContext();File source=new File(target.getCacheDir(),"caption-files-"+UUID.randomUUID()+".mp4");
        proof.phase("caption_files.fixture");
        try(InputStream input=runner.getContext().getAssets().open("framing_fixture.mp4");OutputStream output=new FileOutputStream(source)){copy(input,output);}
        String sourceHash=DuwmNativeEvidence.hash(source);List<Duwm1728BroadcastLayout.Cue> original=originalCues(),relative=clipCues(original),absoluteClip=sourceFromClip(relative);
        Activity activity=null;Throwable failure=null;
        try{
            Uri originalDocument=document(target,"original",null),clipDocument=document(target,"clip",null);
            Uri invalidUtf8=document(target,"invalid-utf8",new byte[]{(byte)0xc0,(byte)0xaf});
            activity=openEditor(runner,source);final Activity first=activity;ui(runner,()->seed(first,original));
            click(runner,first.getWindow(),"caption-files-button");Object controller=controller(runner,first);AlertDialog files=dialog(runner,controller,"dialog");
            for(String tag:new String[]{"caption-files-original","caption-files-clip","caption-files-save","caption-files-share","caption-files-import","caption-files-close"})reachable(runner,files.getWindow(),tag);
            // Exercise both real checked-state transitions before exporting the
            // original timeline; the initial ORIGINAL selection alone is idempotent.
            basis(runner,controller,files,true);basis(runner,controller,files,false);capture(runner,folder,"ANDROID-CAPTION-FILES");
            proof.phase("caption_files.save_original.frozen_snapshot");
            Picker frozen=launch(runner,first,controller,files,"caption-files-save",Intent.ACTION_CREATE_DOCUMENT,originalDocument,false,true,false,"SRT SAVED");
            savedBytes(target,originalDocument,folder,"ANDROID-CAPTIONS-ORIGINAL.srt",original);
            byte[] originalBytes=readUri(target,originalDocument);
            check(frozen.snapshot!=null&&frozen.snapshot.sha256.equals(sha256(originalBytes)),"Save writes the frozen snapshot despite a simulated later committed change");
            final Object initialController=controller;
            ui(runner,()->{check(cues(first).size()==1&&cues(first).get(0).text.equals("SIMULATED NEWER COMMITTED DRAFT"),"Snapshot proof did not silently restore the later draft");
                check(originalDocument.equals(field(initialController,"lastSavedUri")),"Successful actual save records its destination URI");});

            proof.phase("caption_files.import_original.cancel_confirmation");EditorState laterDraft=state(runner,first);
            launch(runner,first,controller,files,"caption-files-import",Intent.ACTION_OPEN_DOCUMENT,originalDocument,false,false,false,"REVIEW IMPORT");
            candidate(runner,controller,original);ui(runner,()->laterDraft.unchanged(first,"Unconfirmed original import"));
            AlertDialog confirmation=dialog(runner,controller,"confirmDialog");capture(runner,folder,"ANDROID-CAPTION-FILES-CONFIRM");
            click(runner,confirmation.getWindow(),"caption-files-cancel-import");status(runner,controller,"IMPORT CANCELLED");
            ui(runner,()->{laterDraft.unchanged(first,"Canceled import confirmation");check(field(initialController,"candidate")==null,"Cancel clears the candidate only");});

            proof.phase("caption_files.import_original.apply");
            launch(runner,first,controller,files,"caption-files-import",Intent.ACTION_OPEN_DOCUMENT,originalDocument,false,false,false,"REVIEW IMPORT");
            candidate(runner,controller,original);confirmation=dialog(runner,controller,"confirmDialog");
            click(runner,confirmation.getWindow(),"caption-files-confirm-import");status(runner,controller,"CAPTIONS IMPORTED");
            ui(runner,()->committed(first,source,original,relative));
            check(original.size()==23&&relative.size()==19,"Fixture covers more than twelve cues and four zero intersections");

            proof.phase("caption_files.save_clip.exact_intersection");basis(runner,controller,files,true);EditorState beforeClipSave=state(runner,first);
            launch(runner,first,controller,files,"caption-files-save",Intent.ACTION_CREATE_DOCUMENT,clipDocument,false,false,false,"SRT SAVED");
            savedBytes(target,clipDocument,folder,"ANDROID-CAPTIONS-CLIP.srt",relative);
            ui(runner,()->beforeClipSave.unchanged(first,"Selected-clip save"));
            check(Duwm1728BroadcastLayout.active(relative,0).text.equals("STARTS AT CLIP START"),"Clipping preserves equal-start priority");
            check(Duwm1728BroadcastLayout.active(relative,25).text.equals("CROSSES THE START"),"Underlying cue resumes at the exact clipped end");
            check(Duwm1728BroadcastLayout.active(relative,450).text.equals("EQUAL START LAST"),"Equal original starts keep stable last-cue priority");

            proof.phase("caption_files.cancel_and_failure_isolation");ui(runner,()->((CheckBox)field(first,"approval")).setChecked(true));
            EditorState stable=state(runner,first);
            launch(runner,first,controller,files,"caption-files-save",Intent.ACTION_CREATE_DOCUMENT,null,true,false,false,"SAVE CANCELLED");
            ui(runner,()->stable.unchanged(first,"Canceled save picker"));
            launch(runner,first,controller,files,"caption-files-save",Intent.ACTION_CREATE_DOCUMENT,null,false,false,true,"SAVE FAILED");
            ui(runner,()->{stable.unchanged(first,"Read-only save destination failure");check(clipDocument.equals(field(initialController,"lastSavedUri")),"Failed save cannot replace the last successful destination");});
            launch(runner,first,controller,files,"caption-files-import",Intent.ACTION_OPEN_DOCUMENT,null,true,false,false,"IMPORT CANCELLED");
            ui(runner,()->stable.unchanged(first,"Canceled import picker"));
            launch(runner,first,controller,files,"caption-files-import",Intent.ACTION_OPEN_DOCUMENT,invalidUtf8,false,false,false,"IMPORT FAILED");
            ui(runner,()->{stable.unchanged(first,"Malformed UTF-8 file");check(field(initialController,"candidate")==null&&field(initialController,"confirmDialog")==null,"Invalid file never creates an import candidate");
                check(((String)field(initialController,"statusText")).contains("UTF-8"),"Invalid encoding is reported to the user");});
            capture(runner,folder,"ANDROID-CAPTION-FILES-ERROR");
            // ORIGINAL times are intentionally too long for SELECTED_CLIP here.
            // A wrong basis must reject the complete file, not truncate its cues.
            launch(runner,first,controller,files,"caption-files-import",Intent.ACTION_OPEN_DOCUMENT,originalDocument,false,false,false,"IMPORT FAILED");
            ui(runner,()->stable.unchanged(first,"Original-time file with selected-clip basis"));

            proof.phase("caption_files.share_provider_contract");basis(runner,controller,files,false);
            Picker share=launch(runner,first,controller,files,"caption-files-share",Intent.ACTION_CHOOSER,null,false,false,false,"SRT READY TO SHARE");
            Uri shared=verifyShare(target,share,original);
            ui(runner,()->{stable.unchanged(first,"Shared caption snapshot");check(shared.equals(field(initialController,"lastSharedUri")),"Controller reports the actual shared URI");});

            proof.phase("caption_files.reopen_original_draft");click(runner,files.getWindow(),"caption-files-close");
            ui(runner,first::finish);activity=null;activity=openEditor(runner,source);final Activity restored=activity;
            ui(runner,()->committed(restored,source,original,relative));click(runner,restored.getWindow(),"caption-files-button");
            controller=controller(runner,restored);files=dialog(runner,controller,"dialog");capture(runner,folder,"ANDROID-CAPTION-FILES-RESTORED");

            proof.phase("caption_files.import_selected_clip.explicit_basis");basis(runner,controller,files,true);
            EditorState beforeClipImport=state(runner,restored);
            launch(runner,restored,controller,files,"caption-files-import",Intent.ACTION_OPEN_DOCUMENT,clipDocument,false,false,false,"REVIEW IMPORT");
            candidate(runner,controller,absoluteClip);ui(runner,()->beforeClipImport.unchanged(restored,"Unconfirmed selected-clip import"));
            confirmation=dialog(runner,controller,"confirmDialog");click(runner,confirmation.getWindow(),"caption-files-confirm-import");
            status(runner,controller,"CAPTIONS IMPORTED");ui(runner,()->committed(restored,source,absoluteClip,relative));
            check(absoluteClip.get(0).startMs==300&&absoluteClip.get(0).endMs==350&&absoluteClip.get(17).endMs==1500,"Selected import adds the explicit 300 ms source origin exactly");
            click(runner,files.getWindow(),"caption-files-close");ui(runner,restored::finish);activity=null;
            activity=openEditor(runner,source);final Activity finalEditor=activity;ui(runner,()->committed(finalEditor,source,absoluteClip,relative));
            check(sourceHash.equals(DuwmNativeEvidence.hash(source)),"Native caption file workflow leaves the recorded MP4 byte-identical");

            JSONObject result=new JSONObject().put("status","PASS").put("run_id",proof.runId())
                .put("scope","NATIVE_APP_CAPTION_FILE_FLOW_WITH_INTERCEPTED_DOCUMENT_ACTIVITY_RESULTS")
                .put("source_sha256",sourceHash).put("seed_source_cues",original.size()).put("selected_clip_cues",relative.size())
                .put("trim_start_ms",300).put("trim_end_ms",1500).put("original_srt_bytes",originalBytes.length)
                .put("original_srt_sha256",sha256(originalBytes)).put("clip_srt_sha256",DuwmNativeEvidence.hash(new File(folder,"ANDROID-CAPTIONS-CLIP.srt")))
                .put("frozen_snapshot_sha256",frozen.snapshot.sha256).put("simulated_committed_edit_after_snapshot",true)
                .put("saved_content_resolver_bytes_verified",true).put("cancel_and_failure_preserve_draft_and_approval",true)
                .put("unconfirmed_import_preserves_draft",true).put("original_import_keeps_outside_trim_cues",true)
                .put("selected_import_rebased_exactly",true).put("approval_reset_after_import",true).put("draft_reopened",true)
                .put("share_read_grant_clipdata_and_metadata_verified",true).put("provider_write_and_traversal_denied",true)
                .put("intercepted_intents",intercepted).put("documents_ui_exercised",false).put("external_recipient_exercised",false)
                .put("physical_camera_verified",false).put("live_ai_network_exercised",false)
                .put("fixture_documents_pending_and_owned",true).put("fixture_document_count",ownedDocuments.size());
            try(OutputStream output=new FileOutputStream(new File(folder,"CAPTION-FILES-NATIVE.json"))){output.write(result.toString(2).getBytes(StandardCharsets.UTF_8));}
            proof.phase("caption_files.complete");
        }catch(Exception|Error error){failure=error;throw error;}
        finally{
            Throwable cleanup=null;
            if(activity!=null){final Activity closing=activity;try{ui(runner,closing::finish);}catch(Exception|Error error){cleanup=error;}}
            // Every URI was inserted by this invocation and is deleted exactly
            // once. Never issue a broad Downloads query or a clear-all action.
            for(Uri uri:ownedDocuments)try{check(target.getContentResolver().delete(uri,null,null)==1,"Remove exactly the test-owned document: "+uri);}
                catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            for(String id:ownedSnapshots)try{
                Duwm1728CaptionFileStore.Snapshot snapshot;
                try{snapshot=Duwm1728CaptionFileStore.find(target,id);}catch(IOException alreadyDiscarded){continue;}
                if(snapshot.shared)check(Duwm1728CaptionFileStore.removeShared(target,id),"Remove only this test's shared snapshot");
                else Duwm1728CaptionFileStore.discardUnshared(target,id);
            }catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            if(source.exists()&&!source.delete()){IOException error=new IOException("Cannot remove test-owned caption source");if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            if(cleanup!=null){if(failure!=null)failure.addSuppressed(cleanup);else rethrow(cleanup);}
        }
    }
    private static void copy(InputStream input,OutputStream output)throws IOException {
        byte[] buffer=new byte[65536];int count;while((count=input.read(buffer))!=-1)output.write(buffer,0,count);
    }
    private static String sha256(byte[] bytes)throws Exception {
        StringBuilder hash=new StringBuilder();for(byte value:MessageDigest.getInstance("SHA-256").digest(bytes))hash.append(String.format(Locale.ROOT,"%02x",value&255));return hash.toString();
    }
}
