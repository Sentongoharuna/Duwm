package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import org.json.JSONArray;
import org.json.JSONObject;

/** Wide-glyph synthetic transcript -> actual editor automatic plan/encoder/Gallery.
 * The result boundary is seeded explicitly; these are never recognition words or
 * physical-camera claims. Readiness accepts the phone's actual support outcome. */
final class DuwmAutomaticReadyChecks {
    private static final String WORDS="WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW WWWWWWWWWW TAIL";
    private static final String NOTES="Synthetic wide-glyph display fixture; no source event or speech inferred.";
    private static final String CAPTION_STATUS="SYNTHETIC WIDE-GLYPH TRANSCRIPT • no recognition callback or accuracy claim";
    private final DuwmNativeEvidence proof;private int checks;
    DuwmAutomaticReadyChecks(DuwmNativeEvidence proof){this.proof=proof;}
    int count(){return checks;}
    private void check(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
    private interface Action {void run()throws Exception;}
    private interface Condition {boolean ready()throws Exception;}
    private static void rethrow(Throwable error)throws Exception {
        if(error instanceof InvocationTargetException){rethrow(((InvocationTargetException)error).getTargetException());return;}
        if(error instanceof Error)throw (Error)error;if(error instanceof Exception)throw (Exception)error;if(error!=null)throw new RuntimeException(error);
    }
    private void ui(Instrumentation runner,Action action)throws Exception {
        AtomicReference<Throwable> error=new AtomicReference<>();runner.runOnMainSync(()->{try{action.run();}catch(Throwable failure){error.set(failure);}});rethrow(error.get());
    }
    private static Object field(Object object,String name)throws Exception {java.lang.reflect.Field field=object.getClass().getDeclaredField(name);field.setAccessible(true);return field.get(object);}
    private static void set(Object object,String name,Object value)throws Exception {java.lang.reflect.Field field=object.getClass().getDeclaredField(name);field.setAccessible(true);field.set(object,value);}
    private static Object call(Object object,String name)throws Exception {java.lang.reflect.Method method=object.getClass().getDeclaredMethod(name);method.setAccessible(true);try{return method.invoke(object);}catch(InvocationTargetException error){rethrow(error);return null;}}
    private void await(Instrumentation runner,Condition condition,long timeout,String label)throws Exception {
        AtomicBoolean ready=new AtomicBoolean();long deadline=SystemClock.elapsedRealtime()+timeout;
        do{ui(runner,()->ready.set(condition.ready()));if(ready.get())break;Thread.sleep(75);}while(SystemClock.elapsedRealtime()<deadline);check(ready.get(),label);
    }
    private Activity open(Instrumentation runner,File source)throws Exception {
        Activity editor=runner.startActivitySync(new Intent(runner.getTargetContext(),Duwm1728VideoEditorActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(Duwm1728VideoEditorActivity.EXTRA_VIDEO_URI,Uri.fromFile(source).toString()).putExtra("notes",NOTES).putExtra("report_category","WEATHER"));
        await(runner,()->(Boolean)field(editor,"prepared"),15000,"Actual source editor prepared");return editor;
    }
    private void finish(Instrumentation runner,Activity editor)throws Exception {if(editor==null)return;ui(runner,editor::finish);await(runner,editor::isDestroyed,15000,"Test-owned editor destroyed before reopen or cleanup");}
    private static void copy(InputStream input,OutputStream output)throws IOException {byte[] bytes=new byte[65536];int count;while((count=input.read(bytes))!=-1)output.write(bytes,0,count);}
    private void png(Bitmap image,File folder,String name)throws Exception {try(OutputStream output=new FileOutputStream(new File(folder,name))){check(image.compress(Bitmap.CompressFormat.PNG,100,output),"Save actual decoded frame "+name);}}
    private static List<Duwm1728BroadcastLayout.Cue> supplied(){return Arrays.asList(
        new Duwm1728BroadcastLayout.Cue(137,1737,WORDS),new Duwm1728BroadcastLayout.Cue(1791,1941,"Separate short synthetic update."));}
    private void sameCues(List<Duwm1728BroadcastLayout.Cue> actual,List<Duwm1728BroadcastLayout.Cue> expected,String label){
        check(actual.size()==expected.size(),label+" cue count");for(int index=0;index<actual.size();index++){Duwm1728BroadcastLayout.Cue a=actual.get(index),b=expected.get(index);check(a.startMs==b.startMs&&a.endMs==b.endMs&&a.text.equals(b.text),label+" exact words and milliseconds "+index);}
    }
    private List<Duwm1728ExportRecovery.Entry> sourceReceipts(Context context,Uri source)throws Exception {
        ArrayList<Duwm1728ExportRecovery.Entry> result=new ArrayList<>();for(Duwm1728ExportRecovery.Entry entry:Duwm1728ExportRecovery.list(context))if(source.equals(entry.sourceUri))result.add(entry);return result;
    }
    private JSONObject awaitSaved(Instrumentation runner,Activity editor,Context target,String key)throws Exception {
        AtomicReference<String> state=new AtomicReference<>("");long deadline=SystemClock.elapsedRealtime()+120000;
        do{
            String raw=target.getSharedPreferences(Duwm1728AutomaticProduction.PREFS,Context.MODE_PRIVATE).getString(key,"");JSONObject receipt=raw.isEmpty()?null:new JSONObject(raw);
            if(receipt!=null&&"SAVED_WITH_CAPTIONS".equals(receipt.optString("state"))){await(runner,()->!(Boolean)field(editor,"autoProducing")&&!(Boolean)field(editor,"busy")&&field(editor,"lastBroadcast")!=null,15000,"Actual editor finishes automatic output");return receipt;}
            ui(runner,()->state.set((String)field(editor,"automaticStatus")));check(!"FAILED".equals(state.get())&&!"CANCELLED".equals(state.get())&&!"INTERRUPTED".equals(state.get()),"Automatic wide-glyph output succeeds: "+state.get());Thread.sleep(100);
        }while(SystemClock.elapsedRealtime()<deadline);throw new AssertionError("Automatic-ready fixture did not publish within120 seconds: "+state.get());
    }
    private static final class Drawn {
        final String text;final float x,width;
        Drawn(String value,float left,float measured){text=value;x=left;width=measured;}
    }
    private static final class RecordingCanvas implements Duwm1728BroadcastLayout.Painter {
        final Duwm1728BroadcastCanvas canvas;final ArrayList<Drawn> ticker=new ArrayList<>();final Duwm1728BroadcastLayout.Geometry geometry;
        final float left,available,baseline;float clipLeft,clipWidth;boolean clipped;
        RecordingCanvas(Bitmap image,String composition){
            canvas=new Duwm1728BroadcastCanvas(new Canvas(image));geometry=new Duwm1728BroadcastLayout.Geometry(image.getWidth(),image.getHeight(),false,composition,0);
            boolean compact="COMPACT".equals(geometry.composition);float label=(compact?95:115)*geometry.unit;
            left=geometry.x+label+16*geometry.unit;available=geometry.width-label-30*geometry.unit;baseline=geometry.tickerTop+(compact?27:36)*geometry.unit;
        }
        public void rect(float x,float y,float width,float height,int color,float radius){canvas.rect(x,y,width,height,color,radius);}
        public void line(float x,float y,float xx,float yy,int color,float width){canvas.line(x,y,xx,yy,color,width);}
        public void text(String value,float x,float y,float size,int color,boolean bold){
            if(clipped&&!bold&&color==Duwm1728BroadcastLayout.WHITE&&Math.abs(y-baseline)<.02f&&Math.abs(clipLeft-left)<.02f&&Math.abs(clipWidth-available)<.02f)ticker.add(new Drawn(value,x,measure(value,size,false)));
            canvas.text(value,x,y,size,color,bold);
        }
        public float measure(String value,float size,boolean bold){return canvas.measure(value,size,bold);}
        public Object captionMeasurementKey(){return canvas.captionMeasurementKey();}
        public void clip(float x,float y,float width,float height){clipLeft=x;clipWidth=width;clipped=true;canvas.clip(x,y,width,height);}
        public void unclip(){clipped=false;canvas.unclip();}
    }
    private Duwm1728CaptionPages.Plan pages(RecordingCanvas painter,String text){return Duwm1728CaptionPages.plan(painter,text,("COMPACT".equals(painter.geometry.composition)?20:23)*painter.geometry.unit,false,painter.available,1);}
    private JSONArray nativePages(Duwm1728OverlayRenderer.Spec spec)throws Exception {
        JSONArray facts=new JSONArray();Duwm1728BroadcastLayout.Cue cue=spec.renderedTickers.get(0);long duration=cue.endMs-cue.startMs;
        for(int[] size:new int[][]{{720,800},{720,1280},{1280,720},{960,540}}){
            Bitmap image=Bitmap.createBitmap(size[0],size[1],Bitmap.Config.ARGB_8888);
            try{
                RecordingCanvas measure=new RecordingCanvas(image,spec.composition);Duwm1728CaptionPages.Plan plan=pages(measure,cue.text);StringBuilder ranges=new StringBuilder(),visible=new StringBuilder();
                check(plan.pageCount()>=2,"Wide-glyph fixture exercises native ticker pagination at each tested output size");
                for(int index=0;index<plan.pageCount();index++){
                    Duwm1728CaptionPages.Page page=plan.pages.get(index);check(page.lines.size()==1,"Native ticker page has exactly one row");ranges.append(cue.text,page.startChar,page.endChar);visible.append(page.lines.get(0).replace(" ",""));
                    long start=plan.pageStartMs(index,duration),end=plan.pageEndMs(index,duration);check(end>start,"Native fixture assigns a nonempty page interval");
                    for(long at:new long[]{cue.startMs+start,cue.startMs+end-1}){
                        RecordingCanvas draw=new RecordingCanvas(image,spec.composition);Duwm1728BroadcastLayout.Report report=Duwm1728OverlayRenderer.reportAt(spec,at);check(report.automaticTickerPages,"Actual editor specification enables automatic measured ticker pages");
                        Duwm1728BroadcastLayout.draw(draw,size[0],size[1],report,at);check(draw.ticker.size()==1&&draw.ticker.get(0).text.equals(page.lines.get(0)),"Actual Android renderer draws the expected complete page at exact boundaries");
                        Drawn row=draw.ticker.get(0);check(Math.abs(row.x-draw.left)<.02f&&row.x+row.width<=draw.left+draw.available+.02f,"Actual Android glyph measurement keeps the entire ticker row inside its viewport");
                    }
                }
                check(ranges.toString().equals(cue.text)&&visible.toString().equals(cue.text.replace(" ","")),"Native measured pages conserve every selected excerpt character");
                facts.put(new JSONObject().put("width",size[0]).put("height",size[1]).put("pages",plan.pageCount()).put("minimum_page_ms",plan.minimumPageDurationMs(duration))
                    .put("code_points_per_second",plan.codePointsPerSecond(duration)).put("human_readability_asserted",false));
            }finally{image.recycle();}
        }
        return facts;
    }
    private static boolean white(int pixel){return Color.red(pixel)>160&&Color.green(pixel)>160&&Color.blue(pixel)>160;}
    private double maskScore(Bitmap actual,Bitmap expected,RecordingCanvas region){
        int left=Math.max(0,(int)Math.ceil(region.left)),right=Math.min(actual.getWidth(),(int)Math.floor(region.left+region.available));
        int top=Math.max(0,(int)Math.ceil(region.geometry.tickerTop+2*region.geometry.unit));
        int bottom=Math.min(actual.getHeight(),(int)Math.floor(region.geometry.tickerTop+region.geometry.tickerHeight-2*region.geometry.unit));
        int observed=0,wanted=0,both=0;for(int y=top;y<bottom;y++)for(int x=left;x<right;x++){boolean a=white(actual.getPixel(x,y)),e=white(expected.getPixel(x,y));if(a)observed++;if(e)wanted++;if(a&&e)both++;}
        check(observed>30&&wanted>30,"Decoded and expected ticker regions both contain actual glyph pixels");return 2.0*both/(observed+wanted);
    }
    private JSONObject decodedPages(File video,Duwm1728OverlayRenderer.Spec spec,File folder)throws Exception {
        MediaMetadataRetriever reader=new MediaMetadataRetriever();Bitmap first=null,last=null,expectedFirst=null,expectedLast=null;
        try{
            reader.setDataSource(video.getAbsolutePath());int width=Integer.parseInt(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)),height=Integer.parseInt(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
            check(width==960&&height==540,"Finished automatic video preserves exact source dimensions");check(Math.abs(Long.parseLong(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION))-spec.toMs)<180,"Finished automatic video retains complete source duration");
            check("yes".equalsIgnoreCase(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)),"Finished automatic video retains original audio");
            expectedFirst=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);expectedLast=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
            RecordingCanvas firstDraw=new RecordingCanvas(expectedFirst,spec.composition),lastDraw=new RecordingCanvas(expectedLast,spec.composition);Duwm1728BroadcastLayout.Cue cue=spec.renderedTickers.get(0);long duration=cue.endMs-cue.startMs;
            Duwm1728CaptionPages.Plan plan=pages(firstDraw,cue.text);check(plan.pageCount()>=2&&plan.minimumPageDurationMs(duration)>250,"Codec fixture leaves multiple frames for distinct first and last ticker pages");
            int finalPage=plan.pageCount()-1;long firstAt=cue.startMs+(plan.pageStartMs(0,duration)+plan.pageEndMs(0,duration))/2,lastAt=cue.startMs+(plan.pageStartMs(finalPage,duration)+plan.pageEndMs(finalPage,duration))/2;
            Duwm1728BroadcastLayout.draw(firstDraw,width,height,Duwm1728OverlayRenderer.reportAt(spec,firstAt),firstAt);Duwm1728BroadcastLayout.draw(lastDraw,width,height,Duwm1728OverlayRenderer.reportAt(spec,lastAt),lastAt);
            first=reader.getFrameAtTime(firstAt*1000,MediaMetadataRetriever.OPTION_CLOSEST);last=reader.getFrameAtTime(lastAt*1000,MediaMetadataRetriever.OPTION_CLOSEST);check(first!=null&&last!=null,"Actual published MP4 decodes both selected ticker pages");
            png(first,folder,"ANDROID-AUTO-READY-TICKER-FIRST.png");png(last,folder,"ANDROID-AUTO-READY-TICKER-LAST.png");
            double firstCorrect=maskScore(first,expectedFirst,firstDraw),firstWrong=maskScore(first,expectedLast,firstDraw),lastCorrect=maskScore(last,expectedLast,lastDraw),lastWrong=maskScore(last,expectedFirst,lastDraw);
            check(firstCorrect>.72&&lastCorrect>.72,"Decoded ticker glyph masks match actual Android expected pages: "+firstCorrect+", "+lastCorrect);
            check(firstCorrect>firstWrong+.12&&lastCorrect>lastWrong+.12,"Decoded first and last ticker pages have distinct expected content rather than one repeated frame");
            check(plan.pages.get(finalPage).lines.get(0).endsWith("TAIL"),"Actual last encoded ticker page contains the complete source-excerpt tail");
            return new JSONObject().put("width",width).put("height",height).put("pages",plan.pageCount()).put("first_frame_requested_ms",firstAt).put("last_frame_requested_ms",lastAt)
                .put("first_expected_rows",new JSONArray(plan.pages.get(0).lines)).put("last_expected_rows",new JSONArray(plan.pages.get(finalPage).lines))
                .put("first_correct_glyph_dice",firstCorrect).put("first_wrong_page_glyph_dice",firstWrong).put("last_correct_glyph_dice",lastCorrect).put("last_wrong_page_glyph_dice",lastWrong)
                .put("comparison","White-glyph masks inside actual ticker viewport; Android shared renderer compared with decoded MP4, not OCR")
                .put("minimum_page_ms",plan.minimumPageDurationMs(duration)).put("code_points_per_second",plan.codePointsPerSecond(duration)).put("human_readability_asserted",false);
        }finally{reader.release();if(first!=null)first.recycle();if(last!=null)last.recycle();if(expectedFirst!=null)expectedFirst.recycle();if(expectedLast!=null)expectedLast.recycle();}
    }
    private void tracks(File video)throws Exception {
        MediaExtractor extractor=new MediaExtractor();try{extractor.setDataSource(video.getAbsolutePath());boolean avc=false,aac=false;
            for(int index=0;index<extractor.getTrackCount();index++){MediaFormat format=extractor.getTrackFormat(index);String mime=format.getString(MediaFormat.KEY_MIME);if("video/avc".equals(mime))avc=true;
                if("audio/mp4a-latm".equals(mime)){aac=true;check(format.getInteger(MediaFormat.KEY_SAMPLE_RATE)==48000&&format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)==1,"Original48 kHz mono AAC format is retained");}}
            check(avc&&aac,"Actual output has AVC video and retained AAC audio");
        }finally{extractor.release();}
    }
    private static boolean hasAddressInput(View view){if(view instanceof EditText)return true;if(view instanceof ViewGroup){ViewGroup group=(ViewGroup)view;for(int index=0;index<group.getChildCount();index++)if(hasAddressInput(group.getChildAt(index)))return true;}return false;}
    private JSONObject speechHelp(Instrumentation runner,Activity editor)throws Exception {
        proof.phase("automatic_ready.speech_help");
        await(runner,()->{View help=editor.getWindow().getDecorView().findViewWithTag("broadcast-editor-auto-help");if(help==null)return false;
            help.requestRectangleOnScreen(new Rect(0,0,help.getWidth(),help.getHeight()),true);Rect visible=new Rect();int minimum=Math.round(48*help.getResources().getDisplayMetrics().density);
            return help.isEnabled()&&help.isShown()&&help.getGlobalVisibleRect(visible)&&visible.width()>=minimum-1&&visible.height()>=minimum-1;},3000,"Actual AI HELP button is reachable with48 dp target");
        ui(runner,()->check(editor.getWindow().getDecorView().findViewWithTag("broadcast-editor-auto-help").performClick(),"Actual AI HELP opens built-in help"));
        await(runner,()->{AlertDialog dialog=(AlertDialog)field(editor,"automaticHelpDialog");if(dialog==null||!dialog.isShowing())return false;
            TextView button=dialog.getWindow().getDecorView().findViewWithTag("broadcast-speech-readiness-check");return button!=null&&button.isEnabled()&&field(editor,"speechReadiness")==null;},15000,"Phone readiness check completes or honestly reports unavailable within its bounded deadline");
        AtomicReference<String> result=new AtomicReference<>();ui(runner,()->{
            AlertDialog dialog=(AlertDialog)field(editor,"automaticHelpDialog");View content=dialog.getWindow().getDecorView().findViewWithTag("broadcast-auto-help-content");check(content!=null&&!hasAddressInput(content),"Built-in help asks for no server address, endpoint or API key");
            TextView status=dialog.getWindow().getDecorView().findViewWithTag("broadcast-speech-readiness-status");result.set(status.getText().toString());
            check(result.get().startsWith("READY TO TRY CAPTIONS")||result.get().startsWith("MODEL DOWNLOAD PENDING")||result.get().startsWith("LANGUAGE MODEL NOT INSTALLED")||result.get().startsWith("ON-DEVICE CAPTIONS UNAVAILABLE")||result.get().startsWith("CAPTION SUPPORT NOT CONFIRMED"),"Help displays an actual bounded readiness outcome without requiring recognition availability");
            TextView again=dialog.getWindow().getDecorView().findViewWithTag("broadcast-speech-readiness-check");again.requestRectangleOnScreen(new Rect(0,0,again.getWidth(),again.getHeight()),true);check(again.performClick(),"Actual CHECK CAPTIONS control can start another support query");
            check(dialog.getButton(AlertDialog.BUTTON_NEGATIVE).performClick(),"Actual CLOSE control dismisses help during or after the support query");
        });
        await(runner,()->field(editor,"automaticHelpDialog")==null&&field(editor,"speechReadiness")==null,3000,"Dismissing help releases its readiness session");
        return new JSONObject().put("actual_displayed_status",result.get()).put("no_address_input",true).put("recheck_control_used",true).put("dismissal_session_cleanup_verified",true)
            .put("speech_recognition_executed_by_this_check",false).put("model_download_started_by_this_check",false);
    }
    private void manualMovement(Duwm1728OverlayRenderer.Spec spec){
        Bitmap image=Bitmap.createBitmap(960,540,Bitmap.Config.ARGB_8888);try{
            RecordingCanvas a=new RecordingCanvas(image,spec.composition),b=new RecordingCanvas(image,spec.composition);
            Duwm1728BroadcastLayout.Report first=Duwm1728OverlayRenderer.reportAt(spec,100),last=Duwm1728OverlayRenderer.reportAt(spec,500);check(!first.automaticTickerPages&&!last.automaticTickerPages,"Actual manual takeover switches off automatic ticker pagination");
            Duwm1728BroadcastLayout.draw(a,960,540,first,100);Duwm1728BroadcastLayout.draw(b,960,540,last,500);
            check(!a.ticker.isEmpty()&&!b.ticker.isEmpty()&&a.ticker.get(0).text.equals(b.ticker.get(0).text),"Manual ticker draws the original complete replacement text");
            check(Math.abs((a.ticker.get(0).x-b.ticker.get(0).x)-15)<.03f,"Actual manual marquee retains its75px/s scaled movement");
        }finally{image.recycle();}
    }
    @SuppressWarnings("unchecked")
    void run(Instrumentation runner,File folder)throws Exception {
        Context target=runner.getTargetContext();File source=new File(target.getCacheDir(),"auto-ready-"+UUID.randomUUID()+".mp4");Uri sourceUri=Uri.fromFile(source);
        String sourceKey=Duwm1728CaptureTelemetry.storageKey(sourceUri),receiptKey=Duwm1728AutomaticProduction.receiptKey(sourceKey);Set<Uri> galleryOwned=new LinkedHashSet<>();Set<String> recoveryOwned=new LinkedHashSet<>();Activity editor=null;JSONObject result=null;Throwable failure=null;
        proof.phase("automatic_ready.fixture");try(InputStream input=runner.getContext().getAssets().open("framing_fixture.mp4");OutputStream output=new FileOutputStream(source)){copy(input,output);}String sourceHash=DuwmNativeEvidence.hash(source);
        try{
            proof.phase("automatic_ready.supplied_transcript_seam");editor=open(runner,source);final Activity first=editor;AtomicReference<Long> duration=new AtomicReference<>();
            ui(runner,()->{duration.set((Long)field(first,"durationMs"));check(Math.abs(duration.get()-2000)<=80,"Independent source player identifies two-second fixture");check(!(Boolean)field(first,"autoProducing")&&!(Boolean)field(first,"busy"),"Fixture is idle before explicitly seeded synthetic result");
                List<Duwm1728BroadcastLayout.Cue> cues=(List<Duwm1728BroadcastLayout.Cue>)field(first,"automaticCues");cues.clear();cues.addAll(supplied());set(first,"automaticCaptionStatus",CAPTION_STATUS);set(first,"autoProducing",true);call(first,"finishAutomaticPlan");});
            JSONObject receipt=awaitSaved(runner,first,target,receiptKey);Uri gallery=Uri.parse(receipt.getString("uri"));galleryOwned.add(gallery);check("content".equals(gallery.getScheme())&&"media".equals(gallery.getAuthority()),"Real automatic-ready video is published to Gallery");check(CAPTION_STATUS.equals(receipt.getString("caption_status")),"Receipt explicitly identifies synthetic supplied words");
            Duwm1728AutomaticProduction.Plan expected=Duwm1728AutomaticProduction.plan(duration.get(),supplied(),CAPTION_STATUS,NOTES);AtomicReference<Duwm1728OverlayRenderer.Spec> selected=new AtomicReference<>();
            ui(runner,()->{Duwm1728OverlayRenderer.Spec spec=(Duwm1728OverlayRenderer.Spec)field(first,"previewSpec");selected.set(spec);check(spec.fromMs==0&&spec.toMs==duration.get()&&"ORIGINAL".equals(spec.ratio)&&"FIT".equals(spec.frameMode)&&"COMPACT".equals(spec.composition),"Actual automatic editor retains full source and existing presentation defaults");
                sameCues(spec.automaticCaptions,supplied(),"Actual editor source captions");sameCues(spec.automaticTickers,expected.tickers,"Actual editor source-time ticker excerpts");check(spec.automaticTickers.get(0).text.endsWith("TAIL"),"Complete test excerpt includes intended wide-glyph tail");});
            Duwm1728OverlayRenderer.Spec spec=selected.get();check(Duwm1728OverlayRenderer.reportAt(spec,137).automaticTickerPages,"Automatic flag propagates from real editor to production report");
            check(Duwm1728BroadcastLayout.active(spec.renderedTickers,136)==null&&Duwm1728BroadcastLayout.active(spec.renderedTickers,137)!=null&&Duwm1728BroadcastLayout.active(spec.renderedTickers,1737)==null&&Duwm1728BroadcastLayout.active(spec.renderedTickers,1791)!=null,"Automatic source boundaries and real silence gap remain exact");
            byte[] srt=Duwm1728CaptionSrt.exportCues(supplied(),Duwm1728CaptionSrt.TimeBase.ORIGINAL,duration.get(),0,duration.get());check(Arrays.equals(srt,Duwm1728CaptionSrt.exportCues(spec.automaticCaptions,Duwm1728CaptionSrt.TimeBase.ORIGINAL,duration.get(),0,duration.get())),"Automatic ticker display leaves source SRT bytes unchanged");
            proof.phase("automatic_ready.native_ticker_pages");JSONArray pageFacts=nativePages(spec);File artifact=new File(folder,"ANDROID-AUTO-READY.mp4");try(InputStream input=target.getContentResolver().openInputStream(gallery);OutputStream output=new FileOutputStream(artifact)){check(input!=null,"Read actual Gallery output");copy(input,output);}
            String outputHash=DuwmNativeEvidence.hash(artifact);List<Duwm1728ExportRecovery.Entry> entries=sourceReceipts(target,sourceUri);check(entries.size()==1,"One source produces one real export receipt");Duwm1728ExportRecovery.Entry entry=entries.get(0);recoveryOwned.add(entry.id);
            check(entry.state==Duwm1728ExportRecovery.State.PUBLISHED&&gallery.equals(entry.publishedUri)&&outputHash.equals(entry.sha256)&&artifact.length()==entry.bytes,"Durable receipt identifies exact published MP4 bytes");
            proof.phase("automatic_ready.decoded_ticker_pages");JSONObject decoded=decodedPages(artifact,spec,folder);tracks(artifact);finish(runner,first);editor=null;
            proof.phase("automatic_ready.trim_and_manual");editor=open(runner,source);final Activity reopened=editor;ui(runner,()->{
                Duwm1728OverlayRenderer.Spec restored=(Duwm1728OverlayRenderer.Spec)field(reopened,"previewSpec");sameCues(restored.automaticTickers,expected.tickers,"Reopened automatic ticker document");check(Duwm1728OverlayRenderer.reportAt(restored,137).automaticTickerPages,"Actual saved draft restores automatic page policy without a new export");
                set(reopened,"updatingFields",true);try{((EditText)field(reopened,"from")).setText("0.300");((EditText)field(reopened,"to")).setText("1.700");}finally{set(reopened,"updatingFields",false);}call(reopened,"refresh");
                Duwm1728OverlayRenderer.Spec trimmed=(Duwm1728OverlayRenderer.Spec)field(reopened,"previewSpec");sameCues(trimmed.automaticTickers,expected.tickers,"Trim retains original source ticker document");sameCues(trimmed.automaticCaptions,supplied(),"Trim retains original source captions");
                check(trimmed.renderedTickers.size()==1&&trimmed.renderedTickers.get(0).startMs==0&&trimmed.renderedTickers.get(0).endMs==1400&&trimmed.renderedTickers.get(0).text.equals(expected.tickers.get(0).text),"Trim intersects/rebases exact ticker milliseconds while preserving complete selected excerpt");
                check(Duwm1728OverlayRenderer.reportAt(trimmed,0).automaticTickerPages,"Trimmed automatic report keeps measured display policy");
                ((EditText)field(reopened,"ticker")).setText("00:00=Explicit manual replacement WWWWWW");Duwm1728OverlayRenderer.Spec manual=(Duwm1728OverlayRenderer.Spec)field(reopened,"previewSpec");check(manual.automaticTickers.isEmpty()&&manual.renderedTickers.size()==1,"Actual manual ticker edit takes over structured automatic excerpts");sameCues(manual.automaticCaptions,supplied(),"Manual ticker takeover retains complete source captions");manualMovement(manual);
            });
            JSONObject help=speechHelp(runner,reopened);check(sourceHash.equals(DuwmNativeEvidence.hash(source)),"All automatic rendering, trim, manual takeover and help leave original MP4 bytes exact");check(sourceReceipts(target,sourceUri).size()==1,"Reopen, trim and support checks do not create duplicate exports");
            result=new JSONObject().put("status","PASS").put("run_id",proof.runId()).put("scope","SYNTHETIC_WIDE_GLYPH_TRANSCRIPT_REAL_EDITOR_AUTOMATIC_ENCODER_GALLERY_AND_SUPPORT_HELP")
                .put("transcript_supplied_by_test",true).put("recognition_result_boundary_seeded",true).put("recognition_callbacks_injected",false).put("on_device_recognition_accuracy_verified",false).put("physical_camera_verified",false)
                .put("source_sha256",sourceHash).put("output_sha256",outputHash).put("output_bytes",artifact.length()).put("gallery_uri",gallery.toString()).put("caption_status",CAPTION_STATUS)
                .put("source_excerpt_words_and_times_exact",true).put("source_srt_bytes_unchanged",true).put("trim_rebase_and_draft_reopen_verified",true).put("manual_marquee_preserved",true)
                .put("native_canvas_ticker_pages",pageFacts).put("decoded_mp4_ticker_pages",decoded).put("built_in_help",help).put("display_page_timing_is_derived",true).put("human_readability_asserted",false);
        }catch(Exception|Error error){failure=error;throw error;}
        finally{
            Throwable cleanup=null;try{finish(runner,editor);}catch(Exception|Error error){cleanup=error;}
            try{for(Duwm1728ExportRecovery.Entry entry:sourceReceipts(target,sourceUri)){recoveryOwned.add(entry.id);if(entry.publishedUri!=null)galleryOwned.add(entry.publishedUri);}}catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            for(Uri uri:galleryOwned)try{check(target.getContentResolver().delete(uri,null,null)==1,"Delete exactly this test-owned Gallery output");}catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            for(String id:recoveryOwned)try{Duwm1728ExportRecovery.discard(target,id);}catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            try{
                check(target.getSharedPreferences(Duwm1728AutomaticProduction.PREFS,Context.MODE_PRIVATE).edit().remove(receiptKey).commit(),"Remove only this source's automatic receipt");
                check(target.getSharedPreferences("duwm_production_drafts",Context.MODE_PRIVATE).edit().remove(sourceKey).commit(),"Remove only test source draft");
                check(target.getSharedPreferences("duwm1728_saved_broadcasts",Context.MODE_PRIVATE).edit().remove(sourceKey).commit(),"Remove only test source last-output shortcut");
                SharedPreferences index=target.getSharedPreferences("duwm1726_gallery_exports",Context.MODE_PRIVATE);StringBuilder retained=new StringBuilder();for(String row:index.getString("items","").split("\n")){int separator=row.indexOf('\t');boolean own=false;
                    if(separator>=0)for(Uri uri:galleryOwned)if(uri.toString().equals(row.substring(0,separator))){own=true;break;}if(!row.isEmpty()&&!own){if(retained.length()>0)retained.append('\n');retained.append(row);}}
                check(index.edit().putString("items",retained.toString()).commit(),"Remove only test-owned Gallery index rows");
            }catch(Exception|Error error){if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}
            if(source.exists()&&!source.delete()){IOException error=new IOException("Cannot remove test-owned automatic-ready fixture");if(cleanup==null)cleanup=error;else cleanup.addSuppressed(error);}if(cleanup!=null){if(failure!=null)failure.addSuppressed(cleanup);else rethrow(cleanup);}
        }
        check(result!=null,"Automatic-ready checks and owned-fixture cleanup completed");result.put("checks",checks).put("test_owned_gallery_and_receipt_cleanup_complete",true);
        try(OutputStream output=new FileOutputStream(new File(folder,"AUTO-READY-NATIVE.json"))){output.write(result.toString(2).getBytes(StandardCharsets.UTF_8));}proof.phase("automatic_ready.complete");
    }
}
