package com.sentongoharuna.worldsituationroom;

import java.nio.charset.StandardCharsets;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** Pure saved-video state rules, shared by Android playback and host verification. */
public final class Duwm1728BroadcastReviewState {
    private Duwm1728BroadcastReviewState() {}

    /** Use the complete content URI, including its authority, path, and query. */
    public static String key(String contentUri) {
        if(contentUri==null)throw new IllegalArgumentException("A saved content URI is required");
        try {
            URI parsed=new URI(contentUri);
            if(!"content".equals(parsed.getScheme())||parsed.getRawAuthority()==null||parsed.getRawAuthority().isEmpty())
                throw new IllegalArgumentException("A saved content URI is required");
        }catch(URISyntaxException invalid){throw new IllegalArgumentException("A saved content URI is required",invalid);}
        try {
            byte[] digest=MessageDigest.getInstance("SHA-256").digest(contentUri.getBytes(StandardCharsets.UTF_8));
            char[] alphabet="0123456789abcdef".toCharArray();
            StringBuilder key=new StringBuilder("video_");
            for(byte value:digest){key.append(alphabet[(value&255)>>>4]);key.append(alphabet[value&15]);}
            return key.toString();
        }catch(NoSuchAlgorithmException impossible){throw new IllegalStateException(impossible);}
    }

    /** Restart completed clips and the final 250 ms (at most 5% of a short clip). */
    public static int resumePosition(long positionMs,long durationMs) {
        if(positionMs<0||durationMs<1)return 0;
        long tail=Math.min(250L,Math.max(1L,durationMs/20L));
        if(positionMs>=durationMs-tail)return 0;
        return (int)Math.min(Integer.MAX_VALUE,positionMs);
    }
}
