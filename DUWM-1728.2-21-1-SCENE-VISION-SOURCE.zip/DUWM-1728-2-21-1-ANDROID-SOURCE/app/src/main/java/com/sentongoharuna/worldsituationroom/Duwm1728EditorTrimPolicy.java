package com.sentongoharuna.worldsituationroom;

/** Millisecond trim bounds for playhead marks; the source recording is never changed. */
public final class Duwm1728EditorTrimPolicy {
    private Duwm1728EditorTrimPolicy() {}
    public static final class Range {
        public final long fromMs,toMs;
        private Range(long from,long to){fromMs=from;toMs=to;}
    }
    private static long clamp(long value,long low,long high){return Math.max(low,Math.min(high,value));}
    private static Range valid(long from,long to,long duration){
        if(duration<=0)throw new IllegalArgumentException("The recording has no valid duration");
        long start=clamp(from,0,duration-1);
        return new Range(start,clamp(to,start+1,duration));
    }
    public static Range reset(long duration){return valid(0,duration,duration);}
    public static Range markIn(long from,long to,long playhead,long duration){
        Range current=valid(from,to,duration);
        return new Range(clamp(playhead,0,current.toMs-1),current.toMs);
    }
    public static Range markOut(long from,long to,long playhead,long duration){
        Range current=valid(from,to,duration);
        return new Range(current.fromMs,clamp(playhead,current.fromMs+1,duration));
    }
}
