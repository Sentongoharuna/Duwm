package com.sentongoharuna.worldsituationroom;

import java.util.ArrayList;
import java.util.Locale;

/** Strict timecoded SRT import. The source file must already contain transcript text and times. */
public final class Duwm1728SubtitleImport {
    private Duwm1728SubtitleImport(){}
    /** Compatibility entry point for exact source-video cues; all new and old
     * callers share the same strict, lossless SRT parser and 20000-cue limit.
     */
    public static java.util.List<Duwm1728BroadcastLayout.Cue> parseSrtCues(String text){
        return Duwm1728CaptionSrt.parse(text);
    }
    /** Compatibility helper only. New editor uses parseSrtCues and retains exact end times. */
    @Deprecated public static String convertSrt(String text){
        ArrayList<String> result=new ArrayList<>();
        for(Duwm1728BroadcastLayout.Cue c:parseSrtCues(text))result.add(String.format(Locale.US,
            "%02d:%02d=%s",c.startMs/60000,(c.startMs/1000)%60,c.text.replace(';',',').replace('=','-')));
        return String.join(";",result);
    }
}
