package com.sentongoharuna.worldsituationroom;

import java.util.Collections;
import java.util.List;

/** Static, measured presentation of an already selected automatic headline.
 * Source selection and its intentional excerpt ellipsis belong to the automatic
 * plan. This display step never invents words or adds another ellipsis. */
public final class Duwm1728HeadlineFit {
    private static final int MAXIMUM_ATTEMPTS=32;
    private Duwm1728HeadlineFit(){}
    public static final class Plan {
        public final String text;
        public final List<String> lines;
        public final float textSize;
        public final boolean compactWrapped;
        public final int attempts;
        private Plan(Duwm1728CaptionPages.Plan measured,boolean wrapped,int count){
            text=measured.text;lines=measured.pages.isEmpty()?Collections.emptyList():measured.pages.get(0).lines;
            textSize=measured.textSize;compactWrapped=wrapped;attempts=count;
        }
    }
    /** Retain the existing size/rows when all selected text fits. Overflow uses
     * at most two static rows; compact callers reserve separate byline space.
     * The existing measured page planner protects Unicode clusters and caches
     * only immutable font/locale identities. No page timing is used here. */
    public static Plan plan(Duwm1728BroadcastLayout.Painter painter,String source,float originalSize,
                            float wrappedSize,float width,int originalRows){
        if(originalRows<1||originalRows>2||!Float.isFinite(wrappedSize)||wrappedSize<=0)
            throw new IllegalArgumentException("Invalid headline layout");
        String text=source==null?"":source;
        Duwm1728CaptionPages.Plan measured=Duwm1728CaptionPages.plan(painter,text,originalSize,true,width,originalRows);
        if(measured.pageCount()<=1)return new Plan(measured,false,1);
        float size=Math.min(originalSize,wrappedSize);
        for(int attempt=1;attempt<=MAXIMUM_ATTEMPTS;attempt++){
            measured=Duwm1728CaptionPages.plan(painter,text,size,true,width,2);
            if(measured.pageCount()<=1)return new Plan(measured,originalRows==1,attempt+1);
            size*=.88f;
        }
        // Bounded failure is preferable to silently dropping selected words.
        // Valid automatic excerpts are at most63 UTF-16 characters, well below
        // the shared planner's500-character defensive input limit.
        throw new IllegalArgumentException("Automatic headline cannot fit the available panel");
    }
}
