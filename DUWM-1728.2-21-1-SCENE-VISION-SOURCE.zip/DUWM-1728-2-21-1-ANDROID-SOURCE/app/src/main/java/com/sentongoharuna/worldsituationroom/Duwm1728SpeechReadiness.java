package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.speech.RecognitionListener;
import android.speech.RecognitionSupport;
import android.speech.RecognitionSupportCallback;
import android.speech.SpeechRecognizer;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

/** A read-only, single-use query of the phone service's recorded-file support.
 * Uses the transcription intent and an un-fed audio pipe; never records, listens,
 * reads a source video or downloads a model. A reported capability is not an
 * executed recognition result and does not verify word timing accuracy. */
public final class Duwm1728SpeechReadiness implements AutoCloseable {
    public interface Listener {void done(Result result);}
    public static final class Result {
        public final String requestedLanguage,selectedLanguage,status,recordingSupport,message;
        public final boolean recordedFileSupported;
        private Result(String requested,String selected,String status,String support,String message){
            requestedLanguage=requested==null?"":requested;selectedLanguage=selected==null?"":selected;
            this.status=status;recordingSupport=support;this.message=message;
            recordedFileSupported=Duwm1728SpeechLanguagePolicy.CONFIRMED.equals(support);
        }
        private Result(Duwm1728SpeechLanguagePolicy.Decision decision){
            this(decision.requestedLanguage,decision.selectedLanguage,decision.status,decision.recordingSupport,decision.message);
        }
    }
    private final Context context;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final AtomicBoolean started=new AtomicBoolean(),finished=new AtomicBoolean();
    private SpeechRecognizer recognizer;
    private ParcelFileDescriptor readPipe,writePipe;
    private Duwm1728SpeechLanguagePolicy.SupportFlow flow;
    private Listener listener;
    private Runnable timeout;
    private long deadline;
    public Duwm1728SpeechReadiness(Context context){this.context=context.getApplicationContext();}

    /** Call on the UI thread. Completion is also delivered on that thread.
     * Closing the query suppresses completion and releases both descriptors. */
    public void check(Listener listener){
        if(Looper.myLooper()!=Looper.getMainLooper())throw new IllegalStateException("Check caption readiness on the UI thread");
        if(listener==null)throw new IllegalArgumentException("A readiness listener is required");
        if(!started.compareAndSet(false,true)||finished.get())return;
        this.listener=listener;
        String requested=Duwm1728RecordedAudioTranscriber.deviceLanguage();
        if(Build.VERSION.SDK_INT<34){
            complete(new Result(requested,"",Duwm1728SpeechLanguagePolicy.UNAVAILABLE,Duwm1728SpeechLanguagePolicy.UNAVAILABLE,
                    "Timed recorded-file captions need Android 14 or newer. Automatic video can still finish without captions."));return;
        }
        if(!Duwm1728RecordedAudioTranscriber.canAttempt(context)){
            complete(new Result(requested,"",Duwm1728SpeechLanguagePolicy.UNAVAILABLE,Duwm1728SpeechLanguagePolicy.UNAVAILABLE,
                    "No on-device speech service is available on this phone. Automatic video can still finish without captions."));return;
        }
        flow=new Duwm1728SpeechLanguagePolicy.SupportFlow(requested,Duwm1728RecordedAudioTranscriber::likelyScript);
        Duwm1728SpeechLanguagePolicy.Decision first=flow.begin();
        if(first.action!=Duwm1728SpeechLanguagePolicy.Action.CHECK){complete(new Result(first));return;}
        deadline=SystemClock.elapsedRealtime()+10000;
        try{
            ParcelFileDescriptor[] pair=ParcelFileDescriptor.createPipe();readPipe=pair[0];writePipe=pair[1];
            recognizer=SpeechRecognizer.createOnDeviceSpeechRecognizer(context);
            // Register before any service command, even for a support-only query.
            recognizer.setRecognitionListener(new RecognitionListener(){
                @Override public void onReadyForSpeech(Bundle b){}
                @Override public void onBeginningOfSpeech(){}
                @Override public void onRmsChanged(float rms){}
                @Override public void onBufferReceived(byte[] bytes){}
                @Override public void onEndOfSpeech(){}
                @Override public void onError(int error){fail(flow.checkNumber(),"The phone could not check caption readiness (service error "+error+")");}
                @Override public void onResults(Bundle b){}
                @Override public void onPartialResults(Bundle b){}
                @Override public void onEvent(int type,Bundle b){}
            });
            query(first);
        }catch(Exception unavailable){fail(flow.checkNumber(),"Cannot inspect on-device captions: "+message(unavailable));}
    }
    private void query(Duwm1728SpeechLanguagePolicy.Decision decision){
        if(finished.get()||decision.action==Duwm1728SpeechLanguagePolicy.Action.IGNORE)return;
        if(decision.action!=Duwm1728SpeechLanguagePolicy.Action.CHECK){complete(new Result(decision));return;}
        final int check=decision.checkNumber;
        long remaining=deadline-SystemClock.elapsedRealtime();
        if(remaining<=0){fail(check,"The phone did not confirm caption readiness within 10 seconds");return;}
        final long checkDeadline=Math.min(deadline,SystemClock.elapsedRealtime()+5000);
        try{
            final Intent request=Duwm1728RecordedAudioTranscriber.recordedFileRequest(decision.selectedLanguage,readPipe);
            if(timeout!=null)main.removeCallbacks(timeout);
            timeout=()->fail(check,"The phone did not answer its recorded-file caption check within 5 seconds");
            main.postDelayed(timeout,Math.max(0,checkDeadline-SystemClock.elapsedRealtime()));
            recognizer.checkRecognitionSupport(request,command->main.post(command),new RecognitionSupportCallback(){
                @Override public void onSupportResult(RecognitionSupport support){
                    if(finished.get())return;
                    if(SystemClock.elapsedRealtime()>=checkDeadline){fail(check,"The phone's caption support response arrived after its bounded check expired");return;}
                    if(support==null){onError(SpeechRecognizer.ERROR_CANNOT_CHECK_SUPPORT);return;}
                    try{
                        Duwm1728SpeechLanguagePolicy.Decision next=flow.support(check,support.getInstalledOnDeviceLanguages(),
                                support.getPendingOnDeviceLanguages(),support.getSupportedOnDeviceLanguages());
                        if(next.action==Duwm1728SpeechLanguagePolicy.Action.IGNORE)return;
                        if(timeout!=null)main.removeCallbacks(timeout);
                        if(next.action==Duwm1728SpeechLanguagePolicy.Action.CHECK)query(next);
                        else complete(new Result(next));
                    }catch(Exception invalid){fail(check,"The phone returned an unusable caption support response: "+message(invalid));}
                }
                @Override public void onError(int error){fail(check,"Recorded-file caption support could not be confirmed (service error "+error+")");}
            });
        }catch(Exception unavailable){fail(check,"Cannot check recorded-file captions: "+message(unavailable));}
    }
    private void fail(int check,String message){
        if(finished.get()||flow==null)return;
        Duwm1728SpeechLanguagePolicy.Decision failure=flow.error(check,message);
        if(failure.action!=Duwm1728SpeechLanguagePolicy.Action.IGNORE)complete(new Result(failure));
    }
    private void complete(Result result){
        if(!finished.compareAndSet(false,true))return;
        Listener completed=listener;cleanup();
        if(completed!=null)completed.done(result);
    }
    private void cleanup(){
        if(timeout!=null)main.removeCallbacks(timeout);
        listener=null;if(flow!=null)flow.cancel();
        if(readPipe!=null){try{readPipe.close();}catch(IOException ignored){}readPipe=null;}
        if(writePipe!=null){try{writePipe.close();}catch(IOException ignored){}writePipe=null;}
        if(recognizer!=null){try{recognizer.destroy();}catch(RuntimeException ignored){}recognizer=null;}
    }
    private static String message(Exception failure){String text=failure.getMessage();return text==null?failure.getClass().getSimpleName():text;}
    @Override public void close(){
        if(!finished.compareAndSet(false,true))return;
        if(Looper.myLooper()==Looper.getMainLooper())cleanup();else main.post(this::cleanup);
    }
}
