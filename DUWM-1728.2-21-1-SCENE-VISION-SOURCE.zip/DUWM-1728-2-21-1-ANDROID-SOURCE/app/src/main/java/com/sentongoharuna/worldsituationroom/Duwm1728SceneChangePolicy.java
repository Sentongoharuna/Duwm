package com.sentongoharuna.worldsituationroom;

/** Bounded image-difference trigger. This never names objects or generates text.
 * A large appearance change expires a previous model observation while the
 * real image model prepares a replacement. Small noise does not cancel work. */
public final class Duwm1728SceneChangePolicy {
    private Duwm1728SceneChangePolicy() {}

    public static boolean changed(int[] previous, int[] current) {
        if (previous == null || current == null || previous.length == 0
                || previous.length != current.length) return false;
        long total = 0;
        int changed = 0;
        for (int i = 0; i < previous.length; i++) {
            int a = previous[i], b = current[i];
            int difference = (Math.abs(((a >>> 16) & 255) - ((b >>> 16) & 255))
                    + Math.abs(((a >>> 8) & 255) - ((b >>> 8) & 255))
                    + Math.abs((a & 255) - (b & 255))) / 3;
            total += difference;
            if (difference >= 55) changed++;
        }
        return total >= 45L * previous.length && changed * 100L >= previous.length * 55L;
    }
}
