package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;

/** 1715: app-wide formal visual contract. Applied on activity resume and never
 * replaces a map, media player, source layer, globe, or the content hierarchy.
 * Android's global theme carries the same typography for newly created views.
 */
public final class Duwm1715FormalUi {
    private Duwm1715FormalUi() {}
    private static final Typeface REGULAR = Typeface.create("sans-serif", Typeface.NORMAL);
    private static final Typeface SEMIBOLD = Typeface.create("sans-serif-medium", Typeface.NORMAL);

    public static void apply(Activity activity) {
        if (activity == null || activity.isFinishing()) return;
        Window window = activity.getWindow();
        if (window == null) return;
        window.setStatusBarColor(DuwmUnifiedTheme.BACKGROUND);
        window.setNavigationBarColor(DuwmUnifiedTheme.BACKGROUND);
        if (Build.VERSION.SDK_INT >= 29) window.setNavigationBarContrastEnforced(false);
        // Status/navigation chrome is always reference navy on every activity.
        // Never alter camera preview, video player, charts or map canvases.
        View decor = window.getDecorView();
        if (decor != null) {
            // Do not let immersive layout flags place the status LEDs beneath
            // the OS clock, notification icons or gesture/navigation bar.
            int systemUi = decor.getSystemUiVisibility();
            int unsafeLayout = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
            if ((systemUi & unsafeLayout) != 0) {
                decor.setSystemUiVisibility(systemUi & ~unsafeLayout);
            }
            systemUi = decor.getSystemUiVisibility();
            int lightBars = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR |
                    View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            if ((systemUi & lightBars) != 0) decor.setSystemUiVisibility(systemUi & ~lightBars);
        }
        View content = activity.findViewById(android.R.id.content);
        if (content != null) normalizeText(content, 0);
    }

    private static void normalizeText(View view, int depth) {
        if (view == null || depth > 35) return;
        if (view instanceof TextView) {
            TextView t = (TextView) view;
            Typeface old = t.getTypeface();
            int style = old == null ? Typeface.NORMAL : old.getStyle();
            t.setTypeface((style & Typeface.BOLD) != 0 ? SEMIBOLD : REGULAR,
                    (style & Typeface.ITALIC) != 0 ? Typeface.ITALIC : Typeface.NORMAL);
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) normalizeText(group.getChildAt(i), depth + 1);
        }
    }
}
