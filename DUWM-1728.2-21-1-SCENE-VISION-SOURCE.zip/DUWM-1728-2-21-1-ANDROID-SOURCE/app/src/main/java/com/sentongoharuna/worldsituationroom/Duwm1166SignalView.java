package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.graphics.Canvas;
import java.util.Locale;
/** Source status view, shared solid-colour animation; no synthetic source events. */
public final class Duwm1166SignalView extends Duwm1728StatusLampView {
    public static final int UNKNOWN=0,FRESH=1,STALE=2,ERROR=3,FETCHING=4,REFERENCE=5;
    private String kind="SOURCE";
    private long sourceTime,receiptTime,fetchStarted;
    private boolean fetching,error,reference;
    public Duwm1166SignalView(Context c){super(c);float d=c.getResources().getDisplayMetrics().density;
        setMinimumWidth(Math.round(22*d));setMinimumHeight(Math.round(22*d));}
    public void source(String type,long observedAt,long receivedAt,boolean isFetching,boolean hasError){
        kind=type==null?"SOURCE":type.toUpperCase(Locale.US);
        sourceTime=observedAt;receiptTime=receivedAt;
        if(isFetching&&!fetching)fetchStarted=System.currentTimeMillis();
        fetching=isFetching;error=hasError;reference=false;refresh();invalidate();
    }
    public void reference(){reference=true;refresh();invalidate();}
    private void refresh(){
        long now=System.currentTimeMillis();Duwm1724SignalFlow.Stage s;
        if(reference)s=Duwm1724SignalFlow.Stage.LOCAL;
        else if(error)s=Duwm1724SignalFlow.Stage.OUTAGE;
        else if(fetching)s=now-fetchStarted>120_000L?Duwm1724SignalFlow.Stage.DEGRADED:Duwm1724SignalFlow.Stage.CONNECTING;
        else if(sourceTime<=0L||receiptTime<=0L||sourceTime>now+600_000L||receiptTime>now+60_000L)s=Duwm1724SignalFlow.Stage.UNKNOWN;
        else if(now-receiptTime>600_000L||now-sourceTime>1_800_000L)s=Duwm1724SignalFlow.Stage.AGED;
        else s=Duwm1724SignalFlow.Stage.HEALTHY;
        setStage(s,kind.hashCode(),true);setContentDescription(kind+": "+s.label);
    }
    @Override protected void onDraw(Canvas c){refresh();super.onDraw(c);}
}
