package com.sentongoharuna.worldsituationroom;

/** Pure, deterministic display policy. It never changes a provider status/count.
 * Alpha is always 255: dim phases use a darker shade, never a washed-out overlay.
 * Receipt flashes require a RECEIVING state from the real receipt policy.
 * Sector phase offsets are deterministic, not random or synthetic traffic.
 */
public final class Duwm1728SignalMotion {
    private Duwm1728SignalMotion() {}
    public static boolean moves(Duwm1724SignalFlow.Stage stage) {
        return stage != null && stage != Duwm1724SignalFlow.Stage.UNKNOWN
                && stage != Duwm1724SignalFlow.Stage.LOCAL;
    }
    public static long periodMs(Duwm1724SignalFlow.Stage stage) {
        if (stage == null) return 3000L;
        switch (stage) {
            case OUTAGE: return 1900L;
            case DEGRADED: return 2300L;
            case AGED: return 3100L;
            case CONNECTING: return 1200L;
            case RECEIVING: return 800L;
            case HEALTHY: return 2900L;
            default: return 3000L;
        }
    }
    private static long positiveMod(long value,long modulus) {
        long r=value%modulus;return r<0?r+modulus:r;
    }
    public static float brightness(Duwm1724SignalFlow.Stage stage, long uptimeMs,
                                   int channel, boolean motionEnabled) {
        if (!motionEnabled || !moves(stage)) return 1f;
        long period = periodMs(stage);
        long salt = ((long)channel & 0x7fffffffL) * 193L;
        double phase = positiveMod(positiveMod(uptimeMs, period) + salt % period, period)
                / (double)period;
        switch (stage) {
            case OUTAGE: return phase < .48 ? 1f : .30f;
            case CONNECTING: return phase < .55 ? 1f : .32f;
            case RECEIVING: return phase < .52 ? 1f : .36f;
            case DEGRADED: return (float)(.46 + .54 * (.5 + .5 * Math.cos(2 * Math.PI * phase)));
            case AGED: return (float)(.64 + .36 * (.5 + .5 * Math.cos(2 * Math.PI * phase)));
            case HEALTHY: return (float)(.78 + .22 * (.5 + .5 * Math.cos(2 * Math.PI * phase)));
            default: return 1f;
        }
    }
    public static int solidColor(int rgb, float brightness) {
        float b = Math.max(0f, Math.min(1f, brightness));
        return 0xff000000 | (Math.round(((rgb >> 16) & 255) * b) << 16)
                | (Math.round(((rgb >> 8) & 255) * b) << 8)
                | Math.round((rgb & 255) * b);
    }
    public static Duwm1724SignalFlow.Stage fromColor(int color) {
        for (Duwm1724SignalFlow.Stage s : Duwm1724SignalFlow.Stage.values())
            if (s.color == color) return s;
        return Duwm1724SignalFlow.Stage.UNKNOWN;
    }
}
