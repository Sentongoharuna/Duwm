package com.sentongoharuna.worldsituationroom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Immutable editing of caption cues in original-source milliseconds.
 * Existing overlaps are intentional: the shared renderer selects the active cue
 * with the latest start, and the last cue in stable order wins equal starts.
 * Editing words never changes other source times or applies the current trim.
 */
public final class Duwm1728CaptionEditPolicy {
    public static final int MAX_CUES=20000;
    private static final int MAX_TEXT=500;
    private static final Comparator<Duwm1728BroadcastLayout.Cue> BY_START=
        (first,second)->Long.compare(first.startMs,second.startMs);
    private Duwm1728CaptionEditPolicy() {}

    /** Decimal seconds, MM:SS[.mmm], or HH:MM:SS[.mmm]; no rounding or exponent notation. */
    public static long parseTime(String text) {
        if(text==null)throw new IllegalArgumentException("Enter a caption time in seconds or HH:MM:SS.mmm");
        String value=text.trim();if(value.isEmpty())throw new IllegalArgumentException("Enter a caption time");
        String[] fields=value.split(":",-1);
        if(fields.length==1)return seconds(fields[0],false);
        if(fields.length!=2&&fields.length!=3)throw new IllegalArgumentException("Use seconds, MM:SS.mmm or HH:MM:SS.mmm");
        long last=seconds(fields[fields.length-1],true);
        if(fields.length==2)return plus(times(digits(fields[0]),60000),last);
        if(!fields[1].matches("[0-5][0-9]"))throw new IllegalArgumentException("Clock minutes must be 00 to 59");
        return plus(plus(times(digits(fields[0]),3600000),times(digits(fields[1]),60000)),last);
    }
    private static long seconds(String value,boolean clock) {
        String[] pieces=value.split("\\.",-1);
        if(pieces.length>2||pieces.length==0)throw new IllegalArgumentException("Use at most three digits after the decimal point");
        String whole=pieces[0];
        if(clock&&!whole.matches("[0-5][0-9]"))throw new IllegalArgumentException("Clock seconds must be 00 to 59");
        long milliseconds=times(digits(whole),1000);
        if(pieces.length==2){
            String fraction=pieces[1];if(!fraction.matches("[0-9]{1,3}"))throw new IllegalArgumentException("Use one to three digits after the decimal point");
            long part=digits(fraction);if(fraction.length()==1)part*=100;else if(fraction.length()==2)part*=10;
            milliseconds=plus(milliseconds,part);
        }
        return milliseconds;
    }
    private static long digits(String value) {
        if(value.isEmpty())throw new IllegalArgumentException("Caption times must contain nonnegative digits");
        long number=0;
        for(int i=0;i<value.length();i++){
            char digit=value.charAt(i);if(digit<'0'||digit>'9')throw new IllegalArgumentException("Caption times must be nonnegative numbers without signs or exponent notation");
            if(number>(Long.MAX_VALUE-(digit-'0'))/10)throw new IllegalArgumentException("Caption time is too large");
            number=number*10+(digit-'0');
        }
        return number;
    }
    private static long times(long value,long factor) {
        if(value<0||value>Long.MAX_VALUE/factor)throw new IllegalArgumentException("Caption time is too large");return value*factor;
    }
    private static long plus(long first,long second) {
        if(first<0||second<0||first>Long.MAX_VALUE-second)throw new IllegalArgumentException("Caption time is too large");return first+second;
    }
    public static String formatTime(long milliseconds) {
        if(milliseconds<0)throw new IllegalArgumentException("Caption time cannot be negative");
        return String.format(Locale.ROOT,"%02d:%02d:%02d.%03d",milliseconds/3600000,(milliseconds/60000)%60,(milliseconds/1000)%60,milliseconds%1000);
    }
    private static void duration(long value) {
        if(value<=0)throw new IllegalArgumentException("The original recording must have a positive duration");
    }
    /** The existing Cue limit is 500 UTF-16 units; reject before it can silently truncate text.
     * Ordinary line breaks/tabs become spaces. Other control characters and broken
     * surrogate pairs are rejected; Unicode scripts, combining marks and emoji survive.
     */
    private static String words(String raw) {
        if(raw==null)throw new IllegalArgumentException("Enter caption words");
        if(raw.length()>MAX_TEXT)throw new IllegalArgumentException("A caption may contain at most 500 characters");
        StringBuilder normalized=new StringBuilder(raw.length());boolean visible=false,inLineSpace=false;
        for(int i=0;i<raw.length();){
            char ch=raw.charAt(i);int cp;
            if(Character.isHighSurrogate(ch)){
                if(i+1>=raw.length()||!Character.isLowSurrogate(raw.charAt(i+1)))throw new IllegalArgumentException("Caption text contains incomplete Unicode");
                cp=Character.toCodePoint(ch,raw.charAt(i+1));i+=2;
            }else{
                if(Character.isLowSurrogate(ch))throw new IllegalArgumentException("Caption text contains incomplete Unicode");
                cp=ch;i++;
            }
            if(cp=='\r'||cp=='\n'||cp=='\t'){
                if(!inLineSpace)normalized.append(' ');inLineSpace=true;continue;
            }
            inLineSpace=false;
            if(Character.isISOControl(cp))throw new IllegalArgumentException("Remove unsupported control characters from the caption");
            normalized.appendCodePoint(cp);
            if(!Character.isWhitespace(cp)&&!Character.isSpaceChar(cp)&&Character.getType(cp)!=Character.FORMAT)visible=true;
        }
        if(!visible)throw new IllegalArgumentException("Enter caption words");
        return normalized.toString().trim();
    }
    private static Duwm1728BroadcastLayout.Cue validated(long start,long end,String text,long durationMs) {
        if(start<0||end<=start)throw new IllegalArgumentException("Caption end must be after its nonnegative start");
        if(start>=durationMs||end>durationMs)throw new IllegalArgumentException("Caption times must stay within the original recording");
        return new Duwm1728BroadcastLayout.Cue(start,end,words(text));
    }
    public static Duwm1728BroadcastLayout.Cue cue(String start,String end,String text,long durationMs) {
        duration(durationMs);String checked=words(text);
        return validated(parseTime(start),parseTime(end),checked,durationMs);
    }
    private static ArrayList<Duwm1728BroadcastLayout.Cue> copied(List<Duwm1728BroadcastLayout.Cue> source,long durationMs) {
        duration(durationMs);
        if(source==null)throw new IllegalArgumentException("Caption list is unavailable");
        if(source.size()>MAX_CUES)throw new IllegalArgumentException("Maximum 20000 caption cues");
        ArrayList<Duwm1728BroadcastLayout.Cue> result=new ArrayList<>(source.size());
        for(Duwm1728BroadcastLayout.Cue cue:source){
            if(cue==null)throw new IllegalArgumentException("Caption list contains an empty cue");
            result.add(validated(cue.startMs,cue.endMs,cue.text,durationMs));
        }
        return result;
    }
    private static List<Duwm1728BroadcastLayout.Cue> ordered(ArrayList<Duwm1728BroadcastLayout.Cue> result) {
        // Collections.sort is stable and available on every supported Android API.
        Collections.sort(result,BY_START);return Collections.unmodifiableList(result);
    }
    public static List<Duwm1728BroadcastLayout.Cue> copyAndValidate(List<Duwm1728BroadcastLayout.Cue> source,long durationMs) {
        return ordered(copied(source,durationMs));
    }
    private static void index(int index,int size) {
        if(index<0||index>=size)throw new IllegalArgumentException("Select an existing caption before editing");
    }
    /** Index refers to the supplied list, before any sorting caused by changed times. */
    public static List<Duwm1728BroadcastLayout.Cue> replace(List<Duwm1728BroadcastLayout.Cue> source,int index,Duwm1728BroadcastLayout.Cue replacement,long durationMs) {
        ArrayList<Duwm1728BroadcastLayout.Cue> result=copied(source,durationMs);index(index,result.size());
        if(replacement==null)throw new IllegalArgumentException("Replacement caption is unavailable");
        result.set(index,validated(replacement.startMs,replacement.endMs,replacement.text,durationMs));return ordered(result);
    }
    public static List<Duwm1728BroadcastLayout.Cue> add(List<Duwm1728BroadcastLayout.Cue> source,Duwm1728BroadcastLayout.Cue addition,long durationMs) {
        ArrayList<Duwm1728BroadcastLayout.Cue> result=copied(source,durationMs);
        if(result.size()>=MAX_CUES)throw new IllegalArgumentException("Maximum 20000 caption cues");
        if(addition==null)throw new IllegalArgumentException("New caption is unavailable");
        result.add(validated(addition.startMs,addition.endMs,addition.text,durationMs));return ordered(result);
    }
    public static List<Duwm1728BroadcastLayout.Cue> remove(List<Duwm1728BroadcastLayout.Cue> source,int index,long durationMs) {
        ArrayList<Duwm1728BroadcastLayout.Cue> result=copied(source,durationMs);index(index,result.size());result.remove(index);return ordered(result);
    }
    /** Migrate start-only manual captions exactly once, using their SAVED source origin.
     * Six-second/next-start ends are clipped only by the complete recording boundary.
     * A cue starting outside that recording is an error, never silently discarded.
     */
    public static List<Duwm1728BroadcastLayout.Cue> fromLegacy(List<Duwm1728TickerTimeline.Cue> source,long originMs,long durationMs) {
        duration(durationMs);if(originMs<0)throw new IllegalArgumentException("Saved caption origin cannot be negative");
        if(source==null)throw new IllegalArgumentException("Saved manual captions are unavailable");
        if(source.size()>MAX_CUES)throw new IllegalArgumentException("Maximum 20000 caption cues");
        ArrayList<Duwm1728BroadcastLayout.Cue> absolute=new ArrayList<>(source.size());
        for(Duwm1728TickerTimeline.Cue cue:source){
            if(cue==null||cue.atMs<0)throw new IllegalArgumentException("A saved manual caption has an invalid start");
            long start=plus(originMs,cue.atMs);
            if(start>=durationMs)throw new IllegalArgumentException("A saved manual caption starts outside the original recording; correct its time before editing");
            long end=start+Math.min(6000,durationMs-start);
            absolute.add(validated(start,end,cue.text,durationMs));
        }
        Collections.sort(absolute,BY_START);
        ArrayList<Duwm1728BroadcastLayout.Cue> result=new ArrayList<>(absolute.size());
        for(int i=0;i<absolute.size();i++){
            Duwm1728BroadcastLayout.Cue cue=absolute.get(i);long end=cue.endMs;
            if(i+1<absolute.size()){
                long next=absolute.get(i+1).startMs;
                if(next==cue.startMs)throw new IllegalArgumentException("Saved manual captions share a start time; correct the duplicate before editing");
                end=Math.min(end,next);
            }
            result.add(new Duwm1728BroadcastLayout.Cue(cue.startMs,end,cue.text));
        }
        return Collections.unmodifiableList(result);
    }
}
