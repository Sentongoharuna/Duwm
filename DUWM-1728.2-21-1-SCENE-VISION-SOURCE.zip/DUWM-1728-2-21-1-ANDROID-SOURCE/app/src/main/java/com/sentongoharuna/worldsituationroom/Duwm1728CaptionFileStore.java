package com.sentongoharuna.worldsituationroom;

import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.AtomicFile;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.UUID;

/** Immutable private SRT snapshots. A picker receives an identifier, never a large cue payload. */
public final class Duwm1728CaptionFileStore {
    public static final String MIME = "application/x-subrip";
    private static final long MAX_CACHE_BYTES = 128L * 1024 * 1024;
    private static final int MAX_SNAPSHOTS = 32;
    private static final Object[] SAVE_LOCKS=new Object[32];
    static {for(int i=0;i<SAVE_LOCKS.length;i++)SAVE_LOCKS[i]=new Object();}
    private Duwm1728CaptionFileStore() {}

    public static final class Snapshot {
        public final String id,name,sourceKey,basis,sha256;
        public final long bytes,createdAt;
        public final boolean shared;
        public final String savedDestination;
        public final Uri uri;
        Snapshot(Context context,JSONObject metadata)throws Exception {
            id=metadata.getString("id");name=metadata.getString("name");sourceKey=metadata.getString("source_key");
            basis=metadata.getString("basis");sha256=metadata.getString("sha256");bytes=metadata.getLong("bytes");
            createdAt=metadata.getLong("created_at");shared=metadata.optBoolean("shared",false);uri=uri(context,id);
            savedDestination=metadata.optString("saved_destination","");
            if(!name.matches("[A-Za-z0-9._-]{1,120}\\.srt")||bytes<1||bytes>Duwm1728CaptionSrt.MAX_BYTES
                    ||!sha256.matches("[0-9a-f]{64}"))throw new IOException("Invalid caption snapshot metadata");
        }
    }

    private static File root(Context context)throws IOException {
        File root=new File(context.getCacheDir(),"caption-files");
        if(!root.isDirectory()&&!root.mkdirs())throw new IOException("Caption file storage is unavailable");
        return root.getCanonicalFile();
    }
    private static String checkedId(String id)throws IOException {
        if(id==null||!id.matches("[0-9a-f]{32}"))throw new IOException("Invalid caption file identifier");return id;
    }
    private static File file(Context context,String id,String extension)throws IOException {
        File parent=root(context),result=new File(parent,checkedId(id)+extension).getCanonicalFile();
        if(!parent.equals(result.getParentFile()))throw new IOException("Invalid caption file path");return result;
    }
    private static void writeMetadata(File destination,JSONObject metadata)throws IOException {
        AtomicFile atomic=new AtomicFile(destination);FileOutputStream stream=null;
        try {stream=atomic.startWrite();stream.write(metadata.toString().getBytes(StandardCharsets.UTF_8));atomic.finishWrite(stream);}
        catch(IOException failure){if(stream!=null)atomic.failWrite(stream);throw failure;}
    }
    private static JSONObject metadata(Context context,String id)throws Exception {
        AtomicFile atomic=new AtomicFile(file(context,id,".json"));
        try(InputStream input=atomic.openRead();ByteArrayOutputStream bytes=new ByteArrayOutputStream()) {
            byte[] buffer=new byte[2048];int count;
            while((count=input.read(buffer))!=-1){if(bytes.size()+count>16384)throw new IOException("Invalid caption metadata size");bytes.write(buffer,0,count);}
            JSONObject value=new JSONObject(new String(bytes.toByteArray(),StandardCharsets.UTF_8));
            if(!id.equals(value.getString("id")))throw new IOException("Caption snapshot identity changed");return value;
        }
    }
    public static synchronized Snapshot create(Context context,byte[] bytes,String name,String sourceKey,String basis)throws IOException {
        if(bytes==null||bytes.length==0||bytes.length>Duwm1728CaptionSrt.MAX_BYTES)throw new IOException("Invalid caption snapshot size");
        File folder=root(context);long total=0;int snapshots=0;File[] entries=folder.listFiles();
        if(entries==null)throw new IOException("Cannot inspect caption file storage");
        for(File entry:entries){
            if(entry.getName().matches("[0-9a-f]{32}\\.srt")){
                try {JSONObject old=metadata(context,entry.getName().substring(0,32));
                    if(!old.optBoolean("shared",false)&&!old.optString("saved_destination","").isEmpty())entry.delete();
                }catch(Exception ignored){} // Corrupt or unfinished snapshots are not silently discarded.
                if(entry.exists()){total+=entry.length();snapshots++;}
            }
            // Partial files never receive a URI or grant; completed or pending snapshots are retained.
            else if(entry.getName().endsWith(".part")&&System.currentTimeMillis()-entry.lastModified()>86400000L)entry.delete();
        }
        // Keep a bounded set of tiny completed-save receipts for recreation.
        // Pending saves and granted share files are never selected by this cleanup.
        java.util.ArrayList<File> receipts=new java.util.ArrayList<>();
        for(File entry:entries)if(entry.getName().matches("[0-9a-f]{32}\\.json"))try{
            String oldId=entry.getName().substring(0,32);JSONObject old=metadata(context,oldId);
            if(!old.optBoolean("shared",false)&&!old.optString("saved_destination","").isEmpty()&&!file(context,oldId,".srt").exists())receipts.add(entry);
        }catch(Exception ignored){}
        java.util.Collections.sort(receipts,(a,b)->Long.compare(a.lastModified(),b.lastModified()));
        for(int i=0;i<receipts.size()-128;i++)new AtomicFile(receipts.get(i)).delete();
        if(snapshots>=MAX_SNAPSHOTS||total+bytes.length>MAX_CACHE_BYTES)
            throw new IOException("Caption share cache is full. Clear DUWM's cache in Android Settings after recipients finish using shared copies.");
        String id=UUID.randomUUID().toString().replace("-","");File temporary=file(context,id,".part"),completed=file(context,id,".srt");
        try {
            JSONObject value=new JSONObject().put("id",id).put("name",name).put("source_key",sourceKey)
                    .put("basis",basis).put("bytes",bytes.length).put("created_at",System.currentTimeMillis())
                    .put("sha256",digest(bytes)).put("shared",false);
            Snapshot snapshot=new Snapshot(context,value); // Validate all metadata before writing.
            try(FileOutputStream output=new FileOutputStream(temporary)){output.write(bytes);output.flush();output.getFD().sync();}
            if(!temporary.renameTo(completed))throw new IOException("Cannot secure the caption snapshot");
            writeMetadata(file(context,id,".json"),value);return snapshot;
        }catch(Exception failure){temporary.delete();completed.delete();throw io("Cannot prepare SRT: ",failure);}
    }
    public static synchronized Snapshot find(Context context,String id)throws IOException {
        try {
            Snapshot snapshot=new Snapshot(context,metadata(context,checkedId(id)));
            File complete=file(context,id,".srt");
            if(snapshot.savedDestination.isEmpty()&&(!complete.isFile()||complete.length()!=snapshot.bytes))throw new IOException("Caption snapshot is no longer available");
            return snapshot;
        }catch(Exception failure){throw io("Caption snapshot unavailable: ",failure);}
    }
    public static Uri uri(Context context,String id) {
        if(id==null||!id.matches("[0-9a-f]{32}"))throw new IllegalArgumentException("Invalid caption snapshot identifier");
        return new Uri.Builder().scheme("content").authority(context.getPackageName()+".caption-files")
                .appendPath("snapshots").appendPath(id+".srt").build();
    }
    static String entryId(Context context,Uri uri)throws IOException {
        if(uri==null||!"content".equals(uri.getScheme())||!(context.getPackageName()+".caption-files").equals(uri.getAuthority())
                ||uri.getQuery()!=null||uri.getFragment()!=null||uri.getPathSegments().size()!=2
                ||!"snapshots".equals(uri.getPathSegments().get(0)))throw new IOException("Invalid caption URI");
        String leaf=uri.getPathSegments().get(1);
        if(!leaf.matches("[0-9a-f]{32}\\.srt"))throw new IOException("Invalid caption URI path");
        return leaf.substring(0,32);
    }
    static File readableFile(Context context,Uri uri)throws IOException {
        String id=entryId(context,uri);Snapshot snapshot=find(context,id);File result=file(context,id,".srt");
        if(!result.isFile()||result.length()!=snapshot.bytes)throw new IOException("Caption file is unavailable");return result;
    }
    public static Intent shareIntent(Uri uri) {
        if(uri==null||!"content".equals(uri.getScheme())||uri.getAuthority()==null||!uri.getAuthority().endsWith(".caption-files")
                ||uri.getQuery()!=null||uri.getFragment()!=null||uri.getPathSegments().size()!=2
                ||!"snapshots".equals(uri.getPathSegments().get(0))||!uri.getPathSegments().get(1).matches("[0-9a-f]{32}\\.srt"))
            throw new IllegalArgumentException("A caption content URI is required");
        Intent send=new Intent(Intent.ACTION_SEND).setType(MIME).putExtra(Intent.EXTRA_STREAM,uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        send.setClipData(new ClipData("DUWM captions",new String[]{MIME},new ClipData.Item(uri)));return send;
    }
    public static synchronized void markShared(Context context,String id)throws IOException {
        try{find(context,id);JSONObject value=metadata(context,id);value.put("shared",true);writeMetadata(file(context,id,".json"),value);}
        catch(Exception failure){throw io("Cannot retain shared captions: ",failure);}
    }
    /** Never automatically delete a snapshot already offered with a read grant. */
    public static synchronized void discardUnshared(Context context,String id)throws IOException {
        Snapshot snapshot=find(context,id);if(snapshot.shared)return;
        File complete=file(context,id,".srt");if(complete.exists()&&!complete.delete())throw new IOException("Cannot remove the completed save snapshot");
        // The small receipt lets a recreated Activity observe a completed write, even
        // when its last saved instance state still held the pending snapshot ID.
        if(snapshot.savedDestination.isEmpty())new AtomicFile(file(context,id,".json")).delete();
    }
    public static synchronized int clearShared(Context context)throws IOException {
        int removed=0;File[] entries=root(context).listFiles();if(entries==null)throw new IOException("Caption storage is unavailable");
        for(File entry:entries)if(entry.getName().matches("[0-9a-f]{32}\\.json")){
            String id=entry.getName().substring(0,32);
            try {if(removeShared(context,id))removed++;}catch(FileNotFoundException ignored){}
        }
        return removed;
    }
    /** Used only after explicit user confirmation; existing recipient links stop opening. */
    public static synchronized boolean removeShared(Context context,String id)throws IOException {
        try {JSONObject value=metadata(context,checkedId(id));if(!value.optBoolean("shared",false))return false;
            File complete=file(context,id,".srt");if(complete.exists()&&!complete.delete())throw new IOException("Cannot remove shared captions");
            new AtomicFile(file(context,id,".json")).delete();return true;
        }catch(IOException failure){throw failure;}catch(Exception failure){throw io("Cannot inspect shared captions: ",failure);}
    }
    /** Both stream close operations must succeed before the caller can report SRT SAVED. */
    public static void copyTo(Context context,String id,Uri destination)throws IOException {
        if(destination==null||!"content".equals(destination.getScheme()))throw new IOException("Choose a document destination");
        if((context.getPackageName()+".caption-files").equals(destination.getAuthority()))throw new IOException("Choose a separate document destination");
        Object lock=SAVE_LOCKS[(checkedId(id).hashCode()&0x7fffffff)%SAVE_LOCKS.length];
        synchronized(lock){copyLocked(context,id,destination);}
    }
    private static void copyLocked(Context context,String id,Uri destination)throws IOException {
        Snapshot snapshot=find(context,id);long written=0;
        if(destination.toString().equals(snapshot.savedDestination))return;
        try {
            MessageDigest digest=MessageDigest.getInstance("SHA-256");
            try(InputStream input=new FileInputStream(readableFile(context,snapshot.uri));
                    OutputStream output=context.getContentResolver().openOutputStream(destination,"wt")) {
                if(output==null)throw new IOException("The document provider did not open the destination");
                byte[] buffer=new byte[32768];int count;
                while((count=input.read(buffer))!=-1){if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("SRT save interrupted");
                    output.write(buffer,0,count);digest.update(buffer,0,count);written+=count;}
                output.flush();
                if(written!=snapshot.bytes||!snapshot.sha256.equals(hex(digest.digest())))throw new IOException("The frozen SRT snapshot changed while saving");
            }
            synchronized(Duwm1728CaptionFileStore.class){JSONObject value=metadata(context,id);
                value.put("saved_destination",destination.toString());writeMetadata(file(context,id,".json"),value);}
        }catch(Exception failure){throw io("Could not finish saving SRT: ",failure);}
    }
    private static String digest(byte[] bytes)throws Exception{return hex(MessageDigest.getInstance("SHA-256").digest(bytes));}
    private static String hex(byte[] bytes){StringBuilder value=new StringBuilder();for(byte b:bytes)value.append(String.format(Locale.ROOT,"%02x",b&255));return value.toString();}
    private static IOException io(String prefix,Exception failure){return new IOException(prefix+(failure.getMessage()==null?failure.getClass().getSimpleName():failure.getMessage()),failure);}
}
