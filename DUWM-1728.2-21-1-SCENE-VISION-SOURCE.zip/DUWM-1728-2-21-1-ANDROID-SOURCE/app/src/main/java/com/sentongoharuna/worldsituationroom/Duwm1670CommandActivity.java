package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import org.json.JSONArray;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** Source-backed dashboard with sector-specific displays and motion separated from real data. */
public final class Duwm1670CommandActivity extends Activity {
  private static final int BG=0xFF041424,WHITE=0xFFDCE9FD,MUTED=0xFFB6C2C5,AQUA=0xFF558BDF,AMBER=DuwmUnifiedTheme.STATUS_ORANGE;
  private static final String[] KINDS={"AIRCRAFT","VESSELS","NEWS","MARKETS","WEATHER","EARTHQUAKES","ISS","LIVE TV","PUBLIC CAMERAS"};
  private final Handler handler=new Handler(Looper.getMainLooper());private boolean visible;
  private int chosen=0;private Duwm1670WorldMapView map;private Duwm1670DataPulseView figure;private Duwm1670HomeTelemetryView rail;
  private TextView headline,figures,age,details,go;
  private final Runnable tick=new Runnable(){@Override public void run(){if(!visible)return;refresh();handler.postDelayed(this,20000);}};
  private int dp(float x){return Math.round(getResources().getDisplayMetrics().density*x);}
  private TextView text(String s,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);
    if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  private GradientDrawable panel(int fill){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(11));d.setStroke(dp(1),0xFF284C87);return d;}
  private TextView action(String s,Runnable f){TextView t=text(s,12,AQUA,true);t.setGravity(Gravity.CENTER);t.setBackground(panel(0xFF114C5E));t.setPadding(dp(10),dp(10),dp(10),dp(10));t.setOnClickListener(v->f.run());return t;}
  private String utc(long ms){if(ms<=0)return "NO SOURCE TIME";SimpleDateFormat d=new SimpleDateFormat("dd MMM HH:mm 'UTC'",Locale.US);d.setTimeZone(TimeZone.getTimeZone("UTC"));return d.format(new Date(ms));}
  @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(BG);setContentView(scroll);Duwm1167SafeArea.install(this,scroll);
    LinearLayout col=new LinearLayout(this);col.setPadding(dp(12),dp(14),dp(12),dp(28));col.setOrientation(LinearLayout.VERTICAL);scroll.addView(col);
    col.addView(text("DEVELOP.UGANDA    /    WORLD INTELLIGENCE SYSTEM",13,AQUA,true));
    col.addView(text("LIVE COMMAND   1670",27,WHITE,true));
    TextView desc=text("Individual intelligence desks • original globe preserved • no fabricated observation dots",11,MUTED,false);col.addView(desc);
    rail=new Duwm1670HomeTelemetryView(this);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(70));rp.topMargin=dp(10);col.addView(rail,rp);
    Spinner select=new Spinner(this);ArrayAdapter<String> choices=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,KINDS);
    choices.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);select.setAdapter(choices);select.setBackground(panel(0xFF12294A));
    LinearLayout.LayoutParams spl=new LinearLayout.LayoutParams(-1,dp(49));spl.topMargin=dp(9);col.addView(select,spl);
    select.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){@Override public void onItemSelected(AdapterView<?> p,View v,int position,long id){chosen=position;refresh();}
      @Override public void onNothingSelected(AdapterView<?> p){} });
    headline=text("AIRCRAFT OPERATIONS",19,WHITE,true);headline.setPadding(0,dp(14),0,dp(7));col.addView(headline);
    figures=text("WAITING FOR VERIFIED SOURCE DATA",13,WHITE,true);col.addView(figures);
    age=text("NOT CONNECTED",11,MUTED,false);age.setPadding(0,dp(4),0,dp(9));col.addView(age);
    map=new Duwm1670WorldMapView(this);map.setOnPinSelected(pin->details.setText("SELECTED RECEIVED FIX: "+pin.title+"\n"+pin.detail+"\nSOURCE TIME: "+utc(pin.observed)));
    figure=new Duwm1670DataPulseView(this);
    col.addView(map,new LinearLayout.LayoutParams(-1,dp(290)));
    col.addView(figure,new LinearLayout.LayoutParams(-1,dp(140)));
    details=text("SELECT THE CATEGORY OR AN OBSERVED MARKER",12,MUTED,false);details.setPadding(dp(11),dp(13),dp(11),dp(13));details.setBackground(panel(0xFF0E3F4D));col.addView(details);
    go=action("OPEN SPECIALIST DESK",this::openDesk);LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,dp(48));op.topMargin=dp(9);col.addView(go,op);
    LinearLayout menu=new LinearLayout(this);LinearLayout.LayoutParams ml=new LinearLayout.LayoutParams(-1,-2);ml.topMargin=dp(8);col.addView(menu,ml);
    menu.addView(action("FLIGHT MAP + ETA",()->startActivity(new Intent(this,Duwm1670FlightMapActivity.class))),new LinearLayout.LayoutParams(0,dp(51),1));
    TextView news=action("NEWS REGION MAP",()->startActivity(new Intent(this,Duwm1670NewsAtlasActivity.class)));
    LinearLayout.LayoutParams nl=new LinearLayout.LayoutParams(0,dp(51),1);nl.leftMargin=dp(8);menu.addView(news,nl);
    col.addView(action("BACK TO ORIGINAL MOVING GLOBE",()->startActivity(new Intent(this,OperationsMainActivity.class))));
    TextView foot=text("Dynamic rings and LEDs indicate display activity. Figures change only when a real provider record changes. " +
        "No invented flight path, real-time market chart, vessel traffic, station position, breaking news event or ETA.",11,MUTED,false);
    foot.setPadding(0,dp(10),0,dp(4));col.addView(foot);refresh();
  }
  private void openDesk(){Intent i;
    switch(chosen){
      case 0:i=new Intent(this,Duwm1670FlightMapActivity.class);break;
      case 1:case 5:case 6:i=new Intent(this,Duwm1668GeopoliticalLensActivity.class);break;
      case 2:i=new Intent(this,Duwm1670NewsAtlasActivity.class);break;
      case 3:case 4:i=new Intent(this,DuwmWorldIntelligenceActivity.class);i.putExtra("kind",chosen==3?"MARKETS":"WEATHER");break;
      case 7:i=new Intent(this,MediaDeskActivity.class);i.putExtra("mode","TV STATIONS");break;
      default:i=new Intent(this,MediaDeskActivity.class);i.putExtra("mode","PUBLIC CAMERAS");break;}
    startActivity(i);
  }
  private void refresh(){if(map==null||figure==null||figures==null)return;String k=KINDS[chosen];headline.setText(k+"   /   LIVE INFORMATION DESK");
    if(rail!=null)rail.update();
    ArrayList<Duwm1670WorldMapView.Pin> pins=new ArrayList<>();
    String metric="--",sourceStatus="NO VERIFIED DATA",extra="";double n=Double.NaN;long when=0;
    if(chosen==0){RunningballV25GlobalAircraftData.Snapshot s=RunningballV25GlobalAircraftData.read(this);
      metric=s.countLabel()+" RECEIVED";sourceStatus=s.status();when=s.receivedAt;
      if(s.hasGood()&&s.ageMs()<21600000L)for(int i=0;i<s.points.length()&&pins.size()<1500;i++){
        JSONArray p=s.points.optJSONArray(i);if(p==null)continue;double lat=p.optDouble(0,Double.NaN),lon=p.optDouble(1,Double.NaN);
        if(!Double.isFinite(lat)||!Double.isFinite(lon))continue;
        String id=p.optString(2,"unknown");Duwm1670WorldMapView.Pin point=new Duwm1670WorldMapView.Pin(id,p.optString(3,id),"AIRCRAFT",lat,lon,p.optLong(7,0)*1000L,"Observed OpenSky flight coordinates");pins.add(point);
      }
      extra=pins.size()+" source coordinates plotted • Global request is rate-limited";
    }else if(chosen==1||chosen==5||chosen==6){String expected=chosen==1?"VESSEL":chosen==5?"EARTHQUAKE":"ISS";
      for(DuwmGeoObservationStore.Fix f:DuwmGeoObservationStore.read(this))if(expected.equals(f.type)||expected.equals("VESSEL")&&"VESSELS".equals(f.type)){
        if(pins.size()>=250)break;Duwm1670WorldMapView.Pin p=new Duwm1670WorldMapView.Pin(f.id,f.title,expected,f.lat,f.lon,f.sourceTime,f.detail);pins.add(p);when=Math.max(when,f.receivedAt);
      }
      metric=pins.size()+" OBSERVED FIXES";sourceStatus=when>0?"CACHED SOURCE FIXES":"SOURCE NOT AVAILABLE";
      extra="Map markers are actual received positions, never synthetic sightings";
    }else if(chosen==2){List<NewsItem> articles=new NewsStore(this).load();metric=articles.size()+" CACHED STORIES";
      for(NewsItem story:articles){when=Math.max(when,story.firstSeenAt);}
      sourceStatus=articles.isEmpty()?"NO RECEIVED ARTICLES":"SOURCE HEADLINES ATTRIBUTED";
      extra="News atlas maps publisher countries, not article incident locations";
    }else if(chosen==3||chosen==4){RunningballV25Sources.Result r=RunningballV25Sources.read(this,chosen==3?7:6);
      metric=r.value;sourceStatus=r.display();when=r.fetchedAt;
      String raw=metric.replaceAll("[^0-9.\\-]","");try{n=Double.parseDouble(raw.split(" ")[0]);}catch(Exception ignored){}
      extra=chosen==3?"ECB / Frankfurter FX REFERENCE • NOT A TRADE TICKER":"REGIONAL WEATHER • CHECK SOURCE FRESHNESS";
    }else if(chosen==7||chosen==8){metric="SOURCE DIRECTORY";sourceStatus="PLAYBACK ON SEPARATE MEDIA DESK";extra="Not all registered streams are available or licensed for in-app playback";}
    figures.setText(metric);
    age.setText(sourceStatus+"  /  "+(when>0?utc(when):"NO VERIFIED RECEIPT"));
    details.setText(extra);
    boolean chart=chosen==3||chosen==4||chosen>=7;
    if(chart){map.setVisibility(View.GONE);figure.setVisibility(View.VISIBLE);figure.update(k,metric,n,sourceStatus,when);}
    else{figure.setVisibility(View.GONE);map.setVisibility(View.VISIBLE);map.setLayer(k);map.setPins(pins,false);}
    go.setText("OPEN "+k+"  /  FULL INTELLIGENCE PAGE");
  }
  @Override protected void onResume(){super.onResume();visible=true;if(map!=null)map.resume();if(figure!=null)figure.start();if(rail!=null)rail.resume();handler.removeCallbacks(tick);handler.post(tick);}
  @Override protected void onPause(){visible=false;handler.removeCallbacks(tick);if(map!=null)map.pause();if(figure!=null)figure.stop();if(rail!=null)rail.pause();super.onPause();}
}
