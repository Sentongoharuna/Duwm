package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.SystemClock;
import android.view.View;

/** Animated presentation of real values, not synthetic telemetry. */
public final class Duwm1670DataPulseView extends View {
  private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
  private boolean active;private String category="MARKETS",value="--",status="NO SOURCE RECEIPT";
  private double scalar=Double.NaN;private long fetched;
  private int dp(float x){return Math.round(getResources().getDisplayMetrics().density*x);}
  public Duwm1670DataPulseView(Context c){super(c);setContentDescription("Market / weather status graphics use actual source values. Decorative motion does not represent changing prices or forecast observations.");}
  public void update(String layer,String figure,double number,String state,long sourceReceived){category=layer;value=figure;scalar=number;status=state;fetched=sourceReceived;invalidate();}
  public void start(){active=true;postInvalidateDelayed(100);}
  public void stop(){active=false;}
  @Override protected void onDetachedFromWindow(){stop();super.onDetachedFromWindow();}
  @Override protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight();c.drawColor(DuwmUnifiedTheme.APPROVED_NAVY);
    p.setStyle(Paint.Style.FILL);p.setTextSize(dp(12));p.setColor(DuwmUnifiedTheme.TEXT);c.drawText(category+"  /  VERIFIED SOURCE STATUS",dp(16),dp(25),p);
    p.setTextSize(dp(32));p.setColor(DuwmUnifiedTheme.TEXT);c.drawText(value.length()>18?value.substring(0,18):value,dp(16),h/2f,p);
    p.setTextSize(dp(11));p.setColor(0xFFB8C5C8);c.drawText(status.length()>58?status.substring(0,58):status,dp(16),h-dp(18),p);
    Duwm1724SignalFlow.Stage stage=Duwm1724SignalFlow.fromText(status);
    if(fetched<=0L && stage==Duwm1724SignalFlow.Stage.HEALTHY)stage=Duwm1724SignalFlow.Stage.UNKNOWN;
    if(stage==Duwm1724SignalFlow.Stage.HEALTHY && System.currentTimeMillis()-fetched>90*60_000L)
        stage=Duwm1724SignalFlow.Stage.AGED;
    float b=Duwm1728SignalMotion.brightness(stage,SystemClock.uptimeMillis(),category.hashCode(),
        active&&Duwm1728StatusLampView.systemMotionEnabled());
    p.setStyle(Paint.Style.FILL);p.setColor(Duwm1728SignalMotion.solidColor(stage.color,b));
    c.drawCircle(w-dp(36),h/2f,dp(7),p);
    if(active)postInvalidateDelayed(95);
  }
}
