package com.sentongoharuna.worldsituationroom;

import java.util.Locale;
import static com.sentongoharuna.worldsituationroom.Duwm1724SignalFlow.Stage.*;

/** 1728.2/7: display-only policy for real camera observations. No synthetic receipts.
 * Input uses monotonic elapsed-realtime milliseconds, not wall-clock time.
 * Optional features deliberately OFF are neutral, never falsely healthy or failed.
 */
public final class Duwm1728CaptureHealth {
    private Duwm1728CaptureHealth() {}
    public enum Channel { CAMERA, MICROPHONE, GPS, COMPASS, WEATHER, GALLERY }
    public static final class Reading {
        public final Channel channel;
        public final Duwm1724SignalFlow.Stage stage;
        public final String label, evidence;
        Reading(Channel c,Duwm1724SignalFlow.Stage s,String label,String evidence) {
            this.channel=c;this.stage=s;this.label=label;this.evidence=evidence;
        }
    }
    /** Built from device callbacks by the Activity. Defaults are unknown, not green. */
    public static final class Input {
        public long now;
        public boolean cameraPermission, cameraOpen, recording, adequateResolution;
        public long frameAt=-1L, recordingMs;
        public double sourceFps=-1d;
        public int targetFps=30;
        public String cameraError="";
        public boolean microphoneEnabled, microphonePermission;
        public int microphonePeak=-1;
        public long microphoneAt=-1L;
        public String microphoneError="";
        public boolean gpsOptIn, gpsPermission, gpsProviderEnabled, mockLocation;
        public long gpsAgeMs=-1L;
        public float gpsAccuracy=Float.NaN;
        public boolean compassPresent;
        public long compassAt=-1L;
        public int compassAccuracy=-1;
        public boolean weatherRequested, weatherLoading, weatherPlaceMatches=true;
        public long weatherAt=-1L;
        public String weatherError="";
        public boolean gallerySaving;
        public int galleryResult; // 0 no export; 1 completed MediaStore copy; -1 failed
        public long galleryAt=-1L;
        public String galleryMessage="";
    }
    private static boolean validAge(long now,long timestamp,long budget) {
        return timestamp>=0L && now>=timestamp && now-timestamp<=budget;
    }
    private static boolean hasError(String s) {return s!=null&&!s.trim().isEmpty();}
    private static Reading r(Channel c,Duwm1724SignalFlow.Stage s,String label,String detail) {
        return new Reading(c,s,label,detail);
    }
    public static Reading[] read(Input in) {
        if(in==null)in=new Input();
        return new Reading[]{camera(in),mic(in),gps(in),compass(in),weather(in),gallery(in)};
    }
    private static Reading camera(Input i) {
        Channel c=Channel.CAMERA;
        if(!i.cameraPermission)return r(c,DEGRADED,"PERMISSION","Camera permission has not been granted.");
        if(hasError(i.cameraError))return r(c,OUTAGE,"ERROR",i.cameraError);
        if(!i.cameraOpen)return r(c,UNKNOWN,"CLOSED","No camera session is open. This is not a verified recording.");
        if(i.frameAt<0L)return r(c,CONNECTING,"STARTING","Session open; waiting for an actual decoded camera frame.");
        if(!validAge(i.now,i.frameAt,3000L))return r(c,AGED,"NO FRAMES","No fresh decoded camera frame within 3 seconds.");
        if(!i.adequateResolution)return r(c,DEGRADED,"RESOLUTION","Camera input is below the selected output dimensions. No quality claim is made.");
        if(i.recording&&i.recordingMs>=3000L&&i.sourceFps>=0d&&i.sourceFps<i.targetFps*.70d)
            return r(c,DEGRADED,"LOW FPS",String.format(Locale.US,"Measured source %.1f fps; target %d fps. Export quality is not guaranteed.",i.sourceFps,i.targetFps));
        return r(c,HEALTHY,i.recording?"RECORDING":"READY","Fresh decoded camera frames. This does not verify the exported MP4 or AI broadcast output.");
    }
    private static Reading mic(Input i) {
        Channel c=Channel.MICROPHONE;
        if(!i.microphoneEnabled)return r(c,LOCAL,"OFF","Microphone recording is disabled by the reporter. Silent video will be recorded.");
        if(!i.microphonePermission)return r(c,DEGRADED,"PERMISSION","Microphone permission is required before recording audio.");
        if(!i.recording)return r(c,UNKNOWN,"NOT TESTED","Permission granted, but no recording amplitude has been sampled yet.");
        if(hasError(i.microphoneError))return r(c,OUTAGE,"ERROR",i.microphoneError);
        if(i.microphonePeak<0)return r(c,CONNECTING,"CHECKING","Waiting for the first MediaRecorder audio-level reading.");
        if(!validAge(i.now,i.microphoneAt,2500L))return r(c,AGED,"STALE","Audio-level reading is no longer current.");
        if(i.microphonePeak==0)return r(c,AGED,"SILENT","Last sampled peak is zero. This may be silence or an unavailable input; audio is not proved healthy.");
        if(i.microphonePeak>=32000)return r(c,DEGRADED,"HIGH LEVEL","Peak audio level is near full scale. Check for clipping.");
        double db=20d*Math.log10(i.microphonePeak/32767d);
        return r(c,HEALTHY,"AUDIO",String.format(Locale.US,"Actual recorder peak %.1f dBFS. This is not a loudness meter or an external-mic routing guarantee.",db));
    }
    private static Reading gps(Input i) {
        Channel c=Channel.GPS;
        if(!i.gpsOptIn)return r(c,LOCAL,"PRIVATE","Precise GPS is off. This indicator does not request location or disclose coordinates.");
        if(!i.gpsPermission)return r(c,DEGRADED,"PERMISSION","Location permission has not been granted.");
        if(!i.gpsProviderEnabled)return r(c,DEGRADED,"DISABLED","GPS/network location providers are disabled or unavailable.");
        if(i.gpsAgeMs<0L)return r(c,CONNECTING,"SEEKING","No valid monotonic-age location reading is available.");
        if(i.mockLocation)return r(c,DEGRADED,"TEST FIX","Android marked this location as a test/mock reading; not genuine location evidence.");
        if(i.gpsAgeMs>120000L)return r(c,AGED,"STALE","Last location reading is older than two minutes.");
        if(Float.isNaN(i.gpsAccuracy)||Float.isInfinite(i.gpsAccuracy)||i.gpsAccuracy<0f||i.gpsAccuracy>100f)
            return r(c,DEGRADED,"LOW ACCURACY","Fresh fix, but uncertainty is missing or exceeds 100 metres.");
        return r(c,HEALTHY,"FIX",String.format(Locale.US,"Fresh sensor fix; reported accuracy ±%.0f m. Exact coordinates are not shown in this status panel.",i.gpsAccuracy));
    }
    private static Reading compass(Input i) {
        Channel c=Channel.COMPASS;
        if(!i.compassPresent)return r(c,UNKNOWN,"MISSING","No rotation-vector sensor is available.");
        if(i.compassAt<0L)return r(c,CONNECTING,"SEEKING","Waiting for a real heading callback.");
        if(!validAge(i.now,i.compassAt,20000L))return r(c,AGED,"STALE","No fresh heading for 20 seconds.");
        if(i.compassAccuracy<=0)return r(c,DEGRADED,"CALIBRATE","Sensor accuracy is unknown or unreliable. Do not treat the heading as verified.");
        return r(c,HEALTHY,"HEADING","Recent sensor heading with reported accuracy. Magnetic heading is not necessarily true north.");
    }
    private static Reading weather(Input i) {
        Channel c=Channel.WEATHER;
        if(!i.weatherRequested)return r(c,UNKNOWN,"OFF","No optional weather request. Opening this panel never fetches weather.");
        if(i.weatherLoading)return r(c,CONNECTING,"FETCHING","An explicit weather-model request is in progress.");
        if(hasError(i.weatherError))return r(c,OUTAGE,"FAILED",i.weatherError);
        if(i.weatherAt<0L||i.now<i.weatherAt)return r(c,UNKNOWN,"NO RECEIPT","No valid weather response is stored.");
        if(!i.weatherPlaceMatches)return r(c,DEGRADED,"OTHER PLACE","Stored model weather belongs to a different location.");
        if(!validAge(i.now,i.weatherAt,1800000L))return r(c,AGED,"STALE","Model weather is older than 30 minutes. Refresh is manual and opt-in.");
        if(validAge(i.now,i.weatherAt,1800L))return r(c,RECEIVING,"RECEIVED","A real weather response arrived recently. It is model data, not a phone measurement.");
        return r(c,HEALTHY,"MODEL","Recent model response for the requested place. Source: Open-Meteo; not an official warning.");
    }
    private static Reading gallery(Input i) {
        Channel c=Channel.GALLERY;
        if(i.gallerySaving)return r(c,CONNECTING,"SAVING","Writing a completed MP4 to phone Gallery. Not yet saved.");
        if(i.galleryResult<0)return r(c,OUTAGE,"FAILED",hasError(i.galleryMessage)?i.galleryMessage:"Gallery export failed. The private draft is retained when valid.");
        if(i.galleryResult==0)return r(c,UNKNOWN,"NO EXPORT","No Gallery export has completed in this camera session.");
        if(!validAge(i.now,i.galleryAt,Long.MAX_VALUE))return r(c,UNKNOWN,"UNCONFIRMED","No valid completion time is available.");
        return r(c,validAge(i.now,i.galleryAt,1800L)?RECEIVING:HEALTHY,"SAVED",
                "The Gallery publisher returned a saved URI. Playback still requires device verification.");
    }
}
