package com.sentongoharuna.worldsituationroom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/** Measured caption pages for preview and encoded frames. The source cue is never
 * rewritten: page intervals are display policy within its original interval,
 * not new speech timestamps. Dense cues can still be too fast to read, or have
 * more pages than a video's frame sampling can show.
 */
public final class Duwm1728CaptionPages {
    private static final int CACHE_LIMIT=64;
    private static final Map<Key,Plan> CACHE=new LinkedHashMap<Key,Plan>(CACHE_LIMIT,0.75f,true){
        @Override protected boolean removeEldestEntry(Map.Entry<Key,Plan> entry){return size()>CACHE_LIMIT;}
    };
    private Duwm1728CaptionPages(){}

    /** Source offsets cover every character, including spaces at a line break.
     * Lines contain only the visible portion of that exact source slice. */
    public static final class Page {
        public final List<String> lines;
        public final int startChar,endChar;
        private Page(List<String> rows,int start,int end){lines=Collections.unmodifiableList(new ArrayList<>(rows));startChar=start;endChar=end;}
    }
    public static final class Plan {
        public final String text;
        public final List<Page> pages;
        public final int rows,codePoints,clusters;
        /** Normally the requested size. An indivisible cluster wider than the
         * whole panel reduces this size, never splitting or hiding that cluster. */
        public final float textSize;
        private Plan(String source,List<Page> result,int rowCount,float size,int clusterCount){
            text=source;pages=Collections.unmodifiableList(new ArrayList<>(result));rows=rowCount;textSize=size;
            codePoints=source.codePointCount(0,source.length());clusters=clusterCount;
        }
        public int pageCount(){return pages.size();}
        public int pageIndex(long elapsedMs,long durationMs){
            if(durationMs<=0)throw new IllegalArgumentException("Caption duration must be positive");
            if(pages.isEmpty())return -1;
            long elapsed=Math.max(0,Math.min(durationMs-1,elapsedMs));
            int low=0,high=pages.size();
            while(low+1<high){int middle=(low+high)>>>1;if(pageStartMs(middle,durationMs)<=elapsed)low=middle;else high=middle;}
            return low;
        }
        public Page pageAt(long elapsedMs,long durationMs){int index=pageIndex(elapsedMs,durationMs);return index<0?null:pages.get(index);}
        /** ceil(page * duration / count), with no long multiplication overflow. */
        public long pageStartMs(int page,long durationMs){
            if(durationMs<=0||page<0||page>pages.size()||pages.isEmpty())throw new IllegalArgumentException("Invalid page interval");
            long count=pages.size();return (durationMs/count)*page+((durationMs%count)*page+count-1)/count;
        }
        public long pageEndMs(int page,long durationMs){if(page<0||page>=pages.size())throw new IllegalArgumentException("Invalid page");return pageStartMs(page+1,durationMs);}
        public long minimumPageDurationMs(long durationMs){if(durationMs<=0)throw new IllegalArgumentException("Invalid duration");return pages.isEmpty()?durationMs:durationMs/pages.size();}
        public double codePointsPerSecond(long durationMs){if(durationMs<=0)throw new IllegalArgumentException("Invalid duration");return codePoints*1000.0/durationMs;}
    }
    private static final class Key {
        final Object metrics;final String text;final int size,width,rows;final boolean bold;
        Key(Object identity,String source,float fontSize,boolean heavy,float available,int maximum){metrics=identity;text=source;size=Float.floatToIntBits(fontSize);width=Float.floatToIntBits(available);rows=maximum;bold=heavy;}
        @Override public int hashCode(){return Objects.hash(metrics,text,size,width,rows,bold);}
        @Override public boolean equals(Object value){if(!(value instanceof Key))return false;Key key=(Key)value;return size==key.size&&width==key.width&&rows==key.rows&&bold==key.bold&&metrics.equals(key.metrics)&&text.equals(key.text);}
    }
    /** A non-null Painter measurement key must be an immutable font/locale
     * identity, never a Canvas, Activity or other UI object. Unknown adapters
     * return null and are safely measured without a shared cache. */
    public static Plan plan(Duwm1728BroadcastLayout.Painter painter,String source,float size,boolean bold,float width,int maximumRows){
        if(painter==null||Float.isNaN(size)||Float.isInfinite(size)||Float.isNaN(width)||Float.isInfinite(width)||size<=0||width<=0||maximumRows<1||maximumRows>4)throw new IllegalArgumentException("Invalid caption layout");
        String text=source==null?"":source;
        if(text.length()>500)throw new IllegalArgumentException("Caption exceeds the source cue limit");
        Object identity=painter.captionMeasurementKey();Key key=identity==null?null:new Key(identity,text,size,bold,width,maximumRows);
        if(key!=null)synchronized(CACHE){Plan found=CACHE.get(key);if(found!=null)return found;}
        Plan result=measure(painter,text,size,bold,width,maximumRows);
        if(key!=null)synchronized(CACHE){Plan existing=CACHE.get(key);if(existing!=null)return existing;CACHE.put(key,result);}
        return result;
    }
    private static Plan measure(Duwm1728BroadcastLayout.Painter painter,String text,float requested,boolean bold,float width,int maximumRows){
        List<Integer> ends=clusterEnds(text);boolean[] boundary=new boolean[text.length()+1];boundary[0]=true;for(int end:ends)boundary[end]=true;
        float size=requested;int previous=0;
        // Extremely wide joined emoji/combining sequences stay intact. This is
        // bounded by the 500-character source limit and happens once per plan.
        for(int end:ends){float measured=painter.measure(text.substring(previous,end),size,bold);if(measured>width)size=Math.max(Float.MIN_NORMAL,size*(width/measured)*.999f);previous=end;}
        ArrayList<Page> pages=new ArrayList<>();ArrayList<String> rows=new ArrayList<>();int start=0,pageStart=0;
        while(start<text.length()){
            int visibleStart=start;while(standaloneSpace(text,visibleStart,boundary))visibleStart++;
            if(visibleStart==text.length()){
                if(!rows.isEmpty())pages.add(new Page(rows,pageStart,text.length()));
                else if(!pages.isEmpty()){Page last=pages.remove(pages.size()-1);pages.add(new Page(last.lines,last.startChar,text.length()));}
                start=text.length();break;
            }
            int fit=visibleStart;
            // Font shaping is not assumed to have monotonic prefix widths.
            // At most 500 source characters are considered per uncached plan.
            for(int end:ends)if(end>visibleStart&&painter.measure(text.substring(visibleStart,end),size,bold)<=width)fit=end;
            if(fit==visibleStart){for(int end:ends)if(end>visibleStart){fit=end;break;}}
            int lineEnd=fit;
            if(fit<text.length()){
                int space=text.lastIndexOf(' ',fit);
                while(space>visibleStart&&!standaloneSpace(text,space,boundary))space=text.lastIndexOf(' ',space-1);
                if(space>visibleStart)lineEnd=space;
            }
            int next=lineEnd;while(standaloneSpace(text,next,boundary))next++;
            if(next==start)throw new IllegalStateException("Caption layout made no progress");
            int visibleEnd=lineEnd;while(visibleEnd>visibleStart&&standaloneSpace(text,visibleEnd-1,boundary))visibleEnd--;
            rows.add(text.substring(visibleStart,visibleEnd));start=next;
            if(rows.size()==maximumRows||start==text.length()){
                pages.add(new Page(rows,pageStart,start));rows.clear();pageStart=start;
            }
        }
        int rowCount=pages.isEmpty()?0:pages.size()>1?maximumRows:pages.get(0).lines.size();
        return new Plan(text,pages,rowCount,size,ends.size());
    }
    /** A space joined to a mark/ZWJ sequence is part of that visible cluster;
     * only standalone spacing may be consumed at a line or page boundary. */
    private static boolean standaloneSpace(String text,int at,boolean[] boundary){return at>=0&&at<text.length()&&text.charAt(at)<=' '&&boundary[at]&&boundary[at+1];}
    private static boolean extend(int cp){
        int type=Character.getType(cp);
        return type==Character.NON_SPACING_MARK||type==Character.COMBINING_SPACING_MARK||type==Character.ENCLOSING_MARK
            ||cp==0x200C||(cp>=0xFE00&&cp<=0xFE0F)||(cp>=0xE0100&&cp<=0xE01EF)
            ||(cp>=0x1F3FB&&cp<=0x1F3FF)||(cp>=0xE0020&&cp<=0xE007F);
    }
    private static boolean regional(int cp){return cp>=0x1F1E6&&cp<=0x1F1FF;}
    private static int hangul(int cp){
        if((cp>=0x1100&&cp<=0x115F)||(cp>=0xA960&&cp<=0xA97C))return 1;
        if((cp>=0x1160&&cp<=0x11A7)||(cp>=0xD7B0&&cp<=0xD7C6))return 2;
        if((cp>=0x11A8&&cp<=0x11FF)||(cp>=0xD7CB&&cp<=0xD7FB))return 3;
        if(cp>=0xAC00&&cp<=0xD7A3)return (cp-0xAC00)%28==0?4:5;return 0;
    }
    private static boolean hangulJoin(int before,int after){int a=hangul(before),b=hangul(after);return a==1&&(b==1||b==2||b==4||b==5)||(a==2||a==4)&&(b==2||b==3)||(a==3||a==5)&&b==3;}
    /** Protects surrogate pairs, combining marks, variation selectors, skin
     * tones, emoji tag/ZWJ sequences, paired flags and Hangul Jamo. It does not
     * claim full language-aware word segmentation or all Unicode tailoring. */
    static List<Integer> clusterEnds(String text){
        ArrayList<Integer> ends=new ArrayList<>();int at=0;
        while(at<text.length()){
            int cp=text.codePointAt(at);at+=Character.charCount(cp);boolean flag=regional(cp);
            if(flag&&at<text.length()&&regional(text.codePointAt(at)))at+=Character.charCount(text.codePointAt(at));
            while(at<text.length()){
                int next=text.codePointAt(at);
                if(extend(next)){at+=Character.charCount(next);continue;}
                if(hangulJoin(cp,next)){cp=next;at+=Character.charCount(next);continue;}
                if(next==0x200D){
                    at+=Character.charCount(next);if(at<text.length()){cp=text.codePointAt(at);at+=Character.charCount(cp);continue;}
                }
                break;
            }
            ends.add(at);
        }
        return ends;
    }
    // Package-visible diagnostics exercise real bounded cache behavior in host
    // tests without exposing cache controls in the application's user flow.
    static int cachedPlans(){synchronized(CACHE){return CACHE.size();}}
    static void clearCache(){synchronized(CACHE){CACHE.clear();}}
}
