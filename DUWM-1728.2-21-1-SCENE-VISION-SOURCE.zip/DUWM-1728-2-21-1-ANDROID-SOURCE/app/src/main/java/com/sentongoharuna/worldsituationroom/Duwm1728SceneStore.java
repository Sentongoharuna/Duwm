package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.net.Uri;
import android.util.AtomicFile;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Private, atomic scene sidecars. No images, addresses, tokens, or fabricated captions. */
public final class Duwm1728SceneStore {
    private static final int SCHEMA = 1;
    private static final int MAX_BYTES = 4 * 1024 * 1024;
    private static final String TAG = "DUWM-SCENES";

    private Duwm1728SceneStore() {}

    private static AtomicFile file(Context context, Uri source) throws IOException {
        if (context == null || source == null) throw new IOException("Video identity required");
        File directory = new File(context.getFilesDir(), "scene-timelines");
        if (!directory.isDirectory() && !directory.mkdirs())
            throw new IOException("Scene storage is unavailable");
        return new AtomicFile(new File(directory,
                Duwm1728CaptureTelemetry.storageKey(source) + ".json"));
    }

    /** An empty successful save still marks this as a scene-enabled capture. */
    public static synchronized boolean save(Context context, Uri source,
                                             List<Duwm1728SceneTimeline.Entry> entries) {
        FileOutputStream output = null;
        AtomicFile atomic = null;
        try {
            List<Duwm1728SceneTimeline.Entry> snapshot = Duwm1728SceneTimeline.normalize(entries);
            JSONObject value = new JSONObject();
            value.put("schema", SCHEMA);
            value.put("source_key", Duwm1728CaptureTelemetry.storageKey(source));
            value.put("scene_capture", true);
            JSONArray observations = new JSONArray();
            for (Duwm1728SceneTimeline.Entry entry : snapshot) {
                JSONObject item = new JSONObject();
                item.put("at_ms", entry.atMs);
                item.put("valid_until_ms", entry.validUntilMs);
                item.put("title", entry.title);
                item.put("description", entry.description);
                item.put("source", entry.source);
                observations.put(item);
            }
            value.put("observations", observations);
            byte[] bytes = value.toString().getBytes(StandardCharsets.UTF_8);
            if (bytes.length > MAX_BYTES) throw new IOException("Scene timeline is too large");
            atomic = file(context, source);
            output = atomic.startWrite();
            output.write(bytes);
            atomic.finishWrite(output);
            return true;
        } catch (Exception failure) {
            if (atomic != null && output != null) atomic.failWrite(output);
            Log.w(TAG, "Scene timeline could not be saved", failure);
            return false;
        }
    }

    /** Distinguishes an empty scene-enabled capture from an imported or legacy recording. */
    public static synchronized boolean hasCapture(Context context, Uri source) {
        try { return read(context, source) != null; }
        catch (Exception failure) {
            Log.w(TAG, "Scene capture marker could not be read", failure);
            return false;
        }
    }

    public static synchronized List<Duwm1728SceneTimeline.Entry> load(Context context, Uri source) {
        try {
            JSONObject value = read(context, source);
            if (value == null) return Collections.emptyList();
            JSONArray observations = value.getJSONArray("observations");
            if (observations.length() > Duwm1728SceneTimeline.MAX_ENTRIES)
                throw new IOException("Too many scene observations");
            List<Duwm1728SceneTimeline.Entry> result = new ArrayList<>();
            for (int index = 0; index < observations.length(); index++) {
                JSONObject item = observations.getJSONObject(index);
                result.add(new Duwm1728SceneTimeline.Entry(item.getLong("at_ms"),
                        item.getLong("valid_until_ms"), item.getString("title"),
                        item.getString("description"), item.getString("source")));
            }
            return Duwm1728SceneTimeline.normalize(result);
        } catch (Exception failure) {
            Log.w(TAG, "Scene timeline could not be read", failure);
            return Collections.emptyList();
        }
    }

    private static JSONObject read(Context context, Uri source) throws Exception {
        if (context == null || source == null) return null;
        AtomicFile atomic = file(context, source);
        if (!atomic.getBaseFile().exists()
                && !new File(atomic.getBaseFile().getPath() + ".bak").exists()) return null;
        try (InputStream input = atomic.openRead();
                ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int count;
            while ((count = input.read(buffer)) != -1) {
                if (bytes.size() + count > MAX_BYTES) throw new IOException("Scene data is too large");
                bytes.write(buffer, 0, count);
            }
            JSONObject value = new JSONObject(new String(bytes.toByteArray(), StandardCharsets.UTF_8));
            if (value.optInt("schema") != SCHEMA || !value.optBoolean("scene_capture")
                    || !Duwm1728CaptureTelemetry.storageKey(source).equals(value.optString("source_key")))
                throw new IOException("Scene timeline identity is invalid");
            return value;
        }
    }
}
