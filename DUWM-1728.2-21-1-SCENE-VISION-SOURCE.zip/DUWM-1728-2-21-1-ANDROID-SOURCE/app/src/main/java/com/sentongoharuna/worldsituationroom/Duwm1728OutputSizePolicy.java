package com.sentongoharuna.worldsituationroom;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Bounded automatic output planning, separate from Android codec discovery.
 * A selection describes advertised support only; configure, encode and decode
 * still have to succeed. The caller must use FIT to retain the whole source.
 */
public final class Duwm1728OutputSizePolicy {
    private Duwm1728OutputSizePolicy() {}
    private static final int[] LONG_EDGES={3840,2560,1920,1600,1280,960,640};
    public static final int MAX_CANDIDATES_PER_CODEC=1+LONG_EDGES.length;
    public static final int MIN_EDGE=64;

    /** The Android adapter checks the final format, including size/rate support. */
    public interface FormatSupport {
        boolean accepts(int width,int height,int fps,int bitrate);
    }

    /** Actual per-encoder bounds, in platform preference order. */
    public static final class Encoder {
        public final String name;
        public final int widthAlignment,heightAlignment,minWidth,maxWidth,minHeight,maxHeight,minBitrate,maxBitrate;
        private final FormatSupport support;
        public Encoder(String name,int widthAlignment,int heightAlignment,int minWidth,int maxWidth,
                       int minHeight,int maxHeight,int minBitrate,int maxBitrate,FormatSupport support){
            if(name==null||name.trim().isEmpty()||support==null)throw new IllegalArgumentException("Missing encoder capability");
            if(!powerOfTwo(widthAlignment)||!powerOfTwo(heightAlignment))throw new IllegalArgumentException("Invalid encoder alignment");
            if(minWidth<1||minHeight<1||maxWidth<minWidth||maxHeight<minHeight||minBitrate<1||maxBitrate<minBitrate)
                throw new IllegalArgumentException("Invalid encoder bounds");
            this.name=name;this.widthAlignment=Math.max(2,widthAlignment);this.heightAlignment=Math.max(2,heightAlignment);
            this.minWidth=minWidth;this.maxWidth=maxWidth;this.minHeight=minHeight;this.maxHeight=maxHeight;
            this.minBitrate=minBitrate;this.maxBitrate=maxBitrate;this.support=support;
        }
    }

    public static final class Selection {
        public final int width,height,fps,bitrate,formatsChecked;
        public final String encoder;
        private Selection(Candidate c,int fps,int checked){
            width=c.width;height=c.height;this.fps=fps;bitrate=c.bitrate;encoder=c.encoder.name;formatsChecked=checked;
        }
    }

    private static final class Candidate {
        final Encoder encoder;final int order,width,height,bitrate;
        Candidate(Encoder encoder,int order,int width,int height,int fps){
            this.encoder=encoder;this.order=order;this.width=width;this.height=height;
            bitrate=Math.max(encoder.minBitrate,Math.min(encoder.maxBitrate,requestedBitrate(width,height,fps)));
        }
    }

    private static boolean powerOfTwo(int n){return n>0&&(n&(n-1))==0;}

    /** The existing quality target, bounded before multiplication can overflow. */
    public static int requestedBitrate(int width,int height,int fps){
        if(width<2||height<2||fps<1||fps>120)throw new IllegalArgumentException("Invalid output format");
        return (int)Math.min(80000000d,Math.max(5000000d,(double)width*height*fps/5d));
    }

    /** Selects the largest advertised canvas in this bounded candidate set.
     * The source-sized candidate is first when its alignment is supported.
     * Codec bounds and fixed long-edge steps then generate smaller canvases;
     * all are even, aligned and no larger than either requested dimension.
     * Minor aspect changes caused by alignment are handled by FIT, never crop.
     * Equal canvas sizes keep the platform's codec preference order. No frame
     * rate conversion or media work occurs here, and no codec is assumed usable.
     */
    public static Selection select(int requestedWidth,int requestedHeight,int fps,List<Encoder> encoders){
        if(requestedWidth<MIN_EDGE||requestedHeight<MIN_EDGE)
            throw new IllegalArgumentException("Automatic broadcast output needs at least 64 × 64 source pixels");
        if(fps<1||fps>120)throw new IllegalArgumentException("Unsupported output frame rate");
        if(encoders==null)throw new IllegalArgumentException("Missing advertised encoders");
        List<Candidate> candidates=new ArrayList<>();
        for(int index=0;index<encoders.size();index++){
            Encoder encoder=encoders.get(index);if(encoder==null)continue;
            Set<Long> seen=new HashSet<>();
            add(candidates,seen,encoder,index,requestedWidth,requestedHeight,fps,Math.max(requestedWidth,requestedHeight));
            for(int edge:LONG_EDGES)add(candidates,seen,encoder,index,requestedWidth,requestedHeight,fps,edge);
        }
        candidates.sort(Comparator.<Candidate>comparingLong(c->(long)c.width*c.height).reversed()
            .thenComparingInt(c->c.order));
        int checked=0;
        for(Candidate c:candidates){
            checked++;
            try{if(c.encoder.support.accepts(c.width,c.height,fps,c.bitrate))return new Selection(c,fps,checked);}
            catch(RuntimeException malformedAdvertisement){/* A broken codec entry cannot certify this candidate. */}
        }
        return null;
    }

    private static void add(List<Candidate> list,Set<Long> seen,Encoder encoder,int order,int sourceWidth,int sourceHeight,int fps,int edge){
        double scale=Math.min(1d,Math.min((double)encoder.maxWidth/sourceWidth,(double)encoder.maxHeight/sourceHeight));
        scale=Math.min(scale,(double)edge/Math.max(sourceWidth,sourceHeight));
        int width=Math.min(sourceWidth,(int)Math.floor(sourceWidth*scale+1e-7));
        int height=Math.min(sourceHeight,(int)Math.floor(sourceHeight*scale+1e-7));
        width-=width%encoder.widthAlignment;height-=height%encoder.heightAlignment;
        if(width<Math.max(MIN_EDGE,encoder.minWidth)||height<Math.max(MIN_EDGE,encoder.minHeight)
                ||width>encoder.maxWidth||height>encoder.maxHeight)return;
        long key=((long)width<<32)|(height&0xffffffffL);
        if(seen.add(key))list.add(new Candidate(encoder,order,width,height,fps));
    }
}
