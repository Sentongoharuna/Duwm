package com.sentongoharuna.worldsituationroom;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** V12 starts here. Every tile opens an actual compiled activity, not a mockup. */
public final class RunningballV12HubActivity extends Activity {
  private static final int BG=0xFF041424, INK=0xFFE4EDFE, DIM=0xFF4C78C4;
  private static final int CYAN=0xFF558BDF, GREEN=DuwmUnifiedTheme.STATUS_GREEN, GOLD=0xFF558BDF;
            private TextView signalSummary;
            private RunningballV16CommandDeck commandDeck;
            private RunningballV17PulsePanel v17Pulse;
  private RunningballV20LiveFeedPulse v20Pulse;
  private TextView v22Status;
  private RunningballV23ControlBar v23Control;
  private RunningballV25Stage1Panel v25Stage1;
  private RunningballV25Stage2Panel v25Stage2;
  private int dp(float d){return Math.round(getResources().getDisplayMetrics().density*d);}
  private GradientDrawable panel(int accent){
    GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
      new int[]{0xEE19365F,0xF00A1C3B});
    g.setCornerRadius(dp(19));g.setStroke(dp(1),accent);return g;
  }
  private TextView text(String s,int sp,int color,boolean bold){
    TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(sp);
    if(bold)t.setTypeface(null,1);return t;
  }
  private void margin(LinearLayout parent,android.view.View v,int top){
    LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(top);parent.addView(v,p);
  }
  private void go(String activity){
    Intent i=new Intent();
    i.setClassName(getPackageName(),"com.sentongoharuna.worldsituationroom."+activity);
    try{startActivity(i);}catch(Exception e){
      android.widget.Toast.makeText(this,"Unable to open "+activity,android.widget.Toast.LENGTH_LONG).show();
    }
  }
  private void tile(LinearLayout parent,String tag,String heading,String detail,String source,String activity,int accent){
    LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);
    p.setPadding(dp(17),dp(13),dp(17),dp(15));p.setBackground(panel(accent));
    p.addView(text(tag,10,accent,true));
    margin(p,text(heading+"   ›",17,INK,true),5);
    margin(p,text(detail,12,DIM,false),6);
    margin(p,text(source,10,accent,false),9);
    p.setClickable(true);p.setFocusable(true);p.setOnClickListener(v->go(activity));
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(11);parent.addView(p,lp);
  }
  @Override protected void onResume(){super.onResume();
    if(signalSummary!=null)signalSummary.setText(RunningballV13SignalsActivity.summary(this));
              if(commandDeck!=null)commandDeck.start();
              if(v17Pulse!=null)v17Pulse.start();if(v20Pulse!=null)v20Pulse.start();}
  @Override protected void onPause(){if(commandDeck!=null)commandDeck.stop();if(v17Pulse!=null)v17Pulse.stop();if(v20Pulse!=null)v20Pulse.stop();super.onPause();}
            @Override public void onCreate(Bundle saved){super.onCreate(saved);RunningballV17Insets.install(this);
    getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
    LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);
    body.setPadding(dp(18),dp(20),dp(18),dp(24));scroll.addView(body);
    body.addView(text("RUNNINGBALL2 · V25 STAGE 2 / ALL STAGES VISIBLE",10,GREEN,true));
    margin(body,text("GLOBAL SIGNALS\nCOMMAND CENTER",26,INK,true),8);
    margin(body,text("Live source summaries + direct native modules • no hidden navigation",12,DIM,false),9);
    TextView dataSourcesShortcut=text("V19  •  LIVE DATA SOURCES  /  CHECK CONNECTIONS",12,GREEN,true);
    margin(body,dataSourcesShortcut,10);
    dataSourcesShortcut.setOnClickListener(v->go("RunningballV19SourceCenterActivity"));
              signalSummary=text("LOADING VERIFIED SOURCE SNAPSHOTS …",14,GREEN,true);
    signalSummary.setPadding(dp(14),dp(14),dp(14),dp(14));
    signalSummary.setBackground(panel(CYAN));
    v22Status=text("V22 / WORLD STATUS  ·  AWAITING VERIFIED FEEDS",12,GREEN,true);
    v22Status.setPadding(dp(14),dp(13),dp(12),dp(13));
    v22Status.setBackground(panel(GREEN));
    v25Stage2=new RunningballV25Stage2Panel(this);
    margin(body,v25Stage2,8);
    v25Stage1=new RunningballV25Stage1Panel(this);
    margin(body,v25Stage1,9);
    margin(body,v22Status,9);
    v23Control=new RunningballV23ControlBar(this);
    margin(body,v23Control,8);
    commandDeck=new RunningballV16CommandDeck(this);
    margin(body,commandDeck,10);
    v20Pulse=new RunningballV20LiveFeedPulse(this);
    v20Pulse.bindV22(v22Status);
    margin(body,v20Pulse,10);
    v22Status.setOnClickListener(v->scroll.post(()->scroll.smoothScrollTo(0,v20Pulse.getTop())));
              v17Pulse=new RunningballV17PulsePanel(this);
              margin(body,v17Pulse,9);
              margin(body,signalSummary,10);
              margin(body,text("V14 HOME WIDGET: Add RUNNINGBALL2 from your home-screen widget picker. Tap AIR / SAT / SEA for direct details.",12,GOLD,true),12);
    margin(body,text("MORE INTELLIGENCE MODULES  /  OPEN DETAIL",11,GREEN,true),14);
              tile(body,"V19 / REAL PROVIDER STATUS","LIVE DATA SOURCES",
      "Actual feed success times, genuine counts, region restrictions, provider failures, and NOAA space weather.",
      "NO DUMMY COUNTS • SOURCE-SPECIFIC FRESHNESS","RunningballV19SourceCenterActivity",GREEN);
    tile(body,"V15  /  FUNCTIONAL VERIFICATION","OPEN SOURCE HEALTH",
      "Real source timestamps, fetch errors, AIS configuration and explicit data refresh.",
      "NO FAKE COUNTS • AIR FETCH IS REAL","RunningballV15SourceHealthActivity",GREEN);
    tile(body,"NEW V13  /  DATA INSPECTOR","OPEN GLOBAL SIGNALS",
      "Aircraft, satellite and vessel reports with source ages and source status.",
      "REAL STORED COUNTS ONLY • NO DEMO DATA","RunningballV13SignalsActivity",CYAN);
    tile(body,"ORIGINAL MONITOR  /  PRESERVED","OPEN THE ORIGINAL APP",
      "Existing world monitor, original globe and reporting functionality.","NO ORIGINAL MONITOR FUNCTIONS REMOVED","MainActivity",GREEN);
    tile(body,"WORLD  /  ANY COUNTRY","WORLDWIDE EARTH",
                "Select any place on Earth; regional aircraft observations follow the selected map center.",
                "GLOBAL MAP  •  LOCATION SEARCH  •  REAL SOURCE STATUS","RunningballWorldExplorerActivity",GREEN);
              tile(body,"GLOBAL  /  NATURAL EVENTS","EARTHQUAKES & NASA EVENTS",
                "Latest reported earthquakes and curated natural events around the planet.",
                "USGS • NASA EONET • OBSERVED REPORTS","RunningballGlobalEventsActivity",CYAN);
              tile(body,"AIR  /  ADS-B REPORTS","AIRCRAFT RADAR",
      "Observed aircraft positions, aircraft details and radar interactions.","PUBLIC ADSB.LOL • REPORTED POSITIONS","AirRadarActivity",CYAN);
    tile(body,"AIR  /  NEAREST CONTACTS","AIRCRAFT CONTACTS",
      "Search, range selection, detail cards and aircraft share cards.","PUBLIC ADSB.LOL • CHECK REPORT AGE","GevContactsActivity",CYAN);
    tile(body,"AIR  /  FLIGHT DETAIL","COCKPIT & CHASE",
      "Cockpit-style telemetry and reported-position chase view.","NO LIVE CAMERA OR PREDICTED VIDEO","GevCockpitActivity",GREEN);
    tile(body,"EARTH  /  GEO EXPLORER","EARTH EXPLORER",
      "Map exploration with direct navigation from aircraft, satellites and ships.","TILE AVAILABILITY DEPENDS ON PUBLIC SOURCE","GevEarthExploreActivity",CYAN);
    tile(body,"ORBIT  /  CELESTRAK","SATELLITE INTELLIGENCE",
      "Public satellite catalogues, estimated positions and satellite widget.","TWO-BODY ESTIMATES • NOT REAL-TIME TRACKING","GevSatelliteActivity",GOLD);
    tile(body,"SEA  /  AIS","MARITIME INTELLIGENCE",
      "Vessel radar, MMSI, vessel details, share cards and marine widget.","HTTPS AIS GATEWAY REQUIRED • NO FABRICATED SHIPS","GevMarineActivity",GOLD);
    tile(body,"WALLPAPER  /  PROTECTED","SET LIVE GLOBE WALLPAPER",
      "Launch the original rotating globe wallpaper chooser.","ORIGINAL 33-MS ENGINE UNCHANGED","LiveWallpaperLauncherActivity",GREEN);
    margin(body,text("V16  •  WORLDWIDE COMMAND GRID  •  SOURCE-TRUTH GUARDED",10,DIM,false),17);
    setContentView(scroll);
  }
}
