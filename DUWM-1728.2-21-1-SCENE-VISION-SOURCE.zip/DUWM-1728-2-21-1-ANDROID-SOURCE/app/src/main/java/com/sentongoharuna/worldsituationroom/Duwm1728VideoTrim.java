package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import java.io.File;
import java.nio.ByteBuffer;
import java.util.ArrayList;

/** Lossless, non-destructive trim of MP4 audio/video samples; no invented frames. */
public final class Duwm1728VideoTrim {
    private Duwm1728VideoTrim() {}
    public static File trim(Context ctx, Uri original, long fromMs, long untilMs) throws Exception {
        if(fromMs<0 || untilMs<=fromMs || untilMs-fromMs>60L*60L*1000L)
            throw new IllegalArgumentException("Invalid clip range");
        File out=File.createTempFile("DUWM_TRIM_", ".mp4", ctx.getCacheDir());
        boolean complete=false;
        MediaExtractor extractor=new MediaExtractor(); MediaMuxer muxer=null;
        try (ParcelFileDescriptor input=ctx.getContentResolver().openFileDescriptor(original,"r")) {
            if(input==null)throw new IllegalArgumentException("Original recording inaccessible");
            extractor.setDataSource(input.getFileDescriptor());
            muxer=new MediaMuxer(out.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int trackCount=extractor.getTrackCount();
            int[] destinations=new int[trackCount];
            java.util.Arrays.fill(destinations,-1);
            int count=0,bufferSize=1048576;
            for(int index=0;index<trackCount;index++){
                MediaFormat fmt=extractor.getTrackFormat(index);
                String mime=fmt.getString(MediaFormat.KEY_MIME);
                if(mime==null || !(mime.startsWith("video/") || mime.startsWith("audio/")))continue;
                destinations[index]=muxer.addTrack(fmt);extractor.selectTrack(index);count++;
                if(fmt.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE))
                    bufferSize=Math.max(bufferSize,fmt.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE));
            }
            if(count==0)throw new IllegalArgumentException("No compatible audio/video tracks");
            muxer.start();
            long fromUs=fromMs*1000L,untilUs=untilMs*1000L;
            extractor.seekTo(fromUs,MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            ByteBuffer buffer=ByteBuffer.allocateDirect(Math.min(Math.max(bufferSize,1048576),16*1048576));
            MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
            long firstWritten=-1L;int total=0;
            while(true){
                int track=extractor.getSampleTrackIndex();if(track<0)break;
                long timestamp=extractor.getSampleTime();if(timestamp<0||timestamp>=untilUs)break;
                int dest=destinations[track];
                if(dest>=0){
                    buffer.clear();int bytes=extractor.readSampleData(buffer,0);
                    if(bytes<0)break;
                    // Include preceding video keyframe to preserve decodability of the trimmed MP4.
                    if(timestamp>=fromUs || (firstWritten<0&&timestamp>=0)){
                        if(firstWritten<0)firstWritten=timestamp;
                        info.offset=0;info.size=bytes;
                        info.presentationTimeUs=Math.max(0L,timestamp-firstWritten);
                        info.flags=extractor.getSampleFlags();
                        muxer.writeSampleData(dest,buffer,info);total++;
                    }
                }
                extractor.advance();
            }
            if(total<2)throw new IllegalArgumentException("Requested period has too few samples");
            complete=true;return out;
        } finally {
            try{extractor.release();}catch(Exception ignored){}
            if(muxer!=null){try{muxer.stop();}catch(Exception ignored){}try{muxer.release();}catch(Exception ignored){}}
            if(!complete)out.delete();
        }
    }
}
