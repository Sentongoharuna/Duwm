package com.sentongoharuna.worldsituationroom;
import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
/** One real, source-backed detail for each of the nine Stage 2 boards. */
public final class RunningballV25Stage2BoardActivity extends Activity {
  private static final int BG=0xFF041424,CYAN=0xFF558BDF,GREEN=DuwmUnifiedTheme.STATUS_GREEN,AMBER=DuwmUnifiedTheme.STATUS_ORANGE,INK=0xFFE0EAFE,MUTED=0xFF7799C3;
  private int index;private TextView figure,age,scope,note,history,delta;
  private RunningballV25Stage2Sparkline chart;private RunningballV25Stage2GeoView geo;private TextView motionState;private long previousStamp=0L,lastRequest=0L;private String previousValue="--";
  private final Handler main=new Handler(Looper.getMainLooper());private boolean visible=false;
  private final Runnable tick=new Runnable(){public void run(){if(!visible)return;refreshView();main.postDelayed(this,1000L);}};
  private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
  private TextView txt(String v,int sp,int tint,boolean bold){TextView t=new TextView(this);t.setText(v);t.setTextSize(sp);t.setTextColor(tint);if(bold)t.setTypeface(null,1);return t;}
  private GradientDrawable panel(int border){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFF0C1B39,BG});d.setCornerRadius(dp(13));d.setStroke(dp(1),border);return d;}
  private void add(LinearLayout parent,android.view.View child,int top){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(top);parent.addView(child,lp);}
  private void action(LinearLayout parent,String label,Runnable job){TextView b=txt(label,12,CYAN,true);b.setGravity(Gravity.CENTER);b.setMinHeight(dp(48));b.setPadding(dp(8),dp(13),dp(8),dp(13));b.setBackground(panel(CYAN));b.setContentDescription(label);b.setOnClickListener(v->job.run());add(parent,b,9);}
  @Override public void onCreate(Bundle state){super.onCreate(state);RunningballV17Insets.install(this);
    index=getIntent().getIntExtra("board",0);if(index<0||index>=9){finish();return;}
    getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
    LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(17),dp(20),dp(17),dp(80));scroll.addView(body);
    action(body,"‹  BACK TO COMMAND CENTER",this::finish);
    add(body,txt("V25 / STAGE 2 / VERIFIED SOURCE BOARD",11,GREEN,true),15);
    add(body,txt(RunningballV25Sources.NAMES[index],24,INK,true),9);
    figure=txt("--",42,INK,true);add(body,figure,12);
    age=txt("AWAITING RECEIVED DATA",13,AMBER,true);add(body,age,5);
    scope=txt("COVERAGE UNKNOWN",12,MUTED,false);add(body,scope,8);
    note=txt("NO DATA YET",12,AMBER,false);add(body,note,9);
    delta=txt("",12,GREEN,true);add(body,delta,6);
    add(body,txt("RECEIVED POSITION SIGNALS / SOURCE-REPORTED ONLY",10,CYAN,true),13);
    geo=new RunningballV25Stage2GeoView(this,index);add(body,geo,7);
    motionState=txt("REDUCE MOTION: CHECKING",11,MUTED,false);
    motionState.setContentDescription("Toggle data update animation, never modifies reported values");
    motionState.setMinHeight(dp(48));motionState.setPadding(dp(8),dp(14),dp(8),dp(14));
    motionState.setBackground(panel(CYAN));motionState.setOnClickListener(v->{
      android.content.SharedPreferences prefs=getSharedPreferences("rb25_visual_preferences",MODE_PRIVATE);
      prefs.edit().putBoolean("reduce_motion",!prefs.getBoolean("reduce_motion",false)).apply();
      refreshView();
    });add(body,motionState,7);
    add(body,txt("RECEIVED-VALUE TREND · ONE SAMPLE PER REAL SOURCE UPDATE",10,CYAN,true),16);
    chart=new RunningballV25Stage2Sparkline(this);add(body,chart,7);
    history=txt("NO VERIFIED EVENTS",11,INK,false);add(body,history,11);
    action(body,"OPEN NATIVE INTELLIGENCE DETAIL",this::openNativeDetail);
    action(body,"SOURCE HEALTH AND PROVIDER",()->startActivity(new Intent(this,RunningballV25SourceHealthActivity.class)));
    action(body,"REQUEST VERIFIED SOURCE UPDATE",this::request);
    action(body,"SHARE SOURCE REPORT",this::share);
    add(body,txt("Missing data are shown as --, never as zero. Position and timing estimates are labelled in their native views.",11,MUTED,false),18);
    setContentView(scroll);refreshView();
  }
  private void refreshView(){RunningballV25Sources.Result r=RunningballV25Sources.read(this,index);
    RunningballV25Stage2History.update(this,index);RunningballV25ChangeLedger.update(this);
    boolean newReport=r.fetchedAt>0&&r.fetchedAt!=previousStamp&&previousStamp>0;
    if(newReport&&!"--".equals(previousValue)&&!"--".equals(r.value)&&!previousValue.equals(r.value)){
      delta.setText("REPORTED CHANGE: "+previousValue+" → "+r.value);delta.setAlpha(1f);delta.animate().alpha(.25f).setDuration(10000L).start();
      figure.setAlpha(.4f);figure.animate().alpha(1f).setDuration(450L).start();
    }
    if(r.fetchedAt>0){previousStamp=r.fetchedAt;previousValue=r.value;}
    figure.setText(r.value);int tint=r.status==RunningballV25Sources.Status.LIVE?GREEN:AMBER;
    age.setText(index==7?"DAILY FX REFERENCE · LAST FETCH "+r.age():r.display());age.setTextColor(tint);
    scope.setText("PROVIDER: "+r.provider+"\nCOVERAGE: "+r.coverage+"\nLAST SUCCESS: "+(r.fetchedAt<=0?"NONE":new java.util.Date(r.fetchedAt).toString()));
    note.setText(r.errorReason.isEmpty()?"PROVIDER STATUS: "+r.status:"PROVIDER ERROR: "+r.errorReason);
    chart.setPoints(RunningballV25Stage2History.points(this,index));
    geo.update(r);
    motionState.setText("REDUCE MOTION  ·  "+(getSharedPreferences("rb25_visual_preferences",MODE_PRIVATE).getBoolean("reduce_motion",false)?"ON":"OFF")+"  /  TAP TO TOGGLE");
    history.setText("VERIFIED SOURCE ACTIVITY\n"+RunningballV25ChangeLedger.summary(this));
  }
  private void request(){long now=System.currentTimeMillis();if(now-lastRequest<60000L){note.setText("REQUEST COOLDOWN / TRY AGAIN IN ONE MINUTE");return;}
    lastRequest=now;note.setText("REQUEST ISSUED / RESULTS NOT CONFIRMED");Context app=getApplicationContext();
    Runnable done=()->main.post(this::refreshView);
    try{RunningballV16SourceRefresh.request(app,false,done);}catch(RuntimeException e){note.setText("UPDATE REQUEST FAILED: "+e.getClass().getSimpleName());}
    try{RunningballV17Feeds.request(app,false,done);}catch(RuntimeException ignored){}
    try{RunningballV19SatelliteBootstrap.request(app,done);}catch(RuntimeException ignored){}
    try{RunningballV19Noaa.request(app,done);}catch(RuntimeException ignored){}
    if(RunningballWorldTarget.ready(app)){Intent i=new Intent(app,AirOperationsWidgets.Pulse.class);i.setAction("com.sentongoharuna.worldsituationroom.AIR_WIDGET_REFRESH");i.setPackage(app.getPackageName());app.sendBroadcast(i);}
  }
  private void openNativeDetail(){Class<?> target=RunningballV19SourceCenterActivity.class;Intent intent=null;
    switch(index){case 0:target=AirRadarActivity.class;break;case 1:target=GevSatelliteActivity.class;break;
      case 2:target=GevMarineActivity.class;break;case 3:case 4:target=RunningballGlobalEventsActivity.class;break;
      case 5:case 6:case 7:target=RunningballV17DetailsActivity.class;break;case 8:target=RunningballV19SourceCenterActivity.class;break;default:break;}
    intent=new Intent(this,target);
    if(index==5)intent.putExtra("feed",RunningballV17Feeds.NEWS);
    if(index==6)intent.putExtra("feed",RunningballV17Feeds.WEATHER);
    if(index==7)intent.putExtra("feed",RunningballV17Feeds.FX);
    startActivity(intent);
  }
  private void share(){RunningballV25Sources.Result r=RunningballV25Sources.read(this,index);
    String s="RUNNINGBALL2 V25 · STAGE 2\n"+RunningballV25Sources.NAMES[index]+": "+r.value+"\nSTATUS: "+r.display()+
      "\nPROVIDER: "+r.provider+"\nCOVERAGE: "+r.coverage+"\n"+(r.fetchedAt>0?"RECEIVED: "+new java.util.Date(r.fetchedAt):"NO VERIFIED REPORT")+"\nNO WORLDWIDE TOTAL IMPLIED";
    Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,s);startActivity(Intent.createChooser(send,"Share sourced observation"));
  }
  @Override protected void onResume(){super.onResume();visible=true;main.post(tick);}
  @Override protected void onPause(){visible=false;main.removeCallbacks(tick);delta.animate().cancel();figure.animate().cancel();super.onPause();}
}
