package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.Intent;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.speech.RecognitionListener;
import android.speech.RecognitionSupport;
import android.speech.RecognitionSupportCallback;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** Optional on-device transcription of decoded source audio. Exact-intent support
 * and segmented file-session callbacks are required. Ordinary microphone-style
 * results are never accepted. These API checks cannot audit a recognizer service's
 * implementation; unavailable or indeterminate support fails closed.
 */
public final class Duwm1728RecordedAudioTranscriber {
    public interface Listener {
        void done(Result result);void error(String message);
        /** UI-thread readiness/language update, not a recognition success. */
        default void status(String message){}
    }
    public static final class Result {
        public final String text,timedCaptions,timingKind,timingNote,requestedLanguage,selectedLanguage;
        /** Compatibility name: validated REPORTED starts, not independently verified speech or measured ends. */
        public final boolean hasVerifiedWordTimes;
        /** Exact supported file session and full PCM delivery completed with no words.
         * This says nothing about whether the source was acoustically silent. */
        public final boolean completedWithoutWords;
        public final List<Duwm1728BroadcastLayout.Cue> cues;
        Result(String text,List<Duwm1728BroadcastLayout.Cue> cues,String note,long fromMs){
            this(text,cues,note,fromMs,false);
        }
        Result(String text,List<Duwm1728BroadcastLayout.Cue> cues,String note,long fromMs,boolean noWords){
            this(text,cues,note,fromMs,noWords,"","");
        }
        Result(String text,List<Duwm1728BroadcastLayout.Cue> cues,String note,long fromMs,boolean noWords,
               String requestedLanguage,String selectedLanguage){
            if(noWords&&(!text.isEmpty()||!cues.isEmpty()))throw new IllegalArgumentException("A no-word result cannot contain transcript words or captions");
            this.text=text;this.cues=Collections.unmodifiableList(new ArrayList<>(cues));
            this.requestedLanguage=requestedLanguage==null?"":requestedLanguage;
            this.selectedLanguage=selectedLanguage==null?"":selectedLanguage;
            completedWithoutWords=noWords;hasVerifiedWordTimes=!cues.isEmpty();
            timingKind=noWords?Duwm1728SpeechSessionPolicy.NO_WORDS_RETURNED
                    :hasVerifiedWordTimes?Duwm1728SpeechCues.REPORTED_STARTS_DERIVED_ENDS:Duwm1728SpeechCues.TEXT_ONLY_UNTIMED;
            timingNote=note;timedCaptions=hasVerifiedWordTimes?Duwm1728SpeechCues.legacy(cues,fromMs):"";
        }
    }
    private final Context context;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final AtomicBoolean started=new AtomicBoolean(),finished=new AtomicBoolean();
    private final Object audioLock=new Object();
    private SpeechRecognizer recognizer;
    private ParcelFileDescriptor readPipe,writePipe;
    private OutputStream activeWriteStream;
    private volatile Thread decodeThread;
    private Listener callbacks;
    private long fromMs,toMs,supportDeadline;
    private boolean supportConfirmed,recognitionStarted,segmentedEnded,audioComplete,timingUsable=true;
    private int segments;
    private String timingProblem="Word timestamps were not supplied",requestedLanguage="",selectedLanguage="";
    private Duwm1728SpeechLanguagePolicy.SupportFlow supportFlow;
    private final StringBuilder transcript=new StringBuilder();
    private final ArrayList<Duwm1728SpeechCues.Word> words=new ArrayList<>();
    private Runnable supportTimeout;
    private final Runnable recognitionTimeout=()->fail("On-device service did not complete a confirmed recorded-file session in time");

    public Duwm1728RecordedAudioTranscriber(Context context){this.context=context.getApplicationContext();}
    public static boolean canAttempt(Context context){
        if(Build.VERSION.SDK_INT<33)return false;
        try{return SpeechRecognizer.isOnDeviceRecognitionAvailable(context);}catch(RuntimeException unavailable){return false;}
    }
    public void transcribe(Uri video,long fromMs,long toMs,Listener listener){
        if(Looper.myLooper()!=Looper.getMainLooper())throw new IllegalStateException("Start transcription on the UI thread");
        if(listener==null)throw new IllegalArgumentException("A transcription listener is required");
        if(!started.compareAndSet(false,true)||finished.get()){listener.error("This transcription request is already finished or in use");return;}
        callbacks=listener;this.fromMs=fromMs;this.toMs=toMs;
        if(!canAttempt(context)){fail("On-device recorded-audio recognition is unavailable on this phone");return;}
        if(video==null||fromMs<0||toMs<=fromMs||toMs-fromMs>Duwm1728PcmTimeline.MAX_DURATION_MS||toMs>Long.MAX_VALUE/1000){fail("Select an audio range of at most 45 seconds");return;}
        try {
            ParcelFileDescriptor[] pipes=ParcelFileDescriptor.createPipe();
            synchronized(audioLock){readPipe=pipes[0];writePipe=pipes[1];}
            recognizer=SpeechRecognizer.createOnDeviceSpeechRecognizer(context);
            recognizer.setRecognitionListener(recognitionListener());
            requestedLanguage=deviceLanguage();
            supportFlow=new Duwm1728SpeechLanguagePolicy.SupportFlow(requestedLanguage,Duwm1728RecordedAudioTranscriber::likelyScript);
            supportDeadline=SystemClock.elapsedRealtime()+10000;
            checkSupport(video,supportFlow.begin());
        }catch(Exception unavailable){fail("Cannot check recorded-file recognition: "+message(unavailable));}
    }
    static String deviceLanguage(){return Duwm1728SpeechLanguagePolicy.normalize(Locale.getDefault().stripExtensions().toLanguageTag());}
    static String likelyScript(String tag){
        try{return android.icu.util.ULocale.addLikelySubtags(android.icu.util.ULocale.forLanguageTag(tag)).getScript();}
        catch(RuntimeException unavailable){return "";}
    }
    /** Shared by live readiness and actual transcription. Neither caller mutates
     * this request after checking it. The audio descriptor is always explicit. */
    static Intent recordedFileRequest(String language,ParcelFileDescriptor pipe){
        String tag=Duwm1728SpeechLanguagePolicy.normalize(language);
        if(tag.isEmpty()||pipe==null||!pipe.getFileDescriptor().valid())throw new IllegalArgumentException("A valid language and recorded-audio pipe are required");
        Intent request=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE,tag)
                .putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE,pipe)
                .putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT,1)
                .putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING,AudioFormat.ENCODING_PCM_16BIT)
                .putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE,Duwm1728PcmTimeline.OUTPUT_RATE)
                .putExtra(RecognizerIntent.EXTRA_SEGMENTED_SESSION,RecognizerIntent.EXTRA_AUDIO_SOURCE)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true);
        if(Build.VERSION.SDK_INT>=34)request.putExtra(RecognizerIntent.EXTRA_REQUEST_WORD_TIMING,true);
        return request;
    }
    private void checkSupport(Uri video,Duwm1728SpeechLanguagePolicy.Decision decision){
        if(finished.get()||recognitionStarted||decision.action==Duwm1728SpeechLanguagePolicy.Action.IGNORE)return;
        if(decision.action!=Duwm1728SpeechLanguagePolicy.Action.CHECK){fail(decision.message);return;}
        final int check=decision.checkNumber;
        long remaining=supportDeadline-SystemClock.elapsedRealtime();
        if(remaining<=0){fail("On-device service did not confirm recorded-file support within 10 seconds");return;}
        final long checkDeadline=Math.min(supportDeadline,SystemClock.elapsedRealtime()+5000);
        final Intent request;
        try{request=recordedFileRequest(decision.selectedLanguage,readPipe);}
        catch(Exception invalid){fail("Cannot prepare recorded-file recognition: "+message(invalid));return;}
        if(callbacks!=null)callbacks.status(decision.message);
        if(finished.get())return;
        if(supportTimeout!=null)main.removeCallbacks(supportTimeout);
        supportTimeout=()->{
            if(finished.get()||recognitionStarted)return;
            Duwm1728SpeechLanguagePolicy.Decision timeout=supportFlow.error(check,"On-device service did not confirm recorded-file support within 5 seconds (check "+check+" of at most 2)");
            if(timeout.action!=Duwm1728SpeechLanguagePolicy.Action.IGNORE)fail(timeout.message);
        };
        main.postDelayed(supportTimeout,Math.max(0,checkDeadline-SystemClock.elapsedRealtime()));
        // A language change has its own exact request check. No PCM is supplied
        // and no listening begins until that final request reports installed support.
        try{recognizer.checkRecognitionSupport(request,command->main.post(command),new RecognitionSupportCallback(){
                @Override public void onSupportResult(RecognitionSupport support){
                    if(finished.get()||recognitionStarted)return;
                    try{
                        if(SystemClock.elapsedRealtime()>=checkDeadline){
                            Duwm1728SpeechLanguagePolicy.Decision expired=supportFlow.error(check,"On-device recorded-file support arrived after its bounded check expired");
                            if(expired.action!=Duwm1728SpeechLanguagePolicy.Action.IGNORE)fail(expired.message);
                            return;
                        }
                        if(support==null){onError(SpeechRecognizer.ERROR_CANNOT_CHECK_SUPPORT);return;}
                        Duwm1728SpeechLanguagePolicy.Decision next=supportFlow.support(check,support.getInstalledOnDeviceLanguages(),
                                support.getPendingOnDeviceLanguages(),support.getSupportedOnDeviceLanguages());
                        if(next.action==Duwm1728SpeechLanguagePolicy.Action.IGNORE)return;
                        if(supportTimeout!=null)main.removeCallbacks(supportTimeout);
                        if(next.action==Duwm1728SpeechLanguagePolicy.Action.CHECK){checkSupport(video,next);return;}
                        if(next.action!=Duwm1728SpeechLanguagePolicy.Action.READY){fail(next.message);return;}
                        selectedLanguage=next.selectedLanguage;
                        if(callbacks!=null)callbacks.status("Using installed "+selectedLanguage+" for recorded captions"
                                +(selectedLanguage.equals(requestedLanguage)?"":" (device language "+requestedLanguage+")"));
                        if(finished.get())return;
                        supportConfirmed=true;recognitionStarted=true;recognizer.startListening(request);
                        if(finished.get())return;
                        main.postDelayed(recognitionTimeout,Math.min(55000,Math.max(10000,toMs-fromMs+10000)));
                        startAudio(video);
                    }catch(Exception unavailable){fail("Cannot use the confirmed recorded-file session: "+message(unavailable));}
                }
                @Override public void onError(int error){
                    if(finished.get()||recognitionStarted)return;
                    Duwm1728SpeechLanguagePolicy.Decision failed=supportFlow.error(check,"Recorded-file recognition support is unavailable or indeterminate (service error "+error+")");
                    if(failed.action!=Duwm1728SpeechLanguagePolicy.Action.IGNORE)fail(failed.message);
                }
            });
        }catch(Exception unavailable){
            Duwm1728SpeechLanguagePolicy.Decision failed=supportFlow.error(check,"Cannot check recorded-file recognition: "+message(unavailable));
            if(failed.action!=Duwm1728SpeechLanguagePolicy.Action.IGNORE)fail(failed.message);
        }
    }
    private RecognitionListener recognitionListener(){return new RecognitionListener(){
        @Override public void onReadyForSpeech(Bundle parameters){}
        @Override public void onBeginningOfSpeech(){}
        @Override public void onRmsChanged(float value){}
        @Override public void onBufferReceived(byte[] buffer){}
        @Override public void onEndOfSpeech(){}
        @Override public void onPartialResults(Bundle results){}
        @Override public void onEvent(int type,Bundle parameters){}
        @Override public void onResults(Bundle ordinary){
            // Some segmented services also send this callback. It is neither a
            // success signal nor an immediate failure; wait for the file-session end.
        }
        @Override public void onSegmentResults(Bundle results){acceptSegment(results);}
        @Override public void onEndOfSegmentedSession(){
            if(finished.get())return;
            if(!supportConfirmed||!recognitionStarted){fail("Unexpected end callback outside the confirmed file session");return;}
            segmentedEnded=true;finishIfComplete();
        }
        // ERROR_NO_MATCH, network and all other errors remain failures. They are
        // never promoted to a completed-no-word result or evidence of silence.
        @Override public void onError(int error){fail("Recorded-file recognition failed (service error "+error+")");}
    };}
    private void acceptSegment(Bundle bundle){
        if(finished.get())return;
        if(!supportConfirmed||!recognitionStarted||segmentedEnded){fail("Unexpected recognition callback outside the confirmed file session");return;}
        try {
            if(bundle==null)throw new IllegalArgumentException("Empty segment bundle");
            ArrayList<String> candidates=bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            String text=candidates==null||candidates.isEmpty()?"":candidates.get(0);
            text=text==null?"":text.trim();if(text.isEmpty())return;
            if(transcript.length()+text.length()+1>250000)throw new IllegalArgumentException("Recognized transcript exceeds the safe document limit");
            if(transcript.length()>0)transcript.append(' ');transcript.append(text);segments++;
            if(Build.VERSION.SDK_INT<34){timingUsable=false;timingProblem="This Android version did not provide requested word starts";return;}
            ArrayList<android.speech.RecognitionPart> parts=bundle.getParcelableArrayList(SpeechRecognizer.RECOGNITION_PARTS,android.speech.RecognitionPart.class);
            if(parts==null||parts.isEmpty()){timingUsable=false;return;}
            StringBuilder partText=new StringBuilder();
            for(android.speech.RecognitionPart part:parts){
                if(part==null)throw new IllegalArgumentException("Null recognition part");
                String value=part.getFormattedText();if(value==null||value.trim().isEmpty())value=part.getRawText();
                if(value==null||value.trim().isEmpty()){timingUsable=false;timingProblem="A word timing part contained no words";continue;}
                if(words.size()>=Duwm1728CaptionEditPolicy.MAX_CUES)throw new IllegalArgumentException("Too many recognition parts");
                words.add(new Duwm1728SpeechCues.Word(part.getTimestampMillis(),value));
                if(partText.length()>0)partText.append(' ');partText.append(value);
            }
            if(!letters(text).equals(letters(partText.toString()))){timingUsable=false;timingProblem="Reported word timing did not cover the complete returned transcript";}
        }catch(Exception invalid){fail("Recorded-file recognition returned malformed data: "+message(invalid));}
    }
    private static String letters(String text){StringBuilder result=new StringBuilder();
        for(int i=0;i<text.length();){int cp=text.codePointAt(i);i+=Character.charCount(cp);if(Character.isLetterOrDigit(cp))result.appendCodePoint(Character.toLowerCase(cp));}return result.toString();}
    private void finishIfComplete(){
        Duwm1728SpeechSessionPolicy.Completion completion=Duwm1728SpeechSessionPolicy.completion(
                supportConfirmed,recognitionStarted,segmentedEnded,audioComplete,finished.get(),segments,transcript.length());
        if(completion==Duwm1728SpeechSessionPolicy.Completion.WAITING||completion==Duwm1728SpeechSessionPolicy.Completion.TERMINATED)return;
        if(completion==Duwm1728SpeechSessionPolicy.Completion.INVALID){fail("Recorded-file completion did not match its confirmed session");return;}
        boolean noWords=completion==Duwm1728SpeechSessionPolicy.Completion.NO_WORDS;
        List<Duwm1728BroadcastLayout.Cue> cues=Collections.emptyList();
        String note=noWords?"The confirmed recorded-file session and complete audio delivery ended without returned words. This does not establish acoustic silence.":timingProblem;
        if(!noWords&&timingUsable&&!words.isEmpty())try{
            boolean nonzero=false;for(Duwm1728SpeechCues.Word word:words)if(word.offsetMs>0)nonzero=true;
            if(!nonzero&&words.size()>1)throw new IllegalArgumentException("All word timestamps were zero; timing support is ambiguous");
            cues=Duwm1728SpeechCues.fromWords(words,fromMs,toMs);
            note="Word starts reported by the on-device service; caption display ends are inferred and bounded, not measured word ends.";
        }catch(IllegalArgumentException unavailable){note=unavailable.getMessage();}
        Result result=new Result(transcript.toString(),cues,note,fromMs,noWords,requestedLanguage,selectedLanguage);
        if(finished.compareAndSet(false,true)){Listener listener=callbacks;cleanup();if(listener!=null)listener.done(result);}
    }
    private void startAudio(Uri video){
        decodeThread=new Thread(()->{
            OutputStream output=null;
            try {
                synchronized(audioLock){
                    if(finished.get()||writePipe==null)throw new InterruptedIOException("Recorded-audio request cancelled");
                    output=new ParcelFileDescriptor.AutoCloseOutputStream(writePipe);writePipe=null;activeWriteStream=output;
                }
                try(OutputStream stream=output){decodePcm(context,video,fromMs,toMs,stream);}
                main.post(()->{if(!finished.get()){audioComplete=true;finishIfComplete();}});
            }catch(Exception failure){if(!finished.get())main.post(()->fail("Cannot provide recorded audio: "+message(failure)));}
            finally{synchronized(audioLock){if(activeWriteStream==output)activeWriteStream=null;}}
        },"duwm-recorded-audio-decode");decodeThread.start();
    }
    private void checkCancelled()throws InterruptedIOException{
        if(finished.get()||Thread.currentThread().isInterrupted())throw new InterruptedIOException("Recorded-audio conversion cancelled");
    }
    private void decodePcm(Context context,Uri video,long fromMs,long toMs,OutputStream output)throws Exception{
        MediaExtractor extractor=new MediaExtractor();MediaCodec decoder=null;Duwm1728PcmTimeline timeline=new Duwm1728PcmTimeline(fromMs,toMs);
        try {
            checkCancelled();extractor.setDataSource(context,video,null);int selected=-1;
            for(int i=0;i<extractor.getTrackCount();i++){String mime=extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME);if(mime!=null&&mime.startsWith("audio/")){selected=i;break;}}
            if(selected<0)throw new IOException("Video contains no audio track");MediaFormat format=extractor.getTrackFormat(selected);
            extractor.selectTrack(selected);extractor.seekTo(fromMs*1000,MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            format.setInteger(MediaFormat.KEY_PCM_ENCODING,AudioFormat.ENCODING_PCM_16BIT);
            decoder=MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME));decoder.configure(format,null,null,0);decoder.start();
            boolean inputDone=false,outputDone=false;MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();long limit=toMs*1000,deadline=SystemClock.elapsedRealtime()+20000;
            int channels=format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)?format.getInteger(MediaFormat.KEY_CHANNEL_COUNT):1;
            int sampleRate=format.containsKey(MediaFormat.KEY_SAMPLE_RATE)?format.getInteger(MediaFormat.KEY_SAMPLE_RATE):44100;
            while(!outputDone){
                checkCancelled();if(SystemClock.elapsedRealtime()>deadline)throw new IOException("Audio decoder did not finish within its bounded preparation time");
                if(!inputDone){int index=decoder.dequeueInputBuffer(10000);if(index>=0){
                    ByteBuffer input=decoder.getInputBuffer(index);if(input==null)throw new IOException("Audio decoder input unavailable");input.clear();
                    int count=extractor.readSampleData(input,0);long pts=extractor.getSampleTime();
                    if(count<0||pts>=limit){decoder.queueInputBuffer(index,0,0,limit,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputDone=true;}
                    else{decoder.queueInputBuffer(index,0,count,pts,0);extractor.advance();}
                }}
                int index=decoder.dequeueOutputBuffer(info,10000);
                if(index==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){MediaFormat changed=decoder.getOutputFormat();
                    channels=changed.containsKey(MediaFormat.KEY_CHANNEL_COUNT)?changed.getInteger(MediaFormat.KEY_CHANNEL_COUNT):channels;
                    sampleRate=changed.containsKey(MediaFormat.KEY_SAMPLE_RATE)?changed.getInteger(MediaFormat.KEY_SAMPLE_RATE):sampleRate;
                    int encoding=changed.containsKey(MediaFormat.KEY_PCM_ENCODING)?changed.getInteger(MediaFormat.KEY_PCM_ENCODING):AudioFormat.ENCODING_PCM_16BIT;
                    if(encoding!=AudioFormat.ENCODING_PCM_16BIT)throw new IOException("Unsupported decoded PCM encoding");
                }else if(index>=0){try{
                    if(info.size>0&&(info.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)==0){
                        if(channels<1||channels>8||sampleRate<8000||sampleRate>192000||info.size%(channels*2)!=0)throw new IOException("Invalid decoded PCM format");
                        ByteBuffer buffer=decoder.getOutputBuffer(index);if(buffer==null)throw new IOException("Decoded PCM unavailable");
                        ByteBuffer pcm=buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN);pcm.position(info.offset);pcm.limit(info.offset+info.size);
                        short[] mono=new short[info.size/(channels*2)];for(int frame=0;frame<mono.length;frame++){
                            int total=0;for(int channel=0;channel<channels;channel++)total+=pcm.getShort();mono[frame]=(short)(total/channels);
                        }
                        timeline.accept(info.presentationTimeUs,sampleRate,mono);
                    }
                    outputDone=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                }finally{decoder.releaseOutputBuffer(index,false);}}
            }
            checkCancelled();if(timeline.coveredSampleCount()==0)throw new IOException("The selected source range contains no decoded audio samples");timeline.writeTo(output);
        }finally{if(decoder!=null){try{decoder.stop();}catch(Exception ignored){}try{decoder.release();}catch(Exception ignored){}}extractor.release();}
    }
    private static String message(Exception failure){return failure.getMessage()==null?failure.getClass().getSimpleName():failure.getMessage();}
    private void fail(String message){
        if(Looper.myLooper()!=Looper.getMainLooper()){main.post(()->fail(message));return;}
        if(finished.compareAndSet(false,true)){Listener listener=callbacks;cleanup();if(listener!=null)listener.error(message);}
    }
    private void cleanup(){
        if(supportTimeout!=null)main.removeCallbacks(supportTimeout);main.removeCallbacks(recognitionTimeout);callbacks=null;
        if(supportFlow!=null)supportFlow.cancel();
        Thread worker=decodeThread;if(worker!=null)worker.interrupt();
        synchronized(audioLock){
            try{if(activeWriteStream!=null)activeWriteStream.close();}catch(IOException ignored){}activeWriteStream=null;
            try{if(writePipe!=null)writePipe.close();}catch(IOException ignored){}writePipe=null;
            try{if(readPipe!=null)readPipe.close();}catch(IOException ignored){}readPipe=null;
        }
        Runnable destroy=()->{if(recognizer!=null){try{recognizer.cancel();}catch(RuntimeException ignored){}try{recognizer.destroy();}catch(RuntimeException ignored){}recognizer=null;}};
        if(Looper.myLooper()==Looper.getMainLooper())destroy.run();else main.post(destroy);
    }
    public void close(){if(finished.compareAndSet(false,true))cleanup();}
}
