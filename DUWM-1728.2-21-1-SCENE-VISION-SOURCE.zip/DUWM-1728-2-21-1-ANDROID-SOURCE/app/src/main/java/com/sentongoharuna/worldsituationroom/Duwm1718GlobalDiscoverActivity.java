package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/**
 * DUWM 1718: country-neutral global discovery. Presets are geographic navigation
 * shortcuts, NOT live reports. Search resolves coordinates using the device
 * Geocoder and says when it is unavailable. No country is a default centre.
 */
public final class Duwm1718GlobalDiscoverActivity extends Activity {
    private static final String PREFS="duwm1718_follow_places";
    private static final String FOLLOWED="followed";
    private static final int NAVY=DuwmUnifiedTheme.APPROVED_NAVY, TEXT=DuwmUnifiedTheme.TEXT;
    private static final String[][] STARTERS={
        {"Tokyo","Japan","35.6762","139.6503","Asia/Tokyo"},
        {"Singapore","Singapore","1.3521","103.8198","Asia/Singapore"},
        {"Mumbai","India","19.0760","72.8777","Asia/Kolkata"},
        {"Delhi","India","28.6139","77.2090","Asia/Kolkata"},
        {"Dubai","United Arab Emirates","25.2048","55.2708","Asia/Dubai"},
        {"Riyadh","Saudi Arabia","24.7136","46.6753","Asia/Riyadh"},
        {"Nairobi","Kenya","-1.2921","36.8219","Africa/Nairobi"},
        {"Kampala","Uganda","0.3476","32.5825","Africa/Kampala"},
        {"Lagos","Nigeria","6.5244","3.3792","Africa/Lagos"},
        {"Johannesburg","South Africa","-26.2041","28.0473","Africa/Johannesburg"},
        {"London","United Kingdom","51.5072","-0.1276","Europe/London"},
        {"Paris","France","48.8566","2.3522","Europe/Paris"},
        {"Berlin","Germany","52.5200","13.4050","Europe/Berlin"},
        {"New York","United States","40.7128","-74.0060","America/New_York"},
        {"Los Angeles","United States","34.0522","-118.2437","America/Los_Angeles"},
        {"Toronto","Canada","43.6532","-79.3832","America/Toronto"},
        {"São Paulo","Brazil","-23.5505","-46.6333","America/Sao_Paulo"},
        {"Buenos Aires","Argentina","-34.6037","-58.3816","America/Argentina/Buenos_Aires"},
        {"Sydney","Australia","-33.8688","151.2093","Australia/Sydney"},
        {"Auckland","New Zealand","-36.8485","174.7633","Pacific/Auckland"}
    };
    private final List<Place> saved=new ArrayList<>();
    private LinearLayout savedList,presetList;
    private TextView status;
    private EditText search;
    private String activeRegion="ALL";
    private LinearLayout regionStrip;
    private static final String[] REGIONS={"ALL","AFRICA","EUROPE","ASIA","MIDDLE EAST","AMERICAS","OCEANIA"};
    private long lastSearch;
    private volatile boolean closed;
    private int dp(float px){return Math.round(getResources().getDisplayMetrics().density*px);}
    private GradientDrawable edge(int border){GradientDrawable d=new GradientDrawable();d.setColor(NAVY);d.setCornerRadius(dp(17));d.setStroke(dp(1),border);return d;}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));return t;}
    private TextView control(String s,Runnable action){TextView t=text(s,12,TEXT);t.setGravity(Gravity.CENTER);t.setMinHeight(dp(48));t.setBackground(edge(DuwmUnifiedTheme.BORDER));t.setOnClickListener(v->action.run());return t;}
    private LinearLayout.LayoutParams separated(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(8);return p;}
    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(NAVY);load();
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(14),dp(10),dp(14),dp(10));root.setBackgroundColor(NAVY);
        root.addView(text("DUWM 1723  /  GLOBAL DISCOVERY",20,TEXT),separated());
        root.addView(text("Choose anywhere on Earth. Nothing is centred on one country. Preset coordinates are navigational shortcuts, not live events.",12,DuwmUnifiedTheme.MUTED),separated());
        search=new EditText(this);search.setSingleLine(true);search.setTextSize(15);search.setHint("Search any city or place worldwide");search.setHintTextColor(DuwmUnifiedTheme.MUTED);search.setTextColor(TEXT);search.setPadding(dp(12),0,dp(12),0);search.setBackground(edge(DuwmUnifiedTheme.BORDER));root.addView(search,new LinearLayout.LayoutParams(-1,dp(50)));
        root.addView(control("SEARCH WORLD LOCATIONS",this::searchWorld),separated());
        root.addView(control("OPEN MY WORLD / SAVED PLACES & CLOCKS",()->startActivity(new Intent(this,Duwm1719MyWorldActivity.class))),separated());
        root.addView(control("GLOBAL EARTHQUAKES / REAL USGS RECEIPTS",()->startActivity(new Intent(this,Duwm1721GlobalQuakesActivity.class))),separated());
        root.addView(control("WORLD WEATHER / CHOOSE ANY COORDINATES",()->startActivity(new Intent(this,Duwm1723GlobalWeatherActivity.class))),separated());
        status=text("Search uses the device geocoder; network coverage varies by location.",11,DuwmUnifiedTheme.MUTED);root.addView(status,separated());
        ScrollView sc=new ScrollView(this);LinearLayout area=new LinearLayout(this);area.setOrientation(LinearLayout.VERTICAL);
        area.addView(text("FOLLOWED PLACES  /  SAVED ON THIS PHONE",13,TEXT),separated());savedList=new LinearLayout(this);savedList.setOrientation(LinearLayout.VERTICAL);area.addView(savedList);
        area.addView(text("EXPLORE WORLDWIDE  /  REGION FILTERS",13,TEXT),separated());
        android.widget.HorizontalScrollView regions=new android.widget.HorizontalScrollView(this);
        regions.setHorizontalScrollBarEnabled(false);
        regionStrip=new LinearLayout(this);regionStrip.setOrientation(LinearLayout.HORIZONTAL);
        regions.addView(regionStrip);area.addView(regions,separated());
        renderRegionControls();
        presetList=new LinearLayout(this);presetList.setOrientation(LinearLayout.VERTICAL);area.addView(presetList);
        sc.addView(area);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(control("OPEN ORIGINAL WORLD GLOBE",()->{Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);finish();}),separated());
        setContentView(root);render();
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){renderPresets(s.toString());}public void afterTextChanged(Editable e){}});
    }
    private static final class Place {String name,country,timezone;double lat,lon; Place(String n,String c,double la,double lo,String tz){name=n;country=c;lat=la;lon=lo;timezone=tz;}}
    private Place starter(String[] x){return new Place(x[0],x[1],Double.parseDouble(x[2]),Double.parseDouble(x[3]),x[4]);}
    private void load(){saved.clear();try{JSONArray a=new JSONArray(getSharedPreferences(PREFS,MODE_PRIVATE).getString(FOLLOWED,"[]"));for(int n=0;n<a.length();n++){JSONObject o=a.optJSONObject(n);if(o==null)continue;double la=o.optDouble("lat",999),lo=o.optDouble("lon",999);if(valid(la,lo))saved.add(new Place(o.optString("name"),o.optString("country"),la,lo,o.optString("timezone")));}}catch(Exception ignored){}}
    private void persist(){JSONArray a=new JSONArray();for(Place p:saved){try{JSONObject o=new JSONObject();o.put("name",p.name);o.put("country",p.country);o.put("lat",p.lat);o.put("lon",p.lon);o.put("timezone",p.timezone);a.put(o);}catch(Exception ignored){}}getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(FOLLOWED,a.toString()).apply();}
    private boolean valid(double la,double lo){return !Double.isNaN(la)&&!Double.isNaN(lo)&&Math.abs(la)<=85&&Math.abs(lo)<=180;}
    private boolean isSaved(Place p){for(Place o:saved){if(Math.abs(p.lat-o.lat)<0.001&&Math.abs(p.lon-o.lon)<0.001)return true;}return false;}
    private void toggle(Place p){if(isSaved(p)){for(int i=saved.size()-1;i>=0;i--){Place o=saved.get(i);if(Math.abs(p.lat-o.lat)<0.001&&Math.abs(p.lon-o.lon)<0.001)saved.remove(i);}}else if(saved.size()<40){saved.add(0,p);}else{Toast.makeText(this,"Maximum 40 followed places",Toast.LENGTH_LONG).show();return;}persist();render();}
    private void open(Place p){Intent i=new Intent(this,DuwmPlaceMapActivity.class);i.putExtra("focus_lat",String.format(Locale.US,"%.6f",p.lat));i.putExtra("focus_lon",String.format(Locale.US,"%.6f",p.lon));startActivity(i);}
    private void openWeather(Place p){
        Intent i=new Intent(this,Duwm1723GlobalWeatherActivity.class);
        i.putExtra("duwm_place_name",p.name+", "+p.country);
        i.putExtra("focus_lat",String.format(Locale.US,"%.6f",p.lat));
        i.putExtra("focus_lon",String.format(Locale.US,"%.6f",p.lon));
        startActivity(i);
    }
    private String localClock(Place p){if(p.timezone==null||p.timezone.isEmpty())return "LOCAL CLOCK UNAVAILABLE";SimpleDateFormat f=new SimpleDateFormat("EEE HH:mm z",Locale.US);f.setTimeZone(TimeZone.getTimeZone(p.timezone));return f.format(new Date());}
    private void add(LinearLayout container,Place p){LinearLayout card=new LinearLayout(this);card.setPadding(dp(11),dp(11),dp(11),dp(10));card.setOrientation(LinearLayout.VERTICAL);card.setBackground(edge(DuwmUnifiedTheme.DIVIDER));
        TextView headline=text(p.name+"  •  "+p.country,16,TEXT);card.addView(headline);
        card.addView(text(localClock(p)+"   /   "+String.format(Locale.US,"%.3f, %.3f",p.lat,p.lon),11,DuwmUnifiedTheme.MUTED));
        LinearLayout actions=new LinearLayout(this);TextView map=control("OPEN LIVE SOURCE MAP",()->open(p));TextView follow=control(isSaved(p)?"REMOVE FOLLOW":"FOLLOW PLACE",()->toggle(p));
        LinearLayout.LayoutParams l=new LinearLayout.LayoutParams(0,dp(48),1);l.rightMargin=dp(6);actions.addView(map,l);actions.addView(follow,new LinearLayout.LayoutParams(0,dp(48),1));card.addView(actions,separated());
        TextView weather=control("7-DAY WORLD WEATHER FOR THIS PLACE",()->openWeather(p));card.addView(weather,separated());
        TextView share=control("SHARE LOCATION AND LOCAL CLOCK",()->sharePlace(p));card.addView(share,separated());
        container.addView(card,separated());}
    private void render(){if(savedList==null)return;savedList.removeAllViews();if(saved.isEmpty())savedList.addView(text("No places saved yet. Choose any place to follow it.",11,DuwmUnifiedTheme.MUTED),separated());for(Place p:new ArrayList<>(saved))add(savedList,p);renderPresets(search==null?"":search.getText().toString());}
    private String regionOf(String[] raw){
        String tz=raw[4];
        if(tz.startsWith("Africa/"))return "AFRICA";
        if(tz.startsWith("Europe/"))return "EUROPE";
        if(tz.startsWith("America/"))return "AMERICAS";
        if(tz.startsWith("Australia/")||tz.startsWith("Pacific/"))return "OCEANIA";
        if("United Arab Emirates".equals(raw[1])||"Saudi Arabia".equals(raw[1]))return "MIDDLE EAST";
        return "ASIA";
    }
    private void renderRegionControls(){if(regionStrip==null)return;regionStrip.removeAllViews();
        for(String region:REGIONS){TextView tab=control(region,()->{
            activeRegion=region;renderRegionControls();renderPresets(search==null?"":search.getText().toString());
        });tab.setTextColor(region.equals(activeRegion)?DuwmUnifiedTheme.LIVE:TEXT);
          LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(48));lp.rightMargin=dp(7);tab.setPadding(dp(13),0,dp(13),0);regionStrip.addView(tab,lp);}
    }
    private void renderPresets(String q){if(presetList==null)return;presetList.removeAllViews();String filter=q.trim().toLowerCase(Locale.ROOT);int count=0;for(String[] raw:STARTERS){if(!"ALL".equals(activeRegion)&&!activeRegion.equals(regionOf(raw)))continue;if(!filter.isEmpty()&&!(raw[0]+" "+raw[1]).toLowerCase(Locale.ROOT).contains(filter))continue;add(presetList,starter(raw));count++;}
        if(count==0)presetList.addView(text("No preset matches in "+activeRegion+". Use worldwide search for any other location.",12,DuwmUnifiedTheme.MUTED),separated());}
    private void sharePlace(Place p){
        String clock=localClock(p);
        String message=p.name+", "+p.country+"\n"+clock+"\n"+
            String.format(Locale.US,"Map: %.5f, %.5f",p.lat,p.lon)+
            "\nSaved geographical location from DUWM. Not a live report or safety alert.";
        Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT,message);
        startActivity(Intent.createChooser(send,"Share DUWM place"));
    }
    private void searchWorld(){String q=search.getText().toString().trim();if(q.length()<2){status.setText("Enter at least 2 characters.");return;}if(System.currentTimeMillis()-lastSearch<1500L)return;lastSearch=System.currentTimeMillis();status.setText("Looking up " + q + " with the device geocoder…");
        new Thread(()->{try{if(!Geocoder.isPresent())throw new IllegalStateException("Geocoding not provided by this device");List<Address> list=new Geocoder(this,Locale.getDefault()).getFromLocationName(q,1);if(list==null||list.isEmpty())throw new IllegalStateException("No location found");Address a=list.get(0);double la=a.getLatitude(),lo=a.getLongitude();if(!valid(la,lo))throw new IllegalStateException("Invalid coordinates");Place p=new Place(q,a.getCountryName()==null?"COUNTRY NOT RETURNED":a.getCountryName(),la,lo,"");runOnUiThread(()->{if(closed)return;status.setText("Found "+p.name+" / "+p.country+". Confirm the location before following.");new android.app.AlertDialog.Builder(this).setTitle("Confirm mapped place").setMessage(p.name+"\n"+p.country+"\n"+String.format(Locale.US,"%.6f, %.6f",p.lat,p.lon)+"\n\nLocation resolved by the device geocoder; verify on map.").setNegativeButton("CANCEL",null).setNeutralButton("OPEN MAP",(d,w)->open(p)).setPositiveButton("FOLLOW",(d,w)->{if(!isSaved(p))toggle(p);}).show();});}
        catch(Exception ex){runOnUiThread(()->{if(!closed)status.setText("PLACE SEARCH UNAVAILABLE: "+ex.getMessage()+". Try again or use a preset.");});}},"duwm1718-global-place-lookup").start();}
    @Override protected void onDestroy(){closed=true;super.onDestroy();}
}
