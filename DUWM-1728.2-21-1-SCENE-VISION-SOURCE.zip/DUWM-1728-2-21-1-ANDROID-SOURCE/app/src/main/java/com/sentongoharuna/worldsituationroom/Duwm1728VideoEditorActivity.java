package com.sentongoharuna.worldsituationroom;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Automatic local production and optional manual editing share the real MP4 renderer. */
public final class Duwm1728VideoEditorActivity extends Activity implements TextureView.SurfaceTextureListener {
    public static final String EXTRA_VIDEO_URI="duwm.editor.video";
    private static final int NAVY=0xFF041424,WHITE=0xFFF5F7FA,SILVER=0xFFDEE5EF,GREEN=0xFF00C853;
    private static final String SAVED_BROADCASTS="duwm1728_saved_broadcasts";
    private static final int CAPTION_DICTATION_REQUEST=17283,PIP_VIDEO_REQUEST=17284;
    private Uri source,pipVideo;private MediaPlayer player;private Surface playbackSurface;
    private TextureView texture;private Duwm1728AspectFrame stage;private View broadcast;
    private LinearLayout workspace;private FrameLayout viewport;private ScrollView controlScroll;private int controlsMaxHeight;
    private EditText title,place,caption,from,to,ticker,subtitles;private CheckBox sourceSummary,preciseExport,recordedTrackToggle,approval,sceneTitlesToggle;
    private TextView outputSummary,playbackTime,captionInfo,automaticReportInfo;
    private TextView layoutButton,layoutSummary,captionEditorButton;private AlertDialog layoutPicker,detailsDialog,automaticHelpDialog;
    private Duwm1728CaptionEditorDialog captionEditor;
    private Duwm1728CaptionFilesController captionFiles;
    private TextView captionFilesButton,captionFilesDetailsButton;
    private boolean draftRestoreBlocked,draftCaptionRecoveryAllowed;
    private Duwm1728OverlayRenderer.Spec captionPreviewSpec;
    private final List<TextView> layoutChoices=new ArrayList<>();
    private String selectedComposition=Duwm1728BroadcastComposition.FULL;
    private long tickerOriginMs,captionOriginMs;private boolean manualCaptionOriginSet;private String captionKind="Manual captions";
    private Duwm1728ExportPreflight.Result outputPlan;
    private String desiredPlanKey="",checkedGeometryKey="",outputPlanError="";private int planGeneration;
    private final ExecutorService planWorker=Executors.newSingleThreadExecutor();
    private Runnable planKick;
    private TextView aiEvidenceView;private String aiEvidence="No AI analysis has been returned for this recording.";
    private TextView state,exportButton,ratioButton,templateButton,pipSelection,tickerPreview;
    private TextView aiButton,aiSetupButton,editButton,playButton,reviewButton,cancelExportButton;
    private TextView recoveryButton,reviewCopyButton,recoveryStatus;private LinearLayout pendingRecoveryRow;
    private Duwm1728ExportRecovery.Entry pendingRecovery;private String recoveryLoadError="";private int recoveryGeneration;
    private final ExecutorService recoveryWorker=Executors.newSingleThreadExecutor();
    private TextView markInButton,markOutButton,resetTrimButton;
    private long lastPreviewPosition=Long.MIN_VALUE,displayedElapsedSeconds=-1,displayedTotalSeconds=-1;
    private long displayedTrimFrom=Long.MIN_VALUE,displayedTrimTo=Long.MIN_VALUE;
    private long surfaceResumeMs=-1;
    private ProgressBar exportProgress;private LinearLayout renderControls;
    private Uri lastBroadcast;private String lastBroadcastName="";
    private final Object exportPublishLock=new Object();private volatile boolean finalizingExport;
    private LinearLayout details;private SeekBar seek;private long durationMs;private int sourceW=1080,sourceH=1920;
    private String frameMode=Duwm1728FramePlan.FIT;private float frameX=.5f,frameY=.5f;
    private boolean showCompositionGuides,showBroadcast=true;private TextView framingButton;
    private String selectedRatio="9:16",reporter="",provenanceLabel="REPORTER ACCOUNT • UNVERIFIED",captureNotes="",captureCategory="";
    private final String[] templates={"GENERAL REPORT","BREAKING NEWS","WEATHER","TRAFFIC","INTERVIEW","ENVIRONMENT"};private int selectedTemplate,tickerSpeed=75;
    private boolean prepared,busy,aiBusy,active,destroyed,updatingFields,scrubbing;
    private boolean autoProducing,autoAwaitingOutput,automaticExport;
    private int automaticGeneration;
    private String automaticStatus="IDLE",automaticCaptionStatus="Not attempted";
    private String automaticContentSource="NEUTRAL",automaticReportEvidence="";
    private int automaticEmptySegments;
    private final Set<String> automaticSpeechLanguages=new LinkedHashSet<>();
    private long automaticHeadlineStart=-1,automaticHeadlineEnd=-1;
    private boolean automaticHeadlineFit,automaticOutputSizing;
    private boolean automaticSceneTitles,sceneCapture,sceneStorageError;
    private List<Duwm1728SceneTimeline.Entry> sceneTrack=Collections.emptyList();
    private final List<Duwm1728BroadcastLayout.Cue> automaticCues=new ArrayList<>();
    private List<Duwm1728BroadcastLayout.Cue> automaticTickerCues=Collections.emptyList();
    private Duwm1728OverlayRenderer.Spec previewSpec,exportSpec;
    private Duwm1728CaptureTelemetry.Snapshot provenance;
    private java.util.List<Duwm1728TelemetryTimeline.Point> recordedTrack=Collections.emptyList();
    private java.util.List<Duwm1728BroadcastLayout.Cue> aiCaptions=Collections.emptyList();
    private Duwm1728RecordedAudioTranscriber recordedAudioTranscriber;private Duwm1728AiProductionClient aiClient;
    private Duwm1728SpeechReadiness speechReadiness;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService insetWorker=Executors.newSingleThreadExecutor();private final AtomicBoolean insetBusy=new AtomicBoolean();
    private MediaMetadataRetriever insetRetriever;private Bitmap insetFrame;private long lastInsetAt=-1;private int insetGeneration;
    private final Runnable clock=new Runnable(){public void run(){if(!active||destroyed)return;long ms=position();
        Duwm1728OverlayRenderer.Spec playback=playbackSpec();
        if(isPlaying()&&playback!=null&&ms>=playback.toMs){pausePreview();seekSource(playback.fromMs);return;}
        renderPreviewAt(ms,false);
        // Paused video has no changing ticker or source time. Edits, seeks and
        // inset callbacks explicitly request their own frame instead of polling.
        if(isPlaying())main.postDelayed(this,33);}};
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView label(String text,int size){TextView t=new TextView(this);t.setText(text);t.setTextColor(WHITE);t.setTextSize(size);t.setPadding(dp(10),dp(6),dp(10),dp(6));return t;}
    private TextView button(String text,Runnable action){TextView t=label(text,12);t.setGravity(Gravity.CENTER);t.setMinHeight(dp(48));t.setMaxLines(2);t.setTypeface(null,Typeface.BOLD);GradientDrawable bg=new GradientDrawable();bg.setColor(0xFF081B2B);bg.setCornerRadius(dp(8));bg.setStroke(Math.max(1,dp(1)),SILVER);t.setBackground(bg);t.setOnClickListener(v->action.run());t.setFocusable(true);return t;}
    private LinearLayout.LayoutParams cell(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(dp(3),dp(3),dp(3),dp(3));return p;}
    private EditText field(String hint,String value){EditText e=new EditText(this);e.setTextColor(WHITE);e.setHintTextColor(0xFFA0A5AE);e.setTextSize(14);e.setHint(hint);e.setText(value);e.setSingleLine(true);e.setMinHeight(dp(46));return e;}
    private LinearLayout.LayoutParams params(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(dp(5),dp(4),dp(5),dp(4));return p;}
    private CheckBox check(String label,boolean checked){CheckBox c=new CheckBox(this);c.setText(label);c.setTextColor(WHITE);c.setChecked(checked);return c;}
    private String extra(String name){String s=getIntent().getStringExtra(name);return s==null?"":s;}
    private long position(){try{return prepared?player.getCurrentPosition():0;}catch(IllegalStateException e){return 0;}}
    private Duwm1728OverlayRenderer.Spec playbackSpec(){return captionPreviewSpec!=null?captionPreviewSpec:previewSpec;}
    private boolean isPlaying(){try{return prepared&&player!=null&&player.isPlaying();}catch(IllegalStateException e){return false;}}
    private void showPlaying(boolean playing){String text=playing?"PAUSE":"PLAY";if(playButton!=null&&!text.contentEquals(playButton.getText()))playButton.setText(text);}
    private void pausePreview(){try{if(isPlaying())player.pause();}catch(IllegalStateException ignored){}main.removeCallbacks(clock);showPlaying(false);}
    private void renderPreviewAt(long ms,boolean force){
        Duwm1728OverlayRenderer.Spec playback=playbackSpec();
        long start=playback==null?0:playback.fromMs,end=playback==null?durationMs:playback.toMs;
        if(end>start){long elapsed=Duwm1728BroadcastTimeline.elapsed(ms,start,end);int progress=(int)(elapsed*1000/(end-start));
            if(seek!=null&&!scrubbing&&seek.getProgress()!=progress)seek.setProgress(progress);
            long seconds=elapsed/1000,total=(end-start)/1000;
            if(playbackTime!=null&&(seconds!=displayedElapsedSeconds||total!=displayedTotalSeconds)){
                playbackTime.setText((captionPreviewSpec!=null?"CAPTION PREVIEW  •  ":"PREVIEW  •  ")+Duwm1728BroadcastTimeline.clock(elapsed)+" / "+Duwm1728BroadcastTimeline.clock(end-start));
                displayedElapsedSeconds=seconds;displayedTotalSeconds=total;
            }
        }
        if(force||ms!=lastPreviewPosition){lastPreviewPosition=ms;if(broadcast!=null)broadcast.invalidate();}
        updateInset(ms);
    }
    private void requestPreviewUpdate(boolean force){
        if(destroyed)return;renderPreviewAt(position(),force);main.removeCallbacks(clock);
        if(active&&isPlaying())main.postDelayed(clock,33);
    }
    private void seekSource(long ms){
        if(!prepared)return;long target=Math.max(0,Math.min(durationMs-1,ms));lastInsetAt=-1;
        if(Build.VERSION.SDK_INT>=26)player.seekTo(target,MediaPlayer.SEEK_CLOSEST);
        else player.seekTo((int)Math.min(Integer.MAX_VALUE,target));
        if(broadcast!=null)broadcast.invalidate();
    }
    private void arrangeEditorPanels(int width,int height){
        if(viewport==null||controlScroll==null)return;boolean wide=width>height;
        int orientation=wide?LinearLayout.HORIZONTAL:LinearLayout.VERTICAL;
        if(workspace.getOrientation()!=orientation)workspace.setOrientation(orientation);
        controlsMaxHeight=wide?height:Math.round(height*.6f);
        LinearLayout.LayoutParams picture=(LinearLayout.LayoutParams)viewport.getLayoutParams();
        int pictureWidth=wide?0:-1,pictureHeight=wide?-1:0;
        if(picture.width!=pictureWidth||picture.height!=pictureHeight){picture.width=pictureWidth;picture.height=pictureHeight;viewport.setLayoutParams(picture);}
        LinearLayout.LayoutParams controls=(LinearLayout.LayoutParams)controlScroll.getLayoutParams();
        int controlsWidth=wide?Math.min(dp(320),width/2):-1,controlsHeight=wide?-1:-2;
        if(controls.width!=controlsWidth||controls.height!=controlsHeight){controls.width=controlsWidth;controls.height=controlsHeight;controlScroll.setLayoutParams(controls);}
    }
    @Override public void onCreate(Bundle saved){super.onCreate(saved);getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(NAVY);
        String raw=extra(EXTRA_VIDEO_URI);if(raw.isEmpty()){finish();return;}source=Uri.parse(raw);reporter=extra("reporter");captureNotes=extra("notes");captureCategory=extra("report_category");
        provenance=Duwm1728CaptureTelemetry.load(this,source);recordedTrack=Duwm1728TelemetryTimeline.load(this,source);
        loadSceneTrack();automaticSceneTitles=sceneCapture;
        MediaMetadataRetriever meta=new MediaMetadataRetriever();try{meta.setDataSource(this,source);sourceW=Integer.parseInt(meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));sourceH=Integer.parseInt(meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));durationMs=Long.parseLong(meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));String r=meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);int rotation=r==null?0:Integer.parseInt(r);if(rotation%180!=0){int t=sourceW;sourceW=sourceH;sourceH=t;}}
        catch(Exception e){notice("Cannot inspect source video: "+e.getMessage());finish();return;}finally{try{meta.release();}catch(Exception ignored){}}
        selectedRatio=extra("broadcast_ratio");if(selectedRatio.isEmpty())selectedRatio=sourceW>sourceH?"16:9":Math.abs(sourceW/(float)sourceH-.9f)<.02f?"9:10":"9:16";
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setBackgroundColor(NAVY);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setBaselineAligned(false);TextView heading=label("BROADCAST STUDIO  /21/1",14);heading.setTypeface(null,Typeface.BOLD);top.addView(heading,new LinearLayout.LayoutParams(0,dp(48),1));aiSetupButton=button("AI HELP",this::aiSettings);aiSetupButton.setTag("broadcast-editor-auto-help");top.addView(aiSetupButton,new LinearLayout.LayoutParams(dp(88),-2));page.addView(top);
        // The same viewport and controls keep their parents when the window changes
        // shape, so rotating does not replace the TextureView or restart its player.
        workspace=new LinearLayout(this){@Override protected void onMeasure(int width,int height){arrangeEditorPanels(View.MeasureSpec.getSize(width),View.MeasureSpec.getSize(height));super.onMeasure(width,height);}};
        workspace.setOrientation(LinearLayout.VERTICAL);workspace.setTag("broadcast-editor-workspace");page.addView(workspace,new LinearLayout.LayoutParams(-1,0,1));
        viewport=new FrameLayout(this);viewport.setTag("broadcast-editor-viewport");workspace.addView(viewport,new LinearLayout.LayoutParams(-1,0,1));
        stage=new Duwm1728AspectFrame(this);viewport.addView(stage,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));texture=new TextureView(this);texture.setOpaque(false);texture.setSurfaceTextureListener(this);stage.addView(texture,new FrameLayout.LayoutParams(-1,-1));
        broadcast=new View(this){@Override protected void onDraw(Canvas c){Duwm1728OverlayRenderer.Spec playback=playbackSpec();if(playback!=null&&showBroadcast){
                long elapsed=Duwm1728BroadcastTimeline.elapsed(position(),playback.fromMs,playback.toMs);
                if(playback.automaticHeadlineFit||playback.automaticOutputSizing||playback.automaticSceneTitles){int[] output=plannedOutputSize(playback);int saved=c.save();
                    c.scale(getWidth()/(float)output[0],getHeight()/(float)output[1]);
                    Duwm1728OverlayRenderer.drawOverlay(c,playback,elapsed,insetFrame,output[0],output[1]);c.restoreToCount(saved);
                }else Duwm1728OverlayRenderer.drawOverlay(c,playback,elapsed,insetFrame);}
            if(showCompositionGuides)drawCompositionGuides(c);}};
        broadcast.setTag("broadcast-editor-overlay");broadcast.setContentDescription("Broadcast graphics preview: same layout used for MP4 export");stage.addView(broadcast,new FrameLayout.LayoutParams(-1,-1));
        controlScroll=new ScrollView(this){@Override protected void onMeasure(int width,int height){
            if(workspace.getOrientation()==LinearLayout.VERTICAL&&View.MeasureSpec.getMode(height)!=View.MeasureSpec.UNSPECIFIED)
                height=View.MeasureSpec.makeMeasureSpec(Math.min(View.MeasureSpec.getSize(height),controlsMaxHeight),View.MeasureSpec.AT_MOST);
            super.onMeasure(width,height);}};
        controlScroll.setTag("broadcast-editor-controls");controlScroll.setContentDescription("Broadcast editing controls; scroll for more options");controlScroll.setFillViewport(false);
        LinearLayout controlColumn=new LinearLayout(this);controlColumn.setOrientation(LinearLayout.VERTICAL);controlScroll.addView(controlColumn,new ScrollView.LayoutParams(-1,-2));workspace.addView(controlScroll,new LinearLayout.LayoutParams(-1,-2));
        seek=new SeekBar(this);seek.setTag("broadcast-editor-seek");seek.setContentDescription("Preview playhead within the selected clip");seek.setMax(1000);seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int progress,boolean user){Duwm1728OverlayRenderer.Spec playback=playbackSpec();if(user&&prepared&&!busy&&playback!=null)seekSource(
            Duwm1728BroadcastTimeline.sourceAtProgress(progress,playback.fromMs,playback.toMs));}public void onStartTrackingTouch(SeekBar s){scrubbing=true;}public void onStopTrackingTouch(SeekBar s){scrubbing=false;}});controlColumn.addView(seek,new LinearLayout.LayoutParams(-1,dp(26)));
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(GREEN));seek.setThumbTintList(android.content.res.ColorStateList.valueOf(SILVER));
        playbackTime=label("PREVIEW  •  00:00",10);playbackTime.setTag("broadcast-editor-time");playbackTime.setMinHeight(dp(25));controlColumn.addView(playbackTime,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout controls=new LinearLayout(this);playButton=button("PLAY",this::play);playButton.setTag("broadcast-editor-play");controls.addView(playButton,cell());ratioButton=button(selectedRatio,this::chooseRatio);controls.addView(ratioButton,cell());framingButton=button("FRAME",this::showFraming);controls.addView(framingButton,cell());editButton=button("EDIT",this::showDetails);controls.addView(editButton,cell());controlColumn.addView(controls);
        LinearLayout layoutRow=new LinearLayout(this);layoutRow.setBaselineAligned(false);layoutRow.setGravity(Gravity.CENTER_VERTICAL);layoutRow.setPadding(dp(3),dp(3),dp(3),dp(3));
        layoutButton=button("LAYOUT",this::showLayoutPicker);layoutButton.setTag("broadcast-editor-layout");layoutRow.addView(layoutButton,cell());
        captionEditorButton=button("CAPTIONS",this::showCaptionEditor);captionEditorButton.setTag("caption-editor-button");layoutRow.addView(captionEditorButton,cell());
        captionFilesButton=button("CAPTION FILES",this::showCaptionFiles);captionFilesButton.setTag("caption-files-button");layoutRow.addView(captionFilesButton,cell());controlColumn.addView(layoutRow);
        layoutSummary=label("FULL REPORT  •  MP4 GRAPHICS",11);layoutSummary.setTag("broadcast-editor-layout-summary");layoutSummary.setTextColor(SILVER);layoutSummary.setMaxLines(3);controlColumn.addView(layoutSummary,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout trimControls=new LinearLayout(this);
        // These are touch targets, not text columns. Baseline alignment shifts
        // two-line MARK buttons below the one-line RESET button and clips their
        // lower edge inside the row; scrolling cannot expose that clipped part.
        trimControls.setBaselineAligned(false);trimControls.setGravity(Gravity.CENTER_VERTICAL);
        markInButton=button("MARK IN",()->markTrim(true));markInButton.setTag("broadcast-editor-mark-in");trimControls.addView(markInButton,cell());
        markOutButton=button("MARK OUT",()->markTrim(false));markOutButton.setTag("broadcast-editor-mark-out");trimControls.addView(markOutButton,cell());
        resetTrimButton=button("RESET TRIM",this::resetTrim);resetTrimButton.setTag("broadcast-editor-reset-trim");resetTrimButton.setContentDescription("Reset trim to the full original recording");trimControls.addView(resetTrimButton,cell());controlColumn.addView(trimControls);
        outputSummary=label("CHECKING OUTPUT…",10);outputSummary.setTextColor(SILVER);
        outputSummary.setMaxLines(2);outputSummary.setEllipsize(android.text.TextUtils.TruncateAt.END);
        outputSummary.setMinHeight(dp(34));outputSummary.setBackgroundColor(0xFF081B2B);
        outputSummary.setContentDescription("Tap for exact broadcast dimensions, audio, crop and encoder check");
        outputSummary.setOnClickListener(v->showOutputCheck());controlColumn.addView(outputSummary,new LinearLayout.LayoutParams(-1,-2));
        state=label("BUILT-IN AUTO PRODUCTION • ready",11);state.setTag("broadcast-editor-production-status");state.setTextColor(0xFFFBC02D);state.setMaxLines(3);state.setEllipsize(android.text.TextUtils.TruncateAt.END);controlColumn.addView(state);
        renderControls=new LinearLayout(this);renderControls.setGravity(Gravity.CENTER_VERTICAL);renderControls.setPadding(dp(12),0,dp(6),0);
        exportProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);exportProgress.setMax(100);exportProgress.setProgressTintList(android.content.res.ColorStateList.valueOf(GREEN));exportProgress.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(GREEN));
        renderControls.addView(exportProgress,new LinearLayout.LayoutParams(0,dp(6),1));cancelExportButton=button("CANCEL",this::cancelExport);renderControls.addView(cancelExportButton,new LinearLayout.LayoutParams(dp(88),dp(40)));renderControls.setVisibility(View.GONE);controlColumn.addView(renderControls);
        approval=check("I reviewed my manual changes (for manual SAVE MP4)",false);approval.setTextSize(12);approval.setMinHeight(dp(48));approval.setButtonTintList(new android.content.res.ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{GREEN,SILVER}));controlColumn.addView(approval,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout actions=new LinearLayout(this);actions.setBaselineAligned(false);aiButton=button("AUTO PRODUCE",this::requestAi);aiButton.setTag("broadcast-editor-auto-produce");actions.addView(aiButton,cell());exportButton=button("SAVE MP4",this::export);exportButton.setTextColor(GREEN);actions.addView(exportButton,cell());reviewButton=button("LAST EXPORT",this::showLastExport);reviewButton.setTag("broadcast-editor-last-export");reviewButton.setContentDescription("Review or share the last broadcast saved to Gallery for this recording");actions.addView(reviewButton,cell());recoveryButton=button("RECOVERY",()->openRecovery(null));recoveryButton.setTag("broadcast-editor-recovery");recoveryButton.setContentDescription("Open pending broadcasts and retry Gallery saves");actions.addView(recoveryButton,cell());controlColumn.addView(actions);
        pendingRecoveryRow=new LinearLayout(this);pendingRecoveryRow.setTag("broadcast-editor-pending");pendingRecoveryRow.setGravity(Gravity.CENTER_VERTICAL);pendingRecoveryRow.setBackgroundColor(0xFF081B2B);
        recoveryStatus=label("",10);recoveryStatus.setTag("broadcast-editor-recovery-status");recoveryStatus.setMaxLines(3);recoveryStatus.setTextColor(0xFFFFB300);pendingRecoveryRow.addView(recoveryStatus,new LinearLayout.LayoutParams(0,-2,1));
        reviewCopyButton=button("REVIEW COPY",this::reviewPendingCopy);reviewCopyButton.setTag("broadcast-editor-review-copy");reviewCopyButton.setContentDescription("Review the local finished MP4; Gallery save is not confirmed");pendingRecoveryRow.addView(reviewCopyButton,new LinearLayout.LayoutParams(dp(104),-2));pendingRecoveryRow.setVisibility(View.GONE);controlColumn.addView(pendingRecoveryRow);
        approval.setOnCheckedChangeListener((v,c)->updateExportState());
        details=new LinearLayout(this);details.setOrientation(LinearLayout.VERTICAL);details.setPadding(dp(12),dp(10),dp(12),dp(20));
        automaticReportInfo=label("Automatic report excerpts appear after production.",12);automaticReportInfo.setTag("broadcast-editor-auto-report-info");automaticReportInfo.setTextColor(SILVER);details.addView(automaticReportInfo,params());
        title=field("Report headline / labelled source excerpt","");place=field("Location (optional)",extra("place"));caption=field("Report summary / notes",extra("notes"));caption.setSingleLine(false);caption.setMinLines(2);
        ticker=field("00:00=First update;00:15=Next update","");ticker.setSingleLine(false);ticker.setMinLines(2);subtitles=field("Timed captions or imported subtitles","");subtitles.setSingleLine(false);
        from=field("Start seconds","0");to=field("End seconds",String.format(Locale.US,"%.3f",durationMs/1000.0));from.setInputType(8194);to.setInputType(8194);
        for(EditText f:new EditText[]{title,place,caption,ticker,subtitles,from,to}){details.addView(f,params());f.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){if(!updatingFields){approval.setChecked(false);if(f==ticker){automaticTickerCues=Collections.emptyList();try{tickerOriginMs=ms(from);}catch(Exception ignored){}updateAutomaticReportInfo();}
            if(f==title){selectSceneTitles(false);automaticHeadlineFit=false;automaticHeadlineStart=automaticHeadlineEnd=-1;if(!automaticReportEvidence.isEmpty()&&!automaticReportEvidence.startsWith("Headline manually edited."))automaticReportEvidence="Headline manually edited. Original automatic-plan evidence:\n"+automaticReportEvidence;}
            if(f==subtitles){
                // Structured imports are edited through CAPTIONS. A stale IME or
                // programmatic text change must never erase their source timing.
                if(!aiCaptions.isEmpty()){updatingFields=true;try{subtitles.setText("");}finally{updatingFields=false;}return;}
                captionKind="Manual captions";
                if(!manualCaptionOriginSet&&!subtitles.getText().toString().trim().isEmpty())try{captionOriginMs=ms(from);manualCaptionOriginSet=true;}catch(Exception ignored){}
                if(captionInfo!=null)captionInfo.setText(captionKind);}
            refresh();}}public void afterTextChanged(android.text.Editable e){}});}
        templateButton=button("CATEGORY: GENERAL REPORT",()->new AlertDialog.Builder(this).setTitle("Report category (not a verification badge)").setItems(templates,(d,i)->{selectedTemplate=i;templateButton.setText("CATEGORY: "+templates[i]);approval.setChecked(false);refresh();}).show());details.addView(templateButton,params());
        sceneTitlesToggle=check("Use recorded AI frame titles when available",automaticSceneTitles);sceneTitlesToggle.setTag("broadcast-editor-scene-titles");sceneTitlesToggle.setEnabled(sceneCapture);details.addView(sceneTitlesToggle,params());
        sceneTitlesToggle.setOnCheckedChangeListener((v,on)->{if(updatingFields)return;automaticSceneTitles=on;approval.setChecked(false);refresh();saveDraft();});
        details.addView(label("AI frame titles follow the original recording times. Missing or expired descriptions stay neutral. Typing a manual headline switches frame titles off; enabling them restores the recorded scene track.",11),params());
        details.addView(label("Automatic source excerpts keep their original-video timestamps. Typing a manual ticker replaces those excerpts. Trimming alone keeps them attached to the same footage.",11),params());
        details.addView(button("TICKER SPEED",()->new AlertDialog.Builder(this).setTitle("Ticker speed").setItems(new String[]{"Slow","Normal","Fast"},(d,i)->{tickerSpeed=new int[]{45,75,115}[i];approval.setChecked(false);refresh();}).show()),params());
        sourceSummary=check("Include available captured sensor information",provenance!=null);sourceSummary.setEnabled(provenance!=null);recordedTrackToggle=check("Use recorded time-aligned samples",!recordedTrack.isEmpty());recordedTrackToggle.setEnabled(!recordedTrack.isEmpty());preciseExport=check("Disclose exact recorded GPS in this broadcast",false);preciseExport.setEnabled(provenance!=null&&provenance.preciseEnabled);
        for(CheckBox c:new CheckBox[]{sourceSummary,recordedTrackToggle,preciseExport}){details.addView(c,params());c.setOnCheckedChangeListener((v,on)->{approval.setChecked(false);refresh();});}
        captionInfo=label("No timed captions imported",11);captionInfo.setTag("broadcast-editor-caption-info");details.addView(captionInfo,params());
        TextView editCaptions=button("EDIT CAPTION WORDS & TIMES",this::showCaptionEditor);editCaptions.setTag("caption-editor-details-button");details.addView(editCaptions,params());
        details.addView(label("CAPTIONS edits exact original-video starts, ends and words, including cues outside this clip. Legacy manual-caption times attach to the trim start on first entry and keep that origin when edited later. Imported captions use CAPTIONS; typing here cannot replace them.",11),params());
        details.addView(button("TRANSCRIBE RECORDED AUDIO ON DEVICE",this::transcribeRecordedAudio),params());
        captionFilesDetailsButton=button("CAPTION FILES • SAVE / SHARE / IMPORT",this::showCaptionFiles);captionFilesDetailsButton.setTag("caption-files-details-button");details.addView(captionFilesDetailsButton,params());
        details.addView(button("DICTATE A CAPTION (MICROPHONE)",this::dictateCaption),params());
        pipSelection=label("PICTURE-IN-PICTURE OFF",11);details.addView(pipSelection,params());details.addView(button("SELECT SECOND VIDEO",this::choosePipVideo),params());details.addView(button("REMOVE SECOND VIDEO",()->{pipVideo=null;loadInset(null);pipSelection.setText("PICTURE-IN-PICTURE OFF");approval.setChecked(false);refresh();}),params());
        aiEvidenceView=label(aiEvidence,11);details.addView(aiEvidenceView,params());
        details.addView(label("AI proposals are not independent verification. Precise GPS is separate and opt-in. Existing labels already inside older MP4s cannot be removed.",11),params());
        // The application-owned signal shell applies system-bar/cutout insets once.
        setContentView(page);loadDraft();initializeCaptionFiles(saved);loadLastExport();refresh();
        // Fresh captures run locally without a server, token, or manual approval step.
        main.post(this::maybeStartAiAfterCapture);
    }
    private void maybeStartAiAfterCapture(){
        SharedPreferences settings=getSharedPreferences(Duwm1728AutomaticProduction.PREFS,MODE_PRIVATE);
        String key=Duwm1728CaptureTelemetry.storageKey(source);
        boolean attempted=settings.contains(Duwm1728AutomaticProduction.receiptKey(key));
        if(attempted)try{JSONObject receipt=new JSONObject(settings.getString(Duwm1728AutomaticProduction.receiptKey(key),"{}"));
            automaticStatus=receipt.optString("state","IDLE");automaticCaptionStatus=receipt.optString("caption_status","Not attempted");
            if(lastBroadcast!=null&&automaticStatus.startsWith("SAVED_")){state.setText("VIDEO READY • saved automatic export available");state.setTextColor(GREEN);}
            else if("STARTED".equals(automaticStatus)||"RENDERING".equals(automaticStatus)||"INTERRUPTED".equals(automaticStatus))state.setText(lastBroadcast!=null
                    ?"SAVED EXPORT AVAILABLE • latest automatic attempt status is incomplete"
                    :"AUTOMATIC EDIT INTERRUPTED • original retained • AUTO PRODUCE to retry");
        }catch(Exception ignored){}
        boolean draft=getSharedPreferences("duwm_production_drafts",MODE_PRIVATE).contains(key);
        if(!Duwm1728AutomaticProduction.shouldStart(getIntent().getBooleanExtra("clean_master",false),
                settings.getBoolean("enabled",true),attempted,lastBroadcast!=null,draft,
                !compositionEditable()||draftRestoreBlocked||destroyed||isFinishing()))return;
        startAutomaticProduction();
    }
    private void loadSceneTrack(){
        sceneStorageError=sceneStorageError||getIntent().getBooleanExtra("scene_capture_storage_error",false);
        sceneCapture=sceneCapture||Duwm1728SceneStore.hasCapture(this,source)||getIntent().getBooleanExtra("scene_capture_enabled",false);
        sceneTrack=sceneStorageError?Collections.emptyList():Collections.unmodifiableList(new ArrayList<>(Duwm1728SceneStore.load(this,source)));
    }
    private void selectSceneTitles(boolean selected){
        automaticSceneTitles=selected;
        if(sceneTitlesToggle!=null){boolean prior=updatingFields;updatingFields=true;try{
            sceneTitlesToggle.setChecked(selected);sceneTitlesToggle.setEnabled(sceneCapture||selected);
        }finally{updatingFields=prior;}}
    }
    private void play(){if(!prepared||busy)return;try{Duwm1728OverlayRenderer.Spec playback=playbackSpec();if(isPlaying())pausePreview();else{if(playback!=null&&(position()<playback.fromMs||position()>=playback.toMs))seekSource(playback.fromMs);player.start();showPlaying(true);}requestPreviewUpdate(true);}catch(Exception e){notice("Playback unavailable");}}
    private String trimTime(long ms){return Duwm1728BroadcastTimeline.clock(ms)+String.format(Locale.US,".%03d",ms%1000);}
    private void updateTrimLabels(){
        if(markInButton==null||from==null||to==null)return;long start=-1,end=-1;
        try{start=ms(from);end=ms(to);if(end<=start||end>durationMs){start=-1;end=-1;}}catch(Exception invalid){start=-1;end=-1;}
        if(start==displayedTrimFrom&&end==displayedTrimTo)return;displayedTrimFrom=start;displayedTrimTo=end;
        markInButton.setText("MARK IN"+(start<0?"":"\n"+trimTime(start)));
        markOutButton.setText("MARK OUT"+(end<0?"":"\n"+trimTime(end)));
        markInButton.setContentDescription("Mark clip start at the current playhead"+(start<0?"":". Current start "+trimTime(start)));
        markOutButton.setContentDescription("Mark clip end at the current playhead"+(end<0?"":". Current end "+trimTime(end)));
    }
    private boolean trimEditable(){return !busy&&!aiBusy&&!autoProducing&&recordedAudioTranscriber==null&&captionEditor==null&&durationMs>0&&(captionFiles==null||!captionFiles.locksEditor());}
    private void markTrim(boolean start){
        if(!prepared||!trimEditable())return;long at=position(),a=0,b=durationMs;
        try{a=ms(from);b=ms(to);}catch(Exception invalid){a=0;b=durationMs;}
        Duwm1728EditorTrimPolicy.Range range=start?Duwm1728EditorTrimPolicy.markIn(a,b,at,durationMs):Duwm1728EditorTrimPolicy.markOut(a,b,at,durationMs);
        applyTrim(range,at);
    }
    private void resetTrim(){if(trimEditable())applyTrim(Duwm1728EditorTrimPolicy.reset(durationMs),position());}
    private void applyTrim(Duwm1728EditorTrimPolicy.Range range,long at){
        pausePreview();updatingFields=true;
        try{from.setText(String.format(Locale.US,"%.3f",range.fromMs/1000d));to.setText(String.format(Locale.US,"%.3f",range.toMs/1000d));}
        finally{updatingFields=false;}
        // Ticker/caption origins stay attached to the original footage.
        approval.setChecked(false);refresh();saveDraft();
        long inside=Math.max(range.fromMs,Math.min(range.toMs-1,at));
        if(prepared&&inside!=at)seekSource(inside);
        markInButton.announceForAccessibility("Clip from "+trimTime(range.fromMs)+" to "+trimTime(range.toMs));
    }
    private boolean captionOperationAvailable(){return !destroyed&&!isFinishing()&&!busy&&!aiBusy&&!autoProducing&&recordedAudioTranscriber==null;}
    private boolean captionEditable(){return captionOperationAvailable()&&(captionFiles==null||!captionFiles.locksEditor());}
    private boolean compositionEditable(){return captionEditable()&&captionEditor==null;}
    private void initializeCaptionFiles(Bundle saved){
        captionFiles=new Duwm1728CaptionFilesController(this,new Duwm1728CaptionFilesController.Host(){
            @Override public boolean canUseFiles(){return captionOperationAvailable()&&captionEditor==null;}
            @Override public Duwm1728CaptionFilesController.Selection selection(){
                long start,end;try{start=ms(from);}catch(Exception invalid){start=-1;}try{end=ms(to);}catch(Exception invalid){end=-1;}
                List<Duwm1728BroadcastLayout.Cue> cues=Collections.emptyList();String error="";
                try{if(draftRestoreBlocked)throw new IllegalArgumentException("Saved captions could not be restored; the original draft is kept.");
                    cues=aiCaptions.isEmpty()?Duwm1728CaptionEditPolicy.fromLegacy(Duwm1728TickerTimeline.parse(subtitles.getText().toString()),captionOriginMs,durationMs):aiCaptions;
                }catch(IllegalArgumentException invalid){error=invalid.getMessage();}
                return new Duwm1728CaptionFilesController.Selection(cues,durationMs,start,end,Duwm1728CaptureTelemetry.storageKey(source),error);
            }
            @Override public boolean replaceCaptions(List<Duwm1728BroadcastLayout.Cue> cues,String kind){
                if(!canUseFiles())return false;return replaceAppliedCaptions(cues,kind);
            }
            @Override public void changed(){updateExportState();}
        },saved);
    }
    private void showCaptionFiles(){
        if(captionFiles==null)return;
        if(captionEditor!=null){notice("Apply or cancel the open caption edits before saving or sharing captions");return;}
        if(!captionOperationAvailable()){notice("Finish the current operation before opening caption files");return;}
        pausePreview();if(detailsDialog!=null)detailsDialog.dismiss();captionFiles.show();
    }
    /** Explicit replacement is the only way to unblock a rejected saved caption array. */
    private boolean replaceAppliedCaptions(List<Duwm1728BroadcastLayout.Cue> cues,String kind){
        if(draftRestoreBlocked&&!draftCaptionRecoveryAllowed)throw new IllegalArgumentException("Saved report data could not be restored. Replacing captions cannot overwrite it; the original draft is kept");
        List<Duwm1728BroadcastLayout.Cue> checked=Duwm1728CaptionEditPolicy.copyAndValidate(cues,durationMs);
        List<Duwm1728BroadcastLayout.Cue> old=aiCaptions;String oldText=subtitles.getText().toString(),oldKind=captionKind;
        boolean oldBlocked=draftRestoreBlocked,oldRecovery=draftCaptionRecoveryAllowed,oldApproved=approval.isChecked();
        updatingFields=true;try{aiCaptions=checked;subtitles.setText("");captionKind=kind;draftRestoreBlocked=false;draftCaptionRecoveryAllowed=false;}
        finally{updatingFields=false;}
        approval.setChecked(false);
        if(!saveDraft()){
            updatingFields=true;try{aiCaptions=old;subtitles.setText(oldText);captionKind=oldKind;draftRestoreBlocked=oldBlocked;draftCaptionRecoveryAllowed=oldRecovery;approval.setChecked(oldApproved);}
            finally{updatingFields=false;}refresh();throw new IllegalArgumentException("Caption draft could not be saved; current captions were kept");
        }
        clearCaptionPreview();refresh();return true;
    }
    private void showCaptionEditor(){
        if(!captionEditable()){notice("Wait for the current operation before editing captions");return;}
        if(captionEditor!=null){pausePreview();captionEditor.show();updateExportState();return;}
        final List<Duwm1728BroadcastLayout.Cue> initial;final long clipStart,clipEnd;final Uri original=source;final String originalKind=captionKind;
        try{clipStart=ms(from);clipEnd=ms(to);if(clipEnd<=clipStart||clipEnd>durationMs)throw new IllegalArgumentException("Check the selected clip range");
            initial=aiCaptions.isEmpty()?Duwm1728CaptionEditPolicy.fromLegacy(Duwm1728TickerTimeline.parse(subtitles.getText().toString()),captionOriginMs,durationMs)
                :Duwm1728CaptionEditPolicy.copyAndValidate(aiCaptions,durationMs);
        }catch(IllegalArgumentException invalid){notice("Caption editor: "+invalid.getMessage());return;}
        pausePreview();if(detailsDialog!=null)detailsDialog.dismiss();
        captionEditor=new Duwm1728CaptionEditorDialog(this,initial,durationMs,clipStart,clipEnd,new Duwm1728CaptionEditorDialog.Listener(){
            @Override public boolean canEdit(){return captionEditable()&&original.equals(source);}
            @Override public long playheadMs(){return position();}
            @Override public boolean preview(long at,List<Duwm1728BroadcastLayout.Cue> captions){
                if(!canEdit())return false;
                if(!prepared){notice("Wait for the source video to load");return false;}
                try{
                    // This independent Spec is preview-only. The selected trim,
                    // committed previewSpec, cue origins and draft are untouched.
                    Duwm1728OverlayRenderer.Spec temporary=spec();temporary.fromMs=0;temporary.toMs=durationMs;
                    temporary.captions="";temporary.captionCues=Collections.emptyList();temporary.automaticCaptions=Duwm1728CaptionEditPolicy.copyAndValidate(captions,durationMs);
                    Duwm1728OverlayRenderer.prepareTimelines(temporary);captionPreviewSpec=temporary;
                    pausePreview();displayedElapsedSeconds=displayedTotalSeconds=-1;lastInsetAt=-1;
                    seek.setContentDescription("Caption preview playhead within the full original recording");
                    seekSource(at);requestPreviewUpdate(true);updateExportState();return true;
                }catch(Exception invalid){clearCaptionPreview();notice("Caption preview: "+invalid.getMessage());return false;}
            }
            @Override public void resumed(){clearCaptionPreview();}
            @Override public boolean apply(List<Duwm1728BroadcastLayout.Cue> captions){
                if(!canEdit())return false;
                List<Duwm1728BroadcastLayout.Cue> checked=Duwm1728CaptionEditPolicy.copyAndValidate(captions,durationMs);
                String kind=checked.isEmpty()?"No captions":originalKind.contains("AI")?"Edited AI soundtrack captions — review required":originalKind.contains("SRT")?"Edited SRT captions (original-video timing)":"Edited captions (original-video timing)";
                return replaceAppliedCaptions(checked,kind);
            }
            @Override public void closed(){captionEditor=null;clearCaptionPreview();if(!destroyed){
                // Outside-clip source seeks remain available for marking while
                // editing. Closing restores a frame that belongs to the clip.
                if(prepared&&previewSpec!=null){long at=position();if(at<previewSpec.fromMs||at>=previewSpec.toMs){pausePreview();seekSource(previewSpec.fromMs);}}
                updateExportState();}}
        });
        captionEditor.show();updateExportState();
    }
    private void clearCaptionPreview(){
        if(captionPreviewSpec!=null){pausePreview();captionPreviewSpec=null;displayedElapsedSeconds=displayedTotalSeconds=-1;lastInsetAt=-1;
            if(seek!=null)seek.setContentDescription("Preview playhead within the selected clip");if(!destroyed)requestPreviewUpdate(true);}
    }
    private void updateCaptionEntry(){
        if(draftRestoreBlocked&&captionInfo!=null)captionInfo.setText(draftCaptionRecoveryAllowed?"SAVED CAPTIONS COULD NOT BE RESTORED • Original draft kept. Apply or import a reviewed replacement.":"SAVED REPORT COULD NOT BE RESTORED • Original draft kept. Caption replacement cannot overwrite report data.");
        if(captionEditorButton!=null){boolean returning=captionEditor!=null&&captionEditor.isPreviewing();String text=returning?"RETURN TO CAPTIONS":"CAPTIONS";
            if(!text.contentEquals(captionEditorButton.getText()))captionEditorButton.setText(text);
            captionEditorButton.setTextColor(returning?GREEN:WHITE);captionEditorButton.setContentDescription(returning?"Return to the same unsaved caption edits":"Edit caption words and exact original-video times");}
        if(subtitles!=null){boolean structured=!aiCaptions.isEmpty();subtitles.setEnabled(!structured&&captionEditable()&&captionEditor==null);
            subtitles.setHint(structured?"Use CAPTIONS to edit imported words and times":"Legacy captions: 00:00=Words;00:06=Next cue");
            subtitles.setContentDescription(structured?"Imported captions are protected. Use Edit caption words and times":"Legacy manual captions with the saved source-time origin");}
    }
    private void updateLayoutSummary(){
        String name=Duwm1728BroadcastComposition.label(selectedComposition),text=name+"  •  MP4 GRAPHICS";
        if(layoutSummary!=null&&!text.contentEquals(layoutSummary.getText()))layoutSummary.setText(text);
        if(layoutButton!=null)layoutButton.setContentDescription("Choose broadcast layout. Current layout: "+name);
    }
    private void updateOutputSummary(){
        if(outputSummary==null)return;String name=Duwm1728BroadcastComposition.label(selectedComposition),text;
        if(previewSpec==null)text=name+"  •  OUTPUT NOT READY — check clip/timing";
        else if(outputPlan==null)text=name+(outputPlanError.isEmpty()?"  •  CHECKING OUTPUT":"  •  OUTPUT BLOCKED — details ›");
        else text=name+"  •  "+outputPlan.width+" × "+outputPlan.height+"\n"+(outputPlan.resolutionAdjusted?"AUTO SIZE  •  ":"")+outputPlan.ratio+"  •  "+(outputPlan.audio?"AUDIO":"SILENT")+"  •  DETAILS ›";
        if(!text.contentEquals(outputSummary.getText()))outputSummary.setText(text);
        outputSummary.setTextColor(previewSpec==null||!outputPlanError.isEmpty()?0xFFF57C00:SILVER);
        outputSummary.setContentDescription(text+". Tap for output dimensions, audio, framing and encoder check.");
    }
    private boolean applyComposition(String requested){
        // Recheck when a modal choice is pressed: AI, transcription or export may
        // have started since the picker was opened.
        if(!compositionEditable()){notice("Wait for the current operation before changing layout");return false;}
        String chosen=Duwm1728BroadcastComposition.normalize(requested);
        if(!chosen.equals(selectedComposition)){
            selectedComposition=chosen;approval.setChecked(false);refresh();saveDraft();
            layoutButton.announceForAccessibility("Broadcast layout: "+Duwm1728BroadcastComposition.label(chosen));
        }
        return true;
    }
    private void showLayoutPicker(){
        if(!compositionEditable()||(layoutPicker!=null&&layoutPicker.isShowing()))return;
        final Duwm1728OverlayRenderer.Spec snapshot;final int[] size;
        try{snapshot=spec();size=plannedOutputSize(snapshot);
            if(size[0]<64||size[1]<64)throw new IllegalArgumentException("Source is too small for broadcast graphics");
        }catch(Exception error){notice("Check report timing before previewing layouts: "+error.getMessage());return;}
        final long elapsed=Duwm1728BroadcastTimeline.elapsed(position(),snapshot.fromMs,snapshot.toMs);
        LinearLayout choices=new LinearLayout(this);choices.setOrientation(LinearLayout.VERTICAL);choices.setPadding(dp(12),dp(4),dp(12),dp(8));choices.setBackgroundColor(NAVY);
        TextView help=label("Graphics at "+trimTime(elapsed)+" of this clip. Footage and inset remain in the editor preview.",12);help.setTextColor(SILVER);choices.addView(help,params());
        if(Duwm1728BroadcastLayout.active(snapshot.renderedCaptions,elapsed)==null){TextView noCaption=label("No caption is active at this playhead.",11);noCaption.setTextColor(SILVER);choices.addView(noCaption,params());}
        ScrollView scroll=new ScrollView(this){@Override protected void onMeasure(int width,int height){
            int available=getWindow().getDecorView().getHeight();if(available<=0)available=getResources().getDisplayMetrics().heightPixels;
            int limit=Math.max(dp(120),Math.round(available*.65f));
            if(View.MeasureSpec.getMode(height)!=View.MeasureSpec.UNSPECIFIED)limit=Math.min(limit,View.MeasureSpec.getSize(height));
            super.onMeasure(width,View.MeasureSpec.makeMeasureSpec(Math.max(1,limit),View.MeasureSpec.AT_MOST));}};
        scroll.setTag("broadcast-editor-layout-picker");scroll.setBackgroundColor(NAVY);scroll.setFillViewport(false);scroll.addView(choices,new ScrollView.LayoutParams(-1,-2));
        TextView heading=label("BROADCAST LAYOUT",16);heading.setTypeface(null,Typeface.BOLD);heading.setMinHeight(dp(48));heading.setBackgroundColor(NAVY);
        final AlertDialog picker=new AlertDialog.Builder(this).setCustomTitle(heading).setView(scroll).setNegativeButton("CLOSE",null).create();
        layoutChoices.clear();
        for(String composition:new String[]{Duwm1728BroadcastComposition.FULL,Duwm1728BroadcastComposition.COMPACT,Duwm1728BroadcastComposition.CAPTIONS}){
            // spec() made a private snapshot. reportAt copies its current strings/cues
            // and applies the same telemetry/GPS policy used by the actual renderer.
            snapshot.composition=composition;
            final Duwm1728BroadcastLayout.Report report=Duwm1728OverlayRenderer.reportAt(snapshot,elapsed);
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(6),dp(6),dp(6),dp(6));
            boolean current=composition.equals(selectedComposition);GradientDrawable border=new GradientDrawable();border.setColor(NAVY);border.setCornerRadius(dp(8));border.setStroke(Math.max(1,dp(1)),current?GREEN:SILVER);card.setBackground(border);
            String name=Duwm1728BroadcastComposition.label(composition);
            TextView choose=button(name,()->{if(applyComposition(composition))picker.dismiss();});choose.setTag("broadcast-editor-layout-"+composition);choose.setSelected(current);choose.setTextColor(current?GREEN:WHITE);
            choose.setContentDescription(name+(current?", current layout":"")+". "+Duwm1728BroadcastComposition.description(composition));
            choose.setAccessibilityDelegate(new View.AccessibilityDelegate(){@Override public void onInitializeAccessibilityNodeInfo(View host,android.view.accessibility.AccessibilityNodeInfo info){super.onInitializeAccessibilityNodeInfo(host,info);info.setClassName("android.widget.Button");}});
            layoutChoices.add(choose);card.addView(choose,new LinearLayout.LayoutParams(-1,-2));
            TextView description=label(Duwm1728BroadcastComposition.description(composition),12);description.setTextColor(SILVER);card.addView(description,new LinearLayout.LayoutParams(-1,-2));
            FrameLayout thumbnail=new FrameLayout(this);card.addView(thumbnail,new LinearLayout.LayoutParams(-1,dp(180)));
            Duwm1728AspectFrame frame=new Duwm1728AspectFrame(this);frame.setRatio(size[0]/(float)size[1]);thumbnail.addView(frame,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));
            View graphics=new View(this){private final Paint backdrop=new Paint();@Override protected void onDraw(Canvas canvas){
                canvas.drawColor(0xFF0A2438);backdrop.setColor(0xFF103149);int tile=dp(12);
                for(int y=0;y<getHeight();y+=tile)for(int x=0;x<getWidth();x+=tile)if(((x/tile+y/tile)&1)==0)canvas.drawRect(x,y,x+tile,y+tile,backdrop);
                int saved=canvas.save();canvas.scale(getWidth()/(float)size[0],getHeight()/(float)size[1]);
                Duwm1728BroadcastLayout.draw(new Duwm1728BroadcastCanvas(canvas),size[0],size[1],report,elapsed);canvas.restoreToCount(saved);
            }};
            graphics.setTag("broadcast-editor-layout-preview-"+composition);graphics.setContentDescription(name+" graphics preview at "+trimTime(elapsed)+" of the selected clip");frame.addView(graphics,new FrameLayout.LayoutParams(-1,-1));
            choices.addView(card,params());
        }
        layoutPicker=picker;picker.setOnDismissListener(d->{if(layoutPicker==picker){layoutPicker=null;layoutChoices.clear();}});
        picker.show();if(picker.getWindow()!=null)picker.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(NAVY));
        picker.getButton(AlertDialog.BUTTON_NEGATIVE).setMinHeight(dp(48));picker.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(SILVER);picker.getButton(AlertDialog.BUTTON_NEGATIVE).setTag("broadcast-editor-layout-close");
        updateExportState();
    }
    private void chooseRatio(){if(!compositionEditable())return;new AlertDialog.Builder(this).setTitle("Final MP4 shape — choose framing separately").setItems(new String[]{"9:10","9:16","16:9","ORIGINAL"},(d,i)->{if(!compositionEditable())return;automaticOutputSizing=false;selectedRatio=new String[]{"9:10","9:16","16:9","ORIGINAL"}[i];ratioButton.setText(selectedRatio);approval.setChecked(false);refresh();saveDraft();}).show();}
    private void showDetails(){if(!compositionEditable()){notice("Finish the current operation before editing report details");return;}if(detailsDialog!=null&&detailsDialog.isShowing())return;if(details.getParent() instanceof android.view.ViewGroup)((android.view.ViewGroup)details.getParent()).removeView(details);ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(NAVY);scroll.addView(details);final AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Report details").setView(scroll).setPositiveButton("DONE",(d,w)->refresh()).create();detailsDialog=dialog;dialog.setOnDismissListener(d->{if(detailsDialog==dialog)detailsDialog=null;});updateCaptionEntry();dialog.show();}
    private long ms(EditText e){double seconds=Double.parseDouble(e.getText().toString().trim());if((Double.isNaN(seconds)||Double.isInfinite(seconds))||seconds<0||seconds>Integer.MAX_VALUE/1000d)throw new IllegalArgumentException("Invalid time");return Math.round(seconds*1000);}
    private Duwm1728OverlayRenderer.Spec spec(){Duwm1728OverlayRenderer.Spec s=new Duwm1728OverlayRenderer.Spec();s.fromMs=ms(from);s.toMs=ms(to);if(s.toMs>durationMs||s.toMs<=s.fromMs)throw new IllegalArgumentException("Trim range exceeds the recording");s.title=title.getText().toString();s.place=place.getText().toString();s.description=caption.getText().toString();s.reporter=reporter;s.template=templates[selectedTemplate];s.breakingApproved=selectedTemplate==1;s.ratio=selectedRatio;s.frameMode=frameMode;s.frameX=frameX;s.frameY=frameY;s.ticker=ticker.getText().toString();s.tickerSpeed=tickerSpeed;s.captions=subtitles.getText().toString();s.pipVideo=pipVideo;s.provenance=provenanceLabel;s.composition=Duwm1728BroadcastComposition.normalize(selectedComposition);
        s.automaticHeadlineFit=automaticHeadlineFit;s.automaticOutputSizing=automaticOutputSizing;
        s.automaticSceneTitles=automaticSceneTitles;s.sceneTrack=Collections.unmodifiableList(new ArrayList<>(sceneTrack));
        s.tickerCues=Duwm1728TickerTimeline.parse(s.ticker);s.captionCues=Duwm1728TickerTimeline.parse(s.captions);s.automaticCaptions=new ArrayList<>(aiCaptions);s.automaticTickers=new ArrayList<>(automaticTickerCues);s.capturedTelemetry=provenance;s.recordedTrack=recordedTrackToggle.isChecked()?recordedTrack:Collections.emptyList();s.includeSourceSummary=sourceSummary.isChecked()&&provenance!=null;s.includeCoordinates=preciseExport.isChecked();s.tickerOriginMs=tickerOriginMs;s.captionOriginMs=captionOriginMs;
        Duwm1728OverlayRenderer.prepareTimelines(s);return s;}
    private void refresh(){if(title==null||recordedTrackToggle==null)return;
        long priorStart=previewSpec==null?-1:previewSpec.fromMs;
        try{previewSpec=spec();if(previewSpec.fromMs!=priorStart)lastInsetAt=-1;int[] d=plannedOutputSize(previewSpec);
            stage.setRatio(d[0]/(float)d[1]);texture.post(this::previewCrop);checkOutput(previewSpec);
            if(framingButton!=null){framingButton.setText(Duwm1728FramePlan.FIT.equals(frameMode)?"FULL":"FILL");framingButton.setContentDescription("Framing: "+(Duwm1728FramePlan.FIT.equals(frameMode)?"keep full picture":"fill with selected crop"));}
            if(captionInfo!=null)captionInfo.setText(captionKind+" • "+previewSpec.renderedCaptions.size()+" cues in selected range");
        }catch(Exception e){previewSpec=null;outputPlan=null;desiredPlanKey="";planGeneration++;
            if(planKick!=null)main.removeCallbacks(planKick);
            if(state!=null)state.setText("Check report: "+e.getMessage());
        }
        updateLayoutSummary();updateOutputSummary();updateTrimLabels();updateAutomaticReportInfo();requestPreviewUpdate(true);updateExportState();
    }
    private void updateAutomaticReportInfo(){
        if(automaticReportInfo==null)return;
        String origin="RECORDED_SPEECH".equals(automaticContentSource)?"Recorded speech":
                "CAPTURE_NOTES".equals(automaticContentSource)?"Reporter-provided capture notes":"Neutral recording label";
        String range=automaticHeadlineStart>=0?" • headline source "+Duwm1728CaptionEditPolicy.formatTime(automaticHeadlineStart)+" – "+Duwm1728CaptionEditPolicy.formatTime(automaticHeadlineEnd):"";
        int visible=previewSpec==null?0:previewSpec.renderedTickers.size();
        String scenes=automaticSceneTitles?"AI frame titles enabled • "+sceneTrack.size()+" saved observations. Missing or expired scenes remain neutral.\n":sceneCapture?"AI frame titles off • manual headline is selected.\n":"";
        if(sceneStorageError)scenes="Frame descriptions could not be saved. This recording uses a neutral scene title.\n"+scenes;
        automaticReportInfo.setText(scenes+origin+range+"\n"+(automaticTickerCues.isEmpty()?"Manual ticker or neutral recording text":automaticTickerCues.size()+" source-time ticker excerpts • "+visible+" in this clip")
                +"\n"+(automaticHeadlineFit?"Automatic headline fits within its panel. ":"")+"Long captions use timed pages; stored words and cue timestamps stay unchanged.");
        if(title!=null)title.setHint(automaticSceneTitles?"Manual headline (typing switches AI frame titles off)":"Report headline / labelled source excerpt");
        if(ticker!=null)ticker.setHint(automaticTickerCues.isEmpty()?"00:00=First update;00:15=Next update":"Type a manual ticker here to replace "+automaticTickerCues.size()+" automatic source excerpts");
    }
    private String outputPlanKey(Duwm1728OverlayRenderer.Spec selected){
        return selected.ratio+"|"+selected.fromMs+"|"+selected.toMs+"|"+selected.frameMode+"|"+selected.frameX+"|"+selected.frameY+"|"+selected.automaticOutputSizing;
    }
    private String outputGeometryKey(Duwm1728OverlayRenderer.Spec selected){
        return selected.ratio+"|"+selected.frameMode+"|"+selected.frameX+"|"+selected.frameY+"|"+selected.automaticOutputSizing;
    }
    private int[] plannedOutputSize(Duwm1728OverlayRenderer.Spec selected){
        // A temporary caption preview may use a different source interval; it
        // still uses the checked canvas when its actual framing is unchanged.
        if(outputPlan!=null&&outputGeometryKey(selected).equals(checkedGeometryKey))return new int[]{outputPlan.width,outputPlan.height};
        return Duwm1728FramePlan.dimensions(sourceW,sourceH,selected.ratio,selected.frameMode);
    }
    private void checkOutput(Duwm1728OverlayRenderer.Spec selected){
        // Composition changes graphics, not codec support or output dimensions.
        String key=outputPlanKey(selected);
        if(key.equals(desiredPlanKey))return;desiredPlanKey=key;int generation=++planGeneration;
        outputPlan=null;outputPlanError="";updateOutputSummary();
        if(planKick!=null)main.removeCallbacks(planKick);
        planKick=()->{if(destroyed||generation!=planGeneration)return;
            planWorker.execute(()->{Duwm1728ExportPreflight.Result result=null;String error="";
                try{result=Duwm1728ExportPreflight.inspect(getApplicationContext(),source,selected.fromMs,selected.toMs,selected.ratio,selected.frameMode,selected.frameX,selected.frameY,selected.automaticOutputSizing);}
                catch(Exception ex){error=ex.getMessage()==null?ex.getClass().getSimpleName():ex.getMessage();}
                final Duwm1728ExportPreflight.Result checked=result;final String failure=error;
                main.post(()->{if(destroyed||generation!=planGeneration)return;
                    outputPlan=checked;outputPlanError=failure;
                    checkedGeometryKey=checked==null?"":outputGeometryKey(selected);
                    if(checked!=null){stage.setRatio(checked.width/(float)checked.height);texture.post(this::previewCrop);requestPreviewUpdate(true);}
                    updateOutputSummary();updateExportState();maybeExportAutomatic();});
            });};main.postDelayed(planKick,180);
    }
    private void showOutputCheck(){
        String text=outputPlan==null?(outputPlanError.isEmpty()?"Output inspection is still running.":outputPlanError):outputPlan.summary()+"\n\nEncoder: "+outputPlan.encoder+
            "\nSource upright size: "+outputPlan.sourceWidth+" × "+outputPlan.sourceHeight+
            "\nThis checks source metadata and advertised codec support, not physical recording quality. No frame is stretched and no missing audio is invented.";
        text="Layout: "+Duwm1728BroadcastComposition.label(selectedComposition)+"\n"+Duwm1728BroadcastComposition.description(selectedComposition)+"\n\n"+text;
        new AlertDialog.Builder(this).setTitle("Broadcast output check").setMessage(text).setNegativeButton("CLOSE",null)
            .setPositiveButton("RECHECK",(d,w)->{if(!busy&&!aiBusy){desiredPlanKey="";refresh();}}).show();
    }
    private void updateExportState(){
        boolean productionIdle=!busy&&!aiBusy&&!autoProducing&&recordedAudioTranscriber==null;
        if(!productionIdle&&captionEditor!=null)captionEditor.dismiss();
        boolean filesIdle=captionFiles==null||!captionFiles.locksEditor();
        boolean idle=productionIdle&&captionEditor==null&&filesIdle;
        boolean ok=!draftRestoreBlocked&&showBroadcast&&idle&&previewSpec!=null&&outputPlan!=null&&approval!=null&&approval.isChecked()&&title!=null&&(automaticSceneTitles||!title.getText().toString().trim().isEmpty());
        enable(exportButton,ok);enable(aiButton,idle);enable(aiSetupButton,idle);enable(editButton,idle);
        enable(ratioButton,idle);enable(framingButton,idle);enable(reviewButton,idle&&lastBroadcast!=null);
        enable(layoutButton,idle);
        enable(captionEditorButton,productionIdle&&filesIdle);enable(captionFilesButton,idle);enable(captionFilesDetailsButton,idle);updateCaptionEntry();
        if(!idle&&layoutPicker!=null)layoutPicker.dismiss();else for(TextView choice:layoutChoices)enable(choice,idle);
        enable(recoveryButton,idle);enable(reviewCopyButton,idle&&pendingRecovery!=null&&pendingRecovery.hasLocalCopy&&recoveryLoadError.isEmpty());
        enable(markInButton,idle&&prepared&&durationMs>0);enable(markOutButton,idle&&prepared&&durationMs>0);enable(resetTrimButton,idle&&durationMs>0);
        enable(playButton,prepared&&!busy&&!autoProducing&&filesIdle);if(seek!=null)seek.setEnabled(prepared&&!busy&&!autoProducing&&filesIdle);if(approval!=null)approval.setEnabled(idle);
        if(renderControls!=null)renderControls.setVisibility(busy||autoProducing?View.VISIBLE:View.GONE);
        if(cancelExportButton!=null)enable(cancelExportButton,(autoProducing&&!busy)||(busy&&!finalizingExport&&exportSpec!=null&&!exportSpec.cancelled.get()));
    }
    private void enable(View view,boolean enabled){if(view!=null){view.setEnabled(enabled);view.setAlpha(enabled?1f:.45f);}}
    private void previewCrop(){
        int w=texture.getWidth(),h=texture.getHeight();if(w<1||h<1)return;
        Duwm1728FramePlan.Plan f=Duwm1728FramePlan.create(sourceW,sourceH,w,h,frameMode,frameX,frameY);
        Matrix m=new Matrix();m.setValues(new float[]{f.scaleX(),0,w*f.translateX(),0,f.scaleY(),h*f.translateY(),0,0,1});
        texture.setTransform(m);texture.invalidate();
    }
    /** Alignment guides are preview-only and are never sent to the graphics encoder. */
    private void drawCompositionGuides(Canvas canvas){
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(0xB0DEE5EF);p.setStrokeWidth(dp(1));
        float w=canvas.getWidth(),h=canvas.getHeight();
        for(int i=1;i<3;i++){canvas.drawLine(w*i/3,0,w*i/3,h,p);canvas.drawLine(0,h*i/3,w,h*i/3,p);}
        p.setStyle(Paint.Style.STROKE);canvas.drawRect(w*.05f,h*.05f,w*.95f,h*.95f,p);
    }
    private void framingChanged(){automaticOutputSizing=false;approval.setChecked(false);refresh();saveDraft();}
    private void showFraming(){
        if(!compositionEditable()){notice("Wait for the current operation before changing framing");return;}
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(14),dp(6),dp(14),dp(12));
        TextView explanation=label("",12);box.addView(explanation,params());
        RadioGroup modes=new RadioGroup(this);modes.setOrientation(LinearLayout.VERTICAL);
        RadioButton fit=new RadioButton(this);fit.setId(View.generateViewId());fit.setText("KEEP FULL PICTURE — navy bars; no crop");fit.setTextColor(WHITE);
        RadioButton fill=new RadioButton(this);fill.setId(View.generateViewId());fill.setText("FILL FRAME — crop around chosen position");fill.setTextColor(WHITE);
        modes.addView(fit);modes.addView(fill);modes.check(Duwm1728FramePlan.FIT.equals(frameMode)?fit.getId():fill.getId());box.addView(modes,params());
        TextView horizontal=label("",11),vertical=label("",11);SeekBar x=new SeekBar(this),y=new SeekBar(this);x.setMax(100);y.setMax(100);x.setProgress(Math.round(frameX*100));y.setProgress(Math.round(frameY*100));
        x.setContentDescription("Horizontal crop position: left to right");y.setContentDescription("Vertical crop position: top to bottom");
        box.addView(horizontal,params());box.addView(x,params());box.addView(vertical,params());box.addView(y,params());
        Runnable labels=()->{int[] size=automaticOutputSizing&&outputPlan!=null&&outputPlan.automaticSizing
                    ?new int[]{outputPlan.width,outputPlan.height}:Duwm1728FramePlan.dimensions(sourceW,sourceH,selectedRatio,frameMode);
            Duwm1728FramePlan.Plan f=Duwm1728FramePlan.create(sourceW,sourceH,size[0],size[1],frameMode,frameX,frameY);
            explanation.setText(f.describe()+"\n"+size[0]+" × "+size[1]+" output • no stretching / no source upscaling");
            horizontal.setText("LEFT ↔ RIGHT  "+Math.round(frameX*100)+"%"+(f.w>=.9999f?" — no horizontal crop":""));
            vertical.setText("TOP ↔ BOTTOM  "+Math.round(frameY*100)+"%"+(f.h>=.9999f?" — no vertical crop":""));
            x.setEnabled(Duwm1728FramePlan.FILL.equals(frameMode)&&f.w<.9999f);y.setEnabled(Duwm1728FramePlan.FILL.equals(frameMode)&&f.h<.9999f);
        };
        modes.setOnCheckedChangeListener((group,id)->{frameMode=id==fit.getId()?Duwm1728FramePlan.FIT:Duwm1728FramePlan.FILL;framingChanged();labels.run();});
        SeekBar.OnSeekBarChangeListener pan=new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar v,int progress,boolean user){if(!user)return;if(v==x)frameX=progress/100f;else frameY=progress/100f;framingChanged();labels.run();}public void onStartTrackingTouch(SeekBar v){}public void onStopTrackingTouch(SeekBar v){}};
        x.setOnSeekBarChangeListener(pan);y.setOnSeekBarChangeListener(pan);
        box.addView(button("RESET SUBJECT TO CENTRE",()->{frameX=.5f;frameY=.5f;x.setProgress(50);y.setProgress(50);framingChanged();labels.run();}),params());
        CheckBox guides=check("Composition guides (preview only)",showCompositionGuides);guides.setOnCheckedChangeListener((v,on)->{showCompositionGuides=on;broadcast.invalidate();});box.addView(guides,params());
        CheckBox graphics=check("Show broadcast graphics in preview",showBroadcast);graphics.setOnCheckedChangeListener((v,on)->{showBroadcast=on;approval.setChecked(false);broadcast.invalidate();updateExportState();});box.addView(graphics,params());
        box.addView(label("The guide and comparison toggles do not change the finished MP4. Turn graphics on again to review and enable export. Export always includes the approved broadcast graphics. Keep Full preserves the scene, but graphics can still cover parts of it.",11),params());
        labels.run();ScrollView scroll=new ScrollView(this);scroll.addView(box);scroll.setBackgroundColor(NAVY);
        new AlertDialog.Builder(this).setTitle("Frame your broadcast").setView(scroll).setPositiveButton("DONE",(d,w)->refresh()).show();
    }
    @Override public void onSurfaceTextureAvailable(SurfaceTexture s,int w,int h){try{releasePlayer();playbackSurface=new Surface(s);player=new MediaPlayer();player.setDataSource(this,source);player.setSurface(playbackSurface);
        player.setOnSeekCompleteListener(p->{if(destroyed||p!=player)return;lastInsetAt=-1;requestPreviewUpdate(true);if(captionEditor!=null)captionEditor.refreshPlayhead();});
        player.setOnPreparedListener(p->{if(destroyed||p!=player)return;prepared=true;previewCrop();
            Duwm1728OverlayRenderer.Spec playback=playbackSpec();long start=playback==null?0:playback.fromMs,end=playback==null?durationMs:playback.toMs;
            long resume=surfaceResumeMs<0?start:Math.max(start,Math.min(end-1,surfaceResumeMs));surfaceResumeMs=-1;
            seekSource(resume);requestPreviewUpdate(true);updateExportState();});
        player.setOnCompletionListener(p->{if(destroyed||p!=player)return;showPlaying(false);requestPreviewUpdate(true);});
        player.setOnErrorListener((p,what,extra)->{prepared=false;main.removeCallbacks(clock);showPlaying(false);updateExportState();notice("Source video cannot be played");return true;});player.prepareAsync();}catch(Exception e){notice("Cannot open video: "+e.getMessage());}}
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture s,int w,int h){previewCrop();}
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture s){releasePlayer();return true;}
    @Override public void onSurfaceTextureUpdated(SurfaceTexture s){}
    private void releasePlayer(){if(prepared&&player!=null)try{surfaceResumeMs=player.getCurrentPosition();}catch(IllegalStateException ignored){}
        prepared=false;main.removeCallbacks(clock);if(player!=null){try{player.release();}catch(Exception ignored){}player=null;}if(playbackSurface!=null){playbackSurface.release();playbackSurface=null;}}
    private void loadInset(Uri uri){int generation=++insetGeneration;
        if(insetFrame!=null)insetFrame.recycle();insetFrame=null;lastInsetAt=-1;if(broadcast!=null)broadcast.invalidate();
        insetWorker.execute(()->{if(insetRetriever!=null){try{insetRetriever.release();}catch(Exception ignored){}insetRetriever=null;}if(uri!=null)try{MediaMetadataRetriever r=new MediaMetadataRetriever();r.setDataSource(getApplicationContext(),uri);insetRetriever=r;}catch(Exception e){main.post(()->{if(!destroyed&&generation==insetGeneration)notice("Inset unavailable");});}
        main.post(()->{if(destroyed||generation!=insetGeneration)return;lastInsetAt=-1;updateInset(position());if(broadcast!=null)broadcast.invalidate();});});}
    private void updateInset(long ms){if(pipVideo==null||(lastInsetAt>=0&&ms>=lastInsetAt&&ms-lastInsetAt<160)||!insetBusy.compareAndSet(false,true))return;lastInsetAt=ms;int generation=insetGeneration;Duwm1728OverlayRenderer.Spec playback=playbackSpec();long start=playback==null?0:playback.fromMs;
        insetWorker.execute(()->{Bitmap frame=null;try{if(insetRetriever!=null){long t=Math.max(0,ms-start)*1000;String d=insetRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);if(d!=null)t=Math.min(t,Math.max(0,Long.parseLong(d)*1000-1));frame=Build.VERSION.SDK_INT>=27?insetRetriever.getScaledFrameAtTime(t,MediaMetadataRetriever.OPTION_CLOSEST,480,480):insetRetriever.getFrameAtTime(t,MediaMetadataRetriever.OPTION_CLOSEST);}}catch(Exception ignored){}
            final Bitmap result=frame;main.post(()->{insetBusy.set(false);Duwm1728OverlayRenderer.Spec current=playbackSpec();if(destroyed||generation!=insetGeneration||start!=(current==null?0:current.fromMs)){
                if(result!=null)result.recycle();if(!destroyed){lastInsetAt=-1;updateInset(position());}return;}
                Bitmap prior=insetFrame;insetFrame=result;if(prior!=null&&prior!=result)prior.recycle();if(broadcast!=null)broadcast.invalidate();
                // A paused seek/trim may have arrived while decoding the previous inset.
                updateInset(position());});});}
    private void aiSettings(){
        if(!compositionEditable())return;if(automaticHelpDialog!=null)automaticHelpDialog.dismiss();
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setBaselineAligned(false);box.setPadding(dp(16),0,dp(16),0);box.setTag("broadcast-auto-help-content");
        CheckBox automatic=check("Automatically edit and save each new recording",getSharedPreferences(Duwm1728AutomaticProduction.PREFS,MODE_PRIVATE).getBoolean("enabled",true));automatic.setMinHeight(dp(48));automatic.setTag("broadcast-auto-enabled");
        box.addView(label("Stop recording and DUWM prepares a finished MP4 with the original picture shape and audio. New recordings use saved AI frame titles when this phone and its on-device image model support them. Titles follow the sampled frames; missing or expired descriptions stay neutral. Speech captions and timed source-word excerpts remain available when supported. Manual editing is optional.",13));
        box.addView(automatic);
        final TextView readiness=label("Checking this phone's caption support…",13);readiness.setTag("broadcast-speech-readiness-status");readiness.setTextIsSelectable(true);box.addView(readiness);
        final TextView checkCaptions=button("CHECK CAPTIONS",()->{});checkCaptions.setTag("broadcast-speech-readiness-check");checkCaptions.setOnClickListener(v->checkSpeechReadiness(readiness,checkCaptions));box.addView(checkCaptions,params());
        box.addView(label("DUWM chooses a compatible installed model for your phone's language. This check does not listen or read your video. During production, DUWM checks the recording request again and uses only the words and timings actually returned.",12));
        box.addView(label("This automatic flow processes recordings on this device. No server address, account or API key is needed. If captions or frame descriptions are unavailable, DUWM still finishes the video and reports their absence. Missing speech languages can be installed through your phone's speech settings; this caption check does not start a language download.",12));
        box.addView(label("Automatic editing keeps the complete recording. SOURCE WORDS are excerpts from the recognized soundtrack; SOURCE NOTES are reporter-provided notes. These are not independently verified news facts. Caption and ticker pages divide the original cue interval for display; they do not create new speech timestamps. Very dense text can still change quickly. A recording is never marked as reviewed by you automatically.",12));
        box.addView(label("Current result: "+automaticStatus+"\nCaptions: "+automaticCaptionStatus+"\nFrame descriptions: "+(sceneStorageError?"Frame descriptions could not be saved":sceneCapture?sceneTrack.size()+" saved observations; their original times determine when each appears":"No scene track for this source"),12));
        automatic.setOnCheckedChangeListener((v,on)->getSharedPreferences(Duwm1728AutomaticProduction.PREFS,MODE_PRIVATE).edit().putBoolean("enabled",on).apply());
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(NAVY);scroll.addView(box);
        final AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Built-in production help").setView(scroll).setNegativeButton("CLOSE",null)
                .setPositiveButton("AUTO PRODUCE",(d,w)->{closeSpeechReadiness();startAutomaticProduction();}).create();
        automaticHelpDialog=dialog;dialog.setOnDismissListener(d->{if(automaticHelpDialog==dialog){automaticHelpDialog=null;closeSpeechReadiness();}});dialog.show();
        checkSpeechReadiness(readiness,checkCaptions);
    }
    private void closeSpeechReadiness(){if(speechReadiness!=null){speechReadiness.close();speechReadiness=null;}}
    private void checkSpeechReadiness(TextView output,TextView checkButton){
        if(destroyed||isFinishing()||automaticHelpDialog==null||!automaticHelpDialog.isShowing())return;
        closeSpeechReadiness();
        if(autoProducing||busy||aiBusy||recordedAudioTranscriber!=null){output.setText("Caption checking is available when the current production finishes.");return;}
        final Duwm1728SpeechReadiness current=new Duwm1728SpeechReadiness(this);speechReadiness=current;
        output.setText("Checking this phone's caption support…");checkButton.setEnabled(false);
        current.check(result->{
            if(destroyed||speechReadiness!=current||automaticHelpDialog==null||!automaticHelpDialog.isShowing())return;
            speechReadiness=null;checkButton.setEnabled(true);
            String heading=result.recordedFileSupported?"READY TO TRY CAPTIONS":
                    "PENDING".equals(result.status)?"MODEL DOWNLOAD PENDING":
                    "DOWNLOADABLE".equals(result.status)?"LANGUAGE MODEL NOT INSTALLED":
                    "UNAVAILABLE".equals(result.status)?"ON-DEVICE CAPTIONS UNAVAILABLE":"CAPTION SUPPORT NOT CONFIRMED";
            String language="Phone language: "+result.requestedLanguage;
            if(result.selectedLanguage!=null&&!result.selectedLanguage.isEmpty())language+="\nSelected speech model: "+result.selectedLanguage;
            output.setText(heading+"\n"+language+"\n"+result.message);
        });
    }
    private void requestAi(){startAutomaticProduction();}
    private String automaticKey(){return Duwm1728AutomaticProduction.receiptKey(Duwm1728CaptureTelemetry.storageKey(source));}
    private static boolean automaticReceipt(Context context,String key,String sourceKey,String status,String captionStatus,Uri output){
        try{JSONObject record=new JSONObject().put("state",status).put("caption_status",captionStatus)
                .put("source_key",sourceKey).put("updated_at",System.currentTimeMillis());
            if(output!=null)record.put("uri",output.toString());
            return context.getSharedPreferences(Duwm1728AutomaticProduction.PREFS,MODE_PRIVATE).edit().putString(key,record.toString()).commit();
        }catch(Exception failure){return false;}
    }
    private void startAutomaticProduction(){
        if(!compositionEditable()||destroyed||isFinishing())return;
        if(draftRestoreBlocked){state.setText("Saved draft needs recovery before starting a replacement. The original draft is kept.");return;}
        if(!automaticReceipt(this,automaticKey(),Duwm1728CaptureTelemetry.storageKey(source),"STARTED","Checking on-device speech",null)){
            state.setText("Automatic production could not record its start. Try again after freeing device storage.");return;}
        automaticGeneration++;autoProducing=true;autoAwaitingOutput=false;automaticExport=false;
        automaticStatus="STARTED";automaticCaptionStatus="Checking on-device speech";automaticCues.clear();automaticEmptySegments=0;automaticSpeechLanguages.clear();approval.setChecked(false);
        if(detailsDialog!=null)detailsDialog.dismiss();if(layoutPicker!=null)layoutPicker.dismiss();if(automaticHelpDialog!=null)automaticHelpDialog.dismiss();closeSpeechReadiness();pausePreview();
        exportProgress.setIndeterminate(true);state.setText("AUTOMATIC EDITING • checking recorded-audio support");state.setTextColor(0xFF00ACC1);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);updateExportState();
        if(Build.VERSION.SDK_INT<34||!Duwm1728RecordedAudioTranscriber.canAttempt(this)){
            automaticCaptionStatus="CAPTIONS UNAVAILABLE • no compatible on-device word-timing service";finishAutomaticPlan();return;
        }
        transcribeAutomaticChunk(0,automaticGeneration);
    }
    private void transcribeAutomaticChunk(long start,int generation){
        if(destroyed||!autoProducing||generation!=automaticGeneration)return;
        if(start>=durationMs){automaticCaptionStatus=(automaticCues.isEmpty()?"NO WORDS RETURNED • recorded-file recognition completed":
                "ON-DEVICE CAPTIONS • word starts reported; cue ends derived"+(automaticEmptySegments>0?" • "+automaticEmptySegments+" completed sections returned no words":""))
                +(automaticSpeechLanguages.isEmpty()?"":" • model "+String.join(", ",automaticSpeechLanguages));finishAutomaticPlan();return;}
        final long end=Duwm1728AutomaticProduction.chunkEnd(start,durationMs);
        automaticStatus="TRANSCRIBING";state.setText("AUTOMATIC CAPTIONS • "+Duwm1728BroadcastTimeline.clock(start)+" / "+Duwm1728BroadcastTimeline.clock(durationMs));
        final Duwm1728RecordedAudioTranscriber current=new Duwm1728RecordedAudioTranscriber(this);recordedAudioTranscriber=current;updateExportState();
        current.transcribe(source,start,end,new Duwm1728RecordedAudioTranscriber.Listener(){
            @Override public void status(String message){
                if(destroyed||!autoProducing||generation!=automaticGeneration||recordedAudioTranscriber!=current)return;
                automaticCaptionStatus=Duwm1728BroadcastLayout.clean(message,240);
                state.setText("AUTOMATIC CAPTIONS • "+Duwm1728BroadcastTimeline.clock(start)+" / "+Duwm1728BroadcastTimeline.clock(durationMs)+"\n"+automaticCaptionStatus);
            }
            @Override public void error(String message){
                if(recordedAudioTranscriber==current)recordedAudioTranscriber=null;
                if(destroyed||!autoProducing||generation!=automaticGeneration)return;
                automaticCues.clear();automaticCaptionStatus="CAPTIONS UNAVAILABLE • "+Duwm1728BroadcastLayout.clean(message,240);finishAutomaticPlan();
            }
            @Override public void done(Duwm1728RecordedAudioTranscriber.Result result){
                if(recordedAudioTranscriber==current)recordedAudioTranscriber=null;
                if(destroyed||!autoProducing||generation!=automaticGeneration)return;
                if(result.selectedLanguage!=null&&!result.selectedLanguage.isEmpty())automaticSpeechLanguages.add(result.selectedLanguage);
                if(result.completedWithoutWords){automaticEmptySegments++;main.post(()->transcribeAutomaticChunk(end,generation));return;}
                if(!result.hasVerifiedWordTimes||result.cues.isEmpty()){
                    automaticCues.clear();automaticCaptionStatus="CAPTIONS UNAVAILABLE • the device did not return usable word timestamps";finishAutomaticPlan();return;
                }
                try{automaticCues.addAll(result.cues);Duwm1728CaptionEditPolicy.copyAndValidate(automaticCues,durationMs);}
                catch(Exception invalid){automaticCues.clear();automaticCaptionStatus="CAPTIONS UNAVAILABLE • invalid or excessive recognition output";finishAutomaticPlan();return;}
                main.post(()->transcribeAutomaticChunk(end,generation));
            }
        });
    }
    private void finishAutomaticPlan(){
        if(destroyed||!autoProducing)return;
        try{Duwm1728AutomaticProduction.Plan plan=Duwm1728AutomaticProduction.plan(durationMs,automaticCues,automaticCaptionStatus,captureNotes);
            loadSceneTrack();
            updatingFields=true;
            try{title.setText(plan.title);caption.setText(plan.description);ticker.setText("");subtitles.setText("");
                from.setText("0.000");to.setText(String.format(Locale.US,"%.3f",plan.toMs/1000d));
                selectedRatio=plan.ratio;ratioButton.setText(selectedRatio);frameMode=plan.frameMode;frameX=.5f;frameY=.5f;
                selectedComposition=plan.composition;selectedTemplate=0;
                for(int i=0;i<templates.length;i++)if(i!=1&&templates[i].equalsIgnoreCase(captureCategory)){selectedTemplate=i;break;}
                templateButton.setText("CATEGORY: "+templates[selectedTemplate]);
                aiCaptions=plan.cues;captionOriginMs=0;tickerOriginMs=0;manualCaptionOriginSet=false;captionKind=plan.cues.isEmpty()?"Automatic video • no speech captions":"Automatic speech captions • ends derived";
                automaticTickerCues=plan.tickers;automaticContentSource=plan.contentSource;automaticReportEvidence=plan.sourceEvidence;
                automaticHeadlineStart=plan.headlineSourceStartMs;automaticHeadlineEnd=plan.headlineSourceEndMs;
                automaticHeadlineFit=true;automaticOutputSizing=true;
                selectSceneTitles(sceneCapture);
                provenanceLabel=plan.provenance;showBroadcast=true;preciseExport.setChecked(false);
                // Automatic output uses the source recording and its existing audio, without an unrelated inset.
                pipVideo=null;loadInset(null);pipSelection.setText("PICTURE-IN-PICTURE OFF");
                aiEvidence="Built-in automatic report. Full source retained; original picture shape; compact graphics.\n"+automaticReportEvidence+"\n"+automaticCaptionStatus
                        +(automaticSceneTitles?"\nAI frame titles use "+sceneTrack.size()+" saved source-time observations. Future and expired descriptions are hidden; gaps use a neutral scene label.":"")
                        +"\nNo cloud request was made. Caption ends and page intervals are display estimates; recognized words remain unreviewed.";aiEvidenceView.setText(aiEvidence);
            }finally{updatingFields=false;}
            approval.setChecked(false);automaticStatus="WAITING_FOR_ENCODER";autoAwaitingOutput=true;state.setText("AUTOMATIC EDITING • checking the MP4 encoder");
            refresh();if(previewSpec==null)throw new IllegalStateException("Automatic output fields are invalid");saveDraft();maybeExportAutomatic();
        }catch(Exception failure){failAutomatic("Automatic edit could not be prepared: "+failure.getMessage());}
    }
    private void maybeExportAutomatic(){
        if(!autoProducing||!autoAwaitingOutput||destroyed||busy||recordedAudioTranscriber!=null)return;
        if(outputPlan==null){if(!outputPlanError.isEmpty())failAutomatic("Automatic MP4 unavailable: "+outputPlanError);return;}
        autoAwaitingOutput=false;export(true);
    }
    private void failAutomatic(String message){
        autoProducing=false;autoAwaitingOutput=false;automaticStatus="FAILED";automaticGeneration++;
        if(recordedAudioTranscriber!=null){recordedAudioTranscriber.close();recordedAudioTranscriber=null;}
        automaticReceipt(this,automaticKey(),Duwm1728CaptureTelemetry.storageKey(source),automaticStatus,automaticCaptionStatus,null);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);state.setText(message);state.setTextColor(0xFFFFB300);updateExportState();
    }
    private void beginAi(Duwm1728OverlayRenderer.Spec selected){
        // Guard again here: a consent dialog may have remained open while the
        // editor changed state. Never start a second worker or an invalid clip.
        if(!compositionEditable())return;
        if(!Duwm1728AiProductionClient.configured(this)){
            state.setText("AI NOT CONNECTED • no video uploaded");
            state.setTextColor(0xFFFBC02D);return;
        }
        if(selected==null||selected.fromMs<0||selected.toMs<=selected.fromMs||selected.toMs>durationMs){
            state.setText("Check the selected video range before AI analysis");return;
        }
        aiBusy=true;approval.setChecked(false);updateExportState();state.setText("AI ANALYSIS IN PROGRESS • no report approved");state.setTextColor(0xFF00ACC1);aiClient=new Duwm1728AiProductionClient(this);
        new Thread(()->{try{JSONObject result=aiClient.produce(source,selected.fromMs,selected.toMs,selected.description);main.post(()->{if(destroyed)return;try{applyAi(result,selected.fromMs,selected.toMs);state.setText("AI DRAFT READY • review headline, ticker and subtitles");state.setTextColor(0xFFFBC02D);}catch(Exception e){state.setText("AI response rejected: "+e.getMessage());}finally{aiBusy=false;updateExportState();if(!destroyed)showDetails();}});}catch(Exception e){main.post(()->{if(destroyed)return;aiBusy=false;state.setText("AI UNAVAILABLE • "+e.getMessage());state.setTextColor(0xFFD50000);updateExportState();});}},"duwm-ai-produce").start();}
    private void applyAi(JSONObject report,long clipStart,long clipEnd)throws Exception{
        // Validate the complete proposal before replacing any reviewed UI field.
        String proposedTitle=report.getString("headline").trim();if(proposedTitle.isEmpty())throw new IllegalArgumentException("Empty AI headline");
        if(report.has("clip_from_ms")&&(report.getLong("clip_from_ms")!=clipStart||report.getLong("clip_to_ms")!=clipEnd))throw new IllegalArgumentException("AI reply is for a different clip");
        if(report.has("ticker_timebase")&&!"clip_relative_ms".equals(report.getString("ticker_timebase")))throw new IllegalArgumentException("Unknown ticker time base");
        if(report.has("caption_timebase")&&!"source_absolute_ms".equals(report.getString("caption_timebase")))throw new IllegalArgumentException("Unknown caption time base");
        JSONArray updates=report.optJSONArray("ticker");Set<Long> secondsSeen=new HashSet<>();StringBuilder text=new StringBuilder();
        if(updates!=null)for(int i=0;i<Math.min(12,updates.length());i++){
            JSONObject item=updates.getJSONObject(i);long stamp=item.getLong("at_ms");
            if(stamp<0||stamp>=clipEnd-clipStart)throw new IllegalArgumentException("AI ticker falls outside the analysed clip");
            long sec=stamp/1000;if(!secondsSeen.add(sec))continue;if(text.length()>0)text.append(';');
            text.append(String.format(Locale.US,"%02d:%02d=",sec/60,sec%60)).append(item.getString("text").replace(';',',').replace('=','-'));
        }
        Duwm1728TickerTimeline.parse(text.toString());
        ArrayList<Duwm1728BroadcastLayout.Cue> cues=new ArrayList<>();JSONArray captions=report.optJSONArray("captions");
        if(captions!=null){if(captions.length()>20000)throw new IllegalArgumentException("Too many AI caption cues");
            for(int i=0;i<captions.length();i++){JSONObject c=captions.getJSONObject(i);long start=c.getLong("start_ms"),end=c.getLong("end_ms");
                if(start<clipStart||end>clipEnd||end<=start)throw new IllegalArgumentException("AI caption falls outside the analysed clip");
                cues.add(new Duwm1728BroadcastLayout.Cue(start,end,c.getString("text")));}}
        updatingFields=true;try{
            selectSceneTitles(false);automaticHeadlineFit=false;title.setText(proposedTitle);caption.setText(report.optString("description"));String category=report.optString("category","FIELD REPORT");
            selectedTemplate=0;for(int i=0;i<templates.length;i++)if(i!=1&&templates[i].equals(category))selectedTemplate=i;
            // AI replaces report content; the reporter's composition stays selected.
            templateButton.setText("CATEGORY: "+templates[selectedTemplate]);tickerOriginMs=clipStart;automaticTickerCues=Collections.emptyList();automaticContentSource="NEUTRAL";automaticReportEvidence="";automaticHeadlineStart=automaticHeadlineEnd=-1;ticker.setText(text);
            aiCaptions=cues;subtitles.setText("");captionKind="AI soundtrack captions — review required";provenanceLabel="AI-ASSISTED • REVIEW REQUIRED";
            StringBuilder evidence=new StringBuilder("AI model: "+report.optString("ai_model","unspecified")+"\nAnalysed source range: "+Duwm1728BroadcastTimeline.clock(clipStart)+" – "+Duwm1728BroadcastTimeline.clock(clipEnd)+"\nVisual analysis uses sampled frames, not every frame.\nUncertainties: ");
            JSONArray warnings=report.optJSONArray("uncertainties");if(warnings!=null)for(int i=0;i<warnings.length();i++)evidence.append("\n• ").append(warnings.optString(i));
            aiEvidence=evidence.toString();aiEvidenceView.setText(aiEvidence);
            getSharedPreferences("duwm_production_drafts",MODE_PRIVATE).edit().putString("ai_"+Duwm1728CaptureTelemetry.storageKey(source),report.toString()).apply();
        }finally{updatingFields=false;}approval.setChecked(false);refresh();
    }
    private void export(){export(false);}
    private void export(boolean automatic){if(draftRestoreBlocked||busy||aiBusy||recordedAudioTranscriber!=null||captionEditor!=null||!showBroadcast
            ||(captionFiles!=null&&captionFiles.locksEditor())||(!automatic&&(!approval.isChecked()||autoProducing))
            ||(automatic&&(!autoProducing||!"WAITING_FOR_ENCODER".equals(automaticStatus))))return;
        if(outputPlan==null){if(automatic)failAutomatic("Automatic MP4 output inspection is unavailable");else notice("Wait for the output check, or correct the reported format problem");return;}final Duwm1728OverlayRenderer.Spec selected;
        try{selected=spec();if(!automatic&&provenanceLabel.startsWith("AI-"))selected.provenance="AI-ASSISTED • REPORTER REVIEWED";Duwm1728OverlayRenderer.prepare(selected);}catch(Exception e){if(automatic)failAutomatic("Automatic MP4 could not be prepared: "+e.getMessage());else notice("Correct report: "+e.getMessage());return;}
        pausePreview();requestPreviewUpdate(true);
        busy=true;automaticExport=automatic;exportSpec=selected;finalizingExport=false;exportProgress.setIndeterminate(false);exportProgress.setProgress(0);
        if(automatic)automaticStatus="RENDERING";
        updateExportState();state.setText("RENDERING BROADCAST  0%");state.setTextColor(0xFF00ACC1);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);saveDraft();
        selected.progress=p->main.post(()->{
            if(destroyed||exportSpec!=selected||selected.cancelled.get()||finalizingExport)return;
            int progress=Math.max(0,Math.min(98,p));exportProgress.setProgress(progress);state.setText("RENDERING BROADCAST  "+progress+"%");
        });
        final Context app=getApplicationContext();final Uri original=source;recoveryGeneration++;
        final String automaticReceiptKey=automaticKey(),automaticSourceKey=Duwm1728CaptureTelemetry.storageKey(source),captionOutcome=automaticCaptionStatus;
        final String automaticSuccess=selected.automaticCaptions.isEmpty()?"SAVED_WITHOUT_CAPTIONS":"SAVED_WITH_CAPTIONS";
        new Thread(()->{File produced=null;Duwm1728ExportRecovery.Entry retained=null;boolean preserveCompleted=false;
            try {
                produced=Duwm1728OverlayRenderer.export(app,original,selected);
                if(selected.cancelled.get())throw new InterruptedException("Export cancelled");
                final String savedInfo=Duwm1728ExportPreflight.savedDetails(produced);
                // Finalization first secures a durable local copy. Once it starts, complete
                // that save even if this Activity is destroyed, then report Gallery's outcome.
                synchronized(exportPublishLock){
                    if(selected.cancelled.get())throw new InterruptedException("Export cancelled");
                    finalizingExport=true;preserveCompleted=true;
                }
                main.post(()->{if(!destroyed&&exportSpec==selected){exportProgress.setIndeterminate(true);state.setText("SECURING LOCAL COPY…");updateExportState();}});
                final String name="DUWM_BROADCAST_"+System.currentTimeMillis()+".mp4";
                retained=Duwm1728ExportRecovery.retain(app,produced,original,name);
                main.post(()->{if(!destroyed&&exportSpec==selected)state.setText("SAVING TO GALLERY…");});
                // The recovery core stores the published receipt, Gallery index and
                // success-only LAST EXPORT shortcut before cleaning its local copy.
                final Uri out=Duwm1728ExportRecovery.publish(app,retained.id);
                final boolean automaticReceiptSaved=!automatic||automaticReceipt(app,automaticReceiptKey,automaticSourceKey,automaticSuccess,captionOutcome,out);
                main.post(()->{
                    if(destroyed)return;
                    finishExportUi(selected);lastBroadcast=out;lastBroadcastName=name;
                    if(automatic){automaticStatus=automaticSuccess;state.setText(selected.automaticCaptions.isEmpty()?
                            "VIDEO READY • saved to Gallery • "+(captionOutcome.startsWith("NO WORDS RETURNED")?"no words returned":"automatic captions unavailable"):
                            "VIDEO READY • saved to Gallery • "+selected.automaticCaptions.size()+" captions • "+selected.automaticTickers.size()+" source excerpts");}
                    else state.setText("BROADCAST SAVED  •  REVIEW OR SHARE");state.setTextColor(GREEN);updateExportState();loadPendingRecovery();
                    if(!automaticReceiptSaved)state.append("\nStatus receipt was not retained; the saved video is available.");
                    if(!automatic)new AlertDialog.Builder(this).setTitle("Broadcast saved")
                        .setMessage(savedInfo+"\n\nReview the finished MP4 before sharing. Your original recording is separate.")
                        .setNegativeButton("CLOSE",null)
                        .setNeutralButton("SHARE",(d,w)->Duwm1728BroadcastReviewActivity.share(this,out))
                        .setPositiveButton("REVIEW",(d,w)->openSavedBroadcast(out)).show();
                });
            }catch(Exception error){
                final boolean cancelled=!finalizingExport&&(error instanceof InterruptedException||selected.cancelled.get());
                final boolean localSaveFailed=preserveCompleted&&retained==null;
                Duwm1728ExportRecovery.Entry recovered=retained;boolean uncertain=error instanceof Duwm1728ExportRecovery.UnconfirmedException;
                Uri returnedGallery=null;
                if(error instanceof Duwm1728ExportRecovery.UnconfirmedException){
                    Duwm1728ExportRecovery.UnconfirmedException unconfirmed=(Duwm1728ExportRecovery.UnconfirmedException)error;
                    if(unconfirmed.entry!=null)recovered=unconfirmed.entry;returnedGallery=unconfirmed.publishedUri;
                }
                if(recovered!=null)try{Duwm1728ExportRecovery.Entry current=Duwm1728ExportRecovery.find(app,recovered.id);
                    if(current!=null)recovered=current;else uncertain=true;
                }catch(Exception unavailable){uncertain=true;}
                final Duwm1728ExportRecovery.Entry copy=recovered;
                final String failure=error.getMessage()==null?error.getClass().getSimpleName():error.getMessage();
                if(automatic)automaticReceipt(app,automaticReceiptKey,automaticSourceKey,cancelled?"CANCELLED":"FAILED",captionOutcome,returnedGallery);
                final String outcome=copy==null?"":returnedGallery!=null?"GALLERY SAVED • RECEIPT UNCONFIRMED":
                    error instanceof Duwm1728ExportRecovery.BusyException||copy.state==Duwm1728ExportRecovery.State.PUBLISHING?"GALLERY SAVE IN PROGRESS":
                    uncertain||copy.state==Duwm1728ExportRecovery.State.UNCONFIRMED?"GALLERY SAVE UNCONFIRMED":
                    copy.hasLocalCopy?"LOCAL COPY • NOT IN GALLERY":"LOCAL COPY UNAVAILABLE";
                main.post(()->{
                    if(destroyed)return;finishExportUi(selected);if(automatic)automaticStatus=cancelled?"CANCELLED":"FAILED";
                    state.setText(cancelled?"EXPORT CANCELLED • draft retained":copy!=null?outcome:localSaveFailed?"LOCAL SAVE FAILED":"EXPORT FAILED • draft retained");
                    state.setTextColor(cancelled?SILVER:0xFFFFB300);updateExportState();
                    if(copy!=null){
                        pendingRecovery=copy;recoveryLoadError="";updateRecoveryUi();recoveryStatus.setText(outcome);
                        String explanation=outcome.equals("LOCAL COPY • NOT IN GALLERY")
                            ?"The finished MP4 is kept on this device. Review the copy, or open Recovery to try saving it to Gallery again."
                            :outcome.equals("GALLERY SAVED • RECEIPT UNCONFIRMED")
                            ?"Gallery returned a saved video, but its receipt could not be secured. The local copy is kept. Open Recovery to check the outcome before retrying."
                            :"The Gallery outcome is not confirmed. Open Recovery to check its status before retrying. A retry may create a duplicate.";
                        AlertDialog.Builder dialog=new AlertDialog.Builder(this).setTitle(outcome)
                            .setMessage(explanation+"\n\n"+failure+"\n\nYour original recording is separate.")
                            .setNegativeButton("CLOSE",null).setNeutralButton("RECOVERY",(d,w)->openRecovery(copy.id));
                        if(copy.hasLocalCopy)dialog.setPositiveButton("REVIEW COPY",(d,w)->openSavedBroadcast(copy.uri));dialog.show();
                    }else if(!cancelled)new AlertDialog.Builder(this).setTitle(localSaveFailed?"Local save failed":"Export failed")
                        .setMessage((localSaveFailed?"The completed MP4 could not be secured as a recovery copy. Its temporary file has been kept, but it is not a confirmed saved broadcast.\n\n":"")+failure+"\n\nYour original recording and draft remain available.")
                        .setPositiveButton("CLOSE",null).show();
                    loadPendingRecovery();
                });
            }finally{
                // retain() copies, never adopts this cache file. Delete the duplicate only
                // after a durable recovery copy exists; a local-save failure keeps it.
                if(produced!=null&&(!preserveCompleted||retained!=null))produced.delete();
            }
        },"duwm-broadcast-export").start();
    }
    private void finishExportUi(Duwm1728OverlayRenderer.Spec selected){
        if(exportSpec!=selected)return;busy=false;exportSpec=null;finalizingExport=false;
        if(automaticExport){autoProducing=false;autoAwaitingOutput=false;automaticExport=false;}
        exportProgress.setIndeterminate(false);getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
    private void cancelExport(){
        if(autoProducing&&!busy){automaticGeneration++;autoProducing=false;autoAwaitingOutput=false;automaticStatus="CANCELLED";
            if(recordedAudioTranscriber!=null){recordedAudioTranscriber.close();recordedAudioTranscriber=null;}
            automaticReceipt(this,automaticKey(),Duwm1728CaptureTelemetry.storageKey(source),automaticStatus,automaticCaptionStatus,null);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);state.setText("AUTOMATIC EDIT CANCELLED • original retained");updateExportState();return;}
        synchronized(exportPublishLock){
            if(!busy||exportSpec==null)return;
            if(finalizingExport){notice("Finishing the export save");return;}
            exportSpec.cancelled.set(true);
        }
        state.setText("CANCELLING EXPORT…");state.setTextColor(SILVER);updateExportState();
    }
    private void loadLastExport(){
        if(source==null)return;
        try{String raw=getSharedPreferences(SAVED_BROADCASTS,MODE_PRIVATE).getString(Duwm1728CaptureTelemetry.storageKey(source),"");
            if(raw.isEmpty())return;JSONObject entry=new JSONObject(raw);Uri saved=Uri.parse(entry.getString("uri"));
            if("content".equals(saved.getScheme())&&!saved.equals(source)){lastBroadcast=saved;lastBroadcastName=entry.optString("name","Saved broadcast");}
        }catch(Exception ignored){}
    }
    private void loadPendingRecovery(){
        if(destroyed||source==null||pendingRecoveryRow==null)return;
        final int generation=++recoveryGeneration;final Uri original=source;final Context app=getApplicationContext();
        recoveryWorker.execute(()->{
            Duwm1728ExportRecovery.Entry newest=null;String failure="";
            try{for(Duwm1728ExportRecovery.Entry entry:Duwm1728ExportRecovery.list(app))
                if(original.equals(entry.sourceUri)&&entry.state!=Duwm1728ExportRecovery.State.PUBLISHED&&
                        (newest==null||entry.createdAt>newest.createdAt))newest=entry;
            }catch(Exception error){failure=error.getMessage()==null?error.getClass().getSimpleName():error.getMessage();}
            final Duwm1728ExportRecovery.Entry result=newest;final String error=failure;
            main.post(()->{if(destroyed||generation!=recoveryGeneration)return;
                pendingRecovery=result;recoveryLoadError=error;loadLastExport();updateRecoveryUi();});
        });
    }
    private void updateRecoveryUi(){
        if(pendingRecoveryRow==null)return;
        pendingRecoveryRow.setVisibility(pendingRecovery==null&&recoveryLoadError.isEmpty()?View.GONE:View.VISIBLE);
        String status="RECOVERY CHECK FAILED";
        if(recoveryLoadError.isEmpty()&&pendingRecovery!=null){
            if(pendingRecovery.state==Duwm1728ExportRecovery.State.PUBLISHING)status="GALLERY SAVE IN PROGRESS";
            else if(pendingRecovery.state==Duwm1728ExportRecovery.State.UNCONFIRMED)
                status=pendingRecovery.publishedUri==null?"GALLERY SAVE UNCONFIRMED":"GALLERY SAVED • RECEIPT UNCONFIRMED";
            else status=pendingRecovery.hasLocalCopy?"LOCAL COPY • NOT IN GALLERY":"LOCAL COPY UNAVAILABLE";
        }
        recoveryStatus.setText(status);updateExportState();
    }
    private void openRecovery(String entryId){
        if(!compositionEditable())return;
        try{if(entryId==null)Duwm1728ExportRecoveryActivity.open(this);else Duwm1728ExportRecoveryActivity.open(this,entryId);}
        catch(Exception error){notice("Pending broadcasts could not be opened");}
    }
    private void reviewPendingCopy(){
        if(!compositionEditable()||pendingRecovery==null||!pendingRecovery.hasLocalCopy||!recoveryLoadError.isEmpty())return;
        openSavedBroadcast(pendingRecovery.uri);
    }
    private void openSavedBroadcast(Uri uri){try{Duwm1728BroadcastReviewActivity.open(this,uri);}catch(Exception error){notice("The saved broadcast could not be opened");}}
    private void showLastExport(){
        if(!compositionEditable()||lastBroadcast==null)return;final Uri saved=lastBroadcast;
        new AlertDialog.Builder(this).setTitle("Last saved broadcast").setMessage(lastBroadcastName)
            .setNegativeButton("CLOSE",null).setNeutralButton("SHARE",(d,w)->Duwm1728BroadcastReviewActivity.share(this,saved))
            .setPositiveButton("REVIEW",(d,w)->openSavedBroadcast(saved)).show();
    }
    private boolean saveDraft(){if(title==null||draftRestoreBlocked)return false;try{JSONObject j=new JSONObject();j.put("headline",title.getText());j.put("place",place.getText());j.put("summary",caption.getText());j.put("ticker",ticker.getText());j.put("subtitles",subtitles.getText());j.put("ratio",selectedRatio);j.put("category",selectedTemplate);j.put("from",from.getText());j.put("to",to.getText());
            j.put("frame_mode",frameMode);j.put("frame_x",frameX);j.put("frame_y",frameY);
            j.put("composition",Duwm1728BroadcastComposition.normalize(selectedComposition));
            j.put("provenance",provenanceLabel);j.put("aiEvidence",aiEvidence);j.put("tickerSpeed",tickerSpeed);j.put("ticker_origin_ms",tickerOriginMs);j.put("caption_origin_ms",captionOriginMs);j.put("caption_kind",captionKind);
            j.put("manual_caption_origin_set",manualCaptionOriginSet);
            j.put("capture_notes",captureNotes);j.put("capture_category",captureCategory);j.put("automatic_content_source",automaticContentSource);j.put("automatic_report_evidence",automaticReportEvidence);
            j.put("automatic_headline_start_ms",automaticHeadlineStart);j.put("automatic_headline_end_ms",automaticHeadlineEnd);
            j.put("automatic_headline_fit",automaticHeadlineFit);j.put("automatic_output_sizing",automaticOutputSizing);
            j.put("automatic_scene_titles",automaticSceneTitles);
            j.put("scene_capture",sceneCapture);j.put("scene_storage_error",sceneStorageError);
            JSONArray tickers=new JSONArray();for(Duwm1728BroadcastLayout.Cue c:automaticTickerCues){JSONObject item=new JSONObject();item.put("start_ms",c.startMs);item.put("end_ms",c.endMs);item.put("text",c.text);tickers.put(item);}j.put("automatic_tickers",tickers);
            JSONArray cues=new JSONArray();for(Duwm1728BroadcastLayout.Cue c:aiCaptions){JSONObject cue=new JSONObject();cue.put("start_ms",c.startMs);cue.put("end_ms",c.endMs);cue.put("text",c.text);cues.put(cue);}j.put("automatic_captions",cues);getSharedPreferences("duwm_production_drafts",MODE_PRIVATE).edit().putString(Duwm1728CaptureTelemetry.storageKey(source),j.toString()).apply();return true;}catch(Exception failed){notice("Draft could not be saved: "+failed.getMessage());return false;}}
    private List<Duwm1728BroadcastLayout.Cue> draftCaptions(JSONObject draft)throws Exception{
        return draftCueArray(draft,"automatic_captions");
    }
    private List<Duwm1728BroadcastLayout.Cue> draftCueArray(JSONObject draft,String field)throws Exception{
        JSONArray captions=draft.optJSONArray(field);ArrayList<Duwm1728BroadcastLayout.Cue> restored=new ArrayList<>();
        if(captions==null){if(draft.has(field)&&!draft.isNull(field))throw new IllegalArgumentException("Saved "+field+" is not a cue array");return Collections.emptyList();}
        if(captions.length()>Duwm1728CaptionEditPolicy.MAX_CUES)throw new IllegalArgumentException("Saved caption count exceeds 20000; nothing was dropped");
        for(int i=0;i<captions.length();i++){
            JSONObject cue=captions.getJSONObject(i);long start=draftCaptionTime(cue,"start_ms"),end=draftCaptionTime(cue,"end_ms");
            restored.add(Duwm1728CaptionEditPolicy.cue(Duwm1728CaptionEditPolicy.formatTime(start),Duwm1728CaptionEditPolicy.formatTime(end),cue.getString("text"),durationMs));
        }
        return Duwm1728CaptionEditPolicy.copyAndValidate(restored,durationMs);
    }
    private long draftCaptionTime(JSONObject cue,String key)throws Exception{
        Object value=cue.get(key);String text=String.valueOf(value);
        if(!(value instanceof Number)||!text.matches("[0-9]+"))throw new IllegalArgumentException("Saved caption timestamps must be exact nonnegative milliseconds");
        return Long.parseLong(text);
    }
    private long draftHeadlineTime(JSONObject draft,String key)throws Exception{
        if(!draft.has(key))return -1;
        Object value=draft.get(key);String text=String.valueOf(value);
        if(!(value instanceof Number)||!text.matches("-1|[0-9]+"))throw new IllegalArgumentException("Saved headline timestamps must be exact milliseconds or -1");
        return Long.parseLong(text);
    }
    private boolean draftBoolean(JSONObject draft,String key)throws Exception{
        if(!draft.has(key))return false;
        Object value=draft.get(key);if(!(value instanceof Boolean))throw new IllegalArgumentException("Saved "+key+" must be a boolean");
        return (Boolean)value;
    }
    private void loadDraft(){
        try{
            String raw=getSharedPreferences("duwm_production_drafts",MODE_PRIVATE).getString(Duwm1728CaptureTelemetry.storageKey(source),"");
            if(raw.isEmpty())return;JSONObject j=new JSONObject(raw);
            // Validate report metadata before deciding whether caption-only
            // replacement can recover this draft. Never save partially decoded data.
            List<Duwm1728BroadcastLayout.Cue> restoredTickers=draftCueArray(j,"automatic_tickers");
            long restoredHeadlineStart=draftHeadlineTime(j,"automatic_headline_start_ms"),restoredHeadlineEnd=draftHeadlineTime(j,"automatic_headline_end_ms");
            if(!(restoredHeadlineStart==-1&&restoredHeadlineEnd==-1)&&(restoredHeadlineStart<0||restoredHeadlineEnd<=restoredHeadlineStart||restoredHeadlineEnd>durationMs))
                throw new IllegalArgumentException("Saved headline source range is invalid");
            String restoredContentSource=j.optString("automatic_content_source","NEUTRAL");
            if(!Arrays.asList("RECORDED_SPEECH","CAPTURE_NOTES","NEUTRAL").contains(restoredContentSource))throw new IllegalArgumentException("Saved automatic report source is invalid");
            boolean restoredHeadlineFit=draftBoolean(j,"automatic_headline_fit"),restoredOutputSizing=draftBoolean(j,"automatic_output_sizing");
            boolean restoredSceneTitles=draftBoolean(j,"automatic_scene_titles");
            boolean restoredSceneCapture=draftBoolean(j,"scene_capture"),restoredSceneStorageError=draftBoolean(j,"scene_storage_error");
            if(restoredOutputSizing&&(!"ORIGINAL".equals(j.optString("ratio"))||!Duwm1728FramePlan.FIT.equals(j.optString("frame_mode"))))
                throw new IllegalArgumentException("Saved automatic output must retain the full original picture");
            if(restoredOutputSizing){
                Object savedX=j.get("frame_x"),savedY=j.get("frame_y");
                if(!(savedX instanceof Number)||!(savedY instanceof Number))throw new IllegalArgumentException("Saved automatic framing anchors must be numbers");
                Duwm1728FramePlan.validate(Duwm1728FramePlan.FIT,((Number)savedX).floatValue(),((Number)savedY).floatValue());
            }
            List<Duwm1728BroadcastLayout.Cue> restored=Collections.emptyList();String captionFailure="";
            try{restored=draftCaptions(j);}catch(Exception invalid){captionFailure=String.valueOf(invalid.getMessage());}
            updatingFields=true;
            selectedComposition=Duwm1728BroadcastComposition.normalize(j.optString("composition",Duwm1728BroadcastComposition.FULL));
            title.setText(j.optString("headline"));place.setText(j.optString("place"));caption.setText(j.optString("summary"));ticker.setText(j.optString("ticker"));subtitles.setText(j.optString("subtitles"));
            String ratio=j.optString("ratio",selectedRatio);if(Arrays.asList("9:10","9:16","16:9","ORIGINAL").contains(ratio))selectedRatio=ratio;
            // /11 draft variants used different key names; keep their framing intent.
            String mode=j.optString("frame_mode",j.optString("framing_mode",j.optString("framing",Duwm1728FramePlan.FILL)));
            float ax=(float)j.optDouble("frame_x",j.optDouble("framing_x",.5)),ay=(float)j.optDouble("frame_y",j.optDouble("framing_y",.5));
            try{Duwm1728FramePlan.validate(mode,ax,ay);frameMode=mode;frameX=ax;frameY=ay;}catch(IllegalArgumentException invalid){frameMode=Duwm1728FramePlan.FILL;frameX=frameY=.5f;}
            selectedTemplate=Math.max(0,Math.min(templates.length-1,j.optInt("category")));from.setText(j.optString("from","0"));to.setText(j.optString("to",to.getText().toString()));
            tickerSpeed=Math.max(20,Math.min(180,j.optInt("tickerSpeed",75)));
            tickerOriginMs=Math.max(0,j.optLong("ticker_origin_ms",ms(from)));captionOriginMs=Math.max(0,j.optLong("caption_origin_ms",ms(from)));
            manualCaptionOriginSet=j.optBoolean("manual_caption_origin_set",!subtitles.getText().toString().trim().isEmpty());
            captionKind=j.optString("caption_kind","Restored captions");
            provenanceLabel=j.optString("provenance","REPORTER ACCOUNT • UNVERIFIED");aiEvidence=j.optString("aiEvidence",aiEvidence);aiEvidenceView.setText(aiEvidence);
            captureNotes=j.optString("capture_notes",captureNotes);captureCategory=j.optString("capture_category",captureCategory);
            automaticTickerCues=restoredTickers;automaticContentSource=restoredContentSource;automaticReportEvidence=j.optString("automatic_report_evidence","");
            automaticHeadlineStart=restoredHeadlineStart;automaticHeadlineEnd=restoredHeadlineEnd;
            automaticHeadlineFit=restoredHeadlineFit;automaticOutputSizing=restoredOutputSizing;
            sceneCapture=sceneCapture||restoredSceneCapture;sceneStorageError=sceneStorageError||restoredSceneStorageError;
            if(sceneStorageError)sceneTrack=Collections.emptyList();
            selectSceneTitles(restoredSceneTitles);
            aiCaptions=restored;draftRestoreBlocked=!captionFailure.isEmpty();draftCaptionRecoveryAllowed=draftRestoreBlocked;
            templateButton.setText("CATEGORY: "+templates[selectedTemplate]);ratioButton.setText(selectedRatio);
            // Approval is deliberately not persisted. Reopened drafts require a fresh review.
            approval.setChecked(false);
            if(draftRestoreBlocked)notice("Saved captions kept unchanged: "+captionFailure+". Other saved report details were restored; apply or import a reviewed caption replacement.");
        }catch(Exception e){draftRestoreBlocked=true;draftCaptionRecoveryAllowed=false;notice("Saved draft kept unchanged: "+e.getMessage());}finally{updatingFields=false;}
    }
    private void dictateCaption(){
        if(!compositionEditable()){notice("Finish the current operation before dictating a caption");return;}
        if(!aiCaptions.isEmpty()){notice("Use CAPTIONS to add a cue without replacing imported captions");return;}
        try{
            Intent intent=new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT,"Speak a caption for manual review");
            startActivityForResult(intent,CAPTION_DICTATION_REQUEST);
        }catch(android.content.ActivityNotFoundException e){notice("No speech recognition app on this phone");}
    }
    private void transcribeRecordedAudio(){
        if(!compositionEditable()){notice("Editor is busy");return;}
        if(!Duwm1728RecordedAudioTranscriber.canAttempt(this)){
            notice("This device has no compatible on-device recorded-audio recognizer. Import SRT captions instead.");return;
        }
        long fromMs,toMs;
        try{fromMs=ms(from);
            toMs=ms(to);
            if(fromMs<0||toMs<=fromMs||toMs-fromMs>45000)throw new IllegalArgumentException();
        }catch(Exception ex){notice("On-device recognition accepts up to 45 seconds per request. Export itself has no 45-second cap.");return;}
        new AlertDialog.Builder(this).setTitle("Transcribe the actual video soundtrack?")
            .setMessage("Uses the phone's on-device recognition service and decoded recorded audio. Some devices do not support audio injection or word timestamps. Never accept subtitles without reviewing them. No camera microphone fallback is requested by DUWM.")
            .setNegativeButton("CANCEL",null).setPositiveButton("START",(d,w)->{
                if(!compositionEditable())return;
                recordedAudioTranscriber=new Duwm1728RecordedAudioTranscriber(this);
                updateExportState();
                notice("Attempting on-device recorded-audio recognition");
                recordedAudioTranscriber.transcribe(source,fromMs,toMs,new Duwm1728RecordedAudioTranscriber.Listener(){
                    @Override public void error(String message){recordedAudioTranscriber=null;if(!destroyed){updateExportState();notice(message);}}
                    @Override public void done(Duwm1728RecordedAudioTranscriber.Result result){
                        recordedAudioTranscriber=null;if(destroyed)return;updateExportState();
                        if(result.completedWithoutWords){notice("Recorded-audio recognition completed and returned no words. Current captions are unchanged.");return;}
                        final TextView review=label(result.text,13);review.setTextIsSelectable(true);
                        ScrollView transcript=new ScrollView(Duwm1728VideoEditorActivity.this);transcript.setBackgroundColor(NAVY);transcript.addView(review);
                        String explanation=result.hasVerifiedWordTimes
                            ?"Word starts were reported by the on-device recognizer. Cue ends are derived and bounded to the source clip. Import replaces the current captions; CAPTIONS can edit the result."
                            :"The recognizer did NOT return reliable word timestamps. Transcript text only: use manual caption times or import SRT.";
                        new AlertDialog.Builder(Duwm1728VideoEditorActivity.this)
                            .setTitle("Review recorded-audio transcript")
                            .setMessage(explanation+(result.selectedLanguage.isEmpty()?"":"\nSpeech model: "+result.selectedLanguage)).setView(transcript).setNegativeButton("DISCARD",null)
                            .setPositiveButton(result.hasVerifiedWordTimes?"IMPORT TIMED CAPTIONS":"COPY TEXT",(dialog,which)->{
                                if(result.hasVerifiedWordTimes){try{if(!compositionEditable())return;
                                    replaceAppliedCaptions(result.cues,"Recorded-audio captions • word starts reported, ends derived");
                                }catch(IllegalArgumentException ex){notice("Correct subtitle time codes: "+ex.getMessage());}}
                                if(!result.hasVerifiedWordTimes){android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
                                    cm.setPrimaryClip(android.content.ClipData.newPlainText("DUWM transcript for manual timing",review.getText().toString()));}
                            }).show();
                    }
                });
            }).show();
    }
    private void choosePipVideo(){
        if(!compositionEditable())return;
        Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("video/*");
        startActivityForResult(pick,PIP_VIDEO_REQUEST);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(captionFiles!=null&&captionFiles.onActivityResult(request,result,data))return;
        if(result!=RESULT_OK||data==null)return;
        if(!compositionEditable()){notice("Finish the current operation before importing changes");return;}
        if(request==PIP_VIDEO_REQUEST){
            Uri selected=data.getData();if(selected==null)return;
            try{getContentResolver().takePersistableUriPermission(selected,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(SecurityException ignored){}
            if(selected.equals(source)){notice("Choose a different video for the inset");return;}
            pipVideo=selected;loadInset(selected);pipSelection.setText("SECOND VIDEO SELECTED / MUTED");approval.setChecked(false);refresh();return;
        }
        if(request!=CAPTION_DICTATION_REQUEST)return;
        java.util.ArrayList<String> phrases=data.getStringArrayListExtra(
            android.speech.RecognizerIntent.EXTRA_RESULTS);
        if(phrases==null||phrases.isEmpty())return;
        String guess=phrases.get(0).replaceAll("[\\r\\n;=]+"," ").trim();
        if(guess.length()>180)guess=guess.substring(0,180);
        long now=!prepared?0:Math.max(0,player.getCurrentPosition());
        if(!aiCaptions.isEmpty()){notice("Use CAPTIONS to add a cue without replacing imported captions");return;}
        long start=captionOriginMs;if(!manualCaptionOriginSet)try{start=ms(from);}catch(Exception ignored){}
        final long dictationOrigin=start;
        long clipMs=Math.max(0,now-start);String cue=String.format(java.util.Locale.US,
            "%02d:%02d=%s",clipMs/60000,(clipMs/1000)%60,guess);
        final String candidate=(subtitles.getText().toString().trim().isEmpty()?"":
            subtitles.getText().toString().trim()+";")+cue;
        new AlertDialog.Builder(this).setTitle("Review dictated words")
          .setMessage("Recognized microphone speech, NOT source-video transcription:\n\n"+guess+
              "\n\nAt video time "+(clipMs/1000)+" seconds. Edit the resulting caption if needed.")
          .setNegativeButton("DISCARD",null).setPositiveButton("ADD CAPTION",(d,w)->importLegacyCaptions(candidate,dictationOrigin,"Dictated captions — manually timed")).show();
    }

    private void importLegacyCaptions(String text,long origin,String kind){
        if(!compositionEditable()){notice("Finish the current operation before importing captions");return;}
        // Explicit reviewed imports may replace a caption set, unlike typing in
        // the disabled legacy field. Validate before asking to replace anything.
        try{Duwm1728CaptionEditPolicy.fromLegacy(Duwm1728TickerTimeline.parse(text),origin,durationMs);}
        catch(IllegalArgumentException invalid){notice("Caption import: "+invalid.getMessage());return;}
        Runnable apply=()->{if(!compositionEditable())return;updatingFields=true;
            try{aiCaptions=Collections.emptyList();subtitles.setText(text);captionOriginMs=origin;manualCaptionOriginSet=true;captionKind=kind;}
            finally{updatingFields=false;}approval.setChecked(false);refresh();saveDraft();};
        if(aiCaptions.isEmpty())apply.run();
        else new AlertDialog.Builder(this).setTitle("Replace all captions?")
            .setMessage("Import this reviewed transcript instead of the current "+aiCaptions.size()+" source-time cues? Use CAPTIONS to edit the existing cues without replacing them.")
            .setNegativeButton("KEEP CURRENT",null).setPositiveButton("REPLACE ALL",(d,w)->apply.run()).show();
    }

    private void notice(String text){Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
    @Override public void onBackPressed(){
        if(captionEditor!=null&&captionEditor.isPreviewing()){showCaptionEditor();return;}
        if(busy&&finalizingExport){notice("Finishing the export save. The result will appear here.");return;}
        if(busy||aiBusy||autoProducing){new AlertDialog.Builder(this).setTitle("Cancel production?").setMessage("The original recording and saved draft remain available.").setNegativeButton("KEEP WORKING",null).setPositiveButton("CANCEL",(d,w)->{
            synchronized(exportPublishLock){if(finalizingExport){notice("Finishing the export save");return;}if(exportSpec!=null)exportSpec.cancelled.set(true);}
            if(autoProducing&&!busy)cancelExport();
            if(aiClient!=null)aiClient.cancel();finish();
        }).show();}else super.onBackPressed();
    }
    @Override protected void onResume(){super.onResume();active=true;loadLastExport();loadPendingRecovery();updateExportState();requestPreviewUpdate(true);}
    @Override public void onConfigurationChanged(android.content.res.Configuration changed){super.onConfigurationChanged(changed);if(workspace!=null)workspace.requestLayout();}
    @Override protected void onPause(){active=false;pausePreview();saveDraft();super.onPause();}
    @Override protected void onSaveInstanceState(Bundle saved){if(captionFiles!=null)captionFiles.saveState(saved);super.onSaveInstanceState(saved);}
    @Override protected void onDestroy(){
        if(autoProducing&&!busy){automaticGeneration++;automaticReceipt(this,automaticKey(),Duwm1728CaptureTelemetry.storageKey(source),"INTERRUPTED",automaticCaptionStatus,null);}
        if(automaticHelpDialog!=null)automaticHelpDialog.dismiss();closeSpeechReadiness();
        destroyed=true;if(captionFiles!=null)captionFiles.close();if(captionEditor!=null)captionEditor.dismiss();captionPreviewSpec=null;if(detailsDialog!=null)detailsDialog.dismiss();if(layoutPicker!=null)layoutPicker.dismiss();main.removeCallbacks(clock);planGeneration++;if(planKick!=null)main.removeCallbacks(planKick);planWorker.shutdownNow();recoveryGeneration++;recoveryWorker.shutdownNow();synchronized(exportPublishLock){if(exportSpec!=null&&!finalizingExport)exportSpec.cancelled.set(true);}if(aiClient!=null)aiClient.cancel();if(recordedAudioTranscriber!=null)recordedAudioTranscriber.close();releasePlayer();insetGeneration++;insetWorker.execute(()->{if(insetRetriever!=null)try{insetRetriever.release();}catch(Exception ignored){}});insetWorker.shutdown();if(insetFrame!=null)insetFrame.recycle();super.onDestroy();}
}
