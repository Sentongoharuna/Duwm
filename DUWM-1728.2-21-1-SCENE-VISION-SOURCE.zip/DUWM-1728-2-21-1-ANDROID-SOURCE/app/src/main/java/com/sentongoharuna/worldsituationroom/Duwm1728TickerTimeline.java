package com.sentongoharuna.worldsituationroom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Reporter-authored timed updates. No automatic claim of fact or verified news. */
public final class Duwm1728TickerTimeline {
    private Duwm1728TickerTimeline() {}
    public static final class Cue {
        public final long atMs;
        public final String text;
        Cue(long at, String message) {atMs=at; text=message;}
    }
    public static List<Cue> parse(String raw) {
        if(raw==null || raw.trim().isEmpty()) return Collections.emptyList();
        ArrayList<Cue> result = new ArrayList<>();
        for(String part : raw.split("[;\\n]+")) {
            String line=part.trim(); if(line.isEmpty())continue;
            int equals=line.indexOf('=');
            if(equals<1)throw new IllegalArgumentException("Use MM:SS=message; MM:SS=message");
            String time=line.substring(0,equals).trim();
            String[] fields=time.split(":");
            if(fields.length!=2 || !fields[0].matches("[0-9]{1,3}") || !fields[1].matches("[0-5][0-9]"))
                throw new IllegalArgumentException("Use MM:SS=message");
            long ms=(Long.parseLong(fields[0])*60L+Long.parseLong(fields[1]))*1000L;
            String text=line.substring(equals+1).trim().replaceAll("[\\r\\t]+", " ");
            if(text.isEmpty() || text.length()>180)throw new IllegalArgumentException("Each ticker update must be 1–180 characters");
            for(Cue prior:result)if(prior.atMs==ms)throw new IllegalArgumentException("Duplicate ticker time");
            result.add(new Cue(ms,text));
            if(result.size()>12)throw new IllegalArgumentException("Maximum 12 timed updates per clip");
        }
        result.sort(Comparator.comparingLong(c->c.atMs));
        return Collections.unmodifiableList(result);
    }
    public static Cue active(List<Cue> cues,long relativeMs) {
        Cue selected=null;
        if(cues!=null)for(Cue cue:cues){if(cue.atMs<=relativeMs)selected=cue;else break;}
        return selected;
    }
    public static String at(List<Cue> cues,long relativeMs) {
        Cue active=active(cues,relativeMs);
        return active==null?"":active.text;
    }
    public static float offsetPixels(long relativeMs, float textWidth, float viewportWidth, float pixelsPerSecond){
        if(textWidth<=0||viewportWidth<=0||pixelsPerSecond<=0)return viewportWidth;
        float travel=viewportWidth+textWidth;
        // A full pass starts outside the right edge and ends outside the left edge.
        double position=((relativeMs/1000d)*pixelsPerSecond)%travel;
        return (float)(viewportWidth-position);
    }
}
