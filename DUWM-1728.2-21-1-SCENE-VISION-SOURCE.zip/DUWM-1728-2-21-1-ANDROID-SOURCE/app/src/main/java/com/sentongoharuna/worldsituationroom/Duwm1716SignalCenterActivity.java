package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.Locale;

/**
 * DUWM 1716 / one full-screen signal centre for all nineteen EXISTING desks.
 * READ ONLY: every count, receipt timestamp and source state comes from the
 * same existing provider receipts as the original desks. No simulated data,
 * artificial ticker, second globe, background poller or network request.
 */
public final class Duwm1716SignalCenterActivity extends Activity {
    public static final String EXTRA_SECTOR = "duwm1716.focusSector";
    private static final String[] FILTER_NAMES = {"ALL 19", "REVIEW", "RECENT", "LOCAL", "FOCUSED"};
    private final Duwm1683DeskCatalog.Desk[] desks=Duwm1683DeskCatalog.ALL;
    private LinearLayout cards, summary;
    private TextView heading, subheading;
    private String query="";
    private int filter=0;
    private int selected=-1;
    private final android.os.Handler liveUi=new android.os.Handler(android.os.Looper.getMainLooper());
    private boolean visiblePage;
    private ScrollView receiptScroll;
    private String observedKey="";
    private final Runnable liveRefresh=new Runnable(){@Override public void run(){
        if(!visiblePage||isFinishing())return;
        String key=currentReceiptKey();
        if(!key.equals(observedKey)){
            int y=receiptScroll==null?0:receiptScroll.getScrollY();
            render();observedKey=key;
            if(receiptScroll!=null)receiptScroll.post(()->receiptScroll.scrollTo(0,y));
        }
        liveUi.postDelayed(this,2000L);
    }};
    private String currentReceiptKey(){
        StringBuilder key=new StringBuilder();
        for(int i=0;i<desks.length;i++){
            Duwm1684DeskDiagnostics.Snapshot s=Duwm1684DeskDiagnostics.read(this,desks[i]);
            key.append(i).append(':').append(Duwm1715SignalLights.stageFor(this,i).name())
               .append(':').append(s.provider).append(':').append(s.received)
               .append(':').append(s.count).append(':').append(s.state).append(';');
        }
        return key.toString();
    }

    private int dp(float value) {return Math.max(1,Math.round(getResources().getDisplayMetrics().density*value));}
    private GradientDrawable border(int fill,int stroke) {
        GradientDrawable g=new GradientDrawable();
        g.setColor(fill);g.setCornerRadius(dp(DuwmUnifiedTheme.FORMAL_CORNER_DP));
        g.setStroke(dp(1),stroke);
        return g;
    }
    private TextView text(String label,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(label);t.setTextColor(color);t.setTextSize(size);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",Typeface.NORMAL));
        return t;
    }
    private LinearLayout.LayoutParams margin(int height,int top) {
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,height<0?height:dp(height));
        p.topMargin=dp(top);return p;
    }
    private TextView control(String label,Runnable action) {
        TextView c=text(label,11,DuwmUnifiedTheme.TEXT,true);
        c.setGravity(Gravity.CENTER);c.setSingleLine(true);
        c.setBackground(border(DuwmUnifiedTheme.APPROVED_NAVY,DuwmUnifiedTheme.BORDER));
        c.setContentDescription(label);c.setMinHeight(dp(46));
        c.setOnClickListener(v->action.run());return c;
    }
    private View pill(String label, boolean selected, Runnable action) {
        TextView t=control(label,action);
        t.setBackground(border(selected?DuwmUnifiedTheme.PANEL_SELECTED:DuwmUnifiedTheme.APPROVED_NAVY,
                selected?DuwmUnifiedTheme.ACCENT_BRIGHT:DuwmUnifiedTheme.DIVIDER));
        return t;
    }
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int index=getIntent().getIntExtra(EXTRA_SECTOR,-1);
        if(index>=0 && index<desks.length) {selected=index;filter=4;}
        getWindow().setStatusBarColor(DuwmUnifiedTheme.APPROVED_NAVY);
        getWindow().setNavigationBarColor(DuwmUnifiedTheme.APPROVED_NAVY);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(DuwmUnifiedTheme.APPROVED_NAVY);
        root.setPadding(dp(12),dp(7),dp(12),dp(7));
        heading=text("WORLD SIGNAL CENTRE  /  1728.2/7",19,DuwmUnifiedTheme.TEXT,true);
        root.addView(heading,margin(32,2));
        subheading=text("19 SOURCE SECTORS  /  ON-DEVICE RECEIPTS  /  NO SIMULATED EVENTS",10,DuwmUnifiedTheme.MUTED,false);
        root.addView(subheading,margin(27,1));
        EditText search=new EditText(this);
        search.setSingleLine(true);search.setTextSize(13);search.setHint("Search sectors, providers or state");
        search.setTextColor(DuwmUnifiedTheme.TEXT);search.setHintTextColor(DuwmUnifiedTheme.MUTED);
        search.setPadding(dp(14),0,dp(14),0);
        search.setBackground(border(DuwmUnifiedTheme.APPROVED_NAVY,DuwmUnifiedTheme.BORDER));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int start,int count,int after) {}
            public void onTextChanged(CharSequence s,int start,int before,int count) {
                query=s==null?"":s.toString().trim().toLowerCase(Locale.US);render();
            }
            public void afterTextChanged(Editable s) {}
        });
        root.addView(search,margin(46,8));
        HorizontalScrollView scroller=new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        LinearLayout chipRow=new LinearLayout(this);chipRow.setGravity(Gravity.CENTER_VERTICAL);
        for(int i=0;i<FILTER_NAMES.length;i++) {
            final int n=i;
            TextView chip=(TextView)pill(FILTER_NAMES[i],filter==i,()->{
                filter=n;if(n==4 && selected<0)selected=0;
                updateFilters();render();
            });
            chip.setTag("filter-"+i);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(i==0?84:103),dp(43));
            p.rightMargin=dp(6);chipRow.addView(chip,p);
        }
        scroller.addView(chipRow);root.addView(scroller,margin(45,6));
        // True counts come from cached provider receipt diagnostics, never from a mock generator.
        summary=new LinearLayout(this);summary.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(summary,margin(61,8));
        TextView guidance=text("SOURCE HEALTH: RED WORST → GREEN BEST  •  GREY = NO DATA  •  SILVER = LOCAL TOOL",9,DuwmUnifiedTheme.MUTED,false);
        root.addView(guidance,margin(24,4));
        // Six-stage severity / information-flow legend. Real source callbacks,
        // not fixed per-sector colours, determine the current light.
        HorizontalScrollView legendScroll=new HorizontalScrollView(this);
        legendScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout legend=new LinearLayout(this);legend.setOrientation(LinearLayout.HORIZONTAL);
        legend.setGravity(Gravity.CENTER_VERTICAL);
        for(Duwm1724SignalFlow.Stage stage:new Duwm1724SignalFlow.Stage[]{
                Duwm1724SignalFlow.Stage.OUTAGE,Duwm1724SignalFlow.Stage.DEGRADED,
                Duwm1724SignalFlow.Stage.AGED,Duwm1724SignalFlow.Stage.CONNECTING,
                Duwm1724SignalFlow.Stage.RECEIVING,Duwm1724SignalFlow.Stage.HEALTHY,
                Duwm1724SignalFlow.Stage.UNKNOWN,Duwm1724SignalFlow.Stage.LOCAL}) {
            LinearLayout chip=new LinearLayout(this);chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);chip.setPadding(dp(7),0,dp(9),0);
            View dot=Duwm1715SignalLights.indicator(this,stage.color,stage.label,9);
            chip.addView(dot,new LinearLayout.LayoutParams(dp(9),dp(9)));
            TextView caption=text(" "+stage.label,9,DuwmUnifiedTheme.TEXT,true);
            chip.addView(caption,new LinearLayout.LayoutParams(-2,dp(28)));
            legend.addView(chip);
        }
        legendScroll.addView(legend);
        root.addView(legendScroll,margin(30,1));
        TextView audit=control("AUDIT HISTORY / 1717  •  Compare saved, actual receipt states",
            ()->startActivity(new Intent(this,Duwm1717ReceiptAuditActivity.class)));
        root.addView(audit,margin(45,6));
        root.addView(control("WORLDWIDE PLACES  /  Follow any city on Earth",
            ()->startActivity(new Intent(this,Duwm1718GlobalDiscoverActivity.class))),margin(45,6));
        ScrollView scroll=new ScrollView(this);receiptScroll=scroll;scroll.setFillViewport(true);
        cards=new LinearLayout(this);cards.setOrientation(LinearLayout.VERTICAL);
        cards.setPadding(0,dp(2),0,dp(18));
        scroll.addView(cards);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));
        LinearLayout controls=new LinearLayout(this);
        for (String item : new String[]{"GLOBE","OPS MATRIX","19 DESKS","REREAD"}) {
            Runnable click;
            if(item.equals("GLOBE")) click=()->{
                Intent g=new Intent(this,MainActivity.class);
                g.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(g);finish();
            };
            else if(item.equals("OPS MATRIX")) click=()->startActivity(new Intent(this,Duwm1712OperationsMatrixActivity.class));
            else if(item.equals("19 DESKS")) click=()->startActivity(new Intent(this,DuwmOptionsActivity.class));
            else click=this::render;
            TextView button=control(item,click);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(47),1f);
            p.rightMargin=dp(4);controls.addView(button,p);
        }
        root.addView(controls,margin(49,5));
        setContentView(root);render();
    }
    @Override protected void onResume(){super.onResume();visiblePage=true;if(cards!=null)render();
        liveUi.removeCallbacks(liveRefresh);liveUi.post(liveRefresh);}
    @Override protected void onPause(){visiblePage=false;liveUi.removeCallbacks(liveRefresh);super.onPause();}
    @Override protected void onDestroy(){visiblePage=false;liveUi.removeCallbacks(liveRefresh);super.onDestroy();}
    private void updateFilters(){
        View content=findViewById(android.R.id.content);
        if(content==null)return;
        for(int i=0;i<FILTER_NAMES.length;i++){
            // Filter controls are owned by the single full-screen page, never the globe.
            View v=content.findViewWithTag("filter-"+i);
            if(v!=null)v.setBackground(border(i==filter?DuwmUnifiedTheme.PANEL_SELECTED:
                DuwmUnifiedTheme.APPROVED_NAVY,i==filter?DuwmUnifiedTheme.ACCENT_BRIGHT:DuwmUnifiedTheme.DIVIDER));
        }
    }
    private boolean review(int color){return color==Duwm1724SignalFlow.Stage.OUTAGE.color ||
        color==Duwm1724SignalFlow.Stage.DEGRADED.color ||
        color==Duwm1724SignalFlow.Stage.AGED.color;}
    private boolean visible(int index,Duwm1684DeskDiagnostics.Snapshot s,int color){
        if(filter==1 && !review(color)) return false;
        if(filter==2 && color!=Duwm1724SignalFlow.Stage.HEALTHY.color && color!=Duwm1724SignalFlow.Stage.RECEIVING.color)return false;
        if(filter==3 && color!=Duwm1724SignalFlow.Stage.LOCAL.color)return false;
        if(filter==4 && index!=selected)return false;
        String find=(desks[index].title+" "+desks[index].subtitle+" "+desks[index].category+" "+
                s.provider+" "+s.state+" "+s.coverage).toLowerCase(Locale.US);
        return query.isEmpty()||find.contains(query);
    }
    private void summaryTile(String title,int number,int color){
        LinearLayout tile=new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);tile.setPadding(dp(8),dp(3),dp(4),dp(3));
        tile.setBackground(border(DuwmUnifiedTheme.APPROVED_NAVY,DuwmUnifiedTheme.DIVIDER));
        TextView figure=text(String.valueOf(number),21,color,true);
        TextView label=text(title,9,DuwmUnifiedTheme.MUTED,false);
        tile.addView(figure,new LinearLayout.LayoutParams(-1,dp(30)));
        tile.addView(label,new LinearLayout.LayoutParams(-1,dp(18)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(58),1f);
        p.rightMargin=dp(5);summary.addView(tile,p);
    }
    private void putText(LinearLayout box,String value,int size,int color,boolean bold,int height){
        TextView t=text(value,size,color,bold);
        t.setMaxLines(2);t.setEllipsize(TextUtils.TruncateAt.END);
        box.addView(t,new LinearLayout.LayoutParams(-1,dp(height)));
    }
    private void addCard(int index,Duwm1684DeskDiagnostics.Snapshot s,int color){
        final Duwm1683DeskCatalog.Desk d=desks[index];
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12),dp(10),dp(12),dp(10));
        card.setBackground(border(DuwmUnifiedTheme.APPROVED_NAVY,
                index==selected?DuwmUnifiedTheme.TEXT:DuwmUnifiedTheme.DIVIDER));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        View led=Duwm1715SignalLights.sectorLamp(this,index,14);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(14),dp(14));
        lp.rightMargin=dp(10);top.addView(led,lp);
        TextView name=text(String.format(Locale.US,"%02d  %s",index+1,d.title),15,DuwmUnifiedTheme.TEXT,true);
        name.setSingleLine(true);name.setEllipsize(TextUtils.TruncateAt.END);
        top.addView(name,new LinearLayout.LayoutParams(0,dp(29),1f));
        Duwm1724SignalFlow.Stage stage=Duwm1715SignalLights.stageFor(this,index);
        TextView state=text(stage.label,10,color,true);
        ((Duwm1728StatusLampView)led).bindLabel(state);
        state.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);state.setMaxLines(2);
        top.addView(state,new LinearLayout.LayoutParams(dp(109),dp(32)));
        card.addView(top,new LinearLayout.LayoutParams(-1,dp(35)));
        View divider=new View(this);divider.setBackgroundColor(Duwm1709SectorOutline.color(index));
        card.addView(divider,margin(1,2));
        putText(card,d.category.toUpperCase(Locale.US)+"  /  "+s.count,11,DuwmUnifiedTheme.MUTED,true,27);
        putText(card,"PROVIDER   "+s.provider,11,DuwmUnifiedTheme.TEXT,false,25);
        putText(card,"RECEIVED   "+s.received,10,DuwmUnifiedTheme.MUTED,false,29);
        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER_VERTICAL);
        TextView open=control("OPEN DESK",()->startActivity(Duwm1683DeskCatalog.intent(this,d)));
        TextView evidence=control("SOURCE DETAILS",()->new AlertDialog.Builder(this)
                .setTitle(d.title+" / receipt evidence")
                .setMessage(s.report()+"\n\nFLOW STAGE  "+stage.label+
                    "\nACTUAL ON-DEVICE STATE HISTORY\n"+Duwm1724SignalHistory.read(this,index)+
                    "\n"+d.howToRead)
                .setPositiveButton("CLOSE",(dialog,which)->dialog.dismiss()).show());
        TextView share=control("SHARE STATUS",()->{
            Intent intent=new Intent(Intent.ACTION_SEND);intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT,"DUWM 1716 / on-device source receipt\n"+
                    d.title+"\n"+s.report()+"\nSource state is local to the reviewing device; no unverified live assertion.");
            startActivity(Intent.createChooser(intent,"Share recorded source status"));
        });
        for(TextView b:new TextView[]{open,evidence,share}){
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(45),1f);
            p.rightMargin=dp(5);actions.addView(b,p);
        }
        // The history contains only actual on-device stage transitions, never decorative samples.
        LinearLayout trace=new LinearLayout(this);trace.setGravity(Gravity.CENTER_VERTICAL);
        TextView trendTitle=text("OBSERVED STATUS CHANGES",9,DuwmUnifiedTheme.MUTED,true);
        trace.addView(trendTitle,new LinearLayout.LayoutParams(0,dp(29),2f));
        Duwm1724SignalFlow.Stage[] observed=Duwm1724SignalHistory.stages(this,index);
        if(observed.length==0){
            TextView none=text("NO HISTORY",9,DuwmUnifiedTheme.UNAVAILABLE,false);
            none.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            trace.addView(none,new LinearLayout.LayoutParams(0,dp(27),3f));
        }else{
            for(int k=observed.length-1;k>=0;k--){
                View dot=Duwm1715SignalLights.indicator(this,observed[k].color,observed[k].label,10);
                LinearLayout.LayoutParams ds=new LinearLayout.LayoutParams(dp(10),dp(10));
                ds.leftMargin=dp(5);trace.addView(dot,ds);
            }
        }
        card.addView(trace,margin(31,3));
        card.addView(actions,margin(45,7));
        LinearLayout.LayoutParams params=margin(-2,8);cards.addView(card,params);
    }
    private void render(){
        if(cards==null||summary==null)return;
        int[] counts=new int[5];
        Duwm1684DeskDiagnostics.Snapshot[] reports=new Duwm1684DeskDiagnostics.Snapshot[desks.length];
        int[] colors=new int[desks.length];
        for(int i=0;i<desks.length;i++){
            reports[i]=Duwm1684DeskDiagnostics.read(this,desks[i]);
            Duwm1724SignalFlow.Stage stage=Duwm1715SignalLights.stageFor(this,i);
            colors[i]=stage.color;
            if(stage==Duwm1724SignalFlow.Stage.HEALTHY || stage==Duwm1724SignalFlow.Stage.RECEIVING)counts[0]++;
            else if(Duwm1724SignalFlow.requiresReview(stage))counts[1]++;
            else if(stage==Duwm1724SignalFlow.Stage.LOCAL)counts[2]++;
            else if(stage==Duwm1724SignalFlow.Stage.CONNECTING)counts[3]++;
            else counts[4]++;
        }
        summary.removeAllViews();
        summaryTile("CURRENT",counts[0],Duwm1724SignalFlow.Stage.HEALTHY.color);
        summaryTile("REVIEW",counts[1],Duwm1724SignalFlow.Stage.DEGRADED.color);
        summaryTile("LOCAL TOOLS",counts[2],Duwm1724SignalFlow.Stage.LOCAL.color);
        summaryTile("CONNECTING",counts[3],Duwm1724SignalFlow.Stage.CONNECTING.color);
        summaryTile("NO RECEIPT",counts[4],DuwmUnifiedTheme.MUTED);
        cards.removeAllViews();
        int shown=0;
        for(int i=0;i<desks.length;i++)if(visible(i,reports[i],colors[i])){
            addCard(i,reports[i],colors[i]);shown++;
        }
        if(shown==0){
            TextView empty=text("NO MATCHING STORED SOURCE RECEIPTS\nChange filter or search to inspect other sectors.",13,DuwmUnifiedTheme.MUTED,false);
            empty.setPadding(dp(12),dp(32),dp(12),dp(24));
            cards.addView(empty,margin(95,5));
        }
        subheading.setText("19 EXISTING DESKS  /  "+shown+" VISIBLE  /  RECEIPTS ON THIS DEVICE");
    }
}
