package com.sentongoharuna.worldsituationroom;

/** Completion gate shared with the real recorded-file callback path. A completed
 * request returning no words is observable; acoustic silence is not established.
 * Every error/cancellation terminates the request before this gate can accept it. */
public final class Duwm1728SpeechSessionPolicy {
    public static final String NO_WORDS_RETURNED="NO_WORDS_RETURNED";
    public enum Completion { WAITING, WITH_WORDS, NO_WORDS, INVALID, TERMINATED }
    private Duwm1728SpeechSessionPolicy() {}

    public static Completion completion(boolean supportConfirmed,boolean recognitionStarted,
            boolean segmentedEnded,boolean audioComplete,boolean terminated,
            int nonemptySegments,int transcriptLength){
        if(terminated)return Completion.TERMINATED;
        if(nonemptySegments<0||transcriptLength<0||nonemptySegments>transcriptLength
                ||(nonemptySegments==0)!=(transcriptLength==0))return Completion.INVALID;
        if((recognitionStarted&&!supportConfirmed)
                ||((segmentedEnded||audioComplete||nonemptySegments>0)&&(!supportConfirmed||!recognitionStarted)))
            return Completion.INVALID;
        if(!segmentedEnded||!audioComplete)return Completion.WAITING;
        return nonemptySegments==0?Completion.NO_WORDS:Completion.WITH_WORDS;
    }
}
