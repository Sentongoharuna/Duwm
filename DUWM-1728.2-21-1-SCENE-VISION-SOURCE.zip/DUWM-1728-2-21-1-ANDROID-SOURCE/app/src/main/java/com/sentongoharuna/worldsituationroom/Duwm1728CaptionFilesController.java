package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Caption document UI. Imports are candidates until accepted; writes use immutable snapshots. */
public final class Duwm1728CaptionFilesController {
    public static final int SAVE_REQUEST=17286,IMPORT_REQUEST=17287;
    private static final int NAVY=0xFF041424,WHITE=0xFFF5F7FA,SILVER=0xFFDEE5EF,GREEN=0xFF00C853;
    public interface Host {
        boolean canUseFiles();
        Selection selection();
        boolean replaceCaptions(List<Duwm1728BroadcastLayout.Cue> cues,String kind);
        void changed();
    }
    public static final class Selection {
        final List<Duwm1728BroadcastLayout.Cue> cues;
        final long durationMs,fromMs,toMs;
        final String sourceKey,captionError;
        public Selection(List<Duwm1728BroadcastLayout.Cue> cues,long durationMs,long fromMs,long toMs,String sourceKey){
            this(cues,durationMs,fromMs,toMs,sourceKey,"");
        }
        public Selection(List<Duwm1728BroadcastLayout.Cue> cues,long durationMs,long fromMs,long toMs,String sourceKey,String captionError){
            this.cues=Collections.unmodifiableList(new ArrayList<>(cues));this.durationMs=durationMs;
            this.fromMs=fromMs;this.toMs=toMs;this.sourceKey=sourceKey;this.captionError=captionError;
        }
    }
    private final Activity owner;
    private final Host host;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private AlertDialog dialog,confirmDialog,clearDialog;
    private TextView status,summary,saveButton,shareButton,importButton,clearButton;
    private RadioButton originalButton,clipButton;
    private String statusText="Choose a time basis. Save and share use applied captions.";
    private boolean working,destroyed,pendingImport;
    private String pendingSaveId="";
    private Uri pendingDestination,lastSavedUri,lastSharedUri;
    private Duwm1728CaptionSrt.TimeBase basis=Duwm1728CaptionSrt.TimeBase.ORIGINAL;
    private Duwm1728CaptionSrt.TimeBase importBasis=Duwm1728CaptionSrt.TimeBase.ORIGINAL;
    private long importDuration,importFrom,importTo;
    private String importSource="";
    private List<Duwm1728BroadcastLayout.Cue> candidate;

    public Duwm1728CaptionFilesController(Activity owner,Host host,Bundle saved){
        this.owner=owner;this.host=host;
        if(saved!=null){
            basis=timeBase(saved.getString("caption_files_basis","ORIGINAL"));
            pendingSaveId=saved.getString("caption_files_save_id","");
            String destination=saved.getString("caption_files_destination","");
            pendingDestination=destination.isEmpty()?null:Uri.parse(destination);
            pendingImport=saved.getBoolean("caption_files_import_pending",false);
            importBasis=timeBase(saved.getString("caption_files_import_basis","ORIGINAL"));
            importDuration=saved.getLong("caption_files_import_duration");importFrom=saved.getLong("caption_files_import_from");
            importTo=saved.getLong("caption_files_import_to");importSource=saved.getString("caption_files_import_source","");
            statusText=saved.getString("caption_files_status",statusText);
            if(saved.getBoolean("caption_files_unfinished_import",false)&&!pendingImport)
                statusText="IMPORT CANCELLED • Review was interrupted. The draft is unchanged; choose the file again.";
            if(!pendingSaveId.isEmpty()&&pendingDestination!=null)main.post(this::writePending);
            else if(saved.getBoolean("caption_files_preparing",false)&&pendingSaveId.isEmpty())
                statusText="SAVE CANCELLED • Preparation was interrupted. Applied captions are unchanged.";
        }
    }
    private static Duwm1728CaptionSrt.TimeBase timeBase(String name){return "SELECTED_CLIP".equals(name)?Duwm1728CaptionSrt.TimeBase.SELECTED_CLIP:Duwm1728CaptionSrt.TimeBase.ORIGINAL;}
    public boolean locksEditor(){return working||pendingImport||!pendingSaveId.isEmpty()||candidate!=null;}
    public void saveState(Bundle state){
        state.putString("caption_files_basis",basis.name());state.putString("caption_files_save_id",pendingSaveId);
        state.putString("caption_files_destination",pendingDestination==null?"":pendingDestination.toString());
        state.putBoolean("caption_files_import_pending",pendingImport);state.putString("caption_files_import_basis",importBasis.name());
        state.putLong("caption_files_import_duration",importDuration);state.putLong("caption_files_import_from",importFrom);state.putLong("caption_files_import_to",importTo);
        state.putString("caption_files_import_source",importSource);state.putString("caption_files_status",statusText);
        state.putBoolean("caption_files_unfinished_import",candidate!=null||(working&&pendingSaveId.isEmpty()));
        state.putBoolean("caption_files_preparing",working&&pendingSaveId.isEmpty()&&!pendingImport&&candidate==null);
    }
    private boolean alive(){return !destroyed&&!owner.isFinishing()&&!owner.isDestroyed();}
    private boolean allowed(){return alive()&&host.canUseFiles();}
    private int dp(int value){return Math.round(value*owner.getResources().getDisplayMetrics().density);}
    private TextView label(String text,int sp){TextView view=new TextView(owner);view.setText(text);view.setTextSize(sp);view.setTextColor(WHITE);view.setPadding(dp(12),dp(8),dp(12),dp(8));return view;}
    private TextView button(String text,String tag,Runnable action){
        TextView view=label(text,13);view.setTag(tag);view.setGravity(Gravity.CENTER);view.setTypeface(null,Typeface.BOLD);
        view.setMinHeight(dp(48));view.setMaxLines(2);view.setFocusable(true);
        GradientDrawable background=new GradientDrawable();background.setColor(0xFF081B2B);background.setCornerRadius(dp(8));background.setStroke(Math.max(1,dp(1)),SILVER);view.setBackground(background);
        view.setOnClickListener(v->{if(allowed()&&!locksEditor())action.run();else if(!host.canUseFiles())setStatus("Apply or cancel caption edits and finish the current operation first.");});return view;
    }
    private LinearLayout.LayoutParams row(){LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,-2);params.setMargins(dp(6),dp(4),dp(6),dp(4));return params;}
    public void show(){
        if(!alive())return;
        if(!host.canUseFiles()){Toast.makeText(owner,"Apply or cancel caption edits before opening caption files.",Toast.LENGTH_LONG).show();return;}
        if(dialog!=null&&dialog.isShowing()){updateControls();return;}
        LinearLayout content=new LinearLayout(owner);content.setOrientation(LinearLayout.VERTICAL);content.setBaselineAligned(false);content.setBackgroundColor(NAVY);content.setTag("caption-files-root");
        content.addView(label("SRT CAPTION FILES",18),row());
        content.addView(label("Only applied captions are exported. Choose the time basis for both saving and importing.",12),row());
        RadioGroup choices=new RadioGroup(owner);choices.setOrientation(RadioGroup.VERTICAL);
        originalButton=choice("Original video • all captions","caption-files-original");
        clipButton=choice("Selected clip • clipped, starts at zero","caption-files-clip");
        choices.addView(originalButton,new RadioGroup.LayoutParams(-1,-2));choices.addView(clipButton,new RadioGroup.LayoutParams(-1,-2));content.addView(choices,row());
        originalButton.setChecked(basis==Duwm1728CaptionSrt.TimeBase.ORIGINAL);clipButton.setChecked(basis==Duwm1728CaptionSrt.TimeBase.SELECTED_CLIP);
        choices.setOnCheckedChangeListener((group,id)->{basis=id==clipButton.getId()?Duwm1728CaptionSrt.TimeBase.SELECTED_CLIP:Duwm1728CaptionSrt.TimeBase.ORIGINAL;updateControls();});
        summary=label("",12);summary.setTag("caption-files-summary");summary.setTextColor(SILVER);content.addView(summary,row());
        status=label(statusText,12);status.setTag("caption-files-status");status.setTextColor(GREEN);content.addView(status,row());
        saveButton=button("SAVE SRT…","caption-files-save",()->prepare(false));content.addView(saveButton,row());
        shareButton=button("SHARE SRT…","caption-files-share",()->prepare(true));content.addView(shareButton,row());
        importButton=button("IMPORT SRT…","caption-files-import",this::chooseImport);content.addView(importButton,row());
        clearButton=button("CLEAR SHARED COPIES","caption-files-clear-shared",this::confirmClear);content.addView(clearButton,row());
        ScrollView scroll=new ScrollView(owner);scroll.setFillViewport(false);scroll.addView(content);
        dialog=new AlertDialog.Builder(owner).setView(scroll).setNegativeButton("CLOSE",(d,w)->{}).create();
        dialog.setOnDismissListener(d->{dialog=null;status=null;summary=null;saveButton=null;shareButton=null;importButton=null;clearButton=null;originalButton=null;clipButton=null;});
        dialog.setOnShowListener(d->{dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTag("caption-files-close");dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setMinHeight(dp(48));});
        dialog.show();updateControls();
    }
    private RadioButton choice(String text,String tag){RadioButton button=new RadioButton(owner);button.setId(View.generateViewId());button.setTag(tag);button.setText(text);button.setTextColor(WHITE);button.setTextSize(13);button.setMinHeight(dp(48));return button;}
    private void updateControls(){
        if(!alive())return;boolean idle=!locksEditor()&&host.canUseFiles();int count=0;String detail;
        try {Selection selection=host.selection();
            if(basis==Duwm1728CaptionSrt.TimeBase.ORIGINAL){count=selection.cues.size();detail=count+" captions • original-video timestamps; includes cues outside the clip.";}
            else {Duwm1728BroadcastTimeline.range(selection.fromMs,selection.toMs);
                if(selection.toMs>selection.durationMs)throw new IllegalArgumentException("Clip ends after the recording");
                for(Duwm1728BroadcastLayout.Cue cue:selection.cues)if(Math.min(cue.endMs,selection.toMs)>Math.max(cue.startMs,selection.fromMs))count++;
                detail=count+" captions • clip "+Duwm1728CaptionEditPolicy.formatTime(selection.fromMs)+" – "+Duwm1728CaptionEditPolicy.formatTime(selection.toMs)+". Import adds this start to file times.";}
            if(!selection.captionError.isEmpty()){count=0;detail=selection.captionError+" Import a reviewed replacement or use CAPTIONS to correct the set.";}
        }catch(Exception invalid){detail="Check the caption or clip fields: "+invalid.getMessage();idle=false;}
        if(summary!=null)summary.setText(detail);enable(saveButton,idle&&count>0);enable(shareButton,idle&&count>0);
        enable(importButton,idle);enable(clearButton,idle);enable(originalButton,!locksEditor());enable(clipButton,!locksEditor());
    }
    private void enable(View view,boolean enabled){if(view!=null){view.setEnabled(enabled);view.setAlpha(enabled?1f:.45f);}}
    private void setStatus(String message){statusText=message;if(status!=null)status.setText(message);if(alive()){
        updateControls();host.changed();if(status==null&&(message.startsWith("SRT SAVED")||message.contains("FAILED")||message.contains("CANCELLED")))
            Toast.makeText(owner,message,Toast.LENGTH_LONG).show();}}
    private void busy(String message){working=true;setStatus(message);}
    private Selection selection(){Selection selected=host.selection();if(!allowed())throw new IllegalStateException("Caption files are unavailable while another edit is open");return selected;}
    private void prepare(boolean sharing){
        final Selection selected;final Duwm1728CaptionSrt.TimeBase selectedBasis=basis;
        try{selected=selection();if(!selected.captionError.isEmpty())throw new IllegalArgumentException(selected.captionError);}
        catch(Exception failure){setStatus("EXPORT FAILED • "+failure.getMessage());return;}
        busy("PREPARING SRT • "+(selectedBasis==Duwm1728CaptionSrt.TimeBase.ORIGINAL?"original video":"selected clip"));
        worker.execute(()->{
            try {
                byte[] encoded=Duwm1728CaptionSrt.exportCues(selected.cues,selectedBasis,selected.durationMs,selected.fromMs,selected.toMs);
                String name="duwm-captions-"+(selectedBasis==Duwm1728CaptionSrt.TimeBase.ORIGINAL?"original":"clip")+"-"+System.currentTimeMillis()+".srt";
                Duwm1728CaptionFileStore.Snapshot snapshot=Duwm1728CaptionFileStore.create(owner.getApplicationContext(),encoded,name,selected.sourceKey,selectedBasis.name());
                main.post(()->{
                    working=false;if(!alive()){discard(snapshot.id);return;}
                    if(!allowed()){discard(snapshot.id);setStatus("EXPORT CANCELLED • The editor changed before the file was ready.");return;}
                    if(sharing)share(snapshot);else chooseSave(snapshot);
                });
            }catch(Exception failure){main.post(()->{working=false;if(alive())setStatus((sharing?"SHARE FAILED • ":"SAVE FAILED • ")+failure.getMessage());});}
        });
    }
    private void chooseSave(Duwm1728CaptionFileStore.Snapshot snapshot){
        pendingSaveId=snapshot.id;pendingDestination=null;setStatus("CHOOSE SAVE LOCATION • Frozen applied captions are ready.");
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(Duwm1728CaptionFileStore.MIME)
                .putExtra(Intent.EXTRA_TITLE,snapshot.name);
        try{owner.startActivityForResult(intent,SAVE_REQUEST);}
        catch(Exception failure){String abandoned=pendingSaveId;pendingSaveId="";discard(abandoned);setStatus("SAVE FAILED • File picker unavailable: "+failure.getMessage());}
    }
    private void share(Duwm1728CaptionFileStore.Snapshot snapshot){
        busy("PREPARING SRT SHARE…");worker.execute(()->{
            try {Duwm1728CaptionFileStore.markShared(owner.getApplicationContext(),snapshot.id);
                main.post(()->{working=false;if(!alive())return;
                    try {Intent send=Duwm1728CaptionFileStore.shareIntent(snapshot.uri);Intent chooser=Intent.createChooser(send,"Share SRT captions");
                        chooser.setClipData(send.getClipData());chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        lastSharedUri=snapshot.uri;owner.startActivity(chooser);setStatus("SRT READY TO SHARE • "+snapshot.name);
                    }catch(Exception failure){setStatus("SHARE FAILED • "+failure.getMessage());}
                });
            }catch(Exception failure){main.post(()->{working=false;if(alive())setStatus("SHARE FAILED • "+failure.getMessage());});}
        });
    }
    private void chooseImport(){
        try {Selection selected=selection();importBasis=basis;importDuration=selected.durationMs;importFrom=selected.fromMs;importTo=selected.toMs;importSource=selected.sourceKey;
            if(importBasis==Duwm1728CaptionSrt.TimeBase.SELECTED_CLIP){Duwm1728BroadcastTimeline.range(importFrom,importTo);if(importTo>importDuration)throw new IllegalArgumentException("Clip ends after the recording");}
            pendingImport=true;setStatus("CHOOSE SRT FILE • "+(importBasis==Duwm1728CaptionSrt.TimeBase.ORIGINAL?"original-video timestamps":"selected-clip timestamps; clip start will be added"));
            Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                    .putExtra(Intent.EXTRA_MIME_TYPES,new String[]{Duwm1728CaptionFileStore.MIME,"text/plain","application/octet-stream"});
            owner.startActivityForResult(intent,IMPORT_REQUEST);
        }catch(Exception failure){pendingImport=false;setStatus("IMPORT FAILED • "+failure.getMessage());}
    }
    /** Handles only these two real Activity result contracts, including cancellation. */
    public boolean onActivityResult(int request,int result,Intent data){
        if(request!=SAVE_REQUEST&&request!=IMPORT_REQUEST)return false;
        if(alive()&&(dialog==null||!dialog.isShowing()))show();
        if(request==SAVE_REQUEST){
            if(pendingSaveId.isEmpty()){setStatus("SAVE FAILED • No frozen pending caption file is available.");return true;}
            if(result!=Activity.RESULT_OK||data==null||data.getData()==null){String abandoned=pendingSaveId;pendingSaveId="";pendingDestination=null;discard(abandoned);setStatus("SAVE CANCELLED • No SRT document was written.");return true;}
            pendingDestination=data.getData();writePending();return true;
        }
        if(!pendingImport){setStatus("IMPORT CANCELLED • The pending import is no longer available.");return true;}
        pendingImport=false;
        if(result!=Activity.RESULT_OK||data==null||data.getData()==null){setStatus("IMPORT CANCELLED • Current captions are unchanged.");return true;}
        Uri selected=data.getData();busy("READING SRT • Validating the complete file…");
        worker.execute(()->{
            try {
                String text;try(InputStream input=owner.getContentResolver().openInputStream(selected)){
                    if(input==null)throw new java.io.IOException("The selected file is unavailable");text=Duwm1728CaptionSrt.read(input);}
                List<Duwm1728BroadcastLayout.Cue> imported=Duwm1728CaptionSrt.importCues(text,importBasis,importDuration,importFrom,importTo);
                main.post(()->{working=false;if(!alive())return;
                    if(!allowed()||!importSource.equals(host.selection().sourceKey)){setStatus("IMPORT CANCELLED • The source or editor changed. Current captions are unchanged.");return;}
                    candidate=imported;setStatus("REVIEW IMPORT • "+candidate.size()+" captions validated. Current captions are unchanged.");confirmImport();
                });
            }catch(Exception failure){main.post(()->{working=false;if(alive())setStatus("IMPORT FAILED • "+failure.getMessage());});}
        });return true;
    }
    private void writePending(){
        if(!alive()||working||pendingSaveId.isEmpty()||pendingDestination==null)return;
        final String id=pendingSaveId;final Uri destination=pendingDestination;final String sourceKey=host.selection().sourceKey;
        busy("WRITING SRT • Saving the frozen caption file…");
        worker.execute(()->{
            try {
                Duwm1728CaptionFileStore.Snapshot snapshot=Duwm1728CaptionFileStore.find(owner.getApplicationContext(),id);
                if(!sourceKey.equals(snapshot.sourceKey))throw new java.io.IOException("Pending captions belong to a different source video");
                Duwm1728CaptionFileStore.copyTo(owner.getApplicationContext(),id,destination);
                main.post(()->{working=false;if(!alive())return;lastSavedUri=destination;pendingSaveId="";pendingDestination=null;
                    setStatus("SRT SAVED • "+snapshot.name);discard(id);});
            }catch(Exception failure){main.post(()->{working=false;if(!alive())return;pendingSaveId="";pendingDestination=null;
                setStatus("SAVE FAILED • "+failure.getMessage()+". The selected destination may contain an incomplete file.");discard(id);});}
        });
    }
    private void confirmImport(){
        LinearLayout body=new LinearLayout(owner);body.setOrientation(LinearLayout.VERTICAL);body.setBaselineAligned(false);body.setBackgroundColor(NAVY);body.setTag("caption-files-confirm");
        String timing=importBasis==Duwm1728CaptionSrt.TimeBase.ORIGINAL?"Original-video timestamps":"Selected-clip timestamps shifted by "+Duwm1728CaptionEditPolicy.formatTime(importFrom);
        body.addView(label(candidate.size()+" validated captions. "+timing+".\nREPLACE ALL changes the current caption set; keeping current captions discards this candidate.",13));
        StringBuilder preview=new StringBuilder();for(int i=0;i<Math.min(3,candidate.size());i++){
            Duwm1728BroadcastLayout.Cue cue=candidate.get(i);preview.append(Duwm1728CaptionEditPolicy.formatTime(cue.startMs)).append(" → ")
                    .append(Duwm1728CaptionEditPolicy.formatTime(cue.endMs)).append('\n').append(cue.text).append("\n\n");}
        if(candidate.size()>3)preview.append("First 3 of ").append(candidate.size()).append(" captions shown. All validated cues will be imported.");
        body.addView(label(preview.toString(),12));ScrollView scroll=new ScrollView(owner);scroll.addView(body);
        confirmDialog=new AlertDialog.Builder(owner).setTitle("Replace current captions?").setView(scroll)
                .setNegativeButton("KEEP CURRENT",(d,w)->{}).setPositiveButton("REPLACE ALL",null).create();
        confirmDialog.setOnShowListener(d->{
            confirmDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTag("caption-files-cancel-import");
            confirmDialog.getButton(AlertDialog.BUTTON_POSITIVE).setTag("caption-files-confirm-import");
            confirmDialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                if(!allowed()||candidate==null||!importSource.equals(host.selection().sourceKey)){setStatus("IMPORT CANCELLED • The editor changed.");confirmDialog.dismiss();return;}
                try {if(host.replaceCaptions(candidate,"Imported SRT ("+(importBasis==Duwm1728CaptionSrt.TimeBase.ORIGINAL?"original-video timing":"selected-clip timing shifted to original video")+")")){
                    int count=candidate.size();candidate=null;setStatus("CAPTIONS IMPORTED INTO DRAFT • "+count+" source-time cues. Review is required.");confirmDialog.dismiss();}}
                catch(Exception failure){setStatus("IMPORT FAILED • "+failure.getMessage());}
            });
        });
        confirmDialog.setOnDismissListener(d->{confirmDialog=null;if(candidate!=null){candidate=null;setStatus("IMPORT CANCELLED • Current captions are unchanged.");}else updateControls();});
        confirmDialog.show();
    }
    private void confirmClear(){
        clearDialog=new AlertDialog.Builder(owner).setTitle("Clear shared SRT copies?")
                .setMessage("Existing recipient links will stop opening. This removes private shared copies; saved documents and pending saves remain available.")
                .setNegativeButton("KEEP",null).setPositiveButton("CLEAR COPIES",(d,w)->{
                    if(!allowed()||locksEditor())return;busy("CLEARING SHARED COPIES…");worker.execute(()->{
                        try{int count=Duwm1728CaptionFileStore.clearShared(owner.getApplicationContext());main.post(()->{working=false;if(alive())setStatus("SHARED COPIES CLEARED • "+count+" removed.");});}
                        catch(Exception failure){main.post(()->{working=false;if(alive())setStatus("CLEAR FAILED • "+failure.getMessage());});}
                    });
                }).create();
        clearDialog.setOnShowListener(d->clearDialog.getButton(AlertDialog.BUTTON_POSITIVE).setTag("caption-files-clear-confirm"));
        clearDialog.setOnDismissListener(d->clearDialog=null);clearDialog.show();
    }
    private void discard(String id){if(id==null||id.isEmpty())return;
        // Cleanup does not turn a completed document write into a false save failure.
        Runnable cleanup=()->{try{Duwm1728CaptionFileStore.discardUnshared(owner.getApplicationContext(),id);}catch(Exception ignored){}};
        if(worker.isShutdown())new Thread(cleanup,"duwm-caption-cleanup").start();else worker.execute(cleanup);
    }
    public void close(){destroyed=true;if(confirmDialog!=null)confirmDialog.dismiss();if(clearDialog!=null)clearDialog.dismiss();if(dialog!=null)dialog.dismiss();
        // An already-authorized document write finishes; its receipt supports Activity recreation.
        worker.shutdown();}
}
