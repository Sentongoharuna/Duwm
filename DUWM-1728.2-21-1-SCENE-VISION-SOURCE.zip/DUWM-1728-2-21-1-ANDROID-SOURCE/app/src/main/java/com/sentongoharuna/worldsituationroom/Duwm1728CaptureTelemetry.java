package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.net.Uri;
import org.json.JSONObject;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Capture-end provenance snapshot for videos actually recorded by DUWM.
 * Not a continuous sensor track. Missing data remains UNAVAILABLE. No external upload.
 */
public final class Duwm1728CaptureTelemetry {
    private Duwm1728CaptureTelemetry() {}
    public static final class Snapshot {
        public final long capturedUtcMs;
        public final String compass, altitude, gpsAccuracy, weather, coordinates;
        public final boolean preciseEnabled;
        public Snapshot(long time,String compass,String altitude,String accuracy,String weather,String coordinates,boolean precise){
            this.capturedUtcMs=time;this.compass=clean(compass);this.altitude=clean(altitude);
            this.gpsAccuracy=clean(accuracy);this.weather=clean(weather);this.coordinates=clean(coordinates);
            this.preciseEnabled=precise;
        }
        public String captureTimeLabel(){return "CAPTURE-END UTC "+utc(capturedUtcMs);}
        public String summary(){return captureTimeLabel()+" | DEVICE HDG "+compass+" | ALT "+altitude+" | GPS ACC "+gpsAccuracy+" | "+weather;}
        public String gpsSummary(boolean exportPermission){return preciseEnabled&&exportPermission?"GPS "+coordinates:"GPS WITHHELD";}
    }
    private static String clean(String value){
        if(value==null||value.trim().isEmpty())return "UNAVAILABLE";
        String s=value.replaceAll("[\\r\\n\\t]+"," ").trim();return s.length()>110?s.substring(0,110):s;
    }
    private static String utc(long ms){
        if(ms<=0)return "UNKNOWN";
        java.text.SimpleDateFormat df=new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'",Locale.US);
        df.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));return df.format(new java.util.Date(ms));
    }
    public static String storageKey(Uri uri){
        if(uri==null)throw new IllegalArgumentException("Video URI required");
        try{byte[] data=MessageDigest.getInstance("SHA-256").digest(uri.toString().getBytes(StandardCharsets.UTF_8));
            StringBuilder hex=new StringBuilder("capture_");for(byte b:data)hex.append(String.format(Locale.US,"%02x",b&255));return hex.toString();
        }catch(Exception e){throw new IllegalStateException("Cannot identify capture",e);}
    }
    public static void save(Context context,Uri video,Snapshot snap){
        if(context==null||snap==null)return;
        try{
            JSONObject json=new JSONObject();json.put("version",1);json.put("capturedUtcMs",snap.capturedUtcMs);
            json.put("compass",snap.compass);json.put("altitude",snap.altitude);
            json.put("accuracy",snap.gpsAccuracy);json.put("weather",snap.weather);
            json.put("coordinates",snap.preciseEnabled?snap.coordinates:"WITHHELD");
            json.put("precise",snap.preciseEnabled);
            context.getSharedPreferences("duwm_capture_provenance",Context.MODE_PRIVATE).edit().putString(storageKey(video),json.toString()).apply();
        }catch(Exception e){android.util.Log.w("DUWM-CAPTURE","Capture provenance not stored",e);}
    }
    public static Snapshot load(Context context,Uri video){
        if(context==null||video==null)return null;
        try{String raw=context.getSharedPreferences("duwm_capture_provenance",Context.MODE_PRIVATE).getString(storageKey(video),null);
            if(raw==null)return null;JSONObject j=new JSONObject(raw);if(j.optInt("version")!=1)return null;
            return new Snapshot(j.optLong("capturedUtcMs"),j.optString("compass","UNAVAILABLE"),j.optString("altitude","UNAVAILABLE"),
                j.optString("accuracy","UNAVAILABLE"),j.optString("weather","UNAVAILABLE"),
                j.optString("coordinates","WITHHELD"),j.optBoolean("precise",false));
        }catch(Exception e){android.util.Log.w("DUWM-CAPTURE","Capture provenance unreadable",e);return null;}
    }
}
