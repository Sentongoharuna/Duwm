package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Actual sampled capture data, NOT inferred GPS track. Max 200 events / 2 second cadence.
 * Only stored for MONITORS CAM Gallery recordings. Precise coordinates require
 * capture consent AND independent edited-export consent.
 */
public final class Duwm1728TelemetryTimeline {
    public static final class Point {
        public final long atMs;
        public final Duwm1728CaptureTelemetry.Snapshot snapshot;
        public Point(long atMs,Duwm1728CaptureTelemetry.Snapshot snapshot){
            if(atMs<0||snapshot==null)throw new IllegalArgumentException("Invalid recorded sample");
            this.atMs=atMs;this.snapshot=snapshot;
        }
    }
    private Duwm1728TelemetryTimeline(){}
    public static Point at(List<Point> points,long clipOffsetMs){
        if(points==null)return null;
        Point current=null;
        for(Point point:points){if(point.atMs>clipOffsetMs)break;current=point;}
        return current;
    }
    public static void save(Context ctx,Uri uri,List<Point> points){
        if(ctx==null||uri==null||points==null||points.isEmpty())return;
        try{
            JSONArray arr=new JSONArray();long prev=-1;
            for(Point point:points){if(arr.length()>=200)break;if(point.atMs<=prev)continue;prev=point.atMs;
                Duwm1728CaptureTelemetry.Snapshot s=point.snapshot;
                JSONObject j=new JSONObject();j.put("t",point.atMs);j.put("utc",s.capturedUtcMs);
                j.put("compass",s.compass);j.put("altitude",s.altitude);j.put("accuracy",s.gpsAccuracy);
                j.put("weather",s.weather);j.put("precise",s.preciseEnabled);
                j.put("coords",s.preciseEnabled?s.coordinates:"WITHHELD");arr.put(j);
            }
            ctx.getSharedPreferences("duwm1728_video_measurements",Context.MODE_PRIVATE)
              .edit().putString(Duwm1728CaptureTelemetry.storageKey(uri),arr.toString()).apply();
        }catch(Exception ex){android.util.Log.w("DUWM-TIMELINE","Saving telemetry samples failed",ex);}
    }
    public static List<Point> load(Context ctx,Uri uri){
        if(ctx==null||uri==null)return Collections.emptyList();
        List<Point> result=new ArrayList<>();
        try{
            String raw=ctx.getSharedPreferences("duwm1728_video_measurements",Context.MODE_PRIVATE)
                .getString(Duwm1728CaptureTelemetry.storageKey(uri),null);
            if(raw==null)return result;JSONArray a=new JSONArray(raw);long prev=-1;
            for(int i=0;i<Math.min(200,a.length());i++){
                JSONObject j=a.getJSONObject(i);long t=j.optLong("t",-1);if(t<=prev)continue;prev=t;
                boolean precise=j.optBoolean("precise",false);
                result.add(new Point(t,new Duwm1728CaptureTelemetry.Snapshot(j.optLong("utc"),
                    j.optString("compass"),j.optString("altitude"),j.optString("accuracy"),
                    j.optString("weather"),precise?j.optString("coords"):"WITHHELD",precise)));
            }
        }catch(Exception ex){android.util.Log.w("DUWM-TIMELINE","Reading telemetry samples failed",ex);}
        return result;
    }
}
