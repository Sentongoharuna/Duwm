package com.sentongoharuna.worldsituationroom;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Completed broadcast copies retained on this device until their Gallery save is confirmed. */
public final class Duwm1728ExportRecoveryActivity extends Activity {
    public static final String EXTRA_ENTRY_ID="duwm_recovery_entry_id";
    private static final int NAVY=0xFF041424,SILVER=0xFFDEE5EF,WHITE=0xFFF5F7FA;
    private static final int GREEN=0xFF00C853,AMBER=0xFFFFB300;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final List<View> actionButtons=new ArrayList<>();
    private TextView status,refreshButton;
    private LinearLayout cards;
    private ScrollView scroll;
    private boolean destroyed,loading,operationBusy;
    private int generation;
    private String selectedId;
    private Duwm1728ExportRecovery.Entry awaitingPermission;
    private static final int STORAGE_PERMISSION=2814;

    public static Intent intent(Context context,String id){
        Intent result=new Intent(context,Duwm1728ExportRecoveryActivity.class);
        if(id!=null)result.putExtra(EXTRA_ENTRY_ID,id);
        return result;
    }
    public static void open(Context context){open(context,null);}
    public static void open(Context context,String id){
        Intent launch=intent(context,id);
        if(!(context instanceof Activity))launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(launch);
    }
    private boolean canPresent(){return !destroyed&&!isFinishing()&&!isDestroyed();}
    private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
    private TextView text(String value,int size){
        TextView view=new TextView(this);view.setText(value);view.setTextSize(size);
        view.setTextColor(WHITE);view.setPadding(dp(12),dp(7),dp(12),dp(7));return view;
    }
    private GradientDrawable border(int color){
        GradientDrawable shape=new GradientDrawable();shape.setColor(NAVY);
        shape.setCornerRadius(dp(12));shape.setStroke(Math.max(1,dp(1)),color);return shape;
    }
    private TextView button(String title,String tag,Runnable action){
        TextView view=text(title,12);view.setTag(tag);view.setTypeface(null,Typeface.BOLD);
        view.setGravity(Gravity.CENTER);view.setMinHeight(dp(48));view.setMaxLines(2);
        view.setBackground(border(SILVER));view.setFocusable(true);view.setContentDescription(title);
        view.setAccessibilityDelegate(new View.AccessibilityDelegate(){
            @Override public void onInitializeAccessibilityNodeInfo(View host,AccessibilityNodeInfo info){
                super.onInitializeAccessibilityNodeInfo(host,info);info.setClassName("android.widget.Button");
            }
        });
        view.setOnClickListener(v->action.run());return view;
    }
    private LinearLayout.LayoutParams cell(){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);
        p.setMargins(dp(3),dp(4),dp(3),dp(4));return p;
    }
    private void enabled(View view,boolean value){view.setEnabled(value);view.setAlpha(value?1f:.45f);}

    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(NAVY);
        selectedId=getIntent().getStringExtra(EXTRA_ENTRY_ID);
        LinearLayout page=new LinearLayout(this);page.setTag("recovery-page");
        page.setOrientation(LinearLayout.VERTICAL);page.setBackgroundColor(NAVY);
        page.setPadding(dp(10),dp(4),dp(10),dp(8));
        LinearLayout heading=new LinearLayout(this);heading.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=text("PENDING BROADCASTS",17);title.setTypeface(null,Typeface.BOLD);
        heading.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        heading.addView(button("BACK","recovery-back",this::finish),new LinearLayout.LayoutParams(dp(72),-2));
        page.addView(heading);
        TextView guidance=text("Completed MP4s kept in DUWM. Review or share a copy, then save it to Gallery without rendering again.",12);
        guidance.setTextColor(SILVER);page.addView(guidance);
        TextView retention=text("These copies stay on this device until saved or deleted. Clearing DUWM's app data or uninstalling removes them.",11);
        retention.setTextColor(SILVER);page.addView(retention);
        LinearLayout toolbar=new LinearLayout(this);toolbar.setGravity(Gravity.CENTER_VERTICAL);
        status=text("LOADING COPIES…",12);status.setTag("recovery-status");status.setTextColor(SILVER);
        toolbar.addView(status,new LinearLayout.LayoutParams(0,-2,1));
        refreshButton=button("REFRESH","recovery-refresh",this::reload);
        toolbar.addView(refreshButton,new LinearLayout.LayoutParams(dp(92),-2));page.addView(toolbar);
        scroll=new ScrollView(this);scroll.setFillViewport(true);
        cards=new LinearLayout(this);cards.setTag("recovery-list");cards.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(cards,new ScrollView.LayoutParams(-1,-2));
        page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(page);
    }
    @Override protected void onResume(){super.onResume();reload();}
    private void reload(){
        if(destroyed||operationBusy||loading)return;
        loading=true;enabled(refreshButton,false);final int request=++generation;
        final Context app=getApplicationContext();
        worker.execute(()->{
            List<Duwm1728ExportRecovery.Entry> entries=null;Exception failure=null;
            try{entries=Duwm1728ExportRecovery.list(app);}catch(Exception e){failure=e;}
            final List<Duwm1728ExportRecovery.Entry> result=entries;final Exception error=failure;
            main.post(()->{
                if(!canPresent()||request!=generation)return;
                loading=false;enabled(refreshButton,true);
                if(error!=null){status.setText("COPIES COULD NOT BE READ • TAP REFRESH");status.setTextColor(AMBER);return;}
                render(result);
            });
        });
    }
    private void render(List<Duwm1728ExportRecovery.Entry> entries){
        cards.removeAllViews();actionButtons.clear();int count=0;View selected=null;
        for(Duwm1728ExportRecovery.Entry entry:entries){
            if(entry.state==Duwm1728ExportRecovery.State.PUBLISHED&&!entry.hasLocalCopy)continue;
            count++;View card=card(entry);cards.addView(card);
            if(entry.id.equals(selectedId))selected=card;
        }
        status.setText(count==0?"NO PENDING COPIES":count+" RETAINED COP"+(count==1?"Y":"IES"));
        status.setTextColor(count==0?SILVER:WHITE);
        if(count==0)cards.addView(text("Any completed broadcast that could not be saved to Gallery will appear here.",14));
        if(selected!=null){final View focus=selected;scroll.post(()->{if(canPresent())scroll.smoothScrollTo(0,focus.getTop());});selectedId=null;}
    }
    private View card(Duwm1728ExportRecovery.Entry entry){
        LinearLayout card=new LinearLayout(this);card.setTag("recovery-entry-"+entry.id);
        card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(6),dp(6),dp(6),dp(6));
        card.setBackground(border(SILVER));
        LinearLayout.LayoutParams layout=new LinearLayout.LayoutParams(-1,-2);layout.setMargins(0,dp(5),0,dp(8));card.setLayoutParams(layout);
        TextView name=text(entry.name,14);name.setTypeface(null,Typeface.BOLD);card.addView(name);
        String stateText;int stateColor=AMBER;
        if(entry.state==Duwm1728ExportRecovery.State.PUBLISHED){stateText="SAVED TO GALLERY • LOCAL COPY RETAINED";stateColor=GREEN;}
        else if(!entry.hasLocalCopy)stateText="LOCAL COPY UNAVAILABLE";
        else if(entry.state==Duwm1728ExportRecovery.State.PUBLISHING)stateText="GALLERY SAVE IN PROGRESS";
        else if(entry.state==Duwm1728ExportRecovery.State.UNCONFIRMED)stateText="SAVE UNCONFIRMED • CHECK GALLERY";
        else stateText="LOCAL COPY • NOT IN GALLERY";
        TextView state=text(stateText,12);state.setTag("recovery-state-"+entry.id);state.setTextColor(stateColor);card.addView(state);
        String date=DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(entry.createdAt));
        TextView details=text(String.format(Locale.getDefault(),"%.1f MiB  •  %s",entry.bytes/1048576d,date),11);
        details.setTextColor(SILVER);card.addView(details);
        if(entry.state==Duwm1728ExportRecovery.State.UNCONFIRMED){
            TextView reason=text("The last save did not leave a confirmed result. Check Gallery before saving another copy.",12);
            reason.setTextColor(SILVER);card.addView(reason);
        }
        // Prefer the retained bytes the action names promise. A receipt can still
        // provide a review route when the private copy is no longer available.
        Uri playable=entry.hasLocalCopy?entry.uri:entry.publishedUri;
        LinearLayout playback=new LinearLayout(this);
        TextView review=button("REVIEW COPY","recovery-review-"+entry.id,()->Duwm1728BroadcastReviewActivity.open(this,playable));
        TextView share=button("SHARE COPY","recovery-share-"+entry.id,()->Duwm1728BroadcastReviewActivity.share(this,playable));
        playback.addView(review,cell());playback.addView(share,cell());card.addView(playback);
        enabled(review,entry.hasLocalCopy||entry.publishedUri!=null);enabled(share,review.isEnabled());
        boolean saving=entry.state==Duwm1728ExportRecovery.State.PUBLISHING;
        boolean published=entry.state==Duwm1728ExportRecovery.State.PUBLISHED;
        LinearLayout actions=new LinearLayout(this);
        TextView save=button(entry.state==Duwm1728ExportRecovery.State.UNCONFIRMED?"CHECK SAVE":"SAVE TO GALLERY",
                "recovery-save-"+entry.id,()->requestSave(entry));save.setTextColor(GREEN);
        TextView delete=button("DELETE COPY","recovery-delete-"+entry.id,()->requestDelete(entry));
        actions.addView(save,cell());actions.addView(delete,cell());card.addView(actions);
        enabled(save,entry.hasLocalCopy&&!saving&&!published);enabled(delete,!saving);
        actionButtons.add(review);actionButtons.add(share);actionButtons.add(save);actionButtons.add(delete);return card;
    }
    private void requestSave(Duwm1728ExportRecovery.Entry entry){
        if(operationBusy||loading)return;
        if(Duwm1724GalleryPublisher.needsLegacyPermission(this)){
            awaitingPermission=entry;
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},STORAGE_PERMISSION);return;
        }
        confirmSaveIfNeeded(entry);
    }
    private void confirmSaveIfNeeded(Duwm1728ExportRecovery.Entry entry){
        if(operationBusy)return;
        if(entry.state==Duwm1728ExportRecovery.State.UNCONFIRMED){
            new AlertDialog.Builder(this).setTitle("Check Gallery before retrying")
                .setMessage("Look for "+entry.name+" in Gallery. The previous attempt may already have saved it. Saving again can create another copy. The retained MP4 will be used without another render.")
                .setNegativeButton("CANCEL",null).setPositiveButton("SAVE ANOTHER COPY",(d,w)->save(entry,true)).show();
        }else save(entry,false);
    }
    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results){
        super.onRequestPermissionsResult(code,permissions,results);
        if(code!=STORAGE_PERMISSION)return;
        Duwm1728ExportRecovery.Entry entry=awaitingPermission;awaitingPermission=null;
        if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED){
            if(entry!=null&&canPresent())confirmSaveIfNeeded(entry);
        }else if(canPresent())new AlertDialog.Builder(this).setTitle("Gallery permission needed")
            .setMessage("This Android version needs storage permission to save to Gallery. Your retained copy can still be reviewed or shared.")
            .setPositiveButton("CLOSE",null).show();
    }
    private void lockActions(String message){
        operationBusy=true;++generation;loading=false;
        status.setText(message);status.setTextColor(SILVER);enabled(refreshButton,false);
        for(View view:actionButtons)enabled(view,false);
    }
    private void unlockActions(){operationBusy=false;enabled(refreshButton,true);reload();}
    private void save(Duwm1728ExportRecovery.Entry entry,boolean confirmedRetry){
        if(operationBusy)return;lockActions("SAVING RETAINED MP4…");
        final Context app=getApplicationContext();worker.execute(()->{
            Uri output=null;Exception failure=null;
            try{output=confirmedRetry?Duwm1728ExportRecovery.retryAfterUnconfirmed(app,entry.id):Duwm1728ExportRecovery.publish(app,entry.id);}
            catch(Exception error){failure=error;}
            final Uri result=output;final Exception error=failure;
            main.post(()->{
                if(!canPresent())return;unlockActions();
                if(error==null){
                    new AlertDialog.Builder(this).setTitle("Broadcast saved to Gallery")
                        .setMessage(entry.name+"\n\nThe retained MP4 was saved without rendering again.")
                        .setNegativeButton("CLOSE",null).setNeutralButton("SHARE",(d,w)->Duwm1728BroadcastReviewActivity.share(this,result))
                        .setPositiveButton("REVIEW",(d,w)->Duwm1728BroadcastReviewActivity.open(this,result)).show();
                }else if(error instanceof Duwm1728ExportRecovery.BusyException){
                    new AlertDialog.Builder(this).setTitle("Save already in progress").setMessage("This copy is being saved by another DUWM screen. Refresh after it finishes.").setPositiveButton("CLOSE",null).show();
                }else if(error instanceof Duwm1728ExportRecovery.UnconfirmedException){
                    Uri reported=((Duwm1728ExportRecovery.UnconfirmedException)error).publishedUri;
                    new AlertDialog.Builder(this).setTitle(reported==null?"Gallery save unconfirmed":"Gallery reported a saved video")
                        .setMessage(reported==null?"DUWM could not confirm the Gallery save. Your local copy is retained. Check Gallery before retrying.":
                            "Gallery returned the saved video, but DUWM could not store its save receipt. Your local copy is retained. Check Gallery before saving another copy.")
                        .setPositiveButton("CLOSE",null).show();
                }else{
                    new AlertDialog.Builder(this).setTitle("Could not save to Gallery")
                        .setMessage("Your retained copy is still listed here. Check its status, review or share it, and try saving again when Gallery is available.")
                        .setPositiveButton("CLOSE",null).show();
                }
            });
        });
    }
    private void requestDelete(Duwm1728ExportRecovery.Entry entry){
        if(operationBusy||loading)return;
        new AlertDialog.Builder(this).setTitle("Delete this retained copy?")
            .setMessage(entry.name+"\n\nThis removes the completed MP4 kept in DUWM. Your original recording, draft and any video already saved to Gallery remain.")
            .setNegativeButton("CANCEL",null).setPositiveButton("DELETE COPY",(d,w)->{
                if(operationBusy)return;lockActions("REMOVING LOCAL COPY…");
                final Context app=getApplicationContext();worker.execute(()->{
                    Exception failure=null;try{Duwm1728ExportRecovery.discard(app,entry.id);}catch(Exception e){failure=e;}
                    final Exception error=failure;main.post(()->{
                        if(!canPresent())return;unlockActions();
                        if(error!=null)new AlertDialog.Builder(this).setTitle("Copy could not be removed")
                            .setMessage("Refresh the list and try again after any Gallery save has finished.").setPositiveButton("CLOSE",null).show();
                    });
                });
            }).show();
    }
    @Override protected void onDestroy(){
        destroyed=true;++generation;main.removeCallbacksAndMessages(null);
        // A publication already running must record its actual result even after this screen closes.
        worker.shutdown();super.onDestroy();
    }
}
