package com.sentongoharuna.worldsituationroom;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Build;
import android.os.SystemClock;
import android.view.View;
import android.widget.TextView;
import java.lang.ref.WeakReference;

/** One solid-colour, lifecycle-aware lamp used by all native sector indicators.
 * Static legends/history never blink. Live sectors read existing receipt state.
 * No animation runs while the owning window is hidden or system motion is off.
 */
public class Duwm1728StatusLampView extends View {
    private final Paint ink = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Duwm1724SignalFlow.Stage stage = Duwm1724SignalFlow.Stage.UNKNOWN;
    private int sector = -1, channel, staticColor = DuwmUnifiedTheme.STATUS_UNKNOWN;
    private boolean animateStatus, bound, motionAllowed = true;
    private long nextRead;
    private WeakReference<TextView> label = new WeakReference<>(null);
    private final Runnable frame = () -> {
        if (isAttachedToWindow() && isShown() && getWindowVisibility() == VISIBLE) invalidate();
    };
    public Duwm1728StatusLampView(Context context) {
        super(context);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);
        setFocusable(false);
        // No translucent View alpha and no white stroke over the coloured core.
        setAlpha(1f);
    }
    public void showStaticColor(int color, String description) {
        bound = false; sector = -1; animateStatus = false; staticColor = color;
        stage = Duwm1728SignalMotion.fromColor(color);
        setContentDescription(description); removeCallbacks(frame); invalidate();
    }
    public void setStage(Duwm1724SignalFlow.Stage value, int key, boolean animate) {
        Duwm1724SignalFlow.Stage safe = value == null ? Duwm1724SignalFlow.Stage.UNKNOWN : value;
        boolean changed = stage != safe || channel != key || animateStatus != animate;
        stage = safe; channel = key; staticColor = stage.color; animateStatus = animate;
        if (changed) invalidate();
    }
    public void bindSector(int index) {
        if (index < 0 || index >= Duwm1683DeskCatalog.ALL.length) return;
        sector = index; bound = true; nextRead = 0L; refreshSource(); invalidate();
    }
    public void bindLabel(TextView text) { label = new WeakReference<>(text); nextRead = 0L; invalidate(); }
    private void refreshSource() {
        if (!bound) return;
        setStage(Duwm1715SignalLights.stageFor(getContext(), sector), sector, true);
        String name = Duwm1683DeskCatalog.ALL[sector].title;
        setContentDescription(name + ": " + stage.label +
                ". Blink describes source state; only cyan marks a new receipt.");
        TextView text = label.get();
        if (text != null) { text.setText(stage.label); text.setTextColor(stage.color); }
    }
    static boolean systemMotionEnabled() {
        return Build.VERSION.SDK_INT < 26 || ValueAnimator.areAnimatorsEnabled();
    }
    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow(); nextRead = 0L; invalidate();
    }
    @Override protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        if (frame == null) return; // View's constructor can dispatch this callback.
        removeCallbacks(frame);
        if (visibility == VISIBLE) { nextRead = 0L; invalidate(); }
    }
    @Override protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        if (frame == null) return;
        removeCallbacks(frame);
        if (visibility == VISIBLE) { nextRead = 0L; invalidate(); }
    }
    @Override protected void onDetachedFromWindow() {
        removeCallbacks(frame); super.onDetachedFromWindow();
    }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        long now = SystemClock.uptimeMillis();
        if (now >= nextRead) {
            refreshSource(); motionAllowed = systemMotionEnabled(); nextRead = now + 2_000L;
        }
        boolean active = animateStatus && motionAllowed;
        drawLampFrame(canvas,now,active);
        removeCallbacks(frame);
        if (isAttachedToWindow() && isShown() && getWindowVisibility() == VISIBLE) {
            // Low-cost repaint, no Animator reset and no network operation per frame.
            if (active && Duwm1728SignalMotion.moves(stage)) postDelayed(frame, 80L);
            else if (bound || animateStatus) postDelayed(frame, 2_000L);
        }
    }
    /** Same drawing path used on screen and by the Android pixel regression test. */
    void drawLampFrame(Canvas canvas,long now,boolean active) {
        float brightness = Duwm1728SignalMotion.brightness(stage, now, channel, active);
        float radius = Math.min(getWidth(), getHeight()) * .39f;
        float x = getWidth() / 2f, y = getHeight() / 2f;
        ink.setShader(null); ink.clearShadowLayer(); ink.setAlpha(255);
        if (stage == Duwm1724SignalFlow.Stage.LOCAL) {
            // A hollow neutral ring cannot be mistaken for a white LIVE light.
            ink.setStyle(Paint.Style.STROKE);
            ink.setStrokeWidth(Math.max(1f, radius * .25f));
            ink.setColor(DuwmUnifiedTheme.LOCAL_SIGNAL);
            canvas.drawCircle(x, y, radius * .82f, ink);
        } else {
            ink.setStyle(Paint.Style.FILL);
            ink.setColor(Duwm1728SignalMotion.solidColor(staticColor, brightness));
            canvas.drawCircle(x, y, radius, ink);
        }
    }

}
