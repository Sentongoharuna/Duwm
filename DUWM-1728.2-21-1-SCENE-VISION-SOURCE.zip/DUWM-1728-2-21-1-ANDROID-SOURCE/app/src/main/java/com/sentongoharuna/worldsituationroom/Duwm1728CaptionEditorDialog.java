package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;

/** Transactional source-time caption correction. No draft changes occur until APPLY. */
public final class Duwm1728CaptionEditorDialog extends Dialog {
    public interface Listener {
        boolean canEdit();
        long playheadMs();
        boolean preview(long sourceMs,List<Duwm1728BroadcastLayout.Cue> captions);
        void resumed();
        boolean apply(List<Duwm1728BroadcastLayout.Cue> captions);
        void closed();
    }
    private static final int NAVY=0xFF041424,WHITE=0xFFF5F7FA,SILVER=0xFFDEE5EF,GREEN=0xFF00C853;
    private final Activity owner;
    private final Listener listener;
    private final long durationMs,trimFromMs,trimToMs;
    private List<Duwm1728BroadcastLayout.Cue> working;
    private AlertDialog cueDialog;
    private TextView summary,notice,childPlayhead;
    private CueAdapter adapter;
    private boolean previewing,resumeChild;

    public Duwm1728CaptionEditorDialog(Activity owner,List<Duwm1728BroadcastLayout.Cue> captions,
            long durationMs,long trimFromMs,long trimToMs,Listener listener) {
        super(owner,android.R.style.Theme_Material_NoActionBar);
        this.owner=owner;this.listener=listener;this.durationMs=durationMs;
        this.trimFromMs=trimFromMs;this.trimToMs=trimToMs;
        working=Duwm1728CaptionEditPolicy.copyAndValidate(captions,durationMs);
        setOwnerActivity(owner);setCanceledOnTouchOutside(false);
        setOnDismissListener(dialog->listener.closed());
    }
    private int dp(int value){return Math.round(value*getContext().getResources().getDisplayMetrics().density);}
    private TextView text(String value,int size){TextView view=new TextView(getContext());view.setText(value);view.setTextColor(WHITE);view.setTextSize(size);view.setPadding(dp(10),dp(5),dp(10),dp(5));return view;}
    private TextView button(String value,String tag,Runnable action){
        TextView view=text(value,12);view.setTag(tag);view.setGravity(Gravity.CENTER);view.setMinHeight(dp(48));view.setMaxLines(2);view.setTypeface(null,Typeface.BOLD);view.setFocusable(true);
        GradientDrawable background=new GradientDrawable();background.setColor(0xFF081B2B);background.setCornerRadius(dp(8));background.setStroke(Math.max(1,dp(1)),SILVER);view.setBackground(background);
        view.setOnClickListener(v->{if(ready())action.run();});
        view.setAccessibilityDelegate(new View.AccessibilityDelegate(){@Override public void onInitializeAccessibilityNodeInfo(View host,android.view.accessibility.AccessibilityNodeInfo info){super.onInitializeAccessibilityNodeInfo(host,info);info.setClassName("android.widget.Button");}});
        return view;
    }
    private LinearLayout column(){LinearLayout view=new LinearLayout(getContext());view.setOrientation(LinearLayout.VERTICAL);return view;}
    private LinearLayout.LayoutParams cell(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(dp(3),dp(3),dp(3),dp(3));return p;}
    private static String time(long value){return Duwm1728CaptionEditPolicy.formatTime(value);}
    private long playhead(){return Math.max(0,Math.min(durationMs,listener.playheadMs()));}
    private boolean ready(){if(owner.isFinishing()||owner.isDestroyed()||!listener.canEdit()){dismiss();return false;}return true;}
    public boolean isPreviewing(){return previewing;}

    @Override protected void onCreate(Bundle saved){
        super.onCreate(saved);Window window=getWindow();
        if(window!=null){window.setBackgroundDrawable(new ColorDrawable(NAVY));window.setStatusBarColor(NAVY);window.setNavigationBarColor(NAVY);window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
            if(Build.VERSION.SDK_INT>=30)window.setDecorFitsSystemWindows(false);
            else window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        LinearLayout page=column();page.setTag("caption-edit-root");page.setBackgroundColor(NAVY);
        TextView heading=text("CAPTIONS",18);heading.setTypeface(null,Typeface.BOLD);heading.setMinHeight(dp(48));heading.setGravity(Gravity.CENTER_VERTICAL);heading.setMaxLines(1);page.addView(heading,new LinearLayout.LayoutParams(-1,-2));
        summary=text("",12);summary.setTag("caption-edit-summary");summary.setTextColor(SILVER);summary.setMaxLines(3);summary.setEllipsize(TextUtils.TruncateAt.END);page.addView(summary,new LinearLayout.LayoutParams(-1,-2));
        FrameLayout middle=new FrameLayout(getContext());page.addView(middle,new LinearLayout.LayoutParams(-1,0,1));
        ListView list=new ListView(getContext());list.setTag("caption-edit-list");list.setContentDescription("Source-time captions, including cues outside the selected clip");list.setDivider(new ColorDrawable(0xFF425163));list.setDividerHeight(dp(1));list.setClipToPadding(false);list.setPadding(dp(6),0,dp(6),dp(4));
        adapter=new CueAdapter();list.setAdapter(adapter);middle.addView(list,new FrameLayout.LayoutParams(-1,-1));
        TextView empty=text("No captions. Add one at the playhead.",14);empty.setGravity(Gravity.CENTER);middle.addView(empty,new FrameLayout.LayoutParams(-1,-1));list.setEmptyView(empty);
        notice=text("",12);notice.setTag("caption-edit-error");notice.setTextColor(0xFFFFB300);notice.setVisibility(View.GONE);page.addView(notice,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout actions=new LinearLayout(getContext());actions.setPadding(dp(3),0,dp(3),dp(4));
        actions.addView(button("ADD AT PLAYHEAD","caption-edit-add",()->openCue(-1)),cell());
        TextView apply=button("APPLY","caption-edit-apply",()->{
            try{List<Duwm1728BroadcastLayout.Cue> checked=Duwm1728CaptionEditPolicy.copyAndValidate(working,durationMs);if(listener.apply(checked))dismiss();}
            catch(IllegalArgumentException invalid){showError(invalid.getMessage());}
        });apply.setTextColor(GREEN);actions.addView(apply,cell());actions.addView(button("CANCEL","caption-edit-cancel",this::cancel),cell());page.addView(actions,new LinearLayout.LayoutParams(-1,-2));
        // Dialogs have their own window: the application's Activity shell cannot
        // apply its insets here. Include all sides, cutouts and the on-screen IME.
        page.setOnApplyWindowInsetsListener((view,insets)->{
            int left,top,right,bottom;
            if(Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()|WindowInsets.Type.ime());left=bars.left;top=bars.top;right=bars.right;bottom=bars.bottom;}
            else{left=insets.getSystemWindowInsetLeft();top=insets.getSystemWindowInsetTop();right=insets.getSystemWindowInsetRight();bottom=insets.getSystemWindowInsetBottom();
                if(Build.VERSION.SDK_INT>=28&&insets.getDisplayCutout()!=null){left=Math.max(left,insets.getDisplayCutout().getSafeInsetLeft());top=Math.max(top,insets.getDisplayCutout().getSafeInsetTop());right=Math.max(right,insets.getDisplayCutout().getSafeInsetRight());bottom=Math.max(bottom,insets.getDisplayCutout().getSafeInsetBottom());}}
            if(view.getPaddingLeft()!=left||view.getPaddingTop()!=top||view.getPaddingRight()!=right||view.getPaddingBottom()!=bottom)view.setPadding(left,top,right,bottom);
            return insets;
        });
        setContentView(page);page.requestApplyInsets();refreshPlayhead();
    }
    @Override public void show(){
        if(!ready())return;
        boolean returning=previewing;previewing=false;
        if(returning)listener.resumed();
        super.show();Window window=getWindow();if(window!=null)window.setLayout(-1,-1);
        refreshPlayhead();
        if(returning&&resumeChild&&cueDialog!=null)cueDialog.show();resumeChild=false;
    }
    @Override public void dismiss(){
        previewing=false;resumeChild=false;
        if(cueDialog!=null){AlertDialog child=cueDialog;cueDialog=null;child.dismiss();}
        super.dismiss();
    }
    @Override public void onBackPressed(){cancel();}
    public void refreshPlayhead(){
        if(summary!=null){String value=working.size()+" CUES  •  ORIGINAL VIDEO TIMES\nCLIP "+time(trimFromMs)+" – "+time(trimToMs)+"\nPLAYHEAD "+time(playhead());summary.setText(value);summary.setContentDescription(value+". Edits stay in this working copy until Apply. Cancel discards them.");}
        if(childPlayhead!=null)childPlayhead.setText("PLAYHEAD  "+time(playhead()));
    }
    private void showError(String message){if(notice!=null){notice.setText(message);notice.setVisibility(View.VISIBLE);notice.announceForAccessibility(message);}}
    private String trimStatus(Duwm1728BroadcastLayout.Cue cue){
        if(cue.endMs<=trimFromMs||cue.startMs>=trimToMs)return "OUTSIDE CLIP";
        return cue.startMs<trimFromMs||cue.endMs>trimToMs?"PARTLY IN CLIP":"IN CLIP";
    }
    private void changed(){adapter.notifyDataSetChanged();notice.setVisibility(View.GONE);refreshPlayhead();}
    private void remove(int index){
        try{working=Duwm1728CaptionEditPolicy.remove(working,index,durationMs);changed();}
        catch(IllegalArgumentException invalid){showError(invalid.getMessage());}
    }
    private void preview(long at,List<Duwm1728BroadcastLayout.Cue> captions){
        if(!ready())return;
        previewing=true;
        if(!listener.preview(at,captions)){previewing=false;return;}
        resumeChild=cueDialog!=null&&cueDialog.isShowing();
        Window focused=resumeChild?cueDialog.getWindow():getWindow();
        android.view.inputmethod.InputMethodManager keyboard=(android.view.inputmethod.InputMethodManager)getContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
        if(keyboard!=null&&focused!=null)keyboard.hideSoftInputFromWindow(focused.getDecorView().getWindowToken(),0);
        if(resumeChild)cueDialog.hide();hide();
    }
    private final class CueAdapter extends BaseAdapter {
        @Override public int getCount(){return working.size();}
        @Override public Duwm1728BroadcastLayout.Cue getItem(int position){return working.get(position);}
        @Override public long getItemId(int position){return position;}
        @Override public View getView(int index,View convert,ViewGroup parent){CueRow row=convert instanceof CueRow?(CueRow)convert:new CueRow();row.bind(index);return row;}
    }
    private final class CueRow extends LinearLayout {
        final TextView times,words,edit,preview,delete;
        int index;
        CueRow(){super(Duwm1728CaptionEditorDialog.this.getContext());setOrientation(VERTICAL);setPadding(0,dp(5),0,dp(5));
            times=text("",12);times.setTextColor(SILVER);times.setMaxLines(2);addView(times,new LinearLayout.LayoutParams(-1,-2));
            words=text("",14);words.setMaxLines(3);words.setEllipsize(TextUtils.TruncateAt.END);addView(words,new LinearLayout.LayoutParams(-1,-2));
            LinearLayout actions=new LinearLayout(getContext());
            edit=button("EDIT","",()->openCue(index));preview=button("PREVIEW","",()->{Duwm1728BroadcastLayout.Cue cue=working.get(index);Duwm1728CaptionEditorDialog.this.preview(cue.startMs,working);});delete=button("DELETE","",()->remove(index));
            actions.addView(edit,cell());actions.addView(preview,cell());actions.addView(delete,cell());addView(actions,new LinearLayout.LayoutParams(-1,-2));
            setOnClickListener(v->{if(ready())openCue(index);});
        }
        void bind(int position){index=position;Duwm1728BroadcastLayout.Cue cue=working.get(position);setTag("caption-edit-row-"+position);
            times.setText(time(cue.startMs)+" – "+time(cue.endMs)+"  •  "+trimStatus(cue));words.setText(cue.text);
            edit.setTag("caption-edit-edit-"+position);preview.setTag("caption-edit-preview-"+position);delete.setTag("caption-edit-delete-"+position);
            edit.setContentDescription("Edit caption "+(position+1)+". "+cue.text);preview.setContentDescription("Preview caption "+(position+1)+" at "+time(cue.startMs));delete.setContentDescription("Delete caption "+(position+1)+" from the working copy");
        }
    }
    private EditText input(String hint,String value,String tag,boolean multiline){
        EditText view=new EditText(getContext());view.setTag(tag);view.setHint(hint);view.setContentDescription(hint);view.setTextColor(WHITE);view.setHintTextColor(SILVER);view.setTextSize(14);view.setMinHeight(dp(48));
        view.setInputType(InputType.TYPE_CLASS_TEXT|(multiline?InputType.TYPE_TEXT_FLAG_MULTI_LINE:InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS));view.setSingleLine(!multiline);if(multiline){view.setMinLines(2);view.setMaxLines(5);}view.setText(value);return view;
    }
    private void openCue(int index){
        if(!ready()||cueDialog!=null)return;
        if(index<0&&working.size()>=Duwm1728CaptionEditPolicy.MAX_CUES){showError("Maximum 20000 caption cues");return;}
        Duwm1728BroadcastLayout.Cue cue=index<0?null:working.get(index);
        long start=cue==null?Math.min(durationMs-1,playhead()):cue.startMs;
        long end=cue==null?start+Math.min(2000,durationMs-start):cue.endMs;
        LinearLayout body=column();body.setBackgroundColor(NAVY);body.setPadding(dp(10),dp(4),dp(10),dp(8));
        TextView help=text("Original-video times • end is exclusive",12);help.setTextColor(SILVER);body.addView(help);
        childPlayhead=text("PLAYHEAD  "+time(playhead()),12);childPlayhead.setTag("caption-cue-playhead");childPlayhead.setTextColor(SILVER);body.addView(childPlayhead);
        EditText startInput=input("Start — HH:MM:SS.mmm",time(start),"caption-cue-start",false);
        EditText endInput=input("End — HH:MM:SS.mmm",time(end),"caption-cue-end",false);
        body.addView(startInput,new LinearLayout.LayoutParams(-1,-2));
        body.addView(button("MARK START AT PLAYHEAD","caption-cue-mark-start",()->{startInput.setText(time(playhead()));refreshPlayhead();}),new LinearLayout.LayoutParams(-1,-2));
        body.addView(endInput,new LinearLayout.LayoutParams(-1,-2));
        body.addView(button("MARK END AT PLAYHEAD","caption-cue-mark-end",()->{endInput.setText(time(playhead()));refreshPlayhead();}),new LinearLayout.LayoutParams(-1,-2));
        EditText words=input("Caption words",cue==null?"":cue.text,"caption-cue-text",true);body.addView(words,new LinearLayout.LayoutParams(-1,-2));
        TextView error=text("",12);error.setTag("caption-cue-error");error.setTextColor(0xFFFFB300);error.setVisibility(View.GONE);body.addView(error,new LinearLayout.LayoutParams(-1,-2));
        ScrollView scroll=new ScrollView(getContext()){@Override protected void onMeasure(int width,int height){
            int available=owner.getWindow().getDecorView().getHeight();if(available<=0)available=getContext().getResources().getDisplayMetrics().heightPixels;
            int limit=Math.max(dp(80),Math.round(available*.72f));if(View.MeasureSpec.getMode(height)!=View.MeasureSpec.UNSPECIFIED)limit=Math.min(limit,View.MeasureSpec.getSize(height));
            super.onMeasure(width,View.MeasureSpec.makeMeasureSpec(Math.max(1,limit),View.MeasureSpec.AT_MOST));
        }};scroll.setFillViewport(false);scroll.setBackgroundColor(NAVY);scroll.addView(body,new ScrollView.LayoutParams(-1,-2));
        TextView heading=text(index<0?"ADD CAPTION":"EDIT CAPTION",16);heading.setMinHeight(dp(48));heading.setTypeface(null,Typeface.BOLD);heading.setBackgroundColor(NAVY);
        final AlertDialog child=new AlertDialog.Builder(owner).setCustomTitle(heading).setView(scroll).create();
        body.addView(button("PREVIEW IN VIDEO","caption-cue-preview",()->{
            try{Duwm1728BroadcastLayout.Cue candidate=Duwm1728CaptionEditPolicy.cue(startInput.getText().toString(),endInput.getText().toString(),words.getText().toString(),durationMs);
                List<Duwm1728BroadcastLayout.Cue> snapshot=index<0?Duwm1728CaptionEditPolicy.add(working,candidate,durationMs):Duwm1728CaptionEditPolicy.replace(working,index,candidate,durationMs);
                preview(candidate.startMs,snapshot);
            }catch(IllegalArgumentException invalid){error.setText(invalid.getMessage());error.setVisibility(View.VISIBLE);error.announceForAccessibility(invalid.getMessage());}
        }),new LinearLayout.LayoutParams(-1,-2));
        LinearLayout actions=new LinearLayout(getContext());
        TextView save=button("SAVE CUE","caption-cue-save",()->{
            try{Duwm1728BroadcastLayout.Cue candidate=Duwm1728CaptionEditPolicy.cue(startInput.getText().toString(),endInput.getText().toString(),words.getText().toString(),durationMs);
                working=index<0?Duwm1728CaptionEditPolicy.add(working,candidate,durationMs):Duwm1728CaptionEditPolicy.replace(working,index,candidate,durationMs);changed();child.dismiss();
            }catch(IllegalArgumentException invalid){error.setText(invalid.getMessage());error.setVisibility(View.VISIBLE);error.announceForAccessibility(invalid.getMessage());}
        });save.setTextColor(GREEN);actions.addView(save,cell());
        if(index>=0)actions.addView(button("DELETE","caption-cue-delete",()->{remove(index);child.dismiss();}),cell());
        actions.addView(button("CANCEL","caption-cue-cancel",child::cancel),cell());body.addView(actions,new LinearLayout.LayoutParams(-1,-2));
        cueDialog=child;child.setCanceledOnTouchOutside(false);child.setOnDismissListener(dialog->{if(cueDialog==child){cueDialog=null;childPlayhead=null;resumeChild=false;}});
        child.show();if(child.getWindow()!=null){child.getWindow().setBackgroundDrawable(new ColorDrawable(NAVY));child.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);}
    }
}
