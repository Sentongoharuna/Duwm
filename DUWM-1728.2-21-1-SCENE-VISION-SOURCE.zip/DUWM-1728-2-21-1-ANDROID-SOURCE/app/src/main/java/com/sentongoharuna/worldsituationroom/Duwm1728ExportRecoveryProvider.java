package com.sentongoharuna.worldsituationroom;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

/** Private completed MP4s, accessible to other apps only through a temporary read grant. */
public final class Duwm1728ExportRecoveryProvider extends ContentProvider {
    @Override public boolean onCreate(){return true;}
    private void requireUri(Uri uri){if(getContext()==null||!Duwm1728ExportRecovery.isRecoveryUri(getContext(),uri))throw new IllegalArgumentException("Invalid recovery URI");}
    @Override public String getType(Uri uri){requireUri(uri);return "video/mp4";}
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sortOrder){
        requireUri(uri);
        try {
            Duwm1728ExportRecovery.Entry entry=Duwm1728ExportRecovery.find(getContext(),Duwm1728ExportRecovery.entryId(uri));
            if(entry==null||!entry.hasLocalCopy)return null;
            String[] columns=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;
            MatrixCursor cursor=new MatrixCursor(columns,1);MatrixCursor.RowBuilder row=cursor.newRow();
            for(String column:columns){if(OpenableColumns.DISPLAY_NAME.equals(column))row.add(entry.name);
                else if(OpenableColumns.SIZE.equals(column))row.add(entry.bytes);else row.add(null);}
            return cursor;
        }catch(IOException unavailable){return null;}
    }
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException {
        if(!"r".equals(mode))throw new FileNotFoundException("Recovery video provider is read only");
        try{requireUri(uri);File file=Duwm1728ExportRecovery.readableFile(getContext(),uri);return ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY);}
        catch(IOException|IllegalArgumentException unavailable){FileNotFoundException error=new FileNotFoundException("Private recovery MP4 is unavailable");error.initCause(unavailable);throw error;}
    }
    @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException("Read only");}
    @Override public int update(Uri uri,ContentValues values,String selection,String[] args){throw new UnsupportedOperationException("Read only");}
    @Override public int delete(Uri uri,String selection,String[] args){throw new UnsupportedOperationException("Read only");}
}
