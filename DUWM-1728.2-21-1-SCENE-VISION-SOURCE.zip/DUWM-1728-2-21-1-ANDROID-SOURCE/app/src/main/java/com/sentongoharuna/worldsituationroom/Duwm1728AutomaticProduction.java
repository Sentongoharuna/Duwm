package com.sentongoharuna.worldsituationroom;

import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Built-in editing policy. Speech recognition is separate and may be unavailable. */
public final class Duwm1728AutomaticProduction {
    public static final String PREFS="duwm_automatic_production";
    public static final long SPEECH_CHUNK_MS=45000;
    public static final String RECORDED_SPEECH="RECORDED_SPEECH",CAPTURE_NOTES="CAPTURE_NOTES",NEUTRAL="NEUTRAL";
    public static final int HEADLINE_EXCERPT_LIMIT=48,TICKER_TEXT_LIMIT=120;
    private static final String WORDS_LABEL="SOURCE WORDS • ",NOTES_LABEL="SOURCE NOTES • ";
    private static final String NEUTRAL_DESCRIPTION="RECORDED VIDEO • SOURCE FOOTAGE";
    private Duwm1728AutomaticProduction() {}

    public static boolean shouldStart(boolean freshCapture,boolean enabled,boolean attempted,
                                      boolean savedOutput,boolean existingDraft,boolean unavailable) {
        return freshCapture&&enabled&&!attempted&&!savedOutput&&!existingDraft&&!unavailable;
    }
    public static String receiptKey(String sourceKey) {
        if(sourceKey==null||sourceKey.isEmpty())throw new IllegalArgumentException("Recording identity is missing");
        return "attempt_"+sourceKey;
    }
    public static long chunkEnd(long start,long duration) {
        if(start<0||duration<=start)throw new IllegalArgumentException("Invalid speech range");
        return duration-start>SPEECH_CHUNK_MS?start+SPEECH_CHUNK_MS:duration;
    }
    public static final class Plan {
        public final long fromMs,toMs;
        public final String title,description,ratio,frameMode,composition,provenance,captionStatus;
        /** Source document metadata belongs in the evidence/UI, never in the burned ticker. */
        public final String contentSource,sourceEvidence,sourceNotes;
        public final long headlineSourceStartMs,headlineSourceEndMs;
        public final int sourceCueCount,tickerExcerptCount,tickerOmittedCount;
        /** All source captions and separate display excerpts, both in original-source milliseconds. */
        public final List<Duwm1728BroadcastLayout.Cue> cues,tickers;
        private Plan(long duration,List<Duwm1728BroadcastLayout.Cue> captions,String status,String captureNotes) {
            fromMs=0;toMs=duration;ratio="ORIGINAL";frameMode=Duwm1728FramePlan.FIT;
            composition=Duwm1728BroadcastComposition.COMPACT;
            cues=Collections.unmodifiableList(Duwm1728CaptionEditPolicy.copyAndValidate(captions,duration));
            captionStatus=status==null?"":status;
            provenance=cues.isEmpty()?"AUTO-EDITED • UNVERIFIED":"AUTO-CAPTIONS • UNREVIEWED";
            sourceNotes=captureNotes==null?"":captureNotes;
            sourceCueCount=cues.size();
            ArrayList<Duwm1728BroadcastLayout.Cue> excerpts=new ArrayList<>();
            String headline="";long headlineStart=-1,headlineEnd=-1;int omitted=0;
            Duwm1728BroadcastLayout.Cue previousSource=null;
            for(Duwm1728BroadcastLayout.Cue cue:cues){
                if(headline.isEmpty()){
                    String candidate=excerpt(cue.text,HEADLINE_EXCERPT_LIMIT);
                    if(!candidate.isEmpty()){headline=WORDS_LABEL+candidate;headlineStart=cue.startMs;headlineEnd=cue.endMs;}
                }
                String body=excerpt(cue.text,TICKER_TEXT_LIMIT-WORDS_LABEL.length());
                if(body.isEmpty()){omitted++;previousSource=null;continue;}
                String text=WORDS_LABEL+body;
                Duwm1728BroadcastLayout.Cue previous=excerpts.isEmpty()?null:excerpts.get(excerpts.size()-1);
                // Repeated recognition on adjoining intervals need not restart the
                // same ticker. Never bridge a source gap or merge differing source text.
                if(previous!=null&&previousSource!=null&&previousSource.text.equals(cue.text)
                        &&previous.text.equals(text)&&cue.startMs<=previous.endMs){
                    excerpts.set(excerpts.size()-1,new Duwm1728BroadcastLayout.Cue(previous.startMs,
                            Math.max(previous.endMs,cue.endMs),text));
                }else excerpts.add(new Duwm1728BroadcastLayout.Cue(cue.startMs,cue.endMs,text));
                previousSource=cue;
            }
            tickers=Collections.unmodifiableList(excerpts);tickerExcerptCount=tickers.size();tickerOmittedCount=omitted;
            headlineSourceStartMs=headlineStart;headlineSourceEndMs=headlineEnd;
            if(!cues.isEmpty()){
                contentSource=RECORDED_SPEECH;title=headline.isEmpty()?"RECORDED REPORT":headline;
                // In gaps, a neutral line avoids displaying a later source phrase early.
                description=NEUTRAL_DESCRIPTION;
                sourceEvidence="Validated caption document: "+sourceCueCount+" original cues retained; "
                        +tickerExcerptCount+" source-time ticker excerpts; "+tickerOmittedCount
                        +" indivisible overlong excerpts omitted from ticker only; "+(sourceCueCount-tickerExcerptCount-tickerOmittedCount)
                        +" adjacent identical source cues coalesced in ticker only. Headline source interval: "
                        +headlineSourceStartMs+".."+headlineSourceEndMs+" ms. Excerpts are source words, not fact-checked summaries. "
                        +"Caption timing status: "+captionStatus;
            }else{
                String notes=Duwm1728BroadcastLayout.clean(sourceNotes,Integer.MAX_VALUE);
                String noteHeadline=excerpt(notes,HEADLINE_EXCERPT_LIMIT);
                String noteTicker=excerpt(notes,TICKER_TEXT_LIMIT-NOTES_LABEL.length());
                if(!noteHeadline.isEmpty()||!noteTicker.isEmpty()){
                    contentSource=CAPTURE_NOTES;
                    title=noteHeadline.isEmpty()?"RECORDED REPORT":NOTES_LABEL+noteHeadline;
                    description=noteTicker.isEmpty()?NEUTRAL_DESCRIPTION:NOTES_LABEL+noteTicker;
                    sourceEvidence="Capture notes supplied with this recording; explicitly labelled source-note excerpts. "
                            +"No speech or source timestamps are inferred from notes. Full original notes retained separately.";
                }else{
                    contentSource=NEUTRAL;title="RECORDED REPORT";description=NEUTRAL_DESCRIPTION;
                    sourceEvidence="Neutral recorded-report presentation; no usable timed speech or short source-note excerpt. "
                            +"No event, location, category or speech is inferred.";
                }
            }
        }
    }
    /** A contiguous prefix, marked when shortened. Word boundaries preserve whole
     * words; Unicode line boundaries also permit natural CJK excerpts. An indivisible
     * overlong token stays in the full caption document instead of becoming a fake word. */
    private static String excerpt(String source,int maximum){
        String text=source==null?"":source.trim();if(text.length()<=maximum)return text;
        int limit=maximum-1,end=0;
        BreakIterator words=BreakIterator.getWordInstance(Locale.ROOT);words.setText(text);
        for(int boundary=words.first();boundary!=BreakIterator.DONE&&boundary<=limit;boundary=words.next())
            if(boundary>0&&safeBoundary(text,boundary))end=boundary;
        // Some word iterators treat a run of ideographs as one word. Line breaks
        // between ideographs are valid readable boundaries, never mid-surrogate.
        BreakIterator lines=BreakIterator.getLineInstance(Locale.ROOT);lines.setText(text);
        for(int boundary=lines.first();boundary!=BreakIterator.DONE&&boundary<=limit;boundary=lines.next())
            if(boundary>end&&boundary>0&&Character.isIdeographic(text.codePointBefore(boundary))&&safeBoundary(text,boundary))end=boundary;
        String prefix=text.substring(0,end).trim();return prefix.isEmpty()?"":prefix+"…";
    }
    private static boolean safeBoundary(String text,int end){
        if(end<=0||end>=text.length())return end==text.length();
        if(Character.isHighSurrogate(text.charAt(end-1))||Character.isLowSurrogate(text.charAt(end)))return false;
        int before=text.codePointBefore(end),after=text.codePointAt(end),type=Character.getType(after);
        if(before==0x200D||after==0x200D||type==Character.NON_SPACING_MARK||type==Character.COMBINING_SPACING_MARK
                ||type==Character.ENCLOSING_MARK||(after>=0x1F3FB&&after<=0x1F3FF))return false;
        if(before>=0x1F1E6&&before<=0x1F1FF&&after>=0x1F1E6&&after<=0x1F1FF){
            int count=0;for(int index=end;index>0;){int cp=text.codePointBefore(index);if(cp<0x1F1E6||cp>0x1F1FF)break;count++;index-=Character.charCount(cp);}
            if((count&1)!=0)return false;
        }
        return true;
    }
    /** Full source and original aspect retain visual context; no events, places or speech are invented. */
    public static Plan plan(long duration,List<Duwm1728BroadcastLayout.Cue> captions,String status) {
        return plan(duration,captions,status,"");
    }
    public static Plan plan(long duration,List<Duwm1728BroadcastLayout.Cue> captions,String status,String captureNotes) {
        if(duration<1||duration>Integer.MAX_VALUE)throw new IllegalArgumentException("Unsupported recording duration");
        if(captions==null)throw new IllegalArgumentException("Captions are missing");
        return new Plan(duration,captions,status,captureNotes);
    }
}
