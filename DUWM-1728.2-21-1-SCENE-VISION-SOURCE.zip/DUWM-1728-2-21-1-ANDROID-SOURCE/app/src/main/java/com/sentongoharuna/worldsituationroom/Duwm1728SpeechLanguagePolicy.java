package com.sentongoharuna.worldsituationroom;

import java.util.List;
import java.util.Locale;
import java.util.TreeSet;

/** Pure installed-model selection and bounded support-query policy. It never
 * starts a recognizer, downloads a model or infers transcription accuracy.
 * The Android caller supplies the platform's likely-script resolver; an unknown
 * script permits an exact tag only, never a guessed language fallback. */
public final class Duwm1728SpeechLanguagePolicy {
    private Duwm1728SpeechLanguagePolicy(){}
    public static final String INSTALLED="INSTALLED",PENDING="PENDING",DOWNLOADABLE="DOWNLOADABLE",
            UNAVAILABLE="UNAVAILABLE",INDETERMINATE="INDETERMINATE",CONFIRMED="CONFIRMED";
    private static final int MAX_MODELS=1024;
    public interface ScriptResolver {String script(String languageTag);}
    public enum Action {CHECK,READY,FAILED,IGNORE}

    public static final class Choice {
        public final String requestedLanguage,selectedLanguage,status;
        private Choice(String requested,String selected,String status){
            requestedLanguage=requested;selectedLanguage=selected;this.status=status;
        }
    }
    public static final class Decision {
        public final Action action;
        public final int checkNumber;
        public final String requestedLanguage,selectedLanguage,status,recordingSupport,message;
        private Decision(Action action,int check,String requested,String selected,String status,String support,String message){
            this.action=action;checkNumber=check;requestedLanguage=requested;selectedLanguage=selected;
            this.status=status;recordingSupport=support;this.message=message;
        }
    }

    /** BCP-47 language/script/region/variant tags only. Extensions and private
     * use are not model identities. Locale.Builder rejects truncated parses. */
    public static String normalize(String value){
        if(value==null)return "";
        String tag=value.trim().replace('_','-');
        if(tag.length()<2||tag.length()>64||!tag.matches("[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*"))return "";
        try{
            Locale locale=new Locale.Builder().setLanguageTag(tag).build();
            String language=locale.getLanguage();
            if(language.isEmpty()||"und".equals(language)||"mul".equals(language)||"zxx".equals(language)
                    ||"mis".equals(language)||!locale.getExtensionKeys().isEmpty())return "";
            return locale.toLanguageTag();
        }catch(IllegalArgumentException invalid){return "";}
    }
    private static TreeSet<String> normalized(List<String> values){
        TreeSet<String> result=new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        if(values!=null)for(String value:values){String tag=normalize(value);if(!tag.isEmpty())result.add(tag);}
        return result;
    }
    private static boolean oversized(List<String> values){return values!=null&&values.size()>MAX_MODELS;}
    private static String script(String tag,ScriptResolver resolver){
        String explicit=Locale.forLanguageTag(tag).getScript();
        if(!explicit.isEmpty())return usableScript(explicit);
        if(resolver==null)return "";
        try{return usableScript(resolver.script(tag));}
        catch(RuntimeException unavailable){return "";}
    }
    private static String usableScript(String value){
        return value!=null&&value.matches("[A-Za-z]{4}")&&!"Zzzz".equalsIgnoreCase(value)
                &&!"Zyyy".equalsIgnoreCase(value)&&!"Zinh".equalsIgnoreCase(value)?value:"";
    }
    private static boolean compatible(String requested,String candidate,ScriptResolver resolver){
        Locale a=Locale.forLanguageTag(requested),b=Locale.forLanguageTag(candidate);
        if(!a.getLanguage().equals(b.getLanguage()))return false;
        String x=script(requested,resolver),y=script(candidate,resolver);
        return !x.isEmpty()&&x.equalsIgnoreCase(y);
    }
    private static String best(String requested,List<String> values,ScriptResolver resolver){
        TreeSet<String> tags=normalized(values);
        if(tags.contains(requested))return requested;
        String primary=Locale.forLanguageTag(requested).getLanguage();
        if(tags.contains(primary)&&compatible(requested,primary,resolver))return primary;
        // Stable lexical tie-break, independent of the service's list ordering.
        // A regional fallback is a model choice, never detected spoken language.
        for(String tag:tags)if(compatible(requested,tag,resolver))return tag;
        return "";
    }
    public static Choice choose(String requested,List<String> installed,List<String> pending,
                                List<String> downloadable,ScriptResolver resolver){
        String tag=normalize(requested);
        if(tag.isEmpty()||oversized(installed)||oversized(pending)||oversized(downloadable))
            return new Choice(tag,"",INDETERMINATE);
        String selected=best(tag,installed,resolver);
        if(!selected.isEmpty())return new Choice(tag,selected,INSTALLED);
        selected=best(tag,pending,resolver);
        if(!selected.isEmpty())return new Choice(tag,selected,PENDING);
        selected=best(tag,downloadable,resolver);
        return new Choice(tag,selected,selected.isEmpty()?UNAVAILABLE:DOWNLOADABLE);
    }

    /** One initial exact-intent query and, only for a changed tag, one final
     * exact-intent query. Results from an older query or a terminal flow are
     * ignored. All methods are owned by the caller's UI thread. */
    public static final class SupportFlow {
        private final String requested;
        private final ScriptResolver scripts;
        private String selected="",status=INDETERMINATE;
        private int activeCheck;
        private boolean terminal;
        public SupportFlow(String requested,ScriptResolver scripts){this.requested=normalize(requested);this.scripts=scripts;}
        private Decision decision(Action action,String support,String message){
            return new Decision(action,activeCheck,requested,selected,status,support,message);
        }
        public Decision begin(){
            if(terminal||activeCheck!=0)return decision(Action.IGNORE,INDETERMINATE,"This support query is already in use");
            if(requested.isEmpty()){terminal=true;return decision(Action.FAILED,INDETERMINATE,"The device language is not a usable speech-model tag");}
            activeCheck=1;selected=requested;
            return decision(Action.CHECK,INDETERMINATE,"Checking installed captions for "+requested);
        }
        public Decision support(int check,List<String> installed,List<String> pending,List<String> downloadable){
            if(terminal||check!=activeCheck||check==0)return decision(Action.IGNORE,INDETERMINATE,"Stale support result ignored");
            if(activeCheck==1){
                Choice choice=choose(requested,installed,pending,downloadable,scripts);
                selected=choice.selectedLanguage;status=choice.status;
                if(INSTALLED.equals(status)){
                    if(!selected.equals(requested)){
                        activeCheck=2;
                        return decision(Action.CHECK,INDETERMINATE,"Checking installed "+selected+" for device language "+requested+" (same-language model)");
                    }
                    return ready();
                }
            }else{
                // The final selected tag must itself be reported installed.
                // No third candidate, alias chase or fallback query is allowed.
                if(oversized(installed)||oversized(pending)||oversized(downloadable))status=INDETERMINATE;
                else if(normalized(installed).contains(selected)){status=INSTALLED;return ready();}
                else if(normalized(pending).contains(selected))status=PENDING;
                else if(normalized(downloadable).contains(selected))status=DOWNLOADABLE;
                else status=UNAVAILABLE;
            }
            terminal=true;
            String note;
            if(PENDING.equals(status))note=selected+" is scheduled for download and is not installed";
            else if(DOWNLOADABLE.equals(status))note=selected+" is available to download but is not installed";
            else if(INDETERMINATE.equals(status))note="The service did not provide a usable model inventory";
            else note=activeCheck==2?"The service did not confirm installed "+selected+" for the final recorded-file request"
                    :"No compatible installed, pending or downloadable speech model was reported for "+requested;
            return decision(Action.FAILED,INDETERMINATE.equals(status)?INDETERMINATE:UNAVAILABLE,
                    note+". Automatic video can finish without captions; no model download was requested.");
        }
        private Decision ready(){
            terminal=true;status=INSTALLED;
            return decision(Action.READY,CONFIRMED,"The phone service reports installed "+selected
                    +" support for this recorded-file request. This check does not verify transcription or word timing accuracy.");
        }
        public Decision error(int check,String reason){
            if(terminal||activeCheck==0||check!=activeCheck)return decision(Action.IGNORE,INDETERMINATE,"Stale support failure ignored");
            terminal=true;
            if(activeCheck==1)selected=""; // No inventory ever selected a model.
            return decision(Action.FAILED,INDETERMINATE,reason);
        }
        public void cancel(){terminal=true;}
        public int checkNumber(){return activeCheck;}
    }
}
