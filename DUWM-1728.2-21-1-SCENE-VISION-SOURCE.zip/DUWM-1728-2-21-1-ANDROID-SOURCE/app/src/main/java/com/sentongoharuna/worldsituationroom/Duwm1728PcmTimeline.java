package com.sentongoharuna.worldsituationroom;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.io.OutputStream;

/** A fixed source-time 16 kHz mono grid. Missing source intervals remain silence.
 * Samples use a zero-order hold; this is a timing-preserving speech conversion,
 * not a claim of mastering-quality filtering. Decoder packet boundaries do not
 * restart the output clock or shorten fractional-rate recordings.
 */
public final class Duwm1728PcmTimeline {
    public static final int OUTPUT_RATE=16000;
    public static final long MAX_DURATION_MS=45000;
    private final long fromUs;
    private final short[] grid;
    private long runStartUs,runFrames,lastPacketUs=Long.MIN_VALUE;
    private int runRate,lastWritten,covered;
    private boolean sealed;

    public Duwm1728PcmTimeline(long fromMs,long toMs){
        if(fromMs<0||toMs<=fromMs||toMs-fromMs>MAX_DURATION_MS||toMs>Long.MAX_VALUE/1000)
            throw new IllegalArgumentException("Choose an audio range of at most 45 seconds");
        fromUs=fromMs*1000;grid=new short[(int)((toMs-fromMs)*16)];
    }
    public int sampleCount(){return grid.length;}
    public int coveredSampleCount(){return covered;}

    /** Adds an ordered decoded PCM packet at its actual source presentation time. */
    public void accept(long packetUs,int rate,short[] mono){
        if(sealed)throw new IllegalStateException("PCM timeline has already been written");
        if(rate<8000||rate>192000||mono==null)throw new IllegalArgumentException("Invalid decoded PCM packet");
        if(packetUs<lastPacketUs)throw new IllegalArgumentException("Decoded audio timestamps moved backwards");
        lastPacketUs=packetUs;if(mono.length==0)return;
        try {
            boolean contiguous=false;
            if(runRate==rate){
                long error=Math.subtractExact(Math.multiplyExact(Math.subtractExact(packetUs,runStartUs),rate),Math.multiplyExact(runFrames,1000000L));
                // Codec timestamps have microsecond precision. Keep the exact input
                // frame clock when only that rounding separates adjacent packets.
                contiguous=error>=-rate&&error<=rate;
            }
            if(!contiguous){runStartUs=packetUs;runFrames=0;runRate=rate;}
            long offset=Math.subtractExact(runStartUs,fromUs),firstFrame=runFrames;
            runFrames=Math.addExact(runFrames,mono.length);
            long start=Math.addExact(Math.multiplyExact(offset,rate),Math.multiplyExact(firstFrame,1000000L));
            long end=Math.addExact(Math.multiplyExact(offset,rate),Math.multiplyExact(runFrames,1000000L));
            long denominator=rate*1000000L;
            long first=ceil(Math.multiplyExact(start,OUTPUT_RATE),denominator);
            long until=ceil(Math.multiplyExact(end,OUTPUT_RATE),denominator);
            int a=(int)Math.max(lastWritten,Math.max(0,Math.min(grid.length,first)));
            int b=(int)Math.max(0,Math.min(grid.length,until));
            for(int i=a;i<b;i++){
                long relative=Math.subtractExact(i*1000000L,Math.multiplyExact(offset,OUTPUT_RATE));
                long sourceIndex=Math.multiplyExact(relative,rate)/(OUTPUT_RATE*1000000L)-firstFrame;
                if(sourceIndex<0||sourceIndex>=mono.length)throw new IllegalArgumentException("Decoded PCM packet does not cover the output grid");
                grid[i]=mono[(int)sourceIndex];covered++;
            }
            lastWritten=Math.max(lastWritten,b);
        }catch(ArithmeticException invalid){throw new IllegalArgumentException("Decoded audio timestamp overflow",invalid);}
    }
    private static long ceil(long value,long divisor){long quotient=value/divisor;return value%divisor>0?quotient+1:quotient;}

    /** Writes exactly durationMs * 16 samples, including leading/internal/trailing gaps. */
    public void writeTo(OutputStream output)throws IOException{
        if(output==null)throw new IllegalArgumentException("An audio output stream is required");
        sealed=true;byte[] block=new byte[8192];int used=0;
        for(short value:grid){
            if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Recorded-audio conversion cancelled");
            block[used++]=(byte)(value&255);block[used++]=(byte)((value>>>8)&255);
            if(used==block.length){output.write(block,0,used);used=0;}
        }
        if(used>0)output.write(block,0,used);output.flush();
    }
}
