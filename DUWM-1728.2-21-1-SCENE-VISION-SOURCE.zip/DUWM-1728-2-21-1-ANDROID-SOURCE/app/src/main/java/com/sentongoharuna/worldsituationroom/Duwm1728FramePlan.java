package com.sentongoharuna.worldsituationroom;

import java.util.Locale;

/** One source-to-output framing contract for preview and GPU encoding.
 * Coordinates are normalised in the UPRIGHT image, with a top-left origin.
 * FILL removes only the chosen crop. FIT preserves the whole source with navy bars.
 * Neither mode stretches source pixels or enlarges them above their captured size.
 */
public final class Duwm1728FramePlan {
    public static final String FIT="FIT", FILL="FILL";
    private Duwm1728FramePlan() {}
    public static void validate(String mode,float x,float y){
        if(!FIT.equals(mode)&&!FILL.equals(mode))throw new IllegalArgumentException("Unknown framing mode");
        if(Float.isNaN(x)||Float.isInfinite(x)||Float.isNaN(y)||Float.isInfinite(y)||x<0||x>1||y<0||y>1)
            throw new IllegalArgumentException("Framing position must be between 0 and 1");
    }
    public static final class Plan {
        public final String mode;
        public final float x,y,w,h,left,top,width,height,anchorX,anchorY;
        private Plan(String mode,float x,float y,float w,float h,float left,float top,float width,float height,float ax,float ay){
            this.mode=mode;this.x=x;this.y=y;this.w=w;this.h=h;
            this.left=left;this.top=top;this.width=width;this.height=height;anchorX=ax;anchorY=ay;
        }
        public float scaleX(){return width/w;}
        public float scaleY(){return height/h;}
        public float translateX(){return left-x*scaleX();}
        public float translateY(){return top-y*scaleY();}
        /** Source area removed, not percentage of video quality or encoded pixels. */
        public int croppedPercent(){return Math.round(100*(1-w*h));}
        public String describe(){
            if(FIT.equals(mode))return "KEEP FULL PICTURE • no source crop; navy bars where needed";
            return String.format(Locale.ROOT,"FILL FRAME • %d%% source-area crop • position %.0f%% / %.0f%%",croppedPercent(),anchorX*100,anchorY*100);
        }
    }
    public static Plan create(int sw,int sh,int ow,int oh,String mode,float ax,float ay){
        validate(mode,ax,ay);if(sw<2||sh<2||ow<2||oh<2)throw new IllegalArgumentException("Invalid video dimensions");
        double source=(double)sw/sh,output=(double)ow/oh;
        if(FIT.equals(mode)){
            float dw=(float)Math.min(1,source/output),dh=(float)Math.min(1,output/source);
            return new Plan(mode,0,0,1,1,(1-dw)/2,(1-dh)/2,dw,dh,ax,ay);
        }
        float cw=(float)Math.min(1,output/source),ch=(float)Math.min(1,source/output);
        return new Plan(mode,(1-cw)*ax,(1-ch)*ay,cw,ch,0,0,1,1,ax,ay);
    }
    public static int[] dimensions(int sw,int sh,String ratio,String mode){
        validate(mode,.5f,.5f);
        if(!FIT.equals(mode)||"ORIGINAL".equals(ratio))return Duwm1728BroadcastLayout.dimensions(sw,sh,ratio);
        if(sw<2||sh<2)throw new IllegalArgumentException("Invalid source dimensions");
        int p,q;if("9:10".equals(ratio)){p=9;q=10;}else if("9:16".equals(ratio)){p=9;q=16;}
        else if("16:9".equals(ratio)){p=16;q=9;}else throw new IllegalArgumentException("Unknown aspect ratio");
        // Canvas retains source long-edge resolution. The contained image is never upscaled.
        int k=(Math.max(sw,sh)/Math.max(p,q))&~1;
        if(k<2)throw new IllegalArgumentException("Source too small");
        return new int[]{p*k,q*k};
    }
    /** Uniformly fit a second picture inside the broadcast's upper-right inset.
     * Both dimensions use one scale, so a portrait interview is never widened to fill
     * the landscape inset bounds. Pixel geometry scales with the final canvas. */
    public static final class Inset {
        public final float left,top,width,height,border;
        private Inset(float left,float top,float width,float height,float border){
            this.left=left;this.top=top;this.width=width;this.height=height;this.border=border;
        }
    }
    public static Inset inset(int canvasWidth,int canvasHeight,int imageWidth,int imageHeight){
        if(canvasWidth<2||canvasHeight<2||imageWidth<2||imageHeight<2)
            throw new IllegalArgumentException("Invalid inset dimensions");
        float scale=Math.min(canvasWidth*.27f/imageWidth,canvasHeight*.28f/imageHeight);
        float width=imageWidth*scale,height=imageHeight*scale;
        return new Inset(canvasWidth*.965f-width,canvasHeight*.13f,width,height,
            Math.min(canvasWidth,canvasHeight)/360f);
    }
}
