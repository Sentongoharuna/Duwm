package com.sentongoharuna.worldsituationroom;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Compact, real-state camera dock. No polling, microphone or location permission
 * acquisition occurs in this view. Activity feeds measured snapshots while visible.
 */
public final class Duwm1728CaptureHealthView extends LinearLayout {
    private static final String[] TITLES={"CAM","MIC","GPS","HEAD","WX","SAVE"};
    private final Duwm1728StatusLampView[] lamps=new Duwm1728StatusLampView[6];
    private final TextView[] labels=new TextView[6];
    private final LinearLayout[] cells=new LinearLayout[6];
    private Duwm1728CaptureHealth.Reading[] readings=Duwm1728CaptureHealth.read(null);
    private int dp(float x){return Math.max(1,Math.round(getResources().getDisplayMetrics().density*x));}
    private TextView text(String value,int sp){TextView t=new TextView(getContext());
        t.setText(value);t.setTextSize(sp);t.setTextColor(DuwmUnifiedTheme.TEXT);
        t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        t.setGravity(Gravity.CENTER);t.setSingleLine(true);t.setMaxLines(1);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);return t;}
    public Duwm1728CaptureHealthView(Context context){super(context);
        setOrientation(HORIZONTAL);setGravity(Gravity.CENTER_VERTICAL);
        setPadding(dp(8),dp(3),dp(8),dp(3));setBackgroundColor(DuwmUnifiedTheme.APPROVED_NAVY);
        for(int k=0;k<6;k++){
            final int index=k;
            LinearLayout cell=new LinearLayout(context);cell.setOrientation(VERTICAL);
            cell.setGravity(Gravity.CENTER);cell.setPadding(dp(2),dp(4),dp(2),dp(4));
            GradientDrawable bg=new GradientDrawable();bg.setColor(DuwmUnifiedTheme.APPROVED_NAVY);
            bg.setCornerRadius(dp(10));bg.setStroke(dp(1),DuwmUnifiedTheme.BORDER);cell.setBackground(bg);
            LinearLayout top=new LinearLayout(context);top.setGravity(Gravity.CENTER);
            lamps[k]=new Duwm1728StatusLampView(context);
            lamps[k].setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
            top.addView(lamps[k],new LayoutParams(dp(13),dp(13)));
            TextView title=text(TITLES[k],9);LayoutParams tp=new LayoutParams(-2,dp(21));tp.leftMargin=dp(2);top.addView(title,tp);
            cell.addView(top,new LayoutParams(-1,dp(22)));
            labels[k]=text("UNKNOWN",8);cell.addView(labels[k],new LayoutParams(-1,dp(19)));
            cell.setFocusable(true);cell.setClickable(true);cell.setMinimumHeight(dp(48));
            cell.setOnClickListener(v->showEvidence(index));
            LayoutParams cp=new LayoutParams(0,dp(52),1f);if(k<5)cp.rightMargin=dp(4);addView(cell,cp);cells[k]=cell;
        }
        update(null);
    }
    public void update(Duwm1728CaptureHealth.Input actual){
        readings=Duwm1728CaptureHealth.read(actual);
        for(int k=0;k<readings.length;k++){
            Duwm1728CaptureHealth.Reading r=readings[k];
            lamps[k].setStage(r.stage,800+k,true);
            lamps[k].setContentDescription(TITLES[k]+": "+r.label);
            // The actual state is in the coloured lamp; white labels stay readable on navy.
            if(!r.label.contentEquals(labels[k].getText()))labels[k].setText(r.label);
            cells[k].setContentDescription(r.channel.name()+": "+r.label+". Tap for measurement details.");
        }
    }
    private void showEvidence(int index){
        Duwm1728CaptureHealth.Reading r=readings[index];
        new AlertDialog.Builder(getContext()).setTitle(r.channel.name()+" / "+r.label)
            .setMessage(r.evidence+"\n\nThis is a device-status reading, not independent verification of a news report. " +
                "Blinking describes the observed state; it does not invent incoming information.")
            .setPositiveButton("CLOSE",null).show();
    }
}
