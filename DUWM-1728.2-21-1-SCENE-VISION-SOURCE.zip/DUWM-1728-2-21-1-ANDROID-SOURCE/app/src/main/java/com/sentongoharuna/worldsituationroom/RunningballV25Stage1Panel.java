package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
/** Independent Stage 1 source-truth dashboard, does not replace V24 views. */
public final class RunningballV25Stage1Panel extends LinearLayout {
  private static final int CYAN=0xFF558BDF,GREEN=DuwmUnifiedTheme.STATUS_GREEN,INK=0xFFE0EAFE,AMBER=DuwmUnifiedTheme.STATUS_ORANGE,RED=DuwmUnifiedTheme.STATUS_RED;
  private final Handler ui=new Handler(Looper.getMainLooper());private final TextView title,summary,changes;
  private final RunningballV25Poller poller;
  private boolean visible=false;private final Runnable tick=new Runnable(){@Override public void run(){if(!visible)return;render();ui.postDelayed(this,5000L);}};
  private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
  private TextView label(String s,int size,int color){TextView t=new TextView(getContext());t.setText(s);t.setTextColor(color);t.setTextSize(size);return t;}
  private TextView action(String s,Runnable run){TextView v=label(s,12,CYAN);v.setGravity(Gravity.CENTER);
    v.setBackgroundColor(0xFF0C1B39);v.setPadding(dp(8),dp(14),dp(8),dp(14));v.setMinHeight(dp(48));
    v.setContentDescription(s);v.setOnClickListener(x->run.run());return v;}
  private void open(Class<?> c){getContext().startActivity(new Intent(getContext(),c));}
  public RunningballV25Stage1Panel(Context c){super(c);poller=new RunningballV25Poller(c);setOrientation(VERTICAL);setPadding(dp(12),dp(12),dp(12),dp(12));
    GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFF0C1B39,0xFF041424});
    g.setCornerRadius(dp(14));g.setStroke(dp(1),CYAN);setBackground(g);
    addView(label("V25 / WORLDWIDE CORE · VERIFIED CACHE ONLY",12,GREEN));
    title=label("WORLD VIEW · SELECT REGION",17,INK);addView(title);
    summary=label("NO PROVIDER REPORTS RECEIVED",11,AMBER);summary.setPadding(0,dp(6),0,dp(8));addView(summary);
    LinearLayout row=new LinearLayout(c);row.setOrientation(HORIZONTAL);
    TextView select=action("SELECT REGION",()->open(RunningballWorldExplorerActivity.class));
    TextView reset=action("RESET GLOBAL",()->{RunningballWorldTarget.resetGlobal(getContext());
      Intent refresh=new Intent(getContext(),AirOperationsWidgets.Pulse.class);
      refresh.setAction("com.sentongoharuna.worldsituationroom.AIR_WIDGET_REFRESH");getContext().sendBroadcast(refresh);render();});
    row.addView(select,new LayoutParams(0,-2,1));row.addView(reset,new LayoutParams(0,-2,1));addView(row);
    LinearLayout row2=new LinearLayout(c);row2.setOrientation(HORIZONTAL);
    row2.addView(action("SOURCE HEALTH",()->open(RunningballV25SourceHealthActivity.class)),new LayoutParams(0,-2,1));
    row2.addView(action("CREDITS",()->open(RunningballV25CreditsActivity.class)),new LayoutParams(0,-2,1));addView(row2);
    changes=label("NO VERIFIED CHANGES RECORDED",11,INK);changes.setPadding(0,dp(9),0,0);addView(changes);
    render();
  }
  public void render(){boolean chosen=RunningballWorldTarget.ready(getContext());
    title.setText(chosen?RunningballWorldTarget.coverage(getContext()):"GLOBAL VIEW / AIRCRAFT NOT SELECTED");
    int live=0,loaded=0;for(int i=0;i<RunningballV25Sources.IDS.length;i++){
      RunningballV25Sources.Result r=RunningballV25Sources.read(getContext(),i);
      if(r.status==RunningballV25Sources.Status.LIVE)live++;
      if(r.fetchedAt>0)loaded++;
    }
    summary.setText(live+"/9 PROVIDER-TIMED RECENT · "+loaded+" RECEIVED CACHES\n"+
      (chosen?"SELECTED REGION: "+RunningballWorldTarget.label(getContext()):"GLOBAL / NO REGIONAL AIRCRAFT TOTAL")+
      "\nSATELLITES: ESTIMATE · TWO-BODY KEPLER");
    RunningballV25ChangeLedger.update(getContext());changes.setText("RECENT VERIFIED CHANGES\n"+RunningballV25ChangeLedger.summary(getContext()));
  }
  @Override protected void onAttachedToWindow(){super.onAttachedToWindow();visible=true;poller.start();ui.post(tick);}
  @Override protected void onDetachedFromWindow(){visible=false;poller.stop();ui.removeCallbacks(tick);super.onDetachedFromWindow();}
}
