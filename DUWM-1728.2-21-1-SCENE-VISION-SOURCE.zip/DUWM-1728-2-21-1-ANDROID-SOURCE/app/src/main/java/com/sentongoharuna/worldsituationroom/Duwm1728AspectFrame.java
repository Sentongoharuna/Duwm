package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.view.View;
import android.widget.FrameLayout;
/** Centred exact-aspect viewport. Neither the video nor text is stretched to fit the window. */
public final class Duwm1728AspectFrame extends FrameLayout {
    private float ratio=9f/16f;
    public Duwm1728AspectFrame(Context c){super(c);setBackgroundColor(0xFF041424);setClipChildren(true);}
    public void setRatio(float value){if(value>0&&(!Float.isNaN(value)&&!Float.isInfinite(value))){ratio=value;requestLayout();}}
    @Override protected void onMeasure(int widthSpec,int heightSpec){int w=View.MeasureSpec.getSize(widthSpec),h=View.MeasureSpec.getSize(heightSpec);
        if(w<=0||h<=0){super.onMeasure(widthSpec,heightSpec);return;}if(w/(float)h>ratio)w=Math.max(1,Math.round(h*ratio));else h=Math.max(1,Math.round(w/ratio));
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(w,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(h,View.MeasureSpec.EXACTLY));}
}
