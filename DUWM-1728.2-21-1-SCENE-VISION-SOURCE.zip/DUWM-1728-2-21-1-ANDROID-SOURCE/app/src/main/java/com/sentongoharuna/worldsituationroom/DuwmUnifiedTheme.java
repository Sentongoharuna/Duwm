package com.sentongoharuna.worldsituationroom;

/** 1715 FIX3: exactly sampled #041424 reference navy, #DEE5EF silver controls: one original command center and one visual language across
 * every native page. Cosmetic values never modify source records or freshness.
 */
public final class DuwmUnifiedTheme {
    private DuwmUnifiedTheme() {}
    public static final int BACKGROUND = 0xFF041424;
    public static final int PANEL = 0xFF041424;
    public static final int PANEL_SELECTED = 0xFF061626;
    public static final int BORDER = 0xFFDEE5EF;
    public static final int DIVIDER = 0xFF7D8E9F;
    public static final int SECTOR_LINE = 0xFFBDC7D2;
    public static final int FORMAL_CORNER_DP = 20;
    public static final int ACCENT = 0xFFDEE5EF;
    public static final int ACCENT_BRIGHT = 0xFFF5F7FA;
    // Whole-screen backgrounds must be the approved navy, not cobalt panels.
    public static final int APPROVED_NAVY = 0xFF041424;
    public static final int RAISED_CARD = PANEL;
    public static final int OVERLAY = 0xF2041424;
    public static final int TEXT = 0xFFF5F7FA;
    public static final int MUTED = 0xFFA0A5AE;
    public static final int UNAVAILABLE = 0xFF526173;
    public static final int LOCAL_SIGNAL = 0xFF798A9C; // Neutral silver for local-only tools, not a live status
    // Limited status accents: always label the status; never portray synthetic data.
    public static final int LIVE = 0xFF00C853;
    public static final int WARNING = 0xFFFBC02D;
    public static final int DANGER = 0xFFD50000;
    // DUWM 1725: solid, high-saturation source-health severity, red worst/green best.
    // These accent colours must NEVER be confused with data-category colours.
    public static final int STATUS_RED = 0xFFD50000;
    public static final int STATUS_ORANGE = 0xFFF57C00;
    public static final int STATUS_YELLOW = 0xFFFBC02D;
    public static final int STATUS_BLUE = 0xFF0D47A1;
    public static final int STATUS_CYAN = 0xFF00ACC1;
    public static final int STATUS_GREEN = 0xFF00C853;
    public static final int STATUS_UNKNOWN = 0xFF526173;
    // 1728.2/6: canvas colours, not merely Android window backgrounds.
    public static final int MAP_OCEAN = 0xFF051526;
    public static final int MAP_OCEAN_SHADE = 0xFF041221;
    public static final int MAP_LAND = 0xFF061728;
    public static final int MAP_COAST = 0xFF28547A;
    public static final int MAP_BORDER = 0xFF173B5B;
    public static final int MAP_RIM = 0xFF184472;
    public static final int MAP_GRID = 0xFF0D2439;
    public static final int DEEP_BLUE_ACCENT = 0xFF0D2A45;
}

