package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.View;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
/** Independent Canvas view. Data from original V24 caches only; no simulations, no network. */
public final class RunningballV25Stage2GeoView extends View {
  private static final int CYAN=0xFF558BDF,GREEN=DuwmUnifiedTheme.STATUS_GREEN,AMBER=DuwmUnifiedTheme.STATUS_ORANGE,RED=DuwmUnifiedTheme.STATUS_RED;
  private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
  private final ArrayList<Point> points=new ArrayList<>();
  private final int source;
  private long lastStamp=-1L,pulseAt=-1L;
  private boolean validReport=false,reduceMotion=false,currentFresh=false;
  private String message="NO VERIFIED POSITIONS";
  private static final class Point { final double lat,lon,magnitude,age;
    Point(double la,double lo,double mag,double seconds){lat=la;lon=lo;magnitude=mag;age=seconds;} }
  private static boolean finite(double d){return !Double.isNaN(d)&&!Double.isInfinite(d);}
  private int dp(float size){return Math.round(size*getResources().getDisplayMetrics().density);}
  private SharedPreferences pref(String key){return getContext().getApplicationContext().getSharedPreferences(key,Context.MODE_PRIVATE);}
  public RunningballV25Stage2GeoView(Context c,int kind){super(c);source=kind;
    setMinimumHeight(dp(180));setContentDescription("No observed geographic positions received");}
  @Override protected void onMeasure(int wSpec,int hSpec){int width=MeasureSpec.getSize(wSpec);
    setMeasuredDimension(width,resolveSize(dp(186),hSpec));}
  private JSONObject object(String raw){try{return new JSONObject(raw);}catch(Exception e){return new JSONObject();}}
  private void add(double lat,double lon,double magnitude,double age){
    if(points.size()>=100||!finite(lat)||!finite(lon)||lat< -90||lat>90||lon< -180||lon>180)return;
    points.add(new Point(lat,lon,finite(magnitude)?magnitude:0d,finite(age)?age:0d));}
  /** Only refresh pins when the *received cache timestamp* changes. Do not animate stale values. */
  public void update(RunningballV25Sources.Result report){
    reduceMotion=pref("rb25_visual_preferences").getBoolean("reduce_motion",false);
    try{reduceMotion|=Settings.Global.getFloat(getContext().getContentResolver(),Settings.Global.ANIMATOR_DURATION_SCALE,1f)==0f;}
    catch(Exception ignored){}
    boolean freshNow=report.status==RunningballV25Sources.Status.LIVE;
    if(report.fetchedAt==lastStamp){
      if(currentFresh!=freshNow){currentFresh=freshNow;invalidate();}
      return;
    }
    long former=lastStamp;lastStamp=report.fetchedAt;points.clear();
    validReport=report.fetchedAt>0&&!"--".equals(report.value);
    currentFresh=freshNow;
    if(!validReport){message="NO OBSERVED POSITIONS / "+report.status;invalidate();return;}
    if(source==0){
      JSONObject snap=object(pref("air_widget_v2").getString("last_snapshot","{}"));
      JSONArray rows=snap.optJSONArray("items");
      boolean region=RunningballWorldTarget.ready(getContext()) &&
        Math.abs(snap.optDouble("observerLat",999)-RunningballWorldTarget.lat(getContext()))<.001 &&
        Math.abs(snap.optDouble("observerLon",999)-RunningballWorldTarget.lon(getContext()))<.001;
      if(region&&rows!=null)for(int i=0;i<rows.length()&&i<100;i++){
        JSONObject r=rows.optJSONObject(i);if(r==null)continue;
        double age=r.optDouble("seen_pos",Double.NaN);
        if(!finite(age)||age<0||age>120)continue;
        add(r.optDouble("lat",Double.NaN),r.optDouble("lon",Double.NaN),0,age);
      }
      message=region?"OBSERVED AIRCRAFT / 250 NM REGION":"AIRCRAFT / SELECT REGION";
    } else if(source==2){
      JSONObject marine=object(pref("rb11_marine").getString("rows","{}"));
      JSONArray rows=marine.optJSONArray("rows");
      if(rows!=null)for(int i=0;i<rows.length()&&i<100;i++){
        JSONObject r=rows.optJSONObject(i);if(r!=null)add(r.optDouble("lat",Double.NaN),r.optDouble("lon",Double.NaN),0,0);
      }
      message="AIS / RECEIVED SHIP POSITIONS ONLY";
    } else if(source==3){
      JSONObject quakes=object(pref("rb_global_public_events").getString("quakes_raw","{}"));
      JSONArray features=quakes.optJSONArray("features");
      if(features!=null)for(int i=0;i<features.length()&&i<100;i++){
        JSONObject event=features.optJSONObject(i);if(event==null)continue;
        JSONObject g=event.optJSONObject("geometry"),info=event.optJSONObject("properties");
        JSONArray co=g==null?null:g.optJSONArray("coordinates");
        if(co!=null&&co.length()>=2)add(co.optDouble(1,Double.NaN),co.optDouble(0,Double.NaN),info==null?0:info.optDouble("mag",0),0);
      }
      message="USGS / REAL EPICENTRES / LAST 24H";
    } else if(source==4){
      JSONObject nasa=object(pref("rb_global_public_events").getString("nasa_raw","{}"));
      JSONArray events=nasa.optJSONArray("events");
      if(events!=null)for(int i=0;i<events.length()&&i<100;i++){
        JSONObject event=events.optJSONObject(i);if(event==null)continue;
        JSONArray geometries=event.optJSONArray("geometry");
        JSONObject last=geometries==null||geometries.length()==0?null:geometries.optJSONObject(geometries.length()-1);
        JSONArray coordinates=last==null?null:last.optJSONArray("coordinates");
        if(coordinates!=null&&coordinates.length()>=2&&"Point".equalsIgnoreCase(last.optString("type","Point")))
          add(coordinates.optDouble(1,Double.NaN),coordinates.optDouble(0,Double.NaN),0,0);
      }
      message="NASA EONET / OBSERVED EVENT LOCATIONS";
    } else if(source==1){message="ORBIT ESTIMATE · TWO-BODY KEPLER / NO VERIFIED POSITION PINS";}
    else{message="NO GEOGRAPHIC OBSERVATIONS FOR THIS FEED";}
    // A verified second snapshot can flash; opening a screen never invents an event.
    if(former>0&&report.fetchedAt>former&&points.size()>0&&!reduceMotion){pulseAt=SystemClock.uptimeMillis();}
    setContentDescription(message+"; "+points.size()+" displayed observations; "+report.display());
    invalidate();
  }
  @Override protected void onDraw(Canvas c){super.onDraw(c);
    float w=getWidth(),h=getHeight();c.drawColor(0xFF041424);
    p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));p.setColor(0xFF284C87);
    if(source==0){
      float cx=w/2f,cy=h/2f,r=Math.min(w*.43f,h*.41f);
      for(int n=1;n<=4;n++)c.drawCircle(cx,cy,r*n/4f,p);
      c.drawLine(cx-r,cy,cx+r,cy,p);c.drawLine(cx,cy-r,cx,cy+r,p);
    }else{
      for(int n=1;n<6;n++){float x=n*w/6f;c.drawLine(x,0,x,h,p);}
      for(int n=1;n<4;n++){float y=n*h/4f;c.drawLine(0,y,w,y,p);}
    }
    boolean live=validReport && !points.isEmpty();
    p.setStyle(Paint.Style.FILL);
    for(Point point:points){
      float x,y;
      if(source==0){
        if(!RunningballWorldTarget.ready(getContext()))continue;
        double clat=RunningballWorldTarget.lat(getContext()),clon=RunningballWorldTarget.lon(getContext());
        double north=(point.lat-clat)*60d;
        double east=(point.lon-clon)*60d*Math.cos(Math.toRadians(clat));
        double dist=Math.hypot(north,east);
        if(dist>250)continue;
        float rad=Math.min(w*.43f,h*.41f);x=w/2f+(float)(east/250d*rad);y=h/2f-(float)(north/250d*rad);
      }else{x=(float)((point.lon+180d)/360d*w);y=(float)((90d-point.lat)/180d*h);}
      int tint=(source==3 && point.magnitude>=5)?RED:source==4?AMBER:GREEN;
      if(source==3){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.1f));p.setColor(tint);
        c.drawCircle(x,y,dp(3+(float)Math.min(7d,Math.max(0d,point.magnitude))),p);p.setStyle(Paint.Style.FILL);}
      p.setColor(tint);p.setAlpha(currentFresh?225:85);c.drawCircle(x,y,dp(source==0?3.5f:2.7f),p);
    }
    long remaining=600L-(SystemClock.uptimeMillis()-pulseAt);
    if(live&&!reduceMotion&&pulseAt>0&&remaining>0){
      p.setColor(CYAN);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2));p.setAlpha(Math.max(0,Math.min(255,(int)(remaining*100/600))));
      c.drawRoundRect(dp(2),dp(2),w-dp(2),h-dp(2),dp(12),dp(12),p);
      postInvalidateDelayed(70L);
    }
    p.setStyle(Paint.Style.FILL);p.setAlpha(255);p.setColor(live?CYAN:AMBER);p.setTextSize(dp(9));
    c.drawText(points.size()+" OBSERVED POSITIONS / "+(currentFresh?"RECENT":"CACHED / STALE"),dp(7),h-dp(8),p);
  }
}
