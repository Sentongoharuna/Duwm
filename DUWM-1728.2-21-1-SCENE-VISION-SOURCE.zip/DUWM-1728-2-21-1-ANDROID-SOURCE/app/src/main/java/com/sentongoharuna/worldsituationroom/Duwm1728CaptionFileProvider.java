package com.sentongoharuna.worldsituationroom;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.FileNotFoundException;
import java.io.IOException;

/** Only immutable generated SRT snapshots are exposed; external callers receive read grants. */
public final class Duwm1728CaptionFileProvider extends ContentProvider {
    @Override public boolean onCreate(){return true;}
    @Override public String getType(Uri uri){
        try{Duwm1728CaptionFileStore.entryId(getContext(),uri);return Duwm1728CaptionFileStore.MIME;}
        catch(IOException invalid){throw new IllegalArgumentException(invalid.getMessage(),invalid);}
    }
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sortOrder){
        try {
            Duwm1728CaptionFileStore.Snapshot snapshot=Duwm1728CaptionFileStore.find(getContext(),Duwm1728CaptionFileStore.entryId(getContext(),uri));
            String[] columns=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;
            MatrixCursor cursor=new MatrixCursor(columns,1);MatrixCursor.RowBuilder row=cursor.newRow();
            for(String column:columns){if(OpenableColumns.DISPLAY_NAME.equals(column))row.add(snapshot.name);
                else if(OpenableColumns.SIZE.equals(column))row.add(snapshot.bytes);else row.add(null);}return cursor;
        }catch(IOException invalid){throw new IllegalArgumentException(invalid.getMessage(),invalid);}
    }
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException {
        if(!"r".equals(mode))throw new FileNotFoundException("Caption snapshots are read only");
        try{return ParcelFileDescriptor.open(Duwm1728CaptionFileStore.readableFile(getContext(),uri),ParcelFileDescriptor.MODE_READ_ONLY);}
        catch(IOException invalid){FileNotFoundException error=new FileNotFoundException(invalid.getMessage());error.initCause(invalid);throw error;}
    }
    @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException("Read only");}
    @Override public int update(Uri uri,ContentValues values,String selection,String[] args){throw new UnsupportedOperationException("Read only");}
    @Override public int delete(Uri uri,String selection,String[] args){throw new UnsupportedOperationException("Read only");}
}
