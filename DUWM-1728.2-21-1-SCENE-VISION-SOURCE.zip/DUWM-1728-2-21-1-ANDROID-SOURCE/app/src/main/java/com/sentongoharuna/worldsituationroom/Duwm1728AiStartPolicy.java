package com.sentongoharuna.worldsituationroom;

/** Side-effect-free admission rule for automatic drafts. It does not perform AI,
 * grant consent, publish a report, or claim that a configured server is reachable. */
public final class Duwm1728AiStartPolicy {
    private Duwm1728AiStartPolicy() { }

    public static boolean allowAutomatic(boolean cleanMaster, boolean headlineEmpty,
            boolean optedIn, boolean configured, boolean closing,
            boolean exporting, boolean requestInFlight) {
        return cleanMaster && headlineEmpty && optedIn && configured
                && !closing && !exporting && !requestInFlight;
    }
}
