package com.sentongoharuna.worldsituationroom;
import android.content.Context;
import android.net.Uri;
import android.security.keystore.*;
import android.util.Base64;
import org.json.*;
import java.io.*;
import java.net.*;
import java.security.KeyStore;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** Calls the owner's HTTPS AI production server, never embeds a model-provider secret.
 * The user must explicitly approve media upload; returned drafts are never auto-published. */
public final class Duwm1728AiProductionClient {
    public static final String PREFS="duwm_ai_production_v1";
    private final Context context;private volatile HttpURLConnection connection;private volatile boolean cancelled;
    public Duwm1728AiProductionClient(Context c){context=c.getApplicationContext();}
    private static SecretKey key()throws Exception{KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);String alias="duwm_ai_device_token";
        if(!store.containsAlias(alias)){KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");generator.init(new KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());generator.generateKey();}return (SecretKey)store.getKey(alias,null);}
    public static void configure(Context c,String address,String token)throws Exception{
        URI u=new URI(address.trim());if(!"https".equalsIgnoreCase(u.getScheme())||u.getHost()==null||u.getUserInfo()!=null||u.getQuery()!=null||u.getFragment()!=null)throw new IllegalArgumentException("Use an HTTPS server URL without credentials or query parameters");
        if(token.trim().length()<24)throw new IllegalArgumentException("Use a server-issued device token of at least 24 characters, not an AI provider API key");
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());String encrypted=Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP)+"."+Base64.encodeToString(cipher.doFinal(token.trim().getBytes("UTF-8")),Base64.NO_WRAP);
        c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString("endpoint",address.trim().replaceAll("/+$","" )).putString("token",encrypted).apply();
    }
    public static boolean configured(Context c){return !c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString("endpoint","").isEmpty()&&!c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString("token","").isEmpty();}
    public static String token(Context context)throws Exception{return new Duwm1728AiProductionClient(context).token();}
    private String token()throws Exception{String[] parts=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString("token","").split("\\.");if(parts.length!=2)throw new IllegalStateException("AI device token missing");Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(parts[0],Base64.NO_WRAP)));return new String(cipher.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),"UTF-8");}
    public void cancel(){cancelled=true;HttpURLConnection c=connection;if(c!=null)c.disconnect();}
    public JSONObject produce(Uri video,long from,long to,String notes)throws Exception{
        if(!configured(context))throw new IllegalStateException("AI production server is not configured");if(from<0||to<=from)throw new IllegalArgumentException("Invalid selected clip");
        String base=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString("endpoint","");
        URL url=new URL(base+"/v1/produce?from_ms="+from+"&to_ms="+to);
        connection=(HttpURLConnection)url.openConnection();connection.setRequestMethod("POST");connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(15000);connection.setReadTimeout(300000);connection.setDoOutput(true);connection.setChunkedStreamingMode(65536);
        connection.setRequestProperty("Authorization","Bearer "+token());connection.setRequestProperty("Content-Type","video/mp4");connection.setRequestProperty("Accept","application/json");
        String safe=Duwm1728BroadcastLayout.clean(notes,1000);connection.setRequestProperty("X-DUWM-Notes",Base64.encodeToString(safe.getBytes("UTF-8"),Base64.NO_WRAP));
        try{try(InputStream in=context.getContentResolver().openInputStream(video);OutputStream out=connection.getOutputStream()){
                if(in==null)throw new IOException("Source video unavailable");byte[] bytes=new byte[65536];int n;long total=0;while((n=in.read(bytes))!=-1){if(cancelled)throw new InterruptedException("AI request cancelled");total+=n;if(total>512L*1024*1024)throw new IOException("Video exceeds 512 MiB AI upload limit");out.write(bytes,0,n);}}
            int code=connection.getResponseCode();InputStream stream=code>=200&&code<300?connection.getInputStream():connection.getErrorStream();
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();if(stream!=null)try(InputStream in=stream){byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))!=-1){if(bytes.size()+n>2*1024*1024)throw new IOException("AI response too large");bytes.write(buffer,0,n);}}
            String body=bytes.toString("UTF-8");if(code!=200)throw new IOException("AI server HTTP "+code+": "+Duwm1728BroadcastLayout.clean(body,200));
            JSONObject report=new JSONObject(body);if(!"duwm.report.v1".equals(report.optString("schema"))||report.optString("headline").trim().isEmpty()||!report.optBoolean("review_required",false))throw new IOException("AI returned an invalid/unreviewable draft");
            if(cancelled)throw new InterruptedException("AI request cancelled");return report;
        }finally{connection.disconnect();connection=null;}
    }
}
