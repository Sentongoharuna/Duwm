package com.sentongoharuna.worldsituationroom;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Exact-millisecond SRT interchange for the complete edited caption list.
 * All returned lists are independent, immutable and stably ordered by start.
 * Overlaps and equal starts retain the shared renderer's existing semantics.
 * Malformed blocks, text over the editing limit and oversized files are errors;
 * none are silently skipped, truncated or treated as HTML.
 */
public final class Duwm1728CaptionSrt {
    public static final int MAX_BYTES=32*1024*1024;
    public enum TimeBase { ORIGINAL, SELECTED_CLIP }
    private static final Pattern TIMING=Pattern.compile(
        "([0-9]+:[0-5][0-9]:[0-5][0-9][,.][0-9]{3})[ \\t]*-->[ \\t]*"+
        "([0-9]+:[0-5][0-9]:[0-5][0-9][,.][0-9]{3})");
    private Duwm1728CaptionSrt() {}

    /** Read at most 32 MiB of strict UTF-8. The caller owns and closes input.
     * A single additional byte is read only to detect an oversized stream.
     */
    public static String read(InputStream input) throws IOException {
        if(input==null)throw new IllegalArgumentException("Select a caption file");
        ByteArrayOutputStream bytes=new ByteArrayOutputStream(8192);
        byte[] buffer=new byte[8192];int total=0;
        while(true){
            int count=input.read(buffer,0,Math.min(buffer.length,MAX_BYTES-total+1));
            if(count<0)break;
            if(count==0){
                // Some document streams return zero from a bulk read. A single
                // read either consumes a byte or reaches EOF, so this cannot spin.
                int single=input.read();if(single<0)break;
                if(total==MAX_BYTES)throw new IOException("Caption file exceeds 32 MiB");
                bytes.write(single);total++;continue;
            }
            if(count>MAX_BYTES-total)throw new IOException("Caption file exceeds 32 MiB");
            bytes.write(buffer,0,count);total+=count;
        }
        try{
            return StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes.toByteArray())).toString();
        }catch(CharacterCodingException malformed){
            throw new IOException("Caption file must contain valid UTF-8 text",malformed);
        }
    }

    /** Parse raw file times. Source-duration validation happens in importCues.
     * Optional sequence numbers and comma or dot milliseconds are accepted.
     * Only a file-leading BOM is removed; U+FEFF within cue words remains text.
     * Ordinary text line breaks and tabs follow CaptionEditPolicy's documented
     * whitespace normalization. A new time code after text requires a blank
     * separator; a timing-shaped first text line is retained literally.
     */
    public static List<Duwm1728BroadcastLayout.Cue> parse(String text) {
        checkText(text);
        Lines lines=new Lines(text);ArrayList<Duwm1728BroadcastLayout.Cue> result=new ArrayList<>();
        String line;
        while((line=lines.next())!=null){
            if(blank(line))continue;
            int block=result.size()+1;
            if(block>Duwm1728CaptionEditPolicy.MAX_CUES)throw new IllegalArgumentException("Maximum 20000 caption cues");
            if(line.trim().matches("[0-9]+")){
                line=lines.next();
                if(line==null||blank(line))throw blockError(block,"a sequence number must be followed by its time code");
            }
            Matcher timing=TIMING.matcher(line.trim());
            if(!timing.matches())throw blockError(block,"use HH:MM:SS,mmm --> HH:MM:SS,mmm on the time-code line");
            StringBuilder words=new StringBuilder();
            while((line=lines.next())!=null&&!blank(line)){
                if(words.length()>0&&TIMING.matcher(line.trim()).matches())
                    throw blockError(block,"separate caption blocks with a blank line before the next time code");
                int separator=words.length()==0?0:1;
                if(line.length()>500-words.length()-separator)throw blockError(block,"a caption may contain at most 500 UTF-16 characters");
                if(separator!=0)words.append('\n');words.append(line);
            }
            if(words.length()==0)throw blockError(block,"enter caption words after the time code");
            try{
                result.add(Duwm1728CaptionEditPolicy.cue(timing.group(1).replace(',','.'),
                    timing.group(2).replace(',','.'),words.toString(),Long.MAX_VALUE));
            }catch(IllegalArgumentException invalid){throw blockError(block,invalid.getMessage());}
        }
        if(result.isEmpty())throw new IllegalArgumentException("No caption cues found in the SRT file");
        return Duwm1728CaptionEditPolicy.copyAndValidate(result,Long.MAX_VALUE);
    }

    /** ORIGINAL ignores fromMs/toMs, including invalid trim values.
     * SELECTED_CLIP requires 0 <= fromMs < toMs <= durationMs, validates every
     * file cue inside that clip duration, then adds fromMs without rounding.
     * Import never clips, drops or applies any part of an invalid list.
     */
    public static List<Duwm1728BroadcastLayout.Cue> importCues(String text,TimeBase basis,
            long durationMs,long fromMs,long toMs) {
        range(basis,durationMs,fromMs,toMs);
        List<Duwm1728BroadcastLayout.Cue> parsed=parse(text);
        if(basis==TimeBase.ORIGINAL)return Duwm1728CaptionEditPolicy.copyAndValidate(parsed,durationMs);
        List<Duwm1728BroadcastLayout.Cue> relative;
        try{relative=Duwm1728CaptionEditPolicy.copyAndValidate(parsed,toMs-fromMs);}
        catch(IllegalArgumentException invalid){throw new IllegalArgumentException(
            "Caption times must stay within the selected clip: "+invalid.getMessage(),invalid);}
        ArrayList<Duwm1728BroadcastLayout.Cue> absolute=new ArrayList<>(relative.size());
        for(Duwm1728BroadcastLayout.Cue cue:relative){
            // Validation above proves both additions are <= toMs <= durationMs.
            absolute.add(new Duwm1728BroadcastLayout.Cue(fromMs+cue.startMs,fromMs+cue.endMs,cue.text));
        }
        return Duwm1728CaptionEditPolicy.copyAndValidate(absolute,durationMs);
    }

    /** Encode deterministic UTF-8 without a BOM. ORIGINAL retains every source
     * cue and ignores trim. SELECTED_CLIP uses the same half-open intersection
     * and rebasing as BroadcastTimeline.captions, including overlaps and gaps.
     * Empty exports are reported rather than creating a misleading empty file.
     */
    public static byte[] exportCues(List<Duwm1728BroadcastLayout.Cue> source,TimeBase basis,
            long durationMs,long fromMs,long toMs) {
        range(basis,durationMs,fromMs,toMs);
        List<Duwm1728BroadcastLayout.Cue> checked=Duwm1728CaptionEditPolicy.copyAndValidate(source,durationMs);
        ArrayList<Duwm1728BroadcastLayout.Cue> selected=new ArrayList<>(checked.size());
        for(Duwm1728BroadcastLayout.Cue cue:checked){
            if(basis==TimeBase.ORIGINAL)selected.add(cue);
            else{
                long start=Math.max(fromMs,cue.startMs),end=Math.min(toMs,cue.endMs);
                if(end>start)selected.add(new Duwm1728BroadcastLayout.Cue(start-fromMs,end-fromMs,cue.text));
            }
        }
        if(selected.isEmpty())throw new IllegalArgumentException(basis==TimeBase.ORIGINAL?
            "There are no captions to export":"There are no captions in the selected clip");
        ByteArrayOutputStream bytes=new ByteArrayOutputStream(8192);
        CharsetEncoder encoder=StandardCharsets.UTF_8.newEncoder()
            .onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT);
        for(int index=0;index<selected.size();index++){
            Duwm1728BroadcastLayout.Cue cue=selected.get(index);
            String block=(index+1)+"\n"+timestamp(cue.startMs)+" --> "+timestamp(cue.endMs)+"\n"+cue.text+"\n\n";
            try{
                ByteBuffer encoded=encoder.encode(CharBuffer.wrap(block));int size=encoded.remaining();
                if(size>MAX_BYTES-bytes.size())throw new IllegalArgumentException("Caption file exceeds 32 MiB");
                byte[] chunk=new byte[size];encoded.get(chunk);bytes.write(chunk,0,chunk.length);
            }catch(CharacterCodingException malformed){throw new IllegalArgumentException("Caption text contains incomplete Unicode",malformed);}
        }
        return bytes.toByteArray();
    }

    private static String timestamp(long milliseconds){return Duwm1728CaptionEditPolicy.formatTime(milliseconds).replace('.',',');}
    private static void range(TimeBase basis,long durationMs,long fromMs,long toMs){
        if(basis==null)throw new IllegalArgumentException("Choose original recording or selected clip times");
        if(durationMs<=0)throw new IllegalArgumentException("The original recording must have a positive duration");
        if(basis==TimeBase.SELECTED_CLIP&&(fromMs<0||toMs<=fromMs||toMs>durationMs))
            throw new IllegalArgumentException("Choose a nonempty clip within the original recording");
    }
    private static IllegalArgumentException blockError(int block,String detail){
        return new IllegalArgumentException("SRT cue "+block+": "+detail);
    }
    private static boolean blank(String line){
        for(int i=0;i<line.length();i++)if(line.charAt(i)!=' '&&line.charAt(i)!='\t')return false;
        return true;
    }
    /** Count the actual UTF-8 bytes even when a caller bypasses read(). */
    private static void checkText(String text){
        if(text==null)throw new IllegalArgumentException("Select an SRT caption file");
        int bytes=0;
        for(int i=0;i<text.length();i++){
            char ch=text.charAt(i);int size;
            if(Character.isHighSurrogate(ch)){
                if(i+1>=text.length()||!Character.isLowSurrogate(text.charAt(i+1)))throw new IllegalArgumentException("Caption file contains incomplete Unicode");
                i++;size=4;
            }else{
                if(Character.isLowSurrogate(ch))throw new IllegalArgumentException("Caption file contains incomplete Unicode");
                if(Character.isISOControl(ch)&&ch!='\r'&&ch!='\n'&&ch!='\t')throw new IllegalArgumentException("Caption file contains an unsupported control character");
                size=ch<=0x7f?1:ch<=0x7ff?2:3;
            }
            if(size>MAX_BYTES-bytes)throw new IllegalArgumentException("Caption file exceeds 32 MiB");
            bytes+=size;
        }
    }
    /** Sequential lines avoid allocating an array for every line in a large file. */
    private static final class Lines {
        private final String text;private int at;
        Lines(String source){text=source;at=source.startsWith("\uFEFF")?1:0;}
        String next(){
            if(at>=text.length())return null;
            int start=at;while(at<text.length()&&text.charAt(at)!='\r'&&text.charAt(at)!='\n')at++;
            String line=text.substring(start,at);
            if(at<text.length()){
                char ending=text.charAt(at++);
                if(ending=='\r'&&at<text.length()&&text.charAt(at)=='\n')at++;
            }
            return line;
        }
    }
}
