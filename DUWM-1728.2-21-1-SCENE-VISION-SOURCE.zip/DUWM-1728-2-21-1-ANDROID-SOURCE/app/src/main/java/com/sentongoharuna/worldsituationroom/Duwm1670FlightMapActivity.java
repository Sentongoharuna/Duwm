package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;

/** Selectable live-source aircraft map. Movement is interpolation ONLY between reported fixes.
 * Source can be 15+ minutes old; redraw does not suggest current position. ETA uses optional
 * manually selected airport, not undisclosed actual origin/destination or a published timetable.
 */
public final class Duwm1670FlightMapActivity extends Activity {
  private Duwm1678VisualKit.PulsePanel flightBand;
  private static final int BG=0xFF041424,WHITE=0xFFDCE8FF,MUTED=0xFF4C78C4,CYAN=0xFF558BDF,AMBER=DuwmUnifiedTheme.STATUS_ORANGE;
  private static final String[] REGION={"WORLD","AFRICA","EUROPE","MIDDLE EAST","INDIA / ASIA","AMERICAS","PACIFIC"};
  private static final double[][] TARGETS={{0,0},{2.0,22.0},{51,12},{25,46},{24,82},{40,-92},{-15,150}};
  private static final String[] AIRPORTS={"NO DESTINATION PROVIDED","EBB • Entebbe","NBO • Nairobi","DXB • Dubai","DOH • Doha","LHR • London Heathrow","DEL • Delhi","JNB • Johannesburg","JFK • New York","ADD • Addis Ababa","AMS • Amsterdam","SIN • Singapore"};
  private static final double[][] AIRPORT_GEO={{0,0},{0.042,32.443},{-1.319,36.927},{25.253,55.364},{25.273,51.608},{51.470,-0.454},{28.556,77.100},{-26.139,28.246},{40.641,-73.778},{8.978,38.799},{52.31,4.764},{1.364,103.99}};
  private final Handler ui=new Handler(Looper.getMainLooper());private boolean active;
  private Duwm1670WorldMapView map;private TextView source,details,summary;
  private Duwm1670WorldMapView.Pin chosen;
  private long sourceAt;
  private final ArrayList<Duwm1670WorldMapView.Pin> aircraftOnMap=new ArrayList<>();
  private TextView flightQuickFacts;private Duwm1690EvidenceBars flightEvidence;private LinearLayout aircraftList;private int visibleAircraftRows=12;
  private String activeRegion="WORLD",displayedKey="";
  private int destIndex=0;
  private boolean followSelected=false;
  private String callsignFilter="";private boolean pairsOnly=false,expandedMap=false,freshOnly=false,highAltitudeOnly=false,fastOnly=false;private int aircraftOrder=0;
  private LinearLayout.LayoutParams liveMapParams;
  private long lastRequested=0L;
  private final Runnable tick=new Runnable(){@Override public void run(){if(!active)return;render();
    if(System.currentTimeMillis()-lastRequested>=90000L){lastRequested=System.currentTimeMillis();
      RunningballV25GlobalAircraftData.refresh(Duwm1670FlightMapActivity.this,()->{if(active)render();});}
    ui.postDelayed(this,1200);}};
  private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}
  private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
  private GradientDrawable frame(){GradientDrawable d=new GradientDrawable();d.setColor(0xFF0C1B39);d.setCornerRadius(dp(10));d.setStroke(dp(1),0xFF284C87);return d;}
  private TextView button(String s,Runnable fn){TextView v=text(s,12,CYAN);v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setGravity(Gravity.CENTER);v.setPadding(dp(8),dp(11),dp(8),dp(11));v.setBackground(frame());v.setOnClickListener(w->fn.run());return v;}
  private Spinner spinner(String[] opts){Spinner spin=new Spinner(this);ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,opts);a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);spin.setAdapter(a);spin.setBackground(frame());return spin;}
  private String utc(long ms){return Duwm1674TimeGuard.utc(ms);}
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);setContentView(scroll);Duwm1167SafeArea.install(this,scroll);
    LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(12),dp(12),dp(12),dp(25));scroll.addView(root);
    TextView head=text("AIR TRAFFIC  /  SOURCE POSITIONS",11,CYAN);head.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(head);
    TextView title=text("WORLD AIRCRAFT TRACKER  /  1700",20,WHITE);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(Duwm1693Chrome.title(title));
    root.addView(text("Real reported positions • two-fix transitions • global country outlines",11,MUTED));
    flightBand=new Duwm1678VisualKit.PulsePanel(this,"AIRCRAFT");
    LinearLayout.LayoutParams flightBandLp=new LinearLayout.LayoutParams(-1,dp(50));flightBandLp.topMargin=dp(8);root.addView(flightBand,flightBandLp);
    flightBand.setReceipt("AWAITING OPENSKY OBSERVATIONS",0,false);
    summary=text("REQUESTING AIRCRAFT SOURCE STATUS",12,WHITE);summary.setPadding(0,dp(12),0,dp(9));root.addView(summary);
    source=text("NO RECEIPT",11,AMBER);root.addView(source);
    LinearLayout actions=new LinearLayout(this);root.addView(actions);
    actions.addView(button("REFRESH SOURCE",()->{RunningballV25GlobalAircraftData.refreshNow(this,this::render);source.setText("Manual update requested • provider retry limit still applies.");}),new LinearLayout.LayoutParams(0,dp(45),1));
    TextView back=button("ORIGINAL GLOBE",()->{Intent home=new Intent(this,MainActivity.class);
      home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(home);});
    LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(45),1);bp.leftMargin=dp(7);actions.addView(back,bp);
    LinearLayout filterDeck=new LinearLayout(this);filterDeck.setOrientation(LinearLayout.VERTICAL);
    TextView mapFocus=button("MAP FIRST  /  HIDE FILTER CONTROLS",()->{});
    LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,dp(49));fp.topMargin=dp(9);root.addView(mapFocus,fp);
    root.addView(filterDeck,new LinearLayout.LayoutParams(-1,-2));
    mapFocus.setOnClickListener(v->{boolean show=filterDeck.getVisibility()!=View.VISIBLE;
      filterDeck.setVisibility(show?View.VISIBLE:View.GONE);
      if(liveMapParams!=null&&map!=null){liveMapParams.height=dp(show?(expandedMap?760:570):800);map.setLayoutParams(liveMapParams);}
      mapFocus.setText(show?"MAP FIRST  /  HIDE FILTER CONTROLS":"MAP FOCUS ACTIVE  /  SHOW FILTER CONTROLS");});
    TextView lbl=text("SELECT WORLD REGION",12,AMBER);lbl.setPadding(0,dp(12),0,0);filterDeck.addView(lbl);
    Spinner region=spinner(REGION);filterDeck.addView(region,new LinearLayout.LayoutParams(-1,dp(48)));
    region.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
      @Override public void onItemSelected(AdapterView<?> p,View v,int position,long id){activeRegion=REGION[position];
        if(map!=null){if(position==0)map.reset();else map.focus(TARGETS[position][0],TARGETS[position][1],2.15f);}
        chosen=null;render();}
      @Override public void onNothingSelected(AdapterView<?> p){} });
    android.widget.EditText search=new android.widget.EditText(this);
    search.setSingleLine(true);search.setTextSize(13);search.setTextColor(WHITE);search.setHintTextColor(MUTED);
    search.setHint("FILTER LIVE SOURCE SAMPLE BY CALLSIGN OR ICAO24");search.setPadding(dp(12),dp(10),dp(12),dp(10));search.setBackground(frame());
    filterDeck.addView(search,new LinearLayout.LayoutParams(-1,dp(48)));
    search.addTextChangedListener(new android.text.TextWatcher(){
      @Override public void beforeTextChanged(CharSequence a,int start,int count,int after){}
      @Override public void onTextChanged(CharSequence a,int start,int before,int count){callsignFilter=a.toString().trim().toUpperCase(Locale.US);render();}
      @Override public void afterTextChanged(android.text.Editable e){}
    });
    LinearLayout observationControls=new LinearLayout(this);observationControls.setOrientation(LinearLayout.HORIZONTAL);
    LinearLayout.LayoutParams ocp=new LinearLayout.LayoutParams(-1,dp(47));ocp.topMargin=dp(8);filterDeck.addView(observationControls,ocp);
    TextView paired=button("ALL REPORTED FIXES",()->{pairsOnly=!pairsOnly;render();});
    observationControls.addView(paired,new LinearLayout.LayoutParams(0,-1,1));
    paired.setOnClickListener(v->{pairsOnly=!pairsOnly;paired.setText(pairsOnly?"TWO-FIX TRACKS ONLY":"ALL REPORTED FIXES");render();});
    TextView expandMap=button("EXPAND MAP",()->{});
    LinearLayout.LayoutParams elp=new LinearLayout.LayoutParams(0,-1,1);elp.leftMargin=dp(7);observationControls.addView(expandMap,elp);
    expandMap.setOnClickListener(v->{expandedMap=!expandedMap;if(liveMapParams!=null&&map!=null){liveMapParams.height=dp(filterDeck.getVisibility()==View.GONE?800:expandedMap?760:570);map.setLayoutParams(liveMapParams);}expandMap.setText(expandedMap?"COMPACT MAP":"EXPAND MAP");});
    TextView fresh=button("20-MIN SOURCE-FIX WINDOW  /  OFF",()->{});
    LinearLayout.LayoutParams freshLp=new LinearLayout.LayoutParams(-1,dp(44));freshLp.topMargin=dp(6);filterDeck.addView(fresh,freshLp);
    fresh.setOnClickListener(v->{freshOnly=!freshOnly;chosen=null;
      fresh.setText(freshOnly?"20-MIN SOURCE-FIX WINDOW  /  ON":"20-MIN SOURCE-FIX WINDOW  /  OFF");render();});
    flightEvidence=new Duwm1690EvidenceBars(this);
    TextView altitude=button("ALL ALTITUDES  /  TAP FOR 9,000m+",()->{});
    LinearLayout.LayoutParams altitudeLp=new LinearLayout.LayoutParams(-1,dp(45));altitudeLp.topMargin=dp(7);filterDeck.addView(altitude,altitudeLp);
    altitude.setOnClickListener(v->{highAltitudeOnly=!highAltitudeOnly;chosen=null;
      altitude.setText(highAltitudeOnly?"HIGH-ALTITUDE RECEIPTS  /  9,000m+":"ALL ALTITUDES  /  TAP FOR 9,000m+");render();});
    TextView speedFilter=button("ALL REPORTED SPEEDS / TAP FOR 400+ KM/H",()->{});
    filterDeck.addView(speedFilter,new LinearLayout.LayoutParams(-1,dp(48)));
    speedFilter.setOnClickListener(v->{fastOnly=!fastOnly;chosen=null;
      speedFilter.setText(fastOnly?"SPEED 400+ KM/H / REAL RECEIPTS":"ALL REPORTED SPEEDS / TAP FOR 400+ KM/H");render();});
    TextView orderAircraft=button("ORDER AIRCRAFT: MOST RECENT RECEIPT",()->{});
    filterDeck.addView(orderAircraft,new LinearLayout.LayoutParams(-1,dp(47)));
    orderAircraft.setOnClickListener(v->{aircraftOrder=(aircraftOrder+1)%3;
      orderAircraft.setText(aircraftOrder==1?"ORDER AIRCRAFT: HIGHEST REPORTED SPEED":
        aircraftOrder==2?"ORDER AIRCRAFT: HIGHEST REPORTED ALTITUDE":"ORDER AIRCRAFT: MOST RECENT RECEIPT");
      visibleAircraftRows=12;render();});
    TextView resetFlight=button("CLEAR ALL FILTERS  /  SHOW RECEIVED WORLD POSITIONS",()->{});
    filterDeck.addView(resetFlight,new LinearLayout.LayoutParams(-1,dp(49)));
    resetFlight.setOnClickListener(v->{pairsOnly=false;freshOnly=false;highAltitudeOnly=false;fastOnly=false;aircraftOrder=0;
      chosen=null;visibleAircraftRows=12;region.setSelection(0);search.setText("");
      paired.setText("ALL REPORTED FIXES");fresh.setText("20-MIN SOURCE-FIX WINDOW  /  OFF");
      altitude.setText("ALL ALTITUDES  /  TAP FOR 9,000m+");speedFilter.setText("ALL REPORTED SPEEDS / TAP FOR 400+ KM/H");
      orderAircraft.setText("ORDER AIRCRAFT: MOST RECENT RECEIPT");render();});
    flightQuickFacts=text("SOURCE RECEIPT  /  WAITING FOR VERIFIED POSITIONS",12,CYAN);
    flightQuickFacts.setPadding(dp(12),dp(10),dp(12),dp(10));
    flightQuickFacts.setBackground(Duwm1678VisualKit.panel(this,"AIRCRAFT",false));
    LinearLayout.LayoutParams factsParams=new LinearLayout.LayoutParams(-1,-2);
    factsParams.topMargin=dp(8);root.addView(flightQuickFacts,factsParams);
    map=new Duwm1670WorldMapView(this);map.setLayer("AIRCRAFT");
    map.setOnPinSelected(pin->{chosen=pin;map.setSelected(pin.id);showSelected();renderAircraftRegister();});
    liveMapParams=new LinearLayout.LayoutParams(-1,dp(570));liveMapParams.topMargin=dp(9);root.addView(map,liveMapParams);
    LinearLayout.LayoutParams chartLp=new LinearLayout.LayoutParams(-1,dp(225));chartLp.topMargin=dp(9);root.addView(flightEvidence,chartLp);
    TextView legend=text("✈  HEADING = REPORTED BEARING     ◉  SELECTED AIRCRAFT     ─  RECEIVED TWO-FIX TRAIL",10,CYAN);
    legend.setPadding(dp(7),dp(6),dp(7),dp(6));legend.setBackground(Duwm1678VisualKit.panel(this,"AIRCRAFT",false));root.addView(legend);
    TextView note=text("DRAG / PINCH MAP   •   TAP AIRCRAFT MARKER   •   LINES JOIN TWO RECEIVED OBSERVATIONS, NOT A SCHEDULED ROUTE",10,MUTED);
    note.setPadding(0,dp(8),0,dp(10));root.addView(note);
    details=text("Select one aircraft marker for real altitude, ground speed, heading and coordinates.",12,WHITE);details.setPadding(dp(12),dp(11),dp(12),dp(11));details.setBackground(frame());root.addView(details);
    TextView registerHead=text("RECEIVED AIRCRAFT / TAP A ROW TO CENTRE THE ORIGINAL MAP",12,CYAN);
    registerHead.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
    registerHead.setPadding(0,dp(13),0,dp(7));root.addView(registerHead);
    aircraftList=new LinearLayout(this);aircraftList.setOrientation(LinearLayout.VERTICAL);root.addView(aircraftList);
    LinearLayout selectedOps=new LinearLayout(this);root.addView(selectedOps);
    selectedOps.addView(button("FOLLOW SELECTED",()->{followSelected=!followSelected;
      if(followSelected&&chosen!=null)map.focus(chosen.lat,chosen.lon,3.25f);
      details.append(followSelected?"\nFOLLOW MODE ON: centres only on received position":"\nFOLLOW MODE OFF");
    }),new LinearLayout.LayoutParams(0,dp(48),1));
    TextView shareFlight=button("SHARE FLIGHT CARD",()->{
      if(chosen==null){details.setText("Select a source-reported aircraft before sharing.");return;}
      Duwm1670WorldMapView.Pin p=chosen;
      Duwm1671Share.share(this,"AIRCRAFT",p.title+" / "+p.id,
        String.format(Locale.US,"RECEIVED POSITION %.4f, %.4f / GROUND SPEED %s / ALTITUDE %s / HEADING %s",
          p.lat,p.lon,Double.isFinite(p.speed)?String.format(Locale.US,"%.0f km/h",p.speed*3.6):"UNKNOWN",
          Double.isFinite(p.altitude)?String.format(Locale.US,"%.0f m",p.altitude):"UNKNOWN",
          Double.isFinite(p.heading)?String.format(Locale.US,"%.0f°",p.heading):"UNKNOWN"),
        "OpenSky states/all","https://opensky-network.org/",p.observed);
    });LinearLayout.LayoutParams shp=new LinearLayout.LayoutParams(0,dp(48),1);shp.leftMargin=dp(8);selectedOps.addView(shareFlight,shp);
    LinearLayout tools=new LinearLayout(this);tools.setOrientation(LinearLayout.HORIZONTAL);
    LinearLayout.LayoutParams toolParams=new LinearLayout.LayoutParams(-1,dp(46));toolParams.topMargin=dp(7);
    root.addView(tools,toolParams);
    tools.addView(button("NEXT AIRCRAFT ▶",this::selectNextAircraft),new LinearLayout.LayoutParams(0,-1,1));
    TextView fit=button("FIT WORLD",()->{followSelected=false;if(map!=null)map.reset();});
    LinearLayout.LayoutParams fitParams=new LinearLayout.LayoutParams(0,-1,1);fitParams.leftMargin=dp(8);
    tools.addView(fit,fitParams);
    TextView dest=text("DESTINATION SCENARIO  /  USER SELECTED (NOT ACTUAL FLIGHT ROUTE)",11,AMBER);dest.setPadding(0,dp(12),0,dp(4));root.addView(dest);
    Spinner airports=spinner(AIRPORTS);root.addView(airports,new LinearLayout.LayoutParams(-1,dp(49)));
    airports.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
      @Override public void onItemSelected(AdapterView<?> p,View v,int pos,long id){destIndex=pos;
        if(map!=null){if(destIndex>0)map.setScenarioDestination(AIRPORT_GEO[destIndex][0],AIRPORT_GEO[destIndex][1],AIRPORTS[destIndex]);
          else map.clearScenario();}showSelected();}
      @Override public void onNothingSelected(AdapterView<?> p){} });
    LinearLayout foot=new LinearLayout(this);foot.setOrientation(LinearLayout.HORIZONTAL);root.addView(foot);
    foot.addView(button("FLIGHT REGISTER",()->startActivity(new Intent(this,RunningballV25FlightRegisterActivity.class))),new LinearLayout.LayoutParams(0,dp(48),1));
    TextView local=button("LOCAL RADAR 250 NM",()->startActivity(new Intent(this,AirRadarActivity.class)));
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1);lp.leftMargin=dp(7);foot.addView(local,lp);
    root.addView(text("DATA: OpenSky /states/all. Manual refresh is available without an artificial 15-minute button lock; provider HTTP 429 and memory safety remain in force. Actual airline destinations and verified ETAs require a separate authorized service.",11,MUTED));
    render();
  }
  private void renderAircraftRegister(){
    if(aircraftList==null)return;
    aircraftList.removeAllViews();
    if(aircraftOnMap.isEmpty()){
      aircraftList.addView(text("NO QUALIFIED AIRCRAFT RECEIVED FOR THE CHOSEN REGION AND FILTERS.",12,MUTED));return;
    }
    int end=Math.min(visibleAircraftRows,aircraftOnMap.size());
    for(int i=0;i<end;i++){
      final Duwm1670WorldMapView.Pin pin=aircraftOnMap.get(i);
      String speed=Double.isFinite(pin.speed)?String.format(Locale.US,"%.0f km/h",pin.speed*3.6d):"SPEED N/A";
      String altitude=Double.isFinite(pin.altitude)?String.format(Locale.US,"%.0f m",pin.altitude):"ALT N/A";
      String age=pin.observed>0?String.valueOf(Math.max(0L,(System.currentTimeMillis()-pin.observed)/60000L))+"m old":"TIME N/A";
      TextView line=button(String.format(Locale.US,"%02d  %s   •   %s\n%s  /  %s  /  %s  /  %s",i+1,pin.title,pin.id,altitude,speed,age,pin.genuinePair()?"2 REAL FIXES":"1 FIX"),()->{
        chosen=pin;if(map!=null){map.setSelected(pin.id);map.focus(pin.lat,pin.lon,3.7f);}showSelected();
        renderAircraftRegister();
      });
      line.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);line.setTextColor(chosen!=null&&chosen.id.equals(pin.id)?WHITE:CYAN);
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(64));lp.bottomMargin=dp(5);aircraftList.addView(line,lp);
    }
    if(end<aircraftOnMap.size()){
      TextView more=button("LOAD NEXT "+Math.min(12,aircraftOnMap.size()-end)+" AIRCRAFT  /  "+(aircraftOnMap.size()-end)+" REMAIN",()->{
        visibleAircraftRows+=12;renderAircraftRegister();
      });aircraftList.addView(more,new LinearLayout.LayoutParams(-1,dp(49)));
    }
  }
  private static double distanceKm(double la1,double lo1,double la2,double lo2){double rla=Math.toRadians(la2-la1),rlo=Math.toRadians(lo2-lo1);
    double a=Math.pow(Math.sin(rla/2),2)+Math.cos(Math.toRadians(la1))*Math.cos(Math.toRadians(la2))*Math.pow(Math.sin(rlo/2),2);
    return 6371.0088*2*Math.asin(Math.min(1,Math.sqrt(a)));
  }
  private void selectNextAircraft(){
    if(aircraftOnMap.isEmpty()){
      if(details!=null)details.setText("NO VERIFIED AIRCRAFT OBSERVATIONS FOR THIS SELECTION. REFRESH OR CLEAR FILTER.");
      return;
    }
    int index=-1;
    if(chosen!=null)for(int i=0;i<aircraftOnMap.size();i++){
      if(aircraftOnMap.get(i).id.equals(chosen.id)){index=i;break;}
    }
    chosen=aircraftOnMap.get((index+1)%aircraftOnMap.size());
    if(map!=null){map.setSelected(chosen.id);map.focus(chosen.lat,chosen.lon,3.2f);}
    showSelected();renderAircraftRegister();
  }
  private static String compass(double heading){
    if(!Double.isFinite(heading))return "N/A";
    String[] sectors={"N","NE","E","SE","S","SW","W","NW"};
    return sectors[((int)Math.round((((heading%360d)+360d)%360d)/45d))%8];
  }
  private void showSelected(){if(details==null)return;
    if(chosen==null){details.setText("TAP AN AIRCRAFT TO SEE REAL TELEMETRY. Destination ETA is unavailable until an airport is chosen as a hypothetical scenario.");return;}
    Duwm1670WorldMapView.Pin p=chosen;String speed=Double.isFinite(p.speed)?String.format(Locale.US,"%.0f km/h",p.speed*3.6d):"NOT REPORTED";
    String alt=Double.isFinite(p.altitude)?String.format(Locale.US,"%.0f m",p.altitude):"NOT REPORTED";
    String heading=Double.isFinite(p.heading)?String.format(Locale.US,"%.0f° %s",p.heading,compass(p.heading)):"NOT REPORTED";
    String knots=Double.isFinite(p.speed)?String.format(Locale.US,"%.0f kn",p.speed*1.943844d):"N/A";
    String feet=Double.isFinite(p.altitude)?String.format(Locale.US,"%.0f ft",p.altitude*3.28084d):"N/A";
    long age=Math.max(0L,(System.currentTimeMillis()-p.observed)/60000L);
    String trail=p.genuinePair()?String.format(Locale.US,"TWO REAL FIXES / %.1f KM OBSERVED SEPARATION",distanceKm(p.prevLat,p.prevLon,p.lat,p.lon)):
         "ONLY ONE QUALIFIED POSITION / NO VERIFIED MOVEMENT TRACK";
    String eta="ACTUAL DESTINATION AND ETA: UNAVAILABLE FROM THIS PROVIDER";
    if(destIndex>0){double d=distanceKm(p.lat,p.lon,AIRPORT_GEO[destIndex][0],AIRPORT_GEO[destIndex][1]);
      if(Double.isFinite(p.speed)&&p.speed>35d){long mins=Math.round(d/(p.speed*3.6d)*60d);
        eta=String.format(Locale.US,"ASSUMED DESTINATION %s  /  %.0f KM GREAT-CIRCLE  /  ~%d H %02d MIN AT REPORTED SPEED\nSCENARIO ONLY · NOT ACTUAL ROUTE, NOT SCHEDULED ETA",AIRPORTS[destIndex],d,mins/60,mins%60);
      }else eta="ASSUMED DESTINATION "+AIRPORTS[destIndex]+" / SPEED UNAVAILABLE FOR ETA SCENARIO";
    }
    details.setText("SELECTED AIRCRAFT  "+p.title+"\nICAO24 / "+p.id+"\n"+
      String.format(Locale.US,"POSITION  %.4f°, %.4f°",p.lat,p.lon)+"\n"+
      "GROUNDSPEED  "+speed+" ("+knots+")\n"+
      "ALTITUDE  "+alt+" ("+feet+")\n"+
      "HEADING  "+heading+"\n"+
      "SOURCE FIX  "+utc(p.observed)+"  /  "+age+" MIN OLD\n"+trail+"\n"+eta);
  }
  /** Region polygons are approximate geographic bounds, never a provider claim of complete coverage. */
  private static boolean inRegion(String name,double lat,double lon){
    switch(name){
      case "AFRICA":return lat>=-36&&lat<=38&&lon>=-19&&lon<=54;
      case "EUROPE":return lat>=35&&lat<=73&&lon>=-13&&lon<=45;
      case "MIDDLE EAST":return lat>=12&&lat<=43&&lon>=32&&lon<=64;
      case "INDIA / ASIA":return lat>=-11&&lat<=56&&lon>=60&&lon<=146;
      case "AMERICAS":return lat>=-57&&lat<=74&&lon>=-169&&lon<=-28;
      case "PACIFIC":return lat>=-51&&lat<=31&&(lon>=122||lon<=-111);
      default:return true;
    }
  }
  private void render(){if(map==null)return;
    RunningballV25GlobalAircraftData.Snapshot snap=RunningballV25GlobalAircraftData.read(this);
    ArrayList<Duwm1670WorldMapView.Pin> fresh=new ArrayList<>();HashMap<String,JSONArray> previous=new HashMap<>();
    if(snap.priorSourceAt>0&&snap.sourceAt>snap.priorSourceAt&&snap.sourceAt-snap.priorSourceAt<=5400000L)
      for(int i=0;i<snap.priorPoints.length();i++){JSONArray r=snap.priorPoints.optJSONArray(i);if(r!=null)previous.put(r.optString(2,""),r);}
    boolean visible=snap.hasGood()&&snap.ageMs()<=21600000L;
    JSONArray rows=visible?snap.points:new JSONArray();
    for(int i=0;i<rows.length();i++){
      JSONArray row=rows.optJSONArray(i);if(row==null)continue;
      double lat=row.optDouble(0,Double.NaN),lon=row.optDouble(1,Double.NaN);String hex=row.optString(2,"").trim();
      if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180||hex.isEmpty()||!inRegion(activeRegion,lat,lon))continue;
      String callsign=row.optString(3,"").trim();if(!callsignFilter.isEmpty()&&!hex.toUpperCase(Locale.US).contains(callsignFilter)&&!callsign.toUpperCase(Locale.US).contains(callsignFilter))continue;long at=Duwm1674TimeGuard.normalize(row.isNull(7)?snap.sourceAt:row.optLong(7,0L));
      if(at<=0L || !Duwm1674TimeGuard.recent(at,21600000L) || (freshOnly&&!Duwm1674TimeGuard.recent(at,1200000L)))continue;
      if(highAltitudeOnly&&(row.isNull(4)||!Double.isFinite(row.optDouble(4,Double.NaN))||row.optDouble(4)<9000d))continue;
      if(fastOnly&&(row.isNull(5)||!Double.isFinite(row.optDouble(5,Double.NaN))||row.optDouble(5)<(400d/3.6d)))continue;
      Duwm1670WorldMapView.Pin pin=new Duwm1670WorldMapView.Pin(hex,callsign.isEmpty()?hex:callsign,"AIRCRAFT",lat,lon,at,"OPENSKY RECEIVED POSITION");
      if(!row.isNull(4))pin.altitude=row.optDouble(4,Double.NaN);
      if(!row.isNull(5))pin.speed=row.optDouble(5,Double.NaN);
      if(!row.isNull(6))pin.heading=row.optDouble(6,Double.NaN);
      JSONArray before=previous.get(hex);
      if(before!=null){double a=before.optDouble(0,Double.NaN),b=before.optDouble(1,Double.NaN);
        long old=Duwm1674TimeGuard.normalize(before.isNull(7)?snap.priorSourceAt:before.optLong(7,0));
        if(Double.isFinite(a)&&Double.isFinite(b)&&old>0&&at>old&&at-old<=5400000L&&
          RunningballV25AircraftTrailPolicy.qualifies(hex,hex,a,b,lat,lon,old/1000L,at/1000L,snap.priorSourceAt,snap.sourceAt)){
          pin.prevLat=a;pin.prevLon=b;pin.prevObserved=old;
        }
      }
      if(!pairsOnly || pin.genuinePair())fresh.add(pin);
    }
    Collections.sort(fresh,(a,b)->{
      if(aircraftOrder==1){double av=Double.isFinite(a.speed)?a.speed:-1,bv=Double.isFinite(b.speed)?b.speed:-1;
        int c=Double.compare(bv,av);if(c!=0)return c;}
      if(aircraftOrder==2){double av=Double.isFinite(a.altitude)?a.altitude:-1,bv=Double.isFinite(b.altitude)?b.altitude:-1;
        int c=Double.compare(bv,av);if(c!=0)return c;}
      return Long.compare(b.observed,a.observed);
    });
    String key=snap.sourceAt+":"+snap.priorSourceAt+":"+fresh.size()+":"+callsignFilter+":"+pairsOnly+":"+activeRegion+":"+freshOnly+":"+highAltitudeOnly+":"+fastOnly+":"+aircraftOrder;boolean changed=!key.equals(displayedKey);displayedKey=key;
    map.setPins(fresh,changed);
    aircraftOnMap.clear();aircraftOnMap.addAll(fresh);
    sourceAt=snap.sourceAt;
    if(flightQuickFacts!=null){
      int moving=0,withAltitude=0,qualifiedPairs=0;
      for(Duwm1670WorldMapView.Pin p:fresh){
        if(Double.isFinite(p.speed)&&p.speed>3d)moving++;
        if(Double.isFinite(p.altitude))withAltitude++;
        if(p.genuinePair())qualifiedPairs++;
      }
      flightQuickFacts.setText(String.format(Locale.US,
        "ON MAP  %,d   •   GROUND SPEED > 3 m/s  %,d   •   ALTITUDE REPORTED  %,d\nTWO REAL FIXES  %,d   •   SOURCE  %s",
        fresh.size(),moving,withAltitude,qualifiedPairs,utc(snap.sourceAt)));
      if(flightEvidence!=null)flightEvidence.setValues("AIR TRAFFIC / RECEIVED MAP SAMPLE",
        new String[]{"MAPPED FIXES","MOVING > 3 m/s","ALTITUDE GIVEN","TWO REAL FIXES"},
        new long[]{fresh.size(),moving,withAltitude,qualifiedPairs});
    }
    summary.setText("REGION "+activeRegion+"  /  "+(freshOnly?"LAST 20-MIN FIXES  /  ":"")+(snap.hasGood()?snap.countLabel():"--")+" PROVIDER RECORDS  /  "+fresh.size()+(pairsOnly?" VERIFIED TWO-FIX TRACKS":" MAP POSITIONS")+"  /  "+map.observedPairCount()+" TWO-FIX DISPLACEMENTS"+
      (callsignFilter.isEmpty()?"":"  /  FILTERED "+callsignFilter));
    source.setText("OPENSKY  •  "+snap.status()+"  •  "+snap.ageLabel()+"  •  SOURCE "+utc(sourceAt)+"  •  NEXT FETCH "+snap.nextCheckLabel());
    source.setTextColor(snap.ageMs()<1200000L&&snap.error.isEmpty()?CYAN:AMBER);
    if(flightBand!=null)flightBand.setReceipt(snap.hasGood()?"OPENSKY RECEIPT / "+snap.ageLabel():"OPENSKY DATA UNAVAILABLE",fresh.size(),snap.hasGood()&&snap.error.isEmpty());
    if(chosen!=null){Duwm1670WorldMapView.Pin replacement=null;for(Duwm1670WorldMapView.Pin pin:fresh)if(pin.id.equals(chosen.id)){replacement=pin;break;}
      chosen=replacement;if(chosen!=null){map.setSelected(chosen.id);if(followSelected)map.focus(chosen.lat,chosen.lon,3.25f);}}
    showSelected();
    if(changed)renderAircraftRegister();
  }
  @Override protected void onResume(){super.onResume();active=true;if(map!=null)map.resume();if(flightBand!=null)flightBand.start();ui.removeCallbacks(tick);ui.post(tick);
    RunningballV25GlobalAircraftData.refresh(this,()->{if(active)render();});}
  @Override protected void onPause(){active=false;ui.removeCallbacks(tick);if(map!=null)map.pause();if(flightBand!=null)flightBand.stop();super.onPause();}
}
