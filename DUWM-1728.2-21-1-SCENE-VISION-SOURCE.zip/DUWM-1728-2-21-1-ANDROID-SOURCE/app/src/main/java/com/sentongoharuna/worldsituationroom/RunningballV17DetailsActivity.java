package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.Intent;
import android.net.Uri;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

/** Factual details for public providers with tap-through to original reporting. */
public final class RunningballV17DetailsActivity extends Activity {
  private static final int BG=0xFF041424,INK=0xFFE4EDFE,MUTED=0xFF4C78C4,CYAN=0xFF558BDF,GREEN=DuwmUnifiedTheme.STATUS_GREEN,GOLD=0xFF558BDF;
  private String feed=RunningballV17Feeds.NEWS;
  private LinearLayout body;private ScrollView scroller;
  private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
  private TextView text(String s,int sp,int col,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(col);if(bold)t.setTypeface(null,1);return t;}
  private GradientDrawable card(int tint){GradientDrawable b=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFF112549,0xFF041424});b.setCornerRadius(dp(14));b.setStroke(dp(1),tint);return b;}
  private void add(String text,int size,int color,boolean bold,int top){TextView v=text(text,size,color,bold);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(top);body.addView(v,p);}
  private void action(String label,Runnable work,int color){TextView b=text(label,12,color,true);b.setGravity(Gravity.CENTER);b.setPadding(dp(12),dp(14),dp(12),dp(14));b.setBackground(card(color));b.setOnClickListener(v->work.run());LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(10);body.addView(b,bp);}
  private String pretty(double d,String unit){return Double.isFinite(d)?String.format(Locale.US,"%.1f%s",d,unit):"NOT REPORTED";}
  private void openLink(String uri){if(uri==null||!uri.startsWith("https://"))return;
    try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(uri)).addCategory(Intent.CATEGORY_BROWSABLE));}
    catch(Exception e){android.widget.Toast.makeText(this,"No browser available",android.widget.Toast.LENGTH_SHORT).show();}
  }
  private void share(){String text="RUNNINGBALL2 V17 / "+feed.toUpperCase(Locale.US)+"\n"+summary()+"\nSource timestamps and availability shown in app";
    Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,text);
    startActivity(Intent.createChooser(send,"Share source status"));}
  private String summary(){JSONObject data=RunningballV17Feeds.cached(this,feed);long t=RunningballV17Feeds.received(this,feed);
    if(t<=0)return "NO VERIFIED SOURCE SNAPSHOT";
    if(feed.equals(RunningballV17Feeds.FX))return "USD reference rates / "+data.optString("date","no date");
    if(feed.equals(RunningballV17Feeds.WEATHER))return "Model weather / "+data.optString("region","no region");
    JSONArray a=data.optJSONArray("articles");return "Retrieved "+(a==null?0:a.length())+" publisher-linked article records";
  }
  @Override protected void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
    String f=getIntent().getStringExtra("feed");if(RunningballV17Feeds.WEATHER.equals(f)||RunningballV17Feeds.FX.equals(f))feed=f;
    scroller=new ScrollView(this);scroller.setFillViewport(true);scroller.setBackgroundColor(BG);
    body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(18),dp(18),dp(18),dp(30));scroller.addView(body);
    scroller.setOnApplyWindowInsetsListener((v,insets)->{
      if(Build.VERSION.SDK_INT>=30){android.graphics.Insets b=insets.getInsets(WindowInsets.Type.systemBars());
        body.setPadding(dp(18),dp(18)+b.top,dp(18),dp(30)+b.bottom);}
      else{body.setPadding(dp(18),dp(18)+insets.getSystemWindowInsetTop(),dp(18),dp(30)+insets.getSystemWindowInsetBottom());}
      return insets;
    });setContentView(scroller);scroller.requestApplyInsets();render();
  }
  private void render(){body.removeAllViews();String label=feed.equals(RunningballV17Feeds.NEWS)?"WORLD NEWS":feed.equals(RunningballV17Feeds.WEATHER)?"REGIONAL WEATHER":"CURRENCY REFERENCE";
    add("‹  RUNNINGBALL2 / V17 / VERIFIED SOURCES",11,CYAN,true,0);
    action("RETURN TO COMMAND CENTER",this::finish,CYAN);
    add(label,24,INK,true,16);
    long time=RunningballV17Feeds.received(this,feed);String err=RunningballV17Feeds.error(this,feed);
    add("LAST SUCCESS: "+RunningballV17Feeds.age(time),11,time>0?GREEN:GOLD,true,10);
    if(!err.isEmpty())add("PROVIDER ERROR: "+err+" / OLDER SNAPSHOT MAY BE SHOWN",11,GOLD,false,7);
    action("REQUEST FRESH SOURCE DATA",()->{RunningballV17Feeds.request(this,true,()->render());},GREEN);
    action("SHARE SOURCED STATUS",this::share,CYAN);
    JSONObject cache=RunningballV17Feeds.cached(this,feed);
    if(feed.equals(RunningballV17Feeds.NEWS)){
      add("PROVIDER: "+cache.optString("provider","NEWS SOURCE")+" • LINKED HEADLINES",11,MUTED,false,17);
      add("A headline is third-party reporting, not independently verified by this app.",11,GOLD,false,7);
      JSONArray articles=cache.optJSONArray("articles");
      if(articles==null||articles.length()==0)add("NO NEWS ARTICLES RETRIEVED",16,MUTED,true,19);
      else for(int i=0;i<articles.length()&&i<15;i++){
        JSONObject a=articles.optJSONObject(i);if(a==null)continue;
        String headline=a.optString("title","UNTITLED");String host=a.optString("domain","PUBLISHER UNAVAILABLE");
        TextView cardView=text(headline+"\n\n"+host+"  ·  "+a.optString("seen","DATE UNAVAILABLE")+"\nTAP TO READ ORIGINAL",13,INK,true);
        cardView.setPadding(dp(14),dp(13),dp(14),dp(13));cardView.setBackground(card(CYAN));
        final String url=a.optString("url","");cardView.setOnClickListener(v->openLink(url));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(11);body.addView(cardView,p);
      }
    } else if(feed.equals(RunningballV17Feeds.WEATHER)){
      add("PROVIDER: OPEN-METEO • MODEL-DERIVED CURRENT WEATHER",11,MUTED,false,17);
      if(!RunningballWorldTarget.ready(this)){add("SELECT A WORLD REGION TO REQUEST WEATHER",15,GOLD,true,16);action("CHOOSE WORLD REGION",()->startActivity(new Intent(this,RunningballWorldExplorerActivity.class)),GREEN);return;}
      String selected=String.format(Locale.US,"%.4f,%.4f",RunningballWorldTarget.lat(this),RunningballWorldTarget.lon(this));
      if(!selected.equals(cache.optString("region",""))){add("NO WEATHER RECEIVED FOR THE CURRENT SELECTED REGION",15,GOLD,true,18);return;}
      add("WORLD REGION: "+RunningballWorldTarget.label(this),14,INK,true,18);
      add("MODEL VALID TIME (UTC): "+cache.optString("time","UNAVAILABLE"),12,MUTED,false,7);
      add("TEMPERATURE: "+pretty(cache.optDouble("temperature",Double.NaN)," °C"),18,INK,true,15);
      add("WIND AT 10m: "+pretty(cache.optDouble("wind",Double.NaN)," km/h"),15,INK,false,12);
      add("PRECIPITATION: "+pretty(cache.optDouble("precipitation",Double.NaN)," mm"),15,INK,false,12);
      add("WMO WEATHER CODE: "+cache.optInt("code",-1),13,MUTED,false,10);
      add("Forecast-model output is not a severe-weather alert or direct ground measurement.",11,GOLD,false,15);
      action("OPEN WEATHER PROVIDER",()->openLink("https://open-meteo.com/"),CYAN);
    }else{
      add("PROVIDER: FRANKFURTER • OFFICIAL DAILY FX REFERENCE RATES",11,MUTED,false,17);
      add("REFERENCE DATE: "+cache.optString("date","NOT REPORTED"),14,INK,true,15);
      JSONObject rates=cache.optJSONObject("rates");
      if(rates==null){add("NO OFFICIAL REFERENCE RATES RETRIEVED",15,GOLD,true,15);return;}
      add("1 USD → EUR "+pretty(rates.optDouble("EUR",Double.NaN),""),18,INK,true,20);
      add("1 USD → GBP "+pretty(rates.optDouble("GBP",Double.NaN),""),18,INK,true,14);
      add("1 USD → JPY "+pretty(rates.optDouble("JPY",Double.NaN),""),18,INK,true,14);
      add("DAILY REFERENCE • NOT LIVE TRADE QUOTES • NO INTRADAY PRICE MOVEMENT IMPLIED",11,GOLD,false,19);
      action("OPEN REFERENCE DATA PROVIDER",()->openLink("https://frankfurter.dev/"),CYAN);
    }
  }
}
