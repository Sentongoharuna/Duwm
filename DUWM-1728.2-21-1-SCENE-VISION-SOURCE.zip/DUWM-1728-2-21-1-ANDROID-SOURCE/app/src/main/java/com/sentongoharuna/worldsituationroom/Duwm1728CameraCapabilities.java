package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.hardware.camera2.params.DynamicRangeProfiles;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaRecorder;
import android.os.Build;
import android.util.Range;
import android.util.Size;

/** Read-only device capability disclosure, never permission to claim a recorded mode works. */
public final class Duwm1728CameraCapabilities {
    private Duwm1728CameraCapabilities(){}
    public static String inspect(Context context){
        StringBuilder out=new StringBuilder();
        try{
            CameraManager manager=(CameraManager)context.getSystemService(Context.CAMERA_SERVICE);
            if(manager==null)return "Camera service unavailable";
            for(String id:manager.getCameraIdList()){
                CameraCharacteristics c=manager.getCameraCharacteristics(id);
                StreamConfigurationMap streams=c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                boolean uhd=false,sixty=false,highSpeed=false,stabilization=false,hdr10=false;
                if(streams!=null){
                    Size[] sizes=streams.getOutputSizes(MediaRecorder.class);
                    if(sizes!=null)for(Size s:sizes)if((long)s.getWidth()*s.getHeight()>=3840L*2160L)uhd=true;
                    Size[] hs=streams.getHighSpeedVideoSizes();
                    highSpeed=hs!=null&&hs.length>0;
                }
                Range<Integer>[] fps=c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
                if(fps!=null)for(Range<Integer> range:fps)if(range.getUpper()>=60)sixty=true;
                int[] modes=c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES);
                if(modes!=null)for(int mode:modes)if(mode!=0)stabilization=true;
                if(Build.VERSION.SDK_INT>=33){
                    DynamicRangeProfiles profiles=c.get(CameraCharacteristics.REQUEST_AVAILABLE_DYNAMIC_RANGE_PROFILES);
                    if(profiles!=null)for(Long profile:profiles.getSupportedProfiles()){
                        if(profile!=DynamicRangeProfiles.STANDARD)hdr10=true;
                    }
                }
                out.append("CAMERA ").append(id)
                   .append("\n4K recorder size: ").append(uhd?"ADVERTISED":"NOT ADVERTISED")
                   .append("\n60 fps AE: ").append(sixty?"ADVERTISED":"NOT ADVERTISED")
                   .append("\n120+ high speed: ").append(highSpeed?"ADVERTISED (separate session required)":"NOT ADVERTISED")
                   .append("\nVideo stabilisation: ").append(stabilization?"ADVERTISED":"NOT ADVERTISED")
                   .append("\n10-bit HDR: ").append(hdr10?"ADVERTISED (separate capture path required)":"NOT ADVERTISED")
                   .append("\n\n");
            }
        }catch(Exception ex){out.append("Camera2 inspection unavailable: ").append(ex.getClass().getSimpleName());}
        boolean h264=false;
        try{
            for(MediaCodecInfo info:new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos()){
                if(!info.isEncoder())continue;
                for(String type:info.getSupportedTypes())if("video/avc".equalsIgnoreCase(type))h264=true;
            }
        }catch(Exception ex){out.append("Encoder inspection unavailable.\n");}
        out.append("H.264 encoder present: ").append(h264?"YES":"NO");
        return out.toString();
    }
}
