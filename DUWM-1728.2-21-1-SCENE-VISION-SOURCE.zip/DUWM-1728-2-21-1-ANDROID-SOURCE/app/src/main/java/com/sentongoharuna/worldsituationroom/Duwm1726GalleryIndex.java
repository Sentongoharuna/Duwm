package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.net.Uri;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;

/** Local index of actual completed gallery exports only; no media-library permission needed. */
public final class Duwm1726GalleryIndex {
    private Duwm1726GalleryIndex() {}
    private static final String PREF="duwm1726_gallery_exports", KEY="items";
    public static void add(Context context,Uri uri,String name){
        if(context==null||uri==null||name==null||!name.matches("[A-Za-z0-9_.-]+\\.mp4"))return;
        SharedPreferences p=context.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);
        String previous=p.getString(KEY,"");
        String record=uri.toString()+"\t"+name;
        StringBuilder out=new StringBuilder(record);
        int count=1;
        for(String row:previous.split("\n")){
            if(row.isEmpty()||row.equals(record)||count>=60)continue;
            out.append('\n').append(row);count++;
        }
        p.edit().putString(KEY,out.toString()).apply();
    }
    public static List<String[]> list(Context context){
        ArrayList<String[]> results=new ArrayList<>();
        String data=context.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(KEY,"");
        for(String row:data.split("\n")){
            int split=row.indexOf('\t');
            if(split<0)continue;
            String uri=row.substring(0,split),name=row.substring(split+1);
            if(uri.startsWith("content://") && !name.isEmpty())results.add(new String[]{uri,name});
        }
        return results;
    }
}
