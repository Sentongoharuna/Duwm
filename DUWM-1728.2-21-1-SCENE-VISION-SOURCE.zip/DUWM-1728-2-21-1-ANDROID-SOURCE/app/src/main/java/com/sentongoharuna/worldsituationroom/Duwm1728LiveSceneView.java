package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;

/** UI-only scene overlay. The underlying TextureView supplies clean pixels to
 * ML Kit; this sibling is never captured by that TextureView or MediaRecorder. */
public final class Duwm1728LiveSceneView extends View {
    private final Duwm1728BroadcastLayout.Report report = new Duwm1728BroadcastLayout.Report();
    private long sourceTimeMs;

    public Duwm1728LiveSceneView(Context context) {
        super(context);
        setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        setClickable(false);
        setFocusable(false);
        report.composition = Duwm1728BroadcastComposition.COMPACT;
        report.automaticSceneTitles = true;
        report.automaticHeadlineFit = true;
        report.sceneNeutralTitle = "CAMERA VIEW";
        report.clock = "CAMERA PREVIEW";
        report.category = "SCENE";
        report.provenance = "AI SCENE DESCRIPTION";
    }

    public void update(Duwm1728SceneTimeline.Entry observation, long atMs, boolean recording) {
        sourceTimeMs = Math.max(0, atMs);
        report.clock = recording ? "RECORDING" : "CAMERA PREVIEW";
        report.sceneAtMs = observation == null ? -1 : observation.atMs;
        report.sceneUntilMs = observation == null ? -1 : observation.validUntilMs;
        report.sceneTitle = observation == null ? "" : observation.title;
        report.sceneDescription = observation == null ? "" : observation.description;
        report.sceneSource = observation == null ? "" : observation.source;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (getWidth() < 64 || getHeight() < 64) return;
        Duwm1728BroadcastLayout.draw(new Duwm1728BroadcastCanvas(canvas),
                getWidth(), getHeight(), report, sourceTimeMs);
    }
}
