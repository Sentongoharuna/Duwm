package com.sentongoharuna.worldsituationroom;
import android.graphics.*;
public final class Duwm1728BroadcastCanvas implements Duwm1728BroadcastLayout.Painter {
    private final Canvas canvas;private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.SUBPIXEL_TEXT_FLAG);
    private final Typeface regular=Typeface.create("sans-serif",Typeface.NORMAL),bold=Typeface.create("sans-serif",Typeface.BOLD);
    private final Object captionMetrics=java.util.Collections.unmodifiableList(java.util.Arrays.asList(
        Duwm1728BroadcastCanvas.class,regular,bold,android.os.Build.VERSION.SDK_INT>=24?p.getTextLocales().toLanguageTags():p.getTextLocale().toLanguageTag()));
    public Duwm1728BroadcastCanvas(Canvas c){canvas=c;}
    public void rect(float x,float y,float w,float h,int color,float radius){p.setStyle(Paint.Style.FILL);p.setColor(color);canvas.drawRoundRect(new RectF(x,y,x+w,y+h),radius,radius,p);}
    public void line(float x,float y,float x2,float y2,int color,float stroke){p.setStyle(Paint.Style.STROKE);p.setColor(color);p.setStrokeWidth(Math.max(.7f,stroke));canvas.drawLine(x,y,x2,y2,p);p.setStyle(Paint.Style.FILL);}
    public void text(String t,float x,float y,float size,int color,boolean heavy){p.setStyle(Paint.Style.FILL);p.setTypeface(heavy?bold:regular);p.setTextSize(size);p.setColor(color);canvas.drawText(t,x,y,p);}
    public float measure(String t,float size,boolean heavy){p.setTypeface(heavy?bold:regular);p.setTextSize(size);return p.measureText(t);}
    public Object captionMeasurementKey(){return captionMetrics;}
    public void clip(float x,float y,float w,float h){canvas.save();canvas.clipRect(x,y,x+w,y+h);}
    public void unclip(){canvas.restore();}
}
