package com.sentongoharuna.worldsituationroom;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * 1724. Publish ONLY a completed, nonempty MP4 to the user's actual Gallery.
 * No third-party service, public upload, or hidden sharing is involved.
 * On Android 10+ MediaStore.IS_PENDING ensures incomplete copies are invisible;
 * on Android 6-9 the caller must request WRITE_EXTERNAL_STORAGE before capture.
 */
public final class Duwm1724GalleryPublisher {
    private Duwm1724GalleryPublisher() {}
    private static final int BUFFER=65536;
    public static final String ALBUM="DUWM Monitors Cam";

    public static boolean needsLegacyPermission(Context context) {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
                context.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED;
    }

    /** Returns a genuine gallery Uri or throws; never reports success on a failed copy. */
    public static Uri publish(Context context,File mp4,String name) throws IOException {
        if(mp4==null || !mp4.isFile() || mp4.length()<1024) throw new IOException("Incomplete MP4");
        if(name==null || !name.matches("[A-Za-z0-9_.-]+\\.mp4")) throw new IOException("Unsafe video filename");
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver=context.getContentResolver();
            Uri collection=MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            ContentValues values=new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME,name);
            values.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH,Environment.DIRECTORY_MOVIES+"/"+ALBUM);
            values.put(MediaStore.Video.Media.IS_PENDING,1);
            Uri video=resolver.insert(collection,values);
            if(video==null)throw new IOException("Gallery rejected video entry");
            boolean completed=false;
            try {
                try(FileInputStream in=new FileInputStream(mp4);OutputStream out=resolver.openOutputStream(video,"w")) {
                    if(out==null)throw new IOException("Gallery output stream unavailable");
                    transfer(in,out);
                }
                ContentValues published=new ContentValues();
                published.put(MediaStore.Video.Media.IS_PENDING,0);
                if(resolver.update(video,published,null,null)<1)throw new IOException("Cannot publish gallery item");
                completed=true;
                return video;
            } finally {if(!completed)resolver.delete(video,null,null);}
        }
        if(needsLegacyPermission(context))throw new IOException("Legacy gallery storage permission not granted");
        File movies=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
        File album=new File(movies,ALBUM);
        if(!album.exists() && !album.mkdirs())throw new IOException("Cannot create gallery album");
        File dest=new File(album,name);
        // Avoid overwriting an unrelated video on devices with pre-scoped storage.
        int suffix=1;
        while(dest.exists())dest=new File(album,name.replace(".mp4","-"+(suffix++)+".mp4"));
        boolean completed=false;
        try {
            try(FileInputStream in=new FileInputStream(mp4);FileOutputStream out=new FileOutputStream(dest)) {
                transfer(in,out);out.getFD().sync();
            }
            if(dest.length()!=mp4.length())throw new IOException("Gallery file size mismatch");
            // API 23–28 still needs a MediaStore content URI. file:// cannot be
            // granted to another app and was also discarded by our Gallery index.
            ContentValues values=new ContentValues();
            values.put(MediaStore.Video.Media.DATA,dest.getAbsolutePath());
            values.put(MediaStore.Video.Media.DISPLAY_NAME,dest.getName());
            values.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");
            values.put(MediaStore.Video.Media.SIZE,dest.length());
            values.put(MediaStore.Video.Media.DATE_ADDED,System.currentTimeMillis()/1000L);
            Uri video=context.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,values);
            if(video==null)throw new IOException("Gallery rejected video entry");
            completed=true;
            // Registration already succeeded; scanning only fills optional metadata.
            try{MediaScannerConnection.scanFile(context,new String[]{dest.getAbsolutePath()},new String[]{"video/mp4"},null);}
            catch(RuntimeException ignored){}
            return video;
        } finally {if(!completed)dest.delete();}
    }
    private static void transfer(FileInputStream input,OutputStream output)throws IOException {
        byte[] block=new byte[BUFFER];int read;
        while((read=input.read(block))!=-1)output.write(block,0,read);
        output.flush();
    }
}
