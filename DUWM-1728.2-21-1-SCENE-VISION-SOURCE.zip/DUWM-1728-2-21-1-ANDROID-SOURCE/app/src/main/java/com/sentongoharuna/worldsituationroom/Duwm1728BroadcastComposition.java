package com.sentongoharuna.worldsituationroom;

/** Stable visual layout choices. The layout never changes report facts or cue times. */
public final class Duwm1728BroadcastComposition {
    public static final String FULL="FULL", COMPACT="COMPACT", CAPTIONS="CAPTIONS";
    private Duwm1728BroadcastComposition() {}

    /** Old drafts and unknown values keep the established full report composition. */
    public static String normalize(String value) {
        if(COMPACT.equals(value))return COMPACT;
        if(CAPTIONS.equals(value))return CAPTIONS;
        return FULL;
    }
    public static String label(String value) {
        String selected=normalize(value);
        if(COMPACT.equals(selected))return "COMPACT";
        if(CAPTIONS.equals(selected))return "CAPTIONS";
        return "FULL REPORT";
    }
    public static String description(String value) {
        String selected=normalize(value);
        if(COMPACT.equals(selected))return "Smaller headline and byline, slim ticker and recorded sensor row. Category and report status stay visible.";
        if(CAPTIONS.equals(selected))return "Timed captions with the DUWM header, category and report status. Headline, ticker and sensor row are hidden.";
        return "Full headline and byline, moving ticker, recorded sensor row and timed captions. Category and report status stay visible.";
    }
}
