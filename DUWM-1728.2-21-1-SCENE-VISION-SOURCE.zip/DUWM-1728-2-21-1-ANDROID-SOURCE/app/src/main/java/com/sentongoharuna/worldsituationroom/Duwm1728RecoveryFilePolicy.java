package com.sentongoharuna.worldsituationroom;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** Android-independent path and byte-identity rules for completed recovery copies. */
public final class Duwm1728RecoveryFilePolicy {
    private Duwm1728RecoveryFilePolicy() {}
    public static void requireId(String id) {
        if(id==null||!id.matches("[a-f0-9]{32}"))throw new IllegalArgumentException("Invalid recovery id");
    }
    public static void requireName(String name) {
        if(name==null||name.length()>180||!name.matches("[A-Za-z0-9_-][A-Za-z0-9_.-]*\\.mp4"))
            throw new IllegalArgumentException("Invalid MP4 filename");
    }
    public static File entryDirectory(File root,String id)throws IOException {
        requireId(id);File canonicalRoot=root.getCanonicalFile();
        File child=new File(canonicalRoot,id).getCanonicalFile();
        if(!canonicalRoot.equals(child.getParentFile())||!id.equals(child.getName()))
            throw new IOException("Recovery directory is outside its private store");
        return child;
    }
    public static File ownedFile(File directory,String name)throws IOException {
        if(!("video.mp4".equals(name)||"video.part".equals(name)||"record.json".equals(name)||"record.json.part".equals(name)))
            throw new IllegalArgumentException("Unknown recovery file");
        File parent=directory.getCanonicalFile(),file=new File(parent,name).getCanonicalFile();
        if(!parent.equals(file.getParentFile())||!name.equals(file.getName()))
            throw new IOException("Recovery file is outside its private directory");
        return file;
    }
    public static final class Identity {
        public final long bytes;public final String sha256;
        private Identity(long bytes,String sha256){this.bytes=bytes;this.sha256=sha256;}
    }
    public static Identity identity(File file)throws IOException {
        if(file==null||!file.isFile())throw new IOException("Completed MP4 is unavailable");
        MessageDigest digest=digest();long bytes=0;
        try(FileInputStream in=new FileInputStream(file)){
            byte[] buffer=new byte[65536];int count;
            while((count=in.read(buffer))!=-1){digest.update(buffer,0,count);bytes+=count;}
        }
        return new Identity(bytes,hex(digest.digest()));
    }
    /** Copy only; the caller's original is never moved, truncated, or deleted. */
    public static void copyExact(File original,File partial,long bytes,String sha256)throws IOException {
        if(original.getCanonicalFile().equals(partial.getCanonicalFile()))throw new IOException("Recovery copy must have a separate path");
        MessageDigest digest=digest();long copied=0;
        try(FileInputStream in=new FileInputStream(original);FileOutputStream out=new FileOutputStream(partial)){
            byte[] buffer=new byte[65536];int count;
            while((count=in.read(buffer))!=-1){out.write(buffer,0,count);digest.update(buffer,0,count);copied+=count;}
            out.flush();out.getFD().sync();
        }
        if(copied!=bytes||!hex(digest.digest()).equals(sha256))throw new IOException("Completed MP4 changed while making its recovery copy");
    }
    public static boolean matches(File file,long bytes,String sha256)throws IOException {
        if(file==null||!file.isFile()||file.length()!=bytes)return false;
        Identity actual=identity(file);return actual.bytes==bytes&&actual.sha256.equals(sha256);
    }
    private static MessageDigest digest(){try{return MessageDigest.getInstance("SHA-256");}
        catch(NoSuchAlgorithmException impossible){throw new IllegalStateException(impossible);}}
    private static String hex(byte[] bytes){StringBuilder out=new StringBuilder(bytes.length*2);char[] digits="0123456789abcdef".toCharArray();
        for(byte b:bytes){out.append(digits[(b&255)>>>4]);out.append(digits[b&15]);}return out.toString();}
}
