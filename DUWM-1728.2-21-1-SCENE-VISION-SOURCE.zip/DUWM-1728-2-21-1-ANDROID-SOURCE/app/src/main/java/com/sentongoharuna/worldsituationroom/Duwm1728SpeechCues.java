package com.sentongoharuna.worldsituationroom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Caption display intervals from reported word starts. RecognitionPart provides
 * no measured word ends: every end here is explicitly a bounded display estimate.
 */
public final class Duwm1728SpeechCues {
    public static final String REPORTED_STARTS_DERIVED_ENDS="REPORTED_STARTS_DERIVED_ENDS";
    public static final String TEXT_ONLY_UNTIMED="TEXT_ONLY_UNTIMED";
    private static final int TARGET_CHARS=160;
    private static final long MAX_GROUP_MS=3500,GAP_MS=1200,TAIL_MS=1200;
    private Duwm1728SpeechCues(){}
    public static final class Word {
        public final long offsetMs;
        public final String text;
        public Word(long offsetMs,String text){this.offsetMs=offsetMs;this.text=text;}
    }
    private static final class Group {
        final long start;long last;final StringBuilder text;
        Group(Word word){start=last=word.offsetMs;text=new StringBuilder(word.text);}
    }
    private static String words(String text){return Duwm1728CaptionEditPolicy.cue("0","0.001",text,1).text;}

    public static List<Duwm1728BroadcastLayout.Cue> fromWords(List<Word> input,long fromMs,long toMs){
        if(fromMs<0||toMs<=fromMs||toMs-fromMs>Duwm1728PcmTimeline.MAX_DURATION_MS)
            throw new IllegalArgumentException("Invalid recorded-audio source range");
        if(input==null||input.isEmpty())throw new IllegalArgumentException("No reported word timestamps");
        if(input.size()>Duwm1728CaptionEditPolicy.MAX_CUES)throw new IllegalArgumentException("Too many recognition parts");
        long duration=toMs-fromMs,last=-1;ArrayList<Word> tokens=new ArrayList<>();
        for(Word raw:input){
            if(raw==null||raw.offsetMs<0||raw.offsetMs>=duration||raw.offsetMs<last)
                throw new IllegalArgumentException("Reported word starts are outside or out of order within the source clip");
            String text=words(raw.text);last=raw.offsetMs;
            if(!tokens.isEmpty()&&tokens.get(tokens.size()-1).offsetMs==raw.offsetMs){
                Word prior=tokens.remove(tokens.size()-1);String combined=prior.text+" "+text;
                if(combined.length()>500)
                    throw new IllegalArgumentException("Simultaneous words exceed the caption limit; retain the untimed transcript for review");
                tokens.add(new Word(raw.offsetMs,combined));
            }else tokens.add(new Word(raw.offsetMs,text));
        }
        ArrayList<Group> groups=new ArrayList<>();Group current=null;
        for(Word word:tokens){
            if(current==null||word.offsetMs-current.last>GAP_MS||word.offsetMs-current.start>=MAX_GROUP_MS
                    ||current.text.length()+1+word.text.length()>TARGET_CHARS){
                current=new Group(word);groups.add(current);
            }else{current.text.append(' ').append(word.text);current.last=word.offsetMs;}
        }
        ArrayList<Duwm1728BroadcastLayout.Cue> output=new ArrayList<>(groups.size());
        for(int i=0;i<groups.size();i++){
            Group group=groups.get(i);long end=Math.min(duration,group.last+TAIL_MS);
            if(i+1<groups.size())end=Math.min(end,groups.get(i+1).start);
            if(end<=group.start)throw new IllegalArgumentException("Reported word timing cannot form a visible caption");
            output.add(new Duwm1728BroadcastLayout.Cue(fromMs+group.start,fromMs+end,group.text.toString()));
        }
        return Collections.unmodifiableList(output);
    }

    /** Legacy start-only editor strings have whole-second precision and delimiters.
     * Return an empty string when they cannot represent ALL cues without changes.
     * The structured cues remain the authoritative result.
     */
    public static String legacy(List<Duwm1728BroadcastLayout.Cue> cues,long fromMs){
        if(cues==null||cues.isEmpty()||cues.size()>12)return "";
        StringBuilder result=new StringBuilder();long previous=-1;
        for(Duwm1728BroadcastLayout.Cue cue:cues){
            long relative=cue.startMs-fromMs;
            if(relative<0||relative%1000!=0||relative<=previous||cue.text.length()>180||cue.text.indexOf(';')>=0||cue.text.indexOf('=')>=0)return "";
            if(result.length()>0)result.append(';');long seconds=relative/1000;
            result.append(String.format(Locale.ROOT,"%02d:%02d=",seconds/60,seconds%60)).append(cue.text);previous=relative;
        }
        return result.toString();
    }
}
