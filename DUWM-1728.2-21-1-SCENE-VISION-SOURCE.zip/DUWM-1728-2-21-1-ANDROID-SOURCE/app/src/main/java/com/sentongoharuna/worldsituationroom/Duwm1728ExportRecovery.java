package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.util.Log;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Durable completed MP4 copies. Every operation except URI helpers belongs on a worker.
 * A private copy is never represented as a Gallery save. Publication is never retried
 * automatically after an ambiguous result or a process interruption.
 */
public final class Duwm1728ExportRecovery {
    private static final String TAG="DUWM-RECOVERY", DIRECTORY="broadcast-recovery";
    private static final Object RECORD_LOCK=new Object();
    private static final Set<String> RETAINING=new HashSet<>(),PUBLISHING=new HashSet<>();
    private Duwm1728ExportRecovery() {}

    public enum State { READY, PUBLISHING, UNCONFIRMED, PUBLISHED }

    public static final class Entry {
        public final String id,name,sha256,lastError;
        public final Uri sourceUri,uri,publishedUri;
        public final State state;
        public final long createdAt,bytes;
        public final boolean hasLocalCopy;
        private Entry(Context app,Record record,File directory)throws IOException {
            id=record.id;name=record.name;sha256=record.sha256;lastError=record.error;
            sourceUri=record.source;uri=uri(app,id);publishedUri=record.published;
            state=record.state;createdAt=record.created;bytes=record.bytes;
            File local=Duwm1728RecoveryFilePolicy.ownedFile(directory,"video.mp4");
            hasLocalCopy=record.complete&&local.isFile()&&local.length()==bytes;
        }
    }
    public static final class BusyException extends IOException {
        public final Entry entry;
        private BusyException(Entry entry){super("This recovery copy is already being saved. Wait for its result.");this.entry=entry;}
    }
    public static final class UnconfirmedException extends IOException {
        public final Entry entry;
        /** Non-null only when the real publisher returned a URI but its receipt could not be stored. */
        public final Uri publishedUri;
        private UnconfirmedException(String message,Entry entry,Uri publishedUri,Throwable cause){
            super(message,cause);this.entry=entry;this.publishedUri=publishedUri;
        }
    }

    /** A test can substitute the transport while retaining the real durable state machine. */
    interface GalleryGateway { Uri publish(Context app,File completed,String name)throws Exception; }
    /** Use only when the gateway can prove no Gallery publication was attempted or committed. */
    static final class DefinitePublishFailure extends IOException {
        DefinitePublishFailure(String message){super(message);}
        DefinitePublishFailure(String message,Throwable cause){super(message,cause);}
    }
    private static final GalleryGateway GALLERY=(app,file,name)->{
        // This check can give a useful definite failure before insertion. The volume may
        // still disappear later; failures after calling the publisher remain ambiguous.
        try {
            if(Build.VERSION.SDK_INT>=29) {
                if(!MediaStore.getExternalVolumeNames(app).contains(MediaStore.VOLUME_EXTERNAL_PRIMARY))
                    throw new DefinitePublishFailure("The phone's primary Gallery storage is unavailable.");
            }else {
                if(!Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState()))
                    throw new DefinitePublishFailure("The phone's Gallery storage is not writable.");
                if(Duwm1724GalleryPublisher.needsLegacyPermission(app))
                    throw new DefinitePublishFailure("Gallery storage permission is required on this Android version.");
            }
        }catch(DefinitePublishFailure known){throw known;}
        catch(RuntimeException checkFailure){throw new DefinitePublishFailure("Gallery storage could not be checked before saving.",checkFailure);}
        return Duwm1724GalleryPublisher.publish(app,file,name);
    };

    public static Uri uri(Context context,String id) {
        Duwm1728RecoveryFilePolicy.requireId(id);
        return new Uri.Builder().scheme("content").authority(context.getPackageName()+".broadcast-recovery")
                .appendPath("exports").appendPath(id).build();
    }
    /** Strict path parsing: no arbitrary names, additional segments, query, or fragment. */
    public static String entryId(Uri uri) {
        if(uri==null||!"content".equals(uri.getScheme())||uri.getAuthority()==null||
                uri.getQuery()!=null||uri.getFragment()!=null||uri.getPathSegments().size()!=2||
                !"exports".equals(uri.getPathSegments().get(0)))throw new IllegalArgumentException("Invalid recovery URI");
        String id=uri.getPathSegments().get(1);Duwm1728RecoveryFilePolicy.requireId(id);
        if(!("/exports/"+id).equals(uri.getEncodedPath()))throw new IllegalArgumentException("Invalid recovery URI path");
        return id;
    }
    public static boolean isRecoveryUri(Context context,Uri uri) {
        try{return (context.getPackageName()+".broadcast-recovery").equals(uri.getAuthority())&&entryId(uri)!=null;}
        catch(RuntimeException invalid){return false;}
    }

    /** Copies a verified encoder result; never deletes or moves the supplied cache file. */
    public static Entry retain(Context context,File completedMp4,Uri sourceUri,String name)throws IOException {
        Context app=context.getApplicationContext();Duwm1728RecoveryFilePolicy.requireName(name);
        if(sourceUri==null||sourceUri.toString().isEmpty())throw new IOException("The original recording is unknown");
        Duwm1728RecoveryFilePolicy.Identity identity=Duwm1728RecoveryFilePolicy.identity(completedMp4);
        if(identity.bytes<1024)throw new IOException("Completed MP4 is too small to retain");
        Record record=new Record();record.id=UUID.randomUUID().toString().replace("-","");record.name=name;
        record.source=sourceUri;record.created=System.currentTimeMillis();record.bytes=identity.bytes;record.sha256=identity.sha256;
        File root=root(app,true),directory;String key;
        synchronized(RECORD_LOCK){
            directory=Duwm1728RecoveryFilePolicy.entryDirectory(root,record.id);
            if(!directory.mkdir())throw new IOException("Cannot create a durable recovery directory");
            syncDirectory(root);key=directory.getAbsolutePath();RETAINING.add(key);
        }
        try {
            // The manifest precedes the copy. A crash after video.mp4 is renamed but before
            // complete=true is persisted can be reconciled by hash, without guessing its source.
            synchronized(RECORD_LOCK){write(directory,record);}
            File partial=Duwm1728RecoveryFilePolicy.ownedFile(directory,"video.part");
            Duwm1728RecoveryFilePolicy.copyExact(completedMp4,partial,record.bytes,record.sha256);
            File finalFile=Duwm1728RecoveryFilePolicy.ownedFile(directory,"video.mp4");
            if(!Duwm1728RecoveryFilePolicy.matches(partial,record.bytes,record.sha256))throw new IOException("Recovery copy byte verification failed");
            rename(partial,finalFile);syncDirectory(directory);
            synchronized(RECORD_LOCK){record.complete=true;write(directory,record);return new Entry(app,record,directory);}
        } finally {synchronized(RECORD_LOCK){RETAINING.remove(key);}}
    }

    public static List<Entry> list(Context context)throws IOException {
        Context app=context.getApplicationContext();File root=root(app,false);
        if(!root.exists())return Collections.emptyList();
        synchronized(RECORD_LOCK){
            File[] directories=root.listFiles();if(directories==null)throw new IOException("Cannot read recovery copies");
            ArrayList<Entry> entries=new ArrayList<>();
            for(File candidate:directories){
                if(!candidate.getName().matches("[a-f0-9]{32}"))continue;
                File directory=Duwm1728RecoveryFilePolicy.entryDirectory(root,candidate.getName());
                if(!directory.isDirectory())continue;
                Record record=readReconciled(directory);
                if(record!=null){entries.add(new Entry(app,record,directory));if(record.state==State.PUBLISHED)repairSuccess(app,record,false);}
            }
            Collections.sort(entries,(a,b)->{int byTime=Long.compare(b.createdAt,a.createdAt);return byTime!=0?byTime:a.id.compareTo(b.id);});
            return Collections.unmodifiableList(entries);
        }
    }
    public static Entry find(Context context,String id)throws IOException {
        Context app=context.getApplicationContext();File directory=Duwm1728RecoveryFilePolicy.entryDirectory(root(app,false),id);
        synchronized(RECORD_LOCK){Record record=readReconciled(directory);if(record==null)return null;
            if(record.state==State.PUBLISHED)repairSuccess(app,record,false);return new Entry(app,record,directory);}
    }

    public static Uri publish(Context context,String id)throws IOException {return publish(context,id,GALLERY);}
    public static Uri retryAfterUnconfirmed(Context context,String id)throws IOException {return retryAfterUnconfirmed(context,id,GALLERY);}
    static Uri publish(Context context,String id,GalleryGateway gateway)throws IOException {return publish(context,id,gateway,false);}
    static Uri retryAfterUnconfirmed(Context context,String id,GalleryGateway gateway)throws IOException {return publish(context,id,gateway,true);}

    private static Uri publish(Context context,String id,GalleryGateway gateway,boolean confirmedRetry)throws IOException {
        Context app=context.getApplicationContext();File directory=Duwm1728RecoveryFilePolicy.entryDirectory(root(app,false),id);
        String key=directory.getAbsolutePath();Record record;
        synchronized(RECORD_LOCK){
            record=readReconciled(directory);if(record==null)throw new IOException("Recovery copy is unavailable");
            Entry entry=new Entry(app,record,directory);
            if(PUBLISHING.contains(key))throw new BusyException(entry);
            if(record.state==State.UNCONFIRMED&&!confirmedRetry)
                throw new UnconfirmedException("The previous Gallery save is unconfirmed. Check Gallery before explicitly retrying.",entry,record.published,null);
            PUBLISHING.add(key);
        }
        try {
            if(record.state==State.PUBLISHED){repairSuccess(app,record,true);cleanupPublished(directory,record);return record.published;}
            File video=Duwm1728RecoveryFilePolicy.ownedFile(directory,"video.mp4");
            if(!Duwm1728RecoveryFilePolicy.matches(video,record.bytes,record.sha256))throw new IOException("Recovery MP4 is missing or its bytes changed. Nothing was sent to Gallery.");
            if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Gallery save has not started; recovery copy retained");
            boolean priorUnconfirmed=record.state==State.UNCONFIRMED;
            // A confirmed retry cannot erase an earlier ambiguous Gallery outcome. Keep
            // its returned URI (if any) in the durable in-progress marker as well.
            record.state=State.PUBLISHING;record.error=priorUnconfirmed?"Retry in progress; the previous Gallery save remains unconfirmed.":"";
            synchronized(RECORD_LOCK){write(directory,record);}
            Uri published;
            try {
                published=gateway.publish(app,video,record.name);
                if(published==null||!"content".equals(published.getScheme())||!"media".equals(published.getAuthority())||published.equals(record.source))
                    throw new IOException("Gallery did not return a distinct MediaStore receipt");
            }catch(Exception failure){
                if(failure instanceof InterruptedException)Thread.currentThread().interrupt();
                boolean definite=failure instanceof DefinitePublishFailure;
                record.state=definite&&!priorUnconfirmed?State.READY:State.UNCONFIRMED;
                record.error=message(failure)+(priorUnconfirmed?" The previous Gallery save remains unconfirmed.":"");
                try{synchronized(RECORD_LOCK){write(directory,record);}}
                catch(IOException persistenceFailure){
                    persistenceFailure.addSuppressed(failure);record.state=State.UNCONFIRMED;
                    throw new UnconfirmedException("The Gallery result could not be recorded. The private MP4 is retained; check Gallery before retrying.",new Entry(app,record,directory),record.published,persistenceFailure);
                }
                if(definite&&!priorUnconfirmed)throw (DefinitePublishFailure)failure;
                throw new UnconfirmedException("Gallery save status is unconfirmed. The private MP4 is retained; check Gallery before retrying.",new Entry(app,record,directory),record.published,failure);
            }
            record.published=published;record.savedAt=System.currentTimeMillis();record.state=State.PUBLISHED;record.error="";
            try{synchronized(RECORD_LOCK){write(directory,record);}}
            catch(IOException receiptFailure){
                // The publisher did return a real URI. Do not describe this as an unsaved
                // video, retry it automatically, or delete the only durable private copy.
                record.state=State.UNCONFIRMED;record.error="Gallery returned a URI, but its recovery receipt could not be saved.";
                try{synchronized(RECORD_LOCK){write(directory,record);}}catch(IOException stillUnavailable){receiptFailure.addSuppressed(stillUnavailable);}
                throw new UnconfirmedException("Gallery returned a saved-video URI, but its receipt could not be stored. Keep this private copy and check Gallery.",new Entry(app,record,directory),published,receiptFailure);
            }
            repairSuccess(app,record,true);cleanupPublished(directory,record);return published;
        }finally{synchronized(RECORD_LOCK){PUBLISHING.remove(key);}}
    }

    /** Deletes only this explicitly selected private copy/receipt, never its Gallery item. */
    public static void discard(Context context,String id)throws IOException {
        Context app=context.getApplicationContext();File root=root(app,false),directory=Duwm1728RecoveryFilePolicy.entryDirectory(root,id);
        synchronized(RECORD_LOCK){
            if(!directory.exists())return;
            Record record=readReconciled(directory);
            if(PUBLISHING.contains(directory.getAbsolutePath())||RETAINING.contains(directory.getAbsolutePath()))
                throw new BusyException(record==null?null:new Entry(app,record,directory));
            // Remove the manifest last. A failed MP4 deletion remains discoverable for retry.
            for(String name:new String[]{"video.part","video.mp4","record.json.part","record.json"}){
                File file=Duwm1728RecoveryFilePolicy.ownedFile(directory,name);
                if(file.exists()&&!file.delete())throw new IOException("Could not remove this private recovery copy");
            }
            if(!directory.delete())throw new IOException("Could not remove this recovery record directory");
            syncDirectory(root);
        }
    }

    static File readableFile(Context context,Uri uri)throws IOException {
        if(!isRecoveryUri(context,uri))throw new IOException("Invalid recovery URI");
        File directory=Duwm1728RecoveryFilePolicy.entryDirectory(root(context.getApplicationContext(),false),entryId(uri));
        synchronized(RECORD_LOCK){
            Record record=readReconciled(directory);File file=Duwm1728RecoveryFilePolicy.ownedFile(directory,"video.mp4");
            if(record==null||!record.complete||!file.isFile()||file.length()!=record.bytes)throw new IOException("Private recovery MP4 is unavailable");
            return file;
        }
    }

    private static void repairSuccess(Context app,Record record,boolean explicitSave) {
        if(record.state!=State.PUBLISHED||record.published==null)return;
        synchronized(RECORD_LOCK){
            try{
                List<String[]> indexed=Duwm1726GalleryIndex.list(app);boolean present=false;
                for(String[] row:indexed)if(record.published.toString().equals(row[0])&&record.name.equals(row[1])){present=true;break;}
                // Automatic receipt reads must not churn older items through the bounded
                // Gallery index. An explicit save may place its selected video at the front.
                if(!present&&(explicitSave||indexed.size()<60))Duwm1726GalleryIndex.add(app,record.published,record.name);
                if((present||explicitSave||indexed.size()<60)&&!app.getSharedPreferences("duwm1726_gallery_exports",Context.MODE_PRIVATE).edit().commit())
                    Log.w(TAG,"Gallery receipt exists; index persistence can be retried later");
            }catch(RuntimeException failedIndex){Log.w(TAG,"Gallery receipt exists; index update can be retried",failedIndex);}
            try {
                android.content.SharedPreferences preferences=app.getSharedPreferences("duwm1728_saved_broadcasts",Context.MODE_PRIVATE);
                String key=Duwm1728CaptureTelemetry.storageKey(record.source),current=preferences.getString(key,"");
                if(!current.isEmpty()){
                    try{JSONObject previous=new JSONObject(current);long savedAt=previous.optLong("saved_at",0);
                        if(savedAt>record.savedAt||savedAt==record.savedAt&&!record.published.toString().equals(previous.optString("uri")))return;
                    }catch(JSONException malformed){/* A verified receipt can repair a malformed shortcut. */}
                }
                String value=new JSONObject().put("uri",record.published.toString()).put("name",record.name)
                        .put("saved_at",record.savedAt).toString();
                boolean stored=preferences.edit().putString(key,value).commit();
                if(!stored)Log.w(TAG,"Gallery receipt exists; last-export shortcut can be repaired later");
            }catch(Exception failedShortcut){Log.w(TAG,"Gallery receipt exists; last-export shortcut update can be retried",failedShortcut);}
        }
    }
    private static void cleanupPublished(File directory,Record record) {
        if(record.state!=State.PUBLISHED||record.published==null)return;
        // Called only after durable PUBLISHED metadata, including on idempotent repair.
        try{File file=Duwm1728RecoveryFilePolicy.ownedFile(directory,"video.mp4");
            if(file.exists()){if(!file.delete()){Log.w(TAG,"Gallery saved; private copy remains for manual cleanup");return;}syncDirectory(directory);}
        }catch(IOException cleanupFailure){Log.w(TAG,"Gallery saved; private cleanup did not finish",cleanupFailure);}
    }

    private static File root(Context app,boolean create)throws IOException {
        File files=app.getFilesDir().getCanonicalFile(),root=new File(files,DIRECTORY).getCanonicalFile();
        if(!files.equals(root.getParentFile())||!DIRECTORY.equals(root.getName()))throw new IOException("Invalid private recovery root");
        if(create&&!root.isDirectory()){if(!root.mkdir()&&!root.isDirectory())throw new IOException("Cannot create private recovery storage");syncDirectory(files);}
        if(root.exists()&&!root.isDirectory())throw new IOException("Private recovery storage is not a directory");
        return root;
    }
    /** Caller owns RECORD_LOCK. Incomplete .part files are preserved but never offered for playback. */
    private static Record readReconciled(File directory)throws IOException {
        Record record=read(directory);if(record==null)return null;
        if(!record.id.equals(directory.getName()))throw new IOException("Recovery record id mismatch");
        String key=directory.getAbsolutePath();
        if(!record.complete){
            if(RETAINING.contains(key))return null;
            File video=Duwm1728RecoveryFilePolicy.ownedFile(directory,"video.mp4");
            File partial=Duwm1728RecoveryFilePolicy.ownedFile(directory,"video.part");
            if(!Duwm1728RecoveryFilePolicy.matches(video,record.bytes,record.sha256)){
                if(!Duwm1728RecoveryFilePolicy.matches(partial,record.bytes,record.sha256))return null;
                rename(partial,video);syncDirectory(directory);
            }
            record.complete=true;record.state=State.READY;record.error="";write(directory,record);
        }
        if(record.state==State.PUBLISHING&&!PUBLISHING.contains(key)){
            record.state=State.UNCONFIRMED;record.error="Gallery save was interrupted. Check Gallery before explicitly retrying.";write(directory,record);
        }
        return record;
    }
    private static Record read(File directory)throws IOException {
        File file=Duwm1728RecoveryFilePolicy.ownedFile(directory,"record.json");
        if(!file.exists())return null;
        if(!file.isFile()||file.length()>65536)throw new IOException("Recovery metadata is invalid");
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        try(FileInputStream in=new FileInputStream(file)){byte[] block=new byte[4096];int count;
            while((count=in.read(block))!=-1){bytes.write(block,0,count);if(bytes.size()>65536)throw new IOException("Recovery metadata is too large");}}
        try{return Record.parse(new JSONObject(new String(bytes.toByteArray(),StandardCharsets.UTF_8)));}
        catch(JSONException|IllegalArgumentException invalid){throw new IOException("Recovery metadata could not be read; its files are retained",invalid);}
    }
    private static void write(File directory,Record record)throws IOException {
        byte[] bytes;
        try{bytes=record.json().toString().getBytes(StandardCharsets.UTF_8);}catch(JSONException invalid){throw new IOException("Cannot encode recovery metadata",invalid);}
        if(bytes.length>65536)throw new IOException("Recovery metadata is too large");
        File partial=Duwm1728RecoveryFilePolicy.ownedFile(directory,"record.json.part");
        try(FileOutputStream out=new FileOutputStream(partial)){out.write(bytes);out.flush();out.getFD().sync();}
        rename(partial,Duwm1728RecoveryFilePolicy.ownedFile(directory,"record.json"));syncDirectory(directory);
    }
    private static void rename(File from,File to)throws IOException {
        try{Os.rename(from.getAbsolutePath(),to.getAbsolutePath());}catch(ErrnoException failure){throw new IOException("Cannot commit private recovery file",failure);}
    }
    private static void syncDirectory(File directory)throws IOException {
        if(!directory.isDirectory())throw new IOException("Private recovery directory is unavailable");
        FileDescriptor fd=null;
        try{fd=Os.open(directory.getAbsolutePath(),OsConstants.O_RDONLY,0);Os.fsync(fd);}
        catch(ErrnoException failure){throw new IOException("Cannot flush private recovery directory",failure);}
        finally{if(fd!=null)try{Os.close(fd);}catch(ErrnoException ignored){}}
    }
    private static String message(Throwable error){String message=error.getMessage();if(message==null||message.trim().isEmpty())message=error.getClass().getSimpleName();return message.length()>1000?message.substring(0,1000):message;}

    private static final class Record {
        String id,name,sha256,error="";Uri source,published;State state=State.READY;
        long created,bytes,savedAt;boolean complete;
        JSONObject json()throws JSONException {
            return new JSONObject().put("schema",1).put("id",id).put("name",name).put("source_uri",source.toString())
                    .put("created_at",created).put("bytes",bytes).put("sha256",sha256).put("complete",complete)
                    .put("state",state.name()).put("last_error",error).put("published_uri",published==null?JSONObject.NULL:published.toString()).put("saved_at",savedAt);
        }
        static Record parse(JSONObject json)throws JSONException {
            if(json.getInt("schema")!=1)throw new IllegalArgumentException("Unknown recovery metadata schema");
            Record record=new Record();record.id=json.getString("id");Duwm1728RecoveryFilePolicy.requireId(record.id);
            record.name=json.getString("name");Duwm1728RecoveryFilePolicy.requireName(record.name);
            record.source=Uri.parse(json.getString("source_uri"));if(record.source.toString().isEmpty())throw new IllegalArgumentException("Missing original URI");
            record.created=json.getLong("created_at");record.bytes=json.getLong("bytes");record.sha256=json.getString("sha256");
            if(record.created<1||record.bytes<1024||!record.sha256.matches("[a-f0-9]{64}"))throw new IllegalArgumentException("Invalid recovery identity");
            record.complete=json.getBoolean("complete");record.state=State.valueOf(json.getString("state"));record.error=json.optString("last_error","");
            if(!json.isNull("published_uri"))record.published=Uri.parse(json.getString("published_uri"));record.savedAt=json.optLong("saved_at",0);
            if(record.published!=null&&(!"content".equals(record.published.getScheme())||!"media".equals(record.published.getAuthority())))throw new IllegalArgumentException("Invalid Gallery receipt");
            if(record.state==State.PUBLISHED&&(record.published==null||record.savedAt<1))throw new IllegalArgumentException("Missing Gallery receipt");
            if(!record.complete&&record.state!=State.READY)throw new IllegalArgumentException("Incomplete MP4 cannot be published");
            return record;
        }
    }
}
