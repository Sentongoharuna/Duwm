package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.media.*;
import android.net.Uri;
import android.os.Build;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Inspects real source tracks and advertised codec support. Does NOT claim a completed export. */
public final class Duwm1728ExportPreflight {
    private Duwm1728ExportPreflight() {}
    public static final class Result {
        public final int sourceWidth,sourceHeight,width,height,fps,bitrate,rotation,requestedWidth,requestedHeight;
        public final long durationMs;public final boolean audio,estimatedFps,automaticSizing,resolutionAdjusted;
        public final String encoder,ratio,selectionReason;public final Duwm1728FramePlan.Plan framing;
        Result(int sw,int sh,int w,int h,int f,int b,int r,long d,boolean a,boolean estimate,String e,String ratio,Duwm1728FramePlan.Plan framing,
               int requestedWidth,int requestedHeight,boolean automaticSizing){
            sourceWidth=sw;sourceHeight=sh;width=w;height=h;fps=f;bitrate=b;rotation=r;durationMs=d;
            audio=a;estimatedFps=estimate;encoder=e;this.ratio=ratio;this.framing=framing;
            this.requestedWidth=requestedWidth;this.requestedHeight=requestedHeight;this.automaticSizing=automaticSizing;
            resolutionAdjusted=w!=requestedWidth||h!=requestedHeight;
            selectionReason=!automaticSizing?"Requested output size.":resolutionAdjusted?
                "Automatic size: "+requestedWidth+" × "+requestedHeight+" → "+w+" × "+h+". Whole picture retained; source timing unchanged.":
                "Automatic size: source resolution retained; source timing unchanged.";
        }
        public String summary(){

            return ratio+"  •  "+width+" × "+height+"  •  "+fps+" fps"+(estimatedFps?" requested*":" requested")+
                "\n"+(audio?"AAC soundtrack retained":"SILENT SOURCE — no audio track")+"  •  "+Duwm1728BroadcastTimeline.clock(durationMs)+
                "\n"+framing.describe()+
                " • no stretching / no upscaling"+(automaticSizing?"\n"+selectionReason:"")+"\nEncoder advertised; actual recording/export still needs testing."+
                (estimatedFps?" *Source does not declare frame rate.":"");
        }
    }
    private static int number(MediaFormat f,String key,int fallback){try{return f.getInteger(key);}catch(Exception e){return fallback;}}
    public static MediaFormat outputFormat(Result p){
        return outputFormat(p.width,p.height,p.fps,p.bitrate);
    }
    private static MediaFormat outputFormat(int width,int height,int fps,int bitrate){
        MediaFormat f=MediaFormat.createVideoFormat("video/avc",width,height);
        f.setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        f.setInteger(MediaFormat.KEY_BIT_RATE,bitrate);f.setInteger(MediaFormat.KEY_FRAME_RATE,fps);
        f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL,2);if(Build.VERSION.SDK_INT>=29)f.setInteger(MediaFormat.KEY_MAX_B_FRAMES,0);
        return f;
    }
    public static Result inspect(Context context,Uri source,long from,long to,String ratio)throws Exception{
        return inspect(context,source,from,to,ratio,Duwm1728FramePlan.FILL,.5f,.5f);
    }
    public static Result inspect(Context context,Uri source,long from,long to,String ratio,String mode,float ax,float ay)throws Exception{
        return inspect(context,source,from,to,ratio,mode,ax,ay,false);
    }
    public static Result inspect(Context context,Uri source,long from,long to,String ratio,String mode,float ax,float ay,boolean automaticSizing)throws Exception{
        Duwm1728FramePlan.validate(mode,ax,ay);
        if(automaticSizing&&(!"ORIGINAL".equals(ratio)||!Duwm1728FramePlan.FIT.equals(mode)))
            throw new IllegalArgumentException("Automatic output sizing requires the whole original picture");
        Duwm1728BroadcastTimeline.range(from,to);
        MediaExtractor tracks=new MediaExtractor();MediaMetadataRetriever meta=new MediaMetadataRetriever();
        try{
            meta.setDataSource(context,source);String d=meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if(d==null||to>Long.parseLong(d))throw new IllegalArgumentException("Clip exceeds the source recording");
            tracks.setDataSource(context,source,null);MediaFormat video=null;boolean audio=false;
            for(int i=0;i<tracks.getTrackCount();i++){
                MediaFormat f=tracks.getTrackFormat(i);String mime=f.getString(MediaFormat.KEY_MIME);
                if(mime!=null&&mime.startsWith("video/")&&video==null)video=f;
                if(mime!=null&&mime.startsWith("audio/")){
                    if(!"audio/mp4a-latm".equals(mime))throw new IllegalArgumentException("This audio codec requires conversion; sound will not be silently discarded");
                    audio=true;
                }
            }
            if(video==null)throw new IllegalArgumentException("No video track in the source");
            int transfer=number(video,MediaFormat.KEY_COLOR_TRANSFER,3);
            if(transfer==6||transfer==7)throw new IllegalArgumentException("HDR source: use an SDR recording for this broadcast renderer; no false HDR conversion");
            int rotation=number(video,MediaFormat.KEY_ROTATION,0);String raw=meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
            if(raw!=null)rotation=Integer.parseInt(raw);rotation=((rotation%360)+360)%360;
            if(rotation%90!=0)throw new IllegalArgumentException("Unsupported non-right-angle source rotation");
            int sw=video.getInteger(MediaFormat.KEY_WIDTH),sh=video.getInteger(MediaFormat.KEY_HEIGHT);
            if(rotation%180!=0){int tmp=sw;sw=sh;sh=tmp;}
            int[] size=Duwm1728FramePlan.dimensions(sw,sh,ratio,mode);
            int declared=number(video,MediaFormat.KEY_FRAME_RATE,0),fps=declared>0?declared:30;
            if(fps>120)throw new IllegalArgumentException("Source exceeds 120 fps; dedicated high-speed conversion is required");
            if(automaticSizing){
                Duwm1728OutputSizePolicy.Selection selected=Duwm1728OutputSizePolicy.select(size[0],size[1],fps,advertisedSurfaceEncoders());
                if(selected==null)throw new IllegalArgumentException("No advertised AVC surface encoder accepts a compatible output size at "+fps+" fps. The original recording is retained.");
                Duwm1728FramePlan.Plan framing=Duwm1728FramePlan.create(sw,sh,selected.width,selected.height,mode,ax,ay);
                return new Result(sw,sh,selected.width,selected.height,fps,selected.bitrate,rotation,to-from,audio,declared<=0,selected.encoder,ratio,framing,size[0],size[1],true);
            }
            Duwm1728FramePlan.Plan framing=Duwm1728FramePlan.create(sw,sh,size[0],size[1],mode,ax,ay);
            int bitrate=(int)Math.min(80000000L,Math.max(5000000L,(long)size[0]*size[1]*fps/5));
            Result proposed=new Result(sw,sh,size[0],size[1],fps,bitrate,rotation,to-from,audio,declared<=0,"",ratio,framing,size[0],size[1],false);
            String encoder=new MediaCodecList(MediaCodecList.ALL_CODECS).findEncoderForFormat(outputFormat(proposed));
            if(encoder==null)throw new IllegalArgumentException("No advertised AVC encoder for "+size[0]+"×"+size[1]+" at "+fps+" fps. Choose another ratio or recording size; the original is unchanged.");
            return new Result(sw,sh,size[0],size[1],fps,bitrate,rotation,to-from,audio,declared<=0,encoder,ratio,framing,size[0],size[1],false);
        }finally{tracks.release();try{meta.release();}catch(Exception ignored){}}
    }
    /** Regular codecs avoid entries that require a special operating mode.
     * Surface input, alignment and bitrate are checked explicitly: Android's
     * generic format predicate does not evaluate every key on every API level.
     * No configure call is made here, so this remains advertised capability.
     */
    private static List<Duwm1728OutputSizePolicy.Encoder> advertisedSurfaceEncoders(){
        List<Duwm1728OutputSizePolicy.Encoder> result=new ArrayList<>();
        for(MediaCodecInfo info:new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos()){
            try{
                if(!info.isEncoder())continue;
                for(String mime:info.getSupportedTypes()){
                    if(!"video/avc".equalsIgnoreCase(mime))continue;
                    final MediaCodecInfo.CodecCapabilities caps=info.getCapabilitiesForType(mime);
                    boolean surface=false;
                    if(caps.colorFormats!=null)for(int color:caps.colorFormats)if(color==MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface){surface=true;break;}
                    if(!surface)continue;
                    final MediaCodecInfo.VideoCapabilities video=caps.getVideoCapabilities();if(video==null)continue;
                    result.add(new Duwm1728OutputSizePolicy.Encoder(info.getName(),video.getWidthAlignment(),video.getHeightAlignment(),
                        video.getSupportedWidths().getLower(),video.getSupportedWidths().getUpper(),
                        video.getSupportedHeights().getLower(),video.getSupportedHeights().getUpper(),
                        Math.max(1,video.getBitrateRange().getLower()),video.getBitrateRange().getUpper(),
                        (width,height,fps,bitrate)->video.areSizeAndRateSupported(width,height,(double)fps)
                            &&caps.isFormatSupported(outputFormat(width,height,fps,bitrate))));
                    break;
                }
            }catch(RuntimeException malformedAdvertisement){/* This codec has not established usable support. */}
        }
        return result;
    }
    public static String savedDetails(File file)throws Exception{
        MediaMetadataRetriever meta=new MediaMetadataRetriever();
        try{meta.setDataSource(file.getAbsolutePath());return
            meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)+" × "+meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)+
            " • "+Duwm1728BroadcastTimeline.clock(Long.parseLong(meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)))+
            " • "+("yes".equalsIgnoreCase(meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO))?"audio track present":"silent MP4")+
            String.format(Locale.ROOT," • %.1f MiB",file.length()/1048576d);
        }finally{try{meta.release();}catch(Exception ignored){}}
    }
}
