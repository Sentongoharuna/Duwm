package com.sentongoharuna.worldsituationroom;

import java.util.*;

/** One time base for trim-aware preview and export. No invented event timestamps. */
public final class Duwm1728BroadcastTimeline {
    private Duwm1728BroadcastTimeline() {}
    public static void range(long from,long to) {
        if(from<0 || to<=from)throw new IllegalArgumentException("Choose a valid clip range");
    }
    private static long plus(long a,long b) {
        if(a<0 || b<0 || a>Long.MAX_VALUE-b)throw new IllegalArgumentException("Timestamp overflow");
        return a+b;
    }
    public static long elapsed(long sourceTime,long from,long to) {
        range(from,to);return Math.max(0,Math.min(to-from-1,sourceTime-from));
    }
    public static long sourceAtProgress(int progress,long from,long to) {
        range(from,to);int p=Math.max(0,Math.min(1000,progress));
        return from+Math.min(to-from-1,Math.round((to-from)*(p/1000d)));
    }
    /** Step updates are anchored to original footage, with the current update carried into a trim. */
    public static List<Duwm1728BroadcastLayout.Cue> tickers(
            List<Duwm1728TickerTimeline.Cue> input,long origin,long from,long to) {
        range(from,to);if(origin<0)throw new IllegalArgumentException("Invalid ticker origin");
        TreeMap<Long,String> original=new TreeMap<>(),visible=new TreeMap<>();
        if(input!=null)for(Duwm1728TickerTimeline.Cue c:input)original.put(plus(origin,c.atMs),c.text);
        for(Map.Entry<Long,String> e:original.entrySet()) {
            if(e.getKey()>=to)break;visible.put(Math.max(0,e.getKey()-from),e.getValue());
        }
        ArrayList<Duwm1728BroadcastLayout.Cue> out=new ArrayList<>();
        for(Map.Entry<Long,String> e:visible.entrySet()) {
            Long next=visible.higherKey(e.getKey());long end=next==null?to-from:next;
            out.add(new Duwm1728BroadcastLayout.Cue(e.getKey(),end,e.getValue()));
        }
        return Collections.unmodifiableList(out);
    }
    /** Start AND end times survive SRT/AI import and trimming. End is exclusive. */
    public static List<Duwm1728BroadcastLayout.Cue> captions(
            List<Duwm1728BroadcastLayout.Cue> source,long from,long to) {
        range(from,to);ArrayList<Duwm1728BroadcastLayout.Cue> out=new ArrayList<>();
        if(source!=null)for(Duwm1728BroadcastLayout.Cue c:source) {
            long a=Math.max(from,c.startMs),b=Math.min(to,c.endMs);
            if(b>a)out.add(new Duwm1728BroadcastLayout.Cue(a-from,b-from,c.text));
        }
        out.sort(Comparator.comparingLong(c->c.startMs));return Collections.unmodifiableList(out);
    }
    /** Manual start-only captions have a bounded six-second display, not indefinite stale text. */
    public static List<Duwm1728BroadcastLayout.Cue> manualCaptions(
            List<Duwm1728TickerTimeline.Cue> source,long origin,long from,long to) {
        range(from,to);ArrayList<Duwm1728BroadcastLayout.Cue> absolute=new ArrayList<>();
        if(source!=null)for(int i=0;i<source.size();i++) {
            Duwm1728TickerTimeline.Cue c=source.get(i);long start=plus(origin,c.atMs);
            long end=plus(start,6000);if(i+1<source.size())end=Math.min(end,plus(origin,source.get(i+1).atMs));
            if(end>start)absolute.add(new Duwm1728BroadcastLayout.Cue(start,end,c.text));
        }
        return captions(absolute,from,to);
    }
    public static String clock(long ms) {
        long total=Math.max(0,ms)/1000,h=total/3600,m=(total%3600)/60,s=total%60;
        return h>0?String.format(Locale.ROOT,"%d:%02d:%02d",h,m,s):String.format(Locale.ROOT,"%02d:%02d",m,s);
    }
}
