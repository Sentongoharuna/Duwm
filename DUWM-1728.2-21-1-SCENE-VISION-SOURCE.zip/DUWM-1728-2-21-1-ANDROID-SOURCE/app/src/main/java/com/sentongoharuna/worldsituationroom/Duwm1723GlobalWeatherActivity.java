package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Worldwide coordinate-based forecast desk. This is a MODEL forecast, not measured device weather.
 *  It makes no network request until the user taps FETCH and does not infer the user's location.
 *  Cached responses are explicitly labelled, dated and restricted to the same coordinates.
 */
public final class Duwm1723GlobalWeatherActivity extends Activity {
    private static final int NAVY=DuwmUnifiedTheme.APPROVED_NAVY;
    private static final int TEXT=DuwmUnifiedTheme.TEXT, MUTED=DuwmUnifiedTheme.MUTED;
    private static final String PREFS="duwm1723_world_weather_source", CACHE="body", CACHE_LAT="lat", CACHE_LON="lon", CACHE_AT="retrieved_utc";
    private static final int MAX_BYTES=210000;
    private static final String ATTRIBUTION="Open-Meteo forecast model • https://open-meteo.com/ • check commercial licensing";
    private final Handler handler=new Handler(Looper.getMainLooper());
    private LinearLayout results; private TextView status,title;
    private EditText latitude,longitude,place;
    private volatile boolean closed,fetching;
    private double shownRequestedLat=Double.NaN,shownRequestedLon=Double.NaN;
    private String shownPlace="";
    private int dp(float px){return Math.round(getResources().getDisplayMetrics().density*px);}
    private GradientDrawable frame(int border){GradientDrawable d=new GradientDrawable();d.setColor(NAVY);d.setCornerRadius(dp(15));d.setStroke(dp(1),border);return d;}
    private TextView text(String value,int size,int color){TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(color);v.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));return v;}
    private TextView button(String value,Runnable action){TextView v=text(value,12,TEXT);v.setGravity(Gravity.CENTER);v.setPadding(dp(10),dp(9),dp(10),dp(9));v.setMinHeight(dp(48));v.setBackground(frame(DuwmUnifiedTheme.BORDER));v.setOnClickListener(w->action.run());return v;}
    private LinearLayout.LayoutParams gap(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(10);return p;}
    private EditText input(String hint,String val){EditText e=new EditText(this);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setTextSize(14);e.setSingleLine(true);e.setHint(hint);e.setText(val);e.setPadding(dp(12),0,dp(12),0);e.setBackground(frame(DuwmUnifiedTheme.BORDER));e.setMinHeight(dp(48));return e;}
    @Override public void onCreate(Bundle b){super.onCreate(b);
        getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(NAVY);
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(NAVY);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(14),dp(10),dp(14),dp(20));root.setBackgroundColor(NAVY);
        root.addView(text("DUWM 1723  /  WORLD WEATHER",21,TEXT),gap());
        root.addView(text("GLOBAL FORECAST DESK  •  SELECT ANY LOCATION  •  NO DEFAULT COUNTRY",11,MUTED),gap());
        root.addView(text("Weather here is opt-in numerical-model data. It is not a device sensor measurement or an official emergency warning.",12,MUTED),gap());
        String initName=getIntent().getStringExtra("duwm_place_name");
        String initLat=getIntent().getStringExtra("focus_lat"),initLon=getIntent().getStringExtra("focus_lon");
        place=input("Place / country (label only)",initName==null?"":initName);root.addView(place,gap());
        latitude=input("Latitude  −90 to 90",initLat==null?"":initLat);root.addView(latitude,gap());
        longitude=input("Longitude  −180 to 180",initLon==null?"":initLon);root.addView(longitude,gap());
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
        TextView fetch=button("FETCH MODEL FORECAST",this::fetchForecast);
        TextView view=button("OPEN PLACE MAP",this::openMap);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(50),1);p.rightMargin=dp(5);actions.addView(fetch,p);actions.addView(view,new LinearLayout.LayoutParams(0,dp(50),1));root.addView(actions,gap());
        title=text("SOURCE STATUS",14,TEXT);root.addView(title,gap());
        status=text("Choose a place in Global Discovery or enter valid coordinates. No network request has been made.",12,MUTED);root.addView(status,gap());
        results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);root.addView(results,gap());
        root.addView(button("CHOOSE A PLACE WORLDWIDE",()->startActivity(new Intent(this,Duwm1718GlobalDiscoverActivity.class))),gap());
        root.addView(button("SHARE VISIBLE FORECAST DETAILS",this::shareCurrent),gap());
        root.addView(text(ATTRIBUTION+". Do not use a forecast alone for emergency decisions; follow local official warnings.",11,MUTED),gap());
        sc.addView(root);setContentView(sc);
        if(initLat!=null&&initLon!=null){showCacheIfMatching();}
    }
    private double[] coords(){try{
        double lat=Double.parseDouble(latitude.getText().toString().trim()),lon=Double.parseDouble(longitude.getText().toString().trim());
        if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)throw new IllegalArgumentException("Coordinates outside Earth range");
        return new double[]{lat,lon};
    }catch(Exception e){status.setText("INVALID COORDINATES: Enter latitude between −90 and 90 and longitude between −180 and 180.");return null;}}
    private static String utc(long millis){SimpleDateFormat d=new SimpleDateFormat("yyyy-MM-dd HH:mm 'UTC'",Locale.US);d.setTimeZone(TimeZone.getTimeZone("UTC"));return d.format(new Date(millis));}
    private static String code(int v){
        if(v==0)return "Clear";if(v==1||v==2)return "Partly cloudy";if(v==3)return "Overcast";
        if(v==45||v==48)return "Fog";if(v>=51&&v<=57)return "Drizzle";if(v>=61&&v<=67)return "Rain";
        if(v>=71&&v<=77)return "Snow";if(v>=80&&v<=82)return "Rain showers";if(v>=85&&v<=86)return "Snow showers";
        if(v>=95&&v<=99)return "Thunderstorm";return "Model code "+v;
    }
    private String placeLabel(){String s=place.getText().toString().trim();return s.isEmpty()?"SELECTED COORDINATES":s;}
    private void showCacheIfMatching(){double[] c=coords();if(c==null)return;
        android.content.SharedPreferences prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        if(Math.abs(prefs.getFloat(CACHE_LAT,999f)-c[0])>0.005||Math.abs(prefs.getFloat(CACHE_LON,999f)-c[1])>0.005)return;
        String cached=prefs.getString(CACHE,"");if(cached.isEmpty())return;
        try{render(cached,true,prefs.getLong(CACHE_AT,0L),c[0],c[1],placeLabel());}catch(Exception ignored){status.setText("Cached model response could not be read. Fetch again.");}
    }
    private void fetchForecast(){double[] c=coords();if(c==null||fetching)return;fetching=true;
        final double lat=c[0],lon=c[1];status.setText("REQUESTING FORECAST MODEL for "+placeLabel()+"… No device location permission required.");
        final String name=placeLabel();
        new Thread(()->{
            HttpURLConnection connection=null;
            try{
                String u=String.format(Locale.US,"https://api.open-meteo.com/v1/forecast?latitude=%.5f&longitude=%.5f&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,wind_speed_10m,weather_code&hourly=temperature_2m,precipitation_probability,weather_code&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code&forecast_days=7&timezone=auto",lat,lon);
                connection=(HttpURLConnection)new URL(u).openConnection();connection.setConnectTimeout(8000);connection.setReadTimeout(9000);
                if(connection.getResponseCode()!=200)throw new IllegalStateException("Forecast HTTP "+connection.getResponseCode());
                try(InputStream in=connection.getInputStream();ByteArrayOutputStream buf=new ByteArrayOutputStream()){
                    byte[] data=new byte[8192];int n;while((n=in.read(data))!=-1){if(buf.size()+n>MAX_BYTES)throw new IllegalStateException("Forecast response too large");buf.write(data,0,n);}
                    String raw=buf.toString("UTF-8");JSONObject parsed=new JSONObject(raw);
                    if(parsed.optJSONObject("current")==null||parsed.optJSONObject("daily")==null)throw new IllegalStateException("Provider returned no forecast data");
                    long downloaded=System.currentTimeMillis();
                    getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(CACHE,raw).putFloat(CACHE_LAT,(float)lat).putFloat(CACHE_LON,(float)lon).putLong(CACHE_AT,downloaded).apply();
                    handler.post(()->{
                        if(closed)return;
                        double[] present=coords();
                        if(present==null||Math.abs(present[0]-lat)>0.005||Math.abs(present[1]-lon)>0.005){
                            status.setText("Forecast for "+name+" downloaded but your selected coordinates changed. Re-select that place to use the new cached result.");
                            return;
                        }
                        render(raw,false,downloaded,lat,lon,name);
                    });
                }
            }catch(Exception error){handler.post(()->{if(closed)return;status.setText("FORECAST UNAVAILABLE: "+error.getMessage()+". Retaining the last labelled result, if any.");});}
            finally{if(connection!=null)connection.disconnect();fetching=false;}
        },"duwm1723-weather-opt-in").start();
    }
    private TextView reportCard(String heading,String detail){TextView v=text(heading+"\n"+detail,13,TEXT);v.setPadding(dp(12),dp(12),dp(12),dp(12));v.setLineSpacing(dp(3),1f);v.setBackground(frame(DuwmUnifiedTheme.DIVIDER));return v;}
    private static String number(JSONObject o,String key,String unit){return o!=null&&o.has(key)&&!o.isNull(key)?String.format(Locale.US,"%.1f%s",o.optDouble(key),unit):"UNAVAILABLE";}
    private static String valueAt(JSONArray a,int i,String suffix){if(a==null||i>=a.length()||a.isNull(i))return "—";Object o=a.opt(i);return String.valueOf(o)+suffix;}
    private void render(String raw,boolean cached,long downloaded,double requestedLat,double requestedLon,String requestedPlace){try{
        JSONObject all=new JSONObject(raw);JSONObject cur=all.getJSONObject("current"),daily=all.getJSONObject("daily");
        JSONArray dates=daily.getJSONArray("time");if(dates.length()==0)throw new IllegalArgumentException("Empty forecast");
        results.removeAllViews();shownRequestedLat=requestedLat;shownRequestedLon=requestedLon;shownPlace=requestedPlace;
        String localZone=all.optString("timezone","PROVIDER TIMEZONE UNAVAILABLE");
        status.setText((cached?"CACHED FORECAST / NOT LIVE":"MODEL FORECAST RECEIVED")+" • downloaded "+utc(downloaded)+"\nPROVIDER LOCAL TIME ZONE: "+localZone+"\nSOURCE: Open-Meteo model forecast; not official warning information.");
        String current="Provider observation time "+cur.optString("time","TIME UNAVAILABLE")+"\nTemperature "+number(cur,"temperature_2m","°C")+
             "  •  Feels like "+number(cur,"apparent_temperature","°C")+"\nHumidity "+number(cur,"relative_humidity_2m","%")+
             "  •  Wind "+number(cur,"wind_speed_10m"," km/h")+"\nPrecipitation "+number(cur,"precipitation"," mm")+
             "  •  "+code(cur.optInt("weather_code",-1));
        results.addView(reportCard("CURRENT MODEL CONDITIONS / "+shownPlace,current),gap());
        JSONArray hi=daily.optJSONArray("temperature_2m_max"),lo=daily.optJSONArray("temperature_2m_min"),rain=daily.optJSONArray("precipitation_probability_max"),wx=daily.optJSONArray("weather_code");
        for(int i=0;i<Math.min(7,dates.length());i++){
            String d=dates.optString(i,"DATE UNAVAILABLE");String detail="High "+valueAt(hi,i,"°C")+"   •   Low "+valueAt(lo,i,"°C")+
                "\nRain probability (model max) "+valueAt(rain,i,"%")+"   •   "+code(wx==null?-1:wx.optInt(i,-1));
            results.addView(reportCard(d+"  /  7-DAY MODEL FORECAST",detail),gap());
        }
        JSONObject hourly=all.optJSONObject("hourly");if(hourly!=null){
            JSONArray times=hourly.optJSONArray("time"),temps=hourly.optJSONArray("temperature_2m"),chance=hourly.optJSONArray("precipitation_probability");
            StringBuilder next=new StringBuilder();if(times!=null){for(int i=0;i<Math.min(times.length(),12);i++){
                next.append(times.optString(i)).append("  •  ").append(valueAt(temps,i,"°C")).append("  •  rain ").append(valueAt(chance,i,"%")).append("\n");
            }}results.addView(reportCard("NEXT 12 MODEL HOURS / PROVIDER LOCAL TIME",next.toString()),gap());
        }
    }catch(Exception e){status.setText("MODEL RESPONSE UNREADABLE: "+e.getMessage());}}
    private void openMap(){double[] c=coords();if(c==null)return;Intent i=new Intent(this,DuwmPlaceMapActivity.class);i.putExtra("focus_lat",String.format(Locale.US,"%.6f",c[0]));i.putExtra("focus_lon",String.format(Locale.US,"%.6f",c[1]));startActivity(i);}
    private void shareCurrent(){if(results==null||results.getChildCount()==0){status.setText("No received forecast to share. Fetch one first.");return;}
        double[] c=coords();if(c==null||Math.abs(c[0]-shownRequestedLat)>0.005||Math.abs(c[1]-shownRequestedLon)>0.005){
            status.setText("The place coordinates changed after the forecast was loaded. Fetch the selected place before sharing.");return;
        }
        StringBuilder s=new StringBuilder("DUWM MODEL WORLD WEATHER / ").append(shownPlace).append("\n").append(status.getText());
        for(int i=0;i<results.getChildCount();i++)if(results.getChildAt(i) instanceof TextView)s.append("\n\n").append(((TextView)results.getChildAt(i)).getText());
        s.append("\n\n").append(ATTRIBUTION).append("\nNot official emergency advice.");
        Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,s.toString());startActivity(Intent.createChooser(send,"Share cited DUWM model weather"));
    }
    @Override protected void onDestroy(){closed=true;super.onDestroy();}
}
