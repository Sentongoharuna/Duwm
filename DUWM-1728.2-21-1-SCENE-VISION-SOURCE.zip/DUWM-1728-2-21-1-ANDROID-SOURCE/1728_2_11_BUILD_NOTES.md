# DUWM 1728.2/11 — Full-picture and subject-position framing

## Real scope
Continuation of complete /10 Android project. No replacement app, camera shell or globe.
Android versionName 1728.2.11; versionCode 172811; launcher DUWM 1728.2/11.

## Implemented
1. A visible FRAME control in Broadcast Studio next to playback, aspect ratio and Edit.
2. KEEP FULL PICTURE retains the complete source picture, fits it without distortion and uses the approved #041424 navy for letterbox/pillarbox areas. New drafts select this mode; reopened older drafts retain their previous centre-crop behaviour.
3. FILL FRAME keeps the chosen output shape and lets the reporter move the crop horizontally or vertically. Sliders automatically disable on axes without a crop. The source master is never overwritten.
4. 9:10, 9:16, 16:9 and ORIGINAL output shapes have independent, even-pixel dimension calculations. FIT uses the captured longest edge as its canvas limit; it never enlarges the contained source image. FILL preserves the existing /10 no-upscale geometry. A landscape clip fitted into portrait naturally has navy bars; it is not stretched or falsely described as full-height footage.
5. TextureView preview and EGL export share the same production Duwm1728FramePlan geometry, in upright-source coordinates. Native tests additionally include 90-degree rotation metadata.
6. Actual selected crop and encoded output dimensions are in preflight. Framing is rechecked by export; encoder availability remains a metadata capability check, not proof of real-phone performance.
7. Preview-only composition guides, and an original-framing / broadcast-graphics comparison toggle. Guides cannot enter the encoder. Turning graphics off disables export; turning them on requires fresh approval.
8. Drafts retain frame mode and crop position. Changing them clears approval and reruns output checks. Invalid persisted positions are rejected and safely reset.
9. Existing red broadcast badge, scrolling ticker, exact subtitle end times, privacy consent, audio preservation, Gallery saving, world sections and independent source-status lamps are retained.

## Tests executed in this session
- 602 executable production-framing assertions: FIT/FILL, left/right/top/bottom anchors, exact ratios, no image stretching/upscaling, preview/export mapping, even pixels and malformed input rejection.
- 113 existing broadcast layout/pixel/movement/privacy/ratio assertions.
- 30 existing subtitle-end, silent-gap, trim, ticker-origin and seek cases.
- 128 AI admission states, AST method-resolution check and negative regression for the old missing startAi method.
- 5,815 signal policy/animation assertions and 188 capture-health assertions.
- 14 server contract/security tests with MOCKED providers; no actual AI service called.
- Java syntax parsing: 281 application files and two instrumentation files. This is not Android API type checking.
- Original application integrity, current version, XML and unchanged-source verification.
- 276 /10 application Java files preserved byte-for-byte, including the original globe, native camera and broadcast layout painter.
- Desktop framing evidence uses the same production framing and graphics maths. It is explicitly a technical fixture, not news, camera footage, Android decoding, or AI analysis.

## Android tests included (not executed locally)
The required emulator job retains prior signal/pixel and four actual MP4 exports. It adds six framing MP4 exports, AAC preservation, left/right/top/bottom marker checks, rotated-source framing, and native Broadcast Studio screenshot checks for full-picture and left/right pan.
The test inputs are synthetic colour markers with a tone soundtrack. No private user footage is bundled in these new tests.
The tested-artifact job still requires native success; failures are not masked with continue-on-error.

## GitHub baseline checked
Repository Sentongoharuna/Duwm. /10 run 42360015269, created 2026-11-07T09:30:27Z, reported success. compile-development job 128366223177 and native-broadcast-tests job 128366607732 both passed. This is /10 evidence, NOT /11 or physical-camera verification.

## Not yet verified
/11 Android build, APK installation, TextureView screenshots, new native exports and physical-phone behaviour have NOT been executed here. The environment has Java but no configured Android SDK/Gradle; dl.google.com failed DNS resolution. The workflow runs those actual build/runtime gates.
Automatic AI news production still needs the configured authenticated service and real model credentials. AI service tests are mocked. HDR conversion, advanced capture modes, live streaming, resumable public uploads and map inset remain outside this update. This build must not be called a completed worldwide broadcasting service.
Framing controls do not erase old text already burned into earlier videos. Keep Full retains pixels but existing broadcast graphics can still cover parts of the picture.

## Build and install
Upload the matching SOURCE.zip at repository root and APK.yml in .github/workflows/.
The workflow can reconstruct the exact /11 source from the known /10, /9 or /8 PRO-BROADCAST source with its embedded verified patch. Renaming an old source ZIP to /11 is not supported.
Compiled artifact: DUWM-1728.2-11-COMPILED-DEVELOPMENT-APK.
Native-passed artifact: DUWM-1728.2-11-NATIVE-TESTED-DEVELOPMENT-APK.
Native proof contains Android-generated screenshots and actual encoded MP4s, and is published even when a test fails.
Debug signer continuity uses the existing optional DUWM_DEBUG_KEYSTORE_B64 secret. Without a retained signer, Android may reject updating an older install; preserve private drafts before any uninstall.

## Primary technical references
Android TextureView.setTransform: https://developer.android.com/reference/android/view/TextureView#setTransform(android.graphics.Matrix)
Android Presentation framing concepts: https://developer.android.com/reference/androidx/media3/effect/Presentation
This project retains its native platform implementation; it does not add a new Media3 dependency.
