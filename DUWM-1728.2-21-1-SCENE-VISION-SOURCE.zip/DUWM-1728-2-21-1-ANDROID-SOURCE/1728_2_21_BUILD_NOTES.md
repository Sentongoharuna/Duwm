# DUWM 1728.2/21 — automatic headline fit and compatible output sizing

## Exact starting point

This build extends the exact delivered /20 AUTO-READY source archive, SHA-256
`600a819b4e3ce031c2c9bab6e91582300857467026a78a41262e683fa1761ca5`.
Its 844-entry source manifest remains unchanged. Four existing production Java
files integrate the changes: the editor, renderer, broadcast layout and output
preflight. Two new pure helpers implement measured headline fitting and bounded
output-size selection. The other 298 production Java files remain byte-for-byte
unchanged; the application has 304 production Java files in total. The original
single globe, native camera, all 19 desks, dark navy #041424, caption documents,
source timing, saved-video review and durable Gallery recovery are retained.

## Automatic headlines that fit

The /20 automatic report policy already selects a bounded source excerpt, with
an intentional ellipsis when it abbreviates the source. The old COMPACT renderer
could abbreviate that selected excerpt again: its single line could clip the last
characters in portrait output. The reproduction uses the actual automatic report
plan and shared production painter, including wide glyphs and a final tail word.

/21 measures the selected automatic headline. Titles that already fit retain the
existing size and coordinates. Overflow can use two static rows, with bounded
font-size selection and separate byline space inside the same external panel.
The complete selected text, source label and any existing excerpt-policy ellipsis
are retained. The unchanged caption planner supplies Unicode-aware measurement
and its bounded immutable font/locale cache. Headline fitting does not turn the
selected excerpt into a full transcript or alter the stored caption document.

Automatic production sets an explicit headline-fit flag. A manual title edit
switches to the existing manual headline renderer. The flag is saved as a strict
boolean in the source draft. Older drafts without the flag retain their previous
behavior; malformed new flags cannot be partially restored or overwritten.

## Automatic output size selection

The old preflight queried only the requested output size. If that format had no
advertised encoder, it stopped and asked for another size even when a smaller
whole-picture output was supported. An executable reproduction uses the actual
/20 preflight with explicitly simulated Android capability responses: it rejects
3840 x 2160 at 60 fps while the same capability fixture accepts 1920 x 1080 at
60 fps. This is a host reproduction of control flow, not physical codec evidence.

The new automatic path inspects regular AVC encoders with surface input. It tries
the source-sized request first when aligned, then a bounded descending candidate
set derived from actual codec bounds and fixed long-edge steps. Each candidate
must satisfy width/height alignment, dimension bounds, bitrate range, size/rate
support and the final advertised format. At most eight candidate sizes per codec
are considered. The largest supported candidate in that bounded set wins; equal
sizes retain platform codec preference order. A refusal remains a refusal.

The original manual inspect overloads keep their strict one-format behavior.
Automatic sizing requires ORIGINAL shape and FIT framing. It never increases
either requested source dimension. Small alignment-related shape differences
produce FIT bars, preserving the whole picture. The source frame timestamps,
frame-rate request and AAC soundtrack are retained. No frame-rate conversion,
audio transcoding or HDR conversion is introduced.

The actual selected width and height are consumed by the encoder, EGL pipe,
overlay bitmap and automatic preview. The renderer rechecks upright source
dimensions, rotation and requested dimensions after reopening the recording.
Automatic preview measures graphics in output pixels before scaling the canvas
to the visible view, so a smaller preview does not choose a different headline
layout. The output details show the selected size and any reduction.

An explicit ratio or framing choice disables automatic size selection for that
draft. The cache key includes the sizing flag, and generation checks reject stale
asynchronous inspection responses. Both new flags are persisted. A saved automatic
sizing flag combined with incompatible framing fails closed. An advertised codec
is still only a candidate: configuration, encoding, output validation and Gallery
publication must complete before DUWM reports a saved video.

## Automatic production and AI help

The existing unattended flow remains enabled after new capture: it retains the
complete recording, chooses compact report graphics, uses recorded speech or
capture notes when available, encodes and saves through the durable Gallery path.
It requires no server address, account or API key. AI HELP checks installed caption
support in the app. If the Android recognition service cannot supply usable
captions, the video can finish with its original audio and an explicit caption-
unavailable result. No general-purpose chatbot or semantic scene-selection model
is bundled. Speech recognition availability and accuracy remain device dependent.

## Confirmed inherited Actions repair

The actual /20 GitHub run 42398937550 completed successfully on 2026-11-07.
Both compile-development and native-broadcast-tests passed. Its exact source ZIP
and workflow matched the delivered /20 bytes. The original downloaded strict
verifier passed all 15 stages using the exact CI application and test APK hashes;
128 listed evidence files were independently checked for path, size and SHA-256.

That run includes the previously failing caption_files stage. The retained /19
repair checks the actual RadioButton, opposite selection, RadioGroup and controller
time basis instead of treating performClick's listener return as selection success.
No stage is skipped or converted to a pass. The /20 automatic-production stage
actually saved and reviewed a caption-free MP4 because its emulator language model
was unavailable. Supplied-transcript stages separately checked captions and ticker
pages through the real renderer and decoded Gallery output. They do not establish
speech-recognition accuracy or physical camera behavior.

These successful /20 results belong to its CI-signed binaries. The local delivered
APK uses the retained local signing certificate. Prior /20 execution is never
counted as native execution of this new /21 APK.

## Matching workflow and required evidence

The /21 workflow retains the runtime BUILD_LOG_DIR context repair and Node 24
actions: checkout v5, setup-java v5, setup-python v6, Gradle setup v5,
upload-artifact v6, download-artifact v7 and android-emulator-runner v2. It restores
the full exact /21 source or a checked patch over an exact /10 through /20 archive.
There are twelve restoration routes. A corrupt present /21 archive is rejected.

All sixteen native stages are mandatory. The new automatic_fit stage uses a
clearly identified synthetic transcript and a test-owned portrait media fixture.
It drives the actual editor, selected advertised output plan, encoder, Gallery,
decoded headline, saved draft flags and manual takeover. The portrait fixture is
derived from the existing test media by changing rotation metadata while retaining
the AVC/AAC packets. It does not fake codec support to claim a native fallback.
Required new evidence is ANDROID-AUTO-FIT.mp4, ANDROID-AUTO-FIT-HEADLINE.png and
AUTO-FIT-NATIVE.json. Every prior stage remains required with exact installed APK
hashes, one run ID, successful instrumentation termination and verified files.

The separate verification ZIP records actual current host and build results.
Current /21 native acceptance is NOT RUN until its exact application/test APKs
complete all sixteen stages. The local runtime has no KVM and an unresolved API35
storage/system-process failure; an equivalent failed boot is not repeated.

Install DUWM-1728.2-21-AUTO-FIT.apk as the signed development build. To run its
matching Actions workflow, place DUWM-1728.2-21-AUTO-FIT-SOURCE.zip at repository
root and DUWM-1728.2-21-AUTO-FIT-APK.yml under .github/workflows/, then push to
main or use workflow_dispatch. The source ZIP and YAML must be this exact pair.
Compiled-development and native-tested APK artifacts remain separately labelled.

## Primary Android references

- https://developer.android.com/reference/android/media/MediaCodecInfo.VideoCapabilities
- https://developer.android.com/reference/android/media/MediaCodecInfo.CodecCapabilities
- https://developer.android.com/reference/android/media/MediaCodecList

These document advertised codec bounds, alignment, bitrate and size/rate support,
format checks and regular codec enumeration. The bounded candidate ladder and
automatic/manual behavior are DUWM policy. Capability discovery is not proof that
a particular device has successfully encoded the requested recording.
