# DUWM 1728.2/1 — Professional broadcast output / development checkpoint

Local status: **NOT RELEASED**. The source is not an installable APK. Full Android compilation and physical-device MP4 export still required.

## Implemented in source and tested
- Reporter-controlled scrolling broadcast ticker, drawn frame by frame into the exported MP4 encoder input surface.
- Timed story updates: `MM:SS=message;MM:SS=message`, up to 12 entries, max 180 characters each, relative to the beginning of the *exported clip*.
- Three ticker speeds (slow/normal/fast) and six newsroom templates (General Report, Breaking News, Weather, Traffic, Interview, Emergency).
- Ticker bounds clipped to a safe strip; explicit `REPORTER UPDATE` and `REPORTER-ENTERED / UNVERIFIED` labels.
- Interactive edit fields, animated preview marquee, trim range, validation and export to a new Gallery MP4 leaving original untouched.
- Report headings and location/description remain permanent burned-in video overlays.
- Pure Java tests prove timed cue selection, movement direction and invalid-input rejection; all Java sources pass syntax checks.

## Unverified / incomplete
- Android APK compilation, surface-input video codec availability, actual MP4 playback, audio synchronisation, and Gallery export on a physical phone.
- Embedded live telemetry in the **post-recording edited output**, independently verified news feeds, fully functional teleprompter, automated speech captions, language translation, picture-in-picture, map inset, C2PA, unlimited-duration export.
- Existing export remains limited to 45 seconds / 1280-pixel max dimension.
- Final release source ZIP and build YAML remain withheld until acceptance as requested.
