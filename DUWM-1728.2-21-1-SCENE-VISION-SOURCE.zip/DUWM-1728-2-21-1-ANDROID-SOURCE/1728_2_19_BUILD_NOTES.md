# DUWM 1728.2/19 — automatic reports and complete caption pages

## Changes to the finished video

The existing unattended camera-to-Gallery flow now prepares a labelled headline
and timed ticker excerpts from the recognized source captions. A headline uses a
short contiguous excerpt labelled SOURCE WORDS; tickers use separate excerpts at
their exact original source intervals. Adjacent identical source cues can share
one ticker interval, but gaps remain gaps. Neither the source caption document nor
its SRT export is shortened. Recognition status and timing diagnostics stay in the
editor evidence, rather than being burned into the finished video's ticker.

When no timed speech is available, existing capture notes may supply explicitly
labelled SOURCE NOTES excerpts. The original notes remain in the draft. When
neither source is usable, the report uses a neutral recording label. This is a
source-excerpt policy; it does not infer visual events or verify factual claims.

Long captions now use measured pages of at most two rows in the shared preview
and encoder painter. Pages cover the original cue text without a permanent
ellipsis, keep the caption panel height stable, and divide the existing cue
interval deterministically. The stored words, cue start/end times and SRT bytes
remain unchanged. Surrogate pairs, combining marks, joined emoji, paired flags
and Hangul Jamo are protected from page splits. This is not a claim of complete
Unicode language tailoring. Extremely dense, short cues can still be too fast to
read or have more pages than video frames; pagination does not invent extra time.

## Automatic recognition and persistence

A confirmed recorded-file recognition session that fully consumes its PCM input
and ends through the expected segmented-session callback may return no words.
That completed section now lets the next section continue without discarding
valid captions already collected. It does not establish that the audio was
silent. Errors, NO_MATCH, unsupported requests, missing timestamps and incomplete
file sessions remain failure conditions, with the inherited honest caption-free
video fallback. Recognition still depends on the installed Android on-device
speech service; no new model, service address or backend is required or bundled.

Automatic ticker cues, notes and headline source intervals survive draft reopen.
Trimming intersects and rebases the display intervals without mutating their
original source times. Explicit manual ticker entry replaces the automatic
ticker list; an explicit headline edit clears its former source interval.

Malformed stored report metadata keeps the original draft protected and blocks
export or caption replacement from overwriting it. When only the caption array
is invalid, other valid report details restore first and an explicit reviewed
caption replacement can recover the draft without losing title, trim or tickers.
Headline source times must be exact integer milliseconds or the absent sentinel.

## Exact lineage and retained application

The baseline is the exact delivered /18 AUTO-PRODUCTION SOURCE ZIP:
`2602a4a93dac8627be1bedd7a2dee7a64bcf5308d745a9d502588d06f36afcce`.
Its 819 manifest hashes were checked before extraction. Six existing production
Java files change for the report, recognition, rendering and editor integration;
292 other /18 production Java files remain byte-for-byte identical. Two production
helpers are added, for a total of 300. The original single globe, navy #041424,
nineteen desks and native camera remain in the complete application.

The /17 Actions run 42388645605 passed all eleven native stages. During this /19
session the /18 upload subsequently arrived and Actions run 42393315192 started.
That exact /18 run compiled successfully and finished with twelve of thirteen
native stages passing. Its automatic-production stage passed actual unattended
MP4 export, Gallery publication, soundtrack retention, review and duplicate
suppression. The emulator reported no confirmed offline speech language, so this
was an honestly labelled caption-free result and did not verify recognition.
Prior results do not count as /19 execution.

## Inherited /18 Actions failure corrected in the native test

The /18 caption_files stage stopped at the first Original video radio choice:
`Actual control responds: caption-files-original`. The test incorrectly required
RadioButton.performClick() to return true. Android's compound-button implementation
updates the checked state and returns the inherited click-listener result; the
caption-file choice is wired through a RadioGroup checked-change listener.

The /19 test now clicks the real reachable radio control and verifies the target
selection, opposite selection, RadioGroup checked ID and actual controller time
basis. It exercises both directions before saving the original-video SRT. The
normal-button listener assertion, actual file-byte checks, all native stages,
exact APK binding and strict failure gate remain required. This is a test-harness
correction; it does not change the production caption-file controller or relabel
the failed /18 run as successful. A new /19 run is needed to execute the repair.

Primary references:
- https://developer.android.com/reference/android/view/View#performClick()
- https://android.googlesource.com/platform/frameworks/base/+/refs/heads/main/core/java/android/widget/CompoundButton.java

## Inherited Actions runtime warnings

The /18 logs also reported actions declaring Node.js 20 while the hosted runner
forced them onto Node.js 24. The current /19 workflow updates those action
references to documented Node.js 24 defaults:

| Action | /18 reference | /19 reference |
|---|---|---|
| Checkout | actions/checkout@v4 | actions/checkout@v5 |
| Python setup | actions/setup-python@v5 | actions/setup-python@v6 |
| Gradle setup | gradle/actions/setup-gradle@v4 | gradle/actions/setup-gradle@v5 |
| Artifact upload | actions/upload-artifact@v4 | actions/upload-artifact@v6 |
| Artifact download | actions/download-artifact@v4 | actions/download-artifact@v7 |

The observed hosted runner is 2.338.2, above the documented 2.327.1 minimum.
Existing Java setup and emulator action references are retained. The same
artifact names, download destinations, exact APK identity checks and fourteen
native stages remain. The final workflow audit checks the current action inputs
and runtime declarations; a subsequent Actions execution verifies runtime use.
No warning-suppression or insecure runtime-override flag is added.

Official runtime releases:
- https://github.com/actions/checkout/releases/tag/v5.0.0
- https://github.com/actions/setup-python/releases/tag/v6.0.0
- https://github.com/gradle/actions/releases/tag/v5.0.0
- https://github.com/actions/upload-artifact/releases/tag/v6.0.0
- https://github.com/actions/download-artifact/releases/tag/v7.0.0

## Build and acceptance evidence

Version code is 172819; version name is 1728.2.19. The deliverables are a newly
compiled signed development APK, matching full SOURCE ZIP, matching Actions YAML
and verification archive. The report accompanying those files records actual
compiler, host, archive-restoration and workflow-validation results.

All thirteen previous native stages remain mandatory. The new fourteenth stage,
automatic_report, uses a clearly identified synthetic transcript fixture to
exercise the actual editor automatic-plan path, native encoder, saved Gallery
MP4, decoded first/last caption pages, exact ticker timing, draft reopen and
manual replacement. It does not inject or claim a successful live recognizer.
The existing automatic_production stage still records its actual device speech
or fallback outcome without injecting a transcript. Current run ID, exact app
and instrumentation APK hashes, stage completion and mandatory media are all
required by the strict gate. A missing stage or environment obstruction fails.

Local Android runtime acceptance is NOT RUN. The environment has no KVM and the
existing API35 emulator has unresolved storage/system-process failures; an
equivalent failed boot was not repeated. A new exact /19 Actions or device run
is required for native acceptance. Physical-camera capture, live recognition
accuracy, external recipient acceptance and older-phone performance remain
separate checks.

## Use and Actions

Install the APK to use /19. New clean camera recordings use the retained automatic
flow; AUTO PRODUCE applies it to an opened recording. AI HELP is built in and
contains no server-address or API-key setup. Manual edits remain optional.

For Actions, place the matching full SOURCE ZIP at the repository root and the
matching YAML in .github/workflows/, then commit them. The workflow supports push
and workflow_dispatch, checks ten exact source-restoration routes, compiles the
app/test APKs and requires all fourteen native stages. Compiled development and
native-tested outputs remain separately labelled.
