# DUWM 1719 — MY WORLD + MONITORS CAM RELIABILITY

## Lineage
Upgrades full DUWM 1718 source; original globe and 19 desks retained. The most recent confirmed GitHub numbered signed APK at authoring time is DUWM 1717 FIX1; source-only 1718 has not yet passed a GitHub APK build.

## Actual source changes
* `Duwm1719MyWorldActivity` is a new full-screen, uniform #041424 country-neutral home. It reads the SAME private followed-place preferences used by 1718 Global Discovery. There are no fictitious live event counts. Cards show explicit IANA time zone clocks, place coordinates, existing map navigation, and location-agnostic quick access to original globe, 19 desks, signal centre, World Monitor and MONITORS CAM. Unknown timezone displays `TIME ZONE NOT SET`. The user can choose an IANA zone; the choice is saved locally. Local topic interests are stored privately; they do not pretend to filter unconnected global feeds.
* MONITORS CAM gains real preflight status checks before recording: permissions, GPS opt-in and accuracy, compass sample freshness, weather model freshness, reporter-supplied claims and the permanent-overlay privacy warning. Camera/video core and report review composer are retained, not replaced.
* The 1718 Global Discovery page links back to My World. Main mission dock has a My World button without adding a second globe.

## Privacy and truthful source states
Precise GPS remains OFF by default. Reporter/place/situation are self-reported; sensor samples are labelled and are treated as stale when old. Opt-in model weather is labelled by source and not presented as observed real-time weather. Published user reports still require review and start UNVERIFIED. No automatic uploads. No invented worldwide media backend.

## Important limits
Java parser and source checks do not prove APK compilation, phone camera encoder support or burned-in MP4 playback. GitHub must build and sign a real APK. Test on representative Android hardware before marking camera recording operational.
