# DUWM 1728.2/9 — automatic AI entrypoint and compilation repair

## Baseline and actual failure
This is the complete original DUWM application, patched from the exact failed
1728.2/8 PRO-BROADCAST archive. It is not the separate BROADCAST-STUDIO archive.

- Repository: Sentongoharuna/Duwm
- Failed Actions run: 42347829732
- Failed compile job: 128329310961
- Commit: f7fe3c36e6452b6a96be009ece4e7dfcaf2e5165
- Baseline ZIP SHA-256: 144baab2e1a066af19d548c8a7b8e610719a15e77441f57c5efe9cee9b8754fd
- Compiler error: Duwm1728VideoEditorActivity.java:84 cannot find symbol startAi(Spec).
- The existing implementation was named beginAi(Spec). Syntax parsing did not
  resolve method references and therefore missed the error.

## Changes implemented
1. Automatic capture-to-AI and confirmed manual AI actions call the same existing
   beginAi implementation. No empty stub, disabled feature, or fabricated output.
2. Automatic start rechecks consent, connection, clean-master status, existing
   headline, activity close state, export state and any request already in flight.
3. The shared entrypoint rejects invalid clip ranges, an unavailable configured
   connection, activity closure, and duplicate/export-time requests.
4. New regression examines the actual editor AST and rejects the original broken
   call. Pure-Java production admission policy is tested in all 128 boolean states.
5. Correct identity: versionName 1728.2.9, versionCode 172809 and matching launcher.
6. CI now exposes an Android Java type-check step before APK assembly, preserves
   complete compiler logs and puts the first errors in the Actions summary.
7. Native Canvas/EGL MP4 tests remain mandatory after compilation. Failures are
   not hidden with continue-on-error. APK artifacts and evidence artifacts stay
   separate and clearly named.
8. The workflow supports both this complete /9 ZIP and verified recovery using
   the exact /8 PRO-BROADCAST ZIP already on GitHub.

## Preservation
276 of 277 baseline application Java files remain byte-identical. The only
changed existing application class is Duwm1728VideoEditorActivity; one small
pure-Java AI admission policy is added. Camera capture, original globe, dark
navy theme, source signals, all desks, broadcast graphics, ratios, ticker,
EGL exporter, AI client/server, and the separate native test suite are retained.
The older /8 manifest and notes are historical; the /9 source manifest is the
current integrity authority.

## Executed here
- 113 shared broadcast layout/pixel/motion/privacy/aspect assertions (host JVM).
- 5,815 source-signal policy assertions and 188 capture-health assertions.
- 128 AI admission-policy states; source AST check; broken-call negative test.
- 13 AI server tests using mocked provider calls, not live model inference.
- Java syntax: 278 application files plus 2 Android-test files.
- XML, version identity, source hashes and ZIP restoration checks.

## Not executed here / not green
Full Android Gradle compilation, native Android encoder tests, installation and
physical-phone recording/playback are not verified in this environment. This
runtime has no Android SDK/Gradle and its SDK download attempt was unsuccessful.
GitHub must execute those real gates. No AI endpoint is deployed or connected by
this patch. Advanced hardware modes and worldwide broadcasting are not marked
complete by this compiler repair.

## Install and build
Place the SOURCE ZIP in the repository root and the matching APK.yml in
.github/workflows/. If the existing exact /8 ZIP is present, the YAML can also
restore /9 from its embedded checked patch without a separate /9 upload.
Do not rename this ZIP to a previous version or rerun the unmodified /8 workflow.
Run the workflow named DUWM 1728.2/9. A compiled debug APK is not a production
certificate of camera performance. Native tests additionally validate actual
encoded test clips but still are not a physical-camera or live-AI test.

The existing package identity is retained. Android updates require the same
signing certificate as the installed app. The optional existing repository
secret DUWM_DEBUG_KEYSTORE_BASE64 can retain the developer signing key. Never
share that private key in chat; preserve private drafts before reinstalling.
