# DUWM 1728.2/21/1 — Camera scene understanding

## Delivery status

This release contains the source integration for real on-device scene descriptions,
the corresponding GitHub Actions build workflow, and scoped verification evidence.
An installable `/21/1` APK has **not** been built in the current environment.

The actual offline Gradle attempt stopped at dependency resolution because
`com.google.mlkit:genai-image-description:1.0.0-beta1` is absent from the cache.
Neither the application compiler nor instrumentation compiler ran in that attempt.
The previously established download restriction was not bypassed or retried.

The delivered workflow resolves the official artifact in the normal build
environment, performs real Android compilation, inspects APK class definitions,
and requires seventeen native stages. A future successful workflow is not itself
proof that Gemini Nano runs on a particular physical phone.

## Exact baseline and identity

- Baseline: `DUWM-1728.2-21-AUTO-FIT-SOURCE.zip`.
- Baseline SHA-256: `3117973d5e1cce4f0e257bf179a3c81bf91a5f903605c8b59fde524744558a2d`.
- Version name: `1728.2.21.1`; launcher label: `DUWM 1728.2/21/1 • DEVELOP.UGANDA`.
- Version code: `172822`, the next integer after `/21`. Subsequent releases must
  use a code greater than `172822`, including a later release named `/22`.
- Application ID: `com.sentongoharuna.worldsituationroom.rb2live25`.
- Minimum Android API: 26, required by the official Image Description SDK.
- Existing original globe, nineteen desks, navy palette and camera-to-recorder
  clean master remain in the project. Three hundred existing production Java
  files are hash-identical to the delivered `/21` baseline.

## Implemented source changes

The camera creates an actual `ImageDescriber`, checks feature availability and
uses `prepareInferenceEngine()` for automatic model preparation. Actual image
requests use `ImageDescriptionRequest` and `runInference()`. There is no
reflection-only substitute, remote address form, developer-key form or generated
scene placeholder in production code.

Camera sampling reads the clean `TextureView`, excluding sibling graphic overlays.
It preserves image proportions, limits image size and reverses the front-camera
preview mirror before model input. The clean master continues through the existing
direct MediaRecorder path.

Only returned model words supply scene titles and descriptions. The title is a
bounded excerpt of those words; the description retains the longer result.
Speech excerpts remain separate. No GPS, weather, notes or status message can
create an apparently observed scene.

The live camera and export share the existing broadcast painter. Scene mode
replaces the fixed DUWM/WORLD MONITOR video badge with the current model title.
Missing, expired or future descriptions produce a neutral scene state. Manual
and legacy compositions retain their existing rendering behavior.

Private atomic sidecars bind descriptions to their source video URI and source
times. An empty sidecar marks an enabled capture with no available description.
An explicit capture marker preserves this distinction if sidecar saving fails.
The automatic production flow loads this track and exports it without requiring
manual title entry. A manual headline edit deliberately switches scene titles off;
the recorded scene mode can be selected again in the editor.

## Timing and lifecycle policies

- At most one accepted inference is in flight; normal requests are separated by
  at least four seconds. Busy and device-quota errors impose additional delays.
- Results older than eight seconds are discarded. Each observation has at most
  twelve seconds of validity, shortened by a later observation or detected
  large image change.
- An image-difference trigger only withdraws stale observations. It never names
  objects, interprets events or supplies caption words.
- Camera switches, recording starts/stops, pause and destruction invalidate old
  callbacks. Scene resets preserve rate-limit cooldowns.
- Captured offsets use the camera activity's monotonic clock relative to successful
  MediaRecorder start. Their physical alignment with encoded video timestamps has
  not yet been measured on the phone; native fixture timing tests do not prove
  camera/encoder latency. This is part of physical-device acceptance.
- Trimming selects observations at original source time and converts bounds to
  clip time once. Expired newer observations never revive an older overlapping one.
- Model work requires the app to remain in the foreground. The camera continues
  to record when the model is unavailable; unavailable observations stay neutral.

## Verification boundaries

Host checks exercise the real timeline, text fitting, scene-change policy and
shared drawing logic with explicitly supplied fixtures. Analyzer lifecycle tests
use isolated test doubles and do not execute a language or image model.

A separate source type check uses the real Android SDK jar and temporary,
documentation-derived Google API declarations to catch cross-file/Android API
mistakes. Those declarations never enter an Android source set, Gradle build,
dependency cache, APK or DEX. This check is not official SDK compilation.

The mandatory `scene_timeline` native stage uses synthetic observations and the
real Android export/decode path. Its evidence explicitly records
`model_inference_verified: false` and `physical_camera_verified: false`.
All sixteen previous stages and their mandatory
artifacts remain required. Native stages were not executed locally for `/21/1`.

The final host suite passed with all 497 application/native Java and verification
inputs unchanged. New checks include 3,564 layout assertions, 494 timeline/text
assertions, 13 appearance-change assertions and 283 controller assertions using
temporary test doubles. All retained `/21` regression suites also passed. The
source-wiring check passed for 309 application and eleven instrumentation Java
files with unchanged inputs; its temporary Google declarations do not constitute
official dependency compilation.

The workflow independently requires successful official SDK resolution and actual
SDK class definitions in the assembled APK. A dependency listing with failed
entries or a descriptor appearing only as a DEX string is insufficient.

## Physical-phone acceptance still required

1. Install the genuine SDK-backed APK with a signing certificate compatible with
   the existing installation, and open the camera.
2. Observe automatic model preparation and a runtime READY state. Unavailable
   devices must retain usable recording and an honest unavailable status.
3. Point at several different real scenes. Confirm distinct relevant returned
   descriptions, sensible response time and no previous-camera result after a flip.
4. Record, move between scenes, stop and let automatic production complete.
   Check the exported video, scene timing, audio and picture orientation.
5. Exercise pause/resume, model unavailability, quota delays and loss of network
   after model preparation. Weather/network features are separate from this test.

This `/21/1` scope is the requested camera understanding step. Automatic location
names, expanded numeric telemetry and automatic weather refresh remain separate
work described in the project plan.

## Build the matching pair

Place `DUWM-1728.2-21-1-SCENE-VISION-SOURCE.zip` in the repository root and
`DUWM-1728.2-21-1-SCENE-VISION-APK.yml` in `.github/workflows/`. The workflow also
supports an exact checked patch over the hash-pinned delivered `/21` or `/20`
source ZIP if the new full source is absent. A corrupt present new source ZIP is
rejected rather than ignored.

Compilation and native-test artifacts have distinct names. Failure diagnostics
are uploaded even when a required stage fails. No step converts a failure into a
pass, and physical model support is never inferred from emulator success.

## Official API references

- https://developers.google.com/ml-kit/genai/image-description/android
- https://developers.google.com/ml-kit/genai
- https://developers.google.com/android/reference/com/google/mlkit/genai/imagedescription/ImageDescriber
- https://developers.google.com/android/reference/com/google/mlkit/genai/common/GenAiException.ErrorCode
