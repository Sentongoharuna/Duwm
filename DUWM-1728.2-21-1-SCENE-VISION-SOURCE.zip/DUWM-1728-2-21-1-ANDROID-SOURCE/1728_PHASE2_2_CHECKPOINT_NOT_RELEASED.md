# DUWM 1728.2/2 — Local development checkpoint, NOT RELEASED

Changes:
- Stores one privacy-aware *capture-end* snapshot for completed Gallery videos recorded by MONITORS CAM, associated with that video URI. This is not a per-frame GPS track.
- Saves UTC capture-end time, sensor heading, altitude and GPS accuracy, and optional model weather with explicit origin/freshness labels. Precision stays withheld unless original recording opted in.
- Editor loads provenance only from existing app storage. External/imported videos without a record cannot invent telemetry.
- Edited MP4 can optionally burn the capture-end snapshot. Publishing coordinates requires another unchecked-by-default export consent.
- Adds reporter-written timed subtitles, clip-relative like the broadcast ticker, burned per frame. These are NOT automatic voice transcription.
- Preserves original recording, moving ticker and six newsroom templates.

Validation: Java parser, source integrity, timing checks and provenance privacy tests. Android compiler, actual MP4 export/audio sync and device verification are outstanding.

Important: This is an additive DEVELOPMENT CHECKPOINT. The 1728 final source ZIP and workflow are withheld until the complete acceptance checklist is verified.
