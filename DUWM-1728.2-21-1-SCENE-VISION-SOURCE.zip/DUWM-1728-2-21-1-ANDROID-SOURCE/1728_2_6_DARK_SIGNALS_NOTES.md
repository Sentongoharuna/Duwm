# DUWM 1728.2/6 — Dark Navy + Real-State Signal Animation

## Scope of this build
This is a colour/animation correction to the complete 1728.2/5 project, not an AI production-engine completion. The camera, speech recognition, editor, ticker and encoding implementations are retained unchanged. Existing unfinished camera/broadcast requirements remain unfinished.

## Changed in actual Android source
- Retained the approved #041424 navy, #DEE5EF silver outlines and #F5F7FA text.
- Darkened the original globe ocean, coastline, country-border and rim paints. Its geography, original rotation/zoom/touch controls and live data architecture are retained.
- Replaced white-outlined dots and transparency fades with an opaque custom-drawn status lamp. Colours on the lit phase are exact: red #D50000, orange #F57C00, yellow #FBC02D, blue #0D47A1, cyan #00ACC1, green #00C853.
- Added independent, deterministic animation phases: red slow warning blink; orange degraded pulse; yellow stale pulse; blue connecting blink; cyan actual-new-receipt blink; green current-source heartbeat.
- Animation does NOT create a source receipt, update a count or reset freshness. Cyan requires the existing genuine-new-record callback. Grey means no receipt and remains still. Local tools use a hollow neutral ring and remain still.
- Applied the shared lamp to the 19-sector rail, Signal Centre/current-source cards, existing native desk lamps, legacy status widgets, the functional World Status header and the original globe's source beacons.
- Static legends/history do not animate; background windows stop scheduled lamp drawing. Android's system animation setting is respected.
- Retained a single original globe. No camera footage, thumbnails, photographs or video are darkened with a whole-screen filter.
- Embedded versionCode 172806 and versionName 1728.2.6. The launcher identifies 1728.2/6 instead of 1727.

## Evidence available in this environment
PASS: executed 5,815 Java assertions against the production motion/colour/freshness policy, including exact on-phase RGB, opaque alpha, independent rhythms, neutral no-animation and stale/error transitions.
PASS: all 270 main Java sources parsed; the separate instrumentation runner parsed.
PASS: original source integrity, 76 XML files and all six prior Phase 2 regression scripts.
PASS: SHA-256 preservation checks of the camera, Gallery publisher/library and every prior Duwm1728 editor/transcription class against the supplied 1728.2/5 source.
NOT RUN: Android Gradle compilation, APK installation, native pixel tests on emulator, physical-phone colour/motion approval. There is no configured Android SDK here, and direct SDK downloads are blocked by DNS.

## Build and verify
Upload the SOURCE.zip to the repository root and the APK.yml to .github/workflows/.
The compile job checks every source hash, runs the regression tests, compiles the real debug APK plus an isolated Android test APK, verifies signing/identity and uploads artifacts.
For native pixel checks and an actual globe screenshot, run the workflow manually with verify_android_pixels enabled. The Android test runner samples real Canvas output for exact colours and time-varying frames. It is in androidTest only, not in the user APK. Its fixtures are test data, not live feeds. A passing compile job does not mean the emulator/phone acceptance passed.

## Physical-phone acceptance still needed
1. The background must match the user's navy reference; the globe must no longer have the old light-blue gradients.
2. A known failed provider is solid red on its lit phase; a current provider is green.
3. Different sectors do not blink together. A receipt turns its own lamp cyan temporarily; delayed/cache data goes yellow/orange as applicable.
4. A source with no receipt stays grey. Local-only tools have a hollow neutral indicator, not a filled white "live" dot.
5. Switching away stops lamp animation; returning resumes it. Turning off system animations leaves solid, readable colours.
6. Check Main, Signal Centre, native desks and MONITORS CAM; confirm original globe gestures and camera playback are not altered.

No claim is made that prior AI broadcasting, aspect ratio, 4K/HDR, transcription or MP4-quality issues have been fixed by this colour patch.
