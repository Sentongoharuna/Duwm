# DUWM 1728.2/15 — Broadcast layouts

This build continues the exact delivered 1728.2/14 Export Recovery source ZIP,
SHA-256 `7910510de6650bfac15d4f77ce7dad74d1e2cf87f872ce6c1e4f5e315daafa16`.
The application ID remains `com.sentongoharuna.worldsituationroom.rb2live25`.
The version code is `172815`, version name `1728.2.15`, and launcher label
`DUWM 1728.2/15 • DEVELOP.UGANDA`.

## Three compositions in the actual broadcast renderer

The prior STYLE control selected the report category while keeping one common
composition. This build separates CATEGORY from LAYOUT. The layout choice is
part of the production specification used by both the editor preview and the
MP4 renderer; it changes encoded graphics rather than only the editor controls.

- **Full Report** retains the complete headline, byline, category, provenance,
  ticker, available selected sensor information and timed captions.
- **Compact** uses a smaller lower third with a single-line headline, byline,
  shorter sensor strip and ticker. Long text is fitted to its visible region.
- **Captions** keeps the DUWM identity, recorded/source clock, category and
  provenance, and active timed captions. It intentionally omits the large
  headline panel, ticker and sensor strip.

Every layout keeps the midnight navy `#041424` background with silver edges
and readable text. Category accents are silver for general reports, cyan for
weather, orange for traffic, purple for interview and green for environment.
Red is reserved for a reporter-approved Breaking News category. A category
colour is not independent verification of an event.

Timed captions keep their original start/end behavior and silent gaps. The
layout change does not alter source timing, trimming, framing, audio handling
or the source recording. Captions and sensor fields are not invented when
their source information is absent. Precise coordinates remain opt-in.

## Visual layout selector and saved drafts

A dedicated LAYOUT control opens graphics previews for the three choices.
Those previews use the shared renderer and the current report. They are
graphics previews rather than a separate edited video or generated news image.
Choosing a layout immediately refreshes the actual editor preview, resets the
review approval, and saves the choice with that recording's draft. Existing
drafts without a layout field use Full Report.

AI-produced text and timed cues use the selected composition. Applying an AI
draft preserves the chosen layout and does not require a second AI request.
Automatic AI production still requires its existing configured service and
consent. This build does not claim to have connected or tested a live AI service.

## Preserved application

The original single globe, native camera, all existing desks, navy application
theme, source receipts, media transport, Gallery publisher and export recovery
remain. `verification/1728_2_14_PRESERVED_JAVA.json` protects 285 existing
production Java files from the delivered /14 source. Existing production
changes are limited to the broadcast editor, shared composition and the
renderer specification that passes the composition to that shared drawing code.
A small composition policy is added separately.

## Verification boundaries

`verification/check_1728_2_15.py` executes the host regressions and production
graphics comparisons. The /14 comparison renderer is a clearly marked,
test-only reference copied from the verified predecessor source. The host
images are labelled as host-rendered production-layout comparisons: they
establish drawing, geometry, colour and timing, not Android font rendering,
Activity layout, MediaCodec, Gallery or physical-phone operation.

All nine previous native stages remain required. A tenth `composition` stage
checks the new native composition and editor path. The complete gate requires
one run ID, the exact installed application and test APK hashes, successful
wrapper/instrumentation results, and all required evidence hashes. Missing,
interrupted, obstructed or older-build stages cannot become a native pass.

The /14 local emulator attempts encountered pre-existing readiness failures
and then a system-process crash during testing. That is prior environment
evidence, not a /15 runtime result. The accompanying /15 verification archive
states exactly which tests were actually run. No /14 pass or failure is reused
as proof that /15 ran.

## Matching source and GitHub workflow

The delivered source ZIP and workflow form a checked pair. The workflow can
restore the exact /15 source from its complete ZIP, or from the verified
/10, /11, /12, /13 or /14 source ZIP plus the embedded checked patch. A mismatched
complete /15 ZIP is rejected. Source restoration is executed during packaging
and all packaged file hashes are checked.

The workflow assembles a signed development APK and matching instrumentation
APK, then requires the full native gate before publishing a native-tested
artifact. The compiled development artifact remains explicitly labelled.
Providing the workflow is not a claim that GitHub Actions ran or turned green.
The optional existing debug-key secret can preserve a prior signer; private
signing material is not included in these deliverables.

Actual build, signature, packaging, host and runtime outcomes belong to the
accompanying verification report. This file describes the implementation and
required gates; it does not mark unexecuted gates as passed.
