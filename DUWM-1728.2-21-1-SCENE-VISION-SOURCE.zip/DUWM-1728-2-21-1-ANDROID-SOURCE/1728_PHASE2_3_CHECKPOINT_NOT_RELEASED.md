# 1728.2/3 — Development checkpoint only (NOT RELEASED)

- Camera teleprompter: user-entered, optional, displayed inside preview only. Does not alter recorded video.
- Capture-time sensor samples: at most 200, approximately every 2 seconds while recording. Stores only readings actually available. An editor setting is opt-in and the exported overlay identifies sample age/time and NOT LIVE.
- GPS remains opt-in during capture and requires another explicit consent in the editor for precise coordinate disclosure.
- Editor can request device speech-recognition microphone dictation to suggest one timed caption; reporter must confirm. This does NOT automatically transcribe video audio.
- Original video remains unchanged. 45-second export / 1280-pixel editor limit remains.
- Required: Android Gradle compilation and device tests for speech recognizer, sensor timeline, audio/video sync and export. No final release ZIP/YAML authorized.
