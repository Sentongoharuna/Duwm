# DUWM 1728.2/17 — Playback Repair

This release continues the exact delivered /16 Caption Editor source archive,
SHA-256 `f162500f0a676dbaf82dcc4c0fb904675f78e11e212122ce6f8a3ec775f1594d`.
The application ID is `com.sentongoharuna.worldsituationroom.rb2live25`.
The compiled identity is version code `172817`, version name `1728.2.17`,
with launcher label `DUWM 1728.2/17 • DEVELOP.UGANDA`.

## Evidence that determined this repair

The actual /16 Actions run was
https://github.com/Sentongoharuna/Duwm/actions/runs/42386137856
at commit `9aeb7729a37b8478f56ba78adf4c16ab2fa99f3f`.
Its compile-development job succeeded. Its native job executed all eleven
stages: eight passed and three failed. The earlier /15 workflow startup error
was therefore already corrected in /16. Node.js deprecation warnings were not
the cause of the native failure.

The /16 CI application hash was
`cecf3b3c61c42e0dfdb2fa839c5e7aa987e3849fad16bb38b2e10d88fac67177`.
Its evidence archive was downloaded and verified against the GitHub artifact
digest before inspecting the failing screenshots, accessibility trees and logs.
Those are prior /16 results; they do not establish a /17 native pass.

## Three corrections

### Landscape trim controls

The actual /16 landscape screenshot shows the two-line MARK IN and MARK OUT
buttons clipped at the lower edge of their row. Horizontal LinearLayout's text
baseline alignment shifts these buttons relative to the one-line RESET TRIM
button. Scrolling cannot reveal a portion clipped inside that row.

The existing trim row now disables baseline alignment and centers its children
vertically. Its 48dp minimum touch height and scrollable editor remain. The
native test still requires the complete visible rectangle of every trim button,
the same TextureView and parent, a visible source viewport, an unchanged paused
playhead, and the same trim bounds. It additionally records each child's bounds
and row bounds, and checks the 48dp height explicitly.

### Saved-video missing-file test cleanup

The /16 review stage reached 23 checks, including the missing-file and Share
checks after deleting its own published video. Its final cleanup then called
MediaStore.delete on that same already-removed URI a second time. The reported
SecurityException at DuwmBroadcastChecks.java:284 failed the stage. Because
cleanup can mask an earlier assertion, the count alone does not prove that the
last Share assertion passed.

The test now records successful deletion and skips only that redundant cleanup
call. The real delete, missing-file state and disabled-sharing assertions remain.
No storage permission is added and no SecurityException is converted into a
passing result. A new phase marker records completion of the missing-file checks.

### Full-screen screenshot synchronization

The failing /16 PNG still showed the ordinary review controls, while its paired
accessibility dump already showed the full-screen controls. The test had sampled
the old displayed frame using the new VideoView coordinates immediately after
the layout change. This did not demonstrate a production framing defect.

The instrumentation now waits within a fixed deadline for rendered full-screen
frames and stable matching view geometry. It preserves the original screenshot
pixels, same-player assertion and strict encoded left/right marker checks. A
timeout remains a failure and saves the latest frame and readiness diagnostics.
The production review Activity remains byte-for-byte identical to /16.

## Preserved application and workflow

The original single globe, midnight navy #041424, native camera, nineteen desks,
three broadcast compositions, source-timed caption editor, playback, Gallery
publication and export recovery remain. The hash inventory
verification/1728_2_16_PRESERVED_JAVA.json protects the 290 other production Java
files from the exact /16 archive. Only the existing editor's heading and trim
row alignment change in production Java.

The /16 runtime RUNNER_TEMP/GITHUB_ENV startup correction is retained. All
eleven stages remain mandatory: signals, graphics, exports4, framing, inset1,
review, editor_controls, review_controls, recovery, composition, caption_editing.
The evidence gate requires one current run ID, exact app/test APK hashes, actual
stage PASS records and complete evidence hashes. It cannot publish a native-tested
artifact after a failed or missing stage. /17 run IDs use the duwm17 prefix.

## Delivery and verification meaning

The APK is a newly compiled signed development build. The accompanying full
SOURCE ZIP and YAML form a matching pair. The generator tests exact restoration
from the full /17 archive and supported verified /10–/16 predecessor archives.
The verification archive records executed compiler, signature, host and workflow
checks, and keeps prior /16 evidence separate from /17 execution status.

Compilation, host checks and workflow validation do not prove that the corrected
Android stages have passed. A new /17 native run is required to establish that.
Physical-phone capture, live AI inference, recipient-app acceptance and device
performance remain outside the local verification performed for this release.
