# DUWM 1722 — Responsive Original Globe and MONITORS CAM

- Continue from complete 1721 source, not a fresh globe.
- Exact #041424 navy, #DEE5EF thin borders, white text.
- No duplicate floating legacy SIG chip above buttons: original 19-sector status header remains.
- Original single globe has 5 width-balanced first-row controls and 3 primary navigation controls, with an Explore dialog exposing all existing 19 desks, aircraft, vessels, weather, news, radio, TV, etc.
- MONITORS CAM records via existing native compositor; Preview, autofocus, zoom and a sticky record button are immediately accessible. Advanced reporter metadata, exposure, GPS privacy, microphone and opt-in weather are placed in an expandable panel.
- USGS global earthquakes support sorting (newest/strongest), source-labelled event sharing and existing offline cache, never invented safety alerts.
- 1722 is not considered a green APK until GitHub compiles it and signature/version checks pass. Camera encoder must also be tested on device.
