# DUWM 1728.2/16 — Caption Editor

This continues the exact delivered /15 Broadcast Layouts source archive, SHA-256
`0cbc629f507dc7a0bf7fb3e10f2cb7034ae1c21e128fb829d4bd116b86b185c2`.
The application ID remains `com.sentongoharuna.worldsituationroom.rb2live25`.
Version code `172816`, version name `1728.2.16`, launcher label
`DUWM 1728.2/16 • DEVELOP.UGANDA` identify the actual compiled application.

## Correct one caption while preserving the recording's timing

SRT and AI imports already retained exact source start and end times in /15,
but the editor exposed a separate start-only manual text field. Typing there
could replace the entire imported set. The new CAPTIONS control opens a native
caption editor with the existing source-timed cues and a separate working copy.
Individual text and start/end corrections, addition, deletion and preview are
available before Apply. Cancel leaves the saved caption set unchanged.

Times accept exact milliseconds as seconds or colon timecodes. Empty captions,
invalid times, reversed ranges and times beyond the source recording are
rejected. A cue may be outside the selected export trim: it is kept with the
source draft, and the existing shared rendering timeline clips it only when
preparing the selected output. Editing a word does not re-anchor other cues.

The editor supports up to 20,000 cues with bounded on-screen rows. Existing
overlapping AI cues remain valid; the established renderer chooses the latest
active start, and the later entry for equal starts. This release does not
silently normalize overlaps or replace supplied ends with inferred speech ends.

Legacy manual cues convert using their saved source origin and the existing
six-second/next-cue end rule, bounded by the source. Conversion is committed only
on Apply. The UI identifies the source-time basis and the legacy end rule.
Applying a change clears prior export approval, refreshes the production
preview and saves the draft. Trim, composition, framing and recording bytes
remain independent of caption editing.

## Workflow startup correction

The uploaded /15 YAML was rejected before any job began. GitHub reported an
unsupported `runner.temp` expression at job environment scope in run
`42383823926`, commit `8ce18aa9d3dec5c7dc01be1af68fcec2ac8fa45b`.
The uploaded file's bytes matched the delivered /15 YAML. This is a real
workflow validation defect, not an Android compiler or native test failure.

The /16 generator establishes its build-log path inside an executing step
using `RUNNER_TEMP`, and includes a focused regression for invalid job context.
The source restoration checks still execute the actual generated restoration
code against the complete source and every supported /10–/15 predecessor.
A local YAML/context check is not a claim that GitHub has accepted or run /16.

## Preserved application

The original single globe, native camera and existing desks remain. Midnight
navy `#041424`, the three broadcast layouts, video/audio transport, Gallery
publication and export recovery are preserved. The hash inventory
`verification/1728_2_15_PRESERVED_JAVA.json` protects 288 unchanged production
Java files from /15. The existing editor is the only modified production Java
file; the caption policy and native dialog are added separately.

## Verification and delivery

Host tests exercise exact time parsing, atomic editing, untouched cue retention,
legacy source origins, large sets, silence boundaries and trimmed rendering.
The supplied graphics proof executes the unchanged production drawing code
through a desktop raster adapter and is explicitly labelled HOST RENDERED.
It is not an Android UI screenshot, encoded video or phone demonstration.

All ten prior native stages remain mandatory. The new `caption_editing` stage
exercises the real controls, invalid edit handling, cancel/apply, draft reopen
and an MP4 export from the edited current specification. The gate requires
eleven stages with one run ID, exact application/test APK identities and full
evidence hashes. Missing, failed, obstructed or stale stages cannot pass.

The source ZIP, signed development APK and matching YAML are intended for
direct downloads in this conversation. The accompanying verification archive
records actual compilation, signatures, host results and native execution
status. Requirements in this file do not imply that unexecuted checks passed.
Physical-phone behavior, live AI inference and recipient-app acceptance remain
separate from compilation and host tests.
