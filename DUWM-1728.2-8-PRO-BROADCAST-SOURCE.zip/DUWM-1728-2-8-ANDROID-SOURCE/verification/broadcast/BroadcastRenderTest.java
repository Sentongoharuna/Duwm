package com.sentongoharuna.worldsituationroom;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;
import javax.imageio.ImageIO;

/** Executes the production Java composition on a desktop raster adapter.
 * These files prove drawing, timing and geometry; NOT Android recording/encoder operation. */
public final class BroadcastRenderTest {
    static int checks=0;
    static void check(boolean ok,String label){checks++;if(!ok)throw new AssertionError(label);}
    static final class Painter implements Duwm1728BroadcastLayout.Painter {
        final Graphics2D g;final Deque<Shape> clips=new LinkedList<>();final ArrayList<String> drawn=new ArrayList<>();
        Painter(BufferedImage b){g=b.createGraphics();g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,RenderingHints.VALUE_FRACTIONALMETRICS_ON);}
        void style(float size,boolean bold){g.setFont(new Font("SansSerif",bold?Font.BOLD:Font.PLAIN,1).deriveFont(size));}
        public void rect(float x,float y,float w,float h,int color,float r){g.setColor(new Color(color,true));g.fill(new RoundRectangle2D.Float(x,y,w,h,2*r,2*r));}
        public void line(float x,float y,float x2,float y2,int c,float width){g.setColor(new Color(c,true));g.setStroke(new BasicStroke(Math.max(.7f,width)));g.draw(new Line2D.Float(x,y,x2,y2));}
        public void text(String s,float x,float y,float size,int c,boolean bold){style(size,bold);g.setColor(new Color(c,true));g.drawString(s,x,y);drawn.add(s);}
        public float measure(String s,float size,boolean b){style(size,b);return (float)g.getFont().getStringBounds(s,g.getFontRenderContext()).getWidth();}
        public void clip(float x,float y,float w,float h){clips.push(g.getClip());g.clip(new Rectangle2D.Float(x,y,w,h));}
        public void unclip(){g.setClip(clips.pop());}
    }
    static Duwm1728BroadcastLayout.Report fixture(){
        Duwm1728BroadcastLayout.Report r=new Duwm1728BroadcastLayout.Report();r.title="Professional graphics rendered into every frame";
        r.location="LOCAL RENDER TEST";r.reporter="NOT A NEWS EVENT";r.category="BREAKING NEWS";r.breakingApproved=true;
        r.clock="GRAPHICS TEST";r.heading="TEST ONLY";r.altitude="TEST ONLY";r.weather="NO LIVE DATA";
        r.gps="PRIVATE COORDINATES";r.coordinatesAllowed=false;r.provenance="TEST FIXTURE • NOT A PUBLISHED REPORT";
        r.tickers.add(new Duwm1728BroadcastLayout.Cue(0,3000,"Solid red banner • Midnight navy • Silver outlines • This ticker moves inside the video"));
        r.tickers.add(new Duwm1728BroadcastLayout.Cue(3000,10000,"Timed update at 3 seconds • Shared preview/export layout • Original video is preserved"));
        r.captions.add(new Duwm1728BroadcastLayout.Cue(500,2700,"Separate captions stay above the news ticker."));
        r.captions.add(new Duwm1728BroadcastLayout.Cue(3200,5600,"This is an executed renderer test, not phone footage."));return r;
    }
    static BufferedImage image(int w,int h,long ms,boolean background,Duwm1728BroadcastLayout.Report r){
        BufferedImage b=new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);Graphics2D g=b.createGraphics();
        g.setColor(new Color(0x171E25));g.fillRect(0,0,w,h);
        if(background){
            g.setColor(new Color(0x28323D));for(int x=0;x<w;x+=w/10)g.drawLine(x,0,x,h);for(int y=0;y<h;y+=h/12)g.drawLine(0,y,w,y);
            int d=Math.min(w,h)/10;double phase=ms/1000.0;int cx=(int)(w*(.5+.25*Math.sin(phase))),cy=(int)(h*.43);
            g.setColor(new Color(0xA7ADB4));g.fillOval(cx-d/2,cy-d/2,d,d);
            g.setFont(new Font("SansSerif",Font.BOLD,Math.max(12,w/30)));g.setColor(new Color(0xDEE5EF));String t="RENDER TEST  /  1728.2/8";int tw=g.getFontMetrics().stringWidth(t);g.drawString(t,(w-tw)/2,(int)(h*.27));
            g.setFont(new Font("SansSerif",Font.PLAIN,Math.max(9,w/54)));String note="Shared production layout • Desktop encoder test";g.drawString(note,(w-g.getFontMetrics().stringWidth(note))/2,(int)(h*.31));
        }
        g.dispose();Painter p=new Painter(b);Duwm1728BroadcastLayout.draw(p,w,h,r,ms);p.g.dispose();return b;
    }
    static int difference(BufferedImage a,BufferedImage b,int x,int y,int w,int h){int count=0;for(int j=y;j<y+h;j++)for(int i=x;i<x+w;i++)if(a.getRGB(i,j)!=b.getRGB(i,j))count++;return count;}
    static void tests(File folder)throws Exception {
        if(!folder.isDirectory()&&!folder.mkdirs())throw new IOException("Cannot create evidence directory");
        int[][] dimensions={{720,800},{720,1280},{1280,720}};String[] labels={"9-10","9-16","16-9"};
        for(int k=0;k<dimensions.length;k++){
            int w=dimensions[k][0],h=dimensions[k][1];Duwm1728BroadcastLayout.Report r=fixture();
            BufferedImage a=image(w,h,0,false,r),b=image(w,h,1000,false,r);Painter p=new Painter(new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB));
            Duwm1728BroadcastLayout.Geometry geo=Duwm1728BroadcastLayout.draw(p,w,h,r,0);float u=geo.unit;
            check(a.getRGB((int)(geo.x+5*u),(int)(geo.tagTop+5*u))==0xFFD50000,labels[k]+" exact red badge");
            check(a.getRGB((int)(geo.x+130*u),(int)(geo.tickerTop+4*u))==0xFF041424,labels[k]+" navy ticker background");
            int silver=0,cyan=0;for(int y=0;y<h;y++)for(int x=0;x<w;x++){int color=a.getRGB(x,y);if(color==0xFFDEE5EF)silver++;if(color==0xFF00ACC1)cyan++;}
            check(silver>10,labels[k]+" silver visible");check(cyan>10,labels[k]+" colored telemetry present");
            check((geo.bottom-geo.tagTop)/h<.29,labels[k]+" graphics do not consume half the footage");
            check(geo.tagTop>h*.5&&geo.bottom<h,labels[k]+" safe layout bounds");
            int x=(int)(geo.x+130*u),y=(int)(geo.tickerTop+3*u),ww=(int)(geo.width-145*u),hh=(int)(49*u);
            check(difference(a,b,x,y,ww,hh)>50,labels[k]+" actual ticker pixels move");
            check(difference(a,b,0,0,w,(int)(h*.4))==0,labels[k]+" static identity does not move with ticker");
            check(p.drawn.stream().noneMatch(t->t.contains("PRIVATE COORDINATES")),labels[k]+" coordinates withheld");
            check(p.drawn.stream().anyMatch(t->t.equals("BREAKING NEWS")),labels[k]+" approved badge present");
            r.breakingApproved=false;Painter unapproved=new Painter(new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB));Duwm1728BroadcastLayout.draw(unapproved,w,h,r,0);
            check(unapproved.drawn.stream().noneMatch(t->t.equals("BREAKING NEWS")),labels[k]+" no unapproved breaking claim");
            r.breakingApproved=true;ImageIO.write(image(w,h,1000,true,r),"png",new File(folder,"broadcast-"+labels[k]+"-1000ms.png"));
            ImageIO.write(image(w,h,4000,true,r),"png",new File(folder,"broadcast-"+labels[k]+"-4000ms.png"));p.g.dispose();unapproved.g.dispose();
        }
        for(String ratio:new String[]{"9:10","9:16","16:9"})for(int[] source:new int[][]{{720,800},{1080,1920},{1920,1080},{2160,3840},{3840,2160}}){
            int[] out=Duwm1728BroadcastLayout.dimensions(source[0],source[1],ratio);String[] parts=ratio.split(":");int p=Integer.parseInt(parts[0]),q=Integer.parseInt(parts[1]);
            check(out[0]*q==out[1]*p,"exact ratio "+ratio);check((out[0]&1)==0&&(out[1]&1)==0,"even encoding dimensions");
            check(out[0]<=source[0]&&out[1]<=source[1],"no upscale");float[] crop=Duwm1728BroadcastLayout.crop(source[0],source[1],out[0],out[1]);
            check(crop[0]>=0&&crop[1]>=0&&crop[0]+crop[2]<=1.00001&&crop[1]+crop[3]<=1.00001,"crop stays in source");
            check(Math.abs(source[0]*crop[2]/(source[1]*crop[3])-out[0]/(float)out[1])<.0001,"crop not stretch");}
        Duwm1728BroadcastLayout.Report r=fixture();check(Duwm1728BroadcastLayout.active(r.tickers,2999).startMs==0,"old ticker before change");check(Duwm1728BroadcastLayout.active(r.tickers,3000).startMs==3000,"new ticker at actual cue");check(Duwm1728BroadcastLayout.active(r.captions,300)==null,"caption not prematurely shown");check(Duwm1728BroadcastLayout.active(r.captions,2700)==null,"caption ends at supplied time");
        boolean invalid=false;try{Duwm1728BroadcastLayout.dimensions(10,10,"bad");}catch(IllegalArgumentException e){invalid=true;}check(invalid,"invalid aspect rejected");
        System.out.println("PASS "+checks+" executed layout, pixels, motion, privacy, cue and aspect checks. NOT a phone or Android encoder test.");
    }
    public static void main(String[] args)throws Exception {
        if(args.length>0&&args[0].equals("video")){int w=Integer.parseInt(args[1]),h=Integer.parseInt(args[2]),frames=Integer.parseInt(args[3]);Duwm1728BroadcastLayout.Report r=fixture();
            try(BufferedOutputStream out=new BufferedOutputStream(System.out,1<<20)){for(int i=0;i<frames;i++)ImageIO.write(image(w,h,i*1000L/30,true,r),"png",out);}return;}
        tests(new File(args.length>0?args[0]:"broadcast-proof"));
    }
}
