package com.sentongoharuna.worldsituationroom;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Clean-master review: shared preview/export graphics, factual AI draft + explicit approval.
 * No cloud account is invented. Original recording remains unchanged. */
public final class Duwm1728VideoEditorActivity extends Activity implements TextureView.SurfaceTextureListener {
    public static final String EXTRA_VIDEO_URI="duwm.editor.video";
    private static final int NAVY=0xFF041424,WHITE=0xFFF5F7FA,SILVER=0xFFDEE5EF;
    private static final int CAPTION_DICTATION_REQUEST=17283,PIP_VIDEO_REQUEST=17284,SUBTITLE_SRT_REQUEST=17285;
    private Uri source,pipVideo;private MediaPlayer player;private Surface playbackSurface;
    private TextureView texture;private Duwm1728AspectFrame stage;private View broadcast;
    private EditText title,place,caption,from,to,ticker,subtitles;private CheckBox sourceSummary,preciseExport,recordedTrackToggle,approval;
    private TextView aiEvidenceView;private String aiEvidence="No AI analysis has been returned for this recording.";
    private TextView state,exportButton,ratioButton,templateButton,pipSelection,tickerPreview;
    private LinearLayout details;private SeekBar seek;private long durationMs;private int sourceW=1080,sourceH=1920;
    private String selectedRatio="9:16",reporter="",provenanceLabel="REPORTER ACCOUNT • UNVERIFIED";
    private final String[] templates={"GENERAL REPORT","BREAKING NEWS","WEATHER","TRAFFIC","INTERVIEW","ENVIRONMENT"};private int selectedTemplate,tickerSpeed=75;
    private boolean prepared,busy,aiBusy,active,destroyed,updatingFields;
    private Duwm1728OverlayRenderer.Spec previewSpec,exportSpec;
    private Duwm1728CaptureTelemetry.Snapshot provenance;
    private java.util.List<Duwm1728TelemetryTimeline.Point> recordedTrack=Collections.emptyList();
    private java.util.List<Duwm1728BroadcastLayout.Cue> aiCaptions=Collections.emptyList();
    private Duwm1728RecordedAudioTranscriber recordedAudioTranscriber;private Duwm1728AiProductionClient aiClient;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService insetWorker=Executors.newSingleThreadExecutor();private final AtomicBoolean insetBusy=new AtomicBoolean();
    private MediaMetadataRetriever insetRetriever;private Bitmap insetFrame;private long lastInsetAt=-1;private int insetGeneration;
    private final Runnable clock=new Runnable(){public void run(){if(!active||destroyed)return;long ms=position();
        if(prepared&&previewSpec!=null&&player.isPlaying()&&ms>=previewSpec.toMs){player.pause();player.seekTo((int)Math.min(Integer.MAX_VALUE,previewSpec.fromMs));}
        if(durationMs>0)seek.setProgress((int)Math.min(1000,ms*1000/durationMs));if(broadcast!=null)broadcast.invalidate();updateInset(ms);main.postDelayed(this,33);}};
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView label(String text,int size){TextView t=new TextView(this);t.setText(text);t.setTextColor(WHITE);t.setTextSize(size);t.setPadding(dp(10),dp(6),dp(10),dp(6));return t;}
    private TextView button(String text,Runnable action){TextView t=label(text,12);t.setGravity(Gravity.CENTER);t.setMinHeight(dp(44));GradientDrawable bg=new GradientDrawable();bg.setColor(0xFF081B2B);bg.setCornerRadius(dp(9));bg.setStroke(dp(1),SILVER);t.setBackground(bg);t.setOnClickListener(v->action.run());return t;}
    private EditText field(String hint,String value){EditText e=new EditText(this);e.setTextColor(WHITE);e.setHintTextColor(0xFFA0A5AE);e.setTextSize(14);e.setHint(hint);e.setText(value);e.setSingleLine(true);e.setMinHeight(dp(46));return e;}
    private LinearLayout.LayoutParams params(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(dp(5),dp(4),dp(5),dp(4));return p;}
    private CheckBox check(String label,boolean checked){CheckBox c=new CheckBox(this);c.setText(label);c.setTextColor(WHITE);c.setChecked(checked);return c;}
    private String extra(String name){String s=getIntent().getStringExtra(name);return s==null?"":s;}
    private long position(){try{return prepared?player.getCurrentPosition():0;}catch(IllegalStateException e){return 0;}}
    @Override public void onCreate(Bundle saved){super.onCreate(saved);getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(NAVY);
        String raw=extra(EXTRA_VIDEO_URI);if(raw.isEmpty()){finish();return;}source=Uri.parse(raw);reporter=extra("reporter");
        provenance=Duwm1728CaptureTelemetry.load(this,source);recordedTrack=Duwm1728TelemetryTimeline.load(this,source);
        MediaMetadataRetriever meta=new MediaMetadataRetriever();try{meta.setDataSource(this,source);sourceW=Integer.parseInt(meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));sourceH=Integer.parseInt(meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));durationMs=Long.parseLong(meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));String r=meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);int rotation=r==null?0:Integer.parseInt(r);if(rotation%180!=0){int t=sourceW;sourceW=sourceH;sourceH=t;}}
        catch(Exception e){notice("Cannot inspect source video: "+e.getMessage());finish();return;}finally{try{meta.release();}catch(Exception ignored){}}
        selectedRatio=extra("broadcast_ratio");if(selectedRatio.isEmpty())selectedRatio=sourceW>sourceH?"16:9":Math.abs(sourceW/(float)sourceH-.9f)<.02f?"9:10":"9:16";
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setBackgroundColor(NAVY);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.addView(label("BROADCAST REVIEW",16),new LinearLayout.LayoutParams(0,dp(44),1));top.addView(button("AI SETUP",this::aiSettings),new LinearLayout.LayoutParams(dp(100),dp(42)));page.addView(top);
        FrameLayout viewport=new FrameLayout(this);stage=new Duwm1728AspectFrame(this);viewport.addView(stage,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));texture=new TextureView(this);texture.setSurfaceTextureListener(this);stage.addView(texture,new FrameLayout.LayoutParams(-1,-1));
        broadcast=new View(this){@Override protected void onDraw(Canvas c){if(previewSpec!=null)Duwm1728OverlayRenderer.drawOverlay(c,previewSpec,Math.max(0,position()-previewSpec.fromMs),insetFrame);}};
        broadcast.setContentDescription("Broadcast graphics preview: same layout used for MP4 export");stage.addView(broadcast,new FrameLayout.LayoutParams(-1,-1));page.addView(viewport,new LinearLayout.LayoutParams(-1,0,1));
        seek=new SeekBar(this);seek.setMax(1000);seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int progress,boolean user){if(user&&prepared)player.seekTo((int)Math.min(Integer.MAX_VALUE,durationMs*progress/1000));}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});page.addView(seek,new LinearLayout.LayoutParams(-1,dp(26)));
        LinearLayout controls=new LinearLayout(this);controls.addView(button("PLAY / PAUSE",this::play),new LinearLayout.LayoutParams(0,dp(44),1));ratioButton=button(selectedRatio,this::chooseRatio);controls.addView(ratioButton,new LinearLayout.LayoutParams(0,dp(44),1));controls.addView(button("EDIT",this::showDetails),new LinearLayout.LayoutParams(0,dp(44),1));page.addView(controls);
        state=label(Duwm1728AiProductionClient.configured(this)?"AI ready to request • original preserved":"AI NOT CONNECTED • configure a server, or review a manual report",11);state.setTextColor(0xFFFBC02D);page.addView(state);
        approval=check("I reviewed the headline, ticker and captions",false);page.addView(approval,new LinearLayout.LayoutParams(-1,dp(42)));
        LinearLayout actions=new LinearLayout(this);actions.addView(button("AI PRODUCE",this::requestAi),new LinearLayout.LayoutParams(0,dp(50),1));exportButton=button("SAVE BROADCAST",this::export);actions.addView(exportButton,new LinearLayout.LayoutParams(0,dp(50),1));page.addView(actions);
        approval.setOnCheckedChangeListener((v,c)->updateExportState());
        details=new LinearLayout(this);details.setOrientation(LinearLayout.VERTICAL);details.setPadding(dp(12),dp(10),dp(12),dp(20));
        title=field("Factual headline — generated by AI or reviewed by you","");place=field("Location (optional)",extra("place"));caption=field("Report summary / notes",extra("notes"));caption.setSingleLine(false);caption.setMinLines(2);
        ticker=field("00:00=First update;00:15=Next update","");ticker.setSingleLine(false);ticker.setMinLines(2);subtitles=field("Timed captions or imported subtitles","");subtitles.setSingleLine(false);
        from=field("Start seconds","0");to=field("End seconds",String.format(Locale.US,"%.3f",durationMs/1000.0));from.setInputType(8194);to.setInputType(8194);
        for(EditText f:new EditText[]{title,place,caption,ticker,subtitles,from,to}){details.addView(f,params());f.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){if(!updatingFields){approval.setChecked(false);if(f==subtitles)aiCaptions=Collections.emptyList();refresh();}}public void afterTextChanged(android.text.Editable e){}});}
        templateButton=button("STYLE: GENERAL REPORT",()->new AlertDialog.Builder(this).setTitle("Report category (not a verification badge)").setItems(templates,(d,i)->{selectedTemplate=i;templateButton.setText("STYLE: "+templates[i]);approval.setChecked(false);refresh();}).show());details.addView(templateButton,params());
        details.addView(button("TICKER SPEED",()->new AlertDialog.Builder(this).setTitle("Ticker speed").setItems(new String[]{"Slow","Normal","Fast"},(d,i)->{tickerSpeed=new int[]{45,75,115}[i];refresh();}).show()),params());
        sourceSummary=check("Include available captured sensor information",provenance!=null);sourceSummary.setEnabled(provenance!=null);recordedTrackToggle=check("Use recorded time-aligned samples",!recordedTrack.isEmpty());recordedTrackToggle.setEnabled(!recordedTrack.isEmpty());preciseExport=check("Disclose exact recorded GPS in this broadcast",false);preciseExport.setEnabled(provenance!=null&&provenance.preciseEnabled);
        for(CheckBox c:new CheckBox[]{sourceSummary,recordedTrackToggle,preciseExport}){details.addView(c,params());c.setOnCheckedChangeListener((v,on)->{approval.setChecked(false);refresh();});}
        details.addView(button("TRANSCRIBE RECORDED AUDIO ON DEVICE",this::transcribeRecordedAudio),params());details.addView(button("IMPORT SRT SUBTITLES",this::chooseSubtitleFile),params());details.addView(button("DICTATE A CAPTION (MICROPHONE)",this::dictateCaption),params());
        pipSelection=label("PICTURE-IN-PICTURE OFF",11);details.addView(pipSelection,params());details.addView(button("SELECT SECOND VIDEO",this::choosePipVideo),params());details.addView(button("REMOVE SECOND VIDEO",()->{pipVideo=null;loadInset(null);pipSelection.setText("PICTURE-IN-PICTURE OFF");refresh();}),params());
        aiEvidenceView=label(aiEvidence,11);details.addView(aiEvidenceView,params());
        details.addView(label("AI proposals are not independent verification. Precise GPS is separate and opt-in. Existing labels already inside older MP4s cannot be removed.",11),params());
        setContentView(page);loadDraft();refresh();
        if(getIntent().getBooleanExtra("clean_master",false)&&title.getText().toString().trim().isEmpty()&&
           getSharedPreferences(Duwm1728AiProductionClient.PREFS,MODE_PRIVATE).getBoolean("auto_after_capture",false)&&Duwm1728AiProductionClient.configured(this)){
            main.post(()->{if(!destroyed&&!aiBusy)try{startAi(spec());}catch(Exception e){state.setText("AI request could not start: "+e.getMessage());}});
        }
    }
    private void play(){if(!prepared)return;try{if(player.isPlaying())player.pause();else{if(previewSpec!=null&&(position()<previewSpec.fromMs||position()>=previewSpec.toMs))player.seekTo((int)previewSpec.fromMs);player.start();}}catch(Exception e){notice("Playback unavailable");}}
    private void chooseRatio(){if(busy)return;new AlertDialog.Builder(this).setTitle("Final encoded aspect ratio — centre crop, no stretching").setItems(new String[]{"9:10","9:16","16:9","ORIGINAL"},(d,i)->{selectedRatio=new String[]{"9:10","9:16","16:9","ORIGINAL"}[i];ratioButton.setText(selectedRatio);approval.setChecked(false);refresh();}).show();}
    private void showDetails(){if(busy){notice("Export is running");return;}if(details.getParent() instanceof android.view.ViewGroup)((android.view.ViewGroup)details.getParent()).removeView(details);ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(NAVY);scroll.addView(details);new AlertDialog.Builder(this).setTitle("Report details").setView(scroll).setPositiveButton("DONE",(d,w)->refresh()).show();}
    private long ms(EditText e){double seconds=Double.parseDouble(e.getText().toString().trim());if((Double.isNaN(seconds)||Double.isInfinite(seconds))||seconds<0||seconds>Integer.MAX_VALUE/1000d)throw new IllegalArgumentException("Invalid time");return Math.round(seconds*1000);}
    private Duwm1728OverlayRenderer.Spec spec(){Duwm1728OverlayRenderer.Spec s=new Duwm1728OverlayRenderer.Spec();s.fromMs=ms(from);s.toMs=ms(to);if(s.toMs>durationMs||s.toMs<=s.fromMs)throw new IllegalArgumentException("Trim range exceeds the recording");s.title=title.getText().toString();s.place=place.getText().toString();s.description=caption.getText().toString();s.reporter=reporter;s.template=templates[selectedTemplate];s.breakingApproved=selectedTemplate==1;s.ratio=selectedRatio;s.ticker=ticker.getText().toString();s.tickerSpeed=tickerSpeed;s.captions=subtitles.getText().toString();s.pipVideo=pipVideo;s.provenance=provenanceLabel;
        s.tickerCues=Duwm1728TickerTimeline.parse(s.ticker);s.captionCues=Duwm1728TickerTimeline.parse(s.captions);s.automaticCaptions=new ArrayList<>(aiCaptions);s.capturedTelemetry=provenance;s.recordedTrack=recordedTrackToggle.isChecked()?recordedTrack:Collections.emptyList();s.includeSourceSummary=sourceSummary.isChecked()&&provenance!=null;s.includeCoordinates=preciseExport.isChecked();return s;}
    private void refresh(){if(title==null||recordedTrackToggle==null)return;try{previewSpec=spec();int[] d=Duwm1728BroadcastLayout.dimensions(sourceW,sourceH,selectedRatio);stage.setRatio(d[0]/(float)d[1]);texture.post(this::previewCrop);broadcast.invalidate();}catch(Exception e){if(state!=null)state.setText("Check report: "+e.getMessage());}updateExportState();}
    private void updateExportState(){if(exportButton!=null){boolean ok=!busy&&!aiBusy&&approval.isChecked()&&title!=null&&!title.getText().toString().trim().isEmpty();exportButton.setEnabled(ok);exportButton.setAlpha(ok?1f:.5f);}}
    private void previewCrop(){int w=texture.getWidth(),h=texture.getHeight();if(w<1||h<1)return;float scale=Math.max(w/(float)sourceW,h/(float)sourceH);Matrix m=new Matrix();m.setScale(sourceW*scale/w,sourceH*scale/h,w/2f,h/2f);texture.setTransform(m);}
    @Override public void onSurfaceTextureAvailable(SurfaceTexture s,int w,int h){try{releasePlayer();playbackSurface=new Surface(s);player=new MediaPlayer();player.setDataSource(this,source);player.setSurface(playbackSurface);player.setOnPreparedListener(p->{prepared=true;previewCrop();if(previewSpec!=null)p.seekTo((int)previewSpec.fromMs);});player.setOnErrorListener((p,what,extra)->{prepared=false;notice("Source video cannot be played");return true;});player.prepareAsync();}catch(Exception e){notice("Cannot open video: "+e.getMessage());}}
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture s,int w,int h){previewCrop();}
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture s){releasePlayer();return true;}
    @Override public void onSurfaceTextureUpdated(SurfaceTexture s){}
    private void releasePlayer(){prepared=false;if(player!=null){try{player.release();}catch(Exception ignored){}player=null;}if(playbackSurface!=null){playbackSurface.release();playbackSurface=null;}}
    private void loadInset(Uri uri){int generation=++insetGeneration;insetWorker.execute(()->{if(insetRetriever!=null){try{insetRetriever.release();}catch(Exception ignored){}insetRetriever=null;}if(uri!=null)try{MediaMetadataRetriever r=new MediaMetadataRetriever();r.setDataSource(getApplicationContext(),uri);insetRetriever=r;}catch(Exception e){main.post(()->notice("Inset unavailable"));}
        main.post(()->{if(generation!=insetGeneration)return;if(insetFrame!=null)insetFrame.recycle();insetFrame=null;lastInsetAt=-1;});});}
    private void updateInset(long ms){if(pipVideo==null||(lastInsetAt>=0&&ms>=lastInsetAt&&ms-lastInsetAt<160)||!insetBusy.compareAndSet(false,true))return;lastInsetAt=ms;int generation=insetGeneration;long start=previewSpec==null?0:previewSpec.fromMs;
        insetWorker.execute(()->{Bitmap frame=null;try{if(insetRetriever!=null){long t=Math.max(0,ms-start)*1000;String d=insetRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);if(d!=null)t=Math.min(t,Math.max(0,Long.parseLong(d)*1000-1));frame=Build.VERSION.SDK_INT>=27?insetRetriever.getScaledFrameAtTime(t,MediaMetadataRetriever.OPTION_CLOSEST,480,480):insetRetriever.getFrameAtTime(t,MediaMetadataRetriever.OPTION_CLOSEST);}}catch(Exception ignored){}
            final Bitmap result=frame;main.post(()->{insetBusy.set(false);if(destroyed||generation!=insetGeneration){if(result!=null)result.recycle();return;}Bitmap prior=insetFrame;insetFrame=result;if(prior!=null&&prior!=result)prior.recycle();});});}
    private void aiSettings(){
        if(busy||aiBusy)return;LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(16),0,dp(16),0);
        EditText url=field("Your authenticated HTTPS AI server",getSharedPreferences(Duwm1728AiProductionClient.PREFS,MODE_PRIVATE).getString("endpoint",""));
        EditText token=field("Server-issued device token (not a provider API key)","");token.setInputType(129);
        CheckBox automatic=check("Automatically prepare a draft after each new recording",getSharedPreferences(Duwm1728AiProductionClient.PREFS,MODE_PRIVATE).getBoolean("auto_after_capture",false));
        box.addView(url);box.addView(token);box.addView(automatic);box.addView(label("Enabling automatic production authorises sending each newly recorded original video and audio to this server and its AI provider. Video can reveal people or locations. Exact GPS sidecars are NOT sent. You still review before saving or publishing. Disable this option at any time.",12));
        new AlertDialog.Builder(this).setTitle("Connect AI production").setView(box)
          .setNegativeButton("CANCEL",null).setPositiveButton("SAVE CONSENT & CONNECTION",(d,w)->{
              try{String value=token.getText().toString();if(value.isEmpty())value=Duwm1728AiProductionClient.token(this);
                  Duwm1728AiProductionClient.configure(this,url.getText().toString(),value);
                  getSharedPreferences(Duwm1728AiProductionClient.PREFS,MODE_PRIVATE).edit().putBoolean("auto_after_capture",automatic.isChecked()).apply();
                  state.setText(automatic.isChecked()?"AI CONFIGURED • automatic draft after capture (consent saved)":"AI CONFIGURED • request analysis to test the service");}
              catch(Exception e){notice(e.getMessage());}}).show();
    }
    private void requestAi(){if(aiBusy||busy)return;if(!Duwm1728AiProductionClient.configured(this)){aiSettings();return;}Duwm1728OverlayRenderer.Spec selected;try{selected=spec();}catch(Exception e){notice(e.getMessage());return;}
        new AlertDialog.Builder(this).setTitle("Send this recording for AI production?").setMessage("The original video, audio, and metadata already embedded in that file will be uploaded to your configured server. Its provider analyses sampled frames and transcribes speech. DUWM does not add your precise-GPS sidecar to the request. Review the result before export or publication.").setNegativeButton("CANCEL",null).setPositiveButton("ANALYSE",(d,w)->beginAi(selected)).show();}
    private void beginAi(Duwm1728OverlayRenderer.Spec selected){aiBusy=true;approval.setChecked(false);updateExportState();state.setText("AI ANALYSIS IN PROGRESS • no report approved");state.setTextColor(0xFF00ACC1);aiClient=new Duwm1728AiProductionClient(this);
        new Thread(()->{try{JSONObject result=aiClient.produce(source,selected.fromMs,selected.toMs,selected.description);main.post(()->{if(destroyed)return;try{applyAi(result,selected.fromMs);state.setText("AI DRAFT READY • review headline, ticker and subtitles");state.setTextColor(0xFFFBC02D);}catch(Exception e){state.setText("AI response rejected: "+e.getMessage());}finally{aiBusy=false;updateExportState();}});}catch(Exception e){main.post(()->{if(destroyed)return;aiBusy=false;state.setText("AI UNAVAILABLE • "+e.getMessage());state.setTextColor(0xFFD50000);updateExportState();});}},"duwm-ai-produce").start();}
    private void applyAi(JSONObject report,long clipStart)throws Exception{
        updatingFields=true;try{title.setText(report.getString("headline"));caption.setText(report.optString("description"));String category=report.optString("category","FIELD REPORT");selectedTemplate=0;for(int i=0;i<templates.length;i++)if(i!=1&&templates[i].equals(category))selectedTemplate=i;templateButton.setText("STYLE: "+templates[selectedTemplate]);
            JSONArray updates=report.optJSONArray("ticker");java.util.Set<Long> secondsSeen=new java.util.HashSet<>();StringBuilder text=new StringBuilder();if(updates!=null)for(int i=0;i<Math.min(12,updates.length());i++){JSONObject item=updates.getJSONObject(i);long sec=item.getLong("at_ms")/1000;if(sec<0||sec*1000>=durationMs-clipStart||!secondsSeen.add(sec))continue;if(text.length()>0)text.append(';');text.append(String.format(Locale.US,"%02d:%02d=",sec/60,sec%60)).append(item.getString("text").replace(';',',').replace('=','-'));}ticker.setText(text);
            ArrayList<Duwm1728BroadcastLayout.Cue> cues=new ArrayList<>();JSONArray captions=report.optJSONArray("captions");if(captions!=null)for(int i=0;i<captions.length();i++){JSONObject c=captions.getJSONObject(i);long start=c.getLong("start_ms"),end=c.getLong("end_ms");if(start>=0&&end>start&&end<=durationMs)cues.add(new Duwm1728BroadcastLayout.Cue(start,end,c.getString("text")));}aiCaptions=cues;subtitles.setText("");provenanceLabel="AI-ASSISTED • REVIEW REQUIRED";
            StringBuilder evidence=new StringBuilder("AI model: "+report.optString("ai_model","unspecified")+"\nVisual analysis uses sampled frames, not every frame.\nUncertainties: ");
            JSONArray warnings=report.optJSONArray("uncertainties");if(warnings!=null)for(int i=0;i<warnings.length();i++)evidence.append("\n• ").append(warnings.optString(i));
            aiEvidence=evidence.toString();aiEvidenceView.setText(aiEvidence);
            getSharedPreferences("duwm_production_drafts",MODE_PRIVATE).edit().putString("ai_"+Duwm1728CaptureTelemetry.storageKey(source),report.toString()).apply();
        }finally{updatingFields=false;}approval.setChecked(false);refresh();showDetails();
    }
    private void export(){if(busy||aiBusy||!approval.isChecked())return;final Duwm1728OverlayRenderer.Spec selected;
        try{selected=spec();if(provenanceLabel.startsWith("AI-"))selected.provenance="AI-ASSISTED • REPORTER REVIEWED";Duwm1728OverlayRenderer.prepare(selected);}catch(Exception e){notice("Correct report: "+e.getMessage());return;}
        if(prepared)player.pause();busy=true;exportSpec=selected;updateExportState();state.setText("RENDERING BROADCAST • original unchanged");state.setTextColor(0xFF00ACC1);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        selected.progress=p->main.post(()->{if(!destroyed)state.setText("RENDERING BROADCAST "+p+"% • original unchanged");});
        final Context app=getApplicationContext();new Thread(()->{File produced=null;try{produced=Duwm1728OverlayRenderer.export(app,source,selected);if(selected.cancelled.get())throw new InterruptedException("Export cancelled");String name="DUWM_BROADCAST_"+System.currentTimeMillis()+".mp4";Uri out=Duwm1724GalleryPublisher.publish(app,produced,name);Duwm1726GalleryIndex.add(app,out,name);
            main.post(()->{if(destroyed)return;busy=false;getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);state.setText("BROADCAST SAVED TO GALLERY • play to verify output");state.setTextColor(0xFF00C853);updateExportState();new AlertDialog.Builder(this).setTitle("Broadcast saved separately").setMessage("Your clean master is unchanged. The new MP4 contains the rendered broadcast graphics. Play it to check the actual phone output.").setNegativeButton("CLOSE",null).setPositiveButton("PLAY",(d,w)->{try{startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(out,"video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));}catch(Exception e){notice("No video player available");}}).show();});
        }catch(Exception e){main.post(()->{if(destroyed)return;busy=false;getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);state.setText("EXPORT FAILED • "+e.getMessage());state.setTextColor(0xFFD50000);updateExportState();});}finally{if(produced!=null)produced.delete();}},"duwm-broadcast-export").start();
    }
    private void saveDraft(){if(title==null)return;try{JSONObject j=new JSONObject();j.put("headline",title.getText());j.put("place",place.getText());j.put("summary",caption.getText());j.put("ticker",ticker.getText());j.put("subtitles",subtitles.getText());j.put("ratio",selectedRatio);j.put("category",selectedTemplate);j.put("from",from.getText());j.put("to",to.getText());
            j.put("provenance",provenanceLabel);j.put("aiEvidence",aiEvidence);j.put("tickerSpeed",tickerSpeed);
            JSONArray cues=new JSONArray();for(Duwm1728BroadcastLayout.Cue c:aiCaptions){JSONObject cue=new JSONObject();cue.put("start_ms",c.startMs);cue.put("end_ms",c.endMs);cue.put("text",c.text);cues.put(cue);}j.put("automatic_captions",cues);getSharedPreferences("duwm_production_drafts",MODE_PRIVATE).edit().putString(Duwm1728CaptureTelemetry.storageKey(source),j.toString()).apply();}catch(Exception ignored){}}
    private void loadDraft(){
        try{
            String raw=getSharedPreferences("duwm_production_drafts",MODE_PRIVATE).getString(Duwm1728CaptureTelemetry.storageKey(source),"");
            if(raw.isEmpty())return;JSONObject j=new JSONObject(raw);updatingFields=true;
            title.setText(j.optString("headline"));place.setText(j.optString("place"));caption.setText(j.optString("summary"));ticker.setText(j.optString("ticker"));subtitles.setText(j.optString("subtitles"));
            String ratio=j.optString("ratio",selectedRatio);if(Arrays.asList("9:10","9:16","16:9","ORIGINAL").contains(ratio))selectedRatio=ratio;
            selectedTemplate=Math.max(0,Math.min(templates.length-1,j.optInt("category")));from.setText(j.optString("from","0"));to.setText(j.optString("to",to.getText().toString()));
            tickerSpeed=Math.max(20,Math.min(180,j.optInt("tickerSpeed",75)));
            provenanceLabel=j.optString("provenance","REPORTER ACCOUNT • UNVERIFIED");aiEvidence=j.optString("aiEvidence",aiEvidence);aiEvidenceView.setText(aiEvidence);
            JSONArray captions=j.optJSONArray("automatic_captions");ArrayList<Duwm1728BroadcastLayout.Cue> restored=new ArrayList<>();
            if(captions!=null)for(int i=0;i<Math.min(20000,captions.length());i++){JSONObject c=captions.getJSONObject(i);long start=c.getLong("start_ms"),end=c.getLong("end_ms");if(start>=0&&end>start&&end<=durationMs)restored.add(new Duwm1728BroadcastLayout.Cue(start,end,c.getString("text")));}aiCaptions=restored;
            templateButton.setText("STYLE: "+templates[selectedTemplate]);ratioButton.setText(selectedRatio);
            // Approval is deliberately not persisted. Reopened drafts require a fresh review.
            approval.setChecked(false);
        }catch(Exception e){notice("Some saved draft fields could not be restored");}finally{updatingFields=false;}
    }
    private void dictateCaption(){
        if(busy){notice("Cannot dictate while exporting");return;}
        try{
            Intent intent=new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT,"Speak a caption for manual review");
            startActivityForResult(intent,CAPTION_DICTATION_REQUEST);
        }catch(android.content.ActivityNotFoundException e){notice("No speech recognition app on this phone");}
    }
    private void transcribeRecordedAudio(){
        if(busy || recordedAudioTranscriber!=null){notice("Editor is busy");return;}
        if(!Duwm1728RecordedAudioTranscriber.canAttempt(this)){
            notice("This device has no compatible on-device recorded-audio recognizer. Import SRT captions instead.");return;
        }
        long fromMs,toMs;
        try{fromMs=ms(from);
            toMs=ms(to);
            if(fromMs<0||toMs<=fromMs||toMs-fromMs>45000)throw new IllegalArgumentException();
        }catch(Exception ex){notice("On-device recognition accepts up to 45 seconds per request. Export itself has no 45-second cap.");return;}
        new AlertDialog.Builder(this).setTitle("Transcribe the actual video soundtrack?")
            .setMessage("Uses the phone's on-device recognition service and decoded recorded audio. Some devices do not support audio injection or word timestamps. Never accept subtitles without reviewing them. No camera microphone fallback is requested by DUWM.")
            .setNegativeButton("CANCEL",null).setPositiveButton("START",(d,w)->{
                recordedAudioTranscriber=new Duwm1728RecordedAudioTranscriber(this);
                notice("Attempting on-device recorded-audio recognition");
                recordedAudioTranscriber.transcribe(source,fromMs,toMs,new Duwm1728RecordedAudioTranscriber.Listener(){
                    @Override public void error(String message){recordedAudioTranscriber=null;notice(message);}
                    @Override public void done(Duwm1728RecordedAudioTranscriber.Result result){
                        recordedAudioTranscriber=null;
                        final EditText review=field("Review transcription / time codes",result.hasVerifiedWordTimes?result.timedCaptions:result.text);
                        review.setSingleLine(false);review.setMinLines(3);
                        String explanation=result.hasVerifiedWordTimes
                            ?"Word timestamps reported by the recognizer; grouped into timed subtitle cues. Verify every word and its timing."
                            :"The recognizer did NOT return reliable word timestamps. Transcript text only: use manual caption times or import SRT.";
                        new AlertDialog.Builder(Duwm1728VideoEditorActivity.this)
                            .setTitle("Review recorded-audio transcript")
                            .setMessage(explanation).setView(review).setNegativeButton("DISCARD",null)
                            .setPositiveButton(result.hasVerifiedWordTimes?"IMPORT TIMED CAPTIONS":"COPY TEXT",(dialog,which)->{
                                if(result.hasVerifiedWordTimes){try{String checked=review.getText().toString().trim();
                                    Duwm1728TickerTimeline.parse(checked);subtitles.setText(checked);
                                }catch(IllegalArgumentException ex){notice("Correct subtitle time codes: "+ex.getMessage());}}
                                if(!result.hasVerifiedWordTimes){android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
                                    cm.setPrimaryClip(android.content.ClipData.newPlainText("DUWM transcript for manual timing",review.getText().toString()));}
                            }).show();
                    }
                });
            }).show();
    }
    private void choosePipVideo(){
        Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("video/*");
        startActivityForResult(pick,PIP_VIDEO_REQUEST);
    }
    private void chooseSubtitleFile(){
        Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
        pick.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/plain","application/x-subrip","application/octet-stream"});
        startActivityForResult(pick,SUBTITLE_SRT_REQUEST);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null)return;
        if(request==PIP_VIDEO_REQUEST){
            Uri selected=data.getData();if(selected==null)return;
            try{getContentResolver().takePersistableUriPermission(selected,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(SecurityException ignored){}
            if(selected.equals(source)){notice("Choose a different video for the inset");return;}
            pipVideo=selected;loadInset(selected);pipSelection.setText("SECOND VIDEO SELECTED / MUTED");refresh();return;
        }
        if(request==SUBTITLE_SRT_REQUEST){
            Uri selected=data.getData();if(selected==null)return;
            try(java.io.InputStream in=getContentResolver().openInputStream(selected)){
                if(in==null)throw new IllegalArgumentException("File unavailable");
                byte[] bytes=new byte[65537];int offset=0,read;
                while(offset<bytes.length && (read=in.read(bytes,offset,bytes.length-offset))>0)offset+=read;
                if(offset>65536)throw new IllegalArgumentException("Subtitle file exceeds 64 KiB");
                String text=new String(bytes,0,offset,java.nio.charset.StandardCharsets.UTF_8);
                String cues=Duwm1728SubtitleImport.convertSrt(text);
                new AlertDialog.Builder(this).setTitle("Review imported time codes")
                    .setMessage("This imports manually time-coded subtitles. It does not transcribe original audio. Review and edit the text before export.")
                    .setNegativeButton("DISCARD",null).setPositiveButton("IMPORT",(d,w)->subtitles.setText(cues)).show();
            }catch(Exception ex){notice("Subtitle import failed: "+ex.getMessage());}return;
        }
        if(request!=CAPTION_DICTATION_REQUEST)return;
        java.util.ArrayList<String> phrases=data.getStringArrayListExtra(
            android.speech.RecognizerIntent.EXTRA_RESULTS);
        if(phrases==null||phrases.isEmpty())return;
        String guess=phrases.get(0).replaceAll("[\\r\\n;=]+"," ").trim();
        if(guess.length()>180)guess=guess.substring(0,180);
        long now=!prepared?0:Math.max(0,player.getCurrentPosition());
        long start=0;try{start=ms(from);}catch(Exception ignored){}
        long clipMs=Math.max(0,now-start);String cue=String.format(java.util.Locale.US,
            "%02d:%02d=%s",clipMs/60000,(clipMs/1000)%60,guess);
        final String candidate=(subtitles.getText().toString().trim().isEmpty()?"":
            subtitles.getText().toString().trim()+";")+cue;
        new AlertDialog.Builder(this).setTitle("Review dictated words")
          .setMessage("Recognized microphone speech, NOT source-video transcription:\n\n"+guess+
              "\n\nAt video time "+(clipMs/1000)+" seconds. Edit the resulting caption if needed.")
          .setNegativeButton("DISCARD",null).setPositiveButton("ADD CAPTION",(d,w)->subtitles.setText(candidate)).show();
    }

    private void notice(String text){Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
    @Override public void onBackPressed(){if(busy||aiBusy){new AlertDialog.Builder(this).setTitle("Cancel production?").setMessage("The original recording remains intact.").setNegativeButton("KEEP WORKING",null).setPositiveButton("CANCEL",(d,w)->{if(exportSpec!=null)exportSpec.cancelled.set(true);if(aiClient!=null)aiClient.cancel();finish();}).show();}else super.onBackPressed();}
    @Override protected void onResume(){super.onResume();active=true;main.removeCallbacks(clock);main.post(clock);}
    @Override protected void onPause(){active=false;main.removeCallbacks(clock);saveDraft();if(prepared)try{player.pause();}catch(Exception ignored){}super.onPause();}
    @Override protected void onDestroy(){destroyed=true;main.removeCallbacks(clock);if(exportSpec!=null)exportSpec.cancelled.set(true);if(aiClient!=null)aiClient.cancel();if(recordedAudioTranscriber!=null)recordedAudioTranscriber.close();releasePlayer();insetGeneration++;insetWorker.execute(()->{if(insetRetriever!=null)try{insetRetriever.release();}catch(Exception ignored){}});insetWorker.shutdown();if(insetFrame!=null)insetFrame.recycle();super.onDestroy();}
}
