package com.sentongoharuna.worldsituationroom;
import android.graphics.Bitmap;
import android.graphics.SurfaceTexture;
import android.opengl.*;
import android.os.*;
import android.view.Surface;
import java.nio.*;
/** GPU decoder-to-encoder transport. No JPEG conversion and no Canvas.lockCanvas on codec input. */
final class Duwm1728EglVideoPipe implements AutoCloseable {
    private EGLDisplay display=EGL14.EGL_NO_DISPLAY;private EGLContext context=EGL14.EGL_NO_CONTEXT;private EGLSurface target=EGL14.EGL_NO_SURFACE;
    private SurfaceTexture texture;private Surface decoderSurface;private HandlerThread callbacks;
    private final Object frameLock=new Object();private boolean pending,closed,allocated;
    private int oes,rgba,videoProgram,overlayProgram;private final int width,height,rotation;
    private final float[] matrix=new float[16],crop;
    private final FloatBuffer vertices=ByteBuffer.allocateDirect(64).order(ByteOrder.nativeOrder()).asFloatBuffer();
    Duwm1728EglVideoPipe(Surface input,int w,int h,int sourceW,int sourceH,int degrees){
        width=w;height=h;rotation=((degrees%360)+360)%360;crop=Duwm1728BroadcastLayout.crop(rotation%180==0?sourceW:sourceH,rotation%180==0?sourceH:sourceW,w,h);
        vertices.put(new float[]{-1,-1,0,0,1,-1,1,0,-1,1,0,1,1,1,1,1}).position(0);
        try{
            display=EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);int[] version=new int[2];
            if(display==EGL14.EGL_NO_DISPLAY||!EGL14.eglInitialize(display,version,0,version,1))throw new IllegalStateException("EGL display unavailable");
            EGLConfig[] configs=new EGLConfig[1];int[] count=new int[1];int[] attrs={EGL14.EGL_RED_SIZE,8,EGL14.EGL_GREEN_SIZE,8,EGL14.EGL_BLUE_SIZE,8,EGL14.EGL_ALPHA_SIZE,8,EGL14.EGL_RENDERABLE_TYPE,EGL14.EGL_OPENGL_ES2_BIT,0x3142,1,EGL14.EGL_NONE};
            if(!EGL14.eglChooseConfig(display,attrs,0,configs,0,1,count,0)||count[0]<1)throw new IllegalStateException("No recordable EGL configuration");
            context=EGL14.eglCreateContext(display,configs[0],EGL14.EGL_NO_CONTEXT,new int[]{EGL14.EGL_CONTEXT_CLIENT_VERSION,2,EGL14.EGL_NONE},0);
            target=EGL14.eglCreateWindowSurface(display,configs[0],input,new int[]{EGL14.EGL_NONE},0);
            if(context==EGL14.EGL_NO_CONTEXT||target==EGL14.EGL_NO_SURFACE||!EGL14.eglMakeCurrent(display,target,target,context))throw new IllegalStateException("EGL encoder surface unavailable");
            videoProgram=program("#extension GL_OES_EGL_image_external : require\nprecision mediump float;varying vec2 uv;uniform samplerExternalOES image;uniform mat4 st;uniform vec4 crop;uniform int rotation;void main(){vec2 t=crop.xy+uv*crop.zw;if(rotation==90)t=vec2(1.0-t.y,t.x);else if(rotation==180)t=vec2(1.0-t.x,1.0-t.y);else if(rotation==270)t=vec2(t.y,1.0-t.x);gl_FragColor=texture2D(image,(st*vec4(t,0.,1.)).xy);}");
            overlayProgram=program("precision mediump float;varying vec2 uv;uniform sampler2D image;void main(){gl_FragColor=texture2D(image,vec2(uv.x,1.0-uv.y));}");
            oes=newTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES);rgba=newTexture(GLES20.GL_TEXTURE_2D);
            texture=new SurfaceTexture(oes);decoderSurface=new Surface(texture);callbacks=new HandlerThread("duwm-codec-frames");callbacks.start();
            texture.setOnFrameAvailableListener(t->{synchronized(frameLock){pending=true;frameLock.notifyAll();}},new Handler(callbacks.getLooper()));
        }catch(RuntimeException e){close();throw e;}
    }
    Surface surface(){return decoderSurface;}
    private static int shader(int type,String source){int s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,source);GLES20.glCompileShader(s);int[] ok={0};GLES20.glGetShaderiv(s,GLES20.GL_COMPILE_STATUS,ok,0);if(ok[0]==0){String msg=GLES20.glGetShaderInfoLog(s);GLES20.glDeleteShader(s);throw new IllegalStateException(msg);}return s;}
    private static int program(String fragment){int vs=shader(GLES20.GL_VERTEX_SHADER,"attribute vec2 position;attribute vec2 coordinate;varying vec2 uv;void main(){gl_Position=vec4(position,0.,1.);uv=coordinate;}"),fs=shader(GLES20.GL_FRAGMENT_SHADER,fragment);int p=GLES20.glCreateProgram();GLES20.glAttachShader(p,vs);GLES20.glAttachShader(p,fs);GLES20.glLinkProgram(p);GLES20.glDeleteShader(vs);GLES20.glDeleteShader(fs);int[] ok={0};GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,ok,0);if(ok[0]==0)throw new IllegalStateException(GLES20.glGetProgramInfoLog(p));return p;}
    private static int newTexture(int target){int[] t=new int[1];GLES20.glGenTextures(1,t,0);GLES20.glBindTexture(target,t[0]);GLES20.glTexParameteri(target,GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_LINEAR);GLES20.glTexParameteri(target,GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_LINEAR);GLES20.glTexParameteri(target,GLES20.GL_TEXTURE_WRAP_S,GLES20.GL_CLAMP_TO_EDGE);GLES20.glTexParameteri(target,GLES20.GL_TEXTURE_WRAP_T,GLES20.GL_CLAMP_TO_EDGE);return t[0];}
    void awaitFrame() throws InterruptedException {long deadline=SystemClock.elapsedRealtime()+10000;
        synchronized(frameLock){while(!pending&&!closed){long wait=deadline-SystemClock.elapsedRealtime();if(wait<=0)throw new IllegalStateException("Decoder frame timeout");frameLock.wait(wait);}if(closed)throw new IllegalStateException("Export closed");pending=false;}
        texture.updateTexImage();texture.getTransformMatrix(matrix);
    }
    private void draw(int program,int targetType,int id){GLES20.glUseProgram(program);int p=GLES20.glGetAttribLocation(program,"position"),t=GLES20.glGetAttribLocation(program,"coordinate");
        vertices.position(0);GLES20.glVertexAttribPointer(p,2,GLES20.GL_FLOAT,false,16,vertices);GLES20.glEnableVertexAttribArray(p);vertices.position(2);GLES20.glVertexAttribPointer(t,2,GLES20.GL_FLOAT,false,16,vertices);GLES20.glEnableVertexAttribArray(t);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);GLES20.glBindTexture(targetType,id);GLES20.glUniform1i(GLES20.glGetUniformLocation(program,"image"),0);
        if(program==videoProgram){GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(program,"st"),1,false,matrix,0);GLES20.glUniform4fv(GLES20.glGetUniformLocation(program,"crop"),1,crop,0);GLES20.glUniform1i(GLES20.glGetUniformLocation(program,"rotation"),rotation);}
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4);GLES20.glDisableVertexAttribArray(p);GLES20.glDisableVertexAttribArray(t);
    }
    void submit(Bitmap graphics,long ptsUs){GLES20.glViewport(0,0,width,height);GLES20.glDisable(GLES20.GL_BLEND);GLES20.glClearColor(0,0,0,1);GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        draw(videoProgram,GLES11Ext.GL_TEXTURE_EXTERNAL_OES,oes);GLES20.glBindTexture(GLES20.GL_TEXTURE_2D,rgba);
        if(!allocated){GLUtils.texImage2D(GLES20.GL_TEXTURE_2D,0,graphics,0);allocated=true;}else GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D,0,0,0,graphics);
        GLES20.glEnable(GLES20.GL_BLEND);GLES20.glBlendFunc(GLES20.GL_ONE,GLES20.GL_ONE_MINUS_SRC_ALPHA);draw(overlayProgram,GLES20.GL_TEXTURE_2D,rgba);GLES20.glDisable(GLES20.GL_BLEND);
        int error=GLES20.glGetError();if(error!=GLES20.GL_NO_ERROR)throw new IllegalStateException("GL error "+error);
        if(!EGLExt.eglPresentationTimeANDROID(display,target,ptsUs*1000L)||!EGL14.eglSwapBuffers(display,target))throw new IllegalStateException("Frame submission failed");
    }
    public void close(){synchronized(frameLock){closed=true;frameLock.notifyAll();}if(decoderSurface!=null){decoderSurface.release();decoderSurface=null;}if(texture!=null){texture.release();texture=null;}if(callbacks!=null){callbacks.quitSafely();callbacks=null;}
        if(display!=EGL14.EGL_NO_DISPLAY){EGL14.eglMakeCurrent(display,EGL14.EGL_NO_SURFACE,EGL14.EGL_NO_SURFACE,EGL14.EGL_NO_CONTEXT);if(target!=EGL14.EGL_NO_SURFACE)EGL14.eglDestroySurface(display,target);if(context!=EGL14.EGL_NO_CONTEXT)EGL14.eglDestroyContext(display,context);EGL14.eglReleaseThread();EGL14.eglTerminate(display);display=EGL14.EGL_NO_DISPLAY;}}
}
