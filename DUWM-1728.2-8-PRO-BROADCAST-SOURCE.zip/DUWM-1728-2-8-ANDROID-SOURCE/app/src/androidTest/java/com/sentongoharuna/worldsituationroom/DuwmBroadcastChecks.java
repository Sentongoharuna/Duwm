package com.sentongoharuna.worldsituationroom;
import android.app.Instrumentation;
import android.content.Context;
import android.graphics.*;
import android.media.*;
import android.net.Uri;
import java.io.*;
import java.util.*;

/** Actual Android Canvas + EGL/codec export tests. Never part of the production APK. */
final class DuwmBroadcastChecks {
    private int passed;
    private void check(boolean condition,String message){passed++;if(!condition)throw new AssertionError(message);}
    private Duwm1728BroadcastLayout.Report fixture(){
        Duwm1728BroadcastLayout.Report r=new Duwm1728BroadcastLayout.Report();r.title="AUTOMATED GRAPHICS TEST";r.description="Not a published news report";r.category="BREAKING NEWS";r.breakingApproved=true;r.clock="TEST ONLY";
        r.heading="TEST";r.altitude="TEST";r.weather="TEST";r.gps="DO NOT EXPOSE";r.coordinatesAllowed=false;
        r.tickers.add(new Duwm1728BroadcastLayout.Cue(0,10000,"Moving ticker from the same layout used in preview and MP4 export"));return r;
    }
    void pixels(Context context)throws Exception{
        for(int[] size:new int[][]{{720,800},{720,1280},{1280,720}}){
            Bitmap first=Bitmap.createBitmap(size[0],size[1],Bitmap.Config.ARGB_8888),later=Bitmap.createBitmap(size[0],size[1],Bitmap.Config.ARGB_8888);
            Canvas a=new Canvas(first),b=new Canvas(later);a.drawColor(0xFF17202B);b.drawColor(0xFF17202B);
            Duwm1728BroadcastLayout.Report report=fixture();
            Duwm1728BroadcastLayout.Geometry g=Duwm1728BroadcastLayout.draw(new Duwm1728BroadcastCanvas(a),size[0],size[1],report,0);
            Duwm1728BroadcastLayout.draw(new Duwm1728BroadcastCanvas(b),size[0],size[1],report,1000);
            check(first.getPixel((int)(g.x+4*g.unit),(int)(g.tagTop+4*g.unit))==0xFFD50000,"Native exact red badge");
            check(first.getPixel((int)(g.x+130*g.unit),(int)(g.tickerTop+4*g.unit))==0xFF041424,"Native navy ticker");
            int changed=0;for(int y=(int)g.tickerTop;y<(int)g.bottom;y++)for(int x=(int)(g.x+130*g.unit);x<(int)(g.x+g.width-10*g.unit);x++)if(first.getPixel(x,y)!=later.getPixel(x,y))changed++;
            check(changed>20,"Native ticker changes pixels");
            File folder=new File(context.getFilesDir(),"broadcast-native-proof");if(!folder.exists()&&!folder.mkdirs())throw new IOException("No evidence directory");
            try(FileOutputStream stream=new FileOutputStream(new File(folder,"NATIVE-"+size[0]+"x"+size[1]+".png"))){check(first.compress(Bitmap.CompressFormat.PNG,100,stream),"Write native PNG");}
            first.recycle();later.recycle();
        }
    }
    void exports(Instrumentation instrumentation)throws Exception {
        Context target=instrumentation.getTargetContext();File folder=new File(target.getFilesDir(),"broadcast-native-proof");if(!folder.exists())folder.mkdirs();
        File master=new File(target.getCacheDir(),"broadcast_fixture.mp4");
        try(InputStream input=instrumentation.getContext().getAssets().open("broadcast_fixture.mp4");FileOutputStream output=new FileOutputStream(master)){byte[] block=new byte[65536];int n;while((n=input.read(block))!=-1)output.write(block,0,n);}
        String sourceDigest=hash(master);
        for(String ratio:new String[]{"9:10","9:16","16:9"}){
            Duwm1728OverlayRenderer.Spec spec=new Duwm1728OverlayRenderer.Spec();spec.fromMs=0;spec.toMs=1900;
            spec.title="AUTOMATED ENCODER TEST";spec.description="Test fixture; not a news event";spec.ratio=ratio;spec.template="BREAKING NEWS";spec.breakingApproved=true;
            spec.ticker="00:00=This ticker is permanently encoded in the test MP4";spec.captions="00:00=Separate caption from the source test";
            File result=Duwm1728OverlayRenderer.export(target,Uri.fromFile(master),spec);
            File proof=new File(folder,"ANDROID-EXPORT-"+ratio.replace(':','-')+".mp4");
            try(InputStream in=new FileInputStream(result);OutputStream out=new FileOutputStream(proof)){byte[] bytes=new byte[65536];int n;while((n=in.read(bytes))!=-1)out.write(bytes,0,n);}finally{result.delete();}
            int[] expected=Duwm1728BroadcastLayout.dimensions(960,540,ratio);MediaMetadataRetriever checkVideo=new MediaMetadataRetriever();
            try{checkVideo.setDataSource(proof.getAbsolutePath());int width=Integer.parseInt(checkVideo.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)),height=Integer.parseInt(checkVideo.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
                check(width==expected[0]&&height==expected[1],"Encoded ratio and dimensions "+ratio);
                check("yes".equalsIgnoreCase(checkVideo.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)),"AAC audio retained "+ratio);
                long duration=Long.parseLong(checkVideo.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));check(Math.abs(duration-1900)<180,"Real encoded duration preserved "+ratio);
                Bitmap a=checkVideo.getFrameAtTime(200000,MediaMetadataRetriever.OPTION_CLOSEST),b=checkVideo.getFrameAtTime(1200000,MediaMetadataRetriever.OPTION_CLOSEST);check(a!=null&&b!=null,"Actual MP4 frames decode "+ratio);
                Duwm1728BroadcastLayout.Report report=fixture();report.heading="";report.altitude="";report.weather="";
                Bitmap dummy=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);Duwm1728BroadcastLayout.Geometry g=Duwm1728BroadcastLayout.draw(new Duwm1728BroadcastCanvas(new Canvas(dummy)),width,height,report,0);dummy.recycle();
                int pixel=a.getPixel((int)(g.x+8*g.unit),(int)(g.tagTop+7*g.unit));check(Color.red(pixel)>150&&Color.green(pixel)<65&&Color.blue(pixel)<65,"Red survives MP4 encoding "+ratio);
                int diff=0;for(int y=(int)g.tickerTop+2;y<(int)g.bottom-2;y++)for(int x=(int)(g.x+130*g.unit);x<(int)(g.x+g.width-10*g.unit);x++)if(a.getPixel(x,y)!=b.getPixel(x,y))diff++;
                check(diff>15,"Ticker actually moves in MP4 "+ratio);a.recycle();b.recycle();
            }finally{checkVideo.release();}
            check(sourceDigest.equals(hash(master)),"Original fixture unchanged "+ratio);
        }
        master.delete();try(FileOutputStream log=new FileOutputStream(new File(folder,"RESULT.txt"))){log.write(("PASS "+passed+" Android pixel and codec checks. Emulator test, not physical camera verification.\n").getBytes("UTF-8"));}
    }
    int count(){return passed;}
    private static String hash(File file)throws Exception{java.security.MessageDigest md=java.security.MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(file)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)md.update(b,0,n);}StringBuilder value=new StringBuilder();for(byte b:md.digest())value.append(String.format(Locale.US,"%02x",b&255));return value.toString();}
}
