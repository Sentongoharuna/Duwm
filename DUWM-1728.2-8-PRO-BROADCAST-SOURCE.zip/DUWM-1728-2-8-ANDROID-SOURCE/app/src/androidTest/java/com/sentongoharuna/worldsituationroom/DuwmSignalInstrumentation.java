package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.app.Instrumentation;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import java.io.File;
import java.io.FileOutputStream;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

/** Native Android Canvas regression, no network, mocked news or test fixtures in the app UI.
 * This runner is compiled into a separate androidTest APK, not the user APK.
 */
public final class DuwmSignalInstrumentation extends Instrumentation {
    private int checks;
    @Override public void onCreate(Bundle args){super.onCreate(args);start();}
    private void require(boolean ok,String text){checks++;if(!ok)throw new AssertionError(text);}
    private Bitmap frame(Duwm1728StatusLampView lamp,long time,boolean motion){
        Bitmap image=Bitmap.createBitmap(80,80,Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(image);c.drawColor(DuwmUnifiedTheme.APPROVED_NAVY);
        lamp.layout(0,0,80,80);lamp.drawLampFrame(c,time,motion);return image;
    }
    private void pixels() throws Exception {
        File folder=new File(getTargetContext().getFilesDir(),"signal-visual-proof");
        if(!folder.isDirectory()&&!folder.mkdirs())throw new IllegalStateException("Cannot save proof");
        for(Duwm1724SignalFlow.Stage state:Duwm1724SignalFlow.Stage.values()){
            Duwm1728StatusLampView lamp=new Duwm1728StatusLampView(getTargetContext());
            lamp.setStage(state,0,true);
            Bitmap fixed=frame(lamp,0L,false);
            int expected=state==Duwm1724SignalFlow.Stage.LOCAL?DuwmUnifiedTheme.APPROVED_NAVY:state.color;
            require(fixed.getPixel(40,40)==expected,"Exact solid colour / hollow local: "+state);
            require(fixed.getPixel(0,0)==DuwmUnifiedTheme.APPROVED_NAVY,"Exact navy background");
            try(FileOutputStream stream=new FileOutputStream(new File(folder,state.name()+"-STATIC.png"))){
                require(fixed.compress(Bitmap.CompressFormat.PNG,100,stream),"PNG proof write");
            }
            fixed.recycle();Set<Integer> distinct=new HashSet<>();
            for(int i=0;i<24;i++){
                Bitmap moving=frame(lamp,Duwm1728SignalMotion.periodMs(state)*i/24L,true);
                int pixel=moving.getPixel(40,40);distinct.add(pixel);
                require((pixel>>>24)==255,"Opaque animated core");moving.recycle();
            }
            require(state.rank>=0?distinct.size()>1:distinct.size()==1,"Real frame colour changes / neutral stays still: "+state);
            Duwm1728StatusLampView legend=new Duwm1728StatusLampView(getTargetContext());
            legend.showStaticColor(state.color,"STATIC HISTORY, NOT LIVE");
            Bitmap before=frame(legend,0,false),after=frame(legend,900,false);
            require(before.sameAs(after),"History does not pretend live activity");before.recycle();after.recycle();
        }
        // Same state, different sector keys -> an independent animation phase.
        Duwm1728StatusLampView one=new Duwm1728StatusLampView(getTargetContext());
        Duwm1728StatusLampView two=new Duwm1728StatusLampView(getTargetContext());
        one.setStage(Duwm1724SignalFlow.Stage.HEALTHY,0,true);
        two.setStage(Duwm1724SignalFlow.Stage.HEALTHY,1,true);
        Bitmap a=frame(one,700,true),b=frame(two,700,true);
        require(a.getPixel(40,40)!=b.getPixel(40,40),"No synchronized blinking across all providers");a.recycle();b.recycle();
    }
    private void cameraHealthDock() throws Exception {
        // Test-only fixtures: demonstrate native layout, never inserted into the production UI.
        android.view.ContextThemeWrapper context=new android.view.ContextThemeWrapper(
                getTargetContext(),R.style.Theme_WorldSituationRoom);
        android.util.TypedValue value=new android.util.TypedValue();
        require(context.getTheme().resolveAttribute(android.R.attr.alertDialogTheme,value,true),"Native dialog theme resolves");
        android.view.ContextThemeWrapper dialog=new android.view.ContextThemeWrapper(context,value.resourceId);
        require(dialog.getTheme().resolveAttribute(android.R.attr.colorBackground,value,true),"Dialog background resolves");
        require(value.data==DuwmUnifiedTheme.APPROVED_NAVY,"Dialog has exact approved navy background");
        Duwm1728CaptureHealth.Input input=new Duwm1728CaptureHealth.Input();
        input.now=1_000_000L;input.cameraPermission=true;input.cameraOpen=true;
        input.frameAt=input.now;input.adequateResolution=true;input.recording=true;
        input.microphoneEnabled=true;input.microphonePermission=true;input.microphoneError="TEST FIXTURE: input failed";
        input.compassPresent=true;input.compassAt=input.now-30_000L;
        input.weatherRequested=true;input.weatherLoading=true;
        Duwm1728CaptureHealthView dock=new Duwm1728CaptureHealthView(context);dock.update(input);
        int width=Math.round(360*context.getResources().getDisplayMetrics().density);
        int height=Math.round(58*context.getResources().getDisplayMetrics().density);
        dock.measure(android.view.View.MeasureSpec.makeMeasureSpec(width,android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(height,android.view.View.MeasureSpec.EXACTLY));
        dock.layout(0,0,width,height);
        require(dock.getChildCount()==6,"Six native camera-health cells");
        Duwm1724SignalFlow.Stage[] expected={Duwm1724SignalFlow.Stage.HEALTHY,
                Duwm1724SignalFlow.Stage.OUTAGE,Duwm1724SignalFlow.Stage.LOCAL,
                Duwm1724SignalFlow.Stage.AGED,Duwm1724SignalFlow.Stage.CONNECTING,
                Duwm1724SignalFlow.Stage.UNKNOWN};
        int end=0;
        for(int k=0;k<6;k++){
            android.view.View cell=dock.getChildAt(k);
            require(cell.getWidth()>0&&cell.getLeft()>=end&&cell.getRight()<=width,"Nonoverlapping native cell "+k);
            end=cell.getRight();
            require(cell.isClickable()&&cell.isFocusable(),"Tap/accessibility target "+k);
            android.view.ViewGroup top=(android.view.ViewGroup)((android.view.ViewGroup)cell).getChildAt(0);
            Duwm1728StatusLampView lamp=(Duwm1728StatusLampView)top.getChildAt(0);
            int left=lamp.getLeft(),topY=lamp.getTop(),right=lamp.getRight(),bottom=lamp.getBottom();
            Bitmap exact=frame(lamp,0L,false);
            require(exact.getPixel(40,40)==(expected[k]==Duwm1724SignalFlow.Stage.LOCAL?
                    DuwmUnifiedTheme.APPROVED_NAVY:expected[k].color),"Camera source maps to real pixel colour "+k);
            exact.recycle();lamp.layout(left,topY,right,bottom);
        }
        File folder=new File(getTargetContext().getFilesDir(),"signal-visual-proof");
        Bitmap image=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
        dock.draw(new Canvas(image));
        require(image.getPixel(0,0)==DuwmUnifiedTheme.APPROVED_NAVY,"Camera dock uses the exact navy surface");
        try(FileOutputStream out=new FileOutputStream(new File(folder,"CAMERA-HEALTH-TEST-FIXTURES.png"))){
            require(image.compress(Bitmap.CompressFormat.PNG,100,out),"Write fixture-only Android dock proof");
        }
        image.recycle();
    }
    @Override public void onStart(){
        Bundle result=new Bundle();AtomicReference<Throwable> failure=new AtomicReference<>();
        DuwmBroadcastChecks broadcast=new DuwmBroadcastChecks();
        runOnMainSync(()->{try{pixels();cameraHealthDock();broadcast.pixels(getTargetContext());}catch(Throwable error){failure.set(error);}});
        if(failure.get()==null)try{broadcast.exports(this);}catch(Throwable error){failure.set(error);}
        if(failure.get()!=null){
            result.putString("stream","DUWM_NATIVE_BROADCAST_FAIL\n"+android.util.Log.getStackTraceString(failure.get()));
            finish(Activity.RESULT_CANCELED,result);
        }else{
            result.putString("stream","DUWM_NATIVE_BROADCAST_PASS: "+checks+" signal checks and "+broadcast.count()+" broadcast checks; not a physical-camera test\n");
            finish(Activity.RESULT_OK,result);
        }
    }
}
