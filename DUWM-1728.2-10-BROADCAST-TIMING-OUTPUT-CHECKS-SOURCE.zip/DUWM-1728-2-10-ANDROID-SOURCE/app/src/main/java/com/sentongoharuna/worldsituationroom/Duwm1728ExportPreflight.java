package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.media.*;
import android.net.Uri;
import android.os.Build;
import java.io.File;
import java.util.Locale;

/** Inspects real source tracks and advertised codec support. Does NOT claim a completed export. */
public final class Duwm1728ExportPreflight {
    private Duwm1728ExportPreflight() {}
    public static final class Result {
        public final int sourceWidth,sourceHeight,width,height,fps,bitrate,rotation;
        public final long durationMs;public final boolean audio,estimatedFps;
        public final String encoder,ratio;
        Result(int sw,int sh,int w,int h,int f,int b,int r,long d,boolean a,boolean estimate,String e,String ratio){
            sourceWidth=sw;sourceHeight=sh;width=w;height=h;fps=f;bitrate=b;rotation=r;durationMs=d;
            audio=a;estimatedFps=estimate;encoder=e;this.ratio=ratio;
        }
        public String summary(){
            float[] crop=Duwm1728BroadcastLayout.crop(sourceWidth,sourceHeight,width,height);
            int lost=Math.round(100*(1-crop[2]*crop[3]));
            return ratio+"  •  "+width+" × "+height+"  •  "+fps+" fps"+(estimatedFps?" requested*":" requested")+
                "\n"+(audio?"AAC soundtrack retained":"SILENT SOURCE — no audio track")+"  •  "+Duwm1728BroadcastTimeline.clock(durationMs)+
                "\n"+(lost>0?"Centre crop removes "+lost+"% of source area":"Full source framing")+
                " • no stretching / no upscaling\nEncoder advertised; actual recording/export still needs testing."+
                (estimatedFps?" *Source does not declare frame rate.":"");
        }
    }
    private static int number(MediaFormat f,String key,int fallback){try{return f.getInteger(key);}catch(Exception e){return fallback;}}
    public static MediaFormat outputFormat(Result p){
        MediaFormat f=MediaFormat.createVideoFormat("video/avc",p.width,p.height);
        f.setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        f.setInteger(MediaFormat.KEY_BIT_RATE,p.bitrate);f.setInteger(MediaFormat.KEY_FRAME_RATE,p.fps);
        f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL,2);if(Build.VERSION.SDK_INT>=29)f.setInteger(MediaFormat.KEY_MAX_B_FRAMES,0);
        return f;
    }
    public static Result inspect(Context context,Uri source,long from,long to,String ratio)throws Exception{
        Duwm1728BroadcastTimeline.range(from,to);
        MediaExtractor tracks=new MediaExtractor();MediaMetadataRetriever meta=new MediaMetadataRetriever();
        try{
            meta.setDataSource(context,source);String d=meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if(d==null||to>Long.parseLong(d))throw new IllegalArgumentException("Clip exceeds the source recording");
            tracks.setDataSource(context,source,null);MediaFormat video=null;boolean audio=false;
            for(int i=0;i<tracks.getTrackCount();i++){
                MediaFormat f=tracks.getTrackFormat(i);String mime=f.getString(MediaFormat.KEY_MIME);
                if(mime!=null&&mime.startsWith("video/")&&video==null)video=f;
                if(mime!=null&&mime.startsWith("audio/")){
                    if(!"audio/mp4a-latm".equals(mime))throw new IllegalArgumentException("This audio codec requires conversion; sound will not be silently discarded");
                    audio=true;
                }
            }
            if(video==null)throw new IllegalArgumentException("No video track in the source");
            int transfer=number(video,MediaFormat.KEY_COLOR_TRANSFER,3);
            if(transfer==6||transfer==7)throw new IllegalArgumentException("HDR source: use an SDR recording for this broadcast renderer; no false HDR conversion");
            int rotation=number(video,MediaFormat.KEY_ROTATION,0);String raw=meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
            if(raw!=null)rotation=Integer.parseInt(raw);rotation=((rotation%360)+360)%360;
            if(rotation%90!=0)throw new IllegalArgumentException("Unsupported non-right-angle source rotation");
            int sw=video.getInteger(MediaFormat.KEY_WIDTH),sh=video.getInteger(MediaFormat.KEY_HEIGHT);
            if(rotation%180!=0){int tmp=sw;sw=sh;sh=tmp;}
            int[] size=Duwm1728BroadcastLayout.dimensions(sw,sh,ratio);
            int declared=number(video,MediaFormat.KEY_FRAME_RATE,0),fps=declared>0?declared:30;
            if(fps>120)throw new IllegalArgumentException("Source exceeds 120 fps; dedicated high-speed conversion is required");
            int bitrate=(int)Math.min(80000000L,Math.max(5000000L,(long)size[0]*size[1]*fps/5));
            Result proposed=new Result(sw,sh,size[0],size[1],fps,bitrate,rotation,to-from,audio,declared<=0,"",ratio);
            String encoder=new MediaCodecList(MediaCodecList.ALL_CODECS).findEncoderForFormat(outputFormat(proposed));
            if(encoder==null)throw new IllegalArgumentException("No advertised AVC encoder for "+size[0]+"×"+size[1]+" at "+fps+" fps. Choose another ratio or recording size; the original is unchanged.");
            return new Result(sw,sh,size[0],size[1],fps,bitrate,rotation,to-from,audio,declared<=0,encoder,ratio);
        }finally{tracks.release();try{meta.release();}catch(Exception ignored){}}
    }
    public static String savedDetails(File file)throws Exception{
        MediaMetadataRetriever meta=new MediaMetadataRetriever();
        try{meta.setDataSource(file.getAbsolutePath());return
            meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)+" × "+meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)+
            " • "+Duwm1728BroadcastTimeline.clock(Long.parseLong(meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)))+
            " • "+("yes".equalsIgnoreCase(meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO))?"audio track present":"silent MP4")+
            String.format(Locale.ROOT," • %.1f MiB",file.length()/1048576d);
        }finally{try{meta.release();}catch(Exception ignored){}}
    }
}
