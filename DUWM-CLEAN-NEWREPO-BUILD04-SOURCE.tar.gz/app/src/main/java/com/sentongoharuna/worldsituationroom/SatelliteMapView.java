package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.RadialGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.Collections;
import java.util.Deque;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Date;
import java.util.TimeZone;

/**
 * Fully native orthographic globe and optional slippy-map renderer. It draws geography,
 * cached satellite/radar tiles and interactive signals directly on an Android Canvas;
 * no browser or WebView is involved.
 */
public final class SatelliteMapView extends View {
    public interface Listener {
        void onSignalTap(Signal signal);
        void onViewportChanged(Bounds bounds);
    }

    public static final class Bounds {
        public final double south;
        public final double west;
        public final double north;
        public final double east;

        Bounds(double south, double west, double north, double east) {
            this.south = south;
            this.west = west;
            this.north = north;
            this.east = east;
        }
    }

    private static final class VisibleTile {
        final int x;
        final int y;
        final double distance;

        VisibleTile(int x, int y, double distance) {
            this.x = x;
            this.y = y;
            this.distance = distance;
        }
    }

    private static final class ActivityPulse {
        final Signal signal;
        final int color;
        final long startedMs;
        final long durationMs;

        ActivityPulse(Signal signal, int color, long startedMs, long durationMs) {
            this.signal = signal;
            this.color = color;
            this.startedMs = startedMs;
            this.durationMs = durationMs;
        }
    }

    /** A provider observation, never a dead-reckoned display position. */
    private static final class TrackPoint {
        final double latitude;
        final double longitude;
        final long timestampMs;

        TrackPoint(double latitude, double longitude, long timestampMs) {
            this.latitude = latitude;
            this.longitude = longitude;
            this.timestampMs = timestampMs;
        }
    }

    // Lightweight native geography appears immediately while raster tiles arrive.
    private static final double[][][] LAND_MASSES = {
            {{37, -17}, {35, -5}, {37, 10}, {31, 33}, {22, 37}, {12, 51},
                    {1, 42}, {-12, 40}, {-25, 34}, {-35, 20}, {-30, 15},
                    {-18, 12}, {-6, 12}, {5, -17}, {22, -17}},
            {{36, -11}, {43, -9}, {50, -5}, {58, -7}, {72, 20}, {70, 38},
                    {58, 45}, {46, 40}, {36, 28}},
            {{36, 28}, {50, 40}, {70, 55}, {77, 105}, {70, 178}, {52, 160},
                    {43, 145}, {35, 140}, {20, 110}, {8, 105}, {7, 80}, {25, 65}},
            {{15, -85}, {25, -110}, {32, -117}, {50, -130}, {70, -168},
                    {82, -70}, {60, -50}, {45, -60}, {30, -80}},
            {{13, -82}, {4, -78}, {-15, -75}, {-35, -72}, {-56, -70},
                    {-50, -35}, {-20, -40}, {8, -50}},
            {{-10, 112}, {-22, 114}, {-35, 116}, {-44, 145}, {-30, 154}, {-10, 154}},
            {{59, -73}, {83, -60}, {81, -20}, {62, -42}},
            {{-12, 43}, {-25, 46}, {-14, 50}},
            {{31, 130}, {35, 132}, {45, 142}, {41, 145}, {33, 135}},
            {{50, -6}, {58, -7}, {59, -2}, {51, 2}},
            {{-34, 166}, {-47, 168}, {-46, 179}, {-35, 174}},
            {{-6, 95}, {-5, 105}, {-7, 115}, {-8, 125}, {-6, 135}, {-3, 141}},
            {{18, 120}, {12, 122}, {6, 126}, {17, 126}}
    };

    private static final double[][] REFERENCE_CITIES = {
            {0.3476, 32.5825}, {30.0444, 31.2357}, {6.5244, 3.3792},
            {-26.2041, 28.0473}, {51.5072, -0.1276}, {48.8566, 2.3522},
            {41.0082, 28.9784}, {25.2048, 55.2708}, {28.6139, 77.2090},
            {19.0760, 72.8777}, {39.9042, 116.4074}, {35.6762, 139.6503},
            {1.3521, 103.8198}, {-33.8688, 151.2093}, {40.7128, -74.0060},
            {34.0522, -118.2437}, {19.4326, -99.1332}, {-23.5505, -46.6333},
            {-34.6037, -58.3816}
    };

    private static final Object[][] REFERENCE_REGIONS = {
            {"AFRICA", 8d, 20d}, {"EUROPE", 53d, 16d}, {"ASIA", 45d, 92d},
            {"NORTH AMERICA", 49d, -105d}, {"SOUTH AMERICA", -18d, -59d},
            {"OCEANIA", -25d, 135d}, {"MIDDLE EAST", 27d, 44d}
    };

    private static final int TILE = 256;
    private static final int MAX_TRAFFIC_MARKERS = 1_500;
    private static final long BASE_MAX_AGE = 30L * 24L * 60L * 60L * 1000L;
    private static final long RADAR_MAX_AGE = 20L * 60L * 1000L;
    private static final long FLIGHT_ESTIMATE_LIMIT_MS = 60_000L;
    private static final long VESSEL_ESTIMATE_LIMIT_MS = 120_000L;
    private static final int MAX_TRACK_HISTORIES = 2_000;
    private static final int MAX_FIXES_PER_TRACK = 32;
    private static final Signal.Layer[] OPERATION_ARCS = {
            Signal.Layer.FLIGHTS, Signal.Layer.SHIPS, Signal.Layer.WEATHER,
            Signal.Layer.AIRSPACE, Signal.Layer.NATURAL, Signal.Layer.NEWS,
            Signal.Layer.SATELLITES
    };
    private final TileStore baseTiles;
    private final TileStore overlayTiles;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint trailPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final GestureDetector gestures;
    private final ScaleGestureDetector scales;
    private final Path markerPath = new Path();
    private final Path geographyPath = new Path();
    private final Path globePath = new Path();
    private final RectF operationalArcBounds = new RectF();
    private final List<ActivityPulse> activityPulses = new ArrayList<>();
    private final LinkedHashMap<String, ArrayDeque<TrackPoint>> observedTracks =
            new LinkedHashMap<>(64, 0.75f, true);
    private final EnumMap<Signal.Layer, FeedStatus> activityStatuses =
            new EnumMap<>(Signal.Layer.class);
    private final EnumMap<Signal.Layer, Long> activityReceivedAt =
            new EnumMap<>(Signal.Layer.class);
    private final SimpleDateFormat replayClock =
            new SimpleDateFormat("HH:mm:ss 'UTC'", Locale.US);
    private final Runnable framePulse = new Runnable() {
        @Override
        public void run() {
            if (isAttachedToWindow() && isShown()) postInvalidateOnAnimation();
        }
    };
    private List<Signal> signals = Collections.emptyList();
    private Listener listener;
    private double centerLat = 12d;
    private double centerLon = 18d;
    private double zoom = 2.25d;
    private boolean weatherVisible = true;
    private boolean duDetectionHudEnabled = true;
    private String radarHost = "";
    private String radarPath = "";
    private long radarTimeMs;
    private List<WorldDataRepository.RadarFrame> radarFrames = Collections.emptyList();
    private int radarFrameIndex;
    private boolean radarAnimationPlaying = true;
    private long lastRadarAdvanceMs;
    private Signal highlightedSignal;
    private long highlightStartedMs;
    private String followedSignalId = "";
    private Signal followedSignal;
    private boolean globeMode = true;
    private double globeScale = 0.94d;
    private long interactionPauseUntilMs;
    private long lastFrameMs;
    private long animationTimeMs;
    private long frameWallTimeMs;
    private boolean replayMode;
    private long replayEpochMs;
    private String replayAttribution = "";
    private Shader globeShader;
    private LinearGradient horizonShader;
    private int globeShaderWidth = -1;
    private int globeShaderHeight = -1;
    private double globeShaderScale = -1d;
    private String baseViewportSignature = "";
    private List<VisibleTile> cachedBaseTiles = Collections.emptyList();
    private Set<String> baseViewportKeys = Collections.emptySet();
    private long nextBaseRetryMs;

    public SatelliteMapView(Context context) {
        super(context);
        setBackgroundColor(Color.rgb(5, 8, 12));
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        // Base imagery is opaque RGB_565 and owns a larger, pinned cache. Labels and animated
        // radar remain ARGB in a separate cache so they cannot evict the map beneath them.
        baseTiles = new TileStore(context, "base", 96L * 1024L * 1024L,
                4, 4, 180L * 1024L * 1024L, true);
        overlayTiles = new TileStore(context, "overlay", 32L * 1024L * 1024L,
                12, 3, 90L * 1024L * 1024L, false);
        textPaint.setTypeface(android.graphics.Typeface.MONOSPACE);
        replayClock.setTimeZone(TimeZone.getTimeZone("UTC"));
        glowPaint.setStyle(Paint.Style.STROKE);
        trailPaint.setStyle(Paint.Style.STROKE);
        trailPaint.setStrokeCap(Paint.Cap.ROUND);
        gestures = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDown(MotionEvent event) {
                return true;
            }

            @Override
            public boolean onScroll(
                    MotionEvent first,
                    MotionEvent current,
                    float distanceX,
                    float distanceY) {
                if (scales.isInProgress()) {
                    return false;
                }
                pauseAutoRotation();
                if (globeMode) {
                    rotateGlobeBy(distanceX, distanceY);
                } else {
                    panBy(distanceX, distanceY);
                }
                return true;
            }

            @Override
            public boolean onSingleTapConfirmed(MotionEvent event) {
                Signal hit = findSignal(event.getX(), event.getY());
                if (hit != null && listener != null) {
                    listener.onSignalTap(hit);
                }
                return true;
            }

            @Override
            public boolean onDoubleTap(MotionEvent event) {
                pauseAutoRotation();
                if (globeMode) {
                    enterDetailMode(4.5d);
                } else {
                    zoom = clamp(zoom + 1d, 1d, 17d);
                }
                invalidate();
                notifyViewport();
                return true;
            }
        });
        scales = new ScaleGestureDetector(context,
                new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    private boolean beganOnGlobe;

                    @Override
                    public boolean onScaleBegin(ScaleGestureDetector detector) {
                        pauseAutoRotation();
                        beganOnGlobe = globeMode;
                        return true;
                    }

                    @Override
                    public boolean onScale(ScaleGestureDetector detector) {
                        if (globeMode) {
                            globeScale = clamp(globeScale * detector.getScaleFactor(),
                                    0.66d, 1.28d);
                        } else {
                            zoom = clamp(zoom
                                    + Math.log(detector.getScaleFactor()) / Math.log(2d),
                                    1d, 17d);
                        }
                        invalidate();
                        return true;
                    }

                    @Override
                    public void onScaleEnd(ScaleGestureDetector detector) {
                        // Any deliberate zoom-in gesture crosses into the real tiled tracker.
                        // Users should never be trapped on the low-detail overview globe.
                        if (beganOnGlobe && globeMode && globeScale > 1.01d) {
                            enterDetailMode(4.5d);
                        } else if (!globeMode && zoom <= 1.35d) {
                            setGlobeMode(true);
                        }
                        notifyViewport();
                    }
                });
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void setSignals(List<Signal> value) {
        // Full provider result sets remain available in their native pages. The Canvas keeps
        // a deterministic, geographically distributed render snapshot so a 10,000-aircraft
        // global response cannot monopolise Android's UI thread.
        recordProviderFixes(value);
        signals = Collections.unmodifiableList(buildRenderSnapshot(value));
        if (!followedSignalId.isEmpty()) {
            followedSignal = findById(value, followedSignalId);
            if (followedSignal != null) {
                updateFollowCenter();
                notifyViewport();
            }
        }
        invalidate();
    }

    /** Switches all time-sensitive rendering to an acquired historical frame. */
    public void setReplayState(boolean enabled, long epochMs) {
        replayMode = enabled;
        replayEpochMs = Math.max(0L, epochMs);
        replayAttribution = enabled && replayEpochMs > 0L
                ? "4D REPLAY  " + replayClock.format(new Date(replayEpochMs))
                + "  •  acquired frames only" : "";
        if (enabled) stopFollowing();
        invalidate();
    }

    /** Records a real provider callback for finite, independently timed globe activity arcs. */
    public void setLayerActivity(Signal.Layer layer, FeedStatus status) {
        if (layer == null || status == null) return;
        activityStatuses.put(layer, status);
        activityReceivedAt.put(layer, SystemClock.uptimeMillis());
        postInvalidateOnAnimation();
    }

    /** Records only timestamps and coordinates received from providers. */
    private void recordProviderFixes(List<Signal> values) {
        long now = System.currentTimeMillis();
        if (values != null) {
            for (Signal signal : values) {
                if (signal == null || !signal.hasLocation()
                        || signal.layer != Signal.Layer.FLIGHTS
                        && signal.layer != Signal.Layer.SHIPS) continue;
                ArrayDeque<TrackPoint> history = observedTracks.get(signal.id);
                if (history == null) {
                    history = new ArrayDeque<>();
                    observedTracks.put(signal.id, history);
                }
                TrackPoint last = history.peekLast();
                if (last == null || signal.timestampMs > last.timestampMs
                        || signal.timestampMs == last.timestampMs
                        && (signal.latitude != last.latitude
                        || signal.longitude != last.longitude)) {
                    history.addLast(new TrackPoint(signal.latitude, signal.longitude,
                            signal.timestampMs));
                    while (history.size() > MAX_FIXES_PER_TRACK) history.removeFirst();
                }
            }
        }
        Iterator<Map.Entry<String, ArrayDeque<TrackPoint>>> iterator =
                observedTracks.entrySet().iterator();
        while (iterator.hasNext()) {
            ArrayDeque<TrackPoint> history = iterator.next().getValue();
            TrackPoint last = history.peekLast();
            if (last == null || now - last.timestampMs > 4L * 60L * 60L * 1000L) {
                iterator.remove();
            }
        }
        while (observedTracks.size() > MAX_TRACK_HISTORIES) {
            Iterator<String> eldest = observedTracks.keySet().iterator();
            if (!eldest.hasNext()) break;
            eldest.next();
            eldest.remove();
        }
    }

    /** Returns only observed provider fixes for one tracked object; never estimated points. */
    public List<double[]> observedTrack(String signalId) {
        List<double[]> result = new ArrayList<>();
        if (signalId == null || signalId.isEmpty()) return result;
        ArrayDeque<TrackPoint> history = observedTracks.get(signalId);
        if (history == null) return result;
        for (TrackPoint point : history) {
            result.add(new double[]{point.latitude, point.longitude, point.timestampMs});
        }
        return Collections.unmodifiableList(result);
    }

    private List<Signal> buildRenderSnapshot(List<Signal> source) {
        EnumMap<Signal.Layer, List<Signal>> grouped =
                new EnumMap<>(Signal.Layer.class);
        for (Signal.Layer layer : Signal.Layer.values()) {
            grouped.put(layer, new ArrayList<>());
        }
        if (source != null) {
            for (Signal signal : source) {
                if (signal != null && signal.hasLocation()) {
                    grouped.get(signal.layer).add(signal);
                }
            }
        }

        List<Signal> result = new ArrayList<>();
        for (Signal.Layer layer : Signal.Layer.values()) {
            appendSample(result, grouped.get(layer), renderLimit(layer),
                    layer == Signal.Layer.NEWS || layer == Signal.Layer.NATURAL
                            || layer == Signal.Layer.AIRSPACE
                            || layer == Signal.Layer.SPACE_WEATHER);
        }
        if (!followedSignalId.isEmpty()) {
            Signal followed = findById(source, followedSignalId);
            if (followed != null && !containsId(result, followed.id)) result.add(followed);
        }
        return result;
    }

    private static void appendSample(
            List<Signal> output,
            List<Signal> values,
            int limit,
            boolean preservePriority) {
        if (values == null || values.isEmpty() || limit <= 0) return;
        if (values.size() <= limit) {
            output.addAll(values);
            return;
        }
        Set<String> added = new HashSet<>();
        if (preservePriority) {
            int priorityLimit = Math.max(1, limit / 2);
            for (Signal signal : values) {
                if (signal.severity >= 4 && added.add(signal.id)) {
                    output.add(signal);
                    if (added.size() >= priorityLimit) break;
                }
            }
        }
        int slots = Math.max(limit, 1);
        for (int slot = 0; slot < slots * 2 && added.size() < limit; slot++) {
            int index = (int) Math.min(values.size() - 1L,
                    (long) slot * values.size() / (slots * 2L));
            Signal signal = values.get(index);
            if (added.add(signal.id)) output.add(signal);
        }
        for (Signal signal : values) {
            if (added.size() >= limit) break;
            if (added.add(signal.id)) output.add(signal);
        }
    }

    private static int renderLimit(Signal.Layer layer) {
        switch (layer) {
            case FLIGHTS: return 1_200;
            case SHIPS: return 600;
            case AIRSPACE: return 200;
            case NATURAL: return 260;
            case NEWS: return 220;
            case SATELLITES: return 320;
            case SPACE_WEATHER: return 80;
            case WEBCAMS: return 150;
            case RADIO:
            case TV: return 50;
            case INFRASTRUCTURE: return 260;
            default: return 0;
        }
    }

    private static boolean containsId(List<Signal> values, String id) {
        if (id == null || id.isEmpty()) return false;
        for (Signal signal : values) if (id.equals(signal.id)) return true;
        return false;
    }

    private static Signal findById(List<Signal> values, String id) {
        if (values == null || id == null || id.isEmpty()) return null;
        for (Signal signal : values) if (id.equals(signal.id)) return signal;
        return null;
    }

    public void setDuDetectionHudEnabled(boolean enabled) {
        duDetectionHudEnabled = enabled;
        invalidate();
    }

    public void setWeatherVisible(boolean visible) {
        weatherVisible = visible;
        invalidate();
    }

    public void setRadarFrame(String host, String path, long timeMs) {
        radarHost = host == null ? "" : host;
        radarPath = path == null ? "" : path;
        radarTimeMs = timeMs;
        invalidate();
    }

    public void setRadarFrames(String host, List<WorldDataRepository.RadarFrame> frames) {
        radarHost = host == null ? "" : host;
        radarFrames = frames == null ? Collections.emptyList()
                : Collections.unmodifiableList(new ArrayList<>(frames));
        radarFrameIndex = radarFrames.isEmpty() ? 0 : radarFrames.size() - 1;
        applyRadarFrameIndex();
        lastRadarAdvanceMs = SystemClock.uptimeMillis();
        invalidate();
    }

    public void setRadarAnimationPlaying(boolean playing) {
        radarAnimationPlaying = playing;
        lastRadarAdvanceMs = SystemClock.uptimeMillis();
        invalidate();
    }

    /** Selects the newest provider radar frame at or before a replay time. */
    public void setRadarReplayTime(long epochMs) {
        if (radarFrames.isEmpty() || epochMs <= 0L) return;
        int selected = 0;
        for (int index = 0; index < radarFrames.size(); index++) {
            if (radarFrames.get(index).timestampMs > epochMs) break;
            selected = index;
        }
        radarFrameIndex = selected;
        radarAnimationPlaying = false;
        applyRadarFrameIndex();
        invalidate();
    }

    public boolean isRadarAnimationPlaying() {
        return radarAnimationPlaying;
    }

    public int getRadarFrameIndex() {
        return radarFrameIndex;
    }

    public void selectRadarFrame(int index) {
        if (radarFrames.isEmpty()) return;
        radarFrameIndex = Math.max(0, Math.min(radarFrames.size() - 1, index));
        radarAnimationPlaying = false;
        applyRadarFrameIndex();
        invalidate();
    }

    private void applyRadarFrameIndex() {
        if (radarFrames.isEmpty()) {
            radarPath = "";
            radarTimeMs = 0L;
            return;
        }
        WorldDataRepository.RadarFrame frame = radarFrames.get(radarFrameIndex);
        radarPath = frame.path;
        radarTimeMs = frame.timestampMs;
    }

    private void updateRadarAnimation() {
        if (!radarAnimationPlaying || radarFrames.size() < 2 || !weatherVisible) return;
        long now = SystemClock.uptimeMillis();
        if (now - lastRadarAdvanceMs < 850L) return;
        lastRadarAdvanceMs = now;
        radarFrameIndex = (radarFrameIndex + 1) % radarFrames.size();
        applyRadarFrameIndex();
    }

    /** Briefly brackets the newest real acquisition without hiding older map objects. */
    public void highlightSignal(Signal signal) {
        highlightedSignal = signal != null && signal.hasLocation() ? signal : null;
        highlightStartedMs = SystemClock.uptimeMillis();
        invalidate();
    }

    /** Adds a finite background ring caused by a genuine acquisition. */
    public void recordActivityPulse(Signal signal, int color) {
        if (signal == null || !signal.hasLocation()) return;
        long duration = color == Color.rgb(219, 73, 80) ? 4_100L
                : color == Color.rgb(199, 151, 68) ? 3_300L : 2_450L;
        activityPulses.add(new ActivityPulse(signal, color,
                SystemClock.uptimeMillis(), duration));
        while (activityPulses.size() > 36) activityPulses.remove(0);
        postInvalidateOnAnimation();
    }

    public void setGlobeMode(boolean enabled) {
        if (globeMode == enabled) return;
        globeMode = enabled;
        if (enabled) {
            followedSignalId = "";
            followedSignal = null;
        } else {
            zoom = Math.max(4.5d, zoom);
        }
        invalidateBaseViewport();
        if (enabled) baseTiles.prioritizeViewport(Collections.emptySet());
        lastFrameMs = 0L;
        invalidate();
        notifyViewport();
    }

    public boolean isGlobeMode() {
        return globeMode;
    }

    public void setCenter(double latitude, double longitude, double requestedZoom) {
        centerLat = clamp(latitude, -85d, 85d);
        centerLon = wrapLongitude(longitude);
        zoom = clamp(requestedZoom, 1d, 17d);
        if (globeMode && requestedZoom >= 3.5d) {
            globeMode = false;
        } else if (globeMode) {
            globeScale = clamp(0.90d + (requestedZoom - 2.25d) * 0.04d,
                    0.72d, 1.18d);
            interactionPauseUntilMs = SystemClock.uptimeMillis() + 15_000L;
        }
        invalidate();
        notifyViewport();
    }

    public void zoomBy(double delta) {
        pauseAutoRotation();
        if (globeMode) {
            if (delta > 0d) {
                enterDetailMode(4.5d);
                return;
            }
            globeScale = clamp(globeScale + delta * 0.10d, 0.66d, 1.28d);
        } else {
            zoom = clamp(zoom + delta, 1d, 17d);
            if (zoom <= 1.25d) {
                setGlobeMode(true);
                return;
            }
        }
        invalidate();
        notifyViewport();
    }

    public double getCenterLatitude() {
        return centerLat;
    }

    public double getCenterLongitude() {
        return centerLon;
    }

    public double getZoom() {
        return zoom;
    }

    /** Opens a real traffic object in detailed satellite mode and follows new fixes. */
    public void followSignal(Signal signal) {
        if (signal == null || !signal.hasLocation()
                || signal.layer != Signal.Layer.FLIGHTS && signal.layer != Signal.Layer.SHIPS) {
            return;
        }
        followedSignalId = signal.id;
        followedSignal = signal;
        globeMode = false;
        zoom = Math.max(zoom, signal.layer == Signal.Layer.FLIGHTS ? 8d : 10d);
        updateFollowCenter();
        invalidate();
        notifyViewport();
    }

    public boolean isFollowing(String signalId) {
        return signalId != null && signalId.equals(followedSignalId);
    }

    public void stopFollowing() {
        followedSignalId = "";
        followedSignal = null;
        invalidate();
    }

    private void enterDetailMode(double targetZoom) {
        globeMode = false;
        zoom = Math.max(targetZoom, zoom);
        globeScale = 0.94d;
        lastFrameMs = 0L;
        invalidate();
        notifyViewport();
    }

    @Override
    protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
        super.onSizeChanged(width, height, oldWidth, oldHeight);
        invalidateBaseViewport();
        horizonShader = new LinearGradient(0f, 0f, 0f, Math.max(1, height),
                new int[]{Color.rgb(5, 8, 12), Color.rgb(8, 13, 18), Color.rgb(4, 7, 10)},
                new float[]{0f, 0.54f, 1f}, Shader.TileMode.CLAMP);
        globeShader = null;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        animationTimeMs = SystemClock.uptimeMillis();
        frameWallTimeMs = replayMode && replayEpochMs > 0L
                ? replayEpochMs : System.currentTimeMillis();
        updateRadarAnimation();
        if (globeMode) {
            drawCommandGrid(canvas);
            updateAutoRotation();
            drawGlobe(canvas);
            drawOperationalArcs(canvas);
        } else {
            canvas.drawColor(Color.rgb(5, 8, 12));
            updateFollowCenter();
            drawFallbackGeography(canvas);
            boolean rasterReady = drawBaseTiles(canvas);
            if (rasterReady && weatherVisible && !radarPath.trim().isEmpty()) {
                drawRadarTiles(canvas);
            }
            if (rasterReady && zoom >= 4d) {
                drawLabelTiles(canvas);
            }
            if (!rasterReady) {
                drawFastStartStatus(canvas);
            }
            drawMapModeStatus(canvas);
        }
        drawActivityPulses(canvas);
        drawSignals(canvas);
        if (duDetectionHudEnabled) drawDuDetectionHud(canvas);
        drawAcquisitionHighlight(canvas);
        drawTrackedCallout(canvas);
        drawAttribution(canvas);
        // Adaptive pacing preserves visible movement without allowing a dense global snapshot
        // to starve taps, scrolling or Android's launch watchdog.
        removeCallbacks(framePulse);
        long frameDelayMs = signals.size() > 1_800 ? 50L
                : signals.size() > 800 ? 40L : 33L;
        postOnAnimationDelayed(framePulse, frameDelayMs);
    }

    /**
     * Count-driven arcs make provider activity readable without inventing map objects. Arc
     * length comes from the provider count; a pulse only follows an actual layer callback.
     */
    private void drawOperationalArcs(Canvas canvas) {
        float density = getResources().getDisplayMetrics().density;
        float radius = globeRadius();
        float cx = globeCenterX();
        float cy = globeCenterY();
        long now = SystemClock.uptimeMillis();
        boolean animate = false;
        for (int index = 0; index < OPERATION_ARCS.length; index++) {
            Signal.Layer layer = OPERATION_ARCS[index];
            FeedStatus status = activityStatuses.get(layer);
            if (status == null) continue;
            int count = status.count;
            if (count <= 0 && status.state != FeedStatus.State.LOADING) {
                continue;
            }
            int color = layerColor(layer);
            float ring = radius + (8f + index * 3.8f) * density;
            float sweep = count <= 0 ? 9f
                    : (float) Math.min(86d, 14d + Math.log10(count + 1d) * 28d);
            long received = activityReceivedAt.containsKey(layer)
                    ? activityReceivedAt.get(layer) : 0L;
            long elapsed = received <= 0L ? Long.MAX_VALUE : now - received;
            float pulse = elapsed < 3_600L
                    ? (float) Math.abs(Math.sin(elapsed / 170d + index * 0.7d)) : 0f;
            if (elapsed < 3_600L) animate = true;
            float start = (float) ((now * (0.006d + index * 0.0007d)
                    + index * 48d) % 360d);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth((0.75f + pulse * 1.25f) * density);
            int alpha = (int) (80f + pulse * 145f);
            paint.setColor(Color.argb(alpha,
                    Color.red(color), Color.green(color), Color.blue(color)));
            operationalArcBounds.set(cx - ring, cy - ring, cx + ring, cy + ring);
            canvas.drawArc(operationalArcBounds, start, sweep, false, paint);
        }
        paint.setStrokeCap(Paint.Cap.BUTT);
        textPaint.setTypeface(android.graphics.Typeface.MONOSPACE);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(6.2f * getResources().getDisplayMetrics().scaledDensity);
        textPaint.setColor(Color.argb(150, 139, 155, 166));
        canvas.drawText("SOURCE ARCS / LENGTH = PROVIDER COUNT",
                cx, cy + radius + 34f * density, textPaint);
        if (animate) postInvalidateOnAnimation();
    }

    private static int layerColor(Signal.Layer layer) {
        switch (layer) {
            case FLIGHTS: return Color.rgb(112, 177, 201);
            case SHIPS: return Color.rgb(75, 166, 124);
            case WEATHER: return Color.rgb(84, 183, 221);
            case AIRSPACE: return Color.rgb(225, 158, 61);
            case NATURAL: return Color.rgb(219, 73, 80);
            case NEWS: return Color.rgb(199, 151, 68);
            case SATELLITES: return Color.rgb(174, 139, 224);
            default: return Color.rgb(139, 155, 166);
        }
    }

    private void drawCommandGrid(Canvas canvas) {
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(horizonShader);
        canvas.drawRect(0, 0, getWidth(), getHeight(), paint);
        paint.setShader(null);

        float density = getResources().getDisplayMetrics().density;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, 0.45f * density));
        paint.setColor(Color.argb(34, 103, 124, 137));
        int step = Math.max((int) (64f * density), getWidth() / 10);
        for (int x = 0; x < getWidth(); x += step) {
            canvas.drawLine(x, 0, x, getHeight(), paint);
        }
        for (int y = 0; y < getHeight(); y += step) {
            canvas.drawLine(0, y, getWidth(), y, paint);
        }

    }

    private void updateAutoRotation() {
        long now = animationTimeMs;
        if (lastFrameMs == 0L) {
            lastFrameMs = now;
            return;
        }
        long elapsed = Math.min(100L, Math.max(0L, now - lastFrameMs));
        lastFrameMs = now;
        if (now > interactionPauseUntilMs) {
            // Clearly visible rotation: roughly one full revolution every 5.5 minutes.
            centerLon = wrapLongitude(centerLon + elapsed * 0.018d);
        }
    }

    private void pauseAutoRotation() {
        interactionPauseUntilMs = SystemClock.uptimeMillis() + 8_000L;
    }

    private float globeCenterX() {
        return getWidth() / 2f;
    }

    private float globeCenterY() {
        return getHeight() * 0.52f;
    }

    private float globeRadius() {
        return (float) (Math.min(getWidth() * 0.43f, getHeight() * 0.35f) * globeScale);
    }

    private void drawGlobe(Canvas canvas) {
        float density = getResources().getDisplayMetrics().density;
        float cx = globeCenterX();
        float cy = globeCenterY();
        float radius = globeRadius();
        if (radius <= 1f) return;

        // Atmospheric glow is purely a display treatment; geographic and signal positions
        // are projected independently from their real latitude/longitude values.
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        for (int ring = 5; ring >= 1; ring--) {
            paint.setStrokeWidth(ring * 2.4f * density);
            paint.setColor(Color.argb(7 + ring * 3, 112, 177, 201));
            canvas.drawCircle(cx, cy, radius + ring * 2.2f * density, paint);
        }

        if (globeShader == null || globeShaderWidth != getWidth()
                || globeShaderHeight != getHeight()
                || Math.abs(globeShaderScale - globeScale) > 0.001d) {
            globeShaderWidth = getWidth();
            globeShaderHeight = getHeight();
            globeShaderScale = globeScale;
            globeShader = new RadialGradient(
                    cx - radius * 0.30f,
                    cy - radius * 0.34f,
                    radius * 1.42f,
                    new int[]{
                            Color.rgb(31, 60, 76),
                            Color.rgb(13, 29, 40),
                            Color.rgb(4, 10, 16)
                    },
                    new float[]{0f, 0.58f, 1f},
                    Shader.TileMode.CLAMP);
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(globeShader);
        canvas.drawCircle(cx, cy, radius, paint);
        paint.setShader(null);

        drawGlobeGrid(canvas);
        drawGlobeLand(canvas);
        drawReferenceLights(canvas);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.8f * density);
        paint.setColor(Color.argb(205, 112, 177, 201));
        canvas.drawCircle(cx, cy, radius, paint);

        textPaint.setTypeface(android.graphics.Typeface.MONOSPACE);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(10f * getResources().getDisplayMetrics().scaledDensity);
        textPaint.setColor(Color.rgb(211, 220, 226));
        canvas.drawText("GLOBAL OPERATIONS / SOURCE-ATTRIBUTED SIGNALS",
                cx, cy - radius - 17f * density, textPaint);
        textPaint.setTextSize(8f * getResources().getDisplayMetrics().scaledDensity);
        textPaint.setColor(Color.rgb(139, 155, 166));
        String frame = weatherVisible && radarTimeMs > 0L
                ? String.format(Locale.US, " • WX %02d/%02d %s",
                radarFrameIndex + 1, Math.max(1, radarFrames.size()),
                radarAnimationPlaying ? "LOOP" : "PAUSED") : "";
        canvas.drawText(String.format(Locale.US,
                        "FOCUS %.1f° %.1f°  /  DRAG ROTATE  /  PINCH OR DOUBLE TAP FOR SATELLITE%s",
                        centerLat, centerLon, frame),
                cx, cy + radius + 19f * density, textPaint);
    }

    private void drawGlobeGrid(Canvas canvas) {
        float[] point = new float[2];
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(0.75f * getResources().getDisplayMetrics().density);
        paint.setColor(Color.argb(48, 112, 177, 201));
        for (int latitude = -60; latitude <= 60; latitude += 30) {
            globePath.reset();
            boolean drawing = false;
            for (int longitude = -180; longitude <= 180; longitude += 4) {
                if (!projectGlobeInto(latitude, longitude, point)) {
                    drawing = false;
                } else if (!drawing) {
                    globePath.moveTo(point[0], point[1]);
                    drawing = true;
                } else {
                    globePath.lineTo(point[0], point[1]);
                }
            }
            canvas.drawPath(globePath, paint);
        }
        for (int longitude = -180; longitude < 180; longitude += 30) {
            globePath.reset();
            boolean drawing = false;
            for (int latitude = -88; latitude <= 88; latitude += 3) {
                if (!projectGlobeInto(latitude, longitude, point)) {
                    drawing = false;
                } else if (!drawing) {
                    globePath.moveTo(point[0], point[1]);
                    drawing = true;
                } else {
                    globePath.lineTo(point[0], point[1]);
                }
            }
            canvas.drawPath(globePath, paint);
        }
    }

    private void drawGlobeLand(Canvas canvas) {
        float density = getResources().getDisplayMetrics().density;
        float[] point = new float[2];
        for (double[][] polygon : LAND_MASSES) {
            geographyPath.reset();
            boolean drawing = false;
            int visible = 0;
            for (double[] coordinate : polygon) {
                if (!projectGlobeInto(coordinate[0], coordinate[1], point)) {
                    drawing = false;
                    continue;
                }
                if (!drawing) {
                    geographyPath.moveTo(point[0], point[1]);
                    drawing = true;
                } else {
                    geographyPath.lineTo(point[0], point[1]);
                }
                visible++;
            }
            if (visible < 3) continue;
            geographyPath.close();
            paint.setShader(null);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb(230, 35, 73, 69));
            canvas.drawPath(geographyPath, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1.2f * density);
            paint.setColor(Color.argb(190, 90, 139, 126));
            canvas.drawPath(geographyPath, paint);
        }
    }

    private void drawReferenceLights(Canvas canvas) {
        float[] point = new float[2];
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        for (double[] city : REFERENCE_CITIES) {
            if (!projectGlobeInto(city[0], city[1], point)) continue;
            paint.setColor(Color.argb(145, 199, 151, 68));
            canvas.drawCircle(point[0], point[1], 1.5f, paint);
        }
        textPaint.setTypeface(android.graphics.Typeface.MONOSPACE);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(6.5f * getResources().getDisplayMetrics().scaledDensity);
        textPaint.setColor(Color.argb(150, 184, 200, 207));
        for (Object[] region : REFERENCE_REGIONS) {
            double latitude = (Double) region[1];
            double longitude = (Double) region[2];
            if (!projectGlobeInto(latitude, longitude, point)) continue;
            canvas.drawText((String) region[0], point[0], point[1], textPaint);
        }
    }

    private boolean drawBaseTiles(Canvas canvas) {
        int z = (int) Math.round(zoom);
        int count = 1 << z;
        double scale = Math.pow(2d, zoom - z);
        double size = TILE * scale;
        double centerX = lonToTileX(centerLon, z) * size;
        double centerY = latToTileY(centerLat, z) * size;
        int firstX = (int) Math.floor((centerX - getWidth() / 2d) / size) - 1;
        int lastX = (int) Math.ceil((centerX + getWidth() / 2d) / size) + 1;
        int firstY = Math.max(0, (int) Math.floor((centerY - getHeight() / 2d) / size) - 1);
        int lastY = Math.min(count - 1,
                (int) Math.ceil((centerY + getHeight() / 2d) / size) + 1);
        String signature = z + ":" + firstX + ":" + lastX + ":" + firstY + ":" + lastY;
        long now = SystemClock.uptimeMillis();
        boolean changed = !signature.equals(baseViewportSignature);
        if (changed) {
            baseViewportSignature = signature;
            cachedBaseTiles = buildVisibleTiles(
                    firstX, lastX, firstY, lastY, centerX / size, centerY / size);
            requestBaseViewport(z, count, cachedBaseTiles);
            nextBaseRetryMs = now + 15_000L;
        } else if (now >= nextBaseRetryMs && baseViewportHasMissing(z, count)) {
            // Retry a failed provider on a controlled cadence, never at the 20–30 FPS marker rate.
            requestBaseViewport(z, count, cachedBaseTiles);
            nextBaseRetryMs = now + 15_000L;
        }

        boolean anyRaster = false;
        boolean placeholderLabelDrawn = false;
        for (VisibleTile tile : cachedBaseTiles) {
            int wrappedX = floorMod(tile.x, count);
            float left = (float) (tile.x * size - centerX + getWidth() / 2d);
            float top = (float) (tile.y * size - centerY + getHeight() / 2d);
            RectF destination = new RectF(left, top, (float) (left + size),
                    (float) (top + size));
            String key = baseKey(z, wrappedX, tile.y);
            Bitmap bitmap = baseTiles.peek(key);
            if (bitmap != null) {
                anyRaster = true;
                paint.setAlpha(255);
                canvas.drawBitmap(bitmap, null, destination, paint);
            } else if (drawParentTileFallback(canvas, destination, z, wrappedX, tile.y)) {
                anyRaster = true;
            } else {
                drawStableTilePlaceholder(canvas, destination, z, wrappedX, tile.y,
                        !placeholderLabelDrawn);
                placeholderLabelDrawn = true;
            }
        }
        paint.setAlpha(255);
        return anyRaster;
    }

    private List<VisibleTile> buildVisibleTiles(
            int firstX,
            int lastX,
            int firstY,
            int lastY,
            double centerTileX,
            double centerTileY) {
        List<VisibleTile> visible = new ArrayList<>();
        for (int tileX = firstX; tileX <= lastX; tileX++) {
            for (int tileY = firstY; tileY <= lastY; tileY++) {
                double dx = tileX - centerTileX;
                double dy = tileY - centerTileY;
                visible.add(new VisibleTile(tileX, tileY, dx * dx + dy * dy));
            }
        }
        Collections.sort(visible, (first, second) -> first.distance == second.distance
                ? 0 : first.distance < second.distance ? -1 : 1);
        return Collections.unmodifiableList(visible);
    }

    /**
     * Schedules one exact request per visible tile, with Esri satellite and the dark provider
     * sharing the same cache key. Parent imagery is requested at two coarser levels so zooming
     * never removes the last useful map before sharper pixels arrive.
     */
    private void requestBaseViewport(int z, int count, List<VisibleTile> visible) {
        Set<String> keep = new HashSet<>();
        for (VisibleTile tile : visible) {
            int wrappedX = floorMod(tile.x, count);
            String key = baseKey(z, wrappedX, tile.y);
            keep.add(key);
            addParentKeys(keep, z, wrappedX, tile.y);
        }
        baseViewportKeys = Collections.unmodifiableSet(keep);
        baseTiles.prioritizeViewport(baseViewportKeys);
        for (VisibleTile tile : visible) {
            int wrappedX = floorMod(tile.x, count);
            requestBaseTile(z, wrappedX, tile.y);
            for (int difference = 1; difference <= 2 && z - difference >= 0; difference++) {
                int parentZ = z - difference;
                requestBaseTile(parentZ, wrappedX >> difference, tile.y >> difference);
            }
        }
    }

    private void requestBaseTile(int z, int x, int y) {
        int count = 1 << z;
        int wrappedX = floorMod(x, count);
        if (y < 0 || y >= count) return;
        String key = baseKey(z, wrappedX, y);
        String primary = String.format(Locale.US, AppConfig.SATELLITE_TILES,
                z, y, wrappedX);
        String fallback = String.format(Locale.US, AppConfig.DARK_FALLBACK_TILES,
                z, wrappedX, y);
        // One key and one request owns both providers, preventing duplicate cache churn.
        baseTiles.request(key, primary, fallback, BASE_MAX_AGE, this::onBaseTileReady);
    }

    private void onBaseTileReady() {
        postInvalidateOnAnimation();
    }

    private boolean baseViewportHasMissing(int z, int count) {
        for (VisibleTile tile : cachedBaseTiles) {
            String key = baseKey(z, floorMod(tile.x, count), tile.y);
            if (baseTiles.peek(key) == null) return true;
        }
        return false;
    }

    private void addParentKeys(Set<String> keys, int z, int x, int y) {
        for (int difference = 1; difference <= 2 && z - difference >= 0; difference++) {
            int parentZ = z - difference;
            keys.add(baseKey(parentZ, x >> difference, y >> difference));
        }
    }

    private boolean drawParentTileFallback(
            Canvas canvas,
            RectF destination,
            int z,
            int x,
            int y) {
        for (int difference = 1; difference <= 2 && z - difference >= 0; difference++) {
            int parentZ = z - difference;
            Bitmap parent = baseTiles.peek(baseKey(
                    parentZ, x >> difference, y >> difference));
            if (parent == null) continue;
            int subdivisions = 1 << difference;
            int localX = floorMod(x, subdivisions);
            int localY = floorMod(y, subdivisions);
            int sourceLeft = parent.getWidth() * localX / subdivisions;
            int sourceTop = parent.getHeight() * localY / subdivisions;
            int sourceRight = parent.getWidth() * (localX + 1) / subdivisions;
            int sourceBottom = parent.getHeight() * (localY + 1) / subdivisions;
            paint.setAlpha(difference == 1 ? 244 : 226);
            canvas.drawBitmap(parent,
                    new Rect(sourceLeft, sourceTop, sourceRight, sourceBottom),
                    destination, paint);
            return true;
        }
        return false;
    }

    /** A deterministic geographic placeholder prevents black holes while every provider retries. */
    private void drawStableTilePlaceholder(
            Canvas canvas,
            RectF destination,
            int z,
            int x,
            int y,
            boolean showLabel) {
        boolean alternate = ((x + y) & 1) == 0;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(alternate
                ? Color.rgb(8, 18, 24) : Color.rgb(7, 15, 21));
        canvas.drawRect(destination, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, getResources().getDisplayMetrics().density * 0.55f));
        paint.setColor(Color.argb(80, 52, 91, 104));
        canvas.drawRect(destination, paint);
        canvas.drawLine(destination.left, destination.centerY(),
                destination.right, destination.centerY(), paint);
        canvas.drawLine(destination.centerX(), destination.top,
                destination.centerX(), destination.bottom, paint);
        if (showLabel && destination.width() >= 110f && destination.height() >= 80f) {
            textPaint.setTypeface(android.graphics.Typeface.MONOSPACE);
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setTextSize(6.5f * getResources().getDisplayMetrics().scaledDensity);
            textPaint.setColor(Color.argb(155, 130, 160, 171));
            canvas.drawText("IMAGERY SYNC  " + z + "/" + x + "/" + y,
                    destination.centerX(), destination.centerY() - 6f, textPaint);
            textPaint.setTextSize(5.5f * getResources().getDisplayMetrics().scaledDensity);
            textPaint.setColor(Color.argb(125, 98, 128, 140));
            canvas.drawText("PINNED VIEWPORT • RETRY 15S",
                    destination.centerX(), destination.centerY() + 8f, textPaint);
        }
    }

    private static String baseKey(int z, int x, int y) {
        return "base_" + z + "_" + x + "_" + y;
    }

    private void invalidateBaseViewport() {
        baseViewportSignature = "";
        cachedBaseTiles = Collections.emptyList();
        baseViewportKeys = Collections.emptySet();
        nextBaseRetryMs = 0L;
    }

    private void drawFallbackGeography(Canvas canvas) {
        if (zoom > 8d) return;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(78, 35, 73, 69));
        for (double[][] polygon : LAND_MASSES) {
            geographyPath.reset();
            for (int index = 0; index < polygon.length; index++) {
                float[] point = project(polygon[index][0], polygon[index][1]);
                if (index == 0) geographyPath.moveTo(point[0], point[1]);
                else geographyPath.lineTo(point[0], point[1]);
            }
            geographyPath.close();
            canvas.drawPath(geographyPath, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1.5f);
            paint.setColor(Color.argb(135, 90, 139, 126));
            canvas.drawPath(geographyPath, paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb(78, 35, 73, 69));
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.5f);
        paint.setColor(Color.argb(170, 112, 177, 201));
        float centerX = getWidth() / 2f;
        float centerY = getHeight() / 2f;
        canvas.drawCircle(centerX, centerY, 9f, paint);
        canvas.drawLine(centerX - 15f, centerY, centerX + 15f, centerY, paint);
        canvas.drawLine(centerX, centerY - 15f, centerX, centerY + 15f, paint);
    }

    private void drawFastStartStatus(Canvas canvas) {
        float density = getResources().getDisplayMetrics().density;
        textPaint.setTypeface(android.graphics.Typeface.MONOSPACE);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(7f * getResources().getDisplayMetrics().scaledDensity);
        textPaint.setColor(Color.rgb(155, 187, 199));
        textPaint.setShadowLayer(4f * density, 0f, density, Color.BLACK);
        canvas.drawText("SATELLITE SYNC • PINNED FALLBACK ACTIVE",
                getWidth() / 2f, getHeight() * 0.56f, textPaint);
        textPaint.clearShadowLayer();
    }

    private void drawRadarTiles(Canvas canvas) {
        int mapZ = (int) Math.round(zoom);
        int radarZ = Math.min(7, mapZ);
        int count = 1 << radarZ;
        double mapScale = Math.pow(2d, zoom - radarZ);
        double size = TILE * mapScale;
        double centerX = lonToTileX(centerLon, radarZ) * size;
        double centerY = latToTileY(centerLat, radarZ) * size;
        int firstX = (int) Math.floor((centerX - getWidth() / 2d) / size) - 1;
        int lastX = (int) Math.ceil((centerX + getWidth() / 2d) / size) + 1;
        int firstY = Math.max(0, (int) Math.floor((centerY - getHeight() / 2d) / size) - 1);
        int lastY = Math.min(count - 1,
                (int) Math.ceil((centerY + getHeight() / 2d) / size) + 1);
        for (int tileX = firstX; tileX <= lastX; tileX++) {
            int wrappedX = floorMod(tileX, count);
            for (int tileY = firstY; tileY <= lastY; tileY++) {
                float left = (float) (tileX * size - centerX + getWidth() / 2d);
                float top = (float) (tileY * size - centerY + getHeight() / 2d);
                RectF destination = new RectF(left, top, (float) (left + size),
                        (float) (top + size));
                String key = "radar_" + radarTimeMs + "_" + radarZ + "_"
                        + wrappedX + "_" + tileY;
                String url = radarHost + radarPath + "/256/" + radarZ + "/"
                        + wrappedX + "/" + tileY + "/2/1_1.png";
                Bitmap bitmap = overlayTiles.request(
                        key, url, null, RADAR_MAX_AGE, this::invalidate);
                if (bitmap != null) {
                    paint.setAlpha(155);
                    canvas.drawBitmap(bitmap, null, destination, paint);
                    paint.setAlpha(255);
                }
            }
        }
    }

    /** Transparent CARTO labels keep city, road and boundary detail readable on imagery. */
    private void drawLabelTiles(Canvas canvas) {
        int z = (int) Math.round(zoom);
        int count = 1 << z;
        double scale = Math.pow(2d, zoom - z);
        double size = TILE * scale;
        double centerX = lonToTileX(centerLon, z) * size;
        double centerY = latToTileY(centerLat, z) * size;
        int firstX = (int) Math.floor((centerX - getWidth() / 2d) / size) - 1;
        int lastX = (int) Math.ceil((centerX + getWidth() / 2d) / size) + 1;
        int firstY = Math.max(0, (int) Math.floor((centerY - getHeight() / 2d) / size) - 1);
        int lastY = Math.min(count - 1,
                (int) Math.ceil((centerY + getHeight() / 2d) / size) + 1);
        for (int tileX = firstX; tileX <= lastX; tileX++) {
            int wrappedX = floorMod(tileX, count);
            for (int tileY = firstY; tileY <= lastY; tileY++) {
                float left = (float) (tileX * size - centerX + getWidth() / 2d);
                float top = (float) (tileY * size - centerY + getHeight() / 2d);
                RectF destination = new RectF(left, top, (float) (left + size),
                        (float) (top + size));
                String key = "labels_" + z + "_" + wrappedX + "_" + tileY;
                String url = String.format(Locale.US, AppConfig.LABEL_TILES,
                        z, wrappedX, tileY);
                Bitmap bitmap = overlayTiles.request(
                        key, url, null, BASE_MAX_AGE, this::invalidate);
                if (bitmap != null) {
                    paint.setAlpha(238);
                    canvas.drawBitmap(bitmap, null, destination, paint);
                    paint.setAlpha(255);
                }
            }
        }
    }

    private void drawMapModeStatus(Canvas canvas) {
        float density = getResources().getDisplayMetrics().density;
        float scaled = getResources().getDisplayMetrics().scaledDensity;
        textPaint.setTypeface(android.graphics.Typeface.MONOSPACE);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(6.8f * scaled);
        textPaint.setColor(Color.argb(205, 186, 211, 220));
        textPaint.setShadowLayer(4f * density, 0f, density, Color.BLACK);
        canvas.drawText(String.format(Locale.US,
                        "SAT TRACK  Z%.1f  •  %.4f  %.4f  •  PINCH / DRAG",
                        zoom, centerLat, centerLon),
                getWidth() / 2f, 135f * density, textPaint);
        textPaint.clearShadowLayer();
    }

    /**
     * Event-driven rings are painted below markers. They expire instead of producing
     * permanent dashboard blinking, and their rhythms differ by operational state.
     */
    private void drawActivityPulses(Canvas canvas) {
        if (activityPulses.isEmpty()) return;
        float density = getResources().getDisplayMetrics().density;
        float[] point = new float[2];
        for (int index = activityPulses.size() - 1; index >= 0; index--) {
            ActivityPulse pulse = activityPulses.get(index);
            long elapsed = animationTimeMs - pulse.startedMs;
            if (elapsed < 0L || elapsed >= pulse.durationMs) {
                activityPulses.remove(index);
                continue;
            }
            if (!projectInto(pulse.signal.latitude, pulse.signal.longitude, point)) continue;
            float progress = elapsed / (float) pulse.durationMs;
            int repetitions = pulse.color == Color.rgb(219, 73, 80) ? 3
                    : pulse.color == Color.rgb(199, 151, 68) ? 2 : 1;
            float beat = (float) Math.abs(Math.sin(progress * Math.PI * repetitions));
            float radius = (10f + progress * 58f + beat * 7f) * density;
            int alpha = (int) ((1f - progress) * (65f + beat * 145f));
            glowPaint.setShader(null);
            glowPaint.setStyle(Paint.Style.STROKE);
            glowPaint.setStrokeWidth((1.1f + beat * 1.6f) * density);
            glowPaint.setColor(Color.argb(Math.max(0, Math.min(255, alpha)),
                    Color.red(pulse.color), Color.green(pulse.color),
                    Color.blue(pulse.color)));
            canvas.drawCircle(point[0], point[1], radius, glowPaint);
            if (repetitions > 1) {
                glowPaint.setStrokeWidth(Math.max(1f, 0.8f * density));
                glowPaint.setColor(Color.argb(Math.max(0, alpha / 2),
                        Color.red(pulse.color), Color.green(pulse.color),
                        Color.blue(pulse.color)));
                canvas.drawCircle(point[0], point[1], radius * 0.62f, glowPaint);
            }
        }
    }

    private void drawDuDetectionHud(Canvas canvas) {
        if (signals == null || signals.isEmpty()) return;
        float[] point = new float[2];
        int drawn = 0;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth((1f * density));
        for (Signal signal : signals) {
            if (signal == null || !signal.hasLocation()) continue;
            if (signal.layer != Signal.Layer.FLIGHTS
                    && signal.layer != Signal.Layer.SHIPS
                    && signal.layer != Signal.Layer.SATELLITES
                    && signal.layer != Signal.Layer.NATURAL
                    && signal.layer != Signal.Layer.WEBCAMS) continue;
            double[] display = new double[2];
            displayPosition(signal, display);
            if (!projectInto(display[0], display[1], point)) continue;
            if (point[0] < 0 || point[0] > getWidth() || point[1] < 0 || point[1] > getHeight()) continue;
            int color = signal.severity >= 4 ? Color.rgb(218,70,76)
                    : signal.severity >= 2 ? Color.rgb(225,168,72)
                    : Color.rgb(78,190,132);
            paint.setColor(color);
            float box = dp(signal.id.equals(trackedSignalId) ? 22 : 15);
            canvas.drawRect(point[0]-box, point[1]-box, point[0]+box, point[1]+box, paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setTextSize((8f * density));
            String label = signal.layer.name()+" · "+compactHudId(signal.id);
            canvas.drawText(label, point[0]-box, point[1]-box-(3f * density), paint);
            if (signal.id.equals(trackedSignalId)) {
                paint.setTextSize((7f * density));
                canvas.drawText("TRACK LOCK", point[0]-box, point[1]+box+(10f * density), paint);
            }
            paint.setStyle(Paint.Style.STROKE);
            if (++drawn >= DuPerformancePolicy.hudBudget(getContext())) break;
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize((8f * density));
        paint.setColor(Color.rgb(78,190,132)); canvas.drawText("● NORMAL", (12f * density), getHeight()-(42f * density), paint);
        paint.setColor(Color.rgb(225,168,72)); canvas.drawText("● DEGRADED", (86f * density), getHeight()-(42f * density), paint);
        paint.setColor(Color.rgb(218,70,76)); canvas.drawText("● CRITICAL", (176f * density), getHeight()-(42f * density), paint);
    }

    private static String compactHudId(String id) {
        if (id == null) return "—";
        return id.length() <= 16 ? id : id.substring(0, 15) + "…";
    }

    private void drawSignals(Canvas canvas) {
        float[] point = new float[2];
        float[] sourcePoint = new float[2];
        double[] display = new double[2];
        int trafficStride = Math.max(1,
                (signals.size() + MAX_TRAFFIC_MARKERS - 1) / MAX_TRAFFIC_MARKERS);
        for (Signal signal : signals) {
            if (!signal.hasLocation()) {
                continue;
            }
            boolean traffic = signal.layer == Signal.Layer.FLIGHTS
                    || signal.layer == Signal.Layer.SHIPS;
            if (traffic && trafficStride > 1
                    && Math.floorMod(signal.id.hashCode(), trafficStride) != 0) {
                continue;
            }
            displayPosition(signal, display);
            if (!projectInto(display[0], display[1], point)
                    || point[0] < -40 || point[1] < -40
                    || point[0] > getWidth() + 40 || point[1] > getHeight() + 40) {
                continue;
            }
            int color = colorFor(signal);
            if (traffic && !globeMode
                    && (zoom >= 6.5d || signal.id.equals(followedSignalId))) {
                drawObservedFixTrail(canvas, signal, color);
            }
            if (traffic && !globeMode
                    && (display[0] != signal.latitude || display[1] != signal.longitude)
                    && projectInto(signal.latitude, signal.longitude, sourcePoint)) {
                drawProviderFixLink(canvas, sourcePoint[0], sourcePoint[1],
                        point[0], point[1], color);
            }
            if (signal.layer == Signal.Layer.FLIGHTS) {
                drawMotionTrail(canvas, signal, point[0], point[1], color, false);
                drawAircraft(canvas, point[0], point[1], (float) signal.heading, color);
            } else if (signal.layer == Signal.Layer.SHIPS) {
                drawMotionTrail(canvas, signal, point[0], point[1], color, true);
                drawShip(canvas, point[0], point[1], color);
            } else if (signal.layer == Signal.Layer.SATELLITES) {
                drawSatellite(canvas, signal, point[0], point[1], color);
                if (!globeMode && zoom >= 5.5d && shouldDrawReferenceLabel(signal)) {
                    drawReferenceLabel(canvas, signal, point[0], point[1], color);
                }
            } else if (signal.layer == Signal.Layer.AIRSPACE) {
                drawAirspaceWarning(canvas, signal, point[0], point[1], color);
            } else if (signal.layer == Signal.Layer.WEBCAMS) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(color);
                canvas.drawRect(point[0] - 5, point[1] - 5, point[0] + 5, point[1] + 5, paint);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2f);
                paint.setColor(Color.WHITE);
                canvas.drawRect(point[0] - 7, point[1] - 7, point[0] + 7, point[1] + 7, paint);
            } else if (signal.layer == Signal.Layer.INFRASTRUCTURE) {
                // Static context uses a hollow diamond so it cannot be mistaken for a live
                // incident, aircraft, vessel or active camera.
                markerPath.reset();
                markerPath.moveTo(point[0], point[1] - 7f);
                markerPath.lineTo(point[0] + 7f, point[1]);
                markerPath.lineTo(point[0], point[1] + 7f);
                markerPath.lineTo(point[0] - 7f, point[1]);
                markerPath.close();
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(1.5f);
                paint.setColor(color);
                canvas.drawPath(markerPath, paint);
                if (!globeMode && shouldDrawReferenceLabel(signal)) {
                    drawReferenceLabel(canvas, signal, point[0], point[1], color);
                }
            } else {
                float radius = 6f + signal.severity * 1.3f;
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(1.6f);
                paint.setColor(Color.argb(92,
                        Color.red(color), Color.green(color), Color.blue(color)));
                canvas.drawCircle(point[0], point[1],
                        radius + 5f + signal.severity * 1.2f, paint);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(color);
                canvas.drawCircle(point[0], point[1], radius, paint);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(1.5f);
                paint.setColor(Color.WHITE);
                canvas.drawCircle(point[0], point[1], radius, paint);
            }
            if (traffic && !globeMode
                    && (zoom >= (signal.layer == Signal.Layer.FLIGHTS ? 7d : 8d)
                    || signal.id.equals(followedSignalId))) {
                drawTrafficLabel(canvas, signal, point[0], point[1], color);
            }
        }
    }

    private void drawSatellite(
            Canvas canvas, Signal signal, float x, float y, int color) {
        float density = getResources().getDisplayMetrics().density;
        if (!Double.isNaN(signal.heading)) {
            double radians = Math.toRadians(signal.heading);
            float dx = (float) Math.sin(radians);
            float dy = (float) -Math.cos(radians);
            trailPaint.setShader(null);
            trailPaint.setStrokeWidth(0.8f * density);
            trailPaint.setColor(Color.argb(92,
                    Color.red(color), Color.green(color), Color.blue(color)));
            canvas.drawLine(x - dx * 18f * density, y - dy * 18f * density,
                    x - dx * 4f * density, y - dy * 4f * density, trailPaint);
        }
        float size = globeMode ? 3.6f * density : 4.8f * density;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1f * density);
        paint.setColor(Color.argb(135,
                Color.red(color), Color.green(color), Color.blue(color)));
        canvas.drawCircle(x, y, size + 2.6f * density, paint);
        markerPath.reset();
        markerPath.moveTo(x, y - size);
        markerPath.lineTo(x + size, y);
        markerPath.lineTo(x, y + size);
        markerPath.lineTo(x - size, y);
        markerPath.close();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        canvas.drawPath(markerPath, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(0.9f * density);
        paint.setColor(Color.rgb(236, 241, 245));
        canvas.drawPath(markerPath, paint);
    }

    private void drawAirspaceWarning(
            Canvas canvas, Signal signal, float x, float y, int color) {
        float density = getResources().getDisplayMetrics().density;
        float size = (5f + signal.severity * 0.9f) * density;
        markerPath.reset();
        markerPath.moveTo(x, y - size);
        markerPath.lineTo(x + size * 0.88f, y + size * 0.7f);
        markerPath.lineTo(x - size * 0.88f, y + size * 0.7f);
        markerPath.close();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.35f * density);
        paint.setColor(color);
        canvas.drawPath(markerPath, paint);
        paint.setColor(Color.argb(72,
                Color.red(color), Color.green(color), Color.blue(color)));
        canvas.drawCircle(x, y, size + 4f * density, paint);
    }

    private void drawProviderFixLink(
            Canvas canvas,
            float sourceX,
            float sourceY,
            float estimateX,
            float estimateY,
            int color) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1f * getResources().getDisplayMetrics().density);
        paint.setColor(Color.argb(120, Color.red(color), Color.green(color), Color.blue(color)));
        canvas.drawLine(sourceX, sourceY, estimateX, estimateY, paint);
        paint.setColor(Color.argb(210, 235, 241, 244));
        canvas.drawCircle(sourceX, sourceY,
                2.1f * getResources().getDisplayMetrics().density, paint);
    }

    private void drawTrafficLabel(
            Canvas canvas,
            Signal signal,
            float x,
            float y,
            int color) {
        float density = getResources().getDisplayMetrics().density;
        float scaled = getResources().getDisplayMetrics().scaledDensity;
        String secondary = signal.layer == Signal.Layer.FLIGHTS
                ? safeFact(signal, "ALTITUDE") + "  •  " + safeFact(signal, "SPEED")
                : safeFact(signal, "TYPE") + "  •  " + safeFact(signal, "SPEED");
        String title = signal.title.length() > 24
                ? signal.title.substring(0, 24) : signal.title;
        textPaint.setTypeface(android.graphics.Typeface.MONOSPACE);
        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setTextSize(8f * scaled);
        float width = Math.max(textPaint.measureText(title), textPaint.measureText(secondary))
                + 12f * density;
        float left = x + 10f * density;
        if (left + width > getWidth() - 4f * density) left = x - width - 10f * density;
        float top = y - 23f * density;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(205, 4, 8, 12));
        canvas.drawRect(left, top, left + width, top + 31f * density, paint);
        paint.setColor(color);
        canvas.drawRect(left, top, left + 2f * density, top + 31f * density, paint);
        textPaint.setColor(Color.rgb(235, 241, 244));
        canvas.drawText(title, left + 7f * density, top + 12f * density, textPaint);
        textPaint.setTextSize(7f * scaled);
        textPaint.setColor(Color.rgb(159, 177, 187));
        canvas.drawText(secondary, left + 7f * density, top + 25f * density, textPaint);
    }

    private static String safeFact(Signal signal, String key) {
        String value = signal.facts.get(key);
        return value == null || value.trim().isEmpty() ? "NOT REPORTED" : value;
    }

    private void drawMotionTrail(
            Canvas canvas,
            Signal signal,
            float x,
            float y,
            int color,
            boolean ship) {
        if (Double.isNaN(signal.heading)) return;
        float density = getResources().getDisplayMetrics().density;
        float heading = (float) signal.heading;
        double radians = Math.toRadians(heading);
        float directionX = (float) Math.sin(radians);
        float directionY = (float) -Math.cos(radians);
        float length = (ship ? 17f : 25f) * density;

        trailPaint.setShader(null);
        trailPaint.setStrokeWidth((ship ? 1.2f : 1.0f) * density);
        trailPaint.setColor(Color.argb(ship ? 92 : 112,
                Color.red(color), Color.green(color), Color.blue(color)));
        canvas.drawLine(x - directionX * length, y - directionY * length,
                x - directionX * 5f * density, y - directionY * 5f * density,
                trailPaint);
    }

    private void drawObservedFixTrail(Canvas canvas, Signal signal, int color) {
        Deque<TrackPoint> history = observedTracks.get(signal.id);
        if (history == null || history.size() < 2) return;
        float density = getResources().getDisplayMetrics().density;
        float[] previous = new float[2];
        float[] current = new float[2];
        boolean havePrevious = false;
        int segment = 0;
        for (TrackPoint fix : history) {
            if (!projectInto(fix.latitude, fix.longitude, current)) {
                havePrevious = false;
                continue;
            }
            if (havePrevious) {
                float dx = current[0] - previous[0];
                float dy = current[1] - previous[1];
                // A dateline wrap should not draw a line across the entire display.
                if (dx * dx + dy * dy < getWidth() * getWidth() * 0.36f) {
                    trailPaint.setShader(null);
                    trailPaint.setStrokeWidth((signal.id.equals(followedSignalId)
                            ? 2.1f : 1.15f) * density);
                    int alpha = Math.min(210, 58 + segment * 16);
                    trailPaint.setColor(Color.argb(alpha,
                            Color.red(color), Color.green(color), Color.blue(color)));
                    canvas.drawLine(previous[0], previous[1], current[0], current[1], trailPaint);
                }
                segment++;
            }
            previous[0] = current[0];
            previous[1] = current[1];
            havePrevious = true;
        }
    }

    private boolean shouldDrawReferenceLabel(Signal signal) {
        int divisor = zoom >= 10d ? 1 : zoom >= 8d ? 3 : zoom >= 6d ? 7 : 15;
        return Math.floorMod(signal.id.hashCode(), divisor) == 0;
    }

    private void drawReferenceLabel(
            Canvas canvas,
            Signal signal,
            float x,
            float y,
            int color) {
        float density = getResources().getDisplayMetrics().density;
        float scaled = getResources().getDisplayMetrics().scaledDensity;
        String title = signal.title.length() > 22
                ? signal.title.substring(0, 21) + "…" : signal.title;
        String category = signal.layer == Signal.Layer.SATELLITES
                ? safeFact(signal, "ALTITUDE ESTIMATE")
                : signal.layer == Signal.Layer.AIRSPACE
                ? safeFact(signal, "HAZARD") : safeFact(signal, "CATEGORY");
        textPaint.setTypeface(android.graphics.Typeface.MONOSPACE);
        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setTextSize(6.8f * scaled);
        textPaint.setColor(Color.argb(220, 224, 234, 238));
        textPaint.setShadowLayer(3.5f * density, 0f, density, Color.BLACK);
        float left = x + 8f * density;
        if (left + textPaint.measureText(title) > getWidth() - 4f * density) {
            left = Math.max(4f * density,
                    x - textPaint.measureText(title) - 8f * density);
        }
        canvas.drawText(title, left, y - 2f * density, textPaint);
        if (zoom >= 8d) {
            textPaint.setTextSize(5.8f * scaled);
            textPaint.setColor(Color.argb(200,
                    Color.red(color), Color.green(color), Color.blue(color)));
            canvas.drawText(category, left, y + 8f * density, textPaint);
        }
        textPaint.clearShadowLayer();
    }

    private void drawAcquisitionHighlight(Canvas canvas) {
        Signal signal = highlightedSignal;
        if (signal == null || !signal.hasLocation()) return;
        long elapsed = animationTimeMs - highlightStartedMs;
        if (elapsed > 4_800L) {
            highlightedSignal = null;
            return;
        }
        float[] point = new float[2];
        double[] display = new double[2];
        displayPosition(signal, display);
        if (!projectInto(display[0], display[1], point)) return;
        float progress = Math.min(1f, elapsed / 4_800f);
        float cycle = (elapsed % 900L) / 900f;
        float radius = 18f + cycle * 42f;
        int color = colorFor(signal);
        int alpha = (int) ((1f - progress * 0.72f) * (210f - cycle * 100f));
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.2f);
        paint.setColor(Color.argb(Math.max(20, alpha),
                Color.red(color), Color.green(color), Color.blue(color)));
        canvas.drawCircle(point[0], point[1], radius, paint);

        float bracket = 16f;
        float gap = 8f;
        paint.setStrokeWidth(2.8f);
        paint.setColor(Color.argb(220, Color.red(color), Color.green(color), Color.blue(color)));
        canvas.drawLine(point[0] - bracket, point[1] - bracket,
                point[0] - gap, point[1] - bracket, paint);
        canvas.drawLine(point[0] - bracket, point[1] - bracket,
                point[0] - bracket, point[1] - gap, paint);
        canvas.drawLine(point[0] + bracket, point[1] + bracket,
                point[0] + gap, point[1] + bracket, paint);
        canvas.drawLine(point[0] + bracket, point[1] + bracket,
                point[0] + bracket, point[1] + gap, paint);
    }

    private void drawAircraft(Canvas canvas, float x, float y, float heading, int color) {
        canvas.save();
        canvas.rotate(Double.isNaN(heading) ? 0f : heading, x, y);
        markerPath.reset();
        markerPath.moveTo(x, y - 10f);
        markerPath.lineTo(x + 6f, y + 8f);
        markerPath.lineTo(x, y + 5f);
        markerPath.lineTo(x - 6f, y + 8f);
        markerPath.close();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        canvas.drawPath(markerPath, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1f);
        paint.setColor(Color.WHITE);
        canvas.drawPath(markerPath, paint);
        canvas.restore();
    }

    private void drawShip(Canvas canvas, float x, float y, int color) {
        markerPath.reset();
        markerPath.moveTo(x, y - 8f);
        markerPath.lineTo(x + 7f, y);
        markerPath.lineTo(x, y + 9f);
        markerPath.lineTo(x - 7f, y);
        markerPath.close();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        canvas.drawPath(markerPath, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1f);
        paint.setColor(Color.WHITE);
        canvas.drawPath(markerPath, paint);
    }

    /**
     * Dead-reckons only traffic records with provider speed and course. The estimate is
     * deliberately short and capped; the hollow marker/line continues to show the actual
     * provider fix so estimated motion is never confused with a new observation.
     */
    private void displayPosition(Signal signal, double[] output) {
        output[0] = signal.latitude;
        output[1] = signal.longitude;
        if (signal.layer != Signal.Layer.FLIGHTS && signal.layer != Signal.Layer.SHIPS) return;
        if (Double.isNaN(signal.speedMetersPerSecond) || signal.speedMetersPerSecond < 0.5d
                || Double.isNaN(signal.heading)) return;
        String state = signal.facts.get("STATE");
        if (state != null && state.toLowerCase(Locale.ROOT).contains("ground")) return;
        long now = frameWallTimeMs > 0L ? frameWallTimeMs : System.currentTimeMillis();
        long age = Math.max(0L, now - signal.timestampMs);
        long limit = signal.layer == Signal.Layer.FLIGHTS
                ? FLIGHT_ESTIMATE_LIMIT_MS : VESSEL_ESTIMATE_LIMIT_MS;
        long usedAge = Math.min(age, limit);
        if (usedAge < 500L) return;
        double angularDistance = signal.speedMetersPerSecond * usedAge / 1000d / 6_371_000d;
        double bearing = Math.toRadians(signal.heading);
        double latitude = Math.toRadians(signal.latitude);
        double longitude = Math.toRadians(signal.longitude);
        double nextLatitude = Math.asin(Math.sin(latitude) * Math.cos(angularDistance)
                + Math.cos(latitude) * Math.sin(angularDistance) * Math.cos(bearing));
        double nextLongitude = longitude + Math.atan2(
                Math.sin(bearing) * Math.sin(angularDistance) * Math.cos(latitude),
                Math.cos(angularDistance) - Math.sin(latitude) * Math.sin(nextLatitude));
        output[0] = Math.toDegrees(nextLatitude);
        output[1] = wrapLongitude(Math.toDegrees(nextLongitude));
    }

    private Signal findById(String id) {
        if (id == null || id.isEmpty()) return null;
        for (Signal signal : signals) {
            if (id.equals(signal.id)) return signal;
        }
        return null;
    }

    private void updateFollowCenter() {
        Signal signal = followedSignal;
        if (signal == null || !signal.hasLocation() || globeMode) return;
        double[] display = new double[2];
        displayPosition(signal, display);
        centerLat = clamp(display[0], -85d, 85d);
        centerLon = wrapLongitude(display[1]);
    }

    private String trackingAge(Signal signal) {
        long now = frameWallTimeMs > 0L ? frameWallTimeMs : System.currentTimeMillis();
        long age = Math.max(0L, now - signal.timestampMs);
        long limit = signal.layer == Signal.Layer.FLIGHTS
                ? FLIGHT_ESTIMATE_LIMIT_MS : VESSEL_ESTIMATE_LIMIT_MS;
        boolean movable = !Double.isNaN(signal.speedMetersPerSecond)
                && signal.speedMetersPerSecond >= 0.5d && !Double.isNaN(signal.heading);
        if (!movable) return String.format(Locale.US, "SOURCE FIX %,ds OLD", age / 1000L);
        if (age > limit) {
            return String.format(Locale.US,
                    "SOURCE FIX %,ds OLD • ESTIMATE HELD AT %ds LIMIT",
                    age / 1000L, limit / 1000L);
        }
        return String.format(Locale.US, "SOURCE FIX %,ds OLD • SHORT ESTIMATE ACTIVE",
                age / 1000L);
    }

    private void drawTrackedCallout(Canvas canvas) {
        Signal signal = followedSignal;
        if (globeMode || signal == null || !signal.hasLocation()) return;
        float density = getResources().getDisplayMetrics().density;
        float scaled = getResources().getDisplayMetrics().scaledDensity;
        float width = Math.min(getWidth() - 20f * density, 340f * density);
        float left = (getWidth() - width) / 2f;
        float bottom = getHeight() - 36f * density;
        float top = bottom - 74f * density;
        int accent = colorFor(signal);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(230, 4, 8, 12));
        canvas.drawRoundRect(new RectF(left, top, left + width, bottom),
                5f * density, 5f * density, paint);
        paint.setColor(accent);
        canvas.drawRect(left, top, left + 3f * density, bottom, paint);
        textPaint.setTypeface(android.graphics.Typeface.MONOSPACE);
        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setTextSize(8f * scaled);
        textPaint.setColor(accent);
        canvas.drawText("FOLLOWING " + signal.layer.name() + " • " + signal.source,
                left + 10f * density, top + 16f * density, textPaint);
        textPaint.setTextSize(11f * scaled);
        textPaint.setColor(Color.rgb(238, 243, 246));
        String title = signal.title.length() > 28
                ? signal.title.substring(0, 28) : signal.title;
        canvas.drawText(title, left + 10f * density, top + 35f * density, textPaint);
        textPaint.setTextSize(8f * scaled);
        textPaint.setColor(Color.rgb(173, 191, 200));
        String metrics = signal.layer == Signal.Layer.FLIGHTS
                ? safeFact(signal, "ALTITUDE") + "  •  " + safeFact(signal, "SPEED")
                : safeFact(signal, "TYPE") + "  •  " + safeFact(signal, "SPEED");
        canvas.drawText(metrics, left + 10f * density, top + 51f * density, textPaint);
        textPaint.setTextSize(7f * scaled);
        textPaint.setColor(Color.rgb(139, 155, 166));
        canvas.drawText(trackingAge(signal), left + 10f * density,
                top + 66f * density, textPaint);
        Deque<TrackPoint> history = observedTracks.get(signal.id);
        if (history != null && history.size() >= 2) {
            textPaint.setTextAlign(Paint.Align.RIGHT);
            textPaint.setColor(Color.rgb(112, 177, 201));
            canvas.drawText("OBSERVED FIX TRAIL " + history.size(),
                    left + width - 10f * density, top + 66f * density, textPaint);
        }
    }

    private void drawAttribution(Canvas canvas) {
        textPaint.setTextSize(10f * getResources().getDisplayMetrics().scaledDensity);
        textPaint.setColor(Color.argb(220, 220, 232, 237));
        textPaint.setTextAlign(Paint.Align.RIGHT);
        textPaint.setShadowLayer(3f, 0f, 1f, Color.BLACK);
        String label;
        if (replayMode && replayEpochMs > 0L) {
            label = replayAttribution;
        } else if (globeMode) {
            label = "Native orthographic globe  •  live layers source-attributed";
        } else {
            label = weatherVisible && !radarPath.trim().isEmpty()
                    ? String.format(Locale.US,
                    "Imagery: Esri  •  Labels: CARTO  •  Radar: RainViewer %02d/%02d",
                    radarFrameIndex + 1, Math.max(1, radarFrames.size()))
                    : "Imagery: Esri  •  Labels/fallback: CARTO";
        }
        canvas.drawText(label, getWidth() - 10f, getHeight() - 10f, textPaint);
        textPaint.clearShadowLayer();
    }

    private Signal findSignal(float x, float y) {
        Signal closest = null;
        double best = 28d * 28d;
        float[] point = new float[2];
        double[] display = new double[2];
        for (Signal signal : signals) {
            if (!signal.hasLocation()) {
                continue;
            }
            displayPosition(signal, display);
            if (!projectInto(display[0], display[1], point)) continue;
            double distance = Math.pow(point[0] - x, 2d) + Math.pow(point[1] - y, 2d);
            if (distance < best) {
                best = distance;
                closest = signal;
            }
        }
        return closest;
    }

    private void rotateGlobeBy(float distanceX, float distanceY) {
        float radius = Math.max(80f, globeRadius());
        centerLon = wrapLongitude(centerLon + distanceX / radius * 84d);
        centerLat = clamp(centerLat - distanceY / radius * 64d, -80d, 80d);
        invalidate();
        notifyViewport();
    }

    private void panBy(float distanceX, float distanceY) {
        double world = TILE * Math.pow(2d, zoom);
        double centerX = (centerLon + 180d) / 360d * world + distanceX;
        double centerY = latToWorldPixel(centerLat, world) + distanceY;
        centerLon = wrapLongitude(centerX / world * 360d - 180d);
        centerLat = worldPixelToLat(clamp(centerY, 0d, world), world);
        invalidate();
        notifyViewport();
    }

    private float[] project(double latitude, double longitude) {
        float[] point = new float[2];
        if (!projectInto(latitude, longitude, point)) {
            point[0] = Float.NaN;
            point[1] = Float.NaN;
        }
        return point;
    }

    /** Projects into a reusable two-float buffer to avoid per-marker allocations. */
    private boolean projectInto(double latitude, double longitude, float[] output) {
        if (globeMode) {
            return projectGlobeInto(latitude, longitude, output);
        }
        double world = TILE * Math.pow(2d, zoom);
        double centerX = (centerLon + 180d) / 360d * world;
        double pointX = (longitude + 180d) / 360d * world;
        double deltaX = pointX - centerX;
        if (deltaX > world / 2d) deltaX -= world;
        if (deltaX < -world / 2d) deltaX += world;
        double centerY = latToWorldPixel(centerLat, world);
        double pointY = latToWorldPixel(latitude, world);
        output[0] = (float) (getWidth() / 2d + deltaX);
        output[1] = (float) (getHeight() / 2d + pointY - centerY);
        return true;
    }

    /** Orthographic projection; false means the coordinate is behind the globe. */
    private boolean projectGlobeInto(double latitude, double longitude, float[] output) {
        double latitudeRadians = Math.toRadians(latitude);
        double centerLatitudeRadians = Math.toRadians(centerLat);
        double longitudeDelta = Math.toRadians(wrapLongitude(longitude - centerLon));
        double sinLatitude = Math.sin(latitudeRadians);
        double cosLatitude = Math.cos(latitudeRadians);
        double sinCenterLatitude = Math.sin(centerLatitudeRadians);
        double cosCenterLatitude = Math.cos(centerLatitudeRadians);
        double visibility = sinCenterLatitude * sinLatitude
                + cosCenterLatitude * cosLatitude * Math.cos(longitudeDelta);
        if (visibility <= 0d) return false;
        float radius = globeRadius();
        output[0] = globeCenterX()
                + (float) (radius * cosLatitude * Math.sin(longitudeDelta));
        output[1] = globeCenterY()
                - (float) (radius * (cosCenterLatitude * sinLatitude
                - sinCenterLatitude * cosLatitude * Math.cos(longitudeDelta)));
        return true;
    }

    private void notifyViewport() {
        if (listener == null || getWidth() == 0 || getHeight() == 0) {
            return;
        }
        if (globeMode) {
            double latitudeSpan = 82d / globeScale;
            double longitudeSpan = 100d / globeScale;
            listener.onViewportChanged(new Bounds(
                    clamp(centerLat - latitudeSpan, -90d, 90d),
                    wrapLongitude(centerLon - longitudeSpan),
                    clamp(centerLat + latitudeSpan, -90d, 90d),
                    wrapLongitude(centerLon + longitudeSpan)));
            return;
        }
        double world = TILE * Math.pow(2d, zoom);
        double centerX = (centerLon + 180d) / 360d * world;
        double centerY = latToWorldPixel(centerLat, world);
        double west = wrapLongitude((centerX - getWidth() / 2d) / world * 360d - 180d);
        double east = wrapLongitude((centerX + getWidth() / 2d) / world * 360d - 180d);
        double north = worldPixelToLat(clamp(centerY - getHeight() / 2d, 0d, world), world);
        double south = worldPixelToLat(clamp(centerY + getHeight() / 2d, 0d, world), world);
        listener.onViewportChanged(new Bounds(south, west, north, east));
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN || event.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN) { if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true); }
        if (event.getActionMasked() == MotionEvent.ACTION_UP || event.getActionMasked() == MotionEvent.ACTION_CANCEL) { if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false); }
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN
                || event.getActionMasked() == MotionEvent.ACTION_MOVE) {
            pauseAutoRotation();
        }
        scales.onTouchEvent(event);
        gestures.onTouchEvent(event);
        if (event.getActionMasked() == MotionEvent.ACTION_UP) {
            performClick();
        }
        return true;
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        if (visibility == View.VISIBLE && isAttachedToWindow()) {
            lastFrameMs = 0L;
            postInvalidateOnAnimation();
        } else {
            removeCallbacks(framePulse);
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(framePulse);
        baseTiles.shutdown();
        overlayTiles.shutdown();
        super.onDetachedFromWindow();
    }

    private static int colorFor(Signal signal) {
        switch (signal.layer) {
            case FLIGHTS: return Color.rgb(112, 177, 201);
            case SHIPS: return Color.rgb(75, 166, 124);
            case WEBCAMS: return Color.rgb(75, 166, 124);
            case RADIO: return Color.rgb(143, 124, 171);
            case TV: return Color.rgb(108, 148, 196);
            case MEDIA: return Color.rgb(113, 143, 173);
            case INFRASTRUCTURE: return Color.rgb(111, 130, 143);
            case AIRSPACE:
                return signal.severity >= 4
                        ? Color.rgb(219, 73, 80) : Color.rgb(225, 158, 61);
            case SATELLITES: return Color.rgb(174, 139, 224);
            case SPACE_WEATHER: return Color.rgb(165, 133, 214);
            case NATURAL:
            case NEWS:
                if (signal.severity >= 4) return Color.rgb(219, 73, 80);
                if (signal.credibility == Signal.Credibility.UNVERIFIED
                        || signal.credibility == Signal.Credibility.REPORTED) {
                    return Color.rgb(199, 151, 68);
                }
                return Color.rgb(75, 166, 124);
            default: return Color.WHITE;
        }
    }

    private static double lonToTileX(double longitude, int zoom) {
        return (longitude + 180d) / 360d * (1 << zoom);
    }

    private static double latToTileY(double latitude, int zoom) {
        double rad = Math.toRadians(clamp(latitude, -85.05112878d, 85.05112878d));
        return (1d - Math.log(Math.tan(rad) + 1d / Math.cos(rad)) / Math.PI)
                / 2d * (1 << zoom);
    }

    private static double latToWorldPixel(double latitude, double world) {
        double rad = Math.toRadians(clamp(latitude, -85.05112878d, 85.05112878d));
        return (1d - Math.log(Math.tan(rad) + 1d / Math.cos(rad)) / Math.PI)
                / 2d * world;
    }

    private static double worldPixelToLat(double pixel, double world) {
        double n = Math.PI - 2d * Math.PI * pixel / world;
        return Math.toDegrees(Math.atan(Math.sinh(n)));
    }

    private static double wrapLongitude(double longitude) {
        double value = (longitude + 180d) % 360d;
        if (value < 0d) value += 360d;
        return value - 180d;
    }

    private static int floorMod(int value, int divisor) {
        int result = value % divisor;
        return result < 0 ? result + divisor : result;
    }

    private static double clamp(double value, double minimum, double maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    public static double distanceKm(double lat1, double lon1, double lat2, double lon2) {
        double earth = 6371d;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2d) * Math.sin(dLat / 2d)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLon / 2d) * Math.sin(dLon / 2d);
        return earth * 2d * Math.atan2(Math.sqrt(a), Math.sqrt(1d - a));
    }
}
